#!/usr/bin/env python3
"""
Tweek Pre-Tool-Use Hook for Claude Code

This hook intercepts tool calls before execution and applies tiered security screening.

Security Layers (Defense in Depth):
1. Rate Limiting - Detect resource theft and burst attacks
2. Pattern Matching - Regex patterns for known attack vectors
3. LLM Review - Semantic analysis for risky/dangerous tiers
4. Session Analysis - Cross-turn anomaly detection
5. Sandbox Preview - Speculative execution (dangerous tier only)

Tiers:
  - safe: No screening (trusted operations)
  - default: Regex pattern matching only
  - risky: Regex + LLM rules
  - dangerous: Regex + LLM + Sandbox preview

Input (stdin): JSON with tool_name and tool_input
Output (stdout): JSON with decision (allow/block/ask) and optional message

Claude Code Hook Protocol:
- Empty response or {}: proceed with tool execution
- "permissionDecision": "ask" - prompt user for confirmation
- "permissionDecision": "deny" - block execution
"""
from __future__ import annotations

import json
import os
import re
import sys
import uuid
from pathlib import Path
from typing import Optional, Dict, List, Any, Tuple

import yaml

# Add parent to path for imports
sys.path.insert(0, str(Path(__file__).parent.parent.parent))

from tweek.logging.security_log import (
    SecurityLogger, SecurityEvent, EventType, get_logger
)
from tweek.hooks.overrides import (
    get_overrides, get_trust_mode, is_protected_config_file,
    bash_targets_protected_config, filter_by_severity, SEVERITY_RANK,
    EnforcementPolicy,
)
from tweek.skills.guard import (
    get_skill_guard_reason,
    get_skill_download_prompt,
)
from tweek.skills.fingerprints import get_fingerprints
from tweek.sandbox.project import get_project_sandbox
from tweek.plugins.base import ReDoSProtection, RegexTimeoutError


# =============================================================================
# PLUGIN SYSTEM INTEGRATION
# =============================================================================

def run_compliance_scans(
    content: str,
    direction: str,
    logger: SecurityLogger,
    session_id: Optional[str] = None,
    tool_name: str = "unknown"
) -> Tuple[bool, Optional[str], List[Dict]]:
    """
    Run all enabled compliance plugins on content.

    Args:
        content: Text content to scan
        direction: "input" or "output"
        logger: Security logger
        session_id: Optional session ID
        tool_name: Tool name for logging

    Returns:
        (should_block, message, findings)
    """
    try:
        from tweek.plugins import get_registry, PluginCategory
        from tweek.plugins.base import ScanDirection, ActionType

        registry = get_registry()
        direction_enum = ScanDirection(direction)

        all_findings = []
        messages = []
        should_block = False

        # Get all enabled compliance plugins
        for plugin in registry.get_all(PluginCategory.COMPLIANCE):
            try:
                result = plugin.scan(content, direction_enum)

                if result.findings:
                    all_findings.extend([f.to_dict() for f in result.findings])

                    if result.message:
                        messages.append(result.message)

                    # Log findings
                    logger.log_quick(
                        EventType.PATTERN_MATCH,
                        tool_name,
                        tier="compliance",
                        pattern_name=f"compliance_{plugin.name}",
                        pattern_severity=result.max_severity.value if result.max_severity else "medium",
                        decision="ask" if result.action != ActionType.BLOCK else "block",
                        decision_reason=f"Compliance scan ({plugin.name}): {len(result.findings)} finding(s)",
                        session_id=session_id,
                        metadata={
                            "plugin": plugin.name,
                            "direction": direction,
                            "findings": [f.pattern_name for f in result.findings],
                            "action": result.action.value,
                        }
                    )

                    if result.action == ActionType.BLOCK:
                        should_block = True

            except Exception as e:
                logger.log_quick(
                    EventType.ERROR,
                    tool_name,
                    decision_reason=f"Compliance plugin {plugin.name} error: {e}",
                    session_id=session_id
                )

        combined_message = "\n\n".join(messages) if messages else None
        return should_block, combined_message, all_findings

    except ImportError:
        # Plugin system not available
        return False, None, []
    except Exception as e:
        logger.log_quick(
            EventType.ERROR,
            tool_name,
            decision_reason=f"Compliance scan error: {e}",
            session_id=session_id
        )
        return False, None, []


def run_screening_plugins(
    tool_name: str,
    content: str,
    context: Dict[str, Any],
    logger: SecurityLogger
) -> Tuple[bool, bool, Optional[str], List[Dict]]:
    """
    Run all enabled screening plugins.

    Args:
        tool_name: Name of the tool
        content: Command/content to screen
        context: Context dict (session_id, tier, etc.)
        logger: Security logger

    Returns:
        (allowed, should_prompt, message, findings)
    """
    try:
        from tweek.plugins import get_registry, PluginCategory

        registry = get_registry()

        allowed = True
        should_prompt = False
        messages = []
        all_findings = []

        for plugin in registry.get_all(PluginCategory.SCREENING):
            try:
                result = plugin.screen(tool_name, content, context)

                if result.findings:
                    all_findings.extend([f.to_dict() for f in result.findings])

                if not result.allowed:
                    allowed = False

                if result.should_prompt:
                    should_prompt = True

                if result.reason and (not result.allowed or result.should_prompt):
                    messages.append(f"[{plugin.name}] {result.reason}")

            except Exception as e:
                logger.log_quick(
                    EventType.ERROR,
                    tool_name,
                    decision_reason=f"Screening plugin {plugin.name} error: {e}",
                    session_id=context.get("session_id")
                )

        combined_message = "\n".join(messages) if messages else None
        return allowed, should_prompt, combined_message, all_findings

    except ImportError:
        # Plugin system not available
        return True, False, None, []


# Module-level caches for hot-path performance (avoid YAML re-parsing per invocation)
_cached_tier_mgr: Optional["TierManager"] = None
_cached_pattern_matcher: Optional["PatternMatcher"] = None


def _get_tier_manager() -> "TierManager":
    """Get or create cached TierManager singleton."""
    global _cached_tier_mgr
    if _cached_tier_mgr is None:
        _cached_tier_mgr = TierManager()
    return _cached_tier_mgr


def _get_pattern_matcher() -> "PatternMatcher":
    """Get or create cached PatternMatcher singleton."""
    global _cached_pattern_matcher
    if _cached_pattern_matcher is None:
        _cached_pattern_matcher = PatternMatcher()
    return _cached_pattern_matcher


_cached_heuristic_scorer: Optional[Any] = None
_heuristic_scorer_checked: bool = False


def _get_heuristic_scorer(tier_mgr: "TierManager") -> Optional[Any]:
    """Get or create cached HeuristicScorerPlugin singleton.

    Returns None if the scorer is disabled in config or unavailable.
    Uses a checked-flag pattern to avoid re-importing on every call
    if the module isn't available.
    """
    global _cached_heuristic_scorer, _heuristic_scorer_checked
    if _heuristic_scorer_checked:
        return _cached_heuristic_scorer
    _heuristic_scorer_checked = True

    # Check config: heuristic_scorer.enabled
    hs_config = tier_mgr.config.get("heuristic_scorer", {})
    if not hs_config.get("enabled", True):
        return None

    try:
        from tweek.plugins.screening.heuristic_scorer import HeuristicScorerPlugin
        _cached_heuristic_scorer = HeuristicScorerPlugin()
        return _cached_heuristic_scorer
    except ImportError:
        return None
    except Exception:
        return None


def _resolve_enforcement(
    pattern_match: Optional[Dict],
    enforcement_policy: Optional[EnforcementPolicy],
    has_non_pattern_trigger: bool = False,
    memory_adjustment: Optional[Dict] = None,
    taint_level: str = "clean",
) -> str:
    """Determine the enforcement decision based on severity + confidence.

    Args:
        pattern_match: The highest-severity pattern match dict, or None.
        enforcement_policy: The active EnforcementPolicy (from overrides config).
        has_non_pattern_trigger: True if LLM/session/sandbox/compliance triggered.
        memory_adjustment: Optional memory-based adjustment suggestion.

    Returns:
        Decision string: "deny", "ask", or "log".
    """
    # Non-pattern triggers (LLM review, session anomaly, etc.) always "ask"
    if not pattern_match:
        if has_non_pattern_trigger:
            return "ask"
        return "log"

    severity = pattern_match.get("severity", "medium")
    confidence = pattern_match.get("confidence", "heuristic")

    # Use the enforcement policy matrix if available
    if enforcement_policy:
        decision = enforcement_policy.resolve(severity, confidence)
    elif severity == "critical" and confidence == "deterministic":
        decision = "deny"
    elif severity == "low":
        decision = "log"
    else:
        decision = "ask"

    # Break-glass: downgrade "deny" to "ask" if active override exists
    break_glass_used = False
    if decision == "deny":
        try:
            from tweek.hooks.break_glass import check_override
            override = check_override(pattern_match.get("name", ""))
            if override:
                # Log the break-glass usage
                _log(
                    EventType.BREAK_GLASS,
                    "break_glass",
                    decision="ask",
                    decision_reason=(
                        f"Break-glass override active for pattern "
                        f"'{pattern_match.get('name')}': {override.get('reason', 'no reason')}"
                    ),
                    metadata={
                        "pattern_name": pattern_match.get("name"),
                        "override_mode": override.get("mode"),
                        "override_reason": override.get("reason"),
                        "override_created_at": override.get("created_at"),
                    },
                )
                decision = "ask"  # Downgrade deny → ask (user still sees prompt)
                break_glass_used = True
        except ImportError:
            pass  # Break-glass module not available

    # Memory-based adjustment: only touches "ask" decisions
    if memory_adjustment and decision == "ask":
        try:
            from tweek.memory.safety import validate_memory_adjustment
            suggested = memory_adjustment.get("adjusted_decision")
            if suggested:
                decision = validate_memory_adjustment(
                    pattern_name=pattern_match.get("name", "") if pattern_match else "",
                    original_severity=pattern_match.get("severity", "medium") if pattern_match else "medium",
                    original_confidence=pattern_match.get("confidence", "heuristic") if pattern_match else "heuristic",
                    suggested_decision=suggested,
                    current_decision=decision,
                )
        except Exception:
            pass  # Memory is best-effort

    # Provenance-based adjustment: modify decision based on session taint
    # Skip when break-glass is active — explicit user overrides take priority
    if not break_glass_used:
        try:
            from tweek.memory.provenance import adjust_enforcement_for_taint
            if pattern_match:
                decision = adjust_enforcement_for_taint(
                    base_decision=decision,
                    severity=severity,
                    confidence=confidence,
                    taint_level=taint_level,
                )
        except Exception:
            pass  # Provenance is best-effort

    return decision


class TierManager:
    """Manages security tier classification and escalation."""

    def __init__(self, config_path: Optional[Path] = None):
        if config_path is None:
            config_path = Path(__file__).parent.parent / "config" / "tiers.yaml"

        self.config = self._load_config(config_path)
        self.tools = self.config.get("tools", {})
        self.skills = self.config.get("skills", {})
        self.escalations = self.config.get("escalations", [])
        self.default_tier = self.config.get("default_tier", "default")
        self.tiers = self.config.get("tiers", {})

    def _load_config(self, path: Path) -> dict:
        """Load tier configuration from YAML."""
        if not path.exists():
            return {}
        with open(path) as f:
            return yaml.safe_load(f) or {}

    def get_base_tier(self, tool_name: str, skill_name: Optional[str] = None) -> str:
        """Get the base tier for a tool or skill.

        Skills can only ESCALATE a tool's tier, never relax it.
        This prevents a safe skill from disabling screening on dangerous tools.
        For example, the 'explore' skill (safe) cannot downgrade Bash (dangerous).
        But the 'deploy' skill (dangerous) can escalate Read (default) to dangerous.
        """
        tier_priority = {"safe": 0, "default": 1, "risky": 2, "dangerous": 3}

        # Start with the tool's inherent tier
        tool_tier = self.tools.get(tool_name, self.default_tier)

        if skill_name and skill_name in self.skills:
            skill_tier = self.skills[skill_name]
            # Skill can only escalate, never relax
            if tier_priority.get(skill_tier, 1) > tier_priority.get(tool_tier, 1):
                return skill_tier

        return tool_tier

    def check_escalations(self, content: str) -> Optional[Dict]:
        """Check if content triggers any escalation patterns.

        Returns the highest-priority escalation match, or None.
        """
        tier_priority = {"safe": 0, "default": 1, "risky": 2, "dangerous": 3}
        highest_match = None
        highest_priority = -1

        for escalation in self.escalations:
            pattern = escalation.get("pattern", "")
            try:
                if re.search(pattern, content, re.IGNORECASE | re.DOTALL):
                    target_tier = escalation.get("escalate_to", "default")
                    priority = tier_priority.get(target_tier, 1)
                    if priority > highest_priority:
                        highest_priority = priority
                        highest_match = escalation
            except re.error:
                continue

        return highest_match

    def check_path_escalation(
        self,
        target_paths: List[str],
        working_dir: Optional[str],
    ) -> Optional[Dict]:
        """Check if any target paths are outside the working directory.

        Returns an escalation dict if an out-of-project path is detected,
        or None. The dict has the same shape as content-based escalations
        (escalate_to, description keys) plus path_boundary and target_path.
        """
        if not working_dir or not target_paths:
            return None

        try:
            cwd_resolved = Path(working_dir).expanduser().resolve()
        except (OSError, ValueError):
            return None

        path_config = self.config.get("path_boundary", {})
        if not path_config.get("enabled", True):
            return None

        sensitive_dirs = path_config.get("sensitive_directories", [
            {"pattern": ".ssh", "escalate_to": "dangerous", "description": "SSH directory access"},
            {"pattern": ".aws", "escalate_to": "dangerous", "description": "AWS credentials directory"},
            {"pattern": ".gnupg", "escalate_to": "dangerous", "description": "GPG keyring directory"},
            {"pattern": ".kube", "escalate_to": "dangerous", "description": "Kubernetes config directory"},
            {"pattern": "/etc/shadow", "escalate_to": "dangerous", "description": "System shadow file"},
            {"pattern": "/etc/sudoers", "escalate_to": "dangerous", "description": "Sudoers file"},
            {"pattern": "/etc/passwd", "escalate_to": "risky", "description": "System passwd file"},
        ])

        default_escalate_to = path_config.get("default_escalate_to", "risky")

        tier_priority = {"safe": 0, "default": 1, "risky": 2, "dangerous": 3}
        highest_escalation = None
        highest_priority = -1

        for target_path_str in target_paths:
            try:
                target_path = Path(target_path_str).expanduser()
                target_resolved = target_path.resolve()
            except (OSError, ValueError):
                continue

            # Symlink detection: if the path or any parent is a symlink,
            # log it and never relax the tier (fail-closed).
            _is_symlink = False
            try:
                if target_path.is_symlink():
                    _is_symlink = True
                else:
                    for parent in target_path.parents:
                        if parent.is_symlink():
                            _is_symlink = True
                            break
            except (OSError, ValueError):
                pass

            # Check if path is inside the project
            try:
                target_resolved.relative_to(cwd_resolved)
                if not _is_symlink:
                    continue  # Inside project, not a symlink -- no escalation
                # Symlink inside project pointing elsewhere — still check further
            except ValueError:
                pass  # Outside project -- check further

            # Path is outside project. Check sensitive directories.
            target_str_lower = str(target_resolved).lower()

            matched_sensitive = False
            for sensitive in sensitive_dirs:
                pattern = sensitive.get("pattern", "")
                if pattern and pattern in target_str_lower:
                    esc_to = sensitive.get("escalate_to", "dangerous")
                    priority = tier_priority.get(esc_to, 2)
                    if priority > highest_priority:
                        highest_priority = priority
                        highest_escalation = {
                            "escalate_to": esc_to,
                            "description": f"Out-of-project access: {sensitive.get('description', pattern)}",
                            "path_boundary": True,
                            "target_path": target_path_str,
                        }
                    matched_sensitive = True
                    break

            if not matched_sensitive:
                priority = tier_priority.get(default_escalate_to, 2)
                if priority > highest_priority:
                    highest_priority = priority
                    highest_escalation = {
                        "escalate_to": default_escalate_to,
                        "description": f"Out-of-project file access: {target_path_str}",
                        "path_boundary": True,
                        "target_path": target_path_str,
                    }

        return highest_escalation

    def get_effective_tier(
        self,
        tool_name: str,
        content: str,
        skill_name: Optional[str] = None,
        target_paths: Optional[List[str]] = None,
        working_dir: Optional[str] = None,
    ) -> tuple[str, Optional[Dict]]:
        """Get the effective tier after checking content and path escalations.

        Returns (tier, escalation_match) where escalation_match is None
        if no escalation occurred. Takes the highest of base tier,
        content-based escalation, and path-boundary escalation.
        """
        tier_priority = {"safe": 0, "default": 1, "risky": 2, "dangerous": 3}

        base_tier = self.get_base_tier(tool_name, skill_name)
        content_escalation = self.check_escalations(content)
        path_escalation = self.check_path_escalation(
            target_paths or [], working_dir
        )

        best_tier = base_tier
        best_priority = tier_priority.get(base_tier, 1)
        best_escalation = None

        if content_escalation:
            esc_tier = content_escalation.get("escalate_to", "default")
            esc_priority = tier_priority.get(esc_tier, 1)
            if esc_priority > best_priority:
                best_tier = esc_tier
                best_priority = esc_priority
                best_escalation = content_escalation

        if path_escalation:
            esc_tier = path_escalation.get("escalate_to", "default")
            esc_priority = tier_priority.get(esc_tier, 1)
            if esc_priority > best_priority:
                best_tier = esc_tier
                best_priority = esc_priority
                best_escalation = path_escalation

        return best_tier, best_escalation

    def get_screening_methods(self, tier: str) -> List[str]:
        """Get the screening methods for a tier."""
        tier_config = self.tiers.get(tier, {})
        return tier_config.get("screening", [])


class PatternMatcher:
    """Matches commands against hostile patterns."""

    def __init__(self, patterns_path: Optional[Path] = None):
        # Always load bundled patterns first, then merge user patterns on top
        user_patterns = Path.home() / ".tweek" / "patterns" / "patterns.yaml"
        bundled_patterns = Path(__file__).parent.parent / "config" / "patterns.yaml"

        if patterns_path is not None:
            # Explicit path: load bundled + explicit (for testing)
            self.patterns = self._load_patterns(bundled_patterns)
            extra = self._load_patterns(patterns_path)
            self._merge_patterns(extra)
        else:
            # Always start with bundled patterns
            self.patterns = self._load_patterns(bundled_patterns)
            # Merge user patterns on top (additive, not replacement)
            if user_patterns.exists():
                extra = self._load_patterns(user_patterns)
                self._merge_patterns(extra)

        # Pre-compile all regex patterns for performance and ReDoS protection.
        # These are our own trusted patterns (not user-supplied), so skip
        # ReDoS validation during compilation (validate=False).
        self._compiled_patterns: List[Tuple[re.Pattern, dict]] = []
        for pattern in self.patterns:
            regex = pattern.get("regex", "")
            if not regex:
                continue
            try:
                compiled = re.compile(regex, re.IGNORECASE | re.DOTALL)
                self._compiled_patterns.append((compiled, pattern))
            except re.error:
                # Skip invalid patterns at compile time
                continue

    def _merge_patterns(self, extra_patterns: List[dict]):
        """Merge additional patterns into existing set (additive).

        User patterns supplement bundled patterns — they cannot replace or
        remove bundled patterns. Duplicate names are skipped.
        """
        existing_names = {p.get("name") for p in self.patterns}
        for pattern in extra_patterns:
            if pattern.get("name") not in existing_names:
                self.patterns.append(pattern)
                existing_names.add(pattern.get("name"))

    def _load_patterns(self, path: Path) -> List[dict]:
        """Load patterns from YAML config.

        All patterns and security features are available to all users (open source).
        Pro (teams) and Enterprise (compliance) tiers coming soon.
        """
        if not path.exists():
            return []

        with open(path) as f:
            config = yaml.safe_load(f) or {}

        return config.get("patterns", [])

    @staticmethod
    def _normalize(content: str) -> str:
        """Normalize Unicode to defeat homoglyph evasion (e.g., Cyrillic 'а' → Latin 'a')."""
        import unicodedata
        return unicodedata.normalize("NFKC", content)

    def check(self, content: str) -> Optional[dict]:
        """Check content against all patterns.

        Returns the first matching pattern, or None.
        Uses timeout-protected regex execution to prevent ReDoS.
        """
        content = self._normalize(content)
        if len(content) > ReDoSProtection.MAX_INPUT_LENGTH:
            content = content[:ReDoSProtection.MAX_INPUT_LENGTH]
        for compiled, pattern in self._compiled_patterns:
            try:
                if ReDoSProtection.safe_search(compiled, content, timeout=2.0):
                    return pattern
            except (RegexTimeoutError, re.error):
                continue
        return None

    def check_all(self, content: str) -> List[dict]:
        """Check content against all patterns, returning all matches.

        Uses timeout-protected regex execution to prevent ReDoS.
        """
        content = self._normalize(content)
        if len(content) > ReDoSProtection.MAX_INPUT_LENGTH:
            content = content[:ReDoSProtection.MAX_INPUT_LENGTH]
        matches = []
        for compiled, pattern in self._compiled_patterns:
            try:
                if ReDoSProtection.safe_search(compiled, content, timeout=2.0):
                    matches.append(pattern)
            except (RegexTimeoutError, re.error):
                continue
        return matches


def format_prompt_message(
    pattern: Optional[dict],
    escalation: Optional[dict],
    command: str,
    tier: str,
    rate_limit_msg: Optional[str] = None,
    llm_msg: Optional[str] = None,
    session_msg: Optional[str] = None
) -> str:
    """Format the message shown to user when prompting for confirmation."""
    severity_icons = {
        "critical": "",
        "high": " ",
        "medium": "",
        "low": "",
    }

    lines = []

    # Header with tier info
    tier_icons = {"safe": "", "default": "", "risky": "", "dangerous": ""}
    lines.append(f"{tier_icons.get(tier, '')} TWEEK SECURITY CHECK")
    lines.append("" * 45)

    # Rate limit info if applicable
    if rate_limit_msg:
        lines.append(rate_limit_msg)
        lines.append("")

    # Session analysis if applicable
    if session_msg:
        lines.append(session_msg)
        lines.append("")

    # Escalation info if applicable
    if escalation:
        lines.append(f"  Escalated to {tier.upper()} tier")
        lines.append(f"   Reason: {escalation.get('description', 'Content-based escalation')}")
        lines.append("")

    # Pattern match info
    if pattern:
        icon = severity_icons.get(pattern.get("severity", "medium"), "")
        lines.append(f"{icon} Pattern Match: {pattern.get('name', 'unknown')}")
        if pattern.get("id"):
            lines.append(f"   ID: {pattern.get('id')}")
        lines.append(f"   Severity: {pattern.get('severity', 'unknown').upper()}")
        lines.append(f"   {pattern.get('description', 'Suspicious command detected')}")
        lines.append("")

    # LLM review if applicable
    if llm_msg:
        lines.append(llm_msg)
        lines.append("")

    # Command preview
    display_cmd = command if len(command) < 60 else command[:57] + "..."
    lines.append(f"Command: {display_cmd}")
    lines.append("" * 45)
    lines.append("Allow this command?")

    return "\n".join(lines)


def _check_project_skill_fingerprints(working_dir: Optional[str], _log) -> None:
    """
    Check project skills for new/modified SKILL.md files via fingerprint cache.

    If a new or modified skill is detected (e.g. from git pull/clone), it is
    routed through the isolation chamber for security scanning. Results:
    - PASS: skill stays in place, fingerprint recorded
    - FAIL: skill removed from project dir, jailed, user warned
    - MANUAL_REVIEW: skill moved to chamber, user warned
    """
    if not working_dir:
        return

    from tweek.skills.config import load_isolation_config

    config = load_isolation_config()
    if not config.enabled:
        return

    fingerprints = get_fingerprints()
    changed = fingerprints.check_project_skills(Path(working_dir))

    if not changed:
        return

    # Import chamber lazily to avoid circular imports and overhead on clean runs
    from tweek.skills.isolation import SkillIsolationChamber

    chamber = SkillIsolationChamber(config=config)

    for skill_path, status in changed:
        skill_name = skill_path.parent.name
        _log(
            EventType.TOOL_INVOKED,
            "SkillFingerprint",
            tier="skill_guard",
            decision="scan",
            decision_reason=f"Git-arrived skill detected: {skill_name} ({status})",
        )

        report, msg = chamber.accept_and_scan(
            skill_path.parent,
            skill_name=f"git-{skill_name}",
            target="project",
        )

        if report.verdict == "pass":
            # Record the fingerprint so we don't re-scan
            fingerprints.register(
                skill_path,
                verdict="pass",
                report_path=msg,
            )
        elif report.verdict == "fail":
            # Remove from project dir — it's now in jail
            import shutil

            try:
                shutil.rmtree(skill_path.parent)
            except OSError:
                pass
            print(
                f"TWEEK SECURITY: Skill '{skill_name}' FAILED security scan "
                f"and was removed from project. See: tweek skills jail list",
                file=sys.stderr,
            )
        elif report.verdict == "manual_review":
            print(
                f"TWEEK SECURITY: Skill '{skill_name}' requires manual review. "
                f"Run: tweek skills chamber approve git-{skill_name}",
                file=sys.stderr,
            )


# =============================================================================
# PATH EXTRACTION: Extract filesystem target paths from tool inputs
# =============================================================================


def _extract_paths_from_bash(command: str) -> List[str]:
    """Best-effort extraction of filesystem paths from a bash command.

    Catches obvious cases like:
      cat /etc/passwd
      cp ~/.ssh/id_rsa /tmp/key
      python3 /home/user/script.py

    Intentionally simple -- does NOT handle pipes, subshells, or variable
    expansion. Content-based escalations (262 patterns) cover the rest.
    """
    import shlex

    paths: List[str] = []
    if not command:
        return paths

    # Only look at the first simple command (before |, &&, ||, ;)
    first_cmd = re.split(r'[|;&]', command)[0].strip()

    try:
        tokens = shlex.split(first_cmd)
    except ValueError:
        # Malformed quotes -- fall back to simple split
        tokens = first_cmd.split()

    for token in tokens:
        if token.startswith('-'):
            continue
        if token.startswith('/') or token.startswith('~'):
            paths.append(token)

    return paths


def extract_target_paths(tool_name: str, tool_input: Dict[str, Any]) -> List[str]:
    """Extract filesystem paths from a tool invocation for boundary checking.

    Returns a list of path strings. For tools with no filesystem target
    (WebFetch, WebSearch), returns an empty list.
    """
    paths: List[str] = []

    if tool_name in ("Read", "Write", "Edit"):
        fp = tool_input.get("file_path", "")
        if fp:
            paths.append(fp)
    elif tool_name == "NotebookEdit":
        np = tool_input.get("notebook_path", "")
        if np:
            paths.append(np)
    elif tool_name == "Glob":
        gp = tool_input.get("path", "")
        if gp:
            paths.append(gp)
    elif tool_name == "Grep":
        gp = tool_input.get("path", "")
        if gp:
            paths.append(gp)
    elif tool_name == "Bash":
        paths.extend(_extract_paths_from_bash(tool_input.get("command", "")))

    return paths


def process_hook(input_data: dict, logger: SecurityLogger) -> dict:
    """Main hook logic with tiered security screening.

    Security Layers:
    1. Rate Limiting - Detect resource theft
    2. Pattern Matching - Known attack vectors
    3. LLM Review - Semantic analysis
    4. Session Analysis - Cross-turn anomalies
    5. Sandbox Preview - Speculative execution

    Args:
        input_data: Dict with tool_name, tool_input from Claude Code
        logger: Security logger instance

    Returns:
        Dict with hookSpecificOutput for Claude Code hook protocol
    """
    tool_name = input_data.get("tool_name", "")
    tool_input = input_data.get("tool_input", {})
    session_id = input_data.get("session_id")
    working_dir = input_data.get("cwd")

    # Generate correlation ID to link all events in this screening pass
    correlation_id = uuid.uuid4().hex[:16]

    def _log(event_type, tool, **kwargs):
        """Log with correlation_id, source, and session_id automatically included."""
        logger.log_quick(
            event_type, tool,
            correlation_id=correlation_id, source="hooks",
            session_id=session_id,
            **kwargs
        )

    # =========================================================================
    # PROJECT SANDBOX: Initialize per-project security state isolation
    # Provides project-scoped logger, overrides, and fingerprints (Layer 2)
    # =========================================================================
    _sandbox = None
    try:
        _sandbox = get_project_sandbox(working_dir)
        if _sandbox:
            # Replace logger with project-scoped one (Python closures are
            # late-binding, so _log will use the new logger automatically)
            logger = _sandbox.get_logger()
    except Exception:
        # Sandbox init is best-effort — fall back to global state
        _sandbox = None

    # =========================================================================
    # SKILL FINGERPRINT CHECK: Detect new/modified git-arrived skills
    # Lightweight SHA-256 check; full scan only on first encounter or change
    # =========================================================================
    try:
        _check_project_skill_fingerprints(working_dir, _log)
    except Exception:
        # Fingerprint check is best-effort — never break the hook
        pass

    # =========================================================================
    # SKILL CONTEXT TRACKING: Detect active skill from Skill tool invocations
    # When Claude invokes the Skill tool, we extract the skill name and write
    # a breadcrumb. Subsequent tool calls read it for tier/memory context.
    # =========================================================================
    _active_skill = None
    try:
        from tweek.skills.context import (
            extract_skill_from_tool_input,
            write_skill_breadcrumb,
            read_skill_context,
        )

        if tool_name == "Skill" and session_id:
            # Skill tool invocation — extract and record the active skill
            skill = extract_skill_from_tool_input(tool_input)
            if skill:
                write_skill_breadcrumb(skill, session_id)
                _active_skill = skill
                _log(
                    EventType.SCREENING_COMPLETE,
                    tool_name,
                    decision="allow",
                    decision_reason=f"Skill context recorded: {skill}",
                    metadata={"skill_context": skill},
                )
        elif session_id:
            # Non-Skill tool — check for active skill breadcrumb
            _active_skill = read_skill_context(session_id)
    except Exception:
        # Skill context is best-effort — never break the hook
        _active_skill = None

    # =========================================================================
    # SELF-PROTECTION: Block AI from modifying security override config
    # This file can only be edited by a human directly.
    # =========================================================================
    if tool_name in ("Write", "Edit"):
        target_path = tool_input.get("file_path", "")
        if is_protected_config_file(target_path):
            _log(
                EventType.BLOCKED,
                tool_name,
                tier="self_protection",
                decision="deny",
                decision_reason=f"BLOCKED: AI cannot modify security override config: {target_path}",
            )
            return {
                "hookSpecificOutput": {
                    "hookEventName": "PreToolUse",
                    "permissionDecision": "deny",
                    "permissionDecisionReason": (
                        "TWEEK SELF-PROTECTION: This file can only be edited by a human.\n"
                        f"File: {target_path}\n"
                        "Security overrides (whitelist, pattern toggles, trust levels) are human-only.\n"
                        "Edit this file directly in your text editor."
                    ),
                }
            }

    if tool_name == "Bash":
        command = tool_input.get("command", "")
        if bash_targets_protected_config(command):
            _log(
                EventType.BLOCKED,
                tool_name,
                tier="self_protection",
                decision="deny",
                decision_reason="BLOCKED: Bash command targets protected config file",
            )
            return {
                "hookSpecificOutput": {
                    "hookEventName": "PreToolUse",
                    "permissionDecision": "deny",
                    "permissionDecisionReason": (
                        "TWEEK SELF-PROTECTION: Cannot modify security override config via shell.\n"
                        "Security overrides can only be edited by a human directly."
                    ),
                }
            }

        # Block AI from running tweek trust/untrust/uninstall/unprotect — human-only commands
        command_stripped = command.strip()
        if re.match(r"tweek\s+(trust|untrust|uninstall|unprotect)\b", command_stripped):
            if "uninstall" in command_stripped or "unprotect" in command_stripped:
                reason = (
                    "TWEEK SELF-PROTECTION: Uninstall must be done by a human.\n"
                    "Run this command directly in your terminal:\n"
                    f"  {command_stripped}\n"
                    "AI agents cannot remove security protections."
                )
                log_reason = "BLOCKED: AI cannot run tweek uninstall"
            else:
                reason = (
                    "TWEEK SELF-PROTECTION: Trust decisions must be made by a human.\n"
                    "Run this command directly in your terminal:\n"
                    f"  {command_stripped}\n"
                    "Trust settings control which projects are exempt from security screening."
                )
                log_reason = "BLOCKED: AI cannot modify trust settings"
            _log(
                EventType.BLOCKED,
                tool_name,
                tier="self_protection",
                decision="deny",
                decision_reason=log_reason,
            )
            return {
                "hookSpecificOutput": {
                    "hookEventName": "PreToolUse",
                    "permissionDecision": "deny",
                    "permissionDecisionReason": reason,
                }
            }

    # =========================================================================
    # SKILL GUARD: Block direct skill installation bypassing isolation chamber
    # =========================================================================
    skill_block_reason = get_skill_guard_reason(tool_name, tool_input)
    if skill_block_reason:
        _log(
            EventType.BLOCKED,
            tool_name,
            tier="skill_guard",
            decision="deny",
            decision_reason=skill_block_reason,
        )
        return {
            "hookSpecificOutput": {
                "hookEventName": "PreToolUse",
                "permissionDecision": "deny",
                "permissionDecisionReason": skill_block_reason,
            }
        }

    # Skill download detection: prompt user instead of blocking
    if tool_name == "Bash":
        download_prompt = get_skill_download_prompt(tool_input.get("command", ""))
        if download_prompt:
            _log(
                EventType.TOOL_INVOKED,
                tool_name,
                tier="skill_guard",
                decision="ask",
                decision_reason="Potential skill download detected",
            )
            return {
                "hookSpecificOutput": {
                    "hookEventName": "PreToolUse",
                    "permissionDecision": "ask",
                    "permissionDecisionReason": download_prompt,
                }
            }

    # Extract target filesystem paths for boundary checking
    target_paths = extract_target_paths(tool_name, tool_input)

    # Extract content to analyze (command for Bash, path + payload for Write/Edit, etc.)
    if tool_name == "Bash":
        content = tool_input.get("command", "")
    elif tool_name == "Read":
        content = tool_input.get("file_path", "")
    elif tool_name == "Write":
        # Screen both path and content payload
        file_path = tool_input.get("file_path", "")
        file_content = tool_input.get("content", "")
        content = f"{file_path}\n{file_content}" if file_content else file_path
    elif tool_name == "Edit":
        # Screen path, old content (may carry injection context), and new content
        file_path = tool_input.get("file_path", "")
        old_string = tool_input.get("old_string", "")
        new_string = tool_input.get("new_string", "")
        content = "\n".join(filter(None, [file_path, old_string, new_string]))
    elif tool_name == "NotebookEdit":
        # Screen notebook path and cell source content
        notebook_path = tool_input.get("notebook_path", "")
        new_source = tool_input.get("new_source", "")
        content = f"{notebook_path}\n{new_source}" if new_source else notebook_path
    elif tool_name == "WebFetch":
        # Screen both URL and prompt (prompt could carry injection)
        url = tool_input.get("url", "")
        prompt = tool_input.get("prompt", "")
        content = f"{url}\n{prompt}" if prompt else url
    elif tool_name == "WebSearch":
        content = tool_input.get("query", "")
    elif tool_name == "Glob":
        content = tool_input.get("pattern", "")
        glob_path = tool_input.get("path", "")
        if glob_path:
            content = f"{glob_path}\n{content}"
    elif tool_name == "Grep":
        content = tool_input.get("pattern", "")
        grep_path = tool_input.get("path", "")
        if grep_path:
            content = f"{grep_path}\n{content}"
    else:
        content = json.dumps(tool_input)

    if not content:
        return {}

    # =========================================================================
    # SELF-TRUST: Skip screening when reading verified Tweek source files.
    # Content-based (SHA-256), not path-based. Prevents false positives
    # when AI reads Tweek's own patterns, hooks, and security modules.
    # =========================================================================
    if tool_name in ("Read", "Grep"):
        try:
            from tweek.security.integrity import is_trusted_tweek_file
            read_path = tool_input.get("file_path") or tool_input.get("path") or ""
            if read_path and is_trusted_tweek_file(read_path):
                _log(
                    EventType.ALLOWED,
                    tool_name,
                    tier="self_trust",
                    decision="allow",
                    decision_reason=f"Self-trust: verified Tweek file {Path(read_path).name}",
                    metadata={"self_trust": True, "file": read_path},
                )
                return {}
        except Exception:
            pass  # Best-effort — fall through to normal screening

    # =========================================================================
    # WHITELIST CHECK: Skip screening for whitelisted tool+path combinations
    # Uses project-scoped overrides (additive-only merge) if sandbox active
    # =========================================================================
    overrides = _sandbox.get_overrides() if _sandbox else get_overrides()
    enforcement_policy = overrides.get_enforcement_policy() if overrides else EnforcementPolicy()
    if overrides:
        whitelist_match = overrides.check_whitelist(tool_name, tool_input, content)
        if whitelist_match:
            _log(
                EventType.ALLOWED,
                tool_name,
                command=content if tool_name == "Bash" else None,
                tier="whitelisted",
                decision="allow",
                decision_reason=f"Whitelisted: {whitelist_match.get('reason', 'matched whitelist rule')}",
                metadata={"whitelist_rule": whitelist_match}
            )
            return {}

    # =========================================================================
    # LAYER 0: Compliance Scanning (INPUT direction)
    # Scan incoming content for sensitive data before processing
    # =========================================================================
    compliance_block, compliance_msg, compliance_findings = run_compliance_scans(
        content=content,
        direction="input",
        logger=logger,
        session_id=session_id,
        tool_name=tool_name
    )

    if compliance_block:
        return {
            "hookSpecificOutput": {
                "hookEventName": "PreToolUse",
                "permissionDecision": "deny",
                "permissionDecisionReason": f" COMPLIANCE BLOCK\n{compliance_msg}",
            }
        }

    # Use cached managers (avoids YAML re-parsing on every invocation)
    tier_mgr = _get_tier_manager()
    pattern_matcher = _get_pattern_matcher()

    # Determine effective tier (skill context overrides tool tier if configured)
    effective_tier, escalation = tier_mgr.get_effective_tier(
        tool_name, content,
        skill_name=_active_skill,
        target_paths=target_paths,
        working_dir=working_dir,
    )
    screening_methods = tier_mgr.get_screening_methods(effective_tier)

    # =========================================================================
    # Non-English Language Detection
    # Escalate tier when non-English content detected so LLM review can catch
    # prompt injection in other languages that bypass English-only regex patterns
    # =========================================================================
    try:
        from tweek.security.language import detect_non_english, NonEnglishHandling

        # Load handling mode from config (default: escalate)
        ne_handling_str = tier_mgr.config.get("non_english_handling", "escalate")
        try:
            ne_handling = NonEnglishHandling(ne_handling_str)
        except ValueError:
            ne_handling = NonEnglishHandling.ESCALATE

        if ne_handling != NonEnglishHandling.NONE:
            lang_result = detect_non_english(content)

            if lang_result.has_non_english and lang_result.confidence >= 0.3:
                _log(
                    EventType.ESCALATION,
                    tool_name,
                    command=content if tool_name == "Bash" else None,
                    tier=effective_tier,
                    decision_reason=f"Non-English content detected ({', '.join(lang_result.detected_scripts)}, confidence: {lang_result.confidence:.0%})",
                    metadata={
                        "language_detection": {
                            "scripts": lang_result.detected_scripts,
                            "confidence": lang_result.confidence,
                            "ratio": lang_result.non_english_ratio,
                            "sample": lang_result.sample,
                            "handling": ne_handling.value,
                        }
                    }
                )

                if ne_handling in (NonEnglishHandling.ESCALATE, NonEnglishHandling.BOTH):
                    # Escalate to at least risky tier to trigger LLM review
                    tier_priority = {"safe": 0, "default": 1, "risky": 2, "dangerous": 3}
                    if tier_priority.get(effective_tier, 1) < tier_priority["risky"]:
                        effective_tier = "risky"
                        screening_methods = tier_mgr.get_screening_methods(effective_tier)
    except ImportError:
        pass  # Language detection module not available
    except Exception as e:
        _log(
            EventType.ERROR,
            tool_name,
            decision_reason=f"Language detection error: {e}",
        )

    # Log tool invocation
    _log(
        EventType.TOOL_INVOKED,
        tool_name,
        command=content if tool_name == "Bash" else None,
        tier=effective_tier,
        working_directory=working_dir,
        metadata={"tool_input": tool_input}
    )

    # Log escalation if it occurred
    if escalation:
        _log(
            EventType.ESCALATION,
            tool_name,
            command=content if tool_name == "Bash" else None,
            tier=effective_tier,
            decision_reason=escalation.get("description"),
            metadata={"escalation": escalation}
        )

    # =========================================================================
    # PROVENANCE: Record tool call and get session taint level
    # Tracks every tool call for taint decay; provides taint_level for
    # enforcement adjustment later in the pipeline.
    # =========================================================================
    # Default to "low" when no session tracking — clean session relaxation
    # requires active provenance tracking as a safety prerequisite.
    _session_taint_level = "low"
    try:
        from tweek.memory.provenance import get_taint_store
        if session_id:
            _taint_store = get_taint_store()
            _taint_state = _taint_store.record_tool_call(session_id, tool_name)
            _session_taint_level = _taint_state.get("taint_level", "clean")
    except Exception:
        _session_taint_level = "low"  # Provenance unavailable — no relaxation

    # =========================================================================
    # LAYER 1: Rate Limiting
    # =========================================================================
    rate_limit_msg = None
    try:
        from tweek.security.rate_limiter import get_rate_limiter

        rate_limiter = get_rate_limiter()
        rate_result = rate_limiter.check(
            tool_name=tool_name,
            command=content if tool_name == "Bash" else None,
            session_id=session_id,
            tier=effective_tier
        )

        if not rate_result.allowed:
            rate_limit_msg = rate_limiter.format_violation_message(rate_result)
            _log(
                EventType.PATTERN_MATCH,
                tool_name,
                command=content if tool_name == "Bash" else None,
                tier=effective_tier,
                pattern_name="rate_limit",
                pattern_severity="high",
                decision="ask",
                decision_reason=f"Rate limit violations: {rate_result.violations}",
                metadata={"rate_limit": rate_result.details}
            )

            # Rate limit alone triggers prompt
            return {
                "hookSpecificOutput": {
                    "hookEventName": "PreToolUse",
                    "permissionDecision": "ask",
                    "permissionDecisionReason": format_prompt_message(
                        None, None, content, effective_tier,
                        rate_limit_msg=rate_limit_msg
                    ),
                }
            }
    except ImportError:
        pass  # Rate limiter not available
    except Exception as e:
        _log(
            EventType.ERROR,
            tool_name,
            decision_reason=f"Rate limiter error: {e}",
        )

    # Safe tier - no further screening
    if not screening_methods:
        _log(
            EventType.ALLOWED,
            tool_name,
            tier=effective_tier,
            decision="allow",
            decision_reason="Safe tier - no screening required",
        )
        return {}

    # =========================================================================
    # LAYER 2: Pattern Matching
    # =========================================================================
    pattern_match = None
    all_pattern_matches = []
    if "regex" in screening_methods:
        all_pattern_matches = pattern_matcher.check_all(content)

        # Apply pattern toggles from overrides (disabled/scoped_disabled patterns)
        if overrides and all_pattern_matches:
            working_path = (
                tool_input.get("file_path", "")
                or tool_input.get("url", "")
                or working_dir
                or ""
            )
            all_pattern_matches = overrides.filter_patterns(
                all_pattern_matches, working_path
            )

        # Use highest-severity match as primary (critical > high > medium > low)
        if all_pattern_matches:
            severity_order = {"critical": 0, "high": 1, "medium": 2, "low": 3}
            all_pattern_matches.sort(key=lambda p: severity_order.get(p.get("severity", "medium"), 4))
            pattern_match = all_pattern_matches[0]

        if pattern_match:
            _log(
                EventType.PATTERN_MATCH,
                tool_name,
                command=content if tool_name == "Bash" else None,
                tier=effective_tier,
                pattern_name=pattern_match.get("name"),
                pattern_severity=pattern_match.get("severity"),
                metadata={"pattern": pattern_match}
            )

    # =========================================================================
    # MEMORY: Read pattern history for confidence adjustment
    # =========================================================================
    memory_adjustment = None
    if pattern_match:
        try:
            from tweek.memory.queries import memory_read_for_pattern
            from tweek.memory.store import hash_project, normalize_path_prefix
            _mem_path = (
                tool_input.get("file_path", "")
                or tool_input.get("url", "")
                or working_dir
                or ""
            )
            memory_adjustment = memory_read_for_pattern(
                pattern_name=pattern_match.get("name", ""),
                pattern_severity=pattern_match.get("severity", "medium"),
                pattern_confidence=pattern_match.get("confidence", "heuristic"),
                tool_name=tool_name,
                path_prefix=_mem_path,
                project_hash=hash_project(working_dir) if working_dir else None,
            )
        except Exception:
            pass  # Memory is best-effort

    # =========================================================================
    # LAYER 2.5: Heuristic Scoring (Confidence-Gated LLM Escalation)
    # Bridges the gap between regex patterns (Layer 2) and LLM review (Layer 3).
    # Runs ONLY when: no regex match AND LLM not already scheduled.
    # If score exceeds threshold, adds "llm" to screening_methods.
    # =========================================================================
    heuristic_escalated = False
    if not pattern_match and "llm" not in screening_methods:
        try:
            scorer = _get_heuristic_scorer(tier_mgr)
            if scorer:
                heuristic_result = scorer.screen(
                    tool_name=tool_name,
                    content=content,
                    context={
                        "tier": effective_tier,
                        "tool_input": tool_input,
                        "working_dir": working_dir,
                    }
                )
                heuristic_score = heuristic_result.details.get("heuristic_score", 0.0)
                should_escalate = heuristic_result.details.get("should_escalate", False)

                if should_escalate:
                    heuristic_escalated = True
                    screening_methods = list(screening_methods) + ["llm"]
                    _log(
                        EventType.ESCALATION,
                        tool_name,
                        command=content if tool_name == "Bash" else None,
                        tier=effective_tier,
                        decision_reason=f"Heuristic scorer escalation (score: {heuristic_score:.3f})",
                        metadata={
                            "heuristic_score": heuristic_score,
                            "family_scores": heuristic_result.details.get("family_scores", {}),
                            "signals": heuristic_result.details.get("signals", []),
                            "threshold": heuristic_result.details.get("threshold", 0.4),
                        }
                    )
                elif tier_mgr.config.get("heuristic_scorer", {}).get("log_all_scores", False):
                    _log(
                        EventType.TOOL_INVOKED,
                        tool_name,
                        metadata={
                            "heuristic_score": heuristic_score,
                            "heuristic_below_threshold": True,
                        }
                    )
        except Exception:
            pass  # Heuristic scorer is best-effort

    # =========================================================================
    # LAYER 3: LLM Review (for risky/dangerous tiers, or heuristic-escalated)
    # =========================================================================
    llm_msg = None
    llm_triggered = False
    if "llm" in screening_methods:
        try:
            from tweek.security.llm_reviewer import get_llm_reviewer

            llm_reviewer = get_llm_reviewer()
            llm_result = llm_reviewer.review(
                command=content,
                tool=tool_name,
                tier=effective_tier,
                tool_input=tool_input,
                session_context=f"session:{session_id}" if session_id else None
            )

            if llm_result.should_prompt:
                llm_triggered = True
                llm_msg = llm_reviewer.format_review_message(llm_result)
                _log(
                    EventType.LLM_RULE_MATCH,
                    tool_name,
                    command=content,
                    tier=effective_tier,
                    pattern_name="llm_review",
                    pattern_severity=llm_result.risk_level.value,
                    decision="ask",
                    decision_reason=llm_result.reason,
                    metadata={
                        "llm_risk": llm_result.risk_level.value,
                        "llm_confidence": llm_result.confidence,
                        "llm_reason": llm_result.reason
                    }
                )
        except ImportError:
            pass  # LLM reviewer not available
        except Exception as e:
            _log(
                EventType.ERROR,
                tool_name,
                decision_reason=f"LLM reviewer error: {e}",
            )

    # =========================================================================
    # LAYER 4: Session Analysis (cross-turn anomaly detection)
    # =========================================================================
    session_msg = None
    session_triggered = False
    if session_id and effective_tier in ("risky", "dangerous"):
        try:
            from tweek.security.session_analyzer import get_session_analyzer

            session_analyzer = get_session_analyzer()
            session_result = session_analyzer.analyze(session_id)

            if session_result.is_suspicious:
                session_triggered = True
                session_msg = session_analyzer.format_analysis_message(session_result)
                _log(
                    EventType.PATTERN_MATCH,
                    tool_name,
                    command=content if tool_name == "Bash" else None,
                    tier=effective_tier,
                    pattern_name="session_anomaly",
                    pattern_severity="high" if session_result.is_high_risk else "medium",
                    decision="ask",
                    decision_reason=f"Session anomalies: {session_result.anomalies}",
                    metadata={
                        "risk_score": session_result.risk_score,
                        "anomalies": [a.value for a in session_result.anomalies]
                    }
                )
        except ImportError:
            pass  # Session analyzer not available
        except Exception as e:
            _log(
                EventType.ERROR,
                tool_name,
                decision_reason=f"Session analyzer error: {e}",
            )

    # =========================================================================
    # LAYER 5: Sandbox Preview (dangerous tier, Bash only)
    # =========================================================================
    sandbox_triggered = False
    sandbox_msg = None
    if "sandbox" in screening_methods and tool_name == "Bash":
        try:
            from tweek.sandbox.executor import SandboxExecutor

            executor = SandboxExecutor()
            preview = executor.preview_command(content, skill="hook-preview", timeout=3.0)

            if preview.suspicious:
                sandbox_triggered = True
                _log(
                    EventType.SANDBOX_PREVIEW,
                    tool_name,
                    command=content,
                    tier=effective_tier,
                    pattern_name="sandbox_preview",
                    pattern_severity="high",
                    decision="ask",
                    decision_reason="Sandbox preview detected suspicious behavior",
                    metadata={"violations": preview.violations, "denied_ops": preview.denied_operations}
                )

                violation_text = "\n".join(f"  * {v}" for v in preview.violations)
                sandbox_msg = (
                    f" SANDBOX PREVIEW\n"
                    f"Speculative execution detected suspicious behavior:\n\n"
                    f"{violation_text}"
                )
        except ImportError:
            pass  # Sandbox not available
        except Exception as e:
            _log(
                EventType.ERROR,
                tool_name,
                command=content,
                tier=effective_tier,
                decision_reason=f"Sandbox preview error: {e}",
            )

    # =========================================================================
    # TRUST LEVEL: Filter pattern matches by severity threshold
    # Interactive (human at CLI) → only prompt on high/critical
    # Automated (launchd/cron) → prompt on everything
    # =========================================================================
    trust_mode = get_trust_mode(overrides)
    if overrides and pattern_match:
        min_severity = overrides.get_min_severity(trust_mode)
        kept, suppressed = filter_by_severity(
            all_pattern_matches if all_pattern_matches else [pattern_match],
            min_severity,
        )
        if suppressed:
            _log(
                EventType.ALLOWED,
                tool_name,
                command=content if tool_name == "Bash" else None,
                tier=effective_tier,
                decision="allow",
                decision_reason=(
                    f"Trust level '{trust_mode}': {len(suppressed)} pattern(s) "
                    f"below {min_severity} severity threshold"
                ),
                metadata={
                    "trust_mode": trust_mode,
                    "min_severity": min_severity,
                    "suppressed_patterns": [
                        p.get("name") for p in suppressed
                    ],
                },
            )
        if kept:
            all_pattern_matches = kept
            kept.sort(key=lambda p: SEVERITY_RANK.get(p.get("severity", "medium"), 4))
            pattern_match = kept[0]
        else:
            all_pattern_matches = []
            pattern_match = None

    # =========================================================================
    # Decision: Prompt if any layer triggered
    # =========================================================================
    compliance_triggered = bool(compliance_findings)

    if pattern_match or llm_triggered or session_triggered or sandbox_triggered or compliance_triggered:
        # Determine graduated enforcement decision
        has_non_pattern = llm_triggered or session_triggered or sandbox_triggered or compliance_triggered
        decision = _resolve_enforcement(pattern_match, enforcement_policy, has_non_pattern, memory_adjustment, _session_taint_level)

        # Build the warning message for ask/deny decisions
        final_msg = format_prompt_message(
            pattern_match, escalation, content, effective_tier,
            rate_limit_msg=rate_limit_msg,
            llm_msg=llm_msg,
            session_msg=session_msg
        )

        if sandbox_msg:
            final_msg += f"\n\n{sandbox_msg}"

        if compliance_msg:
            final_msg += f"\n\n COMPLIANCE NOTICE\n{compliance_msg}"

        if decision == "deny":
            # Hard block: critical + deterministic patterns (or configured deny)
            _log(
                EventType.BLOCKED,
                tool_name,
                command=content if tool_name == "Bash" else None,
                tier=effective_tier,
                pattern_name=pattern_match.get("name") if pattern_match else "multi_layer",
                pattern_severity=pattern_match.get("severity") if pattern_match else "high",
                decision="deny",
                decision_reason="Hard block: critical deterministic pattern",
                metadata={
                    "pattern_triggered": pattern_match is not None,
                    "pattern_confidence": pattern_match.get("confidence") if pattern_match else None,
                    "llm_triggered": llm_triggered,
                    "session_triggered": session_triggered,
                    "sandbox_triggered": sandbox_triggered,
                    "compliance_triggered": compliance_triggered,
                    "enforcement_decision": "deny",
                }
            )
            # Memory: record denied decision
            try:
                from tweek.memory.queries import memory_write_after_decision, memory_update_workflow
                from tweek.memory.store import hash_project, normalize_path_prefix
                if pattern_match:
                    memory_write_after_decision(
                        pattern_name=pattern_match.get("name", ""),
                        pattern_id=pattern_match.get("id"),
                        original_severity=pattern_match.get("severity", "medium"),
                        original_confidence=pattern_match.get("confidence", "heuristic"),
                        decision="deny", user_response="denied",
                        tool_name=tool_name, content=content,
                        path_prefix=tool_input.get("file_path", "") or tool_input.get("url", "") or working_dir or "",
                        project_hash=hash_project(working_dir) if working_dir else None,
                    )
                memory_update_workflow(
                    project_hash=hash_project(working_dir) if working_dir else "global",
                    tool_name=tool_name, was_denied=True,
                )
            except Exception:
                pass
            return {
                "hookSpecificOutput": {
                    "hookEventName": "PreToolUse",
                    "permissionDecision": "deny",
                    "permissionDecisionReason": final_msg,
                }
            }

        elif decision == "log":
            # Silent allow with logging: low-severity or low-confidence patterns
            _log(
                EventType.ALLOWED,
                tool_name,
                command=content if tool_name == "Bash" else None,
                tier=effective_tier,
                pattern_name=pattern_match.get("name") if pattern_match else "multi_layer",
                pattern_severity=pattern_match.get("severity") if pattern_match else "low",
                decision="log",
                decision_reason="Low-severity pattern logged only",
                metadata={
                    "pattern_triggered": pattern_match is not None,
                    "pattern_confidence": pattern_match.get("confidence") if pattern_match else None,
                    "enforcement_decision": "log",
                    "memory_adjusted": memory_adjustment is not None,
                }
            )
            # Memory: record logged decision
            try:
                from tweek.memory.queries import memory_write_after_decision, memory_update_workflow
                from tweek.memory.store import hash_project
                if pattern_match:
                    memory_write_after_decision(
                        pattern_name=pattern_match.get("name", ""),
                        pattern_id=pattern_match.get("id"),
                        original_severity=pattern_match.get("severity", "medium"),
                        original_confidence=pattern_match.get("confidence", "heuristic"),
                        decision="log", user_response=None,
                        tool_name=tool_name, content=content,
                        path_prefix=tool_input.get("file_path", "") or tool_input.get("url", "") or working_dir or "",
                        project_hash=hash_project(working_dir) if working_dir else None,
                    )
                memory_update_workflow(
                    project_hash=hash_project(working_dir) if working_dir else "global",
                    tool_name=tool_name, was_denied=False,
                )
            except Exception:
                pass
            return {}

        else:
            # Ask: prompt user for confirmation (default behavior)
            _log(
                EventType.USER_PROMPTED,
                tool_name,
                command=content if tool_name == "Bash" else None,
                tier=effective_tier,
                pattern_name=pattern_match.get("name") if pattern_match else "multi_layer",
                pattern_severity=pattern_match.get("severity") if pattern_match else "high",
                decision="ask",
                decision_reason="Security check triggered",
                metadata={
                    "pattern_triggered": pattern_match is not None,
                    "pattern_confidence": pattern_match.get("confidence") if pattern_match else None,
                    "llm_triggered": llm_triggered,
                    "session_triggered": session_triggered,
                    "sandbox_triggered": sandbox_triggered,
                    "compliance_triggered": compliance_triggered,
                    "compliance_findings": len(compliance_findings) if compliance_findings else 0,
                    "enforcement_decision": "ask",
                }
            )
            # Memory: record ask decision (user_response set to None until feedback)
            try:
                from tweek.memory.queries import memory_write_after_decision, memory_update_workflow
                from tweek.memory.store import hash_project
                if pattern_match:
                    memory_write_after_decision(
                        pattern_name=pattern_match.get("name", ""),
                        pattern_id=pattern_match.get("id"),
                        original_severity=pattern_match.get("severity", "medium"),
                        original_confidence=pattern_match.get("confidence", "heuristic"),
                        decision="ask", user_response=None,
                        tool_name=tool_name, content=content,
                        path_prefix=tool_input.get("file_path", "") or tool_input.get("url", "") or working_dir or "",
                        project_hash=hash_project(working_dir) if working_dir else None,
                    )
                memory_update_workflow(
                    project_hash=hash_project(working_dir) if working_dir else "global",
                    tool_name=tool_name, was_denied=False,
                )
            except Exception:
                pass
            return {
                "hookSpecificOutput": {
                    "hookEventName": "PreToolUse",
                    "permissionDecision": "ask",
                    "permissionDecisionReason": final_msg,
                }
            }

    # No issues found - allow
    _log(
        EventType.ALLOWED,
        tool_name,
        command=content if tool_name == "Bash" else None,
        tier=effective_tier,
        decision="allow",
        decision_reason="Passed all screening layers",
    )

    # Memory: record clean pass and update workflow baseline
    try:
        from tweek.memory.queries import memory_update_workflow
        from tweek.memory.store import hash_project
        memory_update_workflow(
            project_hash=hash_project(working_dir) if working_dir else "global",
            tool_name=tool_name,
            was_denied=False,
        )
    except Exception:
        pass

    return {}


def check_hook_enabled(hook_name: str = "pre_tool_use") -> bool:
    """
    Check if a Tweek hook should run in the current working directory.

    Looks for a .tweek.yaml file in the project root (cwd). This file
    is created during `tweek protect claude-code` with hooks enabled
    by default. Users can manually set hooks to false to disable
    screening in a specific directory.

    .tweek.yaml format:
        hooks:
          pre_tool_use: true    # set false to disable pre-screening
          post_tool_use: true   # set false to disable post-screening

    If no .tweek.yaml exists, hooks are ENABLED (protected by default).
    This file is protected by Tweek self-protection — only a human
    can create or edit it.

    Args:
        hook_name: "pre_tool_use" or "post_tool_use"

    Returns:
        True if the hook should run, False to skip
    """
    tweek_config = Path.cwd() / ".tweek.yaml"

    if not tweek_config.exists():
        # No config = hooks enabled (protected by default)
        return True

    try:
        with open(tweek_config) as f:
            config = yaml.safe_load(f) or {}
    except Exception:
        return True  # Can't read config = fail safe, keep hooks on

    hooks = config.get("hooks", {})
    return hooks.get(hook_name, True)


def main():
    """Entry point for the hook."""
    # Check if pre_tool_use hook is enabled for this directory
    if not check_hook_enabled("pre_tool_use"):
        print("{}")
        return

    logger = get_logger()

    try:
        # Read JSON from stdin
        input_text = sys.stdin.read()
        if not input_text.strip():
            print("{}")
            return

        input_data = json.loads(input_text)
        result = process_hook(input_data, logger)

        # Output JSON result
        print(json.dumps(result))

    except json.JSONDecodeError as e:
        # Invalid JSON - fail closed (deny) for safety
        logger.log_quick(
            EventType.ERROR,
            "unknown",
            decision="deny",
            decision_reason=f"JSON decode error: {e}"
        )
        print(json.dumps({
            "hookSpecificOutput": {
                "hookEventName": "PreToolUse",
                "permissionDecision": "deny",
                "permissionDecisionReason": f" TWEEK ERROR: Invalid hook input.\nBlocking for safety.",
            }
        }))

    except Exception as e:
        # Any error - fail closed (block for safety)
        logger.log_quick(
            EventType.ERROR,
            "unknown",
            decision="deny",
            decision_reason=f"Hook error: {e}"
        )
        print(json.dumps({
            "hookSpecificOutput": {
                "hookEventName": "PreToolUse",
                "permissionDecision": "deny",
                "permissionDecisionReason": f" TWEEK ERROR: {e}\nBlocking for safety.",
            }
        }))


if __name__ == "__main__":
    main()
