#!/usr/bin/env python3
"""
Tweek Diagnostics Engine

Health check system for verifying Tweek installation, configuration,
and runtime dependencies. Used by `tweek doctor` and the health banner.
"""

import os
import sqlite3
from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path
from typing import List, Optional, Tuple


class CheckStatus(Enum):
    """Health check result status."""
    OK = "ok"
    WARNING = "warning"
    ERROR = "error"
    SKIPPED = "skipped"


@dataclass
class HealthCheck:
    """Result of a single health check."""
    name: str           # Machine name: "hooks_installed"
    label: str          # Human label: "Hook Installation"
    status: CheckStatus
    message: str        # Description: "Global hooks installed at ~/.claude/"
    fix_hint: str = ""  # Recovery: "Run: tweek protect claude-code --global"


def run_health_checks(verbose: bool = False, interactive: bool = False) -> List[HealthCheck]:
    """
    Run all health checks and return results.

    Args:
        verbose: If True, include extra detail in messages.
        interactive: If True, offer to fix issues interactively.

    Returns:
        List of HealthCheck results in check order.
    """
    checks = [
        _check_hooks_installed,
        _check_config_valid,
        _check_patterns_loaded,
        _check_security_db,
        _check_vault_available,
        _check_sandbox_available,
        _check_license_status,
        _check_mcp_available,
        _check_proxy_config,
        _check_plugin_integrity,
        _check_local_model,
        _check_llm_review,
    ]

    results = []
    for check_fn in checks:
        try:
            result = check_fn(verbose)
            results.append(result)
        except Exception as e:
            results.append(HealthCheck(
                name=check_fn.__name__.replace("_check_", ""),
                label=check_fn.__name__.replace("_check_", "").replace("_", " ").title(),
                status=CheckStatus.ERROR,
                message=f"Check failed: {e}",
                fix_hint="This may indicate a corrupted installation. Try: pip install --force-reinstall tweek",
            ))

    # Interactive fix mode — offer to resolve fixable issues
    if interactive:
        _offer_interactive_fixes(results)

    # Log health check results
    try:
        from tweek.logging.security_log import get_logger, SecurityEvent, EventType

        checks_passed = sum(1 for c in results if c.status == CheckStatus.OK)
        checks_failed = sum(1 for c in results if c.status == CheckStatus.ERROR)
        checks_warning = sum(1 for c in results if c.status == CheckStatus.WARNING)

        if checks_failed > 0:
            overall_status = "error"
        elif checks_warning > 0:
            overall_status = "warning"
        else:
            overall_status = "ok"

        get_logger().log(SecurityEvent(
            event_type=EventType.HEALTH_CHECK,
            tool_name="diagnostics",
            decision="allow",
            metadata={
                "overall_status": overall_status,
                "checks_passed": checks_passed,
                "checks_failed": checks_failed,
                "checks_warning": checks_warning,
            },
            source="diagnostics",
        ))
    except Exception:
        pass

    return results


def get_health_verdict(checks: List[HealthCheck]) -> Tuple[str, str]:
    """
    Compute an overall health verdict from check results.

    Returns:
        Tuple of (verdict_text, color) for Rich display.
    """
    ok_count = sum(1 for c in checks if c.status == CheckStatus.OK)
    warn_count = sum(1 for c in checks if c.status == CheckStatus.WARNING)
    error_count = sum(1 for c in checks if c.status == CheckStatus.ERROR)
    skip_count = sum(1 for c in checks if c.status == CheckStatus.SKIPPED)
    total = len(checks)

    if error_count == 0 and warn_count == 0:
        return f"All systems operational ({ok_count}/{total - skip_count} OK)", "green"
    elif error_count == 0:
        return (
            f"Mostly healthy ({ok_count} OK, {warn_count} warning{'s' if warn_count != 1 else ''})",
            "yellow",
        )
    elif error_count <= 2:
        return (
            f"Issues detected ({ok_count} OK, {error_count} error{'s' if error_count != 1 else ''}, "
            f"{warn_count} warning{'s' if warn_count != 1 else ''})",
            "red",
        )
    else:
        return f"Multiple issues ({error_count} errors, {warn_count} warnings)", "red"


# ==================== Individual Health Checks ====================


def _check_hooks_installed(verbose: bool = False) -> HealthCheck:
    """Check if Tweek hooks are installed in Claude Code settings.

    Reports per-location status so users can see exactly which
    paths have hooks (functional protection) vs. only leftover
    artifacts (skill dir / backup file without hooks).
    """
    from tweek.cli_helpers import _tweek_install_info

    global_claude = Path("~/.claude").expanduser()
    project_claude = Path.cwd() / ".claude"

    g = _tweek_install_info(global_claude)
    p = _tweek_install_info(project_claude)

    # --- Both locations have hooks ---
    if g["is_protected"] and p["is_protected"]:
        return HealthCheck(
            name="hooks_installed",
            label="Hook Installation",
            status=CheckStatus.OK,
            message="Hooks active: ~/.claude (global) + ./.claude (project)",
        )

    # --- Global hooks only ---
    if g["is_protected"] and not p["is_protected"]:
        msg = "Hooks active: ~/.claude (global)"
        if p["has_artifacts"]:
            msg += " | ./.claude has Tweek files but hooks missing"
        elif verbose:
            msg += " | no project hooks in ./.claude"
        return HealthCheck(
            name="hooks_installed",
            label="Hook Installation",
            status=CheckStatus.OK,
            message=msg,
        )

    # --- Project hooks only ---
    if p["is_protected"] and not g["is_protected"]:
        msg = "Hooks active: ./.claude (project only)"
        if g["has_artifacts"]:
            msg += " | ~/.claude has Tweek files but hooks missing"
        return HealthCheck(
            name="hooks_installed",
            label="Hook Installation",
            status=CheckStatus.WARNING,
            message=msg,
            fix_hint="Run: tweek protect claude-code --global  (to protect all projects)",
        )

    # --- No hooks anywhere ---
    # Check for orphaned artifacts (explains status vs doctor discrepancy)
    orphan_locs = []
    if g["has_artifacts"]:
        orphan_locs.append("~/.claude")
    if p["has_artifacts"]:
        orphan_locs.append("./.claude")

    if orphan_locs:
        return HealthCheck(
            name="hooks_installed",
            label="Hook Installation",
            status=CheckStatus.ERROR,
            message=(
                f"Tweek files found in {', '.join(orphan_locs)} "
                f"but hooks missing from settings.json"
            ),
            fix_hint="Run: tweek protect claude-code  (to re-install hooks)",
        )

    return HealthCheck(
        name="hooks_installed",
        label="Hook Installation",
        status=CheckStatus.ERROR,
        message="No hooks installed (checked ~/.claude and ./.claude)",
        fix_hint="Run: tweek protect claude-code",
    )


def _check_config_valid(verbose: bool = False) -> HealthCheck:
    """Check that configuration files parse correctly."""
    from tweek.config import ConfigManager

    try:
        config = ConfigManager()
        tools = config.list_tools()
        skills = config.list_skills()

        # Check for validation issues if the method exists
        issues = []
        if hasattr(config, "validate_config"):
            issues = config.validate_config()
            errors = [i for i in issues if i.level == "error"]
            warnings = [i for i in issues if i.level == "warning"]
            if errors:
                return HealthCheck(
                    name="config_valid",
                    label="Configuration",
                    status=CheckStatus.ERROR,
                    message=f"{len(errors)} config error{'s' if len(errors) != 1 else ''}",
                    fix_hint="Run: tweek config validate  (for details)",
                )
            if warnings:
                return HealthCheck(
                    name="config_valid",
                    label="Configuration",
                    status=CheckStatus.WARNING,
                    message=f"Config valid with {len(warnings)} warning{'s' if len(warnings) != 1 else ''} "
                            f"({len(tools)} tools, {len(skills)} skills)",
                    fix_hint="Run: tweek config validate  (for details)",
                )

        return HealthCheck(
            name="config_valid",
            label="Configuration",
            status=CheckStatus.OK,
            message=f"Config valid ({len(tools)} tools, {len(skills)} skills)",
        )
    except Exception as e:
        return HealthCheck(
            name="config_valid",
            label="Configuration",
            status=CheckStatus.ERROR,
            message=f"Failed to load config: {e}",
            fix_hint="Run: tweek config validate  (to see errors)",
        )


def _check_patterns_loaded(verbose: bool = False) -> HealthCheck:
    """Check that attack patterns are loaded and accessible."""
    user_patterns = Path("~/.tweek/patterns/patterns.yaml").expanduser()
    bundled_patterns = Path(__file__).parent / "config" / "patterns.yaml"

    patterns_file = None
    source = None

    if user_patterns.exists():
        patterns_file = user_patterns
        source = "~/.tweek/patterns"
    elif bundled_patterns.exists():
        patterns_file = bundled_patterns
        source = "bundled"

    if patterns_file is None:
        return HealthCheck(
            name="patterns_loaded",
            label="Attack Patterns",
            status=CheckStatus.ERROR,
            message="No patterns file found",
            fix_hint="Run: tweek upgrade  (patterns are bundled with the package)",
        )

    try:
        import yaml
        with open(patterns_file) as f:
            pdata = yaml.safe_load(f) or {}

        count = pdata.get("pattern_count", len(pdata.get("patterns", [])))
        if count == 0:
            return HealthCheck(
                name="patterns_loaded",
                label="Attack Patterns",
                status=CheckStatus.WARNING,
                message=f"Patterns file found ({source}) but contains 0 patterns",
                fix_hint="Run: tweek upgrade  (patterns are bundled with the package)",
            )

        return HealthCheck(
            name="patterns_loaded",
            label="Attack Patterns",
            status=CheckStatus.OK,
            message=f"{count:,} patterns loaded ({source})",
        )
    except Exception as e:
        return HealthCheck(
            name="patterns_loaded",
            label="Attack Patterns",
            status=CheckStatus.ERROR,
            message=f"Failed to parse patterns: {e}",
            fix_hint="Run: tweek upgrade  (patterns are bundled with the package)",
        )


def _check_security_db(verbose: bool = False) -> HealthCheck:
    """Check that the security database exists and is accessible."""
    db_path = Path("~/.tweek/security.db").expanduser()

    if not db_path.exists():
        return HealthCheck(
            name="security_db",
            label="Security Database",
            status=CheckStatus.OK,
            message="Not yet created (will be created on first event)",
        )

    try:
        size_bytes = db_path.stat().st_size
        size_mb = size_bytes / (1024 * 1024)

        # Test that we can open it
        conn = sqlite3.connect(str(db_path))
        conn.execute("SELECT 1")
        conn.close()

        if size_mb > 100:
            return HealthCheck(
                name="security_db",
                label="Security Database",
                status=CheckStatus.WARNING,
                message=f"DB is {size_mb:.0f}MB — consider cleanup",
                fix_hint="Run: tweek logs clear --older-than 30d",
            )
        elif size_mb > 10:
            return HealthCheck(
                name="security_db",
                label="Security Database",
                status=CheckStatus.OK,
                message=f"Active ({size_mb:.1f}MB)",
            )
        else:
            return HealthCheck(
                name="security_db",
                label="Security Database",
                status=CheckStatus.OK,
                message=f"Active ({size_mb:.1f}MB)" if size_mb >= 0.1 else "Active (< 100KB)",
            )
    except sqlite3.Error as e:
        return HealthCheck(
            name="security_db",
            label="Security Database",
            status=CheckStatus.ERROR,
            message=f"Cannot open database: {e}",
            fix_hint="Check file permissions on ~/.tweek/security.db",
        )


def _check_vault_available(verbose: bool = False) -> HealthCheck:
    """Check credential vault availability."""
    try:
        from tweek.platform import get_capabilities
        caps = get_capabilities()

        if caps.vault_available:
            return HealthCheck(
                name="vault_available",
                label="Credential Vault",
                status=CheckStatus.OK,
                message=f"{caps.vault_backend} available",
            )
        else:
            return HealthCheck(
                name="vault_available",
                label="Credential Vault",
                status=CheckStatus.WARNING,
                message="No vault backend available",
                fix_hint="Vault enables secure credential storage. "
                         "Install system keyring support for your platform.",
            )
    except ImportError:
        return HealthCheck(
            name="vault_available",
            label="Credential Vault",
            status=CheckStatus.WARNING,
            message="Platform module not available",
        )


def _check_sandbox_available(verbose: bool = False) -> HealthCheck:
    """Check sandbox availability (platform-dependent)."""
    try:
        from tweek.sandbox import get_sandbox_status
        from tweek.platform import IS_LINUX

        status = get_sandbox_status()

        if status.get("available"):
            return HealthCheck(
                name="sandbox_available",
                label="Sandbox",
                status=CheckStatus.OK,
                message=f"{status.get('tool', 'Available')} available",
            )
        elif IS_LINUX:
            return HealthCheck(
                name="sandbox_available",
                label="Sandbox",
                status=CheckStatus.WARNING,
                message="firejail not installed",
                fix_hint="Install firejail: sudo apt install firejail",
            )
        else:
            return HealthCheck(
                name="sandbox_available",
                label="Sandbox",
                status=CheckStatus.SKIPPED,
                message="Not available on this platform",
            )
    except ImportError:
        return HealthCheck(
            name="sandbox_available",
            label="Sandbox",
            status=CheckStatus.SKIPPED,
            message="Sandbox module not available",
        )


def _check_license_status(verbose: bool = False) -> HealthCheck:
    """Check license status."""
    try:
        from tweek.licensing import get_license, Tier

        lic = get_license()

        if lic.tier == Tier.FREE:
            return HealthCheck(
                name="license_status",
                label="License",
                status=CheckStatus.OK,
                message="Open source (all features included)",
            )
        elif lic.info and lic.info.is_expired:
            return HealthCheck(
                name="license_status",
                label="License",
                status=CheckStatus.WARNING,
                message=f"{lic.tier.value.upper()} license expired",
                fix_hint="Pro and Enterprise tiers coming soon: gettweek.com",
            )
        else:
            email = lic.info.email if lic.info else "unknown"
            return HealthCheck(
                name="license_status",
                label="License",
                status=CheckStatus.OK,
                message=f"{lic.tier.value.upper()} license ({email})",
            )
    except Exception as e:
        return HealthCheck(
            name="license_status",
            label="License",
            status=CheckStatus.WARNING,
            message=f"Cannot check license: {e}",
        )


def _check_mcp_available(verbose: bool = False) -> HealthCheck:
    """Check if MCP dependencies are available."""
    try:
        import mcp  # noqa: F401
        return HealthCheck(
            name="mcp_available",
            label="MCP Server",
            status=CheckStatus.OK,
            message="MCP package installed",
        )
    except ImportError:
        return HealthCheck(
            name="mcp_available",
            label="MCP Server",
            status=CheckStatus.SKIPPED,
            message="MCP package not installed (optional)",
            fix_hint="Install with: pip install tweek[mcp]",
        )


def _check_proxy_config(verbose: bool = False) -> HealthCheck:
    """Check proxy configuration if present."""
    try:
        from tweek.config import ConfigManager
        config = ConfigManager()
        full_config = config.get_full_config()

        proxy_config = full_config.get("proxy", {})
        mcp_config = full_config.get("mcp", {})

        if not proxy_config and not mcp_config:
            return HealthCheck(
                name="proxy_config",
                label="Proxy Config",
                status=CheckStatus.SKIPPED,
                message="No proxy or MCP proxy configured",
            )

        issues = []

        # Check MCP proxy upstreams
        mcp_proxy = mcp_config.get("proxy", {})
        upstreams = mcp_proxy.get("upstreams", {})
        if upstreams:
            for name, upstream in upstreams.items():
                if not upstream.get("command"):
                    issues.append(f"MCP upstream '{name}' missing 'command'")

        if issues:
            return HealthCheck(
                name="proxy_config",
                label="Proxy Config",
                status=CheckStatus.WARNING,
                message="; ".join(issues),
                fix_hint="Check proxy configuration in ~/.tweek/config.yaml",
            )

        parts = []
        if proxy_config:
            parts.append("HTTP proxy configured")
        if upstreams:
            parts.append(f"MCP proxy: {len(upstreams)} upstream{'s' if len(upstreams) != 1 else ''}")

        return HealthCheck(
            name="proxy_config",
            label="Proxy Config",
            status=CheckStatus.OK,
            message=", ".join(parts) if parts else "Configured",
        )
    except Exception as e:
        return HealthCheck(
            name="proxy_config",
            label="Proxy Config",
            status=CheckStatus.WARNING,
            message=f"Cannot check proxy config: {e}",
        )


def _check_plugin_integrity(verbose: bool = False) -> HealthCheck:
    """Check installed plugin integrity."""
    try:
        from tweek.plugins import init_plugins

        registry = init_plugins()
        stats = registry.get_stats()
        total = stats.get("total", 0)
        enabled = stats.get("enabled", 0)

        if total == 0:
            return HealthCheck(
                name="plugin_integrity",
                label="Plugin Integrity",
                status=CheckStatus.OK,
                message="No plugins installed",
            )

        # Check for plugins with load errors
        all_plugins = registry.list_plugins()
        errors = [p for p in all_plugins if p.load_error]

        if errors:
            error_names = ", ".join(p.name for p in errors[:3])
            suffix = f" (+{len(errors) - 3} more)" if len(errors) > 3 else ""
            return HealthCheck(
                name="plugin_integrity",
                label="Plugin Integrity",
                status=CheckStatus.WARNING,
                message=f"{len(errors)} plugin{'s' if len(errors) != 1 else ''} with errors: {error_names}{suffix}",
                fix_hint="Run: tweek plugins verify  (for details)",
            )

        return HealthCheck(
            name="plugin_integrity",
            label="Plugin Integrity",
            status=CheckStatus.OK,
            message=f"{enabled}/{total} plugins verified",
        )
    except Exception as e:
        return HealthCheck(
            name="plugin_integrity",
            label="Plugin Integrity",
            status=CheckStatus.WARNING,
            message=f"Cannot check plugins: {e}",
        )


def _check_local_model(verbose: bool = False) -> HealthCheck:
    """Check local classifier model status and verify inference works."""
    try:
        from tweek.security.local_model import LOCAL_MODEL_AVAILABLE, get_local_model
        from tweek.security.model_registry import (
            get_default_model_name,
            get_model_size,
            is_model_installed,
            verify_model_hashes,
        )
    except ImportError:
        return HealthCheck(
            name="local_model",
            label="Local Model",
            status=CheckStatus.SKIPPED,
            message="Local model module not available",
            fix_hint="Install with: pip install tweek[local-models]",
        )

    if not LOCAL_MODEL_AVAILABLE:
        return HealthCheck(
            name="local_model",
            label="Local Model",
            status=CheckStatus.SKIPPED,
            message="Dependencies not installed (optional)",
            fix_hint="Install with: pip install tweek[local-models]",
        )

    default_name = get_default_model_name()

    if not is_model_installed(default_name):
        return HealthCheck(
            name="local_model",
            label="Local Model",
            status=CheckStatus.WARNING,
            message="Dependencies installed but model not downloaded",
            fix_hint="Run: tweek model download",
        )

    # Model is installed — get size info
    size = get_model_size(default_name)
    size_str = f"{size / 1024 / 1024:.1f} MB" if size else "unknown size"

    # Verify SHA-256 integrity before running inference
    try:
        hash_results = verify_model_hashes(default_name)
        mismatched = [f for f, status in hash_results.items() if status == "mismatch"]
        if mismatched:
            files_str = ", ".join(mismatched)
            return HealthCheck(
                name="local_model",
                label="Local Model",
                status=CheckStatus.ERROR,
                message=f"SHA-256 integrity check failed for: {files_str}",
                fix_hint="Run: tweek model download --force  (to re-download)",
            )
    except Exception:
        pass  # Hash verification is best-effort; don't block on it

    # Run inference smoke test to verify the model actually works
    try:
        model = get_local_model(default_name)
        if model is None:
            return HealthCheck(
                name="local_model",
                label="Local Model",
                status=CheckStatus.ERROR,
                message=f"{default_name} installed ({size_str}) but failed to load",
                fix_hint="Try: tweek model download --force",
            )

        result = model.predict("hello world")
        if result is None or not hasattr(result, "risk_level"):
            return HealthCheck(
                name="local_model",
                label="Local Model",
                status=CheckStatus.ERROR,
                message=f"{default_name} installed ({size_str}) but inference returned no result",
                fix_hint="Try: tweek model download --force",
            )

        msg = f"{default_name} installed ({size_str}), inference OK"
        if verbose:
            msg += f" ({result.inference_time_ms:.0f}ms)"

        return HealthCheck(
            name="local_model",
            label="Local Model",
            status=CheckStatus.OK,
            message=msg,
        )

    except Exception as e:
        return HealthCheck(
            name="local_model",
            label="Local Model",
            status=CheckStatus.ERROR,
            message=f"{default_name} installed ({size_str}) but inference failed: {e}",
            fix_hint="Try: tweek model download --force",
        )


def _check_llm_review(verbose: bool = False) -> HealthCheck:
    """Check LLM review provider availability and configuration."""
    try:
        from tweek.security.llm_reviewer import (
            get_llm_reviewer,
            _detect_local_server,
            FallbackReviewProvider,
            DEFAULT_API_KEY_ENVS,
        )
        from tweek.security.local_model import LOCAL_MODEL_AVAILABLE

        reviewer = get_llm_reviewer()

        if not reviewer.enabled:
            hint_parts = [
                "Set one of: ANTHROPIC_API_KEY, OPENAI_API_KEY, GOOGLE_API_KEY,",
                "  GEMINI_API_KEY, XAI_API_KEY, or other LLM provider API key",
                "  as an environment variable, or configure a provider in",
                "  ~/.tweek/config.yaml.",
                "",
                "  Alternatively, install a local model for offline review.",
                "",
                "  See: docs/CONFIGURATION.md (LLM Review Provider section)",
            ]

            return HealthCheck(
                name="llm_review",
                label="LLM Review",
                status=CheckStatus.WARNING,
                message="No LLM provider configured — using pattern matching only",
                fix_hint="\n".join(hint_parts),
            )

        # Build status message
        provider_name = reviewer.provider_name
        model = reviewer.model
        parts = [f"{model} via {provider_name}"]

        # Check for fallback chain details
        provider = reviewer._provider_instance
        if isinstance(provider, FallbackReviewProvider):
            count = provider.provider_count
            parts.append(f"fallback chain: {count} providers")

        # Check for local LLM server
        try:
            server = _detect_local_server()
            if server:
                if verbose:
                    parts.append(
                        f"local: {server.model} on {server.server_type} "
                        f"({len(server.all_models)} models available)"
                    )
                else:
                    parts.append(f"local: {server.server_type}")
        except Exception:
            pass

        # In verbose mode, report escalation path
        if verbose:
            if provider_name == "local":
                # Check if cloud escalation is available
                cloud_env_found = any(
                    os.environ.get(e) if isinstance(e, str)
                    else any(os.environ.get(v) for v in e)
                    for e in DEFAULT_API_KEY_ENVS.values()
                )
                if cloud_env_found:
                    parts.append("cloud escalation: available")
                else:
                    parts.append("cloud escalation: not configured")

            if LOCAL_MODEL_AVAILABLE:
                parts.append("local ONNX: available")

        return HealthCheck(
            name="llm_review",
            label="LLM Review",
            status=CheckStatus.OK,
            message="; ".join(parts),
        )
    except ImportError:
        return HealthCheck(
            name="llm_review",
            label="LLM Review",
            status=CheckStatus.SKIPPED,
            message="LLM reviewer module not available",
        )
    except Exception as e:
        return HealthCheck(
            name="llm_review",
            label="LLM Review",
            status=CheckStatus.WARNING,
            message=f"Cannot check LLM review: {e}",
        )


# ==================== Interactive Fix Mode ====================


def _offer_interactive_fixes(results: List[HealthCheck]) -> None:
    """Offer to fix issues found during health checks.

    Only runs when ``tweek doctor --fix`` is used. Prompts for each
    fixable issue and attempts automatic remediation.
    """
    import click
    from rich.console import Console

    console = Console()
    fixable = [r for r in results if r.status in (CheckStatus.WARNING, CheckStatus.ERROR)]

    if not fixable:
        return

    console.print("\n[bold]Interactive Fix Mode[/bold]")
    console.print(f"Found {len(fixable)} issue(s) that may be fixable:\n")

    for check in fixable:
        fixed = False

        if check.name == "local_model" and "not downloaded" in check.message:
            if click.confirm(f"  [{check.name}] Download local model now?", default=True):
                fixed = _fix_download_model()

        elif check.name == "local_model" and "Dependencies" in check.message:
            if click.confirm(f"  [{check.name}] Install local model dependencies?", default=True):
                fixed = _fix_install_model_deps()

        elif check.name == "local_model" and "SHA-256" in check.message:
            if click.confirm(f"  [{check.name}] Re-download model (integrity check failed)?", default=True):
                fixed = _fix_redownload_model()

        elif check.name == "llm_review" and "No LLM provider" in check.message:
            if click.confirm(f"  [{check.name}] Configure LLM provider now?", default=True):
                fixed = _fix_configure_llm()

        elif check.name == "hooks_installed" and "No hooks" in check.message:
            if click.confirm(f"  [{check.name}] Install hooks now?", default=True):
                fixed = _fix_install_hooks()

        else:
            if check.fix_hint:
                console.print(f"  [{check.name}] {check.message}")
                console.print(f"    [dim]Hint: {check.fix_hint}[/dim]")

        if fixed:
            console.print(f"  [green]\u2713[/green] Fixed: {check.name}")
        console.print()


def _fix_download_model() -> bool:
    """Download the local classifier model."""
    try:
        from tweek.cli_install import _download_local_model
        return _download_local_model(quick=False)
    except Exception as e:
        from rich.console import Console
        Console().print(f"  [red]\u2717[/red] Failed: {e}")
        return False


def _fix_install_model_deps() -> bool:
    """Install onnxruntime, tokenizers, numpy."""
    try:
        from tweek.cli_install import _ensure_local_model_deps
        return _ensure_local_model_deps()
    except Exception as e:
        from rich.console import Console
        Console().print(f"  [red]\u2717[/red] Failed: {e}")
        return False


def _fix_redownload_model() -> bool:
    """Force re-download the local model."""
    try:
        from tweek.security.model_registry import download_model, get_default_model_name
        download_model(get_default_model_name(), force=True)
        return True
    except Exception as e:
        from rich.console import Console
        Console().print(f"  [red]\u2717[/red] Failed: {e}")
        return False


def _fix_configure_llm() -> bool:
    """Guide user to configure LLM provider via env file."""
    from rich.console import Console
    c = Console()
    c.print()
    c.print("  Add a free Google Gemini API key (no credit card needed):")
    c.print("    1. Go to https://aistudio.google.com/apikey")
    c.print("    2. Click [bold]Create API key[/bold] \u2192 select a project when prompted")
    c.print("       (AI Studio creates one automatically for new users)")
    c.print("    3. Run: [cyan]tweek config edit env[/cyan]")
    c.print("    4. Paste your key in the GOOGLE_API_KEY line")
    c.print()
    c.print("  Other providers: see ~/.tweek/.env | Full wizard: [cyan]tweek configure llm[/cyan]")
    c.print()
    return True


def _fix_install_hooks() -> bool:
    """Run hook installation."""
    try:
        from tweek.cli_install import _install_claude_code_hooks
        _install_claude_code_hooks(
            install_global=True, dev_test=False, backup=True,
            skip_env_scan=True, interactive=False, preset="cautious",
            ai_defaults=False, with_sandbox=False, force_proxy=False,
            skip_proxy_check=True, quick=True,
        )
        return True
    except Exception as e:
        from rich.console import Console
        Console().print(f"  [red]\u2717[/red] Failed: {e}")
        return False
