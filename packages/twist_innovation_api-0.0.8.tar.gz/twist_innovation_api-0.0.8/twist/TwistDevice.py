# Copyright (C) 2025 Twist Innovation
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
#
# See the GNU General Public License for more details:
# https://www.gnu.org/licenses/gpl-3.0.html

from __future__ import annotations
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from TwistAPI import TwistAPI

from .TwistModel import TwistModel

class TwistDevice:
    def __init__(self, twist_id: int, hw: int, api: TwistAPI):
        self.twist_id = twist_id
        self.hw = hw
        self.api = api

        self.model_list: list[TwistModel] = list()

    async def context_msg(self, model_id: int, payload: str):
        if model_id < len(self.model_list) and self.model_list[model_id] is not None:
            await self.model_list[model_id].context_msg(payload)
