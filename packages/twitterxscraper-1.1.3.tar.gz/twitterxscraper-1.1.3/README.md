# TwitterXScraper

A Lightweight Python tool for scraping public X (Twitter) tweets using Playwright.

I needed a simple way to pull public tweets from X without touching the API, dealing with tokens, or waiting on rate limits

So I wrote this CLI tool that asks for username, opens a Chromium browser with Playwright, scrolls a profile, grabs tweet text and timestamps, and dumps everything into a CSV.

PyPI: [https://pypi.org/project/twitterxscraper](https://pypi.org/project/twitterxscraper)


## Features

- Scrape public tweets from any username
- Automatically scroll to load more tweets
- Extract tweet text
- Extract tweet timestamps
- Save results to CSv
- Works in the terminal
- Installed with pip

## Installation

```bash
pip install twitterxscraper
python -m playwright install chromium
```


## Clone this repository

```bash
git clone https://github.com/calchiwo/twitterxscraper.git
cd twitterxscraper
```

Install dependencies.

```bash
python -m pip install -e .
python -m playwright install chromium
```

## How it use

Run the CLI and pass a username:

```bash
python twitterxscraper elonmusk
```

With a custom limit:

```bash
python twitterxscraper elonmusk --limit 15
```

This creates a CSV file named after the username: `elonmusk.csv`.

## Using it in your own code

You can also run it as a module directly as a Python class.

```python
from twitterxscraper import TwitterScraper

scraper = TwitterScraper()
tweets = scraper.scrape_user("elonmusk", limit=10)

print(tweets)
```
## Limitations

- Only works on public profiles
- No login support
- No private acconts
- Breaks if X layout changes
- Uses a Chromium browser with Playwright

This is scraping. Layout changes can

## Tech stack used

- Python
- Playwright
- Pandas