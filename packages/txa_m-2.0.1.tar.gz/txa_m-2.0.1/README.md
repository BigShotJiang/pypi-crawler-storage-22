# TXA MediaFire Bulk Downloader

**A modern, high-speed, and cross-platform CLI tool for downloading files and folders from MediaFire.**

![Platform](https://img.shields.io/badge/Platform-Windows%20%7C%20Linux%20%7C%20macOS%20%7C%20Android-blue)
![Python](https://img.shields.io/badge/Python-3.6%2B-yellow)
![License](https://img.shields.io/badge/License-MIT-green)

## 🚀 Key Features

*   **Bulk Downloading**: Download entire folders recursively or single files.
*   **Cross-Platform**: Fully compatible with **Windows**, **Linux**, **macOS**, and **Android (Termux)**.
*   **Resumable**: Automatically skips files that already exist (verified by hash).
*   **Multi-threaded**: Blazing fast downloads with configurable threading.
*   **Smart Extraction**: Handles dynamic MediaFire links using HTML parsing and Regex fallback.
*   **Beautiful UI**: Rich terminal interface with progress bars, panels, and colors.
*   **Multi-language**: Supports English and Vietnamese (`--sl en/vi`).

## 📥 Installation

You can easily install the tool via pip:

```bash
pip install txa-m
```

_Note: On some systems (like Linux/Mac), you might need to use `pip3`._

## 💻 Usage

Run the tool using the command `txa-m`.

**IMPORTANT**: Always wrap your **URLs** and **Paths** in double quotes (`"`) to ensure special characters don't break the command.

### Basic Download
```bash
txa-m "https://www.mediafire.com/file/example/file.zip"
```

### Download to Specific Folder
```bash
txa-m "https://www.mediafire.com/folder/example/folder" -o "C:/MyDownloads/Mediafire"
```

### Advanced Usage
```bash
# Download with 20 threads and ignore video files
txa-m "https://www.mediafire.com/folder/..." -t 20 -ie ".mp4,.mkv,.avi"
```

### Check for Updates
```bash
txa-m --u
```

## ⚙️ Options

| Option | Alias | Description |
| :--- | :--- | :--- |
| `--output` | `-o` | Output directory path (supports env vars like `%USERPROFILE%`). |
| `--threads` | `-t` | Number of concurrent download threads (Default: 10). |
| `--ignore-extensions` | `-ie` | Comma-separated list of extensions to skip (e.g., `.mp4,.mkv`). |
| `--ignore-names` | `-in` | Comma-separated list of filenames to skip. |
| `--set-lang` | `--sl` | Set application language (`en` or `vi`). |
| `--update` | `-u` | Check for updates and auto-install via pip. |
| `--help` | `-h` | Show the help message. |
| `--version` | `-v` | Show version information. |

## 📱 Running on Android (Termux)

1.  Install Termux from F-Droid or Google Play.
2.  Run these commands:
    ```bash
    pkg update && pkg upgrade
    pkg install python
    pip install txa-m
    ```
3.  Grant storage permission (optional, if saving to internal storage):
    ```bash
    termux-setup-storage
    ```
4.  Run the tool:
    ```bash
    txa-m "YOUR_LINK" -o "/sdcard/Download"
    ```

## 📜 Copyright

Copyright © TXA.
This tool is for educational purposes.
