from setuptools import setup, find_packages

setup(
    name="txa-m",
    version="2.0.1",
    packages=find_packages(),
    install_requires=[
        "requests",
        "gazpacho",
        "rich"
    ],
    include_package_data=True,
    package_data={
        "txa_mediafire": ["*.json"],
    },
    entry_points={
        "console_scripts": [
            "txa-m=txa_mediafire.cli:main",
        ],
    },
    author="TXA",
    description="A modern, high-speed downloader for MediaFire files and folders",
    long_description=open("README.md", encoding="utf-8").read() if open("README.md", encoding="utf-8") else "",
    long_description_content_type="text/markdown",
    classifiers=[
        "Programming Language :: Python :: 3",
        "Operating System :: OS Independent",
        "Operating System :: Microsoft :: Windows",
        "Operating System :: POSIX :: Linux",
        "Operating System :: MacOS",
    ],
    python_requires='>=3.10, <=3.14.3',
)
