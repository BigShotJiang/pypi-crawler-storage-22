"""Integration tests for the TypeBridge code generator."""
