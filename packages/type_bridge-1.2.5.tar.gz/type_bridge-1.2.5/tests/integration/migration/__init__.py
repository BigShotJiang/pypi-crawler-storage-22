"""Integration tests for the migration system."""
