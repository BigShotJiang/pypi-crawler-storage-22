"""Tests for the TypeBridge code generator."""
