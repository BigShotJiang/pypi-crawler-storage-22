"""Unit tests for the migration system."""
