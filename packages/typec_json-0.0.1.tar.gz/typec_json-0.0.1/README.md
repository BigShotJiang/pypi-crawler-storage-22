# Typec-json

This package is a placeholder for the upcoming Typec-json compiler.

Development is ongoing. This initial release exists to reserve the project name.
