# Typed Binance

> A fully typed, validated async client for the Binance API

Use autocomplete instead of documentation.

🚧 Under construction.
