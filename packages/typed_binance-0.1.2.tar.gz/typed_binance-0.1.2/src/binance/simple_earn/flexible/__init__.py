from dataclasses import dataclass
from .list import FlexibleList

@dataclass
class Flexible(FlexibleList):
  ...
