from dataclasses import dataclass
from .coins import Coins

@dataclass
class Capital(Coins):
  ...
