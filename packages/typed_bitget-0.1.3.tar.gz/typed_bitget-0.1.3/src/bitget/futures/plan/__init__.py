from .plan_sub_orders import PlanSubOrders

class Plan(PlanSubOrders):
    ...
