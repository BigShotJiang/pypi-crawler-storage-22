# Licensed to the Apache Software Foundation (ASF) under one
# or more contributor license agreements.  See the NOTICE file
# distributed with this work for additional information
# regarding copyright ownership.  The ASF licenses this file
# to you under the Apache License, Version 2.0 (the
# "License"); you may not use this file except in compliance
# with the License.  You may obtain a copy of the License at
#
#   http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing,
# software distributed under the License is distributed on an
# "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
# KIND, either express or implied.  See the License for the
# specific language governing permissions and limitations
# under the License.

from __future__ import annotations

from typing import TYPE_CHECKING, Optional, Callable

from typedb.api.analyze.analyzed_query import AnalyzedQuery
from typedb.api.answer.query_answer import QueryAnswer
from typedb.api.connection.query_options import QueryOptions
from typedb.api.connection.transaction import Transaction
from typedb.api.connection.transaction_options import TransactionOptions
from typedb.common.exception import TypeDBDriverException, TRANSACTION_CLOSED, TypeDBException
from typedb.common.native_wrapper import NativeWrapper
from typedb.common.promise import Promise
from typedb.common.validation import require_non_null
from typedb.concept.answer.query_answer_factory import wrap_query_answer
from typedb.native_driver_wrapper import error_code, error_message, transaction_new, \
    transaction_analyze, transaction_query, \
    transaction_commit, transaction_rollback, transaction_is_open, transaction_on_close, transaction_close, \
    query_answer_promise_resolve, analyzed_query_promise_resolve, \
    Transaction as NativeTransaction, TransactionCallbackDirector, TypeDBDriverExceptionNative, void_promise_resolve

if TYPE_CHECKING:
    from typedb.api.connection.transaction import TransactionType
    from typedb.native_driver_wrapper import Error as NativeError


class _Transaction(Transaction, NativeWrapper[NativeTransaction]):

    def __init__(self, driver: Driver, database_name: str,
                 transaction_type: TransactionType, options: TransactionOptions = None):
        if not options:
            options = TransactionOptions()
        self._type = transaction_type
        self._options = options
        try:
            super().__init__(
                transaction_new(driver.native_object, database_name, transaction_type.value, options.native_object))
        except TypeDBDriverExceptionNative as e:
            raise TypeDBDriverException.of(e) from None

    @property
    def _native_object_not_owned_exception(self) -> TypeDBDriverException:
        return TypeDBDriverException(TRANSACTION_CLOSED)

    @property
    def type(self) -> TransactionType:
        return self._type

    @property
    def options(self) -> TransactionOptions:
        return self._options

    def analyze(self, query: str) -> Promise[AnalyzedQuery]:
        from typedb.analyze.analyzed_query import _AnalyzedQuery
        require_non_null(query, "query")
        promise = transaction_analyze(self.native_object, query)
        return Promise.map(_AnalyzedQuery, lambda: analyzed_query_promise_resolve(promise))

    def query(self, query: str, options: Optional[QueryOptions] = None) -> Promise[QueryAnswer]:
        require_non_null(query, "query")
        if not options:
            options = QueryOptions()
        promise = transaction_query(self.native_object, query, options.native_object)
        return Promise.map(wrap_query_answer, lambda: query_answer_promise_resolve(promise))

    def is_open(self) -> bool:
        if not self._native_object.thisown:
            return False
        return transaction_is_open(self.native_object)

    def on_close(self, function: Callable):
        callback = _Transaction.TransactionOnClose(function)
        void_promise_resolve(transaction_on_close(self.native_object, callback.__disown__()))

    class TransactionOnClose(TransactionCallbackDirector):

        def __init__(self, function: Callable):
            super().__init__()
            self._function = function

        def callback(self, error: NativeError) -> None:
            try:
                if error:
                     self._function(TypeDBException(error_code(error), error_message(error)))
                else:
                    self._function(None)
            except Exception as e:
                # WARNING: SWIG will not propagate any errors (including syntax!) to the user without more work so we can at least log
                import sys
                print("Error invoking onclose callback: ", e, file=sys.stderr)
                raise e

    def commit(self):
        try:
            self._native_object.thisown = 0
            void_promise_resolve(transaction_commit(self._native_object))
        except TypeDBDriverExceptionNative as e:
            raise TypeDBDriverException.of(e) from None

    def rollback(self):
        try:
            void_promise_resolve(transaction_rollback(self.native_object))
        except TypeDBDriverExceptionNative as e:
            raise TypeDBDriverException.of(e) from None

    def close(self):
        if self._native_object.thisown:
            void_promise_resolve(transaction_close(self._native_object))

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.close()
        if exc_tb is not None:
            return False
