# Admin

::: typedkafka.admin.KafkaAdmin

::: typedkafka.admin.TopicConfig

::: typedkafka.admin.AdminError
