# Configuration

::: typedkafka.config.ProducerConfig

::: typedkafka.config.ConsumerConfig
