# Exceptions

::: typedkafka.exceptions.KafkaError

::: typedkafka.exceptions.ProducerError

::: typedkafka.exceptions.ConsumerError

::: typedkafka.exceptions.SerializationError
