# Producer

::: typedkafka.producer.KafkaProducer

::: typedkafka.producer.TransactionContext
