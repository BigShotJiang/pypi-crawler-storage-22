# Serializers

::: typedkafka.serializers.Serializer

::: typedkafka.serializers.Deserializer

::: typedkafka.serializers.JsonSerializer

::: typedkafka.serializers.JsonDeserializer

::: typedkafka.serializers.StringSerializer

::: typedkafka.serializers.StringDeserializer
