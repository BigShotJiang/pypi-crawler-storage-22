"""Tests for typedkafka package."""
