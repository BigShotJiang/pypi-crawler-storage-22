"""
Main CLI entrypoint.

Copyright 2026 Vlad Emelianov
"""

import sys


def print_info() -> None:
    """
    Print package info to stdout.
    """
    sys.stdout.write(
        "Type annotations for aiobotocore ApplicationInsights 3.1.3\n"
        "Version:         3.1.3\n"
        "Builder version: 8.12.0\n"
        "Docs:            https://youtype.github.io/types_aiobotocore_docs/types_aiobotocore_application_insights//\n"
        "Boto3 docs:      https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/application-insights.html#applicationinsights\n"
        "Other services:  https://pypi.org/project/boto3-stubs/\n"
        "Changelog:       https://github.com/youtype/mypy_boto3_builder/releases\n"
    )


def print_version() -> None:
    """
    Print package version to stdout.
    """
    sys.stdout.write("3.1.3\n")


def main() -> None:
    """
    Main CLI entrypoint.
    """
    if "--version" in sys.argv:
        print_version()
        return
    print_info()


if __name__ == "__main__":
    main()
