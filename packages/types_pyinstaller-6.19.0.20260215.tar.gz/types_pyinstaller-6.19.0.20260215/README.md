## Typing stubs for pyinstaller

This is a [type stub package](https://typing.python.org/en/latest/tutorials/external_libraries.html)
for the [`pyinstaller`](https://github.com/pyinstaller/pyinstaller) package. It can be used by type checkers
to check code that uses `pyinstaller`. This version of
`types-pyinstaller` aims to provide accurate annotations for
`pyinstaller==6.19.*`.

This package is part of the [typeshed project](https://github.com/python/typeshed).
All fixes for types and metadata should be contributed there.
See [the README](https://github.com/python/typeshed/blob/main/README.md)
for more details. The source for this package can be found in the
[`stubs/pyinstaller`](https://github.com/python/typeshed/tree/main/stubs/pyinstaller)
directory.

This package was tested with the following type checkers:
* [mypy](https://github.com/python/mypy/) 1.19.1
* [pyright](https://github.com/microsoft/pyright) 1.1.408

It was generated from typeshed commit
[`7ad79d00cc532173a204de0405f04daeafc655f3`](https://github.com/python/typeshed/commit/7ad79d00cc532173a204de0405f04daeafc655f3).