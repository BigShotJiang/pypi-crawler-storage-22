## Typing stubs for pyperclip

This is a [type stub package](https://typing.python.org/en/latest/tutorials/external_libraries.html)
for the [`pyperclip`](https://github.com/asweigart/pyperclip) package. It can be used by type checkers
to check code that uses `pyperclip`. This version of
`types-pyperclip` aims to provide accurate annotations for
`pyperclip==1.11.*`.

This package is part of the [typeshed project](https://github.com/python/typeshed).
All fixes for types and metadata should be contributed there.
See [the README](https://github.com/python/typeshed/blob/main/README.md)
for more details. The source for this package can be found in the
[`stubs/pyperclip`](https://github.com/python/typeshed/tree/main/stubs/pyperclip)
directory.

This package was tested with the following type checkers:
* [mypy](https://github.com/python/mypy/) 1.19.1
* [pyright](https://github.com/microsoft/pyright) 1.1.408

It was generated from typeshed commit
[`9c00c6e556cd864c044daffb07733f3a8c38b621`](https://github.com/python/typeshed/commit/9c00c6e556cd864c044daffb07733f3a8c38b621).