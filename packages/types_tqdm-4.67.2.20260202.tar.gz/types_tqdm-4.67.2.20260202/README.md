## Typing stubs for tqdm

This is a [type stub package](https://typing.python.org/en/latest/tutorials/external_libraries.html)
for the [`tqdm`](https://github.com/tqdm/tqdm) package. It can be used by type checkers
to check code that uses `tqdm`. This version of
`types-tqdm` aims to provide accurate annotations for
`tqdm==4.67.2`.

This package is part of the [typeshed project](https://github.com/python/typeshed).
All fixes for types and metadata should be contributed there.
See [the README](https://github.com/python/typeshed/blob/main/README.md)
for more details. The source for this package can be found in the
[`stubs/tqdm`](https://github.com/python/typeshed/tree/main/stubs/tqdm)
directory.

This package was tested with the following type checkers:
* [mypy](https://github.com/python/mypy/) 1.19.1
* [pyright](https://github.com/microsoft/pyright) 1.1.408

It was generated from typeshed commit
[`c01356380fd56b42aa49a0aac8a320437fc7f7b9`](https://github.com/python/typeshed/commit/c01356380fd56b42aa49a0aac8a320437fc7f7b9).