# -*- coding: utf-8 -*-
"""typio main."""

if __name__ == "__main__":
    pass
