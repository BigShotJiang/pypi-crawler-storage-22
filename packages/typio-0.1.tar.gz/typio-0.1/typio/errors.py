# -*- coding: utf-8 -*-
"""typio errors."""


class TypioError(Exception):
    """Base class for errors in Typio."""
    
    pass
