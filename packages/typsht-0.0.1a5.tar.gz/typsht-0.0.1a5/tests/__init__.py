"""tests for typsht."""
