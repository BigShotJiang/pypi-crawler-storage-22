"""
========================================================================
TyxonQ 脉冲调教实战教程 - 第 3 步：单比特门精细调优与 Rabi 表征
========================================================================

本步骤的目的是：
✅ 精细调整脉冲参数以达到目标旋转角
✅ 通过 Rabi 振荡表征脉冲的真实特性
✅ 优化保真度至 > 99.9%

学习预期时间：60 分钟
难度：★★★☆☆

========================================================================
实践：精细调优与 Rabi 测量
========================================================================
"""

import numpy as np
from tyxonq import Circuit, waveforms
from tyxonq.core.ir.pulse import PulseProgram

print("""
╔════════════════════════════════════════════════════════════════════════╗
║  TyxonQ 脉冲调教教程 - 第 3 步：单比特门精细调优                       ║
╚════════════════════════════════════════════════════════════════════════╝
""")

# ========================================================================
# 第 3.1 部分：精细振幅调整
# ========================================================================

print("""
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
3.1 精细振幅调整：达到精确的 π 旋转
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

从第 2 步获得的粗调参数：
  • 振幅：约 0.8V
  • 时长：160 ns
  • β：约 0.2

现在进行精细扫描：
  • 范围：±10% 的粗调振幅
  • 步长：0.01 V（高精度）
""")

# 从第 2 步的粗调结果
coarse_amp = 0.8
coarse_duration = 160
coarse_beta = 0.2
coarse_sigma = coarse_duration / 4

# 精细扫描范围
fine_amplitudes = np.linspace(coarse_amp - 0.1, coarse_amp + 0.1, 21)

print(f"\n🔬 精细振幅扫描")
print(f"   范围：{fine_amplitudes[0]:.3f} 到 {fine_amplitudes[-1]:.3f} V")
print(f"   步长：{(fine_amplitudes[1] - fine_amplitudes[0]):.3f} V")
print(f"   扫描点数：{len(fine_amplitudes)}")

print(f"\n开始扫描...")
print("─" * 90)

fine_results = []

for amp in fine_amplitudes:
    prog = PulseProgram(num_qubits=1)
    prog.set_device_params(
        qubit_freq=[5.0e9],
        anharmonicity=[-330e6],
        T1=[80e-6],
        T2=[120e-6]
    )
    
    pulse = waveforms.Drag(
        amp=amp,
        duration=coarse_duration,
        sigma=coarse_sigma,
        beta=coarse_beta
    )
    prog.add_pulse(0, pulse, qubit_freq=5.0e9)
    state = prog.state(backend="numpy")
    
    pop_1 = abs(state[1])**2
    leakage = 1 - abs(state[0])**2 - pop_1
    
    # 推断旋转角
    inferred_angle = 2 * np.arcsin(np.sqrt(pop_1)) if pop_1 <= 1.0 else np.nan
    angle_error = abs(inferred_angle - np.pi)
    
    # 保真度估计
    fidelity = (1 - leakage) * pop_1
    
    fine_results.append({
        'amp': amp,
        'pop_1': pop_1,
        'leakage': leakage,
        'angle': inferred_angle,
        'angle_error': angle_error,
        'fidelity': fidelity
    })
    
    if amp % 0.05 < 0.01 or angle_error < 0.05:
        status = "✅" if fidelity > 0.99 else "✅" if fidelity > 0.95 else "⚠️"
        print(f"{status} 振幅 {amp:.3f}V: P₁={pop_1:.5f}  θ={inferred_angle/np.pi:.5f}π  "
              f"误差={angle_error:.5f}  泄漏={leakage:.5f}  保真度={fidelity:.5f}")

# 找到最优振幅
best_fine_idx = np.argmin([r['angle_error'] for r in fine_results])
best_fine = fine_results[best_fine_idx]

print("\n" + "=" * 90)
print("🎯 精细调优最佳振幅：")
print("=" * 90)
print(f"   最优振幅：{best_fine['amp']:.4f} V")
print(f"   推断旋转角：{best_fine['angle']/np.pi:.6f}π（目标 1.0000π）")
print(f"   角度误差：{best_fine['angle_error']:.6f}（约 {best_fine['angle_error']/np.pi*100:.3f}%）")
print(f"   |1⟩ 人口：{best_fine['pop_1']:.6f}（目标 1.0）")
print(f"   泄漏率：{best_fine['leakage']:.6f}（目标 < 0.1%）")
print(f"   估计保真度：{best_fine['fidelity']:.5f}（{best_fine['fidelity']*100:.3f}%）")

# ========================================================================
# 第 3.2 部分：Rabi 振荡表征
# ========================================================================

print("""
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
3.2 Rabi 振荡测量：验证脉冲特性
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

原理：
  保持脉冲幅度固定，扫描脉冲时长
  测量 |1⟩ 的人口随时长的变化
  从而绘制 Rabi 振荡曲线
  
用途：
  ✅ 验证 Rabi 频率是否与理论一致
  ✅ 检测脉冲质量（对比度、衰减）
  ✅ 精确校准旋转角（找到第一个零点）
""")

# Rabi 扫描：扫描脉冲时长
rabi_durations = np.linspace(10, 400, 40)  # 10 到 400 ns，40 个点

print(f"\n🔬 Rabi 振荡扫描")
print(f"   扫描范围：{rabi_durations[0]:.0f} 到 {rabi_durations[-1]:.0f} ns")
print(f"   扫描点数：{len(rabi_durations)}")

print(f"\n开始 Rabi 扫描...")

rabi_results = []

for duration in rabi_durations:
    prog = PulseProgram(num_qubits=1)
    prog.set_device_params(
        qubit_freq=[5.0e9],
        anharmonicity=[-330e6],
        T1=[80e-6],
        T2=[120e-6]
    )
    
    pulse = waveforms.Drag(
        amp=best_fine['amp'],
        duration=int(duration),
        sigma=int(duration / 4),
        beta=coarse_beta
    )
    prog.add_pulse(0, pulse, qubit_freq=5.0e9)
    state = prog.state(backend="numpy")
    
    pop_1 = abs(state[1])**2
    
    rabi_results.append({
        'duration': duration,
        'pop_1': pop_1
    })

# 找到几个关键点
rabi_durations_arr = np.array([r['duration'] for r in rabi_results])
rabi_pops = np.array([r['pop_1'] for r in rabi_results])

# 找到 π/2（P_1 ≈ 0.5）和 π（P_1 ≈ 1）
idx_pi_over_2 = np.argmin(np.abs(rabi_pops - 0.5))
idx_pi = np.argmin(np.abs(rabi_pops - 1.0))

print("\n📊 Rabi 振荡关键点：")
print("─" * 60)
print(f"{'旋转角':<12} {'时长(ns)':<15} {'|1⟩人口':<15} {'精度评价':<20}")
print("─" * 60)

# π/2 旋转
t_pi_2 = rabi_durations_arr[idx_pi_over_2]
p1_pi_2 = rabi_pops[idx_pi_over_2]
print(f"{'π/2':<12} {t_pi_2:<15.1f} {p1_pi_2:<15.4f} {'✅' if abs(p1_pi_2 - 0.5) < 0.05 else '⚠️'}")

# π 旋转
t_pi = rabi_durations_arr[idx_pi]
p1_pi = rabi_pops[idx_pi]
print(f"{'π':<12} {t_pi:<15.1f} {p1_pi:<15.4f} {'✅' if abs(p1_pi - 1.0) < 0.05 else '⚠️'}")

# 提取 Rabi 频率
rabi_frequency = np.pi / (t_pi * 1e-9)  # 转换为 rad/s
rabi_frequency_mhz = rabi_frequency / (2*np.pi) / 1e6  # 转换为 MHz

print(f"\n📈 Rabi 频率计算：")
print("─" * 60)
print(f"   从 π 旋转时长 {t_pi:.1f} ns 推断：")
print(f"   Ω = π / t = {rabi_frequency/(2*np.pi)/1e6:.2f} MHz")

# ========================================================================
# 第 3.3 部分：H 门调教
# ========================================================================

print("""
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
3.3 H 门调教：π/√2 旋转
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

H 门是 π/√2 旋转，在 (X+Z)/√2 方向
从 Rabi 频率可以推导所需时长
""")

# 计算 H 门所需时长
h_duration_required = (np.pi / np.sqrt(2)) / rabi_frequency * 1e9

print(f"\n🎯 计算 H 门参数：")
print(f"   所需旋转角：π/√2 = {np.pi/np.sqrt(2):.4f} rad")
print(f"   所需时长：{h_duration_required:.1f} ns")

# 验证 H 门
prog_h = PulseProgram(num_qubits=1)
prog_h.set_device_params(
    qubit_freq=[5.0e9],
    anharmonicity=[-330e6],
    T1=[80e-6],
    T2=[120e-6]
)

pulse_h = waveforms.Drag(
    amp=best_fine['amp'],
    duration=int(h_duration_required),
    sigma=int(h_duration_required / 4),
    beta=coarse_beta
)
prog_h.add_pulse(0, pulse_h, qubit_freq=5.0e9)
state_h = prog_h.state(backend="numpy")

pop_0_h = abs(state_h[0])**2
pop_1_h = abs(state_h[1])**2
leakage_h = 1 - pop_0_h - pop_1_h

h_fidelity = 1 - abs(pop_0_h - 0.5) - abs(pop_1_h - 0.5) - leakage_h

print(f"\n✅ H 门验证结果：")
print(f"   |0⟩ 人口：{pop_0_h:.5f}（理想 0.5）")
print(f"   |1⟩ 人口：{pop_1_h:.5f}（理想 0.5）")
print(f"   泄漏率：{leakage_h:.5f}")
print(f"   保真度（估计）：{h_fidelity:.5f}（{h_fidelity*100:.3f}%）")

# ========================================================================
# 总结
# ========================================================================

print("""
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
📌 第 3 步总结与调教结果
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
""")

print(f"""
✅ 完成的单比特门调教：

1️⃣ X 门（π 旋转）
   • 振幅：{best_fine['amp']:.4f} V
   • 时长：{coarse_duration} ns
   • σ：{coarse_sigma} ns
   • β：{coarse_beta:.2f}
   • 保真度：{best_fine['fidelity']:.5f}（{best_fine['fidelity']*100:.3f}%）

2️⃣ H 门（π/√2 旋转）
   • 振幅：{best_fine['amp']:.4f} V
   • 时长：{h_duration_required:.1f} ns
   • σ：{h_duration_required/4:.1f} ns
   • β：{coarse_beta:.2f}
   • 保真度：{h_fidelity:.5f}（{h_fidelity*100:.3f}%）

3️⃣ Rabi 特性表征
   • 提取的 Rabi 频率：{rabi_frequency_mhz:.2f} MHz

⚠️ 当前状态：
   ✅ 单比特门已优化到较高保真度
   ✅ Rabi 振荡已充分表征
   ⚠️ 还需要进行标准的门保真度测试
   ⚠️ 还需要根据实验调整参数

🎯 下一步（第 4 步）：
   → 进行双比特门（CX）的调教
   → 优化 CR 脉冲参数
   → 制备 Bell 态进行保真度测试

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
""")

print("\n✨ 第 3 步完成！单比特门调教已初步完成...")
