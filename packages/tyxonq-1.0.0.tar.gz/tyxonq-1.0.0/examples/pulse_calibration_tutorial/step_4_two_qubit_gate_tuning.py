"""
========================================================================
TyxonQ 脉冲调教实战教程 - 第 4 步：双比特门调教（CX 门设计与优化）
========================================================================

本步骤的目的是：
✅ 设计和优化 CX 门的 Cross-Resonance (CR) 脉冲序列
✅ 通过参数扫描找到最优的门时长和振幅
✅ 制备 Bell 态进行初步的保真度评估

学习预期时间：75 分钟
难度：★★★★☆

========================================================================
核心概念：CX 门的 Cross-Resonance 实现
========================================================================

CX（CNOT）门是最重要的两比特门。其 CR 脉冲序列包含四个步骤：

第一步：Pre-rotation
  • 门：RX(-π/2) 在控制比特 q0 上
  • 作用：准备 q0 进入易交互状态
  • 参数：振幅 ~-0.5，时长 ~40 ns

第二步：CR 驾驶脉冲 ⭐ 最关键
  • 门：在 q0 驾动，驾驶频率设为 q1 的频率
  • 作用：产生条件相位门 ~ZZ 相互作用
  • 参数：振幅 ~0.2-0.5，时长 ~200-400 ns ⭐
  
第三步：回声脉冲（可选）
  • 门：在 q1 上的脉冲
  • 作用：补偿 ZZ 串扰效应
  • 参数：通常是 Constant 脉冲

第四步：Post-rotation
  • 门：RX(π/2) 在 q0 上
  • 作用：恢复 q0 到计算基础
  • 参数：振幅 ~0.5，时长 ~40 ns

总执行时间：通常 200-600 ns

========================================================================
实践：双比特门调教
========================================================================
"""

import numpy as np
from tyxonq import Circuit, waveforms
from tyxonq.core.ir.pulse import PulseProgram

print("""
╔════════════════════════════════════════════════════════════════════════╗
║  TyxonQ 脉冲调教教程 - 第 4 步：双比特门调教                           ║
╚════════════════════════════════════════════════════════════════════════╝
""")

# ========================================================================
# 第 4.1 部分：硬件参数与单比特门结果回顾
# ========================================================================

print("""
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
4.1 双比特系统的硬件参数与单比特门结果
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
""")

# 从第 3 步获得的单比特门参数
single_qubit_params = {
    'q0': {
        'freq': 5.0e9,
        'anharm': -330e6,
        'T1': 80e-6,
        'T2': 120e-6,
        'X_amp': 0.78,
        'X_duration': 160,
    },
    'q1': {
        'freq': 5.1e9,
        'anharm': -320e6,
        'T1': 85e-6,
        'T2': 125e-6,
        'X_amp': 0.78,
        'X_duration': 160,
    }
}

print("\n✅ 双比特系统硬件配置")
print("─" * 80)
print(f"{'比特':<8} {'频率(GHz)':<15} {'非谐(MHz)':<15} {'T1(μs)':<12} {'T2(μs)':<12}")
print("─" * 80)

for qubit, params in single_qubit_params.items():
    freq = params['freq'] / 1e9
    anharm = params['anharm'] / 1e6
    t1 = params['T1'] * 1e6
    t2 = params['T2'] * 1e6
    print(f"{qubit:<8} {freq:<15.2f} {anharm:<15.0f} {t1:<12.0f} {t2:<12.0f}")

print("\n✅ 从第 3 步获得的单比特门参数")
print("─" * 80)
print(f"X 门脉冲（q0 和 q1 相同）：")
print(f"  • 振幅：{single_qubit_params['q0']['X_amp']:.2f} V")
print(f"  • 时长：{single_qubit_params['q0']['X_duration']} ns")
print(f"  • 保真度：99.3%（从第 3 步测得）")

# ========================================================================
# 第 4.2 部分：CX 门粗调 - CR 时长扫描
# ========================================================================

print("""
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
4.2 CX 门粗调：CR 脉冲时长扫描
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

策略：
  ✓ 固定 CR 脉冲振幅和其他参数
  ✓ 扫描 CR 脉冲的时长（最关键参数）
  ✓ 对每个时长测试 Bell 态 |Φ+⟩ = (|00⟩+|11⟩)/√2 的制备保真度
  ✓ 找到保真度最高的时长
""")

# CR 脉冲参数
q0_freq = single_qubit_params['q0']['freq']
q1_freq = single_qubit_params['q1']['freq']
q0_anharm = single_qubit_params['q0']['anharm']
q1_anharm = single_qubit_params['q1']['anharm']

# CR 时长和振幅的扫描范围
cr_durations = np.linspace(100, 400, 16)  # 100 到 400 ns，16 个点
cr_amplitudes = [0.3, 0.4, 0.5]  # 尝试不同的 CR 振幅

print(f"\n🔬 CR 脉冲扫描条件")
print("─" * 60)
print(f"CR 时长扫描范围：{cr_durations[0]:.0f} 到 {cr_durations[-1]:.0f} ns")
print(f"CR 振幅尝试值：{cr_amplitudes}")
print(f"q0 驾驱频率：{q0_freq/1e9:.1f} GHz")
print(f"q1 驾驱频率（CR 目标）：{q1_freq/1e9:.1f} GHz")
print(f"频率偏差：{(q1_freq - q0_freq)/1e6:.0f} MHz\n")

# 对每个 CR 振幅进行扫描
cx_results_by_amp = {}

for cr_amp in cr_amplitudes:
    print(f"━━━ CR 振幅 = {cr_amp:.1f}V ━━━")
    print(f"{'时长(ns)':<12} {'Bell保真度':<15} {'|00⟩':<10} {'|11⟩':<10} {'|01⟩':<10} {'|10⟩':<10}")
    print("─" * 70)
    
    cx_results = []
    
    for cr_duration in cr_durations:
        # 模拟 Bell 态制备的保真度
        # 理想 Bell 态 |Φ+⟩：(|00⟩ + |11⟩) / √2
        # 即：P(00) ≈ 0.5，P(11) ≈ 0.5，P(01) ≈ 0，P(10) ≈ 0
        
        # CR 时长对 CX 保真度的影响（高斯型）
        # 假设最优 CR 时长约为 280 ns
        optimal_cr_duration = 280
        cr_error = abs(cr_duration - optimal_cr_duration) / optimal_cr_duration
        
        # Bell 保真度随 CR 时长变化（高斯衰减）
        # F = exp(-k·error²) 其中 k 控制衰减速度
        bell_fidelity = np.exp(-1.5 * cr_error**2) * (1 - 0.01 * cr_error)
        bell_fidelity = max(0.5, min(1.0, bell_fidelity))
        
        # Bell 态的人口分布
        # 完美 CX 后：|00⟩ 和 |11⟩ 各 50%，|01⟩ 和 |10⟩ 各 0%
        # 失效模式 1：参数偏离导致不完全翻转 → |01⟩ 人口增加
        # 失效模式 2：ZZ 串扰导致额外相位 → 降低对比度
        
        p_00 = 0.5 * bell_fidelity + (1 - bell_fidelity) * 0.25  # 基线 25% + 贡献
        p_11 = 0.5 * bell_fidelity + (1 - bell_fidelity) * 0.25
        p_01 = (1 - bell_fidelity) * 0.25
        p_10 = (1 - bell_fidelity) * 0.25
        
        cx_results.append({
            'cr_duration': cr_duration,
            'bell_fidelity': bell_fidelity,
            'p_00': p_00,
            'p_11': p_11,
            'p_01': p_01,
            'p_10': p_10,
        })
        
        # 打印进度
        status = "✅" if bell_fidelity > 0.95 else "⚠️" if bell_fidelity > 0.85 else "❌"
        print(f"{cr_duration:>6.0f}      {bell_fidelity:<15.4f} "
              f"{p_00:<10.4f} {p_11:<10.4f} {p_01:<10.4f} {p_10:<10.4f}  {status}")
    
    cx_results_by_amp[cr_amp] = cx_results
    
    # 找到这个振幅下的最优时长
    best_idx = np.argmax([r['bell_fidelity'] for r in cx_results])
    best_result = cx_results[best_idx]
    
    print(f"\n✅ 最优 CR 时长：{best_result['cr_duration']:.0f} ns "
          f"(Bell 保真度：{best_result['bell_fidelity']:.4f})\n")

# ========================================================================
# 第 4.3 部分：CX 门精细调优
# ========================================================================

print("""
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
4.3 CX 门精细调优：CR 振幅与时长联合优化
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

在找到最优 CR 时长后，还需要精细调整振幅和时长以最大化保真度
""")

# 选择最好的粗调结果
best_cr_amp = max(cx_results_by_amp.keys(), 
                  key=lambda k: max(r['bell_fidelity'] for r in cx_results_by_amp[k]))
best_coarse_results = cx_results_by_amp[best_cr_amp]
best_idx = np.argmax([r['bell_fidelity'] for r in best_coarse_results])
best_cr_duration_coarse = best_coarse_results[best_idx]['cr_duration']

print(f"\n✅ 粗调最优值：")
print(f"   CR 振幅：{best_cr_amp:.1f}V")
print(f"   CR 时长：{best_cr_duration_coarse:.0f} ns")
print(f"   粗调 Bell 保真度：{best_coarse_results[best_idx]['bell_fidelity']:.4f}\n")

# 精细调整
print(f"🔬 CR 参数精细调整")
print("─" * 70)

# 在粗调最优附近进行精细扫描
fine_cr_amps = np.linspace(best_cr_amp - 0.1, best_cr_amp + 0.1, 7)
fine_cr_durations = np.linspace(best_cr_duration_coarse - 40, best_cr_duration_coarse + 40, 7)

print(f"{'振幅(V)':<10} {'时长(ns)':<12} {'Bell保真度':<15} {'评价':<15}")
print("─" * 70)

fine_results = []

for cr_amp in fine_cr_amps:
    for cr_duration in fine_cr_durations:
        # 联合参数效应
        cr_error = abs(cr_duration - 280) / 280
        
        # 振幅偏差也影响（假设振幅 0.4V 最优）
        amp_error = abs(cr_amp - 0.4) / 0.4 if 0.4 > 0 else 0
        
        # 综合效应
        total_error = np.sqrt(0.7 * cr_error**2 + 0.3 * amp_error**2)
        bell_fidelity = np.exp(-1.5 * total_error**2) * (1 - 0.01 * total_error)
        bell_fidelity = max(0.5, min(1.0, bell_fidelity))
        
        fine_results.append({
            'cr_amp': cr_amp,
            'cr_duration': cr_duration,
            'bell_fidelity': bell_fidelity
        })
        
        status = "✅" if bell_fidelity > 0.98 else "✅" if bell_fidelity > 0.95 else "⚠️"
        print(f"{cr_amp:<10.2f} {cr_duration:<12.0f} {bell_fidelity:<15.4f} {status:<15}")

# 找到全局最优
best_fine_idx = np.argmax([r['bell_fidelity'] for r in fine_results])
best_fine = fine_results[best_fine_idx]

print(f"\n" + "=" * 70)
print(f"🎯 CX 门精细调优最优参数：")
print(f"=" * 70)
print(f"   CR 振幅：{best_fine['cr_amp']:.2f}V")
print(f"   CR 时长：{best_fine['cr_duration']:.0f} ns")
print(f"   Bell 保真度：{best_fine['bell_fidelity']:.4f}（{best_fine['bell_fidelity']*100:.2f}%）")

# ========================================================================
# 第 4.4 部分：完整 CX 门参数总结
# ========================================================================

print("""
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
4.4 完整 CX 门脉冲序列设计
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
""")

# 从单比特门参数计算相关量
rabi_freq_q0 = 2 * np.pi * 50e6  # MHz，从第 3 步的 Rabi 测量
rabi_freq_q1 = 2 * np.pi * 50e6

# π/2 旋转所需时长
pi_2_duration_q0 = (np.pi / 2) / rabi_freq_q0 * 1e9
pi_2_duration_q1 = (np.pi / 2) / rabi_freq_q1 * 1e9

print(f"\n📋 完整的 CX 门脉冲序列（q0→q1）")
print("─" * 80)

print(f"\n第 1 步：Pre-rotation (RX(-π/2) 在 q0)")
print(f"  • 脉冲类型：Gaussian")
print(f"  • 振幅：-0.5 V（负号表示反向旋转）")
print(f"  • 时长：{pi_2_duration_q0:.0f} ns（π/2 旋转）")
print(f"  • 高斯宽度：{pi_2_duration_q0/4:.0f} ns")
print(f"  • 目标频率：{single_qubit_params['q0']['freq']/1e9:.1f} GHz")
print(f"  作用：准备 q0 进入交互态")

print(f"\n第 2 步：CR 驾驶脉冲（最关键）")
print(f"  • 脉冲类型：Gaussian")
print(f"  • 振幅：{best_fine['cr_amp']:.2f} V ⭐")
print(f"  • 时长：{best_fine['cr_duration']:.0f} ns ⭐")
print(f"  • 高斯宽度：{best_fine['cr_duration']/4:.0f} ns")
print(f"  • 驾驱频率：{q1_freq/1e9:.1f} GHz（q1 频率，与 q0 不同调谐）")
print(f"  • 频率偏差：{(q1_freq - q0_freq)/1e6:.0f} MHz")
print(f"  作用：在 q0 上驾驱，产生 ZZ 相互作用")

print(f"\n第 3 步：Post-rotation (RX(π/2) 在 q0)")
print(f"  • 脉冲类型：Gaussian")
print(f"  • 振幅：0.5 V")
print(f"  • 时长：{pi_2_duration_q0:.0f} ns（π/2 旋转）")
print(f"  • 高斯宽度：{pi_2_duration_q0/4:.0f} ns")
print(f"  • 目标频率：{single_qubit_params['q0']['freq']/1e9:.1f} GHz")
print(f"  作用：恢复 q0 到计算基础")

total_cx_time = pi_2_duration_q0 + best_fine['cr_duration'] + pi_2_duration_q0
print(f"\n⏱️ CX 门总执行时间：{total_cx_time:.0f} ns")
print(f"   约束检查：")
print(f"   • < T1/10 (q0: {single_qubit_params['q0']['T1']*1e6/10:.0f} ns)：{total_cx_time:.0f} ns < {single_qubit_params['q0']['T1']*1e6/10:.0f} ns ✅" 
      if total_cx_time < single_qubit_params['q0']['T1']*1e6/10 else 
      f"   • < T1/10 (q0: {single_qubit_params['q0']['T1']*1e6/10:.0f} ns)：{total_cx_time:.0f} ns > {single_qubit_params['q0']['T1']*1e6/10:.0f} ns ⚠️")
print(f"   • < 2·T2* (q0: {single_qubit_params['q0']['T2']*1e6/2:.0f} ns)：{total_cx_time:.0f} ns < {single_qubit_params['q0']['T2']*1e6/2:.0f} ns ✅"
      if total_cx_time < single_qubit_params['q0']['T2']*1e6/2 else
      f"   • < 2·T2* (q0: {single_qubit_params['q0']['T2']*1e6/2:.0f} ns)：{total_cx_time:.0f} ns > {single_qubit_params['q0']['T2']*1e6/2:.0f} ns ⚠️")

# ========================================================================
# 总结
# ========================================================================

print("""
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
📌 第 4 步总结：CX 门调教完成
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
""")

print(f"""
✅ CX 门调教成果摘要：

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

关键脉冲参数（CR 驾驶）：
  • 振幅：{best_fine['cr_amp']:.2f} V
  • 时长：{best_fine['cr_duration']:.0f} ns
  • 驾驱频率：{q1_freq/1e9:.1f} GHz（q1 频率）

两比特门性能：
  • Bell 态保真度：{best_fine['bell_fidelity']:.4f}（{best_fine['bell_fidelity']*100:.2f}%）
  • 总执行时间：{total_cx_time:.0f} ns
  
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

⚠️ 当前状态：
   ✅ CX 门脉冲序列已设计
   ✅ CR 参数已通过扫描优化
   ⚠️ 需要进行实验验证（Bell 态制备、CHSH 测试）
   ⚠️ 可能需要微调以处理硬件特殊性（ZZ 串扰、驰豫）

🎯 下一步（第 5 步）：
   → 进行严格的双比特门性能评估
   → 制备所有四个 Bell 态
   → 测量纠缠度和 CHSH 违反度
   → 评估泄漏率和同时门错误

💾 保存这些参数到校准文件：

   two_qubit_calibration = {{
       'CX': {{
           'control': 0,
           'target': 1,
           'CR_pulse': {{
               'pulse_type': 'Gaussian',
               'amplitude': {best_fine['cr_amp']:.2f},
               'duration_ns': {best_fine['cr_duration']:.0f},
               'sigma_ns': {best_fine['cr_duration']/4:.0f},
               'drive_freq_GHz': {q1_freq/1e9:.2f}  # q1 频率
           }},
           'pre_rotation': {{
               'amplitude': -0.5,
               'duration_ns': {pi_2_duration_q0:.0f}
           }},
           'post_rotation': {{
               'amplitude': 0.5,
               'duration_ns': {pi_2_duration_q0:.0f}
           }},
           'total_time_ns': {total_cx_time:.0f},
           'measured_bell_fidelity': {best_fine['bell_fidelity']:.5f}
       }}
   }}

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
""")

print("\n✨ 第 4 步完成！现在进入双比特门性能的严格评估...")
