# UBE MCP Server

The UBE MCP Server gives you a single, convenient doorway into your build world. Ask it to build, clean, list source files, show logs, or outline the project structure—and get an immediate, clear answer. No hunting for scripts, no digging through folders.

## Why People Use It

- One Command Access: Kick off a build or clean without memorizing long tool invocations.
- Instant Clarity: See whether artifacts exist and what’s inside your project at a glance.
- Fewer Interruptions: Spend less time context‑switching between terminals, explorers, and ad‑hoc scripts.
- Confident Starts: If something’s missing (like the build tool path), you get a helpful message instead of a mystery failure.
- Log Visibility: Grab recent build logs quickly to understand what happened—without spelunking.

## Core Benefits

| Benefit | What You Get |
|---------|--------------|
| Speed | Build + clean actions ready on demand. |
| Focus | Answers about structure, sources, and status in seconds. |
| Simplicity | Human‑readable responses; no technical noise. |
| Reliability | Clear success/fail messages you can trust. |
| Visibility | Quick peeks at logs and artifacts to unblock decisions. |

## Automatic Help From GitHub Copilot

Because this server is integrated with GitHub Copilot, compile and build hiccups don’t stall you—they trigger smart, instant suggestions. Instead of digging through opaque errors, you get:

- Real-time guidance on what went wrong and how to fix it.
- Suggested command retries or cleanup steps when builds fail.
- Fast resolutions for missing paths, absent artifacts, or mis‑named source files.
- Less guesswork; more forward motion.

Think of it as a silent build assistant: you focus on features, Copilot spots the friction and smooths it out. The moment an issue appears, you’re already looking at a clear next step.

## Available Tools (What You Can Ask For)

You don’t need to remember internal command names—just think of what you want to do. The server offers:

| Tool | Plain-English Purpose | Typical Use |
|------|-----------------------|-------------|
| `ube_build` | Build the project now and tell me how it went. | “Build everything.” |
| `ube_clean` | Clear out previous build output so I can start fresh. | “Reset before rebuilding.” |
| `ube_compile_commands` | Produce compile command info used by editors/intellisense. | “Enable better code navigation.” |
| `check_build_status` | Tell me if build artifacts exist. | “Did the last build succeed?” |
| `list_source_files` | Show me the source files (filter by extension). | “Where are the C files?” |
| `get_workspace_info` | Give me a quick summary of what’s in this folder. | “What kind of project is this?” |

And some helpful read-only info “resources” you can fetch:

| Resource | What It Gives You |
|----------|-------------------|
| `build-config://workspace` | Current settings (paths and available commands). |
| `build-log://{workspace}` | Recent snippets from build logs (helpful for quick diagnosis). |
| `project-structure://{path}` | A simple tree view so you grasp layout fast. |

Ask for any of these through your MCP-enabled client and you’ll get a clear, human-friendly response.

## Typical Questions It Answers

| Question | Ask The Server |
|----------|----------------|
| “Did the build produce anything?” | Build status check. |
| “Where are my C sources?” | Source listing. |
| “What does this project look like?” | Project structure view. |
| “What commands are available?” | Build config resource. |
| “Can I safely clean and start fresh?” | Clean command. |

## How You Use It

Start it, then interact through any MCP‑aware client (or an integration in your tools). You make requests; it gives you straight answers.

## Zero Fuss Setup

1. Ensure the UBE tool is installed at `C:\Conan\aurix_rc1_sw\UBE\1.0.0\ube.exe` or set your own path by using `UBE_PATH` env variable.
2. Launch the server.
3. Send build or info requests from your client of choice.

That’s it—no manual wiring, no noisy output.

## When It Saves Your Day

- You need a quick confirmation a build is still healthy.
- You’re onboarding and want a rapid mental map of the codebase.
- You’re cleaning up after a broken attempt and want a fresh start fast.
- You’re demoing a workflow and need consistent, readable responses.

## Why Trust It

It was designed to be quiet unless spoken to, clear when responding, and helpful when something’s missing. It doesn’t dump jargon—just the information you need to move forward.

## Growing With You

More conveniences can be added (like live build progress or metrics). The surface is intentionally simple now so you can benefit immediately.

## Try It Now

Launch it and ask for a build.

## Contact

In case of any doubts please contact Chahat Gupta (ATV MC D SW IMA MET)
