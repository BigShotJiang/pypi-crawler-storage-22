# Ubidots MCP Server

stdio proxy to connect MCP clients with the Ubidots MCP server.

## Setup with Claude Desktop

Add to your `claude_desktop_config.json`:

```json
{
  "mcpServers": {
    "ubidots": {
      "command": "uvx",
      "args": ["ubidots-mcp-server"],
      "env": {
        "X_AUTH_TOKEN": "your-token-here"
      }
    }
  }
}
```

### Custom Deployment

```json
{
  "mcpServers": {
    "my-iot": {
      "command": "uvx",
      "args": ["ubidots-mcp-server"],
      "env": {
        "X_AUTH_TOKEN": "your-token",
        "MCP_BASE_URL": "https://mcp.your-domain.com/mcp"
      }
    }
  }
}
```

## Environment Variables

| Variable | Required | Description |
|----------|----------|-------------|
| `X_AUTH_TOKEN` | Yes | Authentication token |
| `MCP_BASE_URL` | No | MCP server URL (default: `https://mcp.ubidots.com/mcp`) |
| `MCP_LOG_LEVEL` | No | Log level: DEBUG, INFO, WARNING, ERROR (default: INFO) |

## Development

```bash
git clone <repo>
cd ubidots-mcp-server
pip install -e ".[dev]"
pytest
```
