# Configuration

## Claude Desktop

The configuration file is located at:

- **macOS**: `~/Library/Application Support/Claude/claude_desktop_config.json`
- **Windows**: `%APPDATA%\Claude\claude_desktop_config.json`
- **Linux**: `~/.config/Claude/claude_desktop_config.json`

### Basic Setup

```json
{
  "mcpServers": {
    "ubidots": {
      "command": "uvx",
      "args": ["ubidots-mcp-server"],
      "env": {
        "X_AUTH_TOKEN": "UBIDOTS-xxxxxxxxxxxx"
      }
    }
  }
}
```

## Claude Code

Add to `~/.claude/claude_code_settings.json`:

```json
{
  "mcpServers": {
    "ubidots": {
      "command": "uvx",
      "args": ["ubidots-mcp-server"],
      "env": {
        "X_AUTH_TOKEN": "UBIDOTS-xxxxxxxxxxxx"
      }
    }
  }
}
```

## Environment Variables

| Variable | Required | Default | Description |
|----------|----------|---------|-------------|
| `X_AUTH_TOKEN` | Yes | - | Ubidots authentication token |
| `MCP_BASE_URL` | No | `https://mcp.ubidots.com/mcp` | MCP server URL |
| `MCP_LOG_LEVEL` | No | `INFO` | Logging level (DEBUG, INFO, WARNING, ERROR) |

## Getting Your Token

1. Log in to your Ubidots account
2. Go to **API Credentials** in your profile
3. Copy the **Default Token**
