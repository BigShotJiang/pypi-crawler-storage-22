# Custom Deployment

The proxy supports custom deployments by configuring the MCP server URL.

## Configuration

```json
{
  "mcpServers": {
    "my-iot-platform": {
      "command": "uvx",
      "args": ["ubidots-mcp-server"],
      "env": {
        "X_AUTH_TOKEN": "your-token",
        "MCP_BASE_URL": "https://mcp.your-domain.com/mcp"
      }
    }
  }
}
```

## Requirements

The remote MCP server must:

- Support SSE (Server-Sent Events) transport
- Accept authentication via `X-Auth-Token` header
- Implement the standard MCP protocol

## Multiple Servers

You can configure multiple MCP servers:

```json
{
  "mcpServers": {
    "ubidots-prod": {
      "command": "uvx",
      "args": ["ubidots-mcp-server"],
      "env": {
        "X_AUTH_TOKEN": "production-token",
        "MCP_BASE_URL": "https://mcp.ubidots.com/mcp"
      }
    },
    "ubidots-staging": {
      "command": "uvx",
      "args": ["ubidots-mcp-server"],
      "env": {
        "X_AUTH_TOKEN": "staging-token",
        "MCP_BASE_URL": "https://mcp.staging.ubidots.com/mcp"
      }
    }
  }
}
```
