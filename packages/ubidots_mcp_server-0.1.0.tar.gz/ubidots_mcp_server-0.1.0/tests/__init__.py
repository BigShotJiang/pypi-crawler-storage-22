"""Test suite for ubi-mcp-proxy."""
