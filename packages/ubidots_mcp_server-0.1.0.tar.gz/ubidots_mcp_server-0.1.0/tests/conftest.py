"""
Pytest configuration and fixtures.

This module provides shared fixtures for all tests.
"""

import pytest


@pytest.fixture(autouse=True)
def clean_env(monkeypatch: pytest.MonkeyPatch) -> None:
    """
    Clean environment variables before each test.

    This ensures tests don't interfere with each other.
    """
    monkeypatch.delenv("X_AUTH_TOKEN", raising=False)
    monkeypatch.delenv("MCP_BASE_URL", raising=False)
    monkeypatch.delenv("MCP_LOG_LEVEL", raising=False)
