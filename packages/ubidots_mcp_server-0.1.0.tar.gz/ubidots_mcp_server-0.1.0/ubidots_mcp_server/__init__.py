"""
Ubidots MCP Server - stdio proxy for the Ubidots MCP server.

This package provides a proxy that connects to a remote MCP server via SSE
and exposes a stdio interface for local clients.
"""

__version__ = "0.1.0"
__author__ = "Ubidots"
__license__ = "MIT"

from ubidots_mcp_server.proxy import MCPProxy

__all__ = ["MCPProxy"]
