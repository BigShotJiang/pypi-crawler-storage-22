"""
Entry point for the ubidots-mcp-server command.

This module provides the main() function that is called when the package
is executed as a script or via the installed CLI command.
"""

import asyncio
import sys
from typing import NoReturn


def main() -> NoReturn:
    """
    Main entry point for the CLI command.

    This function is registered as the 'ubidots-mcp-server' console script
    in pyproject.toml.
    """
    from ubidots_mcp_server.proxy import run_proxy

    try:
        asyncio.run(run_proxy())
    except KeyboardInterrupt:
        sys.exit(0)
    except Exception:
        sys.exit(1)

    sys.exit(0)


if __name__ == "__main__":
    main()
