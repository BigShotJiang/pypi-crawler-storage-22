"""
优测 UBox 异常定义

定义 UBox 中使用的各种异常类型。
"""


def _format_error_message_with_context(
    base_message: str,
    trace_id: str = None,
    auth_code: str = None,
    debug_id: str = None,
    udid: str = None,
) -> str:
    """
    格式化错误消息，附加调试上下文信息（traceId、authCode、debugId、udid）。
    
    Args:
        base_message: 基础错误消息
        trace_id: 追踪ID（可选）
        auth_code: 认证码（可选）
        debug_id: 调试ID（可选）
        udid: 设备唯一标识（可选）
    
    Returns:
        格式化后的错误消息，包含所有可用的调试信息
    """
    parts = [base_message]
    context_parts = []
    
    # 按顺序添加可用的调试信息
    if udid:
        context_parts.append(f"udid: {udid}")
    if trace_id:
        context_parts.append(f"traceId: {trace_id}")
    if auth_code:
        context_parts.append(f"authCode: {auth_code}")
    if debug_id:
        context_parts.append(f"debugId: {debug_id}")
    
    # 如果有任何上下文信息，添加到消息末尾
    if context_parts:
        parts.append(f" ({', '.join(context_parts)})")
    
    return "".join(parts)


class UBoxError(Exception):
    """
    优测 UBox 基础异常类
    
    所有 UBox 相关异常的基类。
    """
    
    def __init__(
        self,
        message: str,
        code: str = None,
        trace_id: str = None,
        auth_code: str = None,
        debug_id: str = None,
        udid: str = None,
    ):
        """
        初始化异常
        
        Args:
            message: 错误消息
            code: 错误代码（可选）
            trace_id: 追踪ID（可选）
            auth_code: 认证码（可选）
            debug_id: 调试ID（可选）
            udid: 设备唯一标识（可选）
        """
        # 保存原始消息和调试信息
        self._base_message = message
        self.code = code
        self.trace_id = trace_id
        self.auth_code = auth_code
        self.debug_id = debug_id
        self.udid = udid
        
        # 格式化完整消息（包含调试信息）
        formatted_message = _format_error_message_with_context(
            message, trace_id=trace_id, auth_code=auth_code, debug_id=debug_id, udid=udid
        )
        self.message = formatted_message
        super().__init__(self.message)
    
    def __str__(self):
        """返回异常字符串表示"""
        result = self.message
        
        # 添加错误代码（如果存在）
        if self.code:
            result = f"[{self.code}] {result}"
        
        # 添加字段信息（如果有的话）
        if hasattr(self, 'field') and self.field:
            result = f"{result} (字段: {self.field})"
        return result


class UBoxConnectionError(UBoxError):
    """
    连接异常
    
    当无法连接到优测设备或连接中断时抛出。
    """
    
    def __init__(
        self,
        message: str,
        trace_id: str = None,
        auth_code: str = None,
        debug_id: str = None,
        udid: str = None,
    ):
        super().__init__(
            message,
            code="CONNECTION_ERROR",
            trace_id=trace_id,
            auth_code=auth_code,
            debug_id=debug_id,
            udid=udid,
        )


class UBoxAuthenticationError(UBoxError):
    """
    认证异常
    
    当用户名、密码错误或权限不足时抛出。
    """
    
    def __init__(
        self,
        message: str,
        trace_id: str = None,
        auth_code: str = None,
        debug_id: str = None,
        udid: str = None,
    ):
        super().__init__(
            message,
            code="AUTHENTICATION_ERROR",
            trace_id=trace_id,
            auth_code=auth_code,
            debug_id=debug_id,
            udid=udid,
        )


class UBoxValidationError(UBoxError):
    """
    数据验证异常
    
    当输入数据格式不正确或验证失败时抛出。
    """
    
    def __init__(
        self,
        message: str,
        field: str = None,
        trace_id: str = None,
        auth_code: str = None,
        debug_id: str = None,
        udid: str = None,
    ):
        self.field = field
        super().__init__(
            message,
            code="VALIDATION_ERROR",
            trace_id=trace_id,
            auth_code=auth_code,
            debug_id=debug_id,
            udid=udid,
        )


class UBoxTimeoutError(UBoxError):
    """
    超时异常
    
    当请求超时时抛出。
    """
    
    def __init__(
        self,
        message: str,
        trace_id: str = None,
        auth_code: str = None,
        debug_id: str = None,
        udid: str = None,
    ):
        super().__init__(
            message,
            code="TIMEOUT_ERROR",
            trace_id=trace_id,
            auth_code=auth_code,
            debug_id=debug_id,
            udid=udid,
        )


class UBoxDeviceError(UBoxError):
    """
    设备异常
    
    当设备返回错误或设备状态异常时抛出。
    """
    
    def __init__(
        self,
        message: str,
        trace_id: str = None,
        auth_code: str = None,
        debug_id: str = None,
        udid: str = None,
    ):
        super().__init__(
            message,
            code="DEVICE_ERROR",
            trace_id=trace_id,
            auth_code=auth_code,
            debug_id=debug_id,
            udid=udid,
        )
