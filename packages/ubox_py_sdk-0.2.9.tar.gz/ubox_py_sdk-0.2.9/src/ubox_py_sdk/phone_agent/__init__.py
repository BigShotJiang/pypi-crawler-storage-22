"""
Exploration Agent - 基于AI的手机自动化探索测试框架。

支持UBOX SDK设备的探索测试Agent能力，SDK已统一支持Android、iOS和HarmonyOS三端。
用户只需要在创建UBox时传入ModelConfig和AgentConfig，然后使用device.explore()方法即可。
"""

# 导出用户需要的配置类和结构体
from .agent import (
    AgentConfig,
    ExplorationAgent,
    StepUpdate,
    UpdateType,
    ActionDict,
    Screenshot,
)
from .device_interface import IDeviceOperations
from .model import ModelConfig, ModelResponse
from .actions.handler import ActionResult

__version__ = "0.1.0"
__all__ = [
    "ModelConfig",
    "ModelResponse",
    "AgentConfig",
    "ExplorationAgent",
    "StepUpdate",
    "UpdateType",
    "ActionDict",
    "Screenshot",
    "ActionResult",
    "IDeviceOperations",
]
