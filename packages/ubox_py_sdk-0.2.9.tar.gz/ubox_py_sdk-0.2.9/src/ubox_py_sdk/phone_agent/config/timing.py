"""Phone Agent的时序配置。

此模块定义了整个应用程序中所有可配置的等待时间。
用户可以通过修改此文件或设置环境变量来自定义这些值。
"""

import os
from dataclasses import dataclass
from typing import Optional


@dataclass
class ActionTimingConfig:
    """动作处理器的时序延迟配置。"""

    text_input_delay: float = 1.0  # 输入文本后的延迟

    def __post_init__(self):
        """如果存在环境变量，则从环境变量加载值。"""
        self.text_input_delay = float(
            os.getenv("PHONE_AGENT_TEXT_INPUT_DELAY", self.text_input_delay)
        )


@dataclass
class DeviceTimingConfig:
    """设备操作的时序延迟配置。"""

    default_tap_delay: float = 1.0  # 点击后的默认延迟
    default_double_tap_delay: float = 1.0  # 双击后的默认延迟
    default_long_press_delay: float = 1.0  # 长按后的默认延迟
    default_swipe_delay: float = 1.0  # 滑动后的默认延迟
    default_back_delay: float = 1.0  # 按下返回键后的默认延迟
    default_home_delay: float = 1.0  # 按下Home键后的默认延迟
    default_launch_delay: float = 1.0  # 启动应用后的默认延迟

    def __post_init__(self):
        """如果存在环境变量，则从环境变量加载值。"""
        self.default_tap_delay = float(
            os.getenv("PHONE_AGENT_TAP_DELAY", self.default_tap_delay)
        )
        self.default_double_tap_delay = float(
            os.getenv("PHONE_AGENT_DOUBLE_TAP_DELAY", self.default_double_tap_delay)
        )
        self.default_long_press_delay = float(
            os.getenv("PHONE_AGENT_LONG_PRESS_DELAY", self.default_long_press_delay)
        )
        self.default_swipe_delay = float(
            os.getenv("PHONE_AGENT_SWIPE_DELAY", self.default_swipe_delay)
        )
        self.default_back_delay = float(
            os.getenv("PHONE_AGENT_BACK_DELAY", self.default_back_delay)
        )
        self.default_home_delay = float(
            os.getenv("PHONE_AGENT_HOME_DELAY", self.default_home_delay)
        )
        self.default_launch_delay = float(
            os.getenv("PHONE_AGENT_LAUNCH_DELAY", self.default_launch_delay)
        )


@dataclass
class TimingConfig:
    """主时序配置，整合所有时序设置。"""

    action: ActionTimingConfig
    device: DeviceTimingConfig

    def __init__(self):
        """初始化所有时序配置。"""
        self.action = ActionTimingConfig()
        self.device = DeviceTimingConfig()


# 全局时序配置实例
# 用户可以在运行时或通过环境变量修改这些值
TIMING_CONFIG = TimingConfig()


def get_timing_config() -> TimingConfig:
    """
    获取全局时序配置。

    Returns:
        全局TimingConfig实例。
    """
    return TIMING_CONFIG


def update_timing_config(
    action: Optional[ActionTimingConfig] = None,
    device: Optional[DeviceTimingConfig] = None,
) -> None:
    """
    更新全局时序配置。

    Args:
        action: 新的动作时序配置。
        device: 新的设备时序配置。

    Example:
        >>> from ubox_py_sdk.phone_agent.config.timing import update_timing_config, ActionTimingConfig
        >>> custom_action = ActionTimingConfig(text_input_delay=0.5)
        >>> update_timing_config(action=custom_action)
    """
    global TIMING_CONFIG
    if action is not None:
        TIMING_CONFIG.action = action
    if device is not None:
        TIMING_CONFIG.device = device


__all__ = [
    "ActionTimingConfig",
    "DeviceTimingConfig",
    "TimingConfig",
    "TIMING_CONFIG",
    "get_timing_config",
    "update_timing_config",
]
