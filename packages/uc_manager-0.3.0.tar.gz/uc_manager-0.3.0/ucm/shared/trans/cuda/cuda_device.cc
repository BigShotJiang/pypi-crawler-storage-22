/**
 * MIT License
 *
 * Copyright (c) 2025 Huawei Technologies Co., Ltd. All rights reserved.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 * */
#include <cuda_runtime.h>
#include <nvml.h>
#include "cuda_buffer.h"
#include "cuda_sm_stream.h"
#include "cuda_stream.h"
#include "trans/device.h"

namespace UC::Trans {

static void SetCpuAffinity(int32_t deviceId)
{
    nvmlDevice_t device;
    auto ret = nvmlDeviceGetHandleByIndex(deviceId, &device);
    if (ret != NVML_SUCCESS) { return; }
    nvmlDeviceSetCpuAffinity(device);
}

Status Device::Setup(int32_t deviceId)
{
    auto ret = cudaSetDevice(deviceId);
    if (ret != cudaSuccess) { return Status{ret, cudaGetErrorString(ret)}; }
    SetCpuAffinity(deviceId);
    return Status::OK();
}

std::unique_ptr<Stream> Device::MakeStream()
{
    std::unique_ptr<Stream> stream = nullptr;
    try {
        stream = std::make_unique<CudaStream>();
    } catch (...) {
        return nullptr;
    }
    if (stream->Setup().Success()) { return stream; }
    return nullptr;
}

std::unique_ptr<Stream> Device::MakeSMStream()
{
    std::unique_ptr<Stream> stream = nullptr;
    try {
        stream = std::make_unique<CudaSmStream>();
    } catch (...) {
        return nullptr;
    }
    if (stream->Setup().Success()) { return stream; }
    return nullptr;
}

std::unique_ptr<Buffer> Device::MakeBuffer()
{
    try {
        return std::make_unique<CudaBuffer>();
    } catch (...) {
        return nullptr;
    }
}

} // namespace UC::Trans
