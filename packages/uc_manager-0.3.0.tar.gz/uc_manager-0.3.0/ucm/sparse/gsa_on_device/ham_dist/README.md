## How to Run
```sh
python setup.py install
python demo.py
```