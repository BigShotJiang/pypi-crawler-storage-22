# Version

[Ucndata Index](./README.md#ucndata-index) / Version

> Auto-generated documentation for [version](../ucndata/version.py) module.
- [Version](#version)
