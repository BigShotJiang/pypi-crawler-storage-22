from udata.core.dataset.permissions import OwnablePermission


class PageEditPermission(OwnablePermission):
    """Permissions to edit a Page"""

    pass
