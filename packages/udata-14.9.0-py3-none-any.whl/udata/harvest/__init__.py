def init_app(app):
    pass
