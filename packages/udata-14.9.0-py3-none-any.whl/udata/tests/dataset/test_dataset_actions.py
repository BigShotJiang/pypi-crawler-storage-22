from udata.core.dataset.actions import archive
from udata.core.dataset.factories import DatasetFactory
from udata.core.discussions.models import Discussion
from udata.core.user.factories import UserFactory
from udata.tests.api import PytestOnlyDBTestCase


class DatasetActionsTest(PytestOnlyDBTestCase):
    def test_dataset_archive(self, app):
        user = UserFactory()
        app.config["ARCHIVE_COMMENT_USER_ID"] = user.id

        dataset = DatasetFactory()

        archive(dataset, comment=True)

        dataset.reload()
        assert dataset.archived is not None
        discussions = Discussion.objects.filter(subject=dataset)
        assert len(discussions) == 1
        assert discussions[0].discussion[0].posted_by == user
