# udsxml2tex

**Convert AUTOSAR DCM/CanTp arxml to LaTeX UDS specification documents**

A Python library that parses AUTOSAR DCM (Diagnostic Communication Manager) and CanTp (CAN Transport Protocol) arxml configuration files and automatically generates ISO 14229 (UDS) / ISO 15765 (UDS on CAN) specification documents in LaTeX format.

## Features

- Automatically extracts UDS specification data from DCM arxml files
  - Diagnostic sessions
  - Security access levels
  - UDS service list (SID, supported sessions, NRCs, etc.)
  - DID (Data Identifier) definitions
  - Routine Control definitions
- Parses CanTp arxml for transport layer configuration
  - Channel parameters (Block Size, STmin, channel mode)
  - ISO 15765-2 timing parameters (N\_As, N\_Bs, N\_Cs, N\_Ar, N\_Br, N\_Cr)
  - Addressing format and padding configuration
- Generates professional LaTeX specification documents
- Customizable via Jinja2 templates
- Available as both a CLI command and a Python API
- Supports merging multiple arxml files (DCM + CanTp)

## Installation

```bash
pip install udsxml2tex
```

From source (for development):

```bash
git clone https://github.com/YutaroNakagama/udsxml2tex.git
cd udsxml2tex
pip install -e ".[dev]"
```

## Usage

### CLI

```bash
# Basic conversion
udsxml2tex input.arxml

# Specify output file
udsxml2tex input.arxml -o output.tex

# Override ECU name
udsxml2tex input.arxml --ecu-name "MyECU"

# Merge and convert multiple files (DCM + CanTp)
udsxml2tex dcm_config.arxml cantp_config.arxml -o merged_spec.tex

# Verbose logging
udsxml2tex input.arxml -v
```

### Python API

```python
from udsxml2tex import ArxmlParser, TexGenerator

# Parse ARXML (DCM + CanTp)
parser = ArxmlParser()
spec = parser.parse("path/to/dcm_config.arxml")

# Or merge multiple files
spec = parser.parse_multi(["dcm_config.arxml", "cantp_config.arxml"])

# Generate LaTeX
generator = TexGenerator()
generator.generate(spec, "output/uds_spec.tex")

# Get as string
tex_content = generator.generate_string(spec)
```

### Custom Templates

You can use your own LaTeX templates:

```python
generator = TexGenerator(template_dir="my_templates/")
generator.generate(spec, "output.tex", template_name="custom.tex.j2")
```

```bash
udsxml2tex input.arxml --template-dir my_templates/ --template custom.tex.j2
```

## Generated Document Structure

1. **Title Page** — ECU name, date
2. **Table of Contents**
3. **Document Overview** — Protocol information, CAN IDs
4. **Transport Layer Configuration (CanTp)** — Channel overview, ISO 15765-2 timing parameters, addressing & padding
5. **Diagnostic Sessions** — Session list (ID, P2/P2* timers)
6. **Security Access** — Security level list
7. **UDS Services** — Service overview + detailed per-service info (including NRCs)
8. **DID Definitions** — DID overview + data element details
9. **Routine Control** — Routine overview + parameter details

## Supported arxml Structure

The following AUTOSAR module configuration elements are parsed:

| Module | Element | Description |
|--------|---------|-------------|
| DCM | `DcmDsl` | Diagnostic Session Layer (protocol, timing) |
| DCM | `DcmDsp` | Diagnostic Service Processing (sessions, security, DIDs, routines) |
| DCM | `DcmDsd` | Diagnostic Service Dispatcher (service table) |
| CanTp | `CanTpGeneral` | Main function period |
| CanTp | `CanTpChannel` | Channel mode, RxNSdu/TxNSdu (BS, STmin, N\_As/N\_Bs/N\_Cs/N\_Ar/N\_Br/N\_Cr, padding, addressing) |

Supports AUTOSAR R4.x arxml format.

## Requirements

- Python >= 3.9
- lxml >= 4.9.0
- Jinja2 >= 3.1.0
- LaTeX distribution (for compiling the generated .tex files)

## License

MIT License