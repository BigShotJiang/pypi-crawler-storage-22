"""Data models for UDS diagnostic specification parsed from ARXML."""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import IntEnum
from typing import Optional


class SessionType(IntEnum):
    """UDS diagnostic session types."""

    DEFAULT = 0x01
    PROGRAMMING = 0x02
    EXTENDED = 0x03


@dataclass
class DiagSession:
    """Diagnostic session definition."""

    short_name: str
    session_id: int
    p2_server_max: float = 0.05  # seconds
    p2_star_server_max: float = 5.0  # seconds

    @property
    def session_id_hex(self) -> str:
        return f"0x{self.session_id:02X}"


@dataclass
class SecurityLevel:
    """Security access level definition."""

    short_name: str
    security_level: int
    num_max_attempts: int = 3

    @property
    def security_level_hex(self) -> str:
        return f"0x{self.security_level:02X}"


@dataclass
class DataElement:
    """A data element within a DID or routine parameter."""

    short_name: str
    byte_position: int = 0
    bit_position: int = 0
    bit_size: int = 8
    description: str = ""
    data_type: str = "uint8"
    min_value: Optional[float] = None
    max_value: Optional[float] = None
    unit: str = ""
    coding: str = ""


@dataclass
class SubFunction:
    """UDS service sub-function definition."""

    short_name: str
    sub_function_id: int
    description: str = ""
    supported_sessions: list[str] = field(default_factory=list)
    required_security_levels: list[str] = field(default_factory=list)

    @property
    def sub_function_id_hex(self) -> str:
        return f"0x{self.sub_function_id:02X}"


@dataclass
class Did:
    """Data Identifier (DID) definition."""

    short_name: str
    did_id: int
    description: str = ""
    data_elements: list[DataElement] = field(default_factory=list)
    read_access: bool = True
    write_access: bool = False
    supported_sessions: list[str] = field(default_factory=list)
    required_security_levels: list[str] = field(default_factory=list)
    total_byte_length: int = 0

    @property
    def did_id_hex(self) -> str:
        return f"0x{self.did_id:04X}"


@dataclass
class RoutineParameter:
    """Parameter for a routine control service."""

    short_name: str
    direction: str = "in"  # "in", "out"
    byte_position: int = 0
    bit_size: int = 8
    description: str = ""
    data_type: str = "uint8"


@dataclass
class Routine:
    """Routine control definition."""

    short_name: str
    routine_id: int
    description: str = ""
    start_supported: bool = True
    stop_supported: bool = False
    result_supported: bool = False
    in_parameters: list[RoutineParameter] = field(default_factory=list)
    out_parameters: list[RoutineParameter] = field(default_factory=list)
    supported_sessions: list[str] = field(default_factory=list)
    required_security_levels: list[str] = field(default_factory=list)

    @property
    def routine_id_hex(self) -> str:
        return f"0x{self.routine_id:04X}"


@dataclass
class NrcEntry:
    """Negative Response Code entry for a service."""

    nrc_code: int
    nrc_name: str
    description: str = ""

    @property
    def nrc_code_hex(self) -> str:
        return f"0x{self.nrc_code:02X}"


# Standard NRC definitions
STANDARD_NRCS: dict[int, str] = {
    0x10: "generalReject",
    0x11: "serviceNotSupported",
    0x12: "subFunctionNotSupported",
    0x13: "incorrectMessageLengthOrInvalidFormat",
    0x14: "responseTooLong",
    0x21: "busyRepeatRequest",
    0x22: "conditionsNotCorrect",
    0x24: "requestSequenceError",
    0x25: "noResponseFromSubnetComponent",
    0x26: "failurePreventsExecutionOfRequestedAction",
    0x31: "requestOutOfRange",
    0x33: "securityAccessDenied",
    0x35: "invalidKey",
    0x36: "exceededNumberOfAttempts",
    0x37: "requiredTimeDelayNotExpired",
    0x70: "uploadDownloadNotAccepted",
    0x71: "transferDataSuspended",
    0x72: "generalProgrammingFailure",
    0x73: "wrongBlockSequenceCounter",
    0x78: "requestCorrectlyReceivedResponsePending",
    0x7E: "subFunctionNotSupportedInActiveSession",
    0x7F: "serviceNotSupportedInActiveSession",
}


@dataclass
class UdsService:
    """UDS diagnostic service definition."""

    short_name: str
    service_id: int
    description: str = ""
    sub_functions: list[SubFunction] = field(default_factory=list)
    supported_sessions: list[str] = field(default_factory=list)
    required_security_levels: list[str] = field(default_factory=list)
    nrc_list: list[NrcEntry] = field(default_factory=list)
    addressing_modes: list[str] = field(default_factory=list)  # physical, functional

    @property
    def service_id_hex(self) -> str:
        return f"0x{self.service_id:02X}"

    @property
    def positive_response_id(self) -> int:
        return self.service_id + 0x40

    @property
    def positive_response_id_hex(self) -> str:
        return f"0x{self.positive_response_id:02X}"


# Standard UDS service names
UDS_SERVICE_NAMES: dict[int, str] = {
    0x10: "DiagnosticSessionControl",
    0x11: "ECUReset",
    0x14: "ClearDiagnosticInformation",
    0x19: "ReadDTCInformation",
    0x22: "ReadDataByIdentifier",
    0x23: "ReadMemoryByAddress",
    0x24: "ReadScalingDataByIdentifier",
    0x27: "SecurityAccess",
    0x28: "CommunicationControl",
    0x2A: "ReadDataByPeriodicIdentifier",
    0x2C: "DynamicallyDefineDataIdentifier",
    0x2E: "WriteDataByIdentifier",
    0x2F: "InputOutputControlByIdentifier",
    0x31: "RoutineControl",
    0x34: "RequestDownload",
    0x35: "RequestUpload",
    0x36: "TransferData",
    0x37: "RequestTransferExit",
    0x3D: "WriteMemoryByAddress",
    0x3E: "TesterPresent",
    0x85: "ControlDTCSetting",
    0x86: "ResponseOnEvent",
    0x87: "LinkControl",
}


@dataclass
class CanTpChannel:
    """CAN Transport Protocol channel configuration (ISO 15765)."""

    short_name: str
    rx_pdu_id: str = ""
    tx_pdu_id: str = ""
    rx_addressing_format: str = "STANDARD"  # STANDARD, EXTENDED, MIXED
    tx_addressing_format: str = "STANDARD"
    bs: int = 0  # Block Size
    stmin: float = 0.0  # Separation Time minimum (ms)
    n_as: float = 0.0  # N_As timeout (s)
    n_bs: float = 0.0  # N_Bs timeout (s)
    n_cs: float = 0.0  # N_Cs timeout (s)
    n_ar: float = 0.0  # N_Ar timeout (s)
    n_br: float = 0.0  # N_Br timeout (s)
    n_cr: float = 0.0  # N_Cr timeout (s)
    padding_activation: bool = True
    padding_byte: int = 0xFF
    channel_mode: str = "FULL_DUPLEX"  # FULL_DUPLEX, HALF_DUPLEX
    max_data_length: int = 8  # 8 for classic CAN, 64 for CAN FD

    @property
    def padding_byte_hex(self) -> str:
        return f"0x{self.padding_byte:02X}"


@dataclass
class CanTpConfig:
    """CAN Transport Protocol configuration parsed from CanTp ARXML."""

    channels: list[CanTpChannel] = field(default_factory=list)
    main_function_period: float = 0.005  # seconds


@dataclass
class UdsSpecification:
    """Complete UDS specification extracted from ARXML."""

    ecu_name: str = "ECU"
    description: str = ""
    sessions: list[DiagSession] = field(default_factory=list)
    security_levels: list[SecurityLevel] = field(default_factory=list)
    services: list[UdsService] = field(default_factory=list)
    dids: list[Did] = field(default_factory=list)
    routines: list[Routine] = field(default_factory=list)
    protocol_name: str = "UDS on CAN"
    can_rx_id: str = ""
    can_tx_id: str = ""
    can_functional_id: str = ""
    transport_config: Optional[CanTpConfig] = None
