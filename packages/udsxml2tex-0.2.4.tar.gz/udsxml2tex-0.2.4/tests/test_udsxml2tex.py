"""Tests for udsxml2tex."""

from pathlib import Path

import pytest

from udsxml2tex import ArxmlParser, CanTpParser, TexGenerator

FIXTURES_DIR = Path(__file__).parent / "fixtures"
SAMPLE_ARXML = FIXTURES_DIR / "sample_dcm.arxml"
SAMPLE_CANTP = FIXTURES_DIR / "sample_cantp.arxml"


class TestArxmlParser:
    """Tests for the ARXML parser."""

    def test_parse_file_not_found(self):
        parser = ArxmlParser()
        with pytest.raises(FileNotFoundError):
            parser.parse("/nonexistent/file.arxml")

    def test_parse_sample(self):
        parser = ArxmlParser()
        spec = parser.parse(SAMPLE_ARXML)

        assert spec is not None
        assert len(spec.sessions) > 0
        assert len(spec.security_levels) > 0
        assert len(spec.services) > 0
        assert len(spec.dids) > 0
        assert len(spec.routines) > 0

    def test_sessions_parsed(self):
        parser = ArxmlParser()
        spec = parser.parse(SAMPLE_ARXML)

        session_names = [s.short_name for s in spec.sessions]
        assert "DefaultSession" in session_names
        assert "ProgrammingSession" in session_names
        assert "ExtendedSession" in session_names

        default = next(s for s in spec.sessions if s.short_name == "DefaultSession")
        assert default.session_id == 1
        assert default.session_id_hex == "0x01"

    def test_security_levels_parsed(self):
        parser = ArxmlParser()
        spec = parser.parse(SAMPLE_ARXML)

        assert len(spec.security_levels) == 2
        level_names = [s.short_name for s in spec.security_levels]
        assert "SecurityLevel_1" in level_names
        assert "SecurityLevel_2" in level_names

        sec1 = next(
            s for s in spec.security_levels if s.short_name == "SecurityLevel_1"
        )
        assert sec1.security_level == 1
        assert sec1.num_max_attempts == 3

    def test_services_parsed(self):
        parser = ArxmlParser()
        spec = parser.parse(SAMPLE_ARXML)

        service_ids = [s.service_id for s in spec.services]
        assert 0x10 in service_ids  # DiagnosticSessionControl
        assert 0x22 in service_ids  # ReadDataByIdentifier
        assert 0x27 in service_ids  # SecurityAccess
        assert 0x3E in service_ids  # TesterPresent
        assert 0x31 in service_ids  # RoutineControl

    def test_service_names_mapped(self):
        parser = ArxmlParser()
        spec = parser.parse(SAMPLE_ARXML)

        session_ctrl = next(s for s in spec.services if s.service_id == 0x10)
        assert session_ctrl.short_name == "DiagnosticSessionControl"
        assert session_ctrl.positive_response_id == 0x50
        assert session_ctrl.positive_response_id_hex == "0x50"

    def test_service_sessions(self):
        parser = ArxmlParser()
        spec = parser.parse(SAMPLE_ARXML)

        tester_present = next(s for s in spec.services if s.service_id == 0x3E)
        assert "DefaultSession" in tester_present.supported_sessions
        assert "ExtendedSession" in tester_present.supported_sessions

    def test_dids_parsed(self):
        parser = ArxmlParser()
        spec = parser.parse(SAMPLE_ARXML)

        assert len(spec.dids) == 2

        vin_did = next(d for d in spec.dids if d.did_id == 0xF190)
        assert vin_did.short_name == "DID_F190_VIN"
        assert vin_did.did_id_hex == "0xF190"
        assert vin_did.read_access is True
        assert "DefaultSession" in vin_did.supported_sessions

        # Check data elements
        assert len(vin_did.data_elements) > 0

    def test_did_write_access(self):
        parser = ArxmlParser()
        spec = parser.parse(SAMPLE_ARXML)

        app_ver = next(d for d in spec.dids if d.did_id == 0xF101)
        assert app_ver.read_access is True
        assert app_ver.write_access is True

    def test_routines_parsed(self):
        parser = ArxmlParser()
        spec = parser.parse(SAMPLE_ARXML)

        assert len(spec.routines) == 1
        routine = spec.routines[0]
        assert routine.routine_id == 0x0203
        assert routine.routine_id_hex == "0x0203"
        assert routine.start_supported is True
        assert routine.result_supported is True
        assert "ExtendedSession" in routine.supported_sessions
        assert "SecurityLevel_1" in routine.required_security_levels

    def test_nrc_list(self):
        parser = ArxmlParser()
        spec = parser.parse(SAMPLE_ARXML)

        security_svc = next(s for s in spec.services if s.service_id == 0x27)
        nrc_codes = [n.nrc_code for n in security_svc.nrc_list]
        # SecurityAccess should have specific NRCs
        assert 0x33 in nrc_codes  # securityAccessDenied
        assert 0x35 in nrc_codes  # invalidKey
        assert 0x36 in nrc_codes  # exceededNumberOfAttempts


class TestTexGenerator:
    """Tests for the LaTeX generator."""

    def test_generate_string(self):
        parser = ArxmlParser()
        spec = parser.parse(SAMPLE_ARXML)

        gen = TexGenerator()
        tex = gen.generate_string(spec)

        assert r"\documentclass" in tex
        assert r"\begin{document}" in tex
        assert r"\end{document}" in tex
        assert "UDS Diagnostic Specification" in tex

    def test_generate_contains_sessions(self):
        parser = ArxmlParser()
        spec = parser.parse(SAMPLE_ARXML)

        gen = TexGenerator()
        tex = gen.generate_string(spec)

        assert "DefaultSession" in tex
        assert "ProgrammingSession" in tex
        assert "ExtendedSession" in tex

    def test_generate_contains_services(self):
        parser = ArxmlParser()
        spec = parser.parse(SAMPLE_ARXML)

        gen = TexGenerator()
        tex = gen.generate_string(spec)

        assert "0x10" in tex
        assert "DiagnosticSessionControl" in tex
        assert "0x22" in tex
        assert "ReadDataByIdentifier" in tex

    def test_generate_contains_dids(self):
        parser = ArxmlParser()
        spec = parser.parse(SAMPLE_ARXML)

        gen = TexGenerator()
        tex = gen.generate_string(spec)

        assert "0xF190" in tex
        assert "DID\\_F190\\_VIN" in tex  # LaTeX escaped underscores

    def test_generate_file(self, tmp_path):
        parser = ArxmlParser()
        spec = parser.parse(SAMPLE_ARXML)

        gen = TexGenerator()
        output = tmp_path / "test_output.tex"
        result = gen.generate(spec, output)

        assert result == output
        assert output.exists()
        content = output.read_text()
        assert r"\documentclass" in content

    def test_ecu_name_override(self):
        parser = ArxmlParser()
        spec = parser.parse(SAMPLE_ARXML)
        spec.ecu_name = "TestECU"

        gen = TexGenerator()
        tex = gen.generate_string(spec)

        assert "TestECU" in tex

    def test_latex_escape(self):
        from udsxml2tex.generator import _latex_escape

        assert _latex_escape("a&b") == r"a\&b"
        assert _latex_escape("100%") == r"100\%"
        assert _latex_escape("a_b") == r"a\_b"
        assert _latex_escape("a#b") == r"a\#b"
        assert _latex_escape("") == ""


class TestCli:
    """Tests for the CLI interface."""

    def test_cli_help(self):
        from udsxml2tex.cli import _build_parser

        parser = _build_parser()
        assert parser.prog == "udsxml2tex"

    def test_cli_main_success(self, tmp_path):
        from udsxml2tex.cli import main

        output = tmp_path / "output.tex"
        rc = main([str(SAMPLE_ARXML), "-o", str(output)])
        assert rc == 0
        assert output.exists()

    def test_cli_main_file_not_found(self):
        from udsxml2tex.cli import main

        rc = main(["/nonexistent/file.arxml"])
        assert rc == 1

    def test_cli_ecu_name(self, tmp_path):
        from udsxml2tex.cli import main

        output = tmp_path / "output.tex"
        rc = main([str(SAMPLE_ARXML), "-o", str(output), "--ecu-name", "MyECU"])
        assert rc == 0

        content = output.read_text()
        assert "MyECU" in content


class TestCanTpParser:
    """Tests for the CanTp ARXML parser."""

    def test_parse_file_not_found(self):
        parser = CanTpParser()
        with pytest.raises(FileNotFoundError):
            parser.parse("/nonexistent/file.arxml")

    def test_parse_sample(self):
        parser = CanTpParser()
        config = parser.parse(SAMPLE_CANTP)

        assert config is not None
        assert len(config.channels) > 0

    def test_main_function_period(self):
        parser = CanTpParser()
        config = parser.parse(SAMPLE_CANTP)

        assert config.main_function_period == 0.01

    def test_channel_count(self):
        parser = CanTpParser()
        config = parser.parse(SAMPLE_CANTP)

        # Physical channel (1 Rx+Tx pair) + Functional channel (1 Rx only)
        assert len(config.channels) == 2

    def test_physical_channel(self):
        parser = CanTpParser()
        config = parser.parse(SAMPLE_CANTP)

        # Find the physical channel (has CanTpRxNSdu_Phys in name)
        phys = next(
            (ch for ch in config.channels if "Phys" in ch.short_name), None
        )
        assert phys is not None
        assert phys.bs == 8
        assert phys.stmin == 10.0
        assert phys.n_ar == 1.0
        assert phys.n_br == 0.9
        assert phys.n_cr == 1.0
        assert phys.padding_byte == 0xAA
        assert phys.padding_activation is True
        assert phys.rx_addressing_format == "STANDARD"
        assert phys.max_data_length == 8
        assert phys.channel_mode == "FULL_DUPLEX"

    def test_physical_channel_tx(self):
        parser = CanTpParser()
        config = parser.parse(SAMPLE_CANTP)

        phys = next(
            (ch for ch in config.channels if "Phys" in ch.short_name), None
        )
        assert phys is not None
        assert phys.n_as == 1.0
        assert phys.n_bs == 1.0
        assert phys.n_cs == 0.5
        assert phys.tx_addressing_format == "STANDARD"
        assert phys.tx_pdu_id == "DiagPhysTxPdu"

    def test_functional_channel(self):
        parser = CanTpParser()
        config = parser.parse(SAMPLE_CANTP)

        func = next(
            (ch for ch in config.channels if "Func" in ch.short_name), None
        )
        assert func is not None
        assert func.bs == 0
        assert func.stmin == 0.0
        assert func.rx_addressing_format == "EXTENDED"
        assert func.max_data_length == 64
        assert func.channel_mode == "HALF_DUPLEX"
        assert func.padding_byte == 0xFF

    def test_rx_pdu_ref(self):
        parser = CanTpParser()
        config = parser.parse(SAMPLE_CANTP)

        phys = next(
            (ch for ch in config.channels if "Phys" in ch.short_name), None
        )
        assert phys is not None
        assert phys.rx_pdu_id == "DiagPhysRxPdu"

    def test_padding_byte_hex(self):
        parser = CanTpParser()
        config = parser.parse(SAMPLE_CANTP)

        phys = next(
            (ch for ch in config.channels if "Phys" in ch.short_name), None
        )
        assert phys is not None
        assert phys.padding_byte_hex == "0xAA"


class TestCanTpIntegration:
    """Integration tests for CanTp with ArxmlParser and TexGenerator."""

    def test_arxml_parser_detects_cantp(self):
        """ArxmlParser should detect CanTp in a CanTp-only file."""
        parser = ArxmlParser()
        spec = parser.parse(SAMPLE_CANTP)

        assert spec.transport_config is not None
        assert len(spec.transport_config.channels) == 2

    def test_parse_multi_dcm_and_cantp(self):
        """parse_multi should merge DCM and CanTp from separate files."""
        parser = ArxmlParser()
        spec = parser.parse_multi([SAMPLE_ARXML, SAMPLE_CANTP])

        # DCM data present
        assert len(spec.sessions) > 0
        assert len(spec.services) > 0
        assert len(spec.dids) > 0

        # CanTp data merged
        assert spec.transport_config is not None
        assert len(spec.transport_config.channels) == 2

    def test_tex_with_cantp(self):
        """Generator should include transport layer section."""
        parser = ArxmlParser()
        spec = parser.parse_multi([SAMPLE_ARXML, SAMPLE_CANTP])

        gen = TexGenerator()
        tex = gen.generate_string(spec)

        assert "Transport Layer Configuration" in tex
        assert "FULL\\_DUPLEX" in tex or "FULL_DUPLEX" in tex
        assert "0xAA" in tex

    def test_tex_without_cantp(self):
        """Generator without CanTp should show 'No CAN Transport' message."""
        parser = ArxmlParser()
        spec = parser.parse(SAMPLE_ARXML)

        # DCM-only file should have no transport config
        assert spec.transport_config is None

        gen = TexGenerator()
        tex = gen.generate_string(spec)

        assert "No CAN Transport Protocol configuration found" in tex

    def test_generate_file_with_cantp(self, tmp_path):
        """Full pipeline: DCM + CanTp -> .tex file."""
        parser = ArxmlParser()
        spec = parser.parse_multi([SAMPLE_ARXML, SAMPLE_CANTP])
        spec.ecu_name = "TestECU"

        gen = TexGenerator()
        output = tmp_path / "cantp_test.tex"
        result = gen.generate(spec, output)

        assert result == output
        assert output.exists()
        content = output.read_text()
        assert "Transport Layer" in content
        assert "TestECU" in content

    def test_cli_multi_file(self, tmp_path):
        """CLI should handle DCM + CanTp files."""
        from udsxml2tex.cli import main

        output = tmp_path / "multi.tex"
        rc = main([str(SAMPLE_ARXML), str(SAMPLE_CANTP), "-o", str(output)])
        assert rc == 0
        assert output.exists()
        content = output.read_text()
        assert "Transport Layer" in content
