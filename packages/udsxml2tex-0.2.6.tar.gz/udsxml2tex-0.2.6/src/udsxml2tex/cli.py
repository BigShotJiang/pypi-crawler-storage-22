"""Command-line interface for udsxml2tex."""

from __future__ import annotations

import argparse
import logging
import sys
from pathlib import Path

from udsxml2tex.generator import TexGenerator
from udsxml2tex.parser import ArxmlParser


def _build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="udsxml2tex",
        description="Convert AUTOSAR DCM/CanTp arxml to LaTeX UDS specification documents.",
    )
    parser.add_argument(
        "input",
        nargs="+",
        help="Input ARXML file(s). Multiple files will be merged.",
    )
    parser.add_argument(
        "-o",
        "--output",
        default=None,
        help="Output .tex file path. Default: <input_stem>_uds_spec.tex",
    )
    parser.add_argument(
        "--ecu-name",
        default=None,
        help="Override ECU name in the generated document.",
    )
    parser.add_argument(
        "--template-dir",
        default=None,
        help="Directory containing custom Jinja2 LaTeX templates.",
    )
    parser.add_argument(
        "--template",
        default="uds_spec.tex.j2",
        help="Template file name (default: uds_spec.tex.j2).",
    )
    parser.add_argument(
        "-v",
        "--verbose",
        action="store_true",
        help="Enable verbose logging output.",
    )
    parser.add_argument(
        "--version",
        action="version",
        version="%(prog)s 0.2.4",
    )
    return parser


def main(argv: list[str] | None = None) -> int:
    """Main entry point for the CLI.

    Args:
        argv: Command-line arguments. Defaults to sys.argv[1:].

    Returns:
        Exit code (0 for success).
    """
    parser = _build_parser()
    args = parser.parse_args(argv)

    # Configure logging
    level = logging.DEBUG if args.verbose else logging.INFO
    logging.basicConfig(
        level=level,
        format="%(levelname)s: %(message)s",
    )

    # Validate input files
    input_paths = [Path(p) for p in args.input]
    for p in input_paths:
        if not p.exists():
            logging.error("Input file not found: %s", p)
            return 1
        if not p.suffix.lower() == ".arxml":
            logging.warning(
                "File does not have .arxml extension: %s", p
            )

    # Determine output path
    if args.output:
        output_path = Path(args.output)
    else:
        stem = input_paths[0].stem
        output_path = input_paths[0].parent / f"{stem}_uds_spec.tex"

    # Parse ARXML
    arxml_parser = ArxmlParser()
    try:
        if len(input_paths) == 1:
            spec = arxml_parser.parse(input_paths[0])
        else:
            spec = arxml_parser.parse_multi(input_paths)
    except Exception as e:
        logging.error("Failed to parse ARXML: %s", e)
        return 1

    # Override ECU name if specified
    if args.ecu_name:
        spec.ecu_name = args.ecu_name

    # Generate LaTeX
    try:
        tex_gen = TexGenerator(template_dir=args.template_dir)
        result = tex_gen.generate(
            spec, output_path, template_name=args.template
        )
        logging.info("Output written to: %s", result)
    except Exception as e:
        logging.error("Failed to generate LaTeX: %s", e)
        return 1

    return 0


if __name__ == "__main__":
    sys.exit(main())
