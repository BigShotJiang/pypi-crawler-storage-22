"""Data models for UDS specification parsed from ARXML."""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import IntEnum
from typing import Optional


class SessionType(IntEnum):
    """UDS diagnostic session types."""

    DEFAULT = 0x01
    PROGRAMMING = 0x02
    EXTENDED = 0x03


@dataclass
class DiagSession:
    """Diagnostic session definition."""

    short_name: str
    session_id: int
    p2_server_max: float = 0.05  # seconds
    p2_star_server_max: float = 5.0  # seconds

    @property
    def session_id_hex(self) -> str:
        return f"0x{self.session_id:02X}"


@dataclass
class SecurityLevel:
    """Security access level definition."""

    short_name: str
    security_level: int
    num_max_attempts: int = 3

    @property
    def security_level_hex(self) -> str:
        return f"0x{self.security_level:02X}"


@dataclass
class DataElement:
    """A data element within a DID or routine parameter."""

    short_name: str
    byte_position: int = 0
    bit_position: int = 0
    bit_size: int = 8
    description: str = ""
    data_type: str = "uint8"
    min_value: Optional[float] = None
    max_value: Optional[float] = None
    unit: str = ""
    coding: str = ""


@dataclass
class SubFunction:
    """UDS service sub-function definition."""

    short_name: str
    sub_function_id: int
    description: str = ""
    supported_sessions: list[str] = field(default_factory=list)
    required_security_levels: list[str] = field(default_factory=list)

    @property
    def sub_function_id_hex(self) -> str:
        return f"0x{self.sub_function_id:02X}"


@dataclass
class Did:
    """Data Identifier (DID) definition."""

    short_name: str
    did_id: int
    description: str = ""
    data_elements: list[DataElement] = field(default_factory=list)
    read_access: bool = True
    write_access: bool = False
    supported_sessions: list[str] = field(default_factory=list)
    required_security_levels: list[str] = field(default_factory=list)
    total_byte_length: int = 0

    @property
    def did_id_hex(self) -> str:
        return f"0x{self.did_id:04X}"


@dataclass
class RoutineParameter:
    """Parameter for a routine control service."""

    short_name: str
    direction: str = "in"  # "in", "out"
    byte_position: int = 0
    bit_size: int = 8
    description: str = ""
    data_type: str = "uint8"


@dataclass
class Routine:
    """Routine control definition."""

    short_name: str
    routine_id: int
    description: str = ""
    start_supported: bool = True
    stop_supported: bool = False
    result_supported: bool = False
    in_parameters: list[RoutineParameter] = field(default_factory=list)
    out_parameters: list[RoutineParameter] = field(default_factory=list)
    supported_sessions: list[str] = field(default_factory=list)
    required_security_levels: list[str] = field(default_factory=list)

    @property
    def routine_id_hex(self) -> str:
        return f"0x{self.routine_id:04X}"


@dataclass
class NrcEntry:
    """Negative Response Code entry for a service."""

    nrc_code: int
    nrc_name: str
    description: str = ""

    @property
    def nrc_code_hex(self) -> str:
        return f"0x{self.nrc_code:02X}"


# Standard NRC definitions
STANDARD_NRCS: dict[int, str] = {
    0x10: "generalReject",
    0x11: "serviceNotSupported",
    0x12: "subFunctionNotSupported",
    0x13: "incorrectMessageLengthOrInvalidFormat",
    0x14: "responseTooLong",
    0x21: "busyRepeatRequest",
    0x22: "conditionsNotCorrect",
    0x24: "requestSequenceError",
    0x25: "noResponseFromSubnetComponent",
    0x26: "failurePreventsExecutionOfRequestedAction",
    0x31: "requestOutOfRange",
    0x33: "securityAccessDenied",
    0x35: "invalidKey",
    0x36: "exceededNumberOfAttempts",
    0x37: "requiredTimeDelayNotExpired",
    0x70: "uploadDownloadNotAccepted",
    0x71: "transferDataSuspended",
    0x72: "generalProgrammingFailure",
    0x73: "wrongBlockSequenceCounter",
    0x78: "requestCorrectlyReceivedResponsePending",
    0x7E: "subFunctionNotSupportedInActiveSession",
    0x7F: "serviceNotSupportedInActiveSession",
}


@dataclass
class UdsService:
    """UDS diagnostic service definition."""

    short_name: str
    service_id: int
    description: str = ""
    sub_functions: list[SubFunction] = field(default_factory=list)
    supported_sessions: list[str] = field(default_factory=list)
    required_security_levels: list[str] = field(default_factory=list)
    nrc_list: list[NrcEntry] = field(default_factory=list)
    addressing_modes: list[str] = field(default_factory=list)  # physical, functional

    @property
    def service_id_hex(self) -> str:
        return f"0x{self.service_id:02X}"

    @property
    def positive_response_id(self) -> int:
        return self.service_id + 0x40

    @property
    def positive_response_id_hex(self) -> str:
        return f"0x{self.positive_response_id:02X}"


# Standard UDS service names
UDS_SERVICE_NAMES: dict[int, str] = {
    0x10: "DiagnosticSessionControl",
    0x11: "ECUReset",
    0x14: "ClearDiagnosticInformation",
    0x19: "ReadDTCInformation",
    0x22: "ReadDataByIdentifier",
    0x23: "ReadMemoryByAddress",
    0x24: "ReadScalingDataByIdentifier",
    0x27: "SecurityAccess",
    0x28: "CommunicationControl",
    0x29: "Authentication",
    0x2A: "ReadDataByPeriodicIdentifier",
    0x2C: "DynamicallyDefineDataIdentifier",
    0x2E: "WriteDataByIdentifier",
    0x2F: "InputOutputControlByIdentifier",
    0x31: "RoutineControl",
    0x34: "RequestDownload",
    0x35: "RequestUpload",
    0x36: "TransferData",
    0x37: "RequestTransferExit",
    0x3D: "WriteMemoryByAddress",
    0x3E: "TesterPresent",
    0x85: "ControlDTCSetting",
    0x86: "ResponseOnEvent",
    0x87: "LinkControl",
}

# ISO 14229-1 section order for UDS services
# Maps SID to its section order in the standard
ISO14229_SERVICE_ORDER: dict[int, int] = {
    0x10: 1,   # DiagnosticSessionControl (§9.2)
    0x11: 2,   # ECUReset (§9.3)
    0x27: 3,   # SecurityAccess (§9.4)
    0x28: 4,   # CommunicationControl (§9.5)
    0x29: 5,   # Authentication (§9.6)
    0x3E: 6,   # TesterPresent (§9.7)
    0x85: 7,   # ControlDTCSetting (§9.8)
    0x86: 8,   # ResponseOnEvent (§9.9)
    0x87: 9,   # LinkControl (§9.10)
    0x22: 10,  # ReadDataByIdentifier (§10.2)
    0x23: 11,  # ReadMemoryByAddress (§10.3)
    0x24: 12,  # ReadScalingDataByIdentifier (§10.4)
    0x2A: 13,  # ReadDataByPeriodicIdentifier (§10.5)
    0x2C: 14,  # DynamicallyDefineDataIdentifier (§10.6)
    0x2E: 15,  # WriteDataByIdentifier (§10.7)
    0x3D: 16,  # WriteMemoryByAddress (§10.8)
    0x14: 17,  # ClearDiagnosticInformation (§11.2)
    0x19: 18,  # ReadDTCInformation (§11.3)
    0x2F: 19,  # InputOutputControlByIdentifier (§12.2)
    0x31: 20,  # RoutineControl (§12.3)
    0x34: 21,  # RequestDownload (§13.2)
    0x35: 22,  # RequestUpload (§13.3)
    0x36: 23,  # TransferData (§13.4)
    0x37: 24,  # RequestTransferExit (§13.5)
    0x38: 25,  # RequestFileTransfer (§13.6)
    0x84: 26,  # SecuredDataTransmission (§14.2)
}


# Standard sub-function definitions per ISO 14229-1
# Maps SID -> list of (sub_function_id, short_name)
STANDARD_SUB_FUNCTIONS: dict[int, list[tuple[int, str]]] = {
    # DiagnosticSessionControl (§9.2)
    0x10: [
        (0x01, "defaultSession"),
        (0x02, "programmingSession"),
        (0x03, "extendedDiagnosticSession"),
    ],
    # ECUReset (§9.3)
    0x11: [
        (0x01, "hardReset"),
        (0x02, "keyOffOnReset"),
        (0x03, "softReset"),
    ],
    # ReadDTCInformation (§11.3)
    0x19: [
        (0x01, "reportNumberOfDTCByStatusMask"),
        (0x02, "reportDTCByStatusMask"),
        (0x04, "reportDTCSnapshotRecordByDTCNumber"),
        (0x06, "reportDTCExtDataRecordByDTCNumber"),
        (0x0A, "reportSupportedDTC"),
        (0x14, "reportDTCFaultDetectionCounter"),
        (0x15, "reportDTCWithPermanentStatus"),
    ],
    # SecurityAccess (§9.4) — odd = requestSeed, even = sendKey
    0x27: [
        (0x01, "requestSeed (Level 1)"),
        (0x02, "sendKey (Level 1)"),
        (0x03, "requestSeed (Level 2)"),
        (0x04, "sendKey (Level 2)"),
    ],
    # CommunicationControl (§9.5)
    0x28: [
        (0x00, "enableRxAndTx"),
        (0x01, "enableRxAndDisableTx"),
        (0x02, "disableRxAndEnableTx"),
        (0x03, "disableRxAndTx"),
    ],
    # Authentication (§9.6)
    0x29: [
        (0x00, "deAuthenticate"),
        (0x01, "verifyCertificateUnidirectional"),
        (0x02, "verifyCertificateBidirectional"),
        (0x03, "proofOfOwnership"),
        (0x04, "transmitCertificate"),
        (0x05, "requestChallengeForAuthentication"),
        (0x06, "verifyProofOfOwnershipUnidirectional"),
        (0x07, "verifyProofOfOwnershipBidirectional"),
        (0x08, "authenticationConfiguration"),
    ],
    # RoutineControl (§12.3)
    0x31: [
        (0x01, "startRoutine"),
        (0x02, "stopRoutine"),
        (0x03, "requestRoutineResults"),
    ],
    # TesterPresent (§9.7)
    0x3E: [
        (0x00, "zeroSubFunction"),
    ],
    # ControlDTCSetting (§9.8)
    0x85: [
        (0x01, "on"),
        (0x02, "off"),
    ],
}


# UDS Request / Positive-Response message-format definitions per ISO 14229-1
# Maps SID -> (request_rows, response_rows)
# Each row: (byte_position, parameter_name, display_value, is_fixed_hex)
#   is_fixed_hex=True  -> render with \hexval (subscript-16)
#   is_fixed_hex=False -> render with \texttt (variable content)
UDS_MESSAGE_FORMATS: dict[int, tuple[list[tuple[str, str, str, bool]],
                                      list[tuple[str, str, str, bool]]]] = {
    # ---- DiagnosticSessionControl (§9.2) ----
    0x10: (
        [("#1", "Service ID (SID)", "10", True),
         ("#2", "sub-function = sessionType", "xx", False)],
        [("#1", "Response SID", "50", True),
         ("#2", "sub-function = sessionType", "xx", False),
         ("#3--#4", "P2ServerMax (high byte, low byte)", "xx xx", False),
         ("#5--#6", "P2*ServerMax / 10 (high byte, low byte)", "xx xx", False)],
    ),
    # ---- ECUReset (§9.3) ----
    0x11: (
        [("#1", "Service ID (SID)", "11", True),
         ("#2", "sub-function = resetType", "xx", False)],
        [("#1", "Response SID", "51", True),
         ("#2", "sub-function = resetType", "xx", False),
         ("#3", "powerDownTime", "xx", False)],
    ),
    # ---- ClearDiagnosticInformation (§11.2) ----
    0x14: (
        [("#1", "Service ID (SID)", "14", True),
         ("#2--#4", "groupOfDTC[]", "xx xx xx", False)],
        [("#1", "Response SID", "54", True)],
    ),
    # ---- ReadDTCInformation (§11.3) ----
    0x19: (
        [("#1", "Service ID (SID)", "19", True),
         ("#2", "sub-function = reportType", "xx", False),
         ("#3--#N", "DTC status mask / DTC number (report-type dependent)", "...", False)],
        [("#1", "Response SID", "59", True),
         ("#2", "sub-function = reportType", "xx", False),
         ("#3--#N", "data[] (report-type dependent)", "...", False)],
    ),
    # ---- ReadDataByIdentifier (§10.2) ----
    0x22: (
        [("#1", "Service ID (SID)", "22", True),
         ("#2--#3", "dataIdentifier[] (1st DID)", "xx xx", False),
         ("#4--#N", "dataIdentifier[] (additional DIDs, optional)", "...", False)],
        [("#1", "Response SID", "62", True),
         ("#2--#3", "dataIdentifier[]", "xx xx", False),
         ("#4--#N", "dataRecord[]", "...", False)],
    ),
    # ---- SecurityAccess (§9.4) ----
    0x27: (
        [("#1", "Service ID (SID)", "27", True),
         ("#2", "sub-function = securityAccessType", "xx", False),
         ("#3--#N", "securityAccessDataRecord / securityKey", "...", False)],
        [("#1", "Response SID", "67", True),
         ("#2", "sub-function = securityAccessType", "xx", False),
         ("#3--#N", "securitySeed (requestSeed response only)", "...", False)],
    ),
    # ---- Authentication (§9.6) ----
    0x29: (
        [("#1", "Service ID (SID)", "29", True),
         ("#2", "sub-function = authenticationTask", "xx", False),
         ("#3--#N", "authenticationParameter[]", "...", False)],
        [("#1", "Response SID", "69", True),
         ("#2", "sub-function = authenticationTask", "xx", False),
         ("#3", "authenticationReturnParameter", "xx", False),
         ("#4--#N", "authenticationParameter[]", "...", False)],
    ),
    # ---- WriteDataByIdentifier (§10.7) ----
    0x2E: (
        [("#1", "Service ID (SID)", "2E", True),
         ("#2--#3", "dataIdentifier[]", "xx xx", False),
         ("#4--#N", "dataRecord[]", "...", False)],
        [("#1", "Response SID", "6E", True),
         ("#2--#3", "dataIdentifier[]", "xx xx", False)],
    ),
    # ---- RoutineControl (§12.3) ----
    0x31: (
        [("#1", "Service ID (SID)", "31", True),
         ("#2", "sub-function = routineControlType", "xx", False),
         ("#3--#4", "routineIdentifier[]", "xx xx", False),
         ("#5--#N", "routineOptionRecord[]", "...", False)],
        [("#1", "Response SID", "71", True),
         ("#2", "sub-function = routineControlType", "xx", False),
         ("#3--#4", "routineIdentifier[]", "xx xx", False),
         ("#5--#N", "routineStatusRecord[]", "...", False)],
    ),
    # ---- RequestDownload (§13.2) ----
    0x34: (
        [("#1", "Service ID (SID)", "34", True),
         ("#2", "dataFormatIdentifier", "xx", False),
         ("#3", "addressAndLengthFormatIdentifier", "xx", False),
         ("#4--#m", "memoryAddress[]", "...", False),
         ("#(m+1)--#n", "memorySize[]", "...", False)],
        [("#1", "Response SID", "74", True),
         ("#2", "lengthFormatIdentifier", "xx", False),
         ("#3--#N", "maxNumberOfBlockLength", "...", False)],
    ),
    # ---- TransferData (§13.4) ----
    0x36: (
        [("#1", "Service ID (SID)", "36", True),
         ("#2", "blockSequenceCounter", "xx", False),
         ("#3--#N", "transferRequestParameterRecord[]", "...", False)],
        [("#1", "Response SID", "76", True),
         ("#2", "blockSequenceCounter", "xx", False),
         ("#3--#N", "transferResponseParameterRecord[]", "...", False)],
    ),
    # ---- RequestTransferExit (§13.5) ----
    0x37: (
        [("#1", "Service ID (SID)", "37", True),
         ("#2--#N", "transferRequestParameterRecord[]", "...", False)],
        [("#1", "Response SID", "77", True),
         ("#2--#N", "transferResponseParameterRecord[]", "...", False)],
    ),
    # ---- TesterPresent (§9.7) ----
    0x3E: (
        [("#1", "Service ID (SID)", "3E", True),
         ("#2", "sub-function", "xx", False)],
        [("#1", "Response SID", "7E", True),
         ("#2", "sub-function", "xx", False)],
    ),
}


@dataclass
class CanTpChannel:
    """CAN Transport Protocol channel configuration (ISO 15765)."""

    short_name: str
    rx_pdu_id: str = ""
    tx_pdu_id: str = ""
    rx_addressing_format: str = "STANDARD"  # STANDARD, EXTENDED, MIXED
    tx_addressing_format: str = "STANDARD"
    bs: int = 0  # Block Size
    stmin: float = 0.0  # Separation Time minimum (ms)
    n_as: float = 0.0  # N_As timeout (s)
    n_bs: float = 0.0  # N_Bs timeout (s)
    n_cs: float = 0.0  # N_Cs timeout (s)
    n_ar: float = 0.0  # N_Ar timeout (s)
    n_br: float = 0.0  # N_Br timeout (s)
    n_cr: float = 0.0  # N_Cr timeout (s)
    padding_activation: bool = True
    padding_byte: int = 0xFF
    channel_mode: str = "FULL_DUPLEX"  # FULL_DUPLEX, HALF_DUPLEX
    max_data_length: int = 8  # 8 for classic CAN, 64 for CAN FD

    @property
    def padding_byte_hex(self) -> str:
        return f"0x{self.padding_byte:02X}"


@dataclass
class CanTpConfig:
    """CAN Transport Protocol configuration parsed from CanTp ARXML."""

    channels: list[CanTpChannel] = field(default_factory=list)
    main_function_period: float = 0.005  # seconds


@dataclass
class UdsSpecification:
    """Complete UDS specification extracted from ARXML."""

    ecu_name: str = "ECU"
    description: str = ""
    sessions: list[DiagSession] = field(default_factory=list)
    security_levels: list[SecurityLevel] = field(default_factory=list)
    services: list[UdsService] = field(default_factory=list)
    dids: list[Did] = field(default_factory=list)
    routines: list[Routine] = field(default_factory=list)
    protocol_name: str = "UDS on CAN"
    can_rx_id: str = ""
    can_tx_id: str = ""
    can_functional_id: str = ""
    transport_config: Optional[CanTpConfig] = None
