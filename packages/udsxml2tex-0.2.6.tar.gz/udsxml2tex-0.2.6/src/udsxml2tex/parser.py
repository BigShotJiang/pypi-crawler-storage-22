"""ARXML parser for AUTOSAR DCM/CanTp module configuration."""

from __future__ import annotations

import logging
import re
from pathlib import Path
from typing import Optional

from lxml import etree

from udsxml2tex.models import (
    STANDARD_NRCS,
    UDS_SERVICE_NAMES,
    DataElement,
    DiagSession,
    Did,
    NrcEntry,
    Routine,
    RoutineParameter,
    STANDARD_SUB_FUNCTIONS,
    SecurityLevel,
    SubFunction,
    UdsService,
    UdsSpecification,
)

logger = logging.getLogger(__name__)

# Common AUTOSAR namespaces
AR_NAMESPACES = {
    "ar": "http://autosar.org/schema/r4.0",
    "ar3": "http://autosar.org/3.0.2",
    "xsi": "http://www.w3.org/2001/XMLSchema-instance",
}


def _detect_namespace(root: etree._Element) -> dict[str, str]:
    """Detect the AUTOSAR namespace from the root element."""
    ns = root.nsmap
    # Try to find the AUTOSAR namespace
    for prefix, uri in ns.items():
        if "autosar.org" in uri:
            return {"ar": uri}
    # Check if there's a default namespace
    if None in ns and "autosar.org" in ns[None]:
        return {"ar": ns[None]}
    # Fallback: try without namespace
    return {}


def _xpath(element: etree._Element, path: str, ns: dict[str, str]) -> list:
    """Execute XPath query with namespace handling."""
    if ns:
        return element.xpath(path, namespaces=ns)
    # Fallback: try without namespace prefix
    clean_path = re.sub(r"ar:", "", path)
    return element.xpath(clean_path)


def _xpath_text(
    element: etree._Element, path: str, ns: dict[str, str], default: str = ""
) -> str:
    """Get text content from XPath query."""
    results = _xpath(element, path, ns)
    if results:
        if isinstance(results[0], etree._Element):
            return results[0].text or default
        return str(results[0]) or default
    return default


def _xpath_int(
    element: etree._Element, path: str, ns: dict[str, str], default: int = 0
) -> int:
    """Get integer value from XPath query."""
    text = _xpath_text(element, path, ns)
    if not text:
        return default
    try:
        if text.startswith("0x") or text.startswith("0X"):
            return int(text, 16)
        return int(text)
    except ValueError:
        return default


def _xpath_float(
    element: etree._Element, path: str, ns: dict[str, str], default: float = 0.0
) -> float:
    """Get float value from XPath query."""
    text = _xpath_text(element, path, ns)
    if not text:
        return default
    try:
        return float(text)
    except ValueError:
        return default


class ArxmlParser:
    """Parser for AUTOSAR DCM/CanTp ARXML files."""

    def __init__(self) -> None:
        self.ns: dict[str, str] = {}
        self.tree: Optional[etree._ElementTree] = None
        self.root: Optional[etree._Element] = None

    def parse(self, arxml_path: str | Path) -> UdsSpecification:
        """Parse an ARXML file and return a UDS specification.

        Args:
            arxml_path: Path to the ARXML file.

        Returns:
            UdsSpecification with all parsed data.
        """
        arxml_path = Path(arxml_path)
        if not arxml_path.exists():
            raise FileNotFoundError(f"ARXML file not found: {arxml_path}")

        logger.info("Parsing ARXML file: %s", arxml_path)

        parser = etree.XMLParser(remove_blank_text=True, remove_comments=True)
        self.tree = etree.parse(str(arxml_path), parser)
        self.root = self.tree.getroot()
        self.ns = _detect_namespace(self.root)

        spec = UdsSpecification()

        # Parse ECU name from module configuration
        self._parse_ecu_info(spec)

        # Parse DSL (Diagnostic Session Layer) - protocol, timing
        self._parse_dsl(spec)

        # Parse DSP (Diagnostic Service Processing) - sessions, security, DIDs, routines
        self._parse_sessions(spec)
        self._parse_security(spec)
        self._parse_dids(spec)
        self._parse_routines(spec)

        # Parse DSD (Diagnostic Service Dispatcher) - service table
        self._parse_services(spec)

        # Try to parse CanTp configuration from the same file
        self._parse_cantp(spec, arxml_path)

        logger.info(
            "Parsed: %d sessions, %d security levels, %d services, %d DIDs, %d routines",
            len(spec.sessions),
            len(spec.security_levels),
            len(spec.services),
            len(spec.dids),
            len(spec.routines),
        )

        return spec

    def parse_multi(self, arxml_paths: list[str | Path]) -> UdsSpecification:
        """Parse multiple ARXML files and merge results.

        Args:
            arxml_paths: List of paths to ARXML files.

        Returns:
            Merged UdsSpecification.
        """
        specs = [self.parse(p) for p in arxml_paths]
        if not specs:
            return UdsSpecification()

        merged = specs[0]
        for s in specs[1:]:
            merged.sessions.extend(s.sessions)
            merged.security_levels.extend(s.security_levels)
            merged.services.extend(s.services)
            merged.dids.extend(s.dids)
            merged.routines.extend(s.routines)
            # Merge transport config
            if s.transport_config is not None:
                if merged.transport_config is None:
                    merged.transport_config = s.transport_config
                else:
                    merged.transport_config.channels.extend(
                        s.transport_config.channels
                    )

        return merged

    def _parse_ecu_info(self, spec: UdsSpecification) -> None:
        """Extract ECU name from module configuration."""
        assert self.root is not None

        # Try to find ECU-INSTANCE or MODULE-CONFIGURATION short name
        for path in [
            ".//ar:ECU-INSTANCE/ar:SHORT-NAME",
            ".//ar:ECUC-MODULE-CONFIGURATION-VALUES/ar:SHORT-NAME",
            ".//ar:ECUC-VALUE-COLLECTION/ar:SHORT-NAME",
            ".//ar:MODULE-CONFIGURATION/ar:SHORT-NAME",
        ]:
            name = _xpath_text(self.root, path, self.ns)
            if name:
                # Clean up "Dcm" prefix if present
                spec.ecu_name = name.replace("Dcm", "").strip("_") or name
                return

        # Try from SHORT-NAME of top-level AR-PACKAGE
        name = _xpath_text(self.root, ".//ar:AR-PACKAGE/ar:SHORT-NAME", self.ns)
        if name:
            spec.ecu_name = name

    def _parse_cantp(self, spec: UdsSpecification, arxml_path: Path) -> None:
        """Try to parse CanTp configuration from the ARXML file."""
        assert self.root is not None

        # Check if this file contains CanTp module configuration
        cantp_indicators = [
            ".//ar:ECUC-MODULE-CONFIGURATION-VALUES[ar:SHORT-NAME='CanTp']",
            ".//ar:ECUC-MODULE-CONFIGURATION-VALUES[contains(ar:SHORT-NAME/text(), 'CanTp')]",
            ".//ar:ECUC-CONTAINER-VALUE[contains(ar:SHORT-NAME/text(), 'CanTpChannel')]",
            ".//ar:ECUC-CONTAINER-VALUE[contains(ar:SHORT-NAME/text(), 'CanTpRxNSdu')]",
        ]
        has_cantp = False
        for path in cantp_indicators:
            if _xpath(self.root, path, self.ns):
                has_cantp = True
                break

        if has_cantp:
            try:
                from udsxml2tex.cantp_parser import CanTpParser

                cantp_parser = CanTpParser()
                config = cantp_parser.parse(arxml_path)
                if config.channels:
                    spec.transport_config = config
                    logger.info(
                        "CanTp: %d transport channels parsed",
                        len(config.channels),
                    )
            except Exception as e:
                logger.warning("Failed to parse CanTp config: %s", e)

    def _parse_dsl(self, spec: UdsSpecification) -> None:
        """Parse Diagnostic Session Layer configuration."""
        assert self.root is not None

        # Search for DcmDsl protocol configuration
        for proto_path in [
            ".//ar:ECUC-CONTAINER-VALUE[ar:SHORT-NAME='DcmDslProtocolRow']",
            ".//ar:CONTAINER[ar:SHORT-NAME='DcmDslProtocolRow']",
            ".//ar:SUB-CONTAINER[ar:SHORT-NAME='DcmDslProtocolRow']",
        ]:
            protocols = _xpath(self.root, proto_path, self.ns)
            if protocols:
                break

        # Try to find CAN IDs from DcmDslConnection
        for conn_path in [
            ".//ar:ECUC-CONTAINER-VALUE[contains(ar:SHORT-NAME/text(), 'DcmDslConnection')]",
            ".//ar:CONTAINER[contains(ar:SHORT-NAME/text(), 'DcmDslConnection')]",
        ]:
            connections = _xpath(self.root, conn_path, self.ns)
            if connections:
                for conn in connections:
                    for param_path in [
                        ".//ar:ECUC-NUMERICAL-PARAM-VALUE",
                        ".//ar:PARAMETER-VALUES/ar:ECUC-NUMERICAL-PARAM-VALUE",
                    ]:
                        params = _xpath(conn, param_path, self.ns)
                        for param in params:
                            def_ref = _xpath_text(
                                param, "ar:DEFINITION-REF", self.ns
                            ) or _xpath_text(param, "ar:DEFINITION-REF/@DEST", self.ns)
                            value = _xpath_text(param, "ar:VALUE", self.ns)
                            if "RxPduId" in def_ref or "RxAddr" in def_ref:
                                spec.can_rx_id = value
                            elif "TxPduId" in def_ref or "TxAddr" in def_ref:
                                spec.can_tx_id = value
                break

    def _parse_sessions(self, spec: UdsSpecification) -> None:
        """Parse diagnostic session definitions."""
        assert self.root is not None

        # Search for DcmDspSession containers
        session_containers = self._find_containers("DcmDspSession")

        for container in session_containers:
            short_name = _xpath_text(container, "ar:SHORT-NAME", self.ns)
            if not short_name or short_name == "DcmDspSession":
                # This might be the parent container; look for sub-containers
                sub_containers = _xpath(
                    container,
                    ".//ar:SUB-CONTAINERS/ar:ECUC-CONTAINER-VALUE",
                    self.ns,
                ) or _xpath(
                    container,
                    ".//ar:ECUC-CONTAINER-VALUE",
                    self.ns,
                )
                for sub in sub_containers:
                    self._parse_single_session(sub, spec)
                continue

            self._parse_single_session(container, spec)

    def _parse_single_session(
        self, container: etree._Element, spec: UdsSpecification
    ) -> None:
        """Parse a single session container."""
        short_name = _xpath_text(container, "ar:SHORT-NAME", self.ns)
        if not short_name or short_name in ("DcmDspSession",):
            return

        session_id = self._get_param_value_int(container, "DcmDspSessionLevel")
        if session_id == 0:
            session_id = self._get_param_value_int(container, "DcmDspSessionForBoot")

        p2 = self._get_param_value_float(container, "DcmDspSessionP2ServerMax", 0.05)
        p2_star = self._get_param_value_float(
            container, "DcmDspSessionP2StarServerMax", 5.0
        )

        session = DiagSession(
            short_name=short_name,
            session_id=session_id,
            p2_server_max=p2,
            p2_star_server_max=p2_star,
        )
        spec.sessions.append(session)
        logger.debug("  Session: %s (0x%02X)", short_name, session_id)

    def _parse_security(self, spec: UdsSpecification) -> None:
        """Parse security access level definitions."""
        assert self.root is not None

        sec_containers = self._find_containers("DcmDspSecurityRow")
        if not sec_containers:
            sec_containers = self._find_containers("DcmDspSecurity")

        for container in sec_containers:
            short_name = _xpath_text(container, "ar:SHORT-NAME", self.ns)
            if not short_name or short_name == "DcmDspSecurity":
                sub_containers = _xpath(
                    container,
                    ".//ar:SUB-CONTAINERS/ar:ECUC-CONTAINER-VALUE",
                    self.ns,
                )
                for sub in sub_containers:
                    self._parse_single_security(sub, spec)
                continue
            self._parse_single_security(container, spec)

    def _parse_single_security(
        self, container: etree._Element, spec: UdsSpecification
    ) -> None:
        """Parse a single security level container."""
        short_name = _xpath_text(container, "ar:SHORT-NAME", self.ns)
        if not short_name or short_name in ("DcmDspSecurity", "DcmDspSecurityRow"):
            # Check sub-containers
            subs = _xpath(
                container, ".//ar:SUB-CONTAINERS/ar:ECUC-CONTAINER-VALUE", self.ns
            )
            for sub in subs:
                self._parse_single_security(sub, spec)
            return

        level = self._get_param_value_int(container, "DcmDspSecurityLevel")
        max_attempts = self._get_param_value_int(
            container, "DcmDspSecurityNumAttDelay", 3
        )

        sec = SecurityLevel(
            short_name=short_name,
            security_level=level,
            num_max_attempts=max_attempts,
        )
        spec.security_levels.append(sec)
        logger.debug("  Security: %s (level=%d)", short_name, level)

    def _parse_dids(self, spec: UdsSpecification) -> None:
        """Parse Data Identifier definitions."""
        assert self.root is not None

        did_containers = self._find_containers("DcmDspDid")

        for container in did_containers:
            short_name = _xpath_text(container, "ar:SHORT-NAME", self.ns)
            if not short_name or short_name == "DcmDspDid":
                sub_containers = _xpath(
                    container,
                    "ar:SUB-CONTAINERS/ar:ECUC-CONTAINER-VALUE",
                    self.ns,
                )
                for sub in sub_containers:
                    self._parse_single_did(sub, spec)
                continue
            self._parse_single_did(container, spec)

    def _parse_single_did(
        self, container: etree._Element, spec: UdsSpecification
    ) -> None:
        """Parse a single DID container."""
        short_name = _xpath_text(container, "ar:SHORT-NAME", self.ns)
        if not short_name or short_name in ("DcmDspDid",):
            return
        # Skip signal/data sub-containers that are not actual DIDs
        if "Signal" in short_name and "DID" not in short_name.upper().replace("SIGNAL", ""):
            return

        did_id = self._get_param_value_int(container, "DcmDspDidIdentifier")
        if did_id == 0:
            # Try to extract from the short name like "DID_F190"
            match = re.search(r"(?:DID[_]?)([0-9A-Fa-f]{4})", short_name)
            if match:
                did_id = int(match.group(1), 16)

        # Check read/write access
        read_access = True
        write_access = False
        read_ref = self._get_param_ref(container, "DcmDspDidRead")
        write_ref = self._get_param_ref(container, "DcmDspDidWrite")
        if read_ref is not None:
            read_access = True
        if write_ref is not None:
            write_access = True

        # Parse session and security references
        sessions = self._get_ref_list(container, "DcmDspDidReadSessionRef")
        sessions.extend(self._get_ref_list(container, "DcmDspDidWriteSessionRef"))
        security = self._get_ref_list(container, "DcmDspDidReadSecurityLevelRef")
        security.extend(
            self._get_ref_list(container, "DcmDspDidWriteSecurityLevelRef")
        )

        # Parse data elements (DcmDspDidSignal)
        data_elements: list[DataElement] = []
        signal_containers = _xpath(
            container,
            ".//ar:ECUC-CONTAINER-VALUE[contains(ar:SHORT-NAME/text(), 'Signal')]",
            self.ns,
        ) or _xpath(
            container,
            ".//ar:SUB-CONTAINERS/ar:ECUC-CONTAINER-VALUE",
            self.ns,
        )
        for sig in signal_containers:
            sig_name = _xpath_text(sig, "ar:SHORT-NAME", self.ns)
            if sig_name and "Signal" in sig_name:
                byte_pos = self._get_param_value_int(
                    sig, "DcmDspDidBytePosition"
                ) or self._get_param_value_int(sig, "DcmDspDidDataByteOffset")
                bit_size = self._get_param_value_int(
                    sig, "DcmDspDidBitSize"
                ) or self._get_param_value_int(sig, "DcmDspDidDataSize", 8)

                de = DataElement(
                    short_name=sig_name,
                    byte_position=byte_pos,
                    bit_size=bit_size,
                )
                data_elements.append(de)

        # Calculate total byte length
        total_bytes = self._get_param_value_int(container, "DcmDspDidDataSize")
        if total_bytes == 0 and data_elements:
            max_end = max(
                de.byte_position + (de.bit_size + 7) // 8 for de in data_elements
            )
            total_bytes = max_end

        did = Did(
            short_name=short_name,
            did_id=did_id,
            data_elements=data_elements,
            read_access=read_access,
            write_access=write_access,
            supported_sessions=list(set(sessions)),
            required_security_levels=list(set(security)),
            total_byte_length=total_bytes,
        )
        spec.dids.append(did)
        logger.debug("  DID: %s (0x%04X)", short_name, did_id)

    def _parse_routines(self, spec: UdsSpecification) -> None:
        """Parse Routine Control definitions."""
        assert self.root is not None

        routine_containers = self._find_containers("DcmDspRoutine")

        for container in routine_containers:
            short_name = _xpath_text(container, "ar:SHORT-NAME", self.ns)
            if not short_name or short_name == "DcmDspRoutine":
                sub_containers = _xpath(
                    container,
                    ".//ar:SUB-CONTAINERS/ar:ECUC-CONTAINER-VALUE",
                    self.ns,
                )
                for sub in sub_containers:
                    self._parse_single_routine(sub, spec)
                continue
            self._parse_single_routine(container, spec)

    def _parse_single_routine(
        self, container: etree._Element, spec: UdsSpecification
    ) -> None:
        """Parse a single routine container."""
        short_name = _xpath_text(container, "ar:SHORT-NAME", self.ns)
        if not short_name or short_name in ("DcmDspRoutine",):
            return

        routine_id = self._get_param_value_int(
            container, "DcmDspRoutineIdentifier"
        ) or self._get_param_value_int(container, "DcmDspRoutineId")

        if routine_id == 0:
            match = re.search(r"(?:Routine[_]?)([0-9A-Fa-f]{4})", short_name)
            if match:
                routine_id = int(match.group(1), 16)

        # Check start/stop/result support
        start_ref = self._get_param_ref(container, "DcmDspStartRoutine")
        stop_ref = self._get_param_ref(container, "DcmDspStopRoutine")
        result_ref = self._get_param_ref(container, "DcmDspRequestRoutineResults")

        sessions = self._get_ref_list(container, "DcmDspRoutineSessionRef")
        security = self._get_ref_list(container, "DcmDspRoutineSecurityLevelRef")

        routine = Routine(
            short_name=short_name,
            routine_id=routine_id,
            start_supported=start_ref is not None or True,
            stop_supported=stop_ref is not None,
            result_supported=result_ref is not None,
            supported_sessions=sessions,
            required_security_levels=security,
        )
        spec.routines.append(routine)
        logger.debug("  Routine: %s (0x%04X)", short_name, routine_id)

    def _parse_services(self, spec: UdsSpecification) -> None:
        """Parse Diagnostic Service Dispatcher (DSD) service table."""
        assert self.root is not None

        service_containers = self._find_containers("DcmDsdService")

        for container in service_containers:
            short_name = _xpath_text(container, "ar:SHORT-NAME", self.ns)
            if not short_name or short_name in ("DcmDsdService", "DcmDsdServiceTable"):
                sub_containers = _xpath(
                    container,
                    "ar:SUB-CONTAINERS/ar:ECUC-CONTAINER-VALUE",
                    self.ns,
                )
                for sub in sub_containers:
                    self._parse_single_service(sub, spec)
                continue
            self._parse_single_service(container, spec)

    def _parse_single_service(
        self, container: etree._Element, spec: UdsSpecification
    ) -> None:
        """Parse a single service container."""
        short_name = _xpath_text(container, "ar:SHORT-NAME", self.ns)
        if not short_name or short_name in (
            "DcmDsdService",
            "DcmDsdServiceTable",
        ):
            return

        service_id = self._get_param_value_int(container, "DcmDsdSidTabServiceId")
        if service_id == 0:
            service_id = self._get_param_value_int(container, "DcmDsdServiceId")

        # Check if subfunctions supported
        has_subfunc = self._get_param_value_bool(
            container, "DcmDsdSidTabSubfuncAvail"
        )

        # Get session and security info
        sessions = self._get_ref_list(container, "DcmDsdSidTabSessionLevelRef")
        security = self._get_ref_list(container, "DcmDsdSidTabSecurityLevelRef")

        # Get addressing mode
        addressing = []
        addr_val = self._get_param_value_text(container, "DcmDsdSidTabAddressingMode")
        if addr_val:
            addressing = [addr_val]

        # Use standard service name if available
        name = UDS_SERVICE_NAMES.get(service_id, short_name)

        # Parse sub-functions from ARXML (DcmDsdSubService containers)
        sub_functions = self._parse_sub_services(container)
        if not sub_functions and has_subfunc:
            # Fall back to ISO 14229-1 standard sub-functions
            std_sfs = STANDARD_SUB_FUNCTIONS.get(service_id, [])
            sub_functions = [
                SubFunction(short_name=sf_name, sub_function_id=sf_id)
                for sf_id, sf_name in std_sfs
            ]

        # Build default NRC list based on service
        nrc_list = self._build_default_nrcs(service_id, has_subfunc)

        service = UdsService(
            short_name=name,
            service_id=service_id,
            supported_sessions=sessions,
            required_security_levels=security,
            sub_functions=sub_functions,
            nrc_list=nrc_list,
            addressing_modes=addressing,
        )
        spec.services.append(service)
        logger.debug("  Service: %s (0x%02X), %d sub-functions",
                     name, service_id, len(sub_functions))

    def _parse_sub_services(
        self, service_container: etree._Element
    ) -> list[SubFunction]:
        """Parse DcmDsdSubService sub-containers within a service."""
        sub_functions: list[SubFunction] = []
        # Look for DcmDsdSubService containers
        sub_svc_containers = _xpath(
            service_container,
            ".//ar:SUB-CONTAINERS/ar:ECUC-CONTAINER-VALUE",
            self.ns,
        )
        for sub_c in sub_svc_containers:
            sn = _xpath_text(sub_c, "ar:SHORT-NAME", self.ns)
            if not sn:
                continue
            sf_id = self._get_param_value_int(sub_c, "DcmDsdSubServiceId")
            if sf_id == 0 and not sn.lower().startswith("subservice"):
                # Not a sub-service container
                continue
            sf_sessions = self._get_ref_list(
                sub_c, "DcmDsdSubServiceSessionLevelRef"
            )
            sf_security = self._get_ref_list(
                sub_c, "DcmDsdSubServiceSecurityLevelRef"
            )
            sub_functions.append(
                SubFunction(
                    short_name=sn,
                    sub_function_id=sf_id,
                    supported_sessions=sf_sessions,
                    required_security_levels=sf_security,
                )
            )
        return sorted(sub_functions, key=lambda s: s.sub_function_id)

    def _build_default_nrcs(
        self, service_id: int, has_subfunc: bool
    ) -> list[NrcEntry]:
        """Build default NRC list for a service."""
        nrcs = []
        # Common NRCs for all services
        common_nrc_codes = [0x10, 0x11, 0x13, 0x22, 0x7F]
        if has_subfunc:
            common_nrc_codes.append(0x12)
            common_nrc_codes.append(0x7E)

        # Service-specific NRCs
        if service_id == 0x11:  # ECUReset
            common_nrc_codes.extend([0x33])
        elif service_id == 0x14:  # ClearDiagnosticInformation
            common_nrc_codes.extend([0x31])
        elif service_id == 0x19:  # ReadDTCInformation
            common_nrc_codes.extend([0x31])
        elif service_id == 0x27:  # SecurityAccess
            common_nrc_codes.extend([0x24, 0x31, 0x33, 0x35, 0x36, 0x37])
        elif service_id == 0x29:  # Authentication
            common_nrc_codes.extend([0x24, 0x31, 0x33, 0x70])
        elif service_id in (0x22, 0x2E):  # Read/Write DID
            common_nrc_codes.extend([0x31, 0x33])
        elif service_id == 0x31:  # RoutineControl
            common_nrc_codes.extend([0x24, 0x31, 0x33])
        elif service_id == 0x34:  # RequestDownload
            common_nrc_codes.extend([0x31, 0x33, 0x70])
        elif service_id == 0x36:  # TransferData
            common_nrc_codes.extend([0x24, 0x31, 0x71, 0x72, 0x73])
        elif service_id == 0x37:  # RequestTransferExit
            common_nrc_codes.extend([0x24, 0x31, 0x72])

        for code in sorted(set(common_nrc_codes)):
            name = STANDARD_NRCS.get(code, f"NRC_{code:02X}")
            nrcs.append(NrcEntry(nrc_code=code, nrc_name=name))

        return nrcs

    # ---- Helper methods ----

    def _find_containers(self, name: str) -> list:
        """Find ECUC container values by SHORT-NAME pattern."""
        assert self.root is not None
        results = []

        # Try multiple XPath patterns for different ARXML structures
        patterns = [
            f".//ar:ECUC-CONTAINER-VALUE[ar:SHORT-NAME='{name}']",
            f".//ar:ECUC-CONTAINER-VALUE[contains(ar:SHORT-NAME/text(), '{name}')]",
            f".//ar:CONTAINER[ar:SHORT-NAME='{name}']",
            f".//ar:CONTAINER[contains(ar:SHORT-NAME/text(), '{name}')]",
        ]

        for pattern in patterns:
            found = _xpath(self.root, pattern, self.ns)
            if found:
                results.extend(found)
                break

        return results

    def _get_param_value_int(
        self, container: etree._Element, param_name: str, default: int = 0
    ) -> int:
        """Get integer parameter value from container."""
        for path in [
            f".//ar:ECUC-NUMERICAL-PARAM-VALUE[contains(ar:DEFINITION-REF/text(), '{param_name}')]/ar:VALUE",
            f".//ar:PARAMETER-VALUES/ar:ECUC-NUMERICAL-PARAM-VALUE[contains(ar:DEFINITION-REF/text(), '{param_name}')]/ar:VALUE",
        ]:
            text = _xpath_text(container, path, self.ns)
            if text:
                try:
                    if text.startswith("0x") or text.startswith("0X"):
                        return int(text, 16)
                    return int(float(text))
                except ValueError:
                    pass
        return default

    def _get_param_value_float(
        self, container: etree._Element, param_name: str, default: float = 0.0
    ) -> float:
        """Get float parameter value from container."""
        for path in [
            f".//ar:ECUC-NUMERICAL-PARAM-VALUE[contains(ar:DEFINITION-REF/text(), '{param_name}')]/ar:VALUE",
            f".//ar:PARAMETER-VALUES/ar:ECUC-NUMERICAL-PARAM-VALUE[contains(ar:DEFINITION-REF/text(), '{param_name}')]/ar:VALUE",
        ]:
            text = _xpath_text(container, path, self.ns)
            if text:
                try:
                    return float(text)
                except ValueError:
                    pass
        return default

    def _get_param_value_text(
        self, container: etree._Element, param_name: str, default: str = ""
    ) -> str:
        """Get text parameter value from container."""
        for path in [
            f".//ar:ECUC-TEXTUAL-PARAM-VALUE[contains(ar:DEFINITION-REF/text(), '{param_name}')]/ar:VALUE",
            f".//ar:ECUC-NUMERICAL-PARAM-VALUE[contains(ar:DEFINITION-REF/text(), '{param_name}')]/ar:VALUE",
            f".//ar:PARAMETER-VALUES/ar:ECUC-TEXTUAL-PARAM-VALUE[contains(ar:DEFINITION-REF/text(), '{param_name}')]/ar:VALUE",
        ]:
            text = _xpath_text(container, path, self.ns)
            if text:
                return text
        return default

    def _get_param_value_bool(
        self, container: etree._Element, param_name: str, default: bool = False
    ) -> bool:
        """Get boolean parameter value from container."""
        text = self._get_param_value_text(container, param_name)
        if text.lower() in ("true", "1"):
            return True
        if text.lower() in ("false", "0"):
            return False
        return default

    def _get_param_ref(
        self, container: etree._Element, param_name: str
    ) -> Optional[str]:
        """Get a reference parameter value."""
        for path in [
            f".//ar:ECUC-REFERENCE-VALUE[contains(ar:DEFINITION-REF/text(), '{param_name}')]/ar:VALUE-REF",
            f".//ar:REFERENCE-VALUES/ar:ECUC-REFERENCE-VALUE[contains(ar:DEFINITION-REF/text(), '{param_name}')]/ar:VALUE-REF",
        ]:
            results = _xpath(container, path, self.ns)
            if results:
                elem = results[0]
                return elem.text if isinstance(elem, etree._Element) else str(elem)
        return None

    def _get_ref_list(
        self, container: etree._Element, param_name: str
    ) -> list[str]:
        """Get a list of reference names for a parameter."""
        refs: list[str] = []
        for path in [
            f".//ar:ECUC-REFERENCE-VALUE[contains(ar:DEFINITION-REF/text(), '{param_name}')]/ar:VALUE-REF",
            f".//ar:REFERENCE-VALUES/ar:ECUC-REFERENCE-VALUE[contains(ar:DEFINITION-REF/text(), '{param_name}')]/ar:VALUE-REF",
        ]:
            results = _xpath(container, path, self.ns)
            for r in results:
                text = r.text if isinstance(r, etree._Element) else str(r)
                if text:
                    # Extract the last part of the reference path
                    ref_name = text.rsplit("/", 1)[-1]
                    refs.append(ref_name)
        return refs
