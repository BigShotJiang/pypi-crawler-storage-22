"""ARXML parser for AUTOSAR CanTp module configuration."""

from __future__ import annotations

import logging
from pathlib import Path
from typing import Optional

from lxml import etree

from udsxml2tex.models import CanTpChannel, CanTpConfig
from udsxml2tex.parser import _detect_namespace, _xpath, _xpath_text

logger = logging.getLogger(__name__)


class CanTpParser:
    """Parser for AUTOSAR CanTp ARXML files."""

    def __init__(self) -> None:
        self.ns: dict[str, str] = {}
        self.root: Optional[etree._Element] = None

    def parse(self, arxml_path: str | Path) -> CanTpConfig:
        """Parse a CanTp ARXML file and return transport configuration.

        Args:
            arxml_path: Path to the ARXML file.

        Returns:
            CanTpConfig with all parsed channel data.
        """
        arxml_path = Path(arxml_path)
        if not arxml_path.exists():
            raise FileNotFoundError(f"ARXML file not found: {arxml_path}")

        logger.info("Parsing CanTp ARXML file: %s", arxml_path)

        parser = etree.XMLParser(remove_blank_text=True, remove_comments=True)
        tree = etree.parse(str(arxml_path), parser)
        self.root = tree.getroot()
        self.ns = _detect_namespace(self.root)

        config = CanTpConfig()

        self._parse_general(config)
        self._parse_channels(config)

        logger.info("Parsed CanTp: %d channels", len(config.channels))

        return config

    def _parse_general(self, config: CanTpConfig) -> None:
        """Parse CanTpGeneral container for global settings."""
        assert self.root is not None

        # MainFunctionPeriod
        for path in [
            ".//ar:ECUC-CONTAINER-VALUE[contains(ar:SHORT-NAME/text(), 'CanTpGeneral')]",
            ".//ar:CONTAINER[contains(ar:SHORT-NAME/text(), 'CanTpGeneral')]",
        ]:
            containers = _xpath(self.root, path, self.ns)
            if containers:
                general = containers[0]
                period = self._get_param_float(
                    general, "CanTpMainFunctionPeriod", 0.005
                )
                config.main_function_period = period
                break

    def _parse_channels(self, config: CanTpConfig) -> None:
        """Parse CanTpChannel containers."""
        assert self.root is not None

        # Find CanTpChannel containers
        channel_containers = self._find_containers("CanTpChannel")

        for container in channel_containers:
            short_name = _xpath_text(container, "ar:SHORT-NAME", self.ns)
            if not short_name or short_name == "CanTpChannel":
                # Parent container — look at sub-containers
                subs = _xpath(
                    container,
                    "ar:SUB-CONTAINERS/ar:ECUC-CONTAINER-VALUE",
                    self.ns,
                )
                for sub in subs:
                    self._parse_single_channel(sub, config)
                continue
            self._parse_single_channel(container, config)

    def _parse_single_channel(
        self, container: etree._Element, config: CanTpConfig
    ) -> None:
        """Parse a single CanTpChannel or CanTpRxNSdu/CanTpTxNSdu container."""
        short_name = _xpath_text(container, "ar:SHORT-NAME", self.ns)
        if not short_name:
            return

        channel_mode = self._get_param_text(
            container, "CanTpChannelMode", "FULL_DUPLEX"
        )

        # Parse RxNSdu and TxNSdu sub-containers
        rx_sdus = self._find_sub_containers(container, "CanTpRxNSdu")
        tx_sdus = self._find_sub_containers(container, "CanTpTxNSdu")

        # If this container itself has CanTp parameters, treat it as a channel
        if not rx_sdus and not tx_sdus:
            channel = self._build_channel_from_container(container, short_name)
            channel.channel_mode = channel_mode
            config.channels.append(channel)
            return

        # Build channels from Rx/Tx NSdu pairs
        for rx_sdu in rx_sdus:
            rx_name = _xpath_text(rx_sdu, "ar:SHORT-NAME", self.ns) or short_name
            channel = self._build_channel_from_rx_sdu(rx_sdu, rx_name)
            channel.channel_mode = channel_mode

            # Try to find matching Tx NSdu
            for tx_sdu in tx_sdus:
                self._enrich_with_tx_sdu(channel, tx_sdu)

            config.channels.append(channel)

        # If only TxNSdu exists (no RxNSdu), still capture it
        if not rx_sdus and tx_sdus:
            for tx_sdu in tx_sdus:
                tx_name = _xpath_text(tx_sdu, "ar:SHORT-NAME", self.ns) or short_name
                channel = CanTpChannel(short_name=tx_name)
                channel.channel_mode = channel_mode
                self._enrich_with_tx_sdu(channel, tx_sdu)
                config.channels.append(channel)

    def _build_channel_from_container(
        self, container: etree._Element, name: str
    ) -> CanTpChannel:
        """Build a CanTpChannel directly from parameter values."""
        return CanTpChannel(
            short_name=name,
            bs=self._get_param_int(container, "CanTpBs", 0),
            stmin=self._get_param_float(container, "CanTpSTmin", 0.0),
            n_as=self._get_param_float(container, "CanTpNas", 0.0),
            n_bs=self._get_param_float(container, "CanTpNbs", 0.0),
            n_cs=self._get_param_float(container, "CanTpNcs", 0.0),
            n_ar=self._get_param_float(container, "CanTpNar", 0.0),
            n_br=self._get_param_float(container, "CanTpNbr", 0.0),
            n_cr=self._get_param_float(container, "CanTpNcr", 0.0),
            padding_activation=self._get_param_bool(
                container, "CanTpPaddingActivation", True
            ),
            padding_byte=self._get_param_int(container, "CanTpPaddingByte", 0xFF),
            max_data_length=self._get_param_int(container, "CanTpDl", 8),
            rx_addressing_format=self._get_param_text(
                container, "CanTpRxAddressingFormat", "STANDARD"
            ),
            tx_addressing_format=self._get_param_text(
                container, "CanTpTxAddressingFormat", "STANDARD"
            ),
        )

    def _build_channel_from_rx_sdu(
        self, rx_sdu: etree._Element, name: str
    ) -> CanTpChannel:
        """Build a CanTpChannel from an RxNSdu container."""
        rx_pdu_id = self._get_param_text(rx_sdu, "CanTpRxNPduId") or self._get_ref(
            rx_sdu, "CanTpRxNPduRef"
        )
        addressing = self._get_param_text(
            rx_sdu, "CanTpRxAddressingFormat", "STANDARD"
        )
        bs = self._get_param_int(rx_sdu, "CanTpBs", 0)
        stmin = self._get_param_float(rx_sdu, "CanTpSTmin", 0.0)
        n_ar = self._get_param_float(rx_sdu, "CanTpNar", 0.0)
        n_br = self._get_param_float(rx_sdu, "CanTpNbr", 0.0)
        n_cr = self._get_param_float(rx_sdu, "CanTpNcr", 0.0)
        padding = self._get_param_bool(rx_sdu, "CanTpPaddingActivation", True)
        padding_byte = self._get_param_int(rx_sdu, "CanTpPaddingByte", 0xFF)
        dl = self._get_param_int(rx_sdu, "CanTpDl") or self._get_param_int(
            rx_sdu, "CanTpRxDl", 8
        )

        return CanTpChannel(
            short_name=name,
            rx_pdu_id=rx_pdu_id or "",
            rx_addressing_format=addressing,
            bs=bs,
            stmin=stmin,
            n_ar=n_ar,
            n_br=n_br,
            n_cr=n_cr,
            padding_activation=padding,
            padding_byte=padding_byte,
            max_data_length=dl,
        )

    def _enrich_with_tx_sdu(
        self, channel: CanTpChannel, tx_sdu: etree._Element
    ) -> None:
        """Add TxNSdu information to an existing channel."""
        tx_pdu_id = self._get_param_text(tx_sdu, "CanTpTxNPduId") or self._get_ref(
            tx_sdu, "CanTpTxNPduRef"
        )
        if tx_pdu_id:
            channel.tx_pdu_id = tx_pdu_id

        addressing = self._get_param_text(tx_sdu, "CanTpTxAddressingFormat")
        if addressing:
            channel.tx_addressing_format = addressing

        n_as = self._get_param_float(tx_sdu, "CanTpNas")
        if n_as:
            channel.n_as = n_as
        n_bs = self._get_param_float(tx_sdu, "CanTpNbs")
        if n_bs:
            channel.n_bs = n_bs
        n_cs = self._get_param_float(tx_sdu, "CanTpNcs")
        if n_cs:
            channel.n_cs = n_cs

    # ---- Helper methods ----

    def _find_containers(self, name: str) -> list:
        """Find ECUC container values by SHORT-NAME."""
        assert self.root is not None
        patterns = [
            f".//ar:ECUC-CONTAINER-VALUE[ar:SHORT-NAME='{name}']",
            f".//ar:ECUC-CONTAINER-VALUE[contains(ar:SHORT-NAME/text(), '{name}')]",
            f".//ar:CONTAINER[ar:SHORT-NAME='{name}']",
            f".//ar:CONTAINER[contains(ar:SHORT-NAME/text(), '{name}')]",
        ]
        for pattern in patterns:
            found = _xpath(self.root, pattern, self.ns)
            if found:
                return found
        return []

    def _find_sub_containers(
        self, parent: etree._Element, name: str
    ) -> list:
        """Find sub-containers by SHORT-NAME within a parent."""
        patterns = [
            f".//ar:ECUC-CONTAINER-VALUE[contains(ar:SHORT-NAME/text(), '{name}')]",
            f"ar:SUB-CONTAINERS/ar:ECUC-CONTAINER-VALUE[contains(ar:SHORT-NAME/text(), '{name}')]",
        ]
        for pattern in patterns:
            found = _xpath(parent, pattern, self.ns)
            if found:
                return found
        return []

    def _get_param_int(
        self, container: etree._Element, param_name: str, default: int = 0
    ) -> int:
        """Get integer parameter value."""
        for path in [
            f".//ar:ECUC-NUMERICAL-PARAM-VALUE[contains(ar:DEFINITION-REF/text(), '{param_name}')]/ar:VALUE",
            f".//ar:PARAMETER-VALUES/ar:ECUC-NUMERICAL-PARAM-VALUE[contains(ar:DEFINITION-REF/text(), '{param_name}')]/ar:VALUE",
        ]:
            text = _xpath_text(container, path, self.ns)
            if text:
                try:
                    if text.startswith("0x") or text.startswith("0X"):
                        return int(text, 16)
                    return int(float(text))
                except ValueError:
                    pass
        return default

    def _get_param_float(
        self, container: etree._Element, param_name: str, default: float = 0.0
    ) -> float:
        """Get float parameter value."""
        for path in [
            f".//ar:ECUC-NUMERICAL-PARAM-VALUE[contains(ar:DEFINITION-REF/text(), '{param_name}')]/ar:VALUE",
            f".//ar:PARAMETER-VALUES/ar:ECUC-NUMERICAL-PARAM-VALUE[contains(ar:DEFINITION-REF/text(), '{param_name}')]/ar:VALUE",
        ]:
            text = _xpath_text(container, path, self.ns)
            if text:
                try:
                    return float(text)
                except ValueError:
                    pass
        return default

    def _get_param_text(
        self, container: etree._Element, param_name: str, default: str = ""
    ) -> str:
        """Get text parameter value."""
        for path in [
            f".//ar:ECUC-TEXTUAL-PARAM-VALUE[contains(ar:DEFINITION-REF/text(), '{param_name}')]/ar:VALUE",
            f".//ar:ECUC-NUMERICAL-PARAM-VALUE[contains(ar:DEFINITION-REF/text(), '{param_name}')]/ar:VALUE",
            f".//ar:PARAMETER-VALUES/ar:ECUC-TEXTUAL-PARAM-VALUE[contains(ar:DEFINITION-REF/text(), '{param_name}')]/ar:VALUE",
        ]:
            text = _xpath_text(container, path, self.ns)
            if text:
                return text
        return default

    def _get_param_bool(
        self, container: etree._Element, param_name: str, default: bool = False
    ) -> bool:
        """Get boolean parameter value."""
        text = self._get_param_text(container, param_name)
        if text.lower() in ("true", "1", "on"):
            return True
        if text.lower() in ("false", "0", "off"):
            return False
        return default

    def _get_ref(
        self, container: etree._Element, param_name: str
    ) -> Optional[str]:
        """Get reference parameter value (last segment of path)."""
        for path in [
            f".//ar:ECUC-REFERENCE-VALUE[contains(ar:DEFINITION-REF/text(), '{param_name}')]/ar:VALUE-REF",
            f".//ar:REFERENCE-VALUES/ar:ECUC-REFERENCE-VALUE[contains(ar:DEFINITION-REF/text(), '{param_name}')]/ar:VALUE-REF",
        ]:
            results = _xpath(container, path, self.ns)
            if results:
                elem = results[0]
                text = elem.text if isinstance(elem, etree._Element) else str(elem)
                if text:
                    return text.rsplit("/", 1)[-1]
        return None
