"""LaTeX generator for UDS specification documents."""

from __future__ import annotations

import logging
import shutil
from pathlib import Path
from typing import Optional

from jinja2 import Environment, FileSystemLoader, select_autoescape

from udsxml2tex.models import ISO14229_SERVICE_ORDER, NRC_CHECK_ORDER, UDS_MESSAGE_FORMATS, UdsSpecification

logger = logging.getLogger(__name__)

# Characters that need escaping in LaTeX
_LATEX_ESCAPE_MAP = {
    "&": r"\&",
    "%": r"\%",
    "$": r"\$",
    "#": r"\#",
    "_": r"\_",
    "{": r"\{",
    "}": r"\}",
    "~": r"\textasciitilde{}",
    "^": r"\textasciicircum{}",
}


def _latex_escape(text: str) -> str:
    """Escape special LaTeX characters in text."""
    if not text:
        return ""
    # Don't escape backslashes that are already LaTeX commands
    result = []
    i = 0
    while i < len(text):
        ch = text[i]
        if ch == "\\" and i + 1 < len(text) and text[i + 1].isalpha():
            # Likely a LaTeX command, don't escape
            result.append(ch)
        elif ch in _LATEX_ESCAPE_MAP:
            result.append(_LATEX_ESCAPE_MAP[ch])
        else:
            result.append(ch)
        i += 1
    return "".join(result)


def _strip_0x(text: str) -> str:
    """Strip '0x' or '0X' prefix from hex string for subscript-16 notation."""
    if isinstance(text, str) and text.lower().startswith("0x"):
        return text[2:]
    return str(text)


class TexGenerator:
    """Generate LaTeX documents from UDS specification data."""

    def __init__(self, template_dir: Optional[str | Path] = None) -> None:
        """Initialize the TeX generator.

        Args:
            template_dir: Directory containing Jinja2 templates.
                         Defaults to the built-in templates directory.
        """
        if template_dir is None:
            template_dir = Path(__file__).parent / "templates"
        else:
            template_dir = Path(template_dir)

        self.template_dir = template_dir
        self.env = Environment(
            loader=FileSystemLoader(str(template_dir)),
            block_start_string=r"\BLOCK{",
            block_end_string="}",
            variable_start_string=r"\VAR{",
            variable_end_string="}",
            comment_start_string=r"\#{",
            comment_end_string="}",
            autoescape=False,
            trim_blocks=True,
            lstrip_blocks=True,
        )
        # Register custom filters
        self.env.filters["latex_escape"] = _latex_escape
        self.env.filters["strip_0x"] = _strip_0x

    def generate(
        self,
        spec: UdsSpecification,
        output_path: str | Path,
        template_name: str = "uds_spec.tex.j2",
    ) -> Path:
        """Generate a LaTeX document from the UDS specification.

        Args:
            spec: The UDS specification data.
            output_path: Path for the output .tex file.
            template_name: Name of the Jinja2 template to use.

        Returns:
            Path to the generated .tex file.
        """
        output_path = Path(output_path)
        output_path.parent.mkdir(parents=True, exist_ok=True)

        template = self.env.get_template(template_name)

        # Sort data for consistent output
        services = sorted(spec.services, key=lambda s: s.service_id)
        dids = sorted(spec.dids, key=lambda d: d.did_id)
        routines = sorted(spec.routines, key=lambda r: r.routine_id)
        sessions = sorted(spec.sessions, key=lambda s: s.session_id)
        security_levels = sorted(spec.security_levels, key=lambda s: s.security_level)

        transport_config = spec.transport_config
        cantp_channels = transport_config.channels if transport_config else []

        # Collect unique session / security-level names for overview table columns
        session_names = sorted({n for s in services for n in s.supported_sessions})
        security_level_names = sorted(
            {n for s in services for n in s.required_security_levels}
        )

        context = {
            "ecu_name": spec.ecu_name,
            "description": spec.description,
            "protocol_name": spec.protocol_name,
            "can_rx_id": spec.can_rx_id,
            "can_tx_id": spec.can_tx_id,
            "can_functional_id": spec.can_functional_id,
            "sessions": sessions,
            "security_levels": security_levels,
            "services": services,
            "dids": dids,
            "routines": routines,
            "transport_config": transport_config,
            "cantp_channels": cantp_channels,
            "message_formats": UDS_MESSAGE_FORMATS,
            "nrc_check_order": NRC_CHECK_ORDER,
            "session_names": session_names,
            "security_level_names": security_level_names,
        }

        rendered = template.render(**context)

        output_path.write_text(rendered, encoding="utf-8")
        logger.info("Generated LaTeX document: %s", output_path)

        # Copy tikz-uml.sty alongside the output so pdflatex can find it
        tikz_uml_src = self.template_dir / "tikz-uml.sty"
        if tikz_uml_src.exists():
            tikz_uml_dst = output_path.parent / "tikz-uml.sty"
            if not tikz_uml_dst.exists():
                shutil.copy2(tikz_uml_src, tikz_uml_dst)
                logger.info("Copied tikz-uml.sty to %s", tikz_uml_dst)

        return output_path

    def generate_string(
        self,
        spec: UdsSpecification,
        template_name: str = "uds_spec.tex.j2",
    ) -> str:
        """Generate LaTeX content as a string.

        Args:
            spec: The UDS specification data.
            template_name: Name of the Jinja2 template to use.

        Returns:
            Rendered LaTeX content.
        """
        template = self.env.get_template(template_name)

        services = sorted(spec.services,
                         key=lambda s: ISO14229_SERVICE_ORDER.get(s.service_id, 100))
        dids = sorted(spec.dids, key=lambda d: d.did_id)
        routines = sorted(spec.routines, key=lambda r: r.routine_id)
        sessions = sorted(spec.sessions, key=lambda s: s.session_id)
        security_levels = sorted(spec.security_levels, key=lambda s: s.security_level)

        transport_config = spec.transport_config
        cantp_channels = transport_config.channels if transport_config else []

        # Collect unique session / security-level names for overview table columns
        session_names = sorted({n for s in services for n in s.supported_sessions})
        security_level_names = sorted(
            {n for s in services for n in s.required_security_levels}
        )

        context = {
            "ecu_name": spec.ecu_name,
            "description": spec.description,
            "protocol_name": spec.protocol_name,
            "can_rx_id": spec.can_rx_id,
            "can_tx_id": spec.can_tx_id,
            "can_functional_id": spec.can_functional_id,
            "sessions": sessions,
            "security_levels": security_levels,
            "services": services,
            "dids": dids,
            "routines": routines,
            "transport_config": transport_config,
            "cantp_channels": cantp_channels,
            "message_formats": UDS_MESSAGE_FORMATS,
            "nrc_check_order": NRC_CHECK_ORDER,
            "session_names": session_names,
            "security_level_names": security_level_names,
        }

        return template.render(**context)
