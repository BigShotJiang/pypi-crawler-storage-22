# Configuring blocks
