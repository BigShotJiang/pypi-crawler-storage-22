"""
UHT Discovery Package
Semi-automated protein discovery pipeline
"""

__version__ = "0.2.3"
__author__ = "Matthew Penner"
__email__ = "mp957@cam.ac.uk"
