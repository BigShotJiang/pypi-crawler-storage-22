"""MCP tests."""
