# UiPath Robot

[![PyPI downloads](https://img.shields.io/pypi/dm/uipath-robot.svg)](https://pypi.org/project/uipath-robot/)
[![PyPI - Version](https://img.shields.io/pypi/v/uipath-robot)](https://img.shields.io/pypi/v/uipath-robot)
[![Python versions](https://img.shields.io/pypi/pyversions/uipath-robot.svg)](https://pypi.org/project/uipath-robot/)

Robot simulator

## Local Dependency Overrides

To test with local package versions, create a `uipath.robot.toml` file in the directory where you run the robot:
```toml
[dependencies]
uipath = { path = "C:/Users/you/path/to/uipath-python", editable = true }
uipath-langchain = { path = "C:/Users/you/path/to/uipath-langchain-python", editable = true }
```

These overrides will be applied to any package's `pyproject.toml` before environment setup.

> **Note:** Use forward slashes in paths, even on Windows.
