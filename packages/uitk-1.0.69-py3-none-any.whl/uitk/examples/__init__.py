# !/usr/bin/python
# coding=utf-8
"""UITK Example - Task Manager

A practical example demonstrating UITK's core features.
See example.py for the slot class implementation.
"""

from uitk.examples.example import ExampleSlots

__all__ = ["ExampleSlots"]
