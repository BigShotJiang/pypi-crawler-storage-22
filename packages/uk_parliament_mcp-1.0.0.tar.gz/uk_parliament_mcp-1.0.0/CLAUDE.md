# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## Project Overview

UK Parliament MCP Server - A Model Context Protocol server that bridges AI assistants with official UK Parliament data APIs. Built with Python 3.11+, it provides 86 tools covering MPs/Lords, bills, votes, committees, Hansard, and more.

## Build Commands

```bash
# Create virtual environment and install dependencies
python -m venv .venv
source .venv/bin/activate  # Linux/Mac
# .venv\Scripts\activate   # Windows

pip install -e ".[dev]"

# Run the MCP server (stdio transport)
python -m uk_parliament_mcp

# Run tests
pytest

# Type checking
mypy src/

# Linting
ruff check src/
ruff format src/
```

## Architecture

```
AI Assistant ──(MCP/stdio)──> uk_parliament_mcp ──(HTTP)──> UK Parliament APIs
```

**Key Components:**

- **`__main__.py`**: Entry point. Configures logging to stderr (stdout reserved for MCP protocol), creates and runs the FastMCP server.

- **`server.py`**: FastMCP server setup. Creates the MCP server and registers all tool modules.

- **`http_client.py`**: HTTP client with retry logic. Provides:
  - HTTP request handling with 3-retry exponential backoff
  - 30-second timeout protection
  - URL building with parameter filtering (`build_url`)
  - Consistent response format: `{url, data}` or `{url, error, statusCode}`

- **`tools/*.py`**: 14 tool modules (86 total tools) each targeting a specific Parliament API:
  | Module | API Domain | Purpose |
  |--------|------------|---------|
  | members.py | members-api.parliament.uk | MPs, Lords, constituencies, parties |
  | bills.py | bills-api.parliament.uk | Legislation, amendments, stages |
  | commons_votes.py | commonsvotes-api.parliament.uk | Commons divisions |
  | lords_votes.py | lordsvotes-api.parliament.uk | Lords divisions |
  | committees.py | committees-api.parliament.uk | Committee info, evidence |
  | hansard.py | hansard-api.parliament.uk | Parliamentary record |
  | oral_questions.py | oralquestionsandmotions-api.parliament.uk | EDMs, questions |
  | interests.py | interests-api.parliament.uk | Register of interests |
  | now.py | now-api.parliament.uk | Live chamber activity |
  | whatson.py | whatson-api.parliament.uk | Calendar, sessions |
  | statutory_instruments.py | statutoryinstruments-api.parliament.uk | Acts, SIs |
  | treaties.py | treaties-api.parliament.uk | International treaties |
  | erskine_may.py | erskinemay-api.parliament.uk | Procedure rules |
  | core.py | N/A | Session management prompts |

- **`context/`**: OpenAPI spec JSON files for each Parliament API (reference documentation)

## Adding New Tools

Follow the established pattern in any `tools/*.py` file:

```python
"""New API tools for [description]."""
from urllib.parse import quote

from mcp.server.fastmcp import FastMCP

from uk_parliament_mcp.http_client import build_url, get_result

NEW_API_BASE = "https://api.parliament.uk"


def register_tools(mcp: FastMCP) -> None:
    """Register new tools with the MCP server."""

    @mcp.tool()
    async def get_something(param: str) -> str:
        """Action | keywords, synonyms | Use case | Returns format

        Args:
            param: Description of the parameter.

        Returns:
            Description of what is returned.
        """
        url = f"{NEW_API_BASE}/endpoint?param={quote(param)}"
        return await get_result(url)
```

Tool descriptions use a 4-part semantic format: `Action | Keywords | Use case | Returns`

Then register in `server.py`:
```python
from uk_parliament_mcp.tools import new_api
# ...
new_api.register_tools(mcp)
```

## Key Conventions

- **House IDs**: 1 = Commons, 2 = Lords
- **Date format**: YYYY-MM-DD throughout
- **Pagination**: `skip`/`take` parameters where supported
- All tools are read-only and idempotent
- Raw JSON responses from Parliament APIs are passed through (not transformed)
- Use `build_url(base, params)` for URL construction with parameter filtering
- Use `await get_result(url)` for HTTP requests with retry logic

## Dependencies

- mcp (>=1.0.0) - Anthropic's official MCP library
- httpx (>=0.27.0) - Async HTTP client
- tenacity (>=8.2.0) - Retry logic (available but manual retry used)

### Dev Dependencies

- pytest (>=8.0.0) - Testing
- pytest-asyncio (>=0.23.0) - Async test support
- pytest-httpx (>=0.30.0) - HTTP mocking
- ruff (>=0.3.0) - Linting and formatting
- mypy (>=1.8.0) - Type checking

## Project Structure

```
src/uk_parliament_mcp/
├── __init__.py
├── __main__.py         # Entry point
├── server.py           # FastMCP server setup
├── http_client.py      # HTTP client with retry
└── tools/
    ├── __init__.py
    ├── core.py         # Session management (2 tools)
    ├── members.py      # Member tools (25 tools)
    ├── bills.py        # Bills tools (21 tools)
    ├── committees.py   # Committees tools (12 tools)
    ├── commons_votes.py    # Commons votes (5 tools)
    ├── lords_votes.py      # Lords votes (5 tools)
    ├── hansard.py          # Hansard (1 tool)
    ├── oral_questions.py   # Questions (3 tools)
    ├── interests.py        # Interests (3 tools)
    ├── now.py              # Live activity (2 tools)
    ├── whatson.py          # Calendar (3 tools)
    ├── statutory_instruments.py  # SIs (2 tools)
    ├── treaties.py         # Treaties (1 tool)
    └── erskine_may.py      # Procedure (1 tool)
```
