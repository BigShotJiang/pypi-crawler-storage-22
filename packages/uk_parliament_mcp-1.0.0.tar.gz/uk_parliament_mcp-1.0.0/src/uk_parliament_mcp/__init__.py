"""UK Parliament MCP Server - bridges AI assistants with UK Parliament APIs."""

__version__ = "1.0.0"
