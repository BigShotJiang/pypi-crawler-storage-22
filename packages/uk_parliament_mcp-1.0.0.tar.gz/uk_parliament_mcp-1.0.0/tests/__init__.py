"""Tests for UK Parliament MCP Server."""
