"""Tests for UK Parliament MCP tools."""
