from uuid import UUID

from pydantic import ConfigDict
from ul_api_utils.api_resource.api_response import JsonApiResponsePayload


class TokenAuthResponse(JsonApiResponsePayload):
    org_id: UUID
    id: UUID
    user_created_id: UUID

    model_config = ConfigDict(populate_by_name=True, extra='forbid')
