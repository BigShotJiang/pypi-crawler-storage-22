def talk():
    print(2, end='')