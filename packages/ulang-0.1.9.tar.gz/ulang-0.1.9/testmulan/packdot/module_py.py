def talk(msg):
    print(msg, end='')
