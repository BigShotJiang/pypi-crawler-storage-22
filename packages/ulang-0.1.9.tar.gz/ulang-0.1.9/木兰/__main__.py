import sys
from 木兰.中 import 中

中(sys.argv)
