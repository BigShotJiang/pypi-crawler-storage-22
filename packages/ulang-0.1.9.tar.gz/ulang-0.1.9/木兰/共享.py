from sys import version_info as _version_info

python3版本号 = _version_info.minor
