def a(n):
    print(n)
a(1)