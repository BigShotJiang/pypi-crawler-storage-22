def a(x, y):
    print(x)
a(1, 2)