def a(n=2):
    print(n)
a(n=1)