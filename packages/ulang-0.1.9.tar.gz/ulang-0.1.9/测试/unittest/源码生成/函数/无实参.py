def a():
    print(1)
a()