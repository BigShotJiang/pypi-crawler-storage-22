def a():
    return

def b():
    return 1