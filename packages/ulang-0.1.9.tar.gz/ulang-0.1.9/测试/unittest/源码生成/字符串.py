'测试'
a = '测试'
f"{time_diff:.6f}"