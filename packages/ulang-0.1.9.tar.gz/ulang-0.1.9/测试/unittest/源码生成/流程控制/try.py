try:
    pass
except ValueError as e:
    print(0)
