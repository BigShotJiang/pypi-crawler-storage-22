while 1:
    pass