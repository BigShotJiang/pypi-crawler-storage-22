if a>1:
    pass
if True:
    pass
a = 3 if True else 2