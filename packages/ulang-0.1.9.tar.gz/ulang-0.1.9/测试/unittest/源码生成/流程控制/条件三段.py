if 1:
    pass
elif 0:
    print(2)
elif 2:
    print(3)
else:
    print(5)