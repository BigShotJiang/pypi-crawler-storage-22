class Person(C):
    pass
