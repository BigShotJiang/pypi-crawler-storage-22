class Person:
    def __init__(self):
        pass

def a():
    print(1)
a()