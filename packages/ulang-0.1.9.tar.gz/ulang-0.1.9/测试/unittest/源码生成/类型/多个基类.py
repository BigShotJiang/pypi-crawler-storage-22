class Person(C1, C2):
    pass
