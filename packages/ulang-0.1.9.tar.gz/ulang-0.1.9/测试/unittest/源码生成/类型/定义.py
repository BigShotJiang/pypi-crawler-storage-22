class Person:
    pass
