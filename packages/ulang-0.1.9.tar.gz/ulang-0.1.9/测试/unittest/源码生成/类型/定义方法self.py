class Person:
    def getAge(self):
        print(1)

    def hi(self):
        self.getAge()