'a' in d
'a' not in d
'a' in 'ab' in d
a is None
a is not None
a == b
a != b
a >= 0
a > 0
a <= 0
a < 0
a and b
a or b
not a