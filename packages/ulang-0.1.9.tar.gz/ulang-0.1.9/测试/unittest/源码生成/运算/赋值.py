a = 1
a, b = 1, 2
a = b = 1