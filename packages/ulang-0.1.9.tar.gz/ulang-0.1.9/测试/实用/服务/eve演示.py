using Eve in eve

设置 = {'DOMAIN': {'人': {:}}}

服务 = Eve(settings=设置)
服务.run()