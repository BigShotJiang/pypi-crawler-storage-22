try:
    exit()
except Exception as e:
    print('exited')
