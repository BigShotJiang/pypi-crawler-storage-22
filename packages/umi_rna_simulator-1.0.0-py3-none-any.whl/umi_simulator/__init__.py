"""
UMI RNA Simulator - Bulk RNA-seq UMI Simulation Package

A comprehensive Python package for simulating bulk RNA-seq data with Unique Molecular
Identifiers (UMIs), including PCR amplification and sequencing errors.
"""

from .simulator import BulkRNAUMISimulator
from .version import __version__
from . import compare

__all__ = ['BulkRNAUMISimulator', '__version__', 'compare']
