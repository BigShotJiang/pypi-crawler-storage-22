#!/usr/bin/env python3
"""
CLI entry point for umi-simulator package.

Allows running the simulator as: python -m umi_simulator [args]
"""

import sys
from .simulator import main

if __name__ == '__main__':
    sys.exit(main())
