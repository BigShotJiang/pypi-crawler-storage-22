#!/usr/bin/env python3
"""
Comparison utilities for validating UMI deduplication pipelines.

This module provides functions to compare simulation ground truth with
pipeline results from tools like featureCounts and RSEM.
"""

import sys
from typing import Dict, List, Optional

try:
    import matplotlib.pyplot as plt
    import numpy as np
    from scipy.stats import linregress
    HAS_PLOTTING = True
except ImportError:
    HAS_PLOTTING = False


def parse_simulation_truth(filename: str) -> Dict[str, int]:
    """
    Parse simulation ground truth file (_truth.txt).

    Args:
        filename: Path to truth file

    Returns:
        Dictionary mapping gene_id to true molecule count
    """
    print(f"Reading simulation ground truth from: {filename}")

    gene_molecules = {}

    with open(filename, 'r') as f:
        # Skip header line
        header = f.readline()

        if not header.startswith('gene_id'):
            raise ValueError(
                "Invalid truth file format. "
                "Expected header: gene_id\ttrue_molecules\tunique_umis\tfinal_reads"
            )

        for line in f:
            parts = line.strip().split('\t')
            if len(parts) >= 4:
                gene_id = parts[0]
                true_molecules = int(parts[1])
                # Only include genes with non-zero molecules
                if true_molecules > 0:
                    gene_molecules[gene_id] = true_molecules

    print(f"  Found ground truth for {len(gene_molecules)} genes")
    return gene_molecules


def parse_featurecounts(filename: str) -> Dict[str, int]:
    """
    Parse featureCounts output file.

    Args:
        filename: Path to featureCounts output

    Returns:
        Dictionary mapping gene_id to count
    """
    print(f"Reading featureCounts results from: {filename}")

    gene_counts = {}

    with open(filename, 'r') as f:
        for line in f:
            if line.startswith('#') or line.startswith('Geneid'):
                continue

            fields = line.strip().split('\t')
            if len(fields) >= 7:
                gene_id = fields[0]
                count = int(fields[6])
                gene_counts[gene_id] = count

    print(f"  Found counts for {len(gene_counts)} genes")
    return gene_counts


def parse_rsem(filename: str) -> Dict[str, int]:
    """
    Parse RSEM .genes.results output.

    Args:
        filename: Path to RSEM output

    Returns:
        Dictionary mapping gene_id to expected count
    """
    print(f"Reading RSEM results from: {filename}")

    gene_counts = {}

    with open(filename, 'r') as f:
        header = f.readline().strip().split('\t')

        # Find column indices
        try:
            gene_id_idx = header.index('gene_id')
            expected_count_idx = header.index('expected_count')
        except ValueError:
            raise ValueError(
                "RSEM file missing required columns. "
                "Expected: gene_id, expected_count"
            )

        for line in f:
            fields = line.strip().split('\t')
            if len(fields) > max(gene_id_idx, expected_count_idx):
                gene_id = fields[gene_id_idx]
                # Round expected_count to nearest integer
                count = round(float(fields[expected_count_idx]))
                gene_counts[gene_id] = count

    print(f"  Found counts for {len(gene_counts)} genes")
    return gene_counts


def detect_file_format(filename: str) -> str:
    """
    Detect whether file is featureCounts or RSEM format.

    Args:
        filename: Path to file

    Returns:
        Format string: 'featurecounts', 'rsem', or 'unknown'
    """
    with open(filename, 'r') as f:
        first_line = f.readline().strip()

        if first_line.startswith('#'):
            return 'featurecounts'
        elif 'gene_id' in first_line and 'expected_count' in first_line:
            return 'rsem'
        elif first_line.startswith('Geneid'):
            return 'featurecounts'
        else:
            return 'unknown'


def compare_counts(
    ground_truth: Dict[str, int],
    pipeline_results: Dict[str, int],
    report_file: Optional[str] = None,
    plot_file: Optional[str] = None
) -> Dict:
    """
    Compare ground truth with pipeline results.

    Args:
        ground_truth: Dictionary of true molecule counts
        pipeline_results: Dictionary of predicted counts
        report_file: Optional path to write detailed report
        plot_file: Optional path to save scatter plot

    Returns:
        Dictionary containing comparison metrics
    """
    print("\n" + "="*60)
    print("COMPARISON RESULTS")
    print("="*60)

    common_genes = set(ground_truth.keys()) & set(pipeline_results.keys())

    if not common_genes:
        raise ValueError("No common genes found between truth and results!")

    print(f"\nGenes in comparison: {len(common_genes)}")

    # Calculate metrics
    total_true = 0
    total_predicted = 0
    differences = []

    for gene in common_genes:
        true_count = ground_truth[gene]
        pred_count = pipeline_results[gene]

        total_true += true_count
        total_predicted += pred_count

        diff = pred_count - true_count
        pct_diff = (diff / true_count * 100) if true_count > 0 else 0

        differences.append({
            'gene': gene,
            'true': true_count,
            'predicted': pred_count,
            'diff': diff,
            'pct_diff': pct_diff
        })

    # Sort by absolute percentage difference
    differences.sort(key=lambda x: abs(x['pct_diff']), reverse=True)

    # Write report file if requested
    if report_file:
        with open(report_file, 'w') as rf:
            rf.write("Gene\tTruth\tPredicted\tDiff\tPctDiff\n")
            for d in sorted(differences, key=lambda x: x['gene']):
                rf.write(f"{d['gene']}\t{d['true']}\t{d['predicted']}\t"
                         f"{d['diff']}\t{d['pct_diff']:.2f}\n")
        print(f"\nReport written to: {report_file}")

    # Plot if requested
    if plot_file:
        if HAS_PLOTTING:
            plot_scatter(differences, plot_file)
        else:
            print("\nWarning: matplotlib not available, skipping plot")
            print("Install with: pip install matplotlib")

    # Calculate statistics
    accuracies = [d['predicted']/d['true']*100 if d['true'] > 0 else 100
                  for d in differences]

    # Overall statistics
    print("\nOverall Statistics:")
    print(f"  Total true molecules:     {total_true:,}")
    print(f"  Total predicted counts:   {total_predicted:,}")
    print(f"  Overall difference:       {total_predicted - total_true:,}")
    print(f"  Overall accuracy:         {(total_predicted/total_true*100):.2f}%")

    # Per-gene statistics
    print("\nPer-Gene Statistics:")
    print(f"  Mean accuracy:            {sum(accuracies)/len(accuracies):.2f}%")
    print(f"  Median accuracy:          {sorted(accuracies)[len(accuracies)//2]:.2f}%")

    # Show top discrepancies
    print("\nTop 10 Largest Discrepancies:")
    print(f"{'Gene':<20} {'True':>10} {'Predicted':>10} {'Diff':>10} {'% Diff':>10}")
    print("-" * 70)

    for d in differences[:10]:
        print(f"{d['gene']:<20} {d['true']:>10} {d['predicted']:>10} "
              f"{d['diff']:>+10} {d['pct_diff']:>9.1f}%")

    # Show closest matches
    differences_by_accuracy = sorted(differences, key=lambda x: abs(x['pct_diff']))

    print("\nTop 10 Most Accurate:")
    print(f"{'Gene':<20} {'True':>10} {'Predicted':>10} {'Diff':>10} {'% Diff':>10}")
    print("-" * 70)

    for d in differences_by_accuracy[:10]:
        print(f"{d['gene']:<20} {d['true']:>10} {d['predicted']:>10} "
              f"{d['diff']:>+10} {d['pct_diff']:>9.1f}%")

    print("\n" + "="*60)

    return {
        'total_true': total_true,
        'total_predicted': total_predicted,
        'mean_accuracy': sum(accuracies) / len(accuracies),
        'median_accuracy': sorted(accuracies)[len(accuracies)//2],
        'num_genes': len(common_genes)
    }


def plot_scatter(differences: List[Dict], plot_file: str):
    """
    Create scatter plot of truth vs predicted counts.

    Args:
        differences: List of difference dictionaries
        plot_file: Output file path for plot
    """
    if not HAS_PLOTTING:
        return

    # Prepare data
    y_true = np.array([d['true'] for d in differences])
    x_pred = np.array([d['predicted'] for d in differences])

    # Scatter plot
    plt.figure(figsize=(7, 7))
    plt.scatter(x_pred, y_true, alpha=0.5, s=18, label='Genes')

    # Regression
    slope, intercept, r_value, p_value, std_err = linregress(x_pred, y_true)
    reg_x = np.linspace(x_pred.min(), x_pred.max(), 100)
    reg_y = slope * reg_x + intercept
    plt.plot(reg_x, reg_y, color='red', lw=2, label='Regression line')

    # Regression formula
    formula = f"y = {slope:.2f}x + {intercept:.2f}\n$R^2$ = {r_value**2:.3f}"
    plt.text(0.05, 0.95, formula,
             transform=plt.gca().transAxes, fontsize=12,
             verticalalignment='top',
             bbox=dict(facecolor='white', alpha=0.7, edgecolor='none'))

    plt.xlabel('Predicted gene count (pipeline)')
    plt.ylabel('Truth gene count (simulator)')
    plt.title('Gene Quantification: Truth vs Predicted')
    plt.legend()
    plt.tight_layout()
    plt.savefig(plot_file, dpi=150)
    print(f"Scatter plot saved to: {plot_file}")
    plt.close()


def main():  # pragma: no cover
    """CLI entry point for comparing results."""
    import argparse

    parser = argparse.ArgumentParser(
        description="Compare simulation truth with pipeline results."
    )
    parser.add_argument(
        "truth_file",
        help="Ground truth file from simulator (*_truth.txt)"
    )
    parser.add_argument(
        "counts_file",
        help="Output from featureCounts or RSEM"
    )
    parser.add_argument(
        "--report",
        help="Optional output file for per-gene comparison report",
        default=None
    )
    parser.add_argument(
        "--plot",
        help="Optional output PNG file for scatter plot",
        default=None
    )

    args = parser.parse_args()

    try:
        # Parse files
        ground_truth = parse_simulation_truth(args.truth_file)

        # Detect and parse pipeline output
        file_format = detect_file_format(args.counts_file)
        print(f"Detected format: {file_format}")

        if file_format == 'rsem':
            pipeline_results = parse_rsem(args.counts_file)
        elif file_format == 'featurecounts':
            pipeline_results = parse_featurecounts(args.counts_file)
        else:
            print("ERROR: Could not detect file format")
            print("Expected featureCounts or RSEM format")
            sys.exit(1)

        # Compare and optionally write report
        compare_counts(
            ground_truth,
            pipeline_results,
            report_file=args.report,
            plot_file=args.plot
        )

    except Exception as e:
        print(f"\nError: {e}", file=sys.stderr)
        sys.exit(1)


if __name__ == "__main__":
    main()
