#!/usr/bin/env python3
"""
Bulk RNA-seq with UMI Simulation Script

This script simulates bulk RNA-seq data with Unique Molecular Identifiers (UMIs)
including PCR amplification and sequencing errors.

Requirements:
    - numpy
    - scipy
"""

import numpy as np
from scipy.stats import nbinom
import random
import argparse
from collections import defaultdict
from typing import Dict, Optional
import gzip
import re
import sys
sys.stdout.reconfigure(line_buffering=True)


class BulkRNAUMISimulator:
    """Simulates bulk RNA-seq data with UMIs"""

    def __init__(self,
                 n_genes: int = 5000,
                 total_molecules: int = 3000000,
                 umi_length: int = 10,
                 read_length: int = 75,
                 pcr_cycles: int = 12,
                 pcr_efficiency: float = 0.7,
                 sequencing_error_rate: float = 0.001,
                 umi_error_rate: float = 0.002,
                 random_seed: int = 42,
                 gtf_file: Optional[str] = None,
                 fasta_file: Optional[str] = None,
                 use_real_sequences: bool = False,
                 target_reads: Optional[int] = None,
                 paired_end: bool = False,
                 fragment_length: int = 300,
                 umi_in_sequence: bool = False):
        """
        Initialize the simulator

        Args:
            n_genes: Number of genes to simulate
            total_molecules: Total number of cDNA molecules (ignored if
                target_reads is provided)
            umi_length: Length of UMI barcode (8-12 bp typical)
            read_length: Length of sequenced reads
            pcr_cycles: Number of PCR amplification cycles
            pcr_efficiency: PCR efficiency per cycle (0-1)
            sequencing_error_rate: Error rate for read sequences
            umi_error_rate: Error rate for UMI sequences
            random_seed: Random seed for reproducibility
            gtf_file: Path to Ensembl GTF annotation file (optional)
            fasta_file: Path to reference genome FASTA file (optional)
            use_real_sequences: Whether to use real sequences from FASTA
            target_reads: Target number of final reads (optional). If
                provided, total_molecules will be back-calculated to
                achieve approximately this many reads after PCR
            paired_end: Whether to generate paired-end reads (default: False)
            fragment_length: Length of DNA fragments for paired-end mode
                (default: 300 bp)
            umi_in_sequence: Whether to include UMI in the sequence itself
                (default: False). If True, UMI is prepended to R1 sequence
                and header contains just gene info. If False, UMI is only
                in header (pre-extracted format).
        """
        self.n_genes = n_genes
        self.pcr_cycles = pcr_cycles
        self.pcr_efficiency = pcr_efficiency
        self.target_reads = target_reads
        self.calculated_molecules = False

        # Back-calculate total_molecules if target_reads is provided
        if target_reads is not None:
            self.total_molecules = self._calculate_molecules_from_target(
                target_reads, pcr_cycles, pcr_efficiency)
            self.calculated_molecules = True
            print(f"Target reads: {target_reads:,}")
            print(f"Back-calculated total_molecules: "
                  f"{self.total_molecules:,}")
        else:
            self.total_molecules = total_molecules

        self.umi_length = umi_length
        self.read_length = read_length
        self.sequencing_error_rate = sequencing_error_rate
        self.umi_error_rate = umi_error_rate
        self.gtf_file = gtf_file
        self.fasta_file = fasta_file
        self.use_real_sequences = use_real_sequences
        self.paired_end = paired_end
        self.fragment_length = fragment_length
        self.umi_in_sequence = umi_in_sequence

        np.random.seed(random_seed)
        random.seed(random_seed)

        self.nucleotides = ['A', 'C', 'G', 'T']
        self.molecules = []  # List of (gene_id, umi, sequence)
        self.gene_sequences = {}  # Gene reference sequences
        self.gene_info = {}  # Gene metadata from GTF
        self.genome_sequences = {}  # Chromosome sequences from FASTA

    @staticmethod
    def estimate_final_reads(total_molecules: int,
                             pcr_cycles: int,
                             pcr_efficiency: float) -> float:
        """
        Estimate the expected number of final reads after PCR amplification

        This is a helper function to predict the output size before running
        a simulation. The actual number will vary due to stochastic PCR.

        Args:
            total_molecules: Initial number of cDNA molecules
            pcr_cycles: Number of PCR amplification cycles
            pcr_efficiency: PCR efficiency per cycle (0-1)

        Returns:
            Estimated number of final reads (float)

        Example:
            >>> BulkRNAUMISimulator.estimate_final_reads(10000, 12, 0.7)
            159049.0
        """
        amplification_factor = (1 + pcr_efficiency) ** pcr_cycles
        return total_molecules * amplification_factor

    @staticmethod
    def _calculate_molecules_from_target(target_reads: int,
                                         pcr_cycles: int,
                                         pcr_efficiency: float) -> int:
        """
        Back-calculate the number of molecules needed to achieve
        target_reads

        Args:
            target_reads: Desired number of final reads
            pcr_cycles: Number of PCR amplification cycles
            pcr_efficiency: PCR efficiency per cycle (0-1)

        Returns:
            Required number of initial molecules (int)
        """
        amplification_factor = (1 + pcr_efficiency) ** pcr_cycles
        molecules_needed = int(target_reads / amplification_factor)
        # Ensure at least some molecules
        return max(1, molecules_needed)

    def generate_gene_expression(self) -> Dict[str, int]:
        """
        Generate true gene expression levels using negative
        binomial distribution

        Returns:
            Dictionary mapping gene IDs to molecule counts
        """
        print("Step 1: Generating gene expression levels...")

        # Load GTF if provided
        if self.gtf_file:
            gene_ids = self.load_gtf_annotations()
        else:
            gene_ids = list(range(self.n_genes))

        # Negative binomial parameters
        # Higher n = less overdispersion, p controls mean
        n_param = 10
        p_param = 0.3

        # Generate expression levels
        expression_values = nbinom.rvs(n_param, p_param, size=len(gene_ids))

        # Normalize to total molecules
        total_sum = expression_values.sum()
        expression_values = (expression_values / total_sum *
                             self.total_molecules)
        expression_values = expression_values.astype(int)

        # Ensure at least total_molecules
        diff = self.total_molecules - expression_values.sum()
        if diff > 0:
            # Add remaining molecules to random genes
            indices = np.random.choice(len(gene_ids), diff)
            for idx in indices:
                expression_values[idx] += 1

        # Create dictionary mapping gene_id to expression
        expression = dict(zip(gene_ids, expression_values))

        print(f"  Generated expression for {len(gene_ids)} genes")
        print(f"  Total molecules: {sum(expression.values())}")
        expr_values = list(expression.values())
        print(f"  Mean expression: {np.mean(expr_values):.2f}")
        print(f"  Median expression: {np.median(expr_values):.2f}")

        if self.gtf_file and len(self.gene_info) > 0:
            # Show some example genes
            sample_genes = list(expression.items())[:3]
            print("  Example genes:")
            for gid, count in sample_genes:
                name = self.gene_info.get(gid, {}).get('gene_name', gid)
                print(f"    {gid} ({name}): {count} molecules")

        return expression

    def generate_random_sequence(self, length: int) -> str:
        """Generate a random DNA sequence"""
        return ''.join(random.choices(self.nucleotides, k=length))

    def generate_umi(self) -> str:
        """Generate a random UMI sequence"""
        return self.generate_random_sequence(self.umi_length)

    def _reverse_complement(self, seq: str) -> str:
        """Generate reverse complement of a DNA sequence"""
        complement = {'A': 'T', 'T': 'A', 'C': 'G', 'G': 'C', 'N': 'N'}
        return ''.join(complement.get(base, 'N') for base in reversed(seq))

    def parse_gtf_attributes(self, attr_string: str) -> Dict[str, str]:
        """Parse GTF attribute string into dictionary"""
        attributes = {}
        for item in attr_string.strip().split(';'):
            item = item.strip()
            if item:
                match = re.match(r'(\w+)\s+"([^"]+)"', item)
                if match:
                    attributes[match.group(1)] = match.group(2)
        return attributes

    def load_gtf_annotations(self):
        """Load gene and exon annotations from Ensembl GTF file"""
        print(f"Loading GTF annotations from {self.gtf_file}...")

        gene_data = {}
        exon_data = {}
        open_func = gzip.open if self.gtf_file.endswith('.gz') else open
        mode = 'rt' if self.gtf_file.endswith('.gz') else 'r'

        with open_func(self.gtf_file, mode) as f:
            for line in f:
                if line.startswith('#'):
                    continue

                fields = line.strip().split('\t')
                if len(fields) < 9:
                    continue

                feature_type = fields[2]
                chrom = fields[0]
                start = int(fields[3])
                end = int(fields[4])
                strand = fields[6]
                attributes = self.parse_gtf_attributes(fields[8])
                gene_id = attributes.get('gene_id', '')
                gene_name = attributes.get('gene_name', gene_id)
                gene_biotype = attributes.get('gene_biotype', 'unknown')

                if feature_type == 'gene' and gene_biotype == 'protein_coding':
                    gene_data[gene_id] = {
                        'gene_name': gene_name,
                        'chrom': chrom,
                        'start': start,
                        'end': end,
                        'strand': strand,
                        'length': end - start + 1,
                        'biotype': gene_biotype
                    }
                elif feature_type in ('exon', 'CDS') and gene_id:
                    # Use both exon and CDS features (CDS for bacterial genomes)
                    # Prefer exon over CDS to avoid duplicates in eukaryotic GTFs
                    if gene_id not in exon_data:
                        exon_data[gene_id] = []
                    exon_data[gene_id].append({
                        'chrom': chrom,
                        'start': start,
                        'end': end,
                        'strand': strand,
                        'feature_type': feature_type  # Track type for deduplication
                    })

        print(f"  Loaded {len(gene_data)} protein-coding genes")

        # Select n_genes randomly or use all if fewer
        if len(gene_data) > self.n_genes:
            selected_ids = random.sample(list(gene_data.keys()),
                                         self.n_genes)
            self.gene_info = {gid: gene_data[gid] for gid in selected_ids}
        else:
            self.gene_info = gene_data
            self.n_genes = len(gene_data)

        # Attach exons to gene_info and deduplicate overlapping regions
        for gid in self.gene_info:
            raw_exons = exon_data.get(gid, [])

            # Deduplicate exons by coordinates (genes have multiple transcripts with shared exons)
            unique_exons = {}
            for exon in raw_exons:
                # Use coordinates as key to deduplicate
                key = (exon['chrom'], exon['start'], exon['end'])
                if key not in unique_exons:
                    unique_exons[key] = exon
                elif exon['feature_type'] == 'exon' and unique_exons[key]['feature_type'] == 'CDS':
                    # Prefer exon over CDS to get full UTR regions
                    unique_exons[key] = exon

            # Sort deduplicated exons by genomic start position
            self.gene_info[gid]['exons'] = sorted(
                unique_exons.values(),
                key=lambda e: e['start']
            )

        print(f"  Selected {len(self.gene_info)} genes for simulation")
        return list(self.gene_info.keys())

    def load_fasta_sequence(self, chrom: str, start: int, end: int) -> str:
        """Load sequence from FASTA file for a specific region"""
        if chrom not in self.genome_sequences:
            return None

        # Extract sequence (1-based coordinates in GTF)
        seq = self.genome_sequences[chrom][start-1:end]
        return seq.upper()

    def load_genome_fasta(self, chromosomes_needed: set):
        """Load chromosome sequences from FASTA file"""
        print(f"Loading genome sequences from {self.fasta_file}...")
        print(f"  Chromosomes needed: {sorted(chromosomes_needed)}")

        open_func = gzip.open if self.fasta_file.endswith('.gz') else open
        mode = 'rt' if self.fasta_file.endswith('.gz') else 'r'

        current_chrom = None
        current_seq = []
        loaded_chroms = set()

        with open_func(self.fasta_file, mode) as f:
            for line in f:
                line = line.strip()
                if line.startswith('>'):
                    # Save previous chromosome
                    if current_chrom and current_chrom in chromosomes_needed:
                        seq_str = ''.join(current_seq)
                        self.genome_sequences[current_chrom] = seq_str
                        loaded_chroms.add(current_chrom)
                        chrom_len = len(self.genome_sequences[current_chrom])
                        print(f"    Loaded {current_chrom}: {chrom_len:,} bp")

                    # Start new chromosome
                    # Parse chromosome name (handle different formats)
                    header = line[1:].split()[0]
                    current_chrom = header
                    current_seq = []

                    # Skip if not needed
                    if current_chrom not in chromosomes_needed:
                        current_chrom = None
                else:
                    if current_chrom:
                        current_seq.append(line)

            # Save last chromosome
            if current_chrom and current_chrom in chromosomes_needed:
                seq_str = ''.join(current_seq)
                self.genome_sequences[current_chrom] = seq_str
                loaded_chroms.add(current_chrom)
                chrom_len = len(self.genome_sequences[current_chrom])
                print(f"    Loaded {current_chrom}: {chrom_len:,} bp")

        print(f"  Loaded {len(self.genome_sequences)} chromosome sequences")

        # Check for missing chromosomes
        missing = chromosomes_needed - loaded_chroms
        if missing:
            missing_str = sorted(missing)
            print(f"  WARNING: Could not find sequences for: {missing_str}")

    def generate_gene_sequences(self, gene_ids=None):
        """Generate or load gene reference sequences (exonic only for real sequences)"""
        if self.gtf_file and self.use_real_sequences and self.fasta_file:
            print("Loading real gene sequences from genome (exonic only)...")
            chromosomes_needed = set(info['chrom'] for info in self.gene_info.values())
            self.load_genome_fasta(chromosomes_needed)
            for gene_id, info in self.gene_info.items():
                exons = info.get('exons', [])
                if exons and info['chrom'] in self.genome_sequences:
                    # Extract and concatenate exons in genomic order
                    exon_seqs = []
                    for exon in exons:
                        seq = self.load_fasta_sequence(exon['chrom'], exon['start'], exon['end'])
                        if seq:
                            exon_seqs.append(seq)

                    if exon_seqs:
                        # Concatenate exons
                        full_seq = ''.join(exon_seqs)
                        # Apply reverse complement for minus strand genes
                        if info['strand'] == '-':
                            full_seq = self._reverse_complement(full_seq)
                        # Use full sequence (removed 5kb cap to avoid 5' bias in long genes)
                        self.gene_sequences[gene_id] = full_seq
                    else:
                        # Fallback to synthetic if exon extraction failed
                        seq = self.generate_random_sequence(500)
                        self.gene_sequences[gene_id] = seq
                else:
                    # Fallback to synthetic if no exons or chromosome not found
                    seq = self.generate_random_sequence(500)
                    self.gene_sequences[gene_id] = seq
            print(f"  Loaded sequences for {len(self.gene_sequences)} genes")
            print("  Clearing genome sequences from memory to save RAM...")
            self.genome_sequences.clear()
        elif self.gtf_file:
            print("Using synthetic sequences with GTF gene IDs...")
            for gene_id in self.gene_info.keys():
                length = min(self.gene_info[gene_id]['length'], 5000)
                seq_len = max(length, 500)
                seq = self.generate_random_sequence(seq_len)
                self.gene_sequences[gene_id] = seq
        else:
            print("Generating synthetic gene reference sequences...")
            if gene_ids is None:
                gene_ids = range(self.n_genes)
            for gene_id in gene_ids:
                seq = self.generate_random_sequence(500)
                self.gene_sequences[gene_id] = seq

        # Free genome sequences as soon as possible
        if hasattr(self, 'genome_sequences'):
            self.genome_sequences.clear()

    def assign_umis(self, expression: Dict[str, int]):
        """
        Assign UMIs to molecules based on expression levels

        Args:
            expression: Dictionary mapping gene IDs to molecule counts
        """
        mode = "paired-end" if self.paired_end else "single-end"
        print(f"\nStep 2: Assigning UMIs to molecules ({mode})...")

        self.generate_gene_sequences()

        for gene_id, count in expression.items():
            for _ in range(count):
                umi = self.generate_umi()

                # Extract fragment from gene sequence
                if gene_id in self.gene_sequences:
                    gene_seq = self.gene_sequences[gene_id]

                    if self.paired_end:
                        # For paired-end, extract a fragment of fragment_length
                        fragment_len = min(self.fragment_length, len(gene_seq))
                        if len(gene_seq) > fragment_len:
                            max_start = len(gene_seq) - fragment_len
                            start_pos = random.randint(0, max_start)
                            fragment = gene_seq[start_pos:start_pos + fragment_len]
                        else:
                            fragment = gene_seq.ljust(fragment_len, 'N')

                        # R1: from start of fragment
                        r1_seq = fragment[:self.read_length]
                        r1_seq = r1_seq.ljust(self.read_length, 'N')

                        # R2: from end of fragment (reverse complement)
                        r2_seq = fragment[-self.read_length:]
                        r2_seq = r2_seq.ljust(self.read_length, 'N')
                        # Reverse complement for R2
                        r2_seq = self._reverse_complement(r2_seq)

                        self.molecules.append({
                            'gene_id': gene_id,
                            'umi': umi,
                            'sequence': r1_seq,  # R1
                            'sequence_r2': r2_seq,  # R2
                            'original_umi': umi
                        })
                    else:
                        # Single-end mode
                        if len(gene_seq) > self.read_length:
                            max_start = len(gene_seq) - self.read_length
                            start_pos = random.randint(0, max_start)
                            end_pos = start_pos + self.read_length
                            sequence = gene_seq[start_pos:end_pos]
                        else:
                            sequence = gene_seq[:self.read_length]
                            sequence = sequence.ljust(self.read_length, 'N')

                        self.molecules.append({
                            'gene_id': gene_id,
                            'umi': umi,
                            'sequence': sequence,
                            'original_umi': umi
                        })
                else:
                    # Generate random sequences
                    if self.paired_end:
                        r1_seq = self.generate_random_sequence(self.read_length)
                        r2_seq = self.generate_random_sequence(self.read_length)
                        self.molecules.append({
                            'gene_id': gene_id,
                            'umi': umi,
                            'sequence': r1_seq,
                            'sequence_r2': r2_seq,
                            'original_umi': umi
                        })
                    else:
                        sequence = self.generate_random_sequence(self.read_length)
                        self.molecules.append({
                            'gene_id': gene_id,
                            'umi': umi,
                            'sequence': sequence,
                            'original_umi': umi
                        })

        print(f"  Assigned UMIs to {len(self.molecules)} molecules")

        # Free gene sequences to save memory after molecule creation
        print("  Clearing gene sequences from memory to save RAM...")
        self.gene_sequences.clear()

    def simulate_pcr_amplification(self):
        """
        Simulate PCR amplification with specified cycles and efficiency, using batch processing and disk-backed storage to reduce RAM usage.
        """
        import tempfile
        import pickle
        import os

        msg = (f"\nStep 3: Simulating PCR amplification ({self.pcr_cycles} "
               f"cycles, {self.pcr_efficiency:.2f} efficiency, disk-backed)...")
        print(msg)

        initial_count = len(self.molecules)

        # Save initial molecules to temp file and clear from memory
        temp_in = tempfile.NamedTemporaryFile(delete=False, suffix='.pkl')
        temp_out = tempfile.NamedTemporaryFile(delete=False, suffix='.pkl')
        temp_in_path = temp_in.name
        temp_out_path = temp_out.name
        temp_in.close()
        temp_out.close()

        with open(temp_in_path, 'wb') as tf:
            pickle.dump(self.molecules, tf, protocol=pickle.HIGHEST_PROTOCOL)

        # Clear molecules from memory during PCR
        self.molecules = []

        batch_size = 100_000

        for cycle in range(self.pcr_cycles):
            total_new = 0
            # Process in batches to minimize memory usage
            with open(temp_in_path, 'rb') as tf_in:
                molecules = pickle.load(tf_in)
                total_mols = len(molecules)

                with open(temp_out_path, 'wb') as tf_out:
                    new_molecules = []
                    for batch_start in range(0, total_mols, batch_size):
                        batch_end = min(batch_start + batch_size, total_mols)
                        batch = molecules[batch_start:batch_end]

                        for mol in batch:
                            new_molecules.append(mol)
                            if random.random() < self.pcr_efficiency:
                                new_molecules.append(mol.copy())

                        # Free batch memory
                        del batch

                    total_new = len(new_molecules)
                    pickle.dump(new_molecules, tf_out, protocol=pickle.HIGHEST_PROTOCOL)
                    del new_molecules

                # Free loaded molecules
                del molecules

            # Swap files for next cycle
            temp_in_path, temp_out_path = temp_out_path, temp_in_path

            if (cycle + 1) % 3 == 0:
                print(f"  After cycle {cycle + 1}: {total_new:,} molecules (disk-backed)")

        # Load final molecules back into memory
        with open(temp_in_path, 'rb') as tf:
            self.molecules = pickle.load(tf)

        # Cleanup temp files
        try:
            os.remove(temp_in_path)
        except Exception:
            pass
        try:
            os.remove(temp_out_path)
        except Exception:
            pass

        msg = (f"  Amplification complete: {initial_count} -> "
               f"{len(self.molecules)} molecules (disk-backed)")
        print(msg)
        fold = len(self.molecules) / initial_count
        print(f"  Amplification fold: {fold:.2f}x")

    def introduce_sequencing_errors(self, sequence: str,
                                    error_rate: float) -> str:
        """
        Introduce sequencing errors into a sequence using vectorized operations

        Args:
            sequence: Original sequence
            error_rate: Probability of error per base

        Returns:
            Sequence with errors
        """
        if error_rate == 0:
            return sequence

        seq_array = np.array(list(sequence))
        seq_len = len(seq_array)

        # Vectorized error positions
        error_mask = np.random.random(seq_len) < error_rate
        n_errors = error_mask.sum()

        if n_errors == 0:
            return sequence

        # Generate random substitutions for error positions
        error_positions = np.where(error_mask)[0]
        for pos in error_positions:
            original = seq_array[pos]
            alternatives = [n for n in self.nucleotides if n != original]
            seq_array[pos] = random.choice(alternatives)

        return ''.join(seq_array)

    def add_sequencing_errors(self):
        """
        Add sequencing errors to both UMIs and read sequences (optimized with batching)
        """
        print("\nStep 4: Adding sequencing errors...")
        print(f"  Read error rate: {self.sequencing_error_rate}")
        print(f"  UMI error rate: {self.umi_error_rate}")

        batch_size = 50_000
        total_molecules = len(self.molecules)

        for batch_start in range(0, total_molecules, batch_size):
            batch_end = min(batch_start + batch_size, total_molecules)
            for i in range(batch_start, batch_end):
                molecule = self.molecules[i]
                # Add errors to UMI
                molecule['umi'] = self.introduce_sequencing_errors(
                    molecule['umi'], self.umi_error_rate
                )

                # Add errors to read sequence(s)
                molecule['sequence'] = self.introduce_sequencing_errors(
                    molecule['sequence'], self.sequencing_error_rate
                )

                # Add errors to R2 if paired-end
                if self.paired_end and 'sequence_r2' in molecule:
                    molecule['sequence_r2'] = self.introduce_sequencing_errors(
                        molecule['sequence_r2'], self.sequencing_error_rate
                    )

            if (batch_end % 100_000 == 0) or (batch_end == total_molecules):
                print(f"  Processed {batch_end:,} / {total_molecules:,} molecules")

        print(f"  Errors added to {len(self.molecules)} reads")

    def generate_quality_string(self, length: int,
                                mean_quality: int = 30) -> str:
        """
        Generate a quality string for FASTQ format

        Args:
            length: Length of the quality string
            mean_quality: Mean Phred quality score

        Returns:
            Quality string in Phred+33 format
        """
        # Generate quality scores with some variation
        qualities = np.random.normal(mean_quality, 5, length)
        qualities = np.clip(qualities, 2, 40).astype(int)

        # Convert to Phred+33 ASCII
        quality_string = ''.join([chr(q + 33) for q in qualities])
        return quality_string

    def write_fastq(self, output_file: str, gzip_output: bool = True):
        """
        Write molecules to FASTQ format with UMI in header
        For paired-end mode, creates two files: _R1 and _R2

        Args:
            output_file: Output filename (without .fastq extension)
            gzip_output: Whether to gzip compress the output
        """
        print("\nStep 5: Writing FASTQ output...")

        if self.paired_end:
            # Write R1 and R2 files for paired-end
            r1_file = f"{output_file}_R1.fastq"
            r2_file = f"{output_file}_R2.fastq"

            if gzip_output:
                if not r1_file.endswith('.gz'):
                    r1_file += '.gz'
                if not r2_file.endswith('.gz'):
                    r2_file += '.gz'

            open_func = gzip.open if gzip_output else open
            mode = 'wt' if gzip_output else 'w'
            # Use lower compression for faster writing
            compress_level = 1 if gzip_output else None

            kwargs1 = {'mode': mode, 'compresslevel': compress_level} if gzip_output else {'mode': mode}
            kwargs2 = {'mode': mode, 'compresslevel': compress_level} if gzip_output else {'mode': mode}

            with open_func(r1_file, **kwargs1) as f1, open_func(r2_file, **kwargs2) as f2:
                # Batch writes for better performance
                batch_size = 10_000
                r1_buffer = []
                r2_buffer = []
                total_molecules = len(self.molecules)
                progress_interval = max(50_000, total_molecules // 10)

                for idx, molecule in enumerate(self.molecules):
                    # Generate read ID
                    gene_id = molecule['gene_id']
                    if self.gtf_file:
                        gene_name = self.gene_info.get(gene_id, {})
                        gene_name = gene_name.get('gene_name', str(gene_id))
                    else:
                        gene_name = f"GENE{gene_id}"

                    if self.umi_in_sequence:
                        # UMI prepended to R1 sequence
                        read_id_r1 = f"@SIM:{idx}:{gene_id}:{gene_name} 1:N:0:0"
                        # UMI steals bases from cDNA portion - total length = read_length
                        cdna_portion = molecule['sequence'][:self.read_length - self.umi_length]
                        seq_r1 = molecule['umi'] + cdna_portion
                        qual_r1 = self.generate_quality_string(len(seq_r1))
                    else:
                        # UMI in header only (pre-extracted)
                        read_id_r1 = (f"@SIM:{idx}:{gene_id}:{gene_name}:"
                                      f"UMI:{molecule['umi']} 1:N:0:0")
                        seq_r1 = molecule['sequence']
                        qual_r1 = self.generate_quality_string(len(seq_r1))

                    r1_buffer.append(f"{read_id_r1}\n{seq_r1}\n+\n{qual_r1}\n")

                    # R2 (same read ID, different sequence)
                    if self.umi_in_sequence:
                        read_id_r2 = f"@SIM:{idx}:{gene_id}:{gene_name} 2:N:0:0"
                    else:
                        read_id_r2 = (f"@SIM:{idx}:{gene_id}:{gene_name}:"
                                      f"UMI:{molecule['umi']} 2:N:0:0")
                    seq_r2 = molecule['sequence_r2']
                    qual_r2 = self.generate_quality_string(len(seq_r2))

                    r2_buffer.append(f"{read_id_r2}\n{seq_r2}\n+\n{qual_r2}\n")

                    # Flush buffers periodically
                    if len(r1_buffer) >= batch_size:
                        f1.write(''.join(r1_buffer))
                        f2.write(''.join(r2_buffer))
                        r1_buffer = []
                        r2_buffer = []

                    # Progress reporting
                    if (idx + 1) % progress_interval == 0 or (idx + 1) == total_molecules:
                        percent = ((idx + 1) / total_molecules) * 100
                        print(f"  Written {idx + 1:,} / {total_molecules:,} read pairs ({percent:.1f}%)")

                # Flush remaining buffers
                if r1_buffer:
                    f1.write(''.join(r1_buffer))
                    f2.write(''.join(r2_buffer))

            print(f"  Wrote {len(self.molecules)} paired-end reads:")
            print(f"    R1: {r1_file}")
            print(f"    R2: {r2_file}")
        else:
            # Single-end mode
            if gzip_output and not output_file.endswith('.gz'):
                output_file += '.gz'

            open_func = gzip.open if gzip_output else open
            mode = 'wt' if gzip_output else 'w'
            # Use lower compression for faster writing
            compress_level = 1 if gzip_output else None
            kwargs = {'mode': mode, 'compresslevel': compress_level} if gzip_output else {'mode': mode}

            with open_func(output_file, **kwargs) as f:
                # Batch writes for better performance
                batch_size = 10_000
                buffer = []
                total_molecules = len(self.molecules)
                progress_interval = max(50_000, total_molecules // 10)

                for idx, molecule in enumerate(self.molecules):
                    # FASTQ format with UMI in header or sequence
                    gene_id = molecule['gene_id']
                    if self.gtf_file:
                        gene_name = self.gene_info.get(gene_id, {})
                        gene_name = gene_name.get('gene_name', str(gene_id))
                    else:
                        gene_name = f"GENE{gene_id}"

                    if self.umi_in_sequence:
                        # UMI prepended to sequence
                        read_id = f"@SIM:{idx}:{gene_id}:{gene_name}"
                        # UMI steals bases from cDNA portion - total length = read_length
                        cdna_portion = molecule['sequence'][:self.read_length - self.umi_length]
                        sequence = molecule['umi'] + cdna_portion
                    else:
                        # UMI in header only (pre-extracted)
                        read_id = (f"@SIM:{idx}:{gene_id}:{gene_name}:"
                                   f"UMI:{molecule['umi']}")
                        sequence = molecule['sequence']

                    quality = self.generate_quality_string(len(sequence))

                    buffer.append(f"{read_id}\n{sequence}\n+\n{quality}\n")
                    if len(buffer) >= batch_size:
                        f.write(''.join(buffer))
                        buffer = []

                    # Progress reporting
                    if (idx + 1) % progress_interval == 0 or (idx + 1) == total_molecules:
                        percent = ((idx + 1) / total_molecules) * 100
                        print(f"  Written {idx + 1:,} / {total_molecules:,} reads ({percent:.1f}%)")

                if buffer:
                    f.write(''.join(buffer))

            print(f"  Wrote {len(self.molecules)} reads to {output_file}")

    def write_truth_set(self, output_file: str, expression: Dict[str, int]):
        """
        Write ground truth gene expression counts to a file

        This file contains the true simulated expression levels for benchmarking
        and validation purposes.

        Args:
            output_file: Output filename for truth set
            expression: Dictionary mapping gene_id to true molecule count
        """
        print(f"\nWriting ground truth to {output_file}...")

        # Calculate actual read counts per gene after PCR
        gene_read_counts = defaultdict(int)
        gene_unique_molecules = defaultdict(set)

        for molecule in self.molecules:
            gene_id = molecule['gene_id']
            gene_read_counts[gene_id] += 1
            gene_unique_molecules[gene_id].add(molecule['original_umi'])

        with open(output_file, 'w') as f:
            # Write header
            f.write("gene_id\ttrue_molecules\tunique_umis\tfinal_reads\n")

            # Write data for all genes (including zero-count genes)
            for gene_id in sorted(expression.keys()):
                true_count = expression[gene_id]
                unique_umis = len(gene_unique_molecules.get(gene_id, set()))
                final_reads = gene_read_counts.get(gene_id, 0)
                f.write(f"{gene_id}\t{true_count}\t{unique_umis}\t{final_reads}\n")

        print(f"  Wrote truth set for {len(expression)} genes")

    def write_statistics(self, output_file: str):
        """
        Write simulation statistics to a file

        Args:
            output_file: Output filename for statistics
        """
        print(f"\nWriting statistics to {output_file}...")

        # Calculate statistics
        umi_counts = defaultdict(int)
        gene_read_counts = defaultdict(int)
        original_umi_counts = defaultdict(lambda: defaultdict(int))

        for molecule in self.molecules:
            umi_counts[molecule['umi']] += 1
            gene_read_counts[molecule['gene_id']] += 1
            original_umi_counts[molecule['gene_id']][
                molecule['original_umi']] += 1

        with open(output_file, 'w') as f:
            f.write("=== Bulk RNA-seq UMI Simulation Statistics ===\n\n")

            # Report simulation parameters
            if self.calculated_molecules:
                f.write("--- Simulation Parameters ---\n")
                f.write(f"Target reads (requested): "
                        f"{self.target_reads:,}\n")
                f.write(f"Total molecules (back-calculated): "
                        f"{self.total_molecules:,}\n")
                f.write(f"PCR cycles: {self.pcr_cycles}\n")
                f.write(f"PCR efficiency: {self.pcr_efficiency}\n")
                f.write(f"Actual reads (achieved): "
                        f"{len(self.molecules):,}\n\n")

            f.write(f"Total reads: {len(self.molecules)}\n")
            f.write(f"Unique UMIs (with errors): {len(umi_counts)}\n")
            f.write(f"Genes with reads: {len(gene_read_counts)}\n")
            f.write("\n--- UMI Duplication Statistics ---\n")
            mean_reads = np.mean(list(umi_counts.values()))
            f.write(f"Mean reads per UMI: {mean_reads:.2f}\n")
            median_reads = np.median(list(umi_counts.values()))
            f.write(f"Median reads per UMI: {median_reads:.2f}\n")
            f.write(f"Max reads per UMI: {max(umi_counts.values())}\n")

            # Duplication rate
            unique_molecules = sum(
                1 for gene_id in original_umi_counts
                for umi in original_umi_counts[gene_id])
            total_mols = len(self.molecules)
            duplication_rate = (total_mols - unique_molecules) / total_mols
            f.write("\n--- Amplification Statistics ---\n")
            f.write(f"Original unique molecules: {unique_molecules}\n")
            f.write(f"Duplication rate: {duplication_rate:.2%}\n")

            # Top expressed genes
            f.write("\n--- Top 10 Expressed Genes (by read count) ---\n")
            top_genes = sorted(
                gene_read_counts.items(), key=lambda x: x[1], reverse=True)[:10]
            for gene_id, count in top_genes:
                unique_umis = len(original_umi_counts[gene_id])
                msg = f"Gene {gene_id}: {count} reads, {unique_umis} "
                msg += "unique molecules\n"
                f.write(msg)

        print("  Statistics written successfully")

    def run_simulation(self, output_prefix: str = "simulated_bulk_rna"):
        """
        Run the complete simulation pipeline

        Args:
            output_prefix: Prefix for output files
        """
        print("=" * 60)
        print("Bulk RNA-seq with UMI Simulation")
        print("=" * 60)

        # Step 1: Generate gene expression
        expression = self.generate_gene_expression()

        # Step 2: Assign UMIs
        self.assign_umis(expression)

        # Step 3: Simulate PCR
        self.simulate_pcr_amplification()

        # Step 4: Add sequencing errors
        self.add_sequencing_errors()

        # Step 5: Write outputs
        if self.paired_end:
            fastq_output = output_prefix  # No .fastq extension for paired-end
        else:
            fastq_output = f"{output_prefix}.fastq"
        stats_output = f"{output_prefix}_stats.txt"
        truth_output = f"{output_prefix}_truth.txt"

        self.write_fastq(fastq_output, gzip_output=True)
        self.write_statistics(stats_output)
        self.write_truth_set(truth_output, expression)

        print("\n" + "=" * 60)
        print("Simulation complete!")
        print("=" * 60)
        print("Output files:")
        if self.paired_end:
            print(f"  - FASTQ R1: {output_prefix}_R1.fastq.gz")
            print(f"  - FASTQ R2: {output_prefix}_R2.fastq.gz")
        else:
            print(f"  - FASTQ: {fastq_output}.gz")
        print(f"  - Statistics: {stats_output}")
        print(f"  - Ground Truth: {truth_output}")


def main():  # pragma: no cover
    parser = argparse.ArgumentParser(
        description="Simulate bulk RNA-seq data with UMIs",
        formatter_class=argparse.ArgumentDefaultsHelpFormatter
    )

    parser.add_argument(
        "-g", "--genes",
        type=int,
        default=20000,
        help="Number of genes to simulate"
    )

    parser.add_argument(
        "-m", "--molecules",
        type=int,
        default=1000000,
        help="Total number of initial cDNA molecules "
             "(ignored if --target-reads is specified)"
    )

    parser.add_argument(
        "-t", "--target-reads",
        type=int,
        default=None,
        help="Target number of final reads (will back-calculate molecules). "
             "If specified, --molecules is ignored."
    )

    parser.add_argument(
        "-u", "--umi-length",
        type=int,
        default=10,
        help="Length of UMI barcode (8-12 bp typical)"
    )

    parser.add_argument(
        "-r", "--read-length",
        type=int,
        default=150,
        help="Length of sequenced reads"
    )

    parser.add_argument(
        "-c", "--pcr-cycles",
        type=int,
        default=12,
        help="Number of PCR amplification cycles"
    )

    parser.add_argument(
        "-e", "--pcr-efficiency",
        type=float,
        default=0.7,
        help="PCR efficiency per cycle (0-1)"
    )

    parser.add_argument(
        "--seq-error-rate",
        type=float,
        default=0.001,
        help="Sequencing error rate for read sequences"
    )

    parser.add_argument(
        "--umi-error-rate",
        type=float,
        default=0.002,
        help="Sequencing error rate for UMI sequences"
    )

    parser.add_argument(
        "-o", "--output",
        type=str,
        default="simulated_bulk_rna",
        help="Output file prefix"
    )

    parser.add_argument(
        "-s", "--seed",
        type=int,
        default=42,
        help="Random seed for reproducibility"
    )

    parser.add_argument(
        "--gtf",
        type=str,
        default=None,
        help="Path to Ensembl GTF annotation file "
             "(e.g., Homo_sapiens.GRCh38.105.gtf.gz)"
    )

    parser.add_argument(
        "--fasta",
        type=str,
        default=None,
        help="Path to reference genome FASTA file "
             "(e.g., Homo_sapiens.GRCh38.dna.primary_assembly.fa.gz)"
    )

    parser.add_argument(
        "--use-real-sequences",
        action="store_true",
        help="Use real sequences from FASTA file "
             "(requires both --gtf and --fasta)"
    )

    parser.add_argument(
        "--paired-end",
        action="store_true",
        help="Generate paired-end reads (creates R1 and R2 files)"
    )

    parser.add_argument(
        "--fragment-length",
        type=int,
        default=500,
        help="Fragment length for paired-end mode (bp)"
    )

    parser.add_argument(
        "--umi-in-sequence",
        action="store_true",
        help="Include UMI in the sequence itself (prepended to R1). "
             "If not set, UMI is only in header (pre-extracted format)"
    )

    args = parser.parse_args()

    # Validate arguments
    if args.use_real_sequences and (not args.gtf or not args.fasta):
        parser.error("--use-real-sequences requires both --gtf and --fasta")

    # Create simulator
    simulator = BulkRNAUMISimulator(
        n_genes=args.genes,
        total_molecules=args.molecules,
        umi_length=args.umi_length,
        read_length=args.read_length,
        pcr_cycles=args.pcr_cycles,
        pcr_efficiency=args.pcr_efficiency,
        sequencing_error_rate=args.seq_error_rate,
        umi_error_rate=args.umi_error_rate,
        random_seed=args.seed,
        gtf_file=args.gtf,
        fasta_file=args.fasta,
        use_real_sequences=args.use_real_sequences,
        target_reads=args.target_reads,
        paired_end=args.paired_end,
        fragment_length=args.fragment_length,
        umi_in_sequence=args.umi_in_sequence
    )

    # Run simulation
    simulator.run_simulation(output_prefix=args.output)


if __name__ == "__main__":
    main()
