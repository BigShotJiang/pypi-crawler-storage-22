"""Version information for umi-simulator package."""

__version__ = "1.0.0"
