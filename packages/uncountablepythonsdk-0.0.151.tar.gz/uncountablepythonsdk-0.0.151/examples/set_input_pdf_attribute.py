"""
Example: Upload a PDF file and set it as an input (ingredient) attribute value.

This example demonstrates the end-to-end flow for setting a PDF attribute on an input:
1. Upload a PDF file using the upload_files API
2. Call set_input_attribute_values with the file_id to associate the PDF with an input attribute

Prerequisites:
- You need an input (ingredient) ID and an attribute ID that is of type PDF
- You can find these by:
  - Going to the Inputs page in the platform
  - Selecting an input to get its ID from the URL
  - Looking at the attribute configuration to find a PDF-type attribute ID

Usage:
    export UNC_API_ID="your_api_id"
    export UNC_API_SECRET_KEY="your_api_secret_key"
    python set_input_pdf_attribute.py
"""

import os
from pathlib import Path

import uncountable.types.api.inputs.set_input_attribute_values as set_input_attribute_values_t
from uncountable.core import AuthDetailsApiKey, Client, MediaFileUpload

# Initialize the client
client = Client(
    base_url="http://localhost:5000",
    auth_details=AuthDetailsApiKey(
        api_id=os.environ["UNC_API_ID"],
        api_secret_key=os.environ["UNC_API_SECRET_KEY"],
    ),
)

# Configuration - update these values for your specific use case
PDF_FILE_PATH = str(
    (Path.home() / "Downloads" / "All Projects - January 15, 2026.pdf").absolute()
)
INPUT_ID = 1  # Replace with your actual input (ingredient) ID
PDF_ATTRIBUTE_ID = 136  # Replace with your actual PDF attribute ID

# Step 1: Upload the PDF file
print(f"Uploading PDF file: {PDF_FILE_PATH}")
uploaded_files = client.upload_files(
    file_uploads=[
        MediaFileUpload(path=PDF_FILE_PATH),
    ]
)
uploaded_file = uploaded_files[0]
print(f"File uploaded successfully. File ID: {uploaded_file.file_id}")

# Step 2: Set the PDF attribute on the input
print(f"Setting PDF attribute {PDF_ATTRIBUTE_ID} on input {INPUT_ID}...")
client.set_input_attribute_values(
    attribute_values=[
        set_input_attribute_values_t.InputAttributeValue(
            input_id=INPUT_ID,
            attribute_id=PDF_ATTRIBUTE_ID,
            file_ids=[uploaded_file.file_id],
        ),
    ],
)
print("PDF attribute set successfully!")

# After running this script, you should be able to view/download the PDF
# in the platform by navigating to the input's attribute values.
