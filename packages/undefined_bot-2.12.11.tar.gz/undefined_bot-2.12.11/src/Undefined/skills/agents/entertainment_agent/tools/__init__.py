# Entertainment Agent Tools
