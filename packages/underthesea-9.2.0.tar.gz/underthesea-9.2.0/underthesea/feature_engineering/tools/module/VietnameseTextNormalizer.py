def Normalize(s):
    return s
