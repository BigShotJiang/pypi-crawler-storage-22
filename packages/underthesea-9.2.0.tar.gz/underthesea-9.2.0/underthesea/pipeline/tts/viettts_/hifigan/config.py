from pathlib import Path


class FLAGS:
    ckpt_dir = Path("./assets/infore/hifigan")
