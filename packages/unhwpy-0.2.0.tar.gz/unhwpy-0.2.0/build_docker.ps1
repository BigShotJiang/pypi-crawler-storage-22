$ErrorActionPreference = "Stop"

# Create dist directory for artifacts
if (-not (Test-Path -Path "dist")) {
    New-Item -ItemType Directory -Path "dist" | Out-Null
}

Write-Host "Building manylinux wheels and sdist using Docker..."
# Use ghcr.io/pyo3/maturin to build:
# - manylinux wheels (broad Linux compatibility)
# - sdist (Source distribution for all platforms)
# --release: Optimized build
# --sdist: Generate source distribution
# -o dist: Output to local dist folder
# --find-interpreter: Find python interpreter inside the container
docker run --rm -v "${PWD}:/io" ghcr.io/pyo3/maturin build --release --sdist -o dist

Write-Host "Build complete. Artifacts are in the 'dist' directory."
