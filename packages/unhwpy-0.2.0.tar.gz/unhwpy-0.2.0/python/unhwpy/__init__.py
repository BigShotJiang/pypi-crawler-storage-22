from ._unhwpy import (
    CleanupOptions,
    Document,
    FormatType,
    RenderOptions,
    TableFallback,
    convert_to_markdown,
    detect_format,
    is_distribution,
    parse,
)

__all__ = [
    "CleanupOptions",
    "Document",
    "FormatType",
    "RenderOptions",
    "TableFallback",
    "convert_to_markdown",
    "detect_format",
    "is_distribution",
    "parse",
]

try:
    from . import _unhwpy

    if hasattr(_unhwpy, "__doc__") and _unhwpy.__doc__:
        __doc__ = _unhwpy.__doc__
except ImportError:
    pass
