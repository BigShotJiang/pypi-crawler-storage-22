from .platformdetails import PlatformDetails
