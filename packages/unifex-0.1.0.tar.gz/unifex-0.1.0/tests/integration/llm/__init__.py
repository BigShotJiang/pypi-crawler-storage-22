"""LLM integration tests - slow tests that call external APIs."""
