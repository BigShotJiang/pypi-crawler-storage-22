"""OCR integration tests - slow tests that load real ML models."""
