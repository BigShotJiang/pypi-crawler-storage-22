# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/), 
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [1.2.26] - 2026-02-17
- Reverting fix the behavior so that when no knowledge base files are selected, only uploaded files are considered, rather than searching across all files.

## [1.2.25] - 2026-02-12
- Add optional `language_model_orchestrator` parameter (defaults to `None`) and pass to `pick_content_chunks_for_token_window()` for model-agnostic token counting. Ready for orchestrator to pass LLM in future update.

## [1.2.24] - 2026-02-11
- Fix the behavior so that when no knowledge base files are selected, only uploaded files are considered, rather than searching across all files.

## [1.2.23] - 2026-02-11
- Update message log for uploaded files based on feature flag

## [1.2.22] - 2026-02-05
- Adjust new feature flag logic

## [1.2.21] - 2026-01-20
- Fix tool naming for uploaded search

## [1.2.20] - 2026-01-16
- Add local CI testing commands via poethepoet (poe lint, poe test, poe ci-typecheck, etc.)

## [1.2.19] - 2026-01-16
- Add unified type checking CI with basedpyright

## [1.2.18] - 2026-01-13
- Fix test suite: add missing `__init__.py`, mock fixtures, and `_message_step_logger` attribute

## [1.2.17] - 2026-01-13
- Removing unused parameters from config
- Activating multiple search string execution by default

## [1.2.16] - 2026-01-12
- Fix message logswith new ChatUI

## [1.2.15] - 2026-01-12
- Include feature flag to have message logs compatible with new ChatUI

## [1.2.14] - 2026-01-05
- Bump unique_toolkit version

## [1.2.13] - 2025-12-29
- Bump unique_sdk version to `0.10.58`

## [1.2.12] - 2025-12-01
- Fix of multiple search queries: 
  - `max_search_strings` must be at lest 1
  - Only executed queries are shown in the message logs

## [1.2.11] - 2025-11-28
- Parallel search execution using asyncio.gather()
- Automatic deduplication of duplicate search strings
- Configurable limit on search strings via `max_search_strings`

## [1.2.10] - 2025-11-24
- Cosmetic code cleanness change for steplogger print of tool title

## [1.2.9] - 2025-11-24
- Bugfix for message log messages

## [1.2.8] - 2025-11-20
- Update toolkit version

## [1.2.7] - 2025-11-20
- Include message log messages

## [1.2.6] - 2025-11-20
- Fix bug of handling properly uploaded files that are expired1

## [1.2.5] - 2025-11-20
- Bump tiktoken to 0.12.0

## [1.2.4] - 2025-11-17
- Fix bug in search method when `exclude_uploaded_files` is True

## [1.2.3] - 2025-11-14
- Move pytest to dev dependencies

## [1.2.2] - 2025-11-10
- Temporarily reverting the removal of the `get_tool_call_result_for_loop_history` function, as it is still required for the Investment Research Agent. 

## [1.2.1] - 2025-11-06
- Upload and chat system reminder cleanup

## [1.2.0] - 2025-11-04
- Include system reminder for upload and chat tool about it being a forced tool in UniqueAI

## [1.1.0] - 2025-10-30
- Add support for multiple search strings in a single tool call
- Search results from multiple queries are interleaved for better diversity
- Add automatic deduplication of chunks by `chunk_id` when using multiple search queries
  - Prevents duplicate content from appearing in results when multiple related queries return the same chunks
  - Preserves first occurrence and logs number of duplicates removed
- Add automatic parsing and cleaning of search query operators1
  - Removes QDF (QueryDeservedFreshness) operators: `--QDF=0` to `--QDF=5` (freshness ratings)
  - Removes boost operators: `+(term)` and `+(multi word phrase)` for query term boosting

## [1.0.4] - 2025-10-28
- Removing unused tool specific `get_tool_call_result_for_loop_history` function
- Removing unused config `source_format_config`

## [1.0.3] - 2025-10-25
- Fix appending of metadata to chunks

## [1.0.2] - 2025-10-17
- Remove print statements originating from tool refactor

## [1.0.1] - 2025-09-30
- Fix bug in metadata filter in the search method.

## [1.0.0] - 2025-09-18
- Bump toolkit version to allow for both patch and minor updates

## [0.0.7] - 2025-09-17
- Updated to latest toolkit

## [0.0.6] - 2025-09-15
- Fix Minor bug in transforming toolResponse to toolCallResult

## [0.0.5] - 2025-09-05
- Fixed a bug around metadata-filter assignment

## [0.0.4] - 2025-09-05
- Fixed a bug around metadata-filter deep-copy

## [0.0.3] - 2025-09-01
- Migrated the `uploaded_search` into this package.

## [0.0.2] - 2025-09-01
- Migrated the `internal_search`.

## [0.0.1] - 2025-08-18
- Initial release of `internal_search`.
