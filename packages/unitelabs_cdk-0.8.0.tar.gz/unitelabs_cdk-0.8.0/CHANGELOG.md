# Changelog
All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]

## [v0.7.2] - 2026-01-29
### Added
- `sync(title)`: *Parameter was added as required*
- `push_to_gitlab(title)`: *Parameter was added as required*

### Changed
- `DEFAULT_BRANCH`: *Attribute value was changed*: `'chore/cruft-update'` -> `'feature/cruft-update'`

### Fixed
- release glab installation and revert back to previous license and readme [c3fb15182](https://gitlab.com/unitelabs/cdk/python-cdk/commit/c3fb151824afa57e9386c89d8dad90e80e9eeb67) (INT-19)

## [V0.7.1] - 2026-01-26
### Fixed
- Fix root certificate config to load paths from the file system [8745a005c](https://gitlab.com/unitelabs/cdk/python-cdk/commit/8745a005cc3cec25f56d99e1adcce0e96f1e4d44) (INT-22)

[Unreleased]: https://gitlab.com/unitelabs/cdk/python-cdk/compare/v0.7.2...HEAD
[v0.7.2]: https://gitlab.com/unitelabs/cdk/python-cdk/compare/v0.7.1...v0.7.2
[V0.7.1]: https://gitlab.com/unitelabs/cdk/python-cdk/compare/v0.7.0...v0.7.1
