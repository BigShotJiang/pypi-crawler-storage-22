"""Universal Image MCP - Generic image generation server"""
__version__ = "0.1.0"
