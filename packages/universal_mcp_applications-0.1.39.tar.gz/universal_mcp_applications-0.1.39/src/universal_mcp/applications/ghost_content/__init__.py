from .app import GhostContentApp
