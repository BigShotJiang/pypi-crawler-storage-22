# API Reference

::: universalasync
