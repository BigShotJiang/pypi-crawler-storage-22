"""UI step tests."""
