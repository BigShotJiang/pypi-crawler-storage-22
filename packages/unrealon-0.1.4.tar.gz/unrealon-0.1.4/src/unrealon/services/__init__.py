"""SDK services - now provided via gRPC."""

# HTTP services have been removed in favor of gRPC
# See grpc/stream_service.py for the unified gRPC implementation

__all__ = []
