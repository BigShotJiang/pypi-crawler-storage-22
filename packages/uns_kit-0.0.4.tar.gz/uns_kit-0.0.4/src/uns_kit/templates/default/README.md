# UNS Python App Template

## Setup
```bash
poetry install
poetry run python src/main.py
```

## Config
Edit `config.json` with your MQTT host/auth.
