"""
UnSearch Python SDK - Open-source Tavily alternative.

Comprehensive API client with full backend capabilities:
- Agent API (Tavily-compatible)
- Core Search API
- RAG API
- Neural API (Exa-compatible)
- Enhanced API (Advanced scraping & extraction)
- Knowledge Graph API
- Agent Registration API
- Topic Monitoring API
- Verification API (Fact-checking)

Usage:
    from unsearch import UnSearchClient

    client = UnSearchClient(api_key="your-api-key")
    results = client.search("What is machine learning?")

For async:
    from unsearch import AsyncUnSearchClient

    async with AsyncUnSearchClient(api_key="your-key") as client:
        results = await client.search("What is Python?")

For LangChain:
    from unsearch.langchain import UnSearchResults

    tool = UnSearchResults(api_key="your-api-key")
"""

from unsearch.client import (
    UnSearchClient,
    AsyncUnSearchClient,
    # Data classes - Agent API
    SearchResult,
    SearchResponse,
    ExtractedContent,
    ExtractResponse,
    ResearchResponse,
    # Data classes - RAG API
    RAGSource,
    RAGResearchResponse,
    RAGSearchResponse,
    SemanticSearchResult,
    # Data classes - Neural API
    NeuralSearchResult,
    NeuralSearchResponse,
    SimilarContentResponse,
    Highlight,
    SearchPrediction,
    # Data classes - Enhanced API
    EnhancedScrapeResult,
    ChunkResult,
    # Data classes - Knowledge Graph API
    Entity,
    Relationship,
    Person,
    # Data classes - Agent Registration API
    AgentAccessInfo,
    AgentRegisterResponse,
    AgentStatusResponse,
    # Data classes - Monitoring API
    TopicMonitor,
    MonitorResult,
    # Data classes - Verification API
    SourceEvidence,
    ClaimVerificationResponse,
    SourceCredibilityResponse,
)
from unsearch.exceptions import (
    UnSearchError,
    UnSearchAPIError,
    UnSearchRateLimitError,
    UnSearchAuthenticationError,
)

__version__ = "0.2.0"
__all__ = [
    # Clients
    "UnSearchClient",
    "AsyncUnSearchClient",
    # Exceptions
    "UnSearchError",
    "UnSearchAPIError",
    "UnSearchRateLimitError",
    "UnSearchAuthenticationError",
    # Data classes - Agent API
    "SearchResult",
    "SearchResponse",
    "ExtractedContent",
    "ExtractResponse",
    "ResearchResponse",
    # Data classes - RAG API
    "RAGSource",
    "RAGResearchResponse",
    "RAGSearchResponse",
    "SemanticSearchResult",
    # Data classes - Neural API
    "NeuralSearchResult",
    "NeuralSearchResponse",
    "SimilarContentResponse",
    "Highlight",
    "SearchPrediction",
    # Data classes - Enhanced API
    "EnhancedScrapeResult",
    "ChunkResult",
    # Data classes - Knowledge Graph API
    "Entity",
    "Relationship",
    "Person",
    # Data classes - Agent Registration API
    "AgentAccessInfo",
    "AgentRegisterResponse",
    "AgentStatusResponse",
    # Data classes - Monitoring API
    "TopicMonitor",
    "MonitorResult",
    # Data classes - Verification API
    "SourceEvidence",
    "ClaimVerificationResponse",
    "SourceCredibilityResponse",
]
