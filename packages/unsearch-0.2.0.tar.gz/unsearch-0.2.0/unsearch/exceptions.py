"""
UnSearch SDK exceptions.
"""


class UnSearchError(Exception):
    """Base exception for UnSearch SDK."""
    pass


class UnSearchAPIError(UnSearchError):
    """API request error with status code and response."""
    
    def __init__(self, message: str, status_code: int = None, response: str = None):
        super().__init__(message)
        self.status_code = status_code
        self.response = response


class UnSearchRateLimitError(UnSearchAPIError):
    """Rate limit exceeded."""
    pass


class UnSearchAuthenticationError(UnSearchAPIError):
    """Authentication failed."""
    pass
