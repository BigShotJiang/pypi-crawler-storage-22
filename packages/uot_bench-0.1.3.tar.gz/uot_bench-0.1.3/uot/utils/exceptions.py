

class InvalidConfigurationException(Exception):
    pass