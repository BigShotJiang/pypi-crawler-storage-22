"""
Basic example of UPD XML generation

This example shows the minimal setup required to generate a UPD document.
"""

from upd_builder import Upd970
import uuid
from datetime import datetime

# Define document header information
upd_head = {
    "guid_doc": str(uuid.uuid4()),
    "upd_number": "1",
    "upd_date_yyyymmdd": "20260106",
    "upd_date_russian": "06.01.2026",
    "СтоимВсего": "100000.00",
    "СтоимБезНДСВсего": "100000.00",
    "СумНал": "00.00",
    "ВремИнфПр": "12.00.01",
    "СодОпер": "Услуги оказаны в полном объеме",
    "Должность": "Генеральный директор",
}

# Seller information
upd_seller = {
    "guid": "78132234335_7221314401",
    "НаимОрг": "ООО \"Ромашка\"",
    "ИНН": "78132234335",
    "КПП": "7221314401",
    "КодРегион": "78",
    "НаимРегион": "Санкт-Петербург",
    "Город": "Санкт-Петербург",
    "Индекс": "196155",
    "Улица": "ул Думская",
    "Дом": "1",
    "Кварт": "1",
    "Фамилия": "Иванов",
    "Имя": "Иван",
    "Отчество": "Иванович",

}

# Buyer information
upd_buyer = {
    "guid": "7723432423_723423423",
    "НаимОрг": "ООО \"КУЛЕР\"",
    "ИНН": "7723432423",
    "КПП": "723423423",
    "КодРегион": "77",
    "НаимРегион": "Москва",
    "Город": "Москва",
    "Индекс": "125444",
    "Улица": "пл. Ленина",
    "Дом": "1",
}

# Items/goods
upd_table = [
    {
        "НомСтр": "1",
        "Товар": "Услуга консультации",
        "ОКЕИ": "796",
        "НаимЕдИзм": "шт",
        "Кол": "1",
        "Цена": "100000.00",
        "СтоимостьБезНДС": "100000.00",
        "Стоимость": "100000.00",
        "НДС": "00.00",
        "ПрТовРаб": "3",
    }
]

# Basis documents (契約書など)
upd_docs = [
    {
        "РеквНаимДок": "Договор об оказании услуг",
        "РеквНомерДок": "123",
        "РеквДатаДок": "01.01.2026",
    }
]

# Generate UPD XML
upd = Upd970(upd_head, upd_buyer, upd_seller, upd_table, upd_docs)
xml_file = upd.create_xml('/tmp/upd_output')
print(f"✅ UPD generated successfully!")
print(f"📄 File: {xml_file}")
