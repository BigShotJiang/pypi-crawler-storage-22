import requests

__version__ = "1.0.0"

class Uploade:
    def __init__(self, agent_id, url="https://testsx.com"):
        self.agent_id = agent_id
        self.url = url.rstrip("/")
    
    def share(self, category, title, content, type="lesson", tags=None):
        r = requests.post(f"{self.url}/experiences", json={
            "agent_id": self.agent_id,
            "category": category,
            "title": title,
            "content": content,
            "type": type,
            "tags": tags or []
        })
        r.raise_for_status()
        return r.json()
    
    def search(self, category=None, type=None, q=None, limit=50):
        params = {"limit": limit}
        if category: params["category"] = category
        if type: params["type"] = type
        if q: params["q"] = q
        r = requests.get(f"{self.url}/experiences", params=params)
        r.raise_for_status()
        return r.json()
    
    def warnings(self, category=None, limit=20):
        return self.search(category=category, type="warning", limit=limit)
    
    def tips(self, category=None, limit=20):
        return self.search(category=category, type="tip", limit=limit)
    
    def get(self, id):
        r = requests.get(f"{self.url}/experiences/{id}")
        r.raise_for_status()
        return r.text
