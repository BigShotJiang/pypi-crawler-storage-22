from upplib import *
from upplib.index import *


def get_file(file_path: str = None,
             path_startswith: str = None,
             startswith: str = None,
             path_contain: str = None,
             contain: str = None,
             sort_asc: bool | None = True,
             path_endswith: str = None,
             endswith: str = None) -> list[str]:
    """
    有关文件的操作
    查询指定文件夹下面的所有的文件信息, 也可以是指定的文件
    file_path         : 文件路径
    path_startswith   : 文件路径,以 path_startswith 开头
    startswith        : 文件名称,以 startswith 开头
    path_contain      : 文件路径,含有
    contain           : 文件名称,含有
    sort_asc          : 是否按升序排序，也就是从小到大排序
    path_endswith     : 文件路径,以 path_endswith 结尾
    endswith          : 文件名称,以 endswith 结尾
    return list
    """
    if file_path is None:
        file_path = os.path.dirname(os.path.abspath('.'))
    list_data = []
    get_file_all(file_path, list_data, path_startswith, startswith, path_contain, contain, path_endswith, endswith)
    # 去一下重复的数据
    r_list = list(set(list_data))
    if sort_asc is not None:
        if sort_asc:
            r_list.sort(reverse=False)
        else:
            r_list.sort(reverse=True)
    return r_list


def get_file_folder(file_name_one: str = None) -> str:
    """
    返回这个文件的文件夹路径
    param file_name_one : 这个文件的全路径
    return str : 这个文件的文件夹路径
    """
    file_sep = '\\' if is_win() else '/'
    file_name_list = file_name_one.split(file_sep)
    all_file_path = file_sep.join(file_name_list[0:-1])
    return all_file_path


def remove_folder_file(file_path: str = None,
                       path_startswith: str = None,
                       startswith: str = None,
                       path_contain: str = None,
                       contain: str = None,
                       path_endswith: str = None,
                       endswith: str = None):
    """
    删除指定文件夹下面的指定的文件
    """
    file_part_all_list = get_file(file_path=file_path,
                                  path_startswith=path_startswith,
                                  startswith=startswith,
                                  path_contain=path_contain,
                                  contain=contain,
                                  path_endswith=path_endswith,
                                  endswith=endswith)
    for file_part_all_one in file_part_all_list:
        os.remove(file_part_all_one)


def get_folder(file_path: str = None,
               startswith: str = None,
               contain: str = None,
               endswith: str = None) -> list[str]:
    """
    有关文件的操作, 只查询文件夹
    查询指定文件夹下面的所有的文件信息, 也可以是指定的文件
    param list
    return list
    """
    if file_path is None:
        file_path = os.path.dirname(os.path.abspath('.'))
    list_data = []
    get_folder_all(file_path, list_data, startswith, contain, endswith)
    # 去一下重复的数据
    return list(set(list_data))


# 是否包含指定的文件
def contain_file(file_path: str = None,
                 startswith: str = None,
                 contain: str = None,
                 endswith: str = None) -> bool:
    return len(get_file(file_path, startswith, contain, endswith)) > 0


def get_file_data_line(file_path: str = None,
                       find_str: str = 'find_str',
                       from_last: bool = True) -> str | None:
    """
    在指定的文件夹中查找包含指定字符串的数据
    file_path : 文件路径
    find_str : 查找的字符串
    from_last : 是否从文件的最后开始查找
    """
    file_list = get_file(file_path)
    for one_file in file_list:
        one_list = to_list(one_file)
        i = 0
        if from_last:
            i = len(one_list) - 1
        while -1 < i < len(one_list):
            one_line = one_list[i]
            if from_last:
                i -= 1
            else:
                i += 1
            if one_line.find(find_str) > -1:
                return one_line
    return None


# 查询指定文件夹下面的所有的文件信息, 也可以是指定的文件
def get_file_all(file_path: str = None,
                 list_data: list = None,
                 path_startswith: str = None,
                 startswith: str = None,
                 path_contain: str = None,
                 contain: str = None,
                 path_endswith: str = None,
                 endswith: str = None) -> None:
    if os.path.isdir(file_path):
        for root, dir_names, file_names in os.walk(file_path):
            for file_name in file_names:
                if (get_file_check(os.path.join(root, file_name), path_startswith, path_contain, path_endswith)
                        and get_file_check(file_name, startswith, contain, endswith)):
                    list_data.append(os.path.join(root, file_name))
            for dir_name in dir_names:
                get_file_all(os.path.join(root, dir_name), list_data, path_startswith, startswith, path_contain, contain, path_endswith, endswith)
    elif (get_file_check(file_path, startswith, contain, endswith)
          and get_file_check(file_path, path_startswith, path_contain, path_endswith)):
        list_data.append(file_path)


# 查询指定文件夹下面的所有的文件信息, 也可以是指定的文件
def get_folder_all(file_path: str = None,
                   list_data: list = None,
                   startswith: str = None,
                   contain: str = None,
                   endswith: str = None) -> None:
    if os.path.isdir(file_path):
        for root, dir_names, file_names in os.walk(file_path):
            for dir_name in dir_names:
                dir_name_path = os.path.join(root, dir_name)
                if get_file_check(dir_name_path, startswith, contain, endswith):
                    list_data.append(dir_name_path)
                else:
                    get_folder_all(dir_name_path, list_data, startswith, contain, endswith)


def get_file_check(name: str = None,
                   startswith: str = None,
                   contain: str = None,
                   endswith: str = None) -> bool:
    """
    检查文件是否符合要求
    startswith  : 以这个开头
    contain     : 包含这个字符
    endswith    : 以这个结尾
    """
    if name is None or name == '':
        return False
    p = True
    c = True
    s = True
    if startswith is not None:
        p = name.startswith(startswith)
    if contain is not None:
        c = name.find(contain) > -1
    if endswith is not None:
        s = name.endswith(endswith)
    return p and c and s


def find_file_by_content(file_path: str = '',
                         contain_txt: str = None,
                         startswith: str = None,
                         contain: str = None,
                         endswith: str = None) -> bool | None:
    """
    检查文件内容是否包含指定的字符串
    慎用,否则, 执行时间可能比较长
    """
    list_file = get_file(file_path, startswith, contain, endswith)
    if len(list_file) == 0:
        to_log(f'no_matched_file : {file_path} , {contain_txt} , {startswith} , {contain} , {endswith}')
        return False
    if contain_txt is None:
        to_log(list_file)
        return True
    for one_file in list_file:
        try:
            text_file = open(one_file, 'r', encoding='utf-8')
            for line in text_file.readlines():
                if line.find(contain_txt) > -1:
                    if line.endswith('\n'):
                        line = line[0:-1]
                    to_log(one_file, line)
        except Exception as e:
            to_log(one_file, e)
            continue

# print(get_file_data_line(r'D:\notepad_file\202306\a.txt', 'payout', from_last=False))

# file_all = get_file(r'C:\Users\yang\Desktop\ticket\no.use', path_contain='03')
#
# for one_file in file_all:
#     print(one_file)

# get_file_data_line(r'D:\notepad_file\202306', 'a')
# get_file_by_content(r'D:\notepad_file\202306', 'a')
# print(get_file(r'D:\notepad_file\202306', 'a'))
# print(get_file(r'D:\notepad_file\202306'))
# print(get_file())
# print(os.path.abspath('.'))

#
# a_list = get_folder(r'D:\code\20220916\a-java\platform', contain='build')
# for a1 in a_list:
#     os.remove(a1)
#
# print(json.dumps(a_list))

# print('end')
