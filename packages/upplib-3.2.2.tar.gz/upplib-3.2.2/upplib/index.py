from upplib import *
from datetime import datetime, timezone, timedelta
from typing import Any, Optional, Union
from upplib.common_package import *
from upplib.file import get_file
from collections import defaultdict

__CONFIG_PATH = '.upp.config'

__CONFIG_PATH_BAK = '_upp.config'

# 创建一个线程本地存储对象
__THREAD_LOCAL_INDEX_DATA = threading.local()


def get_thread_local_index_data() -> dict[str, Any]:
    if not hasattr(__THREAD_LOCAL_INDEX_DATA, 'data'):
        __THREAD_LOCAL_INDEX_DATA.data = {}
    return __THREAD_LOCAL_INDEX_DATA.data


def is_all_chinese(text: str) -> bool:
    return bool(re.compile(r'^[\u4e00-\u9fff]+$').match(text))


def remove_chinese(text: str) -> str:
    return re.compile(r'[\u4e00-\u9fff]+').sub('', text)


def rreplace(s: str,
             old: str,
             new: str,
             count: int = 1) -> str:
    return new.join(s.rsplit(old, count))


def to_java_one(s: str) -> str:
    """
    将下划线命名转成驼峰命名
    例如 : user_id -> userId
    例如 : USER_ID -> userId
    例如 : gpsMaxMove_new -> gpsMaxMoveNew
    """
    if s is None or s == '':
        return ''
    r = ''.join(list(map(lambda x: (x[0].upper() + x[1:]) if len(x) > 1 else x[0].upper(), str(s).split('_'))))
    return r[0].lower() + r[1:]


def to_java(s: None | str | list[str] | tuple[str] | set[str]) -> None | str | list[str]:
    if s is None or s == '':
        return s
    if isinstance(s, list) or isinstance(s, tuple) or isinstance(s, set):
        return list(map(lambda x: to_java_one(x), s))
    return to_java_one(s)


def to_java_more(*args: Any) -> None | tuple:
    # 使用列表推导式进行过滤和映射
    r = [to_java(x) for x in args if x is not None]
    if not r:
        return None
    return tuple(r)


def to_underline_one(s: str) -> None | str:
    """
    将驼峰命名转成下划线命名
    例如: userId -> user_id
    """
    if not s:
        return s
    return ''.join(['_' + c.lower() if c.isupper() else c for c in s])


def to_underline(s: None | str | list[str] | tuple[str] | set[str]) -> None | str | list[str]:
    if s == '' or s is None:
        return s
    if isinstance(s, list) or isinstance(s, tuple) or isinstance(s, set):
        return list(map(lambda x: to_underline_one(x), s))
    return to_underline_one(s)


def to_underline_more(*args: Any) -> None | tuple:
    # 使用列表推导式进行过滤和映射
    r = [to_underline(x) for x in args if x is not None]
    if not r:
        return None
    return tuple(r)


# 是否能用 json
def is_json_serializable(param: Any) -> bool:
    # 排除不能被 json 序列化的类型
    if isinstance(param, (bytes, complex, str, int, bool, float)):
        return False
    try:
        json.dumps(param)
        return True
    except (TypeError, OverflowError):
        return False


def is_json(myjson: Any) -> bool:
    """
    判断字符串是否是有效的JSON格式

    参数:
        myjson (str): 要检查的字符串

    返回:
        bool: 如果是有效JSON返回True，否则返回False
    """
    try:
        json.loads(myjson)
    except (ValueError, TypeError):
        return False
    return True


# 文件是否存在
def file_is_empty(file_name: str) -> bool:
    return file_name is None or file_name == '' or not os.path.exists(file_name)


# md5 算法
def do_md5(s: str) -> str:
    return hashlib.md5(s.encode(encoding='UTF-8')).hexdigest()


# sha256 算法
def do_sha256(s: str) -> str:
    h = hashlib.sha256()
    h.update(s.encode('utf-8'))
    return h.hexdigest()


# uuid 类型的随机数, 默认 32 位长度
def random_uuid(length: int = 32) -> str:
    r = uuid.uuid4().hex
    while len(r) < length:
        r += uuid.uuid4().hex
    return r[0:length]


def random_str(length: int = 64,
               start_str: int = 1,
               end_str: int = 32) -> str:
    """
    获得随机数
    length    ：随机数长度
    start_str ：随机数开始的字符的位置,从 1 开始, 包含start_str
    end_str   : 随机数结束的字符的位置, 不包含end_str
    默认的随机数是 : 数字+字母大小写
    """
    c_s = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789-_'
    r = ''
    start_str = max(1, start_str)
    end_str = min(len(c_s), end_str)
    while len(r) < length:
        r += c_s[random.Random().randint(start_str, end_str) - 1]
    return r


# 字母的随机数, 默认小写
def random_letter(length: int = 10,
                  is_upper: bool = False) -> str:
    r = random_str(length=length, end_str=26)
    return r.upper() if is_upper else r


def random_int(length_or_start: int = 10,
               end: int = None) -> int:
    """
    数字的随机数, 返回 int
    也可以返回指定范围的随机数据
    """
    if end is None:
        return int(random_int_str(length=length_or_start))
    return random.Random().randint(int(length_or_start), int(end) - 1)


# 数字的随机数, 返回 str
def random_int_str(length: int = 10) -> str:
    return random_str(length=length, start_str=53, end_str=62)


def format_fixed_length_string(value: Any, target_length: int) -> str:
    """
    格式化字符串到指定长度，不足左补0，超出则保留右边字符。
    """
    value = str(value)
    if len(value) >= target_length:
        return value[-target_length:]
    return value.zfill(target_length)


# 去掉 str 中的 非数字字符, 然后, 再转化为 int
def to_int(s: Any = None) -> int:
    """
    去掉字符串中的非数字字符（保留小数点），并转为 int 类型。
    如果是 float 类型则转为 int（直接截断小数部分）。
    如果无法解析为数字，返回 0。
    """
    if s is None:
        return 0
    if isinstance(s, int):
        return s
    if isinstance(s, float):
        return int(s)
    s = str(s).strip()
    if not s:
        return 0
    negative = s.startswith('-')
    s_clean = re.sub(r'[^\d.]', '', s)
    if not s_clean or s_clean.count('.') > 1:
        return 0  # 防止非法格式如 "12.3.4"
    cleaned = f"-{s_clean}" if negative else s_clean
    try:
        # 支持带小数点的转 int（自动舍弃小数部分）
        return int(float(cleaned))
    except ValueError:
        return 0


def to_float(s: Any = None,
             precision: int = None) -> float:
    """
    将字符串中的非数字字符（除了小数点）去掉后转为 float。

    :param s: 输入值（可以是字符串或其他类型）
    :param precision: 小数部分保留的位数（多余部分直接截断）
    :return: 转换后的 float 值
    """
    if not s:
        return 0.0
    s = str(s).strip()
    if not s:
        return 0.0
    negative = s.startswith('-')
    # 提取所有数字和小数点
    s_clean = re.sub(r'[^\d.]', '', s)
    if not s_clean or s_clean.count('.') > 1:
        return 0.0  # 避免多个小数点造成 float 转换失败
    cleaned = f"-{s_clean}" if negative else s_clean
    try:
        value = float(cleaned)
    except ValueError:
        return 0.0
    if precision is not None:
        int_part, _, dec_part = cleaned.partition('.')
        dec_part = dec_part[:precision]
        cleaned = f"{int_part}.{dec_part}" if dec_part else int_part
        try:
            value = float(cleaned)
        except ValueError:
            return 0.0
    return value


def to_datetime(
        s: Any = None,
        pattern: str = None,
        r_str: bool = False,
        error_is_none: bool = False,
        tz: Optional[Union[str, timezone]] = None,
        default_tz: Union[str, timezone] = None
) -> Union[datetime, str, None]:
    """
    将字符串或时间戳转换为 datetime 对象，支持时区处理。
    error_is_none : 当发生错误的时候，是否返回 None
    """
    # 默认时区为 +08:00
    default_tz = default_tz or '+08:00'

    def get_tz(tz_info: Union[str, timezone]) -> timezone:
        """将时区信息转换为timezone对象"""
        if isinstance(tz_info, timezone):
            return tz_info
        if not isinstance(tz_info, str):
            raise ValueError(f"无效的时区格式: {tz_info}")
        tz_str = tz_info.upper()
        if tz_str == "UTC":
            return timezone.utc
        # 处理纯偏移格式，如+07:00、-05:30
        offset_match = re.match(r"^([+-])(\d{1,2}):(\d{2})$", tz_str)
        if offset_match:
            sign = offset_match.group(1)
            hours = int(offset_match.group(2))
            minutes = int(offset_match.group(3))
            # 计算总偏移小时数
            total_hours = hours + minutes / 60
            if sign == "-":
                total_hours = -total_hours
            return timezone(timedelta(hours=total_hours))
        # 处理GMT格式，如GMT+08:00或GMT-5
        gmt_match = re.match(r"GMT([+-]\d{1,2})(:\d{2})?$", tz_str)
        if gmt_match:
            hours = int(gmt_match.group(1))
            return timezone(timedelta(hours=hours))
        # 处理UTC格式，如UTC+8或UTC-05:00
        utc_match = re.match(r"UTC([+-]\d{1,2})(:\d{2})?$", tz_str)
        if utc_match:
            hours = int(utc_match.group(1))
            return timezone(timedelta(hours=hours))
        raise ValueError(f"不支持的时区格式: {tz_info}")

    use_default_time = False
    if s is None or s == '':
        dt = datetime.now(get_tz(default_tz))
    else:
        s = str(s).strip()
        dt = None

        # 1. 尝试解析时间戳
        if re.match(r"^\d{1,19}$", s):
            timestamp = int(s)
            if len(s) > 10:  # 毫秒级时间戳
                timestamp = timestamp // 1000
            # 先转为无时区的 datetime
            dt = datetime.fromtimestamp(timestamp)
            dt = dt.replace(tzinfo=get_tz(default_tz))

        # 2. 尝试解析 ISO 8601 格式
        if dt is None:
            try:
                dt = datetime.fromisoformat(s)
            except ValueError:
                pass

        # 3. 尝试解析带GMT时区的格式，如'2025/09/16 17:32:17.896 GMT+08:00'
        if dt is None:
            gmt_pattern = r"^(\d{4})[/-](\d{2})[/-](\d{2}) (\d{2}):(\d{2}):(\d{2})(\.\d+)? (GMT[+-]\d{1,2}(:\d{2})?)$"
            match = re.match(gmt_pattern, s)
            if match:
                try:
                    # 提取日期时间部分
                    year, month, day = map(int, match.group(1, 2, 3))
                    hour, minute, second = map(int, match.group(4, 5, 6))
                    microsecond = 0
                    if match.group(7):
                        # 处理毫秒/微秒部分
                        microsecond = int(float(match.group(7)) * 1e6)

                    # 创建datetime对象
                    dt = datetime(year, month, day, hour, minute, second, microsecond)

                    # 应用时区
                    tz_info = get_tz(match.group(8))
                    dt = dt.replace(tzinfo=tz_info)
                except ValueError:
                    pass

        # 4. 使用指定的pattern解析
        if dt is None and pattern is not None:
            try:
                # 移除可能的毫秒部分
                s_without_ms = s.split('.')[0]
                dt = datetime.strptime(s_without_ms, pattern)
            except ValueError:
                pass

        # 5. 尝试解析YYYY-MM-DD HH:MM:SS或YYYY/MM/DD HH:MM:SS格式
        if dt is None:
            # 尝试处理不带时区的格式
            formats = ["%Y-%m-%d %H:%M:%S", "%Y/%m/%d %H:%M:%S"]
            for fmt in formats:
                try:
                    # 移除可能的毫秒和时区部分
                    s_clean = re.sub(r"(\.\d+)|[TZ]|GMT.*$", " ", s).strip()
                    dt = datetime.strptime(s_clean, fmt)
                    break
                except ValueError:
                    continue

            if dt is None:
                use_default_time = True
                dt = datetime.now()

        # 确保无时区时附加默认时区
        if dt.tzinfo is None:
            dt = dt.replace(tzinfo=get_tz(default_tz))

    # 转换为目标时区
    if tz is not None:
        dt = dt.astimezone(get_tz(tz))

    if error_is_none and use_default_time:
        return None

    return dt.isoformat() if r_str else dt


# 将字符串 s 转化成 datetime, 然后再次转化成 str
def to_datetime_str(s: Any = None,
                    pattern: str = None,
                    pattern_str: str = None,
                    tz: Optional[Union[str, timezone]] = None,
                    default_tz: Union[str, timezone] = None) -> datetime | str:
    """
    将 s 先转成 datetime, 然后再转成字符串

    :param s: 输入值（可以是字符串或其他类型）
    """
    r_s = to_datetime(s, pattern=pattern, tz=tz, r_str=False, default_tz=default_tz)
    if pattern_str is None:
        iso_str = r_s.isoformat()
        if '.' not in iso_str:
            # '2025-10-09T10:52:41+08:00'
            return iso_str
        parts = iso_str.split('.')
        time_zone_part = parts[1]
        time_zone_str = tz
        millisecond_part = time_zone_part[:3]
        for a in ['+', '-']:
            if a in time_zone_part:
                time_zone_str = a + time_zone_part.split(a)[-1]
        return parts[0] + '.' + millisecond_part + time_zone_str
    else:
        return r_s.strftime(pattern_str)


def to_datetime_format(s: Any = None,
                       pattern_str: str = "%Y-%m-%d %H:%M:%S") -> datetime | str:
    return to_datetime_str(s, pattern=None, pattern_str=pattern_str, tz=None)


def to_datetime_format__6(s: Any = None,
                          pattern_str: str = "%Y-%m-%d %H:%M:%S") -> datetime | str:
    return to_datetime_str(s, pattern=None, pattern_str=pattern_str, tz='-06:00')


def to_datetime_format_7(s: Any = None,
                         pattern_str: str = "%Y-%m-%d %H:%M:%S") -> datetime | str:
    return to_datetime_str(s, pattern=None, pattern_str=pattern_str, tz='+07:00')


def to_datetime_format_8(s: Any = None,
                         pattern_str: str = "%Y-%m-%d %H:%M:%S") -> datetime | str:
    return to_datetime_str(s, pattern=None, pattern_str=pattern_str, tz='+08:00')


# 时间加减
def to_datetime_add(s: Any = None,
                    days: int = 0,
                    seconds: int = 0,
                    microseconds: int = 0,
                    milliseconds: int = 0,
                    minutes: int = 0,
                    hours: int = 0,
                    weeks: int = 0) -> datetime:
    return to_datetime(s) + timedelta(days=days, seconds=seconds, microseconds=microseconds,
                                      milliseconds=milliseconds, minutes=minutes, hours=hours,
                                      weeks=weeks)


# 将字符串 s 转化成 date 例如: 2021-02-03
def to_date(s: Any = None) -> str:
    return str(to_datetime(s))[0:10]


# 将字符串 s 转化成 date 例如: 20210203
def to_date_number(s: Any = None) -> str:
    return str(to_datetime(s))[0:10].replace('-', '')


def get_timestamp(s: Any = None) -> int:
    """获取 Unix 秒级时间戳"""
    return int(to_datetime(s).timestamp())


def get_datetime_number_str(s: Any = None,
                            length: int = None,
                            remove_dz: bool = True,
                            ) -> str:
    """获取 datetime , 然后转成字符串, 然后, 只保留数字
        Args:
            s: 输入值，可以是任何类型，如果是None则使用当前时间
            length: 可选参数，指定返回字符串的长度
            remove_dz: 是否去掉时区
        Returns:
            str: 只包含数字的字符串
        """
    s1 = to_datetime(s)
    digits_only = re.sub(r'\D', '', str(s1))
    # 如果指定了长度，取最后length位
    if length is not None and length > 0:
        return digits_only[-length:] if len(digits_only) > length else digits_only
    if len(digits_only) > 4 and remove_dz:
        digits_only = digits_only[:-4]
    return digits_only


def get_timestamp_ms(s: Any = None) -> int:
    """获取 Unix 毫秒级时间戳"""
    return int(to_datetime(s).timestamp() * 1000)


# 时间加减
def to_date_add(s: Any = None,
                days: int = 0,
                seconds: int = 0,
                microseconds: int = 0,
                milliseconds: int = 0,
                minutes: int = 0,
                hours: int = 0,
                weeks: int = 0) -> str:
    return str(to_datetime_add(s=s, days=days, seconds=seconds, microseconds=microseconds,
                               milliseconds=milliseconds, minutes=minutes, hours=hours, weeks=weeks))[0:10]


# 转化成字符串
def to_str(param: Any = None) -> str:
    return json.dumps(param, ensure_ascii=False) if is_json_serializable(param) else str(param)


def match_str(pattern: str,
              str_a: str = '') -> str | None:
    """
    匹配字符串
    可以参考 正则表达式的操作, 可以使用 chatgpt 帮忙写出这段代码
    @see https://www.runoob.com/python3/python3-reg-expressions.html
    # 示例用法
    # 输出：t_admin
    print(match_str(r'create TABLE (\\w+)', 'CREATE TABLE t_admin (id bigint(20) NOT NULL'))
    这里的 斜杠w 去掉一个斜杠
    """
    match = re.search(pattern, str_a, re.I)
    if match:
        return match.group(1)
    else:
        return None


def format_sorted_kv_string(data_obj: Any,
                            sep: str = '&',
                            join: str = '=',
                            join_list: str = ',') -> str:
    """
    将 dict/json-like 对象按 key 排序后格式化为字符串。
    格式为 key1=value1&key2=value2，支持嵌套结构和列表拼接。

    :param data_obj: 任意结构的数据，如 dict、list、基础类型
    :param sep: 键值对之间的分隔符，默认 '&'
    :param join: key 与 value 的连接符，默认 '='
    :param join_list: 列表等多值类型的连接符，默认 ','
    :return: 格式化后的字符串
    """
    if isinstance(data_obj, (list, tuple, set)):
        return join_list.join(map(str, data_obj))

    if not isinstance(data_obj, dict):
        return str(data_obj)

    # 对 dict 按 key 排序
    sorted_items = sorted(data_obj.items(), key=lambda x: x[0])
    result = []

    for key, value in sorted_items:
        if is_json_serializable(value):
            value_str = format_sorted_kv_string(value, sep=sep, join=join, join_list=join_list)
        else:
            value_str = str(value)
        result.append(f"{key}{join}{value_str}")

    return sep.join(result)


# 将数据写入到 config 中
def set_config_data(file_name: str = 'config',
                    param: dict[str, Any] = None) -> None:
    set_data_in_user_home(file_name, {} if param is None else param)


# 从 config 中获得 配置数据
def get_config_data(file_name: str = 'config') -> dict[str, Any]:
    # print('get_config_data', file_name)
    config_data = get_data_from_user_home(file_name)
    # print('get_data_from_user_home', config_data)
    if not config_data:
        config_data = get_data_from_path(file_name)
    # print('get_data_from_path', config_data)
    return config_data


# 在当前用户的主目录中, 获得指定文件的数据
def get_data_from_user_home(file_name: str = 'config') -> dict[str, Any]:
    return get_data_from_path(file_name, os.path.expanduser("~"))


# 将 data 数据,在当前用户的主目录中, 获得指定文件的数据
def set_data_in_user_home(file_name: str = 'config',
                          param: dict[str, Any] = None) -> None:
    set_data_in_path(file_name, {} if param is None else param, os.path.expanduser("~"))


# 在当前的目录中, 获得指定文件的数据
def get_data_from_path(file_name: str = 'config',
                       file_path: str = None) -> dict[str, Any]:
    param = get_data_from_path_detail(file_name, file_path, __CONFIG_PATH)
    return param if param else get_data_from_path_detail(file_name, file_path, __CONFIG_PATH_BAK)


def get_data_from_path_detail(file_name: str = 'config',
                              file_path: str = None,
                              path_name: str = __CONFIG_PATH) -> dict[str, Any]:
    config_path = file_path + '/' + path_name if file_path else path_name
    # print('config_path_1', config_path)
    if not os.path.exists(config_path):
        # print('config_path_2', config_path)
        return {}
    file_path = config_path + '/' + file_name + '.json'
    # print('config_path_3', file_path)
    if not os.path.exists(file_path):
        return {}
    # print('to_json_from_file', file_path)
    return to_json_from_file(file_path)


# 在当前的目录中, 设置数据到指定路径下
def set_data_in_path(file_name: str = 'config',
                     param: str = None,
                     file_path: str = '') -> None:
    config_path = file_path + '/' + __CONFIG_PATH
    if not os.path.exists(config_path):
        os.mkdir(config_path)
    file_path = config_path + '/' + file_name + '.json'
    text_file = open(file_path, 'w', encoding='utf-8')
    text_file.write(to_str({} if param is None else param))
    text_file.close()


# 执行命令
def exec_command(command: str = None) -> None:
    if command is None:
        return
    try:
        subprocess.run(command, shell=True, check=True)
    except subprocess.CalledProcessError as e:
        print(f"command executed error: {e}")


# 是否是 windows 系统
def is_win() -> bool:
    return platform.system().lower() == 'windows'


# 是否是 linux 系统, 不是 windows , 就是 linux 系统
def is_linux() -> bool:
    return not is_win()


def list_group_by(data_list: list[list],
                  group_by_index: int = 0) -> list[list[list]]:
    """
    将一个 list 分组
    例如:
    data_list = [
        ['a', 1, 2],
        ['b', 4, 5],
        ['c', 2, 1],
        ['c', 6, 2],
        ['c', 4, 0],
        ['b', 1, 3]
    ]
    返回:
    [
        [
            ['a', 1, 2]
        ],
        [
            ['b', 4, 5], ['b', 1, 3]],
        [
            ['c', 2, 1], ['c', 6, 2], ['c', 4, 0]
        ]
    ]
    """
    groups = defaultdict(list)
    for item in data_list:
        key = item[group_by_index]
        groups[key].append(item)
    r_list = []
    for key, group in groups.items():
        r_list.append(group)
    return r_list


def get_and_save_data_to_thread(file_path: str = None,
                                file_name: str = None,
                                file_name_prefix: str = None,
                                file_name_suffix: str = None,
                                interval: int = None,
                                line_with_space_count: int = None,
                                mode: str = 'a',
                                file_name_with_date: bool = False,
                                fun_name: callable = None) -> list:
    """
    将一些参数写入到 thread local 中, 方便后续使用
    """
    # 使用线程本地存储来存储文件路径和文件名称
    if file_name_with_date:
        file_name = get_file_name(file_name=file_path if file_name is None else file_name, is_date=True, suffix='')
    get_thread_local_index_data()['_use_fun_flag'] = True if mode != 'a' else get_thread_local_index_data().get(
        '_use_fun_flag', False)
    fun_name_str = fun_name.__name__
    # 存储函数引用
    get_thread_local_index_data()['_use_fun'] = fun_name
    r_list = []
    # 输出非空字段
    for key, value in {
        'file_path': file_path,
        'file_name': file_name,
        'file_name_prefix': file_name_prefix,
        'file_name_suffix': file_name_suffix,
        'interval': interval,
        'line_with_space_count': line_with_space_count,
    }.items():
        this_key = f'{fun_name_str}__{key}'
        value_temp = value if value is not None else get_thread_local_index_data().get(this_key, None)
        get_thread_local_index_data()[this_key] = value_temp
        r_list.append(value_temp)
    return r_list


def get_file_name(file_name: str = None,
                  suffix: str = '.txt',
                  is_date: bool = False) -> str:
    """
    获得文件名称
    按照  name_天小时分钟_秒毫秒随机数 的规则来生成
    """
    # %Y-%m-%d %H:%M:%S
    [year, month, day, hour, minute, second, ss] = datetime.today().strftime('%Y_%m_%d_%H_%M_%S_%f').split('_')
    s = year + month + day + hour + minute if is_date else month + day + hour + minute
    # 在 file_name 中, 检查是否有后缀
    if '.' in file_name:
        suffix = '.' + file_name.split('.')[-1]
        file_name = file_name[0:file_name.rfind('.')]
    # return str(file_name) + '_' + s + '_' + second + '-' + random_int_str(length=2) + suffix
    # 202506161803_4112
    return str(file_name) + '_' + s + '_' + second + random_int_str(length=2) + suffix


def to_list_list(data_list: list = None,
                 count: int = 10) -> list:
    """
    将 list 切分成 list(list)
    组成一个 list(list) 数据
    多行空行,自动合并到一行空行
    """
    if data_list is None:
        data_list = []
    r_list = []
    o_list = []
    c = 0
    for i in range(len(data_list)):
        o_list.append(data_list[i])
        c += 1
        if c == count:
            r_list.append(o_list)
            o_list = []
            c = 0
    if len(o_list):
        r_list.append(o_list)
    return r_list


# 将多个文件 读取成 list
def to_list_from_txt_list(file_list: list[Any] = None) -> list:
    if file_list is None:
        file_list = []
    data_list = []
    for a in file_list:
        data_list.extend(to_list_from_txt(file_name=a))
    return data_list
