from upplib import *
from datetime import datetime, timezone, timedelta
from typing import Any, Optional, Union
from upplib.common_package import *


def get_tz(tz_info: Union[str, timezone]) -> timezone:
    """将时区信息转换为timezone对象"""
    if isinstance(tz_info, timezone):
        return tz_info
    if not isinstance(tz_info, str):
        raise ValueError(f"无效的时区格式: {tz_info}")
    tz_str = tz_info.upper()
    if tz_str == "UTC":
        return timezone.utc
    # 处理纯偏移格式，如+07:00、-05:30
    offset_match = re.match(r"^([+-])(\d{1,2}):(\d{2})$", tz_str)
    if offset_match:
        sign = offset_match.group(1)
        hours = int(offset_match.group(2))
        minutes = int(offset_match.group(3))
        # 计算总偏移小时数
        total_hours = hours + minutes / 60
        if sign == "-":
            total_hours = -total_hours
        return timezone(timedelta(hours=total_hours))
    # 处理GMT格式，如GMT+08:00或GMT-5
    gmt_match = re.match(r"GMT([+-]\d{1,2})(:\d{2})?$", tz_str)
    if gmt_match:
        hours = int(gmt_match.group(1))
        return timezone(timedelta(hours=hours))
    # 处理UTC格式，如UTC+8或UTC-05:00
    utc_match = re.match(r"UTC([+-]\d{1,2})(:\d{2})?$", tz_str)
    if utc_match:
        hours = int(utc_match.group(1))
        return timezone(timedelta(hours=hours))
    raise ValueError(f"不支持的时区格式: {tz_info}")


def to_datetime(s: Any = None,
                pattern: str = None,
                r_str: bool = False,
                error_is_none: bool = False,
                tz: Optional[Union[str, timezone]] = None,
                default_tz: Union[str, timezone] = None) -> Union[datetime, str, None]:
    """
    将字符串或时间戳转换为 datetime 对象，支持时区处理。
    error_is_none : 当发生错误的时候，是否返回 None
    """
    # 默认时区为 +08:00
    default_tz = default_tz or '+08:00'

    use_default_time = False
    if s is None or s == '':
        dt = datetime.now(get_tz(default_tz))
    else:
        s = str(s).strip()
        dt = None

        # 1. 尝试解析时间戳
        if re.match(r"^\d{1,19}$", s):
            timestamp = int(s)
            if len(s) > 10:  # 毫秒级时间戳
                timestamp = timestamp // 1000
            # 先转为无时区的 datetime
            dt = datetime.fromtimestamp(timestamp)
            dt = dt.replace(tzinfo=get_tz(default_tz))

        # 2. 尝试解析 ISO 8601 格式
        if dt is None:
            try:
                dt = datetime.fromisoformat(s)
            except ValueError:
                pass

        # 3. 尝试解析带GMT时区的格式，如'2025/09/16 17:32:17.896 GMT+08:00'
        if dt is None:
            gmt_pattern = r"^(\d{4})[/-](\d{2})[/-](\d{2}) (\d{2}):(\d{2}):(\d{2})(\.\d+)? (GMT[+-]\d{1,2}(:\d{2})?)$"
            match = re.match(gmt_pattern, s)
            if match:
                try:
                    # 提取日期时间部分
                    year, month, day = map(int, match.group(1, 2, 3))
                    hour, minute, second = map(int, match.group(4, 5, 6))
                    microsecond = 0
                    if match.group(7):
                        # 处理毫秒/微秒部分
                        microsecond = int(float(match.group(7)) * 1e6)

                    # 创建datetime对象
                    dt = datetime(year, month, day, hour, minute, second, microsecond)

                    # 应用时区
                    tz_info = get_tz(match.group(8))
                    dt = dt.replace(tzinfo=tz_info)
                except ValueError:
                    pass

        # 4. 使用指定的pattern解析
        if dt is None and pattern is not None:
            try:
                # 移除可能的毫秒部分
                s_without_ms = s.split('.')[0]
                dt = datetime.strptime(s_without_ms, pattern)
            except ValueError:
                pass

        # 5. 尝试解析YYYY-MM-DD HH:MM:SS或YYYY/MM/DD HH:MM:SS格式
        if dt is None:
            # 尝试处理不带时区的格式
            formats = ["%Y-%m-%d %H:%M:%S", "%Y/%m/%d %H:%M:%S"]
            for fmt in formats:
                try:
                    # 移除可能的毫秒和时区部分
                    s_clean = re.sub(r"(\.\d+)|[TZ]|GMT.*$", " ", s).strip()
                    dt = datetime.strptime(s_clean, fmt)
                    break
                except ValueError:
                    continue

            if dt is None:
                use_default_time = True
                dt = datetime.now()

        # 确保无时区时附加默认时区
        if dt.tzinfo is None:
            dt = dt.replace(tzinfo=get_tz(default_tz))

    # 转换为目标时区
    if tz is not None:
        dt = dt.astimezone(get_tz(tz))

    if error_is_none and use_default_time:
        return None

    return dt.isoformat() if r_str else dt


# 将字符串 s 转化成 datetime, 然后再次转化成 str
def to_datetime_str(s: Any = None,
                    pattern: str = None,
                    pattern_str: str = None,
                    tz: Optional[Union[str, timezone]] = None,
                    default_tz: Union[str, timezone] = None) -> datetime | str:
    """
    将 s 先转成 datetime, 然后再转成字符串
    :type pattern: str
    :type pattern_str: str
    :type tz: str
    :type default_tz: str
    :param s: 输入值（可以是字符串或其他类型）
    """
    r_s = to_datetime(s, pattern=pattern, tz=tz, r_str=False, default_tz=default_tz)
    if pattern_str is None:
        iso_str = r_s.isoformat()
        if '.' not in iso_str:
            # '2025-10-09T10:52:41+08:00'
            return iso_str
        parts = iso_str.split('.')
        time_zone_part = parts[1]
        time_zone_str = tz
        millisecond_part = time_zone_part[:3]
        for a in ['+', '-']:
            if a in time_zone_part:
                time_zone_str = a + time_zone_part.split(a)[-1]
        return parts[0] + '.' + millisecond_part + time_zone_str
    else:
        return r_s.strftime(pattern_str)


def to_datetime_format(s: Any = None,
                       pattern_str: str = "%Y-%m-%d %H:%M:%S") -> datetime | str:
    return to_datetime_str(s, pattern=None, pattern_str=pattern_str, tz=None)


def to_datetime_format__6(s: Any = None,
                          pattern_str: str = "%Y-%m-%d %H:%M:%S") -> datetime | str:
    return to_datetime_str(s, pattern=None, pattern_str=pattern_str, tz='-06:00')


def to_datetime_format_7(s: Any = None,
                         pattern_str: str = "%Y-%m-%d %H:%M:%S") -> datetime | str:
    return to_datetime_str(s, pattern=None, pattern_str=pattern_str, tz='+07:00')


def to_datetime_format_8(s: Any = None,
                         pattern_str: str = "%Y-%m-%d %H:%M:%S") -> datetime | str:
    return to_datetime_str(s, pattern=None, pattern_str=pattern_str, tz='+08:00')


# 时间加减
def to_datetime_add(s: Any = None,
                    days: int = 0,
                    seconds: int = 0,
                    microseconds: int = 0,
                    milliseconds: int = 0,
                    minutes: int = 0,
                    hours: int = 0,
                    weeks: int = 0) -> datetime:
    return to_datetime(s) + timedelta(days=days, seconds=seconds, microseconds=microseconds,
                                      milliseconds=milliseconds, minutes=minutes, hours=hours,
                                      weeks=weeks)


# 将字符串 s 转化成 date 例如: 2021-02-03
def to_date(s: Any = None) -> str:
    return str(to_datetime(s))[0:10]


# 将字符串 s 转化成 date 例如: 20210203
def to_date_number(s: Any = None) -> str:
    return str(to_datetime(s))[0:10].replace('-', '')


def get_timestamp(s: Any = None) -> int:
    """获取 Unix 秒级时间戳"""
    return int(to_datetime(s).timestamp())


def get_datetime_number_str(s: Any = None,
                            length: int = None,
                            remove_dz: bool = True) -> str:
    """获取 datetime , 然后转成字符串, 然后, 只保留数字
        Args:
            s: 输入值，可以是任何类型，如果是None则使用当前时间
            length: 可选参数，指定返回字符串的长度
            remove_dz: 是否去掉时区
        Returns:
            str: 只包含数字的字符串
        """
    s1 = to_datetime(s)
    digits_only = re.sub(r'\D', '', str(s1))
    if len(digits_only) > 4 and remove_dz:
        digits_only = digits_only[:-4]
    # 如果指定了长度，取最后length位
    if length is not None and length > 0:
        digits_only = digits_only[-length:] if len(digits_only) > length else digits_only
    return digits_only


def get_timestamp_ms(s: Any = None) -> int:
    """获取 Unix 毫秒级时间戳"""
    return int(to_datetime(s).timestamp() * 1000)


# 时间加减
def to_date_add(s: Any = None,
                days: int = 0,
                seconds: int = 0,
                microseconds: int = 0,
                milliseconds: int = 0,
                minutes: int = 0,
                hours: int = 0,
                weeks: int = 0) -> str:
    return str(to_datetime_add(s=s, days=days, seconds=seconds, microseconds=microseconds,
                               milliseconds=milliseconds, minutes=minutes, hours=hours, weeks=weeks))[0:10]
