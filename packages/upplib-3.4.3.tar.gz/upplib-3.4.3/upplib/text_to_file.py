from upplib import *
from upplib.common_package import *
from upplib.file_function import get_file


def to_print(*args,
             time_prefix: bool = False,
             line_with_space_count: int = None,
             interval: int = None) -> str:
    """
    记录日志, 如果是对象会转化为 json
    数据直接 print, 不记录到文件
    例如: aaa
    interval: 间隔一段时间，打印一下, 单位: 秒，不要频繁打印
    time_prefix : 是否在前面加时间, 默认 False
    """
    d = ' '.join(map(lambda x: json.dumps(x) if is_json_serializable(x) else str(x), args))
    d = d.strip()
    lo = datetime.today().strftime('%Y-%m-%d %H:%M:%S') + ' ' + d if time_prefix is True else d
    if lo is None or str(lo) == '':
        lo = to_datetime(r_str=True)
    prefix_space = ' ' * (line_with_space_count or 0)
    if interval is None or get_timestamp() - get_thread_local_index_data().get('to_print_time', 0) >= interval:
        get_thread_local_index_data()['to_print_time'] = get_timestamp()
        s = ''
        if interval is not None:
            s = str(to_datetime()) + ' '
        print(prefix_space + s + str(lo))
    return prefix_space + lo


def to_log(*args,
           time_prefix: bool = False,
           line_with_space_count: int = None,
           interval: int = None) -> str:
    """
    记录日志, 如果是对象会转化为 json
    前面加了时间
    例如: 2024-11-07 10:23:47 aaa
    """
    return to_print(*args,
                    time_prefix=time_prefix if time_prefix is not None else True,
                    line_with_space_count=line_with_space_count,
                    interval=interval)


def to_print_file(*args,
                  file_path: str = None,
                  file_name: str = None,
                  file_name_with_date: bool = False,
                  file_name_prefix: str = None,
                  file_name_suffix: str = None,
                  line_with_space_count: int = None,
                  mode: str = 'a',
                  interval: int = None) -> str:
    """
    将 print 数据, 写入到 print_file 文件
    文件按照 日期自动创建
    例如: print_file/2020-01-01.txt
    to_print_file(query_string, mode='w', file_path=file_path, file_name=get_file_name(file_name=file_path, is_date=True))
    """
    [file_path, file_name, file_name_prefix, file_name_suffix, interval,
     line_with_space_count] = get_and_save_data_to_thread(
        file_path=file_path,
        file_name=file_name,
        file_name_prefix=file_name_prefix,
        file_name_suffix=file_name_suffix,
        interval=interval,
        mode=mode,
        file_name_with_date=file_name_with_date,
        line_with_space_count=line_with_space_count,
        fun_name=to_print_file
    )
    return to_txt(data_param=[to_print(*args, line_with_space_count=line_with_space_count, interval=interval)],
                  file_name=('' if file_name_prefix is None else file_name_prefix)
                            + (datetime.today().strftime('%Y-%m-%d') if file_name is None else file_name)
                            + ('' if file_name_suffix is None else file_name_suffix),
                  file_path=str(file_path if file_path is not None else 'to_print_file'),
                  mode=mode,
                  fixed_name=True,
                  suffix='.txt')


def to_print_txt(*args,
                 file_path: str = None,
                 file_name_with_date: bool = False,
                 file_name: str = None,
                 file_name_prefix: str = None,
                 file_name_suffix: str = None,
                 line_with_space_count: int = None,
                 mode: str = 'a',
                 interval: int = None) -> str:
    """
    将 print 数据, 写入到 print_txt 文件
    文件按照 日期自动创建
    例如: print_txt/2020-01-01.txt
    """
    [file_path, file_name, file_name_prefix, file_name_suffix, interval,
     line_with_space_count] = get_and_save_data_to_thread(
        file_path=file_path,
        file_name=file_name,
        file_name_prefix=file_name_prefix,
        file_name_suffix=file_name_suffix,
        interval=interval,
        mode=mode,
        file_name_with_date=file_name_with_date,
        line_with_space_count=line_with_space_count,
        fun_name=to_print_txt
    )
    return to_txt(data_param=[to_print(*args, line_with_space_count=line_with_space_count, interval=interval)],
                  file_name=('' if file_name_prefix is None else file_name_prefix)
                            + (datetime.today().strftime('%Y-%m-%d') if file_name is None else file_name)
                            + ('' if file_name_suffix is None else file_name_suffix),
                  file_path=str(file_path if file_path is not None else 'to_print_txt'),
                  mode=mode,
                  fixed_name=True,
                  suffix='.txt')


def to_log_file(*args,
                file_path: str = None,
                file_name_with_date: bool = False,
                file_name: str = None,
                file_name_prefix: str = None,
                file_name_suffix: str = None,
                line_with_space_count: int = None,
                time_prefix: bool = True,
                mode: str = 'a',
                interval: int = None) -> None:
    """
    将 log 数据, 写入到 log_file 文件
    文件按照 日期自动创建
    例如: log_file/2020-01-01.log
    """
    [file_path, file_name, file_name_prefix, file_name_suffix, interval,
     line_with_space_count] = get_and_save_data_to_thread(
        file_path=file_path,
        file_name=file_name,
        file_name_prefix=file_name_prefix,
        file_name_suffix=file_name_suffix,
        interval=interval,
        mode=mode,
        file_name_with_date=file_name_with_date,
        line_with_space_count=line_with_space_count,
        fun_name=to_log_file
    )
    to_txt(data_param=[
        to_log(*args, time_prefix=time_prefix, line_with_space_count=line_with_space_count, interval=interval)],
        file_name=('' if file_name_prefix is None else file_name_prefix)
                  + (datetime.today().strftime('%Y-%m-%d') if file_name is None else file_name)
                  + ('' if file_name_suffix is None else file_name_suffix),
        file_path=str(file_path if file_path is not None else 'to_log_file'),
        fixed_name=True,
        mode=mode,
        suffix='.log')


def to_log_txt(*args,
               file_path: str = None,
               file_name_with_date: bool = False,
               file_name: str = None,
               file_name_prefix: str = None,
               file_name_suffix: str = None,
               line_with_space_count: int = None,
               time_prefix: bool = True,
               mode: str = 'a',
               interval: int = None) -> None:
    """
    将 log 数据, 写入到 log_txt 文件夹中
    文件按照 日期自动创建
    例如: log_txt/2020-01-01.txt
    """
    [file_path, file_name, file_name_prefix, file_name_suffix, interval,
     line_with_space_count] = get_and_save_data_to_thread(
        file_path=file_path,
        file_name=file_name,
        file_name_prefix=file_name_prefix,
        file_name_suffix=file_name_suffix,
        interval=interval,
        mode=mode,
        file_name_with_date=file_name_with_date,
        line_with_space_count=line_with_space_count,
        fun_name=to_log_txt
    )
    to_txt(data_param=[
        to_log(*args, time_prefix=time_prefix, line_with_space_count=line_with_space_count, interval=interval)],
        file_name=('' if file_name_prefix is None else file_name_prefix)
                  + (datetime.today().strftime('%Y-%m-%d') if file_name is None else file_name)
                  + ('' if file_name_suffix is None else file_name_suffix),
        file_path=str(file_path if file_path is not None else 'to_log_txt'),
        mode=mode,
        fixed_name=True,
        suffix='.txt')


def to_txt(data_param: Any,
           file_name: str = 'txt',
           file_path: str = 'txt',
           fixed_name: bool = False,
           mode: str = 'a',
           suffix: str = '.txt',
           sep_list: str = '\t',
           file_name_is_date: bool = False) -> str:
    r"""
    将 list 中的数据以 json 或者基本类型的形式写入到文件中
    data_param   : 数组数据, 也可以不是数组
    file_name   : 文件名 , 默认 txt
                  当文件名是 C:\Users\yangpu\Desktop\study\abc\d\e\f\a.sql 这种类型的时候, 可以直接创建文件夹,
                      会赋值 file_name=a,
                            file_path=C:\Users\yangpu\Desktop\study\abc\d\e\f,
                            fixed_name=True,
                            suffix=.sql
                  当文件名是 abc 的时候, 按照正常值,计算
    file_path   : 文件路径
    fixed_name  : 是否固定文件名
    suffix      : 文件后缀, 默认 .txt
    sep_list    : 当 data_param 是 list(list) 类型的时候 使用 sep_list 作为分割内部的分隔符,
                  默认使用 \t 作为分隔符, 如果为 None , 则按照 json 去处理这个 list
    """
    file_name = str(file_name)
    for sep in ['\\', '/']:
        f_n = file_name.split(sep)
        if len(f_n) > 1:
            file_name = f_n[-1]
            file_path = sep.join(f_n[0:-1])
            if '.' in file_name:
                suffix = '.' + file_name.split('.')[-1]
                file_name = file_name[0:file_name.rfind('.')]
                fixed_name = True

    # 检查路径 file_path
    while file_path.endswith('/'):
        file_path = file_path[0:-1]
    check_file(file_path)

    # 在 file_name 中, 检查是否有后缀
    if '.' in file_name:
        suffix = '.' + file_name.split('.')[-1]
        file_name = file_name[0:file_name.rfind('.')]

    # 生成 file_name
    if fixed_name:
        file_name = file_name + suffix
    else:
        file_name = get_file_name(file_name, suffix, is_date=file_name_is_date)
    # 文件路径
    file_name_path = file_name
    if file_path != '':
        file_name_path = file_path + '/' + file_name
    # 写入文件
    text_file = open(file_name_path, mode, encoding='utf-8')
    if isinstance(data_param, set):
        data_param = list(data_param)
    if not isinstance(data_param, list):
        text_file.write(to_str(data_param) + '\n')
    else:
        for one in data_param:
            if isinstance(one, (list, tuple, set)) and sep_list is not None:
                text_file.write(str(sep_list).join(list(map(lambda x: to_str(x), one))) + '\n')
            else:
                text_file.write(to_str(one) + '\n')
    text_file.close()
    return file_name_path


# 将 list 中的数据写入到固定的文件中,自己设置文件后缀
def to_txt_file(data_param: Any,
                file_name: str = None,
                mode: str = 'a') -> str:
    file_name = get_file_name('to_txt_file', is_date=True) if file_name is None else file_name
    suffix = '.txt'
    f = file_name
    for sep in ['\\', '/']:
        f_n = file_name.split(sep)
        if len(f_n) > 1:
            f = file_name
    if '.' in f:
        suffix = '.' + f.split('.')[-1]
        file_name = file_name.replace(suffix, '')
    return to_txt(data_param=data_param,
                  file_name=file_name,
                  file_path='to_txt_file',
                  suffix=suffix,
                  fixed_name=True,
                  mode=mode)


# 将 list 中的数据写入到固定的文件中,自己设置文件后缀
def to_file(data_param: Any,
            file_name: str = None,
            mode: str = 'a') -> str:
    file_name = get_file_name('to_file', is_date=True) if file_name is None else file_name
    suffix = '.txt'
    f = file_name
    for sep in ['\\', '/']:
        f_n = file_name.split(sep)
        if len(f_n) > 1:
            f = file_name
    if '.' in f:
        suffix = '.' + f.split('.')[-1]
        file_name = file_name.replace(suffix, '')
    return to_txt(data_param=data_param,
                  file_name=file_name,
                  file_path='file',
                  suffix=suffix,
                  fixed_name=True,
                  mode=mode)


# 将文件导出成excel格式的
def to_excel(data_list: set | list | tuple | None,
             file_name: str = None,
             file_path: str = 'excel') -> None:
    if file_name is None:
        file_name = 'excel'
    file_name = str(file_name)
    while file_path.endswith('/'):
        file_path = file_path[0:-1]
    check_file(file_path)
    # 实例化对象excel对象
    excel_obj = openpyxl.Workbook()
    # excel 内第一个sheet工作表
    excel_obj_sheet = excel_obj[excel_obj.sheetnames[0]]
    # 给单元格赋值
    for one_data in data_list:
        s_list = []
        if isinstance(one_data, list) or isinstance(one_data, set):
            for one in one_data:
                if isinstance(one, dict) or isinstance(one, list):
                    s = json.dumps(one)
                else:
                    s = str(one)
                s_list.append(s)
            excel_obj_sheet.append(s_list)
        else:
            if is_json_serializable(one_data):
                s = json.dumps(one_data)
            else:
                s = str(one_data)
            excel_obj_sheet.append([s])

    # 文件保存
    excel_obj.save(file_path + '/' + get_file_name(file_name, '.xlsx', True))


def to_csv(data_list: set | list | tuple | dict,
           file_name: str = None,
           file_path: str = 'csv') -> None:
    """
    将文件导出成csv格式的
    data_list 格式
    data_list = [['Name', 'Age', 'Gender'],
                 ['Alice', 25, 'Female'],
                 ['Bob', 30, 'Male'],
                 ['Charlie', 35, 'Male']]
    data_list = [{
          "a": 1,
          "b": 2,
      },{
          "a": 1,
          "b": 2,
    }]
    file_name = 'data'
    """
    if file_name is None:
        file_name = 'csv'
    file_name = get_file_name(file_name, '.csv', True)
    while file_path.endswith('/'):
        file_path = file_path[0:-1]
    check_file(file_path)
    d_list = []
    if isinstance(data_list, tuple):
        d_list = list(data_list)
    else:
        if len(data_list) and (isinstance(data_list[0], dict) or isinstance(data_list[0], tuple)):
            title_list = []
            for key in data_list[0]:
                title_list.append(key)
            d_list.append(title_list)
            for one_data in data_list:
                one_list = []
                for k in title_list:
                    one_list.append(one_data[k])
                d_list.append(one_list)
        else:
            d_list = data_list
    with open(file_path + '/' + file_name, 'w', newline='') as f:
        writer = csv.writer(f)
        writer.writerows(d_list)
