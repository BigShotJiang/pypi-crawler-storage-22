from upplib import *
from upplib.common_package import *


def to_list_from_txt(file_name: str = 'a.txt',
                     sep: str = None,
                     sep_line: str = None,
                     sep_line_contain: str = None,
                     sep_line_prefix: str = None,
                     sep_line_suffix: str = None,
                     sep_line_with_space_count: int = None,
                     sep_is_front: bool = True,
                     sep_all: str = None,
                     line_ignore_start_with: list | int | str = None,
                     line_ignore_end_with: list | int | str = None,
                     line_ignore_empty: bool | None = None,
                     line_join: str = None,
                     line_must_start_with: str = None,
                     line_must_contain: str = None,
                     line_json: bool = None,
                     start_index: int = None,
                     start_line: str = None,
                     start_line_exclude: str | list[str] | set[str] = None,
                     end_index: int = None,
                     end_line: str = None,
                     end_line_exclude: str | list[str] | set[str] = None,
                     count: int = None) -> list:
    """
    :param file_name: 文件名称
    :param sep: 分隔符, 对每一行进行分割,将 list(str) 转化为 list(list(str)), 或者将 list(list(str)) 转化为 list(list(list(str)))
    :param sep_line: 分隔符, 行分隔符, 这一行是一个分隔符, 分隔符与这行一样, 将 list(str) 转化为 list(list(str))
    :param sep_line_contain: 分隔符, 行分隔符, 必须包含. 这一行是一个分隔符,包含这个行分隔符的做分割, 将 list(str) 转化为 list(list(str))
    :param sep_line_prefix: 分隔符, 行分隔符, 必须以什么开头. 这一行是一个分隔符,以这个分隔符作为前缀的, 将 list(str) 转化为 list(list(str))
    :param sep_line_suffix: 分隔符, 行分隔符, 必须以什么结尾. 这一行是一个分隔符,以这个分隔符作为后缀的, 将 list(str) 转化为 list(list(str))
    :param sep_line_with_space_count: 分隔符, 行分隔符, 必须包含空格的数量, 分隔符是空格的个数, 将 list(str) 转化为 list(list(str))
    :param sep_is_front: 分隔符, 行分隔符, 是否在前面, 这一行，分割行，是包含到前面，还是包含到
    :param sep_all: 分隔符, 所有的分隔符. 将文件转化成一个字符串,然后对这个字符串,再次总体分割 将 list(str) 转化为 str , 然后再次转化成 list(str)
    :param line_ignore_start_with: 行忽略, 以什么开头. 忽略以这个为开头的行
    :param line_ignore_end_with: 行忽略, 以什么结尾. 忽略以这个为结尾的行
    :param line_ignore_empty: 行忽略, 是否忽略空行. 如果这一行为空，就忽略这行
    :param line_join: 行连接符. 将 list(list(str)) 转化成 list(str) 类型的数据
    :param line_must_start_with: 行必须以什么开头. 这一行必须以这个字符串为开始
    :param line_must_contain: 行必须包含什么. 这一行必须包含这个字符串
    :param line_json: 是否是 json 格式. 将 list(str) 转化成 list(json) 类型的数据, 会自动过滤掉空格行
    :param start_index: 开始索引. 从这个地方开始读取,从1开始标号 , 包含这一行
    :param start_line: 开始行. 从这个地方开始读取,从第一行开始找到这个字符串开始标记 , 包含这一行
    :param start_line_exclude: 开始行, 排除什么. 从这个地方开始读取,从第一行开始找到这个字符串开始标记 , 不包含这一行, 返回的是一个 list(' '.join(one_line_list))
    :param end_index: 结束索引. 读取到这个地方结束,从1开始标号 , 不包含这一行
    :param end_line: 结束行. 读取到这个地方结束,从第一行开始找到这个字符串开始标记 , 不包含这一行
    :param end_line_exclude: 结束行, 排除什么. 读取到这个地方结束,从第一行开始找到这个字符串开始标记 , 不包含这一行, 返回的是一个 list(' '.join(one_line_list))
    :param count: 数量. 读取指定的行数
    :return:
    """
    if file_is_empty(file_name=file_name):
        return []
    data_list = []
    # 普通文件的解析
    d_list = open(file_name, 'r', encoding='utf-8').readlines()
    # 数量
    c = 0
    start_flag = None
    end_flag = None
    if start_line is not None:
        start_flag = False
    if end_line is not None:
        end_flag = False
    for i in range(len(d_list)):
        line = d_list[i].strip()
        # 判断开始位置
        if start_index is not None and i + 1 < to_int(start_index):
            continue
        # 判断结束位置
        if end_index is not None and i + 1 >= to_int(end_index):
            continue
        # 判断数量
        if count is not None and c >= to_int(count):
            continue
        # 开始标记位
        if start_flag is not None and not start_flag and line.find(start_line) > -1:
            # 如果有标记位置,就是 True
            start_flag = True
        # 开始标记位
        if end_flag is not None and not end_flag and line.find(end_line) > -1:
            # 如果有标记位置,就是 True
            end_flag = True
        if start_flag is not None and not start_flag:
            # 有开始标记位参数,并且,还没有走到开始标记位
            continue
        elif end_flag is not None and end_flag:
            # 有结束标记位参数,并且,已经走到了结束标记位
            continue
        c += 1
        can_add = True
        if line_ignore_start_with is not None:
            if isinstance(line_ignore_start_with, list) or isinstance(line_ignore_start_with, set):
                for ss in line_ignore_start_with:
                    if line.startswith(str(ss)):
                        can_add = False
            elif isinstance(line_ignore_start_with, str):
                if line.startswith(str(line_ignore_start_with)):
                    can_add = False
        if line_ignore_end_with is not None:
            if isinstance(line_ignore_end_with, list) or isinstance(line_ignore_end_with, set):
                for ss in line_ignore_end_with:
                    if line.endswith(str(ss)):
                        can_add = False
            elif isinstance(line_ignore_end_with, str):
                if line.endswith(str(line_ignore_end_with)):
                    can_add = False
        if line_ignore_empty is not None and line_ignore_empty:
            # 忽略空行
            if len(line) == 0:
                can_add = False
        if line_must_start_with is not None:
            # 必须以这个字符串为开始
            if not line.startswith(str(line_must_start_with)):
                can_add = False
        if line_must_contain is not None:
            # 必须包含这个字符串
            if line.count(str(line_must_contain)) == 0:
                can_add = False
        if can_add:
            data_list.append(line)

    # 更复杂的切分, 中间的部分 会转成 ' '.join(one_line_list)
    if start_line_exclude is not None and end_line_exclude is not None:
        data_list1 = data_list
        start_flag = False
        start_flag_once = False
        end_flag = False
        one_data_list = []
        data_list = []
        for i in range(len(data_list1)):
            line = data_list1[i].strip()
            # 开始标记位
            if not start_flag:
                if isinstance(start_line_exclude, list) or isinstance(start_line_exclude, set):
                    for ss in start_line_exclude:
                        if line.find(str(ss)) > -1:
                            # 如果有标记位置,就是 True
                            start_flag = True
                            start_flag_once = True
                else:
                    if line.find(str(start_line_exclude)) > -1:
                        # 如果有标记位置,就是 True
                        start_flag = True
                        start_flag_once = True
            # 结束标记位
            if not end_flag:
                if isinstance(end_line_exclude, list) or isinstance(end_line_exclude, set):
                    for ss in end_line_exclude:
                        if line.find(str(ss)) > -1:
                            # 如果有标记位置,就是 True
                            end_flag = True
                else:
                    if line.find(str(end_line_exclude)) > -1:
                        # 如果有标记位置,就是 True
                        end_flag = True
            if not start_flag:
                # 有开始标记位参数,并且,还没有走到开始标记位
                continue
            elif end_flag:
                # 有结束标记位参数,并且,已经走到了结束标记位
                start_flag = False
                end_flag = False
                start_flag_once = False
                # print(one_data_list)
                data_list.append(' '.join(one_data_list).strip())
                one_data_list = []
                continue
            # 去掉 start_line_exclude 包含行
            if start_flag_once:
                start_flag_once = False
                line = ''
            if start_flag and not end_flag:
                one_data_list.append(line)
        if len(one_data_list):
            data_list.append(' '.join(one_data_list).strip())

    if sep_all is not None:
        # 全部划分, 重新分割成 list(str)
        data_list = ''.join(data_list).split(str(sep_all))
    # 有行分隔符, 将会把 list(str) 转化成 list(list)
    if len(list(filter(lambda x: x is not None,
                       [sep_line, sep_line_prefix, sep_line_contain, sep_line_suffix, sep_line_with_space_count]))):
        # 当是这种情况的时候,返回的数据结果
        r_list = []
        # 数据中的一行 list 数据
        one_list = []
        # 空格数量
        space_count = 0
        for d_o in data_list:
            space_count = space_count + 1 if not d_o.strip() else 0
            # 过滤掉空行,无效行
            if len(d_o.strip()) and sep_is_front:
                one_list.append(d_o)
            # 这一行, 等于 sep_line
            if ((sep_line is not None and d_o == sep_line) or
                    # 这一行, 包含 sep_line_contain
                    (sep_line_contain is not None and d_o.find(sep_line_contain) != -1) or
                    # 这一行, 是否是以 sep_line_prefix 开头
                    (sep_line_prefix is not None and d_o.startswith(sep_line_prefix)) or
                    # 这一行, 是否是以 sep_line_suffix 结尾
                    (sep_line_suffix is not None and d_o.endswith(sep_line_suffix))):
                if len(one_list):
                    r_list.append(one_list)
                    one_list = []
            if len(d_o.strip()) and not sep_is_front:
                one_list.append(d_o)
            # 按照空格行的数量来进行分割
            if sep_line_with_space_count is not None and space_count == sep_line_with_space_count:
                if len(one_list):
                    r_list.append(one_list)
                    one_list = []
                space_count = 0
        # 最后的一条数据,兼容一下
        if len(one_list):
            r_list.append(one_list)
        data_list = r_list
    # 对这个 list 进行行内再次分割
    if sep is not None:
        r_list = []
        for line in data_list:
            # list(str) 情况
            if isinstance(line, str):
                r_list.append(line.split(str(sep)))
            # list(list) 情况
            elif isinstance(line, list):
                a_list = []
                for o_line in line:
                    a_list.append(o_line.split(str(sep)))
                r_list.append(a_list)
        data_list = r_list
    # data_list 中的每一个元素都转化成 str
    if line_join is not None:
        data_list = list(map(lambda x: str(line_join).join(x), data_list))
    # data_list 中的每一个元素都转化成 先转化成str, 然后再转化成json
    if line_json is not None and line_json:
        data_list = list(map(lambda x:
                             json.loads(str('' if line_join is None else line_join).join(x)),
                             list(filter(lambda x: x is not None and len(str(x)), data_list))
                             )
                         )
    return data_list


def to_list_from_excel(file_name: str = 'a.xls',
                       sheet_index: int = 1,
                       column_index: list | int | str | None = None,
                       column_date: list | int | str | None = None,
                       column_datetime: list | int | str | None = None) -> list:
    """
    当读取 excel 之类的文件的时候
    将 excel 文件读取到 list 中, 可以指定 sheet, 也可以指定列 column_index(列) ,自动过滤掉每个单元格前后的特殊字符
    sheet_index     : 从 1 开始编号,
    column_index    : 从 1 开始编号, 指定列, 如果是指定值是一个, 这个时候返回的是一个 list, 没有嵌套 list
                       如果是 '1,2,3,4'   [1,2,3,4], 返回的是一个嵌套 list[list]
    column_date     : 指定日期格式的列,规则与 column_index 一样
    column_datetime : 指定日期格式的列,规则与 column_index 一样
    """
    if file_is_empty(file_name):
        return []
    data_list = list()
    # excel 表格解析成 list 数据
    list_index = []
    for one_index in [column_index, column_date, column_datetime]:
        list_index_one = None
        if one_index is not None:
            list_index_one = []
            if isinstance(one_index, int):
                list_index_one.append(one_index)
            if isinstance(one_index, str):
                i_list = one_index.split(',')
                for i in i_list:
                    list_index_one.append(int(i))
            if isinstance(one_index, list):
                for i in one_index:
                    list_index_one.append(int(i))
        list_index.append(list_index_one)
    list_all = []
    for one_list in list_index:
        if one_list is not None:
            for o in one_list:
                list_all.append(o)
    if len(list_all) > 0 and list_index[0] is not None:
        list_index[0] = list_all
    # 是否是单 list 类型的数据
    list_only_one = False
    if list_index[0] is not None and len(list_index[0]) == 1:
        list_only_one = True
    # 是 xls 格式
    if file_name.endswith('.xls'):
        book = xlrd.open_workbook(file_name)  # 打开一个excel
        sheet = book.sheet_by_index(sheet_index - 1)  # 根据顺序获取sheet
        for i in range(sheet.nrows):  # 0 1 2 3 4 5
            rows = sheet.row_values(i)
            row_data = []
            for j in range(len(rows)):
                cell_data = str(rows[j]).strip()
                is_date = False
                is_datetime = False
                # 日期格式的列
                if list_index[1] is not None and j + 1 in list_index[1]:
                    cell_data = to_date(xlrd.xldate_as_datetime(to_int(rows[j]), 0))
                    is_date = True
                    row_data.append(cell_data)
                    if list_only_one:
                        row_data = cell_data
                # 日期时间格式的列
                if not is_date and list_index[2] is not None and j + 1 in list_index[2]:
                    cell_data = to_datetime(xlrd.xldate_as_datetime(to_int(rows[j]), 0))
                    is_datetime = True
                    row_data.append(cell_data)
                    if list_only_one:
                        row_data = cell_data
                # 指定需要的列
                if not is_date and not is_datetime:
                    if list_index[0] is None:
                        row_data.append(cell_data)
                    else:
                        # 指定需要的列
                        if j + 1 in list_index[0]:
                            row_data.append(cell_data)
                            if list_only_one:
                                row_data = cell_data
            data_list.append(row_data)
    # 是 xlsx 格式
    if file_name.endswith('.xlsx'):
        wb = openpyxl.load_workbook(filename=file_name, read_only=True)
        ws = wb[wb.sheetnames[sheet_index - 1]]
        for rows in ws.rows:
            row_data = []
            for j in range(len(rows)):
                cell_data = str(rows[j].value).strip()
                is_date = False
                is_datetime = False
                # 日期格式的列
                if list_index[1] is not None and j + 1 in list_index[1]:
                    cell_data = to_date(cell_data)
                    is_date = True
                    row_data.append(cell_data)
                    if list_only_one:
                        row_data = cell_data
                # 日期时间格式的列
                if not is_date and list_index[2] is not None and j + 1 in list_index[2]:
                    cell_data = to_datetime(cell_data)
                    is_datetime = True
                    row_data.append(cell_data)
                    if list_only_one:
                        row_data = cell_data
                # 指定需要的列
                if not is_date and not is_datetime:
                    if list_index[0] is None:
                        row_data.append(cell_data)
                    else:
                        # 指定需要的列
                        if j + 1 in list_index[0]:
                            row_data.append(cell_data)
                            if list_only_one:
                                row_data = cell_data
            data_list.append(row_data)
    return data_list


def to_list(file_name: str = 'a.txt',
            sep: str = None,
            sep_line: str = None,
            sep_line_contain: str = None,
            sep_line_prefix: str = None,
            sep_line_suffix: str = None,
            sep_all: str = None,
            line_ignore_start_with: list[str] | set[str] | str = None,
            line_ignore_end_with: list[str] | set[str] | str | None = None,
            line_ignore_empty: bool | None = None,
            start_index: int = None,
            start_line: str = None,
            end_index: int = None,
            end_line: str = None,
            count: int = None,
            sheet_index: int = 1,
            column_index: list[str] | set[str] | str | None = None,
            column_date: list[str] | set[str] | str | None = None,
            column_datetime: list[str] | set[str] | str | None = None) -> list:
    """
    当读取 txt 之类的文件的时候
    将 txt 文件读取到 list 中, 每一行自动过滤掉行前行后的特殊字符
    sep             : 是否对每一行进行分割,如果存在这个字段,就分割
    sep_all         : 将文件转化成一个字符串,然后对这个字符串,再次总体分割
    start_index     : 从这个地方开始读取,从1开始标号 , 包含这一行
    start_line      : 从这个地方开始读取,从第一行开始找到这个字符串开始标记 , 包含这一行
    end_index       : 读取到这个地方结束,从1开始标号 , 不包含这一行
    end_line        : 读取到这个地方结束,从第一行开始找到这个字符串开始标记 , 不包含这一行
    count           : 读取指定的行数
    ##############################################
    当读取 excel 之类的文件的时候
    将 excel 文件读取到 list 中, 可以指定 sheet, 也可以指定列 column_index(列) ,自动过滤掉每个单元格前后的特殊字符
    sheet           : 从 1 开始编号,
    column_index    : 从 1 开始编号, 指定列
    column_index    : 如果是指定值, 这个时候返回的是一个 list, 没有嵌套 list
    column_index    : 如果是 '1,2,3,4'   [1,2,3,4], 返回的是一个嵌套 list[list]
    column_date     : 指定日期格式的列,规则与 column_index 一样
    column_datetime : 指定日期格式的列,规则与 column_index 一样
    返回的数据一定是一个 list
    """
    if file_name.endswith('.xls') or file_name.endswith('.xlsx'):
        return to_list_from_excel(file_name=file_name,
                                  sheet_index=sheet_index,
                                  column_index=column_index,
                                  column_date=column_date,
                                  column_datetime=column_datetime)
    return to_list_from_txt(file_name=file_name,
                            sep=sep,
                            sep_line=sep_line,
                            sep_line_contain=sep_line_contain,
                            sep_line_prefix=sep_line_prefix,
                            sep_line_suffix=sep_line_suffix,
                            sep_all=sep_all,
                            line_ignore_start_with=line_ignore_start_with,
                            line_ignore_end_with=line_ignore_end_with,
                            line_ignore_empty=line_ignore_empty,
                            start_index=start_index,
                            start_line=start_line,
                            end_index=end_index,
                            end_line=end_line,
                            count=count)


def to_list_from_txt_with_blank_line(file_name: str = 'a.txt') -> list:
    """
    将一个文件中以空行作为分隔符,
    组成一个 list(list) 数据
    多行空行,自动合并到一行空行
    """
    return to_list_from_txt(file_name, sep_line='')


def to_list_json_from_txt(file_name: str = 'a.txt',
                          start_index: int = None,
                          start_line: str = None,
                          start_line_exclude: str | list[str] | set[str] = None,
                          end_index: int = None,
                          end_line: str = None,
                          end_line_exclude: str | list[str] | set[str] = None,
                          count: int = None) -> list:
    """
    将一个文件中的数据按照行来区分,
    会自动过滤掉空格行,
    组成一个 list[json] 数据
    可以将以下文本转 list[json]
    {"accessKey":"1","signature":"4","timestamp":"1747639787"}
    {"accessKey":"2","signature":"5","timestamp":"1747639787"}
    {"accessKey":"3","signature":"6","timestamp":"1747639787"}
    """
    return to_list_from_txt(file_name,
                            start_index=start_index,
                            start_line=start_line,
                            start_line_exclude=start_line_exclude,
                            end_index=end_index,
                            end_line=end_line,
                            end_line_exclude=end_line_exclude,
                            count=count,
                            line_json=True)


# 读取文件中的数据,返回一个 str
def to_str_from_file(file_name: str = 'a.txt',
                     str_join: str = ' ',
                     line_ignore_start_with: list | int | str | None = None,
                     line_ignore_end_with: list | int | str | None = None,
                     start_index: int = None,
                     start_line: str = None,
                     end_index: int = None,
                     end_line: str = None,
                     count: int = None) -> str:
    return to_data_from_file(file_name=file_name,
                             line_ignore_start_with=line_ignore_start_with,
                             line_ignore_end_with=line_ignore_end_with,
                             str_join=str_join,
                             start_index=start_index,
                             start_line=start_line,
                             end_index=end_index,
                             end_line=end_line,
                             count=count,
                             r_str=True)


# 读取文件中的数据,返回一个 json
def to_json_from_file(file_name: str = 'a.txt',
                      start_index: int = None,
                      start_line: str = None,
                      end_index: int = None,
                      end_line: str = None,
                      line_ignore_start_with=None,
                      count: int = None) -> dict[str, Any]:
    if line_ignore_start_with is None:
        line_ignore_start_with = ['//', '/*', '#']
    return to_data_from_file(file_name=file_name,
                             start_index=start_index,
                             start_line=start_line,
                             end_index=end_index,
                             end_line=end_line,
                             line_ignore_start_with=line_ignore_start_with,
                             count=count,
                             r_json=True)


def to_data_from_file(file_name: str = 'a.txt',
                      sep: str = None,
                      sep_line: str = None,
                      sep_all: str = None,
                      line_ignore_start_with: list | int | str | None = None,
                      line_ignore_end_with: list | int | str | None = None,
                      line_ignore_empty: bool | None = None,
                      start_index: int = None,
                      start_line: str = None,
                      end_index: int = None,
                      end_line: str = None,
                      count: int = None,
                      sheet_index: int = 1,
                      column_index: list | int | str | None = None,
                      column_date: list | int | str | None = None,
                      column_datetime: list | int | str | None = None,
                      r_json: bool = False,
                      str_join: str = '',
                      r_str: bool = False) -> str | dict[str, Any]:
    """
    在 to_list 方法上再嵌套一层,
    r_str    : 返回的数据是否是一个 字符串, ''.join(list)
    str_join : 返回的数据是否是一个 字符串, str_join.join(list), 用 str_join 做连接
    r_json   : 返回的数据是否是一个 json 类型的数据
    """
    d = to_list(file_name=file_name,
                sep=sep,
                sep_line=sep_line,
                sep_all=sep_all,
                line_ignore_start_with=line_ignore_start_with,
                line_ignore_end_with=line_ignore_end_with,
                line_ignore_empty=line_ignore_empty,
                start_index=start_index,
                start_line=start_line,
                end_index=end_index,
                end_line=end_line,
                count=count,
                sheet_index=sheet_index,
                column_index=column_index,
                column_date=column_date,
                column_datetime=column_datetime)
    return str_join.join(d) if r_str else json.loads(str_join.join(d)) if r_json else d


def to_list_from_txt_with_ignore_line(file_name: str = 'a.txt',
                                      sep: str = None,
                                      sep_line: str = None,
                                      sep_line_contain: str = None,
                                      sep_line_prefix: str = None,
                                      sep_line_suffix: str = None,
                                      sep_line_with_space_count: int = None,
                                      sep_is_front: bool = True,
                                      sep_all: str = None,
                                      line_ignore_start_with: list | int | str = None,
                                      line_ignore_end_with: list | int | str = None,
                                      line_ignore_empty: bool | None = True,
                                      line_join: str = None,
                                      line_must_start_with: str = None,
                                      line_must_contain: str = None,
                                      line_json: bool = None,
                                      start_index: int = None,
                                      start_line: str = None,
                                      start_line_exclude: str | list[str] | set[str] = None,
                                      end_index: int = None,
                                      end_line: str = None,
                                      end_line_exclude: str | list[str] | set[str] = None,
                                      count: int = None) -> list:
    return to_list_from_txt(file_name=file_name,
                            sep=sep,
                            sep_line=sep_line,
                            sep_line_contain=sep_line_contain,
                            sep_line_prefix=sep_line_prefix,
                            sep_line_suffix=sep_line_suffix,
                            sep_line_with_space_count=sep_line_with_space_count,
                            sep_is_front=sep_is_front,
                            sep_all=sep_all,
                            line_ignore_start_with=line_ignore_start_with,
                            line_ignore_end_with=line_ignore_end_with,
                            line_ignore_empty=line_ignore_empty,
                            line_join=line_join,
                            line_must_start_with=line_must_start_with,
                            line_must_contain=line_must_contain,
                            line_json=line_json,
                            start_index=start_index,
                            start_line=start_line,
                            start_line_exclude=start_line_exclude,
                            end_index=end_index,
                            end_line=end_line,
                            end_line_exclude=end_line_exclude,
                            count=count)


# 将多个文件 读取成 list
def to_list_from_txt_list(file_list: list[Any] = None) -> list:
    if file_list is None:
        file_list = []
    data_list = []
    for a in file_list:
        data_list.extend(to_list_from_txt(file_name=a))
    return data_list
