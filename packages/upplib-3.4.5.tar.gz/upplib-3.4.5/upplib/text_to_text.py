from upplib import *
from upplib.common_package import *


def to_list_list(list_data: list[str] = None,
                 count: int = None) -> list[list[str]]:
    """
    将 list 切分成 list(list)
    组成一个 list(list) 数据
    多行空行,自动合并到一行空行
    :param list_data: 原始 list 数据
    :param count: 每个 list(list) 数据 包含的元素数量
    :return:
    """
    if count is not None and count > 0:
        if list_data is None:
            list_data = []
        r_list = []
        o_list = []
        c = 0
        for i in range(len(list_data)):
            o_list.append(list_data[i])
            c += 1
            if c == count:
                r_list.append(o_list)
                o_list = []
                c = 0
        if len(o_list):
            r_list.append(o_list)
        return r_list
    return []
