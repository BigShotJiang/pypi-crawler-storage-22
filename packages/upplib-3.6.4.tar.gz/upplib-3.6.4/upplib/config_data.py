from upplib import *
from upplib.common_package import *
from upplib.file_function import *

__CONFIG_PATH = '.upp.config'

__CONFIG_PATH_BAK = '_upp.config'


# 将数据写入到 config 中
def set_config_data(file_name: str = 'config',
                    param: dict[str, Any] = None) -> None:
    set_data_in_user_home(file_name, {} if param is None else param)


# 从 config 中获得 配置数据
def get_config_data(file_name: str = 'config') -> dict[str, Any]:
    # print('get_config_data', file_name)
    config_data = get_data_from_user_home(file_name)
    # print('get_data_from_user_home', config_data)
    if not config_data:
        config_data = get_data_from_path(file_name)
    # print('get_data_from_path', config_data)
    return config_data


# 在当前用户的主目录中, 获得指定文件的数据
def get_data_from_user_home(file_name: str = 'config') -> dict[str, Any]:
    return get_data_from_path(file_name, os.path.expanduser("~"))


# 将 data 数据,在当前用户的主目录中, 获得指定文件的数据
def set_data_in_user_home(file_name: str = 'config',
                          param: dict[str, Any] = None) -> None:
    set_data_in_path(file_name, {} if param is None else param, os.path.expanduser("~"))


# 在当前的目录中, 获得指定文件的数据
def get_data_from_path(file_name: str = 'config',
                       file_path: str = None) -> dict[str, Any]:
    param = get_data_from_path_detail(file_name, file_path, __CONFIG_PATH)
    return param if param else get_data_from_path_detail(file_name, file_path, __CONFIG_PATH_BAK)


def get_data_from_path_detail(file_name: str = 'config',
                              file_path: str = None,
                              path_name: str = __CONFIG_PATH) -> dict[str, Any]:
    config_path = file_path + '/' + path_name if file_path else path_name
    # print('config_path_1', config_path)
    if not os.path.exists(config_path):
        # print('config_path_2', config_path)
        return {}
    file_path = config_path + '/' + file_name + '.json'
    # print('config_path_3', file_path)
    if not os.path.exists(file_path):
        return {}
    # print('to_json_from_file', file_path)
    return to_json_from_file(file_path)


# 在当前的目录中, 设置数据到指定路径下
def set_data_in_path(file_name: str = 'config',
                     param: str = None,
                     file_path: str = '') -> None:
    config_path = file_path + '/' + __CONFIG_PATH
    if not os.path.exists(config_path):
        os.mkdir(config_path)
    file_path = config_path + '/' + file_name + '.json'
    text_file = open(file_path, 'w', encoding='utf-8')
    text_file.write(to_str({} if param is None else param))
    text_file.close()
