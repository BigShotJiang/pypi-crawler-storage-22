from upplib import *
from upplib.common_package import *
from upplib.file_to_text import *


def to_list_list(list_data: list[str] = None,
                 sep_all: str = None,
                 sep_line: str = None,
                 sep_line_contain: str = None,
                 sep_line_startswith: str = None,
                 sep_line_endswith: str = None,
                 sep_line_with_space_count: int = None,
                 sep_line_put_in_front: bool = True,
                 sep: str = None,
                 line_join_str: str = None,
                 line_is_json: bool = None) -> list[list[str]]:
    """
    :param list_data                : list 数据
    :param sep_all                  : 分隔符, 所有的分隔符. 将文件转化成一个字符串,然后对这个字符串,再次总体分割 将 list(str) 转化为 str , 然后再次转化成 list(str)
    :param sep_line                 : 分隔符, 行分隔符, 这一行是一个分隔符, 分隔符与这行一样, 将 list(str) 转化为 list(list(str))
    :param sep_line_contain         : 分隔符, 行分隔符, 必须包含. 这一行是一个分隔符,包含这个行分隔符的做分割, 将 list(str) 转化为 list(list(str))
    :param sep_line_startswith      : 分隔符, 行分隔符, 必须以什么开头. 这一行是一个分隔符,以这个分隔符作为前缀的, 将 list(str) 转化为 list(list(str))
    :param sep_line_endswith        : 分隔符, 行分隔符, 必须以什么结尾. 这一行是一个分隔符,以这个分隔符作为后缀的, 将 list(str) 转化为 list(list(str))
    :param sep_line_with_space_count: 分隔符, 行分隔符, 必须包含空格的数量, 分隔符是空格的个数, 将 list(str) 转化为 list(list(str))
    :param sep_line_put_in_front    : 分隔符, 行分隔符, 是否在前面, 这一行，分割行，是包含到前面，还是包含到后面
    :param sep                      : 分隔符, 对每一行进行分割,将 list(str) 转化为 list(list(str)), 或者将 list(list(str)) 转化为 list(list(list(str)))
    :param line_join_str            : 行连接符. 将 list(list(str)) 转化成 list(str) 类型的数据
    :param line_is_json             : 是否是 json 格式. 将 list(str) 转化成 list(json) 类型的数据, 会自动过滤掉空格行
    :return:
    """
    if sep_all is not None:
        # 全部划分, 重新分割成 list(str)
        list_data = ''.join(list_data).split(str(sep_all))
    # 有行分隔符, 将会把 list(str) 转化成 list(list)
    if any(x is not None for x in [sep_line, sep_line_startswith, sep_line_contain, sep_line_endswith, sep_line_with_space_count]):
        # 当是这种情况的时候,返回的数据结果
        r_list = []
        # 数据中的一行 list 数据
        one_list = []
        # 空格数量
        space_count = 0
        for d_one_line in list_data:
            space_count = space_count + 1 if not d_one_line.strip() else 0
            # 过滤掉空行,无效行
            if len(d_one_line.strip()) and sep_line_put_in_front:
                one_list.append(d_one_line)
            # 这一行, 等于 sep_line
            if ((sep_line is not None and d_one_line == sep_line) or
                    # 这一行, 包含 sep_line_contain
                    (sep_line_contain is not None and sep_line_contain in d_one_line) or
                    # 这一行, 是否是以 sep_line_startswith 开头
                    (sep_line_startswith is not None and d_one_line.startswith(sep_line_startswith)) or
                    # 这一行, 是否是以 sep_line_endswith 结尾
                    (sep_line_endswith is not None and d_one_line.endswith(sep_line_endswith))):
                if len(one_list):
                    r_list.append(one_list)
                    one_list = []
            if len(d_one_line.strip()) and not sep_line_put_in_front:
                one_list.append(d_one_line)
            # 按照空格行的数量来进行分割
            if sep_line_with_space_count is not None and space_count == sep_line_with_space_count:
                if len(one_list):
                    r_list.append(one_list)
                    one_list = []
                space_count = 0
        # 最后的一条数据,兼容一下
        if len(one_list):
            r_list.append(one_list)
        list_data = r_list
    # 对这个 list 进行行内再次分割
    if sep is not None:
        r_list = []
        for line in list_data:
            # list(str) 情况
            if isinstance(line, str):
                r_list.append(line.split(str(sep)))
            # list(list) 情况
            elif isinstance(line, list):
                a_list = []
                for o_line in line:
                    a_list.append(o_line.split(str(sep)))
                r_list.append(a_list)
        list_data = r_list
        # 1. 预处理连接符
    join_char = str(line_join_str) if line_join_str is not None else ""
    # 2. 合并处理：一次循环完成所有操作
    if line_is_json:
        list_data = [
            json.loads(join_char.join(x))
            for x in list_data
            if x  # 过滤掉 None 或空容器
        ]
    elif line_join_str is not None:
        list_data = [join_char.join(x) for x in list_data]

    return list_data


def list_split_list(list_data: list[str] = None,
                    count: int = None) -> list[list[str]]:
    """
    将 list 切分成 list(list)
    组成一个 list(list) 数据
    传入 count > 0 时, 按固定数量切分:
    to_list_list(list_data, 4)
    """
    if list_data is None:
        list_data = []

    # 兼容旧逻辑: 传入 count 时按数量切分
    if count is not None and count > 0:
        r_list: list[list[str]] = []
        o_list: list[str] = []
        c = 0
        for item in list_data:
            o_list.append(item)
            c += 1
            if c == count:
                r_list.append(o_list)
                o_list = []
                c = 0
        if o_list:
            r_list.append(o_list)
        return r_list
    return []


def to_list_from_txt_with_blank_line(file_name: str = 'a.txt') -> list:
    """
    将一个文件中以空行作为分隔符,
    组成一个 list(list) 数据
    多行空行,自动合并到一行空行
    """
    return to_list_list(to_list_from_txt(file_name), sep_line='')


def list_group_by(data_list: list[list],
                  group_by_index: int = 0) -> list[list[list]]:
    """
    将一个 list 分组
    例如:
    data_list = [
        ['a', 1, 2],
        ['b', 4, 5],
        ['c', 2, 1],
        ['c', 6, 2],
        ['c', 4, 0],
        ['b', 1, 3]
    ]
    返回:
    [
        [
            ['a', 1, 2]
        ],
        [
            ['b', 4, 5], ['b', 1, 3]],
        [
            ['c', 2, 1], ['c', 6, 2], ['c', 4, 0]
        ]
    ]
    """
    groups = defaultdict(list)
    for item in data_list:
        key = item[group_by_index]
        groups[key].append(item)
    r_list = []
    for key, group in groups.items():
        r_list.append(group)
    return r_list
