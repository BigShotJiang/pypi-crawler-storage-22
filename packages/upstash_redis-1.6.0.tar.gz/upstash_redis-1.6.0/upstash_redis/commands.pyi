import datetime
from typing import Any, Dict, List, Literal, Mapping, Optional, Tuple, Union

from upstash_redis.typing import FloatMinMaxT, ValueT, JSONValueT
from upstash_redis.utils import GeoSearchResult

class Commands:
    def bitcount(
        self, key: str, start: Optional[int] = None, end: Optional[int] = None
    ) -> int: ...
    def bitfield(self, key: str) -> "BitFieldCommands": ...
    def bitfield_ro(self, key: str) -> "BitFieldROCommands": ...
    def bitop(
        self,
        operation: Literal[
            "AND",
            "OR",
            "XOR",
            "NOT",
            "DIFF",
            "DIFF1",
            "ANDOR",
            "ONE",
            "and",
            "or",
            "xor",
            "not",
            "diff",
            "diff1",
            "andor",
            "one",
        ],
        destkey: str,
        *keys: str,
    ) -> int: ...
    def bitpos(
        self,
        key: str,
        bit: Literal[0, 1],
        start: Optional[int] = None,
        end: Optional[int] = None,
    ) -> int: ...
    def getbit(self, key: str, offset: int) -> Literal[0, 1]: ...
    def setbit(self, key: str, offset: int, value: Literal[0, 1]) -> int: ...
    def ping(self, message: Optional[str] = None) -> str: ...
    def echo(self, message: str) -> str: ...
    def client_setinfo(
        self,
        attribute: Literal["LIB-NAME", "LIB-VER", "lib-name", "lib-ver"],
        value: str,
    ) -> str: ...
    def copy(self, source: str, destination: str, replace: bool = False) -> bool: ...
    def delete(self, *keys: str) -> int: ...
    def exists(self, *keys: str) -> int: ...
    def expire(
        self,
        key: str,
        seconds: Union[int, datetime.timedelta],
        nx: bool = False,
        xx: bool = False,
        gt: bool = False,
        lt: bool = False,
    ) -> bool: ...
    def expireat(
        self,
        key: str,
        unix_time_seconds: Union[int, datetime.datetime],
        nx: bool = False,
        xx: bool = False,
        gt: bool = False,
        lt: bool = False,
    ) -> bool: ...
    def keys(self, pattern: str) -> List[str]: ...
    def persist(self, key: str) -> bool: ...
    def pexpire(
        self,
        key: str,
        milliseconds: Union[int, datetime.timedelta],
        nx: bool = False,
        xx: bool = False,
        gt: bool = False,
        lt: bool = False,
    ) -> bool: ...
    def pexpireat(
        self,
        key: str,
        unix_time_milliseconds: Union[int, datetime.datetime],
        nx: bool = False,
        xx: bool = False,
        gt: bool = False,
        lt: bool = False,
    ) -> bool: ...
    def pttl(self, key: str) -> int: ...
    def randomkey(self) -> Optional[str]: ...
    def rename(self, key: str, newkey: str) -> bool: ...
    def renamenx(self, key: str, newkey: str) -> bool: ...
    def scan(
        self,
        cursor: int,
        match: Optional[str] = None,
        count: Optional[int] = None,
        type: Optional[str] = None,
    ) -> Tuple[int, List[str]]: ...
    def touch(self, *keys: str) -> int: ...
    def ttl(self, key: str) -> int: ...
    def type(self, key: str) -> Optional[str]: ...
    def unlink(self, *keys: str) -> int: ...
    def geoadd(
        self,
        key: str,
        *members: Tuple[float, float, str],
        nx: bool = False,
        xx: bool = False,
        ch: bool = False,
    ) -> int: ...
    def geodist(
        self,
        key: str,
        member1: str,
        member2: str,
        unit: Literal["M", "KM", "FT", "MI"] = "M",
    ) -> Optional[float]: ...
    def geohash(self, key: str, *members: str) -> List[Optional[str]]: ...
    def geopos(
        self, key: str, *members: str
    ) -> List[Union[Tuple[float, float], None]]: ...
    def georadius(
        self,
        key: str,
        longitude: float,
        latitude: float,
        radius: float,
        unit: Literal["M", "KM", "FT", "MI"],
        withdist: bool = False,
        withhash: bool = False,
        withcoord: bool = False,
        count: Optional[int] = None,
        any: bool = False,
        order: Optional[Literal["ASC", "DESC"]] = None,
        store: Optional[str] = None,
        storedist: Optional[str] = None,
    ) -> Union[List[Union[str, GeoSearchResult]], int]: ...
    def georadius_ro(
        self,
        key: str,
        longitude: float,
        latitude: float,
        radius: float,
        unit: Literal["M", "KM", "FT", "MI"],
        withdist: bool = False,
        withhash: bool = False,
        withcoord: bool = False,
        count: Optional[int] = None,
        any: bool = False,
        order: Optional[Literal["ASC", "DESC"]] = None,
    ) -> List[Union[str, GeoSearchResult]]: ...
    def georadiusbymember(
        self,
        key: str,
        member: str,
        radius: float,
        unit: Literal["M", "KM", "FT", "MI"],
        withdist: bool = False,
        withhash: bool = False,
        withcoord: bool = False,
        count: Optional[int] = None,
        any: bool = False,
        order: Optional[Literal["ASC", "DESC"]] = None,
        store: Optional[str] = None,
        storedist: Optional[str] = None,
    ) -> Union[List[Union[str, GeoSearchResult]], int]: ...
    def georadiusbymember_ro(
        self,
        key: str,
        member: str,
        radius: float,
        unit: Literal["M", "KM", "FT", "MI"],
        withdist: bool = False,
        withhash: bool = False,
        withcoord: bool = False,
        count: Optional[int] = None,
        any: bool = False,
        order: Optional[Literal["ASC", "DESC"]] = None,
    ) -> List[Union[str, GeoSearchResult]]: ...
    def geosearch(
        self,
        key: str,
        unit: Literal["M", "KM", "FT", "MI"],
        member: Optional[str] = None,
        longitude: Optional[float] = None,
        latitude: Optional[float] = None,
        radius: Optional[float] = None,
        width: Optional[float] = None,
        height: Optional[float] = None,
        order: Optional[Literal["ASC", "DESC"]] = None,
        count: Optional[int] = None,
        any: bool = False,
        withdist: bool = False,
        withhash: bool = False,
        withcoord: bool = False,
    ) -> List[Union[str, GeoSearchResult]]: ...
    def geosearchstore(
        self,
        destination: str,
        source: str,
        member: Optional[str] = None,
        longitude: Optional[float] = None,
        latitude: Optional[float] = None,
        unit: Literal["M", "KM", "FT", "MI"] = "M",
        radius: Optional[float] = None,
        width: Optional[float] = None,
        height: Optional[float] = None,
        order: Optional[Literal["ASC", "DESC"]] = None,
        count: Optional[int] = None,
        any: bool = False,
        storedist: bool = False,
    ) -> int: ...
    def hdel(self, key: str, *fields: str) -> int: ...
    def hexists(self, key: str, field: str) -> bool: ...
    def hexpire(
        self,
        key: str,
        fields: Union[str, List[str]],
        seconds: Union[int, datetime.timedelta],
        nx: bool = False,
        xx: bool = False,
        gt: bool = False,
        lt: bool = False,
    ) -> List[int]: ...
    def hpexpire(
        self,
        key: str,
        fields: Union[str, List[str]],
        milliseconds: Union[int, datetime.timedelta],
        nx: bool = False,
        xx: bool = False,
        gt: bool = False,
        lt: bool = False,
    ) -> List[int]: ...
    def hexpireat(
        self,
        key: str,
        fields: Union[str, List[str]],
        unix_time_seconds: Union[int, datetime.datetime],
        nx: bool = False,
        xx: bool = False,
        gt: bool = False,
        lt: bool = False,
    ) -> List[int]: ...
    def hpexpireat(
        self,
        key: str,
        fields: Union[str, List[str]],
        unix_time_milliseconds: Union[int, datetime.datetime],
        nx: bool = False,
        xx: bool = False,
        gt: bool = False,
        lt: bool = False,
    ) -> List[int]: ...
    def httl(self, key: str, fields: Union[str, List[str]]) -> List[int]: ...
    def hpttl(self, key: str, fields: Union[str, List[str]]) -> List[int]: ...
    def hexpiretime(self, key: str, fields: Union[str, List[str]]) -> List[int]: ...
    def hpexpiretime(self, key: str, fields: Union[str, List[str]]) -> List[int]: ...
    def hpersist(self, key: str, fields: Union[str, List[str]]) -> int: ...
    def hget(self, key: str, field: str) -> Optional[str]: ...
    def hgetdel(self, key: str, *fields: str) -> List[Optional[str]]: ...
    def hgetex(
        self,
        key: str,
        *fields: str,
        ex: Optional[int] = None,
        px: Optional[int] = None,
        exat: Optional[int] = None,
        pxat: Optional[int] = None,
        persist: Optional[bool] = None,
    ) -> List[Optional[str]]: ...
    def hgetall(self, key: str) -> Dict[str, str]: ...
    def hincrby(self, key: str, field: str, increment: int) -> int: ...
    def hincrbyfloat(self, key: str, field: str, increment: float) -> float: ...
    def hkeys(self, key: str) -> List[str]: ...
    def hlen(self, key: str) -> int: ...
    def hmget(self, key: str, *fields: str) -> List[Optional[str]]: ...
    def hmset(self, key: str, values: Mapping[str, ValueT]) -> bool: ...
    def hrandfield(
        self, key: str, count: Optional[int] = None, withvalues: bool = False
    ) -> Union[str, None, List[str], Dict[str, str]]: ...
    def hscan(
        self,
        key: str,
        cursor: int,
        match: Optional[str] = None,
        count: Optional[int] = None,
    ) -> Tuple[int, Dict[str, str]]: ...
    def hset(
        self,
        key: str,
        field: Optional[str] = None,
        value: Optional[str] = None,
        values: Optional[Mapping[str, ValueT]] = None,
    ) -> int: ...
    def hsetnx(self, key: str, field: str, value: ValueT) -> bool: ...
    def hsetex(
        self,
        key: str,
        field: Optional[str] = None,
        value: Optional[ValueT] = None,
        values: Optional[Mapping[str, ValueT]] = None,
        fnx: bool = False,
        fxx: bool = False,
        ex: Optional[int] = None,
        px: Optional[int] = None,
        exat: Optional[int] = None,
        pxat: Optional[int] = None,
        keepttl: bool = False,
    ) -> int: ...
    def hstrlen(self, key: str, field: str) -> int: ...
    def hvals(self, key: str) -> List[str]: ...
    def pfadd(self, key: str, *elements: ValueT) -> bool: ...
    def pfcount(self, *keys: str) -> int: ...
    def pfmerge(self, destkey: str, *sourcekeys: str) -> bool: ...
    def lindex(self, key: str, index: int) -> Optional[str]: ...
    def linsert(
        self,
        key: str,
        where: Literal["BEFORE", "AFTER"],
        pivot: ValueT,
        element: str,
    ) -> int: ...
    def llen(self, key: str) -> int: ...
    def lmove(
        self,
        source: str,
        destination: str,
        wherefrom: Literal["LEFT", "RIGHT"] = "LEFT",
        whereto: Literal["LEFT", "RIGHT"] = "RIGHT",
    ) -> Optional[str]: ...
    def lpop(
        self, key: str, count: Optional[int] = None
    ) -> Union[str, List[str], None]: ...
    def lpos(
        self,
        key: str,
        element: ValueT,
        rank: Optional[int] = None,
        count: Optional[int] = None,
        maxlen: Optional[int] = None,
    ) -> Union[(Optional[int]), List[int]]: ...
    def lpush(self, key: str, *elements: ValueT) -> int: ...
    def lpushx(self, key: str, *elements: ValueT) -> int: ...
    def lrange(self, key: str, start: int, stop: int) -> List[str]: ...
    def lrem(self, key: str, count: int, element: ValueT) -> int: ...
    def lset(self, key: str, index: int, element: ValueT) -> bool: ...
    def ltrim(self, key: str, start: int, stop: int) -> str: ...
    def rpop(
        self, key: str, count: Optional[int] = None
    ) -> Union[str, List[str], None]: ...
    def rpoplpush(self, source: str, destination: str) -> Optional[str]: ...
    def rpush(self, key: str, *elements: ValueT) -> int: ...
    def rpushx(self, key: str, *elements: ValueT) -> int: ...
    def publish(self, channel: str, message: ValueT) -> int: ...
    def eval(
        self,
        script: str,
        keys: Optional[List[str]] = None,
        args: Optional[List[str]] = None,
    ) -> Any: ...
    def eval_ro(
        self,
        script: str,
        keys: Optional[List[str]] = None,
        args: Optional[List[str]] = None,
    ) -> Any: ...
    def evalsha(
        self,
        sha1: str,
        keys: Optional[List[str]] = None,
        args: Optional[List[str]] = None,
    ) -> Any: ...
    def evalsha_ro(
        self,
        sha1: str,
        keys: Optional[List[str]] = None,
        args: Optional[List[str]] = None,
    ) -> Any: ...
    def dbsize(self) -> int: ...
    def flushall(
        self, flush_type: Optional[Literal["ASYNC", "SYNC"]] = None
    ) -> bool: ...
    def flushdb(
        self, flush_type: Optional[Literal["ASYNC", "SYNC"]] = None
    ) -> bool: ...
    def time(self) -> Tuple[int, int]: ...
    def sadd(self, key: str, *members: ValueT) -> int: ...
    def scard(self, key: str) -> int: ...
    def sdiff(self, *keys: str) -> List[str]: ...
    def sdiffstore(self, destination: str, *keys: str) -> int: ...
    def sinter(self, *keys: str) -> List[str]: ...
    def sinterstore(self, destination: str, *keys: str) -> int: ...
    def sismember(self, key: str, member: ValueT) -> bool: ...
    def smismember(self, key: str, *members: ValueT) -> List[bool]: ...
    def smembers(self, key: str) -> List[str]: ...
    def smove(self, source: str, destination: str, member: ValueT) -> bool: ...
    def spop(
        self, key: str, count: Optional[int] = None
    ) -> Union[str, List[str], None]: ...
    def srandmember(
        self, key: str, count: Optional[int] = None
    ) -> Union[str, List[str], None]: ...
    def srem(self, key: str, *members: ValueT) -> int: ...
    def sscan(
        self,
        key: str,
        cursor: int = 0,
        match: Optional[str] = None,
        count: Optional[int] = None,
    ) -> Tuple[int, List[str]]: ...
    def sunion(self, *keys: str) -> List[str]: ...
    def sunionstore(self, destination: str, *keys: str) -> int: ...
    def zadd(
        self,
        key: str,
        scores: Dict[str, float],
        nx: bool = False,
        xx: bool = False,
        gt: bool = False,
        lt: bool = False,
        ch: bool = False,
        incr: bool = False,
    ) -> Union[int, float, None]: ...
    def zcard(self, key: str) -> int: ...
    def zcount(self, key: str, min: FloatMinMaxT, max: FloatMinMaxT) -> int: ...
    def zdiff(
        self, keys: List[str], withscores: bool = False
    ) -> Union[List[str], List[Tuple[str, float]]]: ...
    def zdiffstore(self, destination: str, keys: List[str]) -> int: ...
    def zincrby(self, key: str, increment: float, member: str) -> float: ...
    def zinter(
        self,
        keys: List[str],
        weights: Union[List[float], List[int], None] = None,
        aggregate: Optional[Literal["SUM", "MIN", "MAX"]] = None,
        withscores: bool = False,
    ) -> Union[List[str], List[Tuple[str, float]]]: ...
    def zinterstore(
        self,
        destination: str,
        keys: List[str],
        weights: Union[List[float], List[int], None] = None,
        aggregate: Optional[Literal["SUM", "MIN", "MAX"]] = None,
    ) -> int: ...
    def zlexcount(self, key: str, min: str, max: str) -> int: ...
    def zmscore(self, key: str, members: List[str]) -> List[Optional[float]]: ...
    def zpopmax(
        self, key: str, count: Optional[int] = None
    ) -> List[Tuple[str, float]]: ...
    def zpopmin(
        self, key: str, count: Optional[int] = None
    ) -> List[Tuple[str, float]]: ...
    def zrandmember(
        self, key: str, count: Optional[int] = None, withscores: bool = False
    ) -> Union[str, None, List[str], List[Tuple[str, float]]]: ...
    def zrange(
        self,
        key: str,
        start: FloatMinMaxT,
        stop: FloatMinMaxT,
        sortby: Optional[Literal["BYSCORE", "BYLEX"]] = None,
        rev: bool = False,
        offset: Optional[int] = None,
        count: Optional[int] = None,
        withscores: bool = False,
    ) -> Union[List[str], List[Tuple[str, float]]]: ...
    def zrangebylex(
        self,
        key: str,
        min: str,
        max: str,
        offset: Optional[int] = None,
        count: Optional[int] = None,
    ) -> List[str]: ...
    def zrangebyscore(
        self,
        key: str,
        min: FloatMinMaxT,
        max: FloatMinMaxT,
        withscores: bool = False,
        offset: Optional[int] = None,
        count: Optional[int] = None,
    ) -> Union[List[str], List[Tuple[str, float]]]: ...
    def zrangestore(
        self,
        dst: str,
        src: str,
        min: FloatMinMaxT,
        max: FloatMinMaxT,
        sortby: Optional[Literal["BYSCORE", "BYLEX"]] = None,
        rev: bool = False,
        offset: Optional[int] = None,
        count: Optional[int] = None,
    ) -> int: ...
    def zrank(self, key: str, member: str) -> Optional[int]: ...
    def zrem(self, key: str, *members: str) -> int: ...
    def zremrangebylex(self, key: str, min: str, max: str) -> int: ...
    def zremrangebyrank(self, key: str, start: int, stop: int) -> int: ...
    def zremrangebyscore(
        self, key: str, min: FloatMinMaxT, max: FloatMinMaxT
    ) -> int: ...
    def zrevrange(
        self, key: str, start: int, stop: int, withscores: bool = False
    ) -> Union[List[str], List[Tuple[str, float]]]: ...
    def zrevrangebylex(
        self,
        key: str,
        max: str,
        min: str,
        offset: Optional[int] = None,
        count: Optional[int] = None,
    ) -> List[str]: ...
    def zrevrangebyscore(
        self,
        key: str,
        max: FloatMinMaxT,
        min: FloatMinMaxT,
        withscores: bool = False,
        offset: Optional[int] = None,
        count: Optional[int] = None,
    ) -> Union[List[str], List[Tuple[str, float]]]: ...
    def zrevrank(self, key: str, member: str) -> Optional[int]: ...
    def zscan(
        self,
        key: str,
        cursor: int,
        match: Optional[str] = None,
        count: Optional[int] = None,
    ) -> Tuple[int, List[Tuple[str, float]]]: ...
    def zscore(self, key: str, member: str) -> Optional[float]: ...
    def zunion(
        self,
        keys: List[str],
        weights: Optional[List[float]] = None,
        aggregate: Optional[Literal["SUM", "MIN", "MAX"]] = None,
        withscores: bool = False,
    ) -> Union[List[str], List[Tuple[str, float]]]: ...
    def zunionstore(
        self,
        destination: str,
        keys: List[str],
        weights: Optional[List[float]] = None,
        aggregate: Optional[Literal["SUM", "MIN", "MAX"]] = None,
    ) -> int: ...
    def append(self, key: str, value: str) -> int: ...
    def decr(self, key: str) -> int: ...
    def decrby(self, key: str, decrement: int) -> int: ...
    def get(self, key: str) -> Optional[str]: ...
    def getdel(self, key: str) -> Optional[str]: ...
    def getex(
        self,
        key: str,
        ex: Optional[int] = None,
        px: Optional[int] = None,
        exat: Optional[int] = None,
        pxat: Optional[int] = None,
        persist: Optional[bool] = None,
    ) -> Optional[str]: ...
    def getrange(self, key: str, start: int, end: int) -> str: ...
    def getset(self, key: str, value: ValueT) -> Optional[str]: ...
    def incr(self, key: str) -> int: ...
    def incrby(self, key: str, increment: int) -> int: ...
    def incrbyfloat(self, key: str, increment: float) -> float: ...
    def mget(self, *keys: str) -> List[Optional[str]]: ...
    def mset(self, values: Mapping[str, ValueT]) -> Literal[True]: ...
    def msetnx(self, values: Mapping[str, ValueT]) -> bool: ...
    def psetex(self, key: str, milliseconds: int, value: str) -> Literal[True]: ...
    def set(
        self,
        key: str,
        value: ValueT,
        nx: bool = False,
        xx: bool = False,
        get: bool = False,
        ex: Optional[int] = None,
        px: Optional[int] = None,
        exat: Optional[int] = None,
        pxat: Optional[int] = None,
        keepttl: bool = False,
    ) -> Optional[str]: ...
    def setex(self, key: str, seconds: int, value: ValueT) -> Literal[True]: ...
    def setnx(self, key: str, value: ValueT) -> bool: ...
    def setrange(self, key: str, offset: int, value: str) -> int: ...
    def strlen(self, key: str) -> int: ...
    def substr(self, key: str, start: int, end: int) -> str: ...
    def script_exists(self, *sha1: str) -> List[bool]: ...
    def script_flush(
        self, flush_type: Optional[Literal["ASYNC", "SYNC"]] = None
    ) -> bool: ...
    def script_load(self, script: str) -> str: ...
    def xadd(
        self,
        key: str,
        id: str,
        data: Mapping[str, ValueT],
        maxlen: Optional[int] = None,
        approximate_trim: bool = True,
        nomkstream: bool = False,
        minid: Optional[str] = None,
        limit: Optional[int] = None,
    ) -> str: ...
    def xack(self, key: str, group: str, *ids: str) -> int: ...
    def xackdel(
        self,
        key: str,
        group: str,
        *ids: str,
        option: Optional[
            Literal["KEEPREF", "DELREF", "ACKED", "keepref", "delref", "acked"]
        ] = None,
    ) -> List[int]: ...
    def xautoclaim(
        self,
        key: str,
        group: str,
        consumer: str,
        min_idle_time: int,
        start: str = "0-0",
        count: Optional[int] = None,
        justid: Optional[bool] = None,
    ) -> Tuple[str, List[Any], List[str]]: ...
    def xclaim(
        self,
        key: str,
        group: str,
        consumer: str,
        min_idle_time: int,
        *ids: str,
        justid: Optional[bool] = None,
    ) -> Union[List[List[Any]], List[str]]: ...
    def xdel(self, key: str, *ids: str) -> int: ...
    def xdelex(
        self,
        key: str,
        *ids: str,
        option: Optional[
            Literal["KEEPREF", "DELREF", "ACKED", "keepref", "delref", "acked"]
        ] = None,
    ) -> List[int]: ...
    def xgroup_create(
        self,
        key: str,
        group: str,
        id: str = "$",
        mkstream: Optional[bool] = None,
    ) -> str: ...
    def xgroup_createconsumer(self, key: str, group: str, consumer: str) -> int: ...
    def xgroup_delconsumer(self, key: str, group: str, consumer: str) -> int: ...
    def xgroup_destroy(self, key: str, group: str) -> int: ...
    def xgroup_setid(
        self,
        key: str,
        group: str,
        id: str,
        entries_read: Optional[int] = None,
    ) -> str: ...
    def xinfo_consumers(self, key: str, group: str) -> List[List[Any]]: ...
    def xinfo_groups(self, key: str) -> List[List[Any]]: ...
    def xlen(self, key: str) -> int: ...
    def xpending(
        self,
        key: str,
        group: str,
        start: Optional[str] = None,
        end: Optional[str] = None,
        count: Optional[int] = None,
        consumer: Optional[str] = None,
        idle: Optional[int] = None,
    ) -> Any: ...
    def xrange(
        self,
        key: str,
        start: str = "-",
        end: str = "+",
        count: Optional[int] = None,
    ) -> List[Tuple[str, List[str]]]: ...
    def xread(
        self,
        streams: Dict[str, str],
        count: Optional[int] = None,
    ) -> List[List[Any]]: ...
    def xreadgroup(
        self,
        group: str,
        consumer: str,
        streams: Dict[str, str],
        count: Optional[int] = None,
        noack: Optional[bool] = None,
    ) -> List[List[Any]]: ...
    def xrevrange(
        self,
        key: str,
        end: str = "+",
        start: str = "-",
        count: Optional[int] = None,
    ) -> List[List[Any]]: ...
    def xtrim(
        self,
        key: str,
        maxlen: Optional[int] = None,
        approximate: Optional[bool] = None,
        minid: Optional[str] = None,
        limit: Optional[int] = None,
    ) -> int: ...

class AsyncCommands:
    def __init__(self): ...
    async def bitcount(
        self, key: str, start: Optional[int] = None, end: Optional[int] = None
    ) -> int: ...
    def bitfield(self, key: str) -> "AsyncBitFieldCommands": ...
    def bitfield_ro(self, key: str) -> "AsyncBitFieldROCommands": ...
    async def bitop(
        self,
        operation: Literal[
            "AND",
            "OR",
            "XOR",
            "NOT",
            "DIFF",
            "DIFF1",
            "ANDOR",
            "ONE",
            "and",
            "or",
            "xor",
            "not",
            "diff",
            "diff1",
            "andor",
            "one",
        ],
        destkey: str,
        *keys: str,
    ) -> int: ...
    async def bitpos(
        self,
        key: str,
        bit: Literal[0, 1],
        start: Optional[int] = None,
        end: Optional[int] = None,
    ) -> int: ...
    async def getbit(self, key: str, offset: int) -> Literal[0, 1]: ...
    async def setbit(self, key: str, offset: int, value: Literal[0, 1]) -> int: ...
    async def ping(self, message: Optional[str] = None) -> str: ...
    async def echo(self, message: str) -> str: ...
    async def client_setinfo(
        self,
        attribute: Literal["LIB-NAME", "LIB-VER", "lib-name", "lib-ver"],
        value: str,
    ) -> str: ...
    async def copy(
        self, source: str, destination: str, replace: bool = False
    ) -> bool: ...
    async def delete(self, *keys: str) -> int: ...
    async def exists(self, *keys: str) -> int: ...
    async def expire(
        self,
        key: str,
        seconds: Union[int, datetime.timedelta],
        nx: bool = False,
        xx: bool = False,
        gt: bool = False,
        lt: bool = False,
    ) -> bool: ...
    async def expireat(
        self,
        key: str,
        unix_time_seconds: Union[int, datetime.datetime],
        nx: bool = False,
        xx: bool = False,
        gt: bool = False,
        lt: bool = False,
    ) -> bool: ...
    async def keys(self, pattern: str) -> List[str]: ...
    async def persist(self, key: str) -> bool: ...
    async def pexpire(
        self,
        key: str,
        milliseconds: Union[int, datetime.timedelta],
        nx: bool = False,
        xx: bool = False,
        gt: bool = False,
        lt: bool = False,
    ) -> bool: ...
    async def pexpireat(
        self,
        key: str,
        unix_time_milliseconds: Union[int, datetime.datetime],
        nx: bool = False,
        xx: bool = False,
        gt: bool = False,
        lt: bool = False,
    ) -> bool: ...
    async def pttl(self, key: str) -> int: ...
    async def randomkey(self) -> Optional[str]: ...
    async def rename(self, key: str, newkey: str) -> bool: ...
    async def renamenx(self, key: str, newkey: str) -> bool: ...
    async def scan(
        self,
        cursor: int,
        match: Optional[str] = None,
        count: Optional[int] = None,
        type: Optional[str] = None,
    ) -> Tuple[int, List[str]]: ...
    async def touch(self, *keys: str) -> int: ...
    async def ttl(self, key: str) -> int: ...
    async def type(self, key: str) -> Optional[str]: ...
    async def unlink(self, *keys: str) -> int: ...
    async def geoadd(
        self,
        key: str,
        *members: Tuple[float, float, str],
        nx: bool = False,
        xx: bool = False,
        ch: bool = False,
    ) -> int: ...
    async def geodist(
        self,
        key: str,
        member1: str,
        member2: str,
        unit: Literal["M", "KM", "FT", "MI"] = "M",
    ) -> Optional[float]: ...
    async def geohash(self, key: str, *members: str) -> List[Optional[str]]: ...
    async def geopos(
        self, key: str, *members: str
    ) -> List[Union[Tuple[float, float], None]]: ...
    async def georadius(
        self,
        key: str,
        longitude: float,
        latitude: float,
        radius: float,
        unit: Literal["M", "KM", "FT", "MI"],
        withdist: bool = False,
        withhash: bool = False,
        withcoord: bool = False,
        count: Optional[int] = None,
        any: bool = False,
        order: Optional[Literal["ASC", "DESC"]] = None,
        store: Optional[str] = None,
        storedist: Optional[str] = None,
    ) -> Union[List[Union[str, GeoSearchResult]], int]: ...
    async def georadius_ro(
        self,
        key: str,
        longitude: float,
        latitude: float,
        radius: float,
        unit: Literal["M", "KM", "FT", "MI"],
        withdist: bool = False,
        withhash: bool = False,
        withcoord: bool = False,
        count: Optional[int] = None,
        any: bool = False,
        order: Optional[Literal["ASC", "DESC"]] = None,
    ) -> List[Union[str, GeoSearchResult]]: ...
    async def georadiusbymember(
        self,
        key: str,
        member: str,
        radius: float,
        unit: Literal["M", "KM", "FT", "MI"],
        withdist: bool = False,
        withhash: bool = False,
        withcoord: bool = False,
        count: Optional[int] = None,
        any: bool = False,
        order: Optional[Literal["ASC", "DESC"]] = None,
        store: Optional[str] = None,
        storedist: Optional[str] = None,
    ) -> Union[List[Union[str, GeoSearchResult]], int]: ...
    async def georadiusbymember_ro(
        self,
        key: str,
        member: str,
        radius: float,
        unit: Literal["M", "KM", "FT", "MI"],
        withdist: bool = False,
        withhash: bool = False,
        withcoord: bool = False,
        count: Optional[int] = None,
        any: bool = False,
        order: Optional[Literal["ASC", "DESC"]] = None,
    ) -> List[Union[str, GeoSearchResult]]: ...
    async def geosearch(
        self,
        key: str,
        unit: Literal["M", "KM", "FT", "MI"],
        member: Optional[str] = None,
        longitude: Optional[float] = None,
        latitude: Optional[float] = None,
        radius: Optional[float] = None,
        width: Optional[float] = None,
        height: Optional[float] = None,
        order: Optional[Literal["ASC", "DESC"]] = None,
        count: Optional[int] = None,
        any: bool = False,
        withdist: bool = False,
        withhash: bool = False,
        withcoord: bool = False,
    ) -> List[Union[str, GeoSearchResult]]: ...
    async def geosearchstore(
        self,
        destination: str,
        source: str,
        member: Optional[str] = None,
        longitude: Optional[float] = None,
        latitude: Optional[float] = None,
        unit: Literal["M", "KM", "FT", "MI"] = "M",
        radius: Optional[float] = None,
        width: Optional[float] = None,
        height: Optional[float] = None,
        order: Optional[Literal["ASC", "DESC"]] = None,
        count: Optional[int] = None,
        any: bool = False,
        storedist: bool = False,
    ) -> int: ...
    async def hdel(self, key: str, *fields: str) -> int: ...
    async def hexists(self, key: str, field: str) -> bool: ...
    async def hexpire(
        self,
        key: str,
        fields: Union[str, List[str]],
        seconds: Union[int, datetime.timedelta],
        nx: bool = False,
        xx: bool = False,
        gt: bool = False,
        lt: bool = False,
    ) -> List[int]: ...
    async def hpexpire(
        self,
        key: str,
        fields: Union[str, List[str]],
        milliseconds: Union[int, datetime.timedelta],
        nx: bool = False,
        xx: bool = False,
        gt: bool = False,
        lt: bool = False,
    ) -> List[int]: ...
    async def hexpireat(
        self,
        key: str,
        fields: Union[str, List[str]],
        unix_time_seconds: Union[int, datetime.datetime],
        nx: bool = False,
        xx: bool = False,
        gt: bool = False,
        lt: bool = False,
    ) -> List[int]: ...
    async def hpexpireat(
        self,
        key: str,
        fields: Union[str, List[str]],
        unix_time_milliseconds: Union[int, datetime.datetime],
        nx: bool = False,
        xx: bool = False,
        gt: bool = False,
        lt: bool = False,
    ) -> List[int]: ...
    async def httl(self, key: str, fields: Union[str, List[str]]) -> List[int]: ...
    async def hpttl(self, key: str, fields: Union[str, List[str]]) -> List[int]: ...
    async def hexpiretime(
        self, key: str, fields: Union[str, List[str]]
    ) -> List[int]: ...
    async def hpexpiretime(
        self, key: str, fields: Union[str, List[str]]
    ) -> List[int]: ...
    async def hpersist(self, key: str, fields: Union[str, List[str]]) -> List[int]: ...
    async def hget(self, key: str, field: str) -> Optional[str]: ...
    async def hgetdel(self, key: str, *fields: str) -> List[Optional[str]]: ...
    async def hgetex(
        self,
        key: str,
        *fields: str,
        ex: Optional[int] = None,
        px: Optional[int] = None,
        exat: Optional[int] = None,
        pxat: Optional[int] = None,
        persist: Optional[bool] = None,
    ) -> List[Optional[str]]: ...
    async def hgetall(self, key: str) -> Dict[str, str]: ...
    async def hincrby(self, key: str, field: str, increment: int) -> int: ...
    async def hincrbyfloat(self, key: str, field: str, increment: float) -> float: ...
    async def hkeys(self, key: str) -> List[str]: ...
    async def hlen(self, key: str) -> int: ...
    async def hmget(self, key: str, *fields: str) -> List[Optional[str]]: ...
    async def hmset(self, key: str, values: Mapping[str, ValueT]) -> bool: ...
    async def hrandfield(
        self, key: str, count: Optional[int] = None, withvalues: bool = False
    ) -> Union[str, None, List[str], Dict[str, str]]: ...
    async def hscan(
        self,
        key: str,
        cursor: int,
        match: Optional[str] = None,
        count: Optional[int] = None,
    ) -> Tuple[int, Dict[str, str]]: ...
    async def hset(
        self,
        key: str,
        field: Optional[str] = None,
        value: Optional[ValueT] = None,
        values: Optional[Mapping[str, ValueT]] = None,
    ) -> int: ...
    async def hsetnx(self, key: str, field: str, value: ValueT) -> bool: ...
    async def hsetex(
        self,
        key: str,
        field: Optional[str] = None,
        value: Optional[ValueT] = None,
        values: Optional[Mapping[str, ValueT]] = None,
        fnx: bool = False,
        fxx: bool = False,
        ex: Optional[int] = None,
        px: Optional[int] = None,
        exat: Optional[int] = None,
        pxat: Optional[int] = None,
        keepttl: bool = False,
    ) -> int: ...
    async def hstrlen(self, key: str, field: str) -> int: ...
    async def hvals(self, key: str) -> List[str]: ...
    async def pfadd(self, key: str, *elements: ValueT) -> bool: ...
    async def pfcount(self, *keys: str) -> int: ...
    async def pfmerge(self, destkey: str, *sourcekeys: str) -> bool: ...
    async def lindex(self, key: str, index: int) -> Optional[str]: ...
    async def linsert(
        self,
        key: str,
        where: Literal["BEFORE", "AFTER"],
        pivot: ValueT,
        element: str,
    ) -> int: ...
    async def llen(self, key: str) -> int: ...
    async def lmove(
        self,
        source: str,
        destination: str,
        wherefrom: Literal["LEFT", "RIGHT"] = "LEFT",
        whereto: Literal["LEFT", "RIGHT"] = "RIGHT",
    ) -> Optional[str]: ...
    async def lpop(
        self, key: str, count: Optional[int] = None
    ) -> Union[str, List[str], None]: ...
    async def lpos(
        self,
        key: str,
        element: ValueT,
        rank: Optional[int] = None,
        count: Optional[int] = None,
        maxlen: Optional[int] = None,
    ) -> Union[(Optional[int]), List[int]]: ...
    async def lpush(self, key: str, *elements: ValueT) -> int: ...
    async def lpushx(self, key: str, *elements: ValueT) -> int: ...
    async def lrange(self, key: str, start: int, stop: int) -> List[str]: ...
    async def lrem(self, key: str, count: int, element: ValueT) -> int: ...
    async def lset(self, key: str, index: int, element: ValueT) -> bool: ...
    async def ltrim(self, key: str, start: int, stop: int) -> str: ...
    async def rpop(
        self, key: str, count: Optional[int] = None
    ) -> Union[str, List[str], None]: ...
    async def rpoplpush(self, source: str, destination: str) -> Optional[str]: ...
    async def rpush(self, key: str, *elements: ValueT) -> int: ...
    async def rpushx(self, key: str, *elements: ValueT) -> int: ...
    async def publish(self, channel: str, message: ValueT) -> int: ...
    async def eval(
        self,
        script: str,
        keys: Optional[List[str]] = None,
        args: Optional[List[str]] = None,
    ) -> Any: ...
    async def eval_ro(
        self,
        script: str,
        keys: Optional[List[str]] = None,
        args: Optional[List[str]] = None,
    ) -> Any: ...
    async def evalsha(
        self,
        sha1: str,
        keys: Optional[List[str]] = None,
        args: Optional[List[str]] = None,
    ) -> Any: ...
    async def evalsha_ro(
        self,
        sha1: str,
        keys: Optional[List[str]] = None,
        args: Optional[List[str]] = None,
    ) -> Any: ...
    async def dbsize(self) -> int: ...
    async def flushall(
        self, flush_type: Optional[Literal["ASYNC", "SYNC"]] = None
    ) -> bool: ...
    async def flushdb(
        self, flush_type: Optional[Literal["ASYNC", "SYNC"]] = None
    ) -> bool: ...
    async def time(self) -> Tuple[int, int]: ...
    async def sadd(self, key: str, *members: ValueT) -> int: ...
    async def scard(self, key: str) -> int: ...
    async def sdiff(self, *keys: str) -> List[str]: ...
    async def sdiffstore(self, destination: str, *keys: str) -> int: ...
    async def sinter(self, *keys: str) -> List[str]: ...
    async def sinterstore(self, destination: str, *keys: str) -> int: ...
    async def sismember(self, key: str, member: ValueT) -> bool: ...
    async def smismember(self, key: str, *members: ValueT) -> List[bool]: ...
    async def smembers(self, key: str) -> List[str]: ...
    async def smove(self, source: str, destination: str, member: ValueT) -> bool: ...
    async def spop(
        self, key: str, count: Optional[int] = None
    ) -> Union[str, List[str], None]: ...
    async def srandmember(
        self, key: str, count: Optional[int] = None
    ) -> Union[str, List[str], None]: ...
    async def srem(self, key: str, *members: ValueT) -> int: ...
    async def sscan(
        self,
        key: str,
        cursor: int = 0,
        match: Optional[str] = None,
        count: Optional[int] = None,
    ) -> Tuple[int, List[str]]: ...
    async def sunion(self, *keys: str) -> List[str]: ...
    async def sunionstore(self, destination: str, *keys: str) -> int: ...
    async def zadd(
        self,
        key: str,
        scores: Dict[str, float],
        nx: bool = False,
        xx: bool = False,
        gt: bool = False,
        lt: bool = False,
        ch: bool = False,
        incr: bool = False,
    ) -> Union[int, float, None]: ...
    async def zcard(self, key: str) -> int: ...
    async def zcount(self, key: str, min: FloatMinMaxT, max: FloatMinMaxT) -> int: ...
    async def zdiff(
        self, keys: List[str], withscores: bool = False
    ) -> Union[List[str], List[Tuple[str, float]]]: ...
    async def zdiffstore(self, destination: str, keys: List[str]) -> int: ...
    async def zincrby(self, key: str, increment: float, member: str) -> float: ...
    async def zinter(
        self,
        keys: List[str],
        weights: Union[List[float], List[int], None] = None,
        aggregate: Optional[Literal["SUM", "MIN", "MAX"]] = None,
        withscores: bool = False,
    ) -> Union[List[str], List[Tuple[str, float]]]: ...
    async def zinterstore(
        self,
        destination: str,
        keys: List[str],
        weights: Union[List[float], List[int], None] = None,
        aggregate: Optional[Literal["SUM", "MIN", "MAX"]] = None,
    ) -> int: ...
    async def zlexcount(self, key: str, min: str, max: str) -> int: ...
    async def zmscore(self, key: str, members: List[str]) -> List[Optional[float]]: ...
    async def zpopmax(
        self, key: str, count: Optional[int] = None
    ) -> List[Tuple[str, float]]: ...
    async def zpopmin(
        self, key: str, count: Optional[int] = None
    ) -> List[Tuple[str, float]]: ...
    async def zrandmember(
        self, key: str, count: Optional[int] = None, withscores: bool = False
    ) -> Union[str, None, List[str], List[Tuple[str, float]]]: ...
    async def zrange(
        self,
        key: str,
        start: FloatMinMaxT,
        stop: FloatMinMaxT,
        sortby: Optional[Literal["BYSCORE", "BYLEX"]] = None,
        rev: bool = False,
        offset: Optional[int] = None,
        count: Optional[int] = None,
        withscores: bool = False,
    ) -> Union[List[str], List[Tuple[str, float]]]: ...
    async def zrangebylex(
        self,
        key: str,
        min: str,
        max: str,
        offset: Optional[int] = None,
        count: Optional[int] = None,
    ) -> List[str]: ...
    async def zrangebyscore(
        self,
        key: str,
        min: FloatMinMaxT,
        max: FloatMinMaxT,
        withscores: bool = False,
        offset: Optional[int] = None,
        count: Optional[int] = None,
    ) -> Union[List[str], List[Tuple[str, float]]]: ...
    async def zrangestore(
        self,
        dst: str,
        src: str,
        min: FloatMinMaxT,
        max: FloatMinMaxT,
        sortby: Optional[Literal["BYSCORE", "BYLEX"]] = None,
        rev: bool = False,
        offset: Optional[int] = None,
        count: Optional[int] = None,
    ) -> int: ...
    async def zrank(self, key: str, member: str) -> Optional[int]: ...
    async def zrem(self, key: str, *members: str) -> int: ...
    async def zremrangebylex(self, key: str, min: str, max: str) -> int: ...
    async def zremrangebyrank(self, key: str, start: int, stop: int) -> int: ...
    async def zremrangebyscore(
        self, key: str, min: FloatMinMaxT, max: FloatMinMaxT
    ) -> int: ...
    async def zrevrange(
        self, key: str, start: int, stop: int, withscores: bool = False
    ) -> Union[List[str], List[Tuple[str, float]]]: ...
    async def zrevrangebylex(
        self,
        key: str,
        max: str,
        min: str,
        offset: Optional[int] = None,
        count: Optional[int] = None,
    ) -> List[str]: ...
    async def zrevrangebyscore(
        self,
        key: str,
        max: FloatMinMaxT,
        min: FloatMinMaxT,
        withscores: bool = False,
        offset: Optional[int] = None,
        count: Optional[int] = None,
    ) -> Union[List[str], List[Tuple[str, float]]]: ...
    async def zrevrank(self, key: str, member: str) -> Optional[int]: ...
    async def zscan(
        self,
        key: str,
        cursor: int,
        match: Optional[str] = None,
        count: Optional[int] = None,
    ) -> Tuple[int, List[Tuple[str, float]]]: ...
    async def zscore(self, key: str, member: str) -> Optional[float]: ...
    async def zunion(
        self,
        keys: List[str],
        weights: Optional[List[float]] = None,
        aggregate: Optional[Literal["SUM", "MIN", "MAX"]] = None,
        withscores: bool = False,
    ) -> Union[List[str], List[Tuple[str, float]]]: ...
    async def zunionstore(
        self,
        destination: str,
        keys: List[str],
        weights: Optional[List[float]] = None,
        aggregate: Optional[Literal["SUM", "MIN", "MAX"]] = None,
    ) -> int: ...
    async def append(self, key: str, value: str) -> int: ...
    async def decr(self, key: str) -> int: ...
    async def decrby(self, key: str, decrement: int) -> int: ...
    async def get(self, key: str) -> Optional[str]: ...
    async def getdel(self, key: str) -> Optional[str]: ...
    async def getex(
        self,
        key: str,
        ex: Optional[int] = None,
        px: Optional[int] = None,
        exat: Optional[int] = None,
        pxat: Optional[int] = None,
        persist: Optional[bool] = None,
    ) -> Optional[str]: ...
    async def getrange(self, key: str, start: int, end: int) -> str: ...
    async def getset(self, key: str, value: ValueT) -> Optional[str]: ...
    async def incr(self, key: str) -> int: ...
    async def incrby(self, key: str, increment: int) -> int: ...
    async def incrbyfloat(self, key: str, increment: float) -> float: ...
    async def mget(self, *keys: str) -> List[Optional[str]]: ...
    async def mset(self, values: Mapping[str, ValueT]) -> Literal[True]: ...
    async def msetnx(self, values: Mapping[str, ValueT]) -> bool: ...
    async def psetex(
        self, key: str, milliseconds: int, value: str
    ) -> Literal[True]: ...
    async def set(
        self,
        key: str,
        value: ValueT,
        nx: bool = False,
        xx: bool = False,
        get: bool = False,
        ex: Optional[int] = None,
        px: Optional[int] = None,
        exat: Optional[int] = None,
        pxat: Optional[int] = None,
        keepttl: bool = False,
    ) -> Optional[str]: ...
    async def setex(self, key: str, seconds: int, value: ValueT) -> Literal[True]: ...
    async def setnx(self, key: str, value: ValueT) -> bool: ...
    async def setrange(self, key: str, offset: int, value: str) -> int: ...
    async def strlen(self, key: str) -> int: ...
    async def substr(self, key: str, start: int, end: int) -> str: ...
    async def script_exists(self, *sha1: str) -> List[bool]: ...
    async def script_flush(
        self, flush_type: Optional[Literal["ASYNC", "SYNC"]] = None
    ) -> bool: ...
    async def script_load(self, script: str) -> str: ...
    async def xadd(
        self,
        key: str,
        id: str,
        data: Mapping[str, ValueT],
        maxlen: Optional[int] = None,
        approximate_trim: bool = True,
        nomkstream: bool = False,
        minid: Optional[str] = None,
        limit: Optional[int] = None,
    ) -> str: ...
    async def xack(self, key: str, group: str, *ids: str) -> int: ...
    async def xackdel(
        self,
        key: str,
        group: str,
        *ids: str,
        option: Optional[
            Literal["KEEPREF", "DELREF", "ACKED", "keepref", "delref", "acked"]
        ] = None,
    ) -> List[int]: ...
    async def xautoclaim(
        self,
        key: str,
        group: str,
        consumer: str,
        min_idle_time: int,
        start: str = "0-0",
        count: Optional[int] = None,
        justid: Optional[bool] = None,
    ) -> Tuple[str, List[Any], List[str]]: ...
    async def xclaim(
        self,
        key: str,
        group: str,
        consumer: str,
        min_idle_time: int,
        *ids: str,
        justid: Optional[bool] = None,
    ) -> Union[List[List[Any]], List[str]]: ...
    async def xdel(self, key: str, *ids: str) -> int: ...
    async def xdelex(
        self,
        key: str,
        *ids: str,
        option: Optional[
            Literal["KEEPREF", "DELREF", "ACKED", "keepref", "delref", "acked"]
        ] = None,
    ) -> List[int]: ...
    async def xgroup_create(
        self,
        key: str,
        group: str,
        id: str = "$",
        mkstream: Optional[bool] = None,
    ) -> bool: ...
    async def xgroup_createconsumer(
        self, key: str, group: str, consumer: str
    ) -> int: ...
    async def xgroup_delconsumer(self, key: str, group: str, consumer: str) -> int: ...
    async def xgroup_destroy(self, key: str, group: str) -> int: ...
    async def xgroup_setid(
        self,
        key: str,
        group: str,
        id: str,
        entries_read: Optional[int] = None,
    ) -> bool: ...
    async def xinfo_consumers(self, key: str, group: str) -> List[List[Any]]: ...
    async def xinfo_groups(self, key: str) -> List[List[Any]]: ...
    async def xlen(self, key: str) -> int: ...
    async def xpending(
        self,
        key: str,
        group: str,
        start: Optional[str] = None,
        end: Optional[str] = None,
        count: Optional[int] = None,
        consumer: Optional[str] = None,
        idle: Optional[int] = None,
    ) -> Any: ...
    async def xrange(
        self,
        key: str,
        start: str = "-",
        end: str = "+",
        count: Optional[int] = None,
    ) -> List[Tuple[str, List[str]]]: ...
    async def xread(
        self,
        streams: Dict[str, str],
        count: Optional[int] = None,
    ) -> List[List[Any]]: ...
    async def xreadgroup(
        self,
        group: str,
        consumer: str,
        streams: Dict[str, str],
        count: Optional[int] = None,
        noack: Optional[bool] = None,
    ) -> List[List[Any]]: ...
    async def xrevrange(
        self,
        key: str,
        end: str = "+",
        start: str = "-",
        count: Optional[int] = None,
    ) -> List[List[Any]]: ...
    async def xtrim(
        self,
        key: str,
        maxlen: Optional[int] = None,
        approximate: Optional[bool] = None,
        minid: Optional[str] = None,
        limit: Optional[int] = None,
    ) -> int: ...

class BitFieldCommands:
    def __init__(self, client: Commands, key: str): ...
    def get(self, encoding: str, offset: Union[int, str]) -> "BitFieldCommands": ...
    def set(
        self, encoding: str, offset: Union[int, str], value: int
    ) -> "BitFieldCommands": ...
    def incrby(
        self, encoding: str, offset: Union[int, str], increment: int
    ) -> "BitFieldCommands": ...
    def overflow(
        self, overflow: Literal["WRAP", "SAT", "FAIL"]
    ) -> "BitFieldCommands": ...
    def execute(self) -> List: ...

class BitFieldROCommands:
    def __init__(self, client: Commands, key: str): ...
    def get(self, encoding: str, offset: Union[int, str]) -> "BitFieldROCommands": ...
    def execute(self) -> List: ...

class AsyncBitFieldCommands:
    def __init__(self, client: AsyncCommands, key: str): ...
    def get(
        self, encoding: str, offset: Union[int, str]
    ) -> "AsyncBitFieldCommands": ...
    def set(
        self, encoding: str, offset: Union[int, str], value: int
    ) -> "AsyncBitFieldCommands": ...
    def incrby(
        self, encoding: str, offset: Union[int, str], increment: int
    ) -> "AsyncBitFieldCommands": ...
    def overflow(
        self, overflow: Literal["WRAP", "SAT", "FAIL"]
    ) -> "AsyncBitFieldCommands": ...
    async def execute(self) -> List: ...

class AsyncBitFieldROCommands:
    def __init__(self, client: AsyncCommands, key: str): ...
    def get(
        self, encoding: str, offset: Union[int, str]
    ) -> "AsyncBitFieldROCommands": ...
    async def execute(self) -> List: ...

class PipelineCommands:
    def bitcount(
        self, key: str, start: Optional[int] = None, end: Optional[int] = None
    ) -> PipelineCommands: ...
    def bitfield(self, key: str) -> PipelineCommands: ...
    def bitfield_ro(self, key: str) -> PipelineCommands: ...
    def bitop(
        self,
        operation: Literal[
            "AND",
            "OR",
            "XOR",
            "NOT",
            "DIFF",
            "DIFF1",
            "ANDOR",
            "ONE",
            "and",
            "or",
            "xor",
            "not",
            "diff",
            "diff1",
            "andor",
            "one",
        ],
        destkey: str,
        *keys: str,
    ) -> PipelineCommands: ...
    def bitpos(
        self,
        key: str,
        bit: Literal[0, 1],
        start: Optional[int] = None,
        end: Optional[int] = None,
    ) -> PipelineCommands: ...
    def getbit(self, key: str, offset: int) -> PipelineCommands: ...
    def setbit(
        self, key: str, offset: int, value: Literal[0, 1]
    ) -> PipelineCommands: ...
    def ping(self, message: Optional[str] = None) -> PipelineCommands: ...
    def echo(self, message: str) -> PipelineCommands: ...
    def client_setinfo(
        self,
        attribute: Literal["LIB-NAME", "LIB-VER", "lib-name", "lib-ver"],
        value: str,
    ) -> PipelineCommands: ...
    def copy(
        self, source: str, destination: str, replace: bool = False
    ) -> PipelineCommands: ...
    def delete(self, *keys: str) -> PipelineCommands: ...
    def exists(self, *keys: str) -> PipelineCommands: ...
    def expire(
        self,
        key: str,
        seconds: Union[int, datetime.timedelta],
        nx: bool = False,
        xx: bool = False,
        gt: bool = False,
        lt: bool = False,
    ) -> PipelineCommands: ...
    def expireat(
        self,
        key: str,
        unix_time_seconds: Union[int, datetime.datetime],
        nx: bool = False,
        xx: bool = False,
        gt: bool = False,
        lt: bool = False,
    ) -> PipelineCommands: ...
    def keys(self, pattern: str) -> PipelineCommands: ...
    def persist(self, key: str) -> PipelineCommands: ...
    def pexpire(
        self,
        key: str,
        milliseconds: Union[int, datetime.timedelta],
        nx: bool = False,
        xx: bool = False,
        gt: bool = False,
        lt: bool = False,
    ) -> PipelineCommands: ...
    def pexpireat(
        self,
        key: str,
        unix_time_milliseconds: Union[int, datetime.datetime],
        nx: bool = False,
        xx: bool = False,
        gt: bool = False,
        lt: bool = False,
    ) -> PipelineCommands: ...
    def pttl(self, key: str) -> PipelineCommands: ...
    def randomkey(self) -> PipelineCommands: ...
    def rename(self, key: str, newkey: str) -> PipelineCommands: ...
    def renamenx(self, key: str, newkey: str) -> PipelineCommands: ...
    def scan(
        self,
        cursor: int,
        match: Optional[str] = None,
        count: Optional[int] = None,
        type: Optional[str] = None,
    ) -> PipelineCommands: ...
    def touch(self, *keys: str) -> PipelineCommands: ...
    def ttl(self, key: str) -> PipelineCommands: ...
    def type(self, key: str) -> PipelineCommands: ...
    def unlink(self, *keys: str) -> PipelineCommands: ...
    def geoadd(
        self,
        key: str,
        *members: Tuple[float, float, str],
        nx: bool = False,
        xx: bool = False,
        ch: bool = False,
    ) -> PipelineCommands: ...
    def geodist(
        self,
        key: str,
        member1: str,
        member2: str,
        unit: Literal["M", "KM", "FT", "MI"] = "M",
    ) -> PipelineCommands: ...
    def geohash(self, key: str, *members: str) -> PipelineCommands: ...
    def geopos(self, key: str, *members: str) -> PipelineCommands: ...
    def georadius(
        self,
        key: str,
        longitude: float,
        latitude: float,
        radius: float,
        unit: Literal["M", "KM", "FT", "MI"],
        withdist: bool = False,
        withhash: bool = False,
        withcoord: bool = False,
        count: Optional[int] = None,
        any: bool = False,
        order: Optional[Literal["ASC", "DESC"]] = None,
        store: Optional[str] = None,
        storedist: Optional[str] = None,
    ) -> PipelineCommands: ...
    def georadius_ro(
        self,
        key: str,
        longitude: float,
        latitude: float,
        radius: float,
        unit: Literal["M", "KM", "FT", "MI"],
        withdist: bool = False,
        withhash: bool = False,
        withcoord: bool = False,
        count: Optional[int] = None,
        any: bool = False,
        order: Optional[Literal["ASC", "DESC"]] = None,
    ) -> PipelineCommands: ...
    def georadiusbymember(
        self,
        key: str,
        member: str,
        radius: float,
        unit: Literal["M", "KM", "FT", "MI"],
        withdist: bool = False,
        withhash: bool = False,
        withcoord: bool = False,
        count: Optional[int] = None,
        any: bool = False,
        order: Optional[Literal["ASC", "DESC"]] = None,
        store: Optional[str] = None,
        storedist: Optional[str] = None,
    ) -> PipelineCommands: ...
    def georadiusbymember_ro(
        self,
        key: str,
        member: str,
        radius: float,
        unit: Literal["M", "KM", "FT", "MI"],
        withdist: bool = False,
        withhash: bool = False,
        withcoord: bool = False,
        count: Optional[int] = None,
        any: bool = False,
        order: Optional[Literal["ASC", "DESC"]] = None,
    ) -> PipelineCommands: ...
    def geosearch(
        self,
        key: str,
        unit: Literal["M", "KM", "FT", "MI"],
        member: Optional[str] = None,
        longitude: Optional[float] = None,
        latitude: Optional[float] = None,
        radius: Optional[float] = None,
        width: Optional[float] = None,
        height: Optional[float] = None,
        order: Optional[Literal["ASC", "DESC"]] = None,
        count: Optional[int] = None,
        any: bool = False,
        withdist: bool = False,
        withhash: bool = False,
        withcoord: bool = False,
    ) -> PipelineCommands: ...
    def geosearchstore(
        self,
        destination: str,
        source: str,
        member: Optional[str] = None,
        longitude: Optional[float] = None,
        latitude: Optional[float] = None,
        unit: Literal["M", "KM", "FT", "MI"] = "M",
        radius: Optional[float] = None,
        width: Optional[float] = None,
        height: Optional[float] = None,
        order: Optional[Literal["ASC", "DESC"]] = None,
        count: Optional[int] = None,
        any: bool = False,
        storedist: bool = False,
    ) -> PipelineCommands: ...
    def hdel(self, key: str, *fields: str) -> PipelineCommands: ...
    def hexists(self, key: str, field: str) -> PipelineCommands: ...
    def hexpire(
        self,
        key: str,
        fields: Union[str, List[str]],
        seconds: Union[int, datetime.timedelta],
        nx: bool = False,
        xx: bool = False,
        gt: bool = False,
        lt: bool = False,
    ) -> PipelineCommands: ...
    def hpexpire(
        self,
        key: str,
        fields: Union[str, List[str]],
        milliseconds: Union[int, datetime.timedelta],
        nx: bool = False,
        xx: bool = False,
        gt: bool = False,
        lt: bool = False,
    ) -> PipelineCommands: ...
    def hexpireat(
        self,
        key: str,
        fields: Union[str, List[str]],
        unix_time_seconds: Union[int, datetime.datetime],
        nx: bool = False,
        xx: bool = False,
        gt: bool = False,
        lt: bool = False,
    ) -> PipelineCommands: ...
    def hpexpireat(
        self,
        key: str,
        fields: Union[str, List[str]],
        unix_time_milliseconds: Union[int, datetime.datetime],
        nx: bool = False,
        xx: bool = False,
        gt: bool = False,
        lt: bool = False,
    ) -> PipelineCommands: ...
    def httl(self, key: str, fields: Union[str, List[str]]) -> PipelineCommands: ...
    def hpttl(self, key: str, fields: Union[str, List[str]]) -> PipelineCommands: ...
    def hexpiretime(
        self, key: str, fields: Union[str, List[str]]
    ) -> PipelineCommands: ...
    def hpexpiretime(
        self, key: str, fields: Union[str, List[str]]
    ) -> PipelineCommands: ...
    def hpersist(self, key: str, fields: Union[str, List[str]]) -> PipelineCommands: ...
    def hget(self, key: str, field: str) -> PipelineCommands: ...
    def hgetdel(self, key: str, *fields: str) -> PipelineCommands: ...
    def hgetex(
        self,
        key: str,
        *fields: str,
        ex: Optional[int] = None,
        px: Optional[int] = None,
        exat: Optional[int] = None,
        pxat: Optional[int] = None,
        persist: Optional[bool] = None,
    ) -> PipelineCommands: ...
    def hgetall(self, key: str) -> PipelineCommands: ...
    def hincrby(self, key: str, field: str, increment: int) -> PipelineCommands: ...
    def hincrbyfloat(
        self, key: str, field: str, increment: float
    ) -> PipelineCommands: ...
    def hkeys(self, key: str) -> PipelineCommands: ...
    def hlen(self, key: str) -> PipelineCommands: ...
    def hmget(self, key: str, *fields: str) -> PipelineCommands: ...
    def hmset(self, key: str, values: Mapping[str, ValueT]) -> PipelineCommands: ...
    def hrandfield(
        self, key: str, count: Optional[int] = None, withvalues: bool = False
    ) -> PipelineCommands: ...
    def hscan(
        self,
        key: str,
        cursor: int,
        match: Optional[str] = None,
        count: Optional[int] = None,
    ) -> PipelineCommands: ...
    def hset(
        self,
        key: str,
        field: Optional[str] = None,
        value: Optional[str] = None,
        values: Optional[Mapping[str, ValueT]] = None,
    ) -> PipelineCommands: ...
    def hsetnx(self, key: str, field: str, value: ValueT) -> PipelineCommands: ...
    def hsetex(
        self,
        key: str,
        field: Optional[str] = None,
        value: Optional[ValueT] = None,
        values: Optional[Mapping[str, ValueT]] = None,
        fnx: bool = False,
        fxx: bool = False,
        ex: Optional[int] = None,
        px: Optional[int] = None,
        exat: Optional[int] = None,
        pxat: Optional[int] = None,
        keepttl: bool = False,
    ) -> PipelineCommands: ...
    def hstrlen(self, key: str, field: str) -> PipelineCommands: ...
    def hvals(self, key: str) -> PipelineCommands: ...
    def pfadd(self, key: str, *elements: ValueT) -> PipelineCommands: ...
    def pfcount(self, *keys: str) -> PipelineCommands: ...
    def pfmerge(self, destkey: str, *sourcekeys: str) -> PipelineCommands: ...
    def lindex(self, key: str, index: int) -> PipelineCommands: ...
    def linsert(
        self,
        key: str,
        where: Literal["BEFORE", "AFTER"],
        pivot: ValueT,
        element: str,
    ) -> PipelineCommands: ...
    def llen(self, key: str) -> PipelineCommands: ...
    def lmove(
        self,
        source: str,
        destination: str,
        wherefrom: Literal["LEFT", "RIGHT"] = "LEFT",
        whereto: Literal["LEFT", "RIGHT"] = "RIGHT",
    ) -> PipelineCommands: ...
    def lpop(self, key: str, count: Optional[int] = None) -> PipelineCommands: ...
    def lpos(
        self,
        key: str,
        element: ValueT,
        rank: Optional[int] = None,
        count: Optional[int] = None,
        maxlen: Optional[int] = None,
    ) -> Union[(Optional[int]), List[int]]: ...
    def lpush(self, key: str, *elements: ValueT) -> PipelineCommands: ...
    def lpushx(self, key: str, *elements: ValueT) -> PipelineCommands: ...
    def lrange(self, key: str, start: int, stop: int) -> PipelineCommands: ...
    def lrem(self, key: str, count: int, element: ValueT) -> PipelineCommands: ...
    def lset(self, key: str, index: int, element: ValueT) -> PipelineCommands: ...
    def ltrim(self, key: str, start: int, stop: int) -> PipelineCommands: ...
    def rpop(self, key: str, count: Optional[int] = None) -> PipelineCommands: ...
    def rpoplpush(self, source: str, destination: str) -> PipelineCommands: ...
    def rpush(self, key: str, *elements: ValueT) -> PipelineCommands: ...
    def rpushx(self, key: str, *elements: ValueT) -> PipelineCommands: ...
    def publish(self, channel: str, message: ValueT) -> PipelineCommands: ...
    def eval(
        self,
        script: str,
        keys: Optional[List[str]] = None,
        args: Optional[List[str]] = None,
    ) -> PipelineCommands: ...
    def eval_ro(
        self,
        script: str,
        keys: Optional[List[str]] = None,
        args: Optional[List[str]] = None,
    ) -> PipelineCommands: ...
    def evalsha(
        self,
        sha1: str,
        keys: Optional[List[str]] = None,
        args: Optional[List[str]] = None,
    ) -> PipelineCommands: ...
    def evalsha_ro(
        self,
        sha1: str,
        keys: Optional[List[str]] = None,
        args: Optional[List[str]] = None,
    ) -> PipelineCommands: ...
    def dbsize(self) -> PipelineCommands: ...
    def flushall(
        self, flush_type: Optional[Literal["ASYNC", "SYNC"]] = None
    ) -> PipelineCommands: ...
    def flushdb(
        self, flush_type: Optional[Literal["ASYNC", "SYNC"]] = None
    ) -> PipelineCommands: ...
    def time(self) -> PipelineCommands: ...
    def sadd(self, key: str, *members: ValueT) -> PipelineCommands: ...
    def scard(self, key: str) -> PipelineCommands: ...
    def sdiff(self, *keys: str) -> PipelineCommands: ...
    def sdiffstore(self, destination: str, *keys: str) -> PipelineCommands: ...
    def sinter(self, *keys: str) -> PipelineCommands: ...
    def sinterstore(self, destination: str, *keys: str) -> PipelineCommands: ...
    def sismember(self, key: str, member: ValueT) -> PipelineCommands: ...
    def smismember(self, key: str, *members: ValueT) -> PipelineCommands: ...
    def smembers(self, key: str) -> PipelineCommands: ...
    def smove(
        self, source: str, destination: str, member: ValueT
    ) -> PipelineCommands: ...
    def spop(self, key: str, count: Optional[int] = None) -> PipelineCommands: ...
    def srandmember(
        self, key: str, count: Optional[int] = None
    ) -> PipelineCommands: ...
    def srem(self, key: str, *members: ValueT) -> PipelineCommands: ...
    def sscan(
        self,
        key: str,
        cursor: int = 0,
        match: Optional[str] = None,
        count: Optional[int] = None,
    ) -> PipelineCommands: ...
    def sunion(self, *keys: str) -> PipelineCommands: ...
    def sunionstore(self, destination: str, *keys: str) -> PipelineCommands: ...
    def zadd(
        self,
        key: str,
        scores: Dict[str, float],
        nx: bool = False,
        xx: bool = False,
        gt: bool = False,
        lt: bool = False,
        ch: bool = False,
        incr: bool = False,
    ) -> PipelineCommands: ...
    def zcard(self, key: str) -> PipelineCommands: ...
    def zcount(
        self, key: str, min: FloatMinMaxT, max: FloatMinMaxT
    ) -> PipelineCommands: ...
    def zdiff(self, keys: List[str], withscores: bool = False) -> PipelineCommands: ...
    def zdiffstore(self, destination: str, keys: List[str]) -> PipelineCommands: ...
    def zincrby(self, key: str, increment: float, member: str) -> PipelineCommands: ...
    def zinter(
        self,
        keys: List[str],
        weights: Union[List[float], List[int], None] = None,
        aggregate: Optional[Literal["SUM", "MIN", "MAX"]] = None,
        withscores: bool = False,
    ) -> PipelineCommands: ...
    def zinterstore(
        self,
        destination: str,
        keys: List[str],
        weights: Union[List[float], List[int], None] = None,
        aggregate: Optional[Literal["SUM", "MIN", "MAX"]] = None,
    ) -> PipelineCommands: ...
    def zlexcount(self, key: str, min: str, max: str) -> PipelineCommands: ...
    def zmscore(self, key: str, members: List[str]) -> PipelineCommands: ...
    def zpopmax(self, key: str, count: Optional[int] = None) -> PipelineCommands: ...
    def zpopmin(self, key: str, count: Optional[int] = None) -> PipelineCommands: ...
    def zrandmember(
        self, key: str, count: Optional[int] = None, withscores: bool = False
    ) -> PipelineCommands: ...
    def zrange(
        self,
        key: str,
        start: FloatMinMaxT,
        stop: FloatMinMaxT,
        sortby: Optional[Literal["BYSCORE", "BYLEX"]] = None,
        rev: bool = False,
        offset: Optional[int] = None,
        count: Optional[int] = None,
        withscores: bool = False,
    ) -> PipelineCommands: ...
    def zrangebylex(
        self,
        key: str,
        min: str,
        max: str,
        offset: Optional[int] = None,
        count: Optional[int] = None,
    ) -> PipelineCommands: ...
    def zrangebyscore(
        self,
        key: str,
        min: FloatMinMaxT,
        max: FloatMinMaxT,
        withscores: bool = False,
        offset: Optional[int] = None,
        count: Optional[int] = None,
    ) -> PipelineCommands: ...
    def zrangestore(
        self,
        dst: str,
        src: str,
        min: FloatMinMaxT,
        max: FloatMinMaxT,
        sortby: Optional[Literal["BYSCORE", "BYLEX"]] = None,
        rev: bool = False,
        offset: Optional[int] = None,
        count: Optional[int] = None,
    ) -> PipelineCommands: ...
    def zrank(self, key: str, member: str) -> PipelineCommands: ...
    def zrem(self, key: str, *members: str) -> PipelineCommands: ...
    def zremrangebylex(self, key: str, min: str, max: str) -> PipelineCommands: ...
    def zremrangebyrank(self, key: str, start: int, stop: int) -> PipelineCommands: ...
    def zremrangebyscore(
        self, key: str, min: FloatMinMaxT, max: FloatMinMaxT
    ) -> PipelineCommands: ...
    def zrevrange(
        self, key: str, start: int, stop: int, withscores: bool = False
    ) -> PipelineCommands: ...
    def zrevrangebylex(
        self,
        key: str,
        max: str,
        min: str,
        offset: Optional[int] = None,
        count: Optional[int] = None,
    ) -> PipelineCommands: ...
    def zrevrangebyscore(
        self,
        key: str,
        max: FloatMinMaxT,
        min: FloatMinMaxT,
        withscores: bool = False,
        offset: Optional[int] = None,
        count: Optional[int] = None,
    ) -> PipelineCommands: ...
    def zrevrank(self, key: str, member: str) -> PipelineCommands: ...
    def zscan(
        self,
        key: str,
        cursor: int,
        match: Optional[str] = None,
        count: Optional[int] = None,
    ) -> PipelineCommands: ...
    def zscore(self, key: str, member: str) -> PipelineCommands: ...
    def zunion(
        self,
        keys: List[str],
        weights: Optional[List[float]] = None,
        aggregate: Optional[Literal["SUM", "MIN", "MAX"]] = None,
        withscores: bool = False,
    ) -> PipelineCommands: ...
    def zunionstore(
        self,
        destination: str,
        keys: List[str],
        weights: Optional[List[float]] = None,
        aggregate: Optional[Literal["SUM", "MIN", "MAX"]] = None,
    ) -> PipelineCommands: ...
    def append(self, key: str, value: str) -> PipelineCommands: ...
    def decr(self, key: str) -> PipelineCommands: ...
    def decrby(self, key: str, decrement: int) -> PipelineCommands: ...
    def get(self, key: str) -> PipelineCommands: ...
    def getdel(self, key: str) -> PipelineCommands: ...
    def getex(
        self,
        key: str,
        ex: Optional[int] = None,
        px: Optional[int] = None,
        exat: Optional[int] = None,
        pxat: Optional[int] = None,
        persist: Optional[bool] = None,
    ) -> PipelineCommands: ...
    def getrange(self, key: str, start: int, end: int) -> PipelineCommands: ...
    def getset(self, key: str, value: ValueT) -> PipelineCommands: ...
    def incr(self, key: str) -> PipelineCommands: ...
    def incrby(self, key: str, increment: int) -> PipelineCommands: ...
    def incrbyfloat(self, key: str, increment: float) -> PipelineCommands: ...
    def mget(self, *keys: str) -> PipelineCommands: ...
    def mset(self, values: Mapping[str, ValueT]) -> PipelineCommands: ...
    def msetnx(self, values: Mapping[str, ValueT]) -> PipelineCommands: ...
    def psetex(self, key: str, milliseconds: int, value: str) -> PipelineCommands: ...
    def set(
        self,
        key: str,
        value: ValueT,
        nx: bool = False,
        xx: bool = False,
        get: bool = False,
        ex: Optional[int] = None,
        px: Optional[int] = None,
        exat: Optional[int] = None,
        pxat: Optional[int] = None,
        keepttl: bool = False,
    ) -> PipelineCommands: ...
    def setex(self, key: str, seconds: int, value: ValueT) -> PipelineCommands: ...
    def setnx(self, key: str, value: ValueT) -> PipelineCommands: ...
    def setrange(self, key: str, offset: int, value: str) -> PipelineCommands: ...
    def strlen(self, key: str) -> PipelineCommands: ...
    def substr(self, key: str, start: int, end: int) -> PipelineCommands: ...
    def script_exists(self, *sha1: str) -> PipelineCommands: ...
    def script_flush(
        self, flush_type: Optional[Literal["ASYNC", "SYNC"]] = None
    ) -> PipelineCommands: ...
    def script_load(self, script: str) -> PipelineCommands: ...

class JsonCommands:
    def __init__(self, client: Commands): ...
    def arrappend(
        self, key: str, path: str = "$", *values: JSONValueT
    ) -> List[Union[int, None]]: ...
    def arrindex(
        self, key: str, path: str, value: JSONValueT, start: int = 0, stop: int = 0
    ) -> List[Union[int, None]]: ...
    def arrinsert(
        self, key: str, path: str, index: int, *values: JSONValueT
    ) -> List[Union[int, None]]: ...
    def arrlen(self, key: str, path: str = "$") -> List[Union[int, None]]: ...
    def arrpop(
        self, key: str, path: str = "$", index: int = -1
    ) -> List[Union[JSONValueT, None]]: ...
    def arrtrim(
        self, key: str, path: str, start: int, stop: int
    ) -> List[Union[int, None]]: ...
    def clear(self, key: str, path: str = "$") -> int: ...
    def delete(self, key: str, path: str = "$") -> int: ...
    def forget(self, key: str, path: str = "$") -> int: ...
    def get(
        self, key: str, *paths: str
    ) -> Union[List[Union[JSONValueT, None]], JSONValueT]: ...
    def merge(self, key: str, path: str, value: JSONValueT) -> Literal[True]: ...
    def mget(
        self, keys: List[str], path: str
    ) -> List[List[Union[JSONValueT, None]]]: ...
    def mset(
        self, key_path_value_tuples: List[Tuple[str, str, JSONValueT]]
    ) -> Literal[True]: ...
    def numincrby(
        self, key: str, path: str, increment: int
    ) -> List[Union[int, None]]: ...
    def nummultby(
        self, key: str, path: str, multiply: int
    ) -> List[Union[int, None]]: ...
    def objkeys(self, key: str, path: str = "$") -> List[Union[List[str], None]]: ...
    def objlen(self, key: str, path: str = "$") -> List[Union[int, None]]: ...
    def resp(self, key: str, path: str = "$") -> List[List[JSONValueT]]: ...
    def set(
        self,
        key: str,
        path: str,
        value: JSONValueT,
        nx: Optional[bool] = None,
        xx: Optional[bool] = None,
    ) -> Literal[True]: ...
    def strappend(self, key: str, path: str, value: str) -> List[Union[int, None]]: ...
    def strlen(self, key: str, path: str = "$") -> List[Union[int, None]]: ...
    def toggle(self, key: str, path: str = "$") -> List[Union[bool, None]]: ...
    def type(self, key: str, path: str = "$") -> List[str]: ...

class PipelineJsonCommands:
    def __init__(self, client: PipelineCommands): ...
    def arrappend(
        self, key: str, path: str = "$", *values: JSONValueT
    ) -> PipelineCommands: ...
    def arrindex(
        self, key: str, path: str, value: JSONValueT, start: int = 0, stop: int = 0
    ) -> PipelineCommands: ...
    def arrinsert(
        self, key: str, path: str, index: int, *values: JSONValueT
    ) -> PipelineCommands: ...
    def arrlen(self, key: str, path: str = "$") -> PipelineCommands: ...
    def arrpop(
        self, key: str, path: str = "$", index: int = -1
    ) -> PipelineCommands: ...
    def arrtrim(
        self, key: str, path: str, start: int, stop: int
    ) -> PipelineCommands: ...
    def clear(self, key: str, path: str = "$") -> PipelineCommands: ...
    def delete(self, key: str, path: str = "$") -> PipelineCommands: ...
    def forget(self, key: str, path: str = "$") -> PipelineCommands: ...
    def get(self, key: str, *paths: str) -> PipelineCommands: ...
    def merge(self, key: str, path: str, value: JSONValueT) -> PipelineCommands: ...
    def mget(self, keys: List[str], path: str) -> PipelineCommands: ...
    def mset(
        self, key_path_value_tuples: List[Tuple[str, str, JSONValueT]]
    ) -> PipelineCommands: ...
    def numincrby(self, key: str, path: str, increment: int) -> PipelineCommands: ...
    def nummultby(self, key: str, path: str, multiply: int) -> PipelineCommands: ...
    def objkeys(self, key: str, path: str = "$") -> PipelineCommands: ...
    def objlen(self, key: str, path: str = "$") -> PipelineCommands: ...
    def resp(self, key: str, path: str = "$") -> PipelineCommands: ...
    def set(
        self,
        key: str,
        path: str,
        value: JSONValueT,
        nx: Optional[bool] = None,
        xx: Optional[bool] = None,
    ) -> PipelineCommands: ...
    def strappend(self, key: str, path: str, value: str) -> PipelineCommands: ...
    def strlen(self, key: str, path: str = "$") -> PipelineCommands: ...
    def toggle(self, key: str, path: str = "$") -> PipelineCommands: ...
    def type(self, key: str, path: str = "$") -> PipelineCommands: ...

class AsyncJsonCommands:
    def __init__(self, client: AsyncCommands): ...
    async def arrappend(
        self, key: str, path: str = "$", *values: JSONValueT
    ) -> List[Union[int, None]]: ...
    async def arrindex(
        self, key: str, path: str, value: JSONValueT, start: int = 0, stop: int = 0
    ) -> List[Union[int, None]]: ...
    async def arrinsert(
        self, key: str, path: str, index: int, *values: JSONValueT
    ) -> List[Union[int, None]]: ...
    async def arrlen(self, key: str, path: str = "$") -> List[Union[int, None]]: ...
    async def arrpop(
        self, key: str, path: str = "$", index: int = -1
    ) -> List[Union[JSONValueT, None]]: ...
    async def arrtrim(
        self, key: str, path: str, start: int, stop: int
    ) -> List[Union[int, None]]: ...
    async def clear(self, key: str, path: str = "$") -> int: ...
    async def delete(self, key: str, path: str = "$") -> int: ...
    async def forget(self, key: str, path: str = "$") -> int: ...
    async def get(
        self, key: str, *paths: str
    ) -> Union[List[Union[JSONValueT, None]], JSONValueT]: ...
    async def merge(self, key: str, path: str, value: JSONValueT) -> Literal[True]: ...
    async def mget(
        self, keys: List[str], path: str
    ) -> List[List[Union[JSONValueT, None]]]: ...
    async def mset(
        self, key_path_value_tuples: List[Tuple[str, str, JSONValueT]]
    ) -> Literal[True]: ...
    async def numincrby(
        self, key: str, path: str, increment: int
    ) -> List[Union[int, None]]: ...
    async def nummultby(
        self, key: str, path: str, multiply: int
    ) -> List[Union[int, None]]: ...
    async def objkeys(
        self, key: str, path: str = "$"
    ) -> List[Union[List[str], None]]: ...
    async def objlen(self, key: str, path: str = "$") -> List[Union[int, None]]: ...
    async def resp(self, key: str, path: str = "$") -> List[List[JSONValueT]]: ...
    async def set(
        self,
        key: str,
        path: str,
        value: JSONValueT,
        nx: Optional[bool] = None,
        xx: Optional[bool] = None,
    ) -> Literal[True]: ...
    async def strappend(
        self, key: str, path: str, value: str
    ) -> List[Union[int, None]]: ...
    async def strlen(self, key: str, path: str = "$") -> List[Union[int, None]]: ...
    async def toggle(self, key: str, path: str = "$") -> List[Union[bool, None]]: ...
    async def type(self, key: str, path: str = "$") -> List[str]: ...
