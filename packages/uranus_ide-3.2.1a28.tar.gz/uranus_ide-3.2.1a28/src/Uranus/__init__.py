# Package initializer# src/Uranus/__main__.py


if __name__ == "__main__":
    core.main()  