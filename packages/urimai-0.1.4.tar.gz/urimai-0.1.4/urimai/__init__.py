"""urimai - AI-powered SQL answer engine."""
__version__ = "0.1.4"
