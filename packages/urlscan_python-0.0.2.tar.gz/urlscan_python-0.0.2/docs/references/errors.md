::: urlscan.APIError

::: urlscan.RateLimitError
