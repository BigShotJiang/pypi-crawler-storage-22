"""urltools-cli: Parse, build, and manipulate URLs."""
__version__ = "0.1.0"
