"""urltools-cli: Parse, build, and manipulate URLs."""

import json
import sys
from urllib.parse import (
    parse_qs,
    parse_qsl,
    quote,
    quote_plus,
    unquote,
    unquote_plus,
    urlencode,
    urljoin,
    urlparse,
    urlunparse,
)

import click


def output_json(data: dict) -> None:
    """Output data as JSON."""
    click.echo(json.dumps(data, indent=2))


def output_plain(data: dict, keys: list = None) -> None:
    """Output data as key=value pairs."""
    if keys is None:
        keys = data.keys()
    for key in keys:
        value = data.get(key, "")
        if value:
            click.echo(f"{key}: {value}")


@click.group()
@click.version_option()
def cli():
    """Parse, build, and manipulate URLs.
    
    A CLI for working with URLs - parse them into components,
    build them from parts, modify query parameters, join paths,
    encode/decode, and more.
    """
    pass


@cli.command()
@click.argument("url")
@click.option("--json", "as_json", is_flag=True, help="Output as JSON")
@click.option("--component", "-c", type=click.Choice([
    "scheme", "netloc", "host", "port", "path", "query", "fragment",
    "username", "password", "params"
]), help="Extract single component")
def parse(url: str, as_json: bool, component: str):
    """Parse URL into components.
    
    Examples:
    
        urltools parse "https://user:pass@example.com:8080/path?q=1#frag"
        
        urltools parse "https://api.example.com/v1/users" -c host
        
        urltools parse "https://example.com?foo=bar&baz=qux" --json
    """
    parsed = urlparse(url)
    
    # Parse query string into dict
    query_dict = parse_qs(parsed.query, keep_blank_values=True)
    # Flatten single-value lists
    query_flat = {k: v[0] if len(v) == 1 else v for k, v in query_dict.items()}
    
    data = {
        "url": url,
        "scheme": parsed.scheme,
        "netloc": parsed.netloc,
        "host": parsed.hostname or "",
        "port": parsed.port,
        "username": parsed.username or "",
        "password": parsed.password or "",
        "path": parsed.path,
        "query": parsed.query,
        "query_params": query_flat,
        "fragment": parsed.fragment,
    }
    
    if component:
        if component == "params":
            if as_json:
                output_json(query_flat)
            else:
                for k, v in query_flat.items():
                    if isinstance(v, list):
                        for item in v:
                            click.echo(f"{k}={item}")
                    else:
                        click.echo(f"{k}={v}")
        elif component == "host":
            click.echo(data["host"])
        elif component == "port":
            if data["port"]:
                click.echo(data["port"])
        else:
            click.echo(data.get(component, ""))
        return
    
    if as_json:
        output_json(data)
    else:
        click.echo(f"scheme: {data['scheme']}")
        click.echo(f"host: {data['host']}")
        if data['port']:
            click.echo(f"port: {data['port']}")
        if data['username']:
            click.echo(f"username: {data['username']}")
        if data['password']:
            click.echo(f"password: {'*' * len(data['password'])}")
        click.echo(f"path: {data['path']}")
        if data['query']:
            click.echo(f"query: {data['query']}")
        if query_flat:
            click.echo("params:")
            for k, v in query_flat.items():
                if isinstance(v, list):
                    for item in v:
                        click.echo(f"  {k}={item}")
                else:
                    click.echo(f"  {k}={v}")
        if data['fragment']:
            click.echo(f"fragment: {data['fragment']}")


@cli.command()
@click.option("--scheme", "-s", default="https", help="URL scheme (default: https)")
@click.option("--host", "-h", required=True, help="Host name")
@click.option("--port", "-p", type=int, help="Port number")
@click.option("--path", default="", help="URL path")
@click.option("--query", "-q", multiple=True, help="Query params as key=value (repeatable)")
@click.option("--fragment", "-f", default="", help="URL fragment")
@click.option("--username", "-u", help="Username for auth")
@click.option("--password", "-w", help="Password for auth")
def build(scheme: str, host: str, port: int, path: str, query: tuple, 
          fragment: str, username: str, password: str):
    """Build URL from components.
    
    Examples:
    
        urltools build --host example.com --path /api/v1
        
        urltools build -h api.example.com -p 8080 --path /users -q limit=10 -q offset=0
        
        urltools build -h db.local -u admin -w secret -p 5432 --path /mydb
    """
    # Build netloc
    netloc = ""
    if username:
        netloc = username
        if password:
            netloc += f":{password}"
        netloc += "@"
    netloc += host
    if port:
        netloc += f":{port}"
    
    # Build query string
    query_str = ""
    if query:
        params = []
        for q in query:
            if "=" in q:
                params.append(tuple(q.split("=", 1)))
            else:
                params.append((q, ""))
        query_str = urlencode(params)
    
    # Ensure path starts with / if not empty
    if path and not path.startswith("/"):
        path = "/" + path
    
    url = urlunparse((scheme, netloc, path, "", query_str, fragment))
    click.echo(url)


@cli.command()
@click.argument("url")
@click.option("--add", "-a", multiple=True, help="Add param as key=value (repeatable)")
@click.option("--remove", "-r", multiple=True, help="Remove param by key (repeatable)")
@click.option("--set", "-s", "set_params", multiple=True, help="Set param (replace) as key=value")
@click.option("--clear", is_flag=True, help="Clear all query params")
@click.option("--json", "as_json", is_flag=True, help="Output params as JSON instead of URL")
def params(url: str, add: tuple, remove: tuple, set_params: tuple, clear: bool, as_json: bool):
    """Modify URL query parameters.
    
    Examples:
    
        urltools params "https://example.com?a=1" --add b=2 --add c=3
        
        urltools params "https://example.com?a=1&b=2" --remove a
        
        urltools params "https://example.com?a=1" --set a=999
        
        urltools params "https://example.com?a=1&b=2" --clear --add fresh=value
        
        urltools params "https://example.com?a=1&b=2" --json
    """
    parsed = urlparse(url)
    query_list = parse_qsl(parsed.query, keep_blank_values=True)
    
    if clear:
        query_list = []
    
    # Remove specified params
    if remove:
        query_list = [(k, v) for k, v in query_list if k not in remove]
    
    # Set params (replace if exists, add if not)
    if set_params:
        for sp in set_params:
            if "=" in sp:
                key, value = sp.split("=", 1)
            else:
                key, value = sp, ""
            # Remove existing
            query_list = [(k, v) for k, v in query_list if k != key]
            # Add new
            query_list.append((key, value))
    
    # Add new params
    if add:
        for a in add:
            if "=" in a:
                key, value = a.split("=", 1)
            else:
                key, value = a, ""
            query_list.append((key, value))
    
    if as_json:
        # Convert to dict (list values for duplicates)
        result = {}
        for k, v in query_list:
            if k in result:
                if isinstance(result[k], list):
                    result[k].append(v)
                else:
                    result[k] = [result[k], v]
            else:
                result[k] = v
        output_json(result)
    else:
        query_str = urlencode(query_list)
        new_url = urlunparse((
            parsed.scheme,
            parsed.netloc,
            parsed.path,
            parsed.params,
            query_str,
            parsed.fragment
        ))
        click.echo(new_url)


@cli.command()
@click.argument("base")
@click.argument("path")
def join(base: str, path: str):
    """Join base URL with path.
    
    Examples:
    
        urltools join "https://example.com/api/" "users"
        # → https://example.com/api/users
        
        urltools join "https://example.com/api/v1" "/v2/users"
        # → https://example.com/v2/users
        
        urltools join "https://example.com/old/path" "../new"
        # → https://example.com/new
    """
    result = urljoin(base, path)
    click.echo(result)


@cli.command()
@click.argument("text", required=False)
@click.option("--plus", is_flag=True, help="Use + for spaces instead of %20")
@click.option("--safe", default="", help="Characters to not encode")
def encode(text: str, plus: bool, safe: str):
    """URL-encode text.
    
    Examples:
    
        urltools encode "hello world"
        # → hello%20world
        
        urltools encode "hello world" --plus
        # → hello+world
        
        echo "query param" | urltools encode
    """
    if text is None:
        text = sys.stdin.read().rstrip("\n")
    
    if plus:
        result = quote_plus(text, safe=safe)
    else:
        result = quote(text, safe=safe)
    
    click.echo(result)


@cli.command()
@click.argument("text", required=False)
@click.option("--plus", is_flag=True, help="Decode + as space")
def decode(text: str, plus: bool):
    """URL-decode text.
    
    Examples:
    
        urltools decode "hello%20world"
        # → hello world
        
        urltools decode "hello+world" --plus
        # → hello world
    """
    if text is None:
        text = sys.stdin.read().rstrip("\n")
    
    if plus:
        result = unquote_plus(text)
    else:
        result = unquote(text)
    
    click.echo(result)


@cli.command()
@click.argument("url1")
@click.argument("url2")
@click.option("--json", "as_json", is_flag=True, help="Output as JSON")
def compare(url1: str, url2: str, as_json: bool):
    """Compare two URLs and show differences.
    
    Examples:
    
        urltools compare "https://example.com/a" "https://example.com/b"
        
        urltools compare "http://a.com?x=1" "https://a.com?x=2" --json
    """
    p1 = urlparse(url1)
    p2 = urlparse(url2)
    
    q1 = dict(parse_qsl(p1.query))
    q2 = dict(parse_qsl(p2.query))
    
    diffs = {}
    
    # Compare basic components
    for component in ["scheme", "netloc", "path", "fragment"]:
        v1 = getattr(p1, component)
        v2 = getattr(p2, component)
        if v1 != v2:
            diffs[component] = {"url1": v1, "url2": v2}
    
    # Compare query params
    all_keys = set(q1.keys()) | set(q2.keys())
    param_diffs = {}
    for key in all_keys:
        v1 = q1.get(key)
        v2 = q2.get(key)
        if v1 != v2:
            param_diffs[key] = {"url1": v1, "url2": v2}
    
    if param_diffs:
        diffs["params"] = param_diffs
    
    if as_json:
        output_json({
            "equal": len(diffs) == 0,
            "differences": diffs
        })
    else:
        if not diffs:
            click.echo("URLs are equivalent")
        else:
            for component, vals in diffs.items():
                if component == "params":
                    click.echo("params:")
                    for key, pv in vals.items():
                        click.echo(f"  {key}:")
                        click.echo(f"    url1: {pv['url1']}")
                        click.echo(f"    url2: {pv['url2']}")
                else:
                    click.echo(f"{component}:")
                    click.echo(f"  url1: {vals['url1']}")
                    click.echo(f"  url2: {vals['url2']}")


@cli.command()
@click.argument("url")
@click.option("--scheme", "-s", help="New scheme")
@click.option("--host", "-h", help="New host")
@click.option("--port", "-p", type=int, help="New port (0 to remove)")
@click.option("--path", help="New path")
@click.option("--fragment", "-f", help="New fragment")
def replace(url: str, scheme: str, host: str, port: int, path: str, fragment: str):
    """Replace URL components.
    
    Examples:
    
        urltools replace "http://example.com/path" --scheme https
        
        urltools replace "https://old.com/api" --host new.com
        
        urltools replace "https://example.com:8080/" --port 443
    """
    parsed = urlparse(url)
    
    new_scheme = scheme if scheme else parsed.scheme
    new_path = path if path is not None else parsed.path
    new_fragment = fragment if fragment is not None else parsed.fragment
    
    # Handle netloc modifications
    new_host = host if host else (parsed.hostname or "")
    
    if port == 0:
        new_port = None
    elif port:
        new_port = port
    else:
        new_port = parsed.port
    
    # Reconstruct netloc
    netloc = ""
    if parsed.username:
        netloc = parsed.username
        if parsed.password:
            netloc += f":{parsed.password}"
        netloc += "@"
    netloc += new_host
    if new_port:
        netloc += f":{new_port}"
    
    new_url = urlunparse((
        new_scheme,
        netloc,
        new_path,
        parsed.params,
        parsed.query,
        new_fragment
    ))
    
    click.echo(new_url)


@cli.command()
@click.argument("url")
def normalize(url: str):
    """Normalize URL (lowercase scheme/host, remove default ports, etc).
    
    Examples:
    
        urltools normalize "HTTP://EXAMPLE.COM:80/Path"
        # → http://example.com/Path
        
        urltools normalize "https://example.com:443/api"
        # → https://example.com/api
    """
    parsed = urlparse(url)
    
    # Lowercase scheme and host
    scheme = parsed.scheme.lower()
    host = (parsed.hostname or "").lower()
    
    # Remove default ports
    port = parsed.port
    if (scheme == "http" and port == 80) or (scheme == "https" and port == 443):
        port = None
    
    # Reconstruct netloc
    netloc = ""
    if parsed.username:
        netloc = parsed.username
        if parsed.password:
            netloc += f":{parsed.password}"
        netloc += "@"
    netloc += host
    if port:
        netloc += f":{port}"
    
    # Normalize path (remove trailing slash except for root)
    path = parsed.path
    if path != "/" and path.endswith("/"):
        path = path.rstrip("/")
    
    # Sort query params for consistency
    query_list = parse_qsl(parsed.query, keep_blank_values=True)
    query_list.sort(key=lambda x: x[0])
    query_str = urlencode(query_list)
    
    normalized = urlunparse((
        scheme,
        netloc,
        path,
        parsed.params,
        query_str,
        parsed.fragment
    ))
    
    click.echo(normalized)


@cli.command()
@click.argument("url")
def validate(url: str):
    """Check if URL is valid.
    
    Exits with code 0 if valid, 1 if invalid.
    
    Examples:
    
        urltools validate "https://example.com" && echo "Valid"
        
        urltools validate "not-a-url" || echo "Invalid"
    """
    parsed = urlparse(url)
    
    issues = []
    
    if not parsed.scheme:
        issues.append("Missing scheme")
    elif parsed.scheme not in ["http", "https", "ftp", "ftps", "file", "mailto", "tel", "ssh", "git"]:
        issues.append(f"Unusual scheme: {parsed.scheme}")
    
    if not parsed.netloc and parsed.scheme in ["http", "https", "ftp", "ftps"]:
        issues.append("Missing host")
    
    if issues:
        click.echo(f"Invalid: {', '.join(issues)}", err=True)
        sys.exit(1)
    else:
        click.echo("Valid")
        sys.exit(0)


if __name__ == "__main__":
    cli()
