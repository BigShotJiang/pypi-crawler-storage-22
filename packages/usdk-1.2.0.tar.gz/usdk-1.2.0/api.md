# uAPI

Methods:

- <code title="get /v1/extract">client.<a href="./src/uapi/_client.py">extract</a>(\*\*<a href="src/uapi/types/client_extract_params.py">params</a>) -> object</code>
- <code title="get /v1/search">client.<a href="./src/uapi/_client.py">search</a>(\*\*<a href="src/uapi/types/client_search_params.py">params</a>) -> object</code>
