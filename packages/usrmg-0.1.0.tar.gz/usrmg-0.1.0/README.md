# User Management System - usrmg

[![pr-checks](https://github.com/rohit1998/usrmg/actions/workflows/pr-checks.yml/badge.svg?branch=main)](https://github.com/rohit1998/usrmg/actions/workflows/pr-checks.yml)
[![Documentation](https://img.shields.io/badge/docs-latest-blue.svg)](https://rohit1998.github.io/usrmg/)
[![PyPI version](https://img.shields.io/pypi/v/usrmg.svg?color=blue)](https://pypi.org/project/usrmg/)
[![Python versions](https://img.shields.io/pypi/pyversions/usrmg.svg?color=blue)](https://pypi.org/project/usrmg/)
[![Docker Image](https://img.shields.io/docker/v/rohgupt/usrmg?label=latest)](https://hub.docker.com/r/rohgupt/usrmg/)

A simple USeR ManaGement - usrmg system.

- [local_docs_link](https://usrmg.dev.local)
- [tailscale_docs_link](https://usrmg.tailb437ea.ts.net)
- [repo_docs_path](docs/index.md)

## License

This project is licensed under the MIT License - see the LICENSE file for details.
