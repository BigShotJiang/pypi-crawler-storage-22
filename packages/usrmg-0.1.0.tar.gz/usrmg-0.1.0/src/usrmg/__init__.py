"""My Project."""

from .module import (
    MyClass,
    my_add_function,
)

__all__ = [
    'MyClass',
    'my_add_function',
]
