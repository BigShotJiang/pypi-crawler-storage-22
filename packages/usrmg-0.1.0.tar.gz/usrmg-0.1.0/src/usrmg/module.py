"""Sample module."""

import logging

from opentelemetry import trace

from cli.tracing_setup import trace_function

logger = logging.getLogger(__name__)
tracer = trace.get_tracer(__name__)


class MyClass:
    """My module."""

    def __init__(self, name: str) -> None:
        """Initialize the module.

        Args:
            name: The name of the person to greet.
        """
        self.name = name

    @trace_function
    def run(self) -> str:
        """Run the module.

        Returns:
            The greeting.
        """
        logger.debug('Running module')
        greeting = f'Hello {self.name}'
        logger.debug('Ran module')
        return greeting

    def get_env_var(self, env_var_name: str) -> str:
        """Get the environment variable.

        Args:
            env_var_name (str): The name of the environment variable.

        Returns:
            The environment variable.

        Raises:
            ValueError: If the environment variable is not found.
        """
        logger.debug('Getting environment variable')
        if env_var_name is None:
            logger.error('Environment variable not found')
            msg = 'Environment variable not found'
            raise ValueError(msg)
        logger.debug('Got environment variable')
        return env_var_name + '_verified'


@trace_function
def my_add_function(a: int, b: int) -> int:
    """My add function.

    Generic function to

    - add two numbers `a` and `b`
    - both a and b must be integers

    Args:
        a (int): The first number to add.
        b (int): The second number to add.

    Returns:
        int: The sum of `a` and `b`.

    Raises:
        TypeError: If the `a` or `b` is not an integer.

    Examples:
        >>> from usrmg import my_add_function
        >>> my_add_function(2, 3)
        5
        >>> my_add_function(2, '3')
        Traceback (most recent call last):
          ...
        TypeError: Both a and b must be integers

    Warning:
        - No support for floats.
    """
    if not isinstance(a, int) or not isinstance(b, int):
        logger.error('Both a and b must be integers')
        msg = 'Both a and b must be integers'
        raise TypeError(msg)

    logger.debug('Running my add function')
    with tracer.start_as_current_span('perform-addition'):
        logger.debug('Adding %s and %s', a, b)
        result = a + b
    logger.debug('%s + %s = %s', a, b, result)
    return result
