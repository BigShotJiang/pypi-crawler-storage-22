# 🔧 utilita-net -- utilita but with helpers for web services

a utility library

## Quick install
```bash
pip install utilita-net
```

## Basic usage

If this package cannot be successfully imported, you may need to reinstall both at the same time:

- pip install --upgrade --no-deps --force-reinstall utilita utilita-net