<!-- This file is generated. DO NOT EDIT -->

# uv-configuration

This crate is an internal component of [uv](https://crates.io/crates/uv). The Rust API exposed here
is unstable and will have frequent breaking changes.

This version (0.0.19) is a component of [uv 0.9.30](https://crates.io/crates/uv/0.9.30). The source
can be found [here](https://github.com/astral-sh/uv/blob/0.9.30/crates/uv-configuration).

See uv's
[crate versioning policy](https://docs.astral.sh/uv/reference/policies/versioning/#crate-versioning)
for details on versioning.
