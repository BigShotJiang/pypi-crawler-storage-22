# Uv helper

Helpful commands for the `uv` tool.

---

## Dev

### Uv install or update

https://docs.astral.sh/uv/getting-started/installation/

```bash
if ! command -v uv &> /dev/null; then
    curl -LsSf https://astral.sh/uv/install.sh | sh;
else
    uv self update;
fi

uv --version
```

### Create venv

```bash
uv sync --all-packages
```

### Register pre-commit hooks

```shell
prek install
```

### Run pre-commit hooks

```shell
prek run --all-files
```

---

## Extra

- Why is the `.idea` folder is partially stored in the repository?
    - [read (UKR)](https://github.com/Alirex/notes/blob/main/notes/ignore_or_not_ide_config/ukr.md)
- Why `py.typed`?
    - [mypy (ENG)](https://mypy.readthedocs.io/en/stable/installed_packages.html#creating-pep-561-compatible-packages)
    - [typing (ENG)](https://typing.python.org/en/latest/spec/distributing.html#packaging-type-information)

### Reinit .idea folder for git for better gitignore support

If you created a new project with JetBrains IDE and automatically created git repository,
before providing more granular `.gitignore` file, you need to reinit `.idea` folder.

```shell
git rm -r --force --cached .idea &&\
git add .idea
```

### Check the paths for the venv

```shell
uv run python -c 'import sys, os; [print(p) for p in sys.path if p and "zip" not in p.lower() and os.path.basename(p)!="src"]'
```

