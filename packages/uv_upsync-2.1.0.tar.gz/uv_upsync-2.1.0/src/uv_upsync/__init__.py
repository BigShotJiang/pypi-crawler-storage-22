"""uv-upsync - is a tool for automated dependency updates and version bumping in pyproject.toml."""

from __future__ import annotations


__version__ = "2.1.0"
