"""Test suite for uv-upsync."""

from __future__ import annotations
