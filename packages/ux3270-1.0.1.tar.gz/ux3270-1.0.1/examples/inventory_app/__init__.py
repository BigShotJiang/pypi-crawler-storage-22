"""Inventory management application."""
