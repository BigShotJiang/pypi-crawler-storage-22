import os

# Perplexity API Configuration
PERPLEXITY_API_KEY = os.getenv("PERPLEXITY_API_KEY", "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")
PERPLEXITY_MODEL = "sonar" # Fast and cost-effective for stock analysis
