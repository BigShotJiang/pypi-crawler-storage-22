import pandas as pd
import numpy as np
import yfinance as yf
from v1indicators import ema, supertrend, macd, bbands, rsi, donchian

class V1Backtester:
    """
    A Vectorized Backtesting Engine for v1indicators.
    Designed for speed and mathematical precision.
    """
    def __init__(self, symbol: str, start: str, end: str):
        self.symbol = symbol
        self.start = start
        self.end = end
        self.data = pd.DataFrame()

    def fetch_data(self):
        """Fetches OHLCV data from yfinance."""
        df = yf.download(self.symbol, start=self.start, end=self.end)
        
        # yfinance v1.0+ returns a MultiIndex DataFrame for symbols.
        # We need to flatten it to get simple Series for our indicators.
        if isinstance(df.columns, pd.MultiIndex):
            df.columns = df.columns.get_level_values(0)
            
        self.data = df
        return self

    def run_youtube_scalper(self):
        """EMA 200 + Supertrend Strategy."""
        df = self.data.copy()
        
        # Indicators
        df['EMA_200'] = ema(df['Close'], length=200)
        st = supertrend(df['High'], df['Low'], df['Close'], length=10, mult=3)
        df = pd.concat([df, st], axis=1)
        
        # Strategy Logic (Vectorized)
        # Long Entry: Price > EMA 200 AND Supertrend flipped to Bullish (1)
        df['signal'] = (df['Close'] > df['EMA_200']) & (df['SUPERTREND_DIR'] == 1) & (df['SUPERTREND_DIR'].shift(1) == -1)
        
        return self._calculate_returns(df, "YouTube Scalper")

    def run_trading_rush_macd(self):
        """EMA 200 + MACD Strategy."""
        df = self.data.copy()
        
        # Indicators
        df['EMA_200'] = ema(df['Close'], length=200)
        macd_df = macd(df['Close'], fast=12, slow=26, signal=9)
        df = pd.concat([df, macd_df], axis=1)
        
        # Long Entry Condition: Trend is up AND Histogram is recovering from negative
        # Logic: MACD Line > Signal Line (Bullish) AND Histogram just ticked up from a low
        df['signal'] = (df['Close'] > df['EMA_200']) & \
                       (df['MACD'] > df['MACD_SIGNAL']) & \
                       (df['MACD_HIST'] > df['MACD_HIST'].shift(1))
        
        return self._calculate_returns(df, "Trading Rush MACD")

    def run_mean_reversion(self):
        """BBands + RSI Strategy."""
        df = self.data.copy()
        
        # Indicators
        bb = bbands(df['Close'], length=20, mult=2)
        df['RSI'] = rsi(df['Close'], length=14)
        df = pd.concat([df, bb], axis=1)
        
        # Long Entry: Close < BB_LOWER AND RSI < 30
        df['signal'] = (df['Close'] < df['BB_LOWER']) & (df['RSI'] < 30)
        
        return self._calculate_returns(df, "Mean Reversion Squeeze")

    def run_turtle_soup(self):
        """Donchian Breakout Strategy."""
        df = self.data.copy()
        
        # Indicators
        # We MUST look at the PREVIOUS candle's Donchian to avoid look-ahead bias
        dc = donchian(df['High'], df['Low'], length=20).shift(1)
        df = pd.concat([df, dc], axis=1)
        
        # Long Entry: Current Price > Previous 20-day High
        df['signal'] = (df['Close'] > df['DONCHIAN_UPPER'])
        
        return self._calculate_returns(df, "Turtle Soup")

    def _calculate_returns(self, df: pd.DataFrame, strategy_name: str):
        """Vectorized return calculation for Trend vs Mean Reversion."""
        # Calculate daily returns
        df['log_return'] = np.log(df['Close'] / df['Close'].shift(1))
        
        # Determine Position Logic
        if strategy_name in ["YouTube Scalper", "Turtle Soup"]:
            # Trend Following: Stay in position while condition is met
            if "SUPERTREND_DIR" in df.columns:
                df['position'] = (df['SUPERTREND_DIR'] == 1).astype(int)
            else:
                # Turtle Soup: Stay in while price > lower band
                df['position'] = (df['Close'] > df['DONCHIAN_LOWER']).astype(int)
        elif strategy_name == "Trading Rush MACD":
            # MACD Regime: Stay in while MACD is bullish
            df['position'] = (df['MACD'] > df['MACD_SIGNAL']).astype(int)
        else:
            # Mean Reversion: 1-day snap back
            df['position'] = df['signal'].astype(int)

        # Shift position by 1 to avoid look-ahead bias (buy at close, get tomorrow's return)
        df['position'] = df['position'].shift(1).fillna(0)
        
        df['strat_return'] = df['position'] * df['log_return']
        
        cum_ret = np.exp(df['strat_return'].cumsum()) - 1
        total_ret = cum_ret.iloc[-1] if not cum_ret.empty else 0
        
        # Metrics
        win_days = (df['strat_return'] > 0).sum()
        total_days = (df['position'] != 0).sum()
        win_rate = win_days / total_days if total_days > 0 else 0
        
        print(f"Strategy: {strategy_name:<25} | Return: {total_ret:>8.2%} | Win Rate: {win_rate:>6.1%}")
        return total_ret

if __name__ == "__main__":
    # Test on real data: Reliance Industries (RELIANCE.NS)
    tester = V1Backtester("RELIANCE.NS", start="2020-01-01", end="2025-01-01")
    tester.fetch_data()
    
    print("\n--- v1backtest Results (RELIANCE 2020-2025) ---")
    tester.run_youtube_scalper()
    tester.run_trading_rush_macd()
    tester.run_mean_reversion()
    tester.run_turtle_soup()
