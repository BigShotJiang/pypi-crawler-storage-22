import aiohttp
import asyncio
import json
import os
import re
import textwrap
from config import PERPLEXITY_API_KEY, PERPLEXITY_MODEL
from colorama import Fore, Style

def get_terminal_width():
    try:
        return os.get_terminal_size().columns
    except:
        return 80

def strip_ansi(text):
    ansi_escape = re.compile(r'\x1B(?:[@-Z\-_]|[\[0-?]*[ -/]*[@-~])')
    return ansi_escape.sub('', text)

def visible_len(text):
    return len(strip_ansi(text))

def ljust_ansi(text, width):
    return text + (" " * (width - visible_len(text)))

def format_content_for_box(text, safe_width):
    lines_to_print = []
    # CASE A: Table Row
    if text.count('|') >= 3 and "---" not in text:
        try:
            parts = [p.strip() for p in text.split('|')]
            w_sym, w_rsi, w_prc, w_rng = 14, 9, 11, 18
            
            raw_sym = parts[0].replace('**', '').strip()[:w_sym-1]
            raw_rsi = parts[1].replace('RSI:', '').strip()[:w_rsi-1]
            raw_prc = parts[2].replace('Price:', '').replace('Pr:', '').strip()[:w_prc-1]
            raw_rng = parts[3].replace('Range:', '').replace('Rg:', '').strip()[:w_rng-1]
            raw_view = parts[4].replace('View:', '').strip() if len(parts) > 4 else ""
            
            used_width = w_sym + w_rsi + w_prc + w_rng + 12 
            view_width = max(10, safe_width - used_width)
            
            wrapped_view = textwrap.wrap(raw_view, width=view_width)
            if not wrapped_view: wrapped_view = [""]
            
            for i, view_line in enumerate(wrapped_view):
                row_str = ""
                if i == 0:
                    row_str += f"{Fore.YELLOW}• {Style.BRIGHT}{raw_sym.ljust(w_sym)}{Style.RESET_ALL} {Fore.WHITE}|{Style.RESET_ALL} "
                    row_str += f"{Fore.GREEN}{raw_rsi.ljust(w_rsi)}{Style.RESET_ALL} {Fore.WHITE}|{Style.RESET_ALL} "
                    row_str += f"{Fore.CYAN}{raw_prc.ljust(w_prc)}{Style.RESET_ALL} {Fore.WHITE}|{Style.RESET_ALL} "
                    row_str += f"{Fore.MAGENTA}{raw_rng.ljust(w_rng)}{Style.RESET_ALL} {Fore.WHITE}|{Style.RESET_ALL} "
                    row_str += f"{Fore.WHITE}{view_line}{Style.RESET_ALL}"
                else:
                    row_str += f"  {' ' * w_sym} {Fore.BLACK}|{Style.RESET_ALL} "
                    row_str += f"{' ' * w_rsi} {Fore.BLACK}|{Style.RESET_ALL} "
                    row_str += f"{' ' * w_prc} {Fore.BLACK}|{Style.RESET_ALL} "
                    row_str += f"{' ' * w_rng} {Fore.BLACK}|{Style.RESET_ALL} "
                    row_str += f"{Fore.WHITE}{view_line}{Style.RESET_ALL}"
                lines_to_print.append(row_str)
            return lines_to_print
        except: pass 

    # CASE B: Chat Text
    text = re.sub(r'\*\*(.*?)\*\*', f"{Fore.YELLOW}{Style.BRIGHT}\1{Style.RESET_ALL}", text)
    wrapped = textwrap.wrap(text, width=safe_width)
    if not wrapped: return [""] 
    return wrapped

async def generate_text_g(prompt, model=PERPLEXITY_MODEL):
    url = "https://api.perplexity.ai/chat/completions"
    term_width = get_terminal_width()
    margin_size = 2
    safe_width = max(term_width - (margin_size * 2) - 4, 80)
    
    headers = {"Authorization": f"Bearer {PERPLEXITY_API_KEY}", "Content-Type": "application/json"}

    # --- THE CONTEXT TRAP: SEPARATE DATA FROM QUESTION ---
    # We scan the prompt. If we see a big list of data, we move it to SYSTEM context.
    # This prevents the AI from thinking "Oh, I need to reply to this list."
    
    user_question = prompt
    background_context = ""

    # Detect if prompt contains the scan list (simple heuristic: look for pipe bars)
    if prompt.count('|') > 5:
        lines = prompt.split('\n')
        data_lines = []
        question_lines = []
        
        for line in lines:
            if '|' in line or "---" in line or "Symbol" in line:
                data_lines.append(line)
            else:
                question_lines.append(line)
        
        background_context = "\n".join(data_lines)
        user_question = "\n".join(question_lines).strip()
        
        # Fallback if question is empty (user just hit enter on the list)
        if not user_question:
            user_question = "Analyze this list."

    # --- SYSTEM INSTRUCTIONS ---
    system_content = (
        "You are Vikram, a professional trader and analyst.\n\n"
        "### CRITICAL RULE: THE POCKET\n"
        f"I have placed a list of scanned stocks in your back pocket. HERE IT IS:\n"
        f"'''\n{background_context}\n'''\n\n"
        "**YOUR ORDERS:**\n"
        "1. **IGNORE** this list unless I explicitly ask about it (e.g. 'review the list', 'categorize them').\n"
        "2. If I ask a general question (e.g., 'What is Jio Finance?', 'Check Northern Arc'), **DO NOT** mention the list. **DO NOT** print the table. Just search the web and answer.\n"
        "3. **formatting:**\n"
        "   - If explaining/chatting: Use short paragraphs.\n"
        "   - If (and ONLY if) asked to list stocks: Use the pipe format: **SYMBOL** | RSI: XX | Price: XX | Range: XX | View: text"
    )

    payload = {
        "model": model,
        "messages": [
            {"role": "system", "content": system_content}, 
            {"role": "user", "content": user_question}
        ],
        "stream": True
    }
    
    print(f"\n{Fore.GREEN}Vikram is analyzing...{Style.RESET_ALL}")
    margin = " " * margin_size
    print(f"{margin}┌{'─' * (safe_width + 2)}┐")
    
    full_response = ""
    current_line = ""
    
    try:
        async with aiohttp.ClientSession() as session:
            async with session.post(url, json=payload, headers=headers) as response:
                if response.status == 200:
                    async for line in response.content:
                        if not line: continue
                        decoded = line.decode('utf-8').strip()
                        if not decoded.startswith("data: "): continue
                        data_str = decoded[6:]
                        if data_str == "[DONE]": break
                        
                        try:
                            data_json = json.loads(data_str)
                            chunk = data_json['choices'][0]['delta'].get('content', '')
                            if not chunk: continue
                            full_response += chunk
                            
                            for char in chunk:
                                if char == '\n':
                                    formatted_lines = format_content_for_box(current_line, safe_width)
                                    for f_line in formatted_lines:
                                        print(f"{margin}│ {ljust_ansi(f_line, safe_width)} │")
                                    current_line = ""
                                else:
                                    current_line += char
                        except:
                            continue
                    
                    if current_line.strip():
                        formatted_lines = format_content_for_box(current_line, safe_width)
                        for f_line in formatted_lines:
                            print(f"{margin}│ {ljust_ansi(f_line, safe_width)} │")
                    
                    print(f"{margin}└{'─' * (safe_width + 2)}┘")
                    return full_response
    except Exception as e:
        print(f"{margin}│ {Fore.RED}Error: {str(e)}{Style.RESET_ALL}")
        print(f"{margin}└{'─' * (safe_width + 2)}┘")
        return str(e)
