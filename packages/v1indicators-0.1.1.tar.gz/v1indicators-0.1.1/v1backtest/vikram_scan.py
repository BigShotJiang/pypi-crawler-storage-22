import csv
import asyncio
import aiohttp
import pandas as pd
from colorama import Fore, Style, init
import time
from vikram_client import generate_text_g
from v1indicators import ema as v1_ema, rsi as v1_rsi

# Initialize colors
init(autoreset=True)

FILE_PATH = "Approved_list.csv"

# --- COLORS ---
SYMBOL_COLOR = Fore.YELLOW
PRICE_COLOR = Fore.CYAN
EMA_COLOR = Fore.GREEN
YEAR_COLOR = Fore.BLUE
ML_COLOR = Fore.WHITE
RESET = Style.RESET_ALL

def get_filtered_symbols():
    print(f"\n{Fore.CYAN}--- STEP 1: FILTER LIST ---{RESET}")
    
    while True:
        try:
            val1_input = input("Enter Primary Value (Margin or Leverage): ")
            if val1_input.lower() in ['q', 'exit']: return {}
            val1 = float(val1_input)
            break
        except ValueError:
            print(f"{Fore.RED}Invalid number. Try again.{RESET}")

    while True:
        try:
            val2_input = input("Enter Upper Bound (Optional, press Enter to skip): ")
            if val2_input.strip() == "":
                val2 = None
                break
            val2 = float(val2_input)
            break
        except ValueError:
            print(f"{Fore.RED}Invalid number. Try again.{RESET}")

    if val1 <= 5:
        field = "leverage"
        if val2:
            condition = lambda x: val1 <= float(x) <= val2
            print(f"Filtering by {field} ({val1} to {val2})...")
        else:
            condition = lambda x: float(x) >= val1
            print(f"Filtering by {field} (>= {val1})...")
    else:
        field = "margin"
        if val2:
            condition = lambda x: val1 <= float(x) <= val2
            print(f"Filtering by {field} ({val1}% to {val2}%)...")
        else:
            condition = lambda x: float(x) <= val1
            print(f"Filtering by {field} (<= {val1}%)...")

    selected_data = {}
    
    try:
        with open(FILE_PATH, newline="") as f:
            reader = csv.DictReader(f)
            for row in reader:
                if row.get(field) and condition(row[field]):
                    symbol = row["tradingsymbol"].strip() + ".NS"
                    selected_data[symbol] = {
                        'm': float(row['margin']),
                        'l': float(row['leverage'])
                    }
    except FileNotFoundError:
        print(f"{Fore.RED}Error: {FILE_PATH} not found.{RESET}")
        return {}
    
    print(f"{Fore.GREEN}Found {len(selected_data)} stocks meeting criteria.{RESET}")
    return selected_data

def calculate_stats(df, ema_length, min_pct, max_pct):
    if len(df) < ema_length: return None
    
    # Use v1indicators for EMA calculation
    ema_series = v1_ema(df['Close'], ema_length)
    df[f'EMA_{ema_length}'] = ema_series
    
    try:
        current = df.iloc[-1]
        price = float(current['Close'])
        ema_val = float(current[f'EMA_{ema_length}'])
        d_high = float(current['High'])
        d_low = float(current['Low'])
        y_high = float(df['High'].max())
        y_low = float(df['Low'].min())
    except:
        return None
    
    upper_limit = ema_val * (1 + (max_pct / 100))
    lower_limit = ema_val * (1 + (min_pct / 100))
    
    in_zone = lower_limit <= price <= upper_limit
    
    if in_zone:
        return {
            'price': price,
            'ema': ema_val,
            'zone_low': lower_limit,
            'zone_high': upper_limit,
            'd_high': d_high,
            'd_low': d_low,
            'y_high': y_high,
            'y_low': y_low
        }
    return None

def calculate_rsi(df, period=14):
    if len(df) < period: return None
    
    # Use v1indicators for RSI calculation
    rsi_series = v1_rsi(df['Close'], period)
    return rsi_series.iloc[-1]

def resample_to_3h(df_hourly):
    if not isinstance(df_hourly.index, pd.DatetimeIndex):
        return pd.DataFrame()
        
    return df_hourly.resample('3h').agg({
        'Open': 'first', 'High': 'max', 'Low': 'min', 'Close': 'last', 'Volume': 'sum'
    }).dropna()

def print_table(title, data_list, meta_data, rsi_period=None):
    print(f"\n{Fore.WHITE}=== {title} ({len(data_list)}) ==={RESET}")
    
    if not data_list:
        print("No matches found.")
        return

    # Header with RSI optional
    rsi_header = f"RSI({rsi_period})" if rsi_period else ""
    
    # Header with strict alignment
    header = (
        f"{'No':>3} "
        f"{'Symbol':<15} "
        f"{'Price':>10} "
        f"{'EMA Range':^22} "
        f"{'Day Range':^22} "
        f"{'Year Range':^22} "
        f"{'M':>6} "
        f"{'L':>6}"
    )
    if rsi_period:
        header += f" {rsi_header:^10}"
        
    print(header)
    print("-" * (115 + (11 if rsi_period else 0)))

    for i, item in enumerate(data_list, 1):
        symbol = item['symbol'].replace('.NS','')
        stats = item['stats']
        m_l = meta_data.get(item['symbol'], {'m': 0, 'l': 0})
        
        ema_range = f"{stats['zone_low']:.1f}-{stats['zone_high']:.1f}"
        day_range = f"{stats['d_low']:.1f}-{stats['d_high']:.1f}"
        year_range = f"{stats['y_low']:.0f}-{stats['y_high']:.0f}"

        line = (
            f"{i:>3} "
            f"{SYMBOL_COLOR}{symbol:<15}{RESET} "
            f"{PRICE_COLOR}{stats['price']:>10.2f}{RESET} "
            f"{EMA_COLOR}{ema_range:^22}{RESET} "
            f"{Fore.CYAN}{day_range:^22}{RESET} "
            f"{YEAR_COLOR}{year_range:^22}{RESET} "
            f"{ML_COLOR}{m_l['m']:>6.1f}{RESET} "
            f"{ML_COLOR}{m_l['l']:>6.2f}{RESET}"
        )
        
        if rsi_period:
            rsi_val = stats.get('rsi')
            if rsi_val is not None:
                rsi_color = Fore.RED if rsi_val > 70 else (Fore.GREEN if rsi_val < 30 else Fore.WHITE)
                line += f" {rsi_color}{rsi_val:^10.2f}{RESET}"
            else:
                line += f" {'N/A':^10}"
        
        print(line)

async def fetch_chart_data(session, symbol, range_str, interval_str):
    url = f"https://query2.finance.yahoo.com/v8/finance/chart/{symbol}"
    params = {
        "range": range_str,
        "interval": interval_str,
        "includeAdjustedClose": "true"
    }
    headers = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36"
    }
    
    try:
        async with session.get(url, params=params, headers=headers) as response:
            if response.status == 200:
                data = await response.json()
                result = data.get('chart', {}).get('result')
                if not result: return pd.DataFrame()
                
                result = result[0]
                timestamps = result.get('timestamp', [])
                indicators = result.get('indicators', {}).get('quote', [{}])[0]
                
                if not timestamps or not indicators: return pd.DataFrame()

                df = pd.DataFrame({
                    'Open': indicators.get('open', []),
                    'High': indicators.get('high', []),
                    'Low': indicators.get('low', []),
                    'Close': indicators.get('close', []),
                    'Volume': indicators.get('volume', [])
                })
                df.index = pd.to_datetime(timestamps, unit='s')
                
                meta = result.get('meta', {})
                tz_name = meta.get('exchangeTimezoneName')
                if tz_name:
                    try:
                        df.index = df.index.tz_localize('UTC').tz_convert(tz_name)
                    except:
                        pass
                
                return df.dropna(subset=['Close'])
    except:
        pass
    return pd.DataFrame()

async def process_symbol_async(sem, session, symbol, ema_len, min_pct, max_pct):
    async with sem:
        results = {'h': None, '3h': None, 'd': None}
        day_high = None
        day_low = None

        try:
            # Fetch Daily Data FIRST to get true Day Range
            data_d = await fetch_chart_data(session, symbol, "2y", "1d")
            if not data_d.empty:
                current_d = data_d.iloc[-1]
                day_high = float(current_d['High'])
                day_low = float(current_d['Low'])
                
                stats_d = calculate_stats(data_d, ema_len, min_pct, max_pct)
                if stats_d: results['d'] = {'symbol': symbol, 'stats': stats_d}

            # Fetch Hourly Data
            data_h = await fetch_chart_data(session, symbol, "1y", "1h")
            if not data_h.empty:
                stats_1h = calculate_stats(data_h, ema_len, min_pct, max_pct)
                if stats_1h:
                    if day_high is not None:
                        stats_1h['d_high'] = day_high
                        stats_1h['d_low'] = day_low
                    results['h'] = {'symbol': symbol, 'stats': stats_1h}
                
                data_3h = resample_to_3h(data_h)
                stats_3h = calculate_stats(data_3h, ema_len, min_pct, max_pct)
                if stats_3h: 
                    if day_high is not None:
                        stats_3h['d_high'] = day_high
                        stats_3h['d_low'] = day_low
                    results['3h'] = {'symbol': symbol, 'stats': stats_3h}
        except:
            pass
        return results

async def run_scan(symbols, ema_len, min_pct, max_pct):
    print(f"\n{Fore.YELLOW}Scanning {len(symbols)} stocks with AsyncIO (Limit: 100)...{RESET}")
    daily_hits, hourly_hits, three_hour_hits = [], [], []
    
    sem = asyncio.Semaphore(100)
    async with aiohttp.ClientSession() as session:
        tasks = [process_symbol_async(sem, session, s, ema_len, min_pct, max_pct) for s in symbols]
        completed = 0
        total = len(tasks)
        start_time = time.time()
        
        for future in asyncio.as_completed(tasks):
            res = await future
            completed += 1
            print(f"\rProgress: {completed}/{total} [{(completed/total)*100:.1f}%]", end="", flush=True)
            if res['h']: hourly_hits.append(res['h'])
            if res['3h']: three_hour_hits.append(res['3h'])
            if res['d']: daily_hits.append(res['d'])
            
    print(f"\n{Fore.GREEN}Scan Complete in {time.time() - start_time:.1f} seconds!{RESET}")
    return daily_hits, hourly_hits, three_hour_hits

async def fetch_and_calc_rsi(sem, session, item, interval, period):
    async with sem:
        symbol = item['symbol']
        # Determine range and interval based on the target timeframe
        if interval == 'd':
            range_str = "1y"
            fetch_interval = "1d"
        elif interval == 'h':
            range_str = "3mo"
            fetch_interval = "1h"
        elif interval == '3h':
            range_str = "6mo"
            fetch_interval = "1h"
        else:
            return

        df = await fetch_chart_data(session, symbol, range_str, fetch_interval)
        if df.empty: return

        if interval == "3h":
            df = resample_to_3h(df)
            
        try:
            rsi_val = calculate_rsi(df, period)
            if rsi_val is not None:
                item['stats']['rsi'] = rsi_val
        except:
            pass

async def enrich_matches_with_rsi(matches, interval, period):
    if not matches: return
    print(f"{Fore.YELLOW}Calculating RSI ({period}) for {len(matches)} symbols...{RESET}")
    sem = asyncio.Semaphore(50)
    async with aiohttp.ClientSession() as session:
        tasks = [fetch_and_calc_rsi(sem, session, m, interval, period) for m in matches]
        completed = 0
        total = len(tasks)
        for future in asyncio.as_completed(tasks):
            await future
            completed += 1
            print(f"\rProgress: {completed}/{total}", end="", flush=True)
    print() # Newline after progress

def get_rsi_preference():
    try:
        rsi_input = input(f"Enter RSI Period (Optional, Default 14, press Enter for default): ").strip()
        if rsi_input == "":
            return 14
        return int(rsi_input)
    except ValueError:
        print(f"{Fore.RED}Invalid input. Using default 14.{RESET}")
        return 14

async def perplexity_chat_loop(matches, timeframe, rsi_period):
    if not matches: return
    
    print(f"\n{Fore.MAGENTA}--- VIKRAM AI ANALYSIS ---{RESET}")
    print("Type your question about these stocks (or 'q' to return to menu).")
    
    # Prepare data summary for the AI (All matches)
    summary = []
    for m in matches:
        s = m['stats']
        rsi_str = f", RSI: {s['rsi']:.2f}" if 'rsi' in s else ""
        summary.append(f"{m['symbol']}: Price {s['price']:.2f}{rsi_str}, Day Range: {s['d_low']:.1f}-{s['d_high']:.1f}")
    
    context = "\n".join(summary)
    timeframe_map = {'h': 'Hourly', '3h': '3-Hour', 'd': 'Daily'}
    
    while True:
        user_query = input(f"\n{Fore.WHITE}Ask Vikram (or 'q'): {RESET}").strip()
        if user_query.lower() in ['q', 'quit', 'exit']: break
        
        full_prompt = (
            f"Context: Analyzing {timeframe_map.get(timeframe)} scan results.\n"
            f"Stock Data:\n{context}\n\n"
            f"User Question: {user_query}"
        )
        
        print(f"{Fore.YELLOW}Vikram is thinking...{RESET}")
        await generate_text_g(full_prompt)

def main():
    try:
        meta_data = get_filtered_symbols()
        if not meta_data: return
        symbols = list(meta_data.keys())

        while True:
            print(f"\n{Fore.CYAN}--- STEP 2: CONFIGURE SCAN ---{RESET}")
            while True:
                try:
                    ema_input = input("Enter EMA Length (e.g. 50, 200): ")
                    if ema_input.lower() in ['q', 'exit']: return
                    ema_len = int(ema_input)
                    break
                except ValueError: print(f"{Fore.RED}Invalid input.{RESET}")

            while True:
                try:
                    min_input = input("Enter Min % (e.g. -2): ")
                    if min_input.lower() in ['q', 'exit']: return
                    min_pct = float(min_input)
                    max_input = input("Enter Max % (e.g. 2): ")
                    if max_input.lower() in ['q', 'exit']: return
                    max_pct = float(max_input)
                    if min_pct >= max_pct: print(f"{Fore.RED}ERROR: Min < Max required.{RESET}")
                    else: break
                except ValueError: print(f"{Fore.RED}Invalid input.{RESET}")

            daily_hits, hourly_hits, three_hour_hits = asyncio.run(run_scan(symbols, ema_len, min_pct, max_pct))

            while True:
                print(f"\n{Fore.CYAN}--- RESULTS MENU ---{RESET}")
                print("[1] Show Jackpot (Union)\n[2] Show Hourly Matches\n[3] Show 3-Hour Matches\n[4] Show Daily Matches\n[5] New Scan\n[0] EXIT")
                choice = input("Select Option: ")
                if choice == '0': return
                elif choice == '5': break
                
                rsi_period = None
                current_matches = []
                current_tf = 'd'
                
                if choice == '1':
                    common = set(x['symbol'] for x in daily_hits) & set(x['symbol'] for x in hourly_hits) & set(x['symbol'] for x in three_hour_hits)
                    current_matches = [x for x in daily_hits if x['symbol'] in common]
                    current_tf = 'd'
                    if current_matches:
                        rsi_period = get_rsi_preference()
                        asyncio.run(enrich_matches_with_rsi(current_matches, current_tf, rsi_period))
                    print_table("JACKPOT LIST (Union)", current_matches, meta_data, rsi_period)
                    
                elif choice == '2':
                    current_matches = hourly_hits
                    current_tf = 'h'
                    if current_matches:
                        rsi_period = get_rsi_preference()
                        asyncio.run(enrich_matches_with_rsi(current_matches, current_tf, rsi_period))
                    print_table("Hourly Matches", current_matches, meta_data, rsi_period)
                    
                elif choice == '3':
                    current_matches = three_hour_hits
                    current_tf = '3h'
                    if current_matches:
                        rsi_period = get_rsi_preference()
                        asyncio.run(enrich_matches_with_rsi(current_matches, current_tf, rsi_period))
                    print_table("3-Hour Matches", current_matches, meta_data, rsi_period)
                    
                elif choice == '4':
                    current_matches = daily_hits
                    current_tf = 'd'
                    if current_matches:
                        rsi_period = get_rsi_preference()
                        asyncio.run(enrich_matches_with_rsi(current_matches, current_tf, rsi_period))
                    print_table("Daily Matches", current_matches, meta_data, rsi_period)
                
                # After showing table, ask for AI analysis
                if choice in ['1', '2', '3', '4'] and current_matches:
                    ai_choice = input(f"\n{Fore.YELLOW}Do you want to discuss these results with Vikram? (y/n): {RESET}").strip().lower()
                    if ai_choice == 'y':
                        asyncio.run(perplexity_chat_loop(current_matches, current_tf, rsi_period))

    except KeyboardInterrupt: print(f"\n{Fore.RED}User Interrupted (Ctrl+C). Exiting...{RESET}")

if __name__ == "__main__":
    main()
