"""
VAIF Studio Python SDK

Official client library for VAIF Studio - the AI-powered backend platform.

Example (async):
    >>> from vaif import create_client
    >>>
    >>> async with create_client(
    ...     project_id="your-project-id",
    ...     api_key="your-api-key"
    ... ) as vaif:
    ...     users = await vaif.db.from_("users").select("*").eq("active", True).execute()
    ...     result = await vaif.storage.from_("avatars").upload("user.png", file_data)

Example (sync - for Django, Flask, scripts):
    >>> from vaif import create_sync_client
    >>>
    >>> with create_sync_client(
    ...     project_id="your-project-id",
    ...     api_key="your-api-key"
    ... ) as vaif:
    ...     users = vaif.db.from_("users").select("*").eq("active", True).execute()
    ...     result = vaif.storage.from_("avatars").upload("user.png", file_data)
"""

from vaif.client import VaifClient, create_client
from vaif.sync_client import SyncVaifClient, create_sync_client
from vaif.database import VaifDatabase, QueryBuilder
from vaif.realtime import VaifRealtime, RealtimeChannel, ConnectionState
from vaif.storage import VaifStorage, StorageBucket
from vaif.functions import VaifFunctions
from vaif.auth import VaifAuth
from vaif.ai import VaifAI
from vaif.typegen import VaifTypeGen, create_typegen, TypeGenOptions
from vaif.retry import RetryConfig

# Exceptions
from vaif.exceptions import (
    VaifError,
    VaifAuthError,
    VaifDatabaseError,
    VaifStorageError,
    VaifFunctionError,
    VaifAIError,
    VaifNetworkError,
    VaifTimeoutError,
    VaifRateLimitError,
    VaifValidationError,
    VaifNotFoundError,
    VaifConflictError,
)

# Types
from vaif.types import (
    VaifConfig,
    ApiResponse,
    ApiError,
    QueryResult,
    User,
    Session,
    AuthResponse,
    FileObject,
    Bucket,
    UploadResult,
    StorageError,
    FunctionResponse,
    FunctionError,
    AIGenerateOptions,
    SchemaGenerationResult,
    FunctionGenerationResult,
    EndpointGenerationResult,
)

__version__ = "0.2.0"
__all__ = [
    # Client
    "VaifClient",
    "create_client",
    # Sync Client
    "SyncVaifClient",
    "create_sync_client",
    # Database
    "VaifDatabase",
    "QueryBuilder",
    # Realtime
    "VaifRealtime",
    "RealtimeChannel",
    "ConnectionState",
    # Storage
    "VaifStorage",
    "StorageBucket",
    # Functions
    "VaifFunctions",
    # Auth
    "VaifAuth",
    # AI
    "VaifAI",
    # Type Generation
    "VaifTypeGen",
    "create_typegen",
    "TypeGenOptions",
    # Retry
    "RetryConfig",
    # Exceptions
    "VaifError",
    "VaifAuthError",
    "VaifDatabaseError",
    "VaifStorageError",
    "VaifFunctionError",
    "VaifAIError",
    "VaifNetworkError",
    "VaifTimeoutError",
    "VaifRateLimitError",
    "VaifValidationError",
    "VaifNotFoundError",
    "VaifConflictError",
    # Types
    "VaifConfig",
    "ApiResponse",
    "ApiError",
    "QueryResult",
    "User",
    "Session",
    "AuthResponse",
    "FileObject",
    "Bucket",
    "UploadResult",
    "StorageError",
    "FunctionResponse",
    "FunctionError",
    "AIGenerateOptions",
    "SchemaGenerationResult",
    "FunctionGenerationResult",
    "EndpointGenerationResult",
]
