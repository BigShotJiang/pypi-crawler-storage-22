"""
VAIF AI Client

AI-powered code generation for schemas, functions, and endpoints.
"""

from __future__ import annotations

from typing import Any, AsyncIterator, Dict, List, Literal, Optional, Union

import httpx

from vaif.types import (
    AIChatRequest,
    AIChatResponse,
    AICreditsInfo,
    AIGenerateOptions,
    EndpointGenerationRequest,
    EndpointGenerationResult,
    FunctionGenerationRequest,
    FunctionGenerationResult,
    SchemaGenerationRequest,
    SchemaGenerationResult,
)


class AIError:
    """AI operation error."""

    def __init__(
        self,
        message: str,
        code: Optional[str] = None,
        status: Optional[int] = None,
    ) -> None:
        self.message = message
        self.code = code
        self.status = status


class VaifAI:
    """AI client for VAIF Studio."""

    def __init__(self, client: Any) -> None:
        """Initialize AI client."""
        self._client = client

    async def generate_schema(
        self,
        request: SchemaGenerationRequest,
        options: Optional[AIGenerateOptions] = None,
    ) -> Dict[str, Union[SchemaGenerationResult, AIError, None]]:
        """
        Generate database schema from natural language.

        Args:
            request: Schema generation request
            options: AI generation options

        Returns:
            Dict with result or error

        Example:
            >>> result = await vaif.ai.generate_schema(
            ...     SchemaGenerationRequest(
            ...         prompt="Create a blog with posts, authors, and comments",
            ...         format="drizzle",
            ...         include_relations=True
            ...     )
            ... )
        """
        options = options or AIGenerateOptions()

        body = {
            **request.model_dump(exclude_none=True),
            "model": options.model.value if options.model else None,
            "temperature": options.temperature,
            "maxTokens": options.max_tokens,
        }

        response = await self._client.request(
            "/ai/generate/schema",
            method="POST",
            body={k: v for k, v in body.items() if v is not None},
        )

        if response.error:
            return {
                "data": None,
                "error": AIError(
                    message=response.error.message,
                    code=response.error.code,
                    status=response.status,
                ),
            }

        return {
            "data": SchemaGenerationResult(**response.data) if response.data else None,
            "error": None,
        }

    async def generate_function(
        self,
        request: FunctionGenerationRequest,
        options: Optional[AIGenerateOptions] = None,
    ) -> Dict[str, Union[FunctionGenerationResult, AIError, None]]:
        """
        Generate edge function from natural language.

        Args:
            request: Function generation request
            options: AI generation options

        Returns:
            Dict with result or error

        Example:
            >>> result = await vaif.ai.generate_function(
            ...     FunctionGenerationRequest(
            ...         prompt="Create a function that sends welcome emails",
            ...         name="send-welcome-email",
            ...         runtime="edge"
            ...     )
            ... )
        """
        options = options or AIGenerateOptions()

        body = {
            **request.model_dump(exclude_none=True),
            "model": options.model.value if options.model else None,
            "temperature": options.temperature,
            "maxTokens": options.max_tokens,
        }

        response = await self._client.request(
            "/ai/generate/function",
            method="POST",
            body={k: v for k, v in body.items() if v is not None},
        )

        if response.error:
            return {
                "data": None,
                "error": AIError(
                    message=response.error.message,
                    code=response.error.code,
                    status=response.status,
                ),
            }

        return {
            "data": FunctionGenerationResult(**response.data) if response.data else None,
            "error": None,
        }

    async def generate_endpoint(
        self,
        request: EndpointGenerationRequest,
        options: Optional[AIGenerateOptions] = None,
    ) -> Dict[str, Union[EndpointGenerationResult, AIError, None]]:
        """
        Generate API endpoint from natural language.

        Args:
            request: Endpoint generation request
            options: AI generation options

        Returns:
            Dict with result or error

        Example:
            >>> result = await vaif.ai.generate_endpoint(
            ...     EndpointGenerationRequest(
            ...         prompt="Create an endpoint to get user profile",
            ...         method="GET",
            ...         path="/users/:id/profile",
            ...         requires_auth=True
            ...     )
            ... )
        """
        options = options or AIGenerateOptions()

        body = {
            **request.model_dump(exclude_none=True),
            "model": options.model.value if options.model else None,
            "temperature": options.temperature,
            "maxTokens": options.max_tokens,
        }

        response = await self._client.request(
            "/ai/generate/endpoint",
            method="POST",
            body={k: v for k, v in body.items() if v is not None},
        )

        if response.error:
            return {
                "data": None,
                "error": AIError(
                    message=response.error.message,
                    code=response.error.code,
                    status=response.status,
                ),
            }

        return {
            "data": EndpointGenerationResult(**response.data) if response.data else None,
            "error": None,
        }

    async def chat(
        self,
        request: AIChatRequest,
        options: Optional[AIGenerateOptions] = None,
    ) -> Dict[str, Union[AIChatResponse, AIError, None]]:
        """
        Chat with AI assistant for project help.

        Args:
            request: Chat request
            options: AI generation options

        Returns:
            Dict with response or error

        Example:
            >>> result = await vaif.ai.chat(
            ...     AIChatRequest(
            ...         messages=[
            ...             AIChatMessage(role="user", content="How do I add pagination?")
            ...         ]
            ...     )
            ... )
        """
        options = options or AIGenerateOptions()

        body = {
            **request.model_dump(exclude_none=True),
            "model": options.model.value if options.model else None,
            "temperature": options.temperature,
            "maxTokens": options.max_tokens,
        }

        response = await self._client.request(
            "/ai/chat",
            method="POST",
            body={k: v for k, v in body.items() if v is not None},
        )

        if response.error:
            return {
                "data": None,
                "error": AIError(
                    message=response.error.message,
                    code=response.error.code,
                    status=response.status,
                ),
            }

        return {
            "data": AIChatResponse(**response.data) if response.data else None,
            "error": None,
        }

    async def chat_stream(
        self,
        request: AIChatRequest,
        options: Optional[AIGenerateOptions] = None,
    ) -> AsyncIterator[str]:
        """
        Stream chat response.

        Args:
            request: Chat request
            options: AI generation options

        Yields:
            Response chunks

        Example:
            >>> async for chunk in vaif.ai.chat_stream(request):
            ...     print(chunk, end="", flush=True)
        """
        options = options or AIGenerateOptions()
        config = self._client.get_config()

        headers = {
            "Content-Type": "application/json",
            "X-Project-ID": config.project_id,
            "apikey": config.api_key,
        }

        token = self._client.get_access_token()
        if token:
            headers["Authorization"] = f"Bearer {token}"

        body = {
            **request.model_dump(exclude_none=True),
            "model": options.model.value if options.model else None,
            "temperature": options.temperature,
            "maxTokens": options.max_tokens,
            "stream": True,
        }

        async with httpx.AsyncClient() as http:
            async with http.stream(
                "POST",
                f"{config.api_url}/ai/chat/stream",
                headers=headers,
                json={k: v for k, v in body.items() if v is not None},
            ) as response:
                if not response.is_success:
                    raise Exception(f"AI chat failed: {response.status_code}")

                async for line in response.aiter_lines():
                    if line.startswith("data: "):
                        data = line[6:]
                        if data == "[DONE]":
                            return
                        try:
                            import json

                            parsed = json.loads(data)
                            if "content" in parsed:
                                yield parsed["content"]
                        except json.JSONDecodeError:
                            pass

    async def get_credits(
        self,
    ) -> Dict[str, Union[AICreditsInfo, AIError, None]]:
        """
        Get AI credits information.

        Returns:
            Dict with credits info or error

        Example:
            >>> result = await vaif.ai.get_credits()
            >>> print(f"Balance: {result['data'].balance} credits")
        """
        response = await self._client.request("/ai/credits")

        if response.error:
            return {
                "data": None,
                "error": AIError(
                    message=response.error.message,
                    code=response.error.code,
                    status=response.status,
                ),
            }

        return {
            "data": AICreditsInfo(**response.data) if response.data else None,
            "error": None,
        }

    async def explain(
        self,
        code: str,
        language: Optional[str] = None,
        context: Optional[str] = None,
        options: Optional[AIGenerateOptions] = None,
    ) -> Dict[str, Union[Dict[str, Any], AIError, None]]:
        """
        Explain code or schema.

        Args:
            code: Code to explain
            language: Programming language
            context: Additional context
            options: AI generation options

        Returns:
            Dict with explanation or error
        """
        options = options or AIGenerateOptions()

        body: Dict[str, Any] = {"code": code}
        if language:
            body["language"] = language
        if context:
            body["context"] = context
        if options.model:
            body["model"] = options.model.value
        if options.temperature:
            body["temperature"] = options.temperature

        response = await self._client.request(
            "/ai/explain",
            method="POST",
            body=body,
        )

        if response.error:
            return {
                "data": None,
                "error": AIError(
                    message=response.error.message,
                    code=response.error.code,
                    status=response.status,
                ),
            }

        return {"data": response.data, "error": None}

    async def review(
        self,
        code: str,
        language: Optional[str] = None,
        focus: Optional[List[Literal["security", "performance", "style"]]] = None,
        options: Optional[AIGenerateOptions] = None,
    ) -> Dict[str, Union[Dict[str, Any], AIError, None]]:
        """
        Review code for issues and improvements.

        Args:
            code: Code to review
            language: Programming language
            focus: Review focus areas
            options: AI generation options

        Returns:
            Dict with review or error
        """
        options = options or AIGenerateOptions()

        body: Dict[str, Any] = {"code": code}
        if language:
            body["language"] = language
        if focus:
            body["focus"] = focus
        if options.model:
            body["model"] = options.model.value
        if options.temperature:
            body["temperature"] = options.temperature

        response = await self._client.request(
            "/ai/review",
            method="POST",
            body=body,
        )

        if response.error:
            return {
                "data": None,
                "error": AIError(
                    message=response.error.message,
                    code=response.error.code,
                    status=response.status,
                ),
            }

        return {"data": response.data, "error": None}

    async def generate_types(
        self,
        schema: str,
        format_: Literal["typescript", "zod", "io-ts"] = "typescript",
        options: Optional[AIGenerateOptions] = None,
    ) -> Dict[str, Union[Dict[str, Any], AIError, None]]:
        """
        Generate TypeScript types from schema.

        Args:
            schema: Schema definition
            format_: Output format
            options: AI generation options

        Returns:
            Dict with types or error
        """
        options = options or AIGenerateOptions()

        body: Dict[str, Any] = {
            "schema": schema,
            "format": format_,
        }
        if options.model:
            body["model"] = options.model.value

        response = await self._client.request(
            "/ai/generate/types",
            method="POST",
            body=body,
        )

        if response.error:
            return {
                "data": None,
                "error": AIError(
                    message=response.error.message,
                    code=response.error.code,
                    status=response.status,
                ),
            }

        return {"data": response.data, "error": None}

    async def generate_migration(
        self,
        current_schema: str,
        target_schema: str,
        database: Literal["postgresql", "mysql", "sqlite"] = "postgresql",
        options: Optional[AIGenerateOptions] = None,
    ) -> Dict[str, Union[Dict[str, Any], AIError, None]]:
        """
        Generate SQL migration from schema diff.

        Args:
            current_schema: Current schema
            target_schema: Target schema
            database: Database type
            options: AI generation options

        Returns:
            Dict with migration or error
        """
        options = options or AIGenerateOptions()

        body: Dict[str, Any] = {
            "currentSchema": current_schema,
            "targetSchema": target_schema,
            "database": database,
        }
        if options.model:
            body["model"] = options.model.value

        response = await self._client.request(
            "/ai/generate/migration",
            method="POST",
            body=body,
        )

        if response.error:
            return {
                "data": None,
                "error": AIError(
                    message=response.error.message,
                    code=response.error.code,
                    status=response.status,
                ),
            }

        return {"data": response.data, "error": None}
