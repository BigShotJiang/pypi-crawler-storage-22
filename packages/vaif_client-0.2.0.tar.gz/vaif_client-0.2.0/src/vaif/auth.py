"""
VAIF Auth Client

Authentication and user management for VAIF Studio projects.
"""

from __future__ import annotations

from typing import Any, Callable, Dict, List, Literal, Optional, Set, Union

from vaif.types import AuthError, AuthResponse, OAuthProvider, Session, User


AuthChangeEvent = Literal[
    "INITIAL_SESSION",
    "SIGNED_IN",
    "SIGNED_OUT",
    "TOKEN_REFRESHED",
    "USER_UPDATED",
    "PASSWORD_RECOVERY",
]
AuthStateChangeCallback = Callable[[AuthChangeEvent, Optional[Session]], None]


class VaifAuth:
    """Auth client for VAIF Studio."""

    def __init__(self, client: Any) -> None:
        """Initialize auth client."""
        self._client = client
        self._current_session: Optional[Session] = None
        self._current_user: Optional[User] = None
        self._state_callbacks: Set[AuthStateChangeCallback] = set()

    async def get_session(
        self,
    ) -> Dict[str, Union[Dict[str, Optional[Session]], AuthError, None]]:
        """
        Get current session.

        Returns:
            Dict with session or None
        """
        return {"data": {"session": self._current_session}, "error": None}

    async def get_user(
        self,
    ) -> Dict[str, Union[Dict[str, Optional[User]], AuthError, None]]:
        """
        Get current user.

        Returns:
            Dict with user or None
        """
        if not self._current_session:
            return {"data": {"user": None}, "error": None}

        response = await self._client.request("/auth/user")

        if response.error:
            return {
                "data": {"user": None},
                "error": AuthError(
                    message=response.error.message,
                    status=response.status,
                ),
            }

        self._current_user = User(**response.data) if response.data else None
        return {"data": {"user": self._current_user}, "error": None}

    async def sign_up(
        self,
        email: Optional[str] = None,
        password: Optional[str] = None,
        phone: Optional[str] = None,
        data: Optional[Dict[str, Any]] = None,
        email_redirect_to: Optional[str] = None,
    ) -> AuthResponse:
        """
        Sign up with email and password.

        Args:
            email: User email
            password: User password
            phone: User phone (optional)
            data: User metadata
            email_redirect_to: Redirect URL after confirmation

        Returns:
            AuthResponse with session/user or error
        """
        body: Dict[str, Any] = {}
        if email:
            body["email"] = email
        if password:
            body["password"] = password
        if phone:
            body["phone"] = phone
        if data:
            body["data"] = data
        if email_redirect_to:
            body["redirectTo"] = email_redirect_to

        response = await self._client.request(
            "/auth/signup",
            method="POST",
            body=body,
        )

        if response.error:
            return AuthResponse(
                session=None,
                user=None,
                error=AuthError(
                    message=response.error.message,
                    status=response.status,
                ),
            )

        session = Session(**response.data["session"]) if response.data and response.data.get("session") else None
        user = User(**response.data["user"]) if response.data and response.data.get("user") else None

        if session:
            await self._set_session(session)
            self._notify_state_change("SIGNED_IN", session)

        return AuthResponse(session=session, user=user, error=None)

    async def sign_in_with_password(
        self,
        email: Optional[str] = None,
        password: Optional[str] = None,
        phone: Optional[str] = None,
    ) -> AuthResponse:
        """
        Sign in with email/phone and password.

        Args:
            email: User email
            password: User password
            phone: User phone (alternative to email)

        Returns:
            AuthResponse with session/user or error
        """
        body: Dict[str, Any] = {}
        if email:
            body["email"] = email
        if password:
            body["password"] = password
        if phone:
            body["phone"] = phone

        response = await self._client.request(
            "/auth/token?grant_type=password",
            method="POST",
            body=body,
        )

        if response.error:
            return AuthResponse(
                session=None,
                user=None,
                error=AuthError(
                    message=response.error.message,
                    status=response.status,
                ),
            )

        session = Session(**response.data["session"]) if response.data and response.data.get("session") else None
        user = User(**response.data["user"]) if response.data and response.data.get("user") else None

        if session:
            await self._set_session(session)
            self._notify_state_change("SIGNED_IN", session)

        return AuthResponse(session=session, user=user, error=None)

    async def sign_in_with_oauth(
        self,
        provider: OAuthProvider,
        redirect_to: Optional[str] = None,
        scopes: Optional[List[str]] = None,
        query_params: Optional[Dict[str, str]] = None,
    ) -> Dict[str, Union[Dict[str, str], AuthError, None]]:
        """
        Sign in with OAuth provider.

        Args:
            provider: OAuth provider
            redirect_to: Redirect URL after auth
            scopes: OAuth scopes
            query_params: Additional query params

        Returns:
            Dict with provider and URL
        """
        config = self._client.get_config()

        params = [f"provider={provider.value}"]
        if redirect_to:
            params.append(f"redirect_to={redirect_to}")
        if scopes:
            params.append(f"scopes={' '.join(scopes)}")
        if query_params:
            for key, value in query_params.items():
                params.append(f"{key}={value}")

        url = f"{config.api_url}/auth/authorize?{'&'.join(params)}"

        return {
            "data": {"provider": provider.value, "url": url},
            "error": None,
        }

    async def sign_in_with_otp(
        self,
        email: Optional[str] = None,
        phone: Optional[str] = None,
        create_user: bool = True,
        redirect_to: Optional[str] = None,
    ) -> Dict[str, Union[Dict[str, str], AuthError, None]]:
        """
        Sign in with magic link/OTP.

        Args:
            email: User email
            phone: User phone
            create_user: Create user if doesn't exist
            redirect_to: Redirect URL

        Returns:
            Dict with message ID or error
        """
        body: Dict[str, Any] = {"create_user": create_user}
        if email:
            body["email"] = email
        if phone:
            body["phone"] = phone
        if redirect_to:
            body["redirect_to"] = redirect_to

        response = await self._client.request(
            "/auth/otp",
            method="POST",
            body=body,
        )

        if response.error:
            return {
                "data": {},
                "error": AuthError(
                    message=response.error.message,
                    status=response.status,
                ),
            }

        return {
            "data": {"messageId": response.data.get("messageId", "")} if response.data else {},
            "error": None,
        }

    async def verify_otp(
        self,
        token: str,
        type_: Literal["sms", "email", "magiclink"],
        email: Optional[str] = None,
        phone: Optional[str] = None,
    ) -> AuthResponse:
        """
        Verify OTP code.

        Args:
            token: OTP token
            type_: OTP type
            email: User email
            phone: User phone

        Returns:
            AuthResponse with session/user or error
        """
        body: Dict[str, Any] = {"token": token, "type": type_}
        if email:
            body["email"] = email
        if phone:
            body["phone"] = phone

        response = await self._client.request(
            "/auth/verify",
            method="POST",
            body=body,
        )

        if response.error:
            return AuthResponse(
                session=None,
                user=None,
                error=AuthError(
                    message=response.error.message,
                    status=response.status,
                ),
            )

        session = Session(**response.data["session"]) if response.data and response.data.get("session") else None
        user = User(**response.data["user"]) if response.data and response.data.get("user") else None

        if session:
            await self._set_session(session)
            self._notify_state_change("SIGNED_IN", session)

        return AuthResponse(session=session, user=user, error=None)

    async def sign_out(
        self, scope: Literal["global", "local", "others"] = "local"
    ) -> Dict[str, Optional[AuthError]]:
        """
        Sign out.

        Args:
            scope: Sign out scope

        Returns:
            Dict with error if failed
        """
        if scope != "local":
            await self._client.request(
                "/auth/logout",
                method="POST",
                body={"scope": scope},
            )

        await self._clear_session()
        self._notify_state_change("SIGNED_OUT", None)

        return {"error": None}

    async def reset_password_for_email(
        self,
        email: str,
        redirect_to: Optional[str] = None,
        captcha_token: Optional[str] = None,
    ) -> Dict[str, Optional[AuthError]]:
        """
        Reset password via email.

        Args:
            email: User email
            redirect_to: Redirect URL
            captcha_token: Captcha token

        Returns:
            Dict with error if failed
        """
        body: Dict[str, Any] = {"email": email}
        if redirect_to:
            body["redirect_to"] = redirect_to
        if captcha_token:
            body["captcha_token"] = captcha_token

        response = await self._client.request(
            "/auth/recover",
            method="POST",
            body=body,
        )

        if response.error:
            return {
                "error": AuthError(
                    message=response.error.message,
                    status=response.status,
                )
            }

        return {"error": None}

    async def update_user(
        self,
        email: Optional[str] = None,
        password: Optional[str] = None,
        phone: Optional[str] = None,
        data: Optional[Dict[str, Any]] = None,
        nonce: Optional[str] = None,
    ) -> Dict[str, Union[Dict[str, Optional[User]], AuthError, None]]:
        """
        Update user.

        Args:
            email: New email
            password: New password
            phone: New phone
            data: User metadata
            nonce: Email change nonce

        Returns:
            Dict with user or error
        """
        body: Dict[str, Any] = {}
        if email:
            body["email"] = email
        if password:
            body["password"] = password
        if phone:
            body["phone"] = phone
        if data:
            body["data"] = data
        if nonce:
            body["nonce"] = nonce

        response = await self._client.request(
            "/auth/user",
            method="PUT",
            body=body,
        )

        if response.error:
            return {
                "data": {"user": None},
                "error": AuthError(
                    message=response.error.message,
                    status=response.status,
                ),
            }

        self._current_user = User(**response.data) if response.data else None
        self._notify_state_change("USER_UPDATED", self._current_session)

        return {"data": {"user": self._current_user}, "error": None}

    async def refresh_session(self) -> AuthResponse:
        """
        Refresh session.

        Returns:
            AuthResponse with new session or error
        """
        if not self._current_session or not self._current_session.refresh_token:
            return AuthResponse(
                session=None,
                user=None,
                error=AuthError(message="No refresh token available", status=401),
            )

        response = await self._client.request(
            "/auth/token?grant_type=refresh_token",
            method="POST",
            body={"refresh_token": self._current_session.refresh_token},
        )

        if response.error:
            await self._clear_session()
            self._notify_state_change("TOKEN_REFRESHED", None)

            return AuthResponse(
                session=None,
                user=None,
                error=AuthError(
                    message=response.error.message,
                    status=response.status,
                ),
            )

        session = Session(**response.data["session"]) if response.data and response.data.get("session") else None
        user = User(**response.data["user"]) if response.data and response.data.get("user") else None

        if session:
            await self._set_session(session)
            self._notify_state_change("TOKEN_REFRESHED", session)

        return AuthResponse(session=session, user=user, error=None)

    def on_auth_state_change(
        self, callback: AuthStateChangeCallback
    ) -> Dict[str, Dict[str, Any]]:
        """
        Subscribe to auth state changes.

        Args:
            callback: Callback function

        Returns:
            Dict with subscription
        """
        self._state_callbacks.add(callback)

        # Immediately call with current state
        if self._current_session:
            callback("INITIAL_SESSION", self._current_session)

        def unsubscribe() -> None:
            self._state_callbacks.discard(callback)

        return {"data": {"subscription": {"unsubscribe": unsubscribe}}}

    async def exchange_code_for_session(self, code: str) -> AuthResponse:
        """
        Exchange authorization code for session (PKCE).

        Args:
            code: Authorization code

        Returns:
            AuthResponse with session or error
        """
        response = await self._client.request(
            "/auth/token?grant_type=authorization_code",
            method="POST",
            body={"code": code},
        )

        if response.error:
            return AuthResponse(
                session=None,
                user=None,
                error=AuthError(
                    message=response.error.message,
                    status=response.status,
                ),
            )

        session = Session(**response.data["session"]) if response.data and response.data.get("session") else None
        user = User(**response.data["user"]) if response.data and response.data.get("user") else None

        if session:
            await self._set_session(session)
            self._notify_state_change("SIGNED_IN", session)

        return AuthResponse(session=session, user=user, error=None)

    # Private methods

    async def _set_session(self, session: Session) -> None:
        """Set current session."""
        self._current_session = session
        self._current_user = session.user
        self._client.set_access_token(session.access_token)

    async def _clear_session(self) -> None:
        """Clear current session."""
        self._current_session = None
        self._current_user = None
        self._client.set_access_token(None)

    def _notify_state_change(
        self, event: AuthChangeEvent, session: Optional[Session]
    ) -> None:
        """Notify state change callbacks."""
        for callback in self._state_callbacks:
            try:
                callback(event, session)
            except Exception:
                pass
