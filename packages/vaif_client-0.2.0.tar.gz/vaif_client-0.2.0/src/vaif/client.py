"""
VAIF Studio Client

Main entry point for the VAIF Python SDK.
"""

from __future__ import annotations

import json
import logging
from typing import Any, Dict, Optional

import httpx

from vaif.exceptions import (
    VaifAuthError,
    VaifError,
    VaifNetworkError,
    VaifRateLimitError,
    VaifTimeoutError,
)
from vaif.retry import RetryConfig, async_sleep_with_backoff
from vaif.types import ApiError, ApiResponse, VaifConfig

logger = logging.getLogger("vaif")


def create_client(
    project_id: str,
    api_key: str,
    api_url: str = "https://api.vaif.studio",
    realtime_url: str = "wss://realtime.vaif.studio",
    timeout: int = 30000,
    headers: Optional[Dict[str, str]] = None,
    debug: bool = False,
    auto_refresh_token: bool = True,
    persist_session: bool = True,
    retry: Optional[RetryConfig] = None,
) -> "VaifClient":
    """
    Create a VAIF Studio client instance.

    Args:
        project_id: Your VAIF project ID
        api_key: Your VAIF API key
        api_url: API base URL (optional)
        realtime_url: WebSocket URL (optional)
        timeout: Request timeout in milliseconds
        headers: Custom headers to include in requests
        debug: Enable debug logging
        auto_refresh_token: Automatically refresh auth tokens
        persist_session: Persist session to storage
        retry: Retry configuration for transient errors

    Returns:
        VaifClient: Configured client instance

    Example:
        >>> vaif = create_client(
        ...     project_id="your-project-id",
        ...     api_key="your-api-key"
        ... )
    """
    config = VaifConfig(
        project_id=project_id,
        api_key=api_key,
        api_url=api_url,
        realtime_url=realtime_url,
        timeout=timeout,
        headers=headers or {},
        debug=debug,
        auto_refresh_token=auto_refresh_token,
        persist_session=persist_session,
    )
    return VaifClient(config, retry=retry)


class VaifClient:
    """
    VAIF Studio Client.

    Provides access to all VAIF services:
    - Database (db)
    - Realtime subscriptions (realtime)
    - Storage (storage)
    - Edge Functions (functions)
    - Authentication (auth)
    - AI Generation (ai)
    """

    def __init__(
        self,
        config: VaifConfig,
        retry: Optional[RetryConfig] = None,
    ) -> None:
        """Initialize the VAIF client."""
        self._config = config
        self._access_token: Optional[str] = None
        self._http_client: Optional[httpx.AsyncClient] = None
        self._retry_config = retry or RetryConfig()

        # Configure logging
        if config.debug:
            logging.basicConfig(level=logging.DEBUG)
            logger.setLevel(logging.DEBUG)

        # Lazy-initialize sub-clients
        self._db: Optional["VaifDatabase"] = None
        self._realtime: Optional["VaifRealtime"] = None
        self._storage: Optional["VaifStorage"] = None
        self._functions: Optional["VaifFunctions"] = None
        self._auth: Optional["VaifAuth"] = None
        self._ai: Optional["VaifAI"] = None
        self._typegen: Optional["VaifTypeGen"] = None

    @property
    def db(self) -> "VaifDatabase":
        """Database client for CRUD operations."""
        if self._db is None:
            from vaif.database import VaifDatabase

            self._db = VaifDatabase(self)
        return self._db

    @property
    def realtime(self) -> "VaifRealtime":
        """Realtime client for subscriptions."""
        if self._realtime is None:
            from vaif.realtime import VaifRealtime

            self._realtime = VaifRealtime(self)
        return self._realtime

    @property
    def storage(self) -> "VaifStorage":
        """Storage client for file operations."""
        if self._storage is None:
            from vaif.storage import VaifStorage

            self._storage = VaifStorage(self)
        return self._storage

    @property
    def functions(self) -> "VaifFunctions":
        """Functions client for edge function invocation."""
        if self._functions is None:
            from vaif.functions import VaifFunctions

            self._functions = VaifFunctions(self)
        return self._functions

    @property
    def auth(self) -> "VaifAuth":
        """Auth client for authentication."""
        if self._auth is None:
            from vaif.auth import VaifAuth

            self._auth = VaifAuth(self)
        return self._auth

    @property
    def ai(self) -> "VaifAI":
        """AI client for generation features."""
        if self._ai is None:
            from vaif.ai import VaifAI

            self._ai = VaifAI(self)
        return self._ai

    @property
    def typegen(self) -> "VaifTypeGen":
        """Type generator for generating Python types from database schema."""
        if self._typegen is None:
            from vaif.typegen import VaifTypeGen

            self._typegen = VaifTypeGen(self)
        return self._typegen

    def get_config(self) -> VaifConfig:
        """Get current configuration."""
        return self._config

    def set_access_token(self, token: Optional[str]) -> None:
        """Set access token for authenticated requests."""
        self._access_token = token

    def get_access_token(self) -> Optional[str]:
        """Get current access token."""
        return self._access_token

    async def _get_http_client(self) -> httpx.AsyncClient:
        """Get or create HTTP client."""
        if self._http_client is None or self._http_client.is_closed:
            self._http_client = httpx.AsyncClient(
                base_url=self._config.api_url,
                timeout=httpx.Timeout(self._config.timeout / 1000),
            )
        return self._http_client

    def _build_headers(
        self, headers: Optional[Dict[str, str]] = None
    ) -> Dict[str, str]:
        """Build request headers with auth and project info."""
        request_headers = {
            "Content-Type": "application/json",
            "X-Project-ID": self._config.project_id,
            "apikey": self._config.api_key,
            **self._config.headers,
            **(headers or {}),
        }
        if self._access_token:
            request_headers["Authorization"] = f"Bearer {self._access_token}"
        return request_headers

    async def request(
        self,
        path: str,
        method: str = "GET",
        body: Optional[Any] = None,
        params: Optional[Dict[str, Any]] = None,
        headers: Optional[Dict[str, str]] = None,
        timeout: Optional[int] = None,
        retry: Optional[RetryConfig] = None,
    ) -> ApiResponse[Any]:
        """
        Make an authenticated API request with automatic retry.

        Args:
            path: API endpoint path
            method: HTTP method
            body: Request body (will be JSON serialized)
            params: Query parameters
            headers: Additional headers
            timeout: Request timeout override (milliseconds)
            retry: Per-request retry config override

        Returns:
            ApiResponse with data or error
        """
        client = await self._get_http_client()
        request_headers = self._build_headers(headers)
        retry_config = retry or self._retry_config
        timeout_seconds = timeout / 1000 if timeout else None

        logger.debug(f"{method} {path}")

        last_error: Optional[ApiResponse[Any]] = None

        for attempt in range(retry_config.max_retries + 1):
            try:
                response = await client.request(
                    method=method,
                    url=path,
                    params=params,
                    json=body if body is not None else None,
                    headers=request_headers,
                    timeout=timeout_seconds,
                )

                response_headers = dict(response.headers)

                if response.is_success:
                    data = self._parse_response_body(response)
                    return ApiResponse(
                        data=data,
                        error=None,
                        status=response.status_code,
                        headers=response_headers,
                    )

                # Check if we should retry this status code
                if retry_config.should_retry(response.status_code, attempt):
                    # Respect Retry-After header for 429
                    retry_after = response.headers.get("retry-after")
                    if retry_after and response.status_code == 429:
                        try:
                            delay = float(retry_after)
                        except ValueError:
                            delay = retry_config.get_delay(attempt)
                        logger.debug(
                            f"Rate limited, retry after {delay:.2f}s "
                            f"(attempt {attempt + 1}/{retry_config.max_retries})"
                        )
                        import asyncio
                        await asyncio.sleep(delay)
                    else:
                        await async_sleep_with_backoff(retry_config, attempt)
                    continue

                # Non-retryable error
                error_data = self._parse_response_body(response)
                error = self._build_api_error(
                    response.status_code, error_data, response_headers
                )
                return ApiResponse(
                    data=None,
                    error=error,
                    status=response.status_code,
                    headers=response_headers,
                )

            except httpx.TimeoutException:
                if retry_config.should_retry(408, attempt):
                    await async_sleep_with_backoff(retry_config, attempt)
                    continue
                return ApiResponse(
                    data=None,
                    error=ApiError(message="Request timed out", code="TIMEOUT"),
                    status=0,
                    headers={},
                )
            except httpx.RequestError as e:
                if retry_config.should_retry(500, attempt):
                    await async_sleep_with_backoff(retry_config, attempt)
                    continue
                return ApiResponse(
                    data=None,
                    error=ApiError(message=str(e), code="NETWORK_ERROR"),
                    status=0,
                    headers={},
                )

        # Exhausted all retries - return last error
        return last_error or ApiResponse(
            data=None,
            error=ApiError(
                message="Request failed after all retry attempts",
                code="MAX_RETRIES_EXCEEDED",
            ),
            status=0,
            headers={},
        )

    def _parse_response_body(self, response: httpx.Response) -> Any:
        """Parse response body based on content type."""
        content_type = response.headers.get("content-type", "")
        if content_type.startswith("application/json"):
            try:
                return response.json()
            except json.JSONDecodeError:
                return None
        return response.text if response.text else None

    def _build_api_error(
        self,
        status: int,
        data: Any,
        headers: Dict[str, str],
    ) -> ApiError:
        """Build ApiError from response data."""
        if isinstance(data, dict):
            return ApiError(
                message=data.get("message") or data.get("error") or "Request failed",
                code=data.get("code"),
                status=status,
                details=data.get("details"),
                request_id=headers.get("x-request-id"),
            )
        return ApiError(
            message=f"Request failed with status {status}",
            status=status,
        )

    async def close(self) -> None:
        """Close the client and release resources."""
        if self._http_client:
            await self._http_client.aclose()
            self._http_client = None

        if self._realtime:
            await self._realtime.disconnect()

    async def __aenter__(self) -> "VaifClient":
        """Async context manager entry."""
        return self

    async def __aexit__(self, *args: Any) -> None:
        """Async context manager exit."""
        await self.close()

    def debug(self, *args: Any) -> None:
        """Log debug messages."""
        if self._config.debug:
            logger.debug(" ".join(str(arg) for arg in args))
