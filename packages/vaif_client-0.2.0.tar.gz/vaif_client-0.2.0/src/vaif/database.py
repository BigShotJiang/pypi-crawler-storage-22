"""
VAIF Database Client

Type-safe database operations with a fluent query builder.
"""

from __future__ import annotations

import logging
from typing import Any, Dict, Generic, List, Literal, Optional, TypeVar, Union

from vaif.types import QueryError, QueryResult

logger = logging.getLogger("vaif.database")

T = TypeVar("T", bound=Dict[str, Any])


class VaifDatabase:
    """Database client for VAIF Studio."""

    def __init__(self, client: "VaifClient") -> None:  # type: ignore[name-defined]
        """Initialize database client."""
        self._client = client

    def from_(self, table: str) -> "QueryBuilder[Dict[str, Any]]":
        """
        Start a query on a table.

        Args:
            table: Table name

        Returns:
            QueryBuilder for chaining operations

        Example:
            >>> users = await vaif.db.from_("users").select("*").execute()
        """
        return QueryBuilder(self._client, table)

    async def raw(
        self, sql: str, params: Optional[List[Any]] = None
    ) -> QueryResult[List[Dict[str, Any]]]:
        """
        Execute raw SQL query (admin only).

        Args:
            sql: SQL query string
            params: Query parameters

        Returns:
            Query result with rows

        Example:
            >>> result = await vaif.db.raw(
            ...     "SELECT * FROM users WHERE id = $1",
            ...     [user_id]
            ... )
        """
        response = await self._client.request(
            "/db/query",
            method="POST",
            body={"sql": sql, "params": params or []},
        )

        if response.error:
            return QueryResult(
                data=[],
                error=QueryError(
                    message=response.error.message,
                    code=response.error.code or "QUERY_ERROR",
                ),
                status=response.status,
            )

        rows = response.data.get("rows", []) if response.data else []
        return QueryResult(data=rows, error=None, status=response.status)

    async def rpc(
        self, function_name: str, params: Optional[Dict[str, Any]] = None
    ) -> QueryResult[Any]:
        """
        Execute a stored procedure/function.

        Args:
            function_name: Function name
            params: Function parameters

        Returns:
            Function result

        Example:
            >>> result = await vaif.db.rpc("calculate_total", {"order_id": "123"})
        """
        response = await self._client.request(
            f"/db/rpc/{function_name}",
            method="POST",
            body=params or {},
        )

        return QueryResult(
            data=response.data,
            error=QueryError(
                message=response.error.message,
                code=response.error.code or "RPC_ERROR",
            )
            if response.error
            else None,
            status=response.status,
        )


class QueryBuilder(Generic[T]):
    """
    Query builder for constructing database queries.

    Supports fluent chaining for building complex queries.
    """

    def __init__(self, client: Any, table: str) -> None:
        """Initialize query builder."""
        self._client = client
        self._table = table
        self._query_type: Literal["select", "insert", "update", "delete"] = "select"
        self._select_columns: str = "*"
        self._insert_data: Optional[Union[Dict[str, Any], List[Dict[str, Any]]]] = None
        self._update_data: Optional[Dict[str, Any]] = None
        self._filters: List[Dict[str, Any]] = []
        self._order_specs: List[Dict[str, Any]] = []
        self._limit_count: Optional[int] = None
        self._offset_count: Optional[int] = None
        self._returning: Optional[str] = None
        self._count_option: Optional[Literal["exact", "planned", "estimated"]] = None
        self._negate_next: bool = False
        self._on_conflict_columns: Optional[List[str]] = None
        self._on_conflict_action: Optional[Literal["nothing", "update"]] = None
        self._on_conflict_update: Optional[Dict[str, Any]] = None

    def select(self, columns: Union[str, List[str]] = "*") -> "QueryBuilder[T]":
        """
        Select columns.

        Args:
            columns: Column names or "*" for all

        Returns:
            Self for chaining
        """
        self._query_type = "select"
        self._select_columns = (
            ", ".join(columns) if isinstance(columns, list) else columns
        )
        return self

    def insert(
        self, data: Union[Dict[str, Any], List[Dict[str, Any]]]
    ) -> "QueryBuilder[T]":
        """
        Insert data.

        Args:
            data: Record or list of records to insert

        Returns:
            Self for chaining
        """
        self._query_type = "insert"
        self._insert_data = data
        return self

    def update(self, data: Dict[str, Any]) -> "QueryBuilder[T]":
        """
        Update data.

        Args:
            data: Fields to update

        Returns:
            Self for chaining
        """
        self._query_type = "update"
        self._update_data = data
        return self

    def delete(self) -> "QueryBuilder[T]":
        """
        Delete rows.

        Returns:
            Self for chaining
        """
        self._query_type = "delete"
        return self

    def upsert(
        self,
        data: Union[Dict[str, Any], List[Dict[str, Any]]],
        on_conflict: Union[str, List[str]],
        update_columns: Optional[Dict[str, Any]] = None,
    ) -> "QueryBuilder[T]":
        """
        Insert or update on conflict (upsert).

        Args:
            data: Record or list of records to upsert
            on_conflict: Column(s) that determine conflict
            update_columns: Specific columns to update on conflict.
                           If None, updates all non-conflict columns.

        Returns:
            Self for chaining

        Example:
            >>> result = await vaif.db.from_("users").upsert(
            ...     {"email": "user@test.com", "name": "Updated Name"},
            ...     on_conflict="email"
            ... ).execute()
        """
        self._query_type = "insert"
        self._insert_data = data
        self._on_conflict_columns = (
            [on_conflict] if isinstance(on_conflict, str) else list(on_conflict)
        )
        self._on_conflict_action = "update"
        self._on_conflict_update = update_columns
        return self

    def on_conflict(self, columns: Union[str, List[str]]) -> "QueryBuilder[T]":
        """
        Handle insert conflicts (upsert).

        Args:
            columns: Conflict columns

        Returns:
            Self for chaining
        """
        self._on_conflict_columns = (
            [columns] if isinstance(columns, str) else list(columns)
        )
        return self

    def do_nothing(self) -> "QueryBuilder[T]":
        """
        Do nothing on conflict.

        Returns:
            Self for chaining
        """
        self._on_conflict_action = "nothing"
        return self

    def do_update(self, data: Dict[str, Any]) -> "QueryBuilder[T]":
        """
        Update on conflict.

        Args:
            data: Fields to update on conflict

        Returns:
            Self for chaining
        """
        self._on_conflict_action = "update"
        self._on_conflict_update = data
        return self

    def returning(self, columns: Union[str, List[str]] = "*") -> "QueryBuilder[T]":
        """
        Specify columns to return after insert/update/delete.

        Args:
            columns: Column names or "*" for all

        Returns:
            Self for chaining

        Example:
            >>> result = await vaif.db.from_("users") \\
            ...     .insert({"email": "user@test.com"}) \\
            ...     .returning("id, email") \\
            ...     .execute()
        """
        self._returning = (
            ", ".join(columns) if isinstance(columns, list) else columns
        )
        return self

    # Filter methods
    def eq(self, column: str, value: Any) -> "QueryBuilder[T]":
        """Filter: column equals value."""
        operator = "neq" if self._negate_next else "eq"
        self._add_filter(column, operator, value)
        self._negate_next = False
        return self

    def neq(self, column: str, value: Any) -> "QueryBuilder[T]":
        """Filter: column not equals value."""
        operator = "eq" if self._negate_next else "neq"
        self._add_filter(column, operator, value)
        self._negate_next = False
        return self

    def gt(self, column: str, value: Any) -> "QueryBuilder[T]":
        """Filter: column greater than value."""
        operator = "lte" if self._negate_next else "gt"
        self._add_filter(column, operator, value)
        self._negate_next = False
        return self

    def gte(self, column: str, value: Any) -> "QueryBuilder[T]":
        """Filter: column greater than or equal to value."""
        operator = "lt" if self._negate_next else "gte"
        self._add_filter(column, operator, value)
        self._negate_next = False
        return self

    def lt(self, column: str, value: Any) -> "QueryBuilder[T]":
        """Filter: column less than value."""
        operator = "gte" if self._negate_next else "lt"
        self._add_filter(column, operator, value)
        self._negate_next = False
        return self

    def lte(self, column: str, value: Any) -> "QueryBuilder[T]":
        """Filter: column less than or equal to value."""
        operator = "gt" if self._negate_next else "lte"
        self._add_filter(column, operator, value)
        self._negate_next = False
        return self

    def like(self, column: str, pattern: str) -> "QueryBuilder[T]":
        """Filter: column matches pattern (case-sensitive)."""
        operator = "nlike" if self._negate_next else "like"
        self._add_filter(column, operator, pattern)
        self._negate_next = False
        return self

    def ilike(self, column: str, pattern: str) -> "QueryBuilder[T]":
        """Filter: column matches pattern (case-insensitive)."""
        operator = "nilike" if self._negate_next else "ilike"
        self._add_filter(column, operator, pattern)
        self._negate_next = False
        return self

    def is_(self, column: str, value: Optional[bool]) -> "QueryBuilder[T]":
        """Filter: column is null or boolean."""
        operator = "isnot" if self._negate_next else "is"
        self._add_filter(column, operator, value)
        self._negate_next = False
        return self

    def in_(self, column: str, values: List[Any]) -> "QueryBuilder[T]":
        """Filter: column in list of values."""
        operator = "nin" if self._negate_next else "in"
        self._add_filter(column, operator, values)
        self._negate_next = False
        return self

    def contains(self, column: str, value: List[Any]) -> "QueryBuilder[T]":
        """Filter: array column contains values."""
        self._add_filter(column, "cs", value)
        self._negate_next = False
        return self

    def contained_by(self, column: str, value: List[Any]) -> "QueryBuilder[T]":
        """Filter: array column is contained by values."""
        self._add_filter(column, "cd", value)
        self._negate_next = False
        return self

    def overlaps(self, column: str, value: List[Any]) -> "QueryBuilder[T]":
        """Filter: array column overlaps with values."""
        self._add_filter(column, "ov", value)
        self._negate_next = False
        return self

    def text_search(
        self, column: str, query: str, config: Optional[str] = None
    ) -> "QueryBuilder[T]":
        """Filter: full-text search."""
        self._add_filter(column, "fts", query, config)
        self._negate_next = False
        return self

    @property
    def not_(self) -> "QueryBuilder[T]":
        """Negate the next filter."""
        self._negate_next = True
        return self

    def or_(self, filters: str) -> "QueryBuilder[T]":
        """Combine filters with OR."""
        self._filters.append({"type": "or", "value": filters})
        return self

    def order(
        self,
        column: str,
        ascending: bool = True,
        nulls_first: Optional[bool] = None,
    ) -> "QueryBuilder[T]":
        """
        Order results.

        Args:
            column: Column to order by
            ascending: Sort ascending (default True)
            nulls_first: Place nulls first

        Returns:
            Self for chaining
        """
        self._order_specs.append(
            {
                "column": column,
                "ascending": ascending,
                "nullsFirst": nulls_first,
            }
        )
        return self

    def limit(self, count: int) -> "QueryBuilder[T]":
        """
        Limit results.

        Args:
            count: Maximum number of rows

        Returns:
            Self for chaining
        """
        self._limit_count = count
        return self

    def offset(self, count: int) -> "QueryBuilder[T]":
        """
        Offset results.

        Args:
            count: Number of rows to skip

        Returns:
            Self for chaining
        """
        self._offset_count = count
        return self

    def range(self, start: int, end: int) -> "QueryBuilder[T]":
        """
        Range of results.

        Args:
            start: Start index (inclusive)
            end: End index (inclusive)

        Returns:
            Self for chaining
        """
        self._offset_count = start
        self._limit_count = end - start + 1
        return self

    def count(
        self, count_type: Literal["exact", "planned", "estimated"] = "exact"
    ) -> "QueryBuilder[T]":
        """
        Include count in result.

        Args:
            count_type: Count type

        Returns:
            Self for chaining
        """
        self._count_option = count_type
        return self

    async def single(self) -> QueryResult[T]:
        """
        Return single result.

        Raises error if no rows or multiple rows.
        """
        self._limit_count = 1
        result = await self.execute()

        if result.error:
            return QueryResult(
                data=None,
                error=result.error,
                status=result.status,
            )

        if not result.data or len(result.data) == 0:
            return QueryResult(
                data=None,
                error=QueryError(message="No rows returned", code="PGRST116"),
                status=406,
            )

        return QueryResult(
            data=result.data[0],
            error=None,
            status=result.status,
        )

    async def maybe_single(self) -> QueryResult[Optional[T]]:
        """Return single result or None."""
        self._limit_count = 1
        result = await self.execute()

        if result.error:
            return QueryResult(
                data=None,
                error=result.error,
                status=result.status,
            )

        return QueryResult(
            data=result.data[0] if result.data else None,
            error=None,
            status=result.status,
        )

    async def execute(self) -> QueryResult[List[T]]:
        """Execute the query."""
        body = self._build_query()

        logger.debug(f"Executing {self._query_type} on {self._table}")

        response = await self._client.request(
            f"/db/{self._table}",
            method=self._get_http_method(),
            body=body,
        )

        if response.error:
            return QueryResult(
                data=[],
                error=QueryError(
                    message=response.error.message,
                    code=response.error.code or "QUERY_ERROR",
                    details=str(response.error.details) if response.error.details else None,
                ),
                status=response.status,
            )

        data = response.data.get("data", []) if response.data else []
        count = response.data.get("count") if response.data else None

        return QueryResult(
            data=data,
            error=None,
            status=response.status,
            count=count,
        )

    # Private helpers
    def _add_filter(
        self, column: str, operator: str, value: Any, extra: Optional[str] = None
    ) -> None:
        """Add a filter to the query."""
        self._filters.append(
            {"type": "filter", "column": column, "operator": operator, "value": value, "extra": extra}
        )

    def _get_http_method(self) -> str:
        """Get HTTP method for query type."""
        method_map = {
            "select": "GET",
            "insert": "POST",
            "update": "PATCH",
            "delete": "DELETE",
        }
        return method_map[self._query_type]

    def _build_query(self) -> Dict[str, Any]:
        """Build query object."""
        query: Dict[str, Any] = {"type": self._query_type}

        if self._query_type == "select":
            query["select"] = self._select_columns

        if self._query_type == "insert" and self._insert_data:
            query["data"] = self._insert_data
            if self._on_conflict_columns:
                query["onConflict"] = {
                    "columns": self._on_conflict_columns,
                    "action": self._on_conflict_action,
                    "update": self._on_conflict_update,
                }

        if self._query_type == "update" and self._update_data:
            query["data"] = self._update_data

        if self._filters:
            query["filters"] = self._filters

        if self._order_specs:
            query["order"] = self._order_specs

        if self._limit_count is not None:
            query["limit"] = self._limit_count

        if self._offset_count is not None:
            query["offset"] = self._offset_count

        if self._count_option:
            query["count"] = self._count_option

        if self._returning:
            query["returning"] = self._returning

        return query
