"""
VAIF SDK Exception Hierarchy

Proper Python exceptions for all SDK error conditions.
"""

from __future__ import annotations

from typing import Any, Dict, Optional


class VaifError(Exception):
    """Base exception for all VAIF SDK errors."""

    def __init__(
        self,
        message: str,
        code: Optional[str] = None,
        status: Optional[int] = None,
        details: Optional[Any] = None,
        request_id: Optional[str] = None,
    ) -> None:
        self.message = message
        self.code = code
        self.status = status
        self.details = details
        self.request_id = request_id
        super().__init__(message)

    def to_dict(self) -> Dict[str, Any]:
        """Serialize to dict for compatibility."""
        return {
            "message": self.message,
            "code": self.code,
            "status": self.status,
            "details": self.details,
            "request_id": self.request_id,
        }


class VaifAuthError(VaifError):
    """Authentication or authorization error (401/403)."""
    pass


class VaifDatabaseError(VaifError):
    """Database query or operation error."""
    pass


class VaifStorageError(VaifError):
    """Storage operation error."""
    pass


class VaifFunctionError(VaifError):
    """Edge function invocation error."""

    def __init__(
        self,
        message: str,
        function_name: Optional[str] = None,
        **kwargs: Any,
    ) -> None:
        self.function_name = function_name
        super().__init__(message, **kwargs)


class VaifAIError(VaifError):
    """AI generation or chat error."""
    pass


class VaifNetworkError(VaifError):
    """Network connectivity error."""
    pass


class VaifTimeoutError(VaifNetworkError):
    """Request timeout error."""
    pass


class VaifRateLimitError(VaifError):
    """Rate limit exceeded (429)."""

    def __init__(
        self,
        message: str = "Rate limit exceeded",
        retry_after: Optional[float] = None,
        **kwargs: Any,
    ) -> None:
        self.retry_after = retry_after
        super().__init__(message, **kwargs)


class VaifValidationError(VaifError):
    """Request validation error (400)."""
    pass


class VaifNotFoundError(VaifError):
    """Resource not found (404)."""
    pass


class VaifConflictError(VaifError):
    """Resource conflict (409)."""
    pass
