"""
VAIF Functions Client

Invoke edge functions deployed on VAIF Studio.
"""

from __future__ import annotations

import json
from typing import Any, Dict, List, Literal, Optional, Union

import httpx

from vaif.types import FunctionError, FunctionInvokeOptions, FunctionResponse


class VaifFunctions:
    """Functions client for VAIF Studio."""

    def __init__(self, client: Any) -> None:
        """Initialize functions client."""
        self._client = client

    async def invoke(
        self,
        function_name: str,
        body: Optional[Any] = None,
        options: Optional[FunctionInvokeOptions] = None,
    ) -> FunctionResponse[Any]:
        """
        Invoke an edge function.

        Args:
            function_name: Function name
            body: Request body
            options: Invocation options

        Returns:
            FunctionResponse with data or error

        Example:
            >>> result = await vaif.functions.invoke(
            ...     "send-email",
            ...     {"to": "user@example.com", "subject": "Hello"}
            ... )
        """
        options = options or FunctionInvokeOptions()
        config = self._client.get_config()

        url = f"{config.api_url}/functions/{function_name}"

        headers = {
            "Content-Type": "application/json",
            "X-Project-ID": config.project_id,
            "apikey": config.api_key,
            **options.headers,
        }

        token = self._client.get_access_token()
        if token:
            headers["Authorization"] = f"Bearer {token}"

        timeout = (options.timeout or config.timeout) / 1000

        try:
            async with httpx.AsyncClient() as http:
                response = await http.request(
                    method=options.method,
                    url=url,
                    json=body,
                    headers=headers,
                    timeout=timeout,
                )

                # Parse response
                content_type = response.headers.get("content-type", "")

                if content_type.startswith("application/json"):
                    data = response.json()
                elif content_type.startswith("text/"):
                    data = response.text
                else:
                    data = response.content

                if response.is_success:
                    return FunctionResponse(data=data, error=None)
                else:
                    message = (
                        data.get("message")
                        if isinstance(data, dict)
                        else f"Function invocation failed: {response.status_code}"
                    )
                    return FunctionResponse(
                        data=None,
                        error=FunctionError(
                            message=message,
                            status=response.status_code,
                            name=function_name,
                        ),
                    )

        except httpx.TimeoutException:
            return FunctionResponse(
                data=None,
                error=FunctionError(
                    message="Function invocation timed out",
                    status=0,
                    name=function_name,
                ),
            )
        except Exception as e:
            return FunctionResponse(
                data=None,
                error=FunctionError(
                    message=str(e),
                    status=0,
                    name=function_name,
                ),
            )

    def create_url(self, function_name: str) -> str:
        """
        Create function URL for direct invocation.

        Args:
            function_name: Function name

        Returns:
            Function URL
        """
        config = self._client.get_config()
        return f"{config.api_url}/functions/{function_name}"

    async def list(
        self,
    ) -> Dict[
        str,
        Union[
            List[Dict[str, Any]],
            FunctionError,
            None,
        ],
    ]:
        """
        Get list of deployed functions.

        Returns:
            Dict with function list or error
        """
        response = await self._client.request("/functions")

        if response.error:
            return {
                "data": None,
                "error": FunctionError(
                    message=response.error.message,
                    status=response.status,
                    name="list",
                ),
            }

        return {"data": response.data, "error": None}

    async def get(
        self, function_name: str
    ) -> Dict[str, Union[Dict[str, Any], FunctionError, None]]:
        """
        Get function details.

        Args:
            function_name: Function name

        Returns:
            Dict with function details or error
        """
        response = await self._client.request(f"/functions/{function_name}")

        if response.error:
            return {
                "data": None,
                "error": FunctionError(
                    message=response.error.message,
                    status=response.status,
                    name=function_name,
                ),
            }

        return {"data": response.data, "error": None}
