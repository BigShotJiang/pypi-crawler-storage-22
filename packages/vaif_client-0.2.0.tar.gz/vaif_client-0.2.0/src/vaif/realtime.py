"""
VAIF Realtime Client

WebSocket-based realtime subscriptions for database changes, broadcasts, and presence.
"""

from __future__ import annotations

import asyncio
import json
import logging
from enum import Enum
from typing import Any, Callable, Dict, List, Literal, Optional, TypeVar

try:
    import websockets
    from websockets.client import WebSocketClientProtocol
except ImportError:
    websockets = None  # type: ignore[assignment]
    WebSocketClientProtocol = Any  # type: ignore[assignment, misc]

from vaif.types import ChannelStatus, RealtimeOptions

logger = logging.getLogger("vaif.realtime")

T = TypeVar("T")
SubscriptionCallback = Callable[[Any], None]


class ConnectionState(str, Enum):
    """Realtime connection state."""

    DISCONNECTED = "disconnected"
    CONNECTING = "connecting"
    CONNECTED = "connected"
    RECONNECTING = "reconnecting"


ConnectionStateCallback = Callable[[ConnectionState], None]


class VaifRealtime:
    """Realtime client for VAIF Studio."""

    def __init__(self, client: Any) -> None:
        """Initialize realtime client."""
        self._client = client
        self._socket: Optional[WebSocketClientProtocol] = None
        self._channels: Dict[str, RealtimeChannel] = {}
        self._reconnect_attempts = 0
        self._max_reconnect_attempts = 10
        self._reconnect_interval = 1.0
        self._heartbeat_task: Optional[asyncio.Task[None]] = None
        self._receive_task: Optional[asyncio.Task[None]] = None
        self._connected = False
        self._options: Optional[RealtimeOptions] = None
        self._state = ConnectionState.DISCONNECTED
        self._state_callbacks: List[ConnectionStateCallback] = []

    @property
    def state(self) -> ConnectionState:
        """Get current connection state."""
        return self._state

    def on_state_change(self, callback: ConnectionStateCallback) -> Callable[[], None]:
        """
        Subscribe to connection state changes.

        Args:
            callback: Called with new ConnectionState when state changes

        Returns:
            Unsubscribe function
        """
        self._state_callbacks.append(callback)

        def unsubscribe() -> None:
            self._state_callbacks.remove(callback)

        return unsubscribe

    def _set_state(self, state: ConnectionState) -> None:
        """Update state and notify callbacks."""
        if self._state != state:
            self._state = state
            logger.debug(f"Connection state: {state.value}")
            for cb in self._state_callbacks:
                try:
                    cb(state)
                except Exception as e:
                    logger.error(f"State callback error: {e}")

    async def connect(self, options: Optional[RealtimeOptions] = None) -> None:
        """
        Connect to realtime server.

        Args:
            options: Connection options
        """
        if websockets is None:
            raise ImportError(
                "websockets package is required for realtime features. "
                "Install with: pip install vaif-client[realtime]"
            )

        if self._connected and self._socket:
            return

        self._options = options or RealtimeOptions()
        config = self._client.get_config()

        is_reconnect = self._reconnect_attempts > 0
        self._set_state(
            ConnectionState.RECONNECTING if is_reconnect else ConnectionState.CONNECTING
        )

        # Build WebSocket URL
        url = f"{config.realtime_url}?apikey={config.api_key}&project={config.project_id}"
        token = self._client.get_access_token()
        if token:
            url += f"&token={token}"

        try:
            self._socket = await websockets.connect(url)
            self._connected = True
            self._reconnect_attempts = 0
            self._set_state(ConnectionState.CONNECTED)

            logger.info("Realtime connected")

            # Start heartbeat
            if self._options.heartbeat:
                self._heartbeat_task = asyncio.create_task(
                    self._heartbeat_loop(self._options.heartbeat_interval / 1000)
                )

            # Start receive loop
            self._receive_task = asyncio.create_task(self._receive_loop())

            # Resubscribe all channels after reconnect
            for channel in self._channels.values():
                await channel._resubscribe()

        except Exception as e:
            logger.warning(f"Realtime connection failed: {e}")
            await self._handle_disconnect()

    async def disconnect(self) -> None:
        """Disconnect from realtime server."""
        self._connected = False

        if self._heartbeat_task:
            self._heartbeat_task.cancel()
            self._heartbeat_task = None

        if self._receive_task:
            self._receive_task.cancel()
            self._receive_task = None

        for channel in list(self._channels.values()):
            await channel.unsubscribe()
        self._channels.clear()

        if self._socket:
            await self._socket.close()
            self._socket = None

        self._set_state(ConnectionState.DISCONNECTED)

    def channel(self, name: str) -> "RealtimeChannel":
        """
        Create or get a channel.

        Args:
            name: Channel name

        Returns:
            RealtimeChannel instance
        """
        if name not in self._channels:
            self._channels[name] = RealtimeChannel(self, name)
        return self._channels[name]

    async def remove_channel(self, name: str) -> None:
        """
        Remove a channel.

        Args:
            name: Channel name
        """
        if name in self._channels:
            await self._channels[name].unsubscribe()
            del self._channels[name]

    async def send(self, message: Any) -> None:
        """
        Send message to server.

        Args:
            message: Message to send
        """
        if self._socket and self._connected:
            data = json.dumps(message)
            logger.debug(f"WS send: {data[:200]}")
            await self._socket.send(data)

    async def _heartbeat_loop(self, interval: float) -> None:
        """Send periodic heartbeats."""
        while self._connected:
            try:
                await self.send({"topic": "phoenix", "event": "heartbeat", "payload": {}})
                await asyncio.sleep(interval)
            except asyncio.CancelledError:
                break
            except Exception as e:
                logger.warning(f"Heartbeat failed: {e}")
                break

    async def _receive_loop(self) -> None:
        """Receive and handle messages."""
        while self._connected and self._socket:
            try:
                message = await self._socket.recv()
                logger.debug(f"WS recv: {str(message)[:200]}")
                data = json.loads(message)
                await self._handle_message(data)
            except asyncio.CancelledError:
                break
            except websockets.exceptions.ConnectionClosed as e:
                logger.warning(f"WebSocket closed: code={e.code} reason={e.reason}")
                await self._handle_disconnect()
                break
            except Exception as e:
                logger.error(f"Receive error: {e}")

    async def _handle_message(self, message: Dict[str, Any]) -> None:
        """Handle incoming message."""
        topic = message.get("topic", "")
        if topic in self._channels:
            await self._channels[topic]._handle_message(message)

    async def _handle_disconnect(self) -> None:
        """Handle disconnection and attempt reconnect."""
        self._connected = False
        logger.info("Realtime disconnected")

        if self._options and self._options.auto_reconnect:
            max_attempts = self._options.max_reconnect_attempts or self._max_reconnect_attempts
            if self._reconnect_attempts < max_attempts:
                self._reconnect_attempts += 1
                base_interval = (self._options.reconnect_interval or 1000) / 1000
                delay = min(base_interval * (2 ** (self._reconnect_attempts - 1)), 30)
                logger.info(
                    f"Reconnecting in {delay:.1f}s "
                    f"(attempt {self._reconnect_attempts}/{max_attempts})"
                )
                await asyncio.sleep(delay)
                await self.connect(self._options)
            else:
                logger.error(f"Max reconnection attempts ({max_attempts}) exhausted")
                self._set_state(ConnectionState.DISCONNECTED)


class RealtimeChannel:
    """Realtime channel for subscriptions."""

    def __init__(self, realtime: VaifRealtime, name: str) -> None:
        """Initialize channel."""
        self._realtime = realtime
        self._name = name
        self._subscriptions: Dict[str, List[SubscriptionCallback]] = {}
        self._status: ChannelStatus = ChannelStatus.CLOSED
        self._presence_state: Dict[str, List[Dict[str, Any]]] = {}

    @property
    def status(self) -> ChannelStatus:
        """Get current channel status."""
        return self._status

    def on(
        self,
        event: Literal["postgres_changes", "broadcast", "presence"],
        filter_: Dict[str, Any],
        callback: SubscriptionCallback,
    ) -> "RealtimeChannel":
        """
        Subscribe to events.

        Args:
            event: Event type
            filter_: Event filter
            callback: Callback function

        Returns:
            Self for chaining
        """
        key = f"{event}:{json.dumps(filter_, sort_keys=True)}"
        if key not in self._subscriptions:
            self._subscriptions[key] = []
        self._subscriptions[key].append(callback)
        return self

    def on_postgres_changes(
        self,
        event: Literal["INSERT", "UPDATE", "DELETE", "*"],
        schema: str = "public",
        table: Optional[str] = None,
        filter_: Optional[str] = None,
        callback: Optional[SubscriptionCallback] = None,
    ) -> "RealtimeChannel":
        """
        Subscribe to postgres changes.

        Args:
            event: Event type
            schema: Schema name
            table: Table name
            filter_: Additional filter
            callback: Callback function

        Returns:
            Self for chaining
        """
        filter_dict = {"event": event, "schema": schema}
        if table:
            filter_dict["table"] = table
        if filter_:
            filter_dict["filter"] = filter_

        if callback:
            return self.on("postgres_changes", filter_dict, callback)
        return self

    def on_broadcast(
        self, event: str, callback: SubscriptionCallback
    ) -> "RealtimeChannel":
        """
        Subscribe to broadcast events.

        Args:
            event: Event name
            callback: Callback function

        Returns:
            Self for chaining
        """
        return self.on("broadcast", {"event": event}, callback)

    def on_presence(
        self,
        event: Literal["sync", "join", "leave"],
        callback: SubscriptionCallback,
    ) -> "RealtimeChannel":
        """
        Subscribe to presence events.

        Args:
            event: Presence event type
            callback: Callback function

        Returns:
            Self for chaining
        """
        return self.on("presence", {"event": event}, callback)

    async def subscribe(
        self, callback: Optional[Callable[[ChannelStatus, Optional[Exception]], None]] = None
    ) -> "RealtimeChannel":
        """
        Subscribe to channel.

        Args:
            callback: Status callback

        Returns:
            Self for chaining
        """
        try:
            await self._realtime.send(
                {
                    "topic": self._name,
                    "event": "phx_join",
                    "payload": {"subscriptions": list(self._subscriptions.keys())},
                    "ref": f"{self._name}-join",
                }
            )

            self._status = ChannelStatus.SUBSCRIBED
            if callback:
                callback(self._status, None)
        except Exception as e:
            self._status = ChannelStatus.ERRORED
            logger.error(f"Channel subscribe error: {e}")
            if callback:
                callback(self._status, e)

        return self

    async def unsubscribe(self) -> None:
        """Unsubscribe from channel."""
        try:
            await self._realtime.send(
                {
                    "topic": self._name,
                    "event": "phx_leave",
                    "payload": {},
                    "ref": f"{self._name}-leave",
                }
            )
        except Exception as e:
            logger.warning(f"Unsubscribe error (may be disconnected): {e}")
        self._status = ChannelStatus.CLOSED
        self._subscriptions.clear()

    async def broadcast(self, event: str, payload: Any) -> None:
        """
        Broadcast message to channel.

        Args:
            event: Event name
            payload: Event payload
        """
        await self._realtime.send(
            {
                "topic": self._name,
                "event": "broadcast",
                "payload": {"event": event, "payload": payload},
            }
        )

    async def track(self, payload: Dict[str, Any]) -> None:
        """
        Track presence.

        Args:
            payload: Presence data
        """
        await self._realtime.send(
            {
                "topic": self._name,
                "event": "presence",
                "payload": {"type": "track", "payload": payload},
            }
        )

    async def untrack(self) -> None:
        """Untrack presence."""
        await self._realtime.send(
            {
                "topic": self._name,
                "event": "presence",
                "payload": {"type": "untrack"},
            }
        )

    def presence_state(self) -> Dict[str, List[Dict[str, Any]]]:
        """Get current presence state."""
        return self._presence_state

    async def _handle_message(self, message: Dict[str, Any]) -> None:
        """Handle incoming message."""
        event = message.get("event", "")
        payload = message.get("payload")

        for key, callbacks in self._subscriptions.items():
            sub_event = key.split(":")[0]
            if event == sub_event or event == "broadcast":
                for callback in callbacks:
                    try:
                        callback(payload)
                    except Exception as e:
                        logger.error(f"Callback error: {e}")

    async def _resubscribe(self) -> None:
        """Resubscribe after reconnect, preserving existing subscriptions."""
        if self._subscriptions:
            logger.debug(f"Resubscribing channel: {self._name}")
            await self.subscribe()
