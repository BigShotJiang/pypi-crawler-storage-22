"""
VAIF SDK Retry Logic

Configurable retry with exponential backoff for transient errors.
"""

from __future__ import annotations

import asyncio
import logging
import random
from dataclasses import dataclass, field
from typing import Set

logger = logging.getLogger("vaif.retry")

# HTTP status codes that are safe to retry
RETRYABLE_STATUS_CODES: Set[int] = {408, 429, 500, 502, 503, 504}


@dataclass
class RetryConfig:
    """Retry configuration."""

    max_retries: int = 3
    base_delay: float = 0.5
    max_delay: float = 30.0
    jitter: bool = True
    retryable_status_codes: Set[int] = field(default_factory=lambda: set(RETRYABLE_STATUS_CODES))

    def get_delay(self, attempt: int) -> float:
        """Calculate delay for a given attempt using exponential backoff."""
        delay = min(self.base_delay * (2 ** attempt), self.max_delay)
        if self.jitter:
            delay = delay * (0.5 + random.random() * 0.5)
        return delay

    def should_retry(self, status_code: int, attempt: int) -> bool:
        """Determine whether to retry based on status code and attempt count."""
        if attempt >= self.max_retries:
            return False
        return status_code in self.retryable_status_codes


async def async_sleep_with_backoff(config: RetryConfig, attempt: int) -> None:
    """Sleep with exponential backoff."""
    delay = config.get_delay(attempt)
    logger.debug(f"Retry attempt {attempt + 1}/{config.max_retries}, sleeping {delay:.2f}s")
    await asyncio.sleep(delay)
