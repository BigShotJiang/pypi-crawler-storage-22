"""
VAIF Storage Client

File storage operations with CDN and image transformations.
"""

from __future__ import annotations

import logging
import mimetypes
from typing import Any, BinaryIO, Callable, Dict, List, Optional, Union

import httpx

from vaif.types import (
    Bucket,
    DownloadOptions,
    FileObject,
    ListFilesOptions,
    SignedUrlOptions,
    StorageError,
    UploadOptions,
    UploadResult,
)

logger = logging.getLogger("vaif.storage")

ProgressCallback = Callable[[int, int], None]

# Default chunk size for large file uploads (5MB)
DEFAULT_CHUNK_SIZE = 5 * 1024 * 1024


def _guess_content_type(path: str) -> str:
    """Guess content type from file path."""
    content_type, _ = mimetypes.guess_type(path)
    return content_type or "application/octet-stream"


class VaifStorage:
    """Storage client for VAIF Studio."""

    def __init__(self, client: Any) -> None:
        """Initialize storage client."""
        self._client = client

    def from_(self, bucket: str) -> "StorageBucket":
        """
        Get a storage bucket.

        Args:
            bucket: Bucket name

        Returns:
            StorageBucket for operations
        """
        return StorageBucket(self._client, bucket)

    async def list_buckets(
        self,
    ) -> Dict[str, Union[List[Bucket], StorageError, None]]:
        """
        List all buckets.

        Returns:
            Dict with data or error
        """
        response = await self._client.request("/storage/buckets")

        if response.error:
            return {
                "data": None,
                "error": StorageError(
                    message=response.error.message,
                    status_code=str(response.status),
                    error=response.error.code or "STORAGE_ERROR",
                ),
            }

        buckets = [Bucket(**b) for b in (response.data or [])]
        return {"data": buckets, "error": None}

    async def create_bucket(
        self,
        name: str,
        public: bool = False,
        file_size_limit: Optional[int] = None,
        allowed_mime_types: Optional[List[str]] = None,
    ) -> Dict[str, Union[Bucket, StorageError, None]]:
        """
        Create a bucket.

        Args:
            name: Bucket name
            public: Make bucket public
            file_size_limit: Max file size in bytes
            allowed_mime_types: Allowed MIME types

        Returns:
            Dict with data or error
        """
        body: Dict[str, Any] = {"name": name, "public": public}
        if file_size_limit:
            body["fileSizeLimit"] = file_size_limit
        if allowed_mime_types:
            body["allowedMimeTypes"] = allowed_mime_types

        response = await self._client.request(
            "/storage/buckets",
            method="POST",
            body=body,
        )

        if response.error:
            return {
                "data": None,
                "error": StorageError(
                    message=response.error.message,
                    status_code=str(response.status),
                    error=response.error.code or "STORAGE_ERROR",
                ),
            }

        return {"data": Bucket(**response.data) if response.data else None, "error": None}

    async def delete_bucket(self, name: str) -> Dict[str, Optional[StorageError]]:
        """
        Delete a bucket.

        Args:
            name: Bucket name

        Returns:
            Dict with error if failed
        """
        response = await self._client.request(
            f"/storage/buckets/{name}",
            method="DELETE",
        )

        if response.error:
            return {
                "error": StorageError(
                    message=response.error.message,
                    status_code=str(response.status),
                    error=response.error.code or "STORAGE_ERROR",
                )
            }

        return {"error": None}


class StorageBucket:
    """Storage bucket operations."""

    def __init__(self, client: Any, bucket: str) -> None:
        """Initialize bucket."""
        self._client = client
        self._bucket = bucket

    async def upload(
        self,
        path: str,
        file: Union[bytes, BinaryIO, str],
        options: Optional[UploadOptions] = None,
        on_progress: Optional[ProgressCallback] = None,
    ) -> Dict[str, Union[UploadResult, StorageError, None]]:
        """
        Upload a file.

        Args:
            path: File path in bucket
            file: File data (bytes, file object, or local file path)
            options: Upload options
            on_progress: Callback for upload progress (bytes_sent, total_bytes)

        Returns:
            Dict with data or error

        Example:
            >>> result = await bucket.upload(
            ...     "photos/vacation.jpg",
            ...     open("vacation.jpg", "rb"),
            ...     on_progress=lambda sent, total: print(f"{sent}/{total}")
            ... )
        """
        options = options or UploadOptions()
        config = self._client.get_config()

        # Prepare file data
        if isinstance(file, str):
            with open(file, "rb") as f:
                file_data = f.read()
            # Auto-detect content type from file path
            if not options.content_type:
                options.content_type = _guess_content_type(file)
        elif isinstance(file, bytes):
            file_data = file
        else:
            file_data = file.read()

        # Auto-detect content type from upload path if not set
        if not options.content_type:
            options.content_type = _guess_content_type(path)

        total_size = len(file_data)

        # Get filename from path
        filename = path.split("/")[-1]

        # Build multipart form data
        files = {"file": (filename, file_data, options.content_type)}
        data: Dict[str, str] = {}

        if options.content_type:
            data["contentType"] = options.content_type
        if options.cache_control:
            data["cacheControl"] = options.cache_control
        if options.upsert:
            data["upsert"] = "true"
        if options.metadata:
            import json
            data["metadata"] = json.dumps(options.metadata)

        # Build headers
        headers = {
            "X-Project-ID": config.project_id,
            "apikey": config.api_key,
        }

        token = self._client.get_access_token()
        if token:
            headers["Authorization"] = f"Bearer {token}"

        logger.debug(f"Uploading {path} ({total_size} bytes) to bucket {self._bucket}")

        try:
            async with httpx.AsyncClient() as http:
                response = await http.post(
                    f"{config.api_url}/storage/{self._bucket}/{path}",
                    files=files,
                    data=data,
                    headers=headers,
                    timeout=httpx.Timeout(max(config.timeout / 1000, 300)),
                )

                # Report final progress
                if on_progress:
                    on_progress(total_size, total_size)

                if response.is_success:
                    return {
                        "data": UploadResult(**response.json()),
                        "error": None,
                    }
                else:
                    error_data = (
                        response.json()
                        if response.headers.get("content-type", "").startswith("application/json")
                        else {}
                    )
                    return {
                        "data": None,
                        "error": StorageError(
                            message=error_data.get("message", f"Upload failed: {response.status_code}"),
                            status_code=str(response.status_code),
                            error=error_data.get("code", "UPLOAD_ERROR"),
                        ),
                    }
        except httpx.TimeoutException:
            return {
                "data": None,
                "error": StorageError(
                    message="Upload timed out",
                    status_code="0",
                    error="TIMEOUT",
                ),
            }
        except Exception as e:
            return {
                "data": None,
                "error": StorageError(
                    message=str(e),
                    status_code="0",
                    error="NETWORK_ERROR",
                ),
            }

    async def upload_chunked(
        self,
        path: str,
        file: Union[BinaryIO, str],
        chunk_size: int = DEFAULT_CHUNK_SIZE,
        options: Optional[UploadOptions] = None,
        on_progress: Optional[ProgressCallback] = None,
    ) -> Dict[str, Union[UploadResult, StorageError, None]]:
        """
        Upload a large file in chunks.

        Args:
            path: File path in bucket
            file: File object or local file path
            chunk_size: Size of each chunk in bytes (default 5MB)
            options: Upload options
            on_progress: Callback for upload progress (bytes_sent, total_bytes)

        Returns:
            Dict with data or error
        """
        options = options or UploadOptions()
        config = self._client.get_config()

        # Read file to get total size
        if isinstance(file, str):
            with open(file, "rb") as f:
                file_data = f.read()
            if not options.content_type:
                options.content_type = _guess_content_type(file)
        else:
            file_data = file.read()

        if not options.content_type:
            options.content_type = _guess_content_type(path)

        total_size = len(file_data)

        # For small files, use regular upload
        if total_size <= chunk_size:
            return await self.upload(path, file_data, options, on_progress)

        headers = {
            "X-Project-ID": config.project_id,
            "apikey": config.api_key,
        }
        token = self._client.get_access_token()
        if token:
            headers["Authorization"] = f"Bearer {token}"

        logger.debug(
            f"Chunked upload: {path} ({total_size} bytes, "
            f"{(total_size + chunk_size - 1) // chunk_size} chunks)"
        )

        # Initiate chunked upload
        try:
            async with httpx.AsyncClient() as http:
                init_response = await http.post(
                    f"{config.api_url}/storage/{self._bucket}/{path}/chunked",
                    json={
                        "totalSize": total_size,
                        "chunkSize": chunk_size,
                        "contentType": options.content_type,
                        "metadata": options.metadata,
                    },
                    headers={**headers, "Content-Type": "application/json"},
                )

                if not init_response.is_success:
                    # Fallback to regular upload if chunked not supported
                    logger.debug("Chunked upload not supported, falling back to regular upload")
                    return await self.upload(path, file_data, options, on_progress)

                upload_id = init_response.json().get("uploadId")

                # Upload chunks
                bytes_sent = 0
                chunk_index = 0

                while bytes_sent < total_size:
                    chunk_end = min(bytes_sent + chunk_size, total_size)
                    chunk = file_data[bytes_sent:chunk_end]

                    chunk_response = await http.put(
                        f"{config.api_url}/storage/{self._bucket}/{path}/chunked/{upload_id}",
                        content=chunk,
                        headers={
                            **headers,
                            "Content-Type": "application/octet-stream",
                            "X-Chunk-Index": str(chunk_index),
                            "X-Total-Chunks": str((total_size + chunk_size - 1) // chunk_size),
                        },
                    )

                    if not chunk_response.is_success:
                        return {
                            "data": None,
                            "error": StorageError(
                                message=f"Chunk upload failed at chunk {chunk_index}",
                                status_code=str(chunk_response.status_code),
                                error="CHUNK_UPLOAD_ERROR",
                            ),
                        }

                    bytes_sent = chunk_end
                    chunk_index += 1

                    if on_progress:
                        on_progress(bytes_sent, total_size)

                # Complete chunked upload
                complete_response = await http.post(
                    f"{config.api_url}/storage/{self._bucket}/{path}/chunked/{upload_id}/complete",
                    headers={**headers, "Content-Type": "application/json"},
                )

                if complete_response.is_success:
                    return {
                        "data": UploadResult(**complete_response.json()),
                        "error": None,
                    }
                else:
                    return {
                        "data": None,
                        "error": StorageError(
                            message="Chunked upload completion failed",
                            status_code=str(complete_response.status_code),
                            error="COMPLETE_UPLOAD_ERROR",
                        ),
                    }

        except Exception as e:
            return {
                "data": None,
                "error": StorageError(
                    message=str(e),
                    status_code="0",
                    error="NETWORK_ERROR",
                ),
            }

    async def download(
        self,
        path: str,
        options: Optional[DownloadOptions] = None,
    ) -> Dict[str, Union[bytes, StorageError, None]]:
        """
        Download a file.

        Args:
            path: File path in bucket
            options: Download options

        Returns:
            Dict with data (bytes) or error
        """
        options = options or DownloadOptions()
        config = self._client.get_config()

        # Build URL with transform params
        url = f"{config.api_url}/storage/{self._bucket}/{path}"
        params: Dict[str, str] = {}

        if options.transform:
            if options.transform.width:
                params["width"] = str(options.transform.width)
            if options.transform.height:
                params["height"] = str(options.transform.height)
            if options.transform.resize:
                params["resize"] = options.transform.resize
            if options.transform.format:
                params["format"] = options.transform.format
            if options.transform.quality:
                params["quality"] = str(options.transform.quality)

        headers = {
            "apikey": config.api_key,
        }

        token = self._client.get_access_token()
        if token:
            headers["Authorization"] = f"Bearer {token}"

        logger.debug(f"Downloading {path} from bucket {self._bucket}")

        try:
            async with httpx.AsyncClient() as http:
                response = await http.get(url, params=params, headers=headers)

                if response.is_success:
                    return {"data": response.content, "error": None}
                else:
                    return {
                        "data": None,
                        "error": StorageError(
                            message=f"Download failed: {response.status_code}",
                            status_code=str(response.status_code),
                            error="DOWNLOAD_ERROR",
                        ),
                    }
        except httpx.TimeoutException:
            return {
                "data": None,
                "error": StorageError(
                    message="Download timed out",
                    status_code="0",
                    error="TIMEOUT",
                ),
            }
        except Exception as e:
            return {
                "data": None,
                "error": StorageError(
                    message=str(e),
                    status_code="0",
                    error="NETWORK_ERROR",
                ),
            }

    def get_public_url(self, path: str) -> Dict[str, Dict[str, str]]:
        """
        Get public URL for a file.

        Args:
            path: File path in bucket

        Returns:
            Dict with publicUrl
        """
        config = self._client.get_config()
        return {
            "data": {
                "publicUrl": f"{config.api_url}/storage/{self._bucket}/{path}"
            }
        }

    async def create_signed_url(
        self,
        path: str,
        options: SignedUrlOptions,
    ) -> Dict[str, Union[Dict[str, str], StorageError, None]]:
        """
        Create signed URL.

        Args:
            path: File path in bucket
            options: Signed URL options

        Returns:
            Dict with signedUrl or error
        """
        body: Dict[str, Any] = {"expiresIn": options.expires_in}

        if options.transform:
            body["transform"] = options.transform.model_dump(exclude_none=True)
        if options.download is not None:
            body["download"] = options.download

        response = await self._client.request(
            f"/storage/{self._bucket}/{path}/sign",
            method="POST",
            body=body,
        )

        if response.error:
            return {
                "data": None,
                "error": StorageError(
                    message=response.error.message,
                    status_code=str(response.status),
                    error=response.error.code or "SIGN_ERROR",
                ),
            }

        return {"data": response.data, "error": None}

    async def list(
        self,
        path: str = "",
        options: Optional[ListFilesOptions] = None,
    ) -> Dict[str, Union[List[FileObject], StorageError, None]]:
        """
        List files in a path.

        Args:
            path: Path prefix
            options: List options

        Returns:
            Dict with file list or error
        """
        options = options or ListFilesOptions()

        body: Dict[str, Any] = {"prefix": path}
        if options.limit:
            body["limit"] = options.limit
        if options.offset:
            body["offset"] = options.offset
        if options.search:
            body["search"] = options.search
        if options.sort_by:
            body["sortBy"] = options.sort_by

        response = await self._client.request(
            f"/storage/{self._bucket}/list",
            method="POST",
            body=body,
        )

        if response.error:
            return {
                "data": None,
                "error": StorageError(
                    message=response.error.message,
                    status_code=str(response.status),
                    error=response.error.code or "LIST_ERROR",
                ),
            }

        files = [FileObject(**f) for f in (response.data or [])]
        return {"data": files, "error": None}

    async def move(
        self, from_path: str, to_path: str
    ) -> Dict[str, Optional[StorageError]]:
        """
        Move/rename a file.

        Args:
            from_path: Source path
            to_path: Destination path

        Returns:
            Dict with error if failed
        """
        response = await self._client.request(
            f"/storage/{self._bucket}/move",
            method="POST",
            body={"from": from_path, "to": to_path},
        )

        if response.error:
            return {
                "error": StorageError(
                    message=response.error.message,
                    status_code=str(response.status),
                    error=response.error.code or "MOVE_ERROR",
                )
            }

        return {"error": None}

    async def copy(
        self, from_path: str, to_path: str
    ) -> Dict[str, Optional[StorageError]]:
        """
        Copy a file.

        Args:
            from_path: Source path
            to_path: Destination path

        Returns:
            Dict with error if failed
        """
        response = await self._client.request(
            f"/storage/{self._bucket}/copy",
            method="POST",
            body={"from": from_path, "to": to_path},
        )

        if response.error:
            return {
                "error": StorageError(
                    message=response.error.message,
                    status_code=str(response.status),
                    error=response.error.code or "COPY_ERROR",
                )
            }

        return {"error": None}

    async def remove(
        self, paths: Union[str, List[str]]
    ) -> Dict[str, Optional[StorageError]]:
        """
        Delete file(s).

        Args:
            paths: Path or list of paths to delete

        Returns:
            Dict with error if failed
        """
        path_list = [paths] if isinstance(paths, str) else paths

        response = await self._client.request(
            f"/storage/{self._bucket}/delete",
            method="DELETE",
            body={"paths": path_list},
        )

        if response.error:
            return {
                "error": StorageError(
                    message=response.error.message,
                    status_code=str(response.status),
                    error=response.error.code or "DELETE_ERROR",
                )
            }

        return {"error": None}
