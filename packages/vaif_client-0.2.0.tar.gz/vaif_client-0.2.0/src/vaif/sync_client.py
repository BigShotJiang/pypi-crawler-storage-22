"""
VAIF Studio Synchronous Client

Sync wrapper for the async VaifClient, enabling use in Django, scripts, and
other non-async Python environments.
"""

from __future__ import annotations

import asyncio
import threading
from typing import Any, Callable, Dict, List, Literal, Optional, TypeVar, Union

from vaif.client import VaifClient, create_client as _create_async_client
from vaif.retry import RetryConfig
from vaif.types import (
    ApiResponse,
    AuthResponse,
    FunctionResponse,
    QueryResult,
    VaifConfig,
)

T = TypeVar("T")


def _run_sync(coro: Any) -> Any:
    """Run an async coroutine synchronously.

    Uses a dedicated event loop in a background thread to avoid
    conflicts with any existing event loop (e.g. Jupyter, Django channels).
    """
    try:
        loop = asyncio.get_running_loop()
    except RuntimeError:
        loop = None

    if loop is not None and loop.is_running():
        # We're inside an existing event loop - run in a new thread
        result: Any = None
        exception: Optional[BaseException] = None

        def _run() -> None:
            nonlocal result, exception
            try:
                new_loop = asyncio.new_event_loop()
                try:
                    result = new_loop.run_until_complete(coro)
                finally:
                    new_loop.close()
            except BaseException as e:
                exception = e

        thread = threading.Thread(target=_run)
        thread.start()
        thread.join()

        if exception is not None:
            raise exception
        return result
    else:
        # No event loop running - we can use asyncio.run directly
        return asyncio.run(coro)


class SyncQueryBuilder:
    """Synchronous wrapper around QueryBuilder."""

    def __init__(self, async_builder: Any) -> None:
        self._builder = async_builder

    def select(self, columns: Union[str, List[str]] = "*") -> "SyncQueryBuilder":
        self._builder = self._builder.select(columns)
        return self

    def insert(self, data: Union[Dict[str, Any], List[Dict[str, Any]]]) -> "SyncQueryBuilder":
        self._builder = self._builder.insert(data)
        return self

    def update(self, data: Dict[str, Any]) -> "SyncQueryBuilder":
        self._builder = self._builder.update(data)
        return self

    def delete(self) -> "SyncQueryBuilder":
        self._builder = self._builder.delete()
        return self

    def upsert(
        self,
        data: Union[Dict[str, Any], List[Dict[str, Any]]],
        on_conflict: Union[str, List[str]],
        update_columns: Optional[Dict[str, Any]] = None,
    ) -> "SyncQueryBuilder":
        self._builder = self._builder.upsert(data, on_conflict, update_columns)
        return self

    def on_conflict(self, columns: Union[str, List[str]]) -> "SyncQueryBuilder":
        self._builder.on_conflict(columns)
        return self

    def do_nothing(self) -> "SyncQueryBuilder":
        self._builder.do_nothing()
        return self

    def do_update(self, data: Dict[str, Any]) -> "SyncQueryBuilder":
        self._builder.do_update(data)
        return self

    def eq(self, column: str, value: Any) -> "SyncQueryBuilder":
        self._builder.eq(column, value)
        return self

    def neq(self, column: str, value: Any) -> "SyncQueryBuilder":
        self._builder.neq(column, value)
        return self

    def gt(self, column: str, value: Any) -> "SyncQueryBuilder":
        self._builder.gt(column, value)
        return self

    def gte(self, column: str, value: Any) -> "SyncQueryBuilder":
        self._builder.gte(column, value)
        return self

    def lt(self, column: str, value: Any) -> "SyncQueryBuilder":
        self._builder.lt(column, value)
        return self

    def lte(self, column: str, value: Any) -> "SyncQueryBuilder":
        self._builder.lte(column, value)
        return self

    def like(self, column: str, pattern: str) -> "SyncQueryBuilder":
        self._builder.like(column, pattern)
        return self

    def ilike(self, column: str, pattern: str) -> "SyncQueryBuilder":
        self._builder.ilike(column, pattern)
        return self

    def is_(self, column: str, value: Optional[bool]) -> "SyncQueryBuilder":
        self._builder.is_(column, value)
        return self

    def in_(self, column: str, values: List[Any]) -> "SyncQueryBuilder":
        self._builder.in_(column, values)
        return self

    def contains(self, column: str, value: List[Any]) -> "SyncQueryBuilder":
        self._builder.contains(column, value)
        return self

    def contained_by(self, column: str, value: List[Any]) -> "SyncQueryBuilder":
        self._builder.contained_by(column, value)
        return self

    def overlaps(self, column: str, value: List[Any]) -> "SyncQueryBuilder":
        self._builder.overlaps(column, value)
        return self

    def text_search(
        self, column: str, query: str, config: Optional[str] = None
    ) -> "SyncQueryBuilder":
        self._builder.text_search(column, query, config)
        return self

    @property
    def not_(self) -> "SyncQueryBuilder":
        self._builder.not_
        return self

    def or_(self, filters: str) -> "SyncQueryBuilder":
        self._builder.or_(filters)
        return self

    def order(
        self,
        column: str,
        ascending: bool = True,
        nulls_first: Optional[bool] = None,
    ) -> "SyncQueryBuilder":
        self._builder.order(column, ascending, nulls_first)
        return self

    def limit(self, count: int) -> "SyncQueryBuilder":
        self._builder.limit(count)
        return self

    def offset(self, count: int) -> "SyncQueryBuilder":
        self._builder.offset(count)
        return self

    def range(self, start: int, end: int) -> "SyncQueryBuilder":
        self._builder.range(start, end)
        return self

    def returning(self, columns: Union[str, List[str]] = "*") -> "SyncQueryBuilder":
        self._builder.returning(columns)
        return self

    def count(
        self, count_type: Literal["exact", "planned", "estimated"] = "exact"
    ) -> "SyncQueryBuilder":
        self._builder.count(count_type)
        return self

    def execute(self) -> QueryResult[Any]:
        return _run_sync(self._builder.execute())

    def single(self) -> QueryResult[Any]:
        return _run_sync(self._builder.single())

    def maybe_single(self) -> QueryResult[Any]:
        return _run_sync(self._builder.maybe_single())


class SyncDatabase:
    """Synchronous wrapper around VaifDatabase."""

    def __init__(self, async_db: Any) -> None:
        self._db = async_db

    def from_(self, table: str) -> SyncQueryBuilder:
        return SyncQueryBuilder(self._db.from_(table))

    def raw(self, sql: str, params: Optional[List[Any]] = None) -> QueryResult[Any]:
        return _run_sync(self._db.raw(sql, params))

    def rpc(
        self, function_name: str, params: Optional[Dict[str, Any]] = None
    ) -> QueryResult[Any]:
        return _run_sync(self._db.rpc(function_name, params))


class SyncAuth:
    """Synchronous wrapper around VaifAuth."""

    def __init__(self, async_auth: Any) -> None:
        self._auth = async_auth

    def get_session(self) -> Any:
        return _run_sync(self._auth.get_session())

    def get_user(self) -> Any:
        return _run_sync(self._auth.get_user())

    def sign_up(self, **kwargs: Any) -> AuthResponse:
        return _run_sync(self._auth.sign_up(**kwargs))

    def sign_in_with_password(self, **kwargs: Any) -> AuthResponse:
        return _run_sync(self._auth.sign_in_with_password(**kwargs))

    def sign_in_with_oauth(self, **kwargs: Any) -> Any:
        return _run_sync(self._auth.sign_in_with_oauth(**kwargs))

    def sign_in_with_otp(self, **kwargs: Any) -> Any:
        return _run_sync(self._auth.sign_in_with_otp(**kwargs))

    def verify_otp(self, **kwargs: Any) -> AuthResponse:
        return _run_sync(self._auth.verify_otp(**kwargs))

    def sign_out(self, scope: str = "local") -> Any:
        return _run_sync(self._auth.sign_out(scope))

    def reset_password_for_email(self, **kwargs: Any) -> Any:
        return _run_sync(self._auth.reset_password_for_email(**kwargs))

    def update_user(self, **kwargs: Any) -> Any:
        return _run_sync(self._auth.update_user(**kwargs))

    def refresh_session(self) -> AuthResponse:
        return _run_sync(self._auth.refresh_session())

    def exchange_code_for_session(self, code: str) -> AuthResponse:
        return _run_sync(self._auth.exchange_code_for_session(code))

    def on_auth_state_change(self, callback: Any) -> Any:
        return self._auth.on_auth_state_change(callback)


class SyncStorage:
    """Synchronous wrapper around VaifStorage."""

    def __init__(self, async_storage: Any) -> None:
        self._storage = async_storage

    def from_(self, bucket: str) -> "SyncStorageBucket":
        return SyncStorageBucket(self._storage.from_(bucket))

    def list_buckets(self) -> Any:
        return _run_sync(self._storage.list_buckets())

    def create_bucket(self, **kwargs: Any) -> Any:
        return _run_sync(self._storage.create_bucket(**kwargs))

    def delete_bucket(self, name: str) -> Any:
        return _run_sync(self._storage.delete_bucket(name))


class SyncStorageBucket:
    """Synchronous wrapper around StorageBucket."""

    def __init__(self, async_bucket: Any) -> None:
        self._bucket = async_bucket

    def upload(self, path: str, file: Any, options: Any = None) -> Any:
        return _run_sync(self._bucket.upload(path, file, options))

    def download(self, path: str, options: Any = None) -> Any:
        return _run_sync(self._bucket.download(path, options))

    def get_public_url(self, path: str) -> Any:
        return self._bucket.get_public_url(path)

    def create_signed_url(self, path: str, options: Any) -> Any:
        return _run_sync(self._bucket.create_signed_url(path, options))

    def list(self, path: str = "", options: Any = None) -> Any:
        return _run_sync(self._bucket.list(path, options))

    def move(self, from_path: str, to_path: str) -> Any:
        return _run_sync(self._bucket.move(from_path, to_path))

    def copy(self, from_path: str, to_path: str) -> Any:
        return _run_sync(self._bucket.copy(from_path, to_path))

    def remove(self, paths: Any) -> Any:
        return _run_sync(self._bucket.remove(paths))


class SyncFunctions:
    """Synchronous wrapper around VaifFunctions."""

    def __init__(self, async_functions: Any) -> None:
        self._functions = async_functions

    def invoke(self, function_name: str, body: Any = None, options: Any = None) -> FunctionResponse[Any]:
        return _run_sync(self._functions.invoke(function_name, body, options))

    def create_url(self, function_name: str) -> str:
        return self._functions.create_url(function_name)

    def list(self) -> Any:
        return _run_sync(self._functions.list())

    def get(self, function_name: str) -> Any:
        return _run_sync(self._functions.get(function_name))


class SyncAI:
    """Synchronous wrapper around VaifAI."""

    def __init__(self, async_ai: Any) -> None:
        self._ai = async_ai

    def generate_schema(self, request: Any, options: Any = None) -> Any:
        return _run_sync(self._ai.generate_schema(request, options))

    def generate_function(self, request: Any, options: Any = None) -> Any:
        return _run_sync(self._ai.generate_function(request, options))

    def generate_endpoint(self, request: Any, options: Any = None) -> Any:
        return _run_sync(self._ai.generate_endpoint(request, options))

    def chat(self, request: Any, options: Any = None) -> Any:
        return _run_sync(self._ai.chat(request, options))

    def get_credits(self) -> Any:
        return _run_sync(self._ai.get_credits())

    def explain(self, code: str, **kwargs: Any) -> Any:
        return _run_sync(self._ai.explain(code, **kwargs))

    def review(self, code: str, **kwargs: Any) -> Any:
        return _run_sync(self._ai.review(code, **kwargs))

    def generate_types(self, schema: str, **kwargs: Any) -> Any:
        return _run_sync(self._ai.generate_types(schema, **kwargs))

    def generate_migration(self, current_schema: str, target_schema: str, **kwargs: Any) -> Any:
        return _run_sync(self._ai.generate_migration(current_schema, target_schema, **kwargs))


class SyncVaifClient:
    """
    Synchronous VAIF Studio Client.

    Wraps the async VaifClient for use in Django, Flask, scripts,
    and other non-async Python environments.

    Example:
        >>> from vaif import create_sync_client
        >>>
        >>> vaif = create_sync_client(
        ...     project_id="your-project-id",
        ...     api_key="your-api-key"
        ... )
        >>>
        >>> # Database operations (no await needed)
        >>> users = vaif.db.from_("users").select("*").eq("active", True).execute()
        >>>
        >>> # Storage
        >>> result = vaif.storage.from_("avatars").upload("user.png", file_data)
    """

    def __init__(self, async_client: VaifClient) -> None:
        """Initialize sync client wrapping an async client."""
        self._async_client = async_client
        self._db: Optional[SyncDatabase] = None
        self._auth: Optional[SyncAuth] = None
        self._storage: Optional[SyncStorage] = None
        self._functions: Optional[SyncFunctions] = None
        self._ai: Optional[SyncAI] = None

    @property
    def db(self) -> SyncDatabase:
        """Database client for CRUD operations."""
        if self._db is None:
            self._db = SyncDatabase(self._async_client.db)
        return self._db

    @property
    def auth(self) -> SyncAuth:
        """Auth client for authentication."""
        if self._auth is None:
            self._auth = SyncAuth(self._async_client.auth)
        return self._auth

    @property
    def storage(self) -> SyncStorage:
        """Storage client for file operations."""
        if self._storage is None:
            self._storage = SyncStorage(self._async_client.storage)
        return self._storage

    @property
    def functions(self) -> SyncFunctions:
        """Functions client for edge function invocation."""
        if self._functions is None:
            self._functions = SyncFunctions(self._async_client.functions)
        return self._functions

    @property
    def ai(self) -> SyncAI:
        """AI client for generation features."""
        if self._ai is None:
            self._ai = SyncAI(self._async_client.ai)
        return self._ai

    def request(self, path: str, **kwargs: Any) -> ApiResponse[Any]:
        """Make an authenticated API request synchronously."""
        return _run_sync(self._async_client.request(path, **kwargs))

    def get_config(self) -> VaifConfig:
        """Get current configuration."""
        return self._async_client.get_config()

    def set_access_token(self, token: Optional[str]) -> None:
        """Set access token for authenticated requests."""
        self._async_client.set_access_token(token)

    def get_access_token(self) -> Optional[str]:
        """Get current access token."""
        return self._async_client.get_access_token()

    def close(self) -> None:
        """Close the client and release resources."""
        _run_sync(self._async_client.close())

    def __enter__(self) -> "SyncVaifClient":
        """Context manager entry."""
        return self

    def __exit__(self, *args: Any) -> None:
        """Context manager exit."""
        self.close()


def create_sync_client(
    project_id: str,
    api_key: str,
    api_url: str = "https://api.vaif.studio",
    realtime_url: str = "wss://realtime.vaif.studio",
    timeout: int = 30000,
    headers: Optional[Dict[str, str]] = None,
    debug: bool = False,
    auto_refresh_token: bool = True,
    persist_session: bool = True,
    retry: Optional[RetryConfig] = None,
) -> SyncVaifClient:
    """
    Create a synchronous VAIF Studio client.

    This is the recommended entry point for Django, Flask, scripts,
    and other non-async Python environments.

    Args:
        project_id: Your VAIF project ID
        api_key: Your VAIF API key
        api_url: API base URL (optional)
        realtime_url: WebSocket URL (optional)
        timeout: Request timeout in milliseconds
        headers: Custom headers to include in requests
        debug: Enable debug logging
        auto_refresh_token: Automatically refresh auth tokens
        persist_session: Persist session to storage
        retry: Retry configuration for transient errors

    Returns:
        SyncVaifClient: Configured synchronous client instance

    Example:
        >>> from vaif import create_sync_client
        >>>
        >>> vaif = create_sync_client(
        ...     project_id="your-project-id",
        ...     api_key="your-api-key"
        ... )
        >>>
        >>> # No async/await needed!
        >>> users = vaif.db.from_("users").select("*").execute()
    """
    async_client = _create_async_client(
        project_id=project_id,
        api_key=api_key,
        api_url=api_url,
        realtime_url=realtime_url,
        timeout=timeout,
        headers=headers,
        debug=debug,
        auto_refresh_token=auto_refresh_token,
        persist_session=persist_session,
        retry=retry,
    )
    return SyncVaifClient(async_client)
