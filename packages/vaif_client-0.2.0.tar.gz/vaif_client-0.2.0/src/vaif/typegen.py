"""
VAIF Type Generator

Generate Python types (Pydantic models) from database schema.
"""

from typing import TYPE_CHECKING, Any, Optional, List, Dict
from dataclasses import dataclass
from datetime import datetime
from enum import Enum

if TYPE_CHECKING:
    from .client import VaifClient


@dataclass
class ColumnSchema:
    """Database column schema."""
    name: str
    type: str
    nullable: bool
    default_value: Optional[str] = None
    is_primary_key: bool = False
    is_foreign_key: bool = False
    foreign_table: Optional[str] = None
    foreign_column: Optional[str] = None
    is_unique: bool = False
    comment: Optional[str] = None


@dataclass
class ForeignKeySchema:
    """Foreign key relationship."""
    name: str
    columns: List[str]
    foreign_table: str
    foreign_columns: List[str]
    on_delete: str
    on_update: str


@dataclass
class IndexSchema:
    """Database index."""
    name: str
    columns: List[str]
    unique: bool
    type: str


@dataclass
class TableSchema:
    """Database table schema."""
    name: str
    schema: str
    columns: List[ColumnSchema]
    primary_key: List[str]
    foreign_keys: List[ForeignKeySchema]
    indexes: List[IndexSchema]
    comment: Optional[str] = None


@dataclass
class EnumSchema:
    """Database enum type."""
    name: str
    schema: str
    values: List[str]


@dataclass
class ViewSchema:
    """Database view schema."""
    name: str
    schema: str
    columns: List[ColumnSchema]


@dataclass
class DatabaseSchema:
    """Complete database schema."""
    tables: List[TableSchema]
    enums: List[EnumSchema]
    views: List[ViewSchema]


@dataclass
class TypeGenOptions:
    """Type generation options."""
    # Include Row types (for SELECT)
    include_row: bool = True
    # Include Insert types (for INSERT)
    include_insert: bool = True
    # Include Update types (for UPDATE)
    include_update: bool = True
    # Include relationships
    include_relationships: bool = True
    # Schema to generate types for
    schema: str = "public"
    # Tables to include (all if empty)
    tables: Optional[List[str]] = None
    # Tables to exclude
    exclude_tables: Optional[List[str]] = None
    # Add docstrings
    include_comments: bool = True
    # Output format: "pydantic" | "dataclass" | "typeddict"
    output_format: str = "pydantic"
    # Generate Base model class
    include_base_model: bool = True


# PostgreSQL to Python type mapping
PG_TO_PYTHON_TYPES: Dict[str, str] = {
    # Numeric
    "smallint": "int",
    "integer": "int",
    "bigint": "int",
    "int2": "int",
    "int4": "int",
    "int8": "int",
    "decimal": "Decimal",
    "numeric": "Decimal",
    "real": "float",
    "double precision": "float",
    "float4": "float",
    "float8": "float",
    "serial": "int",
    "bigserial": "int",
    "smallserial": "int",
    "money": "Decimal",

    # String
    "character": "str",
    "character varying": "str",
    "varchar": "str",
    "char": "str",
    "text": "str",
    "name": "str",
    "citext": "str",

    # Boolean
    "boolean": "bool",
    "bool": "bool",

    # Date/Time
    "date": "date",
    "time": "time",
    "time with time zone": "time",
    "time without time zone": "time",
    "timestamp": "datetime",
    "timestamp with time zone": "datetime",
    "timestamp without time zone": "datetime",
    "timestamptz": "datetime",
    "timetz": "time",
    "interval": "timedelta",

    # Binary
    "bytea": "bytes",

    # UUID
    "uuid": "UUID",

    # JSON
    "json": "Dict[str, Any]",
    "jsonb": "Dict[str, Any]",

    # Network
    "inet": "str",
    "cidr": "str",
    "macaddr": "str",
    "macaddr8": "str",

    # Geometric
    "point": "Tuple[float, float]",
    "line": "str",
    "lseg": "str",
    "box": "str",
    "path": "str",
    "polygon": "str",
    "circle": "str",

    # Text search
    "tsvector": "str",
    "tsquery": "str",

    # Other
    "xml": "str",
    "void": "None",
    "unknown": "Any",
}


class VaifTypeGen:
    """VAIF Type Generator for Python."""

    def __init__(self, client: "VaifClient"):
        self._client = client

    async def fetch_schema(self, schema: str = "public") -> DatabaseSchema:
        """Fetch database schema from the API."""
        response = await self._client.request(
            f"/database/schema?schema={schema}"
        )

        if response.error:
            raise Exception(response.error.message)

        data = response.data

        # Parse into dataclasses
        tables = []
        for t in data.get("tables", []):
            columns = [
                ColumnSchema(
                    name=c["name"],
                    type=c["type"],
                    nullable=c.get("nullable", True),
                    default_value=c.get("defaultValue"),
                    is_primary_key=c.get("isPrimaryKey", False),
                    is_foreign_key=c.get("isForeignKey", False),
                    foreign_table=c.get("foreignTable"),
                    foreign_column=c.get("foreignColumn"),
                    is_unique=c.get("isUnique", False),
                    comment=c.get("comment"),
                )
                for c in t.get("columns", [])
            ]
            foreign_keys = [
                ForeignKeySchema(
                    name=fk["name"],
                    columns=fk["columns"],
                    foreign_table=fk["foreignTable"],
                    foreign_columns=fk["foreignColumns"],
                    on_delete=fk.get("onDelete", "NO ACTION"),
                    on_update=fk.get("onUpdate", "NO ACTION"),
                )
                for fk in t.get("foreignKeys", [])
            ]
            indexes = [
                IndexSchema(
                    name=idx["name"],
                    columns=idx["columns"],
                    unique=idx.get("unique", False),
                    type=idx.get("type", "btree"),
                )
                for idx in t.get("indexes", [])
            ]
            tables.append(
                TableSchema(
                    name=t["name"],
                    schema=t.get("schema", "public"),
                    columns=columns,
                    primary_key=t.get("primaryKey", []),
                    foreign_keys=foreign_keys,
                    indexes=indexes,
                    comment=t.get("comment"),
                )
            )

        enums = [
            EnumSchema(
                name=e["name"],
                schema=e.get("schema", "public"),
                values=e.get("values", []),
            )
            for e in data.get("enums", [])
        ]

        views = []
        for v in data.get("views", []):
            columns = [
                ColumnSchema(
                    name=c["name"],
                    type=c["type"],
                    nullable=c.get("nullable", True),
                )
                for c in v.get("columns", [])
            ]
            views.append(
                ViewSchema(
                    name=v["name"],
                    schema=v.get("schema", "public"),
                    columns=columns,
                )
            )

        return DatabaseSchema(tables=tables, enums=enums, views=views)

    async def generate(self, options: Optional[TypeGenOptions] = None) -> str:
        """Generate Python types from schema."""
        if options is None:
            options = TypeGenOptions()

        db_schema = await self.fetch_schema(options.schema)
        return self.generate_from_schema(db_schema, options)

    def generate_from_schema(
        self,
        schema: DatabaseSchema,
        options: Optional[TypeGenOptions] = None,
    ) -> str:
        """Generate Python types from schema directly."""
        if options is None:
            options = TypeGenOptions()

        lines: List[str] = []

        # Header
        lines.append('"""')
        lines.append("VAIF Studio Database Types")
        lines.append(f"Generated at {datetime.now().isoformat()}")
        lines.append("DO NOT EDIT - This file is auto-generated")
        lines.append('"""')
        lines.append("")

        # Imports based on format
        if options.output_format == "pydantic":
            lines.append("from __future__ import annotations")
            lines.append("")
            lines.append("from datetime import date, datetime, time, timedelta")
            lines.append("from decimal import Decimal")
            lines.append("from enum import Enum")
            lines.append("from typing import Any, Dict, List, Optional, Tuple")
            lines.append("from uuid import UUID")
            lines.append("")
            lines.append("from pydantic import BaseModel, Field")
            lines.append("")

            if options.include_base_model:
                lines.append("")
                lines.append("class VaifBaseModel(BaseModel):")
                lines.append('    """Base model for all VAIF types."""')
                lines.append("")
                lines.append("    class Config:")
                lines.append("        from_attributes = True")
                lines.append("        populate_by_name = True")
                lines.append("")

        elif options.output_format == "dataclass":
            lines.append("from __future__ import annotations")
            lines.append("")
            lines.append("from dataclasses import dataclass, field")
            lines.append("from datetime import date, datetime, time, timedelta")
            lines.append("from decimal import Decimal")
            lines.append("from enum import Enum")
            lines.append("from typing import Any, Dict, List, Optional, Tuple")
            lines.append("from uuid import UUID")
            lines.append("")

        elif options.output_format == "typeddict":
            lines.append("from __future__ import annotations")
            lines.append("")
            lines.append("from datetime import date, datetime, time, timedelta")
            lines.append("from decimal import Decimal")
            lines.append("from enum import Enum")
            lines.append("from typing import Any, Dict, List, Optional, Tuple, TypedDict")
            lines.append("from uuid import UUID")
            lines.append("")

        # Generate enums first
        if schema.enums:
            lines.append("# Enums")
            lines.append("")
            for enum_def in schema.enums:
                lines.extend(self._generate_enum(enum_def, options))
                lines.append("")

        # Filter tables
        tables = list(options.tables) if options.tables else []
        exclude_tables = list(options.exclude_tables) if options.exclude_tables else []

        filtered_tables = [
            t for t in schema.tables
            if (not tables or t.name in tables) and t.name not in exclude_tables
        ]

        # Generate table types
        lines.append("# Tables")
        lines.append("")

        for table in filtered_tables:
            table_lines = self._generate_table_types(
                table, schema.tables, options
            )
            lines.extend(table_lines)
            lines.append("")

        # Generate view types
        if schema.views:
            lines.append("# Views")
            lines.append("")
            for view in schema.views:
                if tables and view.name not in tables:
                    continue
                if view.name in exclude_tables:
                    continue
                view_lines = self._generate_view_type(view, options)
                lines.extend(view_lines)
                lines.append("")

        return "\n".join(lines)

    def _generate_enum(
        self, enum_def: EnumSchema, options: TypeGenOptions
    ) -> List[str]:
        """Generate enum type."""
        lines: List[str] = []
        class_name = self._to_pascal_case(enum_def.name)

        if options.include_comments:
            lines.append(f'class {class_name}(str, Enum):')
            lines.append(f'    """Enum: {enum_def.name}"""')
        else:
            lines.append(f"class {class_name}(str, Enum):")

        for value in enum_def.values:
            # Make valid Python identifier
            py_name = self._to_snake_case(value).upper()
            if py_name[0].isdigit():
                py_name = "_" + py_name
            lines.append(f'    {py_name} = "{value}"')

        return lines

    def _generate_table_types(
        self,
        table: TableSchema,
        all_tables: List[TableSchema],
        options: TypeGenOptions,
    ) -> List[str]:
        """Generate types for a table."""
        lines: List[str] = []
        class_name = self._to_pascal_case(table.name)

        # Row type (SELECT)
        if options.include_row:
            lines.extend(
                self._generate_model(
                    f"{class_name}Row",
                    table.columns,
                    table.comment,
                    options,
                    include_all=True,
                    relationships=table.foreign_keys if options.include_relationships else [],
                    all_tables=all_tables,
                )
            )
            lines.append("")

        # Insert type
        if options.include_insert:
            lines.extend(
                self._generate_model(
                    f"{class_name}Insert",
                    table.columns,
                    f"Insert model for {table.name}",
                    options,
                    include_all=False,
                    make_optional_with_defaults=True,
                )
            )
            lines.append("")

        # Update type
        if options.include_update:
            # For update, exclude primary keys and make all optional
            update_columns = [
                c for c in table.columns if not c.is_primary_key
            ]
            lines.extend(
                self._generate_model(
                    f"{class_name}Update",
                    update_columns,
                    f"Update model for {table.name}",
                    options,
                    include_all=True,
                    all_optional=True,
                )
            )

        return lines

    def _generate_model(
        self,
        class_name: str,
        columns: List[ColumnSchema],
        comment: Optional[str],
        options: TypeGenOptions,
        include_all: bool = True,
        make_optional_with_defaults: bool = False,
        all_optional: bool = False,
        relationships: Optional[List[ForeignKeySchema]] = None,
        all_tables: Optional[List[TableSchema]] = None,
    ) -> List[str]:
        """Generate a model class."""
        lines: List[str] = []

        if options.output_format == "pydantic":
            base_class = "VaifBaseModel" if options.include_base_model else "BaseModel"
            lines.append(f"class {class_name}({base_class}):")
        elif options.output_format == "dataclass":
            lines.append("@dataclass")
            lines.append(f"class {class_name}:")
        elif options.output_format == "typeddict":
            total = "True" if not all_optional else "False"
            lines.append(f"class {class_name}(TypedDict, total={total}):")

        if options.include_comments and comment:
            lines.append(f'    """{comment}"""')

        has_fields = False

        for col in columns:
            py_type = self._pg_type_to_python(col.type)

            # Determine if optional
            is_optional = col.nullable or all_optional
            if make_optional_with_defaults:
                is_optional = is_optional or col.default_value is not None or col.is_primary_key

            if is_optional:
                py_type = f"Optional[{py_type}]"

            # Field definition
            field_name = self._to_snake_case(col.name)

            if options.output_format == "pydantic":
                if is_optional:
                    lines.append(f"    {field_name}: {py_type} = None")
                else:
                    lines.append(f"    {field_name}: {py_type}")
            elif options.output_format == "dataclass":
                if is_optional:
                    lines.append(f"    {field_name}: {py_type} = None")
                else:
                    lines.append(f"    {field_name}: {py_type}")
            elif options.output_format == "typeddict":
                lines.append(f"    {field_name}: {py_type}")

            has_fields = True

        # Add relationship fields
        if relationships and all_tables:
            for fk in relationships:
                related_table = next(
                    (t for t in all_tables if t.name == fk.foreign_table),
                    None,
                )
                if related_table:
                    related_class = self._to_pascal_case(fk.foreign_table)
                    field_name = self._to_snake_case(fk.foreign_table)
                    lines.append(f"    {field_name}: Optional[{related_class}Row] = None")
                    has_fields = True

        if not has_fields:
            lines.append("    pass")

        return lines

    def _generate_view_type(
        self, view: ViewSchema, options: TypeGenOptions
    ) -> List[str]:
        """Generate type for a view."""
        return self._generate_model(
            f"{self._to_pascal_case(view.name)}Row",
            view.columns,
            f"View: {view.name}",
            options,
            include_all=True,
        )

    def _pg_type_to_python(self, pg_type: str) -> str:
        """Convert PostgreSQL type to Python type."""
        # Handle arrays
        if pg_type.endswith("[]"):
            base_type = pg_type[:-2]
            py_base_type = PG_TO_PYTHON_TYPES.get(base_type.lower(), "Any")
            return f"List[{py_base_type}]"

        # Handle ARRAY type
        import re
        array_match = re.match(r"^(.+)\s+ARRAY$", pg_type, re.IGNORECASE)
        if array_match:
            base_type = array_match.group(1)
            py_base_type = PG_TO_PYTHON_TYPES.get(base_type.lower(), "Any")
            return f"List[{py_base_type}]"

        # Handle with precision (e.g., numeric(10,2))
        precision_match = re.match(r"^(\w+)\(", pg_type)
        if precision_match:
            base_type = precision_match.group(1)
            return PG_TO_PYTHON_TYPES.get(base_type.lower(), "Any")

        return PG_TO_PYTHON_TYPES.get(pg_type.lower(), "Any")

    def _to_pascal_case(self, s: str) -> str:
        """Convert string to PascalCase."""
        import re
        parts = re.split(r"[_\s-]+", s)
        return "".join(part.capitalize() for part in parts)

    def _to_snake_case(self, s: str) -> str:
        """Convert string to snake_case."""
        import re
        # Handle camelCase
        s = re.sub(r"([a-z0-9])([A-Z])", r"\1_\2", s)
        # Handle spaces and hyphens
        s = re.sub(r"[\s-]+", "_", s)
        return s.lower()


def create_typegen(client: "VaifClient") -> VaifTypeGen:
    """Create a type generator instance."""
    return VaifTypeGen(client)
