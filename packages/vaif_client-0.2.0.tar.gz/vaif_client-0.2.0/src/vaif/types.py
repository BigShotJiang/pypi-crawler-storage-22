"""
Type definitions for VAIF Studio SDK

Uses Pydantic for runtime type validation and serialization.
"""

from __future__ import annotations

from datetime import datetime
from enum import Enum
from typing import Any, Dict, Generic, List, Literal, Optional, TypeVar, Union

from pydantic import BaseModel, Field


# Generic type variables
T = TypeVar("T")


# ============================================================================
# Client Types
# ============================================================================


class VaifConfig(BaseModel):
    """VAIF client configuration."""

    model_config = {"frozen": True}

    project_id: str = Field(..., description="Project ID")
    api_key: str = Field(..., description="API key")
    api_url: str = Field(
        default="https://api.vaif.studio", description="API base URL"
    )
    realtime_url: str = Field(
        default="wss://realtime.vaif.studio", description="WebSocket URL"
    )
    timeout: int = Field(default=30000, description="Request timeout in ms")
    headers: Dict[str, str] = Field(default_factory=dict, description="Custom headers")
    debug: bool = Field(default=False, description="Enable debug logging")
    auto_refresh_token: bool = Field(default=True, description="Auto-refresh auth token")
    persist_session: bool = Field(default=True, description="Persist session to storage")


class ApiError(BaseModel):
    """API error response."""

    message: str
    code: Optional[str] = None
    status: Optional[int] = None
    details: Optional[Any] = None
    request_id: Optional[str] = None


class ApiResponse(BaseModel, Generic[T]):
    """Generic API response wrapper."""

    data: Optional[T] = None
    error: Optional[ApiError] = None
    status: int = 0
    headers: Dict[str, str] = Field(default_factory=dict)


# ============================================================================
# Database Types
# ============================================================================


class QueryError(BaseModel):
    """Database query error."""

    message: str
    code: Optional[str] = None
    details: Optional[str] = None


class QueryResult(BaseModel, Generic[T]):
    """Database query result."""

    data: Optional[T] = None
    error: Optional[QueryError] = None
    status: int = 200
    count: Optional[int] = None


class FilterOperator(str, Enum):
    """Filter operators for query builder."""

    EQ = "eq"
    NEQ = "neq"
    GT = "gt"
    GTE = "gte"
    LT = "lt"
    LTE = "lte"
    LIKE = "like"
    ILIKE = "ilike"
    IS = "is"
    IN = "in"
    CONTAINS = "cs"
    CONTAINED_BY = "cd"
    OVERLAPS = "ov"
    FTS = "fts"


class OrderDirection(str, Enum):
    """Order direction for sorting."""

    ASC = "asc"
    DESC = "desc"


# ============================================================================
# Auth Types
# ============================================================================


class UserMetadata(BaseModel):
    """User metadata."""

    model_config = {"extra": "allow"}


class User(BaseModel):
    """Authenticated user."""

    id: str
    email: Optional[str] = None
    phone: Optional[str] = None
    email_confirmed_at: Optional[datetime] = None
    phone_confirmed_at: Optional[datetime] = None
    last_sign_in_at: Optional[datetime] = None
    created_at: datetime
    updated_at: Optional[datetime] = None
    user_metadata: Dict[str, Any] = Field(default_factory=dict)
    app_metadata: Dict[str, Any] = Field(default_factory=dict)


class Session(BaseModel):
    """User session."""

    access_token: str
    refresh_token: str
    expires_in: int
    expires_at: int
    token_type: str = "bearer"
    user: Optional[User] = None


class AuthError(BaseModel):
    """Authentication error."""

    message: str
    status: Optional[int] = None


class AuthResponse(BaseModel):
    """Authentication response."""

    session: Optional[Session] = None
    user: Optional[User] = None
    error: Optional[AuthError] = None


class OAuthProvider(str, Enum):
    """Supported OAuth providers."""

    GOOGLE = "google"
    GITHUB = "github"
    APPLE = "apple"
    MICROSOFT = "microsoft"
    FACEBOOK = "facebook"
    TWITTER = "twitter"


# ============================================================================
# Storage Types
# ============================================================================


class FileObject(BaseModel):
    """File object metadata."""

    id: str
    name: str
    bucket_id: str
    created_at: datetime
    updated_at: Optional[datetime] = None
    size: int
    content_type: Optional[str] = None
    metadata: Dict[str, Any] = Field(default_factory=dict)


class Bucket(BaseModel):
    """Storage bucket."""

    id: str
    name: str
    public: bool = False
    file_size_limit: Optional[int] = None
    allowed_mime_types: List[str] = Field(default_factory=list)
    created_at: datetime
    updated_at: Optional[datetime] = None


class UploadResult(BaseModel):
    """File upload result."""

    id: str
    path: str
    full_path: str
    size: int
    content_type: Optional[str] = None


class StorageError(BaseModel):
    """Storage operation error."""

    message: str
    status_code: str
    error: str


class ImageTransformOptions(BaseModel):
    """Image transformation options."""

    width: Optional[int] = None
    height: Optional[int] = None
    resize: Optional[Literal["cover", "contain", "fill"]] = None
    format: Optional[Literal["webp", "png", "jpeg", "avif"]] = None
    quality: Optional[int] = Field(default=None, ge=1, le=100)


class UploadOptions(BaseModel):
    """File upload options."""

    content_type: Optional[str] = None
    cache_control: Optional[str] = None
    upsert: bool = False
    metadata: Dict[str, Any] = Field(default_factory=dict)


class DownloadOptions(BaseModel):
    """File download options."""

    transform: Optional[ImageTransformOptions] = None


class SignedUrlOptions(BaseModel):
    """Signed URL options."""

    expires_in: int = Field(..., description="Expiration in seconds")
    transform: Optional[ImageTransformOptions] = None
    download: Optional[Union[bool, str]] = None


class ListFilesOptions(BaseModel):
    """List files options."""

    limit: Optional[int] = None
    offset: Optional[int] = None
    search: Optional[str] = None
    sort_by: Optional[Dict[str, str]] = None


# ============================================================================
# Functions Types
# ============================================================================


class FunctionError(BaseModel):
    """Function invocation error."""

    message: str
    status: Optional[int] = None
    name: Optional[str] = None


class FunctionResponse(BaseModel, Generic[T]):
    """Function invocation response."""

    data: Optional[T] = None
    error: Optional[FunctionError] = None


class FunctionInvokeOptions(BaseModel):
    """Function invocation options."""

    method: Literal["GET", "POST", "PUT", "PATCH", "DELETE"] = "POST"
    headers: Dict[str, str] = Field(default_factory=dict)
    timeout: Optional[int] = None


# ============================================================================
# AI Types
# ============================================================================


class CopilotModel(str, Enum):
    """Copilot model tiers."""

    QUICK = "copilot-quick"  # Fast responses for simple tasks
    BALANCED = "copilot-balanced"  # Best balance of speed and capability (default)
    POWER = "copilot-power"  # Maximum capability for complex tasks
    ENTERPRISE = "copilot-enterprise"  # Enterprise-grade models


# Backward compatibility alias
AIModel = CopilotModel


class AIGenerateOptions(BaseModel):
    """AI generation options."""

    model: Optional[CopilotModel] = None
    temperature: Optional[float] = Field(default=None, ge=0, le=1)
    max_tokens: Optional[int] = None
    stream: bool = False


class GeneratedColumn(BaseModel):
    """Generated database column."""

    name: str
    type: str
    nullable: bool = False
    primary_key: bool = False
    unique: bool = False
    default_value: Optional[str] = None


class GeneratedIndex(BaseModel):
    """Generated database index."""

    name: str
    columns: List[str]
    unique: bool = False


class GeneratedRelation(BaseModel):
    """Generated database relation."""

    name: str
    target_table: str
    source_columns: List[str]
    target_columns: List[str]
    type: Literal["one-to-one", "one-to-many", "many-to-many"]


class GeneratedTable(BaseModel):
    """Generated database table."""

    name: str
    columns: List[GeneratedColumn]
    indexes: List[GeneratedIndex] = Field(default_factory=list)
    relations: List[GeneratedRelation] = Field(default_factory=list)


class SchemaGenerationRequest(BaseModel):
    """Schema generation request."""

    prompt: str
    format: Literal["drizzle", "prisma", "sql", "json"] = "sql"
    include_relations: bool = True
    include_indexes: bool = True
    database: Literal["postgresql", "mysql", "sqlite"] = "postgresql"


class SchemaGenerationResult(BaseModel):
    """Schema generation result."""

    model_config = {"populate_by_name": True}

    schema_: str = Field(..., alias="schema")
    format: str
    tables: List[GeneratedTable]
    types: Optional[str] = None
    explanation: Optional[str] = None
    credits_used: int


class FunctionGenerationRequest(BaseModel):
    """Function generation request."""

    prompt: str
    name: Optional[str] = None
    runtime: Literal["edge", "node"] = "edge"
    include_types: bool = True


class FunctionGenerationResult(BaseModel):
    """Function generation result."""

    code: str
    name: str
    types: Optional[str] = None
    input_schema: Optional[Dict[str, Any]] = None
    output_schema: Optional[Dict[str, Any]] = None
    explanation: Optional[str] = None
    credits_used: int


class EndpointGenerationRequest(BaseModel):
    """Endpoint generation request."""

    prompt: str
    method: Literal["GET", "POST", "PUT", "PATCH", "DELETE"] = "GET"
    path: Optional[str] = None
    requires_auth: bool = True
    include_validation: bool = True


class EndpointGenerationResult(BaseModel):
    """Endpoint generation result."""

    code: str
    method: str
    path: str
    request_schema: Optional[Dict[str, Any]] = None
    response_schema: Optional[Dict[str, Any]] = None
    openapi_spec: Optional[Dict[str, Any]] = None
    explanation: Optional[str] = None
    credits_used: int


class AIChatMessage(BaseModel):
    """AI chat message."""

    role: Literal["user", "assistant", "system"]
    content: str


class AIChatRequest(BaseModel):
    """AI chat request."""

    messages: List[AIChatMessage]
    context: Optional[Dict[str, Any]] = None


class AISuggestion(BaseModel):
    """AI suggestion."""

    type: Literal["schema", "function", "endpoint", "query"]
    title: str
    description: str
    prompt: str


class AIChatResponse(BaseModel):
    """AI chat response."""

    message: AIChatMessage
    suggestions: List[AISuggestion] = Field(default_factory=list)
    credits_used: int


class AICreditsInfo(BaseModel):
    """AI credits information."""

    balance: int
    monthly_allocation: int
    used_this_month: int
    reset_date: str


# ============================================================================
# Realtime Types
# ============================================================================


class ChannelStatus(str, Enum):
    """Channel subscription status."""

    SUBSCRIBED = "SUBSCRIBED"
    CLOSED = "CLOSED"
    ERRORED = "ERRORED"
    TIMED_OUT = "TIMED_OUT"


class PostgresChangeEvent(BaseModel, Generic[T]):
    """Postgres change event."""

    model_config = {"populate_by_name": True}

    schema_: str = Field(..., alias="schema")
    table: str
    event_type: Literal["INSERT", "UPDATE", "DELETE"]
    old_record: Optional[T] = None
    new_record: Optional[T] = None
    commit_timestamp: str


class BroadcastMessage(BaseModel, Generic[T]):
    """Broadcast message."""

    event: str
    payload: T


class PresenceState(BaseModel, Generic[T]):
    """Presence state."""

    presence_ref: str
    online_at: str
    data: T


class RealtimeOptions(BaseModel):
    """Realtime connection options."""

    heartbeat: bool = True
    heartbeat_interval: int = 30000
    auto_reconnect: bool = True
    reconnect_interval: int = 1000
    max_reconnect_attempts: int = 10
