"""
Configuration module for Valence SDK.

This module provides configuration settings for the Valence API client,
including default URLs, environment variable support, and legacy compatibility.

Environment Variables:
    VALENCE_API_KEY: API key for authentication (required)
    VALENCE_API_BASE_URL: Base URL for API endpoints (default: https://api.getvalenceai.com)
    VALENCE_WEBSOCKET_URL: WebSocket URL for streaming (default: wss://api.getvalenceai.com)
    VALENCE_DISCRETE_URL: Legacy discrete API URL (deprecated)
    VALENCE_ASYNCH_URL: Legacy async API URL (deprecated)
"""
import os

# API Key from environment
VALENCE_API_KEY = os.getenv("VALENCE_API_KEY")

# Default URLs point to production environment (api.getvalenceai.com)
# These can be overridden by environment variables or constructor parameters
DEFAULT_BASE_URL = "https://api.getvalenceai.com"
DEFAULT_WEBSOCKET_URL = "wss://api.getvalenceai.com"

# Environment variable overrides for base URLs
VALENCE_API_BASE_URL = os.getenv("VALENCE_API_BASE_URL", DEFAULT_BASE_URL)
VALENCE_WEBSOCKET_URL = os.getenv("VALENCE_WEBSOCKET_URL", DEFAULT_WEBSOCKET_URL)

# Legacy environment variables for backward compatibility (deprecated)
VALENCE_DISCRETE_URL = os.getenv("VALENCE_DISCRETE_URL")
VALENCE_ASYNCH_URL = os.getenv("VALENCE_ASYNCH_URL")
