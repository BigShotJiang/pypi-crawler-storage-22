

class ValenceSDKException(Exception):
    """Base exception for Valence SDK errors."""
    pass


class UploadError(ValenceSDKException):
    """Raised when a file upload fails."""
    pass


class PredictionError(ValenceSDKException):
    """Raised when a prediction request fails."""
    pass


class AudioTooShortError(ValenceSDKException):
    """Raised when the audio file is shorter than the minimum required duration."""

    def __init__(self, message: str, min_duration: float = None, actual_duration: float = None):
        super().__init__(message)
        self.min_duration = min_duration
        self.actual_duration = actual_duration


class AudioTooLongError(ValenceSDKException):
    """Raised when the audio file exceeds the maximum allowed duration."""

    def __init__(self, message: str, max_duration: float = None, actual_duration: float = None):
        super().__init__(message)
        self.max_duration = max_duration
        self.actual_duration = actual_duration


class FileSizeLimitExceededError(ValenceSDKException):
    """Raised when the audio file size exceeds the rate limit policy maximum."""

    def __init__(self, message: str, max_size_mb: float = None, actual_size_mb: float = None):
        super().__init__(message)
        self.max_size_mb = max_size_mb
        self.actual_size_mb = actual_size_mb