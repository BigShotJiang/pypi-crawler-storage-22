"""
Rate Limit API module for Valence SDK.

This module provides functionality to check rate limit status and health
for the Valence API.
"""
import requests
from .logger import get_logger
from .exceptions import ValenceSDKException

logger = get_logger()


class RateLimitAPI:
    """Client for rate limit status and management."""

    def __init__(self, headers, base_url):
        """Initialize the Rate Limit API client.

        Args:
            headers (dict): Headers including API key
            base_url (str): Base URL for API endpoints
        """
        self.headers = headers
        self.base_url = base_url

    def get_status(self):
        """Get current rate limit status and usage.

        Returns:
            dict: Rate limit status including limits and current usage

        Raises:
            ValenceSDKException: If the API request fails
        """
        url = f"{self.base_url}/v1/rate-limit/status"
        try:
            logger.info("Fetching rate limit status")
            response = requests.get(url, headers=self.headers, timeout=15)
            response.raise_for_status()
            logger.info("Rate limit status retrieved successfully")
            return response.json()
        except requests.exceptions.RequestException as e:
            logger.error(f"Failed to get rate limit status: {e}")
            raise ValenceSDKException(f"Rate limit status request failed: {e}")

    def get_health(self):
        """Check rate limiting service health.

        Returns:
            dict: Health status of rate limiting service

        Raises:
            ValenceSDKException: If the API request fails
        """
        url = f"{self.base_url}/v1/rate-limit/health"
        try:
            logger.info("Checking rate limit service health")
            response = requests.get(url, headers=self.headers, timeout=15)
            response.raise_for_status()
            logger.info("Rate limit health check completed")
            return response.json()
        except requests.exceptions.RequestException as e:
            logger.error(f"Failed to check rate limit health: {e}")
            raise ValenceSDKException(f"Rate limit health check failed: {e}")
