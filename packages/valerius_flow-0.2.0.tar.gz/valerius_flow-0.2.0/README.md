# ValeriusFlow

A Django-inspired API framework.

## Installation

```bash
pip install valerius-flow
```

## Usage

Create a new project:

```bash
valerius_flow startproject myproject
```

Create a new app:

```bash
python manage.py startapp myapp
```

Run server:

```bash
python manage.py startapp run
```
