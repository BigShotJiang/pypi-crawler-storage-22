import os


def create_app(app_name):
    class_name = app_name.capitalize()
    os.makedirs(app_name, exist_ok=True)
    
    app_files = {
        "__init__.py": "",
        "models.py": f"class {class_name}(object):\n    pass\n",
        "handlers.py": f"class {class_name}Resource:\n    async def get(self, req):\n        return {{'message': 'Hello from {app_name}'}}\n",
        "router.py": f"from .handlers import {class_name}Resource\n\nroutes = [\n    ('/{app_name}', {class_name}Resource),\n]\n"
    }

    for filename, content in app_files.items():
        with open(os.path.join(app_name, filename), "w") as f:
            f.write(content)

    print(f"App '{app_name}' created and registered!")