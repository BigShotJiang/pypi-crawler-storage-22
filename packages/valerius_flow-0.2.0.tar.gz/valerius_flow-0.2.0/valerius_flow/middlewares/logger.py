from datetime import datetime


class LoggerMiddleware:
    def __init__(self, app):
        self.app = app

    def __call__(self, environ, start_response):
        # 1. Logic BEFORE the request hits the API
        start_time = datetime.now()
        method = environ.get('REQUEST_METHOD')
        path = environ.get('PATH_INFO')
        
        # 2. Pass the request to the main API (or the next middleware)
        response = self.app(environ, start_response)

        # 3. Logic AFTER the response is generated
        duration = datetime.now() - start_time

        return response
