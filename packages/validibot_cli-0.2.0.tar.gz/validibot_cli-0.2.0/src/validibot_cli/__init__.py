"""Validibot CLI - Command-line interface for automated data validation."""

from importlib.metadata import version

__version__ = version("validibot-cli")
