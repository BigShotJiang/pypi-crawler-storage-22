"""Validibot CLI tests."""
