from dataclasses import dataclass
from typing import Any

from camel_converter import to_snake
from gql.transport.exceptions import TransportServerError


@dataclass
class SourceSchemaReinference:
    source_names: set[str] | None

    def should_reinfer_schema_for_source(self, source_name: str) -> bool:
        if self.source_names is None:
            return False
        if len(self.source_names) == 0:  # ReInfer for all
            return True
        return source_name in self.source_names


def _sanitized_error_str(e: Exception, show_secrets: bool) -> str:
    """Sanitize error and return string.

    This method **does not** raise any exception but returns a string
    representation of either the original error or the sanitized version to be
    re-raised.

    :param e: The exception.
    :param show_secrets: If secrets should be shown or not.
    """
    if show_secrets:
        return str(e)

    code = ""
    if isinstance(e, TransportServerError):
        code = f" ({e.code})"

    return (
        f"API error{code}: The error message has been "
        "suppressed because it potentially contains sensitive information; "
        "If you would like to view the error message, run again with --show-secrets"
    )


def _rename_dict_key(d: dict[str, Any], from_key: str, to_key: str) -> None:
    if from_key not in d:
        return

    d[to_key] = d[from_key]
    del d[from_key]


def _to_snake_recursive(obj: Any, max_depth: int = 10, _depth: int = 0) -> Any:
    """Recursively convert dictionary keys to snake_case."""
    if _depth > max_depth:
        return obj

    if isinstance(obj, dict):
        return {
            to_snake(k): _to_snake_recursive(v, max_depth, _depth + 1)
            for k, v in obj.items()
        }

    if isinstance(obj, list):
        return [_to_snake_recursive(item, max_depth, _depth + 1) for item in obj]

    return obj
