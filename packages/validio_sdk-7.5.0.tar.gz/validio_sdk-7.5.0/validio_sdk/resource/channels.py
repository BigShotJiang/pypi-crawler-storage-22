"""Notification Channels."""

from enum import Enum
from typing import TYPE_CHECKING, Any, Union, cast

from camel_converter import to_camel

from validio_sdk.resource._diffable import Diffable
from validio_sdk.resource._resource import (
    ApiSecretChangeNestedResource,
    Resource,
    ResourceGraph,
)
from validio_sdk.resource._resource_graph import RESOURCE_GRAPH
from validio_sdk.resource._serde import (
    NODE_TYPE_FIELD_NAME,
    _api_create_input_params,
    _api_update_input_params,
    _encode_resource,
    _maybe_cast,
    decode_nested_objects,
    get_children_node,
    get_config_node,
    with_resource_graph_info,
)

if TYPE_CHECKING:
    from validio_sdk.resource._diff import DiffContext


class EmailChannelSmtpEncryption(str, Enum):
    """Connection encryption mode for an EmailChannel."""

    TLS = "TLS"
    START_TLS = "START_TLS"
    NONE = "NONE"


class Channel(Resource):
    """A notification channel configuration.

    https://docs.validio.io/docs/channels
    """

    def __init__(
        self,
        name: str,
        display_name: str | None,
        ignore_changes: bool = False,
        __internal__: ResourceGraph | None = None,
    ) -> None:
        """
        Constructor.

        :param name: Unique resource name assigned to the destination
        :param display_name: Human-readable name for the channel. This name is
          visible in the UI and does not need to be unique.
        :param ignore_changes: If set to true, changes to the resource will be ignored.
        :param __internal__: Should be left ignored. This is for internal usage only.
        """
        # Channels are at the root sub-graphs.
        g: ResourceGraph = __internal__ or RESOURCE_GRAPH
        super().__init__(
            name=name,
            display_name=display_name,
            ignore_changes=ignore_changes,
            __internal__=g,
        )

        self._resource_graph: ResourceGraph = g
        self._resource_graph._add_root(self)

    def _immutable_fields(self) -> set[str]:
        return set({})

    def _all_fields(self) -> set[str]:
        return {
            *super()._all_fields(),
            *self._secret_fields(),
        }

    def resource_class_name(self) -> str:
        """Returns the base class name."""
        return "Channel"

    def _encode(self) -> dict[str, object]:
        return _encode_resource(self)

    def _api_create_input(self, namespace: str, _: "DiffContext") -> Any:
        overrides = {
            "namespaceId": namespace,
            **{
                to_camel(f): obj._api_input()
                for f, obj in self._nested_secret_objects().items()
            },
        }
        return _api_create_input_params(
            resource=self,
            overrides=overrides,
        )

    def _api_update_input(self, _namespace: str, _ctx: "DiffContext") -> Any:
        overrides = {
            **{
                to_camel(f): obj._api_input()
                for f, obj in self._nested_secret_objects().items()
            }
        }
        return _api_update_input_params(
            resource=self,
            overrides=overrides,
        )

    @staticmethod
    def _decode(
        ctx: "DiffContext",
        cls: type,
        obj: dict[str, dict[str, object]],
        g: ResourceGraph,
    ) -> "Channel":
        from validio_sdk.resource.notification_rules import NotificationRule

        args = get_config_node(obj)

        decode_nested_objects(
            obj=args,
            cls_eval=lambda cls_name: eval(cls_name),
        )

        channel = cls(**with_resource_graph_info(args, g))

        # Decode notification rules
        children_obj = cast(dict[str, dict[str, object]], get_children_node(obj))
        notification_rules_obj = cast(
            dict[str, dict[str, object]],
            children_obj.get(NotificationRule.__name__, {}),
        )

        notification_rules = {}
        for rule_name, value in notification_rules_obj.items():
            rule = NotificationRule._decode(ctx, channel, value)
            notification_rules[rule_name] = rule
            ctx.notification_rules[rule_name] = rule

        if len(notification_rules) > 0:
            channel._children[NotificationRule.__name__] = cast(
                dict[str, Resource], notification_rules
            )

        return channel


class SlackChannel(Channel):
    """
    Configuration to send notifications to a Slack channel.

    https://docs.validio.io/docs/slack
    """

    def __init__(
        self,
        *,
        name: str,
        application_link_url: str,
        slack_channel_id: str,
        token: str,
        signing_secret: str | None = None,
        app_token: str | None = None,
        interactive_message_enabled: bool = True,
        display_name: str | None = None,
        ignore_changes: bool = False,
        __internal__: ResourceGraph | None = None,
    ):
        """
        Constructor.

        :param application_link_url: URL to your Validio application
            instance, used to send notifications.
        :param slack_channel_id: Slack channel ID to send to.
        :param token: Slack API token.
        :param signing_secret: Slack API signing secret. Deprecated.
        :param app_token: App level token used to retrieve user events from Slack.
        :param interactive_message_enabled: If interactive notification messages should
         be used.
        :param display_name: Human-readable name for the channel. This name is
          visible in the UI and does not need to be unique.
        :param ignore_changes: If set to true, changes to the resource will be ignored.
        """
        super().__init__(
            name=name,
            display_name=display_name,
            ignore_changes=ignore_changes,
            __internal__=__internal__,
        )
        self.application_link_url = application_link_url
        self.slack_channel_id = slack_channel_id
        self.token = token
        self.signing_secret = signing_secret
        self.app_token = app_token
        self.interactive_message_enabled = interactive_message_enabled

        if self.signing_secret:
            self.add_field_deprecation("signing_secret", "app_token")

    def _secret_fields(self) -> set[str]:
        return {
            "app_token",
            "signing_secret",
            "token",
        }

    def _immutable_fields(self) -> set[str]:
        return set({})

    def _mutable_fields(self) -> set[str]:
        return {
            *super()._mutable_fields(),
            *{
                "application_link_url",
                "slack_channel_id",
                "interactive_message_enabled",
            },
        }


class MsTeamsChannel(Channel):
    """
    Configuration to send notifications to a Microsoft Teams channel.

    https://docs.validio.io/docs/msteams
    """

    def __init__(
        self,
        *,
        name: str,
        application_link_url: str,
        ms_teams_channel_id: str,
        client_id: str,
        client_secret: str,
        tenant_id: str | None = None,
        interactive_message_enabled: bool = True,
        display_name: str | None = None,
        ignore_changes: bool = False,
        __internal__: ResourceGraph | None = None,
    ):
        """
        Constructor.

        :param application_link_url: URL to your Validio application
            instance, used to send notifications.
        :param ms_teams_channel_id: Channel ID to send notifications to.
        :param client_id: Client ID for authentication.
        :param client_secret: Client secret for authentication.
        :param tenant_id: Tenant ID for the bot used for sending messages.
            Leave empty if using a multi-tenant bot.
        :param interactive_message_enabled: If interactive notification messages should
         be used.
        :param display_name: Human-readable name for the channel. This name is
          visible in the UI and does not need to be unique.
        :param ignore_changes: If set to true, changes to the resource will be ignored.
        """
        super().__init__(
            name=name,
            display_name=display_name,
            ignore_changes=ignore_changes,
            __internal__=__internal__,
        )
        self.application_link_url = application_link_url
        self.ms_teams_channel_id = ms_teams_channel_id
        self.client_id = client_id
        self.client_secret = client_secret
        self.tenant_id = tenant_id
        self.interactive_message_enabled = interactive_message_enabled

    def _secret_fields(self) -> set[str]:
        return {"client_id", "client_secret"}

    def _immutable_fields(self) -> set[str]:
        return set({})

    def _mutable_fields(self) -> set[str]:
        return {
            *super()._mutable_fields(),
            *{
                "application_link_url",
                "ms_teams_channel_id",
                "tenant_id",
                "interactive_message_enabled",
            },
        }


class WebhookChannel(Channel):
    """
    Configuration to send notifications to a webhook.

    https://docs.validio.io/docs/webhooks
    """

    def __init__(
        self,
        *,
        name: str,
        application_link_url: str,
        webhook_url: str,
        auth_header: str | None = None,
        display_name: str | None = None,
        ignore_changes: bool = False,
        __internal__: ResourceGraph | None = None,
    ):
        """
        Constructor.

        :param application_link_url: URL to your Validio application
            instance, used to send notifications.
        :param webhook_url: Webhook URL to the specified HTTP endpoint.
        :param auth_header: Signature to include in the authorization
            header sent to the HTTP endpoint.
        :param display_name: Human-readable name for the channel. This name is
          visible in the UI and does not need to be unique.
        :param ignore_changes: If set to true, changes to the resource will be ignored.
        """
        super().__init__(
            name=name,
            display_name=display_name,
            ignore_changes=ignore_changes,
            __internal__=__internal__,
        )
        self.application_link_url = application_link_url
        self.webhook_url = webhook_url
        self.auth_header = auth_header

    def _secret_fields(self) -> set[str]:
        return {"auth_header", "webhook_url"}

    def _immutable_fields(self) -> set[str]:
        return set({})

    def _mutable_fields(self) -> set[str]:
        return {
            *super()._mutable_fields(),
            *{"application_link_url"},
        }


class EmailChannelAuthSmtpUserPassword(ApiSecretChangeNestedResource):
    """
    Credential configuration for an Email channel resource.

    Contains configuration based on SMTP user-password authentication.
    """

    def __init__(
        self,
        *,
        address: str,
        port: int,
        encryption: EmailChannelSmtpEncryption,
        username: str | None,
        password: str | None,
    ):
        """
        Constructor.

        :param address: The hostname or IP address of the SMTP server.
        :param port: Port number where the SMTP server is hosted.
        :param encryption: Connection encryption mode towards the SMTP server.
        :param username: Username to log in with the email provider.
        :param password: Password associated with the provided login username.
        """
        self.address = address
        self.port = port
        self.encryption = encryption
        self.username = username
        self.password = password

    def _api_variant_name(self) -> str:
        return "smtpUserPassword"

    def _immutable_fields(self) -> set[str]:
        return set({})

    def _mutable_fields(self) -> set[str]:
        return {"address", "port", "encryption", "username"}

    def _secret_fields(self) -> set[str]:
        return {"password"}

    def _mutable_nested_objects(
        self,
    ) -> dict[str, "Diffable | list[Diffable] | None"]:
        return {}


EmailChannelAuth = Union[EmailChannelAuthSmtpUserPassword]


class EmailChannel(Channel):
    """Configuration to send notifications via email."""

    def __init__(
        self,
        *,
        name: str,
        application_link_url: str,
        sender_address: str,
        recipient_addresses: list[str],
        auth: EmailChannelAuth,
        interactive_message_enabled: bool = True,
        display_name: str | None = None,
        ignore_changes: bool = False,
        __internal__: ResourceGraph | None = None,
    ):
        """
        Constructor.

        :param application_link_url: URL to your Validio application
            instance, used to send notifications.
        :param sender_address: The address to use to send
            emails. e.g. `validio@acme.com`
        :param recipient_addresses: One or more recipient addresses to
            receive email messages. e.g. `incidents@acme.com`
        :param auth: Credentials to use for authentication.
        :param interactive_message_enabled:
        :param display_name: Human-readable name for the channel. This name is
          visible in the UI and does not need to be unique.
        :param ignore_changes: If set to true, changes to the resource will be ignored.
        """
        super().__init__(
            name=name,
            display_name=display_name,
            ignore_changes=ignore_changes,
            __internal__=__internal__,
        )
        self.application_link_url = application_link_url
        self.sender_address = sender_address
        self.recipient_addresses = recipient_addresses
        self.auth = auth
        self.interactive_message_enabled = interactive_message_enabled

    def _immutable_fields(self) -> set[str]:
        return set({})

    def _mutable_fields(self) -> set[str]:
        return {
            *super()._mutable_fields(),
            *{
                "application_link_url",
                "sender_address",
                "recipient_addresses",
                "interactive_message_enabled",
            },
        }

    def _secret_fields(self) -> set[str]:
        return set()

    def _mutable_nested_objects(
        self,
    ) -> dict[str, "Diffable | list[Diffable] | None"]:
        return {"auth": self.auth}


class ServiceNowBasicAuth(ApiSecretChangeNestedResource):
    """Credential configuration for a ServiceNow channel."""

    def __init__(
        self,
        *,
        username: str,
        password: str,
    ):
        """
        Constructor.

        :param username: Username to log in with ServiceNow.
        :param password: Password associated with the provided login username.
        """
        self.username = username
        self.password = password

    def _api_variant_name(self) -> str:
        return "basicAuth"

    def _immutable_fields(self) -> set[str]:
        return set()

    def _mutable_fields(self) -> set[str]:
        return {"username"}

    def _secret_fields(self) -> set[str]:
        return {"password"}

    def _api_secret_change_input(self) -> dict[str, Any]:
        return {
            self._api_variant_name(): {
                "password": self.password,
            }
        }


class ServiceNowOAuth(ApiSecretChangeNestedResource):
    """Credential configuration for a ServiceNow channel."""

    def __init__(
        self,
        *,
        client_id: str,
        client_secret: str,
    ):
        """
        Constructor.

        :param client_id: Client ID to log in with OAuth at ServiceNow.
        :param client_secret: Client secret associated with the provided Client ID.
        """
        self.client_id = client_id
        self.client_secret = client_secret

    def _api_variant_name(self) -> str:
        return "oauth"

    def _immutable_fields(self) -> set[str]:
        return set()

    def _mutable_fields(self) -> set[str]:
        return {"client_id"}

    def _secret_fields(self) -> set[str]:
        return {"client_secret"}

    def _api_secret_change_input(self) -> dict[str, Any]:
        return {
            self._api_variant_name(): {
                "clientSecret": self.client_secret,
            }
        }


ServiceNowChannelAuth = ServiceNowBasicAuth | ServiceNowOAuth


class ServiceNowStatusMapping(Diffable):
    """Status mapping between Validio and ServiceNow.

    To ensure updates are synchronized correctly between Validio and ServiceNow
    when status on an incident changes this map is needed to set the right
    status.

    It's also used to determine what incidents are considered as open to tell if
    a new incident should be created or an existing one should be updated.
    """

    def __init__(
        self,
        triage: str = "1",
        investigating: str = "2",
        resolved: str = "6",
        service_now_active: list[str] | None = None,
        resolved_close_code: str = "Resolved by caller",
        not_an_anomaly_close_code: str = "Resolved by caller",
    ):
        """Constructor.

        :param triage: Equivalent status value to Validio's Triage in ServiceNow
        :param investigating: Equivalent status value to Validios' Investigating
            in ServiceNow
        :param resolved: Equivalent status value to Validios' Resolved in ServiceNow
        :param service_now_active: Other statuses used in ServiceNow that are
            considered as an active incident.
        :param resolved_close_code: ServiceNow close code to use when an incident
            is marked as Resolved in Validio.
        :param not_an_anomaly_close_code: ServieNow close code to use when an
            incident is marked as Not an anomaly in Validio.
        """
        self.triage = triage
        self.investigating = investigating
        self.resolved = resolved
        self.resolved_close_code = resolved_close_code
        self.not_an_anomaly_close_code = not_an_anomaly_close_code
        self.service_now_active = (
            ["3"] if service_now_active is None else service_now_active
        )

    def _immutable_fields(self) -> set[str]:
        return set()

    def _mutable_fields(self) -> set[str]:
        return {
            "triage",
            "investigating",
            "resolved",
            "service_now_active",
            "resolved_close_code",
            "not_an_anomaly_close_code",
        }

    def _mutable_nested_objects(self) -> dict[str, Diffable | list[Diffable] | None]:
        return {}

    @staticmethod
    def _decode(_: "DiffContext", obj: dict[str, Any]) -> "ServiceNowStatusMapping":
        cls = eval(obj[NODE_TYPE_FIELD_NAME])
        return cls(**{k: v for k, v in obj.items() if k != NODE_TYPE_FIELD_NAME})

    def _api_input(self) -> dict[str, Any]:
        return {to_camel(k): v for k, v in self.__dict__.items()}


class ServiceNowChannel(Channel):
    """Configuration to send notifications to ServiceNow."""

    def __init__(
        self,
        *,
        name: str,
        application_link_url: str,
        instance_url: str,
        webhook_secret: str,
        auth: ServiceNowChannelAuth,
        status_mapping: ServiceNowStatusMapping,
        display_name: str | None = None,
        ignore_changes: bool = False,
        __internal__: ResourceGraph | None = None,
    ):
        """
        Constructor.

        :param application_link_url: URL to your Validio application
            instance, used to send notifications.
        :param instance_url: The URL to the ServiceNow instance.
        :param webhook_secret: The secret to configure the ServiceNow webhook
            that will send events to Validio. Used to validate authenticity of
            request.
        :param auth: Credentials to use for authentication.
        :param status_mapping: Mapping between Validio and ServiceNow statuses.
        :param display_name: Human-readable name for the channel. This name is
          visible in the UI and does not need to be unique.
        :param ignore_changes: If set to true, changes to the resource will be ignored.
        """
        super().__init__(
            name=name,
            display_name=display_name,
            ignore_changes=ignore_changes,
            __internal__=__internal__,
        )

        self.application_link_url = application_link_url
        self.instance_url = instance_url
        self.webhook_secret = webhook_secret
        self.auth = auth
        self.status_mapping = _maybe_cast(status_mapping, ServiceNowStatusMapping)

    def _immutable_fields(self) -> set[str]:
        return set()

    def _mutable_fields(self) -> set[str]:
        return {
            *super()._mutable_fields(),
            *{
                "application_link_url",
                "instance_url",
            },
        }

    def _secret_fields(self) -> set[str]:
        return {"webhook_secret"}

    def _mutable_nested_objects(
        self,
    ) -> dict[str, "Diffable | list[Diffable] | None"]:
        return {
            "auth": self.auth,
            "status_mapping": self.status_mapping,
        }

    def _api_create_input(self, namespace: str, _: "DiffContext") -> Any:
        overrides = {
            "namespaceId": namespace,
            "statusMapping": self.status_mapping._api_input(),
            **{
                to_camel(f): obj._api_input()
                for f, obj in self._nested_secret_objects().items()
            },
        }

        return _api_create_input_params(
            resource=self,
            overrides=overrides,
        )

    def _api_update_input(self, _namespace: str, _ctx: "DiffContext") -> Any:
        overrides = {
            "statusMapping": self.status_mapping._api_input(),
            **{
                to_camel(f): obj._api_input()
                for f, obj in self._nested_secret_objects().items()
            },
        }

        return _api_update_input_params(
            resource=self,
            overrides=overrides,
        )
