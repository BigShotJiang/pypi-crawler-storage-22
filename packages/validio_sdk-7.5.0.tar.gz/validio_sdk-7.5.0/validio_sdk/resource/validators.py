"""Validator configuration."""

import re
from abc import ABC
from enum import Enum
from typing import TYPE_CHECKING, Any, cast

from validio_sdk._api.api import execute_mutation
from validio_sdk.client import Session
from validio_sdk.exception import ValidioError, ValidioResourceError
from validio_sdk.resource._diffable import Diffable
from validio_sdk.resource._resource import Resource
from validio_sdk.resource._serde import (
    _api_create_input_params,
    _api_update_input_params,
    _encode_resource,
    _maybe_cast,
    _maybe_cast_opt,
    get_config_node,
)
from validio_sdk.resource._util import _rename_dict_key
from validio_sdk.resource.enums import IncidentGroupPriority
from validio_sdk.resource.filters import Filter
from validio_sdk.resource.segmentations import Segmentation
from validio_sdk.resource.sources import (
    GcpBigQuerySource,
    SnowflakeSource,
    Source,
)
from validio_sdk.resource.tags import Tag
from validio_sdk.resource.thresholds import (
    DynamicThreshold,
    Threshold,
)
from validio_sdk.resource.windows import (
    GlobalWindow,
    TumblingWindow,
    Window,
)
from validio_sdk.scalars import JsonPointer

if TYPE_CHECKING:
    from validio_sdk.code._import import ImportContext
    from validio_sdk.resource._diff import DiffContext


class CategoricalDistributionMetric(str, Enum):
    """Metric for categorical distribution."""

    ADDED = "ADDED"
    CHANGED = "CHANGED"
    RELATIVE_ENTROPY = "RELATIVE_ENTROPY"
    REMOVED = "REMOVED"


class NumericDistributionMetric(str, Enum):
    """Metric for numeric distribution."""

    MAXIMUM_RATIO = "MAXIMUM_RATIO"
    MEAN_RATIO = "MEAN_RATIO"
    MINIMUM_RATIO = "MINIMUM_RATIO"
    RELATIVE_ENTROPY = "RELATIVE_ENTROPY"
    STANDARD_DEVIATION_RATIO = "STANDARD_DEVIATION_RATIO"
    SUM_RATIO = "SUM_RATIO"


class NumericMetric(str, Enum):
    """Metric for numeric."""

    MAX = "MAX"
    MEAN = "MEAN"
    MIN = "MIN"
    STD = "STD"
    SUM = "SUM"


class RelativeTimeMetric(str, Enum):
    """Metric for relative time."""

    MAXIMUM_DIFFERENCE = "MAXIMUM_DIFFERENCE"
    MEAN_DIFFERENCE = "MEAN_DIFFERENCE"
    MINIMUM_DIFFERENCE = "MINIMUM_DIFFERENCE"


class RelativeVolumeMetric(str, Enum):
    """Metric for relative volume."""

    COUNT_RATIO = "COUNT_RATIO"
    PERCENTAGE_RATIO = "PERCENTAGE_RATIO"


class VolumeMetric(str, Enum):
    """Metric for volume."""

    COUNT = "COUNT"
    DUPLICATES_COUNT = "DUPLICATES_COUNT"
    DUPLICATES_PERCENTAGE = "DUPLICATES_PERCENTAGE"
    PERCENTAGE = "PERCENTAGE"
    UNIQUE_COUNT = "UNIQUE_COUNT"
    UNIQUE_PERCENTAGE = "UNIQUE_PERCENTAGE"


class FieldMapping(Diffable):
    """Represents a field mapping between source and reference datasets."""

    def __init__(
        self,
        *,
        source_field: JsonPointer,
        reference_field: JsonPointer,
    ):
        """
        Constructor.

        :param source_field: Field from the source dataset.
        :param reference_field: Corresponding field from the reference
            dataset.
        """
        self.source_field = source_field
        self.reference_field = reference_field

    def _immutable_fields(self) -> set[str]:
        return {"source_field", "reference_field"}

    def _mutable_fields(self) -> set[str]:
        return set({})

    def _mutable_nested_objects(self) -> dict[str, Diffable | list[Diffable] | None]:
        return {}


class Reference(Diffable):
    """
    Represents configuration for reference validators.

    See the Validio docs for more info on reference configuration
    https://docs.validio.io/docs/reference-source-config
    """

    def __init__(
        self,
        history: int,
        offset: int,
        source: Source | None = None,
        window: Window | None = None,
        filter: Filter | None = None,
    ):
        """
        Constructor.

        :param history: Over how many windows metric will be calculated
            for the reference source
        :param offset: By how many windows in the past the reference
            calculation is shifted.
        :param source: The reference source to attach the validator to. (deprecated)
        :param window: The window in the reference source to attach the
            validator to. (deprecated)
        :param filter: Optional filter on the data processed from the
            reference source.
        """
        self.history = history
        self.offset = offset
        self.filter_name = None if filter is None else filter.name

        # deprecated
        self.source_name = source.name if source else None
        self.window_name = window.name if window else None

    def _immutable_fields(self) -> set[str]:
        return {"source_name", "window_name"}

    def _mutable_fields(self) -> set[str]:
        return {"history", "offset", "filter_name"}

    def _mutable_nested_objects(self) -> dict[str, Diffable | list[Diffable] | None]:
        return {}

    def _import_str(
        self,
        indent_level: int,
        import_ctx: "ImportContext",
        inits: list[tuple[str, Any, str | None]] | None = None,
        skip_fields: set[str] | None = None,
    ) -> str:
        inits = list(inits or [])
        skip_fields = (skip_fields or set()) | {"source", "window", "filter"}
        if self.filter_name:
            filter_ = import_ctx.get_variable(Filter, self.filter_name)
            inits.append(("filter", filter_, None))
        return super()._import_str(
            indent_level=indent_level,
            import_ctx=import_ctx,
            inits=inits,
            skip_fields=skip_fields,
        )

    def _reference_source_config_create_input(
        self,
        ctx: "DiffContext",
    ) -> dict[str, Any]:
        return {
            "offset": self.offset,
            "history": self.history,
            **self._filter_api_input(ctx),
        }

    def _reference_source_config_update_input(
        self, ctx: "DiffContext"
    ) -> dict[str, Any]:
        return {
            "offset": self.offset,
            "history": self.history,
            **self._filter_api_input(ctx),
        }

    def _filter_api_input(
        self,
        ctx: "DiffContext",
    ) -> dict[str, Any]:
        return {
            "filterId": (
                ctx.filters[self.filter_name]._must_id()
                if self.filter_name is not None
                else None
            )
        }

    @staticmethod
    def _decode(
        ctx: "DiffContext",
        validator_name: str,
        obj: dict[str, Any],
    ) -> "Reference":
        if filter_name := obj.pop("filter_name"):
            obj["filter"] = Validator._decode_filter(ctx, validator_name, filter_name)

        # Remove the deprecated fields for resources that are not compatible
        # with the constructor. Note: we don't decode these because they are
        # not supported anymore.
        del obj["source_name"]
        del obj["window_name"]

        return Reference(**obj)


class SlideConfig(Diffable):
    """Sliding window configuration for validators."""

    def __init__(
        self,
        *,
        history: int,
    ):
        """
        Constructor.

        :param history: Over how many additional windows metric
            will be calculated for the validator.
        """
        self.history = history

    def _immutable_fields(self) -> set[str]:
        return set({})

    def _mutable_fields(self) -> set[str]:
        return {"history"}

    def _mutable_nested_objects(self) -> dict[str, Diffable | list[Diffable] | None]:
        return {}

    def _api_input(self) -> dict[str, Any]:
        return {"history": self.history}


class Validator(Resource, ABC):
    """Base class for a validator resources.

    https://docs.validio.io/docs/validators
    """

    def __init__(
        self,
        name: str,
        window: Window,
        segmentation: Segmentation,
        display_name: str | None,
        threshold: Threshold | None = None,
        owner: str | None = None,
        filter: Filter | None = None,
        reference: Reference | None = None,
        initialize_with_backfill: bool = False,
        ignore_changes: bool = False,
        description: str | None = None,
        tags: list[Tag] | None = None,
        priority: IncidentGroupPriority | None = None,
    ):
        """
        Constructor.

        :param name: Unique resource name assigned to the validator.
        :param window: The window to attach the validator to.
        :param segmentation: The segmentation to attach the validator to.
        :param threshold: A threshold configuration to attach to the validator.
            Note: While a threshold's configuration can be updated, it is not
            possible to change the threshold type after the validator has been
            created.
        :param filter: Optional filter to attach to the validator.
            https://docs.validio.io/docs/validators#filters
        :param reference: Configuration for reference validators
        :param initialize_with_backfill: If set to true, will wait for an
            explicit source backfill before the validator can start
            processing data.
            https://docs.validio.io/docs/validators#backfill
        :param display_name: Human-readable name for the validator. This name is
          visible in the UI and does not need to be unique.
        :param owner: User email address of the validator owner.
        :param ignore_changes: If set to true, changes to the resource will be ignored
        :param description: Description of the resource.
        :param tags: Tags to add to the resource
        :param priority: Priority to assign to incidents created by this validator.
        """
        super().__init__(
            name=name,
            display_name=display_name,
            ignore_changes=ignore_changes,
            __internal__=window._resource_graph,
        )

        if window.source_name != segmentation.source_name:
            raise ValidioResourceError(
                self,
                f"window source '{window.source_name}' does not match "
                f"segmentation source '{segmentation.source_name}'",
            )

        source = window._resource_graph._find_source(window.source_name)
        if not source:
            raise ValidioResourceError(
                self,
                f"missing source '{window.source_name}' for window '{window.name}'",
            )

        self.owner = owner
        self.source_name: str = source.name
        self.window_name: str = window.name
        self.segmentation_name: str = segmentation.name
        self.filter_name = None if filter is None else filter.name

        self.threshold = threshold or DynamicThreshold._default_value()
        self.reference = reference
        self.initialize_with_backfill: bool = initialize_with_backfill
        self.description = description

        self.priority = (
            priority
            if isinstance(priority, (type(None), IncidentGroupPriority))
            else IncidentGroupPriority(priority)
        )

        self.tag_names = [t.name for t in tags] if tags is not None else []
        # Ensure always sorted
        self.tag_names.sort()

        source.add(self.name, self)
        if isinstance(self.threshold, DynamicThreshold):
            if self.threshold.algorithm:
                self.add_deprecation(
                    "Validator's threshold sets the 'algorithm' argument. "
                    "This argument is ignored and will be removed in a "
                    "future release."
                )
            del self.threshold.algorithm

        if self.reference is not None and (
            self.reference.source_name is not None
            or self.reference.window_name is not None
        ):
            self.reference.source_name = None
            self.reference.window_name = None
            self.add_deprecation(
                "Reference for validator uses the deprecated "
                "source and window configuration. "
                "This will be unsupported in a future release. "
                "Please remove source and window fields "
                "from reference configuration."
            )

        self._check_threshold_deprecation()

    def _check_threshold_deprecation(self) -> None:
        # TODO(VR-3875): Fully remove after deprecation warning period.
        self._check_and_delete_arg_deprecation_on_child(self.threshold)

    def _mutable_nested_objects(self) -> dict[str, Diffable | list[Diffable] | None]:
        objects: dict[str, Diffable | list[Diffable] | None] = {
            "threshold": self.threshold,
        }

        if hasattr(self, "slide_config"):
            objects["slide_config"] = self.slide_config

        if self.reference:
            objects["reference"] = self.reference

        return objects

    def _nested_mutable_parents(self) -> dict[str, str | None]:
        if not self.reference:
            return {}

        return {"filter_name": self.reference.filter_name}

    def _supports_filter(self) -> bool:
        """Returns true if the validator supports filters."""
        return True

    def _supports_metric(self) -> bool:
        """Returns true if the validator supports metric property."""
        return True

    def _immutable_fields(self) -> set[str]:
        fields = {
            "source_name",
            "window_name",
            "segmentation_name",
        }

        if self._supports_metric():
            fields.add("metric")

        return fields

    def _mutable_fields(self) -> set[str]:
        return {
            *super()._mutable_fields(),
            *{"description", "filter_name", "owner", "priority", "tag_names"},
        }

    def _ignored_fields(self) -> set[str]:
        return {
            # initialize_with_backfill is treated as a hint on the backend.
            # So what the client sets is not necessarily what the server will
            # return back. The field is also unused after validator creation
            # so that it doesn't matter to diff it. So we ignore it always.
            "initialize_with_backfill",
        }

    def _replace_on_type_change_fields(self) -> set[str]:
        # We can't switch threshold type e.g. going from dynamic to fixed
        # threshold without re-creating the validator.
        return {"threshold"}

    def resource_class_name(self) -> str:
        """Returns the base class name."""
        return "Validator"

    def _source_config_create_input(self, ctx: "DiffContext") -> dict[str, Any]:
        source_id = ctx.sources[self.source_name]._id.value
        segmentation_id = ctx.segmentations[self.segmentation_name]._id.value
        window_id = ctx.windows[self.window_name]._id.value

        return {
            "sourceId": source_id,
            "segmentationId": segmentation_id,
            "windowId": window_id,
            **self._filter_api_input(ctx),
        }

    def _source_config_update_input(self, ctx: "DiffContext") -> dict[str, Any]:
        return self._filter_api_input(ctx)

    def _filter_api_input(
        self,
        ctx: "DiffContext",
    ) -> dict[str, Any]:
        return {
            "filterId": (
                ctx.filters[self.filter_name]._id.value
                if self.filter_name is not None
                else None
            )
        }

    def _api_skip_fields(self) -> set[str]:
        return {"owner", "tagNames"}

    def _api_create_input(self, _namespace: str, ctx: "DiffContext") -> Any:
        owner_id = ctx.user_email_ids.get(self.owner) if self.owner else None

        overrides = {
            "sourceConfig": self._source_config_create_input(ctx),
            "tagIds": [ctx.tags[name]._must_id() for name in self.tag_names],
            "ownerId": owner_id,
            **self._slide_config_api_input(),
            **self._api_create_input_overrides(ctx),
        }

        if self.reference is not None:
            overrides["referenceSourceConfig"] = (
                self.reference._reference_source_config_create_input(ctx)
            )

        return {
            **_api_create_input_params(
                self,
                skip_fields=self._api_skip_fields(),
                overrides=overrides,
            ),
            "threshold": self.threshold._api_create_input(),
        }

    def _api_update_input(self, _namespace: str, ctx: "DiffContext") -> Any:
        owner_id = ctx.user_email_ids.get(self.owner) if self.owner else None

        overrides: dict[str, Any] = {
            "tagIds": [ctx.tags[name]._must_id() for name in self.tag_names],
            "ownerId": owner_id,
            **self._slide_config_api_input(),
            **self._api_update_input_overrides(ctx),
        }

        if self._supports_filter():
            overrides["sourceConfig"] = self._source_config_update_input(ctx)

        if self.reference is not None:
            overrides["referenceSourceConfig"] = (
                self.reference._reference_source_config_update_input(ctx)
            )

        return _api_update_input_params(
            self,
            skip_fields=self._api_skip_fields(),
            overrides=overrides,
        )

    def _slide_config_api_input(self) -> dict[str, Any]:
        if hasattr(self, "slide_config"):
            return {
                "slideConfig": (
                    self.slide_config._api_input()
                    if (
                        self.slide_config and isinstance(self.slide_config, SlideConfig)
                    )
                    else None
                )
            }

        return {}

    def _api_create_input_overrides(self, _ctx: "DiffContext") -> dict[str, Any]:
        """Override to provide validator-specific create API input fields."""
        return {}

    def _api_update_input_overrides(self, _ctx: "DiffContext") -> dict[str, Any]:
        """Override to provide validator-specific update API input fields."""
        return {}

    def _api_create_arguments(self) -> dict[str, str]:
        return {
            "input": f"{self.__class__.__name__}CreateInput!",
            "threshold": f"{self.threshold.__class__.__name__}CreateInput!",
        }

    def _api_create_method_name(self) -> str:
        name = self.__class__.__name__
        lc_first = name[0].lower() + name[1:]

        return f"{lc_first}With{self.threshold.__class__.__name__}Create"

    async def _api_update(
        self,
        namespace: str,
        ctx: "DiffContext",
        session: Session,
        show_secrets: bool,
    ) -> None:
        # Update the validator
        await super()._api_update(
            namespace,
            ctx,
            session=session,
            show_secrets=show_secrets,
        )

        # For validators, update the threshold as well. Those have
        # an explicit update api.
        method_name = f"validatorWith{self.threshold.__class__.__name__}Update"
        arguments = {
            "input": f"ValidatorWith{self.threshold.__class__.__name__}UpdateInput!"
        }
        api_input = {"input": self.threshold._api_update_input(self._must_id())}

        # We catch and re-throw any error with the resource context.
        try:
            response = await execute_mutation(
                session,
                method_name,
                arguments,
                api_input,
                resource_class_name=self.resource_class_name().lower(),
                returns="id",
            )
        except Exception as e:
            raise ValidioResourceError(self, str(e))

        self._check_graphql_response(
            response=response,
            method_name=method_name,
            response_field=None,
        )

    def _encode(self) -> dict[str, object]:
        skip_fields = {"reference"} if self.reference is None else set({})
        skip_fields.add("filter")

        return _encode_resource(self, skip_fields=skip_fields)

    @staticmethod
    def _decode_pending(ctx: "DiffContext") -> None:
        for name, (cls, obj) in ctx.pending_validators_raw.items():
            ctx.validators[name] = Validator._decode(ctx, cls, obj)

    @staticmethod
    def _decode(
        ctx: "DiffContext",
        cls: type,
        obj: dict[str, Any],
    ) -> "Validator":
        obj = cast(dict[str, Any], get_config_node(obj))

        validator_name = obj["name"]

        # Drop source_name since it's not part of the constructor
        # but rather derived from the window.
        del obj["source_name"]

        obj["window"] = Validator._decode_window(
            ctx, validator_name, obj.pop("window_name")
        )

        obj["segmentation"] = Validator._decode_segmentation(
            ctx, validator_name, obj.pop("segmentation_name")
        )

        if filter_name := obj.pop("filter_name"):
            obj["filter"] = Validator._decode_filter(
                ctx,
                validator_name,
                filter_name,
            )

        if "reference_source_name" in obj:
            obj["reference_source"] = Validator._decode_source(
                ctx, validator_name, obj.pop("reference_source_name")
            )
        if "reference_window_name" in obj:
            obj["reference_window"] = Validator._decode_window(
                ctx, validator_name, obj.pop("reference_window_name")
            )
        if "reference_filter_name" in obj:
            obj["reference_filter"] = Validator._decode_filter(
                ctx, validator_name, obj.pop("reference_filter_name")
            )

        obj["threshold"] = Threshold._decode(obj.pop("threshold"))

        if "reference" in obj:
            obj["reference"] = Reference._decode(
                ctx,
                validator_name,
                obj["reference"],
            )

        obj["tags"] = [ctx.tags[name] for name in obj.pop("tag_names") or []]

        return cls(**obj)

    @staticmethod
    def _decode_source(
        ctx: "DiffContext", validator_name: str, source_name: str
    ) -> "Source":
        if source_name not in ctx.sources:
            raise ValidioError(
                f"failed to decode validator {validator_name}: "
                f"missing source {source_name}"
            )
        return ctx.sources[source_name]

    @staticmethod
    def _decode_window(
        ctx: "DiffContext", validator_name: str, window_name: str
    ) -> "Window":
        if window_name not in ctx.windows:
            raise ValidioError(
                f"failed to decode validator {validator_name}: "
                f"missing window {window_name}"
            )
        return ctx.windows[window_name]

    @staticmethod
    def _decode_segmentation(
        ctx: "DiffContext", validator_name: str, segmentation_name: str
    ) -> "Segmentation":
        if segmentation_name not in ctx.segmentations:
            raise ValidioError(
                f"failed to decode validator {validator_name}: "
                f"missing segmentation {segmentation_name}"
            )
        return ctx.segmentations[segmentation_name]

    @staticmethod
    def _decode_filter(
        ctx: "DiffContext", validator_name: str, filter_name: str
    ) -> Filter:
        if filter_name not in ctx.filters:
            raise ValidioError(
                f"failed to decode validator {validator_name}: "
                f"missing filter {filter_name}"
            )
        return ctx.filters[filter_name]

    @staticmethod
    def has_cross_source_references() -> bool:
        """Returns whether the validator references resources from other sources."""
        return False


class NumericValidator(Validator):
    """A Numeric validator resource.

    https://docs.validio.io/docs/numeric
    """

    def __init__(
        self,
        *,
        name: str,
        window: Window,
        segmentation: Segmentation,
        metric: NumericMetric,
        source_field: JsonPointer,
        slide_config: SlideConfig | None = None,
        threshold: Threshold | None = None,
        filter: Filter | None = None,
        initialize_with_backfill: bool = False,
        display_name: str | None = None,
        owner: str | None = None,
        ignore_changes: bool = False,
        description: str | None = None,
        tags: list[Tag] | None = None,
        priority: IncidentGroupPriority | None = None,
    ):
        """
        Constructor.

        :param source_field: Field to monitor.
        :param slide_config: Configuration for sliding validators
        :param metric: Metric type for the validator.
        :param display_name: Human-readable name for the validator. This name is
          visible in the UI and does not need to be unique.
        :param owner: User email address of the validator owner.
        :param ignore_changes: If set to true, changes to the resource will be ignored
        :param description: Description of the resource.
        :param tags: Tags to add to the resource
        :param priority: Priority to assign to incidents created by this validator.
        """
        super().__init__(
            name=name,
            window=window,
            segmentation=segmentation,
            threshold=threshold,
            filter=filter,
            initialize_with_backfill=initialize_with_backfill,
            display_name=display_name,
            owner=owner,
            ignore_changes=ignore_changes,
            description=description,
            tags=tags,
            priority=priority,
        )

        self.metric = NumericMetric(metric) if isinstance(metric, str) else metric
        self.source_field: str = source_field
        self.slide_config = _maybe_cast_opt(slide_config, SlideConfig)

    def _immutable_fields(self) -> set[str]:
        return {
            *super()._immutable_fields(),
            *{
                "source_field",
                "metric",
            },
        }


class VolumeValidator(Validator):
    """A Volume validator resource.

    https://docs.validio.io/docs/volume
    """

    def __init__(
        self,
        *,
        name: str,
        window: Window,
        segmentation: Segmentation,
        metric: VolumeMetric,
        source_fields: list[str] | None = None,
        slide_config: SlideConfig | None = None,
        threshold: Threshold | None = None,
        filter: Filter | None = None,
        initialize_with_backfill: bool = False,
        metadata_enabled: bool = False,
        display_name: str | None = None,
        owner: str | None = None,
        ignore_changes: bool = False,
        # Deprecated.
        optional_source_field: JsonPointer | None = None,
        description: str | None = None,
        tags: list[Tag] | None = None,
        priority: IncidentGroupPriority | None = None,
    ):
        """
        Constructor.

        :param source_fields: List of fields for the DUPLICATES and UNIQUE metrics.
        :param slide_config: Configuration for sliding validators
        :param metric: Metric type for the validator.
        :param display_name: Human-readable name for the validator. This name is
          visible in the UI and does not need to be unique.
        :param owner: User email address of the validator owner.
        :param ignore_changes: If set to true, changes to the resource will be ignored
        :param optional_source_field: Deprecated.
        :param description: Description of the resource.
        :param tags: Tags to add to the resource
        :param priority: Priority to assign to incidents created by this validator.
        """
        super().__init__(
            name=name,
            window=window,
            segmentation=segmentation,
            threshold=threshold,
            filter=filter,
            initialize_with_backfill=initialize_with_backfill,
            display_name=display_name,
            owner=owner,
            ignore_changes=ignore_changes,
            description=description,
            tags=tags,
            priority=priority,
        )

        self.metric = (
            metric if isinstance(metric, VolumeMetric) else VolumeMetric(metric)
        )

        self.slide_config = _maybe_cast_opt(slide_config, SlideConfig)

        self.metadata_enabled = metadata_enabled
        if metadata_enabled:
            _validate_metadata_validator(self, window, segmentation, self.metric)

        self.optional_source_field: str | None = None
        if optional_source_field:
            self.optional_source_field = optional_source_field

        self.source_fields = source_fields if source_fields else []

    def _immutable_fields(self) -> set[str]:
        return {
            *super()._immutable_fields(),
            *{"optional_source_field", "source_fields", "metric", "metadata_enabled"},
        }

    def _api_create_input(self, namespace: str, ctx: "DiffContext") -> Any:
        api_input = super()._api_create_input(namespace, ctx)
        _rename_dict_key(api_input["input"], "optionalSourceField", "sourceField")

        return api_input


class NumericDistributionValidator(Validator):
    """A Numeric distribution validator resource.

    https://docs.validio.io/docs/numeric-distribution
    """

    def __init__(
        self,
        *,
        name: str,
        window: Window,
        segmentation: Segmentation,
        metric: NumericDistributionMetric,
        source_field: JsonPointer,
        reference_source_field: JsonPointer,
        reference: Reference,
        threshold: Threshold | None = None,
        filter: Filter | None = None,
        initialize_with_backfill: bool = False,
        display_name: str | None = None,
        owner: str | None = None,
        ignore_changes: bool = False,
        description: str | None = None,
        tags: list[Tag] | None = None,
        priority: IncidentGroupPriority | None = None,
    ):
        """
        Constructor.

        :param source_field: Field to monitor.
        :param reference_source_field: Reference field to compare against.
        :param metric: Metric type for the validator.
        :param display_name: Human-readable name for the validator. This name is
          visible in the UI and does not need to be unique.
        :param owner: User email address of the validator owner.
        :param ignore_changes: If set to true, changes to the resource will be ignored
        :param description: Description of the resource.
        :param tags: Tags to add to the resource
        :param priority: Priority to assign to incidents created by this validator.
        """
        super().__init__(
            name=name,
            window=window,
            segmentation=segmentation,
            threshold=threshold,
            reference=reference,
            filter=filter,
            initialize_with_backfill=initialize_with_backfill,
            display_name=display_name,
            owner=owner,
            ignore_changes=ignore_changes,
            description=description,
            tags=tags,
            priority=priority,
        )

        self.metric = (
            metric
            if isinstance(metric, NumericDistributionMetric)
            else NumericDistributionMetric(metric)
        )

        self.source_field: str = source_field
        self.reference_source_field: str = reference_source_field

    def _immutable_fields(self) -> set[str]:
        return {
            *super()._immutable_fields(),
            *{
                "source_field",
                "reference_source_field",
            },
        }


class CategoricalDistributionValidator(Validator):
    """A Categorical distribution validator resource.

    https://docs.validio.io/docs/categorical-distribution
    """

    def __init__(
        self,
        *,
        name: str,
        window: Window,
        segmentation: Segmentation,
        metric: CategoricalDistributionMetric,
        source_field: JsonPointer,
        reference_source_field: JsonPointer,
        reference: Reference,
        threshold: Threshold | None = None,
        filter: Filter | None = None,
        initialize_with_backfill: bool = False,
        display_name: str | None = None,
        owner: str | None = None,
        ignore_changes: bool = False,
        description: str | None = None,
        tags: list[Tag] | None = None,
        priority: IncidentGroupPriority | None = None,
    ):
        """
        Constructor.

        :param source_field: Field to monitor.
        :param reference_source_field: Reference field to
            compare against.
        :param metric: Metric type for the validator.
        :param display_name: Human-readable name for the validator. This name is
          visible in the UI and does not need to be unique.
        :param owner: User email address of the validator owner.
        :param ignore_changes: If set to true, changes to the resource will be ignored
        :param description: Description of the resource.
        :param tags: Tags to add to the resource
        :param priority: Priority to assign to incidents created by this validator.
        """
        super().__init__(
            name=name,
            window=window,
            segmentation=segmentation,
            threshold=threshold,
            reference=reference,
            filter=filter,
            initialize_with_backfill=initialize_with_backfill,
            display_name=display_name,
            owner=owner,
            ignore_changes=ignore_changes,
            description=description,
            tags=tags,
            priority=priority,
        )

        self.metric = (
            metric
            if isinstance(metric, CategoricalDistributionMetric)
            else CategoricalDistributionMetric(metric)
        )

        self.source_field: str = source_field
        self.reference_source_field: str = reference_source_field

    def _immutable_fields(self) -> set[str]:
        return {
            *super()._immutable_fields(),
            *{
                "source_field",
                "reference_source_field",
            },
        }


class ReferentialIntegrityValidator(Validator):
    """A Referential Integrity validator resource.

    Validates referential integrity by matching records between source
    and reference datasets using key fields, with optional value field
    comparison for data consistency checks.

    https://docs.validio.io/docs/referential-integrity
    """

    def __init__(
        self,
        *,
        name: str,
        window: Window,
        segmentation: Segmentation,
        key_fields: list[FieldMapping],
        value_fields: list[FieldMapping] | None = None,
        reference_source: Source,
        reference_window: Window,
        reference_filter: Filter | None = None,
        threshold: Threshold | None = None,
        filter: Filter | None = None,
        initialize_with_backfill: bool = False,
        display_name: str | None = None,
        owner: str | None = None,
        ignore_changes: bool = False,
        description: str | None = None,
        tags: list[Tag] | None = None,
        priority: IncidentGroupPriority | None = None,
    ):
        """
        Constructor.

        :param key_fields: Fields used to match records between source
            and reference datasets. These act as join keys (e.g.,
            customer_id, order_id).
        :param value_fields: Optional fields to compare for data
            consistency after records are matched (e.g., customer_name,
            amount).
        :param reference_source: The reference source to compare with.
        :param reference_window: The window from the reference source.
        :param reference_filter: Optional filter on the data processed
            from the reference source.
        :param display_name: Human-readable name for the validator.
            This name is visible in the UI and does not need to be
            unique.
        :param owner: User email address of the validator owner.
        :param ignore_changes: If set to true, changes to the resource
            will be ignored
        :param description: Description of the resource.
        :param tags: Tags to add to the resource
        :param priority: Priority to assign to incidents created by
            this validator.
        """
        super().__init__(
            name=name,
            window=window,
            segmentation=segmentation,
            threshold=threshold,
            filter=filter,
            initialize_with_backfill=initialize_with_backfill,
            display_name=display_name,
            owner=owner,
            ignore_changes=ignore_changes,
            description=description,
            tags=tags,
            priority=priority,
        )

        self.key_fields = sorted(
            [_maybe_cast(f, FieldMapping) for f in key_fields],
            key=lambda f: (f.source_field, f.reference_field),
        )

        self.value_fields = None
        if value_fields:
            self.value_fields = sorted(
                [_maybe_cast(f, FieldMapping) for f in value_fields],
                key=lambda f: (f.source_field, f.reference_field),
            )

        if not self.key_fields:
            raise ValidioResourceError(
                self,
                "key_fields must contain at least one field mapping",
            )

        self.reference_source_name = reference_source.name
        self.reference_window_name = reference_window.name
        self.reference_filter_name = (
            None if reference_filter is None else reference_filter.name
        )

    def _supports_metric(self) -> bool:
        return False

    def _immutable_fields(self) -> set[str]:
        return {
            *super()._immutable_fields(),
            *{
                "reference_source_name",
                "reference_window_name",
            },
        }

    def _mutable_fields(self) -> set[str]:
        return {
            *super()._mutable_fields(),
            *{"reference_filter_name"},
        }

    def _immutable_nested_objects(self) -> dict[str, Diffable | list[Diffable] | None]:
        return {
            **super()._immutable_nested_objects(),
            "key_fields": self.key_fields,  # type: ignore
            "value_fields": self.value_fields,  # type: ignore
        }

    def _api_skip_fields(self) -> set[str]:
        return {
            *super()._api_skip_fields(),
            "referenceSourceName",
            "referenceWindowName",
            "referenceFilterName",
        }

    def _api_create_input_overrides(self, ctx: "DiffContext") -> dict[str, Any]:
        key_fields_input = [
            {
                "sourceField": field.source_field,
                "referenceField": field.reference_field,
            }
            for field in self.key_fields
        ]

        value_fields_input = (
            [
                {
                    "sourceField": field.source_field,
                    "referenceField": field.reference_field,
                }
                for field in self.value_fields
            ]
            if self.value_fields is not None
            else None
        )

        return {
            "keyFields": key_fields_input,
            "valueFields": value_fields_input,
            "referenceSourceId": ctx.sources[self.reference_source_name]._must_id(),
            "referenceWindowId": ctx.windows[self.reference_window_name]._must_id(),
            "referenceFilterId": (
                ctx.filters[self.reference_filter_name]._must_id()
                if self.reference_filter_name is not None
                else None
            ),
        }

    def _api_update_input_overrides(self, ctx: "DiffContext") -> dict[str, Any]:
        return {
            "referenceFilterId": ctx.filters[self.reference_filter_name]._must_id()
            if self.reference_filter_name is not None
            else None
        }

    @staticmethod
    def has_cross_source_references() -> bool:
        """Returns whether the validator references resources from other sources."""
        return True

    def _import_str(
        self,
        indent_level: int,
        import_ctx: "ImportContext",
        inits: list[tuple[str, Any, str | None]] | None = None,
        skip: set[str] | None = None,
    ) -> str:
        inits = list(inits or [])
        skip = (skip or set()) | {
            "reference_source_name",
            "reference_window_name",
            "reference_filter_name",
        }

        ref_source = import_ctx.get_variable(Source, self.reference_source_name)
        inits.append(("reference_source", ref_source, None))

        ref_window = import_ctx.get_variable(Window, self.reference_window_name)
        inits.append(("reference_window", ref_window, None))

        if self.reference_filter_name:
            ref_filter = import_ctx.get_variable(Filter, self.reference_filter_name)
            inits.append(("reference_filter", ref_filter, None))

        return super()._import_str(
            indent_level=indent_level,
            import_ctx=import_ctx,
            inits=inits,
            skip=skip,
        )


class RelativeVolumeValidator(Validator):
    """A Relative volume validator resource.

    https://docs.validio.io/docs/relative-volume
    """

    def __init__(
        self,
        *,
        name: str,
        window: Window,
        segmentation: Segmentation,
        metric: RelativeVolumeMetric,
        reference: Reference,
        source_field: JsonPointer | None = None,
        reference_source_field: JsonPointer | None = None,
        threshold: Threshold | None = None,
        filter: Filter | None = None,
        initialize_with_backfill: bool = False,
        display_name: str | None = None,
        owner: str | None = None,
        ignore_changes: bool = False,
        description: str | None = None,
        tags: list[Tag] | None = None,
        priority: IncidentGroupPriority | None = None,
    ):
        """
        Constructor.

        :param source_field: Field to monitor.
        :param reference_source_field: Reference field to compare
            against.
        :param metric: Metric type for the validator.
        :param display_name: Human-readable name for the validator. This name is
          visible in the UI and does not need to be unique.
        :param owner: User email address of the validator owner.
        :param ignore_changes: If set to true, changes to the resource will be ignored
        :param description: Description of the resource.
        :param tags: Tags to add to the resource
        :param priority: Priority to assign to incidents created by this validator.
        """
        super().__init__(
            name=name,
            window=window,
            segmentation=segmentation,
            threshold=threshold,
            reference=reference,
            filter=filter,
            initialize_with_backfill=initialize_with_backfill,
            display_name=display_name,
            owner=owner,
            ignore_changes=ignore_changes,
            description=description,
            tags=tags,
            priority=priority,
        )

        self.metric = (
            metric
            if isinstance(metric, RelativeVolumeMetric)
            else RelativeVolumeMetric(metric)
        )
        self.source_field = source_field
        self.reference_source_field = reference_source_field

    def _immutable_fields(self) -> set[str]:
        return {
            *super()._immutable_fields(),
            *{
                "source_field",
                "reference_source_field",
            },
        }


class RelativeTimeValidator(Validator):
    """A Relative time validator resource.

    https://docs.validio.io/docs/relative-time
    """

    def __init__(
        self,
        *,
        name: str,
        window: Window,
        segmentation: Segmentation,
        metric: RelativeTimeMetric,
        source_field_minuend: JsonPointer,
        source_field_subtrahend: JsonPointer,
        threshold: Threshold | None = None,
        filter: Filter | None = None,
        initialize_with_backfill: bool = False,
        display_name: str | None = None,
        owner: str | None = None,
        ignore_changes: bool = False,
        description: str | None = None,
        tags: list[Tag] | None = None,
        priority: IncidentGroupPriority | None = None,
    ):
        """
        Constructor.

        :param source_field_minuend: Timestamp field to monitor.
        :param source_field_subtrahend: Reference timestamp to subtract.
        :param metric: Metric type for the validator.
        :param display_name: Human-readable name for the validator. This name is
          visible in the UI and does not need to be unique.
        :param owner: User email address of the validator owner.
        :param ignore_changes: If set to true, changes to the resource will be ignored
        :param description: Description of the resource.
        :param tags: Tags to add to the resource
        :param priority: Priority to assign to incidents created by this validator.
        """
        super().__init__(
            name=name,
            window=window,
            segmentation=segmentation,
            threshold=threshold,
            filter=filter,
            initialize_with_backfill=initialize_with_backfill,
            display_name=display_name,
            owner=owner,
            ignore_changes=ignore_changes,
            description=description,
            tags=tags,
            priority=priority,
        )

        self.metric = (
            metric
            if isinstance(metric, RelativeTimeMetric)
            else RelativeTimeMetric(metric)
        )
        self.source_field_minuend = source_field_minuend
        self.source_field_subtrahend = source_field_subtrahend

    def _immutable_fields(self) -> set[str]:
        return {
            *super()._immutable_fields(),
            *{
                "source_field_minuend",
                "source_field_subtrahend",
            },
        }


class FreshnessValidator(Validator):
    """A Freshness validator resource.

    https://docs.validio.io/docs/freshness
    """

    def __init__(
        self,
        *,
        name: str,
        window: TumblingWindow,
        segmentation: Segmentation,
        threshold: Threshold | None = None,
        filter: Filter | None = None,
        initialize_with_backfill: bool = False,
        metadata_enabled: bool = False,
        source_field: JsonPointer | None = None,
        display_name: str | None = None,
        owner: str | None = None,
        ignore_changes: bool = False,
        description: str | None = None,
        tags: list[Tag] | None = None,
        priority: IncidentGroupPriority | None = None,
    ):
        """Constructor.

        :param name: Unique resource name assigned to the validator.
        :param window: The window to attach the validator to.
        :param segmentation: The segmentation to attach the validator to.
        :param threshold: A threshold configuration to attach to the validator.
            Note: While a threshold's configuration can be updated, it is not
            possible to change the threshold type after the validator has been
            created.
        :param filter: Optional filter to attach to the validator.
            https://docs.validio.io/docs/validators#filters
        :param initialize_with_backfill: If set to true, will wait for an
            explicit source backfill before the validator can start
            processing data.
            https://docs.validio.io/docs/validators#backfill
        :param metadata_enabled: Compute freshness on metadata rather than
            source data.
        :param source_field: Field to monitor.
        :param display_name: Human-readable name for the validator. This name is
          visible in the UI and does not need to be unique.
        :param owner: User email address of the validator owner.
        :param ignore_changes: If set to true, changes to the resource will be ignored
        :param description: Description of the resource.
        :param tags: Tags to add to the resource
        :param priority: Priority to assign to incidents created by this validator.
        """
        super().__init__(
            name=name,
            window=window,
            segmentation=segmentation,
            threshold=threshold,
            filter=filter,
            initialize_with_backfill=initialize_with_backfill,
            display_name=display_name,
            owner=owner,
            ignore_changes=ignore_changes,
            description=description,
            tags=tags,
            priority=priority,
        )

        self.source_field = source_field

        self.metadata_enabled = metadata_enabled
        if metadata_enabled:
            _validate_metadata_validator(self, window, segmentation)

    def _supports_metric(self) -> bool:
        return False

    def _immutable_fields(self) -> set[str]:
        return {
            *super()._immutable_fields(),
            *{"source_field", "metadata_enabled"},
        }


class SqlValidator(Validator):
    """A SQL validator resource.

    https://docs.validio.io/docs/custom-sql
    """

    def __init__(
        self,
        *,
        name: str,
        window: TumblingWindow,
        segmentation: Segmentation,
        query: str,
        threshold: Threshold | None = None,
        initialize_with_backfill: bool = False,
        display_name: str | None = None,
        owner: str | None = None,
        ignore_changes: bool = False,
        description: str | None = None,
        tags: list[Tag] | None = None,
        priority: IncidentGroupPriority | None = None,
    ):
        """Constructor.

        :param query: SQL query to execute.
        :param display_name: Human-readable name for the validator. This name is
          visible in the UI and does not need to be unique.
        :param ignore_changes: If set to true, changes to the resource will be ignored
        :param description: Description of the resource.
        :param tags: Tags to add to the resource
        :param priority: Priority to assign to incidents created by this validator.
        """
        super().__init__(
            name=name,
            window=window,
            segmentation=segmentation,
            threshold=threshold,
            initialize_with_backfill=initialize_with_backfill,
            display_name=display_name,
            owner=owner,
            ignore_changes=ignore_changes,
            description=description,
            tags=tags,
            priority=priority,
        )

        for r in [
            r"({{\s*table\s*}})",
            r"({{\s*select_columns\s*}})",
            r"({{\s*group_by_columns\s*}})",
        ]:
            match = re.search(r, query)
            if match:
                self.add_deprecation(
                    f"SQL syntax {match.groups(1)[0]} is deprecated "
                    f"and support will be removed in a future release. "
                    f"Please see the SQL validator documentation for the "
                    f"alternative SQL syntax: "
                    f"https://docs.validio.io/docs/custom-sql"
                )
                break

        self.query = query

    def _supports_filter(self) -> bool:
        return False

    def _supports_metric(self) -> bool:
        return False

    def _mutable_nested_objects(self) -> dict[str, Diffable | list[Diffable] | None]:
        objects: dict[str, Diffable | list[Diffable] | None] = {
            "threshold": self.threshold,
        }

        return objects

    def _mutable_fields(self) -> set[str]:
        return {*super()._mutable_fields(), *{"query"}}

    def _immutable_fields(self) -> set[str]:
        return {
            *super()._immutable_fields(),
        }


def _validate_metadata_validator(
    validator: Validator,
    window: Window,
    segmentation: Segmentation,
    metric: VolumeMetric | None = None,
) -> None:
    source = window._resource_graph._find_source(window.source_name)
    if not isinstance(source, (GcpBigQuerySource, SnowflakeSource)):
        raise ValidioResourceError(
            validator,
            f"Source {source.__class__.__name__} does not support metadata "
            "enabled validators",
        )

    if window.__class__ != GlobalWindow:
        raise ValidioResourceError(
            validator,
            "Metadata enabled validator requires a global window",
        )

    if len(segmentation.fields) > 0:
        raise ValidioResourceError(
            validator,
            "Metadata enabled validator requires an unsegmented segmentation",
        )

    if segmentation.filter_name is not None:
        raise ValidioResourceError(
            validator,
            "Metadata enabled validator requires to not use any segmentation filter",
        )

    if metric is not None and metric != VolumeMetric.COUNT:
        raise ValidioResourceError(
            validator,
            "Metadata enabled validator requires the `COUNT` metric",
        )
