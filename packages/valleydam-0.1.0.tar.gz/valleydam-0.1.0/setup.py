from setuptools import setup, find_packages

with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setup(
    name="valleydam",
    version="0.1.0",
    author="Supra N.",
    description="A DNS-based cryptographic identity verification protocol for AI Agents.",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/supra-nlpn/valley-dam",
    project_urls={
        "Bug Tracker": "https://github.com/supra-nlpn/valley-dam/issues",
    },
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
        "Topic :: Security",
        "Topic :: Internet :: WWW/HTTP",
    ],
    package_dir={"": "src"},
    packages=find_packages(where="src"),
    python_requires=">=3.7",
    install_requires=[
        "requests>=2.25.0",
        "cryptography>=3.4.0",
        "dnspython>=2.1.0",
    ],
    entry_points={
        'console_scripts': [
            'valleydam-gen=valleydam.cli:main',
        ],
    },
)