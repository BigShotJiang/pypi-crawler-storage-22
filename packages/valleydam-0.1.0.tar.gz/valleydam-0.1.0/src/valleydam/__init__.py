"""
ValleyDam: DNS-based Identity Verification Protocol.
"""

from .client import ValleyDamSession
from .verifier import verify_request, DnsKeyResolver
from .core import ValleyDamSigner, ValleyDamVerifier

__version__ = "0.1.0"
__all__ = [
    "ValleyDamSession",
    "verify_request",
    "DnsKeyResolver",
    "ValleyDamSigner",
    "ValleyDamVerifier"
]