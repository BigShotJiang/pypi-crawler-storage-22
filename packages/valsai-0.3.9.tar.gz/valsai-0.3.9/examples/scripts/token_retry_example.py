import asyncio
import os

from vals import RunParameters, RunStatus, Suite, configure_credentials
from vals.sdk.types import TokenRetryParams

configure_credentials(api_key=os.environ["VALS_API_KEY"])


async def main():
    SUITE_ID = "YOUR_SUITE_ID"
    suite = await Suite.from_id(SUITE_ID)

    parameters = RunParameters(
        max_output_tokens=2048,
        custom_parameters={
            "top_p": 0.5,
            "text": {"verbosity": "low"},
            "reasoning": {"effort": "low", "summary": "auto"},
        },
        token_retry_params=TokenRetryParams(output_modifier=17),
    )

    # NOTE: CHANGE THE OUTPUT MODIFIER
    # it is the ratio between the number of output and input tokens

    model = "openai/gpt-5-mini-2025-08-07"

    run = await suite.run(model=model, parameters=parameters)
    completed_status = await run.wait_for_run_completion()

    if completed_status == RunStatus.SUCCESS:
        print("Run completed successfully. Status=%s" % completed_status)
    else:
        print("Run failed. Status=%s" % completed_status)

    test_results = await run.test_results
    for test_result in test_results:
        print(test_result.metadata)


asyncio.run(main())
