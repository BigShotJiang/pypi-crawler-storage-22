"""Presenters for CLI display."""
