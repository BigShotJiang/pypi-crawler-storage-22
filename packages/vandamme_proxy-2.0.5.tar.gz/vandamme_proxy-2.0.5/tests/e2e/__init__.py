"""E2E tests for Vandamme Proxy dashboard.

This package contains Playwright-based end-to-end tests for the dashboard UI.
"""
