"""Tests for alias resolution strategy pattern components."""
