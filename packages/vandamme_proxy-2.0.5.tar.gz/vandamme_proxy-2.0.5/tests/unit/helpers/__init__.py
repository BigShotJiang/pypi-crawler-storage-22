"""Test helper utilities for streaming state machine tests."""
