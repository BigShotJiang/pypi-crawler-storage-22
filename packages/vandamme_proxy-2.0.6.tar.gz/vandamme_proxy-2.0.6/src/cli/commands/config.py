"""Configuration management commands."""

import asyncio
import sys
from pathlib import Path

import typer
from rich.console import Console
from rich.panel import Panel
from rich.prompt import Confirm, Prompt
from rich.table import Table

from src.core.config import Config

app = typer.Typer(help="Configuration management")


@app.command()
def show() -> None:
    """Display current configuration."""
    console = Console()
    cfg = Config()

    table = Table(title="Current Configuration")
    table.add_column("Variable", style="cyan")
    table.add_column("Value", style="green")
    table.add_column("Source", style="yellow")

    # Add rows with masked secrets
    table.add_row(f"{cfg.default_provider.upper()}_API_KEY", cfg.api_key_hash, "Environment")
    table.add_row(
        "PROXY_API_KEY",
        "***" if cfg.proxy_api_key else "<not set>",
        "Environment",
    )
    table.add_row(f"{cfg.default_provider.upper()}_BASE_URL", cfg.base_url, "Environment/Default")
    table.add_row("HOST", cfg.host, "Environment/Default")
    table.add_row("PORT", str(cfg.port), "Environment/Default")
    table.add_row("LOG_LEVEL", cfg.log_level, "Environment/Default")
    table.add_row("MIN_TOKENS_LIMIT", str(cfg.min_tokens_limit), "Environment/Default")
    table.add_row("MAX_TOKENS_LIMIT", str(cfg.max_tokens_limit), "Environment/Default")
    table.add_row("MAX_RETRIES", str(cfg.max_retries), "Environment/Default")
    table.add_row("REQUEST_TIMEOUT", str(cfg.request_timeout), "Environment/Default")

    console.print(table)


@app.command()
def validate() -> None:
    """Validate configuration."""
    console = Console()
    cfg = Config()

    errors = []

    # Validate required settings
    if not cfg.openai_api_key:
        errors.append("❌ OPENAI_API_KEY is required")
    elif not cfg.validate_api_key():
        errors.append("❌ OPENAI_API_KEY format is invalid")

    if errors:
        console.print(Panel("\n".join(errors), title="Validation Errors", style="red"))
        sys.exit(1)
    else:
        console.print(
            Panel("✅ All configuration is valid!", title="Validation Success", style="green")
        )


@app.command()
def env() -> None:
    """Show required environment variables."""
    console = Console()

    console.print(
        Panel(
            """
[bold cyan]Required Environment Variables:[/bold cyan]
  OPENAI_API_KEY        - Your OpenAI API key (format: sk-...)

[bold yellow]Optional Environment Variables:[/bold yellow]
  PROXY_API_KEY    - Expected API key for client validation at the proxy
  OPENAI_BASE_URL      - OpenAI API base URL (default: https://api.openai.com/v1)
  AZURE_API_VERSION    - API version for Azure OpenAI
  HOST                - Server host (default: 0.0.0.0)
  PORT                - Server port (default: 8082)
  LOG_LEVEL           - Logging level: DEBUG/INFO/WARNING/ERROR (default: INFO)
  MIN_TOKENS_LIMIT    - Minimum tokens per request (default: 100)
  MAX_TOKENS_LIMIT    - Maximum tokens per request (default: 4096)
  MAX_RETRIES         - Maximum retry attempts (default: 2)
  REQUEST_TIMEOUT     - Request timeout in seconds (default: 90)

[bold green]Custom Headers:[/bold green]
  CUSTOM_HEADER_*     - Any env var starting with CUSTOM_HEADER_ will be
                        converted to a HTTP header (underscores -> hyphens)
                        Example: CUSTOM_HEADER_X_API_KEY=xyz becomes X-API-Key: xyz
      """,
            title="Environment Variables",
            width=100,
        )
    )


@app.command(name="reload-profiles")
def reload_profiles_cmd() -> None:
    """Reload profile configurations from TOML files.

    Allows hot-reloading profiles without restarting the server.
    """
    console = Console()

    async def do_reload() -> None:
        try:
            console.print("[dim]Reloading profiles...[/dim]")
            from src.core.dependencies import reload_profiles

            await reload_profiles()
            console.print("[green]Profiles reloaded successfully[/green]")
        except RuntimeError as e:
            console.print(f"[red]Error reloading profiles: {e}[/red]")
            raise SystemExit(1) from None

    asyncio.run(do_reload())


@app.command()
def setup() -> None:
    """Interactive configuration setup."""
    console = Console()

    env_path = Path(".env")

    if env_path.exists() and not Confirm.ask(".env file already exists. Overwrite?", default=False):
        console.print("[yellow]Setup cancelled[/yellow]")
        return

    console.print("[bold cyan]Vandamme Proxy Configuration Setup[/bold cyan]")
    console.print()

    # Get required values
    openai_key = Prompt.ask("OpenAI API Key", password=True)

    # Get optional values
    anthropic_key = Prompt.ask("Proxy API Key (optional)", default="", password=True)
    base_url = Prompt.ask("OpenAI Base URL", default="https://api.openai.com/v1")
    host = Prompt.ask("Server Host", default="0.0.0.0")
    port = Prompt.ask("Server Port", default="8082")

    # Write .env file
    with open(env_path, "w") as f:
        f.write("# Vandamme Proxy Configuration\n")
        f.write(f"OPENAI_API_KEY={openai_key}\n")
        if anthropic_key:
            f.write(f"PROXY_API_KEY={anthropic_key}\n")
        if base_url != "https://api.openai.com/v1":
            f.write(f"OPENAI_BASE_URL={base_url}\n")
        if host != "0.0.0.0":
            f.write(f"HOST={host}\n")
        if port != "8082":
            f.write(f"PORT={port}\n")

    console.print(f"\n[green]✅ Configuration saved to {env_path}[/green]")
