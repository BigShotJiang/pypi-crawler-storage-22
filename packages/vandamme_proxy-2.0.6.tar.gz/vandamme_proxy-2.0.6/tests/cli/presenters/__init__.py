"""Tests for CLI presenters."""
