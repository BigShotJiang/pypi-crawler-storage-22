"""Tests for middleware system."""
