# VanityClient

Discord vanity URL client using user tokens — with TLS session pooling and MFA support.

## Install

```bash
pip install vanityclient
```

## Quick Start

```python
from vanityclient import VanityClient

vanity = VanityClient(token="USER_TOKEN", mfa_secret="MFA_SECRET")
await vanity.init()
await vanity.set_vanity(guild_id, "myvanity")
```

## Usage in a discord.py Bot

```python
import discord
from discord.ext import commands
from vanityclient import VanityClient

bot = commands.Bot(command_prefix="!", intents=discord.Intents.all())

vanity = VanityClient(token="USER_TOKEN", mfa_secret="MFA_SECRET")

@bot.event
async def on_ready():
    await vanity.init()

@bot.event
async def on_audit_log_entry_create(entry):
    if entry.action != discord.AuditLogAction.guild_update:
        return
    old = getattr(entry.changes.before, 'vanity_url_code', None)
    new = getattr(entry.changes.after, 'vanity_url_code', None)
    if old and old != new:
        await vanity.restore_vanity(entry.guild.id, old)

bot.run("BOT_TOKEN")
```

## Multiple Tokens

```python
vanity1 = VanityClient(token="TOKEN_1", mfa_secret="SECRET_1")
vanity2 = VanityClient(token="TOKEN_2")

await vanity1.init()
await vanity2.init()

await vanity1.set_vanity(guild_id, "myvanity")
await vanity2.set_vanity(other_guild_id, "othervanity")
```

## API

| Method | Returns | Description |
|--------|---------|-------------|
| `await init()` | `bool` | Initialize client |
| `await set_vanity(guild_id, code)` | `bool` | Set vanity URL |
| `await restore_vanity(guild_id, code)` | `bool` | Aggressive restore with parallel sessions |
| `await health_check()` | `bool` | Validate token |
| `get_status()` | `dict` | Client status |

## License

MIT
