# VanityClient — Discord Vanity URL Client Module
#
# Discord removed vanity URL management from the bot API.
# This module lets you set and restore vanity URLs from within
# your discord.py bot using a Discord user token.
#
# Install:
#   pip install vanityclient
#
# Quick Start:
#   from vanityclient import VanityClient
#
#   vanity = VanityClient(token="USER_TOKEN", mfa_secret="MFA_SECRET")
#   await vanity.init()
#   await vanity.set_vanity(guild_id, "myvanity")
#
# Multiple Tokens:
#   vanity1 = VanityClient(token="TOKEN_1", mfa_secret="SECRET_1")
#   vanity2 = VanityClient(token="TOKEN_2")
#   await vanity1.init()
#   await vanity2.init()
#   await vanity1.set_vanity(guild_id, "myvanity")
#
# Usage in a discord.py Bot:
#   @bot.event
#   async def on_ready():
#       await vanity.init()
#
#   @bot.event
#   async def on_audit_log_entry_create(entry):
#       if vanity change detected:
#           await vanity.restore_vanity(guild_id, "myvanity")
#
# API:
#   VanityClient(token, mfa_secret=None, session_pool_size=5, max_retries=30)
#     .init()                              → bool
#     .set_vanity(guild_id, vanity_code)   → bool
#     .restore_vanity(guild_id, vanity_code) → bool
#     .health_check()                      → bool
#     .get_status()                        → dict
#
# Modules:
#   vanityclient.client   — Main VanityClient class
#   vanityclient.session  — TLS session pool + cookie management
#   vanityclient.headers  — Discord API header builder
#   vanityclient.mfa      — TOTP MFA handler + pre-warming
#   vanityclient.restore  — Parallel + sequential restore logic

from .client import VanityClient

__version__ = "1.0.0"
__all__ = ["VanityClient"]