import time
import asyncio
from xylogger import console
from .session import SessionPool
from .headers import build_headers, build_headers_for_session
from .mfa import MFAHandler
from .restore import full_restore


class VanityClient:
    BASE_URL = "https://discord.com/api/v10"

    def __init__(self, token, mfa_secret=None, session_pool_size=5,
                 max_retries=30, ntp_server="time.google.com"):
        self.token = token
        self.max_retries = max_retries
        self.ntp_server = ntp_server
        self.time_offset = 0.0
        self.user_info = None
        self.user_id = None
        self.is_ready = False
        self._init_time = None
        self._total_requests = 0
        self._successful_requests = 0

        self.pool = SessionPool(size=session_pool_size)

        self.mfa = None
        if mfa_secret:
            self.mfa = MFAHandler(
                mfa_secret,
                get_headers_fn=self._headers,
                run_fn=self._run,
                get_time_fn=self._time
            )

    def _headers(self, mfa_token=None, guild_id=None):
        return build_headers(self.token, self.pool, mfa_token, guild_id)

    def _session_headers(self, entry, mfa_token=None, guild_id=None):
        return build_headers_for_session(self.token, self.pool, entry, mfa_token, guild_id)

    def _time(self):
        return time.time() + self.time_offset

    async def _run(self, fn):
        return await asyncio.get_event_loop().run_in_executor(None, fn)

    async def _sync_time(self):
        try:
            import ntplib
            resp = await self._run(lambda: ntplib.NTPClient().request(self.ntp_server, version=3))
            self.time_offset = resp.offset
        except:
            pass

    async def _warmup(self):
        async def warm(entry):
            try:
                h = self._session_headers(entry)
                await self._run(lambda: entry.session.get(f"{self.BASE_URL}/gateway", headers=h))
            except:
                pass

        await asyncio.gather(*[warm(e) for e in self.pool.entries[:3]], return_exceptions=True)

    async def init(self):
        console.info("VanityClient Initializing...")
        init_start = time.time()
        self.pool.refresh_cookies(force=True)

        time_task = asyncio.create_task(self._sync_time())
        warmup_task = asyncio.create_task(self._warmup())

        try:
            resp = await self._run(lambda: self.pool.primary.get(
                f"{self.BASE_URL}/users/@me", headers=self._headers()
            ))
            if resp.status_code == 200:
                self.user_info = resp.json()
                self.user_id = int(self.user_info.get("id"))
                self.is_ready = True
                self._init_time = time.time()
                username = self.user_info.get("username", "?")
                mfa_status = "MFA On" if self.mfa else "MFA Off"
                init_ms = int((time.time() - init_start) * 1000)
                console.success(f"VanityClient Ready | {username} ({self.user_id}) | {mfa_status} | {len(self.pool.entries)} sessions | Build {self.pool.build_number} | {init_ms}ms")
            else:
                console.error(f"VanityClient Token validation failed | HTTP {resp.status_code}")
                self.is_ready = False
        except Exception as e:
            console.error(f"VanityClient Init failed | {e}")
            self.is_ready = False

        await time_task
        await warmup_task

        if self.is_ready and self.mfa:
            await self.mfa.prewarm(self.pool.primary)

        return self.is_ready

    async def set_vanity(self, guild_id, vanity_code):
        if not self.is_ready:
            console.error("VanityClient Not ready")
            return False

        guild_id = int(guild_id)
        vanity_code = vanity_code.lower().replace("/", "").strip()
        start = time.time()
        self._total_requests += 1
        best = self.pool.best

        if self.mfa and self.mfa.cached:
            h = self._session_headers(best, mfa_token=self.mfa.cache, guild_id=guild_id)
            resp = await self._run(lambda: best.session.patch(
                f"{self.BASE_URL}/guilds/{guild_id}/vanity-url",
                headers=h, json={"code": vanity_code}
            ))
            if resp.status_code == 200:
                ms = int((time.time() - start) * 1000)
                self._successful_requests += 1
                self.pool.record_success(best.session)
                console.success(f"VanityClient Set /{vanity_code} | {ms}ms")
                return True
            if resp.status_code == 429:
                retry = resp.json().get("retry_after", 1)
                self.pool.record_rate_limit(best.session, retry)
                console.warning(f"VanityClient Rate limited | {retry}s")
                await asyncio.sleep(retry)
                return await self.set_vanity(guild_id, vanity_code)
            self.mfa.cache = None
            self.mfa.cache_time = 0
            self.pool.record_failure(best.session)

        h = self._session_headers(best, guild_id=guild_id)
        resp = await self._run(lambda: best.session.patch(
            f"{self.BASE_URL}/guilds/{guild_id}/vanity-url",
            headers=h, json={"code": vanity_code}
        ))

        if resp.status_code == 200:
            ms = int((time.time() - start) * 1000)
            self._successful_requests += 1
            self.pool.record_success(best.session)
            console.success(f"VanityClient Set /{vanity_code} | {ms}ms")
            return True

        data = resp.json()

        if resp.status_code == 401 and data.get("code") == 60003:
            if self.mfa:
                result = await self.mfa.solve(best.session, guild_id, vanity_code)
                if result:
                    self._successful_requests += 1
                    self.pool.record_success(best.session)
                return result
            console.error("VanityClient MFA required but no secret configured")
            return False

        if resp.status_code == 429:
            retry = data.get("retry_after", 1)
            self.pool.record_rate_limit(best.session, retry)
            console.warning(f"VanityClient Rate limited | {retry}s")
            await asyncio.sleep(retry)
            return await self.set_vanity(guild_id, vanity_code)

        self.pool.record_failure(best.session)
        console.error(f"VanityClient Failed to set /{vanity_code} | HTTP {resp.status_code} | {data.get('message', '')}")
        return False

    async def restore_vanity(self, guild_id, vanity_code):
        if not self.is_ready:
            console.error("VanityClient Not ready")
            return False

        guild_id = int(guild_id)
        vanity_code = vanity_code.lower().replace("/", "").strip()
        self._total_requests += 1

        result = await full_restore(
            self.token, self.pool, self._headers, self._run, self.mfa,
            guild_id, vanity_code, self.max_retries, self._sync_time
        )
        if result:
            self._successful_requests += 1
        return result

    async def health_check(self):
        try:
            resp = await self._run(lambda: self.pool.primary.get(
                f"{self.BASE_URL}/users/@me", headers=self._headers()
            ))
            if resp.status_code == 200:
                self.user_info = resp.json()
                console.success("VanityClient Health check passed")
                return True
            console.error(f"VanityClient Health check failed | HTTP {resp.status_code}")
            return False
        except Exception as e:
            console.error(f"VanityClient Health check error | {e}")
            return False

    def get_status(self):
        uptime = int(time.time() - self._init_time) if self._init_time else 0
        return {
            "ready": self.is_ready,
            "user": f"{self.user_info.get('username', '?')} ({self.user_info.get('id', '?')})" if self.user_info else "Unknown",
            "mfa": bool(self.mfa),
            "mfa_cached": bool(self.mfa and self.mfa.cached),
            "sessions": len(self.pool.entries),
            "build": self.pool.build_number,
            "time_offset": round(self.time_offset, 3),
            "uptime_seconds": uptime,
            "total_requests": self._total_requests,
            "successful_requests": self._successful_requests,
            "session_stats": self.pool.stats()
        }
