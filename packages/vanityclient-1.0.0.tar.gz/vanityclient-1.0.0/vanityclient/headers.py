import json
import base64
import uuid


def super_props(build_number):
    data = {
        "os": "Windows", "browser": "Chrome", "device": "",
        "system_locale": "en-US",
        "browser_user_agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Safari/537.36 Edg/139.0.0.0",
        "browser_version": "139.0.0.0", "os_version": "10",
        "referrer": "https://discord.com/", "referring_domain": "discord.com",
        "referrer_current": "", "referring_domain_current": "",
        "release_channel": "stable", "client_build_number": int(build_number),
        "native_build_number": None, "native_build_type": None, "client_event_source": None,
        "client_launch_id": str(uuid.uuid4()),
        "client_heartbeat_session_id": str(uuid.uuid4()),
        "launch_signature": str(uuid.uuid4()),
        "has_client_mods": False, "design_id": 0
    }
    return base64.b64encode(json.dumps(data, separators=(',', ':')).encode()).decode()


def context_props(guild_id=None):
    data = {
        "location": "Guild Settings",
        "location_guild_id": str(guild_id) if guild_id else None,
        "location_channel_id": None,
        "location_channel_type": None
    }
    return base64.b64encode(json.dumps(data, separators=(',', ':')).encode()).decode()


def build_headers(token, pool, mfa_token=None, guild_id=None):
    pool.refresh_cookies()
    best = pool.best
    ua = best.browser["ua"]
    sec_ch = best.browser["sec_ch"]

    h = {
        "authority": "discord.com", "accept": "*/*",
        "accept-encoding": "gzip, deflate, br, zstd",
        "accept-language": "en-US,en;q=0.9",
        "authorization": token, "content-type": "application/json",
        "cookie": pool.cookies or "", "origin": "https://discord.com",
        "priority": "u=1, i",
        "referer": f"https://discord.com/channels/{guild_id}" if guild_id else "https://discord.com/channels/@me",
        "sec-ch-ua": sec_ch,
        "sec-ch-ua-mobile": "?0", "sec-ch-ua-platform": '"Windows"',
        "sec-fetch-dest": "empty", "sec-fetch-mode": "cors", "sec-fetch-site": "same-origin",
        "user-agent": ua,
        "x-debug-options": "bugReporterEnabled",
        "x-discord-locale": "en-US", "x-discord-timezone": "Asia/Kolkata",
        "x-super-properties": super_props(pool.build_number)
    }
    if guild_id:
        h["x-context-properties"] = context_props(guild_id)
    if pool.fingerprint:
        h["x-fingerprint"] = pool.fingerprint
    if mfa_token:
        h["x-discord-mfa-authorization"] = mfa_token
    return h


def build_headers_for_session(token, pool, entry, mfa_token=None, guild_id=None):
    pool.refresh_cookies()
    ua = entry.browser["ua"]
    sec_ch = entry.browser["sec_ch"]

    h = {
        "authority": "discord.com", "accept": "*/*",
        "accept-encoding": "gzip, deflate, br, zstd",
        "accept-language": "en-US,en;q=0.9",
        "authorization": token, "content-type": "application/json",
        "cookie": pool.cookies or "", "origin": "https://discord.com",
        "priority": "u=1, i",
        "referer": f"https://discord.com/channels/{guild_id}" if guild_id else "https://discord.com/channels/@me",
        "sec-ch-ua": sec_ch,
        "sec-ch-ua-mobile": "?0", "sec-ch-ua-platform": '"Windows"',
        "sec-fetch-dest": "empty", "sec-fetch-mode": "cors", "sec-fetch-site": "same-origin",
        "user-agent": ua,
        "x-debug-options": "bugReporterEnabled",
        "x-discord-locale": "en-US", "x-discord-timezone": "Asia/Kolkata",
        "x-super-properties": super_props(pool.build_number)
    }
    if guild_id:
        h["x-context-properties"] = context_props(guild_id)
    if pool.fingerprint:
        h["x-fingerprint"] = pool.fingerprint
    if mfa_token:
        h["x-discord-mfa-authorization"] = mfa_token
    return h
