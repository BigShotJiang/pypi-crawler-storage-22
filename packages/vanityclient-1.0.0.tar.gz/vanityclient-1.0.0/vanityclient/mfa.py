import time
import asyncio
import pyotp
from xylogger import console


class MFAHandler:
    BASE_URL = "https://discord.com/api/v10"

    def __init__(self, mfa_secret, get_headers_fn, run_fn, get_time_fn):
        self.secret = mfa_secret.replace(" ", "").replace("-", "").replace("\n", "").upper()
        self.totp = pyotp.TOTP(self.secret)
        self._headers = get_headers_fn
        self._run = run_fn
        self._time = get_time_fn
        self.cache = None
        self.cache_time = 0
        self.ticket_cache = None
        self.ticket_time = 0

    @property
    def cached(self):
        return self.cache and (time.time() - self.cache_time) < 270

    @property
    def fresh_ticket(self):
        return self.ticket_cache and (time.time() - self.ticket_time) < 25

    def generate(self, offset=0):
        try:
            return self.totp.at(int(self._time()) + offset)
        except:
            return None

    def _optimal_codes(self):
        codes = []
        now = int(self._time())
        remaining = 30 - (now % 30)
        if remaining <= 5:
            codes.append(self.generate(30))
            codes.append(self.generate(0))
        else:
            codes.append(self.generate(0))
            codes.append(self.generate(-30))
            codes.append(self.generate(30))
        return [c for c in codes if c]

    async def _wait_for_optimal_window(self):
        remaining = 30 - (int(self._time()) % 30)
        if remaining <= 3:
            await asyncio.sleep(remaining + 0.3)

    async def prewarm(self, session):
        if self.cached:
            return
        try:
            resp = await self._run(lambda: session.post(
                f"{self.BASE_URL}/users/@me/mfa/totp/enable",
                headers=self._headers(), json={}
            ))
            if resp.status_code == 401:
                data = resp.json()
                if data.get("code") == 60003:
                    ticket = data.get("mfa", {}).get("ticket")
                    if ticket:
                        self.ticket_cache = ticket
                        self.ticket_time = time.time()
                        await self._wait_for_optimal_window()
                        codes = self._optimal_codes()
                        for code in codes:
                            mfa_resp = await self._run(lambda: session.post(
                                f"{self.BASE_URL}/mfa/finish",
                                headers=self._headers(),
                                json={"ticket": ticket, "mfa_type": "totp", "data": code}
                            ))
                            if mfa_resp.status_code == 200:
                                t = mfa_resp.json().get("token")
                                if t:
                                    self.cache = t
                                    self.cache_time = time.time()
                                    console.success("VanityClient MFA pre-warmed")
                                    return
                            elif mfa_resp.status_code == 400 and mfa_resp.json().get("code") == 60008:
                                continue
                            else:
                                break
        except:
            pass

    async def solve(self, session, guild_id, vanity_code):
        url = f"{self.BASE_URL}/guilds/{guild_id}/vanity-url"
        payload = {"code": vanity_code}
        start = time.time()

        if self.cached:
            resp = await self._run(lambda: session.patch(
                url, headers=self._headers(mfa_token=self.cache, guild_id=guild_id), json=payload
            ))
            if resp.status_code == 200:
                ms = int((time.time() - start) * 1000)
                console.success(f"VanityClient Set /{vanity_code} via cached MFA | {ms}ms")
                return True
            if resp.status_code == 429:
                retry = resp.json().get("retry_after", 1)
                await asyncio.sleep(retry)
                return await self.solve(session, guild_id, vanity_code)
            self.cache = None
            self.cache_time = 0

        resp = await self._run(lambda: session.patch(
            url, headers=self._headers(guild_id=guild_id), json=payload
        ))
        data = resp.json()

        if resp.status_code == 200:
            ms = int((time.time() - start) * 1000)
            console.success(f"VanityClient Set /{vanity_code} | {ms}ms")
            return True

        if resp.status_code != 401 or data.get("code") != 60003:
            return False

        ticket = data.get("mfa", {}).get("ticket")
        if not ticket:
            console.error("VanityClient No MFA ticket")
            return False

        self.ticket_cache = ticket
        self.ticket_time = time.time()
        await self._wait_for_optimal_window()
        codes = self._optimal_codes()

        for code in codes:
            mfa_resp = await self._run(lambda: session.post(
                f"{self.BASE_URL}/mfa/finish",
                headers=self._headers(guild_id=guild_id),
                json={"ticket": ticket, "mfa_type": "totp", "data": code}
            ))
            mfa_data = mfa_resp.json()

            if mfa_resp.status_code == 200 and mfa_data.get("token"):
                mfa_token = mfa_data["token"]
                self.cache = mfa_token
                self.cache_time = time.time()

                for retry in range(3):
                    final = await self._run(lambda: session.patch(
                        url,
                        headers=self._headers(mfa_token=mfa_token, guild_id=guild_id),
                        json=payload
                    ))

                    if final.status_code == 200:
                        ms = int((time.time() - start) * 1000)
                        console.success(f"VanityClient Set /{vanity_code} via MFA | {ms}ms")
                        return True

                    if final.status_code == 429:
                        wait = final.json().get("retry_after", 1)
                        console.warning(f"VanityClient Rate limited | {wait}s")
                        await asyncio.sleep(wait)
                        continue

                    if final.status_code == 403 and final.json().get("code") == 10008:
                        if retry < 2:
                            await asyncio.sleep(0.3)
                            continue

                    console.error(f"VanityClient MFA final failed | HTTP {final.status_code}")
                    return False

            elif mfa_resp.status_code == 400 and mfa_data.get("code") == 60008:
                continue
            elif mfa_resp.status_code == 400 and mfa_data.get("code") == 60011:
                console.error("VanityClient MFA ticket expired")
                return False
            elif mfa_resp.status_code == 429:
                await asyncio.sleep(mfa_data.get("retry_after", 5))
                continue

        console.error("VanityClient All MFA codes failed")
        return False
