import time
import asyncio
from xylogger import console
from .headers import build_headers_for_session


BASE_URL = "https://discord.com/api/v10"


async def parallel_restore(token, pool, run_fn, headers_fn, mfa, guild_id, vanity_code):
    url = f"{BASE_URL}/guilds/{guild_id}/vanity-url"
    payload = {"code": vanity_code}
    available = pool.available_sessions

    if not available:
        available = pool.entries[:1]

    async def fire(entry):
        try:
            if mfa and mfa.cached:
                h = build_headers_for_session(token, pool, entry, mfa_token=mfa.cache, guild_id=guild_id)
            else:
                h = build_headers_for_session(token, pool, entry, guild_id=guild_id)
            resp = await run_fn(lambda: entry.session.patch(url, headers=h, json=payload))
            return entry, resp.status_code, resp.json() if resp.status_code != 200 else {}
        except:
            return entry, 0, {}

    results = await asyncio.gather(*[fire(e) for e in available], return_exceptions=True)

    for r in results:
        if isinstance(r, Exception):
            continue
        entry, status, data = r
        if status == 200:
            pool.record_success(entry.session)
            return True

    need_mfa = False
    for r in results:
        if isinstance(r, Exception):
            continue
        entry, status, data = r
        if status == 200:
            pool.record_success(entry.session)
            return True
        elif status == 429:
            retry = data.get("retry_after", 1)
            pool.record_rate_limit(entry.session, retry)
        elif status == 401 and data.get("code") == 60003:
            need_mfa = True
        else:
            pool.record_failure(entry.session)

    if need_mfa:
        if mfa:
            return await mfa.solve(pool.primary, guild_id, vanity_code)
        console.error("VanityClient MFA required but no secret configured")
        return False

    return False


async def single_restore(token, pool, run_fn, headers_fn, mfa, guild_id, vanity_code, attempt):
    entry = pool.get(attempt)
    if not entry.available:
        entry = pool.best
    url = f"{BASE_URL}/guilds/{guild_id}/vanity-url"
    payload = {"code": vanity_code}
    h = build_headers_for_session(token, pool, entry, guild_id=guild_id)

    if mfa and mfa.cached:
        h_mfa = build_headers_for_session(token, pool, entry, mfa_token=mfa.cache, guild_id=guild_id)
        resp = await run_fn(lambda: entry.session.patch(url, headers=h_mfa, json=payload))
        if resp.status_code == 200:
            pool.record_success(entry.session)
            return True
        data = resp.json()
        if resp.status_code == 429:
            pool.record_rate_limit(entry.session, data.get("retry_after", 1))
            await asyncio.sleep(data.get("retry_after", 1))
            return await single_restore(token, pool, run_fn, headers_fn, mfa, guild_id, vanity_code, attempt + 1)
        if resp.status_code in (401, 403):
            mfa.cache = None
            mfa.cache_time = 0
        pool.record_failure(entry.session)

    resp = await run_fn(lambda: entry.session.patch(url, headers=h, json=payload))
    if resp.status_code == 200:
        pool.record_success(entry.session)
        return True

    data = resp.json()

    if resp.status_code == 401 and data.get("code") == 60003:
        if mfa:
            return await mfa.solve(entry.session, guild_id, vanity_code)
        console.error("VanityClient MFA required but no secret configured")
        return False

    if resp.status_code == 429:
        retry = data.get("retry_after", 1)
        pool.record_rate_limit(entry.session, retry)
        console.warning(f"VanityClient Rate limited | {retry}s")
        await asyncio.sleep(retry)
        return await single_restore(token, pool, run_fn, headers_fn, mfa, guild_id, vanity_code, attempt + 1)

    pool.record_failure(entry.session)
    return False


async def check_ownership(run_fn, pool, headers_fn, guild_id, expected):
    try:
        resp = await run_fn(lambda: pool.primary.get(
            f"{BASE_URL}/guilds/{guild_id}/vanity-url",
            headers=headers_fn(guild_id=guild_id)
        ))
        if resp.status_code == 200:
            current = resp.json().get("code", "")
            return current and current.lower() == expected.lower()
    except:
        pass
    return False


async def full_restore(token, pool, headers_fn, run_fn, mfa, guild_id, vanity_code, max_retries, sync_fn):
    start = time.time()

    if await check_ownership(run_fn, pool, headers_fn, guild_id, vanity_code):
        return True

    for attempt in range(1, max_retries + 1):
        if await parallel_restore(token, pool, run_fn, headers_fn, mfa, guild_id, vanity_code):
            ms = int((time.time() - start) * 1000)
            console.success(f"VanityClient Restored /{vanity_code} | {ms}ms | parallel | attempt {attempt}")
            return True

        if await check_ownership(run_fn, pool, headers_fn, guild_id, vanity_code):
            ms = int((time.time() - start) * 1000)
            console.success(f"VanityClient Restored /{vanity_code} | {ms}ms | verified | attempt {attempt}")
            return True

        if await single_restore(token, pool, run_fn, headers_fn, mfa, guild_id, vanity_code, attempt):
            ms = int((time.time() - start) * 1000)
            console.success(f"VanityClient Restored /{vanity_code} | {ms}ms | single | attempt {attempt}")
            return True

        if attempt % 3 == 0:
            pool.rotate_worst()
        if attempt % 5 == 0:
            pool.rebuild()
            if sync_fn:
                await sync_fn()
            if mfa:
                await mfa.prewarm(pool.primary)
        if attempt % 10 == 0:
            if await check_ownership(run_fn, pool, headers_fn, guild_id, vanity_code):
                ms = int((time.time() - start) * 1000)
                console.success(f"VanityClient Restored /{vanity_code} | {ms}ms | deep-verify | attempt {attempt}")
                return True

        await asyncio.sleep(min(0.1 * attempt, 2.0))

    if await check_ownership(run_fn, pool, headers_fn, guild_id, vanity_code):
        ms = int((time.time() - start) * 1000)
        console.success(f"VanityClient Restored /{vanity_code} | {ms}ms | final-verify")
        return True

    console.error(f"VanityClient Failed to restore /{vanity_code} after {max_retries} attempts | {int((time.time() - start) * 1000)}ms")
    return False
