import time
import re
import random
import secrets
import tls_client
from xylogger import console


BROWSERS = [
    {"id": "chrome_139", "version": "139",
     "ja3": "771,4865-4866-4867-49195-49199-49196-49200-52393-52392-49171-49172-156-157-47-53,0-5-10-11-13-16-18-23-27-35-43-45-51-17613-65037-65281,4588-29-23-24,0",
     "ua": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Safari/537.36",
     "sec_ch": '"Chromium";v="139", "Google Chrome";v="139", "Not:A-Brand";v="24"'},
    {"id": "chrome_138", "version": "138",
     "ja3": "771,4865-4866-4867-49195-49199-49196-49200-52393-52392-49171-49172-156-157-47-53,0-5-10-11-13-16-18-23-27-35-43-45-51-17613-65281,29-23-24,0",
     "ua": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36",
     "sec_ch": '"Chromium";v="138", "Google Chrome";v="138", "Not:A-Brand";v="24"'},
    {"id": "chrome_137", "version": "137",
     "ja3": "771,4865-4866-4867-49195-49199-49196-49200-52393-52392-49171-49172-156-157-47-53,0-5-10-11-13-16-18-23-27-35-43-45-51-17513-65281,29-23-24,0",
     "ua": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Safari/537.36",
     "sec_ch": '"Chromium";v="137", "Google Chrome";v="137", "Not:A-Brand";v="24"'},
    {"id": "chrome_139", "version": "139",
     "ja3": "771,4865-4866-4867-49195-49199-49196-49200-52393-52392-49171-49172-156-157-47-53,0-5-10-11-13-16-18-23-27-35-43-45-51-17613-65037-65281,4588-29-23-24,0",
     "ua": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Safari/537.36 Edg/139.0.0.0",
     "sec_ch": '"Microsoft Edge";v="139", "Chromium";v="139", "Not:A-Brand";v="24"'},
    {"id": "chrome_138", "version": "138",
     "ja3": "771,4865-4866-4867-49195-49199-49196-49200-52393-52392-49171-49172-156-157-47-53,0-5-10-11-13-16-18-23-27-35-43-45-51-17613-65281,29-23-24,0",
     "ua": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36 Edg/138.0.0.0",
     "sec_ch": '"Microsoft Edge";v="138", "Chromium";v="138", "Not:A-Brand";v="24"'},
]


def create_session(browser=None):
    if not browser:
        browser = random.choice(BROWSERS)
    return tls_client.Session(
        client_identifier=browser["id"],
        random_tls_extension_order=True,
        ja3_string=browser["ja3"],
        h2_settings={
            "HEADER_TABLE_SIZE": 65536,
            "ENABLE_PUSH": 0,
            "INITIAL_WINDOW_SIZE": 6291456,
            "MAX_HEADER_LIST_SIZE": 262144
        },
        h2_settings_order=["HEADER_TABLE_SIZE", "ENABLE_PUSH", "INITIAL_WINDOW_SIZE", "MAX_HEADER_LIST_SIZE"],
        supported_signature_algorithms=[
            "ecdsa_secp256r1_sha256", "rsa_pss_rsae_sha256", "rsa_pkcs1_sha256",
            "ecdsa_secp384r1_sha384", "rsa_pss_rsae_sha384", "rsa_pkcs1_sha384",
            "rsa_pss_rsae_sha512", "rsa_pkcs1_sha512"
        ],
        supported_versions=["TLS_1_3", "TLS_1_2"],
        key_share_curves=["GREASE", "X25519MLKEM768", "X25519", "secp256r1", "secp384r1"],
        pseudo_header_order=[":method", ":authority", ":scheme", ":path"],
        connection_flow=15663105,
        priority_frames=[]
    ), browser


class SessionEntry:
    def __init__(self, session, browser):
        self.session = session
        self.browser = browser
        self.hits = 0
        self.misses = 0
        self.rate_limited_until = 0
        self.last_used = 0

    @property
    def score(self):
        total = self.hits + self.misses
        if total == 0:
            return 1.0
        return self.hits / total

    @property
    def available(self):
        return time.time() >= self.rate_limited_until

    def hit(self):
        self.hits += 1
        self.last_used = time.time()

    def miss(self):
        self.misses += 1
        self.last_used = time.time()

    def rate_limit(self, seconds):
        self.rate_limited_until = time.time() + seconds
        self.last_used = time.time()


class SessionPool:
    def __init__(self, size=5):
        self.size = size
        self.entries = []
        self.build_number = 429117
        self.cookies = None
        self.fingerprint = None
        self.cf_token = None
        self.last_refresh = 0
        self.refresh_interval = 120
        self._build()

    def _build(self):
        self.entries = []
        browsers = list(BROWSERS)
        random.shuffle(browsers)
        for i in range(self.size):
            browser = browsers[i % len(browsers)]
            session, browser_info = create_session(browser)
            self.entries.append(SessionEntry(session, browser_info))

    @property
    def primary(self):
        return self.best.session

    @property
    def best(self):
        available = [e for e in self.entries if e.available]
        if not available:
            return self.entries[0]
        return max(available, key=lambda e: e.score)

    @property
    def all_sessions(self):
        return [e.session for e in self.entries]

    @property
    def available_sessions(self):
        return [e for e in self.entries if e.available]

    def get(self, idx):
        return self.entries[idx % len(self.entries)]

    def record_success(self, session):
        for e in self.entries:
            if e.session is session:
                e.hit()
                return

    def record_failure(self, session):
        for e in self.entries:
            if e.session is session:
                e.miss()
                return

    def record_rate_limit(self, session, seconds):
        for e in self.entries:
            if e.session is session:
                e.rate_limit(seconds)
                return

    def rebuild(self):
        self._build()
        self.refresh_cookies(force=True)
        console.info(f"VanityClient Session pool rebuilt | {self.size} sessions")

    def rotate_worst(self):
        worst = min(self.entries, key=lambda e: e.score)
        idx = self.entries.index(worst)
        browser = random.choice(BROWSERS)
        session, browser_info = create_session(browser)
        self.entries[idx] = SessionEntry(session, browser_info)

    def refresh_cookies(self, force=False):
        if not force and (time.time() - self.last_refresh) < self.refresh_interval:
            return
        session = self.primary
        try:
            resp = session.get("https://discord.com/channels/@me")
            match = re.search(r"r:'([^']+)'", resp.text)
            build = re.search(r'"BUILD_NUMBER":"?(\d+)"?', resp.text)
            if build:
                self.build_number = int(build.group(1))
            if match:
                cf = session.post(
                    f'https://discord.com/cdn-cgi/challenge-platform/h/b/jsd/r/{random.random():.16f}:{int(time.time())}:{secrets.token_urlsafe(32)}/{match.group(1)}'
                )
                if cf.status_code == 200 and cf.cookies:
                    c = list(cf.cookies)[0]
                    self.cf_token = f"{c.name}={c.value}"
        except:
            pass
        try:
            resp = session.get("https://discord.com/api/v9/experiments")
            if resp.status_code == 200:
                self.cookies = "; ".join([f"{c.name}={c.value}" for c in resp.cookies])
                if self.cf_token:
                    self.cookies += f"; {self.cf_token}"
                self.cookies += "; locale=en-US"
                self.fingerprint = resp.json().get("fingerprint")
            else:
                self._fallback_cookies()
        except:
            self._fallback_cookies()
        self.last_refresh = time.time()

    def _fallback_cookies(self):
        self.cookies = "__dcfduid=62f9e16000a211ef8089eda5bffbf7f9; __sdcfduid=62f9e16100a211ef8089eda5bffbf7f98e904ba04346eacdf57ee4af97bdd94e4c16f7df1db5132bea9132dd26b21a2a; locale=en-US"

    def stats(self):
        return [{"browser": e.browser["ua"].split("/")[-1], "score": round(e.score, 2),
                 "hits": e.hits, "misses": e.misses, "available": e.available} for e in self.entries]
