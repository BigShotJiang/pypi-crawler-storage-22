from setuptools import setup, find_packages

setup(
    name="variables_plus",
    version="0.1.0",
    packages=find_packages(),
    description="A simple library to create, clear, and delete global variables",
    author="",
    python_requires=">=3.7",
)