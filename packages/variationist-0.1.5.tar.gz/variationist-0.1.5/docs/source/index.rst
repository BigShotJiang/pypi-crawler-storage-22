.. Variationist documentation master file, created by
   sphinx-quickstart on Tue Jul 30 17:15:37 2024.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Variationist
============

.. include::
   intro.rst

.. toctree::
   :maxdepth: 4
   :caption: Introduction

   Introduction <intro>

.. toctree::
   :maxdepth: 4
   :caption: Core classes

   Core classes <core-classes>

.. toctree::
   :maxdepth: 4
   :caption: Full documentation

   Variationist documentation <variationist>



