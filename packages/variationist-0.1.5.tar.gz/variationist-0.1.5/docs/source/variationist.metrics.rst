variationist.metrics package
============================

Submodules
----------

variationist.metrics.corpus\_statistics module
----------------------------------------------

.. automodule:: variationist.metrics.corpus_statistics
   :members:
   :undoc-members:
   :show-inheritance:

variationist.metrics.lexical\_artifacts module
----------------------------------------------

.. automodule:: variationist.metrics.lexical_artifacts
   :members:
   :undoc-members:
   :show-inheritance:

variationist.metrics.lexical\_variation module
----------------------------------------------

.. automodule:: variationist.metrics.lexical_variation
   :members:
   :undoc-members:
   :show-inheritance:

variationist.metrics.metrics module
-----------------------------------

.. automodule:: variationist.metrics.metrics
   :members:
   :undoc-members:
   :show-inheritance:

variationist.metrics.pmi module
-------------------------------

.. automodule:: variationist.metrics.pmi
   :members:
   :undoc-members:
   :show-inheritance:

variationist.metrics.shared\_metrics module
-------------------------------------------

.. automodule:: variationist.metrics.shared_metrics
   :members:
   :undoc-members:
   :show-inheritance:

variationist.metrics.utils module
---------------------------------

.. automodule:: variationist.metrics.utils
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: variationist.metrics
   :members:
   :undoc-members:
   :show-inheritance:
