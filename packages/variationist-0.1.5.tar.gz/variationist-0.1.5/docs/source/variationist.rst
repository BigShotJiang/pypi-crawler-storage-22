variationist package
====================

Subpackages
-----------

.. toctree::
   :maxdepth: 4

   variationist.data
   variationist.metrics
   variationist.visualization

Submodules
----------

variationist.inspector module
-----------------------------

.. automodule:: variationist.inspector
   :members:
   :undoc-members:
   :show-inheritance:

variationist.utils module
-------------------------

.. automodule:: variationist.utils
   :members:
   :undoc-members:
   :show-inheritance:

variationist.visualizer module
------------------------------

.. automodule:: variationist.visualizer
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: variationist
   :members:
   :undoc-members:
   :show-inheritance:
