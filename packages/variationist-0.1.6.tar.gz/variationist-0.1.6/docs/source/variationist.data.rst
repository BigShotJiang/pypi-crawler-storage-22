variationist.data package
=========================

Submodules
----------

variationist.data.preprocess\_utils module
------------------------------------------

.. automodule:: variationist.data.preprocess_utils
   :members:
   :undoc-members:
   :show-inheritance:

variationist.data.tokenization module
-------------------------------------

.. automodule:: variationist.data.tokenization
   :members:
   :undoc-members:
   :show-inheritance:

variationist.data.tokenization\_utils module
--------------------------------------------

.. automodule:: variationist.data.tokenization_utils
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: variationist.data
   :members:
   :undoc-members:
   :show-inheritance:
