List all available examples in this project and provide a quick reference.

Read and summarize:
1. Read examples/README.md for the full overview
2. List all example directories with their topics
3. Group by difficulty level (Beginner, Intermediate, Advanced)

Present the examples in a table format showing:
- Example number
- Topic
- Estimated time
- Key concepts

Ask the user which example they'd like to explore in detail.
