"""Tests for the VASP calculator package."""
