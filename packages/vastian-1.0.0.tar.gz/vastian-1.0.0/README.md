# Vastian Network

A distributed multi-agent system for personal and professional knowledge management, with MARL-inspired Mentor Council collaboration.

## Quick Start

```bash
# Use project venv (recommended — avoids global pip pollution)
python -m venv .venv
.venv\Scripts\activate   # Windows
# source .venv/bin/activate   # Linux/macOS

pip install -e ".[dev,mcp]"
vastian chat          # Interactive chat with agents
vastian /inbox        # Inbox status
vastian /report <id>  # Delegation report
```

**Venv note**: Install in the project venv, not globally. If markdown or other deps were installed globally, run `pip uninstall markdown -y` (outside venv) then `pip install -e .` inside venv.

## Key Commands

- `vastian chat` — Interactive session; use `/help` for commands
- `vastian setup gdrive` / `vastian setup dropbox` — Backup storage OAuth
- `vastian backup-panel` — Web UI for backup config
- `vastian worker` — Background task processor
- `vastian giga push` / `vastian giga pull` — Giga memory sync

See [ARCHITECTURE.md](ARCHITECTURE.md) for system design.

## PyPI (pip install vastian)

```bash
pip install build twine
python -m build
twine upload dist/*
```

Create a [PyPI account](https://pypi.org/account/register/) and API token first. See [packaging.python.org](https://packaging.python.org/en/latest/tutorials/packaging-projects/).

## Desktop App

### Dev testing (after code changes)

```bash
# Backend only — open http://127.0.0.1:4545 in browser
vastian serve

# Full Tauri app (backend starts automatically)
cd neptune && npm run dev
```

No build step needed — Python runs from source via the venv.

If you hit a "Permission Denied" Tauri build error, kill stale sidecar processes:
`taskkill /F /IM vastian-backend.exe` (Windows) or `pkill vastian-backend` (macOS/Linux).

### Release / installer build

```bash
rustup update
pip install pyinstaller
python scripts/build_binary.py --clean   # freeze backend into .exe
powershell -ExecutionPolicy Bypass -File scripts\prepare_vastian.ps1   # copy sidecar binary  - ./scripts/prepare_vastian.sh
cd neptune && npm run build              # produce installer (.msi / .dmg)
```

See [neptune/README.md](neptune/README.md) for desktop app details.
