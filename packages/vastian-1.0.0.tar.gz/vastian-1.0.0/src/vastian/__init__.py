"""
Vastian Network — Distributed multi-agent system for knowledge management
and MARL-inspired Mentor Council collaboration.
"""

__version__ = "0.1.0"
