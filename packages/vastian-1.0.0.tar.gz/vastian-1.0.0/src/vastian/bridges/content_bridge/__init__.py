"""Content Bridge adapters — route external content to agents.

DEPRECATED: Replaced by Charles triage + Maya extract_signals tool.
See docs/operations/content-bridge-status.md.

These adapters are registered in bootstrap but are NOT called from the runtime.
The canonical pipeline is: inbox -> Charles triage -> Maya extract_signals ->
_route_meeting_signals. Kept for protocol tests only.
"""

from __future__ import annotations

from .manual_input import ManualInputAdapter
from .meeting_summary import MeetingSummaryAdapter
from .transcript import TranscriptAdapter

__all__ = [
    "ManualInputAdapter",
    "MeetingSummaryAdapter",
    "TranscriptAdapter",
]
