"""Cursor bridge -- Cursor Session Protocol for presenting to and receiving feedback from agents.

Two modes:
- **Direct mode** (CursorAdapter): Lightweight 1:1 and batch agent queries.
  Uses orchestrator.handle_user_message_direct. Briefings are reliably
  injected into agent system prompts. Recommended for quizzes, knowledge
  checks, and quick presentations.
- **Presentation mode** (session engine): Multi-agent rounds with consensus
  tracking, sentiment analysis, and rebuttals. Heavier context overhead.
  Use for formal council meetings and complex multi-round discussions.

Both satisfy the CodingAgentBridge protocol from bridges/protocols.py.
"""

from vastian.bridges.cursor_bridge.direct import CursorAdapter

__all__ = ["CursorAdapter"]
