"""Cursor bridge sessions — the Cursor Session Protocol lives here.

This is the canonical location for session models and engine.
The old vastian.sessions package re-exports from here for backward compat.
"""

from vastian.bridges.cursor_bridge.sessions.engine import SessionEngine
from vastian.bridges.cursor_bridge.sessions.models import (
    SessionDirection,
    SessionMessage,
    SessionPhase,
    SessionRound,
    VastianSession,
)

__all__ = [
    "VastianSession",
    "SessionDirection",
    "SessionPhase",
    "SessionMessage",
    "SessionRound",
    "SessionEngine",
]
