"""Giga dev bridge — outbox handlers for agents to write plans/neurons to Giga.

This bridge is registered via loader.py at startup. Core never imports
this module directly.
"""

from vastian.bridges.giga_dev_bridge.handlers import (
    GigaAdapter,
    write_giga_neuron,
    write_giga_plan,
)

__all__ = ["write_giga_plan", "write_giga_neuron", "GigaAdapter", "register"]


def register():
    """Register Giga bridge tool handlers with the plugin loader."""
    from vastian.loader import register as loader_register

    loader_register("giga_plan_writer", write_giga_plan)
    loader_register("giga_neuron_writer", write_giga_neuron)
    loader_register("giga_memory", GigaAdapter)
