"""Persistent config store — replaces .env for installed-app users.

Reads and writes ``{data_root}/config/local/settings.json``.
For desktop installer users who don't have a ``.env`` file, this is the
primary config source.  For developers, ``.env`` takes priority.

Priority order (highest wins):
  1. Environment variable (e.g. ``OPENAI_API_KEY``)
  2. ``settings.json`` in data root
  3. Pydantic default

Secrets (API keys) are stored in the JSON file.  On desktop, the keyring
library can optionally be used (future enhancement).
"""

from __future__ import annotations

import json
import logging
from pathlib import Path
from typing import Any

logger = logging.getLogger(__name__)

# Fields stored in settings.json — maps JSON key to env var name
_FIELD_MAP: dict[str, str] = {
    "user_name": "VASTIAN_USER_NAME",
    "llm_provider": "VASTIAN_LLM_PROVIDER",
    "openai_api_key": "OPENAI_API_KEY",
    "anthropic_api_key": "ANTHROPIC_API_KEY",
    "default_model": "VASTIAN_DEFAULT_MODEL",
    "fast_model": "VASTIAN_FAST_MODEL",
    "user_tier": "VASTIAN_USER_TIER",
    "port": "VASTIAN_PORT",
    "ollama_base_url": "OLLAMA_BASE_URL",
    "ollama_model": "OLLAMA_MODEL",
    "log_level": "VASTIAN_LOG_LEVEL",
}

_DEFAULTS: dict[str, Any] = {
    "user_name": "",
    "llm_provider": "",
    "openai_api_key": "",
    "anthropic_api_key": "",
    "default_model": "gpt-4o",
    "fast_model": "gpt-4o-mini",
    "user_tier": "admin",
    "port": 4545,
    "ollama_base_url": "http://localhost:11434",
    "ollama_model": "",
    "log_level": "INFO",
}


def _settings_path(data_root: Path) -> Path:
    return data_root / "config" / "local" / "settings.json"


def load_settings_json(data_root: Path) -> dict[str, Any]:
    """Load settings.json from the data root.  Returns empty dict if missing."""
    path = _settings_path(data_root)
    if not path.exists():
        return {}
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
        return data if isinstance(data, dict) else {}
    except Exception:
        logger.warning("Failed to read settings.json at %s", path, exc_info=True)
        return {}


def save_settings_json(data_root: Path, settings: dict[str, Any]) -> None:
    """Write settings to settings.json in the data root."""
    path = _settings_path(data_root)
    path.parent.mkdir(parents=True, exist_ok=True)
    # Merge with existing
    existing = load_settings_json(data_root)
    existing.update(settings)
    path.write_text(
        json.dumps(existing, indent=2, ensure_ascii=False) + "\n",
        encoding="utf-8",
    )
    logger.info("Saved settings.json at %s", path)


def get_config_value(key: str, data_root: Path | None = None) -> Any:
    """Get a config value with priority: env var > settings.json > default.

    If ``data_root`` is None, only checks env vars and defaults.
    """
    import os

    # 1. Environment variable
    env_key = _FIELD_MAP.get(key, "")
    if env_key:
        val = os.environ.get(env_key)
        if val is not None and val != "":
            return val

    # 2. settings.json
    if data_root is not None:
        stored = load_settings_json(data_root)
        if key in stored and stored[key] not in (None, ""):
            return stored[key]

    # 3. Default
    return _DEFAULTS.get(key, "")


def set_config_value(key: str, value: Any, data_root: Path) -> None:
    """Set a config value in settings.json."""
    save_settings_json(data_root, {key: value})


def is_configured(data_root: Path) -> bool:
    """Check if the system has been configured (has an API key or Ollama)."""
    import os

    # Check env vars first
    if os.environ.get("OPENAI_API_KEY") or os.environ.get("ANTHROPIC_API_KEY"):
        return True

    # Check settings.json
    stored = load_settings_json(data_root)
    if stored.get("openai_api_key") or stored.get("anthropic_api_key"):
        return True
    return bool(stored.get("llm_provider") == "ollama" and stored.get("ollama_model"))


def apply_settings_to_env(data_root: Path) -> int:
    """Load settings.json and set any missing env vars from it.

    This bridges the gap: Settings class reads from env vars, and this
    function populates env vars from settings.json for values not already set.

    Returns the number of env vars set.
    """
    import os

    stored = load_settings_json(data_root)
    count = 0
    for json_key, env_key in _FIELD_MAP.items():
        if (
            json_key in stored
            and stored[json_key] not in (None, "")
            and not os.environ.get(env_key)
        ):
            os.environ[env_key] = str(stored[json_key])
            count += 1
    return count
