"""External service integrations for the Vastian Network."""
