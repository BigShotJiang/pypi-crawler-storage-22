"""Vastian Knowledge Store — unified facade over vector, structured, and document storage."""

from vastian.knowledge.store import KnowledgeStore

__all__ = ["KnowledgeStore"]
