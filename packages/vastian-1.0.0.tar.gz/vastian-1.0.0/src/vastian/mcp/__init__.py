"""MCP (Model Context Protocol) client for connecting to external MCP servers.

Vastian's native MCP client replaces Cursor as the bridge for Giga, Zo,
and other MCP providers. Used for: Giga cloud memory sync, Zo messaging,
and future integrations.

See: config/mcp-providers.yaml for provider registry (UI-managed).
"""

from vastian.mcp.client import MCPClient
from vastian.mcp.giga_sync import giga_pull, giga_push
from vastian.mcp.providers import MCPProviderConfig, load_mcp_providers

__all__ = [
    "MCPClient",
    "load_mcp_providers",
    "MCPProviderConfig",
    "giga_push",
    "giga_pull",
]

# zo_client is used by zo_messaging plugin (Mars M1d), not exported to avoid circular imports
