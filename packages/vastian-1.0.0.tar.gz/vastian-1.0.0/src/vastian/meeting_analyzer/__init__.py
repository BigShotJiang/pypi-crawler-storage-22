"""Vastian Meeting Analyzer — package root.

Provides adaptive parsing and signal extraction for meeting summaries
from multiple sources (Teams, Pocket, manual markdown, etc.).
"""

from __future__ import annotations

from .constants import EMPTY_SIGNALS, HEADING_PATTERNS, HEADING_TO_SIGNAL_TYPE, SIGNAL_TYPES
from .extractor import deduplicate_signals, extract_signals_from_sections, merge_signals
from .parser import detect_heading, parse_adaptive

__all__ = [
    "SIGNAL_TYPES",
    "HEADING_PATTERNS",
    "HEADING_TO_SIGNAL_TYPE",
    "EMPTY_SIGNALS",
    "parse_adaptive",
    "detect_heading",
    "extract_signals_from_sections",
    "merge_signals",
    "deduplicate_signals",
]
