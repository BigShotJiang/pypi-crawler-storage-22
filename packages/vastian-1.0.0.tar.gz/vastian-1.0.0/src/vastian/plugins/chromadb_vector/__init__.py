"""ChromaDB Vector plugin — implements VectorProvider protocol.

Extracted from knowledge/vector.py during Phase Venus Wave V1.
The original VectorStore class is now a plugin that can be swapped
for other vector backends (Pinecone, Qdrant, etc.).
"""

from __future__ import annotations

from vastian.knowledge.vector import VectorStore as ChromaDBVectorAdapter

__all__ = ["ChromaDBVectorAdapter"]


def register() -> None:
    """Register this plugin with the loader."""
    from vastian.loader import loader_register

    loader_register("chromadb_vector", ChromaDBVectorAdapter)
