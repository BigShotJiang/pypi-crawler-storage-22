"""Prompt quality and drift detection for Theo.

Compares current agent prompts (from registry/config) against frozen baselines
in state/prompt-baselines/ to detect role drift, prompt_drift, or unintended changes.
"""

from __future__ import annotations

import logging
from pathlib import Path

logger = logging.getLogger(__name__)


def get_drift_report(
    agent_id: str,
    current_prompt_text: str,
    project_root: Path | None = None,
) -> list[dict]:
    """Compare current prompt to baseline and return drift items (stub).

    Args:
        agent_id: Agent ID (e.g. charles, theo).
        current_prompt_text: Full system prompt as built at runtime.
        project_root: Workspace root; defaults to cwd.

    Returns:
        List of drift dicts: [{"type": "prompt_drift"|"role_drift", "summary": str, "severity": str}].
        Stub: returns empty list until baselines are populated and comparison is implemented.
    """
    root = project_root or Path.cwd()
    baselines_dir = root / "state" / "prompt-baselines"
    baseline_path = baselines_dir / f"{agent_id}.md"
    if not baseline_path.exists():
        logger.debug("No baseline for %s at %s", agent_id, baseline_path)
        return []
    # TODO: load baseline, diff or semantic compare against current_prompt_text,
    # return structured drift items for Theo to suggest_prompt_fix.
    return []
