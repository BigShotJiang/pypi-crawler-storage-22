"""Provider interfaces — contracts that core code depends on.

Core modules import from providers/ only. Never from plugins/ or bridges/.
Each provider defines an ABC that plugin implementations must satisfy.
"""
