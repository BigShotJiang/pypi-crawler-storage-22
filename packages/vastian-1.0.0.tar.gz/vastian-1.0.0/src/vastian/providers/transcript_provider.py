"""Transcript provider protocol — re-exported from bridges.protocols."""

from __future__ import annotations

from vastian.bridges.protocols import TranscriptProvider

__all__ = ["TranscriptProvider"]
