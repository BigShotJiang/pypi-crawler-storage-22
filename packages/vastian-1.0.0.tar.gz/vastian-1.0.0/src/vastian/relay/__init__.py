"""The Relay — backend agent outbox aggregation for Maria.

Backend agents (Henry, Theo, Orion, Elias, Adrian, Jake, Kiran, Felix) write
report JSON files to state/relay/outbox/{category}/. Maria reads these via
read_relay_outbox and creates REL- tickets (Kanban tasks) for triage.

Relay report JSON schema (per file):
  - agent_id: str
  - category: str (ux, prompts, ops, pulse, personas, metrics, scenarios, knowledge)
  - summary: str
  - payload: dict (optional)
  - timestamp: str (ISO optional)
"""

from vastian.relay.reader import read_relay_outbox
from vastian.relay.writer import write_relay_report

__all__ = ["read_relay_outbox", "write_relay_report"]
