"""Vastian Session Protocol — backward-compat re-exports.

Canonical location: vastian.bridges.cursor_bridge.sessions
This stub exists so existing imports continue to work.
"""

from vastian.bridges.cursor_bridge.sessions.engine import SessionEngine
from vastian.bridges.cursor_bridge.sessions.models import (
    SessionDirection,
    SessionMessage,
    SessionPhase,
    SessionRound,
    VastianSession,
)

__all__ = [
    "VastianSession",
    "SessionDirection",
    "SessionPhase",
    "SessionMessage",
    "SessionRound",
    "SessionEngine",
]
