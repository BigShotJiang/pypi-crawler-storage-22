"""Backward-compat stub — SessionEngine lives in bridges/cursor_bridge/sessions/engine.py now."""

from vastian.bridges.cursor_bridge.sessions.engine import SessionEngine  # noqa: F401
