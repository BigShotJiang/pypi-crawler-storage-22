"""Backward-compat stub — Session models live in bridges/cursor_bridge/sessions/models.py now."""

from vastian.bridges.cursor_bridge.sessions.models import (  # noqa: F401
    SessionDirection,
    SessionMessage,
    SessionPhase,
    SessionRound,
    VastianSession,
)
