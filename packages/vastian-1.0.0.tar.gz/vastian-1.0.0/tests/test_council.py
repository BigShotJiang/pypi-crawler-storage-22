"""Tests for the Mentor Council system."""

import pytest

from vastian.council.session import (
    CouncilSession,
    CouncilType,
    CouncilPhase,
    Contribution,
    ActionItem,
)
from vastian.council.synthesizer import (
    extract_themes,
    calculate_consensus_score,
    format_council_report,
)


@pytest.fixture
def sample_session() -> CouncilSession:
    return CouncilSession(
        council_type=CouncilType.STRATEGIC_REVIEW,
        topic="Q1 Strategic Alignment",
        member_ids=["rowan", "victor", "dominic", "orion"],
        synthesizer_id="dominic",
    )


class TestCouncilSession:
    def test_creation(self, sample_session: CouncilSession) -> None:
        assert sample_session.council_type == CouncilType.STRATEGIC_REVIEW
        assert sample_session.phase == CouncilPhase.CONVENE
        assert len(sample_session.member_ids) == 4

    def test_add_contribution(self, sample_session: CouncilSession) -> None:
        sample_session.current_round = 1
        contrib = sample_session.add_contribution(
            agent_id="rowan",
            agent_name="Rowan",
            content="We need to focus on alignment across all modules.",
        )
        assert contrib.round_number == 1
        assert len(sample_session.contributions) == 1

    def test_advance_round(self, sample_session: CouncilSession) -> None:
        assert sample_session.advance_round()
        assert sample_session.current_round == 1
        sample_session.max_rounds = 2
        assert sample_session.advance_round()
        assert not sample_session.advance_round()  # max reached

    def test_transcript(self, sample_session: CouncilSession) -> None:
        sample_session.current_round = 1
        sample_session.add_contribution(
            agent_id="rowan",
            agent_name="Rowan",
            content="Focus on alignment.",
        )
        sample_session.add_contribution(
            agent_id="victor",
            agent_name="Victor",
            content="Vision clarity is paramount.",
        )
        transcript = sample_session.transcript
        assert "Rowan" in transcript
        assert "Victor" in transcript
        assert "Focus on alignment" in transcript

    def test_summary(self, sample_session: CouncilSession) -> None:
        summary = sample_session.to_summary()
        assert summary["type"] == "strategic_review"
        assert summary["topic"] == "Q1 Strategic Alignment"
        assert len(summary["members"]) == 4


class TestSynthesizer:
    def test_extract_themes(self) -> None:
        contributions = [
            Contribution(
                agent_id="rowan",
                agent_name="Rowan",
                round_number=1,
                content="We need better alignment across teams and prioritize the integration.",
            ),
            Contribution(
                agent_id="victor",
                agent_name="Victor",
                round_number=1,
                content="The timeline concerns me. We should prioritize carefully.",
            ),
        ]
        themes = extract_themes(contributions)
        assert "alignment" in themes
        assert "priority" in themes
        assert "rowan" in themes["alignment"]

    def test_consensus_score_no_dissent(self, sample_session: CouncilSession) -> None:
        sample_session.current_round = 1
        sample_session.add_contribution("rowan", "Rowan", "I agree.")
        sample_session.add_contribution("victor", "Victor", "I concur.")
        score = calculate_consensus_score(sample_session)
        assert score == 1.0

    def test_consensus_score_with_dissent(self, sample_session: CouncilSession) -> None:
        sample_session.current_round = 1
        sample_session.add_contribution("rowan", "Rowan", "I agree.")
        sample_session.contributions[-1].dissent_from = ["victor"]
        sample_session.add_contribution("victor", "Victor", "I disagree.")
        score = calculate_consensus_score(sample_session)
        assert score < 1.0

    def test_format_council_report(self, sample_session: CouncilSession) -> None:
        sample_session.current_round = 1
        sample_session.add_contribution("rowan", "Rowan", "Prioritize alignment.")
        sample_session.synthesis = "The council recommends focusing on alignment."
        sample_session.action_items.append(
            ActionItem(
                description="Draft alignment plan",
                assigned_to="dominic",
                priority="high",
            )
        )
        report = format_council_report(sample_session)
        assert "MENTOR COUNCIL REPORT" in report
        assert "Strategic Review" in report
        assert "alignment plan" in report
