"""Tests for the plugin loader registry."""

from __future__ import annotations

import pytest

from vastian import loader


@pytest.fixture(autouse=True)
def _clean_registry(monkeypatch: pytest.MonkeyPatch) -> None:
    """Isolate each test from the global registry."""
    monkeypatch.setattr(loader, "_registry", {})


class _DummyPlugin:
    pass


class _AnotherPlugin:
    pass


class TestRegisterAndGet:
    def test_register_and_get(self) -> None:
        loader.register("test_provider", _DummyPlugin)
        assert loader.get("test_provider") is _DummyPlugin

    def test_get_unregistered_raises_keyerror(self) -> None:
        with pytest.raises(KeyError, match="No plugin registered"):
            loader.get("nonexistent")

    def test_available_returns_registered_names(self) -> None:
        loader.register("alpha", _DummyPlugin)
        loader.register("beta", _AnotherPlugin)
        names = loader.available()
        assert "alpha" in names
        assert "beta" in names
        assert len(names) == 2

    def test_is_registered_true_and_false(self) -> None:
        assert not loader.is_registered("test_provider")
        loader.register("test_provider", _DummyPlugin)
        assert loader.is_registered("test_provider")

    def test_register_overwrites_previous(self) -> None:
        loader.register("test_provider", _DummyPlugin)
        loader.register("test_provider", _AnotherPlugin)
        assert loader.get("test_provider") is _AnotherPlugin

    def test_available_empty_initially(self) -> None:
        assert loader.available() == []
