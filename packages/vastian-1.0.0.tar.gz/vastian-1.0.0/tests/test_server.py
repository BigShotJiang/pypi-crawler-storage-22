"""Tests for the unified FastAPI server."""

from __future__ import annotations

import pytest
from fastapi.testclient import TestClient

from vastian.server import create_app


class TestHealthEndpoint:
    """Test /api/health endpoint."""

    def test_health_returns_ready(self) -> None:
        app = create_app()
        client = TestClient(app)
        resp = client.get("/api/health")
        assert resp.status_code == 200
        data = resp.json()
        assert data["status"] == "ready"
        assert "version" in data


class TestUnifiedShell:
    """Test Vastian unified shell."""

    def test_root_serves_shell(self) -> None:
        app = create_app()
        client = TestClient(app)
        resp = client.get("/")
        assert resp.status_code == 200
        html = resp.text
        assert "sidebar" in html
        assert "#/dashboard" in html
        assert "nav-item" in html

    def test_chat_commands_endpoint(self) -> None:
        app = create_app()
        client = TestClient(app)
        resp = client.get("/api/chat/commands")
        assert resp.status_code == 200
        data = resp.json()
        assert "commands" in data
        assert "agents" in data

    def test_chat_requires_message(self) -> None:
        app = create_app()
        client = TestClient(app)
        resp = client.post("/api/chat", json={})
        assert resp.status_code == 200
        data = resp.json()
        assert data.get("ok") is False
        assert "message" in data.get("error", "").lower()
