# Vastian Network

A distributed multi-agent system for personal and professional knowledge management, with MARL-inspired Mentor Council collaboration.

## Install

```bash
pip install vastian
```

## Quick Start

```bash
vastian serve          # Start the web UI (http://127.0.0.1:4545)
vastian chat           # Interactive CLI with agents
```

## Key Commands

| Command | Description |
|---------|-------------|
| `vastian serve` | Start the unified app (dashboard, copilot, boards) |
| `vastian chat` | Interactive session; use `/help` for commands |
| `vastian setup gdrive` / `vastian setup dropbox` | Backup storage OAuth |
| `vastian backup-panel` | Web UI for backup config |
| `vastian worker` | Background task processor |
| `vastian giga push` / `vastian giga pull` | Giga memory sync |

## Desktop App

Download the installer for [Windows](https://vastianconnect.com) or [macOS](https://vastianconnect.com). The desktop app bundles the backend and runs the same unified UI in a native window.

## Configuration

- **First run:** The app creates a data folder. You can set `VASTIAN_DATA_ROOT` to choose the location.
- **LLM provider:** Configure via the Settings page in the app, or set `VASTIAN_LLM_PROVIDER` and API keys in `.env`.

## Troubleshooting (Desktop App)

**Backend won't start from the installer**

1. **Check the log:**  
   - Windows: `%LOCALAPPDATA%\com.vastian\logs\vastian.log` or `%LOCALAPPDATA%\Vastian\logs\vastian.log`  
   - macOS: `~/Library/Application Support/com.vastian/logs/vastian.log`

2. **Run from Command Prompt** to see errors: open cmd, go to the install folder (e.g. `C:\Users\YourName\AppData\Local\Programs\Vastian`), run `Vastian.exe`. Stderr appears in the console.

3. **First launch** can take 60–90s — PyInstaller extracts on first run.

4. **Port 4545** must be free. Check with `netstat -an | findstr 4545` (Windows) or `lsof -i :4545` (macOS).

5. **Antivirus** may block `vastian-backend.exe` — add an exception if needed.

## More

- [vastianconnect.com](https://vastianconnect.com) — Documentation and downloads
