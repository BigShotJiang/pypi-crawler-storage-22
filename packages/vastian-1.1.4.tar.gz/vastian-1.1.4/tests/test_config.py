"""Unit tests for configuration and model catalog."""

from __future__ import annotations

import pytest

from vastian.config import (
    LLMProvider,
    Settings,
    OPENAI_MODELS,
    ANTHROPIC_MODELS,
    MODEL_CATALOG,
)


class TestLLMProvider:
    """Test the LLMProvider enum."""

    def test_provider_values(self) -> None:
        assert LLMProvider.OPENAI.value == "openai"
        assert LLMProvider.ANTHROPIC.value == "anthropic"
        assert LLMProvider.AUTO.value == "auto"
        assert LLMProvider.LOCAL.value == "local"

    def test_string_enum(self) -> None:
        assert isinstance(LLMProvider.OPENAI, str)
        assert LLMProvider.OPENAI == "openai"


class TestModelCatalog:
    """Test the model catalog and model name constants."""

    def test_openai_models_defined(self) -> None:
        assert "default" in OPENAI_MODELS
        assert "fast" in OPENAI_MODELS
        assert OPENAI_MODELS["default"] == "gpt-4o"
        assert OPENAI_MODELS["fast"] == "gpt-4o-mini"

    def test_anthropic_models_defined(self) -> None:
        assert "default" in ANTHROPIC_MODELS
        assert "fast" in ANTHROPIC_MODELS
        assert (
            "opus" in ANTHROPIC_MODELS["default"].lower() or "claude" in ANTHROPIC_MODELS["default"]
        )
        assert "sonnet" in ANTHROPIC_MODELS["fast"].lower() or "claude" in ANTHROPIC_MODELS["fast"]

    def test_catalog_has_both_providers(self) -> None:
        assert "openai" in MODEL_CATALOG
        assert "anthropic" in MODEL_CATALOG

    def test_catalog_entries_are_tuples(self) -> None:
        for provider, tiers in MODEL_CATALOG.items():
            for tier, (prov, model) in tiers.items():
                assert isinstance(prov, str)
                assert isinstance(model, str)
                assert prov == provider


class TestSettings:
    """Test the Settings Pydantic model."""

    def test_defaults(self, monkeypatch: pytest.MonkeyPatch) -> None:
        # Isolate from real env vars and .env file
        monkeypatch.delenv("OPENAI_API_KEY", raising=False)
        monkeypatch.delenv("ANTHROPIC_API_KEY", raising=False)
        monkeypatch.delenv("VASTIAN_LLM_PROVIDER", raising=False)
        # Use _env_file=None to prevent pydantic-settings from reading .env
        s = Settings(_env_file=None)
        assert s.llm_provider == LLMProvider.OLLAMA
        assert s.default_model == "gpt-4o"
        assert s.fast_model == "gpt-4o-mini"

    def test_settings_paths(self) -> None:
        s = Settings(
            OPENAI_API_KEY="",
            ANTHROPIC_API_KEY="",
        )
        assert s.agents_dir.name == "agents"
        assert s.docs_dir.name == "docs"
        assert str(s.sqlite_path).endswith("vastian.db")
