"""Bridges — dev-only tooling that helps build but is not required at runtime.

Bridges connect development tools (Cursor, Giga) to the Vastian agent system.
Core never imports bridges directly.
"""
