"""Copilot bridge stub -- proves CodingAgentBridge protocol is swappable.

This adapter satisfies the CodingAgentBridge protocol via structural
subtyping (typing.Protocol). It is NOT yet wired to GitHub Copilot --
all methods raise NotImplementedError with guidance on what would be
needed to complete the integration.

To wire Copilot:
1. Copilot communicates via MCP or VS Code extension API
2. Messages would need to be routed through Vastian's orchestrator
3. The prompt format may differ from Cursor (adjust in query_agent)
4. Copilot may not support the same tool-calling patterns

isinstance(CopilotAdapter(), CodingAgentBridge) returns True, proving
the Protocol contract works without inheritance.
"""

from __future__ import annotations

import logging
from typing import Any

logger = logging.getLogger(__name__)


class CopilotAdapter:
    """GitHub Copilot adapter stub implementing CodingAgentBridge protocol.

    All methods raise NotImplementedError. This stub exists to prove
    that the CodingAgentBridge Protocol is truly swappable -- any class
    implementing the same methods satisfies the contract without importing
    or inheriting from Vastian.
    """

    async def query_agent(self, agent_id: str, message: str) -> str:
        """Send a message to a single agent via Copilot."""
        raise NotImplementedError(
            "CopilotAdapter.query_agent not yet wired. "
            "Needs: MCP connection to Vastian orchestrator from VS Code Copilot extension."
        )

    async def query_agents(self, agent_ids: list[str], message: str) -> dict[str, str]:
        """Send the same message to multiple agents via Copilot."""
        raise NotImplementedError(
            "CopilotAdapter.query_agents not yet wired. "
            "Needs: Same as query_agent, with parallel dispatch."
        )

    async def quiz_agents(self, agent_ids: list[str], questions: str) -> dict[str, str]:
        """Quiz multiple agents via Copilot."""
        raise NotImplementedError(
            "CopilotAdapter.quiz_agents not yet wired. "
            "Needs: Same as query_agents, with quiz-formatted prompt."
        )

    async def present(self, agent_ids: list[str], brief: str) -> dict[str, Any]:
        """Present a brief to agents via Copilot."""
        raise NotImplementedError(
            "CopilotAdapter.present not yet wired. "
            "Needs: Same as query_agents, with presentation-formatted prompt."
        )

    def persist_briefs(self, results: dict[str, Any], agent_ids: list[str]) -> None:
        """Write session outcomes to agent docs."""
        raise NotImplementedError(
            "CopilotAdapter.persist_briefs not yet wired. "
            "Needs: Access to docs/ directory for brief file writes."
        )


def _verify_protocol() -> bool:
    """Verify CopilotAdapter satisfies CodingAgentBridge at import time."""
    from vastian.bridges.protocols import CodingAgentBridge

    return isinstance(CopilotAdapter(), CodingAgentBridge)


__all__ = ["CopilotAdapter"]
