"""Vastian Message Bus — async event-driven inter-agent communication."""

from vastian.bus.bus import MessageBus
from vastian.bus.message import Message, MessageType, Priority

__all__ = ["Message", "MessageType", "Priority", "MessageBus"]
