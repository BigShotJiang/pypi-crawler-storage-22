"""Plugin loader — simple dict registry mapping provider names to plugin classes.

MVP implementation: manual registration. Auto-discovery is in the product
readiness backlog.

Usage:
    from vastian.loader import register, get

    # In a plugin's __init__.py:
    register("openai_llm", OpenAIProvider)

    # In core code (via provider interface):
    cls = get("openai_llm")
    instance = cls(settings)
"""

from __future__ import annotations

from typing import Any

_registry: dict[str, Any] = {}


def register(provider_name: str, cls: Any) -> None:
    """Register a plugin class or adapter under a provider name."""
    _registry[provider_name] = cls


def get(provider_name: str) -> type:
    """Retrieve a registered plugin class by provider name.

    Raises KeyError if the provider has not been registered.
    """
    if provider_name not in _registry:
        raise KeyError(
            f"No plugin registered for provider '{provider_name}'. "
            f"Available: {list(_registry.keys())}"
        )
    return _registry[provider_name]


def available() -> list[str]:
    """Return the names of all registered providers."""
    return list(_registry.keys())


def is_registered(provider_name: str) -> bool:
    """Check whether a provider name has been registered."""
    return provider_name in _registry


# Alias for plugins that use loader_register
loader_register = register
