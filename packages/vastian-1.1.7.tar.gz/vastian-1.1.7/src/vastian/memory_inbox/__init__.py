"""Memory Inbox — processor and distribution pipeline.

Reads external context from state/memory-inbox/{mind}/, writes raw context
to docs/shared/{mind}/context.md, and distributes tailored briefs to
subscribed agents via Charles.

This module is provider-agnostic: any memory system writes JSON to the
inbox dirs, and this module consumes them.
"""

from __future__ import annotations

from .distributor import distribute_briefs
from .processor import InboxProcessor

__all__ = ["InboxProcessor", "distribute_briefs"]
