"""Plugin implementations — concrete adapters that talk to external systems.

Each plugin lives in its own sub-package and implements a provider interface.
Plugins are loaded via loader.py at startup. Core never imports plugins directly.
"""
