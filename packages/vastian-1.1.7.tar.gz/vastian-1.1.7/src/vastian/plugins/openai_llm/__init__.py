"""OpenAI LLM plugin — implements BaseLLMProvider for OpenAI models."""

from __future__ import annotations

import logging

from vastian.config import Settings
from vastian.providers.llm_provider import BaseLLMProvider

logger = logging.getLogger(__name__)


class OpenAIProvider(BaseLLMProvider):
    """OpenAI API provider."""

    def __init__(self, settings: Settings) -> None:
        super().__init__(settings)
        from openai import AsyncOpenAI

        self.client = AsyncOpenAI(api_key=settings.openai_api_key)
        self.last_usage: dict[str, int] = {}  # populated after each call

    def _extract_usage(self, response: object, model: str) -> None:
        """Extract token usage from response and store for tracking."""
        usage = getattr(response, "usage", None)
        if usage:
            self.last_usage = {
                "provider": "openai",
                "model": model,
                "input_tokens": getattr(usage, "prompt_tokens", 0) or 0,
                "output_tokens": getattr(usage, "completion_tokens", 0) or 0,
            }
        else:
            self.last_usage = {}

    async def generate(
        self,
        system_prompt: str,
        messages: list[dict[str, str]],
        model: str | None = None,
        temperature: float = 0.7,
        max_tokens: int = 4096,
    ) -> str:
        model = model or self.default_model
        full_messages = [{"role": "system", "content": system_prompt}] + messages

        response = await self.client.chat.completions.create(
            model=model,
            messages=full_messages,
            temperature=temperature,
            max_tokens=max_tokens,
        )
        self._extract_usage(response, model)
        return response.choices[0].message.content or ""

    async def generate_with_tools(
        self,
        system_prompt: str,
        messages: list[dict[str, str]],
        tools: list[dict],
        model: str | None = None,
        temperature: float = 0.7,
    ) -> dict:
        model = model or self.default_model
        full_messages = [{"role": "system", "content": system_prompt}] + messages

        response = await self.client.chat.completions.create(
            model=model,
            messages=full_messages,
            tools=tools,
            temperature=temperature,
        )
        self._extract_usage(response, model)
        choice = response.choices[0]

        result: dict = {"content": choice.message.content or ""}
        if choice.message.tool_calls:
            result["tool_calls"] = [
                {
                    "id": tc.id,
                    "function": tc.function.name,
                    "arguments": tc.function.arguments,
                }
                for tc in choice.message.tool_calls
            ]
        return result


def register() -> None:
    """Register the OpenAI LLM plugin with the loader."""
    from vastian.loader import register as loader_register

    loader_register("openai_llm", OpenAIProvider)
