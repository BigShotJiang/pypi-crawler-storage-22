"""SQLite Structured plugin — implements StructuredProvider protocol.

Extracted from knowledge/structured.py during Phase Venus Wave V1.
The original StructuredStore class is now a plugin that can be swapped
for other structured backends (Postgres, Supabase, etc.).
"""

from __future__ import annotations

from vastian.knowledge.structured import StructuredStore as SQLiteStructuredAdapter

__all__ = ["SQLiteStructuredAdapter"]


def register() -> None:
    """Register this plugin with the loader."""
    from vastian.loader import loader_register

    loader_register("sqlite_structured", SQLiteStructuredAdapter)
