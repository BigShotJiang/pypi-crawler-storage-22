"""Finance provider protocol — re-exported from bridges.protocols for convenience.

Core modules import from providers/ only. Plugin implementations (e.g.
mercury_finance) satisfy the FinanceProvider protocol by implementing:
  - get_balances() -> list[dict]
  - list_accounts() -> list[dict]
  - get_transactions(account_id, start_date?, end_date?) -> list[dict]
"""

from __future__ import annotations

from vastian.bridges.protocols import FinanceProvider

__all__ = ["FinanceProvider"]
