# Inbox — Async Updates

Drop `.txt` files here for processing. No CLI needed.

**Lifecycle:** inbox → intake (processing) → complete (done)

- Charles triages each file and delegates to the right agents
- For Kanban tasks: name files `task-{kanban_id}-description.txt` to route directly
- Use `intro.txt` for onboarding: tell the network about yourself, then run `/onboard`
