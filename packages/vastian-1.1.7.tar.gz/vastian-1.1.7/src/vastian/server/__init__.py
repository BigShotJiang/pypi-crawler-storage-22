"""Unified HTTP server — FastAPI app consolidating feed, roster, persona, settings, backup.

PSB2: Single port (4545) for all web UI + API.
"""

from vastian.server.app import (
    create_app,
    find_available_port,
    run_server,
    run_server_async,
    run_server_blocking,
)

__all__ = [
    "create_app",
    "find_available_port",
    "run_server",
    "run_server_async",
    "run_server_blocking",
]
