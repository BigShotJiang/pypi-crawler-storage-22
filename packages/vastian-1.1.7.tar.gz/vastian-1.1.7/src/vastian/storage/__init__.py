"""Git-tracked file-based storage for persistent Vastian Network state."""

from vastian.storage.data_root import get_config_dir, get_data_root, set_data_root
from vastian.storage.file_store import FileStore

__all__ = ["FileStore", "get_data_root", "get_config_dir", "set_data_root"]
