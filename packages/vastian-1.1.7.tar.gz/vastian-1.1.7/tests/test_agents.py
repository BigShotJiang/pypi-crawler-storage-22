"""Tests for the Vastian agent system."""

import pytest
from pathlib import Path

from vastian.agents.base import AgentConfig, BaseAgent, AgentState
from vastian.agents.registry import AgentRegistry
from vastian.bus import MessageBus, Message, MessageType


@pytest.fixture
def sample_config() -> AgentConfig:
    return AgentConfig(
        agent_id="test-agent",
        name="Test Agent",
        title="Test Specialist",
        sigil="🧪",
        tone="Professional and clear",
        role_description="A test agent for unit testing.",
        responsibilities=["Run tests", "Validate behavior"],
        owned_documents=["test-report.md"],
        reports_to="dominic",
        teams=["vv-dev"],
    )


@pytest.fixture
def bus() -> MessageBus:
    return MessageBus()


class TestAgentConfig:
    def test_display_name(self, sample_config: AgentConfig) -> None:
        assert sample_config.display_name == "🧪 Test Agent (Test Specialist)"

    def test_display_name_no_sigil(self) -> None:
        config = AgentConfig(
            agent_id="plain",
            name="Plain",
            title="Agent",
            role_description="A plain agent.",
        )
        assert config.display_name == "Plain (Agent)"


class TestBaseAgent:
    def test_agent_creation(self, sample_config: AgentConfig, bus: MessageBus) -> None:
        agent = BaseAgent(config=sample_config, bus=bus)
        assert agent.agent_id == "test-agent"
        assert agent.state == AgentState.IDLE
        assert "test-agent" in bus.agent_ids

    def test_system_prompt(self, sample_config: AgentConfig, bus: MessageBus) -> None:
        agent = BaseAgent(config=sample_config, bus=bus)
        prompt = agent.build_system_prompt()
        assert "Test Agent" in prompt
        assert "Test Specialist" in prompt
        assert "Run tests" in prompt
        assert "test-report.md" in prompt
        assert "dominic" in prompt

    @pytest.mark.asyncio
    async def test_process_query_stub(self, sample_config: AgentConfig, bus: MessageBus) -> None:
        agent = BaseAgent(config=sample_config, bus=bus)
        msg = Message(
            sender="user",
            recipient="test-agent",
            type=MessageType.QUERY,
            payload={"content": "What are you working on?"},
        )
        response = await agent.process_message(msg)
        assert response is not None
        assert "content" in response.payload
        assert response.sender == "test-agent"


class TestAgentRegistry:
    def test_load_from_directory(self) -> None:
        registry = AgentRegistry()
        agents_dir = Path(__file__).parent.parent / "agents"
        if agents_dir.exists():
            count = registry.load_from_directory(agents_dir)
            assert count > 0
            assert "rowan" in registry.agent_ids
            assert "charles" in registry.agent_ids

    def test_reporting_chain(self) -> None:
        registry = AgentRegistry()
        agents_dir = Path(__file__).parent.parent / "agents"
        if agents_dir.exists():
            registry.load_from_directory(agents_dir)
            chain = registry.get_reporting_chain("liam")
            assert "dominic" in chain
            assert "rowan" in chain

    def test_team_members(self) -> None:
        registry = AgentRegistry()
        agents_dir = Path(__file__).parent.parent / "agents"
        if agents_dir.exists():
            registry.load_from_directory(agents_dir)
            sync_team = registry.get_team_members("vv-sync")
            assert "liam" in sync_team
            assert "elias" in sync_team
