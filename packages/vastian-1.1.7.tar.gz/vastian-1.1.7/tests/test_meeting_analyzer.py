"""Tests for the meeting analyzer — parser and extractor."""

from __future__ import annotations

import pytest

from vastian.meeting_analyzer.parser import parse_adaptive, detect_heading
from vastian.meeting_analyzer.extractor import (
    extract_signals_from_sections,
    extract_items,
    merge_signals,
    deduplicate_signals,
    extract_from_synthesized,
)


class TestParseAdaptive:
    def test_markdown_headings_parsed(self) -> None:
        text = "## Action Items\n- Do the thing\n- Do another thing"
        result = parse_adaptive(text)
        assert "action_item" in result
        assert "Do the thing" in result["action_item"]

    def test_colon_headers_parsed(self) -> None:
        text = "Decisions:\n- We decided to proceed\n\nRisks:\n- Might be late"
        result = parse_adaptive(text)
        assert "decision" in result
        assert "risk" in result

    def test_no_headings_returns_notes(self) -> None:
        text = "Just some plain text without any headings at all."
        result = parse_adaptive(text)
        assert "notes" in result
        assert "plain text" in result["notes"]

    def test_multiple_sections(self) -> None:
        text = (
            "## Decisions\n- Approved the plan\n\n"
            "## Blockers\n- Waiting on API key\n\n"
            "## Ideas\n- Try a new approach"
        )
        result = parse_adaptive(text)
        assert "decision" in result
        assert "blocker" in result
        assert "idea" in result

    def test_html_aside_skipped(self) -> None:
        text = "<aside class='note'>hidden</aside>\n## Notes\n- Visible content"
        result = parse_adaptive(text)
        # The aside tag should not appear in any section content
        for value in result.values():
            assert "hidden" not in value


class TestDetectHeading:
    def test_markdown_heading(self) -> None:
        result = detect_heading("## Action Items")
        assert result == "action_item"

    def test_non_heading_returns_none(self) -> None:
        result = detect_heading("Just regular text here")
        assert result is None

    def test_bold_heading(self) -> None:
        result = detect_heading("**Decisions**")
        assert result == "decision"

    def test_colon_heading(self) -> None:
        result = detect_heading("Risks:")
        assert result == "risk"


class TestExtractSignals:
    def test_extract_from_sections(self) -> None:
        sections = {
            "decision": "- We approved the plan\n- Finalized the budget",
            "action_item": "- Henry to review architecture",
            "blocker": "- Waiting on API key",
        }
        signals = extract_signals_from_sections(sections)
        assert len(signals["decisions"]) == 2
        assert len(signals["action_items"]) == 1
        assert len(signals["blockers"]) == 1

    def test_extract_items(self) -> None:
        content = "- First item\n- Second item\n- Third item"
        items = extract_items(content)
        assert len(items) == 3
        assert items[0] == "First item"

    def test_extract_items_skips_short(self) -> None:
        content = "- OK\n- A longer item here\n- Hi"
        items = extract_items(content)
        assert len(items) == 1
        assert items[0] == "A longer item here"

    def test_merge_signals(self) -> None:
        base = {"decisions": ["Plan A"], "action_items": [], "risks": []}
        additional = {"decisions": ["Plan B"], "action_items": ["Do X"]}
        result = merge_signals(base, additional)
        assert "Plan A" in result["decisions"]
        assert "Plan B" in result["decisions"]
        assert "Do X" in result["action_items"]

    def test_merge_signals_skips_duplicates(self) -> None:
        base = {"decisions": ["Plan A"], "action_items": []}
        additional = {"decisions": ["Plan A"]}
        result = merge_signals(base, additional)
        assert result["decisions"].count("Plan A") == 1

    def test_deduplicate_signals(self) -> None:
        signals = {
            "decisions": ["Plan A", "plan a", "Plan B"],
            "action_items": ["Do X", "do x"],
        }
        result = deduplicate_signals(signals)
        assert len(result["decisions"]) == 2
        assert len(result["action_items"]) == 1

    def test_extract_from_synthesized(self) -> None:
        text = (
            "Decisions:\n"
            "- We approved the plan\n"
            "Action Items:\n"
            "- Henry to review\n"
            "Risks:\n"
            "- Timeline might slip"
        )
        result = extract_from_synthesized(text)
        assert len(result["decisions"]) == 1
        assert len(result["action_items"]) == 1
        assert len(result["risks"]) == 1
