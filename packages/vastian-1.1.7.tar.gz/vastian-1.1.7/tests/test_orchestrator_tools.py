"""Unit tests for the orchestrator tool registry and tool definitions."""

from __future__ import annotations

import pytest

from vastian.orchestrator.orchestrator import (
    AGENT_TOOL_REGISTRY,
    TOOL_DESCRIPTIONS,
    get_tools_for_agent,
    get_tool_names_for_agent,
    BASE_TOOLS,
)


class TestToolRegistry:
    """Test the agent tool registry."""

    KNOWN_AGENTS = [
        "charles",
        "dominic",
        "liam",
        "henry",
        "finley",
        "theo",
        "elias",
        "victor",
        "adrian",
        "concord",
        "jake",
        "orion",
        "rowan",
    ]

    def test_all_agents_have_tool_entries(self) -> None:
        for agent_id in self.KNOWN_AGENTS:
            assert agent_id in AGENT_TOOL_REGISTRY, f"{agent_id} missing from AGENT_TOOL_REGISTRY"

    def test_all_agents_have_base_tools(self) -> None:
        base_names = {t["function"]["name"] for t in BASE_TOOLS}
        for agent_id in self.KNOWN_AGENTS:
            tools = get_tools_for_agent(agent_id)
            tool_names = {t["function"]["name"] for t in tools}
            assert base_names.issubset(tool_names), f"{agent_id} missing base tools"

    def test_liam_has_batch_tools(self) -> None:
        names = get_tool_names_for_agent("liam")
        assert "batch_delegate" in names
        assert "targeted_batch_delegate" in names
        assert "spawn_sub_agent" in names

    def test_henry_has_code_tools(self) -> None:
        names = get_tool_names_for_agent("henry")
        assert "search_codebase" in names
        assert "spawn_sub_agent" in names

    def test_theo_has_audit_tools(self) -> None:
        names = get_tool_names_for_agent("theo")
        assert "read_agent_config" in names
        assert "suggest_prompt_fix" in names

    def test_concord_has_simulation_tools(self) -> None:
        names = get_tool_names_for_agent("concord")
        assert "run_simulation" in names

    def test_jake_has_metrics_tools(self) -> None:
        names = get_tool_names_for_agent("jake")
        assert "score_metrics" in names

    def test_charles_has_network_tools(self) -> None:
        names = get_tool_names_for_agent("charles")
        assert "get_network_status" in names
        assert "get_tasks" in names

    def test_unknown_agent_gets_base_tools(self) -> None:
        tools = get_tools_for_agent("nobody")
        assert tools == BASE_TOOLS


class TestToolDescriptions:
    """Test that all tools have human-readable descriptions."""

    def test_all_tools_have_descriptions(self) -> None:
        all_tool_names: set[str] = set()
        for tools in AGENT_TOOL_REGISTRY.values():
            for tool in tools:
                all_tool_names.add(tool["function"]["name"])

        for name in all_tool_names:
            assert name in TOOL_DESCRIPTIONS, f"Missing description for tool: {name}"

    def test_tool_definitions_valid_format(self) -> None:
        for agent_id, tools in AGENT_TOOL_REGISTRY.items():
            for tool in tools:
                assert tool.get("type") == "function", f"Bad tool type for {agent_id}"
                func = tool.get("function", {})
                assert "name" in func, f"Missing name in tool for {agent_id}"
                assert "description" in func, f"Missing desc in tool for {agent_id}"
                assert "parameters" in func, f"Missing params in tool for {agent_id}"
