"""Tests for protocol contracts — runtime_checkable isinstance checks."""

from __future__ import annotations

import pytest
from unittest.mock import MagicMock

from vastian.bridges.protocols import (
    CodingAgentBridge,
    MemoryBridge,
    ContentBridge,
    LLMProvider,
    TranscriptProvider,
    SummaryProvider,
    FinanceProvider,
)
from vastian.bridges.giga_dev_bridge.handlers import GigaAdapter
from vastian.bridges.cursor_bridge.direct import CursorAdapter
from vastian.bridges.content_bridge.manual_input import ManualInputAdapter
from vastian.bridges.content_bridge.meeting_summary import MeetingSummaryAdapter
from vastian.bridges.content_bridge.transcript import TranscriptAdapter


class TestProtocolRuntimeCheckable:
    """Verify all protocols have the @runtime_checkable decorator."""

    def test_coding_agent_bridge_is_runtime_checkable(self) -> None:
        assert hasattr(CodingAgentBridge, "__protocol_attrs__") or hasattr(
            CodingAgentBridge, "_is_runtime_protocol"
        )

    def test_memory_bridge_is_runtime_checkable(self) -> None:
        assert isinstance(GigaAdapter(), MemoryBridge)

    def test_content_bridge_is_runtime_checkable(self) -> None:
        assert isinstance(ManualInputAdapter(), ContentBridge)


class TestMemoryBridge:
    def test_giga_adapter_satisfies_memory_bridge(self) -> None:
        adapter = GigaAdapter()
        assert isinstance(adapter, MemoryBridge)

    def test_incomplete_class_fails_memory_bridge(self) -> None:
        class Incomplete:
            def write_plan(self, agent_id, key_name, content, mind="x"): ...

        assert not isinstance(Incomplete(), MemoryBridge)


class TestCodingAgentBridge:
    def test_cursor_adapter_satisfies_coding_agent_bridge(self) -> None:
        mock_orch = MagicMock()
        adapter = CursorAdapter(mock_orch)
        assert isinstance(adapter, CodingAgentBridge)


class TestContentBridge:
    def test_manual_input_satisfies_content_bridge(self) -> None:
        assert isinstance(ManualInputAdapter(), ContentBridge)

    def test_meeting_summary_satisfies_content_bridge(self) -> None:
        assert isinstance(MeetingSummaryAdapter(), ContentBridge)

    def test_transcript_satisfies_content_bridge(self) -> None:
        assert isinstance(TranscriptAdapter(), ContentBridge)

    def test_incomplete_class_fails_content_bridge(self) -> None:
        class Incomplete:
            def get_target_agents(self, content, metadata): ...

        assert not isinstance(Incomplete(), ContentBridge)
