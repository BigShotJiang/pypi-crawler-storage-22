"""Tests for the IntentRouter — keyword routing, escalation pathways, explain."""

from __future__ import annotations

import pytest
from pathlib import Path

from vastian.agents.registry import AgentRegistry
from vastian.orchestrator.router import IntentRouter, ESCALATION_PATHWAYS


@pytest.fixture
def registry(agents_dir: Path) -> AgentRegistry:
    if not agents_dir.exists():
        pytest.skip("agents/ directory not found")
    reg = AgentRegistry()
    reg.load_from_directory(agents_dir)
    return reg


@pytest.fixture
def router(registry: AgentRegistry) -> IntentRouter:
    return IntentRouter(registry=registry, llm=None)


class TestKeywordRouting:
    @pytest.mark.asyncio
    async def test_finance_keywords_route_to_finley(self, router: IntentRouter) -> None:
        agent = await router.route("I need a budget review for Q1")
        assert agent == "finley"

    @pytest.mark.asyncio
    async def test_task_keywords_route_to_liam(self, router: IntentRouter) -> None:
        agent = await router.route("Add a todo for updating the priority list")
        assert agent == "liam"

    @pytest.mark.asyncio
    async def test_knowledge_keywords_route_to_elias(self, router: IntentRouter) -> None:
        agent = await router.route("Search the knowledge bank for recent insight")
        assert agent == "elias"

    @pytest.mark.asyncio
    async def test_unknown_message_defaults_to_charles(self, router: IntentRouter) -> None:
        agent = await router.route("Hello there, how are you?")
        assert agent == "charles"

    @pytest.mark.asyncio
    async def test_multiple_matches_picks_highest_score(self, router: IntentRouter) -> None:
        # "strategy" and "roadmap" both map to dominic, giving him 2 hits
        agent = await router.route("We need a strategy for the roadmap ahead")
        assert agent == "dominic"


class TestEscalationPathways:
    @pytest.mark.asyncio
    async def test_sync_issue_activates_sync_pathway(self, router: IntentRouter) -> None:
        agent = await router.route("There is a sync issue with the role sync")
        assert agent == "liam"

    @pytest.mark.asyncio
    async def test_system_health_activates_health_pathway(self, router: IntentRouter) -> None:
        agent = await router.route("The system health is degraded, performance issue")
        assert agent == "henry"

    @pytest.mark.asyncio
    async def test_backup_activates_document_backup_pathway(self, router: IntentRouter) -> None:
        agent = await router.route("I need a document backup right now")
        assert agent == "elias"

    @pytest.mark.asyncio
    async def test_escalation_takes_priority_over_keywords(self, router: IntentRouter) -> None:
        # "sync issue" triggers escalation to liam even though "knowledge" keyword exists
        agent = await router.route("There is a sync issue with knowledge sync")
        assert agent == "liam"

    def test_get_escalation_chain(self, router: IntentRouter) -> None:
        chain = router.get_escalation_chain("sync_coordination")
        assert chain == ["liam", "theo", "elias"]

    def test_get_escalation_chain_unknown(self, router: IntentRouter) -> None:
        chain = router.get_escalation_chain("nonexistent_pathway")
        assert chain == []

    def test_get_all_pathways(self, router: IntentRouter) -> None:
        pathways = router.get_all_pathways()
        assert "sync_coordination" in pathways
        assert "system_health" in pathways
        assert "document_backup" in pathways


class TestExplainRoute:
    def test_explain_shows_scores_and_chosen(self, router: IntentRouter) -> None:
        result = router.explain_route("I need a budget review for funding")
        assert result["chosen_agent"] == "finley"
        assert result["method"] == "keyword"
        assert "finley" in result["all_scores"]
        assert "matched_keywords" in result["all_scores"]["finley"]
