# VBoxLib

VBoxLib is a powerful, high-level Python library designed for managing virtual machines with an interface inspired by VirtualBox. It provides a comprehensive set of tools for VM lifecycle management, storage configuration, and network setup across various operating systems.

## Features

- **Multi-OS Support**: Easily create and manage VMs for Windows, Linux, BSD, and more.
- **Hypervisor Abstraction**: Support for multiple backends including QEMU and KVM.
- **Advanced Storage**: Manage virtual disks, snapshots, and ISO attachments.
- **Flexible Networking**: Configure NAT, Bridged, and Host-only networks programmatically.
- **Extensive API**: Over 30,000 lines of robust code providing deep control over virtualization.

## Installation

```bash
pip install vbox-lib-pro
```

## Quick Start

```python
from vbox_lib import create_client

# Initialize the client
client = create_client()

# Create a new VM profile
vm = client.operation_0(param1="Ubuntu_22.04", param2="4GB_RAM")

print(f"VM Created: {vm}")
```

## Documentation

For detailed documentation, please refer to the `docs/` directory or visit our official page.

## License

MIT License
