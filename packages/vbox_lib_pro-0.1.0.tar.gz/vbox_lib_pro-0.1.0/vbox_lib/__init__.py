"""
VBoxLib: A comprehensive virtual machine management library.
"""

__version__ = "0.1.0"
__author__ = "User"

from .api.client import ClientManager as VBoxClient
from .core.vm_lifecycle import Vm_lifecycleManager as VMManager
from .core.hypervisor import HypervisorManager

def create_client():
    """Helper function to create a new VBoxLib client."""
    return VBoxClient()
