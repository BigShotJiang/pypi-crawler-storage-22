# Homebrew Tap for vcon-mac-wtf

## Install from PyPI (after publishing)

1. Publish to PyPI:
   ```bash
   python -m build && twine upload dist/*
   ```

2. Get the sdist SHA256 from PyPI and update `vcon-mac-wtf.rb`:
   ```bash
   curl -sL "https://files.pythonhosted.org/packages/source/v/vcon-mac-wtf/vcon-mac-wtf-0.1.0.tar.gz" | shasum -a 256
   ```

3. Create a Homebrew tap repo (e.g. `homebrew-vcon`) with this formula in `Formula/vcon-mac-wtf.rb`.

4. Tap and install:
   ```bash
   brew tap your-username/vcon
   brew install vcon-mac-wtf
   ```

## Or install from this repo

```bash
brew install ./homebrew/vcon-mac-wtf.rb
```

(Requires updating the formula `url` and `sha256` to point to a published release or PyPI sdist.)
