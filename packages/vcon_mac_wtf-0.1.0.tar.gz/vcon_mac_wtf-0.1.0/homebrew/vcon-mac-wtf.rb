# typed: false
# frozen_string_literal: true

class VconMacWtf < Formula
  include Language::Python::Virtualenv

  desc "MLX Whisper transcription server for Apple Silicon with WTF/vCon support"
  homepage "https://github.com/vcon-dev/vcon-mac-wtf"
  url "https://files.pythonhosted.org/packages/source/v/vcon-mac-wtf/vcon-mac-wtf-0.1.0.tar.gz"
  sha256 "REPLACE_WITH_SHA256_AFTER_PYPI_PUBLISH"
  license "MIT"

  depends_on "python@3.12"

  def install
    virtualenv_create(libexec, "python3.12")
    system libexec/"bin/pip", "install", "-v", "--ignore-installed", buildpath
    bin.install_symlink libexec/"bin/vcon-mac-wtf"
  end

  test do
    assert_path_exists bin/"vcon-mac-wtf"
    system opt_libexec/"bin/python", "-c", "import vcon_mac_wtf; print('ok')"
  end
end
