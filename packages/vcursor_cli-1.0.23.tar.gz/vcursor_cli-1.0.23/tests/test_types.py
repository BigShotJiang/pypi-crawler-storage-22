"""Basic tests for type serialization/deserialization."""

from vcursor.types import (
    SubmitRequest,
    SubmitResponse,
    TaskProgress,
    AgentSubmitRequest,
    AgentProgress,
    ConcurrencyStatus,
)


def test_submit_request_to_dict():
    req = SubmitRequest(prompt="hello world")
    d = req.to_dict()
    assert d == {"prompt": "hello world"}


def test_submit_request_with_extras():
    req = SubmitRequest(
        prompt="test",
        media_keys=["key1"],
        reference_urls=["https://example.com"],
        submission_mode="plan",
    )
    d = req.to_dict()
    assert d["media_keys"] == ["key1"]
    assert d["reference_urls"] == ["https://example.com"]
    assert d["submission_mode"] == "plan"


def test_submit_response_from_dict():
    resp = SubmitResponse.from_dict({
        "code": 200,
        "message": "OK",
        "task_id": "abc123",
        "mode": "text2video",
    })
    assert resp.task_id == "abc123"
    assert resp.mode == "text2video"


def test_task_progress_from_dict():
    progress = TaskProgress.from_dict({
        "code": 200,
        "message": "OK",
        "data": {
            "task_id": "t1",
            "status": "processing",
            "progress": 50.0,
            "queuing_time": 1.0,
            "remaining_process_time": 10.0,
            "total_process_time": 20.0,
            "products": {
                "url": "https://cdn.example.com/video.mp4",
                "upload_completed": True,
            },
        },
    })
    assert progress.data.status == "processing"
    assert progress.data.progress == 50.0
    assert progress.data.products.url == "https://cdn.example.com/video.mp4"


def test_agent_submit_request_to_dict():
    req = AgentSubmitRequest(message="make a commercial", duration="30s")
    d = req.to_dict()
    assert d == {"message": "make a commercial", "duration": "30s"}


def test_agent_progress_from_dict():
    p = AgentProgress.from_dict({
        "task_id": "a1",
        "status": "completed",
        "progress": 100.0,
        "video_url": "https://cdn.example.com/agent.mp4",
    })
    assert p.status == "completed"
    assert p.video_url == "https://cdn.example.com/agent.mp4"


def test_concurrency_status_from_dict():
    s = ConcurrencyStatus.from_dict({
        "allowed": True,
        "limit": 30,
        "used": 5,
        "remaining": 25,
        "category": "standard",
        "tier": "pro",
        "bypassEnabled": False,
        "windowHours": 1,
        "resetAt": None,
        "summary": {
            "standard": {"used": 5, "limit": 30, "remaining": 25},
            "agent": {"used": 1, "limit": 5, "remaining": 4},
        },
    })
    assert s.allowed is True
    assert s.limit == 30
    assert s.used == 5
    assert s.remaining == 25
    assert s.category == "standard"
    assert s.tier == "pro"
    assert s.bypass_enabled is False
    assert s.window_hours == 1
    assert s.summary is not None
    assert s.summary["standard"].used == 5
    assert s.summary["standard"].limit == 30
    assert s.summary["agent"].used == 1
    assert s.summary["agent"].limit == 5
