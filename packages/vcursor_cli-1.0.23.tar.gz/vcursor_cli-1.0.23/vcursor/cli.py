"""VCursor CLI - Python entry point.

Provides the same core commands as the Node.js CLI:
  vcursor "a cat playing piano"
  vcursor --agent "create a commercial"
  vcursor login
  vcursor whoami
"""

from __future__ import annotations

import argparse
import getpass
import json
import os
import sys
import time
from pathlib import Path

from vcursor.client import VCursor, VCursorError, ConcurrencyLimitError, _load_config, DEFAULT_SERVER

CONFIG_DIR = Path.home() / ".vcursor"
CONFIG_FILE = CONFIG_DIR / "config.json"


def _save_config(config: dict) -> None:
    CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    CONFIG_FILE.write_text(json.dumps(config, indent=2) + "\n")
    CONFIG_FILE.chmod(0o600)


def _resolve_server(args: argparse.Namespace) -> str:
    return getattr(args, "server", None) or os.environ.get("VCURSOR_SERVER") or _load_config().get("server") or DEFAULT_SERVER


def _resolve_api_key(args: argparse.Namespace) -> str | None:
    return getattr(args, "api_key", None) or os.environ.get("VCURSOR_API_KEY") or _load_config().get("apiKey")


# ---------------------------------------------------------------------------
# Commands
# ---------------------------------------------------------------------------

def cmd_login(args: argparse.Namespace) -> None:
    server = _resolve_server(args)
    api_key = getattr(args, "api_key", None)
    if not api_key:
        print(f"Server: {server}")
        api_key = getpass.getpass("API Key: ")
    if not api_key:
        print("No API key provided.")
        sys.exit(1)

    # Validate
    import httpx
    try:
        resp = httpx.post(
            f"{server.rstrip('/')}/api/cli/validate",
            headers={"Authorization": f"Bearer {api_key}", "Content-Type": "application/json"},
            json={},
            timeout=15,
        )
        if resp.status_code != 200:
            print(f"Validation failed: {resp.text}")
            sys.exit(1)
    except Exception as e:
        print(f"Connection error: {e}")
        sys.exit(1)

    config = _load_config()
    config["server"] = server
    config["apiKey"] = api_key
    _save_config(config)
    print("Logged in successfully.")


def cmd_logout(_args: argparse.Namespace) -> None:
    config = _load_config()
    config.pop("apiKey", None)
    _save_config(config)
    print("Logged out.")


def cmd_whoami(args: argparse.Namespace) -> None:
    server = _resolve_server(args)
    api_key = _resolve_api_key(args)
    if not api_key:
        print("Not authenticated. Run: vcursor login")
        sys.exit(1)

    import httpx
    try:
        resp = httpx.post(
            f"{server.rstrip('/')}/api/cli/validate",
            headers={"Authorization": f"Bearer {api_key}", "Content-Type": "application/json"},
            json={},
            timeout=15,
        )
        data = resp.json()
        if resp.status_code == 200:
            print(f"Authenticated as: {data.get('email', data.get('name', 'unknown'))}")
            print(f"Server: {server}")
        else:
            print(f"Auth failed: {data.get('message', resp.status_code)}")
    except Exception as e:
        print(f"Connection error: {e}")
        sys.exit(1)


def cmd_generate(args: argparse.Namespace) -> None:
    api_key = _resolve_api_key(args)
    if not api_key:
        print("Not authenticated. Run: vcursor login")
        sys.exit(1)

    prompt = " ".join(args.inputs)
    if not prompt:
        print("No prompt provided.")
        sys.exit(1)

    max_conc = int(args.max_concurrency) if args.max_concurrency else None
    client = VCursor(
        api_key=api_key,
        server=_resolve_server(args),
        max_concurrency=max_conc,
    )

    try:
        if args.agent:
            _run_agent(client, prompt, args)
        else:
            _run_standard(client, prompt, args)
    except ConcurrencyLimitError as e:
        window_label = "" if e.tier == "free" else "/hr"
        print(f"Rate limit reached: {e.used}/{e.rate_limit} {e.category} requests{window_label} (tier: {e.tier})")
        if e.tier == "free":
            print("Upgrade your plan to get more requests.")
        else:
            print("Wait for your quota to reset, then try again.")
        sys.exit(1)
    except VCursorError as e:
        print(f"Error ({e.status}): {e}")
        sys.exit(1)
    finally:
        client.close()


def _run_standard(client: VCursor, prompt: str, args: argparse.Namespace) -> None:
    print(f"Submitting: {prompt[:120]}{'...' if len(prompt) > 120 else ''}")

    kwargs = {}
    if args.mode:
        kwargs["submission_mode"] = args.mode

    resp = client.submit(prompt, **kwargs)

    if resp.chat_response:
        print(f"\n{resp.chat_response}")
        return
    if resp.plan:
        print(f"\nPlan:\n{resp.plan}")
        return
    if not resp.task_id:
        print("No task ID returned.")
        sys.exit(1)

    print(f"Task: {resp.task_id} (mode: {resp.mode or 'auto'})")

    def _on_progress(p):
        d = p.data
        bar_len = 30
        filled = int(bar_len * d.progress / 100)
        bar = "█" * filled + "░" * (bar_len - filled)
        eta = f" ~{int(d.remaining_process_time)}s" if d.remaining_process_time > 0 else ""
        print(f"\r  [{bar}] {d.progress:.0f}% {d.status}{eta}  ", end="", flush=True)

    result = client.wait_for_completion(resp.task_id, on_progress=_on_progress)
    print()

    if result.data.status == "completed":
        print("Completed!")
        if result.data.products.url:
            print(f"  Output: {result.data.products.url}")
        if result.data.products.audio_url:
            print(f"  Audio:  {result.data.products.audio_url}")
        if result.data.products.refined_prompt:
            print(f"  Refined: {result.data.products.refined_prompt}")
    else:
        print(f"Task failed: {result.data.detail or result.data.status}")
        sys.exit(1)

    if args.json:
        print(json.dumps({"code": result.code, "data": {"status": result.data.status}}, indent=2))


def _run_agent(client: VCursor, prompt: str, args: argparse.Namespace) -> None:
    print(f"Submitting agent task: {prompt[:120]}{'...' if len(prompt) > 120 else ''}")

    resp = client.submit_agent(prompt)
    task_id = resp.get("task_id")
    if not task_id:
        print("No task ID returned.")
        sys.exit(1)

    print(f"Agent task: {task_id}")

    def _on_progress(p):
        bar_len = 30
        filled = int(bar_len * p.progress / 100)
        bar = "█" * filled + "░" * (bar_len - filled)
        stage = p.current_stage or p.status
        print(f"\r  [{bar}] {p.progress:.0f}% {stage}  ", end="", flush=True)

    result = client.wait_for_agent_completion(task_id, on_progress=_on_progress)
    print()

    if result.status == "completed":
        print("Agent task completed!")
        if result.video_url:
            print(f"  Video:  {result.video_url}")
        if result.assets_url:
            print(f"  Assets: {result.assets_url}")
    else:
        print(f"Agent task failed: {result.error_message or result.status}")
        sys.exit(1)


def cmd_concurrency(args: argparse.Namespace) -> None:
    """Show current concurrency status."""
    api_key = _resolve_api_key(args)
    if not api_key:
        print("Not authenticated. Run: vcursor login")
        sys.exit(1)

    client = VCursor(api_key=api_key, server=_resolve_server(args))
    try:
        status = client.check_concurrency()
        window_label = "lifetime" if status.tier == "free" else f"{status.window_hours}h window"
        print(f"Tier:      {status.tier} ({window_label})")
        if status.summary:
            s = status.summary["standard"]
            a = status.summary["agent"]
            print(f"Standard:  {s.used}/{s.limit} used, {s.remaining} remaining")
            print(f"Agent:     {a.used}/{a.limit} used, {a.remaining} remaining")
        if status.bypass_enabled:
            print("Bypass:    enabled (admin/test)")
    except VCursorError as e:
        print(f"Error: {e}")
        sys.exit(1)
    finally:
        client.close()


# ---------------------------------------------------------------------------
# Argument parser
# ---------------------------------------------------------------------------

def main() -> None:
    parser = argparse.ArgumentParser(
        prog="vcursor",
        description="VCursor CLI - Generate videos from text, images, and URLs using AI",
    )
    parser.add_argument("-v", "--version", action="version", version="vcursor 1.0.0")

    sub = parser.add_subparsers(dest="command")

    # login
    login_p = sub.add_parser("login", help="Authenticate with your VCursor API key")
    login_p.add_argument("--server", help="Server URL")
    login_p.add_argument("--api-key", help="API key (non-interactive)")

    # logout
    sub.add_parser("logout", help="Remove stored API key")

    # whoami
    whoami_p = sub.add_parser("whoami", help="Show current authenticated user")
    whoami_p.add_argument("--server", help="Server URL")

    # concurrency
    conc_p = sub.add_parser("concurrency", help="Show concurrency limit status")
    conc_p.add_argument("--server", help="Server URL")
    conc_p.add_argument("--api-key", help="API key")

    # generate (default)
    gen_p = sub.add_parser("generate", help="Generate video from prompt")
    gen_p.add_argument("inputs", nargs="+", help="Text prompt, file paths, or URLs")
    gen_p.add_argument("--agent", action="store_true", help="Use agent mode")
    gen_p.add_argument("--mode", help="Force a specific mode")
    gen_p.add_argument("--max-concurrency", help="Max concurrent tasks (client-side)")
    gen_p.add_argument("--server", help="Server URL")
    gen_p.add_argument("--api-key", help="API key")
    gen_p.add_argument("--json", action="store_true", help="Output raw JSON")

    args = parser.parse_args()

    # If no subcommand but there are remaining args, treat as generate
    if args.command is None:
        # Re-parse with generate as implicit default
        remaining = sys.argv[1:]
        if remaining and not remaining[0].startswith("-"):
            gen_args = gen_p.parse_args(remaining)
            cmd_generate(gen_args)
            return
        parser.print_help()
        return

    if args.command == "login":
        cmd_login(args)
    elif args.command == "logout":
        cmd_logout(args)
    elif args.command == "whoami":
        cmd_whoami(args)
    elif args.command == "concurrency":
        cmd_concurrency(args)
    elif args.command == "generate":
        cmd_generate(args)
    else:
        parser.print_help()


if __name__ == "__main__":
    main()
