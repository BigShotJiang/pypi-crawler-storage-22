"""VCursor API client for Python - sync and async."""

from __future__ import annotations

import json
import os
import time
from pathlib import Path
from typing import Any, Callable

import httpx

from vcursor.types import (
    AgentProgress,
    AgentSubmitRequest,
    ConcurrencyStatus,
    SubmitRequest,
    SubmitResponse,
    TaskProgress,
)

DEFAULT_SERVER = "https://www.cli.vcursor.com"
CONFIG_PATH = Path.home() / ".vcursor" / "config.json"


class VCursorError(Exception):
    """Error returned by the VCursor API."""

    def __init__(self, message: str, status: int, data: dict[str, Any] | None = None):
        super().__init__(message)
        self.status = status
        self.data = data


class ConcurrencyLimitError(VCursorError):
    """Raised when the user has exceeded their concurrency limit."""

    def __init__(self, message: str, data: dict[str, Any] | None = None):
        super().__init__(message, 429, data)
        self.used: int = (data or {}).get("used", 0)
        self.rate_limit: int = (data or {}).get("rateLimit", 0)
        self.category: str = (data or {}).get("category", "standard")
        self.tier: str = (data or {}).get("tier", "free")


def _load_config() -> dict[str, Any]:
    """Load config from ~/.vcursor/config.json."""
    try:
        return json.loads(CONFIG_PATH.read_text())
    except (FileNotFoundError, json.JSONDecodeError):
        return {}


def _resolve_server(server: str | None = None) -> str:
    return server or os.environ.get("VCURSOR_SERVER") or _load_config().get("server") or DEFAULT_SERVER


def _resolve_api_key(api_key: str | None = None) -> str | None:
    return api_key or os.environ.get("VCURSOR_API_KEY") or _load_config().get("apiKey")


# ---------------------------------------------------------------------------
# Synchronous client
# ---------------------------------------------------------------------------

class VCursor:
    """Synchronous VCursor API client.

    Usage::

        from vcursor import VCursor

        client = VCursor(api_key="vk-...")
        resp = client.submit("a cat playing piano")
        result = client.wait_for_completion(resp.task_id)
        print(result.data.products.url)
    """

    def __init__(
        self,
        api_key: str | None = None,
        server: str | None = None,
        max_concurrency: int | None = None,
        timeout: float = 60.0,
    ):
        self.server = _resolve_server(server).rstrip("/")
        self.api_key = _resolve_api_key(api_key)
        self.max_concurrency = max_concurrency
        self._client = httpx.Client(timeout=timeout)

    def _headers(self) -> dict[str, str]:
        h: dict[str, str] = {"Content-Type": "application/json"}
        if self.api_key:
            h["Authorization"] = f"Bearer {self.api_key}"
        return h

    def _request(self, method: str, path: str, body: dict[str, Any] | None = None) -> Any:
        url = f"{self.server}{path}"
        resp = self._client.request(method, url, headers=self._headers(), json=body)
        data = resp.json()
        if not resp.is_success:
            msg = data.get("message") or data.get("error") or f"HTTP {resp.status_code}"
            if resp.status_code == 429:
                raise ConcurrencyLimitError(msg, data)
            raise VCursorError(msg, resp.status_code, data)
        return data

    # --- Concurrency ---

    def check_concurrency(self, category: str = "standard") -> ConcurrencyStatus:
        """Check current rate limit usage and limits.

        Args:
            category: 'standard' or 'agent'.
        """
        data = self._request("POST", "/api/concurrency/check", {"category": category})
        return ConcurrencyStatus.from_dict(data)

    def _enforce_concurrency(self, category: str = "standard") -> None:
        """Pre-flight rate limit guard. Raises ConcurrencyLimitError if over limit."""
        status = self.check_concurrency(category)
        effective_limit = self.max_concurrency if self.max_concurrency is not None else status.limit
        if not status.bypass_enabled and status.used >= effective_limit:
            window_label = "" if status.tier == "free" else "/hr"
            raise ConcurrencyLimitError(
                f"Rate limit reached: {status.used}/{effective_limit} {category} requests{window_label}",
                {
                    "used": status.used,
                    "rateLimit": effective_limit,
                    "category": category,
                    "tier": status.tier,
                },
            )

    # --- Standard mode ---

    def submit(self, prompt: str, **kwargs: Any) -> SubmitResponse:
        """Submit a standard video generation task.

        Args:
            prompt: Text prompt.
            **kwargs: Additional fields for SubmitRequest (media_keys, reference_urls, etc.).

        Returns:
            SubmitResponse with task_id for polling.
        """
        self._enforce_concurrency("standard")
        req = SubmitRequest(prompt=prompt, **kwargs)
        data = self._request("POST", "/api/task/submit_anything", req.to_dict())
        return SubmitResponse.from_dict(data)

    def get_progress(self, task_id: str) -> TaskProgress:
        """Get progress for a standard task."""
        data = self._request("GET", f"/api/task/progress/{task_id}")
        return TaskProgress.from_dict(data)

    def cancel_task(self, task_id: str) -> dict[str, str]:
        """Cancel a running task."""
        return self._request("GET", f"/api/task/abort/{task_id}")

    def wait_for_completion(
        self,
        task_id: str,
        poll_interval: float = 2.0,
        on_progress: Callable[[TaskProgress], None] | None = None,
    ) -> TaskProgress:
        """Poll until a standard task completes or fails.

        Args:
            task_id: Task ID to poll.
            poll_interval: Seconds between polls.
            on_progress: Optional callback invoked on each poll.

        Returns:
            Final TaskProgress.
        """
        while True:
            progress = self.get_progress(task_id)
            if on_progress:
                on_progress(progress)
            if progress.data.status in ("completed", "failed"):
                return progress
            time.sleep(poll_interval)

    # --- Agent mode ---

    def submit_agent(self, message: str, **kwargs: Any) -> dict[str, str]:
        """Submit an agent mode task.

        Args:
            message: Agent prompt.
            **kwargs: Additional fields for AgentSubmitRequest.

        Returns:
            Dict with task_id and status.
        """
        self._enforce_concurrency("agent")
        req = AgentSubmitRequest(message=message, **kwargs)
        return self._request("POST", "/api/direct/submit", req.to_dict())

    def get_agent_progress(self, task_id: str) -> AgentProgress:
        """Get progress for an agent task."""
        data = self._request("GET", f"/api/direct/progress/{task_id}")
        return AgentProgress.from_dict(data)

    def cancel_agent_task(self, task_id: str) -> dict[str, str]:
        """Cancel an agent task."""
        return self._request("DELETE", f"/api/direct/cancel/{task_id}")

    def wait_for_agent_completion(
        self,
        task_id: str,
        poll_interval: float = 3.0,
        on_progress: Callable[[AgentProgress], None] | None = None,
    ) -> AgentProgress:
        """Poll until an agent task completes or fails."""
        while True:
            progress = self.get_agent_progress(task_id)
            if on_progress:
                on_progress(progress)
            if progress.status in ("completed", "error"):
                return progress
            time.sleep(poll_interval)

    def close(self) -> None:
        self._client.close()

    def __enter__(self) -> VCursor:
        return self

    def __exit__(self, *args: Any) -> None:
        self.close()


# ---------------------------------------------------------------------------
# Async client
# ---------------------------------------------------------------------------

class VCursorAsync:
    """Async VCursor API client.

    Usage::

        import asyncio
        from vcursor import VCursorAsync

        async def main():
            async with VCursorAsync(api_key="vk-...") as client:
                resp = await client.submit("a cat playing piano")
                result = await client.wait_for_completion(resp.task_id)
                print(result.data.products.url)

        asyncio.run(main())
    """

    def __init__(
        self,
        api_key: str | None = None,
        server: str | None = None,
        max_concurrency: int | None = None,
        timeout: float = 60.0,
    ):
        self.server = _resolve_server(server).rstrip("/")
        self.api_key = _resolve_api_key(api_key)
        self.max_concurrency = max_concurrency
        self._client = httpx.AsyncClient(timeout=timeout)

    def _headers(self) -> dict[str, str]:
        h: dict[str, str] = {"Content-Type": "application/json"}
        if self.api_key:
            h["Authorization"] = f"Bearer {self.api_key}"
        return h

    async def _request(self, method: str, path: str, body: dict[str, Any] | None = None) -> Any:
        url = f"{self.server}{path}"
        resp = await self._client.request(method, url, headers=self._headers(), json=body)
        data = resp.json()
        if not resp.is_success:
            msg = data.get("message") or data.get("error") or f"HTTP {resp.status_code}"
            if resp.status_code == 429:
                raise ConcurrencyLimitError(msg, data)
            raise VCursorError(msg, resp.status_code, data)
        return data

    # --- Concurrency ---

    async def check_concurrency(self, category: str = "standard") -> ConcurrencyStatus:
        data = await self._request("POST", "/api/concurrency/check", {"category": category})
        return ConcurrencyStatus.from_dict(data)

    async def _enforce_concurrency(self, category: str = "standard") -> None:
        status = await self.check_concurrency(category)
        effective_limit = self.max_concurrency if self.max_concurrency is not None else status.limit
        if not status.bypass_enabled and status.used >= effective_limit:
            window_label = "" if status.tier == "free" else "/hr"
            raise ConcurrencyLimitError(
                f"Rate limit reached: {status.used}/{effective_limit} {category} requests{window_label}",
                {
                    "used": status.used,
                    "rateLimit": effective_limit,
                    "category": category,
                    "tier": status.tier,
                },
            )

    # --- Standard mode ---

    async def submit(self, prompt: str, **kwargs: Any) -> SubmitResponse:
        await self._enforce_concurrency("standard")
        req = SubmitRequest(prompt=prompt, **kwargs)
        data = await self._request("POST", "/api/task/submit_anything", req.to_dict())
        return SubmitResponse.from_dict(data)

    async def get_progress(self, task_id: str) -> TaskProgress:
        data = await self._request("GET", f"/api/task/progress/{task_id}")
        return TaskProgress.from_dict(data)

    async def cancel_task(self, task_id: str) -> dict[str, str]:
        return await self._request("GET", f"/api/task/abort/{task_id}")

    async def wait_for_completion(
        self,
        task_id: str,
        poll_interval: float = 2.0,
        on_progress: Callable[[TaskProgress], None] | None = None,
    ) -> TaskProgress:
        import asyncio
        while True:
            progress = await self.get_progress(task_id)
            if on_progress:
                on_progress(progress)
            if progress.data.status in ("completed", "failed"):
                return progress
            await asyncio.sleep(poll_interval)

    # --- Agent mode ---

    async def submit_agent(self, message: str, **kwargs: Any) -> dict[str, str]:
        await self._enforce_concurrency("agent")
        req = AgentSubmitRequest(message=message, **kwargs)
        return await self._request("POST", "/api/direct/submit", req.to_dict())

    async def get_agent_progress(self, task_id: str) -> AgentProgress:
        data = await self._request("GET", f"/api/direct/progress/{task_id}")
        return AgentProgress.from_dict(data)

    async def cancel_agent_task(self, task_id: str) -> dict[str, str]:
        return await self._request("DELETE", f"/api/direct/cancel/{task_id}")

    async def wait_for_agent_completion(
        self,
        task_id: str,
        poll_interval: float = 3.0,
        on_progress: Callable[[AgentProgress], None] | None = None,
    ) -> AgentProgress:
        import asyncio
        while True:
            progress = await self.get_agent_progress(task_id)
            if on_progress:
                on_progress(progress)
            if progress.status in ("completed", "error"):
                return progress
            await asyncio.sleep(poll_interval)

    async def close(self) -> None:
        await self._client.aclose()

    async def __aenter__(self) -> VCursorAsync:
        return self

    async def __aexit__(self, *args: Any) -> None:
        await self.close()
