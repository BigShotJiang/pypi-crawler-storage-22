"""Type definitions for the VCursor SDK."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Optional


@dataclass
class SubmitRequest:
    """Request to submit a standard video generation task."""
    prompt: str
    media_keys: list[str] | None = None
    reference_urls: list[str] | None = None
    submission_mode: str | None = None  # 'plan' | 'execute' | 'ask'
    plan_id: str | None = None
    plan_data: dict[str, Any] | None = None

    def to_dict(self) -> dict[str, Any]:
        d: dict[str, Any] = {"prompt": self.prompt}
        if self.media_keys:
            d["media_keys"] = self.media_keys
        if self.reference_urls:
            d["reference_urls"] = self.reference_urls
        if self.submission_mode:
            d["submission_mode"] = self.submission_mode
        if self.plan_id:
            d["plan_id"] = self.plan_id
        if self.plan_data:
            d["plan_data"] = self.plan_data
        return d


@dataclass
class SubmitResponse:
    """Response from task submission."""
    code: int
    message: str
    task_id: str | None = None
    mode: str | None = None
    chat_response: str | None = None
    plan: str | None = None
    plan_id: str | None = None

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> SubmitResponse:
        return cls(
            code=data.get("code", 0),
            message=data.get("message", ""),
            task_id=data.get("task_id"),
            mode=data.get("mode"),
            chat_response=data.get("chat_response"),
            plan=data.get("plan"),
            plan_id=data.get("plan_id"),
        )


@dataclass
class TaskProducts:
    """Products from a completed task."""
    url: str | None = None
    thumbnail_url: str | None = None
    audio_url: str | None = None
    upload_completed: bool = False
    refined_prompt: str | None = None
    aspect_ratio: str | None = None

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> TaskProducts:
        return cls(
            url=data.get("url"),
            thumbnail_url=data.get("thumbnail_url"),
            audio_url=data.get("audio_url"),
            upload_completed=data.get("upload_completed", False),
            refined_prompt=data.get("refined_prompt"),
            aspect_ratio=data.get("aspect_ratio"),
        )


@dataclass
class TaskProgressData:
    """Inner data of task progress."""
    task_id: str
    status: str  # 'pending' | 'processing' | 'completed' | 'failed' | 'temporal_error'
    progress: float = 0.0
    queuing_time: float = 0.0
    remaining_process_time: float = 0.0
    total_process_time: float = 0.0
    products: TaskProducts = field(default_factory=TaskProducts)
    detail: str | None = None

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> TaskProgressData:
        return cls(
            task_id=data.get("task_id", ""),
            status=data.get("status", "pending"),
            progress=data.get("progress", 0.0),
            queuing_time=data.get("queuing_time", 0.0),
            remaining_process_time=data.get("remaining_process_time", 0.0),
            total_process_time=data.get("total_process_time", 0.0),
            products=TaskProducts.from_dict(data.get("products", {})),
            detail=data.get("detail"),
        )


@dataclass
class TaskProgress:
    """Full task progress response."""
    code: int
    message: str
    data: TaskProgressData = field(default_factory=lambda: TaskProgressData(task_id="", status="pending"))

    @classmethod
    def from_dict(cls, raw: dict[str, Any]) -> TaskProgress:
        return cls(
            code=raw.get("code", 0),
            message=raw.get("message", ""),
            data=TaskProgressData.from_dict(raw.get("data", {})),
        )


@dataclass
class AgentSubmitRequest:
    """Request to submit an agent mode task."""
    message: str
    duration: str | None = None
    aspect_ratio: str | None = None
    model_name: str | None = None
    voiceover: str | None = None
    subtitles: str | None = None
    bgm: str | None = None
    sound_effects: str | None = None
    visual_style: str | None = None

    def to_dict(self) -> dict[str, Any]:
        d: dict[str, Any] = {"message": self.message}
        for key in ("duration", "aspect_ratio", "model_name", "voiceover",
                     "subtitles", "bgm", "sound_effects", "visual_style"):
            val = getattr(self, key)
            if val is not None:
                d[key] = val
        return d


@dataclass
class AgentProgress:
    """Agent task progress."""
    task_id: str
    status: str  # 'pending' | 'processing' | 'completed' | 'error'
    progress: float = 0.0
    current_stage: str | None = None
    estimated_time_remaining: float | None = None
    video_url: str | None = None
    assets_url: str | None = None
    error_message: str | None = None

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> AgentProgress:
        return cls(
            task_id=data.get("task_id", ""),
            status=data.get("status", "pending"),
            progress=data.get("progress", 0.0),
            current_stage=data.get("current_stage"),
            estimated_time_remaining=data.get("estimated_time_remaining"),
            video_url=data.get("video_url"),
            assets_url=data.get("assets_url"),
            error_message=data.get("error_message"),
        )


@dataclass
class CategoryUsage:
    """Usage for a single task category (standard or agent)."""
    used: int
    limit: int | float
    remaining: int | float

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> CategoryUsage:
        return cls(
            used=data.get("used", 0),
            limit=data.get("limit", 0),
            remaining=data.get("remaining", 0),
        )


@dataclass
class ConcurrencyStatus:
    """Rate limit status for the current user.

    Includes separate quotas for standard and agent requests.
    """
    allowed: bool
    limit: int | float
    used: int
    remaining: int | float
    category: str  # 'standard' | 'agent'
    tier: str
    bypass_enabled: bool = False
    window_hours: int = 1
    reset_at: str | None = None
    summary: dict[str, CategoryUsage] | None = None

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> ConcurrencyStatus:
        summary_raw = data.get("summary", {})
        summary = {
            "standard": CategoryUsage.from_dict(summary_raw.get("standard", {})),
            "agent": CategoryUsage.from_dict(summary_raw.get("agent", {})),
        } if summary_raw else None
        return cls(
            allowed=data.get("allowed", False),
            limit=data.get("limit", 0),
            used=data.get("used", 0),
            remaining=data.get("remaining", 0),
            category=data.get("category", "standard"),
            tier=data.get("tier", "free"),
            bypass_enabled=data.get("bypassEnabled", False),
            window_hours=data.get("windowHours", 1),
            reset_at=data.get("resetAt"),
            summary=summary,
        )
