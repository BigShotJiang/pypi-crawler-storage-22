# vecta_sdk/vecta/__init__.py
"""Vecta: An open source benchmarking package for RAG retrieval systems."""

from vecta.core.benchmark import VectaClient
from vecta.api_client import VectaAPIClient
from vecta.core.plotting import plot_experiment, get_metadata_keys
from vecta.core.schemas import (
    ChunkData,
    BenchmarkEntry,
    EvaluationMetrics,
    GenerationMetrics,
    BenchmarkResults,
    RetrievalAndGenerationResults,
    GenerationOnlyResults,
    EvaluationResultRow,
    VectorDBType,
    FileStoreType,
    DataSourceType,
    EvaluationType,
    VectorDBSchema,
    SyntheticQuestion,
    ChunkJudgment,
    RenameRequest,
    UsageInfo,
)
from vecta.exceptions import (
    VectaAPIError,
    VectaAuthenticationError,
    VectaNotFoundError,
    VectaBadRequestError,
    VectaServerError,
    VectaForbiddenError,
    VectaRateLimitError,
    VectaInsufficientDataError,
    VectaNoBenchmarkError,
    VectaUsageLimitError,
)

# Lazy imports for modules with heavy/optional dependencies
# (e.g. datasets, chromadb, pinecone, weaviate) that users shouldn't
# need to install unless they actually use that specific feature.
_LAZY_IMPORTS = {
    "BenchmarkDatasetImporter": "vecta.core.dataset_importer",
    "ChromaLocalConnector": "vecta.connectors.chroma_local_connector",
    "ChromaCloudConnector": "vecta.connectors.chroma_cloud_connector",
    "PineconeConnector": "vecta.connectors.pinecone_connector",
    "AzureCosmosConnector": "vecta.connectors.azure_cosmos_connector",
    "DatabricksConnector": "vecta.connectors.databricks_connector",
    "LangChainVectorStoreConnector": "vecta.connectors.langchain_connector",
    "LlamaIndexConnector": "vecta.connectors.llama_index_connector",
    "PgVectorConnector": "vecta.connectors.pgvector_connector",
    "WeaviateConnector": "vecta.connectors.weaviate_connector",
    "FileStoreConnector": "vecta.connectors.file_store_connector",
}


def __getattr__(name: str):
    if name in _LAZY_IMPORTS:
        import importlib

        module = importlib.import_module(_LAZY_IMPORTS[name])
        value = getattr(module, name)
        # Cache it so subsequent access is fast and doesn't re-import
        globals()[name] = value
        return value
    raise AttributeError(f"module 'vecta' has no attribute {name!r}")

__version__ = "0.1.0"
__all__ = [
    "VectaClient",
    "VectaAPIClient",
    "BenchmarkDatasetImporter",
    "plot_experiment",
    "get_metadata_keys",
    "ChunkData",
    "BenchmarkEntry",
    "EvaluationMetrics",
    "GenerationMetrics",
    "BenchmarkResults",
    "RetrievalAndGenerationResults",
    "GenerationOnlyResults",
    "EvaluationResultRow",
    "VectorDBType",
    "FileStoreType",
    "DataSourceType",
    "EvaluationType",
    "VectorDBSchema",
    "SyntheticQuestion",
    "ChunkJudgment",
    "RenameRequest",
    "UsageInfo",
    "ChromaLocalConnector",
    "ChromaCloudConnector",
    "PineconeConnector",
    "AzureCosmosConnector",
    "DatabricksConnector",
    "LangChainVectorStoreConnector",
    "LlamaIndexConnector",
    "PgVectorConnector",
    "WeaviateConnector",
    "FileStoreConnector",
    "VectaAPIError",
    "VectaAuthenticationError",
    "VectaNotFoundError",
    "VectaBadRequestError",
    "VectaServerError",
    "VectaForbiddenError",
    "VectaRateLimitError",
    "VectaInsufficientDataError",
    "VectaNoBenchmarkError",
    "VectaUsageLimitError",
]
