"""vectl: Agentic Implementation Plan Manager."""

__version__ = "0.1.3"
