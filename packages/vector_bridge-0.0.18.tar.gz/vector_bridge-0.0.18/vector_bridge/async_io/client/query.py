from vector_bridge import AsyncVectorBridgeClient
from vector_bridge.schema.errors.queries import raise_for_query_detail
from vector_bridge.schema.queries import Query, QueryResponse
from weaviate.collections.classes.filters import _Filters
from weaviate.collections.classes.grpc import _Sorting


class AsyncQueryClient:
    """Async user client for query endpoints that require an API key."""

    def __init__(self, client: AsyncVectorBridgeClient):
        self.client = client

    async def run_search_query(
        self,
        vector_schema: str,
        target_vector: str = "default",
        integration_name: str | None = None,
        near_text: str | None = None,
        distance: float = 0.75,
        filters: _Filters | None = None,
        sort: _Sorting | None = None,
        limit: int = 100,
        offset: int | None = None,
        **kwargs,
    ) -> QueryResponse:
        """
        Run a vector search query.

        Args:
            vector_schema: The schema to be queried
            target_vector: The named vector to query against
            integration_name: The name of the Integration
            near_text: The query text
            distance: Similarity distance threshold
            filters: The filters to apply to the query
            sort: The sort to apply to the query
            limit: The maximum number of results to return
            offset: The offset to start with

        Returns:
            Search results
        """
        await self.client._ensure_session()

        if integration_name is None:
            integration_name = self.client.integration_name

        query_payload = Query(
            target_vector=target_vector,
            near_text=near_text,
            distance=distance,
            filters=filters,
            sort=sort,
            limit=limit,
            offset=offset,
            kwargs=kwargs,
        )

        url = f"{self.client.base_url}/v1/vector-query/search/run"
        params = {"vector_schema": vector_schema, "integration_name": integration_name}

        headers = self.client._get_auth_headers()

        async with self.client.session.post(
            url,
            headers=headers,
            params=params,
            json=query_payload.serialize_bytes(),
        ) as response:
            result = await self.client._handle_response(response=response, error_callable=raise_for_query_detail)
            return QueryResponse.model_validate(result)

    async def run_find_similar_query(
        self,
        vector_schema: str,
        near_id: str,
        target_vector: str = "default",
        integration_name: str | None = None,
        distance: float = 0.75,
        filters: _Filters | None = None,
        sort: _Sorting | None = None,
        limit: int = 100,
        offset: int | None = None,
        **kwargs,
    ) -> QueryResponse:
        """
        Run a vector similarity query.

        Args:
            vector_schema: The schema to be queried
            target_vector: The named vector to query against
            near_id: The id from which to find similar documents
            integration_name: The name of the Integration
            distance: Similarity distance threshold
            filters: The filters to apply to the query
            sort: The sort to apply to the query
            limit: The maximum number of results to return
            offset: The offset to start with
        Returns:
            Search results
        """
        await self.client._ensure_session()

        if integration_name is None:
            integration_name = self.client.integration_name

        query_payload = Query(
            target_vector=target_vector,
            near_id=near_id,
            distance=distance,
            filters=filters,
            sort=sort,
            limit=limit,
            offset=offset,
            kwargs=kwargs,
        )

        url = f"{self.client.base_url}/v1/vector-query/find-similar/run"
        params = {"vector_schema": vector_schema, "integration_name": integration_name}

        headers = self.client._get_auth_headers()

        async with self.client.session.post(
            url, headers=headers, params=params, json=query_payload.serialize_bytes()
        ) as response:
            result = await self.client._handle_response(response=response, error_callable=raise_for_query_detail)
            return QueryResponse.model_validate(result)
