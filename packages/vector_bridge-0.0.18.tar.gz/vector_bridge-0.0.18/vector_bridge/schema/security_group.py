from datetime import datetime
from enum import StrEnum
from typing import Self
from uuid import uuid4

from pydantic import BaseModel, Field

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from vector_bridge import AsyncVectorBridgeClient, VectorBridgeClient

DEFAULT_SECURITY_GROUP = "default"


class SecurityGroupsSorting(StrEnum):
    created_at = "created_at"
    updated_at = "updated_at"


# Define individual permission models for each category
class LogsPermissions(BaseModel):
    read: bool


class APIKeysPermissions(BaseModel):
    create: bool
    read: bool
    delete: bool


class UsagePermissions(BaseModel):
    read: bool


class UserPermissions(BaseModel):
    read_env_variables: bool
    write_env_variables: bool


class IntegrationsPermissions(BaseModel):
    create: bool
    read: bool
    update: bool
    delete: bool
    add_user: bool
    update_users_security_group: bool
    remove_user: bool


class HistoryPermissions(BaseModel):
    read: bool
    delete: bool
    delete_all: bool


class AIKnowledgeFileStoragePermissions(BaseModel):
    create: bool
    read: bool
    update: bool
    delete: bool
    grant_revoke_access: bool


# Aggregate all permission categories into a single Permissions class
class Permissions(BaseModel):
    logs: LogsPermissions
    api_keys: APIKeysPermissions
    usage: UsagePermissions
    user: UserPermissions
    integrations: IntegrationsPermissions
    history: HistoryPermissions
    ai_knowledge_file_storage: AIKnowledgeFileStoragePermissions


# Security Group Models
class SecurityGroupCreate(BaseModel):
    group_name: str
    description: str


class SecurityGroup(SecurityGroupCreate):
    group_id: str = Field(default_factory=lambda: str(uuid4()))
    organization_id: str | None = Field(default=None)
    group_permissions: Permissions
    created_at: datetime
    updated_at: datetime

    @property
    def uuid(self):
        return self.group_id

    def delete(self, client: "VectorBridgeClient") -> None:
        """Delete this security group."""
        client.admin.security_groups.delete_security_group(group_id=self.group_id)

    async def a_delete(self, client: "AsyncVectorBridgeClient") -> None:
        """Asynchronously delete this security group."""
        await client.admin.security_groups.delete_security_group(group_id=self.group_id)

    def update(self, client: "VectorBridgeClient", security_group_data: "SecurityGroupUpdate") -> "SecurityGroup":
        """Update this security group with new data."""
        return client.admin.security_groups.update_security_group(
            group_id=self.group_id, security_group_data=security_group_data
        )

    async def a_update(
        self,
        client: "AsyncVectorBridgeClient",
        security_group_data: "SecurityGroupUpdate",
    ) -> Self:
        """Asynchronously update this security group with new data."""
        return await client.admin.security_groups.update_security_group(
            group_id=self.group_id, security_group_data=security_group_data
        )


class SecurityGroupUpdate(BaseModel):
    permissions: Permissions


class PaginatedSecurityGroups(BaseModel):
    security_groups: list[SecurityGroup]
    limit: int
    last_evaluated_key: str | None = None
    has_more: bool
