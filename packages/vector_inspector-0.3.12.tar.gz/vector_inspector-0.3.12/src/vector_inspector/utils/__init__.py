"""Utilities for Vector Inspector."""
