"""
Integration adapters for popular vector databases and frameworks.

This module provides compatibility layers for:
- LangChain VectorStore
- LlamaIndex VectorStore
- Supabase pgvector
- Milvus
- Qdrant
- Weaviate
"""

__all__ = []
