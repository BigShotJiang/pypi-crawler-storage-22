"""AgentLens - Agent observability that traces decisions, not just API calls."""

from agentlens.client import init, shutdown, get_client
from agentlens.decision import log_decision
from agentlens.models import (
    TraceData,
    DecisionPoint,
    Span,
    Event,
    TraceStatus,
    DecisionType,
    SpanType,
    SpanStatus,
    EventType,
)

import sys

if sys.version_info >= (3, 7):
    import importlib

    __trace_module = importlib.import_module("agentlens.trace")
    trace = getattr(__trace_module, "trace")
    TraceContext = getattr(__trace_module, "TraceContext")
    get_current_trace = getattr(__trace_module, "get_current_trace")
else:
    from agentlens.trace import trace, TraceContext, get_current_trace

__version__ = "0.1.0"
__all__ = [
    "init",
    "shutdown",
    "get_client",
    "trace",
    "TraceContext",
    "get_current_trace",
    "log_decision",
    "TraceData",
    "DecisionPoint",
    "Span",
    "Event",
    "TraceStatus",
    "DecisionType",
    "SpanType",
    "SpanStatus",
    "EventType",
]
