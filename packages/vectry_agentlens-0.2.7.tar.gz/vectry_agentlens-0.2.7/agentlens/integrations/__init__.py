"""Integration packages for AgentLens.

Available integrations:

- ``openai``: Wrap OpenAI clients with ``wrap_openai(client)``.
- ``anthropic``: Wrap Anthropic clients with ``wrap_anthropic(client)``.
- ``langchain``: LangChain callback handler for tracing.
"""
