# Vedro VCS Changed

[![PyPI](https://img.shields.io/pypi/v/vedro-vcs-changed.svg?style=flat-square)](https://pypi.python.org/pypi/vedro-vcs-changed/)
[![Python Version](https://img.shields.io/pypi/pyversions/vedro-vcs-changed.svg?style=flat-square)](https://pypi.python.org/pypi/vedro-vcs-changed/)

A [Vedro](https://vedro.io) plugin that runs only test scenarios affected by changes in the current VCS branch. It combines VCS diff with Python AST import analysis to determine which scenarios are transitively affected by modified files.

## Features

- **VCS-agnostic** — supports git (default) and arc, extensible to other VCS
- **Transitive dependency analysis** — if a mock, context, schema, or page object changes, all scenarios that import it (directly or transitively) will run
- **Zero external dependencies** — uses only `subprocess` and `ast` from Python stdlib (plus vedro)

## Installation

```shell
$ pip install vedro-vcs-changed
```

Activate the plugin in your `vedro.cfg.py`:

```python
import vedro
import vedro_vcs_changed

class Config(vedro.Config):

    class Plugins(vedro.Config.Plugins):

        class VCSChanged(vedro_vcs_changed.VedroVCSChanged):
            enabled = True
```

## Usage

### Git (default)

```shell
$ vedro run --changed-against-branch=main
```

### Arc (Arcadia)

```shell
$ vedro run --changed-against-branch=trunk --changed-vcs=arc
```

### Options

| Option | Description | Default |
|--------|-------------|---------|
| `--changed-against-branch` | Branch to compare against | *(required)* |
| `--changed-vcs` | VCS backend: `git`, `arc` | `git` |

## How It Works

1. Runs VCS diff to get the list of changed `.py` files in the current branch
2. Parses all `.py` files in the project using Python AST to extract imports
3. Builds a reverse dependency graph (file → set of files that import it)
4. Starting from each changed file, traverses the reverse graph (BFS) to find all transitively affected scenario files
5. Ignores all scenarios that are not affected
