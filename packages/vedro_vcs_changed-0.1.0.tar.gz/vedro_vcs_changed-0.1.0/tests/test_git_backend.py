import subprocess
from pathlib import Path
from unittest.mock import patch

import pytest

from vedro_vcs_changed import GitBackend, VCSError


@pytest.fixture()
def backend() -> GitBackend:
    return GitBackend()


# --- find_repo_root ---

def test_finds_git_root(tmp_path: Path, backend: GitBackend) -> None:
    (tmp_path / ".git").mkdir()
    sub = tmp_path / "a" / "b"
    sub.mkdir(parents=True)

    result = backend.find_repo_root(sub)

    assert result == tmp_path


def test_finds_git_root_at_start(tmp_path: Path, backend: GitBackend) -> None:
    (tmp_path / ".git").mkdir()

    result = backend.find_repo_root(tmp_path)

    assert result == tmp_path


def test_raises_when_no_git_root(tmp_path: Path, backend: GitBackend) -> None:
    with pytest.raises(VCSError, match="Unable to find a git repository"):
        backend.find_repo_root(tmp_path)


# --- get_changed_files ---

def test_git_returns_changed_py_files(tmp_path: Path, backend: GitBackend) -> None:
    (tmp_path / ".git").mkdir()
    project_dir = tmp_path

    mock_result = subprocess.CompletedProcess(
        args=[], returncode=0,
        stdout="helpers/utils.py\nscenarios/test_a.py\nREADME.md\n",
        stderr="",
    )

    (tmp_path / "helpers").mkdir()
    (tmp_path / "helpers" / "utils.py").touch()
    (tmp_path / "scenarios").mkdir()
    (tmp_path / "scenarios" / "test_a.py").touch()

    with patch("vedro_vcs_changed._vcs._git.subprocess.run", return_value=mock_result):
        result = backend.get_changed_files("main", project_dir)

    assert result == {Path("helpers/utils.py"), Path("scenarios/test_a.py")}


def test_git_filters_non_py_files(tmp_path: Path, backend: GitBackend) -> None:
    (tmp_path / ".git").mkdir()

    mock_result = subprocess.CompletedProcess(
        args=[], returncode=0,
        stdout="README.md\nsetup.cfg\n",
        stderr="",
    )

    with patch("vedro_vcs_changed._vcs._git.subprocess.run", return_value=mock_result):
        result = backend.get_changed_files("main", tmp_path)

    assert result == set()


def test_git_empty_diff(tmp_path: Path, backend: GitBackend) -> None:
    (tmp_path / ".git").mkdir()

    mock_result = subprocess.CompletedProcess(
        args=[], returncode=0, stdout="", stderr="",
    )

    with patch("vedro_vcs_changed._vcs._git.subprocess.run", return_value=mock_result):
        result = backend.get_changed_files("main", tmp_path)

    assert result == set()


def test_git_raises_on_executable_not_found(tmp_path: Path, backend: GitBackend) -> None:
    (tmp_path / ".git").mkdir()

    with patch(
        "vedro_vcs_changed._vcs._git.subprocess.run",
        side_effect=FileNotFoundError(),
    ):
        with pytest.raises(VCSError, match="git executable not found"):
            backend.get_changed_files("main", tmp_path)


def test_git_raises_on_command_error(tmp_path: Path, backend: GitBackend) -> None:
    (tmp_path / ".git").mkdir()

    with patch(
        "vedro_vcs_changed._vcs._git.subprocess.run",
        side_effect=subprocess.CalledProcessError(1, "git", stderr="fatal: bad ref"),
    ):
        with pytest.raises(VCSError, match="Failed to retrieve file differences"):
            backend.get_changed_files("main", tmp_path)


def test_git_skips_files_outside_project_dir(tmp_path: Path, backend: GitBackend) -> None:
    (tmp_path / ".git").mkdir()
    project_dir = tmp_path / "subproject"
    project_dir.mkdir()

    mock_result = subprocess.CompletedProcess(
        args=[], returncode=0,
        stdout="outside/file.py\nsubproject/inside.py\n",
        stderr="",
    )

    (project_dir / "inside.py").touch()

    with patch("vedro_vcs_changed._vcs._git.subprocess.run", return_value=mock_result):
        result = backend.get_changed_files("main", project_dir)

    assert result == {Path("inside.py")}
