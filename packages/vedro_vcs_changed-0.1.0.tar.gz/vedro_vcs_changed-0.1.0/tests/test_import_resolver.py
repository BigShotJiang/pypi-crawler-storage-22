from pathlib import Path

import pytest

from vedro_vcs_changed import ImportResolver


@pytest.fixture()
def tmp_project(tmp_path: Path) -> Path:
    return tmp_path


def _write(project: Path, rel: str, content: str = "") -> Path:
    p = project / rel
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(content, encoding="utf-8")
    return p


# --- build ---

def test_build_creates_reverse_graph(tmp_project: Path) -> None:
    _write(tmp_project, "helpers/utils.py", "x = 1")
    _write(tmp_project, "scenarios/test_a.py", "from helpers.utils import x")

    resolver = ImportResolver(tmp_project)
    resolver.build()

    assert resolver._built is True


def test_build_skips_hidden_dirs(tmp_project: Path) -> None:
    _write(tmp_project, ".hidden/secret.py", "x = 1")
    _write(tmp_project, "scenarios/test_a.py", "from .hidden.secret import x")

    resolver = ImportResolver(tmp_project)
    resolver.build()

    assert Path(".hidden/secret.py") not in resolver._reverse_graph


def test_build_skips_node_modules(tmp_project: Path) -> None:
    _write(tmp_project, "node_modules/pkg.py", "x = 1")

    resolver = ImportResolver(tmp_project)
    resolver.build()

    assert Path("node_modules/pkg.py") not in resolver._reverse_graph


def test_build_handles_syntax_error(tmp_project: Path) -> None:
    _write(tmp_project, "bad.py", "def !!!")

    resolver = ImportResolver(tmp_project)
    resolver.build()

    assert resolver._built is True


def test_build_handles_unicode_error(tmp_project: Path) -> None:
    p = tmp_project / "binary.py"
    p.write_bytes(b"\x80\x81\x82")

    resolver = ImportResolver(tmp_project)
    resolver.build()

    assert resolver._built is True


# --- _resolve_module ---

def test_resolve_module_as_py_file(tmp_project: Path) -> None:
    _write(tmp_project, "helpers/utils.py")

    resolver = ImportResolver(tmp_project)
    result = resolver._resolve_module("helpers.utils")

    assert result == Path("helpers/utils.py")


def test_resolve_module_as_package(tmp_project: Path) -> None:
    _write(tmp_project, "helpers/__init__.py")

    resolver = ImportResolver(tmp_project)
    result = resolver._resolve_module("helpers")

    assert result == Path("helpers/__init__.py")


def test_resolve_module_not_found(tmp_project: Path) -> None:
    resolver = ImportResolver(tmp_project)
    result = resolver._resolve_module("nonexistent.module")

    assert result is None


def test_resolve_module_prefers_py_file_over_package(tmp_project: Path) -> None:
    _write(tmp_project, "helpers/utils.py")
    _write(tmp_project, "helpers/utils/__init__.py")

    resolver = ImportResolver(tmp_project)
    result = resolver._resolve_module("helpers.utils")

    assert result == Path("helpers/utils.py")


# --- get_affected_scenarios ---

def test_direct_scenario_change(tmp_project: Path) -> None:
    _write(tmp_project, "scenarios/test_a.py", "x = 1")

    resolver = ImportResolver(tmp_project)
    resolver.build()

    changed = {Path("scenarios/test_a.py")}
    affected = resolver.get_affected_scenarios(changed)

    assert affected == {Path("scenarios/test_a.py")}


def test_dependency_change_affects_scenario(tmp_project: Path) -> None:
    _write(tmp_project, "helpers/utils.py", "x = 1")
    _write(tmp_project, "scenarios/test_a.py", "from helpers.utils import x")

    resolver = ImportResolver(tmp_project)
    resolver.build()

    changed = {Path("helpers/utils.py")}
    affected = resolver.get_affected_scenarios(changed)

    assert affected == {Path("scenarios/test_a.py")}


def test_transitive_dependency(tmp_project: Path) -> None:
    _write(tmp_project, "lib/core.py", "val = 42")
    _write(tmp_project, "helpers/utils.py", "from lib.core import val")
    _write(tmp_project, "scenarios/test_a.py", "from helpers.utils import val")

    resolver = ImportResolver(tmp_project)
    resolver.build()

    changed = {Path("lib/core.py")}
    affected = resolver.get_affected_scenarios(changed)

    assert affected == {Path("scenarios/test_a.py")}


def test_no_affected_scenarios(tmp_project: Path) -> None:
    _write(tmp_project, "helpers/utils.py", "x = 1")
    _write(tmp_project, "scenarios/test_a.py", "y = 2")

    resolver = ImportResolver(tmp_project)
    resolver.build()

    changed = {Path("helpers/utils.py")}
    affected = resolver.get_affected_scenarios(changed)

    assert affected == set()


def test_multiple_scenarios_affected(tmp_project: Path) -> None:
    _write(tmp_project, "helpers/utils.py", "x = 1")
    _write(tmp_project, "scenarios/test_a.py", "from helpers.utils import x")
    _write(tmp_project, "scenarios/test_b.py", "from helpers.utils import x")

    resolver = ImportResolver(tmp_project)
    resolver.build()

    changed = {Path("helpers/utils.py")}
    affected = resolver.get_affected_scenarios(changed)

    assert affected == {Path("scenarios/test_a.py"), Path("scenarios/test_b.py")}


def test_change_in_non_imported_file(tmp_project: Path) -> None:
    _write(tmp_project, "helpers/utils.py", "x = 1")
    _write(tmp_project, "helpers/other.py", "y = 2")
    _write(tmp_project, "scenarios/test_a.py", "from helpers.utils import x")

    resolver = ImportResolver(tmp_project)
    resolver.build()

    changed = {Path("helpers/other.py")}
    affected = resolver.get_affected_scenarios(changed)

    assert affected == set()


def test_auto_builds_if_not_built(tmp_project: Path) -> None:
    _write(tmp_project, "helpers/utils.py", "x = 1")
    _write(tmp_project, "scenarios/test_a.py", "from helpers.utils import x")

    resolver = ImportResolver(tmp_project)

    changed = {Path("helpers/utils.py")}
    affected = resolver.get_affected_scenarios(changed)

    assert affected == {Path("scenarios/test_a.py")}


def test_custom_scenarios_dir(tmp_project: Path) -> None:
    _write(tmp_project, "helpers/utils.py", "x = 1")
    _write(tmp_project, "tests/test_a.py", "from helpers.utils import x")

    resolver = ImportResolver(tmp_project)
    resolver.build()

    changed = {Path("helpers/utils.py")}
    affected = resolver.get_affected_scenarios(changed, scenarios_dir="tests")

    assert affected == {Path("tests/test_a.py")}


def test_empty_changed_files(tmp_project: Path) -> None:
    _write(tmp_project, "scenarios/test_a.py", "x = 1")

    resolver = ImportResolver(tmp_project)
    resolver.build()

    affected = resolver.get_affected_scenarios(set())

    assert affected == set()


def test_diamond_dependency(tmp_project: Path) -> None:
    _write(tmp_project, "lib/base.py", "val = 1")
    _write(tmp_project, "helpers/a.py", "from lib.base import val")
    _write(tmp_project, "helpers/b.py", "from lib.base import val")
    _write(
        tmp_project,
        "scenarios/test_x.py",
        "from helpers.a import val\nfrom helpers.b import val",
    )

    resolver = ImportResolver(tmp_project)
    resolver.build()

    changed = {Path("lib/base.py")}
    affected = resolver.get_affected_scenarios(changed)

    assert affected == {Path("scenarios/test_x.py")}


def test_nested_scenarios_dir(tmp_project: Path) -> None:
    _write(tmp_project, "helpers/utils.py", "x = 1")
    _write(tmp_project, "scenarios/sub/test_a.py", "from helpers.utils import x")

    resolver = ImportResolver(tmp_project)
    resolver.build()

    changed = {Path("helpers/utils.py")}
    affected = resolver.get_affected_scenarios(changed)

    assert affected == {Path("scenarios/sub/test_a.py")}
