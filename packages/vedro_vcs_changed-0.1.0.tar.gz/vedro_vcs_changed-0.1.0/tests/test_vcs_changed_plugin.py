import argparse
from pathlib import Path
from typing import AsyncIterator, List
from unittest.mock import MagicMock, patch

import pytest

from vedro_vcs_changed import VedroVCSChanged, VedroVCSChangedPlugin
from vedro_vcs_changed._vcs import VCSBackend, VCSError


def _make_plugin() -> VedroVCSChangedPlugin:
    return VedroVCSChangedPlugin(VedroVCSChanged)


# --- on_arg_parse ---

def test_on_arg_parse_adds_arguments() -> None:
    plugin = _make_plugin()
    parser = argparse.ArgumentParser()
    event = MagicMock()
    event.arg_parser = parser

    plugin.on_arg_parse(event)

    actions = {a.dest: a for a in parser._actions}
    assert "changed_against_branch" in actions
    assert "changed_vcs" in actions


def test_on_arg_parse_default_vcs_is_git() -> None:
    plugin = _make_plugin()
    parser = argparse.ArgumentParser()
    event = MagicMock()
    event.arg_parser = parser

    plugin.on_arg_parse(event)

    args = parser.parse_args([])
    assert args.changed_vcs == "git"


# --- on_arg_parsed ---

def test_on_arg_parsed_sets_branch() -> None:
    plugin = _make_plugin()
    event = MagicMock()
    event.args = argparse.Namespace(
        changed_against_branch="main",
        changed_vcs="git",
    )

    plugin.on_arg_parsed(event)

    assert plugin._branch == "main"


def test_on_arg_parsed_no_branch_does_nothing() -> None:
    plugin = _make_plugin()
    event = MagicMock()
    event.args = argparse.Namespace(
        changed_against_branch=None,
        changed_vcs="git",
    )

    plugin.on_arg_parsed(event)

    assert plugin._branch is None
    assert plugin._backend is None


def test_on_arg_parsed_creates_backend() -> None:
    plugin = _make_plugin()
    event = MagicMock()
    event.args = argparse.Namespace(
        changed_against_branch="main",
        changed_vcs="git",
    )

    plugin.on_arg_parsed(event)

    assert plugin._backend is not None


def test_on_arg_parsed_raises_on_unknown_vcs() -> None:
    plugin = _make_plugin()
    event = MagicMock()
    event.args = argparse.Namespace(
        changed_against_branch="main",
        changed_vcs="svn",
    )

    with pytest.raises(ValueError, match="Unknown VCS backend 'svn'"):
        plugin.on_arg_parsed(event)


# --- helpers for on_startup ---

class _FakeScheduler:
    def __init__(self, scenarios: List[MagicMock]) -> None:
        self._scenarios = scenarios
        self._ignored: List[MagicMock] = []

    def __aiter__(self) -> AsyncIterator[MagicMock]:
        return self._async_iter()

    async def _async_iter(self) -> AsyncIterator[MagicMock]:
        for s in self._scenarios:
            yield s

    def ignore(self, scenario: MagicMock) -> None:
        self._ignored.append(scenario)


def _make_scenario(path: str) -> MagicMock:
    scenario = MagicMock()
    scenario.path = path
    return scenario


# --- on_startup ---

async def test_on_startup_skips_when_no_branch() -> None:
    plugin = _make_plugin()
    event = MagicMock()

    await plugin.on_startup(event)


async def test_on_startup_ignores_unaffected_scenarios(tmp_path: Path) -> None:
    plugin = _make_plugin()
    plugin._branch = "main"

    mock_backend = MagicMock(spec=VCSBackend)
    mock_backend.get_changed_files.return_value = {Path("helpers/utils.py")}
    plugin._backend = mock_backend

    scenario_a = _make_scenario(str(tmp_path / "scenarios" / "test_a.py"))
    scenario_b = _make_scenario(str(tmp_path / "scenarios" / "test_b.py"))
    scheduler = _FakeScheduler([scenario_a, scenario_b])

    event = MagicMock()
    event.scheduler = scheduler

    mock_resolver = MagicMock()
    mock_resolver.get_affected_scenarios.return_value = {
        Path("scenarios/test_a.py"),
    }

    with patch("vedro_vcs_changed._vcs_changed_plugin.Path.cwd", return_value=tmp_path):
        with patch(
            "vedro_vcs_changed._vcs_changed_plugin.ImportResolver",
            return_value=mock_resolver,
        ):
            await plugin.on_startup(event)

    assert scheduler._ignored == [scenario_b]
    assert plugin._affected_count == 1
    assert plugin._total_count == 2


async def test_on_startup_ignores_all_when_no_changes(tmp_path: Path) -> None:
    plugin = _make_plugin()
    plugin._branch = "main"

    mock_backend = MagicMock(spec=VCSBackend)
    mock_backend.get_changed_files.return_value = set()
    plugin._backend = mock_backend

    scenario = _make_scenario(str(tmp_path / "scenarios" / "test_a.py"))
    scheduler = _FakeScheduler([scenario])

    event = MagicMock()
    event.scheduler = scheduler

    mock_resolver = MagicMock()
    mock_resolver.get_affected_scenarios.return_value = set()

    with patch("vedro_vcs_changed._vcs_changed_plugin.Path.cwd", return_value=tmp_path):
        with patch(
            "vedro_vcs_changed._vcs_changed_plugin.ImportResolver",
            return_value=mock_resolver,
        ):
            await plugin.on_startup(event)

    assert scheduler._ignored == [scenario]
    assert plugin._no_changed is True


async def test_on_startup_raises_system_exit_on_vcs_error(tmp_path: Path) -> None:
    plugin = _make_plugin()
    plugin._branch = "main"

    mock_backend = MagicMock(spec=VCSBackend)
    mock_backend.get_changed_files.side_effect = VCSError("git failed")
    plugin._backend = mock_backend

    event = MagicMock()

    with patch("vedro_vcs_changed._vcs_changed_plugin.Path.cwd", return_value=tmp_path):
        with pytest.raises(SystemExit, match="vedro-vcs-changed: git failed"):
            await plugin.on_startup(event)


async def test_on_startup_keeps_all_affected_scenarios(tmp_path: Path) -> None:
    plugin = _make_plugin()
    plugin._branch = "main"

    mock_backend = MagicMock(spec=VCSBackend)
    mock_backend.get_changed_files.return_value = {Path("scenarios/test_a.py")}
    plugin._backend = mock_backend

    scenario = _make_scenario(str(tmp_path / "scenarios" / "test_a.py"))
    scheduler = _FakeScheduler([scenario])

    event = MagicMock()
    event.scheduler = scheduler

    mock_resolver = MagicMock()
    mock_resolver.get_affected_scenarios.return_value = {
        Path("scenarios/test_a.py"),
    }

    with patch("vedro_vcs_changed._vcs_changed_plugin.Path.cwd", return_value=tmp_path):
        with patch(
            "vedro_vcs_changed._vcs_changed_plugin.ImportResolver",
            return_value=mock_resolver,
        ):
            await plugin.on_startup(event)

    assert scheduler._ignored == []
    assert plugin._affected_count == 1


# --- on_cleanup ---

async def test_on_cleanup_no_summary_when_no_branch() -> None:
    plugin = _make_plugin()
    event = MagicMock()

    await plugin.on_cleanup(event)

    event.report.add_summary.assert_not_called()


async def test_on_cleanup_summary_when_no_changes() -> None:
    plugin = _make_plugin()
    plugin._branch = "main"
    plugin._no_changed = True
    event = MagicMock()

    await plugin.on_cleanup(event)

    event.report.add_summary.assert_called_once()
    msg = event.report.add_summary.call_args[0][0]
    assert "No scenarios are affected" in msg
    assert "'main'" in msg


async def test_on_cleanup_summary_with_affected_scenarios() -> None:
    plugin = _make_plugin()
    plugin._branch = "main"
    plugin._affected_count = 3
    plugin._total_count = 10
    event = MagicMock()

    await plugin.on_cleanup(event)

    event.report.add_summary.assert_called_once()
    msg = event.report.add_summary.call_args[0][0]
    assert "3 of 10 scenarios affected" in msg
    assert "'main'" in msg


async def test_on_cleanup_no_summary_when_zero_affected_but_not_no_changed() -> None:
    plugin = _make_plugin()
    plugin._branch = "main"
    plugin._affected_count = 0
    plugin._no_changed = False
    event = MagicMock()

    await plugin.on_cleanup(event)

    event.report.add_summary.assert_not_called()
