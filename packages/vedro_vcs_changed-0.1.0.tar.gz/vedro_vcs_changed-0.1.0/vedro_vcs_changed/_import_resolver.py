import ast
from collections import defaultdict, deque
from pathlib import Path
from typing import Dict, List, Optional, Set

__all__ = ("ImportResolver",)


class ImportResolver:
    """Builds a reverse dependency graph from Python imports using AST analysis.

    Parses all .py files in a project directory, extracts `from X import Y`
    statements, resolves module names to file paths, and builds a reverse
    graph (file -> set of files that import it). This allows determining
    which scenario files are transitively affected by a set of changed files.
    """

    def __init__(self, project_dir: Path) -> None:
        self._project_dir = project_dir.resolve()
        self._reverse_graph: Dict[Path, Set[Path]] = defaultdict(set)
        self._built = False

    def build(self) -> None:
        """Parse all .py files and build the reverse dependency graph."""
        py_files = self._collect_py_files()
        for py_file in py_files:
            imports = self._extract_imports(py_file)
            rel_file = py_file.relative_to(self._project_dir)
            for imp in imports:
                resolved = self._resolve_module(imp)
                if resolved is not None:
                    self._reverse_graph[resolved].add(rel_file)
        self._built = True

    def get_affected_scenarios(
        self,
        changed_files: Set[Path],
        scenarios_dir: str = "scenarios",
    ) -> Set[Path]:
        """Find all scenario files transitively affected by the changed files.

        Uses BFS over the reverse dependency graph starting from each changed
        file. Returns only files that reside under the scenarios directory.

        :param changed_files: Set of changed file paths relative to project_dir.
        :param scenarios_dir: Name of the scenarios directory.
        :returns: Set of affected scenario file paths relative to project_dir.
        """
        if not self._built:
            self.build()

        affected: Set[Path] = set()
        visited: Set[Path] = set()
        queue: deque[Path] = deque()

        for f in changed_files:
            queue.append(f)
            visited.add(f)

        while queue:
            current = queue.popleft()

            if str(current).startswith(scenarios_dir + "/") or str(current).startswith(scenarios_dir + "\\"):
                affected.add(current)

            for dependent in self._reverse_graph.get(current, set()):
                if dependent not in visited:
                    visited.add(dependent)
                    queue.append(dependent)

        return affected

    def _collect_py_files(self) -> List[Path]:
        """Collect all .py files in the project directory, excluding hidden dirs."""
        py_files = []
        for path in self._project_dir.rglob("*.py"):
            parts = path.relative_to(self._project_dir).parts
            if any(part.startswith(".") or part == "node_modules" for part in parts):
                continue
            py_files.append(path)
        return py_files

    def _extract_imports(self, file_path: Path) -> List[str]:
        """Extract module names from ImportFrom AST nodes."""
        try:
            source = file_path.read_text(encoding="utf-8")
            tree = ast.parse(source, filename=str(file_path))
        except (SyntaxError, UnicodeDecodeError):
            return []

        modules = []
        for node in ast.walk(tree):
            if isinstance(node, ast.ImportFrom) and node.module:
                modules.append(node.module)
        return modules

    def _resolve_module(self, module_name: str) -> Optional[Path]:
        """Resolve a dotted module name to a relative file path.

        Tries two resolutions:
        1. module/name.py (module is a package, name is a module)
        2. module/name/__init__.py (module.name is a package)

        :param module_name: Dotted module name (e.g. "contexts.opened_main_page").
        :returns: Relative path if the file exists, None otherwise.
        """
        parts = module_name.split(".")
        rel_path = Path(*parts)

        # Try as a .py file
        candidate = rel_path.with_suffix(".py")
        if (self._project_dir / candidate).is_file():
            return candidate

        # Try as a package (__init__.py)
        candidate = rel_path / "__init__.py"
        if (self._project_dir / candidate).is_file():
            return candidate

        return None
