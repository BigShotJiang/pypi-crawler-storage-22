from typing import Dict, Type

from ._arc import ArcBackend
from ._base import VCSBackend, VCSError
from ._git import GitBackend

__all__ = (
    "VCSBackend", "VCSError",
    "GitBackend", "ArcBackend",
    "VCS_BACKENDS", "DEFAULT_VCS",
)

VCS_BACKENDS: Dict[str, Type[VCSBackend]] = {
    "git": GitBackend,
    "arc": ArcBackend,
}

DEFAULT_VCS = "git"
