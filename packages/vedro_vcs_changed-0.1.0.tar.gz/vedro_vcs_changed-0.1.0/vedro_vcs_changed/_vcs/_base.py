from abc import ABC, abstractmethod
from pathlib import Path
from typing import Set

__all__ = ("VCSBackend", "VCSError",)


class VCSError(Exception):
    pass


class VCSBackend(ABC):
    """Abstract base class for VCS backends."""

    @abstractmethod
    def find_repo_root(self, start: Path) -> Path:
        """Find the VCS repository root starting from the given directory.

        :param start: Directory to start searching from.
        :returns: Path to the repository root.
        :raises VCSError: If the repository root cannot be found.
        """

    @abstractmethod
    def get_changed_files(self, against_branch: str, project_dir: Path) -> Set[Path]:
        """Return the set of changed .py file paths relative to project_dir.

        :param against_branch: Branch name to compare against.
        :param project_dir: Project directory (paths will be relative to this).
        :returns: Set of Path objects for changed .py files.
        :raises VCSError: If the diff command fails.
        """
