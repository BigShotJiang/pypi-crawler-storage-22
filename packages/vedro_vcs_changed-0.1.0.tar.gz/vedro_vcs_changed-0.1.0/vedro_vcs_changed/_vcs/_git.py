import subprocess
from pathlib import Path
from typing import Set

from ._base import VCSBackend, VCSError

__all__ = ("GitBackend",)


class GitBackend(VCSBackend):
    """Git VCS backend. Uses `git diff` to detect changed files."""

    def find_repo_root(self, start: Path) -> Path:
        """Find the git repository root by searching for .git directory."""
        current = start.resolve()
        while current != current.parent:
            if (current / ".git").exists():
                return current
            current = current.parent
        raise VCSError(
            "Unable to find a git repository in the current or any parent directories. "
            "Ensure you are in a directory that is part of a valid git repository."
        )

    def get_changed_files(self, against_branch: str, project_dir: Path) -> Set[Path]:
        """Get changed .py files relative to project_dir using git diff."""
        repo_root = self.find_repo_root(project_dir)

        try:
            result = subprocess.run(
                [
                    "git", "diff", "--name-only", "--diff-filter=ACMTR",
                    f"origin/{against_branch}...HEAD", "--", ".",
                ],
                cwd=str(repo_root),
                capture_output=True,
                text=True,
                check=True,
            )
        except FileNotFoundError:
            raise VCSError(
                "git executable not found. "
                "Ensure git is installed and available in PATH."
            )
        except subprocess.CalledProcessError as e:
            raise VCSError(
                f"Failed to retrieve file differences from git for branch "
                f"'{against_branch}'. Ensure the branch name is correct and exists. "
                f"stderr: {e.stderr.strip()}"
            )

        changed_files: Set[Path] = set()
        for line in result.stdout.strip().splitlines():
            file_path = repo_root / line
            if file_path.suffix == ".py":
                try:
                    rel_path = file_path.relative_to(project_dir)
                    changed_files.add(rel_path)
                except ValueError:
                    pass
        return changed_files
