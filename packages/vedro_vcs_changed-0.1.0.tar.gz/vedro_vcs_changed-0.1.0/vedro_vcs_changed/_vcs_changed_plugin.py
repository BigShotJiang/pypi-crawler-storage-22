from pathlib import Path
from typing import Type, Union

from vedro.core import Dispatcher, Plugin, PluginConfig
from vedro.events import ArgParsedEvent, ArgParseEvent, CleanupEvent, StartupEvent

from ._import_resolver import ImportResolver
from ._vcs import DEFAULT_VCS, VCS_BACKENDS, VCSBackend, VCSError

__all__ = ("VedroVCSChanged", "VedroVCSChangedPlugin",)


class VedroVCSChangedPlugin(Plugin):
    def __init__(self, config: Type["VedroVCSChanged"]) -> None:
        super().__init__(config)
        self._branch: Union[str, None] = None
        self._vcs_type: str = DEFAULT_VCS
        self._backend: Union[VCSBackend, None] = None
        self._no_changed: bool = False
        self._affected_count: int = 0
        self._total_count: int = 0

    def subscribe(self, dispatcher: Dispatcher) -> None:
        dispatcher.listen(ArgParseEvent, self.on_arg_parse) \
                  .listen(ArgParsedEvent, self.on_arg_parsed) \
                  .listen(StartupEvent, self.on_startup) \
                  .listen(CleanupEvent, self.on_cleanup)

    def on_arg_parse(self, event: ArgParseEvent) -> None:
        group = event.arg_parser.add_argument_group("VCS Changed")
        group.add_argument(
            "--changed-against-branch",
            help="Run only scenarios affected by changes relative to the specified branch",
        )
        available_vcs = ", ".join(sorted(VCS_BACKENDS.keys()))
        group.add_argument(
            "--changed-vcs",
            default=DEFAULT_VCS,
            help=f"VCS backend to use ({available_vcs}). Default: {DEFAULT_VCS}",
        )

    def on_arg_parsed(self, event: ArgParsedEvent) -> None:
        self._branch = event.args.changed_against_branch
        self._vcs_type = event.args.changed_vcs

        if self._branch is None:
            return

        if self._vcs_type not in VCS_BACKENDS:
            available = ", ".join(sorted(VCS_BACKENDS.keys()))
            raise ValueError(
                f"Unknown VCS backend '{self._vcs_type}'. "
                f"Available backends: {available}"
            )

        self._backend = VCS_BACKENDS[self._vcs_type]()

    async def on_startup(self, event: StartupEvent) -> None:
        if self._branch is None or self._backend is None:
            return

        project_dir = Path.cwd()

        try:
            changed_files = self._backend.get_changed_files(self._branch, project_dir)
        except VCSError as e:
            raise SystemExit(f"vedro-vcs-changed: {e}") from e

        resolver = ImportResolver(project_dir)
        resolver.build()
        affected_scenarios = resolver.get_affected_scenarios(changed_files)

        self._no_changed = len(affected_scenarios) == 0

        async for scenario in event.scheduler:
            self._total_count += 1
            rel_path = Path(scenario.path).relative_to(project_dir)
            if self._no_changed or (rel_path not in affected_scenarios):
                event.scheduler.ignore(scenario)
            else:
                self._affected_count += 1

    async def on_cleanup(self, event: CleanupEvent) -> None:
        if self._branch is None:
            return

        if self._no_changed:
            event.report.add_summary(
                f"No scenarios are affected by changes relative to "
                f"the '{self._branch}' branch"
            )
        elif self._affected_count > 0:
            event.report.add_summary(
                f"{self._affected_count} of {self._total_count} scenarios affected "
                f"by changes relative to the '{self._branch}' branch"
            )


class VedroVCSChanged(PluginConfig):
    plugin = VedroVCSChangedPlugin
    description = (
        "Runs only scenarios affected by VCS branch changes "
        "(supports git, arc, and other VCS backends)"
    )
