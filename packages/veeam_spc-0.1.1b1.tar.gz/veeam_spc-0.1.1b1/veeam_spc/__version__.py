"""Version details for veeam-spc

This file shamelessly taken from the requests library"""

__title__ = "veeam-spc"
__description__ = "A basic Veeam Service Provider Console REST API client."
__url__ = "https://github.com/Cenvora/veeam-spc"
__version__ = "0.1.0"
__author__ = "Jonah May"
__author_email__ = "jonah@mayfamily.me"
__license__ = "Apache 2.0"
__maintainer__ = "Jonah May"
__maintainer_email__ = "jonah@mayfamily.me"
__keywords__ = "python veeam service provider console veeam.com"
