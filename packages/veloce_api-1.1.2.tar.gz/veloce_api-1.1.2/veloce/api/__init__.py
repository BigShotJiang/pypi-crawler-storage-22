"""API module initialization"""
