# Misc module tests
