# Changelog

All notable changes to VenomQA will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]

## [0.4.0] - 2026-02-17

### Added

- **`HttpClient.with_headers(headers)`** — returns a new `HttpClient` inheriting base URL and timeout but merging the given headers over defaults. Enables per-role auth tokens without a second full client: `viewer_api = api.with_headers({"Authorization": viewer_token})`.
- **`World(setup=fn)`** — optional `setup` function called by `Agent.explore()` before the initial checkpoint. Use for DB seeding, auth token bootstrap, or any one-time pre-exploration setup: `World(api=api, setup=bootstrap_auth)`.
- **`coverage_target` param on `Agent` and `explore()`** — stop exploration once action coverage reaches the given fraction (0.0–1.0). Exposed in CLI as `venomqa explore --coverage-target 0.8`.
- **`precondition_action_ran(*action_names)`** — gate an action on prior actions having fired at least once in the current exploration. Agent checks `_required_actions` against the set of used action names, enabling clean dependency ordering without guard logic inside action functions.
- **`Graph.used_action_names`** property — set of action names executed at least once. Used internally by context-aware precondition checking.
- **`src/` layout** — package source moved to `src/venomqa/` to prevent the local directory from shadowing an installed `venomqa` package. Root `conftest.py` adds `src/` to `sys.path` for test runs.

### Fixed

- **`HTMLTraceReporter` crash (`KeyError: 'coverage_percent'`)** — `ExplorationResult.summary()` now includes a `coverage_percent` alias key (mapped to `action_coverage_percent`) so the HTML reporter and any other consumers that reference `summary['coverage_percent']` no longer crash.
- **`expected_status=[404]` without `expect_failure=True` was ignored** — `ResponseAssertion.validate()` previously checked `response.ok` even when the status code was already explicitly accepted by `expected_status`. Now, if `expected_status` is set and the response status is in the list, the ok/fail check is skipped entirely. `Action(expected_status=[404])` alone now correctly passes on a 404 response.
- **`precondition_has_context` now enforces checks via Agent** — context-aware preconditions are evaluated with the live `Context` when filtering valid actions.

## [0.3.0] - 2026-02-17

### Added

- **MockHTTPServer** — abstract base class for in-process mock HTTP servers with real checkpoint/rollback (no HTTP round-trips). Subclass and implement `get_state_snapshot()`, `rollback_from_snapshot()`, `observe_from_state()` for instant branching exploration.
- **HTMLTraceReporter** — self-contained D3.js force-graph report. Nodes are states (colored by violation severity), edges are action transitions with HTTP status. Fully offline, zero external dependencies.
- **RequestRecorder + Journey codegen** — wrap any `HttpClient` with `RequestRecorder` to capture all HTTP traffic, then call `generate_journey_code()` to produce a runnable VenomQA Journey skeleton from real traffic.
- **`venomqa record` CLI command** — record HTTP traffic against a live API and generate a Journey file automatically.
- **`Violation.action_result`** — violations now carry the triggering `ActionResult` so reporters can display the full HTTP request/response payload.
- **ConsoleReporter HTTP payload** — when a violation occurs, the console reporter now prints the full HTTP request/response that triggered it.
- **Hypergraph system** — multi-dimensional state indexing with 6 built-in dimensions (auth status, user role, entity status, count class, usage class, plan type). Opt in with `Agent(hypergraph=True)`.
- **DimensionNoveltyStrategy** — exploration strategy that prioritises state/action pairs closest to unexplored dimension combinations.
- **DimensionCoverage + DimensionCoverageReporter** — per-dimension coverage metrics and tabular reporter.
- **Constraints** — `AnonHasNoRole`, `AuthHasRole`, `FreeCannotExceedUsage`, `LambdaConstraint` for encoding business rules as graph constraints.
- **`venomqa explore --strategy coverage|weighted|dimension`** — all five exploration strategies now accessible from the CLI.

### Fixed

- **PostgresAdapter now uses psycopg (v3)** instead of psycopg2. The dependency (`psycopg[binary]>=3.1.0`) and the import now match.
- **`precondition_has_context` now enforces context checks** — the Agent passes live context when filtering valid actions, so preconditions created with `precondition_has_context("key")` correctly gate action selection.

### Improved

- `Action.can_execute_with_context(state, context)` — new method that evaluates context-aware preconditions against the live Context.
- `Graph.get_valid_actions(state, context=None)` — accepts optional context for context-aware filtering.
- Combined mock adapter integration test (`tests/v1/test_adapters_integration.py`).

## [0.2.0] - 2026-02-15

### Added

- **State Graph Testing** - Model apps as state machines, explore all paths automatically
- **Invariant System** - Define rules that must always hold true
- **Journey Validation** - `journey.validate()` catches structural issues before runtime
- **Enhanced Error Messages** - Request/response details shown on failure
- **Preflight Smoke Tests** - `venomqa smoke-test` for quick API health checks
- **Demo Command** - `venomqa demo --explain` for instant experience
- **Doctor Command** - `venomqa doctor` for system diagnostics
- **Watch Mode** - Auto-rerun tests on file changes
- **Load Testing** - Built-in load testing with `venomqa load`
- **Security Scanning** - OWASP-style security tests
- **GraphQL Support** - Full GraphQL client and test generation
- **Multiple Reporters** - HTML, JSON, JUnit, Markdown, Slack, Discord, SARIF
- **Combinatorial Testing** - Generate test combinations from parameters

### Improved

- StateManager warnings when checkpoint/branch used without database
- Better import handling - no more sys.path hacks in generated code
- Comprehensive test suite (2400+ tests)

### Fixed

- Journey discovery now unified across CLI and plugins
- Checkpoint validation in branch structures

## [0.1.0] - 2024-01-15

### Added

- Core journey DSL with Journey, Step, Checkpoint, Branch, and Path models
- JourneyRunner for executing journeys with branching and rollback
- HTTP Client with retry logic and request history tracking
- AsyncClient for async HTTP operations
- ExecutionContext for sharing state between steps
- PostgreSQL state manager with SAVEPOINT support
- Docker Compose infrastructure manager
- Multiple reporter formats:
  - MarkdownReporter for human-readable reports
  - JSONReporter for structured output
  - JUnitReporter for CI/CD integration
- CLI commands:
  - `venomqa run` - Execute journeys
  - `venomqa list` - List available journeys
  - `venomqa report` - Generate reports
- Configuration via YAML file and environment variables
- Automatic issue capture with suggestions
- Parallel path execution support
- Request/response logging

### Documentation

- API reference documentation
- CLI usage guide
- Journey writing guide
- Database backend configuration
- Advanced usage patterns
- Real-world examples

### Dependencies

- httpx>=0.25.0 for HTTP client
- pydantic>=2.0.0 for data validation
- pydantic-settings>=2.0.0 for configuration
- click>=8.0.0 for CLI
- rich>=13.0.0 for output formatting
- pyyaml>=6.0 for configuration
- psycopg[binary]>=3.1.0 for PostgreSQL

---

## Version History

| Version | Date | Description |
|---------|------|-------------|
| 0.1.0 | 2024-01-15 | Initial release |

---

## Future Roadmap

### Planned for 0.2.0

- MySQL state backend support
- SQLite state backend for local testing
- WebSocket client for real-time testing
- Improved parallel execution with process pools
- Watch mode for re-running on file changes

### Planned for 0.3.0

- OpenAPI spec journey generation
- Hypothesis integration for property-based testing
- Failure clustering and analysis
- Distributed execution support

### Planned for 1.0.0

- Stable API guarantee
- Complete documentation
- Full test coverage
- Performance benchmarks
