"""Backward-compatible CLI shim for verbatim."""

from verbatim_cli.main import main

__all__ = ["main"]


if __name__ == "__main__":
    main()
