"""Entry point for python -m verbatim_batch."""

from .main import main

if __name__ == "__main__":
    main()
