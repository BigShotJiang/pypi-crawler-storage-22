from .diarize import ChannelDiarization

__all__ = ["ChannelDiarization"]
