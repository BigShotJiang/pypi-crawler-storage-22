from .factory import create_diarizer

__all__ = ["create_diarizer"]
