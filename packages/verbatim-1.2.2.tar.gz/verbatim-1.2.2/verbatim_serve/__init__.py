"""HTTP server entrypoint for verbatim."""

from verbatim_serve.main import main

__all__ = ["main"]
