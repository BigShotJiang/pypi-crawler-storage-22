import logging
from abc import ABC, abstractmethod
from typing import Optional

from verbatim.cache import ArtifactCache
from verbatim_files.rttm import Annotation, dumps_rttm

LOG = logging.getLogger(__name__)


class DiarizationStrategy(ABC):
    """Base class for all diarization strategies"""

    def __init__(self, *, cache: ArtifactCache):
        self.cache = cache

    @abstractmethod
    def compute_diarization(self, file_path: str, out_rttm_file: Optional[str] = None, out_vttm_file: Optional[str] = None, **kwargs) -> Annotation:
        """
        Compute speaker diarization for the given audio file.

        Args:
            file_path: Path to the audio file
            out_rttm_file: Optional legacy RTTM output path (derived from VTTM if present)
            out_vttm_file: Preferred VTTM output path
            **kwargs: Strategy-specific parameters

        Returns:
            Annotation object containing speaker segments
        """

    def save_rttm(self, annotation: Annotation, out_rttm_file: str):
        """Save annotation to RTTM file"""
        self.cache.set_text(out_rttm_file, dumps_rttm(annotation))
