"""Verifily — ML data quality gate."""

__version__ = "1.2.4"
