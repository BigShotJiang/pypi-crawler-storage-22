"""
Technical Indicators (powered by talipp).

This module exposes "Smart" versions of talipp indicators that handle:
1.  Automatic extraction of `close` price from Candle objects.
2.  Automatic support for `SamplingPeriodType` via efficient internal chaining.
"""

import sys
import inspect
from typing import Any, List, Union
from datetime import datetime

# Import Talipp essentials
from talipp.indicators import *
from talipp.indicators.Indicator import Indicator
from talipp.input import SamplingPeriodType

# 1. Helper: Resampler
class Resampler(Indicator):
    """
    Pass-through indicator that handles sampling.
    """
    def __init__(self, input_sampling):
        super().__init__(input_sampling=input_sampling)
        
    def _calculate_new_value(self):
        # Return the latest aggregated object from the sampler
        if not self.input_values:
            return None
        return self.input_values[-1]

# 2. Smart Wrapper Logic
OHLCV_INDICATORS = {
    # Trend (need OHLC data)
    "ADX", "Aroon", "ParabolicSAR", "Ichimoku", "ChandeKrollStop", 
    "CHOP", "VTX", "ZigZag", "SuperTrend",
    # Volatility (need OHLC data)
    "ATR", "NATR", "KeltnerChannels", "DonchianChannels", "RogersSatchell",
    # Volume (need OHLCV data)
    "OBV", "SOBV", "AccuDist", "ChaikinOsc", "EMV", "ForceIndex", 
    "KVO", "VWAP", "VWMA", "BOP", "MassIndex",
    # Oscillators (need OHLC data)
    "Stoch", "CCI", "UO", "Williams", "AO",
    # Other (need OHLC data)
    "IBS", "PivotsHL", "SFX", "TTM", "FibonacciRetracement",
}

# Indicators that don't support incremental add() natively - we buffer and reinitialize
NO_INCREMENTAL_SUPPORT = {
    "PivotsHL",  # Pivot detection requires historical lookback, doesn't support update()
    "ZigZag",    # Similar lookback requirement
}

# These are utility classes, not real indicators
UTILITY_CLASSES = {
    "FibonacciRetracement",  # Static utility, not a streaming indicator
}

def _make_smart(cls_name, cls):
    is_ohlcv_native = cls_name in OHLCV_INDICATORS
    no_incremental = cls_name in NO_INCREMENTAL_SUPPORT
    is_utility = cls_name in UTILITY_CLASSES
    
    # Skip utility classes - they don't need wrapping
    if is_utility:
        return cls
    
    # For indicators that don't support incremental add(), create a buffered wrapper
    if no_incremental:
        class BufferedWrapper:
            """
            Wrapper for indicators that don't support incremental add().
            Maintains an internal buffer and reinitializes the indicator on each add().
            """
            def __init__(self, *args, max_buffer: int = 1000, **kwargs):
                self._args = args
                self._kwargs = kwargs
                self._buffer = []
                self._max_buffer = max_buffer
                self._indicator = None
                
                # If input_values provided, initialize immediately
                if 'input_values' in kwargs:
                    input_values = kwargs.pop('input_values')
                    self._kwargs = kwargs
                    self._buffer = list(input_values)
                    if len(self._buffer) > self._max_buffer:
                        self._buffer = self._buffer[-self._max_buffer:]
                    self._rebuild()
            
            def _rebuild(self):
                """Rebuild the indicator with current buffer."""
                if len(self._buffer) > 0:
                    self._indicator = cls(*self._args, input_values=self._buffer, **self._kwargs)
                else:
                    self._indicator = None
            
            def add(self, value: Any):
                """Add a new value and rebuild the indicator."""
                self._buffer.append(value)
                # Trim buffer if too large
                if len(self._buffer) > self._max_buffer:
                    self._buffer = self._buffer[-self._max_buffer:]
                self._rebuild()
            
            def __getitem__(self, index):
                if self._indicator is None:
                    raise IndexError("No data yet")
                return self._indicator[index]
            
            def __len__(self):
                if self._indicator is None:
                    return 0
                return len(self._indicator)
            
            def __iter__(self):
                if self._indicator is None:
                    return iter([])
                return iter(self._indicator)
            
            def __getattr__(self, name):
                # Delegate to underlying indicator
                if self._indicator is not None:
                    return getattr(self._indicator, name)
                raise AttributeError(f"'{cls_name}' has no data yet - call add() first")
        
        BufferedWrapper.__name__ = cls_name
        BufferedWrapper.__doc__ = f"Buffered wrapper for {cls_name}. Supports incremental add() by maintaining internal history."
        return BufferedWrapper
    
    # We create a wrapper class for normal indicators
    class SmartWrapper(cls):
        def __init__(self, *args, **kwargs):
            # Check for sampling request
            self._resampler = None
            self._is_feeding = False
            
            if 'input_sampling' in kwargs:
                sampling = kwargs.pop('input_sampling')
                
                # Handling Sampling for Float-based indicators (e.g. SMA)
                if not is_ohlcv_native:
                    # Chain: SmartWrapper -> Resampler -> SmartWrapper(Internal Logic)
                    self._resampler = Resampler(input_sampling=sampling)
                    kwargs['input_indicator'] = self._resampler
                    
                    if 'input_modifier' not in kwargs:
                         # Default to Close price for the RETURNED sampled output
                         kwargs['input_modifier'] = lambda c: c.close if hasattr(c, 'close') else c
                else:
                    # OHLCV indicators assume compatible input
                    kwargs['input_sampling'] = sampling
            
            super().__init__(*args, **kwargs)

        def add(self, value: Any):
            # Break recursion: If we are already feeding the resampler (triggered by its own callback),
            # or if we are processing the output of the resampler, proceed to real logic.
            if self._is_feeding:
                super().add(value)
                return

            # If we have a Resampler chain, we must feed the Resampler!
            if self._resampler is not None:
                self._is_feeding = True
                try:
                    self._resampler.add(value)
                finally:
                    self._is_feeding = False
                return 
            
            # Non-sampled, simple mode: Handle conversion manually
            if not is_ohlcv_native:
                if hasattr(value, 'close'):
                    value = value.close
            
            super().add(value)
            
    try:
        SmartWrapper.__name__ = cls_name
        SmartWrapper.__doc__ = cls.__doc__
    except:
        pass
        
    return SmartWrapper

# Re-export all indicators as SmartWrappers
import talipp.indicators as _ti

msg = []

for name, obj in inspect.getmembers(_ti):
    if inspect.isclass(obj) and obj.__module__.startswith('talipp'):
        # Create smart wrapper
        SmartObj = _make_smart(name, obj)
        # Export it
        setattr(sys.modules[__name__], name, SmartObj)
        msg.append(name)

__all__ = msg + ["SamplingPeriodType"]
