from dataclasses import dataclass, asdict, field
from typing import Optional, List, Union, Any

@dataclass
class StrategyInitSettings:
    """
    Settings for initializing a strategy.
    """
    symbols: List[str] = field(default_factory=list)
    mode: str = "BACKTEST"
    board: str = "G1"
    initial_capital: float = 1000000000.0
    timeframe: Union[str, Any] = "1d"
    from_date: Optional[str] = None
    to_date: Optional[str] = None
    account_id: Optional[str] = None
    api_port: Optional[int] = None
    jwt_token: Optional[str] = None
    
    @property
    def symbol(self) -> str:
        """Get primary symbol (first in list)."""
        return self.symbols[0] if self.symbols else ""
    
    @classmethod
    def default(cls) -> "StrategyInitSettings":
        """Get default settings."""
        return cls()
    
    def to_dict(self) -> dict:
        """Convert to dictionary, masking sensitive fields."""
        d = asdict(self)
        if d.get("jwt_token"):
            d["jwt_token"] = "***"
        return d
