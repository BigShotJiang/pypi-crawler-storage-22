"""
Setup configuration for verril-learn package.
A Surgical Machine Unlearning library for edge devices.
"""

from setuptools import setup, find_packages

with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read() if fh else ""

setup(
    name="verril-learn",
    version="0.1.0",
    author="Verril",
    author_email="verrilvaz404@gmail.com",
    description="A Surgical Machine Unlearning library for edge devices using PyTorch",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/Verril-hash/verril-unlearn.git",
    packages=find_packages(),
    classifiers=[
        "Development Status :: 3 - Alpha",
        "Intended Audience :: Developers",
        "Intended Audience :: Science/Research",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Topic :: Scientific/Engineering :: Artificial Intelligence",
        "Topic :: Security",
    ],
    python_requires=">=3.8",
    install_requires=[
        "torch>=1.9.0",
        "torchvision>=0.10.0",
        "numpy>=1.19.0",
    ],
    extras_require={
        "dev": [
            "pytest>=6.0",
            "black",
            "flake8",
        ],
    },
    keywords=[
        "machine-learning",
        "unlearning",
        "privacy",
        "pytorch",
        "edge-devices",
        "surgical-unlearning",
        "fisher-information",
    ],
)
