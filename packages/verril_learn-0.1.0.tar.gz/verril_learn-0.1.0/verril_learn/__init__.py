"""
Verril-Learn: A Surgical Machine Unlearning Library for Edge Devices

This library provides tools for:
- Training models on MNIST
- Simulating data poisoning attacks
- Surgical unlearning using Gradient Ascent + Fisher Information

Example Usage:
    from verril_learn import get_poisoned_mnist, SimpleCNN, surgical_unlearn
    
    # Load poisoned data
    train_loader, test_loader, poison_indices = get_poisoned_mnist(poison_ratio=0.1)
    
    # Train your model
    model = SimpleCNN()
    # ... training code ...
    
    # Unlearn the poisoned data
    unlearned_model = surgical_unlearn(model, poisoned_data, retain_data)
"""

__version__ = "0.1.0"
__author__ = "Verril"

# Import main components for easy access
from .data_loader import get_poisoned_mnist, get_clean_mnist
from .model import SimpleCNN
from .core import (
    surgical_unlearn,
    calculate_fisher,
)

__all__ = [
    # Data loading
    "get_poisoned_mnist",
    "get_clean_mnist",
    # Model
    "SimpleCNN",
    # Core unlearning
    "surgical_unlearn",
    "calculate_fisher",
]
