# VertexEngine/Vertex
VertexEngine is a GUI and Game Engine for python applications, it works best if you use py installer
## Offical Extensions:
[VertexEngine-WebEngine](https://pypi.org/project/VertexEngine-WebEngine)
[VertexEngine-CLI](https://pypi.org/project/VertexEngine-CLI/1.0/)
## Change Logs (1.0rc1 - 1.2rc3), NEW!
### 1.2rc4
- Final RC!
- Docs will be updated on Feb 04, 2026.
- New Library!:
~ VertexEngine.AdvancedWidgets
### 1.2rc3
- Added 1 New Library:
~ HBox, VBox but horizontally not vertically.
### 1.2rc1
- Added a new Extension: [VertexEngine-CLI](https://pypi.org/project/VertexEngine-CLI/1.0/)

### 1.1
- Bugfixed WebEngine
- Compression

### 1.1rc4
- FINAL RC!
- Added 2 New Libraries: ~ VertexEngine.WebEngine ~ VertexEngine.WebView

### 1.1rc3
Revamped Input System!
DEMO GAMES!
Updated Scene Docs

### Version 1.1rc2
Documentation Expansion! ~ Fixed the Changelogs
New Input System!
Old System (Qt) depreceated and not recomended for use.

### Version 1.1rc1
New Library! (And Modules)!: ~ InputSystem ~ Buttons (Mouse and Widget) ~ Keyboard Input

### Version 1.0.1
Added Changelogs!

### Version 1.0
Added 2 New Libraries: ~ VertexEngine.SimpleGUI ~ VertexEngine.VertexScreenModifiers

### Version 1.0rc2
Final Release Candidate
Added 1 New Library!: ~ VertexUI

### Version 1.0rc1
Size Compression
Added 1 New Library!: ~ VertexScreen

## How to install Pyinstaller
Step 1. Type in: pip install pyinstaller

Step 2. Wait a few min, don't worry if it takes 1 hr or more, it will finish

Step 3. How to use pyinstaller type: python -m PyInstaller --onefile *.py

There are flags: --noconsole > disables the console when you run the app --onefile > compress all of the code into one file --icon > the *.ico file after you type it will be set as the app icon.

## How to install VertexEngine/Vertex:
Step 1: Type in pip install VertexEngine

Step 2: Wait a few min, don't worry if it takes 1 hr or more, it will finish

Pygame or PyQt6 systems are compatible with Vertex so you can use pygame collision system or PyQt6's UI system in VertexEngine.

## Help
The documentation is in the following link: (Documentation)["https://vertexenginedocs.netlify.app/"] for help.

## Dependencies
Vertex obviously has heavy dependencies since it's a game engine, the following requirements are:

| Dependency       | Version                              |
|------------------|--------------------------------------|
| PyQt6            | >=6.7                                |   
| Pygame           | >=2.0                                |
| Python           | >=3.10                               |

## About Me ❔
I Am a solo developer in Diliman, Quezon City that makes things for fun :) 77 Rd 1, 53 Rd 3 Bg-Asa QC Email: FinalFacility0828@gmail.com

## 📄 License
VertexEngine/Vertex is Managed by the MIT License. This license allows others to tweak the code. However, I would like my name be in the credits if you choose this as your starting ground for your next library.