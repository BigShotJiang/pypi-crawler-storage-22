from __future__ import annotations

from pathlib import Path

from setuptools import find_packages, setup

ROOT = Path(__file__).parent
README = (ROOT / "README.md").read_text(encoding="utf-8")

setup(
    name="vertical",
    version="0.1.0a2026021701",
    description="Terminal-first live training monitor for Python ML workloads across frameworks.",
    long_description=README,
    long_description_content_type="text/markdown",
    author="vertical contributors",
    license="MIT",
    python_requires=">=3.10",
    package_dir={"": "src"},
    packages=find_packages(where="src", include=["vertical*", "tui*"]),
    include_package_data=True,
    install_requires=[
        "rich>=13.9.4",
    ],
    extras_require={
        "pytorch": ["torch>=2.2"],
        "jax": ["jax>=0.4.30"],
        "flax": ["flax>=0.8.0", "jax>=0.4.30"],
        "all": ["torch>=2.2", "jax>=0.4.30", "flax>=0.8.0"],
    },
    entry_points={
        "console_scripts": [
            "vertical-demo=vertical.demo:main",
            "vertical-tui=tui.__main__:main",
        ]
    },
    keywords=["machine-learning", "monitoring", "pytorch", "jax", "flax", "metrics"],
    classifiers=[
        "Development Status :: 3 - Alpha",
        "Intended Audience :: Developers",
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3 :: Only",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
        "Topic :: Scientific/Engineering :: Artificial Intelligence",
    ],
)
