from __future__ import annotations

import argparse
import os

from tui.viewer import TerminalRunViewer


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="Live terminal viewer for vertical metric endpoints."
    )
    parser.add_argument(
        "--endpoint",
        default="http://127.0.0.1:9100",
        help="Base URL of metric server (default: http://127.0.0.1:9100)",
    )
    parser.add_argument(
        "--refresh",
        type=int,
        default=4,
        help="UI refresh rate per second.",
    )
    parser.add_argument(
        "--history-limit",
        type=int,
        default=40,
        help="Number of recent events to render.",
    )
    parser.add_argument(
        "--duration",
        type=float,
        default=None,
        help="Optional viewer runtime in seconds. If omitted, runs until Ctrl+C.",
    )
    parser.add_argument(
        "--token",
        default=os.getenv("VERTICAL_AUTH_TOKEN"),
        help="Optional bearer token for authenticated metric endpoints.",
    )
    return parser


def main() -> None:
    args = build_parser().parse_args()
    viewer = TerminalRunViewer(
        endpoint=args.endpoint,
        auth_token=args.token,
        refresh_per_second=max(1, args.refresh),
        history_limit=max(1, args.history_limit),
    )
    viewer.run(duration_seconds=args.duration)


if __name__ == "__main__":
    main()
