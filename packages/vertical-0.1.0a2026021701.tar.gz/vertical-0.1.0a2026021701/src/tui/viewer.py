from __future__ import annotations

import json
import time
from collections.abc import Mapping
from typing import Any
from urllib import error, request

from rich.console import RenderableType
from rich.live import Live
from rich.panel import Panel
from rich.table import Table
from rich.text import Text


class MetricEndpointClient:
    def __init__(
        self,
        base_url: str,
        *,
        timeout: float = 2.0,
        auth_token: str | None = None,
    ) -> None:
        self.base_url = base_url.rstrip("/")
        self.timeout = timeout
        self.auth_token = auth_token

    def latest(self) -> dict[str, Any] | None:
        payload = self._get_json("/metrics/latest")
        event = payload.get("event")
        if isinstance(event, Mapping):
            return dict(event)
        return None

    def history(self, *, limit: int = 40) -> list[dict[str, Any]]:
        payload = self._get_json(f"/metrics/history?limit={max(1, int(limit))}")
        events = payload.get("events")
        if not isinstance(events, list):
            return []
        normalized: list[dict[str, Any]] = []
        for event in events:
            if isinstance(event, Mapping):
                normalized.append(dict(event))
        return normalized

    def _get_json(self, path: str) -> dict[str, Any]:
        url = f"{self.base_url}{path}"
        req = request.Request(url, method="GET", headers=self._build_headers())
        try:
            with request.urlopen(req, timeout=self.timeout) as response:
                body = response.read().decode("utf-8")
        except (error.URLError, OSError) as exc:
            raise RuntimeError(f"failed to query {url}: {exc}") from exc
        try:
            decoded = json.loads(body) if body else {}
        except json.JSONDecodeError as exc:
            raise RuntimeError(f"invalid JSON from {url}: {exc}") from exc
        if not isinstance(decoded, dict):
            raise RuntimeError(f"invalid payload from {url}: expected object")
        return decoded

    def _build_headers(self) -> dict[str, str]:
        if self.auth_token is None:
            return {}
        return {"Authorization": f"Bearer {self.auth_token}"}


class TerminalRunViewer:
    def __init__(
        self,
        *,
        endpoint: str = "http://127.0.0.1:9100",
        auth_token: str | None = None,
        refresh_per_second: int = 4,
        history_limit: int = 40,
    ) -> None:
        self.endpoint = endpoint.rstrip("/")
        self.auth_token = auth_token
        self.refresh_per_second = refresh_per_second
        self.history_limit = history_limit
        self._client = MetricEndpointClient(self.endpoint, auth_token=self.auth_token)

    def run(self, *, duration_seconds: float | None = None) -> None:
        started_at = time.monotonic()
        frame_interval = 1 / max(1, self.refresh_per_second)

        with Live(
            self._render_frame(latest=None, history=[], error_message=None),
            refresh_per_second=self.refresh_per_second,
        ) as live:
            while True:
                latest: dict[str, Any] | None = None
                history: list[dict[str, Any]] = []
                error_message: str | None = None
                try:
                    latest = self._client.latest()
                    history = self._client.history(limit=self.history_limit)
                except RuntimeError as exc:
                    error_message = str(exc)

                live.update(
                    self._render_frame(
                        latest=latest,
                        history=history,
                        error_message=error_message,
                    )
                )
                if duration_seconds is not None and (
                    time.monotonic() - started_at
                ) >= duration_seconds:
                    break
                time.sleep(frame_interval)

    def _render_frame(
        self,
        *,
        latest: dict[str, Any] | None,
        history: list[dict[str, Any]],
        error_message: str | None,
    ) -> RenderableType:
        if error_message:
            return Panel(
                Text(error_message, style="bold red"),
                title=f"vertical tui - {self.endpoint}",
                border_style="red",
            )

        if latest is None and not history:
            return Panel(
                Text("Waiting for training events...", style="italic cyan"),
                title=f"vertical tui - {self.endpoint}",
                border_style="bright_blue",
            )

        summary = Table.grid(padding=(0, 2))
        summary.add_column(style="bold white")
        summary.add_column(style="bright_magenta")
        summary.add_row("Step", _fmt_int(latest.get("step") if latest else None))
        summary.add_row("Epoch", _fmt_int(latest.get("epoch") if latest else None))
        summary.add_row("Loss", _fmt_float(latest.get("loss") if latest else None))
        summary.add_row(
            "Learning Rate",
            _fmt_float(latest.get("learning_rate") if latest else None),
        )
        summary.add_row("Status", str(latest.get("status", "-") if latest else "-"))

        metric_map = latest.get("metrics", {}) if latest else {}
        if isinstance(metric_map, Mapping) and metric_map:
            metric_table = Table.grid(expand=True)
            metric_table.add_column(style="bold")
            metric_table.add_column(style="green")
            for key, value in sorted(metric_map.items()):
                metric_table.add_row(str(key), _fmt_float(value))
            summary.add_row("Metrics", "")
            summary.add_row("", metric_table)

        trend = _build_loss_trend(history)
        summary.add_row("Loss Trend", trend)

        history_table = Table(title="Recent Events", expand=True)
        history_table.add_column("Step", justify="right", style="cyan")
        history_table.add_column("Loss", justify="right", style="magenta")
        history_table.add_column("LR", justify="right", style="yellow")
        history_table.add_column("Status", style="green")
        for event in reversed(history[-min(len(history), self.history_limit) :]):
            history_table.add_row(
                _fmt_int(event.get("step")),
                _fmt_float(event.get("loss")),
                _fmt_float(event.get("learning_rate")),
                str(event.get("status", "-")),
            )

        layout = Table.grid(expand=True)
        layout.add_row(summary)
        layout.add_row(history_table)
        return Panel(layout, title=f"vertical tui - {self.endpoint}", border_style="bright_blue")


def _build_loss_trend(history: list[dict[str, Any]], width: int = 32) -> str:
    losses = [float(item["loss"]) for item in history if item.get("loss") is not None]
    if not losses:
        return "-"
    sample = losses[-width:]
    low = min(sample)
    high = max(sample)
    if high - low < 1e-12:
        return "=" * len(sample)
    symbols = " .:-=+*#%@"
    trend = []
    for value in sample:
        normalized = (value - low) / (high - low)
        index = int(normalized * (len(symbols) - 1))
        trend.append(symbols[index])
    return "".join(trend)


def _fmt_float(value: Any) -> str:
    if value is None:
        return "-"
    try:
        number = float(value)
    except (TypeError, ValueError):
        return "-"
    return f"{number:.6f}" if abs(number) < 1 else f"{number:.4f}"


def _fmt_int(value: Any) -> str:
    if value is None:
        return "-"
    try:
        return str(int(value))
    except (TypeError, ValueError):
        return "-"
