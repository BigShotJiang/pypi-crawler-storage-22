from __future__ import annotations

import json
import threading
from collections.abc import Mapping
from datetime import datetime, timezone
from typing import Any
from urllib import error, request


class MetricClientError(RuntimeError):
    """Raised when metrics cannot be posted to the server."""


class HTTPMetricLogger:
    """
    Simple HTTP logger compatible with framework training loops.

    It posts metric events to `POST /metrics` on the configured base URL.
    """

    def __init__(
        self,
        base_url: str,
        *,
        timeout: float = 2.0,
        run_id: str | None = None,
        auth_token: str | None = None,
    ) -> None:
        self.base_url = base_url.rstrip("/")
        self.timeout = timeout
        self.run_id = run_id
        self.auth_token = auth_token
        self._forward_calls = 0
        self._lock = threading.Lock()

    def log(
        self,
        *,
        step: int,
        epoch: int | None = None,
        loss: float | None = None,
        learning_rate: float | None = None,
        metrics: Mapping[str, float] | None = None,
        training_info: Mapping[str, Any] | None = None,
        status: str = "running",
        run_id: str | None = None,
    ) -> dict[str, Any]:
        payload: dict[str, Any] = {
            "step": int(step),
            "epoch": epoch,
            "loss": _opt_float(loss),
            "learning_rate": _opt_float(learning_rate),
            "metrics": dict(metrics) if metrics else {},
            "training_info": dict(training_info) if training_info else {},
            "status": status,
            "run_id": run_id if run_id is not None else self.run_id,
            "timestamp": datetime.now(timezone.utc).isoformat(),
        }
        data = json.dumps(payload).encode("utf-8")
        req = request.Request(
            f"{self.base_url}/metrics",
            method="POST",
            data=data,
            headers=self._build_headers(),
        )
        try:
            with request.urlopen(req, timeout=self.timeout) as response:
                body = response.read().decode("utf-8")
                return json.loads(body) if body else {}
        except (error.URLError, OSError, json.JSONDecodeError) as exc:
            raise MetricClientError(f"failed to post metrics to {self.base_url}: {exc}") from exc

    def log_forward(
        self,
        *,
        loss: float | None,
        step: int | None = None,
        epoch: int | None = None,
        learning_rate: float | None = None,
        metrics: Mapping[str, float] | None = None,
        training_info: Mapping[str, Any] | None = None,
        run_id: str | None = None,
    ) -> dict[str, Any]:
        with self._lock:
            self._forward_calls += 1
            forward_call = self._forward_calls

        merged_metrics = dict(metrics) if metrics else {}
        merged_metrics["forward_call"] = float(forward_call)
        merged_training_info = dict(training_info) if training_info else {}
        merged_training_info.setdefault("event", "forward")

        return self.log(
            step=forward_call if step is None else step,
            epoch=epoch,
            loss=loss,
            learning_rate=learning_rate,
            metrics=merged_metrics,
            training_info=merged_training_info,
            status="forward",
            run_id=run_id,
        )

    def _build_headers(self) -> dict[str, str]:
        headers = {"Content-Type": "application/json"}
        if self.auth_token is not None:
            headers["Authorization"] = f"Bearer {self.auth_token}"
        return headers


def _opt_float(value: float | None) -> float | None:
    if value is None:
        return None
    return float(value)
