from __future__ import annotations

import random
import time

from vertical import TrainingMonitor


def main() -> None:
    total_steps = 120
    with TrainingMonitor(title="vertical demo") as monitor:
        for step in range(1, total_steps + 1):
            progress = step / total_steps
            base_loss = max(0.02, 2.0 * (1 - progress) ** 2)
            jitter = random.uniform(-0.04, 0.04)
            loss = max(0.01, base_loss + jitter)
            lr = 1e-3 * (0.95 ** (step // 20))
            val_loss = loss + random.uniform(0.01, 0.12)
            acc = min(0.99, progress + random.uniform(-0.03, 0.03))

            monitor.log(
                step=step,
                epoch=((step - 1) // 30) + 1,
                loss=loss,
                learning_rate=lr,
                metrics={"val_loss": val_loss, "accuracy": acc},
                status="running" if step < total_steps else "done",
            )
            time.sleep(0.06)


if __name__ == "__main__":
    main()
