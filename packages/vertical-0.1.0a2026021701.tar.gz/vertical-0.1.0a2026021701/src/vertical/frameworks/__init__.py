from .base import FrameworkAdapter, FrameworkContext
from .flax import FlaxAdapter, FlaxTrainingWrapper
from .jax import JaxAdapter, JaxTrainingWrapper
from .pytorch import PyTorchAdapter, PyTorchTrainingWrapper

_ADAPTERS: dict[str, type[FrameworkAdapter]] = {
    "pytorch": PyTorchAdapter,
    "torch": PyTorchAdapter,
    "jax": JaxAdapter,
    "flax": FlaxAdapter,
}


def get_adapter(framework: str) -> FrameworkAdapter:
    normalized = framework.strip().lower()
    adapter_cls = _ADAPTERS.get(normalized)
    if adapter_cls is None:
        supported = ", ".join(sorted(_ADAPTERS))
        raise ValueError(f"unsupported framework '{framework}'. Supported frameworks: {supported}")
    return adapter_cls()


__all__ = [
    "FrameworkAdapter",
    "FrameworkContext",
    "FlaxAdapter",
    "FlaxTrainingWrapper",
    "JaxAdapter",
    "JaxTrainingWrapper",
    "PyTorchAdapter",
    "PyTorchTrainingWrapper",
    "get_adapter",
]
