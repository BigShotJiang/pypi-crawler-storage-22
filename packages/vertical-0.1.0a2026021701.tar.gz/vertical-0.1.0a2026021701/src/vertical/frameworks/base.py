from __future__ import annotations

from collections.abc import Mapping
from dataclasses import dataclass, field
from typing import Any, Protocol


@dataclass(frozen=True)
class FrameworkContext:
    name: str
    device: str | None = None
    extras: dict[str, str] = field(default_factory=dict)


class FrameworkAdapter(Protocol):
    name: str

    def build_context(self, options: Mapping[str, Any]) -> FrameworkContext:
        ...
