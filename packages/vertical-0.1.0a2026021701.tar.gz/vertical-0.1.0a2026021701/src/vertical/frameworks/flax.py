from __future__ import annotations

import importlib
from collections.abc import Mapping
from typing import Any

from .base import FrameworkAdapter, FrameworkContext
from .jax import _jax_metrics_to_floats, _jax_scalar_to_float, _resolve_device


class FlaxAdapter(FrameworkAdapter):
    name = "flax"

    def build_context(self, options: Mapping[str, Any]) -> FrameworkContext:
        importlib.import_module("flax")
        jax = importlib.import_module("jax")
        device = _resolve_device(jax, options.get("backend"))
        return FrameworkContext(
            name=self.name,
            device=str(device),
            extras={"platform": device.platform},
        )


class FlaxTrainingWrapper:
    """Convenience wrapper for Flax training loops and TrainState integration."""

    def __init__(self, run: Any) -> None:
        self._run = run

    def forward(
        self,
        *,
        loss: Any,
        step: int | None = None,
        epoch: int | None = None,
        learning_rate: float | None = None,
        metrics: Mapping[str, Any] | None = None,
        training_info: Mapping[str, Any] | None = None,
        status: str = "forward",
        **metric_values: Any,
    ) -> Any:
        normalized_metrics = _jax_metrics_to_floats(metrics or {})
        normalized_metrics.update(_jax_metrics_to_floats(metric_values))

        merged_training_info = {
            "framework": "flax",
            "platform": self._run.framework.extras.get("platform", "unknown"),
        }
        if training_info:
            merged_training_info.update({str(key): value for key, value in training_info.items()})

        return self._run.forward(
            loss=_jax_scalar_to_float(loss),
            step=step,
            epoch=epoch,
            learning_rate=learning_rate,
            metrics=normalized_metrics,
            training_info=merged_training_info,
            status=status,
        )

    def train_state_step(
        self,
        *,
        state: Any,
        loss: Any,
        learning_rate: float | None = None,
        metrics: Mapping[str, Any] | None = None,
        training_info: Mapping[str, Any] | None = None,
        status: str = "forward",
        **metric_values: Any,
    ) -> Any:
        state_step = getattr(state, "step", None)
        if state_step is None:
            raise ValueError("state must expose a 'step' attribute")

        normalized_state_step = int(_jax_scalar_to_float(state_step))

        merged_training_info = {"state": type(state).__name__}
        if training_info:
            merged_training_info.update({str(key): value for key, value in training_info.items()})

        return self.forward(
            loss=loss,
            step=normalized_state_step,
            learning_rate=learning_rate,
            metrics=metrics,
            training_info=merged_training_info,
            status=status,
            **metric_values,
        )
