from __future__ import annotations

import importlib
from collections.abc import Mapping
from numbers import Number
from typing import Any

from .base import FrameworkAdapter, FrameworkContext


class JaxAdapter(FrameworkAdapter):
    name = "jax"

    def build_context(self, options: Mapping[str, Any]) -> FrameworkContext:
        jax = importlib.import_module("jax")
        device = _resolve_device(jax, options.get("backend"))
        return FrameworkContext(
            name=self.name,
            device=str(device),
            extras={"platform": device.platform},
        )


class JaxTrainingWrapper:
    """Helper wrapper for emitting forward-pass metrics from JAX loops."""

    def __init__(self, run: Any) -> None:
        self._run = run

    def forward(
        self,
        *,
        loss: Any,
        step: int | None = None,
        epoch: int | None = None,
        learning_rate: float | None = None,
        metrics: Mapping[str, Any] | None = None,
        status: str = "forward",
        training_info: Mapping[str, Any] | None = None,
        **metric_values: Any,
    ) -> Any:
        normalized_metrics = _jax_metrics_to_floats(metrics or {})
        normalized_metrics.update(_jax_metrics_to_floats(metric_values))

        merged_training_info = {
            "framework": "jax",
            "platform": self._run.framework.extras.get("platform", "unknown"),
        }
        if training_info:
            merged_training_info.update({str(key): value for key, value in training_info.items()})

        return self._run.forward(
            loss=_jax_scalar_to_float(loss),
            step=step,
            epoch=epoch,
            learning_rate=learning_rate,
            metrics=normalized_metrics,
            training_info=merged_training_info,
            status=status,
        )


def _resolve_device(jax_module: Any, backend: Any) -> Any:
    if backend is None:
        return jax_module.devices()[0]
    normalized_backend = str(backend).lower()
    if normalized_backend not in {"cpu", "cuda", "gpu", "tpu"}:
        raise ValueError(f"unsupported jax backend '{backend}'")
    devices = jax_module.devices(normalized_backend)
    if not devices:
        raise RuntimeError(f"no jax devices found for backend '{normalized_backend}'")
    return devices[0]


def _jax_scalar_to_float(value: Any) -> float | None:
    if value is None:
        return None
    if isinstance(value, bool):
        raise TypeError("boolean values are not valid metrics")
    if isinstance(value, Number):
        return float(value)

    if hasattr(value, "item"):
        extracted = value.item()
        if isinstance(extracted, bool):
            raise TypeError("boolean values are not valid metrics")
        return float(extracted)

    jax = importlib.import_module("jax")
    extracted = jax.device_get(value)
    if hasattr(extracted, "item"):
        extracted = extracted.item()
    if isinstance(extracted, bool):
        raise TypeError("boolean values are not valid metrics")
    return float(extracted)


def _jax_metrics_to_floats(values: Mapping[str, Any]) -> dict[str, float]:
    return {str(name): _jax_scalar_to_float(metric) for name, metric in values.items()}
