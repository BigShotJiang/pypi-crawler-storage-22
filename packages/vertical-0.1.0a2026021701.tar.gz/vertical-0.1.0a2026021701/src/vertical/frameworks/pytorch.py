from __future__ import annotations

import importlib
from collections.abc import Mapping
from numbers import Number
from typing import Any

from .base import FrameworkAdapter, FrameworkContext


class PyTorchAdapter(FrameworkAdapter):
    name = "pytorch"

    def build_context(self, options: Mapping[str, Any]) -> FrameworkContext:
        torch = importlib.import_module("torch")
        requested = str(options.get("device", "cuda")).lower()
        if requested.startswith("cuda") and not torch.cuda.is_available():
            requested = "cpu"
        if requested not in {"cpu", "cuda"} and not requested.startswith("cuda:"):
            raise ValueError(f"unsupported pytorch device '{requested}'")
        if requested.startswith("cuda") and not torch.cuda.is_available():
            raise RuntimeError("pytorch cuda device requested but CUDA is unavailable")
        return FrameworkContext(name=self.name, device=requested)


class PyTorchTrainingWrapper:
    """Helper wrapper for emitting forward-pass metrics from PyTorch loops."""

    def __init__(self, run: Any) -> None:
        self._run = run

    def forward(
        self,
        *,
        loss: Any,
        step: int | None = None,
        epoch: int | None = None,
        learning_rate: float | None = None,
        metrics: Mapping[str, Any] | None = None,
        training_info: Mapping[str, Any] | None = None,
        status: str = "forward",
        **metric_values: Any,
    ) -> Any:
        normalized_metrics = _torch_metrics_to_floats(metrics or {})
        normalized_metrics.update(_torch_metrics_to_floats(metric_values))

        merged_training_info = {
            "framework": "pytorch",
            "device": self._run.framework.device or "unknown",
        }
        if training_info:
            merged_training_info.update({str(key): value for key, value in training_info.items()})

        return self._run.forward(
            loss=_torch_scalar_to_float(loss),
            step=step,
            epoch=epoch,
            learning_rate=learning_rate,
            metrics=normalized_metrics,
            training_info=merged_training_info,
            status=status,
        )

    def module_step(
        self,
        *,
        module: Any,
        loss: Any,
        optimizer: Any | None = None,
        step: int | None = None,
        epoch: int | None = None,
        learning_rate: float | None = None,
        metrics: Mapping[str, Any] | None = None,
        training_info: Mapping[str, Any] | None = None,
        status: str = "forward",
        **metric_values: Any,
    ) -> Any:
        resolved_step = step if step is not None else _resolve_module_step(module)
        resolved_lr = learning_rate
        if resolved_lr is None:
            resolved_lr = _resolve_optimizer_lr(optimizer)

        merged_training_info = _module_training_info(module)
        if training_info:
            merged_training_info.update({str(key): value for key, value in training_info.items()})

        return self.forward(
            loss=loss,
            step=resolved_step,
            epoch=epoch,
            learning_rate=resolved_lr,
            metrics=metrics,
            training_info=merged_training_info,
            status=status,
            **metric_values,
        )


def _resolve_module_step(module: Any) -> int | None:
    for candidate in ("global_step", "step"):
        if not hasattr(module, candidate):
            continue
        raw_value = getattr(module, candidate)
        try:
            normalized = _torch_scalar_to_float(raw_value)
        except (TypeError, ValueError):
            continue
        if normalized is not None:
            return int(normalized)
    return None


def _resolve_optimizer_lr(optimizer: Any | None) -> float | None:
    if optimizer is None:
        return None
    param_groups = getattr(optimizer, "param_groups", None)
    if not isinstance(param_groups, list) or not param_groups:
        return None
    first_group = param_groups[0]
    if not isinstance(first_group, Mapping):
        return None
    lr = first_group.get("lr")
    if lr is None:
        return None
    return float(lr)


def _module_training_info(module: Any) -> dict[str, Any]:
    info: dict[str, Any] = {"module": type(module).__name__}

    training_mode = getattr(module, "training", None)
    if isinstance(training_mode, bool):
        info["mode"] = "train" if training_mode else "eval"

    device = _first_tensor_attr(module, "device")
    if device is not None:
        info["module_device"] = device

    dtype = _first_tensor_attr(module, "dtype")
    if dtype is not None:
        info["module_dtype"] = dtype

    return info


def _first_tensor_attr(module: Any, attr_name: str) -> str | None:
    for iterator_name in ("parameters", "buffers"):
        iterator_factory = getattr(module, iterator_name, None)
        if not callable(iterator_factory):
            continue
        try:
            iterator = iter(iterator_factory())
            first = next(iterator, None)
        except TypeError:
            continue
        if first is None:
            continue
        value = getattr(first, attr_name, None)
        if value is None:
            continue
        return str(value)
    return None


def _torch_metrics_to_floats(values: Mapping[str, Any]) -> dict[str, float]:
    return {str(name): _torch_scalar_to_float(metric) for name, metric in values.items()}


def _torch_scalar_to_float(value: Any) -> float | None:
    if value is None:
        return None
    if isinstance(value, bool):
        raise TypeError("boolean values are not valid metrics")
    if isinstance(value, Number):
        return float(value)

    detached = value.detach() if hasattr(value, "detach") else value
    if hasattr(detached, "item"):
        extracted = detached.item()
        if isinstance(extracted, bool):
            raise TypeError("boolean values are not valid metrics")
        return float(extracted)

    return float(detached)
