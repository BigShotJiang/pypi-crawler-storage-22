from __future__ import annotations

from collections import deque
from collections.abc import Mapping
from dataclasses import dataclass, field
from datetime import datetime, timezone

from rich.console import RenderableType
from rich.live import Live
from rich.panel import Panel
from rich.table import Table
from rich.text import Text


@dataclass(frozen=True)
class TrainingSnapshot:
    step: int
    epoch: int | None = None
    loss: float | None = None
    learning_rate: float | None = None
    metrics: dict[str, float] = field(default_factory=dict)
    status: str = "running"
    timestamp: datetime = field(default_factory=lambda: datetime.now(timezone.utc))


class TrainingMonitor:
    def __init__(
        self,
        *,
        title: str = "Training Monitor",
        history_size: int = 8,
        refresh_per_second: int = 8,
        transient: bool = False,
    ) -> None:
        self.title = title
        self._history: deque[TrainingSnapshot] = deque(maxlen=history_size)
        self._refresh_per_second = refresh_per_second
        self._transient = transient
        self._live: Live | None = None

    def __enter__(self) -> TrainingMonitor:
        self.start()
        return self

    def __exit__(self, exc_type: object, exc: object, tb: object) -> None:
        self.stop()

    @property
    def history(self) -> list[TrainingSnapshot]:
        return list(self._history)

    @property
    def latest(self) -> TrainingSnapshot | None:
        return self._history[-1] if self._history else None

    def start(self) -> None:
        if self._live is not None:
            return
        self._live = Live(
            self._render(),
            refresh_per_second=self._refresh_per_second,
            transient=self._transient,
        )
        self._live.start()

    def stop(self) -> None:
        if self._live is None:
            return
        self._live.stop()
        self._live = None

    def log(
        self,
        *,
        step: int,
        epoch: int | None = None,
        loss: float | None = None,
        learning_rate: float | None = None,
        metrics: Mapping[str, float] | None = None,
        status: str = "running",
    ) -> TrainingSnapshot:
        snapshot = TrainingSnapshot(
            step=step,
            epoch=epoch,
            loss=loss,
            learning_rate=learning_rate,
            metrics=dict(metrics) if metrics else {},
            status=status,
        )
        self._history.append(snapshot)
        self._refresh()
        return snapshot

    def _refresh(self) -> None:
        if self._live is not None:
            self._live.update(self._render())

    def _render(self) -> RenderableType:
        latest = self.latest
        if latest is None:
            return Panel(
                Text("Waiting for training logs...", style="italic cyan"),
                title=self.title,
                border_style="bright_blue",
            )

        summary = Table.grid(padding=(0, 2))
        summary.add_column(style="bold white")
        summary.add_column(style="bright_magenta")
        summary.add_row("Step", str(latest.step))
        summary.add_row("Epoch", "-" if latest.epoch is None else str(latest.epoch))
        summary.add_row("Loss", _fmt_float(latest.loss))
        summary.add_row("Learning Rate", _fmt_float(latest.learning_rate))
        summary.add_row("Status", latest.status)
        summary.add_row("Updated", latest.timestamp.strftime("%H:%M:%S"))

        if latest.metrics:
            metric_table = Table.grid(expand=True)
            metric_table.add_column(style="bold")
            metric_table.add_column(style="green")
            for name, value in sorted(latest.metrics.items()):
                metric_table.add_row(name, _fmt_float(value))
            summary.add_row("Metrics", "")
            summary.add_row("", metric_table)

        history_table = Table(title="Recent Steps", expand=True, show_lines=False)
        history_table.add_column("Step", justify="right", style="cyan")
        history_table.add_column("Loss", justify="right", style="magenta")
        history_table.add_column("LR", justify="right", style="yellow")
        history_table.add_column("Status", justify="left", style="green")
        for snapshot in reversed(self.history):
            history_table.add_row(
                str(snapshot.step),
                _fmt_float(snapshot.loss),
                _fmt_float(snapshot.learning_rate),
                snapshot.status,
            )

        frame = Table.grid(expand=True)
        frame.add_row(summary)
        frame.add_row(history_table)

        return Panel(frame, title=self.title, border_style="bright_blue")


def _fmt_float(value: float | None) -> str:
    if value is None:
        return "-"
    return f"{value:.6f}" if abs(value) < 1 else f"{value:.4f}"
