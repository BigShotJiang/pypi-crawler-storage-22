from __future__ import annotations

import hashlib
import json
import os
import secrets
import subprocess
import threading
import time
from collections import deque
from collections.abc import Mapping
from dataclasses import dataclass, field
from datetime import datetime, timezone
from http import HTTPStatus
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from typing import Any
from urllib.parse import parse_qs, urlparse

from .client import HTTPMetricLogger

DEFAULT_IDENTITY_FILE = "~/.ssh/vertical_ed25519"


class TunnelError(RuntimeError):
    """Raised when an SSH reverse tunnel cannot be started."""


@dataclass(frozen=True)
class MetricEvent:
    step: int
    epoch: int | None = None
    loss: float | None = None
    learning_rate: float | None = None
    metrics: dict[str, float] = field(default_factory=dict)
    training_info: dict[str, Any] = field(default_factory=dict)
    status: str = "running"
    run_id: str | None = None
    timestamp: datetime = field(default_factory=lambda: datetime.now(timezone.utc))

    def to_dict(self) -> dict[str, Any]:
        return {
            "step": self.step,
            "epoch": self.epoch,
            "loss": self.loss,
            "learning_rate": self.learning_rate,
            "metrics": self.metrics,
            "training_info": self.training_info,
            "status": self.status,
            "run_id": self.run_id,
            "timestamp": self.timestamp.isoformat(),
        }

    @classmethod
    def from_payload(cls, payload: Mapping[str, Any]) -> MetricEvent:
        if "step" not in payload:
            raise ValueError("missing required field: step")
        metrics = payload.get("metrics") or {}
        if not isinstance(metrics, Mapping):
            raise ValueError("metrics must be an object")
        normalized_metrics = {str(key): float(value) for key, value in metrics.items()}
        training_info = payload.get("training_info") or {}
        if not isinstance(training_info, Mapping):
            raise ValueError("training_info must be an object")
        normalized_training_info = _normalize_training_info(training_info)
        timestamp = _parse_timestamp(payload.get("timestamp"))
        run_id = payload.get("run_id")
        if run_id is not None:
            run_id = str(run_id)
        return cls(
            step=int(payload["step"]),
            epoch=_coerce_optional_int(payload.get("epoch")),
            loss=_coerce_optional_float(payload.get("loss")),
            learning_rate=_coerce_optional_float(payload.get("learning_rate")),
            metrics=normalized_metrics,
            training_info=normalized_training_info,
            status=str(payload.get("status", "running")),
            run_id=run_id,
            timestamp=timestamp,
        )


@dataclass
class ReverseTunnelConfig:
    ssh_host: str
    ssh_user: str | None = None
    ssh_port: int = 22
    remote_port: int = 9100
    remote_bind_host: str = "127.0.0.1"
    local_host: str = "127.0.0.1"
    local_port: int | None = None
    identity_file: str | None = None
    strict_host_key_checking: bool = True
    known_hosts_file: str | None = None
    extra_ssh_args: tuple[str, ...] = ()
    enforce_key_auth: bool = True

    @property
    def destination(self) -> str:
        if self.ssh_user:
            return f"{self.ssh_user}@{self.ssh_host}"
        return self.ssh_host


class SSHReverseTunnel:
    def __init__(self, config: ReverseTunnelConfig) -> None:
        self.config = config
        self._process: subprocess.Popen[str] | None = None
        self._lock = threading.Lock()

    @property
    def is_running(self) -> bool:
        with self._lock:
            return self._process is not None and self._process.poll() is None

    def build_command(self) -> list[str]:
        if self.config.local_port is None:
            raise TunnelError("local_port must be resolved before starting the tunnel")
        command = [
            "ssh",
            "-N",
            "-T",
            "-p",
            str(self.config.ssh_port),
            "-o",
            "ExitOnForwardFailure=yes",
            "-o",
            "ServerAliveInterval=30",
            "-o",
            "ServerAliveCountMax=3",
        ]
        if self.config.enforce_key_auth:
            command.extend(
                [
                    "-o",
                    "BatchMode=yes",
                    "-o",
                    "PasswordAuthentication=no",
                    "-o",
                    "PreferredAuthentications=publickey",
                ]
            )
        if self.config.identity_file:
            command.extend(["-i", self.config.identity_file])
        if self.config.known_hosts_file:
            command.extend(["-o", f"UserKnownHostsFile={self.config.known_hosts_file}"])
        if not self.config.strict_host_key_checking:
            command.extend(["-o", "StrictHostKeyChecking=no"])
        command.extend(self.config.extra_ssh_args)
        command.extend(
            [
                "-R",
                (
                    f"{self.config.remote_bind_host}:{self.config.remote_port}:"
                    f"{self.config.local_host}:{self.config.local_port}"
                ),
                self.config.destination,
            ]
        )
        return command

    def start(self) -> None:
        with self._lock:
            if self._process is not None and self._process.poll() is None:
                return
            command = self.build_command()
            process = subprocess.Popen(
                command,
                stdin=subprocess.DEVNULL,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True,
            )
            self._process = process

        time.sleep(0.25)
        with self._lock:
            process = self._process
            if process is None:
                raise TunnelError("ssh reverse tunnel process is missing")
            if process.poll() is not None:
                stderr = process.stderr.read().strip() if process.stderr else ""
                self._process = None
                message = stderr or "unknown error"
                raise TunnelError(f"ssh reverse tunnel exited immediately: {message}")

    def stop(self) -> None:
        with self._lock:
            process = self._process
            self._process = None
        if process is None:
            return
        if process.poll() is None:
            process.terminate()
            try:
                process.wait(timeout=5)
            except subprocess.TimeoutExpired:
                process.kill()
                process.wait(timeout=5)


class _MetricStore:
    def __init__(self, history_size: int = 512) -> None:
        self._events: deque[MetricEvent] = deque(maxlen=history_size)
        self._lock = threading.Lock()

    def append(self, event: MetricEvent) -> None:
        with self._lock:
            self._events.append(event)

    def latest(self) -> MetricEvent | None:
        with self._lock:
            return self._events[-1] if self._events else None

    def history(self, *, limit: int | None = None) -> list[MetricEvent]:
        with self._lock:
            values = list(self._events)
        if limit is not None:
            return values[-limit:]
        return values


class TrainingMetricServer:
    def __init__(
        self,
        *,
        host: str = "127.0.0.1",
        port: int = 0,
        history_size: int = 512,
        run_id: str | None = None,
        auth_token: str | None = None,
    ) -> None:
        self.host = host
        self.port = port
        self.run_id = run_id
        self.auth_token = auth_token
        self._store = _MetricStore(history_size=history_size)
        self._server: ThreadingHTTPServer | None = None
        self._thread: threading.Thread | None = None

    def __enter__(self) -> TrainingMetricServer:
        self.start()
        return self

    def __exit__(self, exc_type: object, exc: object, tb: object) -> None:
        self.stop()

    def _build_handler(self) -> type[BaseHTTPRequestHandler]:
        store = self._store
        run_id = self.run_id
        auth_token = self.auth_token

        class Handler(BaseHTTPRequestHandler):
            def do_GET(self) -> None:  # noqa: N802
                if not self._authorize():
                    return
                parsed = urlparse(self.path)
                if parsed.path == "/health":
                    self._write_json(HTTPStatus.OK, {"status": "ok"})
                    return
                if parsed.path == "/metrics":
                    latest = store.latest()
                    if latest is None:
                        self._write_json(HTTPStatus.OK, {"status": "idle", "run_id": run_id})
                    else:
                        self._write_json(HTTPStatus.OK, latest.to_dict())
                    return
                if parsed.path == "/metrics/latest":
                    latest = store.latest()
                    self._write_json(HTTPStatus.OK, {"event": latest.to_dict() if latest else None})
                    return
                if parsed.path == "/metrics/history":
                    query = parse_qs(parsed.query)
                    raw_limit = query.get("limit", [None])[0]
                    limit = None
                    if raw_limit is not None:
                        limit = max(1, int(raw_limit))
                    payload = {"events": [event.to_dict() for event in store.history(limit=limit)]}
                    self._write_json(HTTPStatus.OK, payload)
                    return
                self._write_json(HTTPStatus.NOT_FOUND, {"error": "not found"})

            def do_POST(self) -> None:  # noqa: N802
                if not self._authorize():
                    return
                parsed = urlparse(self.path)
                if parsed.path != "/metrics":
                    self._write_json(HTTPStatus.NOT_FOUND, {"error": "not found"})
                    return
                try:
                    body = self._read_json()
                    event = MetricEvent.from_payload(body)
                    if event.run_id is None and run_id is not None:
                        event = MetricEvent(
                            step=event.step,
                            epoch=event.epoch,
                            loss=event.loss,
                            learning_rate=event.learning_rate,
                            metrics=event.metrics,
                            training_info=event.training_info,
                            status=event.status,
                            run_id=run_id,
                            timestamp=event.timestamp,
                        )
                except (json.JSONDecodeError, UnicodeDecodeError, ValueError) as exc:
                    self._write_json(HTTPStatus.BAD_REQUEST, {"error": str(exc)})
                    return
                store.append(event)
                self._write_json(HTTPStatus.CREATED, {"event": event.to_dict()})

            def log_message(self, format: str, *args: object) -> None:  # noqa: A003
                return

            def _authorize(self) -> bool:
                if auth_token is None:
                    return True
                authorization = self.headers.get("Authorization")
                if not authorization or not authorization.startswith("Bearer "):
                    self._write_json(HTTPStatus.UNAUTHORIZED, {"error": "unauthorized"})
                    return False
                supplied = authorization[len("Bearer ") :].strip()
                if not secrets.compare_digest(supplied, auth_token):
                    self._write_json(HTTPStatus.UNAUTHORIZED, {"error": "unauthorized"})
                    return False
                return True

            def _read_json(self) -> dict[str, Any]:
                raw_len = self.headers.get("Content-Length", "0")
                body_len = int(raw_len)
                payload = self.rfile.read(body_len)
                return json.loads(payload.decode("utf-8"))

            def _write_json(self, status: HTTPStatus, payload: Mapping[str, Any]) -> None:
                body = json.dumps(payload).encode("utf-8")
                self.send_response(status.value)
                self.send_header("Content-Type", "application/json")
                self.send_header("Content-Length", str(len(body)))
                self.end_headers()
                self.wfile.write(body)

        return Handler

    def start(self) -> None:
        if self._server is not None:
            return
        server = ThreadingHTTPServer((self.host, self.port), self._build_handler())
        thread = threading.Thread(
            target=server.serve_forever,
            name="vertical-metric-server",
            daemon=True,
        )
        thread.start()
        self._server = server
        self._thread = thread

    def stop(self) -> None:
        server = self._server
        thread = self._thread
        self._server = None
        self._thread = None
        if server is None:
            return
        server.shutdown()
        server.server_close()
        if thread is not None:
            thread.join(timeout=2)

    @property
    def local_port(self) -> int:
        if self._server is None:
            raise RuntimeError("server is not started")
        return int(self._server.server_address[1])

    @property
    def base_url(self) -> str:
        return f"http://{self.host}:{self.local_port}"

    def log(
        self,
        *,
        step: int,
        epoch: int | None = None,
        loss: float | None = None,
        learning_rate: float | None = None,
        metrics: Mapping[str, float] | None = None,
        training_info: Mapping[str, Any] | None = None,
        status: str = "running",
        run_id: str | None = None,
    ) -> MetricEvent:
        event = MetricEvent(
            step=step,
            epoch=epoch,
            loss=loss,
            learning_rate=learning_rate,
            metrics=dict(metrics) if metrics else {},
            training_info=_normalize_training_info(training_info or {}),
            status=status,
            run_id=run_id if run_id is not None else self.run_id,
        )
        self._store.append(event)
        return event

    def latest(self) -> MetricEvent | None:
        return self._store.latest()

    def history(self, *, limit: int | None = None) -> list[MetricEvent]:
        return self._store.history(limit=limit)


class TunnelledMetricService:
    def __init__(
        self,
        *,
        server: TrainingMetricServer,
        tunnel: SSHReverseTunnel,
        auth_token: str | None,
        ssh_public_key_path: str | None,
        reconnect_initial_delay: float = 1.0,
        reconnect_max_delay: float = 30.0,
        monitor_interval: float = 1.0,
    ) -> None:
        self.server = server
        self.tunnel = tunnel
        self.auth_token = auth_token
        self.ssh_public_key_path = ssh_public_key_path
        self.reconnect_initial_delay = reconnect_initial_delay
        self.reconnect_max_delay = reconnect_max_delay
        self.monitor_interval = monitor_interval
        self._stop_event = threading.Event()
        self._supervisor_thread: threading.Thread | None = None

    @classmethod
    def connect(
        cls,
        *,
        ssh_host: str,
        ssh_user: str | None = None,
        ssh_port: int = 22,
        remote_port: int | None = None,
        run_id: str | None = None,
        remote_bind_host: str = "127.0.0.1",
        local_host: str = "127.0.0.1",
        local_port: int | None = None,
        identity_file: str | None = None,
        auto_bootstrap_ssh_key: bool = True,
        strict_host_key_checking: bool = True,
        known_hosts_file: str | None = None,
        extra_ssh_args: tuple[str, ...] = (),
        auth_token: str | None = None,
        require_auth: bool = True,
        reconnect_initial_delay: float = 1.0,
        reconnect_max_delay: float = 30.0,
        monitor_interval: float = 1.0,
    ) -> TunnelledMetricService:
        if remote_port is None:
            remote_port = deterministic_port_for_run(run_id) if run_id else 9100
        resolved_identity_file = identity_file
        resolved_public_key_path = None
        if auto_bootstrap_ssh_key:
            if resolved_identity_file is None:
                resolved_identity_file = DEFAULT_IDENTITY_FILE
            resolved_identity_file, resolved_public_key_path = ensure_local_ssh_keypair(
                resolved_identity_file
            )
        resolved_auth_token = auth_token
        if require_auth and resolved_auth_token is None:
            resolved_auth_token = generate_auth_token()
        server = TrainingMetricServer(
            host=local_host,
            port=local_port or 0,
            run_id=run_id,
            auth_token=resolved_auth_token,
        )
        tunnel_config = ReverseTunnelConfig(
            ssh_host=ssh_host,
            ssh_user=ssh_user,
            ssh_port=ssh_port,
            remote_port=remote_port,
            remote_bind_host=remote_bind_host,
            local_host=local_host,
            local_port=local_port,
            identity_file=resolved_identity_file,
            strict_host_key_checking=strict_host_key_checking,
            known_hosts_file=known_hosts_file,
            extra_ssh_args=extra_ssh_args,
        )
        return cls(
            server=server,
            tunnel=SSHReverseTunnel(tunnel_config),
            auth_token=resolved_auth_token,
            ssh_public_key_path=resolved_public_key_path,
            reconnect_initial_delay=reconnect_initial_delay,
            reconnect_max_delay=reconnect_max_delay,
            monitor_interval=monitor_interval,
        )

    def __enter__(self) -> TunnelledMetricService:
        self.start()
        return self

    def __exit__(self, exc_type: object, exc: object, tb: object) -> None:
        self.stop()

    @property
    def remote_url(self) -> str:
        return f"http://{self.tunnel.config.remote_bind_host}:{self.tunnel.config.remote_port}"

    def logger(self) -> HTTPMetricLogger:
        return HTTPMetricLogger(
            self.server.base_url,
            run_id=self.server.run_id,
            auth_token=self.auth_token,
        )

    def start(self) -> None:
        if self._supervisor_thread is not None and self._supervisor_thread.is_alive():
            return
        self.server.start()
        if self.tunnel.config.local_port is None:
            self.tunnel.config.local_port = self.server.local_port
        self._stop_event.clear()
        try:
            self.tunnel.start()
        except Exception:
            self.server.stop()
            raise
        self._supervisor_thread = threading.Thread(
            target=self._supervise_tunnel,
            name="vertical-ssh-tunnel-supervisor",
            daemon=True,
        )
        self._supervisor_thread.start()

    def stop(self) -> None:
        self._stop_event.set()
        thread = self._supervisor_thread
        self._supervisor_thread = None
        if thread is not None:
            thread.join(timeout=2)
        self.tunnel.stop()
        self.server.stop()

    def log(
        self,
        *,
        step: int,
        epoch: int | None = None,
        loss: float | None = None,
        learning_rate: float | None = None,
        metrics: Mapping[str, float] | None = None,
        training_info: Mapping[str, Any] | None = None,
        status: str = "running",
    ) -> MetricEvent:
        return self.server.log(
            step=step,
            epoch=epoch,
            loss=loss,
            learning_rate=learning_rate,
            metrics=metrics,
            training_info=training_info,
            status=status,
        )

    def _supervise_tunnel(self) -> None:
        backoff = self.reconnect_initial_delay
        while not self._stop_event.wait(self.monitor_interval):
            if self.tunnel.is_running:
                backoff = self.reconnect_initial_delay
                continue
            try:
                self.tunnel.start()
                backoff = self.reconnect_initial_delay
            except TunnelError:
                if self._stop_event.wait(backoff):
                    return
                backoff = min(
                    self.reconnect_max_delay,
                    max(backoff * 2, self.reconnect_initial_delay),
                )


def deterministic_port_for_run(
    run_id: str,
    *,
    base_port: int = 20000,
    port_count: int = 20000,
) -> int:
    if not run_id:
        raise ValueError("run_id must be non-empty")
    if port_count <= 0:
        raise ValueError("port_count must be positive")
    upper = base_port + port_count - 1
    if base_port < 1 or upper > 65535:
        raise ValueError("base_port/port_count must define valid TCP ports")
    digest = hashlib.sha256(run_id.encode("utf-8")).digest()
    offset = int.from_bytes(digest[:4], "big") % port_count
    return base_port + offset


def generate_auth_token(length_bytes: int = 32) -> str:
    if length_bytes < 16:
        raise ValueError("length_bytes must be at least 16")
    return secrets.token_urlsafe(length_bytes)


def ensure_local_ssh_keypair(identity_file: str) -> tuple[str, str]:
    private_key = Path(identity_file).expanduser()
    public_key = Path(f"{private_key}.pub")
    if private_key.exists() and public_key.exists():
        return str(private_key), str(public_key)

    private_key.parent.mkdir(parents=True, exist_ok=True)
    os.chmod(private_key.parent, 0o700)
    command = [
        "ssh-keygen",
        "-t",
        "ed25519",
        "-f",
        str(private_key),
        "-N",
        "",
    ]
    process = subprocess.run(
        command,
        check=False,
        capture_output=True,
        text=True,
    )
    if process.returncode != 0:
        stderr = process.stderr.strip()
        message = stderr or "unknown ssh-keygen error"
        raise TunnelError(f"failed to generate ssh keypair: {message}")
    if not public_key.exists():
        raise TunnelError("ssh keypair generation succeeded but public key file is missing")

    os.chmod(private_key, 0o600)
    os.chmod(public_key, 0o644)
    return str(private_key), str(public_key)


def _coerce_optional_float(value: Any) -> float | None:
    if value is None:
        return None
    return float(value)


def _coerce_optional_int(value: Any) -> int | None:
    if value is None:
        return None
    return int(value)



def _normalize_training_info(values: Mapping[str, Any]) -> dict[str, Any]:
    normalized = {str(key): value for key, value in values.items()}
    try:
        json.dumps(normalized)
    except (TypeError, ValueError) as exc:
        raise ValueError("training_info must be JSON-serializable") from exc
    return normalized

def _parse_timestamp(value: Any) -> datetime:
    if value is None:
        return datetime.now(timezone.utc)
    if not isinstance(value, str):
        raise ValueError("timestamp must be an ISO8601 string")
    normalized = value.replace("Z", "+00:00")
    parsed = datetime.fromisoformat(normalized)
    if parsed.tzinfo is None:
        return parsed.replace(tzinfo=timezone.utc)
    return parsed.astimezone(timezone.utc)
