from __future__ import annotations

import os
import shlex
from collections.abc import Mapping
from dataclasses import dataclass, field
from numbers import Number
from typing import Any, Protocol

from .frameworks import (
    FlaxTrainingWrapper,
    FrameworkContext,
    JaxTrainingWrapper,
    PyTorchTrainingWrapper,
    get_adapter,
)

DefaultValue = float | int | str | None


class MetricSink(Protocol):
    def log(
        self,
        *,
        step: int,
        epoch: int | None = None,
        loss: float | None = None,
        learning_rate: float | None = None,
        metrics: Mapping[str, float] | None = None,
        status: str = "running",
    ) -> Any:
        ...


@dataclass
class TrainingRun:
    sink: MetricSink
    framework: FrameworkContext
    defaults: dict[str, DefaultValue] = field(default_factory=dict)
    remote_session: RemoteSession | None = None
    _service: Any | None = field(default=None, repr=False, compare=False)

    def track(
        self,
        *,
        step: int,
        loss: float | None = None,
        epoch: int | None = None,
        learning_rate: float | None = None,
        status: str = "running",
        metrics: Mapping[str, Number] | None = None,
        **metric_values: Number,
    ) -> Any:
        merged_metrics: dict[str, float] = {}
        if metrics:
            merged_metrics.update(_normalize_metrics(metrics))
        if metric_values:
            merged_metrics.update(_normalize_metrics(metric_values))

        return self.sink.log(
            step=step,
            epoch=_default_int(self.defaults.get("epoch")) if epoch is None else epoch,
            loss=loss,
            learning_rate=(
                _default_float(self.defaults.get("learning_rate"))
                if learning_rate is None
                else learning_rate
            ),
            metrics=merged_metrics,
            status=status,
        )

    def forward(
        self,
        *,
        loss: float | None,
        step: int | None = None,
        epoch: int | None = None,
        learning_rate: float | None = None,
        metrics: Mapping[str, Number] | None = None,
        training_info: Mapping[str, Any] | None = None,
        status: str = "forward",
        **metric_values: Number,
    ) -> Any:
        merged_metrics: dict[str, float] = {}
        if metrics:
            merged_metrics.update(_normalize_metrics(metrics))
        if metric_values:
            merged_metrics.update(_normalize_metrics(metric_values))

        if hasattr(self.sink, "log_forward"):
            return self.sink.log_forward(
                step=step,
                epoch=_default_int(self.defaults.get("epoch")) if epoch is None else epoch,
                loss=loss,
                learning_rate=(
                    _default_float(self.defaults.get("learning_rate"))
                    if learning_rate is None
                    else learning_rate
                ),
                metrics=merged_metrics,
                training_info=dict(training_info) if training_info else {},
            )

        if step is None:
            raise ValueError("step is required when sink does not implement log_forward")

        return self.track(
            step=step,
            epoch=epoch,
            loss=loss,
            learning_rate=learning_rate,
            status=status,
            metrics=merged_metrics,
        )

    @property
    def jax(self) -> JaxTrainingWrapper:
        if self.framework.name not in {"jax", "flax"}:
            raise RuntimeError("jax wrapper is only available for framework='jax' or 'flax'")
        return JaxTrainingWrapper(self)

    @property
    def flax(self) -> FlaxTrainingWrapper:
        if self.framework.name != "flax":
            raise RuntimeError("flax wrapper is only available for framework='flax'")
        return FlaxTrainingWrapper(self)

    @property
    def pytorch(self) -> PyTorchTrainingWrapper:
        if self.framework.name != "pytorch":
            raise RuntimeError("pytorch wrapper is only available for framework='pytorch'")
        return PyTorchTrainingWrapper(self)

    @property
    def torch(self) -> PyTorchTrainingWrapper:
        return self.pytorch

    @property
    def remote_url(self) -> str | None:
        if self.remote_session is None:
            return None
        return self.remote_session.remote_url

    @property
    def auth_token(self) -> str | None:
        if self.remote_session is None:
            return None
        return self.remote_session.auth_token

    def close(self) -> None:
        service = self._service
        self._service = None
        if service is not None:
            service.stop()

    def __enter__(self) -> TrainingRun:
        return self

    def __exit__(self, exc_type: object, exc: object, tb: object) -> None:
        self.close()


@dataclass(frozen=True)
class RemoteSession:
    remote_url: str
    auth_token: str | None
    run_id: str | None
    ssh_host: str
    ssh_user: str | None
    ssh_port: int
    remote_port: int
    identity_file: str | None
    public_key_path: str | None


def init(
    *,
    framework: str,
    logger: MetricSink | None = None,
    remote: Mapping[str, Any] | None = None,
    **defaults: DefaultValue,
) -> TrainingRun:
    adapter = get_adapter(framework)
    context = adapter.build_context(defaults)
    service = None
    remote_session = None
    remote_config = _resolve_remote_config(remote=remote, defaults=defaults)

    if remote_config is not None:
        if logger is not None:
            raise ValueError("logger cannot be set when remote tunnel config is enabled")
        service = _start_remote_service(remote_config, defaults)
        sink: MetricSink = service.logger()
        remote_session = RemoteSession(
            remote_url=service.remote_url,
            auth_token=service.auth_token,
            run_id=service.server.run_id,
            ssh_host=service.tunnel.config.ssh_host,
            ssh_user=service.tunnel.config.ssh_user,
            ssh_port=service.tunnel.config.ssh_port,
            remote_port=service.tunnel.config.remote_port,
            identity_file=service.tunnel.config.identity_file,
            public_key_path=service.ssh_public_key_path,
        )
    if logger is None:
        if remote_config is None:
            from .monitor import TrainingMonitor

            sink = TrainingMonitor(title=f"vertical::{context.name}")
    else:
        sink = logger
    return TrainingRun(
        sink=sink,
        framework=context,
        defaults=dict(defaults),
        remote_session=remote_session,
        _service=service,
    )


def _normalize_metrics(metrics: Mapping[str, Number]) -> dict[str, float]:
    normalized: dict[str, float] = {}
    for name, value in metrics.items():
        if isinstance(value, bool) or not isinstance(value, Number):
            raise TypeError(f"metric '{name}' must be numeric")
        normalized[str(name)] = float(value)
    return normalized


def _default_int(value: float | int | str | None) -> int | None:
    return value if isinstance(value, int) else None


def _default_float(value: float | int | str | None) -> float | None:
    return float(value) if isinstance(value, (int, float)) else None


def _start_remote_service(
    remote_config: Mapping[str, Any],
    defaults: Mapping[str, DefaultValue],
) -> Any:
    from .remote import TunnelledMetricService

    config = dict(remote_config)
    default_run_id = defaults.get("run_id")
    if "run_id" not in config and isinstance(default_run_id, str) and default_run_id:
        config["run_id"] = default_run_id
    service = TunnelledMetricService.connect(**config)
    service.start()
    return service


def _resolve_remote_config(
    *,
    remote: Mapping[str, Any] | None,
    defaults: Mapping[str, DefaultValue],
) -> dict[str, Any] | None:
    if remote is not None:
        return dict(remote)
    return _remote_config_from_env(defaults=defaults)


def _remote_config_from_env(*, defaults: Mapping[str, DefaultValue]) -> dict[str, Any] | None:
    ssh_host = os.getenv("VERTICAL_SSH_HOST")
    if not ssh_host:
        return None

    config: dict[str, Any] = {"ssh_host": ssh_host}
    _set_if_env(config, "ssh_user", "VERTICAL_SSH_USER")
    _set_if_env(config, "identity_file", "VERTICAL_SSH_IDENTITY_FILE")
    _set_if_env(config, "known_hosts_file", "VERTICAL_KNOWN_HOSTS_FILE")
    _set_if_env(config, "remote_bind_host", "VERTICAL_REMOTE_BIND_HOST")
    _set_if_env(config, "local_host", "VERTICAL_LOCAL_HOST")
    _set_if_env(config, "auth_token", "VERTICAL_AUTH_TOKEN")

    ssh_port = os.getenv("VERTICAL_SSH_PORT")
    if ssh_port:
        config["ssh_port"] = _parse_env_int("VERTICAL_SSH_PORT", ssh_port)
    remote_port = os.getenv("VERTICAL_REMOTE_PORT")
    if remote_port:
        config["remote_port"] = _parse_env_int("VERTICAL_REMOTE_PORT", remote_port)
    local_port = os.getenv("VERTICAL_LOCAL_PORT")
    if local_port:
        config["local_port"] = _parse_env_int("VERTICAL_LOCAL_PORT", local_port)

    strict_host_key_checking = os.getenv("VERTICAL_STRICT_HOST_KEY_CHECKING")
    if strict_host_key_checking:
        config["strict_host_key_checking"] = _parse_env_bool(
            "VERTICAL_STRICT_HOST_KEY_CHECKING",
            strict_host_key_checking,
        )
    auto_ssh_keygen = os.getenv("VERTICAL_AUTO_SSH_KEYGEN")
    if auto_ssh_keygen:
        config["auto_bootstrap_ssh_key"] = _parse_env_bool(
            "VERTICAL_AUTO_SSH_KEYGEN",
            auto_ssh_keygen,
        )
    require_auth = os.getenv("VERTICAL_REQUIRE_AUTH")
    if require_auth:
        config["require_auth"] = _parse_env_bool("VERTICAL_REQUIRE_AUTH", require_auth)

    extra_ssh_args = os.getenv("VERTICAL_EXTRA_SSH_ARGS")
    if extra_ssh_args:
        config["extra_ssh_args"] = tuple(shlex.split(extra_ssh_args))

    run_id = os.getenv("VERTICAL_RUN_ID")
    if run_id:
        config["run_id"] = run_id
    else:
        default_run_id = defaults.get("run_id")
        if isinstance(default_run_id, str) and default_run_id:
            config["run_id"] = default_run_id
    return config


def _set_if_env(config: dict[str, Any], key: str, env_name: str) -> None:
    value = os.getenv(env_name)
    if value:
        config[key] = value


def _parse_env_int(name: str, value: str) -> int:
    try:
        return int(value)
    except ValueError as exc:
        raise ValueError(f"{name} must be an integer") from exc


def _parse_env_bool(name: str, value: str) -> bool:
    normalized = value.strip().lower()
    if normalized in {"1", "true", "yes", "on"}:
        return True
    if normalized in {"0", "false", "no", "off"}:
        return False
    raise ValueError(f"{name} must be a boolean value")
