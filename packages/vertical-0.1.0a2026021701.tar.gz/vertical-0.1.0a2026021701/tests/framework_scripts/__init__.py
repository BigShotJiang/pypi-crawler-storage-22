# Framework compatibility training scripts used by tests.
