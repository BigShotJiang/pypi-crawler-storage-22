from __future__ import annotations

from collections.abc import Sequence


def run_training(logger: object, *, steps: int = 8) -> Sequence[float]:
    import jax
    import jax.numpy as jnp

    x = jnp.linspace(-1.0, 1.0, 128).reshape((-1, 1))
    y = (1.5 * x) + 0.7

    params = {"w": jnp.array([[0.0]]), "b": jnp.array([0.0])}
    learning_rate = 0.2

    def loss_fn(model_params: dict[str, jnp.ndarray]) -> jnp.ndarray:
        pred = x @ model_params["w"] + model_params["b"]
        return jnp.mean((pred - y) ** 2)

    grad_fn = jax.grad(loss_fn)

    losses: list[float] = []
    for step in range(1, steps + 1):
        grads = grad_fn(params)
        params = {
            "w": params["w"] - learning_rate * grads["w"],
            "b": params["b"] - learning_rate * grads["b"],
        }
        loss_value = float(loss_fn(params))
        losses.append(loss_value)
        logger.log(
            step=step,
            epoch=1,
            loss=loss_value,
            learning_rate=learning_rate,
            metrics={"mse": loss_value},
            status="running",
        )
    return losses
