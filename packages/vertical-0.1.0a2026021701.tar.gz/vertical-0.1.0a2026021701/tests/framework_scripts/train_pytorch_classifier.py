from __future__ import annotations

from collections.abc import Sequence


def run_training(logger: object, *, steps: int = 8) -> Sequence[float]:
    import torch

    torch.manual_seed(13)
    x = torch.linspace(-2.0, 2.0, 128).unsqueeze(1)
    y = (x > 0).float()

    model = torch.nn.Sequential(torch.nn.Linear(1, 8), torch.nn.Tanh(), torch.nn.Linear(8, 1))
    optimizer = torch.optim.Adam(model.parameters(), lr=0.05)
    criterion = torch.nn.BCEWithLogitsLoss()

    losses: list[float] = []
    for step in range(1, steps + 1):
        optimizer.zero_grad()
        logits = model(x)
        loss = criterion(logits, y)
        loss.backward()
        optimizer.step()

        probs = torch.sigmoid(logits)
        accuracy = float(((probs > 0.5) == y.bool()).float().mean().item())
        loss_value = float(loss.item())
        losses.append(loss_value)
        logger.log(
            step=step,
            epoch=1,
            loss=loss_value,
            learning_rate=0.05,
            metrics={"accuracy": accuracy},
            status="running",
        )
    return losses
