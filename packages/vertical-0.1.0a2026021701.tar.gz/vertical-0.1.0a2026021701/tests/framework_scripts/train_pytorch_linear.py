from __future__ import annotations

from collections.abc import Sequence


def run_training(logger: object, *, steps: int = 8) -> Sequence[float]:
    import torch

    torch.manual_seed(7)
    x = torch.linspace(-1.0, 1.0, 128).unsqueeze(1)
    y = (2.0 * x) + 0.5

    model = torch.nn.Linear(1, 1)
    optimizer = torch.optim.SGD(model.parameters(), lr=0.1)
    criterion = torch.nn.MSELoss()

    losses: list[float] = []
    for step in range(1, steps + 1):
        optimizer.zero_grad()
        pred = model(x)
        loss = criterion(pred, y)
        loss.backward()
        optimizer.step()

        loss_value = float(loss.item())
        losses.append(loss_value)
        logger.log(
            step=step,
            epoch=1,
            loss=loss_value,
            learning_rate=0.1,
            metrics={"mse": loss_value},
            status="running",
        )
    return losses
