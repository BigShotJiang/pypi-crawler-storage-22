from __future__ import annotations

from collections.abc import Sequence


def run_training(logger: object, *, steps: int = 8) -> Sequence[float]:
    import tensorflow as tf

    tf.random.set_seed(11)
    x = tf.reshape(tf.linspace(-1.0, 1.0, 128), (-1, 1))
    y = (3.0 * x) - 0.2

    w = tf.Variable(tf.random.normal((1, 1)))
    b = tf.Variable(tf.zeros((1,)))
    optimizer = tf.keras.optimizers.SGD(learning_rate=0.1)

    losses: list[float] = []
    for step in range(1, steps + 1):
        with tf.GradientTape() as tape:
            pred = tf.matmul(x, w) + b
            loss = tf.reduce_mean(tf.square(pred - y))
        gradients = tape.gradient(loss, [w, b])
        optimizer.apply_gradients(zip(gradients, [w, b], strict=False))

        loss_value = float(loss.numpy())
        losses.append(loss_value)
        logger.log(
            step=step,
            epoch=1,
            loss=loss_value,
            learning_rate=0.1,
            metrics={"mse": loss_value},
            status="running",
        )
    return losses
