from __future__ import annotations

import pytest

from vertical import HTTPMetricLogger, MetricClientError, TrainingMetricServer


def test_http_metric_logger_posts_to_server() -> None:
    server = TrainingMetricServer()
    server.start()
    try:
        logger = HTTPMetricLogger(server.base_url, run_id="run-logger")
        logger.log(step=1, loss=0.75, metrics={"acc": 0.3})
        logger.log(step=2, loss=0.55, metrics={"acc": 0.6}, status="done")
        events = server.history()
    finally:
        server.stop()

    assert len(events) == 2
    assert events[-1].status == "done"
    assert events[-1].metrics["acc"] == 0.6
    assert events[-1].run_id == "run-logger"


def test_http_metric_logger_forward_posts_training_json() -> None:
    server = TrainingMetricServer()
    server.start()
    try:
        logger = HTTPMetricLogger(server.base_url, run_id="run-forward")
        logger.log_forward(
            loss=0.33,
            learning_rate=0.001,
            metrics={"perplexity": 12.0},
            training_info={"framework": "pytorch", "stage": "train"},
        )
        event = server.latest()
    finally:
        server.stop()

    assert event is not None
    assert event.status == "forward"
    assert event.loss == 0.33
    assert event.metrics["perplexity"] == 12.0
    assert event.metrics["forward_call"] == 1.0
    assert event.training_info["framework"] == "pytorch"
    assert event.training_info["event"] == "forward"


def test_http_metric_logger_supports_auth_token() -> None:
    server = TrainingMetricServer(auth_token="secret-token")
    server.start()
    try:
        without_token = HTTPMetricLogger(server.base_url, run_id="run-auth")
        with pytest.raises(MetricClientError):
            without_token.log(step=1, loss=1.0)

        with_token = HTTPMetricLogger(
            server.base_url,
            run_id="run-auth",
            auth_token="secret-token",
        )
        with_token.log(step=2, loss=0.5)
        events = server.history()
    finally:
        server.stop()

    assert len(events) == 1
    assert events[0].step == 2
