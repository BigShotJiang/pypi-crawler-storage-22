from __future__ import annotations

import importlib
import importlib.util
import math
from pathlib import Path
from types import ModuleType

import pytest

from vertical import HTTPMetricLogger, TrainingMetricServer

FRAMEWORK_CASES = [
    ("train_pytorch_linear", "torch"),
    ("train_pytorch_classifier", "torch"),
    ("train_tensorflow_linear", "tensorflow"),
    ("train_jax_linear", "jax"),
]


@pytest.mark.parametrize(("module_name", "framework_module"), FRAMEWORK_CASES)
def test_framework_script_logs_into_loss_server(
    module_name: str,
    framework_module: str,
) -> None:
    pytest.importorskip(framework_module)
    script = _load_script_module(module_name)

    server = TrainingMetricServer()
    server.start()
    try:
        logger = HTTPMetricLogger(server.base_url)
        losses = list(script.run_training(logger, steps=4))
        events = server.history()
    finally:
        server.stop()

    assert len(losses) == 4
    assert len(events) == 4
    assert [event.step for event in events] == [1, 2, 3, 4]
    assert all(math.isfinite(value) for value in losses)
    assert events[-1].loss is not None
    assert math.isclose(float(events[-1].loss), float(losses[-1]), rel_tol=1e-7)


def _load_script_module(module_name: str) -> ModuleType:
    script_path = Path(__file__).parent / "framework_scripts" / f"{module_name}.py"
    spec = importlib.util.spec_from_file_location(
        f"framework_script_{module_name}",
        script_path,
    )
    if spec is None or spec.loader is None:
        raise RuntimeError(f"unable to load framework script: {script_path}")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module
