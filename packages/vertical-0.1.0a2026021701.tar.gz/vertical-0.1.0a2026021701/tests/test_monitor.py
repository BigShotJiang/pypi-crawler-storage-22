import pytest

pytest.importorskip("rich")

from vertical.monitor import TrainingMonitor


def test_log_stores_latest_snapshot() -> None:
    monitor = TrainingMonitor(history_size=2)
    first = monitor.log(step=1, loss=1.2, learning_rate=1e-3)
    second = monitor.log(step=2, loss=0.8, learning_rate=9e-4, metrics={"acc": 0.42})

    assert first.step == 1
    assert second.step == 2
    assert monitor.latest is second
    assert len(monitor.history) == 2
    assert monitor.history[-1].metrics["acc"] == 0.42


def test_history_honors_max_size() -> None:
    monitor = TrainingMonitor(history_size=2)
    monitor.log(step=1, loss=1.0)
    monitor.log(step=2, loss=0.9)
    monitor.log(step=3, loss=0.8)

    assert [item.step for item in monitor.history] == [2, 3]
