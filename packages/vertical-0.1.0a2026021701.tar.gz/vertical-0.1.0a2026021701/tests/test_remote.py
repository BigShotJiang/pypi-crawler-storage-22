from __future__ import annotations

import io
import json
import time
from urllib import error, request

import pytest

import vertical.remote as remote
from vertical.remote import (
    ReverseTunnelConfig,
    SSHReverseTunnel,
    TrainingMetricServer,
    TunnelledMetricService,
    deterministic_port_for_run,
)


def test_reverse_tunnel_build_command() -> None:
    config = ReverseTunnelConfig(
        ssh_host="terminal.example.com",
        ssh_user="alice",
        ssh_port=2222,
        remote_port=9100,
        remote_bind_host="127.0.0.1",
        local_host="127.0.0.1",
        local_port=8000,
        identity_file="/tmp/id_ed25519",
        strict_host_key_checking=False,
        known_hosts_file="/tmp/known_hosts",
        extra_ssh_args=("-v",),
    )
    tunnel = SSHReverseTunnel(config)

    command = tunnel.build_command()

    assert command[:3] == ["ssh", "-N", "-T"]
    assert "-R" in command
    assert "127.0.0.1:9100:127.0.0.1:8000" in command
    assert "alice@terminal.example.com" in command
    assert "BatchMode=yes" in command
    assert "PasswordAuthentication=no" in command
    assert "StrictHostKeyChecking=no" in command
    assert "/tmp/id_ed25519" in command


def test_metric_server_http_endpoints() -> None:
    server = TrainingMetricServer(run_id="run-abc")
    server.start()
    try:
        server.log(step=1, loss=0.95, metrics={"acc": 0.1})

        with request.urlopen(f"{server.base_url}/health") as response:
            payload = json.loads(response.read())
            assert response.status == 200
            assert payload["status"] == "ok"

        with request.urlopen(f"{server.base_url}/metrics") as response:
            payload = json.loads(response.read())
            assert payload["step"] == 1
            assert payload["run_id"] == "run-abc"

        with request.urlopen(f"{server.base_url}/metrics/latest") as response:
            payload = json.loads(response.read())
            assert payload["event"]["step"] == 1
            assert payload["event"]["metrics"]["acc"] == 0.1

        body = json.dumps(
            {
                "step": 2,
                "loss": 0.82,
                "metrics": {"acc": 0.25},
                "training_info": {"framework": "jax"},
            }
        ).encode("utf-8")
        req = request.Request(
            f"{server.base_url}/metrics",
            data=body,
            method="POST",
            headers={"Content-Type": "application/json"},
        )
        with request.urlopen(req) as response:
            payload = json.loads(response.read())
            assert response.status == 201
            assert payload["event"]["step"] == 2
            assert payload["event"]["run_id"] == "run-abc"
            assert payload["event"]["training_info"]["framework"] == "jax"

        with request.urlopen(f"{server.base_url}/metrics/history?limit=1") as response:
            payload = json.loads(response.read())
            assert len(payload["events"]) == 1
            assert payload["events"][0]["step"] == 2
    finally:
        server.stop()


def test_tunnelled_service_resolves_local_port_before_ssh(monkeypatch) -> None:
    captured: dict[str, list[str]] = {}

    class FakeProcess:
        def __init__(self, command: list[str]) -> None:
            self.command = command
            self.stderr = io.StringIO("")
            self._running = True

        def poll(self) -> int | None:
            return None if self._running else 0

        def terminate(self) -> None:
            self._running = False

        def wait(self, timeout: float | None = None) -> int:
            return 0

        def kill(self) -> None:
            self._running = False

    def fake_popen(command: list[str], **_: object) -> FakeProcess:
        captured["command"] = command
        return FakeProcess(command)

    monkeypatch.setattr(remote.subprocess, "Popen", fake_popen)
    monkeypatch.setattr(remote.time, "sleep", lambda _seconds: None)

    service = TunnelledMetricService.connect(ssh_host="terminal.example.com", remote_port=9333)
    service.start()
    try:
        assert service.tunnel.config.local_port == service.server.local_port
        assert captured["command"][0] == "ssh"
        assert "127.0.0.1:9333:127.0.0.1" in " ".join(captured["command"])
        service.logger().log(step=1, loss=0.5, metrics={"acc": 0.25})
        assert len(service.server.history()) == 1
    finally:
        service.stop()


def test_tunnelled_service_reconnects_when_tunnel_drops(monkeypatch) -> None:
    processes: list[FakeProcess] = []

    class FakeProcess:
        def __init__(self, command: list[str]) -> None:
            self.command = command
            self.stderr = io.StringIO("")
            self._running = True

        def poll(self) -> int | None:
            return None if self._running else 255

        def terminate(self) -> None:
            self._running = False

        def wait(self, timeout: float | None = None) -> int:
            return 0

        def kill(self) -> None:
            self._running = False

    def fake_popen(command: list[str], **_: object) -> FakeProcess:
        process = FakeProcess(command)
        processes.append(process)
        return process

    monkeypatch.setattr(remote.subprocess, "Popen", fake_popen)

    service = TunnelledMetricService.connect(
        ssh_host="terminal.example.com",
        remote_port=9333,
        reconnect_initial_delay=0.05,
        reconnect_max_delay=0.1,
        monitor_interval=0.05,
    )
    service.start()
    try:
        assert len(processes) == 1
        processes[0]._running = False

        deadline = time.monotonic() + 1.5
        while len(processes) < 2 and time.monotonic() < deadline:
            time.sleep(0.02)

        assert len(processes) >= 2
    finally:
        service.stop()


def test_deterministic_port_for_run_is_stable() -> None:
    first = deterministic_port_for_run("run-42")
    second = deterministic_port_for_run("run-42")
    other = deterministic_port_for_run("run-43")

    assert first == second
    assert first != other
    assert 1 <= first <= 65535


def test_connect_uses_deterministic_port_when_run_id_given() -> None:
    service = TunnelledMetricService.connect(ssh_host="terminal.example.com", run_id="run-42")

    assert service.server.run_id == "run-42"
    assert service.tunnel.config.remote_port == deterministic_port_for_run("run-42")


def test_metric_server_auth_token_protects_endpoints() -> None:
    server = TrainingMetricServer(auth_token="secret-token")
    server.start()
    try:
        with pytest.raises(error.HTTPError) as excinfo:
            request.urlopen(f"{server.base_url}/health")
        assert excinfo.value.code == 401

        req = request.Request(
            f"{server.base_url}/health",
            headers={"Authorization": "Bearer secret-token"},
        )
        with request.urlopen(req) as response:
            payload = json.loads(response.read())
            assert response.status == 200
            assert payload["status"] == "ok"
    finally:
        server.stop()
