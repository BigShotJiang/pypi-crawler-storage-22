from __future__ import annotations

from collections.abc import Mapping
from typing import Any

import pytest

import vertical.frameworks.flax as flax_framework
import vertical.frameworks.jax as jax_framework
import vertical.frameworks.pytorch as pytorch_framework
import vertical.tracker as tracker


class FakeSink:
    def __init__(self) -> None:
        self.calls: list[dict[str, Any]] = []

    def log(self, **kwargs: Any) -> dict[str, Any]:
        self.calls.append(kwargs)
        return kwargs


class FakeForwardSink(FakeSink):
    def __init__(self) -> None:
        super().__init__()
        self.forward_calls: list[dict[str, Any]] = []

    def log_forward(self, **kwargs: Any) -> dict[str, Any]:
        self.forward_calls.append(kwargs)
        return kwargs


class _FakeTorchModule:
    class cuda:  # noqa: N801
        @staticmethod
        def is_available() -> bool:
            return False


class _FakeJaxDevice:
    platform = "cpu"

    def __str__(self) -> str:
        return "TFRT_CPU_0"


class _FakeJaxModule:
    @staticmethod
    def devices(_backend: str | None = None) -> list[_FakeJaxDevice]:
        return [_FakeJaxDevice()]

    @staticmethod
    def device_get(value: Any) -> Any:
        return value


class _FakeFlaxModule:
    pass


class _FakeTrainState:
    def __init__(self, step: int) -> None:
        self.step = step


class _FakeTunnelConfig:
    ssh_host = "terminal.example.com"
    ssh_user = "alice"
    ssh_port = 22
    remote_port = 9100


class _FakeTunnel:
    config = _FakeTunnelConfig()


class _FakeServer:
    run_id = "run-123"


class _FakeRemoteService:
    def __init__(self, sink: FakeSink) -> None:
        self._sink = sink
        self.remote_url = "http://127.0.0.1:9100"
        self.auth_token = "secret-token"
        self.server = _FakeServer()
        self.tunnel = _FakeTunnel()
        self.stop_calls = 0

    def logger(self) -> FakeSink:
        return self._sink

    def stop(self) -> None:
        self.stop_calls += 1


def test_init_uses_only_selected_framework(monkeypatch: pytest.MonkeyPatch) -> None:
    imported: list[str] = []

    def fake_import(name: str) -> Any:
        imported.append(name)
        if name == "torch":
            return _FakeTorchModule()
        raise AssertionError(f"unexpected import: {name}")

    monkeypatch.setattr(pytorch_framework.importlib, "import_module", fake_import)

    run = tracker.init(framework="pytorch", logger=FakeSink())

    assert run.framework.name == "pytorch"
    assert imported == ["torch"]


def test_init_flax_resolves_jax_and_flax(monkeypatch: pytest.MonkeyPatch) -> None:
    imported: list[str] = []

    def fake_import(name: str) -> Any:
        imported.append(name)
        if name == "flax":
            return _FakeFlaxModule()
        if name == "jax":
            return _FakeJaxModule()
        raise AssertionError(f"unexpected import: {name}")

    monkeypatch.setattr(flax_framework.importlib, "import_module", fake_import)

    run = tracker.init(framework="flax", logger=FakeSink(), backend="cpu")

    assert run.framework.name == "flax"
    assert run.framework.extras["platform"] == "cpu"
    assert imported == ["flax", "jax"]


def test_track_merges_defaults_and_custom_metrics(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setattr(jax_framework.importlib, "import_module", lambda _name: _FakeJaxModule())
    sink = FakeSink()

    run = tracker.init(framework="jax", logger=sink, learning_rate=0.002, epoch=3)
    event = run.track(step=8, loss=0.42, perplexity=12.5, metrics={"accuracy": 0.9})

    assert event["step"] == 8
    assert event["epoch"] == 3
    assert event["learning_rate"] == 0.002
    assert event["metrics"] == {"accuracy": 0.9, "perplexity": 12.5}


def test_track_rejects_non_numeric_metrics(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setattr(jax_framework.importlib, "import_module", lambda _name: _FakeJaxModule())
    run = tracker.init(framework="jax", logger=FakeSink())

    with pytest.raises(TypeError):
        run.track(step=1, metrics={"note": "bad"})


def test_forward_uses_forward_json_path(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setattr(jax_framework.importlib, "import_module", lambda _name: _FakeJaxModule())
    sink = FakeForwardSink()

    run = tracker.init(framework="jax", logger=sink, learning_rate=0.01, epoch=2)
    payload = run.forward(
        loss=0.9,
        perplexity=15.0,
        training_info={"framework": "jax", "phase": "train"},
    )

    assert payload["metrics"]["perplexity"] == 15.0
    assert payload["training_info"]["framework"] == "jax"
    assert payload["learning_rate"] == 0.01
    assert payload["epoch"] == 2


def test_jax_wrapper_normalizes_metrics(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setattr(jax_framework.importlib, "import_module", lambda _name: _FakeJaxModule())
    sink = FakeForwardSink()

    run = tracker.init(framework="jax", logger=sink)
    payload = run.jax.forward(loss=1.1, metrics={"perplexity": 10}, grad_norm=2)

    assert payload["metrics"] == {"perplexity": 10.0, "grad_norm": 2.0}
    assert payload["training_info"]["framework"] == "jax"
    assert payload["training_info"]["platform"] == "cpu"


def test_flax_wrapper_supports_train_state_step(monkeypatch: pytest.MonkeyPatch) -> None:
    def fake_import(name: str) -> Any:
        if name == "flax":
            return _FakeFlaxModule()
        if name == "jax":
            return _FakeJaxModule()
        raise AssertionError(f"unexpected import: {name}")

    monkeypatch.setattr(flax_framework.importlib, "import_module", fake_import)
    sink = FakeForwardSink()

    run = tracker.init(framework="flax", logger=sink)
    payload = run.flax.train_state_step(
        state=_FakeTrainState(step=12),
        loss=0.5,
        metrics={"perplexity": 7},
        grad_norm=1.5,
    )

    assert payload["step"] == 12
    assert payload["metrics"] == {"perplexity": 7.0, "grad_norm": 1.5}
    assert payload["training_info"]["framework"] == "flax"
    assert payload["training_info"]["state"] == "_FakeTrainState"


def test_init_starts_remote_service_when_remote_config_is_provided(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setattr(jax_framework.importlib, "import_module", lambda _name: _FakeJaxModule())
    sink = FakeSink()
    fake_service = _FakeRemoteService(sink)
    captured: dict[str, Any] = {}

    def fake_start_remote_service(
        remote_config: Mapping[str, Any],
        defaults: Mapping[str, Any],
    ) -> Any:
        captured["remote"] = dict(remote_config)
        captured["defaults"] = dict(defaults)
        return fake_service

    monkeypatch.setattr(tracker, "_start_remote_service", fake_start_remote_service)

    run = tracker.init(
        framework="jax",
        remote={"ssh_host": "terminal.example.com"},
        run_id="run-123",
    )

    assert captured["remote"]["ssh_host"] == "terminal.example.com"
    assert captured["defaults"]["run_id"] == "run-123"
    assert run.sink is sink
    assert run.remote_url == "http://127.0.0.1:9100"
    assert run.auth_token == "secret-token"
    assert run.remote_session is not None
    assert run.remote_session.run_id == "run-123"

    run.close()
    assert fake_service.stop_calls == 1


def test_init_uses_environment_for_remote_config(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setattr(jax_framework.importlib, "import_module", lambda _name: _FakeJaxModule())
    monkeypatch.setenv("VERTICAL_SSH_HOST", "colab.example.com")
    monkeypatch.setenv("VERTICAL_SSH_PORT", "2222")
    monkeypatch.setenv("VERTICAL_EXTRA_SSH_ARGS", "-v -F /tmp/ssh_config")

    sink = FakeSink()
    fake_service = _FakeRemoteService(sink)
    captured: dict[str, Any] = {}

    def fake_start_remote_service(
        remote_config: Mapping[str, Any],
        defaults: Mapping[str, Any],
    ) -> Any:
        captured["remote"] = dict(remote_config)
        captured["defaults"] = dict(defaults)
        return fake_service

    monkeypatch.setattr(tracker, "_start_remote_service", fake_start_remote_service)

    run = tracker.init(framework="jax")

    assert captured["remote"]["ssh_host"] == "colab.example.com"
    assert captured["remote"]["ssh_port"] == 2222
    assert captured["remote"]["extra_ssh_args"] == ("-v", "-F", "/tmp/ssh_config")
    run.close()


def test_init_rejects_logger_when_remote_enabled(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setattr(jax_framework.importlib, "import_module", lambda _name: _FakeJaxModule())

    with pytest.raises(ValueError):
        tracker.init(
            framework="jax",
            logger=FakeSink(),
            remote={"ssh_host": "terminal.example.com"},
        )
