import pytest

pytest.importorskip("rich")

from tui.viewer import MetricEndpointClient, _build_loss_trend
from vertical import TrainingMetricServer


def test_metric_endpoint_client_fetches_latest_and_history() -> None:
    server = TrainingMetricServer()
    server.start()
    try:
        server.log(step=1, loss=1.2, metrics={"acc": 0.1})
        server.log(step=2, loss=0.9, metrics={"acc": 0.2})
        client = MetricEndpointClient(server.base_url)

        latest = client.latest()
        history = client.history(limit=10)
    finally:
        server.stop()

    assert latest is not None
    assert int(latest["step"]) == 2
    assert len(history) == 2
    assert int(history[0]["step"]) == 1
    assert int(history[1]["step"]) == 2


def test_build_loss_trend_generates_ascii_series() -> None:
    history = [
        {"step": 1, "loss": 1.0},
        {"step": 2, "loss": 0.7},
        {"step": 3, "loss": 0.4},
        {"step": 4, "loss": 0.3},
    ]
    trend = _build_loss_trend(history)

    assert isinstance(trend, str)
    assert len(trend) == len(history)
    assert trend != "-"


def test_metric_endpoint_client_supports_auth_token() -> None:
    server = TrainingMetricServer(auth_token="secret-token")
    server.start()
    try:
        server.log(step=1, loss=1.2, metrics={"acc": 0.1})
        unauthorized = MetricEndpointClient(server.base_url)
        with pytest.raises(RuntimeError):
            unauthorized.latest()

        authorized = MetricEndpointClient(server.base_url, auth_token="secret-token")
        latest = authorized.latest()
    finally:
        server.stop()

    assert latest is not None
    assert int(latest["step"]) == 1
