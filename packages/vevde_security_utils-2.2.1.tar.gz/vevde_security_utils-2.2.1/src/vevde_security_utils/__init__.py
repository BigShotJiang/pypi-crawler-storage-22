name = 'vevde_security_utils'
version = '2.2.1'
