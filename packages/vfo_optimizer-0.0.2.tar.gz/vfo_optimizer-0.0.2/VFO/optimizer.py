import numpy as np
import math
import tensorflow as tf

class VFO:
    """
    Van Fish Optimization (VFO) algorithm implementation with TensorFlow.
    
    Based on Van Fish Optimization (VFO) context:
    - Biological Inspiration: Migration behavior of Van Fish (Alburnus tarichi).
    - Features: Directional search (current resistance), local minimum escape (obstacle jumping),
      swarm leadership, and target-oriented movement.
    - Optimized with TensorFlow for vectorized operations.
    """
    
    def __init__(self, objective_func, bounds, num_agents=30, max_iter=100, dimension=2, 
                 stagnation_threshold=5, verbose=False, use_gpu=False, seed=None):
        """
        Initialize VFO algorithm with TensorFlow backend.
        
        Args:
            objective_func (callable): The objective function to minimize.
            bounds (list of tuples or array): The bounds for variables [(min, max), ...].
            num_agents (int): Population size (N).
            max_iter (int): Maximum number of iterations.
            dimension (int): Dimension of the problem (d).
            stagnation_threshold (int): Variance threshold to trigger Levy flight jumps.
            verbose (bool): Whether to print progress at each iteration.
            use_gpu (bool): Whether to use GPU acceleration (if available).
            seed (int, optional): Random seed for reproducibility. If None, uses random initialization.
        """
        self.objective_func = objective_func
        self.dim = dimension
        self.n = num_agents
        self.max_iter = max_iter
        self.stagnation_threshold = stagnation_threshold
        self.verbose = verbose
        
        # Set random seed for reproducibility
        if seed is not None:
            tf.random.set_seed(seed)
            np.random.seed(seed)
        
        # Set device strategy
        if use_gpu and len(tf.config.list_physical_devices('GPU')) > 0:
            self.device = '/GPU:0'
        else:
            self.device = '/CPU:0'

        # Convert bounds to tensors
        bounds = np.array(bounds)
        if bounds.shape == (dimension, 2):
            self.lb = tf.constant(bounds[:, 0], dtype=tf.float32)
            self.ub = tf.constant(bounds[:, 1], dtype=tf.float32)
        else:
            if len(bounds) == 2 and bounds.ndim == 1:
                self.lb = tf.constant([bounds[0]] * dimension, dtype=tf.float32)
                self.ub = tf.constant([bounds[1]] * dimension, dtype=tf.float32)
            else:
                self.lb = tf.constant(bounds[:, 0], dtype=tf.float32)
                self.ub = tf.constant(bounds[:, 1], dtype=tf.float32)

    def _levy_flight(self, beta=1.5, n_samples=1):
        """
        Generates Levy flight steps using Mantegna's algorithm (TensorFlow version).
        
        Args:
            beta (float): Levy exponent parameter.
            n_samples (int): Number of samples to generate.
            
        Returns:
            TensorFlow tensor of Levy flight steps.
        """
        sigma_u = (math.gamma(1 + beta) * math.sin(math.pi * beta / 2) / 
                   (math.gamma((1 + beta) / 2) * beta * 2 ** ((beta - 1) / 2))) ** (1 / beta)
        sigma_v = 1.0

        u = tf.random.normal([n_samples, self.dim], mean=0.0, stddev=sigma_u)
        v = tf.random.normal([n_samples, self.dim], mean=0.0, stddev=sigma_v)

        step = u / (tf.abs(v) ** (1 / beta))
        return step

    def _evaluate_population(self, X):
        """
        Vectorized fitness evaluation for the entire population.
        Uses tf.map_fn to apply objective function to each agent in parallel.
        """
        def eval_single(x):
            result = tf.py_function(self.objective_func, [x], tf.float32)
            result.set_shape([])  # Scalar output
            return result
        
        return tf.map_fn(eval_single, X, parallel_iterations=10, dtype=tf.float32)

    def optimize(self):
        """
        Execute the optimization process using fully vectorized TensorFlow operations.

        Returns:
            X_best (numpy array): Best position found.
            f_best (float): Best fitness value found.
            history (list): Convergence history.
        """
        with tf.device(self.device):
            # 1. Initialize population X_i within bounds (vectorized)
            X = tf.random.uniform([self.n, self.dim], 
                                 minval=self.lb, 
                                 maxval=self.ub, 
                                 dtype=tf.float32)
            X = tf.Variable(X)

            # 2. Calculate fitness for all agents (vectorized)
            fitness = self._evaluate_population(X)
            fitness = tf.Variable(fitness)

            # 3. Find initial best
            best_idx = tf.argmin(fitness)
            X_best = tf.Variable(X[best_idx])
            f_best = tf.Variable(fitness[best_idx])

            # Initialize stagnation counters and energy
            stagnation_counter = tf.Variable(tf.zeros(self.n, dtype=tf.int32))
            E = tf.Variable(tf.fill([self.n], 100.0))
            
            C = 1.0  # Cost per step
            G = 5.0  # Gain per improvement

            history = []

            # Main iteration loop
            for t in range(1, self.max_iter + 1):
                # Update adaptive parameters (scalar values, computed once per iteration)
                A = 2.0 * (1.0 - t / self.max_iter)
                B = 1.0 - 0.9 * t / self.max_iter

                # Vectorized position update for all agents simultaneously
                # Generate random perturbations for all agents at once
                R = tf.random.normal([self.n, self.dim])
                
                # Broadcast X_best to match population shape and compute new positions
                # X_new = X + A*(X_best - X) + B*R (fully vectorized)
                X_best_broadcast = tf.broadcast_to(X_best[tf.newaxis, :], [self.n, self.dim])
                X_new = X + A * (X_best_broadcast - X) + B * R
                
                # Clip to bounds (vectorized operation across all agents)
                X_new = tf.clip_by_value(X_new, self.lb, self.ub)

                # Evaluate fitness for all new positions (vectorized, no loops)
                new_fitness = self._evaluate_population(X_new)

                # Vectorized comparison: which agents improved
                improved = new_fitness < fitness
                
                # Update all positions and fitness values (vectorized)
                X.assign(X_new)
                fitness.assign(new_fitness)
                
                # Update stagnation counter (vectorized: increment all, reset improved)
                stagnation_counter.assign(
                    tf.where(improved, 
                            tf.zeros(self.n, dtype=tf.int32), 
                            stagnation_counter + 1)
                )
                
                # Update energy for all agents (vectorized)
                E.assign(
                    tf.where(improved,
                            E - C + G,  # Gain energy for improved agents
                            E - C)      # Lose energy for non-improved agents
                )

                # Vectorized stagnation handling with Levy flights
                stagnated_mask = stagnation_counter > self.stagnation_threshold
                
                if tf.reduce_any(stagnated_mask):
                    # Count stagnated agents
                    n_stagnated = tf.reduce_sum(tf.cast(stagnated_mask, tf.int32))
                    
                    # Generate Levy flight steps for all stagnated agents at once
                    levy_steps = self._levy_flight(beta=1.5, n_samples=n_stagnated)
                    
                    # Vectorized Levy step scaling
                    alpha = 0.01
                    step_size = alpha * (self.ub - self.lb) * levy_steps
                    
                    # Extract stagnated agents' positions (vectorized indexing)
                    stagnated_indices = tf.where(stagnated_mask)
                    X_stagnated = tf.gather_nd(X, stagnated_indices)
                    
                    # Apply Levy jump to all stagnated agents simultaneously
                    X_stagnated_new = X_stagnated + step_size
                    X_stagnated_new = tf.clip_by_value(X_stagnated_new, self.lb, self.ub)
                    
                    # Update positions for stagnated agents (vectorized scatter)
                    X.assign(tf.tensor_scatter_nd_update(X, stagnated_indices, X_stagnated_new))
                    
                    # Re-evaluate fitness for jumped agents (vectorized)
                    fitness_stagnated = self._evaluate_population(X_stagnated_new)
                    fitness.assign(tf.tensor_scatter_nd_update(fitness, stagnated_indices, fitness_stagnated))
                    
                    # Reset stagnation counter for jumped agents (vectorized)
                    stagnation_counter.assign(
                        tf.where(stagnated_mask, 
                                tf.zeros(self.n, dtype=tf.int32), 
                                stagnation_counter)
                    )

                # Update global best (vectorized argmin operation)
                current_best_idx = tf.argmin(fitness)
                current_best_fitness = fitness[current_best_idx]
                
                if current_best_fitness < f_best:
                    f_best.assign(current_best_fitness)
                    X_best.assign(X[current_best_idx])

                history.append(float(f_best.numpy()))

                # Print progress
                if self.verbose:
                    print(f"Iter {t}/{self.max_iter}, Best Fitness: {f_best.numpy():.6f}")

            return X_best.numpy(), float(f_best.numpy()), history