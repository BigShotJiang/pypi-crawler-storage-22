from airflow.providers.common.sql.operators.sql import SQLCheckOperator
from typing import Optional


def create_count_check_task(
    task_id: str,
    table_name: str,
    partition_column: Optional[str] = None,
    partition_value: Optional[str] = None,
    conn_id: str = 'vfq_hive'
):
    schema, table = table_name.split('.')
    test_table_name = f"test_{schema}.{table}"
    
    if partition_column and partition_value:
        where_clause = f"WHERE {partition_column} = '{partition_value}'"
    else:
        where_clause = ""
    
    return SQLCheckOperator(
        task_id=task_id,
        conn_id=conn_id,
        sql=f"""
        SELECT CASE 
            WHEN COUNT(DISTINCT cnt) = 1 THEN 1 
            ELSE 0 
        END as result
        FROM (
            SELECT COUNT(*) as cnt 
            FROM {table_name}
            {where_clause}
            UNION ALL
            SELECT COUNT(*) as cnt 
            FROM {test_table_name}
            {where_clause}
        ) counts
        """
    )


def create_data_check_task(
    task_id: str,
    table_name: str,
    partition_column: Optional[str] = None,
    partition_value: Optional[str] = None,
    conn_id: str = 'vfq_hive'
):
    schema, table = table_name.split('.')
    test_table_name = f"test_{schema}.{table}"
    
    if partition_column and partition_value:
        where_clause = f"WHERE {partition_column} = '{partition_value}'"
    else:
        where_clause = ""
    
    return SQLCheckOperator(
        task_id=task_id,
        conn_id=conn_id,
        sql=f"""
        SELECT CASE 
            WHEN COUNT(*) = 0 THEN 1 
            ELSE 0 
        END as result
        FROM (
            SELECT 'test_table_extra' as difference_type, * FROM (
                SELECT * FROM {test_table_name}
                {where_clause}
                EXCEPT ALL
                SELECT * FROM {table_name}
                {where_clause}
            ) a
            UNION ALL
            SELECT 'orjinal_table_extra' as difference_type, * FROM (
                SELECT * FROM {table_name}
                {where_clause}
                EXCEPT ALL
                SELECT * FROM {test_table_name}
                {where_clause}
            ) b
        ) differences
        """
    )