# Viethas Website Scan v1.1
## Tính năng mới
- Chỉnh sửa điều kiện thỏa mãn với frame-repeate