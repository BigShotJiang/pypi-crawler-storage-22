# from .utils import get_logger
from .document import DocumentNode

__all__ = [
    'DocumentNode',
]
                          