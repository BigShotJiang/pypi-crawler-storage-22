# Vibe-Logger

Vibe-Logger is a lightweight Python logging utility designed for developers who require organized console output, persistent file logging, and automated exception handling with minimal configuration.

## Features
- **ANSI Color Support:** Integrated color-coded levels via Colorama for enhanced readability.
- **Automated Log Cleaning:** Uses regex to strip ANSI escape sequences before writing to files, ensuring clean log data.
- **Exception Decorator:** Includes a `@catch` decorator to automatically log function failures with full error context.
- **Command Callbacks:** Supports functional hooks that trigger specific actions (oncommand) when a log level is reached.
- **Configurable Levels:** Supports standard logging levels (INFO, WARN, CRITICAL) to filter output.

