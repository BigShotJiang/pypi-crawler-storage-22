"""
vibe-logger
A goated logging utility for clean consoles and auto-error catching.
"""

from .logger import Logger

__author__ = "Adam Hany Ahmed"
__version__ = "0.1.0"
__about__ = "A goated logging utility for clean consoles and auto-error catching."
__all__ = ["Logger"]