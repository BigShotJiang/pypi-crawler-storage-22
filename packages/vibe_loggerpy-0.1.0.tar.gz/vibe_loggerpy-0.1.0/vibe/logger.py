import colorama
import re
from datetime import datetime

colorama.init()

class Logger:
    def __init__(self, name: str, logfile: str = None, level: str = "INFO"):
        self.name = name
        self.logfile = logfile
        self.level = level
        # Regex to remove ANSI escape sequences for clean file logging
        self.ansi_escape = re.compile(r'\x1B(?:[@-Z\\-_]|\[[0-?]*[ -/]*[@-~])')

    def _get_time(self):
        return datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    def _write_to_file(self, message: str):
        if self.logfile:
            # Strip colors before writing to file
            clean_message = self.ansi_escape.sub('', message)
            with open(self.logfile, 'a', encoding='utf-8') as f:
                f.write(clean_message + '\n')

    def log_message(self, level: str, color: str, message: str):
        timestamp = self._get_time()
        formatted = f"{color}({timestamp}) [{self.name}] [{level}]: {message}{colorama.Style.RESET_ALL}"
        print(formatted)
        self._write_to_file(formatted)

    def catch(self, func):
        def wrapper(*args, **kwargs):
            self.info(f"Starting {func.__name__}...") # Before
            try:
                result = func(*args, **kwargs) # The actual function
                return result
            except Exception as e:
                self.critical(f"Crash in {func.__name__}: {e}") # After (if error)
        return wrapper
    
    def info(self, message: str, oncommand=None, *args, **kwargs):
        self.log_message("INFO", colorama.Fore.GREEN, message)
        if oncommand:
            # This handles both positional (args) and named (kwargs)
            oncommand(*args, **kwargs)
    def warn(self, message: str, oncommand=None, *args, **kwargs):
        self.log_message("WARN", colorama.Fore.YELLOW, message)
        if oncommand:
            # This handles both positional (args) and named (kwargs)
            oncommand(*args, **kwargs)

    def critical(self, message: str, oncommand=None, *args, **kwargs):
        self.log_message("CRITICAL", colorama.Fore.RED, message)
        if oncommand:
            # This handles both positional (args) and named (kwargs)
            oncommand(*args, **kwargs)
