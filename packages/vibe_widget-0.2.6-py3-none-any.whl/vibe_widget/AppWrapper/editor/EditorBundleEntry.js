import EditorViewer from "../components/editor/EditorViewer";

export default EditorViewer;
