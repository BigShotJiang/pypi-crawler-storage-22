"""Service layer for Vibe Widgets."""
