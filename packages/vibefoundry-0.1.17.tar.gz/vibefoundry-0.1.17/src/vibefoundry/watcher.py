"""
File watching for data and script changes using native OS events (watchdog)
"""

import asyncio
import threading
from pathlib import Path
from typing import Callable, Optional
from dataclasses import dataclass

from watchdog.observers import Observer
from watchdog.events import FileSystemEventHandler, FileSystemEvent


@dataclass
class FileChange:
    """Represents a file change event"""
    path: str
    change_type: str  # "created", "modified", "deleted"
    folder_type: str  # "input", "output", "scripts"


class FolderHandler(FileSystemEventHandler):
    """Handler for file system events in a specific folder"""

    def __init__(
        self,
        folder_type: str,
        on_change: Optional[Callable[[FileChange], None]] = None
    ):
        self.folder_type = folder_type
        self.on_change = on_change
        # Debounce: track recently seen events to avoid duplicates
        self._recent_events: dict[str, float] = {}
        self._lock = threading.Lock()

    def _should_ignore(self, path: str) -> bool:
        """Check if this file should be ignored"""
        name = Path(path).name.lower()
        # Ignore system files, temp files, and hidden files
        ignore_patterns = [
            '.ds_store', 'thumbs.db', 'desktop.ini',
            '.git', '__pycache__', '.pyc', '.pyo',
            'zone.identifier', '.tmp', '.temp', '~',
            'time_keeper.txt', 'time_keeper'
        ]
        for pattern in ignore_patterns:
            if pattern in name:
                return True
        if name.startswith('.'):
            return True
        return False

    def _handle_event(self, event: FileSystemEvent, change_type: str):
        """Handle a file system event"""
        if event.is_directory:
            return

        path = event.src_path
        if self._should_ignore(path):
            return

        # Debounce: skip if we just saw this event
        import time
        now = time.time()
        with self._lock:
            last_time = self._recent_events.get(path, 0)
            if now - last_time < 0.5:  # 500ms debounce
                return
            self._recent_events[path] = now

            # Clean old entries
            self._recent_events = {
                k: v for k, v in self._recent_events.items()
                if now - v < 5.0
            }

        if self.on_change:
            change = FileChange(path=path, change_type=change_type, folder_type=self.folder_type)
            self.on_change(change)

    def on_created(self, event: FileSystemEvent):
        self._handle_event(event, "created")

    def on_modified(self, event: FileSystemEvent):
        self._handle_event(event, "modified")

    def on_deleted(self, event: FileSystemEvent):
        self._handle_event(event, "deleted")


class FileWatcher:
    """
    Watches project folders for file changes using native OS events.
    Uses watchdog for efficient, event-based file watching.
    """

    def __init__(
        self,
        project_folder: Path,
        on_data_change: Optional[Callable[[], None]] = None,
        on_script_change: Optional[Callable[[Path], None]] = None,
        on_output_file_change: Optional[Callable[[Path, str], None]] = None,
        poll_interval: float = 2.0  # Unused, kept for API compatibility
    ):
        self.project_folder = project_folder
        self.input_folder = project_folder / "input_folder"
        self.output_folder = project_folder / "output_folder"
        self.scripts_folder = project_folder / "app_folder" / "scripts"

        self.on_data_change = on_data_change
        self.on_script_change = on_script_change
        self.on_output_file_change = on_output_file_change

        self._observer: Optional[Observer] = None
        self._running = False
        self._loop: Optional[asyncio.AbstractEventLoop] = None

    def _safe_callback(self, callback, *args):
        """Safely call a callback, handling both sync and async from watchdog thread"""
        if callback is None:
            return

        try:
            # If we have an event loop and the callback returns a coroutine, schedule it
            result = callback(*args)
            if asyncio.iscoroutine(result) and self._loop:
                asyncio.run_coroutine_threadsafe(result, self._loop)
        except Exception as e:
            print(f"Watcher callback error: {e}")

    def _handle_change(self, change: FileChange):
        """Route change events to appropriate callbacks"""
        if change.folder_type == "input":
            self._safe_callback(self.on_data_change)
        elif change.folder_type == "output":
            self._safe_callback(self.on_data_change)
            if change.change_type in ("created", "modified"):
                self._safe_callback(self.on_output_file_change, Path(change.path), change.change_type)
        elif change.folder_type == "scripts":
            if change.change_type in ("created", "modified"):
                self._safe_callback(self.on_script_change, Path(change.path))

    def scan_initial_state(self):
        """No-op for compatibility - watchdog doesn't need initial state"""
        pass

    def start(self, loop: Optional[asyncio.AbstractEventLoop] = None):
        """Start watching using native OS file events"""
        if self._running:
            return

        self._running = True
        self._loop = loop

        self._observer = Observer()

        # Create handlers for each folder
        input_handler = FolderHandler("input", self._handle_change)
        output_handler = FolderHandler("output", self._handle_change)
        scripts_handler = FolderHandler("scripts", self._handle_change)

        # Schedule watchers (create folders if they don't exist)
        for folder, handler in [
            (self.input_folder, input_handler),
            (self.output_folder, output_handler),
            (self.scripts_folder, scripts_handler)
        ]:
            folder.mkdir(parents=True, exist_ok=True)
            self._observer.schedule(handler, str(folder), recursive=True)

        self._observer.start()

    async def start_async(self):
        """Start watching - captures event loop for async callbacks"""
        loop = asyncio.get_running_loop()
        self.start(loop=loop)

    def stop(self):
        """Stop watching"""
        self._running = False
        if self._observer:
            self._observer.stop()
            self._observer.join(timeout=2.0)
            self._observer = None

    def check_once(self):
        """
        No-op for compatibility - watchdog is event-based, not poll-based.
        Returns empty change lists.
        """
        return [], [], []
