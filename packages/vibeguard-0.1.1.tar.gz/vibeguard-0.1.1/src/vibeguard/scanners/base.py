"""Base scanner - re-export from __init__."""

from vibeguard.scanners import Scanner

__all__ = ["Scanner"]
