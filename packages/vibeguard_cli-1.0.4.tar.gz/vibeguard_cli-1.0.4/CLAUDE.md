# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## Project Overview

**VibeGuard CLI** is a unified security scanner orchestrator that runs multiple scanners on local repos, normalizes findings into one report + score, and generates safe patch diffs using a BYOK (Bring Your Own Key) LLM.

Key differentiators: normalization + dedup, correlation/confidence scoring, safe patch generation and application.

## Tech Stack

- **Runtime**: Python 3.11+
- **CLI**: Typer[all], Rich, Questionary
- **Config/Validation**: Pydantic v2, toml, python-dotenv
- **Execution**: asyncio + subprocess, httpx, GitPython or direct git subprocess
- **LLM (BYOK)**: litellm (primary), openai SDK, anthropic SDK (fallbacks)
- **Security**: cryptography (Fernet for local key storage)
- **Testing**: pytest + pytest-asyncio, ruff (lint), mypy (type checks)

## Build & Development Commands

```bash
# Install dependencies (once pyproject.toml exists)
pip install -e ".[dev]"

# Run tests
pytest

# Run single test file
pytest tests/test_specific.py

# Run tests with async support
pytest --asyncio-mode=auto

# Lint
ruff check .

# Fix lint issues
ruff check --fix .

# Type check
mypy src/vibeguard
```

## Project Structure

```
vibeguard-cli-2/
├── src/vibeguard/
│   ├── __init__.py       # Package version
│   ├── cli/              # Typer CLI commands
│   │   ├── main.py       # App entry point
│   │   ├── doctor.py     # Environment check command
│   │   ├── init_cmd.py   # Project initialization
│   │   └── scan.py       # Main scan command
│   ├── scanners/
│   │   ├── __init__.py   # Manifest loader
│   │   ├── manifests/    # Scanner plugin manifests (.toml)
│   │   ├── parsers/      # Parser adapters (semgrep.py)
│   │   └── runners/      # LocalRunner, DockerRunner
│   ├── models/           # Pydantic models (Finding, ScanResult)
│   └── core/             # Config utilities
├── tests/                # pytest test suite
├── docs/                 # progress.md, plan.md, context.md
└── pyproject.toml
```

## Architecture

### Plugin System (Manifest-Driven)
Scanners are defined via manifests in `src/vibeguard/scanners/manifests/*.toml`. Each manifest specifies: name, tier, categories, languages, install strategy (binary/pip/docker), command templates, output type (json/sarif/text), and parser module reference.

### Hybrid Runner
- **LocalRunner**: Auto-downloads binaries to `~/.vibeguard/bin/`, caches by version + OS/arch, verifies checksums
- **DockerRunner**: Fallback for tools like Semgrep; mounts repo read-only
- **Graceful degradation**: Scanner failure → warn, mark scan partial, continue

### Data Models (Pydantic v2)
- **Finding**: id (stable hash), scanner, severity, category, title, message, file_path, line_start/end, cwe, references, code_snippet, fingerprints
- **ScanResult**: repo_root, started_at/finished_at, score (0-100), grade, findings list, counts by severity, scanners_run/skipped, partial flag
- **PatchArtifact**: finding_id, file_path, unified_diff, provider/model, generated_at
- **Baseline**: name, created_at, findings (BaselineFinding list), scanners_used
- **ComparisonResult**: baseline_name, new_findings (regressions), fixed_findings (improvements), unchanged_count

### Scoring (v1)
Base 100, deductions: Critical -20, High -10, Medium -5, Low -2. Grades: A+ ≥95, A ≥85, B ≥70, C ≥50, D ≥30, F <30.

## CLI Commands

### Free Tier
- `vibeguard doctor` - Detect environment, installed scanners, print actionable fixes
- `vibeguard init` - Create `.vibeguard/config.toml` and `.vibeguardignore`
- `vibeguard scan [path]` - Run scanners (options: `--pack`, `--ci`, `--output`, `--baseline`, `--threshold`)
- `vibeguard report` - Generate reports from cached scan
- `vibeguard fix [finding-id]` - Generate copy-paste prompt (FREE)
  - No args: Interactive mode to browse/select findings
  - `--bulk` - Multi-select mode for bulk prompt generation
  - `--severity LEVEL` - Filter by minimum severity
  - `--interactive` - Force interactive mode
- `vibeguard baseline save [name]` - Save current scan as baseline
- `vibeguard baseline list` - List all saved baselines
- `vibeguard baseline show <name>` - Show baseline details
- `vibeguard baseline delete <name>` - Delete a baseline

### Experimental
- `vibeguard live <url>` - DAST scan on running web application (Nuclei)
  - Localhost-only by default (127.0.0.1, localhost, ::1)
  - `--i-own-this` - REQUIRED for non-localhost targets
  - `--rate-limit N` - Max requests per second (default: 50)
  - `--timeout N` - Per-request timeout in seconds (default: 10)
  - `--tags TAGS` - Filter templates by tags (comma-separated)
  - `--severity LEVELS` - Filter by severity (comma-separated)
  - `--output FORMAT` - Output format: terminal, json

### Pro Tier (License + BYOK)
- `vibeguard auth login <license-key>` - Activate Pro license for this machine
- `vibeguard auth status` - Show current license status
- `vibeguard auth logout` - Deactivate license and clear token
- `vibeguard patch [finding-id]` - Generate unified diff via LLM (requires license + BYOK key)
  - No args: Interactive mode to browse/select findings
  - `--bulk` - Multi-select mode for bulk patching
  - `--severity LEVEL` - Filter by minimum severity
- `vibeguard apply <patch-file>` - Safe patch application with git checks (requires license)

## Scanner Packs

- **Core** (default): Semgrep, Gitleaks, Trivy, Bandit, TruffleHog v3
- **Ecosystem** (auto-enabled by repo detection): Safety/pip-audit, npm/yarn audit, cargo-audit, gosec, Grype
- **Differentiation**: Checkov, tfsec, Nuclei, Bearer, Horusec, Dockle, kube-linter

## Core Principles

1. **Local-first**: Scanning runs on developer's machine only
2. **Safe-by-default**: Never auto-apply patches; require explicit `apply`
3. **Graceful degradation**: Missing scanner → warn + continue
4. **Deterministic CI**: `--ci` must be stable/reproducible
5. **Minimal friction**: Useful output within 5 minutes of install
6. **BYOK transparency**: User controls keys, LLM bill, data

## Patch Safety Rules

1. Minimal changes only
2. No new dependencies unless absolutely required
3. No secrets in output
4. Preserve code style
5. Output ONLY valid unified diff
6. Validate diff before saving
7. Insert `# MANUAL_REVIEW_REQUIRED` if uncertain

## Development Guidelines

- Ship weekly increments that work
- Prefer the simplest working solution
- One command/feature per session
- Tests for every parser + scoring function
- No claims without running the command locally
- Keep defaults fast; make deep scans opt-in
- Do NOT hardcode scanners; use manifest-driven plugins

## Iteration Workflow

**Before starting work:**
1. Read `docs/progress.md` for context on current status and what's next

**After each iteration:**
1. Update `docs/progress.md` with completed work and next steps
2. Update this file (CLAUDE.md) if architecture or commands change
3. Commit and push to git

**Planning:**
- Implementation plans are stored in `docs/plan.md`
- Use plan mode for non-trivial features before implementation

## API Server (vibeguard-api)

The Pro backend (vibeguard-api) handles licensing, entitlements, and policy bundles.

### SSH Access
```bash
ssh -i C:/Users/faheem/.ssh/faheem_ssh ubuntu@<server-ip>
```

### API Endpoints
- Base URL: `https://api-cli-2.vibeguard.co`
- `POST /v1/licenses/activate` - Activate license key
- `POST /v1/licenses/refresh-token` - Refresh auth token
- `GET /v1/entitlements` - Get current entitlements
- `GET /v1/bundles/latest` - Download policy bundle

### Local Auth Storage
- Machine ID: `~/.vibeguard/machine_id`
- Auth token: `~/.vibeguard/auth.json`
- Bundles: `~/.vibeguard/bundles/`

## Website (vibeguard.co)

The VibeGuard marketing website.

- **Domain**: vibeguard.co
- **Local path**: `G:\Downloads 2.0\vibeguard-website-2`

## Panel System

User dashboard and admin panel. Implemented as a Turborepo monorepo.

**Location**: `C:\Users\faheem\OneDrive\Documents\apps\vibeguard-panel\`

| Domain | Purpose | Port (dev) |
|--------|---------|------------|
| `app.vibeguard.co` | User dashboard (licenses, machines, billing, settings) | 3000 |
| `admin.vibeguard.co` | Admin panel (user management, license issuance, audit) | 3001 |

### Tech Stack
- **Framework**: Next.js 14 (App Router)
- **Auth**: Clerk
- **Styling**: Tailwind CSS
- **Data Fetching**: TanStack Query
- **Build**: Turborepo + pnpm workspaces

### Panel Commands
```bash
cd C:\Users\faheem\OneDrive\Documents\apps\vibeguard-panel

# Install dependencies
pnpm install

# Run all apps
pnpm dev

# Run specific app
pnpm --filter @vibeguard/user-panel dev
pnpm --filter @vibeguard/admin dev

# Build all
pnpm build
```

### Panel Structure
```
vibeguard-panel/
├── apps/
│   ├── user/           # app.vibeguard.co
│   │   └── src/app/
│   │       ├── (auth)/       # Sign-in/up pages
│   │       └── (dashboard)/  # Dashboard, licenses, machines, billing, settings
│   └── admin/          # admin.vibeguard.co
│       └── src/app/
│           ├── (auth)/       # Admin sign-in
│           └── (dashboard)/  # Dashboard, users, licenses, payments, audit
├── packages/
│   ├── ui/             # Shared components (Button, Card, Badge, Toggle)
│   ├── api-client/     # TanStack Query hooks for API calls
│   └── config/         # Shared ESLint/Tailwind config
└── README.md
```

### Sprint Status
- **Sprint 1**: Backend payment infrastructure ✅ (webhooks, Stripe provider, atomic fulfillment)
- **Sprint 2**: Panel auth + dashboard ✅ (Clerk, all pages built, TanStack Query hooks)
