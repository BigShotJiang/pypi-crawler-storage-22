# VibeGuard CI Integration Guide

This guide covers integrating VibeGuard into your CI/CD pipelines.

## Quick Start

### GitHub Actions

Add this to `.github/workflows/security.yml`:

```yaml
name: Security Scan

on: [push, pull_request]

permissions:
  security-events: write

jobs:
  vibeguard:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4

      - uses: actions/setup-python@v5
        with:
          python-version: '3.11'

      - run: pip install vibeguard

      - name: Run VibeGuard
        run: vibeguard scan . --ci --sarif-file results.sarif

      - uses: github/codeql-action/upload-sarif@v3
        with:
          sarif_file: results.sarif
```

### GitLab CI

Add this to `.gitlab-ci.yml`:

```yaml
vibeguard:
  image: python:3.11
  script:
    - pip install vibeguard
    - vibeguard scan . --ci --output json > results.json
  artifacts:
    reports:
      sast: results.json
```

### Jenkins

```groovy
pipeline {
    agent any
    stages {
        stage('Security Scan') {
            steps {
                sh 'pip install vibeguard'
                sh 'vibeguard scan . --ci --sarif-file results.sarif --threshold 70'
            }
            post {
                always {
                    archiveArtifacts artifacts: 'results.sarif', fingerprint: true
                }
            }
        }
    }
}
```

## CI Mode (`--ci`)

The `--ci` flag enables CI-optimized behavior:

- **Deterministic**: No auto-downloads or pip installs (use pre-installed scanners)
- **Quiet output**: Minimal console output, no progress bars
- **GitHub annotations**: Auto-emits `::error::` and `::warning::` annotations in GitHub Actions
- **No interactive prompts**: Never blocks waiting for user input
- **No auto-report**: Skips auto-generating HTML reports

```bash
vibeguard scan . --ci
```

## Exit Codes

VibeGuard uses specific exit codes for CI integration:

| Code | Meaning | CI Action |
|------|---------|-----------|
| 0 | Success, no findings | Pass |
| 1 | Success, findings detected | Pass (or fail if strict) |
| 2 | Scan error (partial scan) | Warning |
| 10 | Score below threshold | Fail |

### Using Exit Codes

```bash
vibeguard scan . --ci
EXIT_CODE=$?

case $EXIT_CODE in
  0) echo "Clean scan" ;;
  1) echo "Findings detected" ;;
  2) echo "Partial scan - some scanners failed" ;;
  10) echo "Score below threshold - failing build" && exit 1 ;;
esac
```

## Output Formats

### SARIF (GitHub Code Scanning)

SARIF 2.1.0 format for GitHub Code Scanning integration:

```bash
vibeguard scan . --ci --sarif-file results.sarif
```

Upload to GitHub:
```yaml
- uses: github/codeql-action/upload-sarif@v3
  with:
    sarif_file: results.sarif
    category: vibeguard
```

### JSON

Machine-readable JSON output:

```bash
vibeguard scan . --ci --output json > results.json
```

### Quiet Mode

Minimal output for clean CI logs:

```bash
vibeguard scan . --quiet
# Output: VibeGuard: Score 85/100 (A) | C:0 H:2 M:5 L:3 | Scanners: semgrep,gitleaks,trivy,bandit,trufflehog
```

## Threshold Enforcement

Fail the build if security score drops below a threshold:

```bash
# Fail if score < 70
vibeguard scan . --ci --threshold 70
```

Exit code 10 indicates threshold failure.

## GitHub Annotations

In GitHub Actions, VibeGuard auto-emits workflow annotations:

```bash
vibeguard scan . --ci --github-annotations
```

This creates inline annotations in the PR diff view:
- `::error::` for Critical and High findings
- `::warning::` for Medium and Low findings

Auto-enabled when `--ci` flag is used in GitHub Actions environment.

## Badge Generation

Generate a badge for your README:

```bash
vibeguard scan . --ci --badge badge.svg
```

Then in your README:
```markdown
![VibeGuard Score](./badge.svg)
```

## Pre-installed Scanners

For faster CI runs, pre-install scanners in your Docker image or CI environment:

```dockerfile
# Dockerfile for CI
FROM python:3.11

# Install scanners
RUN pip install semgrep bandit

# Install VibeGuard
RUN pip install vibeguard
```

Or in CI setup:
```yaml
- name: Install Scanners
  run: |
    pip install semgrep bandit
    # Download binaries
    curl -sSfL https://github.com/gitleaks/gitleaks/releases/download/v8.18.0/gitleaks_8.18.0_linux_x64.tar.gz | tar xz
    sudo mv gitleaks /usr/local/bin/
```

## Environment Variables

| Variable | Description |
|----------|-------------|
| `CI` | Set to `true` to enable CI mode detection |
| `GITHUB_ACTIONS` | Auto-detected for GitHub annotations |
| `VIBEGUARD_CI` | Force CI mode behavior |

## Caching

Cache scanner binaries between runs:

```yaml
# GitHub Actions
- uses: actions/cache@v4
  with:
    path: ~/.vibeguard/bin
    key: vibeguard-scanners-${{ runner.os }}
```

## PR Comments (Coming Soon)

Future feature: Auto-comment security summary on PRs.

## Troubleshooting

### Scanner Not Found

Ensure scanners are installed before running with `--ci`:
```bash
vibeguard doctor  # Check scanner availability
```

### Partial Scan

Exit code 2 indicates some scanners failed. Check:
- Scanner installation
- Docker availability (for fallback)
- Network connectivity (for downloads)

### Threshold Failure

Exit code 10 means score is below threshold:
```bash
# Get current score
vibeguard scan . --output json | jq '.score'
```

## Complete Example

```yaml
name: Security

on:
  push:
    branches: [main]
  pull_request:

permissions:
  contents: read
  security-events: write

jobs:
  vibeguard:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4

      - uses: actions/setup-python@v5
        with:
          python-version: '3.11'

      - uses: actions/cache@v4
        with:
          path: ~/.vibeguard/bin
          key: vibeguard-${{ runner.os }}

      - name: Install VibeGuard
        run: pip install vibeguard semgrep bandit

      - name: Security Scan
        run: |
          vibeguard scan . \
            --ci \
            --sarif-file results.sarif \
            --badge badge.svg \
            --threshold 50

      - uses: github/codeql-action/upload-sarif@v3
        if: always()
        with:
          sarif_file: results.sarif

      - uses: actions/upload-artifact@v4
        if: always()
        with:
          name: security-badge
          path: badge.svg
```
