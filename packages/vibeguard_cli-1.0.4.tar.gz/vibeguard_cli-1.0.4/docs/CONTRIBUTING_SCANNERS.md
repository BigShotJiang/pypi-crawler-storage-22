# Contributing Scanner Plugins to VibeGuard

This guide explains how to add new security scanners to VibeGuard CLI.

## Overview

VibeGuard uses a **manifest-driven plugin system**. Each scanner requires:
1. A manifest file (`.toml`) defining the scanner configuration
2. A parser module (`.py`) to normalize output to the Finding model
3. Tests for the parser

The architecture is decoupled: **manifest + parser = complete scanner integration**.

## Quick Start

To add a new scanner:

1. Create manifest: `src/vibeguard/scanners/manifests/<scanner_name>.toml`
2. Create parser: `src/vibeguard/scanners/parsers/<scanner_name>.py`
3. Add to whitelist: `ALLOWED_PARSER_MODULES` in `cli/scan.py`
4. Add tests: `tests/test_<scanner_name>_parser.py`
5. Run tests: `pytest tests/test_<scanner_name>_parser.py`

---

## Scanner Manifest Structure

Create `src/vibeguard/scanners/manifests/<scanner_name>.toml`:

### Required Sections

```toml
# Scanner metadata
[scanner]
name = "example_scanner"           # Unique identifier (lowercase, underscores)
display_name = "Example Scanner"    # Human-readable name
version = "1.0.0"                   # Scanner version to download/use
tier = "ecosystem"                  # core, ecosystem, or differentiation
categories = ["security"]           # security, secrets, vulnerability, etc.
languages = ["python"]              # Supported languages or ["*"] for all

# Installation strategies (priority order)
[install]
strategies = ["local", "download", "pip", "docker"]

# Local binary check
[install.local]
check_command = "example-scanner --version"
binary_name = "example-scanner"

# Auto-download from GitHub releases
[install.download]
url_template = "https://github.com/org/repo/releases/download/v{version}/example_{version}_{os}_{arch}.tar.gz"
binary_name = "example-scanner"
archive_type = "tar.gz"
windows_archive_type = "zip"       # Different archive for Windows
windows_arch = "amd64"             # Windows architecture name

# Pip installation
[install.pip]
package_name = "example-scanner"

# Docker fallback
[install.docker]
image = "org/example-scanner:latest"
mount_mode = "ro"                   # Read-only mount

# Execution configuration
[execution]
command = "example-scanner scan {target} --format json"
timeout = 300                       # Timeout in seconds
output_format = "json"              # json, jsonl, sarif

# Docker-specific execution
[execution.docker]
command = "scan /src --format json"
workdir = "/src"

# Output parsing
[output]
format = "json"                     # json, jsonl, sarif
parser_module = "vibeguard.scanners.parsers.example_scanner"
parser_function = "parse_output"
```

### Placeholders

Use these placeholders in commands:
- `{target}` - Target directory path (for SAST)
- `{image}` - Docker image name (for container scanners like Dockle)

### Tier Classification

- **core**: Essential scanners included by default (Semgrep, Gitleaks, Trivy, Bandit, TruffleHog)
- **ecosystem**: Auto-enabled based on repo detection (npm-audit, pip-audit, cargo-audit)
- **differentiation**: Specialized scanners (Checkov, Dockle, Nuclei)

---

## Parser Implementation

Create `src/vibeguard/scanners/parsers/<scanner_name>.py`:

### Required Function

```python
def parse_output(raw_output: str) -> list[Finding]:
    """Parse scanner output into normalized Findings.

    Args:
        raw_output: Raw stdout from scanner

    Returns:
        List of Finding objects

    Raises:
        ValueError: If output cannot be parsed (optional)
    """
```

### Finding Model Fields

```python
from vibeguard.models.finding import Finding, Severity, Category

finding = Finding(
    # Required fields
    scanner="example_scanner",      # Your scanner name
    rule_id="RULE-001",             # Original rule/check ID
    severity=Severity.HIGH,         # CRITICAL, HIGH, MEDIUM, LOW, INFO
    category=Category.SECURITY,     # SECURITY, SECRETS, VULNERABILITY, etc.
    title="Short description",      # Brief title
    message="Detailed message",     # Explanation of the issue
    file_path="path/to/file.py",    # Affected file
    line_start=42,                  # Starting line (use 1 if unknown)

    # Optional fields
    line_end=45,                    # Ending line
    cwe="CWE-79",                   # CWE ID if available
    references=["https://..."],     # Reference URLs
    code_snippet="affected code",   # Code context
    fingerprint="unique_id",        # For deduplication
)
```

### Severity Enum

```python
from vibeguard.models.finding import Severity

Severity.CRITICAL  # Most severe
Severity.HIGH
Severity.MEDIUM
Severity.LOW
Severity.INFO      # Informational
```

### Category Enum

```python
from vibeguard.models.finding import Category

Category.SECURITY           # General security issues
Category.SECRETS            # Exposed secrets/credentials
Category.VULNERABILITY      # Known CVEs/vulnerabilities
Category.MISCONFIGURATION   # Configuration issues
Category.BEST_PRACTICE      # Best practice violations
```

### Parser Template

```python
"""Example scanner output parser."""

import json
from typing import Any

from vibeguard.models.finding import Category, Finding, Severity

# Map scanner severity to VibeGuard severity
SEVERITY_MAP: dict[str, Severity] = {
    "critical": Severity.CRITICAL,
    "high": Severity.HIGH,
    "medium": Severity.MEDIUM,
    "low": Severity.LOW,
    "info": Severity.INFO,
}


def parse_output(raw_output: str) -> list[Finding]:
    """Parse scanner JSON output into normalized Findings."""
    if not raw_output or raw_output.strip() == "":
        return []

    try:
        data = json.loads(raw_output)
    except json.JSONDecodeError as e:
        raise ValueError(f"Invalid JSON: {e}") from e

    findings: list[Finding] = []
    for item in data.get("results", []):
        finding = _parse_item(item)
        if finding:
            findings.append(finding)

    return findings


def _parse_item(item: dict[str, Any]) -> Finding | None:
    """Parse a single result into a Finding."""
    try:
        severity_str = item.get("severity", "medium").lower()
        severity = SEVERITY_MAP.get(severity_str, Severity.MEDIUM)

        return Finding(
            scanner="example_scanner",
            rule_id=item.get("rule_id", "unknown"),
            severity=severity,
            category=Category.SECURITY,
            title=item.get("title", "Finding"),
            message=item.get("message", ""),
            file_path=item.get("file", ""),
            line_start=item.get("line", 1),
            line_end=item.get("end_line"),
            cwe=item.get("cwe"),
            references=item.get("references", []),
            code_snippet=item.get("snippet"),
        )
    except Exception:
        # Skip malformed items gracefully
        return None
```

### JSONL Parser (One JSON per Line)

For scanners like Nuclei that output JSON Lines:

```python
def parse_output(raw_output: str) -> list[Finding]:
    """Parse JSONL output (one JSON object per line)."""
    if not raw_output or raw_output.strip() == "":
        return []

    findings: list[Finding] = []
    for line in raw_output.strip().split("\n"):
        line = line.strip()
        if not line:
            continue
        try:
            data = json.loads(line)
            finding = _parse_item(data)
            if finding:
                findings.append(finding)
        except json.JSONDecodeError:
            continue  # Skip malformed lines

    return findings
```

---

## Security Whitelist

Add your parser module to `ALLOWED_PARSER_MODULES` in `src/vibeguard/cli/scan.py`:

```python
ALLOWED_PARSER_MODULES = frozenset([
    # ... existing modules ...
    "vibeguard.scanners.parsers.example_scanner",
])
```

This whitelist prevents arbitrary code loading for security.

---

## Testing Requirements

Create `tests/test_<scanner_name>_parser.py`:

### Required Test Cases

1. **Empty output handling**
2. **Invalid JSON handling**
3. **Single finding parsing**
4. **Multiple findings parsing**
5. **Severity mapping**
6. **Missing fields (graceful defaults)**
7. **Malformed entries (skip gracefully)**

### Test Template

```python
"""Tests for example scanner parser."""

import json
import pytest

from vibeguard.models.finding import Category, Severity
from vibeguard.scanners.parsers.example_scanner import parse_output


class TestParseOutput:
    def test_empty_output_returns_empty_list(self) -> None:
        assert parse_output("") == []
        assert parse_output("   ") == []

    def test_invalid_json_raises_value_error(self) -> None:
        with pytest.raises(ValueError, match="Invalid"):
            parse_output("not json")

    def test_single_finding(self) -> None:
        output = json.dumps({
            "results": [{
                "rule_id": "TEST-001",
                "severity": "high",
                "title": "Test Finding",
                "message": "Test message",
                "file": "test.py",
                "line": 10,
            }]
        })
        findings = parse_output(output)
        assert len(findings) == 1
        assert findings[0].rule_id == "TEST-001"
        assert findings[0].severity == Severity.HIGH

    def test_multiple_findings(self) -> None:
        output = json.dumps({
            "results": [
                {"rule_id": "A", "severity": "high", "file": "a.py", "line": 1},
                {"rule_id": "B", "severity": "low", "file": "b.py", "line": 2},
            ]
        })
        findings = parse_output(output)
        assert len(findings) == 2

    def test_missing_severity_defaults_medium(self) -> None:
        output = json.dumps({
            "results": [{"rule_id": "TEST", "file": "test.py", "line": 1}]
        })
        findings = parse_output(output)
        assert findings[0].severity == Severity.MEDIUM

    def test_malformed_entry_skipped(self) -> None:
        output = json.dumps({
            "results": [
                None,  # Invalid
                {"rule_id": "TEST", "severity": "high", "file": "test.py", "line": 1},
            ]
        })
        findings = parse_output(output)
        assert len(findings) == 1


class TestSeverityMapping:
    @pytest.mark.parametrize("input_sev,expected", [
        ("critical", Severity.CRITICAL),
        ("high", Severity.HIGH),
        ("medium", Severity.MEDIUM),
        ("low", Severity.LOW),
        ("info", Severity.INFO),
        ("CRITICAL", Severity.CRITICAL),  # Case insensitive
    ])
    def test_severity_mapping(self, input_sev: str, expected: Severity) -> None:
        output = json.dumps({
            "results": [{"rule_id": "T", "severity": input_sev, "file": "t.py", "line": 1}]
        })
        findings = parse_output(output)
        assert findings[0].severity == expected
```

---

## Optional: Display Messages

Add fun status messages in `src/vibeguard/cli/display.py`:

```python
SCANNER_MESSAGES = {
    # ... existing scanners ...
    "example_scanner": [
        "Running example scan",
        "Analyzing with example",
        "Example scanner active",
        "Checking for issues",
    ],
}
```

---

## Checklist

Before submitting:

- [ ] Manifest file created and valid TOML
- [ ] Parser module implements `parse_output()`
- [ ] Parser added to `ALLOWED_PARSER_MODULES`
- [ ] Tests cover edge cases (empty, invalid, malformed)
- [ ] All tests pass: `pytest tests/test_<scanner>_parser.py`
- [ ] Ruff lint clean: `ruff check src/vibeguard/scanners/parsers/<scanner>.py`
- [ ] Display messages added (optional)

---

## Examples

See these existing implementations for reference:

| Scanner | Type | Manifest | Parser |
|---------|------|----------|--------|
| Semgrep | SAST | `semgrep.toml` | `semgrep.py` |
| Gitleaks | Secrets | `gitleaks.toml` | `gitleaks.py` |
| Trivy | Deps/CVE | `trivy.toml` | `trivy.py` |
| Nuclei | DAST | `nuclei.toml` | `nuclei.py` |
| Checkov | IaC | `checkov.toml` | `checkov.py` |

---

## Questions?

Open an issue on GitHub or check the main documentation.
