# VibeGuard CLI — Master Development Context (Jan 2026)

## Role
You are acting as a senior engineer building **VibeGuard CLI** end-to-end.
The founder is solo and will rely on you to implement everything. Ship weekly increments that work.
Do not suggest hiring engineers. Do not propose long refactors. Prefer the simplest working solution.

---

## Product One-Liner
**VibeGuard CLI** runs multiple security scanners on a local repo, normalizes findings into one report + score, and generates **safe, minimal patch diffs** using a BYOK LLM key.

---

## Strategic Positioning
VibeGuard is **not** “another scanner.” It’s a **unified orchestrator**:
- One command: `vibeguard scan .`
- One normalized output schema
- One score/grade
- One set of safe patch workflows (`fix` → `patch` → `apply`)
- Optional scanner packs to scale from “fast” to “mind-blowing coverage”

**Differentiation moat**:
1) normalization + dedup
2) correlation/confidence (multiple tools agree = P0)
3) safe patch generation and safe apply

---

## Non-Goals (DO NOT BUILD in first 90 days)
- No enterprise dashboard web app
- No multi-tenant SaaS backend for scanning
- No cloud code upload (code must stay local; only send minimal snippets to user’s chosen LLM)
- No auto-apply patches without explicit user command
- No invasive telemetry (opt-in later)
- No automated exploitation / “red team” automation (Metasploit chains, exploit frameworks) in first 90 days
- No scanning of third-party targets (DAST must be localhost-only by default)

---

## Core Principles
1. **Local-first**: scanning runs on the developer’s machine
2. **Safe-by-default**: never auto-apply patches; require explicit `apply`
3. **Graceful degradation**: missing scanner => warn + continue
4. **Deterministic CI**: `--ci` must be stable/reproducible
5. **Minimal friction**: user gets useful output within 5 minutes of install
6. **BYOK transparency**: user keys, user LLM bill, user data control

---

## Tech Stack (Locked)
### Runtime
- Python 3.11+

### CLI
- Typer[all] (CLI framework)
- Rich (terminal UI)
- Questionary (interactive prompts)

### Config & Validation
- Pydantic v2 (models + settings)
- toml (project config)
- python-dotenv (env vars)

### Execution
- asyncio + subprocess
- httpx (download binaries)
- GitPython OR direct `git` subprocess (prefer direct git if simpler)

### LLM (BYOK)
- litellm (primary abstraction)
- openai SDK (fallback)
- anthropic SDK (fallback)

### Security
- cryptography (Fernet) for local encrypted key storage

### Testing
- pytest + pytest-asyncio
- ruff (lint)
- mypy (type checks)

---

## CLI Commands

### Free (Core)
- `vibeguard doctor`
  - Detect OS/arch, git, docker availability
  - Detect installed scanners
  - Print actionable fix steps
  - Choose runner mode (local vs docker fallback)

- `vibeguard init`
  - Create `.vibeguard/config.toml`
  - Create `.vibeguardignore`

- `vibeguard scan [path]`
  - Runs enabled scanners (default = Core Pack)
  - Normalizes to unified schema
  - Outputs summary, score, grade
  - Options:
    - `--pack core|ecosystem|full`
    - `--ci`
    - `--output terminal|json|sarif|html`
    - `--changed-only`
    - `--severity critical|high|medium|low`
    - `--timeout N`

- `vibeguard report --format json|sarif|html`
  - Uses cached `.vibeguard/last-scan.json`

- `vibeguard fix <finding-id>`
  - FREE: outputs a copy-paste prompt (no API call)
  - User can paste into ChatGPT/Claude manually

### Pro (Paid, BYOK LLM)
- `vibeguard patch <finding-id>`
  - Generates unified diff (BYOK LLM)
  - Writes `.vibeguard/patches/{finding-id}.patch`
  - Never auto-applies

- `vibeguard apply <patch-file>`
  - Runs `git apply --check`
  - Applies if safe; else instructs manual review
  - `--dry-run`

### Experimental (late 90 days)
- `vibeguard live <url>`
  - localhost-only by default
  - runs safe DAST templates (e.g., Nuclei HTTP templates)
  - requires explicit `--i-own-this` to scan remote targets

---

## Scanner Packs (90-day scope)
### Pack: Core (default)
Ship by Week 4.
- Semgrep (SAST multi-lang) — prefer existing install; docker fallback
- Gitleaks (secrets) — auto-download binary
- Trivy (deps/container/iac) — auto-download binary
- Bandit (Python SAST) — pip install, enabled when Python detected
- TruffleHog v3 (secrets) — auto-download binary

Marketing claim (Week 4): **“5 industry-standard scanners, zero config.”**

### Pack: Ecosystem (auto-enabled)
Ship gradually Weeks 5–8.
Auto-enable based on repo files:
- Safety or pip-audit (Python) -> requirements.txt / pyproject.toml
- npm audit / yarn audit (JS) -> package.json
- cargo-audit (Rust) -> Cargo.toml
- gosec (Go) -> go.mod / *.go
- Grype (deps, optional) as alternate coverage

### Pack: Differentiation (selective)
Ship 2–3 tools only in Weeks 8–12:
Pick from:
- Checkov (IaC policies)
- tfsec (Terraform)
- Nuclei (template engine; used for live mode later)
- Bearer (data flow / PII)
- Horusec (multi-lang SAST fallback)
- Dockle (container best practices)
- kube-linter (K8s manifests)

Rule: do not add a tool unless:
- installation can be automated reliably (binary or pip)
- output can be parsed deterministically (json/sarif)
- runtime can be bounded with timeouts

### Commercial Provider Connectors (NOT full orchestration in 90 days)
Start with **import mode**:
- `vibeguard import --sarif path/to/codeql.sarif`
- `vibeguard import --json path/to/snyk.json`
Goal: merge third-party results into unified report + correlation.
API orchestration may be Team tier later.

---

## Plugin Architecture (Critical)
Do NOT hardcode scanners in a giant dict.

Use **manifest-driven plugins**:
- `src/vibeguard/scanners/manifests/*.toml` (or YAML)
- Each manifest defines:
  - name, tier, categories, languages
  - install strategy (binary/pip/docker/builtin)
  - command template(s)
  - output type (json/sarif/text)
  - parser module reference

Scanner adapters can be community-contributed by adding a manifest + parser + tests.

---

## Hybrid Runner Architecture
Implement two runner modes with fallback:

### LocalRunner (Primary)
- Auto-download scanner binaries into `~/.vibeguard/bin/`
- Cache by version + OS/arch
- Verify checksums where available
- Weekly update check (best-effort)

### DockerRunner (Fallback)
- Used primarily for Semgrep if not installed locally
- Mount repo read-only
- Capture JSON output

Graceful degradation:
- scanner fails => warn, mark scan partial, continue

---

## Normalized Data Models (Pydantic v2)
- Finding:
  - id (stable hash)
  - scanner, severity, category, title, message
  - file_path, line_start/line_end
  - cwe, references, code_snippet
  - confidence (optional; later)
  - fingerprints (for dedup)
- ScanResult:
  - repo_root, started_at, finished_at
  - score (0-100), grade
  - findings list
  - counts by severity
  - scanners_run / scanners_skipped
  - partial: bool
- PatchArtifact:
  - finding_id, file_path, unified_diff
  - provider/model, generated_at

---

## Patch Safety Rules (Enforced)
1. Minimal changes only
2. No new dependencies unless absolutely required
3. No secrets in output
4. Preserve code style
5. Output ONLY valid unified diff
6. Validate diff before saving
7. If uncertain, insert `# MANUAL_REVIEW_REQUIRED`

---

## Scoring (v1)
Start simple and deterministic:
- Base 100
- Deductions:
  - Critical -20
  - High -10
  - Medium -5
  - Low -2
- Grade bands:
  - A+ >= 95, A >= 85, B >= 70, C >= 50, D >= 30 else F

Later (Team tier): correlation increases confidence, not score.

---

## Monetization & BYOK (Positioning)
### Core insight
Do NOT charge for scanning. Charge when you **save time**.

### Free Tier (forever)
Users get:
- Core scanning (5 scanners)
- Score + grade
- JSON/SARIF outputs
- `fix` prompt (copy/paste)
- Badge generation

### Pro ($29/mo)
Users pay for:
- `patch` unified diff generation (BYOK LLM)
- `apply` safe patch application
- Batch patching Top N findings
- Better summaries (LLM) but still BYOK
- “Full pack” unlock (optional; keep it simple)

Deliverable expectation:
- “I can go from finding → safe diff → applied fix in minutes.”

### Team ($99/mo, 5 seats)
Users pay for:
- Correlation/confidence scoring
- Baselines + regression checks
- Policy presets (fail PR if confidence high)
- Import results from other tools + unify reporting

Enterprise is out-of-scope for first 90 days (custom later).

---

# 90-Day Execution Plan (Weekly Deliverables)

## Weeks 1–4: Foundation + Core Pack
### Week 1
- Project scaffold, Typer CLI, Rich output
- Pydantic models
- `doctor`, `init`, skeleton `scan`
Exit: `vibeguard scan .` runs Semgrep and prints findings table.

### Week 2
- Hybrid runner (local + docker fallback)
- Auto-download framework + caching
- Add Gitleaks + Trivy
Exit: `scan` runs 3 tools (Semgrep/Gitleaks/Trivy), outputs JSON cache.

### Week 3
- Add Bandit + TruffleHog
- Normalization layer (unified Finding schema)
- Scoring + grade
Exit: “5 scanners, one score” works.

### Week 4
- Reports: JSON + SARIF + HTML
- Badge SVG generator
- Polished errors + exit codes
Exit: v0.1 public release + README.

## Weeks 5–8: Paid Value + CI + Ecosystem Pack
### Week 5
- Config storage + encrypted BYOK keys
- `fix` prompt templates
- `patch` diff generation (BYOK)
Exit: patch file generated + validated unified diff.

### Week 6
- `apply` command with git safety checks
- License key gating for Pro features (minimal)
- Start Founding Pro pricing
Exit: first paying users can patch+apply reliably.

### Week 7
- CI mode + deterministic outputs + exit codes
- GitHub Action wrapper
Exit: PR scan + SARIF upload + fail threshold.

### Week 8
- Add 2–3 ecosystem scanners with auto-detection
- Announce “10 tools in one CLI” (if real)
Exit: packs + auto-enable work on real repos.

## Weeks 9–12: Differentiation + Correlation + Experimental Live
### Week 9
- Dedup improvements + fingerprints
- Baseline support (save baseline, compare)
Exit: “regression” workflow works.

### Week 10
- Add 1–2 differentiation scanners (e.g., Checkov + Dockle)
Exit: “AI-generated IaC is unsafe” angle is real.

### Week 11
- Import mode for external SARIF/JSON
- Merge + normalized reporting
Exit: VibeGuard can unify CodeQL SARIF + local scanners.

### Week 12
- Experimental `live` localhost-only using safe templates
- Documentation, contributor guide for scanner plugins
Exit: credible “code + running app” story without turning into a hacking tool.

---

## Working Rules
- One command/feature shipped per session
- Tests for every parser + scoring
- No claims without running the command locally
- Keep defaults fast; make deep scans opt-in
