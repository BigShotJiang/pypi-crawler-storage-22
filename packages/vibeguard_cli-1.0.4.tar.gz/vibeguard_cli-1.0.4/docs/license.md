# License Management

## Issuing New Licenses

### 1. Manual Script (Current Method)

SSH into the server and run:

```bash
ssh -i C:/Users/faheem/.ssh/faheem_ssh ubuntu@api-cli-2.vibeguard.co

# Run inside the API container
sudo docker exec vibeguard_api_1 python -c "
import asyncio
from app.seed_license import create_test_license
asyncio.run(create_test_license())
"
```

Or create a custom license with specific email:

```bash
sudo docker exec vibeguard_api_1 python -c "
import asyncio
from app.database import async_session_maker, init_db
from app.models import User, License
from app.auth import generate_license_key, hash_license_key

async def create_license(email, plan='pro', max_activations=3):
    await init_db()
    async with async_session_maker() as db:
        user = User(email=email)
        db.add(user)
        await db.flush()

        key = generate_license_key()
        license = License(
            user_id=user.id,
            license_key_hash=hash_license_key(key),
            license_key_prefix=key[:8],
            plan=plan,
            max_activations=max_activations
        )
        db.add(license)
        await db.commit()
        print(f'License for {email}: {key}')

asyncio.run(create_license('customer@example.com'))
"
```

### 2. Stripe Checkout (Automated - Not Yet Connected)

Once Stripe is connected, the flow will be:

1. Customer goes to `vibeguard.co/pricing` → clicks "Buy Pro"
2. Stripe Checkout handles payment
3. Webhook `checkout.session.completed` fires
4. Server auto-creates user + license
5. Email sent to customer with license key

**To connect Stripe:**

1. Create a Stripe product/price for "VibeGuard Pro"
2. Get your webhook secret from Stripe dashboard
3. Update the server `.env`:

```bash
ssh -i C:/Users/faheem/.ssh/faheem_ssh ubuntu@api-cli-2.vibeguard.co

# Edit the env file
sudo nano /opt/vibeguard/api/.env

# Add:
STRIPE_SECRET_KEY=sk_live_...
STRIPE_WEBHOOK_SECRET=whsec_...

# Restart
cd /opt/vibeguard && sudo docker-compose restart api
```

4. Add webhook endpoint in Stripe dashboard:
   - URL: `https://api-cli-2.vibeguard.co/v1/stripe/webhook`
   - Events: `checkout.session.completed`, `customer.subscription.updated`, `customer.subscription.deleted`

---

## License Key Format

License keys follow this format:
```
VG-XXXX-XXXX-XXXX-XXXX
```

Example: `VG-1DA6ACD9-88FD3AFB-41BC23D1-A597FBF4`

## Plans and Entitlements

| Plan | Entitlements |
|------|--------------|
| `pro` | `pro.patch`, `pro.apply`, `bundles.v1` |
| `team` | `pro.patch`, `pro.apply`, `bundles.v1`, `team.members` |
| `enterprise` | `pro.patch`, `pro.apply`, `bundles.v1`, `team.members`, `enterprise.sso` |

## Server Location

- **API URL**: `https://api-cli-2.vibeguard.co`
- **Server Path**: `/opt/vibeguard/`
- **Database**: PostgreSQL in Docker (`vibeguard_vibeguard-postgres_1`)

## Test License

To create a test license for development, run the manual script above with `test@vibeguard.co` as the email. The license key will be printed to stdout - do not commit it to version control.

Test licenses are stored with hashed keys in the database per the security requirements in upgrade.md (line 137).
