# VibeGuard CLI - Week 3 Implementation Plan

## Overview
Add Bandit (Python SAST) and TruffleHog (secret scanning) scanners, improve finding normalization with deduplication, and refine the scoring algorithm.

**Exit Criteria**: 5 scanners running (Semgrep, Gitleaks, Trivy, Bandit, TruffleHog), improved dedup/normalization, refined scoring.

---

## Implementation Order

### Phase 1: Bandit Scanner
1. `src/vibeguard/scanners/manifests/bandit.toml` - Manifest with pip install strategy
2. `src/vibeguard/scanners/parsers/bandit.py` - JSON parser with severity mapping
3. `tests/test_parsers/test_bandit.py` - Parser tests

### Phase 2: TruffleHog Scanner
4. `src/vibeguard/scanners/manifests/trufflehog.toml` - Manifest with download strategy
5. `src/vibeguard/scanners/parsers/trufflehog.py` - JSON lines parser
6. `tests/test_parsers/test_trufflehog.py` - Parser tests

### Phase 3: Normalization Improvements
7. Update `src/vibeguard/models/finding.py` - Enhanced fingerprinting
8. Create `src/vibeguard/core/dedup.py` - Deduplication logic
9. Update `src/vibeguard/cli/scan.py` - Apply dedup before reporting
10. `tests/test_dedup.py` - Deduplication tests

### Phase 4: Scoring Refinements
11. Update `src/vibeguard/models/scan_result.py` - Refined scoring with caps
12. Update scoring tests in `tests/test_models.py`

---

## Key Files to Create

| File | Purpose |
|------|---------|
| `manifests/bandit.toml` | Bandit manifest: pip install, JSON output |
| `parsers/bandit.py` | Parse Bandit JSON → list[Finding] |
| `manifests/trufflehog.toml` | TruffleHog manifest: auto-download, JSON lines |
| `parsers/trufflehog.py` | Parse TruffleHog JSON lines → list[Finding] |
| `core/dedup.py` | Deduplicate findings by fingerprint + location |

---

## Scanner Specifications

### Bandit (Python Security Linter)
- **Install**: `pip install bandit` (local only, no download/docker needed)
- **Command**: `bandit -r {target} -f json`
- **Output**: JSON with `results[]` array
- **Categories**: SAST, security
- **Languages**: Python only

**Severity Mapping**:
- HIGH + HIGH_CONFIDENCE → CRITICAL
- HIGH → HIGH
- MEDIUM → MEDIUM
- LOW → LOW

**Sample Output**:
```json
{
  "results": [
    {
      "code": "os.system(user_input)",
      "filename": "app.py",
      "issue_confidence": "HIGH",
      "issue_severity": "HIGH",
      "issue_text": "Possible shell injection via user input",
      "line_number": 42,
      "line_range": [42, 42],
      "test_id": "B602",
      "test_name": "subprocess_popen_with_shell_equals_true"
    }
  ]
}
```

### TruffleHog v3 (Secret Detection)
- **Install**: Download binary from GitHub releases
- **Command**: `trufflehog filesystem {target} --json`
- **Output**: JSON lines (one finding per line)
- **Categories**: secrets
- **Languages**: * (all)

**Download URLs**:
- Linux x64: `trufflehog_{version}_linux_amd64.tar.gz`
- macOS x64: `trufflehog_{version}_darwin_amd64.tar.gz`
- macOS ARM: `trufflehog_{version}_darwin_arm64.tar.gz`
- Windows: `trufflehog_{version}_windows_amd64.zip`

**Severity Mapping**:
- AWS/GCP/Azure credentials → CRITICAL
- API keys, tokens → HIGH
- Generic secrets → MEDIUM

**Sample Output (JSON lines)**:
```json
{"SourceMetadata":{"Data":{"Filesystem":{"file":"config.py","line":15}}},"SourceID":1,"SourceType":15,"SourceName":"trufflehog - filesystem","DetectorType":1,"DetectorName":"AWS","DecoderName":"PLAIN","Verified":false,"Raw":"AKIA_FAKE_KEY_FOR_DOCS","Redacted":"AKIAIOSFODNN7***","ExtraData":null}
```

---

## Deduplication Strategy

### Fingerprint-Based Dedup
Group findings by a normalized fingerprint:
1. Primary key: `{scanner}:{rule_id}:{file_path}:{line_start}`
2. Secondary grouping: Similar findings within 5 lines of each other
3. Keep the highest severity when deduplicating

### Cross-Scanner Dedup
- Gitleaks + TruffleHog may find same secret → prefer verified findings
- Semgrep + Bandit may find same issue → prefer more specific rule

```python
def deduplicate_findings(findings: list[Finding]) -> list[Finding]:
    """Remove duplicate findings, prefer higher severity/verified."""
    seen: dict[str, Finding] = {}
    for finding in sorted(findings, key=lambda f: f.severity.value):
        key = normalize_fingerprint(finding)
        if key not in seen or should_replace(seen[key], finding):
            seen[key] = finding
    return list(seen.values())
```

---

## Scoring Refinements (v2)

### Changes from v1
1. **Cap deductions per category**: Max -50 from any single category
2. **Bonus for verified fixes**: +5 for each resolved finding (future)
3. **Confidence weighting**: HIGH confidence = full deduction, LOW = half

### Updated Formula
```python
def calculate_score(findings: list[Finding]) -> int:
    base = 100
    deductions = {
        Severity.CRITICAL: 20,
        Severity.HIGH: 10,
        Severity.MEDIUM: 5,
        Severity.LOW: 2,
    }

    # Group by category and cap
    by_category: dict[Category, int] = {}
    for f in findings:
        penalty = deductions[f.severity]
        by_category[f.category] = by_category.get(f.category, 0) + penalty

    # Apply cap of 50 per category
    total_deduction = sum(min(v, 50) for v in by_category.values())
    return max(0, base - total_deduction)
```

---

## Verification Steps

```bash
# Run all tests
pytest -v

# Test Bandit parser
pytest tests/test_parsers/test_bandit.py -v

# Test TruffleHog parser
pytest tests/test_parsers/test_trufflehog.py -v

# Test dedup
pytest tests/test_dedup.py -v

# Run full scan (should show 5 scanners)
vibeguard scan .

# Lint and type check
ruff check src/
mypy src/vibeguard
```

---

## Progress Tracking

- [x] Phase 1: Bandit Scanner
  - [x] Create bandit.toml manifest
  - [x] Create bandit.py parser
  - [x] Create test_bandit.py tests (19 tests)
- [x] Phase 2: TruffleHog Scanner
  - [x] Create trufflehog.toml manifest
  - [x] Create trufflehog.py parser
  - [x] Create test_trufflehog.py tests (25 tests)
- [x] Phase 3: Normalization Improvements
  - [x] Create dedup.py
  - [x] Update scan.py to use dedup
  - [x] Create test_dedup.py (28 tests)
- [x] Phase 4: Scoring Refinements
  - [x] Update scan_result.py scoring with category caps
  - [x] Update test_models.py
- [x] Final: All 154 tests passing, ruff clean, mypy clean


## Week 3.1: Option C - Auto-Bootstrap on `scan` (Zero Config)

**Goal**: `vibeguard scan .` auto-installs or downloads missing scanners (where allowed) before executing the scan.

**Exit Criteria**:
- On a fresh machine, `vibeguard scan .` bootstraps Core pack tools and runs 5 scanners without manual installs (unless user disables bootstrap).
- `--ci` produces deterministic behavior (no downloads, no pip installs).
- Docker fallback is only attempted when Docker is confirmed running.

### Phase 0: Bootstrap
1. Add `src/vibeguard/core/bootstrap.py` (ensure tools exist before scan)
2. Update `src/vibeguard/cli/scan.py` to run bootstrap phase first
3. Add CLI flags: `--bootstrap/--no-bootstrap`, `--no-download`, `--no-pip-install`, `--ci`
4. Update manifests to include install metadata required for bootstrap (pip package, download asset patterns)
5. Fix cache write encoding to UTF-8
6. Tests: `tests/test_bootstrap.py`, cache encoding test, asset resolver selection test
