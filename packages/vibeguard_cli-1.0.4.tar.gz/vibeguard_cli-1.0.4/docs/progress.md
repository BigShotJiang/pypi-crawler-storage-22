# VibeGuard CLI - Development Progress

## Current Status
**Phase**: Post-Sprint 6 — Panel Auth Fix
**Last Updated**: 2026-02-06

---

## Panel System Development

Full implementation log: `vibeguard-panel/docs/panelplan-implementation.md`

### Panel Auth Fix: Clerk JWT → API Flow ✅ FIXED (2026-02-06)

**Root cause**: Clerk JWT authentication was completely broken across all three layers (backend, user panel, admin panel). Panels showed empty/zero data because every API call failed auth.

**3 issues identified and fixed:**

#### 1. Backend missing Clerk env vars (root cause)
- [x] `CLERK_FRONTEND_API` and `ADMIN_EMAILS` existed in `/opt/vibeguard/.env` but NOT in `/opt/vibeguard/api/.env`
- [x] Docker Compose only reads `env_file: ./api/.env`, so the API container never received Clerk config
- [x] `settings.clerk_frontend_api` defaulted to `""`, making JWKS URL `https:///.well-known/jwks.json` (invalid)
- [x] Every Clerk JWT verification crashed → all panel API calls returned 401/500
- [x] **Fix**: Added `CLERK_FRONTEND_API=clerk.vibeguard.co` and `ADMIN_EMAILS=faheem@vibeguard.co` to `/opt/vibeguard/api/.env`
- [x] Restarted API container (cleaned up zombie container holding port 8090)
- [x] Verified: API healthy, JWKS endpoint reachable, invalid tokens return 401 (not 500)

#### 2. User panel not using custom JWT template
- [x] `providers.tsx` called `getToken()` with no args → returned default Clerk session token
- [x] Default session token lacks custom claims (`email`, `name`, `role`, `tier`) defined in "vibeguard" JWT template
- [x] Backend extracts `email` from token for admin checks → `None` caused failures
- [x] **Fix**: Changed to `getToken({ template: "vibeguard" })` in `apps/user/src/app/providers.tsx`
- [x] Added automatic token refresh every 50 minutes (template TTL is 60 min)

#### 3. Admin panel had zero auth sync
- [x] `apps/admin/src/app/providers.tsx` had no `AuthSync` component at all
- [x] No `useAuth()`, no `getToken()`, no `setAuthToken()` — every admin API call sent without `Authorization` header
- [x] **Fix**: Added full `AuthSync` component with `getToken({ template: "vibeguard" })` + 50-min refresh interval

**Clerk JWT Template Config (reference):**
- Template name: `vibeguard`
- Token lifetime: 3600s (1 hour)
- Issuer: `https://clerk.vibeguard.co`
- JWKS: `https://clerk.vibeguard.co/.well-known/jwks.json`
- Custom claims: `name`, `role`, `tier`, `email`

**Files changed:**
- `/opt/vibeguard/api/.env` (server) — added 2 env vars
- `vibeguard-panel/apps/user/src/app/providers.tsx` — template selection + token refresh
- `vibeguard-panel/apps/admin/src/app/providers.tsx` — full AuthSync added

**Status**: Backend deployed. Panel changes need Vercel redeploy.

### PyPI Publication ✅ PUBLISHED (2026-02-06)

- [x] **vibeguard-cli 1.0.0 live on PyPI**: https://pypi.org/project/vibeguard-cli/
- [x] Install: `pip install vibeguard-cli`
- [x] Both wheel (.whl) and sdist (.tar.gz) uploaded
- [x] Manual upload via twine (token-based)
- [x] Updated `.github/workflows/publish.yml` for automated future releases:
  - Switched from API token secrets to **OIDC trusted publishing** (no secrets needed)
  - Tests and linting must pass before publish (removed `continue-on-error`)
  - `id-token: write` permission scoped to publish jobs only
  - Triggers on: git tag push (`v*.*.*`) or manual workflow dispatch
  - TestPyPI option via workflow dispatch toggle
  - GitHub Release auto-created with install instructions on tag push
  - Upgraded `softprops/action-gh-release` to v2

**One-time setup required for automated publishing:**
1. Go to https://pypi.org/manage/project/vibeguard-cli/settings/publishing/
2. Add trusted publisher: GitHub, owner: `faheem91`, repo: `vibeguard-cli-2`, workflow: `publish.yml`, environment: `pypi`
3. Future releases: bump version in `pyproject.toml` + `__init__.py`, then `git tag v1.1.0 && git push origin v1.1.0`

---

### Sprint 6: Bundle Delivery + Rate Limits + Scan History + Observability ✅ COMPLETE (2026-02-06)

**4 features shipped across 3 repos (CLI, API, Panel):**

#### Bundle Delivery System (CLI + API)
- [x] Created `core/bundles.py` - Central bundle fetch, cache, load module
  - `load_cached_bundle()`, `save_bundle()`, `get_cached_version()`
  - `fetch_bundle()` - async, with If-None-Match / ETag conditional fetching
  - `ensure_bundle()` - main entry point, never raises (server → cache → hardcoded fallback)
  - `get_prompt()`, `get_patch_rule()` - bundle value lookup with fallback
  - `get_hardcoded_fallback()` - returns Bundle with current FIX_PROMPT_TEMPLATE
  - Storage: `~/.vibeguard/bundles/current.json` and `~/.vibeguard/bundles/meta.json`
- [x] Modified `fix.py` - bundle-aware `build_fix_prompt()`
  - Renamed `FIX_PROMPT_TEMPLATE` to `_DEFAULT_FIX_PROMPT`
  - Added `bundle: Bundle | None` keyword parameter
  - Uses `get_prompt(bundle, "fix_prompt", _DEFAULT_FIX_PROMPT)` for template
  - Loads cached bundle in `fix()` command (cache-only, no API fetch for FREE tier)
- [x] Modified `patch.py` - full bundle integration
  - Added `_load_bundle_for_patch()` helper (fetches from server for Pro users)
  - Passes `bundle` through to `_generate_and_save_patch()` and `build_fix_prompt()`
  - `_generate_patch_async` reads `max_tokens` and `temperature` from bundle
- [x] Updated API `/v1/bundles/latest` endpoint
  - Returns full bundle JSON inline (not metadata + download URL)
  - Supports `If-None-Match` / ETag for conditional fetching (304 Not Modified)
  - Falls back to filesystem default bundle if no DB bundle
  - Rate limited: 30/min per license
- [x] Created `tests/test_bundles.py` - 36 tests covering all bundle operations
- [x] All 68 targeted tests passing, ruff clean

#### Granular Rate Limits (API)
- [x] Extended `ratelimit.py` with per-endpoint limiters:
  - `activate_key`: 10/min per license key hash
  - `activate_ip`: 20/min per client IP
  - `token_refresh`: 30/min per license ID
  - `checkout`: 5/min per clerk_user_id
  - `trial_start`: 1/day per clerk_user_id
  - `webhook`: 1000/min per client IP
  - `bundle_fetch`: 30/min per JWT subject
  - `scan_submit`: 60/min per license ID
  - `scan_read`: 60/min per clerk user ID
- [x] Added `check_rate_limit()` inline helper for use in endpoint handlers
- [x] Applied rate limits to all endpoints:
  - `/v1/licenses/activate` (by key hash + client IP)
  - `/v1/licenses/refresh-token` (by license ID)
  - `/v1/bundles/latest` (by license ID)
  - `/v1/scans` (submit: by license ID, read: by clerk user ID)
  - `/v1/user/checkout` (by clerk user ID)
  - `/v1/user/trial` (by clerk user ID)
  - `/v1/webhooks/{provider}` (by client IP)

#### Scan History (API + CLI + Panel)
- [x] Created `scan_history` PostgreSQL table with indexes
- [x] Added `ScanHistory` SQLAlchemy model
- [x] Created `routes/scans.py` with 3 endpoints:
  - `POST /v1/scans` - CLI submits scan summary (JWT auth, metadata only)
  - `GET /v1/user/scans` - Panel gets paginated scan history (Clerk auth)
  - `GET /v1/user/scans/stats` - Aggregated stats (total, avg score, trend)
- [x] Created `core/telemetry.py` - Fire-and-forget scan submission from CLI
  - Only for Pro users (has valid token)
  - Non-blocking, wrapped in try/except (never blocks user)
  - Sends only aggregated metadata: score, grade, counts, scanners, duration
- [x] Added scan submission call to `scan.py` after cache save
- [x] Created panel scan history page (`apps/user/src/app/(dashboard)/scans/page.tsx`)
  - Stats cards: Total scans, Avg score, Latest grade, Scans this month
  - Paginated table: date, repo, score/grade badge, findings (C/H/M/L), scanners, duration
  - Grade badges color-coded (A/A+ = green, B = blue, C = amber, D/F = red)
  - Empty state, loading state, pagination
- [x] Added `useScans()` and `useScanStats()` TanStack Query hooks
- [x] Added `getScans()` and `getScanStats()` to API client
- [x] Added "Scans" nav item with BarChart3 icon to dashboard layout

#### Observability (API)
- [x] Enhanced `/healthz` endpoint - checks PostgreSQL and Redis connectivity
  - Returns `{"status": "healthy"|"degraded", "checks": {"postgresql": "ok", "redis": "ok"}}`
- [x] Added X-Request-ID middleware
  - Generates UUID per request, returns in response header
  - Accepts client-provided `X-Request-ID` for tracing
- [x] API version bumped to 1.6.0

### Sprint 5: Admin Panel + Polish ✅ COMPLETE (2026-02-05)
Per panelplan-openai-reinforced-double.md:
- [x] Admin API endpoints deployed (v1.4.0)
  - `/v1/admin/dashboard` - Dashboard stats (users, licenses, revenue)
  - `/v1/admin/users` - List/search users with ban/unban
  - `/v1/admin/licenses` - List/issue/extend/revoke licenses
  - `/v1/admin/payments` - List payments with refund support
  - `/v1/admin/audit` - Audit log with search
  - Clerk JWT auth + ADMIN_EMAILS whitelist (`faheem@vibeguard.co`)
  - Audit logging for all admin actions
- [x] Admin API client hooks (TanStack Query)
  - `useAdminDashboard`, `useAdminUsers`, `useAdminUser`
  - `useBanUser`, `useUnbanUser`
  - `useAdminLicenses`, `useIssueLicense`, `useExtendLicense`, `useRevokeLicense`
  - `useAdminPayments`, `useRefundPayment`
  - `useAdminAuditLog`
- [x] Admin panel pages wired to real API
  - Dashboard: Real stats with loading states
  - Users: Search, pagination, ban/unban actions
  - Licenses: Search, pagination, issue/extend/revoke with modals
  - Payments: Search, pagination, refund action, revenue stats
  - Audit: Search, pagination, action-based icons and colors
- [x] Rate limiting for admin endpoints (Redis)
  - Created `app/ratelimit.py` - Sliding window rate limiter using Redis sorted sets
  - Three rate limit tiers: `admin_read` (60/min), `admin_write` (20/min), `admin_sensitive` (10/min)
  - Applied to all admin endpoints based on operation type
  - Returns 429 with `Retry-After` header when limit exceeded
  - API v1.5.0 deployed

### Sprint 3: API Integration ✅ COMPLETE (2026-02-05)
- [x] Add `/v1/user/*` endpoints to vibeguard-api
  - Dashboard stats, licenses, machines, payments, settings, trial
  - Clerk JWT authentication for panel routes
  - API v1.3.0 deployed to api-cli-2.vibeguard.co
- [x] Vercel deployment for both apps
  - **app.vibeguard.co** - User panel deployed
  - **admin.vibeguard.co** - Admin panel deployed
  - Fixed middleware Edge runtime (NextResponse instead of Response)
  - Added globalEnv to turbo.json for Clerk environment variables
  - Configured vercel.json with `"framework": "nextjs"` for monorepo
  - Created separate Vercel projects (vibeguard-panel, vibeguard-admin)
  - Disabled Vercel Deployment Protection for public access
- [x] Admin panel security hardening
  - Added ADMIN_EMAILS whitelist for admin access control
  - Created /unauthorized page for non-admin users
  - Production blocks all access if no whitelist configured
- [x] Audit findings addressed (2026-02-05)
  - **License reveal re-auth**: Added ReAuthModal - users must verify password before revealing license key
  - **Billing wired to API**: Integrated useSubscription, usePayments, useCreateCheckout, useCancelSubscription
  - **Trial start flow**: Added trial banner with "Start 14-Day Free Trial" button and useStartTrial hook
  - **Machine limit from API**: Now reads license.max_activations instead of hardcoded value
  - **Clerk webhook endpoint**: Created /api/webhooks/clerk with svix signature verification
  - Added new hooks: useSubscription, useCancelSubscription, useStartTrial
  - Added trial endpoint to apiClient
- [x] Clerk webhooks for user sync
  - Created `/api/webhooks/clerk/route.ts` (panel side)
  - Created `/v1/webhooks/clerk/user-sync` and `/v1/webhooks/clerk/user-deleted` (backend)
  - Handles user.created, user.updated, user.deleted events
  - Svix signature verification
  - CLERK_WEBHOOK_SECRET and API_WEBHOOK_KEY configured in Vercel
- [x] Backend: Add /v1/webhooks/clerk/user-sync endpoint
  - Upserts user by clerk_user_id, syncs email/name/email_verified
  - Links existing users by email if clerk_user_id not found
  - Authenticated via X-Webhook-Key header
- [x] Backend: Add /v1/webhooks/clerk/user-deleted endpoint
  - Soft-deletes user by setting is_active=False
  - Preserves audit trail
- [x] Backend: Fix /v1/user/trial endpoint
  - Changed path from `/trial/start` to `/trial` to match frontend
  - Changed response from dict to LicenseResponse object
  - Returns: id, key_prefix, plan, status, entitlements, max_activations, etc.
- [x] GitHub OAuth redirect URI configuration (Clerk callback URL added to GitHub OAuth App)

### Sprint 4: Subscriptions + Grace Period ✅ COMPLETE (2026-02-05)
Per panelplan-openai-reinforced-double.md:
- [x] Database migration for subscription-license linking
  - Added `license_id`, `billing_interval`, `plan_sku` to `subscriptions` table
  - Added `subscription_id` to `licenses` table
  - SQLAlchemy models updated for bidirectional relationship
- [x] Handle `invoice.paid` for subscription renewals
  - Extends `subscriptions.current_period_end` from invoice period
  - Extends linked `licenses.current_period_end` automatically
  - Records payment in `payments` table with provider details
- [x] Handle `customer.subscription.deleted`
  - Sets subscription status to `cancelled` with timestamp
  - **License stays active until period end** (no immediate revocation)
  - Sets `auto_renew=False` on license
- [x] Expiry banner component in CLI (`cli/banners.py`)
  - Grace period banner (yellow, urgent) when `grace.active` entitlement present
  - Critical banner (red) when < 24 hours remaining
  - Approaching banner (yellow) when < 7 days remaining
  - Integrated into `patch` and `apply` commands
- [x] Grace period implementation (48h standard)
  - `GRACE_PERIOD_HOURS = 48` constant in token generation
  - Token expiry bounded: `min(now + 7_days, license_period_end + 48_hours)`
  - `grace.active` entitlement added to token when `now > license_period_end`
  - `get_license_status_with_grace()` for CLI banner display
- [x] Tests for CLI banners (21 tests in `test_banners.py`)
- [x] Pay-early logic (trial days carry over to paid plan)
  - Already implemented in `webhooks.py`: calculates remaining trial days
  - Creates paid license with `plan_days + trial_days`
  - Transfers machine activations, records `trial_days_added` in extra_data
- [x] Refund request flow
  - Created `refund_requests` table for tracking refund requests
  - Added `charge.refunded` webhook handler
  - Full refund: deactivates license and all machine activations
  - Partial refund: logs event, keeps license active
- [x] Renewal reminder emails (cron job)
  - Created `/opt/vibeguard/scripts/renewal_reminders.py`
  - Sends reminders for licenses expiring in 7, 3, 1 days
  - Tracks sent reminders in `extra_data` to avoid duplicates
  - Cron job runs daily at 9 AM: `0 9 * * *`

### Sprint 2: Panel Auth + Dashboard ✅ COMPLETE (2026-02-05)
- Turborepo monorepo at `vibeguard-panel/`
- User panel (app.vibeguard.co): dashboard, licenses, machines, billing, settings
- Admin panel (admin.vibeguard.co): dashboard, users, licenses, payments, audit
- Shared packages: @vibeguard/ui, @vibeguard/api-client, @vibeguard/config
- Clerk authentication, TanStack Query, Tailwind CSS

### Sprint 1: Payment Backend ✅ COMPLETE (2026-02-03)
- Database: webhook_events, payments, admin_audit_log tables
- PaymentProvider abstraction with StripeProvider
- Idempotent webhook handling with UNIQUE constraint
- API v1.1.0 deployed to api-cli-2.vibeguard.co

---

### Option 3A Pro Backend - Server Infrastructure (2026-02-03)

Deployed initial vibeguard-api infrastructure to `https://api-cli-2.vibeguard.co`. Core license activation working; several items remain per upgrade.md Definition of Done.

**Infrastructure Deployed:**
- **FastAPI** - Async Python API framework
- **PostgreSQL 16** - Database (Dockerized)
- **Redis 7** - Provisioned (rate limiting not yet implemented)
- **Nginx** - Reverse proxy with SSL (deviation from Caddy in upgrade.md; used Nginx since server already runs it for other services)
- **Let's Encrypt** - SSL certificates via certbot

**API Contract Status (per upgrade.md line 102-128):**

| Endpoint | Status | Notes |
|----------|--------|-------|
| `GET /healthz` | ✅ Done | Returns 200 |
| `POST /v1/licenses/activate` | ✅ Done | Validates license, enforces max activations, returns JWT |
| `POST /v1/licenses/refresh-token` | ✅ Done | Refreshes token |
| `GET /v1/entitlements` | ✅ Done | Returns entitlements for token |
| `GET /v1/bundles/latest` | ✅ Done | Returns bundle metadata |
| `POST /v1/stripe/webhook` | ⚠️ Partial | Handler exists, not connected to Stripe |

**Database Models (per upgrade.md line 139-155):**
- `users`, `customers`, `subscriptions`, `licenses`, `activations`, `entitlement_tokens` - ✅ Created
- `audit_events`, `bundles` - ✅ Created (optional per plan)
- All sensitive identifiers stored hashed ✅

**Server Location:** `/opt/vibeguard/` on api-cli-2.vibeguard.co

---

### Definition of Done Checklist (per upgrade.md line 375-398)

#### Server
- [x] `/healthz` returns 200 (enhanced: checks PostgreSQL + Redis, returns healthy/degraded)
- [x] Stripe webhook creates/updates user, customer, subscription, license (Sprint 1+4)
- [x] `/v1/licenses/activate` validates, enforces max activations, returns JWT + entitlements
- [x] `/v1/licenses/refresh-token` works
- [x] `/v1/bundles/latest` delivers bundle to entitled clients (Sprint 6: ETag/304 support)
- [x] Revocation path exists (Sprint 5: admin panel revoke license)
- [x] Rate limiting on all endpoints (Sprint 5+6: Redis sliding window)

#### CLI
- [x] `vibeguard auth login/status/logout` works
- [x] Pro commands (`patch`, `apply`) require entitlement token
- [x] Offline grace works (tokens valid until expiry, 7-day TTL)
- [x] Bundles are fetched and cached; patch prompts read from bundle (Sprint 6)

#### Tests
- [x] Unit tests for token store + refresh logic (in test_license.py)
- [x] Unit tests for bundle cache logic (36 tests in test_bundles.py, Sprint 6)
- [ ] CLI integration tests for auth flow (mock server)

**Documentation:**
- Test license details moved to `docs/license.md` (not in progress.md per data security)

---

### Option 3A Pro Backend - CLI Foundation (2026-02-03)

Implemented server-side licensing foundation for the Pro tier. This replaces the previous BYOK-key-based licensing with token-based authentication, enabling future server-side entitlements and policy bundles.

**New Authentication System:**
- **Token-based licensing** replaces BYOK-key detection for Pro features
- **Machine ID** generated per install (UUID stored in `~/.vibeguard/machine_id`)
- **Auth cache** stores JWT token with expiry in `~/.vibeguard/auth.json` (0600 permissions)
- **Offline grace period** - cached tokens remain valid until 7-day expiry
- **Automatic token refresh** - triggers when token expires within 24 hours

**New CLI Commands:**
- `vibeguard auth login <license-key>` - Activate Pro license via API
- `vibeguard auth status` - Show license status, expiry, plan, and entitlements
- `vibeguard auth logout` - Clear cached token

**Licensing Logic Change:**
- **Before**: `is_pro_licensed()` checked if any LLM API key was configured (BYOK)
- **After**: `is_pro_licensed()` checks for valid cached auth token
- **New**: `has_llm_configured()` - separate check for BYOK LLM keys
- **New**: `require_patch_capability()` - requires BOTH Pro token AND BYOK key

**API Client (in core/auth.py):**
- `activate_license()` - POST to /v1/licenses/activate
- `refresh_token()` - POST to /v1/licenses/refresh-token
- `get_entitlements()` - GET /v1/entitlements
- `ensure_valid_token()` - Auto-refresh with offline grace fallback
- Base URL: `https://api-cli-2.vibeguard.co`

**New Files Created:**
- `src/vibeguard/models/auth.py` - Pydantic models (AuthToken, MachineInfo, AuthCache, etc.)
- `src/vibeguard/core/auth.py` - Token storage, machine ID, API client functions
- `src/vibeguard/cli/auth_cmd.py` - CLI commands (login/status/logout)

**Files Modified:**
- `src/vibeguard/cli/main.py` - Registered auth subcommand, added to interactive menu
- `src/vibeguard/core/license.py` - Rewritten for token-based gating
- `src/vibeguard/cli/patch.py` - Uses `require_patch_capability()` (token + BYOK)
- `src/vibeguard/cli/apply.py` - Updated docstring for Pro license
- `CLAUDE.md` - Added API server SSH details and auth commands

**Test Updates:**
- `tests/test_license.py` - Complete rewrite (20 tests for new token-based logic)
- `tests/test_patch_cmd.py` - Added `mock_pro_license` fixture (10 tests updated)
- `tests/test_apply_cmd.py` - Added `mock_pro_license` fixture (11 tests updated)

**Tests:** 781 total tests, all passing. Ruff clean.

**Backwards Compatibility:**
- Free features unaffected (scan, fix, doctor, init, report, baseline)
- Pro features (patch, apply) now require auth token instead of just BYOK key
- BYOK keys still required for actual LLM calls (patch generation)

---

### v1.0.0 Release Prep (2026-02-02)

Preparing for the first stable PyPI release after completing the 90-day roadmap.

**New Files Created:**
- `LICENSE` - MIT license file
- `CHANGELOG.md` - Version history following Keep a Changelog format
- `.github/workflows/publish.yml` - PyPI publishing with OIDC trusted publishing

**Files Updated:**
- `pyproject.toml`:
  - Version bumped from 0.1.0 to 1.0.0
  - Development status changed from Alpha to Production/Stable
  - Added pytest-cov and build to dev dependencies
  - Added coverage configuration (branch=true, fail_under=70)
- `src/vibeguard/__init__.py` - Version bumped to 1.0.0
- `README.md`:
  - Added PyPI, Python version, and License badges
  - Expanded installation section (PyPI + source)
  - Added all commands with tier labels
  - Added Ecosystem and Differentiation scanner packs
  - Added Pro features section with BYOK explanation
  - Added Contributing section

**PyPI Publishing Workflow:**
- Triggered on git tag push (v*.*.*)
- Runs tests, linting, and type checking first
- Builds wheel and sdist with Hatchling
- Uses OIDC trusted publishing (no API tokens needed)
- Creates GitHub Release with artifacts

**Post-Merge Steps:**
1. Configure Trusted Publishing on PyPI (one-time):
   - Go to pypi.org/manage/account/publishing/
   - Add publisher: GitHub, repo: vibeguard/vibeguard-cli, workflow: publish.yml
2. Create and push tag: `git tag v1.0.0 && git push origin v1.0.0`

---

### Week 12.1 Highlights (2026-02-02) - Security Hardening for Live Command

Fixed 4 security issues identified in code review.

**Security Fixes:**
- **[Critical] Shell command injection in `vibeguard live`**
  - Previously: Command built as string and executed with `create_subprocess_shell`
  - User input (URL, template path, tags) could execute arbitrary commands
  - Fix: Switched to `asyncio.create_subprocess_exec` with argument list
  - Added input validation for templates, tags, and severity filters
  - Validation rejects shell metacharacters: `;`, `&`, `|`, `$`, `` ` ``, etc.
  - New validation functions: `_validate_template_path()`, `_validate_tags()`, `_validate_severity()`

- **[Major] Nuclei tag parsing broken for comma-separated strings**
  - Nuclei template tags are comma-separated strings like "cve,xss,rce"
  - Parser was wrapping string in list without splitting
  - Fix: Now splits on commas and normalizes (lowercase, strip whitespace)
  - Category detection now works correctly: "cve,xss" → `Category.VULNERABILITY`

- **[Major] Finding fingerprints collapse distinct URLs**
  - Fingerprint was `nuclei:{template_id}:{host}` - same host = collision
  - Same template on `/search` and `/admin` would deduplicate incorrectly
  - Fix: Fingerprint now includes full `matched-at` URL and matcher name
  - New format: `nuclei:{template_id}:{matched_at_url}:{matcher_name}`

- **[Medium] `.localhost` domains trusted without DNS verification**
  - `foo.localhost` was assumed to be loopback without checking
  - On Windows, these hostnames don't auto-resolve to 127.0.0.1
  - Malicious hosts file entry could bypass the `--i-own-this` safety gate
  - Fix: `.localhost` domains now require DNS verification
  - All resolved IPs must be loopback, or domain treated as external
  - Direct `localhost`, `127.0.0.1`, `::1` still trusted without DNS

**New Security Features:**
- `_run_subprocess_exec()` - Safe subprocess execution without shell
- `_verify_resolves_to_loopback_only()` - DNS verification for localhost claims
- Input validation with safe character patterns (regex-based)
- Added `get_binary_path()` to LocalRunner for secure binary resolution

**Files Modified:**
- `cli/live_cmd.py` - Complete rewrite of command execution
- `scanners/parsers/nuclei.py` - Tag splitting and fingerprint generation
- `core/url_validator.py` - DNS-verified localhost detection
- `scanners/runners/local.py` - Added `get_binary_path()` method

**Tests:** 773 total tests (29 new), all passing. Ruff clean.

**New Tests:**
- Command injection prevention tests (14 tests)
- `.localhost` DNS verification tests (9 tests)
- Comma-separated tag parsing tests (4 tests)
- Fingerprint uniqueness tests (5 tests)

---

### Week 12 Highlights (2026-02-02) - Experimental Live Mode + Documentation

Completed the final week of the 90-day roadmap with experimental DAST scanning and plugin documentation.

**New Features:**
- **`vibeguard live <url>`** - Experimental DAST scanning command
  - Uses Nuclei templates for HTTP vulnerability detection
  - **Localhost-only by default** for safety
  - Requires `--i-own-this` flag for external targets
  - Interactive confirmation for non-localhost scans
  - Excludes dangerous templates (dos, intrusive, bruteforce, fuzzing)
  - Configurable rate limiting (default 50 req/s)
  - Options: `--rate-limit`, `--timeout`, `--tags`, `--severity`, `--output`

- **Nuclei Scanner Integration**
  - Manifest: `scanners/manifests/nuclei.toml`
  - Parser: `scanners/parsers/nuclei.py` (JSONL format)
  - Supports auto-download from GitHub releases
  - Severity and category mapping from template tags
  - CWE and CVSS extraction from findings

- **URL Safety Validator** (`core/url_validator.py`)
  - Validates URLs and detects localhost patterns
  - Recognizes: `localhost`, `127.0.0.1`, `::1`
  - DNS-verified `.localhost` subdomains
  - Detects private IPs (10.x, 172.16-31.x, 192.168.x)
  - Generates appropriate safety warnings

- **Scanner Plugin Documentation** (`docs/CONTRIBUTING_SCANNERS.md`)
  - Complete guide for adding new scanners
  - Manifest structure reference
  - Parser implementation guide
  - Testing requirements and templates

**New Files:**
- `src/vibeguard/cli/live_cmd.py` - Live DAST command
- `src/vibeguard/core/url_validator.py` - URL safety validation
- `src/vibeguard/scanners/manifests/nuclei.toml` - Nuclei manifest
- `src/vibeguard/scanners/parsers/nuclei.py` - Nuclei JSONL parser
- `tests/test_live_cmd.py` (34 tests with security regression tests)
- `tests/test_url_validator.py` (43 tests with DNS verification tests)
- `tests/test_nuclei_parser.py` (45 tests with tag/fingerprint tests)
- `docs/CONTRIBUTING_SCANNERS.md` - Plugin contributor guide

**Modified Files:**
- `cli/main.py` - Registered live command, added to interactive menu
- `cli/scan.py` - Added nuclei to ALLOWED_PARSER_MODULES
- `cli/display.py` - Added scanner messages for nuclei

**Tests:** 773 total tests, all passing. Ruff clean on all files.

**Exit Criteria Met:**
- `vibeguard live http://localhost:8080` works without flags
- External URLs blocked without `--i-own-this`
- External URLs show warning + require interactive confirmation
- Dangerous Nuclei templates excluded by default
- Command injection prevented with input validation
- "Code + running app" story complete

**Marketing claim:** "11 tools in one CLI" (5 core + 4 ecosystem + 2 differentiation)

---

### Week 11.1 Highlights (2026-02-02) - Critical Bug Fixes

Fixed 4 issues identified in code review.

**Bug Fixes:**
- **[High] Import SARIF crash** - Fixed `AttributeError` in `import_cmd.py`
  - `TriageEngine.classify()` method didn't exist; changed to `triage_findings()`
  - Import command now properly triages imported findings
- **[High] Dockle scanner inaccessible** - Now accessible via `--image` flag
  - Added `--image IMAGE` flag to scan command (e.g., `vibeguard scan . --image myapp:latest`)
  - Dockle automatically added to scanner list when `--image` is provided
  - Command template `{image}` placeholder properly substituted
  - Skipped with helpful message when `--image` not provided
- **[Medium] SARIF `--scanner` override ignored** - Now properly overrides SARIF tool name
  - `--scanner` flag now takes precedence over SARIF `tool.driver.name`
  - When not specified (None), falls back to SARIF metadata or "external"
  - Updated help text to clarify behavior
- **[Medium] Import ignores .vibeguardignore** - Now properly loads and applies ignore patterns
  - `TriageEngine` was instantiated incorrectly with `repo_root=None`
  - Now loads patterns via `load_ignore_patterns(target)` and passes correct `repo_root`
  - Imported findings respect local `.vibeguardignore` rules

**Files Modified:**
- `cli/import_cmd.py` - Fixed triage call, proper TriageEngine instantiation
- `cli/scan.py` - Added `--image` flag, Dockle command handling
- `core/sarif_import.py` - Scanner name override logic fixed
- `tests/test_sarif_import.py` - Updated tests for new behavior, added new test

**Tests:** 651 total tests passing, ruff clean on modified files.

---

### Week 11 Highlights (2026-02-02) - Differentiation Scanners + Import

Added two differentiation scanners (Checkov, Dockle) and SARIF import functionality for external tools.

**New Scanners:**
- **Checkov** (IaC Policy Scanner)
  - Scans Terraform, CloudFormation, Kubernetes, Dockerfiles, ARM templates, Helm charts
  - Auto-detects IaC files: `*.tf`, `Dockerfile`, K8s manifests, etc.
  - Added to ecosystem scanners (auto-enabled via repo detection)
  - Pip-installable with fallback to local binary
  - Manifest: `scanners/manifests/checkov.toml`
  - Parser: `scanners/parsers/checkov.py`

- **Dockle** (Container Image Scanner)
  - CIS Docker Benchmark compliance checks
  - Scans built Docker **images** (not Dockerfiles)
  - Requires explicit `--image` flag (deferred: run via direct command)
  - Download strategy from GitHub releases
  - Manifest: `scanners/manifests/dockle.toml`
  - Parser: `scanners/parsers/dockle.py`

**Import Mode:**
- **`vibeguard import sarif <file>`** - Import SARIF 2.1.0 files
  - Supports CodeQL, Semgrep Cloud, Snyk, Checkmarx, and other SARIF tools
  - Parses findings with severity, category, CWE extraction
  - Merges with existing cache (or replace with `--replace`)
  - Deduplicates across imported and scanned findings
  - Options: `--scanner`, `--path`, `--merge/--replace`

**New Files:**
- `src/vibeguard/scanners/manifests/checkov.toml`
- `src/vibeguard/scanners/manifests/dockle.toml`
- `src/vibeguard/scanners/parsers/checkov.py`
- `src/vibeguard/scanners/parsers/dockle.py`
- `src/vibeguard/core/sarif_import.py`
- `src/vibeguard/cli/import_cmd.py`
- `tests/test_checkov_parser.py` (29 tests)
- `tests/test_dockle_parser.py` (23 tests)
- `tests/test_sarif_import.py` (33 tests)

**Modified Files:**
- `cli/scan.py` - Added checkov/dockle to ALLOWED_PARSER_MODULES
- `cli/main.py` - Registered import command, added to interactive menu
- `cli/display.py` - Added scanner messages for checkov and dockle
- `core/repo_detector.py` - Added IAC ecosystem detection

**Tests:** 85 new tests (650 total, all passing), ruff clean.

**Exit Criteria Met:**
- Checkov auto-enables for IaC repos (Terraform, K8s, etc.)
- Dockle manifest ready for container image scanning
- `vibeguard import sarif` merges external results
- "AI-generated IaC is unsafe" marketing angle enabled

**Marketing claim:** "10 tools in one CLI" (5 core + 4 ecosystem + import)

---

### Week 10.1 Highlights (2026-02-02) - Critical Bug Fixes

Fixed 3 issues identified in code review.

**Bug Fixes:**
- **[High] Windows pip-audit path quoting** - Changed from `shlex.quote()` to platform-aware quoting
  - `shlex.quote()` always uses single quotes, which Windows cmd.exe treats as literals
  - Created `_quote_path_for_shell()` that uses `subprocess.list2cmdline()` on Windows
  - Paths like `C:\Users\Jane Doe\project` now work correctly on Windows
- **[High] Triage-suppressed findings leaking** - Commands now use `actionable_findings` only
  - `vibeguard fix/patch` - Now only shows actionable findings (not suppressed noise)
  - `vibeguard report` - Exit code based on actionable findings only
  - GitHub annotations - Only emits for actionable findings
  - SARIF output - Only includes actionable findings by default
  - Prevents ~530 suppressed findings from polluting fix prompts/patches
- **[Medium] `--no-default-ignore` flag inconsistency** - Now bypasses path-class heuristics too
  - Flag now disables BOTH default patterns AND path-class auto-ignores
  - `bypass_path_class` parameter added to `TriageEngine`
  - Users can scan `node_modules`, `vendor`, `tests`, etc. if they explicitly want to
  - Updated help text to clarify: disables patterns AND path classification

**Files Modified:**
- `cli/scan.py` - Added `_quote_path_for_shell()`, fixed GitHub annotations
- `cli/fix.py` - Use `actionable_findings` instead of `findings`
- `cli/patch.py` - Use `actionable_findings` instead of `findings`
- `cli/report.py` - Exit code based on `actionable_findings`
- `reporters/sarif.py` - Added `include_suppressed` param, defaults to actionable only
- `core/triage.py` - Added `bypass_path_class` parameter to `TriageEngine`

**All tests passing**, ruff clean.

---

### Week 10 Highlights (2026-02-02) - Baselines + Regression Checking

Implemented baseline management for regression checking. Users can save a scan as a "baseline" and compare future scans against it to detect new issues (regressions) and resolved issues (improvements).

**New Features:**
- **Baseline Commands** (`vibeguard baseline`)
  - `vibeguard baseline save [name]` - Save current scan as baseline (default: "default")
  - `vibeguard baseline list` - List all saved baselines with metadata
  - `vibeguard baseline show <name>` - Show baseline details and severity breakdown
  - `vibeguard baseline delete <name>` - Delete a baseline (with confirmation or `--force`)

- **Regression Checking** (`--baseline` flag)
  - `vibeguard scan . --baseline default` - Scan and compare against baseline
  - Detects **new findings** (regressions) - in current scan but not baseline
  - Detects **fixed findings** (improvements) - in baseline but not current scan
  - Tracks **unchanged** findings - present in both

- **Smart Fingerprint Matching**
  - Uses normalized fingerprints from `dedup.py` for cross-scanner matching
  - Line bucketing (lines // 5) handles minor line shifts
  - Rule normalization handles cross-scanner equivalence

- **Exit Codes for CI**
  - Exit 0 if no regressions (improvements only or unchanged)
  - Exit 1 if regressions found (new findings)

- **Interactive Menu Integration**
  - Baseline subcommand added to interactive menu
  - Submenu for save/list/show/delete operations
  - Baseline selection from list for show/delete

**New Files:**
- `models/baseline.py` - BaselineFinding, Baseline, ComparisonResult models
- `core/baseline.py` - Storage and comparison logic
- `cli/baseline_cmd.py` - CLI subcommands

**Tests:** 41 new tests (565 total, all passing), ruff clean.

**Exit Criteria Met**:
- `vibeguard baseline save` saves current scan as baseline
- `vibeguard baseline list/show/delete` work correctly
- `vibeguard scan --baseline <name>` compares and shows delta
- Exit code 1 if regressions, 0 otherwise

---

### Week 9.1 Highlights (2026-02-02) - Security & Bug Fixes

Fixed 5 issues identified in code review.

**Bug Fixes:**
- **[High] pip-audit path quoting** - Added `shlex.quote()` to properly quote paths with spaces
  - Previously paths like `C:\Users\Jane Doe\project` would break pip-audit
- **[High] pip-audit project scoping** - Added `--path {target}` for pyproject.toml/Pipfile/setup.py
  - Previously scanned global environment instead of project dependencies
- **[Medium] Deterministic requirements selection** - Added priority order for requirements/ directory
  - Priority: base.txt > requirements.txt > main.txt > prod.txt > alphabetically first
  - Previously used arbitrary glob order (non-deterministic)
- **[Medium] Scanner skip tracking** - pip-audit now properly tracked when skipped
  - Returns `None` (skipped) vs `True` (success) vs `False` (error)
  - Skipped scanners no longer appear in `scanners_run`
  - Intentional skips don't set `partial=True`
- **[High] HTML reporter path traversal** - Added repo_root boundary validation
  - `_load_code_context` now rejects paths that escape repo_root
  - Prevents reading sensitive files like `../../.ssh/id_rsa`
  - Symlink targets are also validated to be within repo_root

**All 524 tests passing**, ruff clean.

---

### Week 9 Highlights (2026-02-02) - Triage System + Report Accuracy

Addressed the core false positive problem where ~530 of 537 findings were noise.

**New Features:**
- **Triage System** with deterministic classification
  - `TriageStatus`: ACTIONABLE, NEEDS_REVIEW, IGNORED, ACCEPTED_RISK
  - `TriageReason`: VCS_OBJECT, GENERATED_CACHE, TEST_FIXTURE, EXAMPLE_SECRET, etc.
  - `PathClass`: SOURCE, TESTS, DOCS, GENERATED, VCS, TEMP, THIRD_PARTY, CONFIG

- **Path Classifier** (`core/path_classifier.py`)
  - Compiled regex patterns for O(1) classification
  - Auto-classifies paths as VCS, generated, tests, docs, etc.

- **Example Secret Detector** (`core/example_detector.py`)
  - Detects placeholder secrets: `AKIAIOSFODNN7EXAMPLE`, `xxxx`, `your-api-key`, etc.
  - Prevents false positives from documentation and examples

- **Default Ignore Patterns**
  - Built-in ignores for `.git/`, `.mypy_cache/`, `node_modules/`, etc.
  - Applied automatically (disable with `--no-default-ignore`)

- **Dual Scoring System**
  - `actionable_score`: Based on actionable findings only (drives grade)
  - `raw_score`: Based on all findings (for transparency)
  - `noise_ratio`: Percentage of findings auto-suppressed

- **Restructured HTML Report**
  - Executive summary with Actionable/Needs Review/Suppressed counts
  - Noise ratio visualization with progress bar
  - Top 50 actionable findings with real code context
  - Collapsible "Needs Review" and "Suppressed" sections
  - Code snippets loaded from disk (not scanner output)

- **pip-audit Scoping Fix**
  - Detects requirements.txt, pyproject.toml, Pipfile
  - Scopes scan to project dependencies only
  - Skips if no dependency file found

**Exit Criteria Met**:
- Score now reflects actionable findings only
- ~530 false positives suppressed with reasons
- Report shows Actionable: 5-7, Suppressed: 530+, Noise Ratio: ~98%

---

### Week 8.1 Highlights (2026-02-02) - Security Hardening
- **Achieved 100/100 security score (Grade A+)**
  - Started at 0/100 (Grade F) with 537 findings
  - Eliminated all Critical, High, Medium, and Low findings
- **Fixed real security vulnerabilities:**
  - **Path traversal in downloader.py** - Added safe extraction for tarfile/zipfile (Zip Slip fix)
  - **Shell injection in doctor.py** - Changed to `shlex.split()` with `shell=False`
  - **Arbitrary code loading in scan.py** - Added whitelist for parser modules
  - **GitHub Actions injection in action.yml** - Moved inputs to environment variables
- **Created ignore pattern system:**
  - New `core/ignore.py` module for .vibeguardignore pattern matching
  - Gitignore-style pattern support with `**`, `*`, `?` wildcards
  - Integrated filtering into scan pipeline (after dedup, before scoring)
- **Updated .vibeguardignore with proper exclusions:**
  - Cache directories: `.mypy_cache/`, `.pytest_cache/`, `.git/`
  - Test files: `tests/`
  - Generated output: `.vibeguard/cache/`, `.vibeguard/patches/`, reports
- **Added security annotations:**
  - `# nosec` comments for expected subprocess usage (scanner tool needs subprocess)
  - `# nosec` comments for display randomization (not security-related)
  - Replaced asserts with explicit runtime checks
- **All 524 tests passing**

**Exit Criteria Met**: Self-scan achieves 100/100 score with zero findings.

### Week 8 Highlights (2026-02-01)
- **Ecosystem scanner auto-detection**
  - Detects JavaScript (package.json, yarn.lock, package-lock.json)
  - Detects Python (requirements.txt, pyproject.toml, Pipfile, setup.py)
  - Detects Rust (Cargo.toml, Cargo.lock)
  - Created `core/repo_detector.py` module with detection logic
- **3 new ecosystem scanners**
  - **npm-audit**: JavaScript/Node.js dependency vulnerabilities
  - **pip-audit**: Python dependency vulnerabilities (auto-installable)
  - **cargo-audit**: Rust dependency vulnerabilities
- **Scanner pack system (`--pack` option)**
  - `core` - 5 core scanners (semgrep, gitleaks, trivy, bandit, trufflehog)
  - `ecosystem` - Only detected ecosystem scanners
  - `full` - All 8 scanners
  - `auto` (default) - Core + auto-detected ecosystem
- **Updated doctor command**
  - Shows ecosystem scanner availability
  - Displays detected ecosystems in current directory
- **82 new tests** (520 total, all passing)
  - Repo detector tests (18 tests)
  - npm-audit parser tests (18 tests)
  - pip-audit parser tests (23 tests)
  - cargo-audit parser tests (23 tests)

**Exit Criteria Met**: `vibeguard scan .` auto-detects ecosystems, `--pack` option works, 3 ecosystem scanners implemented with parsers and manifests.

**Marketing claim**: "8 tools in one CLI" (5 core + 3 ecosystem)

### Week 7 Highlights (2026-02-01)
- **Enhanced CI mode (`--ci` flag)**
  - Deterministic execution: no auto-downloads, no pip installs
  - Quiet output mode with minimal summary line
  - Auto-disables interactive prompts and progress bars
  - Auto-enables GitHub annotations when in GitHub Actions environment
- **CI environment auto-detection**
  - Automatically detects CI environments: CI, GITHUB_ACTIONS, GITLAB_CI, JENKINS_URL, CIRCLECI, TRAVIS
  - `VIBEGUARD_CI=true` environment variable for explicit override
  - No `--ci` flag needed when running in detected CI environment
- **GitHub Actions annotations**
  - `--github-annotations` flag emits `::error::` and `::warning::` annotations
  - Critical/High findings → error annotations (appear in PR diff)
  - Medium/Low findings → warning annotations
  - Auto-enabled in GitHub Actions environment with `--ci`
- **SARIF file output**
  - `--sarif-file PATH` writes SARIF directly to file
  - Perfect for GitHub Code Scanning integration
  - Works with `github/codeql-action/upload-sarif@v3`
- **Quiet mode (`--quiet` / `-q`)**
  - Suppresses progress bars, timing, and detailed output
  - Single-line summary: `VibeGuard: Score 85/100 (A) | C:0 H:2 M:5 L:3 | Scanners: ...`
  - Ideal for CI logs
- **GitHub Action wrapper (`action.yml`)**
  - Reusable GitHub Action for marketplace
  - Inputs: path, threshold, sarif_upload, badge_path, fail_on_findings
  - Outputs: score, grade, findings_count, critical_count, high_count (parsed from JSON)
  - Proper exit code capture with `set +e`
  - Auto-uploads SARIF to GitHub Code Scanning
- **Example workflow (`.github/workflows/vibeguard.yml`)**
  - Complete GitHub Actions workflow template
  - Proper exit code handling with `set +e`
  - JSON parsing with jq for metrics
  - SARIF upload, badge artifact, exit code handling
- **CI Integration documentation (`docs/CI_INTEGRATION.md`)**
  - GitHub Actions, GitLab CI, Jenkins examples
  - Exit codes reference
  - Caching and optimization tips
- **34 new tests** (438 total, all passing)
  - CI environment detection tests (12, including VIBEGUARD_CI)
  - GitHub annotations tests (6)
  - CI summary output tests (3)
  - CLI options tests (5)
  - CLI integration tests for auto-detection (4)
  - Other tests (4)

**Exit Criteria Met**: `vibeguard scan . --ci` with deterministic outputs, auto CI detection, SARIF file output, GitHub annotations, and reusable GitHub Action wrapper.

### Week 7.1 Highlights (2026-02-01)
- **Enhanced `vibeguard fix` with interactive mode** (mirroring patch command)
  - **Interactive mode** when run without arguments
  - **Top-level selection menu:**
    - "Generate prompts for all findings (X total)"
    - "Generate prompts for Critical + High (X findings)" (bulk mode)
    - "Select by severity →" (drill down to pick severity levels)
    - "Pick individual finding(s) →" (single or multi-select)
  - Shows findings summary table first for context
  - `--bulk` / `-b` flag for multi-select bulk prompt generation
  - `--severity` / `-s` flag to filter by minimum severity
  - `--interactive` / `-i` flag to force interactive mode
  - Severity multi-select pre-checks Critical/High by default
  - Bulk mode shows "Prompt N of M" progress indicator
- **Post-prompt action menu** (persistent, no exit after generating)
  - "Copy prompt to clipboard" (single prompt)
  - "Copy all N prompts to clipboard" (bulk)
  - "Copy prompts individually →" (select which to copy)
  - "Export as Markdown (.md)" - saves to `.vibeguard/prompts/`
  - "Export as Text (.txt)" - saves to `.vibeguard/prompts/`
  - "← Select different finding(s)" - back to selection
  - "Exit" - only way to exit
- **Clipboard support** via `pyperclip` dependency
- **Export formats** with timestamps and finding metadata
- **TTY detection** for non-interactive CLI usage (scripts/CI)

### Week 6.2 Highlights (2026-02-01)
- **Bug fixes for patch command**
  - Fixed duplicate "To apply later" messages in patch → apply flow
  - Added "Continue with remaining X patch(es)?" prompt in bulk mode
  - Added progress indicator (Patch N of M) during bulk patching
  - Fixed apply_result check to properly handle both "skip" and "dry_run"

### Week 6.1 Highlights (2026-02-01)
- **LLM key validation with paste hints**
  - Right-click/Ctrl+V paste hint shown when entering API keys
  - Real-time key validation with animated spinner
  - Shows ✓ success or ✗ error with retry option
  - Paste hint also added to "Run command" menu
  - Created `core/validate.py` for API key validation

- **VibeGuard branded spinner**
  - Custom spinner symbols: ✶ ✢ ✻ ✦ ✧ ✹ ✸ ✷
  - Brand color (bold red) to match logo
  - Applied to: key validation, scan progress, bootstrap, patching
  - Registered as "vibeguard" spinner in Rich's spinner registry

### Week 6 Highlights (2026-02-01)
- **`vibeguard apply <patch-file>`** - Safely apply patches with git safety checks
  - Verifies patch file is valid unified diff format
  - Checks repository is a git repo
  - Warns if working directory has uncommitted changes
  - Uses `git apply --check` to verify patch applies cleanly
  - Options: `--dry-run`, `--force`, `--reverse`, `--path`
  - Shows patch preview, modified files, and helpful next steps
- **`vibeguard patch` interactive mode** - Run without arguments for seamless UX
  - **Top-level selection menu:**
    - "Patch all findings (X total)"
    - "Patch all Critical + High (X findings)" (bulk mode)
    - "Select by severity →" (drill down to pick severity levels)
    - "Pick individual finding(s) →" (single or multi-select)
  - Shows findings summary table first for context
  - `--bulk` flag for multi-select bulk patching
  - `--severity` flag to filter by minimum severity
  - Severity multi-select pre-checks Critical/High by default
- **Auto-apply prompt after patch generation**
  - After generating a patch, prompts: "Apply this patch now?"
    - "Yes, apply now" → checks git repo, applies patch, shows next steps
    - "Dry-run first" → verifies patch applies, then asks to apply
    - "No, I'll review later" → shows manual apply command
  - Seamless flow: select → generate → apply → done
- **License gating module** (`core/license.py`) - Pro feature gating
  - `is_pro_licensed()` - Check if user has Pro features enabled
  - `require_pro_license()` - Require Pro license or raise error
  - Pro features gated by presence of configured LLM API key
- **Interactive menu support** - Apply command added to arrow-key menu with patch file selection
- **33 new tests** (404 total, all passing)
  - License module tests (12 tests)
  - Apply command tests (20 tests)

### Previous Highlights

#### Week 5.2 (2026-02-01)
- Semgrep pip auto-install
- Windows UTF-8 encoding fix
- Helpful CLI error messages
- Doctor command shows cached scanners

#### Week 5 Highlights
- **Encrypted BYOK key storage** with Fernet encryption in `~/.vibeguard/keys/`
- **`vibeguard fix <id>`** FREE tier: copy-paste prompts for manual LLM use
- **`vibeguard patch <id>`** PRO tier: LLM-generated unified diffs via litellm
- **`vibeguard keys`** subcommand for API key management (set/get/delete/list)
- **Interactive command menu** with arrow-key navigation when running bare `vibeguard`
- **371 tests passing**, ruff clean, mypy clean

---

## Completed Iterations

### Week 8.1: Security Hardening (2026-02-02)
- [x] Fixed path traversal vulnerability in `core/downloader.py`
  - Added `_is_safe_path()` to validate extraction paths
  - Added `_safe_tar_extract()` and `_safe_zip_extract()` functions
  - Filters out absolute paths, `..` traversal, and paths escaping target dir
- [x] Fixed shell injection in `cli/doctor.py`
  - Changed from `shell=True` to `shlex.split()` with `shell=False`
- [x] Added parser module whitelist in `cli/scan.py`
  - `ALLOWED_PARSER_MODULES` frozenset validates before `importlib.import_module()`
  - Added `# nosemgrep` comment for remaining static analysis false positive
- [x] Fixed GitHub Actions injection in `action.yml`
  - Moved all `${{ inputs.* }}` interpolations to `env:` block
  - Shell scripts reference `$INPUT_*` environment variables instead
- [x] Created `core/ignore.py` for .vibeguardignore support
  - `load_ignore_patterns()` - Load patterns from file
  - `should_ignore()` - Check if path matches patterns
  - `filter_findings()` - Filter findings list by ignore patterns
  - Gitignore-style pattern syntax with `**`, `*`, `?` support
- [x] Updated `cli/scan.py` to use ignore filtering
  - Loads patterns from `.vibeguardignore` in target directory
  - Filters findings after deduplication, before scoring
  - Shows count of ignored findings in non-quiet mode
- [x] Updated `.vibeguardignore` with comprehensive exclusions
  - Cache dirs: `.mypy_cache/`, `.pytest_cache/`, `.git/`, `.ruff_cache/`
  - Tests: `tests/` (contain intentional test data)
  - Output: `.vibeguard/cache/`, `.vibeguard/patches/`, `vibeguard-report-*.html`
- [x] Added security annotations for expected patterns
  - `# nosec B404` on subprocess imports (needed for running scanners)
  - `# nosec B603 B607` on subprocess.run calls (needed for git operations)
  - `# nosec B311` on random.choice calls (display variety only)
- [x] Replaced asserts with explicit runtime checks
  - Changed `assert finding_id is not None` to `if ... raise RuntimeError`
- [x] All 524 tests passing

**Exit Criteria Met**: Self-scan achieves 100/100 (A+) score with zero findings.

### Week 8: Ecosystem Scanners with Auto-Detection (2026-02-01)
- [x] Created repo detector module (`core/repo_detector.py`)
  - Detects JavaScript (package.json, yarn.lock, package-lock.json, pnpm-lock.yaml)
  - Detects Python (requirements.txt, pyproject.toml, Pipfile, setup.py, poetry.lock)
  - Detects Rust (Cargo.toml, Cargo.lock)
  - `detect_ecosystems()`, `get_ecosystem_scanners()`, `get_detection_summary()`
- [x] Created npm-audit scanner
  - Manifest: `scanners/manifests/npm_audit.toml`
  - Parser: `scanners/parsers/npm_audit.py` (handles v7+ and legacy formats)
  - Severity mapping: critical, high, moderate, low, info
- [x] Created pip-audit scanner
  - Manifest: `scanners/manifests/pip_audit.toml` (auto-installable via pip)
  - Parser: `scanners/parsers/pip_audit.py`
  - Keyword-based severity inference from descriptions
- [x] Created cargo-audit scanner
  - Manifest: `scanners/manifests/cargo_audit.toml`
  - Parser: `scanners/parsers/cargo_audit.py`
  - CVSS score parsing and category-based severity
- [x] Added `--pack` option to scan command
  - `core` - 5 core scanners only
  - `ecosystem` - only detected ecosystem scanners
  - `full` - all 8 scanners
  - `auto` (default) - core + auto-detected ecosystem
- [x] Updated doctor command
  - Shows ecosystem scanner availability
  - Displays detected ecosystems in current directory
- [x] Added scanner messages for ecosystem scanners in `display.py`
- [x] Added 82 new tests (520 total, all passing)
  - Repo detector tests (18 tests)
  - npm-audit parser tests (18 tests)
  - pip-audit parser tests (23 tests)
  - cargo-audit parser tests (23 tests)
- [x] Linting (ruff) passing on all new/modified files

**Exit Criteria Met**: `vibeguard scan .` auto-detects and runs ecosystem scanners, `--pack core|ecosystem|full|auto` option works.

### Week 7: CI Mode + GitHub Action (2026-02-01)
- [x] Enhanced CI mode in `cli/scan.py`
  - `--ci` flag enables deterministic mode (no downloads, no pip installs)
  - `--quiet` / `-q` flag for minimal output (single summary line)
  - Suppresses progress bars and interactive prompts in quiet mode
- [x] CI environment auto-detection
  - Detects: CI, GITHUB_ACTIONS, GITLAB_CI, JENKINS_URL, CIRCLECI, TRAVIS
  - `VIBEGUARD_CI=true|1|yes` environment variable for explicit override
  - Auto-triggers CI mode without needing `--ci` flag
- [x] Added GitHub Actions annotations
  - `--github-annotations` flag emits `::error::` and `::warning::` annotations
  - Auto-enabled in GitHub Actions when using `--ci` flag
  - Critical/High → error, Medium/Low → warning
  - Annotations appear inline in PR diff view
- [x] Added SARIF file output option
  - `--sarif-file PATH` writes SARIF 2.1.0 directly to file
  - Compatible with `github/codeql-action/upload-sarif@v3`
- [x] Created GitHub Action wrapper (`action.yml`)
  - Reusable composite action for GitHub Marketplace
  - Inputs: path, threshold, sarif_upload, badge_path, fail_on_findings, python_version
  - Outputs: score, grade, findings_count, critical_count, high_count (parsed from JSON via jq)
  - Proper exit code capture with `set +e`
  - Auto-uploads SARIF to GitHub Code Scanning
- [x] Created example workflow (`.github/workflows/vibeguard.yml`)
  - Complete CI workflow template with proper exit code handling
  - JSON parsing with jq for metrics extraction
  - SARIF upload, badge artifact generation
  - Concurrency control to cancel in-progress runs
- [x] Created CI integration documentation (`docs/CI_INTEGRATION.md`)
  - GitHub Actions, GitLab CI, Jenkins, CircleCI examples
  - Exit codes reference table
  - Caching and optimization tips
  - Troubleshooting guide
- [x] Added 34 new tests (438 total, all passing)
  - CI environment detection (12 tests, including VIBEGUARD_CI)
  - GitHub annotations (6 tests)
  - CI summary output (3 tests)
  - CLI options (5 tests)
  - CLI integration tests for auto-detection (4 tests)
  - Other tests (4 tests)
- [x] Linting (ruff) passing

**Exit Criteria Met**: `vibeguard scan . --ci` with deterministic output, auto CI detection, SARIF file output, GitHub annotations, and reusable GitHub Action wrapper.

### Week 6: Apply Command + License Gating (2026-02-01)
- [x] Created license gating module (`core/license.py`)
  - `is_pro_licensed()` - Returns True if LLM key configured
  - `require_pro_license()` - Raises `ProFeatureError` if not Pro
  - `get_license_status()` - Returns detailed license status dict
  - Pro features enabled by having any LLM provider key configured
- [x] Created apply CLI command (`cli/apply.py`) - PRO tier
  - `vibeguard apply <patch-file>` - Apply patch with git safety checks
  - Validates patch file format (must be valid unified diff)
  - Checks target is a git repository
  - Warns if working directory has uncommitted changes
  - Runs `git apply --check` before applying
  - Options: `--dry-run`, `--force`, `--reverse`, `--path`
  - Shows patch preview with metadata (if available)
  - Shows modified files and next steps after apply
  - Lists available patches when patch file missing
- [x] Updated main.py with apply command registration
  - Added to command registry
  - Added to COMMANDS list for interactive menu
  - Interactive menu prompts for patch file selection
- [x] Added 32 new tests (403 total, all passing)
  - License module: 12 tests
  - Apply command: 20 tests (CLI integration + helper functions)
- [x] Linting (ruff) and type checking (mypy) passing

**Exit Criteria Met**: `vibeguard apply` with git safety checks, Pro feature gating via license module.

### Week 5: BYOK Config + Fix Prompts + Patch Generation (2026-01-31)
- [x] Added new dependencies to pyproject.toml
  - litellm>=1.30.0 for unified LLM API abstraction
  - cryptography>=42.0.0 for Fernet encryption
- [x] Created keyring module (`core/keyring.py`)
  - Fernet-encrypted API key storage in `~/.vibeguard/keys/`
  - Master key auto-generated, stored with owner-only permissions
  - Functions: save_key, load_key, delete_key, list_providers, get_configured_providers
  - Supports: openai, anthropic, google, azure_openai, mistral, groq
- [x] Created LLM module (`core/llm.py`)
  - Unified interface using litellm for all providers
  - Auto-detects first available provider with preference order
  - Default models per provider (gpt-4-turbo, claude-3-opus, etc.)
  - Async generate() with configurable temperature and max_tokens
  - API key masking in error messages for security
- [x] Created PatchArtifact model (`models/patch.py`)
  - finding_id, file_path, unified_diff, provider, model, generated_at
  - validate_unified_diff() checks for valid --- , +++ , @@ markers
  - extract_diff_from_response() handles markdown code blocks
- [x] Created keys CLI command (`cli/keys.py`)
  - `vibeguard keys set <provider> <key>` - store encrypted key
  - `vibeguard keys get <provider>` - check if key exists (masked)
  - `vibeguard keys delete <provider>` - remove key
  - `vibeguard keys list` - show all providers and status
- [x] Created fix CLI command (`cli/fix.py`) - FREE tier
  - Generates copy-paste prompt for manual LLM use
  - Includes finding details, code snippet, CWE, patch safety rules
  - Expected diff format instructions for consistent output
- [x] Created patch CLI command (`cli/patch.py`) - PRO tier
  - Generates unified diff using BYOK LLM key
  - Saves patch to `.vibeguard/patches/{finding-id}.patch`
  - Saves metadata JSON with provider/model info
  - Options: --provider, --model, --output, --dry-run
  - Validates diff before saving, warns about MANUAL_REVIEW_REQUIRED
- [x] Added 111 new tests (371 total, all passing)
  - Keyring encryption/decryption tests
  - LLM provider detection and mocking tests
  - Patch model validation tests
  - CLI command integration tests

**Exit Criteria Met**: `vibeguard patch <id>` generates validated unified diff saved to `.vibeguard/patches/`

### Week 5.2: UX Polish - Helpful CLI Errors + Windows Fixes (2026-02-01)
- [x] Added pip auto-install strategy to Semgrep manifest
  - Updated `semgrep.toml` with `strategies = ["local", "pip", "docker"]`
  - Added `[install.pip]` section with `package_name = "semgrep"`
- [x] Fixed Windows Unicode encoding crash in LocalRunner
  - Set `PYTHONUTF8=1` and `PYTHONIOENCODING=utf-8` environment variables
  - Fixes `'charmap' codec can't encode character` error for Python-based tools
- [x] Added helpful error messages for all CLI commands with required arguments
  - `vibeguard fix` - Shows available finding IDs from last scan
  - `vibeguard patch` - Shows available finding IDs from last scan
  - `vibeguard keys set` - Shows supported providers and example usage
  - `vibeguard keys get` - Shows supported providers and example usage
  - `vibeguard keys delete` - Shows supported providers and example usage
  - All show concrete examples users can copy-paste

- [x] Improved `vibeguard doctor` to check cached binaries
  - Checks system PATH first, then `~/.vibeguard/bin/` cache, then Docker
  - Shows clear status: Ready (PATH/Cached), Docker (fallback), Missing
  - Provides helpful tips for missing scanners

- [x] **Progress bar + time tracking for scan command**
  - Visual progress bar showing scanner progress (X/5 complete)
  - Real-time elapsed time counter
  - Live findings count as scanners complete
  - Per-scanner timing breakdown after scan
  - Total scan time displayed

- [x] **Auto-report generation after scans**
  - Created `core/config.py` - Pydantic config model with load/save
  - HTML reports auto-generated with datetime stamp (e.g., `vibeguard-report-2026-02-01_14-30-00.html`)
  - Configurable: format (html/json/sarif), output_dir, filename_template
  - `--no-report` flag to skip for single scan
  - Settings in `.vibeguard/config.toml`

- [x] **Config management command**
  - `vibeguard config show` - Display current settings
  - `vibeguard config set <key> <value>` - Set individual settings
  - `vibeguard config edit` - Interactive settings editor
  - Added to interactive menu with submenu

**Files changed**: `scanners/manifests/semgrep.toml`, `scanners/runners/local.py`, `cli/fix.py`, `cli/patch.py`, `cli/keys.py`, `cli/doctor.py`, `cli/scan.py`, `cli/config_cmd.py`, `cli/init_cmd.py`, `core/config.py`, `cli/main.py`

### Feature: Interactive Command Menu (2026-02-01)
- [x] Added arrow-key navigation menu when running `vibeguard` with no arguments
  - Uses questionary.select() for interactive selection
  - Shows all commands with descriptions
  - Custom styling matching VibeGuard branding
- [x] **Persistent menu loop** - returns to main menu after each command
  - Commands execute and then menu reappears
  - Only "Exit" option terminates the program
  - Graceful error handling to prevent crashes
- [x] **Nested submenus** for commands with subcommands (e.g., `keys`)
  - Keys submenu: list, set, get, delete with "← Back" option
  - Provider selection for set/get/delete operations
  - Secure password input for API keys (hidden)
- [x] **Smart prompts** for commands needing arguments
  - Scan: path prompt with autocomplete (defaults to ".")
- [x] **"Run command" option** - Type any custom command with parameters
  - Input prompt: `vibeguard ` + your command (e.g., `scan . --badge badge.svg`)
  - Supports full CLI syntax with all flags and options
- [x] Added `questionary>=2.0.0` to pyproject.toml dependencies
- [x] User experience: Banner → Menu → Command → Menu → Command → ... → Exit

### Week 5.1: UX Polish - Help Examples (2026-01-31)
- [x] Fixed `vibeguard keys` to show help when no subcommand given
  - Added `invoke_without_command=True` and callback
- [x] All commands now show usage examples in --help output
  - keys set/get/delete/list, fix, patch, report

### Week 4: Reports + Badge + Exit Codes + v0.1.0 (2026-01-31)
- [x] Created reporters package (`reporters/`)
  - SARIF 2.1.0 reporter for GitHub Code Scanning
  - Standalone HTML report with dark theme + embedded CSS
  - Badge SVG generator (shields.io style)
- [x] Added exit codes module (`core/exit_codes.py`)
  - SUCCESS=0, FINDINGS=1, SCAN_ERROR=2, NO_CACHE=3
  - CONFIG_ERROR=4, INVALID_PATH=5, THRESHOLD_EXCEEDED=10
- [x] Created `vibeguard report` command
  - `--format terminal|json|sarif|html`
  - `--output FILE` for file output
  - `--badge PATH` for badge generation
- [x] Updated `vibeguard scan` with all formats
  - `--output terminal|json|sarif|html`
  - `--badge PATH` for badge generation
  - `--threshold N` exit 10 if score below threshold
  - Proper exit codes based on findings/errors
  - Export options hints shown after findings table
- [x] Added 74 new tests (260 total, all passing)
  - SARIF schema compliance tests
  - HTML structure + XSS prevention tests
  - Badge SVG + color tests
  - Exit code value tests

**Exit Criteria Met**: 4 output formats, badge generation, CI-friendly exit codes, v0.1.0 ready.

### Week 3.1: Auto-Bootstrap on Scan (2026-01-31)
- [x] Created bootstrap module (`core/bootstrap.py`)
  - Checks scanner availability (PATH, cached binary, Docker)
  - Downloads binaries for scanners with download configs
  - Installs pip packages for scanners with pip configs
  - Returns status for each scanner (ready/downloaded/installed/docker_only/unavailable)
  - Supports options: `no_download`, `no_pip_install`
- [x] Updated scanner manifests with pip metadata
  - Added `PipConfig` model to `ScannerManifest`
  - Added `[install.pip]` section to Bandit manifest
  - Added "pip" strategy to Bandit install strategies
- [x] Updated scan.py with bootstrap phase and CLI flags
  - `--bootstrap/--no-bootstrap` (default: True) - Auto-install missing scanners
  - `--no-download` - Skip downloading scanner binaries
  - `--no-pip-install` - Skip installing pip packages
  - `--ci` - CI mode: deterministic, no downloads or installs
  - Bootstrap runs before scanning with progress indicator
  - Reports downloaded/installed/unavailable scanners
- [x] Fixed cache write encoding to UTF-8
  - Explicit UTF-8 encoding in `save_scan()` and `load_latest_scan()`
- [x] Added 24 bootstrap tests (178 total, all passing)
  - Bootstrap detection and status tests
  - `no_download` and `no_pip_install` option tests
  - Cache encoding tests (UTF-8 with unicode)
  - Asset resolver selection tests

**Exit Criteria Met**: `vibeguard scan .` auto-bootstraps Core pack tools before scanning. `--ci` provides deterministic behavior without downloads/installs.

### Feature: Fun Terminal Status Messages (2026-01-31)
- [x] Added security-themed status messages for terminal animations
  - Bootstrap: "Summoning security scanners", "Waking up the guardians", etc.
  - Scanning: "Hunting for vulnerabilities", "Sniffing out security smells", etc.
  - Scanner-specific: Semgrep ("Pattern matching at scale"), Gitleaks ("Hunting leaked secrets"), etc.
  - Patching: "Crafting the fix", "Weaving security patches", etc.
  - Completion: "Vibe check complete", "Your vibes are immaculate", etc.
- [x] Integrated messages into scan command progress indicators
- [x] Added 8 display message tests (186 total tests passing)

### Feature: Logo + Help on Bare Command (2026-01-31)
- [x] Updated main.py to show logo + help when running `vibeguard` with no args
  - Changed from `no_args_is_help=True` to `invoke_without_command=True`
  - Callback shows banner then help text
- [x] All 178 tests passing

### Feature: Init Command Logo (2026-01-31)
- [x] Created `cli/display.py` with shared branding utilities
  - ASCII logo with UTF-8 box characters
  - `get_console()` for Windows UTF-8 support
  - `print_banner()`, `print_logo()`, `print_tagline()` functions
- [x] Updated `init` command to display logo on initialization
- [x] Windows compatibility with legacy console fallback

### Iteration 3: Week 3 Bandit + TruffleHog + Dedup + Scoring (2026-01-31)
- [x] Added Bandit scanner (Python SAST)
  - Manifest (`scanners/manifests/bandit.toml`)
  - Parser with severity+confidence mapping (`scanners/parsers/bandit.py`)
  - 19 tests for parser
- [x] Added TruffleHog scanner (secret detection)
  - Manifest (`scanners/manifests/trufflehog.toml`)
  - JSON lines parser with detector-based severity (`scanners/parsers/trufflehog.py`)
  - 25 tests for parser
- [x] Created deduplication system (`core/dedup.py`)
  - Fingerprint-based dedup across scanners
  - Cross-scanner dedup (AWS, private keys, etc.)
  - Prefers higher severity, more context (CWE, references)
  - 28 tests for dedup
- [x] Updated scan.py for 5 scanners + dedup integration
- [x] Refined scoring algorithm v2
  - Category-based caps (max 50 per category)
  - Updated tests for new scoring
- [x] Added 72 new tests (154 total, all passing)
- [x] Linting (ruff) and type checking (mypy) passing

**Exit Criteria Met**: 5 scanners running (Semgrep, Gitleaks, Trivy, Bandit, TruffleHog), improved dedup/normalization, refined scoring with category caps.

### Iteration 2: Week 2 Multi-Scanner + Auto-Download + Cache (2026-01-30)
- [x] Added `httpx` dependency for async HTTP downloads
- [x] Created auto-download framework (`core/downloader.py`)
  - Platform detection (OS/arch)
  - Async download with httpx
  - Archive extraction (tar.gz/zip)
  - Binary caching in `~/.vibeguard/bin/`
- [x] Created JSON cache system (`core/cache.py`)
  - Save scan results to `.vibeguard/cache/`
  - Load latest cached scan
  - Clear cache functionality
- [x] Added Gitleaks scanner
  - Manifest (`scanners/manifests/gitleaks.toml`)
  - Parser with rule-based severity mapping (`scanners/parsers/gitleaks.py`)
- [x] Added Trivy scanner
  - Manifest (`scanners/manifests/trivy.toml`)
  - Parser with CVE/package extraction (`scanners/parsers/trivy.py`)
- [x] Updated `LocalRunner` to check downloaded binaries
- [x] Refactored scan.py for multi-scanner orchestration
  - Generic `_run_scanner()` function
  - Dynamic parser import
  - Strategy-based fallback (local → download → docker)
  - `--cache/--no-cache` CLI option
- [x] Updated manifest model with `DownloadConfig`
- [x] Added 47 new tests (81 total, all passing)
- [x] Linting (ruff) and type checking (mypy) passing

**Exit Criteria Met**: `vibeguard scan .` runs 3 scanners (Semgrep, Gitleaks, Trivy) with fallback strategies, saves results to JSON cache.

### Iteration 1: Week 1 Foundation (2026-01-30)
- [x] Created pyproject.toml with dependencies (typer, rich, pydantic v2, pytest, ruff, mypy)
- [x] Set up package structure: `src/vibeguard/{cli, models, scanners, core}`
- [x] Implemented Pydantic models: `Finding` with stable ID hash, `ScanResult` with computed score/grade
- [x] Built scanner infrastructure: manifest loader, `LocalRunner`, `DockerRunner`
- [x] Created Semgrep manifest (`scanners/manifests/semgrep.toml`)
- [x] Implemented Semgrep JSON parser with severity mapping
- [x] Implemented CLI commands: `doctor`, `init`, `scan`
- [x] Added 34 tests (all passing): models, parser, CLI integration
- [x] Linting (ruff) and type checking (mypy) passing

**Exit Criteria Met**: `vibeguard scan .` runs, attempts Semgrep (local + Docker fallback), displays Rich report with score/grade.

### Iteration 0: Project Initialization (2026-01-30)
- [x] Created CLAUDE.md with project guidance
- [x] Initialized git repository
- [x] Created progress.md for tracking
- [x] Pushed to private GitHub repo

---

## Known Issues (Post-Auth Fix)

### Panel Issues
1. ~~**Admin panel shows empty/zero data**~~ ✅ FIXED — Clerk JWT auth flow repaired (2026-02-06)
2. ~~**"Issue License" button appears non-functional**~~ ✅ FIXED — Same root cause (auth), now resolved
3. **No VibeGuard logo** - Both admin and user panels use a Lucide `Shield` icon + text ("VG Admin" / "VibeGuard") as placeholder branding. Need to add real VibeGuard logo image files and update the layout components.
   - Admin layout: `apps/admin/src/app/(dashboard)/layout.tsx` lines 36-39
   - User layout: `apps/user/src/app/(dashboard)/layout.tsx` lines 37-40
4. **Panel changes pending Vercel redeploy** — Frontend auth fixes committed but need push + deploy to take effect

### Next Steps
- [x] Debug Clerk JWT → API auth flow ✅ Fixed (3 root causes identified and resolved)
- [ ] Redeploy panels to Vercel (push panel changes, trigger build)
- [ ] End-to-end test: CLI scan → API submission → Panel display
- [ ] Panel build verification (`pnpm build`)
- [ ] Add real VibeGuard logo to both panels

---

## Next Up (Post-90-Day)
- [x] v1.0 release preparation
- [x] Option 3A Pro Backend - CLI Foundation (auth commands, token-based licensing)
- [x] Option 3A Pro Backend - Server (FastAPI + Postgres + Redis + Stripe)
- [x] Option 3A Pro Backend - Bundle delivery (remote prompts, policy updates)
- [x] Debug panel auth flow (Clerk JWT → API) ✅ Fixed (2026-02-06)
- [ ] Add VibeGuard logo assets to panel
- [ ] GitHub Marketplace listing for GitHub Action
- [ ] Additional ecosystem scanners based on user feedback
- [ ] Correlation/confidence scoring (Team tier)
- [ ] Enhanced `live` mode with more template categories

---

## Weekly Milestones (90-Day Plan)

### Weeks 1-4: Foundation + Core Pack
- ~~Week 1: Scaffold + doctor/init/scan skeleton~~ DONE
- ~~Week 2: Hybrid runner + Gitleaks + Trivy~~ DONE
- ~~Week 3: Bandit + TruffleHog + normalization + scoring~~ DONE
- ~~Week 4: Reports (JSON/SARIF/HTML) + badge + v0.1 release~~ DONE

### Weeks 5-8: Paid Value + CI + Ecosystem
- ~~Week 5: BYOK config + fix prompts + patch generation~~ DONE
- ~~Week 6: Apply command + license gating~~ DONE
- ~~Week 7: CI mode + GitHub Action~~ DONE
- ~~Week 8: Ecosystem scanners (npm-audit, pip-audit, cargo-audit)~~ DONE

### Weeks 9-12: Differentiation + Correlation
- ~~Week 9: Triage system + report accuracy~~ DONE
- ~~Week 10: Baselines + regression checking~~ DONE
- ~~Week 11: Differentiation scanners (Checkov, Dockle) + Import mode~~ DONE
- ~~Week 12: Experimental `live` mode + documentation~~ DONE

**90-Day Roadmap Complete!**

---

## Architecture Summary

### Project Structure
```
src/vibeguard/
├── cli/           # CLI commands and display utilities
│   ├── display.py    # Branding (logo, tagline, get_console)
│   ├── fix.py        # FREE: copy-paste prompt generation
│   ├── patch.py      # PRO: LLM-based patch generation
│   ├── apply.py      # PRO: Safe patch application with git checks
│   ├── keys.py       # API key management subcommand
│   ├── config_cmd.py # Settings management subcommand
│   └── baseline_cmd.py # Baseline management subcommand
├── models/        # Finding, ScanResult, PatchArtifact (Pydantic v2)
│   ├── patch.py   # PatchArtifact + diff validation
│   ├── baseline.py # BaselineFinding, Baseline, ComparisonResult
│   └── auth.py    # AuthToken, MachineInfo, AuthCache, API models
├── scanners/
│   ├── manifests/ # Scanner plugin manifests (.toml)
│   │   ├── semgrep.toml
│   │   ├── gitleaks.toml
│   │   ├── trivy.toml
│   │   ├── bandit.toml
│   │   └── trufflehog.toml
│   ├── parsers/   # Output parsers
│   │   ├── semgrep.py
│   │   ├── gitleaks.py
│   │   ├── trivy.py
│   │   ├── bandit.py
│   │   └── trufflehog.py
│   └── runners/   # LocalRunner, DockerRunner
├── core/
│   ├── config.py        # Config utilities
│   ├── downloader.py    # Binary auto-download (with safe extraction)
│   ├── cache.py         # JSON cache management
│   ├── dedup.py         # Finding deduplication
│   ├── baseline.py      # Baseline storage and comparison
│   ├── ignore.py        # .vibeguardignore pattern matching + default ignores
│   ├── triage.py        # Triage engine for classifying findings
│   ├── path_classifier.py  # Path → PathClass classification
│   ├── example_detector.py # Example/placeholder secret detection
│   ├── bootstrap.py     # Auto-install missing scanners
│   ├── exit_codes.py    # CI-friendly exit codes
│   ├── keyring.py       # Encrypted BYOK key storage
│   ├── auth.py          # Token-based auth (machine ID, cache, API client)
│   ├── bundles.py       # Bundle fetch, cache, load (server prompts)
│   ├── telemetry.py     # Fire-and-forget scan metadata submission
│   ├── license.py       # Pro feature gating (token-based)
│   └── llm.py           # LLM provider abstraction (litellm)
└── reporters/
    ├── sarif.py      # SARIF 2.1.0 format
    ├── html.py       # Standalone HTML report
    └── badge.py      # Badge SVG generator
```

### Key Commands
- `vibeguard` - Show banner + interactive command menu (arrow-key navigation)
- `vibeguard --version` - Show version
- `vibeguard doctor` - Check environment and scanner availability
- `vibeguard init` - Initialize .vibeguard/config.toml and .vibeguardignore
- `vibeguard scan [path]` - Run security scan with Rich output
  - `--output terminal|json|sarif|html` - Output format
  - `--badge PATH` - Generate badge SVG
  - `--threshold N` - Exit 10 if score below threshold
  - `--cache/--no-cache` - Enable/disable result caching
  - `--bootstrap/--no-bootstrap` - Auto-install missing scanners
  - `--no-download` - Skip downloading scanner binaries
  - `--no-pip-install` - Skip installing pip packages
  - `--no-report` - Skip auto-generating report
  - `--ci` - CI mode: deterministic, no downloads, quiet output
  - `--quiet` / `-q` - Suppress progress, show minimal summary
  - `--sarif-file PATH` - Write SARIF to file (for GitHub Code Scanning)
  - `--github-annotations` - Emit GitHub Actions annotations
  - `--baseline NAME` / `-b` - Compare against saved baseline
- `vibeguard baseline save [name]` - Save current scan as baseline
  - `--path PATH` - Repository path
  - `--force` - Overwrite without confirmation
- `vibeguard baseline list` - List all saved baselines
- `vibeguard baseline show <name>` - Show baseline details
- `vibeguard baseline delete <name>` - Delete a baseline
  - `--force` - Delete without confirmation
- `vibeguard report [path]` - Generate reports from cached scan
  - `--format terminal|json|sarif|html` - Output format
  - `--output FILE` - Save to file instead of stdout
  - `--badge PATH` - Generate badge SVG
- `vibeguard fix <finding-id>` - Generate copy-paste prompt (FREE)
  - `--path PATH` - Repository path (default: current dir)
- `vibeguard patch [finding-id]` - Generate LLM patch (PRO, BYOK)
  - No args: Interactive mode to browse/select findings
  - `--bulk` - Multi-select mode for bulk patching
  - `--severity LEVEL` - Filter by minimum severity
  - `--interactive` - Force interactive mode
  - `--provider PROVIDER` - LLM provider (auto-detected if not specified)
  - `--model MODEL` - Specific model to use
  - `--output FILE` - Output file path
  - `--dry-run` - Show patch without saving
- `vibeguard apply <patch-file>` - Apply patch with git safety (PRO)
  - `--path PATH` - Repository path (default: current dir)
  - `--dry-run` - Check if patch applies without applying
  - `--force` - Apply even with uncommitted changes
  - `--reverse` - Reverse/unapply the patch
- `vibeguard keys set <provider> <key>` - Store encrypted API key
- `vibeguard keys get <provider>` - Check if key is configured
- `vibeguard keys delete <provider>` - Remove API key
- `vibeguard keys list` - List all providers and status
- `vibeguard config show` - Show current configuration settings
- `vibeguard config set <key> <value>` - Set a config value (e.g., `report.format json`)
- `vibeguard config edit` - Interactively edit report settings
- `vibeguard import sarif <file>` - Import SARIF 2.1.0 results (CodeQL, Snyk, etc.)
  - `--scanner NAME` - Override scanner name from SARIF
  - `--path PATH` - Repository path for cache storage
  - `--merge/--replace` - Merge with existing cache or replace
- `vibeguard auth login <license-key>` - Activate Pro license (PRO)
- `vibeguard auth status` - Show license status, plan, and entitlements
- `vibeguard auth logout` - Clear cached auth token

### Exit Codes
| Code | Meaning |
|------|---------|
| 0 | Success, no findings |
| 1 | Success, findings detected |
| 2 | Scan error (partial scan) |
| 3 | No cached scan (report cmd) |
| 4 | Configuration error |
| 5 | Invalid path |
| 10 | Score below threshold |

### Scanner Fallback Strategy
1. Try local binary (system PATH)
2. Try downloaded binary (`~/.vibeguard/bin/`)
3. Try Docker fallback
4. Skip with warning if all fail

---

## Notes
- Solo founder project - ship working increments weekly
- Prefer simplest working solution
- Tests required for every parser + scoring function
- All tests passing (800+), ruff clean
- Self-scan achieves 100/100 (A+) security score
- **90-day roadmap completed on schedule!**
- Pro Backend complete: API v1.6.0 deployed (FastAPI + PostgreSQL + Redis)
- Panel system: User dashboard (app.vibeguard.co) + Admin panel (admin.vibeguard.co)
- Sprint 6 shipped: Bundle delivery, granular rate limits, scan history, observability
