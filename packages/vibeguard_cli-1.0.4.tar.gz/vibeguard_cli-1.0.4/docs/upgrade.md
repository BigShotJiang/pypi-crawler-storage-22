# VibeGuard — Master Development Context (Option 3A Pro Backend, Feb 2026)

> Source of truth for building the *next* major milestone: **Option 3A**
> (server-side licensing + entitlements + policy bundles) while keeping scanning and patch/apply **local-first**.

---

## Role

You are acting as a senior engineer shipping **weekly, working increments**.

Rules:
- Ship the simplest working solution first; iterate.
- Don’t propose “big refactors” unless it unblocks shipping.
- Keep **Free** tier always useful and fully local.
- Keep **Pro** value enforceable server-side (entitlements + bundles).
- Update `progress.md` after each shipped step. Align work with `plan.md`.

---

## Current State (as of Feb 2, 2026)

### What’s already built (CLI)
- Scanner orchestration, triage, reports, baselines, import mode, and experimental `live`.
- Pro features implemented **locally**:
  - `vibeguard patch` generates unified diffs using BYOK LLM keys.
  - `vibeguard apply` applies diffs with git safety checks.
- Current Pro “license” gating is *BYOK-key-based* (presence of any configured LLM provider key).

### What changes now
We are moving to **Option 3**: the CLI stays public, but paid value moves server-side:
- **Entitlements + policy bundles** are delivered from VibeGuard servers.
- The CLI becomes a “thin Pro client”:
  - It fetches bundles
  - It proves entitlement via short-lived tokens
  - It still does all scanning + patch/apply locally

---

## Strategic Choice: Option 3

### What stays local
Local (public repo + PyPI):
- scanning, aggregation, dedup, triage UI, reporting
- git checks + patch application safety checks
- caching results in `.vibeguard/`
- BYOK LLM keys remain local and encrypted (`~/.vibeguard/keys/`)

### What moves to the server (your moat)
Server (private repo):
- licensing + subscriptions + entitlements
- policy bundles (prompt packs, patch safety rules, templates, provider/model guardrails)
- token issuance + revocation

### Scope decision for this milestone (DEFAULT)
✅ **3A only**: license + entitlements + bundles  
⛔ Not yet: server-side patch planning / generation APIs (3B)

Rationale:
- fastest path to a real “moat”
- preserves “code never leaves your machine” promise
- avoids customer trust concerns and reduces support risk

---

## Repositories & Responsibilities

### `vibeguard` (public)
Owns:
- CLI UX and orchestration
- local scanning + caching
- patch/apply workflows
- **Pro client**: auth + token cache + bundle fetch + entitlement checks

### `vibeguard-api` (private)
Owns:
- FastAPI service
- database (Postgres) models + migrations
- Stripe webhooks + license issuance
- bundle storage + delivery
- optional background jobs (later)

---

## Option 3A: Pro Backend MVP

### User-facing reality
- Customer buys a subscription via Stripe Checkout
- Server issues a **license key**
- CLI activates license and receives a **short-lived entitlement token** (JWT)
- Pro commands (`patch`, `apply`, and bundle-backed functionality) require:
  1) **Valid entitlement token**
  2) **BYOK LLM key configured** (still required for patch generation)

### Offline grace
- If token is valid, Pro runs offline until token expiry.
- Token TTL target: **7 days**
- CLI refreshes automatically when online.

---

## API Contract (v1)

Base URL:
- `https://api-cli-2.vibeguard.co`

Public:
- `GET /healthz` → 200 OK

Stripe:
- `POST /v1/stripe/webhook` (signature-verified)

CLI auth & entitlements:
- `POST /v1/licenses/activate`
  - body: `{ "license_key": "...", "machine_id": "..." }`
  - returns: `{ "token": "...", "expires_at": "...", "entitlements": [...] }`
- `POST /v1/licenses/refresh-token`
  - Authorization: Bearer token
  - returns: new token
- `GET /v1/entitlements`
  - Authorization: Bearer token
  - returns: current entitlement set + plan info

Bundles:
- `GET /v1/bundles/latest`
  - Authorization: Bearer token
  - returns: bundle metadata + download URL (or streams file directly)
  - support caching via `ETag`/`If-None-Match` if easy

(Reserved for later dashboard)
- magic link login, deactivate machine, portal session creation

---

## Data Model (minimum viable)

Store **hashed** sensitive identifiers. Never store raw license keys.

### Tables
- `users`
  - `id`, `email`, `created_at`
- `customers`
  - `id`, `user_id`, `stripe_customer_id`
- `subscriptions`
  - `id`, `stripe_subscription_id`, `status`, `plan`, `current_period_end`
- `licenses`
  - `id`, `license_key_hash`, `user_id`, `status`, `max_activations`
- `activations`
  - `id`, `license_id`, `machine_id_hash`, `created_at`, `last_seen_at`, `revoked_at`
- `entitlement_tokens`
  - `id`, `license_id`, `token_jti`, `expires_at`, `revoked_at`

Optional (nice early):
- `audit_events` (activation attempts, webhook events processed)
- `bundles` (version, created_at, sha256, path)

---

## Bundles (Policy Packs)

### Purpose
Bundles are the “secret sauce”:
- patch prompt packs (system prompt + safety constraints)
- patch safety rules (local validator config)
- templates (report summaries, fix prompt templates)
- provider/model guardrails (allowed models, max tokens, temperature caps)

### Bundle format (MVP)
- Single `bundle.json` with:
  - `version` (semver or date-based)
  - `prompts`: `{ patch_system, patch_user_template, ... }`
  - `patch_rules`: structured checks (see below)
  - `defaults`: model allowlist and safe defaults
- Delivered as:
  - `bundle.json` directly, or zipped (`bundle_{version}.zip`) later

### Local bundle cache
- Cache per-user in `~/.vibeguard/bundles/<version>/bundle.json`
- Keep last N versions (e.g., 3) and a `current` pointer.

### Patch rules (example)
Keep it simple and deterministic:
- **banned file globs** (e.g., `.env`, `*.pem`, `id_rsa`)
- **banned diff patterns** (regex):
  - disabling auth/CSRF
  - adding network calls in auth code
  - turning off TLS verification
- **manual review triggers** (regex):
  - touching crypto code
  - changing access control logic
- **max lines changed** (cap)

The CLI enforces these locally in addition to unified-diff validation.

---

## CLI Changes Required (public repo)

### 1) Add `vibeguard auth` command group
Commands:
- `vibeguard auth login <license_key>`
  - activates license for this machine and caches token
- `vibeguard auth status`
  - shows token expiry, plan, entitlements, last refresh
- `vibeguard auth logout`
  - deletes cached token

### 2) Token & machine ID storage
- Store machine ID in `~/.vibeguard/machine_id` (random UUID on first run)
- Store token in `~/.vibeguard/auth.json` with strict permissions (0600)
- Token refresh:
  - auto-refresh if expiring within 24h and network available
  - otherwise use cached token

### 3) Replace `core/license.py` gating model
Today: Pro = “has BYOK LLM key”  
New:
- `is_pro_licensed()` means **token is valid AND includes required entitlement**
- BYOK LLM key still required for patch generation, but is not “the license”

Pro entitlement examples:
- `pro.patch`
- `pro.apply`
- `bundles.v1`

Implementation notes:
- Keep existing error UX quality (actionable guidance).
- If server is unreachable:
  - allow Pro to proceed **only if cached token is still valid**
  - otherwise show a clear “offline grace expired” message.

### 4) Bundle-backed prompts (small integration first)
- Patch/fix prompts should read from the current bundle if present
- If no bundle:
  - fallback to built-in prompt strings (keeps CLI resilient)

---

## vibeguard-api: Implementation Notes (private repo)

### FastAPI + JWT
- Issue short-lived JWTs (7 days) containing:
  - `sub` = license id
  - `jti` = token id (for revocation)
  - `entitlements` list
  - `exp` expiration
- Validate on each Pro endpoint:
  - signature
  - exp
  - token not revoked
  - license active
  - activation exists for machine (optional: include machine hash claim)

### Stripe webhook handling (MVP)
Process at minimum:
- `checkout.session.completed` → issue license
- subscription updates/cancellations (either now or next step):
  - cancel / past_due / unpaid → mark license inactive and revoke tokens

Webhook rules:
- verify signature using Stripe signing secret
- store webhook event IDs for idempotency

### Rate limiting
Add rate limiting early for:
- `/v1/licenses/activate`
- `/v1/licenses/refresh-token`
Use Redis to store counters or token buckets.

---

## Deployment Target (OVH Dedicated Server)

Domain:
- `api-cli-2.vibeguard.co` → A record → OVH server IP

### Docker Compose services
- `caddy` (reverse proxy + TLS)
- `api` (FastAPI)
- `postgres` (DB)
- `redis` (optional but recommended)

### Directory layout
- `/opt/vibeguard/api`
- `/opt/vibeguard/db`
- `/opt/vibeguard/bundles`
- `/opt/vibeguard/caddy`

### docker-compose.yml (production)
```yaml
services:
  caddy:
    image: caddy:2
    restart: unless-stopped
    ports:
      - "80:80"
      - "443:443"
    volumes:
      - ./caddy/Caddyfile:/etc/caddy/Caddyfile:ro
      - caddy_data:/data
      - caddy_config:/config
    depends_on:
      - api

  api:
    image: ghcr.io/faheem91/vibeguard-api:latest
    restart: unless-stopped
    env_file:
      - ./api/.env
    volumes:
      - ./bundles:/app/bundles
    depends_on:
      - postgres
      - redis

  postgres:
    image: postgres:16
    restart: unless-stopped
    environment:
      POSTGRES_DB: vibeguard
      POSTGRES_USER: vibeguard
      POSTGRES_PASSWORD: ${POSTGRES_PASSWORD}
    volumes:
      - ./db:/var/lib/postgresql/data

  redis:
    image: redis:7
    restart: unless-stopped

volumes:
  caddy_data:
  caddy_config:
```

### Caddyfile
```caddyfile
api-cli-2.vibeguard.co {
  encode zstd gzip

  @api path /v1/* /healthz
  handle @api {
    reverse_proxy api:8000
  }

  handle {
    respond "Not Found" 404
  }
}
```

### API env (.env)
```bash
ENV=prod
LOG_LEVEL=info

DATABASE_URL=postgresql+psycopg://vibeguard:<POSTGRES_PASSWORD>@postgres:5432/vibeguard
REDIS_URL=redis://redis:6379/0

STRIPE_SECRET_KEY=...
STRIPE_WEBHOOK_SECRET=...

JWT_SIGNING_KEY=...  # long random
LICENSE_HMAC_KEY=... # long random

BUNDLE_STORAGE_PATH=/app/bundles
```

### Backups
- Daily Postgres dump
- Keep 7 days locally
- Sync off-server (S3/Backblaze/second box)

---

## Definition of Done (next milestone)

### Server
- [ ] `/healthz` returns 200
- [ ] Stripe webhook creates/updates:
  - user, customer, subscription, license
- [ ] `/v1/licenses/activate`:
  - validates license
  - enforces max activations
  - returns JWT + entitlements
- [ ] `/v1/licenses/refresh-token` works
- [ ] `/v1/bundles/latest` delivers a bundle to entitled clients
- [ ] revocation path exists (admin script is OK for v1)

### CLI
- [ ] `vibeguard auth login/status/logout` works
- [ ] Pro commands (`patch`, `apply`) require entitlement token
- [ ] Offline grace works exactly as specified
- [ ] Bundles are fetched and cached; patch prompts read from bundle

### Tests
- [ ] Unit tests for token store + refresh logic
- [ ] Unit tests for bundle cache logic
- [ ] CLI integration tests for auth flow (mock server)

---

## Safety / Non-Goals (still true)
- No uploading repo code to VibeGuard servers in 3A.
- No auto-apply patches; user must run `apply`.
- No invasive telemetry.

---

## Notes on UX
- Follow existing Rich/Questionary styling and “helpful error” patterns.
- Keep copy concise and actionable: always show the exact next command the user should run.
