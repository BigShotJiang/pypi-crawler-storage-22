"""VibeGuard CLI - Unified security scanner orchestrator."""

__version__ = "1.0.4"
