"""CLI commands for VibeGuard."""
