"""Core utilities for VibeGuard."""
