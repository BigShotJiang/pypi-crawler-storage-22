"""Tests for VibeGuard CLI."""
