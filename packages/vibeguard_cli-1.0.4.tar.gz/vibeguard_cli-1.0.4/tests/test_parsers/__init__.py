"""Parser tests for VibeGuard."""
