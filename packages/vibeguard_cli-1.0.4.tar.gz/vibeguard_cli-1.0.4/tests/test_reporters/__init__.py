"""Tests for report generators."""
