# VibeGuard - Remaining Work Plan

**Last Updated**: 2026-02-06

## Priority Order

### P0 — Ship Blockers (do first)
1. [x] **v1.0.5 Scanner fixes** — Trivy download + pipx venv discovery ✅
2. [x] **Panel Vercel redeploy** ✅ — Auth fixes + admin wiring + scan history pushed, Vercel auto-deploys
3. [x] **Panel build verification** ✅ — Both apps compile clean with `pnpm build`

### P1 — Panel Polish
4. [x] **Add VibeGuard logo to panels** ✅ — Real logo replaces placeholder Shield icon
   - Fixed admin refund type error (payments page build failure)

### P2 — End-to-End & Testing
5. [ ] **End-to-end test** — CLI scan → API submission → Panel display
   - Run `vibeguard scan .` with a Pro license
   - Verify scan appears in panel scan history page
6. [ ] **CLI integration tests for auth flow** — Mock server tests

### P3 — Growth Features
7. [ ] **GitHub Marketplace listing** — Publish `action.yml` as a reusable GitHub Action
8. [ ] **Additional ecosystem scanners** — gosec (Go), brakeman (Ruby)
9. [ ] **Enhanced `live` mode** — More Nuclei template categories

### P4 — Future Tier
10. [ ] **Correlation/confidence scoring** — Cross-scanner correlation for Team tier
11. [ ] **Team tier features** — Multi-user, org-level dashboards
