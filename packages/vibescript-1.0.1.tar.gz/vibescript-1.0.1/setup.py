"""
VibeScript Setup - Legacy setup.py for backward compatibility
For modern installs, use pyproject.toml
"""
import os
from setuptools import setup, find_packages

setup(
    name="vibescript",
    version="1.0.1",
    packages=find_packages(),
    install_requires=[
        "google-genai>=0.3.0",
        "pydantic>=2.0.0",
        "typer[all]>=0.9.0",
        "rich>=13.0.0",
        "watchdog>=3.0.0",
    ],
    entry_points={
        "console_scripts": [
            "vibe=vibescript.cli:app",
        ],
    },
    python_requires=">=3.10",
    author="Beri Dayan",
    author_email="beridayan2008@gmail.com",
    description="Transform intent into production code - The Vibe-to-Code compiler",
    long_description=open("README.md", encoding="utf-8").read() if os.path.exists("README.md") else "",
    long_description_content_type="text/markdown",
    url="https://github.com/your-org/vibescript",
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Developers",
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
    ],
)

