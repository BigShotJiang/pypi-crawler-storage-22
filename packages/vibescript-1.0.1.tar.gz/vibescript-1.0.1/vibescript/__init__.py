"""
VibeScript V4 - Transform Intent into Production Code
"""
__version__ = "1.0.0"
__author__ = "Beri Dayan"
__email__ = "beridayan2008@gmail.com"

from vibescript.cli import app

__all__ = ["app"]
