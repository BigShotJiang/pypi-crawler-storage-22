"""
VibeScript V4 CLI — Production-Ready Developer Tool
Transforms .vibe files into production-ready Next.js/Prisma or FastAPI code.

Features:
- Modern CLI with Typer (init, build, dev, doctor, version)
- Beautiful output with Rich (progress bars, tables, panels)
- Watch mode for auto-recompilation
- Graceful error handling
- Config file support (vibe.config.json)
"""
import json
import os
import re
import sys
import time
from pathlib import Path
from typing import List, Set, Optional
from datetime import datetime

import typer
from rich.console import Console
from rich.progress import Progress, SpinnerColumn, TextColumn
from rich.table import Table
from rich.panel import Panel
from rich import print as rprint
from watchdog.observers import Observer
from watchdog.events import FileSystemEventHandler

from google import genai
from google.genai import types
from pydantic import BaseModel, TypeAdapter, ValidationError

# Initialize CLI app and console
app = typer.Typer(
    name="vibe",
    help="VibeScript V4 — Transform intent into production code",
    add_completion=False,
)
# Configure console with Windows compatibility
console = Console(
    force_terminal=True,
    legacy_windows=False,
)

# Version constant
VIBESCRIPT_VERSION = "4.0.0"

# ---------------------------------------------------------------------------
# RESERVED KEYWORDS (Pre-Processor validation)
# ---------------------------------------------------------------------------
RESERVED_METADATA = {"@platform", "@app", "@version", "@auth", "@db"}
REQUIRED_BLOCKS_FOR_WEB = ("[Data", "[UI", "[Logic", "[Theme]")

# Supported @db values → Prisma provider name
SUPPORTED_DATABASES = {
    "sqlite": "sqlite",
    "postgresql": "postgresql",
    "postgres": "postgresql",
    "mysql": "mysql",
    "cockroachdb": "cockroachdb",
}
DB_SOURCE_VALUES = {"local", "url"}

# ---------------------------------------------------------------------------
# DEPENDENCY MAPPING (V4 Feature: Pre-computation Dependency Scanner)
# ---------------------------------------------------------------------------
VIBE_TO_NPM = {
    # UI Components
    "calendar": ["@fullcalendar/react", "@fullcalendar/core", "@fullcalendar/daygrid", "@fullcalendar/timegrid", "@fullcalendar/interaction"],
    "richtext:editor": ["@tiptap/react", "@tiptap/starter-kit", "@tiptap/extension-link", "@tiptap/extension-image"],
    "drag:drop": ["@dnd-kit/core", "@dnd-kit/sortable", "@dnd-kit/utilities"],
    "map": ["react-map-gl", "mapbox-gl"],
    "chart:bar": ["recharts"],
    "chart:line": ["recharts"],
    "chart:pie": ["recharts"],
    "chart": ["recharts"],
    "table": ["@tanstack/react-table"],
    "datepicker": ["react-day-picker", "date-fns"],
    "infinite:scroll": ["react-intersection-observer"],
    "form": ["react-hook-form", "zod", "@hookform/resolvers"],
    "ws:connect": ["ws"],
    "ws:send": ["ws"],
    "presence:detect": ["ws"],
    "typing:indicator": ["ws"],
    "indexedDB:store": ["idb"],
    "video:player": ["react-player"],
    "audio:record": ["recordrtc"],
    "ship:toast": ["sonner"],
    "ai:generate": ["openai"],
    "ai:embed": ["openai"],
    "ai:classify": ["openai"],
    "ai:stream": ["openai"],
    "billing:charge": ["stripe"],
    "process:payment": ["stripe"],
    "sms:send": ["twilio"],
    "email:send": ["nodemailer"],
    "geocode": ["@googlemaps/google-maps-services-js"],
    "geolocate": ["@googlemaps/google-maps-services-js"],
}

CORE_NEXTJS_DEPS = {
    "next": "14.2.3",
    "react": "^18",
    "react-dom": "^18",
    "typescript": "^5",
    "@types/node": "^20",
    "@types/react": "^18",
    "@types/react-dom": "^18",
    "prisma": "^5.19.0",
    "@prisma/client": "^5.19.0",
    "tailwindcss": "^3.4.1",
    "autoprefixer": "^10.4.14",
    "postcss": "^8.4.31",
    "lucide-react": "^0.378.0",
    "class-variance-authority": "^0.7.0",
    "clsx": "^2.1.1",
    "tailwind-merge": "^2.3.0",
}

SHADCN_DEPS = {
    "@radix-ui/react-dialog": "^1.0.5",
    "@radix-ui/react-separator": "^1.0.3",
    "@radix-ui/react-tabs": "^1.0.4",
    "@radix-ui/react-dropdown-menu": "^2.0.6",
    "@radix-ui/react-tooltip": "^1.0.7",
    "@radix-ui/react-popover": "^1.0.7",
    "@radix-ui/react-select": "^2.0.0",
    "@radix-ui/react-label": "^2.0.2",
    "@radix-ui/react-slot": "^1.0.2",
}

# Template .vibe file for `vibe init`
TEMPLATE_VIBE = '''// METADATA
@platform "web-nextjs"
@app "MyApp"
@db "sqlite" local
@version "1.0.0"

// DATA MODEL
[Data: Task]
  id: uuid
  title: text
  description: text:long
  status: enum(todo, in_progress, done)
  createdAt: datetime

// UI
[UI: TaskPage]
  layout: split(sidebar, main, 1/4)
  
  sidebar:
    layout: stack(4)
    list(tasks, TaskCard)
  
  main:
    form(createTaskForm)
    table(tasks, [title, status, createdAt])

// LOGIC
[Logic: TaskActions]
  submit:createTaskForm -> 
    validate(),
    create:db(task),
    ship:toast(success, "Task created!"),
    close:modal(createForm)
  
  click:deleteBtn -> 
    delete:db(taskId),
    ship:toast(success, "Deleted")

// THEME
[Theme]
  vibe: "zen-minimalist"
  colors.accent: hsl(160 40% 45%)
'''

# ---------------------------------------------------------------------------
# HELPER FUNCTIONS
# ---------------------------------------------------------------------------

def load_config() -> dict:
    """Load vibe.config.json if it exists"""
    config_path = Path("vibe.config.json")
    if config_path.exists():
        try:
            return json.loads(config_path.read_text())
        except Exception as e:
            console.print(f"[yellow]Warning: Could not parse vibe.config.json: {e}[/yellow]")
    return {}

def scan_dependencies(code: str) -> Set[str]:
    """V4 FEATURE: Pre-computation Dependency Scanner"""
    required_packages = set()
    code_lower = code.lower()
    
    for keyword, packages in VIBE_TO_NPM.items():
        pattern = r'\b' + re.escape(keyword.replace(':', r'\:')) + r'\b'
        if re.search(pattern, code_lower):
            required_packages.update(packages)
    
    return required_packages

def preprocess_vibe(code: str) -> dict:
    """Parse .vibe file for metadata and structure"""
    result = {
        "platform": "web-nextjs",
        "app": "VibeApp",
        "db": "sqlite",
        "db_source": "local",
        "auth": None,
        "version": None,
        "valid": True,
        "errors": [],
        "required_packages": set(),
    }
    
    for line in code.split("\n"):
        stripped = line.strip()
        
        if stripped.startswith("@platform"):
            match = re.search(r'@platform\s+"([^"]+)"', stripped)
            if match:
                result["platform"] = match.group(1).strip()
        
        elif stripped.startswith("@app"):
            match = re.search(r'@app\s+"([^"]+)"', stripped)
            if match:
                result["app"] = match.group(1).strip()
        
        elif stripped.startswith("@version"):
            match = re.search(r'@version\s+"([^"]+)"', stripped)
            if match:
                result["version"] = match.group(1).strip()
        
        elif stripped.startswith("@auth"):
            match = re.search(r'@auth\s+"([^"]+)"', stripped)
            if match:
                result["auth"] = match.group(1).strip()
        
        elif stripped.startswith("@db"):
            match = re.search(r'@db\s+"([^"]+)"(?:\s+(local|url))?', stripped, re.IGNORECASE)
            if match:
                raw = match.group(1).strip().lower()
                source = (match.group(2) or "").strip().lower()
                if raw in SUPPORTED_DATABASES:
                    result["db"] = SUPPORTED_DATABASES[raw]
                else:
                    result["errors"].append(
                        f"Unsupported @db \"{raw}\". Choose one of: "
                        f"{', '.join(SUPPORTED_DATABASES.keys())}"
                    )
                
                if source in DB_SOURCE_VALUES:
                    result["db_source"] = source
                elif not source:
                    result["db_source"] = "local" if result["db"] == "sqlite" else "url"
                else:
                    result["errors"].append(
                        f"Invalid @db source \"{source}\". Choose 'local' or 'url'."
                    )
    
    # Validate required blocks for web platforms
    if result["platform"] in ["web-nextjs", "web-react"]:
        for block in REQUIRED_BLOCKS_FOR_WEB:
            if block not in code:
                result["errors"].append(f"Missing required block: {block}")
    
    # Scan dependencies
    result["required_packages"] = scan_dependencies(code)
    
    if result["errors"]:
        result["valid"] = False
    
    return result

class GeneratedFile(BaseModel):
    path: str
    content: str

def clean_json_response(raw: str) -> str:
    print(raw)
    """Clean markdown code blocks from JSON response"""
    if raw is None:
        return ""
    text = raw.strip()
    # Remove leading/trailing fenced code block markers if present.
    lines = text.split("\n")
    if lines and lines[0].startswith("```"):
        lines = lines[1:]
    if lines and lines[-1].strip() == "```":
        lines = lines[:-1]
    text = "\n".join(lines).strip()
    # Extract the first JSON array if extra text remains.
    start = text.find("[")
    end = text.rfind("]")
    if start != -1 and end != -1 and end > start:
        text = text[start:end + 1]
    return text

def try_repair_truncated_json(s: str) -> str:
    """Try to close a truncated JSON array so it can be parsed (avoids a full retry)."""
    if s is None:
        return ""
    s = s.strip()
    if not s:
        return s
    if s.endswith("]"):
        return s
    # Remove trailing incomplete key or comma
    s = s.rstrip()
    while s and s[-1] in (",", "\n", " "):
        s = s.rstrip()
        if s.endswith(","):
            s = s[:-1].rstrip()
    if not s.endswith("]"):
        s = s + "]"
    return s

def _run_one_request(client, model_name: str, prompt: str, config: dict, use_stream: bool) -> str:
    """Execute single API request (streaming or sync)"""
    if use_stream:
        response = client.models.generate_content_stream(
            model=model_name,
            contents=prompt,
            config=types.GenerateContentConfig(**config),
        )
        chunks = []
        for chunk in response:
            if chunk.text:
                chunks.append(chunk.text)
        return "".join(chunks) or ""
    else:
        response = client.models.generate_content(
            model=model_name,
            contents=prompt,
            config=types.GenerateContentConfig(**config),
        )
        return response.text or ""

# Import system prompts (truncated for brevity - keeping original logic)
SYSTEM_PROMPT_NEXTJS =   """
You are the VibeScript V4 Compiler. Convert .vibe code into a Production-Ready Next.js 14 application.
Output a JSON array of files:
[
  {"path": "package.json", "content": "..."},
  {"path": "app/page.tsx", "content": "..."}
]

Your output must be an original compilation of the user's VibeScript input—generate new code that implements the spec. Do not reproduce existing codebases; transform only what the .vibe file describes.

### CRITICAL RULES
1. **NO 'any' TYPES** — Generate explicit TypeScript interfaces for all props. Import types from '@prisma/client'. Use `unknown` only where type is truly dynamic; never use `any`.

2. **DEPENDENCY PINNING** — In package.json use exactly:
    - "next": "14.2.3", "react": "^18", "react-dom": "^18"
    - "typescript": "^5", "@types/node": "^20", "@types/react": "^18", "@types/react-dom": "^18"
    - "prisma": "^5.19.0", "@prisma/client": "^5.19.0"
    - "tailwindcss": "^3.4.1", "autoprefixer": "^10.4.14", "postcss": "^8.4.31"
    - "lucide-react": "^0.378.0", "class-variance-authority": "^0.7.0", "clsx": "^2.1.1", "tailwind-merge": "^2.3.0"
    - Shadcn/UI Radix: "@radix-ui/react-dialog": "^1.0.5", "@radix-ui/react-separator": "^1.0.3", "@radix-ui/react-tabs": "^1.0.4", "@radix-ui/react-dropdown-menu": "^2.0.6", "@radix-ui/react-tooltip": "^1.0.7", "@radix-ui/react-popover": "^1.0.7", "@radix-ui/react-select": "^2.0.0", "@radix-ui/react-label": "^2.0.2", "@radix-ui/react-slot": "^1.0.2"
    - **REQUIRED PACKAGES FROM SCAN**: {required_packages}
    - **CRITICAL**: You MUST include ALL packages listed in REQUIRED_PACKAGES FROM SCAN in the package.json dependencies. These were detected from the user's .vibe file and are essential for the generated code to work.

3. **DATA FETCHING** — page.tsx must be an async Server Component that fetches via Prisma. Charts receive real aggregated data props.

4. **SERVER vs CLIENT COMPONENTS** — 
   - Server Components CANNOT pass functions (event handlers, callbacks like onSuccess) to Client Components.
   - When a page uses a modal/dialog that contains a form with a callback (e.g. onSuccess to close the dialog), emit a wrapper Client Component (e.g. CreateXxxDialog) that contains the entire Dialog + DialogTrigger + DialogContent + form and passes the callback only inside that component. The page (Server Component) must only render that wrapper with no function props.
   - For clickable list items or buttons, emit a Client Component wrapper that owns the onClick handler.
   - NEVER put onClick or other event handlers directly in Server Components.

5. **FONTS** — In styles/globals.css do not use @font-face with url('/fonts/...') unless you also emit that file under public/fonts/. Prefer system font stacks (e.g. system-ui, -apple-system, 'Segoe UI', Roboto, sans-serif) for --font-sans and ui-monospace for --font-mono, or add a <link> to Google Fonts in app/layout.tsx; never reference local font paths that are not generated.

6. **SQLITE ENUM HANDLING** —
   - SQLite does NOT support native Prisma enums.
   - When the database is sqlite and the user defines enum(a,b,c), DO NOT create an enum in schema.prisma.
   - Instead: use String type in Prisma, and enforce validation using Zod enum in the validation schema.
   - Example: status: enum(draft,published) → in Prisma: status String, in Zod: z.enum(['draft', 'published'])

### LIBRARY MAPPING (NO GUESSING)
The compiler has detected required libraries and YOU MUST use these specific implementations:

**UI Components:**
- calendar() → @fullcalendar/react with dayGridPlugin, timeGridPlugin, interactionPlugin
- richtext:editor() → @tiptap/react with starter-kit
- drag:drop() → @dnd-kit/core with sortable and utilities
- map() → react-map-gl with mapbox-gl
- chart:bar(), chart:line(), chart:pie(), chart() → recharts (BarChart, LineChart, PieChart)
- table() → @tanstack/react-table with sorting, filtering, pagination
- datepicker() → react-day-picker with date-fns
- infinite:scroll() → react-intersection-observer
- form() → react-hook-form + zod + @hookform/resolvers (zodResolver)

**Real-Time & WebSocket:**
- ws:connect(), ws:send(), ws:on() → ws library (WebSocket client)
- presence:detect(), typing:indicator() → WebSocket-based presence system

**State & Storage:**
- indexedDB:store() → idb library for IndexedDB operations

**Media:**
- video:player() → react-player
- audio:record() → recordrtc

**Notifications:**
- ship:toast() → sonner library (toast.success, toast.error, etc.)

**AI Integration:**
- ai:generate(), ai:embed(), ai:classify(), ai:stream() → openai library

**Payment:**
- billing:charge(), process:payment() → stripe library

**Communication:**
- sms:send() → twilio
- email:send() → nodemailer

**Geolocation:**
- geocode(), geolocate() → @googlemaps/google-maps-services-js

### REQUIRED OUTPUT FILE STRUCTURE (generate all that apply from the .vibe file)
- **prisma/schema.prisma** — From [Data] blocks: Prisma schema with uuid, ref:, relation:many, enum(), etc. Use Prisma 5 syntax. Set datasource provider and url from the Database: line (see Metadata). **IMPORTANT**: If database is sqlite, do NOT use enum type; use String and validate with Zod.
- **lib/validations/*.ts or lib/schemas.ts** — Zod schemas derived from [Data] for form/API validation. If sqlite + enum(), use z.enum() here.
- **app/actions/*.ts** — Server Actions with "use server": create, update, delete, soft:delete, revalidatePath, and any fetch:db/create:db/update:db/delete:db from [Logic].
- **app/**/page.tsx** — Pages as async Server Components; **app/layout.tsx** — Root layout.
- **components/ui/** — Shadcn/ui + Tailwind: from [UI] macros (split, stack, grid, list, form, modal, table, tabs, chart:bar, etc.). **CRITICAL**: For every `@/components/ui/X` that any generated file imports, you MUST emit the file **components/ui/X.tsx**. In particular: if any component imports from `@/components/ui/dialog` (Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, etc.), you MUST emit **components/ui/dialog.tsx** implementing the shadcn Dialog primitive (using * from "@radix-ui/react-dialog"). Same for button, input, label, form, etc.—emit the corresponding components/ui/*.tsx for every ui import used.
- **components/** — Custom components for list items, cards, etc. If clickable, must be Client Components with "use client".
- **lib/websocket.ts** — If ws:connect is used, create WebSocket client utilities.
- **lib/stripe.ts** — If billing:charge or process:payment is used, create Stripe utilities.
- **styles/globals.css** — From [Theme]: Emit CSS variables for all theme tokens (colors.*, spacing.*, borderRadius.*, shadows.*, typography.*, borders.weight.*). Support vibe presets ("zen-minimalist", "neon-punk", etc.) and full custom themes where the user defines tokens directly in the [Theme] block.
- **tsconfig.json** — MUST include path alias so that @/ resolves: in compilerOptions set "baseUrl": "." and "paths": { "@/*": ["./*"] }. This is required for imports like "@/styles/globals.css" and "@/components/...". If you emit a tsconfig, always include these.
- **.env.example** — Database connection string template based on db_source.
- **package.json** — ALL detected dependencies + core dependencies.

### VIBE LANGUAGE SPEC

A. **Metadata**
- @platform "web-nextjs" → Next.js 14 App Router, Prisma, Tailwind.
- @auth "google-oauth" → (Future: NextAuth.js setup; for now, note in comments)
- @version "1.0.0" → (Future: Compatibility checks; for now, note in comments)
- **Database (@db)**: The user message may include "Database: <provider>, source: local" or "source: url". Use it for prisma/schema.prisma and .env.example:
  - **source: local** — sqlite: url = "file:./dev.db", no .env needed. postgresql/mysql/cockroachdb: url = env("DATABASE_URL"), .env.example with localhost (e.g. postgresql://user:pass@localhost:5432/mydb).
  - **source: url** — url = env("DATABASE_URL"), .env.example with a generic placeholder (e.g. postgresql://USER:PASSWORD@HOST:5432/DATABASE?schema=public). For sqlite, url = env("DATABASE_URL") so user can set path via env.
  - **Database: sqlite** (local) → provider = "sqlite", url = "file:./dev.db". (url) → url = env("DATABASE_URL").
  - **Database: postgresql/mysql/cockroachdb** — provider as named; url = env("DATABASE_URL"); .env.example localhost for local, generic host for url.
  If no Database line is given, default to sqlite, source local.

B. **[Data]** → Prisma Schema + Zod
- Generate prisma/schema.prisma. uuid → String @id @default(uuid()). ref:Model → relation. relation:many(Model) → Model[]. 
- **enum(a,b)**: If database is NOT sqlite → create enum in Prisma. If database IS sqlite → use String in Prisma, enforce with z.enum() in Zod.
- Generate Zod schemas for all create/update payloads (no 'any'; use z.infer for types).

C. **[UI]** → Shadcn + Tailwind
- layout: split(left, right, ratio?) → flex layout with ratio-based widths.
- layout: stack(spacing?) → flex flex-col with gap.
- layout: grid(cols, gap?) → grid grid-cols-X gap-Y.
- list(items, component) → items.map with typed component. If items are clickable, component must be Client Component.
- form(fields[], onSubmit) → React Hook Form + Zod + @hookform/resolvers.
- modal(trigger, content) → Radix Dialog. **You MUST emit components/ui/dialog.tsx** (re-exporting Dialog, DialogTrigger, DialogContent, DialogHeader, DialogTitle, DialogFooter from @radix-ui/react-dialog with Tailwind styling and DialogPrimitive.Root as Dialog) whenever any generated code imports from "@/components/ui/dialog". Without this file, builds fail with "Can't resolve '@/components/ui/dialog'". When the modal contains a form that takes a callback (onSuccess), emit a single Client Component (e.g. CreateXxxDialog) that wraps Dialog + DialogTrigger + DialogContent + the form and passes onSuccess inside the client boundary; the Server Component page must only render <CreateXxxDialog /> with no function props.
- table(data, cols) → TanStack Table (@tanstack/react-table).
- tabs(items[]) → Radix Tabs.
- chart:bar(data), chart:line(data), chart:pie(data) → Recharts with typed data.
- calendar() → FullCalendar with plugins.
- richtext:editor() → TipTap editor.
- drag:drop() → dnd-kit implementation.
- map() → react-map-gl with Mapbox.

D. **[Logic]** → Server Actions & Advanced Logic
- fetch:db(query) → Prisma findMany in Server Action.
- create:db(data), update:db(mutation), delete:db(id) → Server Actions with "use server", revalidatePath.
- **soft:delete(model, id)** → Server Action that updates isDeleted=true (or deletedAt=DateTime) instead of removing the record. Requires the model to have an isDeleted: Boolean or deletedAt: DateTime? field.
- filter:db(model, criteria), search:db(model, query), sort:db(model, field, order), paginate:db(model, page, size) → Prisma queries in Server Actions.
- aggregate:db(model, func, field), groupBy:db(model, field), upsert:db(model, data), bulk:create(model, items) → Prisma operations.
- ship:toast(type, message) → sonner toast.
- open:modal(id), close:modal(id) → Client Component state updates.
- redirect(path) → Next.js router.push or redirect().
- set:state(key, value), toggle:state(key) → React useState.
- update:local(key, value), fetch:local(key) → localStorage.
- validate() → Zod validation.
- check:auth() → Session check with redirect.
- upload:file(field, destination), upload:image(field), download:file(url, name) → File operations.
- if:condition -> action, loop:items -> action → Control flow.
- **ws:connect(url)** → WebSocket connection setup. Create lib/websocket.ts with connection utilities.
- **ws:send(channel, data)** → WebSocket send message.
- **ws:on(event, handler)** → WebSocket event listener.
- **presence:detect()** → User presence tracking via WebSocket.
- **typing:indicator(userId, isTyping)** → Typing status broadcast.
- **billing:charge(customerId, amount)** → Stripe payment. Create lib/stripe.ts with Stripe utilities.
- **process:payment(method, amount)** → Payment processing via Stripe.
- indexedDB:store(key, data), offline:queue(action), sync:resolve(strategy) → Offline/sync operations.
- undo:action(), redo:action(), share:state(key) → State management.
- transaction:db(operations[]) → Prisma.$transaction([...]).
- process:file(file, parser), image:edit(file, transforms) → File processing.
- ai:generate(prompt), ai:embed(text), ai:classify(input, categories), ai:stream(prompt) → AI operations using openai.
- vector:search(embedding, limit) → Vector search (requires vector DB setup).
- geocode(address), geolocate() → Geolocation using Google Maps.
- sms:send(to, message) → SMS via Twilio.
- email:send(to, subject, body) → Email via nodemailer.

E. **[Theme]** → globals.css
- Users may use a preset: vibe: "zen-minimalist" | "neon-punk" | "corp-clean" | "nordic-light" | "brutalist-mono" | "retro-terminal" | "gradient-modern" | "glassmorphism" | "neomorphism" | "dark-mode" (and 30+ others from the theme library). Each preset maps to concrete CSS variables.
- Users may also create FULL CUSTOM THEMES by defining any of the tokens below directly in the [Theme] block. Support every token listed; emit CSS variables (e.g. --color-primary, --spacing-unit) in styles/globals.css and use them in Tailwind/shadcn.
- **Theme tokens to support (custom themes):**
  - **Colors**: colors.primary, colors.secondary, colors.accent, colors.accent.secondary, colors.accent.tertiary, colors.background, colors.surface, colors.border, colors.text.primary, colors.text.secondary, colors.text.muted
  - **Spacing**: spacing.unit, spacing.section, spacing.container
  - **Border radius**: borderRadius.default, borderRadius.lg, borderRadius.full
  - **Borders**: borders.weight.default, borders.weight.heavy, borders.weight.neon (optional)
  - **Shadows**: shadows.sm, shadows.md, shadows.lg, shadows.neon (optional)
  - **Typography**: typography.fontFamily.sans, typography.fontFamily.serif, typography.fontFamily.mono, typography.fontSize.base, typography.lineHeight.base, typography.fontWeight.normal, typography.fontWeight.medium, typography.fontWeight.bold, typography.textTransform.caps (optional)
- If the user specifies both vibe: "preset" and overrides (e.g. colors.accent: hsl(200 60% 50%)), merge: apply preset then override with the custom tokens from the [Theme] block.
- Fonts: Use system font stacks or a <link> to Google Fonts in app/layout.tsx; avoid local @font-face unless font files are emitted.

### COMPILATION GUARANTEES
1. All files use correct imports (no missing dependencies).
2. TypeScript has no 'any' types (explicit interfaces everywhere).
3. Server/Client boundaries are respected (no function props Server→Client).
4. Clickable elements are in Client Components with "use client".
5. package.json includes ALL detected dependencies from the scan.
6. tsconfig.json has @/ path alias configured.
7. SQLite databases use String for enums, not Prisma enum type.
8. Forms using react-hook-form include @hookform/resolvers in dependencies.
9. All detected libraries from LIBRARY MAPPING are used correctly.
10. Advanced logic commands (soft:delete, ws:connect, billing:charge) are fully implemented.

Generate complete, working Next.js 14 app with App Router..
"""

SYSTEM_PROMPT_FASTAPI = """You are a FastAPI code generator..."""

def compile_vibe(
    code: str,
    platform: str,
    db: str = "sqlite",
    db_source: str = "local",
    auth: Optional[str] = None,
    version: Optional[str] = None,
    required_packages: Optional[Set[str]] = None,
    relax_safety: bool = False,
    use_stream: bool = True,
) -> str:
    """Compile .vibe code using Gemini API"""
    api_key = os.getenv("GEMINI_API_KEY")
    if not api_key:
        console.print(Panel(
            "[red]GEMINI_API_KEY not set[/red]\n\n"
            "[yellow]How to fix:[/yellow]\n"
            "1. Get API key: [cyan]https://aistudio.google.com/apikey[/cyan]\n"
            "2. Set environment variable:\n\n"
            "[dim]Unix/macOS:[/dim]\n"
            "  export GEMINI_API_KEY=\"your-key-here\"\n\n"
            "[dim]Windows:[/dim]\n"
            "  setx GEMINI_API_KEY \"your-key-here\"\n\n"
            "3. Run [cyan]vibe doctor[/cyan] to verify",
            title="[X] API Key Required",
            border_style="red"
        ))
        raise typer.Exit(1)
    
    # No timeout (match working behavior; optional timeout can cause hang on some systems)
    client = genai.Client(api_key=api_key)
    
    # Format required packages
    packages_str = ", ".join(sorted(required_packages or []))
    
    # Select system prompt
    if platform == "web-nextjs":
        system_prompt = SYSTEM_PROMPT_NEXTJS.replace("{required_packages}", packages_str)
    else:
        system_prompt = SYSTEM_PROMPT_FASTAPI.replace("{required_packages}", packages_str)
    
    # Build user message
    user_message = f"""Platform: {platform}
Database: {db}, source: {db_source}"""
    
    if auth:
        user_message += f"\nAuth: {auth}"
    if version:
        user_message += f"\nVersion: {version}"
    
    user_message += f"\n\n{code}"
    
    prompt = f"{system_prompt}\n\n{user_message}"
    
    # V4: Strict predictability
    base_config = {
        "temperature": 0.0,
        "top_p": 1.0,
        "top_k": 1,
    }
    
    # Model order matching working test.py; then fallbacks for APIs that 404 on "latest" aliases
    models = [
        "gemini-flash-latest",
        "gemini-flash-lite-latest",
        "gemini-pro-latest",
        "gemini-2.5-flash",
        "gemini-2.5-pro",
        "gemini-2.0-flash",
    ]
    
    last_error = None
    for model_name in models:
        try:
            config_kw = base_config.copy()
            if relax_safety:
                config_kw["safety_settings"] = [
                    types.SafetySetting(
                        category=types.HarmCategory.HARM_CATEGORY_DANGEROUS_CONTENT,
                        threshold=types.HarmBlockThreshold.BLOCK_ONLY_HIGH,
                    ),
                    types.SafetySetting(
                        category=types.HarmCategory.HARM_CATEGORY_HARASSMENT,
                        threshold=types.HarmBlockThreshold.BLOCK_ONLY_HIGH,
                    ),
                    types.SafetySetting(
                        category=types.HarmCategory.HARM_CATEGORY_HATE_SPEECH,
                        threshold=types.HarmBlockThreshold.BLOCK_ONLY_HIGH,
                    ),
                    types.SafetySetting(
                        category=types.HarmCategory.HARM_CATEGORY_SEXUALLY_EXPLICIT,
                        threshold=types.HarmBlockThreshold.BLOCK_ONLY_HIGH,
                    ),
                ]
            
            return _run_one_request(client, model_name, prompt, config_kw, use_stream)
            
        except Exception as e:
            last_error = e
            continue
    
    raise RuntimeError(f"All models failed. Last error: {last_error}") if last_error else RuntimeError("All models failed.")

# ---------------------------------------------------------------------------
# CLI COMMANDS
# ---------------------------------------------------------------------------

@app.command()
def init(
    project_name: str = typer.Argument(..., help="Name of the project to initialize"),
    template: str = typer.Option("default", help="Template to use (default, calendar, chat)")
):
    """Initialize a new VibeScript project with template files"""
    
    project_path = Path(project_name)
    
    if project_path.exists():
        console.print(f"[red]Error:[/red] Directory '{project_name}' already exists")
        raise typer.Exit(1)
    
    # Create project directory
    project_path.mkdir(parents=True)
    
    # Write template .vibe file
    vibe_file = project_path / f"{project_name}.vibe"
    vibe_file.write_text(TEMPLATE_VIBE.replace("MyApp", project_name))
    
    # Write .env.example
    env_example = project_path / ".env.example"
    env_example.write_text("GEMINI_API_KEY=your-api-key-here\nDATABASE_URL=file:./dev.db\n")
    
    # Write vibe.config.json
    config_file = project_path / "vibe.config.json"
    config_file.write_text(json.dumps({
        "output_dir": f"{project_name}_app",
        "platform": "web-nextjs",
        "database": "sqlite"
    }, indent=2))
    
    # Success panel
    console.print(Panel.fit(
        f"[green]Success![/green] Project '{project_name}' initialized!\n\n"
        f"Created:\n"
        f"  - {vibe_file.name}\n"
        f"  - .env.example\n"
        f"  - vibe.config.json\n\n"
        f"[cyan]Next steps:[/cyan]\n"
        f"  cd {project_name}\n"
        f"  vibe build {vibe_file.name}",
        title="Success",
        border_style="green"
    ))

@app.command()
def build(
    vibe_file: str = typer.Argument(..., help="Path to .vibe file"),
    skip_validation: bool = typer.Option(False, "--skip-validation", help="Skip structure validation"),
    relax_safety: bool = typer.Option(False, "--relax-safety", help="Use less strict safety filters"),
    stream: bool = typer.Option(False, "--stream", help="Use streaming (faster start, but can hang; default is non-streaming)."),
):
    """Compile a .vibe file into production code"""
    
    vibe_path = Path(vibe_file)
    
    if not vibe_path.exists():
        console.print(f"[red]Error:[/red] File '{vibe_file}' not found")
        raise typer.Exit(1)
    
    # Load config
    config = load_config()
    
    # Read .vibe file
    code = vibe_path.read_text(encoding="utf-8")
    
    # Preprocess
    if not skip_validation:
        with Progress(
            SpinnerColumn(),
            TextColumn("[progress.description]{task.description}"),
            console=console,
        ) as progress:
            task = progress.add_task("Validating .vibe file...", total=None)
            pre = preprocess_vibe(code)
            progress.update(task, completed=True)
        
        if not pre["valid"]:
            console.print("[red]Validation errors:[/red]")
            for err in pre["errors"]:
                console.print(f"  • {err}")
            console.print("\n[yellow]Tip:[/yellow] Run with --skip-validation to compile anyway")
            raise typer.Exit(1)
        
        platform = pre["platform"]
        app_name = pre["app"]
        db = pre["db"]
        db_source = pre.get("db_source", "local")
        auth = pre.get("auth")
        version = pre.get("version")
        required_packages = pre.get("required_packages", set())
        
        # Display metadata table
        metadata_table = Table(title="Project Metadata", show_header=False)
        metadata_table.add_column("Property", style="cyan")
        metadata_table.add_column("Value", style="green")
        
        metadata_table.add_row("Platform", platform)
        metadata_table.add_row("App Name", app_name)
        metadata_table.add_row("Database", f"{db} ({db_source})")
        if auth:
            metadata_table.add_row("Auth", auth)
        if version:
            metadata_table.add_row("Version", version)
        
        console.print(metadata_table)
        
        # Display detected packages
        if required_packages:
            pkg_table = Table(title="Detected Dependencies", show_header=False)
            pkg_table.add_column("Package", style="yellow")
            
            for pkg in sorted(required_packages):
                pkg_table.add_row(pkg)
            
            console.print(pkg_table)
    else:
        platform = "web-nextjs"
        app_name = "VibeApp"
        db = "sqlite"
        db_source = "local"
        auth = None
        version = None
        required_packages = scan_dependencies(code)
    
    # Compile
    try:
        with Progress(
            SpinnerColumn(),
            TextColumn("[progress.description]{task.description}"),
            console=console,
        ) as progress:
            task = progress.add_task("🔧 Compiling with Gemini...", total=None)
            
            raw_json = compile_vibe(
                code,
                platform,
                db=db,
                db_source=db_source,
                auth=auth,
                version=version,
                required_packages=required_packages,
                relax_safety=relax_safety,
                use_stream=stream,
            )
            
            progress.update(task, description="✅ Compilation complete")
        
        console.print("[dim]Parsing and writing files...[/dim]")
        if raw_json is None or (isinstance(raw_json, str) and not raw_json.strip()):
            console.print(Panel(
                "[red]Compilation returned no content.[/red]\n\n"
                "This can happen if the request was cancelled (Ctrl+C), the API timed out, or the model returned an empty response. Try running the build again.",
                title="Error",
                border_style="red"
            ))
            raise typer.Exit(1)
        
        # Parse JSON
        clean_json = clean_json_response(raw_json)
        try:
            files = TypeAdapter(List[GeneratedFile]).validate_json(clean_json)
        except ValidationError as ve:
            if "json_invalid" in str(ve).lower() or "eof" in str(ve).lower():
                # Try repairing truncated JSON (close array) before retrying
                repaired = try_repair_truncated_json(clean_json)
                try:
                    files = TypeAdapter(List[GeneratedFile]).validate_json(repaired)
                except ValidationError:
                    if stream:
                        console.print("[yellow]JSON truncated, retrying without stream (may take 2–5 min)...[/yellow]")
                        with Progress(
                            SpinnerColumn(),
                            TextColumn("[progress.description]{task.description}"),
                            console=console,
                        ) as retry_progress:
                            retry_task = retry_progress.add_task("🔧 Retrying without stream...", total=None)
                            raw_json = compile_vibe(
                                code,
                                platform,
                                db=db,
                                db_source=db_source,
                                auth=auth,
                                version=version,
                                required_packages=required_packages,
                                relax_safety=relax_safety,
                                use_stream=False,
                            )
                            retry_progress.update(retry_task, description="✅ Retry complete")
                        if not raw_json or not (raw_json.strip() if isinstance(raw_json, str) else raw_json):
                            raise RuntimeError("Retry returned no content. Request may have been cancelled or the API returned empty.")
                        clean_json = clean_json_response(raw_json)
                        files = TypeAdapter(List[GeneratedFile]).validate_json(clean_json)
                    else:
                        raise
            else:
                raise
        
        # Write files
        out_dir = vibe_path.parent / config.get("output_dir", f"{vibe_path.stem}_app")
        
        for f in files:
            p = out_dir / f.path.replace("\\", "/").lstrip("/")
            p.parent.mkdir(parents=True, exist_ok=True)
            p.write_text(f.content, encoding="utf-8")
        
        # Success panel
        if platform == "web-nextjs":
            next_steps = f"""cd {out_dir}
npm install
npx prisma generate
npx prisma db push
npm run dev"""
        else:
            next_steps = f"""cd {out_dir}
pip install -r requirements.txt
uvicorn app.main:app --reload"""
        
        console.print(Panel.fit(
            f"[green]Success![/green] App generated successfully!\n\n"
            f"Output: [cyan]{out_dir}[/cyan]\n\n"
            f"[yellow]Next steps:[/yellow]\n{next_steps}",
            title="Build Complete",
            border_style="green"
        ))
        
    except Exception as e:
        console.print(Panel(
            f"[red]Compilation failed:[/red]\n{str(e)}",
            title="Error",
            border_style="red"
        ))
        raise typer.Exit(1)

class VibeFileHandler(FileSystemEventHandler):
    """Watch .vibe files for changes"""
    
    def __init__(self, vibe_file: Path, callback):
        self.vibe_file = vibe_file
        self.callback = callback
        self.last_modified = 0
    
    def on_modified(self, event):
        if event.src_path == str(self.vibe_file):
            # Debounce
            current_time = time.time()
            if current_time - self.last_modified < 1:
                return
            self.last_modified = current_time
            
            console.print(f"\n[cyan]Detected change in {self.vibe_file.name}[/cyan]")
            self.callback()

@app.command()
def dev(
    vibe_file: str = typer.Argument(..., help="Path to .vibe file"),
    relax_safety: bool = typer.Option(False, "--relax-safety", help="Use less strict safety filters"),
):
    """Watch mode: auto-recompile on .vibe file changes"""
    
    vibe_path = Path(vibe_file)
    
    if not vibe_path.exists():
        console.print(f"[red]Error:[/red] File '{vibe_file}' not found")
        raise typer.Exit(1)
    
    # Initial build
    console.print("[green]Starting watch mode...[/green]")
    build(vibe_file, relax_safety=relax_safety)
    
    # Setup file watcher
    def on_change():
        console.print("[yellow]Rebuilding...[/yellow]")
        try:
            build(vibe_file, relax_safety=relax_safety)
        except:
            console.print("[red]Build failed, watching for next change...[/red]")
    
    event_handler = VibeFileHandler(vibe_path, on_change)
    observer = Observer()
    observer.schedule(event_handler, str(vibe_path.parent), recursive=False)
    observer.start()
    
    console.print(f"\n[green]Watching {vibe_file} for changes...[/green]")
    console.print("[dim]Press Ctrl+C to stop[/dim]\n")
    
    try:
        while True:
            time.sleep(1)
    except KeyboardInterrupt:
        observer.stop()
        console.print("\n[yellow]Watch mode stopped[/yellow]")
    
    observer.join()

@app.command()
def doctor():
    """Validate development environment and dependencies"""
    
    console.print(Panel.fit(
        "[bold cyan]VibeScript Environment Doctor[/bold cyan]\n"
        "Checking your development environment...",
        border_style="cyan"
    ))
    
    checks = []
    
    # Check GEMINI_API_KEY
    api_key = os.getenv("GEMINI_API_KEY")
    checks.append({
        "check": "GEMINI_API_KEY",
        "status": "OK" if api_key else "FAIL",
        "details": "Set" if api_key else "Not set (export GEMINI_API_KEY=...)"
    })
    
    # Check Python version
    import sys
    py_version = f"{sys.version_info.major}.{sys.version_info.minor}.{sys.version_info.micro}"
    py_ok = sys.version_info >= (3, 10)
    checks.append({
        "check": "Python Version",
        "status": "OK" if py_ok else "FAIL",
        "details": f"{py_version} {'(OK)' if py_ok else '(Need 3.10+)'}"
    })
    
    # Check Node.js
    try:
        import subprocess
        result = subprocess.run(["node", "--version"], capture_output=True, text=True)
        node_version = result.stdout.strip()
        node_ok = True
    except:
        node_version = "Not found"
        node_ok = False
    
    checks.append({
        "check": "Node.js",
        "status": "OK" if node_ok else "FAIL",
        "details": node_version if node_ok else "Not installed (need 18+)"
    })
    
    # Check Python dependencies
    deps_ok = True
    missing_deps = []
    for dep in ["google-genai", "pydantic", "typer", "rich", "watchdog"]:
        try:
            __import__(dep.replace("-", "_"))
        except:
            deps_ok = False
            missing_deps.append(dep)
    
    checks.append({
        "check": "Python Dependencies",
        "status": "OK" if deps_ok else "FAIL",
        "details": "All installed" if deps_ok else f"Missing: {', '.join(missing_deps)}"
    })
    
    # Display results
    table = Table(title="Environment Status")
    table.add_column("Check", style="cyan")
    table.add_column("Status", style="bold")
    table.add_column("Details")
    
    all_ok = True
    for check in checks:
        status_color = "green" if check["status"] == "OK" else "red"
        table.add_row(
            check["check"],
            f"[{status_color}]{check['status']}[/{status_color}]",
            check["details"]
        )
        if check["status"] == "FAIL":
            all_ok = False
    
    console.print(table)
    
    if all_ok:
        console.print("\n[green]All checks passed! You're ready to build.[/green]")
    else:
        console.print("\n[yellow]Some checks failed. Fix the issues above before compiling.[/yellow]")
        raise typer.Exit(1)

@app.command()
def models():
    """List Gemini models available for compilation (uses GEMINI_API_KEY)"""
    api_key = os.getenv("GEMINI_API_KEY")
    if not api_key:
        console.print("[red]GEMINI_API_KEY not set.[/red] Set it to list models.")
        raise typer.Exit(1)
    try:
        client = genai.Client(
            api_key=api_key,
            http_options=types.HttpOptions(timeout=15_000),
        )
        # Recommended for generateContent (text/code)
        recommended = {"gemini-flash-latest", "gemini-flash-lite-latest", "gemini-pro-latest", "gemini-2.5-flash", "gemini-2.5-pro", "gemini-2.0-flash"}
        console.print("[bold cyan]Models available for VibeScript compile (generateContent):[/bold cyan]\n")
        table = Table(show_header=True, header_style="bold")
        table.add_column("Model", style="cyan")
        table.add_column("Used by default", style="green")
        seen = set()
        for m in client.models.list():
            name = getattr(m, "name", None)
            if not name or not name.startswith("models/"):
                continue
            short = name.replace("models/", "", 1)
            if short in seen or "embedding" in short or "imagen" in short or "veo-" in short or "aqa" in short:
                continue
            seen.add(short)
            default = "Yes" if short in recommended else ""
            table.add_row(short, default)
        console.print(table)
        console.print("\n[dim]Default compile order: gemini-flash-latest → gemini-flash-lite-latest → gemini-pro-latest → gemini-2.5-flash → …[/dim]")
    except Exception as e:
        console.print(f"[red]Failed to list models:[/red] {e}")
        raise typer.Exit(1)

@app.command()
def version():
    """Display VibeScript version and metadata"""
    
    console.print(Panel.fit(
        f"[bold cyan]VibeScript CLI[/bold cyan]\n\n"
        f"Version: [green]{VIBESCRIPT_VERSION}[/green]\n"
        f"Edition: [yellow]Senior Architect[/yellow]\n"
        f"Release: [dim]2026-02-10[/dim]\n\n"
        f"Features:\n"
        f"  - Dependency Scanner\n"
        f"  - Temperature 0.0 (Deterministic)\n"
        f"  - SQLite Enum Handling\n"
        f"  - Client/Server Safety\n"
        f"  - Watch Mode\n\n"
        f"[dim]Learn more: github.com/your-org/vibescript[/dim]",
        title="Version Info",
        border_style="cyan"
    ))

if __name__ == "__main__":
    app()
