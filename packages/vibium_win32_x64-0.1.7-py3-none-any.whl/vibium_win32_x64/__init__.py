"""Vibium clicker binary for Windows x64."""

from pathlib import Path

__version__ = "0.1.7"

def get_binary_path() -> str:
    """Get the path to the clicker binary."""
    return str(Path(__file__).parent / "bin" / "clicker.exe")
