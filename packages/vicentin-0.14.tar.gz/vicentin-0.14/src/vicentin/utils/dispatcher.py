from typing import Any, Callable, Dict, List, Optional, Tuple

SUPPORTED_BACKENDS = {
    "np": "np",
    "numpy": "np",
    "torch": "torch",
    "pytorch": "torch",
    "jax": "jax",
}


class Dispatcher:
    def __init__(self):
        self._registry: Dict[str, Tuple[Callable, Optional[Callable]]] = {}

        self.backend = None
        self.dtype = None
        self.device = None

    def register(
        self,
        backend_name: str,
        func: Callable,
        transformer: Optional[Callable] = None,
    ):
        if backend_name.lower() in SUPPORTED_BACKENDS.keys():
            self._registry[SUPPORTED_BACKENDS[backend_name.lower()]] = (
                func,
                transformer,
            )

    def detect_backend(self, arg: Any, backend: Optional[str] = None):
        try:
            if (
                backend is not None
                and backend.lower() in SUPPORTED_BACKENDS.keys()
            ):
                self.backend = SUPPORTED_BACKENDS[backend.lower()]
            else:
                self.backend = SUPPORTED_BACKENDS[
                    arg.__class__.__module__.lower()
                ]
        except KeyError:
            self.backend = ""

        if self.backend not in self._registry.keys():
            self.backend = list(self._registry.keys())[-1]

        self.dtype = getattr(arg, "dtype", None)
        self.device = getattr(arg, "device", None)

    def _cast_value(self, value: Any, target_backend: str) -> Any:
        if value is None:
            return None

        if isinstance(value, (list, tuple)):
            return [self._cast_value(v, target_backend) for v in value]

        if target_backend == "torch":
            import numpy as np
            import torch

            if not torch.is_tensor(value):
                try:
                    return torch.as_tensor(
                        np.copy(value), dtype=self.dtype, device=self.device
                    )
                except TypeError:
                    return torch.as_tensor(np.copy(value))
            return value

        elif target_backend == "jax":
            import jax.numpy as jnp

            return jnp.array(value, dtype=self.dtype)

        elif target_backend == "np":
            import numpy as np

            return np.array(value, dtype=self.dtype)

        return value

    def cast_values(self, *args) -> List[Any]:
        if self.backend is None:
            raise TypeError(
                "Dispatcher did not detect any backends. Please call `detect_backend` first."
            )

        casted_args = []

        for arg in args:
            casted_args.append(self._cast_value(arg, self.backend))

        if len(args) == 1:
            return casted_args[0]

        return casted_args

    def __call__(self, *args, **kwargs):
        if self.backend is None:
            raise TypeError(
                "Dispatcher did not detect any backends. Please call `detect_backend` first."
            )

        func, transformer = self._registry[self.backend]

        if transformer:
            args, kwargs = transformer(*args, **kwargs)

        return func(*args, **kwargs)
