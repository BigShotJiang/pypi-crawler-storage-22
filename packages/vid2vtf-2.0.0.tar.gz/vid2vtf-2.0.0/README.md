Make Sure FFMPEG is Installed.

```cmd
  --video VIDEO
  --fps FPS
  --width WIDTH
  --height HEIGHT
  --output_filename OUTPUT_FILENAME
  --output_dir OUTPUT_DIR
```