## Task

Evaluate this code review comment. Read the source file and determine if the issue is valid.

**Instructions:**
1. Read the file mentioned in the review: `packages/providers/fal/avatar-generation/fal_avatar/models/grok.py`
2. Check line 128 and surrounding context
3. Determine if the review feedback is valid
4. If valid: Fix the issue in the code
5. If invalid: Explain why the feedback doesn't apply

**Important:** Be concise. Either fix the code or explain in 2-3 sentences why it's not applicable.

---

# Review Comment

- **Author:** coderabbitai[bot]
- **File:** `packages/providers/fal/avatar-generation/fal_avatar/models/grok.py`
- **Line:** 128
- **Date:** 2026-01-30
- **Comment ID:** 2744842939
- **URL:** https://github.com/donghaozhang/video-agent-skill/pull/14#discussion_r2744842939

---

_⚠️ Potential issue_ | _🟠 Major_

**Guard against `None` or non-numeric durations from the API.** If `video_info["duration"]` is present but `None`, `estimate_cost()` will throw when calling `min(...)`.  
