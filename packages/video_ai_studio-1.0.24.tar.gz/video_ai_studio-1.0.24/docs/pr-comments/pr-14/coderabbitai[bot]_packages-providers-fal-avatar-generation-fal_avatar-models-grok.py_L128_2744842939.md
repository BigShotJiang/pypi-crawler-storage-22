# Review Comment

- **Author:** coderabbitai[bot]
- **File:** `packages/providers/fal/avatar-generation/fal_avatar/models/grok.py`
- **Line:** 128
- **Date:** 2026-01-30
- **Comment ID:** 2744842939
- **URL:** https://github.com/donghaozhang/video-agent-skill/pull/14#discussion_r2744842939

---

_⚠️ Potential issue_ | _🟠 Major_

**Guard against `None` or non-numeric durations from the API.** If `video_info["duration"]` is present but `None`, `estimate_cost()` will throw when calling `min(...)`.  

<details>
<summary>🛠️ Suggested fix</summary>

```diff
-            video_info = result.get("video", {})
+            video_info = result.get("video", {})
+            duration = video_info.get("duration")
+            if not isinstance(duration, (int, float)):
+                duration = 6
@@
-                duration=video_info.get("duration"),
+                duration=duration,
                 cost=self.estimate_cost(
-                    duration=video_info.get("duration", 6),
-                    input_duration=min(8, video_info.get("duration", 6)),
+                    duration=duration,
+                    input_duration=min(self.max_duration, duration),
                 ),
```
</details>

<details>
<summary>🤖 Prompt for AI Agents</summary>

```
In `@packages/providers/fal/avatar-generation/fal_avatar/models/grok.py` around
lines 117 - 128, The code constructing AvatarGenerationResult can pass None or
non-numeric values from video_info.get("duration") into estimate_cost and min,
causing exceptions; before calling AvatarGenerationResult (inside the method
that builds the response), normalize the raw duration by reading duration_raw =
video_info.get("duration"), converting/validating it to a numeric (e.g., try
float(duration_raw) or fallback to a default like 6 if None/invalid), then use
this sanitized duration_numeric when setting duration, and use min(8,
duration_numeric) (or an int-casted version) for input_duration passed to
estimate_cost so estimate_cost never receives None or non-numeric input; update
references to video_info.get("duration") in the AvatarGenerationResult
construction and the estimate_cost call accordingly (see AvatarGenerationResult
and estimate_cost usages).
```

</details>

<!-- fingerprinting:phantom:poseidon:eagle -->

<!-- This is an auto-generated comment by CodeRabbit -->
