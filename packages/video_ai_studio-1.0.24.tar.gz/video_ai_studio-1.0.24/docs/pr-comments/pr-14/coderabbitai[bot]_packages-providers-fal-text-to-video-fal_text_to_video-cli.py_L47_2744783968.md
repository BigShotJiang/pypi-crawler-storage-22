# Review Comment

- **Author:** coderabbitai[bot]
- **File:** `packages/providers/fal/text-to-video/fal_text_to_video/cli.py`
- **Line:** 47
- **Date:** 2026-01-30
- **Comment ID:** 2744783968
- **URL:** https://github.com/donghaozhang/video-agent-skill/pull/14#discussion_r2744783968

---

_⚠️ Potential issue_ | _🟡 Minor_

**Default duration for Grok Imagine never reaches 6s.**

`--duration` defaults to `"5"` (Line 200), so the `grok_imagine` fallback of 6 seconds is never used. This means users get 5s by default even though the model default is 6s.  


<details>
<summary>🔧 Proposed fix (model-specific defaults)</summary>

```diff
@@
-    gen_parser.add_argument("--duration", "-d", default="5",
-                           help="Video duration (default: 5)")
+    gen_parser.add_argument("--duration", "-d", default=None,
+                           help="Video duration (default: model-specific)")
@@
-    if args.model == "kling_2_6_pro":
-        kwargs["duration"] = args.duration
+    if args.model == "kling_2_6_pro":
+        kwargs["duration"] = args.duration or "5"
@@
-    elif args.model == "grok_imagine":
-        kwargs["duration"] = int(args.duration) if args.duration else 6
+    elif args.model == "grok_imagine":
+        kwargs["duration"] = int(args.duration) if args.duration else 6
@@
-    cost_parser.add_argument("--duration", "-d", default="5",
-                            help="Video duration")
+    cost_parser.add_argument("--duration", "-d", default=None,
+                            help="Video duration (default: model-specific)")
@@
-    if args.model == "kling_2_6_pro":
-        kwargs["duration"] = args.duration
+    if args.model == "kling_2_6_pro":
+        kwargs["duration"] = args.duration or "5"
@@
-    elif args.model == "grok_imagine":
-        kwargs["duration"] = int(args.duration) if args.duration else 6
+    elif args.model == "grok_imagine":
+        kwargs["duration"] = int(args.duration) if args.duration else 6
```
</details>


Also applies to: 135-137

<details>
<summary>🤖 Prompt for AI Agents</summary>

```
In `@packages/providers/fal/text-to-video/fal_text_to_video/cli.py` around lines
44 - 47, The issue is that args.duration has a parser default of "5", so the
grok_imagine branch's fallback to 6 never triggers; update the argument parsing
and the model-specific branches to use a true "no value" sentinel (e.g., make
the --duration argparse default None) or explicitly check for the parser default
and override for model-specific defaults. Concretely: change the argparse
add_argument for --duration to default=None (or detect args.duration is
None/empty) and then in the grok_imagine handling (the block that sets
kwargs["duration"]) set kwargs["duration"] = int(args.duration) if args.duration
is not None else 6; apply the same pattern to the other occurrence around the
135-137 handling so model-specific defaults are respected.
```

</details>

<!-- fingerprinting:phantom:poseidon:eagle -->

<!-- This is an auto-generated comment by CodeRabbit -->
