# Review Comment

- **Author:** gemini-code-assist[bot]
- **File:** `packages/providers/fal/text-to-video/fal_text_to_video/models/grok.py`
- **Line:** 128
- **Date:** 2026-01-30
- **Comment ID:** 2744749352
- **URL:** https://github.com/donghaozhang/video-agent-skill/pull/14#discussion_r2744749352

---

![medium](https://www.gstatic.com/codereviewagent/medium-priority.svg)

The base duration `6` is hardcoded in this method. This can be brittle if the pricing structure in `constants.py` changes. To make this more robust, consider adding a `base_duration` field to the pricing dictionary in `constants.py` and referencing it here. This keeps all pricing-related values together.

For example, in `constants.py`:
```python
"grok_imagine": {
    "type": "per_second",
    "base_duration": 6,
    "base_cost_6s": 0.30,
    "cost_per_additional_second": 0.05
}
```

```suggestion
        base_duration = self.pricing.get("base_duration", 6)
        if duration <= base_duration:
            return base_cost
        else:
            additional_seconds = duration - base_duration
            return base_cost + (additional_seconds * cost_per_additional)
```
