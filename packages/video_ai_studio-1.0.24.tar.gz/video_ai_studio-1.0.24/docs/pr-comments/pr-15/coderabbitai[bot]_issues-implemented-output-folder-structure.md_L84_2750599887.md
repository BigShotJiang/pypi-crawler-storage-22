# Review Comment

- **Author:** coderabbitai[bot]
- **File:** `issues/implemented/output-folder-structure.md`
- **Line:** 84
- **Date:** 2026-02-01
- **Comment ID:** 2750599887
- **URL:** https://github.com/donghaozhang/video-agent-skill/pull/15#discussion_r2750599887

---

_⚠️ Potential issue_ | _🟡 Minor_

**Normalize table spacing and escape wildcard patterns.**

Markdown currently treats some patterns as emphasis and fails MD060 spacing rules.  


<details>
<summary>🛠️ Proposed fix</summary>

```diff
-| File Pattern | Destination |
-|-------------|-------------|
-| generated_image_*.png/jpg | output/images/ |
-| upscaled_*.png, grid_*.png | output/images/ |
-| generated_video_*.mp4/webm | output/videos/ |
-| motion_*.mp4, avatar_*.mp4 | output/videos/ |
-| generated_audio_*.mp3/wav | output/audio/ |
-| tts_*.mp3, voice_*.wav | output/audio/ |
-| *_transcript*.txt | output/transcripts/ |
-| *.srt, *.vtt | output/transcripts/ |
-| *_words.json, *_raw.json | output/transcripts/ |
-| *_analysis*.md/json | output/analysis/ |
-| *_timeline*.md/json | output/analysis/ |
+| File Pattern | Destination |
+| ----------- | ----------- |
+| `generated_image_*.png` / `generated_image_*.jpg` | output/images/ |
+| `upscaled_*.png`, `grid_*.png` | output/images/ |
+| `generated_video_*.mp4` / `generated_video_*.webm` | output/videos/ |
+| `motion_*.mp4`, `avatar_*.mp4` | output/videos/ |
+| `generated_audio_*.mp3` / `generated_audio_*.wav` | output/audio/ |
+| `tts_*.mp3`, `voice_*.wav` | output/audio/ |
+| `*_transcript*.txt` | output/transcripts/ |
+| `*.srt`, `*.vtt` | output/transcripts/ |
+| `*_words.json`, `*_raw.json` | output/transcripts/ |
+| `*_analysis*.md` / `*_analysis*.json` | output/analysis/ |
+| `*_timeline*.md` / `*_timeline*.json` | output/analysis/ |
```
</details>

<details>
<summary>🧰 Tools</summary>

<details>
<summary>🪛 markdownlint-cli2 (0.20.0)</summary>

[warning] 73-73: Table column style
Table pipe is missing space to the right for style "compact"

(MD060, table-column-style)

---

[warning] 73-73: Table column style
Table pipe is missing space to the left for style "compact"

(MD060, table-column-style)

---

[warning] 73-73: Table column style
Table pipe is missing space to the right for style "compact"

(MD060, table-column-style)

---

[warning] 73-73: Table column style
Table pipe is missing space to the left for style "compact"

(MD060, table-column-style)

---

[warning] 81-81: Spaces inside emphasis markers

(MD037, no-space-in-emphasis)

---

[warning] 82-82: Spaces inside emphasis markers

(MD037, no-space-in-emphasis)

</details>

</details>

<details>
<summary>🤖 Prompt for AI Agents</summary>

```
In `@issues/implemented/output-folder-structure.md` around lines 72 - 84, The
table's markdown spacing and unescaped asterisks cause MD060 and emphasis
parsing issues; fix by normalizing column spacing (single space padding around
pipes) and wrapping each File Pattern cell in backticks to escape wildcard
asterisks (e.g., `generated_image_*.png`, `*_transcript*.txt`,
`generated_audio_*.mp3`, `*.srt`, `*_analysis*.md`) so the patterns render
literally and the table follows MD table spacing rules.
```

</details>

<!-- fingerprinting:phantom:poseidon:eagle -->

<!-- This is an auto-generated comment by CodeRabbit -->
