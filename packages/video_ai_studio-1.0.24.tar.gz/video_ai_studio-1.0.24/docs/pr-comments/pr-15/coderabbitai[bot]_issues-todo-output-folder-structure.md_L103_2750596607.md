# Review Comment

- **Author:** coderabbitai[bot]
- **File:** `issues/todo/output-folder-structure.md`
- **Line:** 103
- **Date:** 2026-02-01
- **Comment ID:** 2750596607
- **URL:** https://github.com/donghaozhang/video-agent-skill/pull/15#discussion_r2750596607

---

_⚠️ Potential issue_ | _🟡 Minor_

**Normalize table spacing and escape underscores in patterns.**

MD060 and MD037 are triggered by compact pipe spacing and unescaped underscores. Consider code‑formatting file patterns.

<details>
<summary>💡 Suggested fix</summary>

```diff
-| File Pattern | Destination |
-|-------------|-------------|
-| generated_image_*.png/jpg | output/images/ |
-| generated_video_*.mp4/webm | output/videos/ |
-| generated_audio_*.mp3/wav | output/audio/ |
-| *_transcript*.txt | output/transcripts/ |
-| *.srt, *.vtt | output/transcripts/ |
-| *_words.json, *_raw.json | output/transcripts/ |
-| *_analysis*.md/json | output/analysis/ |
-| step_*_output.* | output/pipelines/{name}/ |
+| File Pattern | Destination |
+| ------------ | ----------- |
+| `generated_image_*.png/jpg` | `output/images/` |
+| `generated_video_*.mp4/webm` | `output/videos/` |
+| `generated_audio_*.mp3/wav` | `output/audio/` |
+| `*_transcript*.txt` | `output/transcripts/` |
+| `*.srt, *.vtt` | `output/transcripts/` |
+| `*_words.json, *_raw.json` | `output/transcripts/` |
+| `*_analysis*.md/json` | `output/analysis/` |
+| `step_*_output.*` | `output/pipelines/{name}/` |
```
</details>

<!-- suggestion_start -->

<details>
<summary>📝 Committable suggestion</summary>

> ‼️ **IMPORTANT**
> Carefully review the code before committing. Ensure that it accurately replaces the highlighted code, contains no missing lines, and has no issues with indentation. Thoroughly test & benchmark the code to ensure it meets the requirements.

```suggestion
| File Pattern | Destination |
| ------------ | ----------- |
| `generated_image_*.png/jpg` | `output/images/` |
| `generated_video_*.mp4/webm` | `output/videos/` |
| `generated_audio_*.mp3/wav` | `output/audio/` |
| `*_transcript*.txt` | `output/transcripts/` |
| `*.srt, *.vtt` | `output/transcripts/` |
| `*_words.json, *_raw.json` | `output/transcripts/` |
| `*_analysis*.md/json` | `output/analysis/` |
| `step_*_output.*` | `output/pipelines/{name}/` |
```

</details>

<!-- suggestion_end -->

<details>
<summary>🧰 Tools</summary>

<details>
<summary>🪛 markdownlint-cli2 (0.20.0)</summary>

[warning] 94-94: Table column style
Table pipe is missing space to the right for style "compact"

(MD060, table-column-style)

---

[warning] 94-94: Table column style
Table pipe is missing space to the left for style "compact"

(MD060, table-column-style)

---

[warning] 94-94: Table column style
Table pipe is missing space to the right for style "compact"

(MD060, table-column-style)

---

[warning] 94-94: Table column style
Table pipe is missing space to the left for style "compact"

(MD060, table-column-style)

---

[warning] 99-99: Spaces inside emphasis markers

(MD037, no-space-in-emphasis)

---

[warning] 100-100: Spaces inside emphasis markers

(MD037, no-space-in-emphasis)

</details>

</details>

<details>
<summary>🤖 Prompt for AI Agents</summary>

```
In `@issues/todo/output-folder-structure.md` around lines 93 - 103, Table rows use
compact pipe spacing and unescaped underscores, which trigger MD060/MD037;
update the markdown table to use consistent spacing around pipes (one space
before and after each |) and escape all literal underscores in file pattern
cells (e.g., replace _ with \_) so patterns like generated_image_*.png/jpg,
generated_audio_*.mp3/wav, *_transcript*.txt, *_words.json, *_analysis*.md/json
and step_*_output.* are escaped; keep the same content and column alignment
while applying these formatting and escaping changes.
```

</details>

<!-- fingerprinting:phantom:poseidon:eagle -->

<!-- This is an auto-generated comment by CodeRabbit -->
