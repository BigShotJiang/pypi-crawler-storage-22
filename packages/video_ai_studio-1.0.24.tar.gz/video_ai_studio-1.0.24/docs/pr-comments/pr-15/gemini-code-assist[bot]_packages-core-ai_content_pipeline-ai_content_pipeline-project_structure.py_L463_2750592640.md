# Review Comment

- **Author:** gemini-code-assist[bot]
- **File:** `packages/core/ai_content_pipeline/ai_content_pipeline/project_structure.py`
- **Line:** 463
- **Date:** 2026-02-01
- **Comment ID:** 2750592640
- **URL:** https://github.com/donghaozhang/video-agent-skill/pull/15#discussion_r2750592640

---

![medium](https://www.gstatic.com/codereviewagent/medium-priority.svg)

There's a small typo in the type hint. You're using the built-in function `any` instead of `Any` from the `typing` module. You'll need to import `Any` from `typing` at the top of the file for this to work.

```python
def get_structure_info(root_dir: str = ".") -> Dict[str, Any]:
```
