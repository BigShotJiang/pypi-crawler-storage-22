# Review Comment

- **Author:** gemini-code-assist[bot]
- **File:** `tests/test_project_structure.py`
- **Line:** 49
- **Date:** 2026-02-01
- **Comment ID:** 2750592642
- **URL:** https://github.com/donghaozhang/video-agent-skill/pull/15#discussion_r2750592642

---

![medium](https://www.gstatic.com/codereviewagent/medium-priority.svg)

The `try/except` block for handling `ImportError` duplicates the entire list of imports. You can refactor this to be more concise and avoid repetition by first attempting a minimal import to check the path, then doing the full import outside the `try/except` block.

```python
try:
    # This will work if the package is installed.
    from ai_content_pipeline.project_structure import InitResult
except ImportError:
    # This allows running tests directly from the repo root.
    import sys
    sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'packages', 'core', 'ai_content_pipeline'))

from ai_content_pipeline.project_structure import (
    init_project,
    organize_project,
    cleanup_temp_files,
    get_structure_info,
    get_destination_folder,
    get_all_directories,
    DEFAULT_STRUCTURE,
    FILE_EXTENSIONS,
    InitResult,
    OrganizeResult,
)
```
