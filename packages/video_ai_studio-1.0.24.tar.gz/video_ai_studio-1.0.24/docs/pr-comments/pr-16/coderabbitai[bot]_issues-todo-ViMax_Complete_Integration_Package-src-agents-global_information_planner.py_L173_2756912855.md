# Review Comment

- **Author:** coderabbitai[bot]
- **File:** `issues/todo/ViMax_Complete_Integration_Package/src/agents/global_information_planner.py`
- **Line:** 173
- **Date:** 2026-02-03
- **Comment ID:** 2756912855
- **URL:** https://github.com/donghaozhang/video-agent-skill/pull/16#discussion_r2756912855

---

_⚠️ Potential issue_ | _🔴 Critical_

**Attribute name mismatch: `character.index` vs `CharacterInScene.idx`.**

Based on the `CharacterInScene` interface in the relevant snippets, the field is named `idx`, not `index`. This will raise an `AttributeError` at runtime.

<details>
<summary>🐛 Proposed fix</summary>

```diff
             for character in scene.characters:
-                scene_str += f"<CHARACTER_{character.index}_START>\n"
+                scene_str += f"<CHARACTER_{character.idx}_START>\n"
                 scene_str += str(character)
-                scene_str += f"<CHARACTER_{character.index}_END>\n"
+                scene_str += f"<CHARACTER_{character.idx}_END>\n"
```
</details>

<!-- suggestion_start -->

<details>
<summary>📝 Committable suggestion</summary>

> ‼️ **IMPORTANT**
> Carefully review the code before committing. Ensure that it accurately replaces the highlighted code, contains no missing lines, and has no issues with indentation. Thoroughly test & benchmark the code to ensure it meets the requirements.

```suggestion
            for character in scene.characters:
                scene_str += f"<CHARACTER_{character.idx}_START>\n"
                scene_str += str(character)
                scene_str += f"<CHARACTER_{character.idx}_END>\n"
```

</details>

<!-- suggestion_end -->

<details>
<summary>🤖 Prompt for AI Agents</summary>

```
In
`@issues/todo/ViMax_Complete_Integration_Package/src/agents/global_information_planner.py`
around lines 170 - 173, The loop building scene_str uses character.index which
doesn't exist on CharacterInScene (the correct field is idx); update the loop to
reference character.idx (or, if the model is intentionally named index, rename
the CharacterInScene field consistently) in the for loop that iterates
scene.characters and ensure any other uses of CharacterInScene use the same idx
field (search for CharacterInScene, scene.characters, and the code that
stringifies characters to keep names consistent).
```

</details>

<!-- fingerprinting:phantom:medusa:ocelot -->

<!-- This is an auto-generated comment by CodeRabbit -->
