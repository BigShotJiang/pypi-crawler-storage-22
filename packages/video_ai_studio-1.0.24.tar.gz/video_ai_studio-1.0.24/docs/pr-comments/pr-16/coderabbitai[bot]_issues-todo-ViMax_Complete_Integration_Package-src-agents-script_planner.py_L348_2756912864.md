# Review Comment

- **Author:** coderabbitai[bot]
- **File:** `issues/todo/ViMax_Complete_Integration_Package/src/agents/script_planner.py`
- **Line:** 348
- **Date:** 2026-02-03
- **Comment ID:** 2756912864
- **URL:** https://github.com/donghaozhang/video-agent-skill/pull/16#discussion_r2756912864

---

_⚠️ Potential issue_ | _🔴 Critical_

**`@retry` decorator without stop condition causes infinite retries.**

The `@retry` decorator at Line 344 has no `stop` parameter, meaning it will retry indefinitely on any exception. This can cause the application to hang.

<details>
<summary>🐛 Proposed fix</summary>

```diff
-    `@retry`
+    `@retry`(stop=stop_after_attempt(3))
     def plan_script(
         self,
         basic_idea: str,
     ) -> PlannedScriptResponse:
```
</details>

You'll also need to import `stop_after_attempt`:

```diff
-from tenacity import retry
+from tenacity import retry, stop_after_attempt
```

<details>
<summary>🤖 Prompt for AI Agents</summary>

```
In `@issues/todo/ViMax_Complete_Integration_Package/src/agents/script_planner.py`
around lines 344 - 348, The `@retry` on the plan_script function will retry
forever because it lacks a stop condition; update the decorator on plan_script
to include a stop policy (for example stop=stop_after_attempt(3)) and any
desired wait policy, and add the import for stop_after_attempt (from tenacity
import stop_after_attempt) at the top of the file so retries will cease after a
finite number of attempts.
```

</details>

<!-- fingerprinting:phantom:medusa:ocelot -->

<!-- This is an auto-generated comment by CodeRabbit -->
