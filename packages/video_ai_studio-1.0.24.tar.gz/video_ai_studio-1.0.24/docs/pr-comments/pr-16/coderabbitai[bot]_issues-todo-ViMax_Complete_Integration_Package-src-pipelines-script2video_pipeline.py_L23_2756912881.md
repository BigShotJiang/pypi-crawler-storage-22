# Review Comment

- **Author:** coderabbitai[bot]
- **File:** `issues/todo/ViMax_Complete_Integration_Package/src/pipelines/script2video_pipeline.py`
- **Line:** 23
- **Date:** 2026-02-03
- **Comment ID:** 2756912881
- **URL:** https://github.com/donghaozhang/video-agent-skill/pull/16#discussion_r2756912881

---

_⚠️ Potential issue_ | _🔴 Critical_

**Critical: Mutable class attributes cause shared state between instances.**

These dictionaries are class-level attributes, meaning they're shared across all instances of `Script2VideoPipeline`. If multiple pipelines run concurrently (or sequentially without cleanup), they will corrupt each other's state and cause race conditions or incorrect event signaling.


<details>
<summary>🐛 Proposed fix: Move to instance attributes</summary>

```diff
 class Script2VideoPipeline:
-
-    # events
-    character_portrait_events = {}
-    shot_desc_events = {}
-    frame_events = {}


     def __init__(
         self,
         chat_model: str,
         image_generator,
         video_generator,
         working_dir: str,
     ):
+        # Instance-level events for concurrent safety
+        self.character_portrait_events: Dict[int, asyncio.Event] = {}
+        self.shot_desc_events: Dict[int, asyncio.Event] = {}
+        self.frame_events: Dict[int, Dict[str, asyncio.Event]] = {}

         self.chat_model = chat_model
```
</details>

<details>
<summary>🧰 Tools</summary>

<details>
<summary>🪛 Ruff (0.14.14)</summary>

[warning] 21-21: Mutable class attributes should be annotated with `typing.ClassVar`

(RUF012)

---

[warning] 22-22: Mutable class attributes should be annotated with `typing.ClassVar`

(RUF012)

---

[warning] 23-23: Mutable class attributes should be annotated with `typing.ClassVar`

(RUF012)

</details>

</details>

<details>
<summary>🤖 Prompt for AI Agents</summary>

```
In
`@issues/todo/ViMax_Complete_Integration_Package/src/pipelines/script2video_pipeline.py`
around lines 20 - 23, The three dictionaries character_portrait_events,
shot_desc_events, and frame_events are defined as class attributes on
Script2VideoPipeline and must be moved into the instance by initializing them in
the class __init__ (e.g., self.character_portrait_events = {},
self.shot_desc_events = {}, self.frame_events = {}) and removing the class-level
definitions; also update all usages in methods to reference
self.character_portrait_events, self.shot_desc_events, and self.frame_events so
each Script2VideoPipeline instance has its own independent event state.
```

</details>

<!-- fingerprinting:phantom:medusa:ocelot -->

<!-- This is an auto-generated comment by CodeRabbit -->
