# Review Comment

- **Author:** coderabbitai[bot]
- **File:** `packages/core/ai_content_platform/vimax/adapters/image_adapter.py`
- **Line:** 291
- **Date:** 2026-02-03
- **Comment ID:** 2756951647
- **URL:** https://github.com/donghaozhang/video-agent-skill/pull/16#discussion_r2756951647

---

_⚠️ Potential issue_ | _🟠 Major_

**Validate URL scheme to prevent SSRF or local file access.**

`urllib.request.urlretrieve` can be exploited with `file://` or custom schemes, potentially leading to SSRF or local file access vulnerabilities. Validate the URL scheme before downloading.



<details>
<summary>🛡️ Proposed fix</summary>

```diff
     def _download_image(self, url: str, path: str):
         """Download image from URL to path."""
         try:
+            from urllib.parse import urlparse
+            parsed = urlparse(url)
+            if parsed.scheme not in ("http", "https"):
+                self.logger.warning(f"Refusing to download from non-HTTP URL: {url}")
+                return
             import urllib.request
             urllib.request.urlretrieve(url, path)
         except Exception as e:
             self.logger.warning(f"Failed to download image: {e}")
```
</details>

<details>
<summary>🧰 Tools</summary>

<details>
<summary>🪛 Ruff (0.14.14)</summary>

[error] 261-261: Audit URL open for permitted schemes. Allowing use of `file:` or custom schemes is often unexpected.

(S310)

---

[warning] 262-262: Do not catch blind exception: `Exception`

(BLE001)

</details>

</details>

<details>
<summary>🤖 Prompt for AI Agents</summary>

```
In `@packages/core/ai_content_platform/vimax/adapters/image_adapter.py` around
lines 257 - 264, The _download_image method currently calls
urllib.request.urlretrieve directly which allows dangerous schemes (e.g.,
file://) and can lead to SSRF/local access; before calling urlretrieve, parse
the input URL (e.g., with urllib.parse.urlparse) and verify the scheme is
strictly "http" or "https" (or explicitly allowed list), log a warning and
skip/raise if not allowed, and only then proceed to download; keep the existing
exception handling around urllib.request.urlretrieve but ensure the validation
prevents non-HTTP(S) schemes from reaching urlretrieve.
```

</details>

<!-- fingerprinting:phantom:medusa:ocelot -->

<!-- This is an auto-generated comment by CodeRabbit -->
