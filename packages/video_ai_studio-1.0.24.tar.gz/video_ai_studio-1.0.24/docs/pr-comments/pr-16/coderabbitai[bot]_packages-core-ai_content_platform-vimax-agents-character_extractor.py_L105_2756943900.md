# Review Comment

- **Author:** coderabbitai[bot]
- **File:** `packages/core/ai_content_platform/vimax/agents/character_extractor.py`
- **Line:** 105
- **Date:** 2026-02-03
- **Comment ID:** 2756943900
- **URL:** https://github.com/donghaozhang/video-agent-skill/pull/16#discussion_r2756943900

---

_⚠️ Potential issue_ | _🟡 Minor_

**Use non-greedy regex and chain exceptions properly.**

The greedy regex `\[.*\]` may incorrectly match from the first `[` to the last `]` in responses containing multiple arrays or nested structures. Additionally, re-raising without `from` loses the original traceback context.


<details>
<summary>🛠️ Proposed fix</summary>

```diff
             # Parse response
             try:
                 data = json.loads(response.content)
             except json.JSONDecodeError:
                 # Try to extract JSON from response
-                match = re.search(r'\[.*\]', response.content, re.DOTALL)
+                match = re.search(r'\[.*?\]', response.content, re.DOTALL)
                 if match:
                     data = json.loads(match.group())
                 else:
-                    raise ValueError("Could not parse character data from response")
+                    raise ValueError("Could not parse character data from response") from None
```
</details>

<!-- suggestion_start -->

<details>
<summary>📝 Committable suggestion</summary>

> ‼️ **IMPORTANT**
> Carefully review the code before committing. Ensure that it accurately replaces the highlighted code, contains no missing lines, and has no issues with indentation. Thoroughly test & benchmark the code to ensure it meets the requirements.

```suggestion
            try:
                data = json.loads(response.content)
            except json.JSONDecodeError:
                # Try to extract JSON from response
                match = re.search(r'\[.*?\]', response.content, re.DOTALL)
                if match:
                    data = json.loads(match.group())
                else:
                    raise ValueError("Could not parse character data from response") from None
```

</details>

<!-- suggestion_end -->

<details>
<summary>🧰 Tools</summary>

<details>
<summary>🪛 Ruff (0.14.14)</summary>

[warning] 105-105: Within an `except` clause, raise exceptions with `raise ... from err` or `raise ... from None` to distinguish them from errors in exception handling

(B904)

---

[warning] 105-105: Avoid specifying long messages outside the exception class

(TRY003)

</details>

</details>

<details>
<summary>🤖 Prompt for AI Agents</summary>

```
In `@packages/core/ai_content_platform/vimax/agents/character_extractor.py` around
lines 97 - 105, The JSON fallback currently uses a greedy regex and drops
original traceback; change the except block to capture the JSONDecodeError
(e.g., except json.JSONDecodeError as e), use a non-greedy pattern when
searching (r'\[.*?\]' with re.DOTALL) to avoid over-matching, and when raising
the ValueError on failure re-raise it with the original exception as context
(raise ValueError("Could not parse character data from response") from e);
update the block around json.loads(response.content), re.search, and the data
assignment accordingly.
```

</details>

<!-- fingerprinting:phantom:poseidon:ocelot -->

<!-- This is an auto-generated comment by CodeRabbit -->
