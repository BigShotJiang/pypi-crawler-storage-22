# Review Comment

- **Author:** coderabbitai[bot]
- **File:** `packages/core/ai_content_platform/vimax/agents/storyboard_artist.py`
- **Line:** 129
- **Date:** 2026-02-03
- **Comment ID:** 2756973518
- **URL:** https://github.com/donghaozhang/video-agent-skill/pull/16#discussion_r2756973518

---

_⚠️ Potential issue_ | _🟠 Major_

**Sanitize titles/shot IDs before using them as filesystem paths.**  
Using `script.title` and `shot.shot_id` directly can allow path traversal or invalid filenames on some OSes.  


<details>
<summary>🛡️ Suggested fix (safe slugging)</summary>

```diff
+import re
@@
 class StoryboardArtist(BaseAgent[Script, StoryboardResult]):
@@
+    def _safe_slug(self, value: str) -> str:
+        safe = re.sub(r"[^A-Za-z0-9._-]+", "_", value).strip("_")
+        return safe or "untitled"
@@
-            output_dir = Path(self.config.output_dir) / script.title.replace(" ", "_")
+            safe_title = self._safe_slug(script.title)
+            output_dir = Path(self.config.output_dir) / safe_title
@@
-                    output_path = str(output_dir / f"{shot.shot_id}.png")
+                    safe_shot_id = self._safe_slug(shot.shot_id)
+                    output_path = str(output_dir / f"{safe_shot_id}.png")
@@
-        output_dir = Path(self.config.output_dir) / title.replace(" ", "_")
+        safe_title = self._safe_slug(title)
+        output_dir = Path(self.config.output_dir) / safe_title
```
</details>


Also applies to: 180-186

<details>
<summary>🤖 Prompt for AI Agents</summary>

```
In `@packages/core/ai_content_platform/vimax/agents/storyboard_artist.py` around
lines 112 - 129, The code uses script.title and shot.shot_id directly when
creating filesystem paths (output_dir and the file name in
storyboard_artist.py); implement and call a filename-sanitization helper (e.g.,
sanitize_filename or slugify_filename) that strips/path-normalizes dangerous
characters, removes path separators, collapses whitespace, replaces invalid OS
characters, and truncates to a safe length, then use that sanitized value when
building output_dir = Path(self.config.output_dir) /
sanitize_filename(script.title) and when composing the shot filename
(sanitize_filename(shot.shot_id) + ".png"); apply the same sanitization for the
other occurrences noted around lines 180-186.
```

</details>

<!-- fingerprinting:phantom:poseidon:eagle -->

<!-- This is an auto-generated comment by CodeRabbit -->
