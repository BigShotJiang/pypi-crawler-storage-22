# Review Comment

- **Author:** coderabbitai[bot]
- **File:** `packages/core/ai_content_platform/vimax/pipelines/idea2video.py`
- **Line:** 196
- **Date:** 2026-02-03
- **Comment ID:** 2756943912
- **URL:** https://github.com/donghaozhang/video-agent-skill/pull/16#discussion_r2756943912

---

_⚠️ Potential issue_ | _🟡 Minor_

<details>
<summary>🧩 Analysis chain</summary>

🏁 Script executed:

```shell
# First, explore the repository structure
git ls-files | head -20
```

Repository: donghaozhang/video-agent-skill

Length of output: 1020

---

🏁 Script executed:

```shell
# Find the CharacterPortraitsGenerator class
rg "class CharacterPortraitsGenerator" -A 20
```

Repository: donghaozhang/video-agent-skill

Length of output: 7356

---

🏁 Script executed:

```shell
# Find the generate_batch method
rg "def generate_batch" -A 10
```

Repository: donghaozhang/video-agent-skill

Length of output: 5067

---

🏁 Script executed:

```shell
# Look at the specific file mentioned in the review
fd "idea2video.py" --type f
```

Repository: donghaozhang/video-agent-skill

Length of output: 137

---

🏁 Script executed:

```shell
# View the generate_batch method implementation
sed -n '1,100p' packages/core/ai_content_platform/vimax/agents/character_portraits.py | cat -n
```

Repository: donghaozhang/video-agent-skill

Length of output: 4316

---

🏁 Script executed:

```shell
# Find and view generate_batch method
rg "async def generate_batch" -A 30 packages/core/ai_content_platform/vimax/agents/character_portraits.py
```

Repository: donghaozhang/video-agent-skill

Length of output: 616

---

🏁 Script executed:

```shell
# Check the CharacterPortrait data structure
rg "class CharacterPortrait" -A 20
```

Repository: donghaozhang/video-agent-skill

Length of output: 12012

---

🏁 Script executed:

```shell
# View lines around 190-194 in idea2video.py
sed -n '180,200p' packages/core/ai_content_platform/vimax/pipelines/idea2video.py | cat -n
```

Repository: donghaozhang/video-agent-skill

Length of output: 1431

---

🏁 Script executed:

```shell
# Search for cost tracking patterns and portrait cost values
rg "0\.003|portrait.*cost|cost.*portrait" -i
```

Repository: donghaozhang/video-agent-skill

Length of output: 8831

---

🏁 Script executed:

```shell
# Look for configuration files or constants related to costs
rg "class.*Config" packages/core/ai_content_platform/vimax/ | grep -i portrait
```

Repository: donghaozhang/video-agent-skill

Length of output: 188

---

🏁 Script executed:

```shell
# Check if AgentResult or similar classes have metadata/cost fields
rg "class AgentResult" -A 10
```

Repository: donghaozhang/video-agent-skill

Length of output: 2203

---

🏁 Script executed:

```shell
# Check if PortraitsGeneratorConfig has cost field or if adapters expose it
rg "class PortraitsGeneratorConfig" -A 20 packages/core/ai_content_platform/vimax/agents/character_portraits.py
```

Repository: donghaozhang/video-agent-skill

Length of output: 716

---

🏁 Script executed:

```shell
# Look at how cost is handled in generate_batch and process methods
rg "async def process" -A 30 packages/core/ai_content_platform/vimax/agents/character_portraits.py | head -50
```

Repository: donghaozhang/video-agent-skill

Length of output: 1102

---



</details>

**Extract cost per view from adapter's COST_MAP instead of hardcoding 0.003.**

The `generate_batch` method exists, but it doesn't expose cost information in its return value. The hardcoded cost of `0.003` per view cannot be tracked from the generator's response since `CharacterPortrait` contains no cost metadata. Instead, reference the cost from the image adapter's `COST_MAP` based on the configured model (`self.portraits_generator.config.image_model`), similar to how `ImageGeneratorAdapter` handles cost tracking internally.

<details>
<summary>🤖 Prompt for AI Agents</summary>

```
In `@packages/core/ai_content_platform/vimax/pipelines/idea2video.py` around lines
190 - 194, The code is hardcoding per-view cost (0.003) when summing portrait
costs; instead look up the per-view cost from the image adapter COST_MAP using
the configured model name and multiply by number of views. Update the block that
iterates result.portraits (after calling
self.portraits_generator.generate_batch) to retrieve model =
self.portraits_generator.config.image_model, get per_view_cost =
ImageGeneratorAdapter.COST_MAP[model] (or the appropriate adapter COST_MAP
symbol), and add len(portrait.views) * per_view_cost to result.total_cost; do
not assume CharacterPortrait contains cost metadata and reference the adapter
COST_MAP and self.portraits_generator.config.image_model to determine the rate.
```

</details>

<!-- fingerprinting:phantom:poseidon:ocelot -->

<!-- This is an auto-generated comment by CodeRabbit -->
