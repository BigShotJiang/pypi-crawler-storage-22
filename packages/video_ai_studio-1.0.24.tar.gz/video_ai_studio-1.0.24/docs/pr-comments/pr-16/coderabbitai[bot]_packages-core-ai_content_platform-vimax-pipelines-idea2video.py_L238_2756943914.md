# Review Comment

- **Author:** coderabbitai[bot]
- **File:** `packages/core/ai_content_platform/vimax/pipelines/idea2video.py`
- **Line:** 238
- **Date:** 2026-02-03
- **Comment ID:** 2756943914
- **URL:** https://github.com/donghaozhang/video-agent-skill/pull/16#discussion_r2756943914

---

_⚠️ Potential issue_ | _🟡 Minor_

**Guard against `None` duration in format string.**

If `completed_at` is not set (e.g., on early failure paths), `result.duration` returns `None`, causing a `TypeError` when formatting with `:.1f`.


<details>
<summary>🛠️ Proposed fix</summary>

```diff
             self.logger.info(
-                f"Pipeline completed successfully! "
-                f"Duration: {result.duration:.1f}s, "
-                f"Cost: ${result.total_cost:.3f}"
+                f"Pipeline completed successfully! "
+                f"Duration: {result.duration or 0:.1f}s, "
+                f"Cost: ${result.total_cost:.3f}"
             )
```
</details>

<details>
<summary>🤖 Prompt for AI Agents</summary>

```
In `@packages/core/ai_content_platform/vimax/pipelines/idea2video.py` around lines
218 - 222, The log formatting for pipeline completion assumes result.duration is
numeric and uses "{result.duration:.1f}", which raises if duration is None;
update the logging in the block that calls self.logger.info (the Pipeline
completion path using result.duration and result.total_cost) to guard against
None by computing a safe string or default numeric value first (e.g.,
duration_str = f"{result.duration:.1f}s" if result.duration is not None else
"N/A" or safe_duration = result.duration or 0.0 and then format), and use that
safe value in the f-string so the logger never tries to format None.
```

</details>

<!-- fingerprinting:phantom:poseidon:ocelot -->

<!-- This is an auto-generated comment by CodeRabbit -->
