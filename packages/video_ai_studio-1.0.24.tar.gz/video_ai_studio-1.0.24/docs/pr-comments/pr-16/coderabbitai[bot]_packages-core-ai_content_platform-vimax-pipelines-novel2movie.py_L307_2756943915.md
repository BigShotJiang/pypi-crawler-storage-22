# Review Comment

- **Author:** coderabbitai[bot]
- **File:** `packages/core/ai_content_platform/vimax/pipelines/novel2movie.py`
- **Line:** 307
- **Date:** 2026-02-03
- **Comment ID:** 2756943915
- **URL:** https://github.com/donghaozhang/video-agent-skill/pull/16#discussion_r2756943915

---

_⚠️ Potential issue_ | _🟡 Minor_

**Use non-greedy regex and avoid silently swallowing parse errors.**

The greedy regex can cause incorrect matches. Also, silently continuing on parse failure may result in missing chapters without clear indication to the user.


<details>
<summary>🛠️ Proposed fix</summary>

```diff
             try:
-                match = re.search(r'\{.*\}', response.content, re.DOTALL)
+                match = re.search(r'\{.*?\}', response.content, re.DOTALL)
                 if match:
                     data = json.loads(match.group())
                     chapter = ChapterSummary(
                         chapter_id=f"chapter_{i+1}",
                         title=data.get("title", f"Chapter {i+1}"),
                         summary="",
                         key_events=[s.get("description", "") for s in data.get("scenes", [])],
                         characters=[c for s in data.get("scenes", []) for c in s.get("characters", [])],
                     )
                     chapters.append(chapter)
+                else:
+                    self.logger.warning(f"No JSON found in response for chunk {i+1}")
             except Exception as e:
                 self.logger.warning(f"Failed to parse chapter {i+1}: {e}")
```
</details>

<details>
<summary>🧰 Tools</summary>

<details>
<summary>🪛 Ruff (0.14.14)</summary>

[warning] 264-264: Do not catch blind exception: `Exception`

(BLE001)

</details>

</details>

<details>
<summary>🤖 Prompt for AI Agents</summary>

```
In `@packages/core/ai_content_platform/vimax/pipelines/novel2movie.py` around
lines 252 - 265, The regex used to extract JSON from response.content is greedy
and parse failures are silently suppressed; update the search to use a
non-greedy pattern (e.g., r'\{.*?\}' with re.DOTALL) when parsing in the block
that creates ChapterSummary, and change the except block to log the full
exception and context (include chapter index i+1 and response.content snippet)
instead of only a short warning; also consider appending a fallback
ChapterSummary (e.g., with summary indicating parse failed and empty
key_events/characters) so the pipeline keeps chapter ordering rather than
dropping entries silently (refer to ChapterSummary construction and the logger
usage in this try/except).
```

</details>

<!-- fingerprinting:phantom:poseidon:ocelot -->

<!-- This is an auto-generated comment by CodeRabbit -->
