# Review Comment

- **Author:** coderabbitai[bot]
- **File:** `packages/core/ai_content_platform/vimax/pipelines/novel2movie.py`
- **Line:** 330
- **Date:** 2026-02-03
- **Comment ID:** 2756943921
- **URL:** https://github.com/donghaozhang/video-agent-skill/pull/16#discussion_r2756943921

---

_⚠️ Potential issue_ | _🟡 Minor_

**Guard against infinite loop when `overlap >= chunk_size`.**

If `overlap` is configured to be greater than or equal to `chunk_size`, the loop will never terminate because `start` never advances (or advances backward).


<details>
<summary>🛠️ Proposed fix</summary>

```diff
     def _split_text(self, text: str) -> List[str]:
         """Split text into overlapping chunks."""
+        if self.config.overlap >= self.config.chunk_size:
+            raise ValueError("overlap must be less than chunk_size")
+
         chunks = []
         start = 0
```
</details>

<details>
<summary>🤖 Prompt for AI Agents</summary>

```
In `@packages/core/ai_content_platform/vimax/pipelines/novel2movie.py` around
lines 269 - 288, The _split_text method can infinite-loop when
self.config.overlap >= self.config.chunk_size; add a guard at the start of
_split_text to validate the config and fail-fast (e.g., raise a ValueError with
a clear message referencing self.config.chunk_size and self.config.overlap) or
clamp overlap to a safe value (such as chunk_size - 1) before entering the while
loop so start always advances; ensure the chosen fix updates callers/tests if
you change behavior.
```

</details>

<!-- fingerprinting:phantom:poseidon:ocelot -->

<!-- This is an auto-generated comment by CodeRabbit -->
