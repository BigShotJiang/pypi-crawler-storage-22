# Review Comment

- **Author:** gemini-code-assist[bot]
- **File:** `packages/core/ai_content_platform/vimax/adapters/llm_adapter.py`
- **Line:** 317
- **Date:** 2026-02-03
- **Comment ID:** 2756900262
- **URL:** https://github.com/donghaozhang/video-agent-skill/pull/16#discussion_r2756900262

---

![medium](https://www.gstatic.com/codereviewagent/medium-priority.svg)

The current JSON parsing logic in `chat_with_structured_output` is basic and might fail if the LLM wraps the JSON response in markdown code blocks (e.g., ```json\n{...}\n```), which is a common occurrence. Other agents in this PR, like `CharacterExtractor`, implement their own regex-based logic to handle this, leading to code duplication.

To make this more robust and to centralize the logic, I recommend enhancing this method to handle responses that might be wrapped in markdown. You can use a regex to extract the JSON content before parsing. This will make the adapter more resilient and simplify the agent implementations, as they can rely on this method for all structured output needs.

```suggestion
        try:
            # Try to extract JSON from response that might be in a markdown block
            content = response.content.strip()
            match = re.search(r"\{.*\}", content, re.DOTALL)
            if match:
                json_str = match.group(0)
            else:
                json_str = content

            data = json.loads(json_str)
            return output_schema(**data)
        except (json.JSONDecodeError, ValueError) as e:
            self.logger.error(f"Failed to parse structured output: {e}")
            raise ValueError(f"LLM response was not valid JSON: {response.content[:200]}")
```
