# Review Comment

- **Author:** gemini-code-assist[bot]
- **File:** `packages/core/ai_content_platform/vimax/agents/character_portraits.py`
- **Line:** 170
- **Date:** 2026-02-03
- **Comment ID:** 2756900268
- **URL:** https://github.com/donghaozhang/video-agent-skill/pull/16#discussion_r2756900268

---

![medium](https://www.gstatic.com/codereviewagent/medium-priority.svg)

The `generate_batch` method currently returns a dictionary of portraits but doesn't propagate the accumulated cost of the generation process. This forces the calling pipeline (`Idea2VideoPipeline`) to use a hardcoded approximation for cost calculation, which is not ideal.

The `process` method already returns an `AgentResult` containing the cost. I suggest refactoring `generate_batch` to also return an `AgentResult` that includes the accumulated cost from all the `process` calls. This will ensure accurate cost tracking and make the agent's interface more consistent.

```python
    async def generate_batch(
        self,
        characters: List[CharacterInNovel],
    ) -> AgentResult[Dict[str, CharacterPortrait]]:
        """
        Generate portraits for multiple characters.

        Args:
            characters: List of characters

        Returns:
            AgentResult containing a dict mapping character names to portraits and total cost.
        """
        portraits = {}
        total_cost = 0.0
        errors = []

        for char in characters:
            result = await self.process(char)
            if result.success:
                portraits[char.name] = result.result
                total_cost += result.metadata.get("cost", 0)
            else:
                errors.append(f"Failed to generate portrait for {char.name}: {result.error}")

        if errors:
            return AgentResult.fail("\n".join(errors), result=portraits, cost=total_cost)

        return AgentResult.ok(portraits, cost=total_cost)
```
