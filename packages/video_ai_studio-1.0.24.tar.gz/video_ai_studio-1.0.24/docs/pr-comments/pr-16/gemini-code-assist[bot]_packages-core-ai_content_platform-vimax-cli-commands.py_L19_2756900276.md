# Review Comment

- **Author:** gemini-code-assist[bot]
- **File:** `packages/core/ai_content_platform/vimax/cli/commands.py`
- **Line:** 19
- **Date:** 2026-02-03
- **Comment ID:** 2756900276
- **URL:** https://github.com/donghaozhang/video-agent-skill/pull/16#discussion_r2756900276

---

![medium](https://www.gstatic.com/codereviewagent/medium-priority.svg)

The `run_async` function creates and manages its own event loop. While this works, the modern and recommended approach for running a top-level async function from a synchronous context is to use `asyncio.run()`. It simplifies the code and correctly handles the event loop lifecycle, including in environments where an event loop might already be running.

I suggest replacing the custom `run_async` implementation with a direct call to `asyncio.run()`.

```suggestion
def run_async(coro):
    """Run async function in sync context."""
    return asyncio.run(coro)
```
