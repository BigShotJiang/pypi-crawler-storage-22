# Review Comment

- **Author:** gemini-code-assist[bot]
- **File:** `packages/core/ai_content_platform/vimax/pipelines/idea2video.py`
- **Line:** 196
- **Date:** 2026-02-03
- **Comment ID:** 2756900270
- **URL:** https://github.com/donghaozhang/video-agent-skill/pull/16#discussion_r2756900270

---

![medium](https://www.gstatic.com/codereviewagent/medium-priority.svg)

The cost for character portrait generation is currently approximated with a hardcoded value (`len(portrait.views) * 0.003`). This is brittle and can lead to inaccurate cost tracking, especially if the underlying models or their pricing change.

To improve this, the `CharacterPortraitsGenerator.generate_batch` method should be updated to return the total cost of the generated portraits. The pipeline can then use this accurate cost figure instead of an approximation. This change will make the cost tracking more robust and maintainable.

```suggestion
            if self.config.generate_portraits and result.characters:
                self.logger.info("Step 3/5: Generating character portraits...")
                portraits_result = await self.portraits_generator.generate_batch(
                    result.characters[:5]  # Limit to main characters
                )
                if portraits_result.success:
                    result.portraits = portraits_result.result
                    result.total_cost += portraits_result.metadata.get("cost", 0)
                else:
                    self.logger.warning(f"Portrait generation had failures: {portraits_result.error}")
```
