# Review Comment

- **Author:** coderabbitai[bot]
- **File:** `issues/unify-cli-framework.md`
- **Line:** 70
- **Date:** 2026-02-06
- **Comment ID:** 2772288518
- **URL:** https://github.com/donghaozhang/video-agent-skill/pull/19#discussion_r2772288518

---

_⚠️ Potential issue_ | _🟡 Minor_

**Add a language tag to the fenced block.**

MD040 flags missing language on the fenced block.

<details>
<summary>✏️ Suggested change</summary>

```diff
-```
+```text
 ENTRY POINTS (setup.py):
   ai-content-pipeline  → __main__.py:main()        [argparse, 25 commands]
   aicp                 → __main__.py:main()        [alias]
   fal-text-to-video    → fal_text_to_video/cli.py  [argparse, 4 commands]
   fal-image-to-video   → fal_image_to_video/cli.py [argparse, 4 commands]
   vimax                → vimax/cli/commands.py      [click, 11 commands]
 ```
</details>

<details>
<summary>🧰 Tools</summary>

<details>
<summary>🪛 markdownlint-cli2 (0.20.0)</summary>

[warning] 27-27: Fenced code blocks should have a language specified

(MD040, fenced-code-language)

</details>

</details>

<details>
<summary>🤖 Prompt for AI Agents</summary>

````
In `@issues/unify-cli-framework.md` around lines 27 - 34, The fenced code block
that begins with "ENTRY POINTS (setup.py):" is missing a language tag which
triggers MD040; update the triple-backtick opening fence to include a language
(e.g., ```text or ```console) so the block becomes a properly tagged fenced code
block; locate the block containing the listed entry points and add the chosen
language tag to the opening ``` marker.
````

</details>

<!-- fingerprinting:phantom:triton:eagle -->

<!-- This is an auto-generated comment by CodeRabbit -->
