# Review Comment

- **Author:** coderabbitai[bot]
- **File:** `issues/unify-cli-framework.md`
- **Line:** 751
- **Date:** 2026-02-06
- **Comment ID:** 2772288537
- **URL:** https://github.com/donghaozhang/video-agent-skill/pull/19#discussion_r2772288537

---

_⚠️ Potential issue_ | _🟡 Minor_

**Add a language tag to the fenced block.**

MD040 flags missing language on the fenced block.

<details>
<summary>✏️ Suggested change</summary>

```diff
-```
+```text
 Subtask 1: Migrate fal-text-to-video (30 min) ----+
                                                     |
 Subtask 2: Migrate fal-image-to-video (30 min) ----+ (independent of 1)
                                                     |
 Subtask 3: Migrate unified pipeline (45 min) ------+ (independent of 1,2)
                                                     |
          +------- all depend on 1,2,3 ------------+
          |
 Subtask 4: Register as subgroups (15 min)
          |
 Subtask 5: Cleanup and verification (15 min)
 ```
</details>

<details>
<summary>🧰 Tools</summary>

<details>
<summary>🪛 markdownlint-cli2 (0.20.0)</summary>

[warning] 493-493: Fenced code blocks should have a language specified

(MD040, fenced-code-language)

</details>

</details>

<details>
<summary>🤖 Prompt for AI Agents</summary>

````
In `@issues/unify-cli-framework.md` around lines 493 - 505, The fenced ASCII
diagram block is missing a language tag which triggers MD040; update the fenced
code block that starts with "Subtask 1: Migrate fal-text-to-video..." and ends
with "Subtask 5: Cleanup and verification (15 min)" to include a language tag
(e.g., ```text) immediately after the opening backticks so the block becomes
```text and satisfies the linter.
````

</details>

<!-- fingerprinting:phantom:triton:eagle -->

<!-- This is an auto-generated comment by CodeRabbit -->
