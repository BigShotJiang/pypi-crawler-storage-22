# Review Comment

- **Author:** coderabbitai[bot]
- **File:** `issues/unify-cli-framework.md`
- **Line:** 81
- **Date:** 2026-02-06
- **Comment ID:** 2772288526
- **URL:** https://github.com/donghaozhang/video-agent-skill/pull/19#discussion_r2772288526

---

_⚠️ Potential issue_ | _🟡 Minor_

**Add a language tag to the fenced block.**

MD040 flags missing language on the fenced block.

<details>
<summary>✏️ Suggested change</summary>

```diff
-```
+```text
 ENTRY POINTS (setup.py):
   ai-content-pipeline  → __main__.py:main()        [click, all commands]
   aicp                 → __main__.py:main()        [alias]
   fal-text-to-video    → fal_text_to_video/cli.py  [click, 4 commands]  ← thin wrapper
   fal-image-to-video   → fal_image_to_video/cli.py [click, 4 commands]  ← thin wrapper
   vimax                → vimax/cli/commands.py      [click, 11 commands]
 ```
</details>

<details>
<summary>🧰 Tools</summary>

<details>
<summary>🪛 markdownlint-cli2 (0.20.0)</summary>

[warning] 38-38: Fenced code blocks should have a language specified

(MD040, fenced-code-language)

</details>

</details>

<details>
<summary>🤖 Prompt for AI Agents</summary>

````
In `@issues/unify-cli-framework.md` around lines 38 - 45, The fenced code block
showing "ENTRY POINTS (setup.py):" is missing a language tag (MD040); update the
opening fence from ``` to ```text so the block is treated as plain text; locate
the block that contains the lines starting with "ENTRY POINTS (setup.py):" and
change only the fence marker to include "text" (no other content changes).
````

</details>

<!-- fingerprinting:phantom:triton:eagle -->

<!-- This is an auto-generated comment by CodeRabbit -->
