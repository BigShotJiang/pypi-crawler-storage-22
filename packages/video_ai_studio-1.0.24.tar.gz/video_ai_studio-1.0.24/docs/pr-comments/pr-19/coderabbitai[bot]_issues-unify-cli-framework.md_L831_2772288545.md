# Review Comment

- **Author:** coderabbitai[bot]
- **File:** `issues/unify-cli-framework.md`
- **Line:** 831
- **Date:** 2026-02-06
- **Comment ID:** 2772288545
- **URL:** https://github.com/donghaozhang/video-agent-skill/pull/19#discussion_r2772288545

---

_⚠️ Potential issue_ | _🟡 Minor_

**Surround tables with blank lines.**

MD058 requires blank lines around tables.

<details>
<summary>✏️ Suggested change</summary>

```diff
-### Files to create
-| File | Purpose |
-|---|---|
-| `tests/test_t2v_cli.py` | Click CliRunner tests for text-to-video CLI |
-| `tests/test_i2v_cli.py` | Click CliRunner tests for image-to-video CLI |
-| `tests/test_unified_cli.py` | Click CliRunner tests for unified pipeline CLI |
-| `tests/test_cli_entry_points.py` | Entry point smoke tests |
+### Files to create
+
+| File | Purpose |
+|---|---|
+| `tests/test_t2v_cli.py` | Click CliRunner tests for text-to-video CLI |
+| `tests/test_i2v_cli.py` | Click CliRunner tests for image-to-video CLI |
+| `tests/test_unified_cli.py` | Click CliRunner tests for unified pipeline CLI |
+| `tests/test_cli_entry_points.py` | Entry point smoke tests |
+
```
</details>

<!-- suggestion_start -->

<details>
<summary>📝 Committable suggestion</summary>

> ‼️ **IMPORTANT**
> Carefully review the code before committing. Ensure that it accurately replaces the highlighted code, contains no missing lines, and has no issues with indentation. Thoroughly test & benchmark the code to ensure it meets the requirements.

```suggestion
### Files to create

| File | Purpose |
|---|---|
| `tests/test_t2v_cli.py` | Click CliRunner tests for text-to-video CLI |
| `tests/test_i2v_cli.py` | Click CliRunner tests for image-to-video CLI |
| `tests/test_unified_cli.py` | Click CliRunner tests for unified pipeline CLI |
| `tests/test_cli_entry_points.py` | Entry point smoke tests |

```

</details>

<!-- suggestion_end -->

<details>
<summary>🧰 Tools</summary>

<details>
<summary>🪛 markdownlint-cli2 (0.20.0)</summary>

[warning] 529-529: Tables should be surrounded by blank lines

(MD058, blanks-around-tables)

</details>

</details>

<details>
<summary>🤖 Prompt for AI Agents</summary>

```
In `@issues/unify-cli-framework.md` around lines 528 - 535, The Markdown table
under the "### Files to create" heading violates MD058 by not being surrounded
by blank lines; add a single blank line immediately before the table and a
single blank line immediately after it so the block is separated from the
surrounding text. Update the section containing the table listing
`tests/test_t2v_cli.py`, `tests/test_i2v_cli.py`, `tests/test_unified_cli.py`,
and `tests/test_cli_entry_points.py` to include these blank lines.
```

</details>

<!-- fingerprinting:phantom:triton:eagle -->

<!-- This is an auto-generated comment by CodeRabbit -->
