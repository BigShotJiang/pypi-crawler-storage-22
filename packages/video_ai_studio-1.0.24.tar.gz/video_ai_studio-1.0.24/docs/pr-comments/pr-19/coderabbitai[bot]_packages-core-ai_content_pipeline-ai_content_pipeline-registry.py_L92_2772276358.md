# Review Comment

- **Author:** coderabbitai[bot]
- **File:** `packages/core/ai_content_pipeline/ai_content_pipeline/registry.py`
- **Line:** 92
- **Date:** 2026-02-06
- **Comment ID:** 2772276358
- **URL:** https://github.com/donghaozhang/video-agent-skill/pull/19#discussion_r2772276358

---

_⚠️ Potential issue_ | _🟡 Minor_

<details>
<summary>🧩 Analysis chain</summary>

🏁 Script executed:

```shell
cat -n packages/core/ai_content_pipeline/ai_content_pipeline/registry.py | head -100
```

Repository: donghaozhang/video-agent-skill

Length of output: 4485

---

🏁 Script executed:

```shell
cat -n packages/core/ai_content_pipeline/ai_content_pipeline/registry.py | sed -n '86,150p'
```

Repository: donghaozhang/video-agent-skill

Length of output: 2287

---

🏁 Script executed:

```shell
cat -n packages/core/ai_content_pipeline/ai_content_pipeline/registry.py | tail -20
```

Repository: donghaozhang/video-agent-skill

Length of output: 829

---



</details>

**Add `ClassVar` annotation to `_models` class attribute.**

The `_models` attribute at line 92 is a class-level mutable dictionary accessed exclusively through `cls._models` in all methods. Ruff correctly flags mutable class attributes without explicit `ClassVar` annotation per PEP 526. Add the import and annotate as shown:

<details>
<summary>Suggested change</summary>

```diff
-from typing import Dict, List, Any
+from typing import Dict, List, Any, ClassVar

 class ModelRegistry:
     """Central registry for all AI models."""
-    _models: Dict[str, ModelDefinition] = {}
+    _models: ClassVar[Dict[str, ModelDefinition]] = {}
```
</details>

<details>
<summary>🧰 Tools</summary>

<details>
<summary>🪛 Ruff (0.14.14)</summary>

[warning] 92-92: Mutable class attributes should be annotated with `typing.ClassVar`

(RUF012)

</details>

</details>

<details>
<summary>🤖 Prompt for AI Agents</summary>

```
In `@packages/core/ai_content_pipeline/ai_content_pipeline/registry.py` at line
92, The class-level mutable dictionary _models should be annotated as a ClassVar
to satisfy PEP 526 and Ruff: add an import for ClassVar from typing and change
the declaration from "_models: Dict[str, ModelDefinition] = {}" to "_models:
ClassVar[Dict[str, ModelDefinition]] = {}", keeping the same name (_models) and
ModelDefinition type so all references to cls._models remain valid.
```

</details>

<!-- fingerprinting:phantom:medusa:eagle -->

<!-- This is an auto-generated comment by CodeRabbit -->
