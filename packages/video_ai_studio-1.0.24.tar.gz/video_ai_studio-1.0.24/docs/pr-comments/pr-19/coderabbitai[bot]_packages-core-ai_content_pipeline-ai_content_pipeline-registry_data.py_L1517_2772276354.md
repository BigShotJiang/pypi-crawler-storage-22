# Review Comment

- **Author:** coderabbitai[bot]
- **File:** `packages/core/ai_content_pipeline/ai_content_pipeline/registry_data.py`
- **Line:** 1517
- **Date:** 2026-02-06
- **Comment ID:** 2772276354
- **URL:** https://github.com/donghaozhang/video-agent-skill/pull/19#discussion_r2772276354

---

_⚠️ Potential issue_ | _🟠 Major_

**File exceeds 500-line limit — needs modular split.**  
This new module is far over the 500-line cap. Please split by category (e.g., registry_data_text_to_video.py, registry_data_image_to_video.py, etc.) and import them from a thin registry_data.py aggregator.  


As per coding guidelines, "Never create a file longer than 500 lines of code. If a file approaches this limit, refactor by splitting it into modules or helper files."

<details>
<summary>🤖 Prompt for AI Agents</summary>

```
In `@packages/core/ai_content_pipeline/ai_content_pipeline/registry_data.py`
around lines 1 - 1517, The file is >500 lines and must be split; refactor
registry_data.py by extracting category blocks into separate modules (e.g.,
registry_data_text_to_video.py, registry_data_image_to_video.py,
registry_data_image_to_image.py, registry_data_avatar.py,
registry_data_video_to_video.py, registry_data_text_to_image.py,
registry_data_text_to_speech.py, registry_data_image_understanding.py,
registry_data_prompt_generation.py, registry_data_speech_to_text.py) each
containing the ModelRegistry.register(ModelDefinition(...)) calls for that
category and a local register_all_models() or register_models() function; leave
a thin aggregator registry_data.py that imports those modules and calls their
register functions (or re-exports a single register_all_models that delegates to
each submodule), preserving existing symbols like register_all_models,
ModelRegistry.register, and ModelDefinition so external callers are unaffected.
Ensure no duplicate registrations and run tests to confirm behavior unchanged.
```

</details>

<!-- fingerprinting:phantom:poseidon:eagle -->

<!-- This is an auto-generated comment by CodeRabbit -->
