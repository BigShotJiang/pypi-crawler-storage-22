# Review Comment

- **Author:** coderabbitai[bot]
- **File:** `scripts/validate_registry.py`
- **Line:** 71
- **Date:** 2026-02-06
- **Comment ID:** 2772276387
- **URL:** https://github.com/donghaozhang/video-agent-skill/pull/19#discussion_r2772276387

---

_⚠️ Potential issue_ | _🟡 Minor_

**Fragile instantiation pattern using `__new__` bypasses `__init__`.**

Using `__new__` and manually calling `_build_models()` bypasses the class's `__init__` method. If `FALImageToVideoGenerator.__init__` performs important setup, this validation will break or produce incorrect results.


<details>
<summary>🔧 Proposed fix: Use normal instantiation</summary>

```diff
     # 6. Check image-to-video models
     try:
         from fal_image_to_video.generator import FALImageToVideoGenerator
-        gen = FALImageToVideoGenerator.__new__(FALImageToVideoGenerator)
-        gen.models = FALImageToVideoGenerator._build_models()
+        gen = FALImageToVideoGenerator()
         i2v_keys = ModelRegistry.provider_keys_for_category("image_to_video")
         for key in i2v_keys:
             if key not in gen.models:
                 errors.append(f"image_to_video model '{key}' has no class")
```
</details>

<!-- suggestion_start -->

<details>
<summary>📝 Committable suggestion</summary>

> ‼️ **IMPORTANT**
> Carefully review the code before committing. Ensure that it accurately replaces the highlighted code, contains no missing lines, and has no issues with indentation. Thoroughly test & benchmark the code to ensure it meets the requirements.

```suggestion
    # 6. Check image-to-video models
    try:
        from fal_image_to_video.generator import FALImageToVideoGenerator
        try:
            gen = FALImageToVideoGenerator()
        except TypeError:
            # Fallback to __new__ pattern if normal instantiation requires args
            gen = FALImageToVideoGenerator.__new__(FALImageToVideoGenerator)
            gen.models = FALImageToVideoGenerator._build_models()
        i2v_keys = ModelRegistry.provider_keys_for_category("image_to_video")
        for key in i2v_keys:
            if key not in gen.models:
                errors.append(f"image_to_video model '{key}' has no class")
    except ImportError:
        errors.append("Could not import fal_image_to_video.generator")
```

</details>

<!-- suggestion_end -->

<details>
<summary>🤖 Prompt for AI Agents</summary>

```
In `@scripts/validate_registry.py` around lines 62 - 71, Replace the fragile
bypass of __init__ for FALImageToVideoGenerator by constructing the class
normally: use gen = FALImageToVideoGenerator() (instead of __new__) and then
call the builder on the instance (e.g., gen.models = gen._build_models() or
models = gen._build_models()) so any __init__ setup runs before you inspect
gen.models; keep the rest of the logic that uses
ModelRegistry.provider_keys_for_category("image_to_video") and appends to errors
unchanged, and still catch ImportError as before.
```

</details>

<!-- fingerprinting:phantom:medusa:ocelot -->

<!-- This is an auto-generated comment by CodeRabbit -->
