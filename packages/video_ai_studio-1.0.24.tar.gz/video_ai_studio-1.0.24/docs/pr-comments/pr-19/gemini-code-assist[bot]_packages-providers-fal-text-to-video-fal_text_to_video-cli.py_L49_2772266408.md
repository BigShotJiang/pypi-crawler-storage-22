# Review Comment

- **Author:** gemini-code-assist[bot]
- **File:** `packages/providers/fal/text-to-video/fal_text_to_video/cli.py`
- **Line:** 49
- **Date:** 2026-02-06
- **Comment ID:** 2772266408
- **URL:** https://github.com/donghaozhang/video-agent-skill/pull/19#discussion_r2772266408

---

![critical](https://www.gstatic.com/codereviewagent/critical.svg)

There's a critical type mismatch bug here. The `args.duration` from `argparse` is always a string. However, some models, like `sora_2` and `sora_2_pro`, are defined in the registry to expect an integer for their duration. Passing a string will cause a `ValueError` during the model's parameter validation.

To fix this, you should inspect the model's definition from the registry to determine the expected type for the duration and cast `args.duration` accordingly before passing it to the generator.

```python
    model_def = ModelRegistry.get(args.model)
    if args.duration:
        # Cast duration to the correct type based on the model's definition.
        if model_def.duration_options and isinstance(model_def.duration_options[0], int):
            kwargs["duration"] = int(args.duration)
        else:
            kwargs["duration"] = args.duration
    else:
        kwargs["duration"] = model_def.defaults.get("duration", "5")

    kwargs["aspect_ratio"] = args.aspect_ratio
    if hasattr(args, "cfg_scale") and args.cfg_scale is not None:
        kwargs["cfg_scale"] = args.cfg_scale
    if hasattr(args, "audio") and args.audio:
        kwargs["generate_audio"] = True
    if args.negative_prompt:
        kwargs["negative_prompt"] = args.negative_prompt
    if hasattr(args, "resolution") and args.resolution:
        kwargs["resolution"] = args.resolution
    if hasattr(args, "keep_remote") and args.keep_remote:
        kwargs["delete_video"] = False
```
