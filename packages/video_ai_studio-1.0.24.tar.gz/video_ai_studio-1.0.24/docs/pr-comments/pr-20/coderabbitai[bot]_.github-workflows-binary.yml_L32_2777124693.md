# Review Comment

- **Author:** coderabbitai[bot]
- **File:** `.github/workflows/binary.yml`
- **Line:** 32
- **Date:** 2026-02-07
- **Comment ID:** 2777124693
- **URL:** https://github.com/donghaozhang/video-agent-skill/pull/20#discussion_r2777124693

---

_⚠️ Potential issue_ | _🟠 Major_

<details>
<summary>🧩 Analysis chain</summary>

🌐 Web query:

`GitHub Actions macOS runner labels 2024 2025 supported versions`

💡 Result:

### GitHub Actions macOS runner labels (supported in **2024–2025**)

| Workflow label | macOS version / notes | Support status (key dates) |
|---|---|---|
| `macos-12` | macOS 12 Monterey | **Deprecated** starting **Oct 7, 2024**; **unsupported on GitHub Actions after Dec 3, 2024**. ([github.com](https://github.com/actions/runner-images/issues/10721?utm_source=openai)) |
| `macos-13` | macOS 13 Ventura (Intel in GitHub Docs table; plus related “large/xlarge” variants referenced in changelog) | Retirement announced: **retired by Dec 4, 2025** (with brownouts in Nov 2025). ([github.blog](https://github.blog/changelog/2025-09-19-github-actions-macos-13-runner-image-is-closing-down?utm_source=openai)) |
| `macos-14` | macOS 14 (arm64) | Supported label listed in GitHub Docs and runner-images “Available Images”. ([docs.github.com](https://docs.github.com/en/actions/reference/github-hosted-runners-reference?utm_source=openai)) |
| `macos-15` | macOS 15 (arm64) | Supported; became the target for `macos-latest` migration in 2025. ([docs.github.com](https://docs.github.com/en/actions/reference/github-hosted-runners-reference?utm_source=openai)) |
| `macos-15-intel` | macOS 15 on x86_64 (Intel) | Added as an Intel option; listed in GitHub Docs. ([docs.github.com](https://docs.github.com/en/actions/reference/github-hosted-runners-reference?utm_source=openai)) |
| `macos-latest` | “latest GA” macOS runner label | Migrated from macOS 14 to **macOS 15** beginning **Aug 4, 2025**, completing by **Sep 1, 2025** (changelog). ([github.blog](https://github.blog/changelog/2025-07-11-upcoming-changes-to-macos-hosted-runners-macos-latest-migration-and-xcode-support-policy-updates?utm_source=openai)) |
| `macos-26` | macOS 26 (arm64) | **Public preview / beta** label shown in GitHub Docs and runner-images list. ([docs.github.com](https://docs.github.com/en/actions/reference/github-hosted-runners-reference?utm_source=openai)) |

**Where to confirm “currently available” images/labels:** the `actions/runner-images` repo “Available Images” table is the most direct, up-to-date mapping of YAML labels → images. ([github.com](https://github.com/actions/runner-images?utm_source=openai))

Citations:

- 1: https://github.com/actions/runner-images/issues/10721?utm_source=openai
- 2: https://github.blog/changelog/2025-09-19-github-actions-macos-13-runner-image-is-closing-down?utm_source=openai
- 3: https://docs.github.com/en/actions/reference/github-hosted-runners-reference?utm_source=openai
- 4: https://docs.github.com/en/actions/reference/github-hosted-runners-reference?utm_source=openai
- 5: https://docs.github.com/en/actions/reference/github-hosted-runners-reference?utm_source=openai
- 6: https://github.blog/changelog/2025-07-11-upcoming-changes-to-macos-hosted-runners-macos-latest-migration-and-xcode-support-policy-updates?utm_source=openai
- 7: https://docs.github.com/en/actions/reference/github-hosted-runners-reference?utm_source=openai
- 8: https://github.com/actions/runner-images?utm_source=openai

---



</details>

**Fix unsupported macOS runner label.**

`macos-13` is retired as of December 4, 2025 and no longer available for GitHub Actions workflows. Update to `macos-15-intel` for x86_64 Intel builds.

<details>
<summary>Suggested edit</summary>

```diff
-          - os: macos-13
+          - os: macos-15-intel
             artifact_name: aicp-macos-x86_64
```
</details>

<details>
<summary>🧰 Tools</summary>

<details>
<summary>🪛 actionlint (1.7.10)</summary>

[error] 29-29: label "macos-13" is unknown. available labels are "windows-latest", "windows-latest-8-cores", "windows-2025", "windows-2022", "windows-11-arm", "ubuntu-slim", "ubuntu-latest", "ubuntu-latest-4-cores", "ubuntu-latest-8-cores", "ubuntu-latest-16-cores", "ubuntu-24.04", "ubuntu-24.04-arm", "ubuntu-22.04", "ubuntu-22.04-arm", "macos-latest", "macos-latest-xlarge", "macos-latest-large", "macos-26-xlarge", "macos-26", "macos-15-intel", "macos-15-xlarge", "macos-15-large", "macos-15", "macos-14-xlarge", "macos-14-large", "macos-14", "self-hosted", "x64", "arm", "arm64", "linux", "macos", "windows". if it is a custom label for self-hosted runner, set list of labels in actionlint.yaml config file

(runner-label)

</details>

</details>

<details>
<summary>🤖 Prompt for AI Agents</summary>

```
In @.github/workflows/binary.yml around lines 24 - 32, Update the retired runner
label macos-13 to the supported intel runner macos-15-intel for the x86_64 macOS
artifact; specifically replace the os value "macos-13" that corresponds to
artifact_name "aicp-macos-x86_64" with "macos-15-intel" so the workflow uses the
current macOS Intel runner.
```

</details>

<!-- fingerprinting:phantom:poseidon:eagle -->

<!-- This is an auto-generated comment by CodeRabbit -->
