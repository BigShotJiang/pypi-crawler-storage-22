# Review Comment

- **Author:** coderabbitai[bot]
- **File:** `.github/workflows/on-merge.yml`
- **Line:** 299
- **Date:** 2026-02-07
- **Comment ID:** 2777129363
- **URL:** https://github.com/donghaozhang/video-agent-skill/pull/20#discussion_r2777129363

---

_⚠️ Potential issue_ | _🟠 Major_

**Script injection risk with untrusted PR title in release notes.**

The PR title is interpolated directly into the inline script via `${{ github.event.pull_request.title }}`. A malicious PR title containing shell metacharacters could break the script or execute unintended commands. Pass it through an environment variable instead.

<details>
<summary>🔒 Proposed fix: Pass PR title through environment variable</summary>

```diff
       - name: Create latest release
+        env:
+          GITHUB_TOKEN: ${{ secrets.GITHUB_TOKEN }}
+          PR_TITLE: ${{ github.event.pull_request.title }}
+          PR_NUMBER: ${{ github.event.pull_request.number }}
+          VERSION: ${{ steps.version.outputs.VERSION }}
         run: |
           gh release create latest \
-            --title "Latest Build (v${{ steps.version.outputs.VERSION }})" \
+            --title "Latest Build (v${VERSION})" \
             --notes "$(cat <<NOTES
           ## Latest Build
 
-          **Version**: ${{ steps.version.outputs.VERSION }}
-          **PR**: #${{ github.event.pull_request.number }} — ${{ github.event.pull_request.title }}
+          **Version**: ${VERSION}
+          **PR**: #${PR_NUMBER} — ${PR_TITLE}
           **Updated**: $(date -u +%Y-%m-%d\ %H:%M\ UTC)
 
           ### Install
           ...
           NOTES
           )" \
             --prerelease \
             release-assets/*
-        env:
-          GITHUB_TOKEN: ${{ secrets.GITHUB_TOKEN }}
```
</details>

Note: Also remove the single quotes from `<<'NOTES'` to `<<NOTES` so shell variables expand properly.

<details>
<summary>🧰 Tools</summary>

<details>
<summary>🪛 actionlint (1.7.10)</summary>

[error] 262-262: "github.event.pull_request.title" is potentially untrusted. avoid using it directly in inline scripts. instead, pass it through an environment variable. see https://docs.github.com/en/actions/reference/security/secure-use#good-practices-for-mitigating-script-injection-attacks for more details

(expression)

</details>

</details>

<details>
<summary>🤖 Prompt for AI Agents</summary>

```
In @.github/workflows/on-merge.yml around lines 261 - 299, The release notes
currently interpolate the PR title directly via ${{
github.event.pull_request.title }}, which risks shell injection; instead set an
environment variable (e.g. PR_TITLE="${{ github.event.pull_request.title }}")
before running gh and reference that variable inside the heredoc, and change the
heredoc delimiter from <<'NOTES' to <<NOTES so shell variables expand; update
the block that calls gh release create latest (and the --notes heredoc) to use
$PR_TITLE rather than the GitHub expression to avoid direct script injection.
```

</details>

<!-- fingerprinting:phantom:poseidon:ocelot -->

<!-- This is an auto-generated comment by CodeRabbit -->
