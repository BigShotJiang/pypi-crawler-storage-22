# Review Comment

- **Author:** coderabbitai[bot]
- **File:** `.github/workflows/publish-check.yml`
- **Line:** 41
- **Date:** 2026-02-07
- **Comment ID:** 2777124694
- **URL:** https://github.com/donghaozhang/video-agent-skill/pull/20#discussion_r2777124694

---

_⚠️ Potential issue_ | _🔴 Critical_

**Fix Python `-c` quoting that breaks version extraction.**

Line 36’s inline Python uses nested quotes that trigger a SyntaxError (matches the pipeline failure). Use a heredoc to avoid shell-escaping issues.

<details>
<summary>🧩 Suggested fix</summary>

```diff
-          BASE=$(python -c "
-          import re
-          with open('packages/core/ai_content_pipeline/ai_content_pipeline/_version.py') as f:
-              match = re.search(r'__version__\s*=\s*[\"'\''](.*?)[\"'\'']', f.read())
-              print(match.group(1))
-          ")
+          BASE=$(python - <<'PY'
+import re
+from pathlib import Path
+
+text = Path("packages/core/ai_content_pipeline/ai_content_pipeline/_version.py").read_text(encoding="utf-8")
+match = re.search(r'__version__\s*=\s*["\']([^"\']+)["\']', text)
+print(match.group(1))
+PY
+          )
```
</details>

<!-- suggestion_start -->

<details>
<summary>📝 Committable suggestion</summary>

> ‼️ **IMPORTANT**
> Carefully review the code before committing. Ensure that it accurately replaces the highlighted code, contains no missing lines, and has no issues with indentation. Thoroughly test & benchmark the code to ensure it meets the requirements.

```suggestion
      - name: Compute dev version
        id: version
        run: |
          BASE=$(python - <<'PY'
import re
from pathlib import Path

text = Path("packages/core/ai_content_pipeline/ai_content_pipeline/_version.py").read_text(encoding="utf-8")
match = re.search(r'__version__\s*=\s*["\']([^"\']+)["\']', text)
print(match.group(1))
PY
          )
```

</details>

<!-- suggestion_end -->

<details>
<summary>🤖 Prompt for AI Agents</summary>

```
In @.github/workflows/publish-check.yml around lines 33 - 41, The inline Python
in the "Compute dev version" step (id: version) uses nested shell quotes and
breaks; replace the python -c invocation with a heredoc invocation (python
<<'PY' ... PY) that reads
packages/core/ai_content_pipeline/ai_content_pipeline/_version.py and runs the
same re.search for __version__ to print match.group(1), so you avoid
shell-escaping issues with the regex string.
```

</details>

<!-- fingerprinting:phantom:poseidon:eagle -->

<!-- This is an auto-generated comment by CodeRabbit -->
