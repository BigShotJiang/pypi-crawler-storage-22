# Review Comment

- **Author:** coderabbitai[bot]
- **File:** `issues/completed/subtask-3-stdin-stdout.md`
- **Line:** 56
- **Date:** 2026-02-07
- **Comment ID:** 2777124699
- **URL:** https://github.com/donghaozhang/video-agent-skill/pull/20#discussion_r2777124699

---

_⚠️ Potential issue_ | _🟡 Minor_

**Documentation inconsistency: code example doesn't match implementation summary.**

The implementation summary (lines 11-12) states that `read_input()` "Raises `ValueError` for TTY stdin" and "Raises `FileNotFoundError` for missing files" with mapping via the exit_codes module. However, the code example shows direct `sys.exit()` calls:

- Line 47: `sys.exit(2)` instead of raising `ValueError`
- Line 53: `sys.exit(3)` instead of raising `FileNotFoundError`

This contradicts the centralized error handling approach mentioned in the PR objectives. The code example should raise exceptions that the CLI layer catches and maps to exit codes.



<details>
<summary>📝 Proposed fix to align with implementation summary</summary>

```diff
 def read_input(input_arg: Optional[str], fallback: Optional[str] = None) -> Optional[str]:
     """Read input from a file path, stdin ('-'), or use fallback.
 
     Args:
         input_arg: File path, '-' for stdin, or None.
         fallback: Value to return if input_arg is None.
 
     Returns:
         The input text, or None if no input available.
+    
+    Raises:
+        ValueError: If stdin is a TTY (not piped).
+        FileNotFoundError: If the specified file does not exist.
     """
     if input_arg == '-':
         if sys.stdin.isatty():
-            print("error: --input - requires piped input (stdin is a terminal)",
-                  file=sys.stderr)
-            sys.exit(2)
+            raise ValueError("--input - requires piped input (stdin is a terminal)")
         return sys.stdin.read().strip()
     elif input_arg:
         path = Path(input_arg)
         if not path.exists():
-            print(f"error: input file not found: {input_arg}", file=sys.stderr)
-            sys.exit(3)
+            raise FileNotFoundError(f"input file not found: {input_arg}")
         return path.read_text().strip()
     return fallback
```

The CLI layer should then catch these exceptions and use `error_exit()` from the exit_codes module.
</details>

<details>
<summary>🤖 Prompt for AI Agents</summary>

```
In `@issues/subtask-3-stdin-stdout.md` around lines 32 - 56, The read_input
function currently calls sys.exit(...) directly which contradicts the docstring
and centralized error handling; change the behavior in read_input: when
input_arg == '-' and stdin is a TTY raise a ValueError (with a descriptive
message) instead of sys.exit(2), and when a provided path does not exist raise a
FileNotFoundError (with a descriptive message) instead of sys.exit(3); keep
returning strings otherwise and let the CLI layer catch these exceptions and map
them to exit codes via the exit_codes/error_exit mechanism.
```

</details>

<!-- fingerprinting:phantom:triton:puma -->

<!-- This is an auto-generated comment by CodeRabbit -->
