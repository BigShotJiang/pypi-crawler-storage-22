# Review Comment

- **Author:** coderabbitai[bot]
- **File:** `issues/plan-unix-style-migration.md`
- **Line:** 1
- **Date:** 2026-02-07
- **Comment ID:** 2777111270
- **URL:** https://github.com/donghaozhang/video-agent-skill/pull/20#discussion_r2777111270

---

_⚠️ Potential issue_ | _🟡 Minor_

**Hyphenate the compound modifier in the title.**

Use “Unix/Linux-style” instead of “Unix/Linux Style” for correct compound-modifier hyphenation.

<details>
<summary>🧰 Tools</summary>

<details>
<summary>🪛 LanguageTool</summary>

[grammar] ~1-~1: Use a hyphen to join words.
Context: # Implementation Plan: Unix/Linux Style Framework Migration  **Issue**: [f...

(QB_NEW_EN_HYPHEN)

</details>

</details>

<details>
<summary>🤖 Prompt for AI Agents</summary>

```
In `@issues/plan-unix-style-migration.md` at line 1, Update the document title
string "Unix/Linux Style Framework Migration" to use a hyphenated compound
modifier by changing it to "Unix/Linux-style Framework Migration" so the title
reads correctly; locate and edit the header text in the file where the top-level
title variable or literal "# Implementation Plan: Unix/Linux Style Framework
Migration" is defined and replace it with "# Implementation Plan:
Unix/Linux-style Framework Migration".
```

</details>

<!-- fingerprinting:phantom:triton:eagle -->

<!-- This is an auto-generated comment by CodeRabbit -->
