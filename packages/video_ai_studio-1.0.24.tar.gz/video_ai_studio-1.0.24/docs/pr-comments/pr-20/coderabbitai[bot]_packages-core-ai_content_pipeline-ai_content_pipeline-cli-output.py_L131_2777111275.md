# Review Comment

- **Author:** coderabbitai[bot]
- **File:** `packages/core/ai_content_pipeline/ai_content_pipeline/cli/output.py`
- **Line:** 131
- **Date:** 2026-02-07
- **Comment ID:** 2777111275
- **URL:** https://github.com/donghaozhang/video-agent-skill/pull/20#discussion_r2777111275

---

_⚠️ Potential issue_ | _🟡 Minor_

**Header order can drift from row values in human table output.**

When `headers` are provided, `row.values()` does not guarantee alignment with those headers, leading to mismatched columns. Consider using the header list to drive column order for dict rows.

<details>
<summary>Possible fix</summary>

```diff
-            for row in rows:
-                if isinstance(row, dict):
-                    print("  ".join(f"{str(v):<20}" for v in row.values()))
-                else:
-                    print(str(row))
+            for row in rows:
+                if isinstance(row, dict):
+                    if headers:
+                        print("  ".join(f"{str(row.get(h, '')):<20}" for h in headers))
+                    else:
+                        print("  ".join(f"{str(v):<20}" for v in row.values()))
+                else:
+                    print(str(row))
```
</details>

<details>
<summary>🧰 Tools</summary>

<details>
<summary>🪛 Ruff (0.14.14)</summary>

[warning] 131-131: Use explicit conversion flag

Replace with conversion flag

(RUF010)

</details>

</details>

<details>
<summary>🤖 Prompt for AI Agents</summary>

```
In `@packages/core/ai_content_pipeline/ai_content_pipeline/cli/output.py` around
lines 126 - 131, The table printer uses row.values() which can misalign with
headers; change the logic in the loop that processes rows (look for the
variables headers and rows in output.py) so that when a row is a dict you
iterate over the headers list and fetch each cell by key (e.g., row.get(header,
"")) to produce columns in the same order as the printed headers and preserve
alignment for missing keys.
```

</details>

<!-- fingerprinting:phantom:poseidon:eagle -->

<!-- This is an auto-generated comment by CodeRabbit -->
