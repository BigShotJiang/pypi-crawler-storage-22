# Review Comment

- **Author:** coderabbitai[bot]
- **File:** `tests/test_exit_codes.py`
- **Line:** 205
- **Date:** 2026-02-07
- **Comment ID:** 2777111278
- **URL:** https://github.com/donghaozhang/video-agent-skill/pull/20#discussion_r2777111278

---

_⚠️ Potential issue_ | _🟠 Major_

**Add required type hints and Google-style docstrings to public test methods.**

All public test methods here should include parameter/return type hints and Google-style docstrings with Args, Returns, Cost, and Example sections.

As per coding guidelines: “All public methods in generator classes and test files must include type hints for parameters and return values”, “All public methods should include docstrings with Args, Returns, Cost information, and Example sections”, and “Write docstrings for every function using Google style format”.

<details>
<summary>🧰 Tools</summary>

<details>
<summary>🪛 Ruff (0.14.14)</summary>

[warning] 189-189: Abstract `raise` to an inner function

(TRY301)

---

[warning] 189-189: Avoid specifying long messages outside the exception class

(TRY003)

---

[warning] 199-199: Abstract `raise` to an inner function

(TRY301)

---

[warning] 199-199: Avoid specifying long messages outside the exception class

(TRY003)

</details>

</details>

<details>
<summary>🤖 Prompt for AI Agents</summary>

```
In `@tests/test_exit_codes.py` around lines 26 - 205, Update all public test
methods in TestExitCodeConstants, TestExitCodeForBuiltins,
TestExitCodeForFrameworkExceptions, TestRegisterException, and TestErrorExit to
include Python type hints and a minimal Google-style docstring (Args, Returns,
Cost, Example). For each method annotate parameters (self and fixtures like
capsys) and the return type as -> None, and add a brief Google-style docstring
describing the purpose, listing Args, Returns (None), Cost (O(1) or trivial),
and a one-line Example where applicable; target symbols include
test_success_is_zero, test_general_error_is_one, test_invalid_args_is_two,
test_missing_config_is_three, test_provider_error_is_four,
test_pipeline_error_is_five, test_value_error_maps_to_invalid_args,
test_file_not_found_maps_to_missing_config,
test_permission_error_maps_to_missing_config,
test_unknown_exception_maps_to_general_error,
test_type_error_maps_to_general_error, _ensure_registered,
test_validation_error_maps_to_invalid_args,
test_configuration_error_maps_to_missing_config,
test_pipeline_config_error_maps_to_missing_config,
test_api_key_error_maps_to_missing_config,
test_service_not_available_maps_to_provider_error,
test_step_execution_error_maps_to_pipeline_error,
test_pipeline_execution_error_maps_to_pipeline_error,
test_register_custom_exception, test_subclass_inherits_mapping,
test_exits_with_mapped_code_for_value_error,
test_exits_with_mapped_code_for_file_not_found,
test_exits_with_general_error_for_unknown_exception,
test_exits_with_general_error_for_string_message, test_prints_error_to_stderr,
test_debug_mode_prints_traceback, and test_no_traceback_without_debug. Ensure
docstrings use Google style and are concise; do not change test logic or
assertions.
```

</details>

<!-- fingerprinting:phantom:poseidon:eagle -->

<!-- This is an auto-generated comment by CodeRabbit -->
