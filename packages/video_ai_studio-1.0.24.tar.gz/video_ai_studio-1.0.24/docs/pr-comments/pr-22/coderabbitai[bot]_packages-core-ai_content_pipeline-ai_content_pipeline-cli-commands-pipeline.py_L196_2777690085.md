# Review Comment

- **Author:** coderabbitai[bot]
- **File:** `packages/core/ai_content_pipeline/ai_content_pipeline/cli/commands/pipeline.py`
- **Line:** 196
- **Date:** 2026-02-07
- **Comment ID:** 2777690085
- **URL:** https://github.com/donghaozhang/video-agent-skill/pull/22#discussion_r2777690085

---

_⚠️ Potential issue_ | _🟠 Major_

<details>
<summary>🧩 Analysis chain</summary>

🏁 Script executed:

```shell
find . -type f -name "pipeline.py" | grep -E "cli/commands"
```

Repository: donghaozhang/video-agent-skill

Length of output: 154

---

🏁 Script executed:

```shell
cat -n packages/core/ai_content_pipeline/ai_content_pipeline/cli/commands/pipeline.py | head -220 | tail -40
```

Repository: donghaozhang/video-agent-skill

Length of output: 1943

---

🏁 Script executed:

```shell
# Search for the create_video_cmd function implementation
rg -A 30 "def create_video_cmd" packages/core/ai_content_pipeline/
```

Repository: donghaozhang/video-agent-skill

Length of output: 3579

---

🏁 Script executed:

```shell
# Check if there's any handling of output_dir default downstream
rg -B 5 -A 10 "output_dir" packages/core/ai_content_pipeline/ai_content_pipeline/cli/commands/pipeline.py
```

Repository: donghaozhang/video-agent-skill

Length of output: 5794

---

🏁 Script executed:

```shell
find . -type f -name "manager.py" | grep pipeline
```

Repository: donghaozhang/video-agent-skill

Length of output: 149

---

🏁 Script executed:

```shell
# Search for quick_create_video method implementation
rg -B 5 -A 20 "def quick_create_video" packages/core/ai_content_pipeline/
```

Repository: donghaozhang/video-agent-skill

Length of output: 2875

---

🏁 Script executed:

```shell
# Check if result_folder is used in the codebase as the default output directory
rg "result_folder" packages/core/ai_content_pipeline/
```

Repository: donghaozhang/video-agent-skill

Length of output: 56

---

🏁 Script executed:

```shell
cat -n packages/core/ai_content_pipeline/ai_content_pipeline/pipeline/manager.py | grep -A 40 "def quick_create_video"
```

Repository: donghaozhang/video-agent-skill

Length of output: 1738

---

🏁 Script executed:

```shell
# Also check what the default output directory really is
rg -B 5 -A 15 "output_dir or|output_dir if|output_dir ==" packages/core/ai_content_pipeline/
```

Repository: donghaozhang/video-agent-skill

Length of output: 2344

---

🏁 Script executed:

```shell
# Check the entire manager class initialization and defaults
rg "self.output_dir" packages/core/ai_content_pipeline/ai_content_pipeline/pipeline/manager.py
```

Repository: donghaozhang/video-agent-skill

Length of output: 220

---



</details>

**Default video output directory should use `result_folder/` per coding guidelines.**

The `--output-dir` option defaults to `None`, which causes the video output to use the manager's default of `output/` directory. However, the coding guidelines explicitly require: "Store generated video outputs in result_folder/ directory". The CLI should enforce this guideline.

<details>
<summary>🔧 Suggested change</summary>

```diff
-@click.option("--output-dir", default=None, help="Output directory")
+@click.option("--output-dir", default="result_folder", help="Output directory")
```
</details>

<details>
<summary>🤖 Prompt for AI Agents</summary>

```
In
`@packages/core/ai_content_pipeline/ai_content_pipeline/cli/commands/pipeline.py`
around lines 189 - 196, The --output-dir Click option in the create-video
command currently defaults to None which falls back to the manager's "output/";
change the Click option declaration for create-video (the
`@click.command`("create-video") block and its --output-dir option) to set
default="result_folder/" and show_default=True so generated videos are stored in
result_folder/ per guidelines and the CLI help displays the default.
```

</details>

<!-- fingerprinting:phantom:medusa:eagle -->

<!-- This is an auto-generated comment by CodeRabbit -->
