# Review Comment

- **Author:** coderabbitai[bot]
- **File:** `packages/core/ai_content_platform/vimax/agents/storyboard_artist.py`
- **Line:** 111
- **Date:** 2026-02-07
- **Comment ID:** 2777644867
- **URL:** https://github.com/donghaozhang/video-agent-skill/pull/22#discussion_r2777644867

---

_⚠️ Potential issue_ | _🟡 Minor_

**Use Google‑style docstring for `_build_prompt`.**  
Line 106 introduces a narrative docstring; please add Args/Returns sections to match the required format.

<details>
<summary>✍️ Suggested docstring update</summary>

```diff
-    """Build image generation prompt from shot description.
-
-    When character references have been resolved on the shot, appends
-    per-character appearance descriptions (dress, face, look) and an
-    instruction telling the model to use the input image for each character.
-    """
+    """Build image generation prompt from shot description.
+
+    Args:
+        shot: Shot description used to build the prompt.
+        scene: Parent scene context.
+        registry: Optional portrait registry for per-character descriptions.
+
+    Returns:
+        Full prompt string for image generation.
+    """
```
</details>
As per coding guidelines, "Write docstrings for every function using Google style format".

<details>
<summary>🤖 Prompt for AI Agents</summary>

```
In `@packages/core/ai_content_platform/vimax/agents/storyboard_artist.py` around
lines 100 - 111, The _build_prompt docstring is written as a narrative; convert
it to Google-style with Args and Returns sections: describe parameters shot
(ShotDescription), scene (Scene), and registry
(Optional[CharacterPortraitRegistry]) plus what each represents, and add a
Returns section stating it returns a str prompt; keep the existing summary and
note that per-character appearance descriptions and image-use instructions are
appended. Update only the docstring for the _build_prompt method to follow
Google style.
```

</details>

<!-- fingerprinting:phantom:poseidon:eagle -->

<!-- This is an auto-generated comment by CodeRabbit -->
