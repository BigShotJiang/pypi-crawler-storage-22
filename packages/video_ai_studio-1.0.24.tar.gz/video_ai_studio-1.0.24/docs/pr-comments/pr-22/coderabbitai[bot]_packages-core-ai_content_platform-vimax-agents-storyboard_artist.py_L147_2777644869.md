# Review Comment

- **Author:** coderabbitai[bot]
- **File:** `packages/core/ai_content_platform/vimax/agents/storyboard_artist.py`
- **Line:** 147
- **Date:** 2026-02-07
- **Comment ID:** 2777644869
- **URL:** https://github.com/donghaozhang/video-agent-skill/pull/22#discussion_r2777644869

---

_⚠️ Potential issue_ | _🟡 Minor_

**Guard reference instructions when no reference image is used.**  
Line 137 appends “Use the input image …” whenever `shot.character_references` exists, even if no `primary_reference_image` is passed. This can mislead the model when references are disabled or missing. Gate this block on actual reference usage.

<details>
<summary>✅ Suggested guard</summary>

```diff
-        if shot.character_references:
+        if (
+            self.config.use_character_references
+            and shot.primary_reference_image
+            and shot.character_references
+        ):
```
</details>

<details>
<summary>🤖 Prompt for AI Agents</summary>

```
In `@packages/core/ai_content_platform/vimax/agents/storyboard_artist.py` around
lines 136 - 147, The code appends "Use the input image for {name}." whenever
shot.character_references exists even if no reference image is actually
provided; update the block around shot.character_references so the "Use the
input image..." parts.append call is only executed when a reference image is
enabled/present (e.g., check shot.primary_reference_image or an explicit flag
that indicates reference usage) while still retrieving portraits via
registry.get_portrait and appending descriptions when available; modify the
logic in the loop that builds parts (the desc retrieval and parts.append calls)
so the descriptive append happens unconditionally when desc exists but the "Use
the input image..." append is conditioned on actual reference usage.
```

</details>

<!-- fingerprinting:phantom:poseidon:eagle -->

<!-- This is an auto-generated comment by CodeRabbit -->
