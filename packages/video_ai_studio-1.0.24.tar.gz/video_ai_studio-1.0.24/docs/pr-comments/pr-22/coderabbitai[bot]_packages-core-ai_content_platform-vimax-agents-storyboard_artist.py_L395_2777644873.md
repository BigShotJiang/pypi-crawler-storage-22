# Review Comment

- **Author:** coderabbitai[bot]
- **File:** `packages/core/ai_content_platform/vimax/agents/storyboard_artist.py`
- **Line:** 395
- **Date:** 2026-02-07
- **Comment ID:** 2777644873
- **URL:** https://github.com/donghaozhang/video-agent-skill/pull/22#discussion_r2777644873

---

_⚠️ Potential issue_ | _🟡 Minor_

**Gate reference instructions on actual reference usage in `generate_from_shots`.**  
Line 381 adds “Use the input image …” based on `shot.character_references` alone. Align this with `use_refs` and the presence of `shot.primary_reference_image`.

<details>
<summary>✅ Suggested guard</summary>

```diff
-            if shot.character_references:
+            if use_refs and shot.primary_reference_image and shot.character_references:
```
</details>

<details>
<summary>🤖 Prompt for AI Agents</summary>

```
In `@packages/core/ai_content_platform/vimax/agents/storyboard_artist.py` around
lines 381 - 395, In generate_from_shots, the prompt unconditionally appends "Use
the input image for {name}." whenever shot.character_references exist; change
this so that the prompt only adds that sentence when use_refs is truthy and the
shot actually has a primary reference image (shot.primary_reference_image); wrap
the prompt append in a guard checking use_refs and shot.primary_reference_image,
and ensure the earlier reference_image = shot.primary_reference_image if
use_refs else None remains the single source of truth for whether a reference is
available.
```

</details>

<!-- fingerprinting:phantom:poseidon:eagle -->

<!-- This is an auto-generated comment by CodeRabbit -->
