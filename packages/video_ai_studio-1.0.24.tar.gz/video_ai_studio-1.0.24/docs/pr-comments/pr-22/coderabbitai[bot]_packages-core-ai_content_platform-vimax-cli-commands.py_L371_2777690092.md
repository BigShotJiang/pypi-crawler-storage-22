# Review Comment

- **Author:** coderabbitai[bot]
- **File:** `packages/core/ai_content_platform/vimax/cli/commands.py`
- **Line:** 371
- **Date:** 2026-02-07
- **Comment ID:** 2777690092
- **URL:** https://github.com/donghaozhang/video-agent-skill/pull/22#discussion_r2777690092

---

_⚠️ Potential issue_ | _🟠 Major_

<details>
<summary>🧩 Analysis chain</summary>

🏁 Script executed:

```shell
find . -path "*/vimax/cli/commands.py" -type f
```

Repository: donghaozhang/video-agent-skill

Length of output: 131

---

🏁 Script executed:

```shell
cat -n ./packages/core/ai_content_platform/vimax/cli/commands.py | sed -n '355,385p'
```

Repository: donghaozhang/video-agent-skill

Length of output: 1599

---

🏁 Script executed:

```shell
cat -n ./packages/core/ai_content_platform/vimax/cli/commands.py | sed -n '300,375p'
```

Repository: donghaozhang/video-agent-skill

Length of output: 3900

---

🏁 Script executed:

```shell
find . -path "*/agents*" -name "*.py" -type f | grep -i storyboard
```

Repository: donghaozhang/video-agent-skill

Length of output: 143

---

🏁 Script executed:

```shell
wc -l ./packages/core/ai_content_platform/vimax/agents/storyboard_artist.py
```

Repository: donghaozhang/video-agent-skill

Length of output: 147

---

🏁 Script executed:

```shell
cat -n ./packages/core/ai_content_platform/vimax/agents/storyboard_artist.py | head -80
```

Repository: donghaozhang/video-agent-skill

Length of output: 3442

---

🏁 Script executed:

```shell
cat -n ./packages/core/ai_content_platform/vimax/agents/storyboard_artist.py | grep -A 30 "def resolve_references"
```

Repository: donghaozhang/video-agent-skill

Length of output: 1502

---

🏁 Script executed:

```shell
cat -n ./packages/core/ai_content_platform/vimax/agents/storyboard_artist.py | sed -n '155,200p'
```

Repository: donghaozhang/video-agent-skill

Length of output: 2175

---

🏁 Script executed:

```shell
cat -n ./packages/core/ai_content_platform/vimax/agents/storyboard_artist.py | sed -n '194,280p'
```

Repository: donghaozhang/video-agent-skill

Length of output: 4363

---



</details>

**Prevent overwriting existing inline references with registry resolution.**

The CLI unconditionally calls `resolve_references()` whenever a portrait registry is provided, which will overwrite any inline references already present in the script JSON. Gate the pre-resolution with `and not has_inline_refs` to match the protection in `StoryboardArtist.process()`.

<details>
<summary>🔧 Suggested change</summary>

```diff
-        if portrait_registry and len(portrait_registry.portraits) > 0:
+        if portrait_registry and len(portrait_registry.portraits) > 0 and not has_inline_refs:
             resolved = await artist.resolve_references(script_obj, portrait_registry)
             return resolved, await artist.process(script_obj, portrait_registry=portrait_registry)
```
</details>

<details>
<summary>🤖 Prompt for AI Agents</summary>

```
In `@packages/core/ai_content_platform/vimax/cli/commands.py` around lines 365 -
371, The run function currently always calls artist.resolve_references when
portrait_registry is present, which can overwrite inline refs; modify the guard
to only call resolve_references when portrait_registry and
portrait_registry.portraits exist AND the script has no inline refs (i.e., add a
check for not has_inline_refs or equivalent on script_obj) so it matches the
protection used in StoryboardArtist.process(); update the condition around
artist.resolve_references(script_obj, portrait_registry) and the subsequent
return accordingly.
```

</details>

<!-- fingerprinting:phantom:medusa:eagle -->

<!-- This is an auto-generated comment by CodeRabbit -->
