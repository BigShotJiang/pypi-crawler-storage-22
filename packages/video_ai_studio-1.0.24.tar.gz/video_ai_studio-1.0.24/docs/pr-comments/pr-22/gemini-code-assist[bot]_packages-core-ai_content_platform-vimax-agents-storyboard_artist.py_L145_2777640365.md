# Review Comment

- **Author:** gemini-code-assist[bot]
- **File:** `packages/core/ai_content_platform/vimax/agents/storyboard_artist.py`
- **Line:** 145
- **Date:** 2026-02-07
- **Comment ID:** 2777640365
- **URL:** https://github.com/donghaozhang/video-agent-skill/pull/22#discussion_r2777640365

---

![security-medium](https://www.gstatic.com/codereviewagent/security-medium-priority.svg) ![medium](https://www.gstatic.com/codereviewagent/medium-priority.svg)

User-provided character descriptions are concatenated directly into the image generation prompt. If a description in the portrait registry contains malicious instructions (e.g., prompt injection attacks), it can manipulate the behavior of the AI model. 

Consider sanitizing the description by removing or escaping characters that could be used for injection, such as newlines or brackets, or by using a more structured prompt format.

```suggestion
                if desc:
                    clean_desc = desc.replace("\n", " ").replace("[", "(").replace("]", ")")
                    parts.append(f"{name}: {clean_desc}.")
```
