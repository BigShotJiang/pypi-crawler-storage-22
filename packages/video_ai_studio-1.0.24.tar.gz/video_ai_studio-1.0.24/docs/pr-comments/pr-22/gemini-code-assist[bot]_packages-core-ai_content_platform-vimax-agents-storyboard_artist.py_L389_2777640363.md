# Review Comment

- **Author:** gemini-code-assist[bot]
- **File:** `packages/core/ai_content_platform/vimax/agents/storyboard_artist.py`
- **Line:** 389
- **Date:** 2026-02-07
- **Comment ID:** 2777640363
- **URL:** https://github.com/donghaozhang/video-agent-skill/pull/22#discussion_r2777640363

---

![security-medium](https://www.gstatic.com/codereviewagent/security-medium-priority.svg) ![medium](https://www.gstatic.com/codereviewagent/medium-priority.svg)

This block directly appends character descriptions to the prompt, making it susceptible to prompt injection if the description in the registry is malicious. It's crucial to sanitize inputs before using them in prompts. Additionally, this logic is nearly identical to that in the `_build_prompt` method; consider extracting it into a dedicated helper method to avoid code duplication and improve maintainability.

```suggestion
                    if desc:
                        clean_desc = desc.replace("\n", " ").replace("[", "(").replace("]", ")")
                        prompt += f" {name}: {clean_desc}."
```
