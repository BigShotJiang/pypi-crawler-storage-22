# Review Comment

- **Author:** gemini-code-assist[bot]
- **File:** `packages/core/ai_content_platform/vimax/agents/storyboard_artist.py`
- **Line:** 394
- **Date:** 2026-02-07
- **Comment ID:** 2777640362
- **URL:** https://github.com/donghaozhang/video-agent-skill/pull/22#discussion_r2777640362

---

![security-high](https://www.gstatic.com/codereviewagent/security-high-priority.svg) ![high](https://www.gstatic.com/codereviewagent/high-priority.svg)

This line uses the `primary_reference_image` from the shot, which may have been populated from an untrusted source (like an inline reference in a script JSON file). As with the resolution logic, this path should be validated before being used for file operations or uploads to prevent arbitrary file reading.

```python
            # Use pre-resolved reference from shot if it is a safe path
            reference_image = None
            if use_refs and shot.primary_reference_image:
                ref_path = Path(shot.primary_reference_image)
                if not ref_path.is_absolute() and ".." not in ref_path.parts:
                    reference_image = shot.primary_reference_image
```
