# Review Comment

- **Author:** gemini-code-assist[bot]
- **File:** `packages/core/ai_content_platform/vimax/cli/commands.py`
- **Line:** 395
- **Date:** 2026-02-07
- **Comment ID:** 2777640368
- **URL:** https://github.com/donghaozhang/video-agent-skill/pull/22#discussion_r2777640368

---

![medium](https://www.gstatic.com/codereviewagent/medium-priority.svg)

There's a logic issue here in how reference mappings are displayed. The `if ref_shots:` condition on line 378 means that if no shots are successfully resolved, no feedback is printed at all, even if there were characters that failed to match. This can be confusing for the user. To fix this, the feedback block should be entered if a `portrait_registry` was provided, regardless of whether any shots were resolved. This will ensure that the user is always informed about which characters could not be matched.
