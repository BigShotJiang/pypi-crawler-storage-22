# Review Comment

- **Author:** coderabbitai[bot]
- **File:** `issues/vmax-test-novel2movie-fixes.md`
- **Line:** 38
- **Date:** 2026-02-09
- **Comment ID:** 2780863595
- **URL:** https://github.com/donghaozhang/video-agent-skill/pull/24#discussion_r2780863595

---

_⚠️ Potential issue_ | _🟡 Minor_

**Capitalize “Markdown.”**

Use the proper noun for the formatting language.  


<details>
<summary>✏️ Proposed fix</summary>

```diff
-- Root cause: kimi-k2.5 LLM returns JSON with trailing commas, markdown code fences, and extra commentary text
+- Root cause: kimi-k2.5 LLM returns JSON with trailing commas, Markdown code fences, and extra commentary text
```
</details>

<details>
<summary>🧰 Tools</summary>

<details>
<summary>🪛 LanguageTool</summary>

[uncategorized] ~37-~37: Did you mean the formatting language “Markdown” (= proper noun)?
Context: ... LLM returns JSON with trailing commas, markdown code fences, and extra commentary text ...

(MARKDOWN_NNP)

</details>

</details>

<details>
<summary>🤖 Prompt for AI Agents</summary>

```
In `@issues/vmax-test-novel2movie-fixes.md` around lines 35 - 38, The
documentation line uses the lowercase word "markdown" instead of the proper noun
"Markdown"; update the text in the issue note (the header/description that
mentions the proposed fix and LLM parsing) to use "Markdown" with a capital M
wherever "markdown" appears (e.g., in the diff text referencing code fences and
parsing), ensuring the string in the commit/heading "fix: Robust JSON parsing
for LLM responses in character extractor and screenwriter" and related lines
mention "Markdown" correctly.
```

</details>

<!-- fingerprinting:phantom:poseidon:eagle -->

<!-- This is an auto-generated comment by CodeRabbit -->
