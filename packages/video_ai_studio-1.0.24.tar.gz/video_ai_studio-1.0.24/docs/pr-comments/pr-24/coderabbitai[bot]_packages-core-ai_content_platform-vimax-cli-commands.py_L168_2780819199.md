# Review Comment

- **Author:** coderabbitai[bot]
- **File:** `packages/core/ai_content_platform/vimax/cli/commands.py`
- **Line:** 168
- **Date:** 2026-02-09
- **Comment ID:** 2780819199
- **URL:** https://github.com/donghaozhang/video-agent-skill/pull/24#discussion_r2780819199

---

_⚠️ Potential issue_ | _🟡 Minor_

<details>
<summary>🧩 Analysis chain</summary>

🏁 Script executed:

```shell
# First, let's locate and examine the test file mentioned in the review
find . -path "*/tests/unit/vimax/test_cli.py" -type f
```

Repository: donghaozhang/video-agent-skill

Length of output: 104

---

🏁 Script executed:

```shell
# Also find the CLI commands file
find . -path "*/packages/core/ai_content_platform/vimax/cli/commands.py" -type f
```

Repository: donghaozhang/video-agent-skill

Length of output: 131

---

🏁 Script executed:

```shell
# Let's examine the test file around lines 53-58
cat -n ./tests/unit/vimax/test_cli.py | head -80
```

Repository: donghaozhang/video-agent-skill

Length of output: 3468

---

🏁 Script executed:

```shell
# Now let's examine the CLI commands file around lines 167-168 and 183-184
cat -n ./packages/core/ai_content_platform/vimax/cli/commands.py | sed -n '150,200p'
```

Repository: donghaozhang/video-agent-skill

Length of output: 2623

---

🏁 Script executed:

```shell
# Search for all occurrences of storyboard_only in test files
rg -n "storyboard_only|storyboard.only" tests/ --type=py -A 2 -B 2
```

Repository: donghaozhang/video-agent-skill

Length of output: 56

---



</details>

**Update mock function signature in tests to match the actual CLI implementation and add test coverage for `storyboard_only`.**

The mock `novel2movie` function at `tests/unit/vimax/test_cli.py:49-59` has signature `(novel, title, output, max_scenes)` but the actual implementation at `packages/core/ai_content_platform/vimax/cli/commands.py:158` includes additional parameters: `video_model`, `image_model`, and `storyboard_only`. Update the mock to match the real signature and add test cases covering the `storyboard_only` flag behavior (both enabled and disabled states). No existing tests cover this parameter.

<details>
<summary>🤖 Prompt for AI Agents</summary>

```
In `@packages/core/ai_content_platform/vimax/cli/commands.py` around lines 167 -
168, Update the tests to match the real CLI function signature and add coverage
for the storyboard_only flag: change the mock novel2movie in
tests/unit/vimax/test_cli.py to accept the full signature used by the CLI
(novel2movie(novel, title, output, max_scenes, video_model, image_model,
storyboard_only)) and adjust assertions to check those extra args as needed;
then add two test cases invoking the CLI with storyboard_only enabled and
disabled (e.g., via the CLI option or by passing storyboard_only) to assert the
CLI prints the correct mode string ("storyboard only (steps 1-5)" vs "full
pipeline") and that the mock was called with the expected storyboard_only
boolean.
```

</details>

<!-- fingerprinting:phantom:poseidon:ocelot -->

<!-- This is an auto-generated comment by CodeRabbit -->
