# Review Comment

- **Author:** coderabbitai[bot]
- **File:** `tests/unit/vimax/test_structured_output.py`
- **Line:** 198
- **Date:** 2026-02-10
- **Comment ID:** 2785197323
- **URL:** https://github.com/donghaozhang/video-agent-skill/pull/24#discussion_r2785197323

---

_⚠️ Potential issue_ | _🟡 Minor_

<details>
<summary>🧩 Analysis chain</summary>

🏁 Script executed:

```shell
find . -name "test_structured_output.py" -type f
```

Repository: donghaozhang/video-agent-skill

Length of output: 118

---

🏁 Script executed:

```shell
cat -n ./tests/unit/vimax/test_structured_output.py
```

Repository: donghaozhang/video-agent-skill

Length of output: 17904

---



</details>

**Replace generic `Exception` with `ValidationError` in pytest.raises**

Pydantic v2 raises `ValidationError` when a required field is missing; catching generic `Exception` obscures this specific validation error and can hide unrelated failures. Import and assert the specific exception type.

<details>
<summary>🔧 Suggested fix</summary>

```diff
-from pydantic import BaseModel
+from pydantic import BaseModel, ValidationError
...
-        with pytest.raises(Exception):
+        with pytest.raises(ValidationError):
             CharacterListResponse(**{"people": []})
```
</details>

<details>
<summary>🧰 Tools</summary>

<details>
<summary>🪛 Ruff (0.14.14)</summary>

[warning] 193-193: Do not assert blind exception: `Exception`

(B017)

</details>

</details>

<details>
<summary>🤖 Prompt for AI Agents</summary>

```
In `@tests/unit/vimax/test_structured_output.py` around lines 191 - 194, The test
test_character_list_rejects_missing_characters_key currently catches a generic
Exception; change it to catch pydantic.errors.ValidationError (import
ValidationError from pydantic) and use pytest.raises(ValidationError) when
constructing CharacterListResponse(**{"people": []}) so the test asserts the
specific schema validation error rather than any Exception.
```

</details>

<!-- fingerprinting:phantom:medusa:eagle -->

<!-- This is an auto-generated comment by CodeRabbit -->
