# Review Comment

- **Author:** gemini-code-assist[bot]
- **File:** `packages/core/ai_content_platform/vimax/pipelines/novel2movie.py`
- **Line:** 406
- **Date:** 2026-02-09
- **Comment ID:** 2780816243
- **URL:** https://github.com/donghaozhang/video-agent-skill/pull/24#discussion_r2780816243

---

![medium](https://www.gstatic.com/codereviewagent/medium-priority.svg)

The type hint for `characters` is `List[CharacterInNovel]`, and `CharacterInNovel` is a Pydantic `BaseModel`, so it should always have the `model_dump()` method. The `hasattr` check and fallback to `vars(c)` seems unnecessary and could lead to incorrect serialization if a non-Pydantic object ends up in the list. It's safer to rely on the type hint and just use `c.model_dump()`.

```suggestion
        data = [c.model_dump() for c in characters]
```
