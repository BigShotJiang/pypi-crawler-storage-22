# Higgsfield Music Video Grid - Creative Brief

**DIRECTIVE:** Generate a 3x3 chronological storytelling grid depicting a music video sequence inspired by Afroman's "Because I Got High."

## SUBJECT/CHARACTER DEFINITIONS

* **Afroman:** A Black man with a large, iconic 70s-style Afro, wearing a green vest and a gold chain, often holding an acoustic guitar.
* **Jay:** A thin man with long, straight blonde hair, a backwards yellow baseball cap, and an oversized yellow windbreaker.
* **Silent Bob:** A man with a thick, dark beard and long hair, wearing a backwards black baseball cap and a heavy dark green trench coat.
* **The Device:** A modern smartphone with a glowing screen displaying a vibrant lime green background, the black squiggly Higgsfield "S" logo, and the bold text "I got Higgs."

## PANELS & LAYOUT

| Panel | Description |
|-------|-------------|
| **Panel 1** | Establishing wide shot. Afroman, Jay, and Silent Bob sitting on a sunny, cluttered front porch. "TechTV" logo in the bottom right corner. |
| **Panel 2** | Close-up of Afroman looking at his smartphone with a surprised, happy expression. |
| **Panel 3** | Macro shot of the phone screen clearly showing the Higgsfield logo and the text "I got Higgs." |
| **Panel 4** | Medium shot of Jay and Silent Bob leaning in to look at the phone, smoke swirling around them. |
| **Panel 5** | Low-angle fisheye lens shot of the trio walking down a suburban street, Afroman triumphantly holding the phone up. |
| **Panel 6** | Medium shot of Afroman sitting on a couch in a hazy room, the green glow from the phone illuminating his face. |
| **Panel 7** | A "TechTV" news-style graphic overlaying a shot of the group dancing in front of a convenience store. |
| **Panel 8** | Over-the-shoulder shot of the phone being passed from Jay to Silent Bob. |
| **Panel 9** | Final wide shot. The trio staring blankly at the camera on the porch, the smartphone resting on a table in the foreground with the "I got Higgs" screen visible. |

## TECHNICAL SPECS

* **Style:** 2000s music video aesthetic, high color saturation, heavy film grain, and slight motion blur.
* **Lighting:** Warm, hazy golden hour lighting throughout.
* **Aspect Ratio:** Square (1:1) for each panel
* **Grid:** 3x3 layout

## STYLE PROMPT SUFFIX

```
2000s music video aesthetic, high color saturation, heavy film grain, slight motion blur, warm hazy golden hour lighting, cinematic composition
```
