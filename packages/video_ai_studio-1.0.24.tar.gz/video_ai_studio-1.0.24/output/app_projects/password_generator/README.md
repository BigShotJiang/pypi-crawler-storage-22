# Password Generator CLI

A secure command-line password generator written in Python.

## Features

- Generate cryptographically secure passwords using `secrets` module
- Customizable length (default: 16 characters)
- Include/exclude character types (uppercase, lowercase, digits, symbols)
- Generate multiple passwords at once
- Exclude specific ambiguous characters (like 0/O, 1/l/I)
- Presets for digits-only (PIN) and letters-only

## Installation

No external dependencies required - uses only Python standard library.

```bash
python password_gen.py --help
```

## Usage

### Basic Usage
```bash
python password_gen.py              # Generate 1 password (16 chars)
```

### Custom Length
```bash
python password_gen.py -l 24        # 24-character password
python password_gen.py --length 32  # 32-character password
```

### Multiple Passwords
```bash
python password_gen.py -n 5         # Generate 5 passwords
python password_gen.py -n 10 -l 20  # 10 passwords, 20 chars each
```

### Character Options
```bash
python password_gen.py --no-symbols     # No special characters
python password_gen.py --no-digits      # No numbers
python password_gen.py --no-uppercase   # No uppercase letters
python password_gen.py --digits-only    # Numeric PIN only
python password_gen.py --letters-only   # Letters only
```

### Exclude Ambiguous Characters
```bash
python password_gen.py --exclude "0O1lI"  # Exclude similar-looking chars
```

## Example Output

```bash
$ python password_gen.py
Xk9#mP2$vL8@nQ5!

$ python password_gen.py -n 3 -l 12
1. aB3$xY7@kM2!
2. pQ9#nL4$wR6@
3. zK5@mJ8#vX2$

$ python password_gen.py --digits-only -l 6
847291
```

## Files

- `password_gen.py` - Main application
- `test_password_gen.py` - Unit tests (10 tests)
- `README.md` - This file

## Running Tests

```bash
python -m pytest test_password_gen.py -v
```

## Security

- Uses Python's `secrets` module for cryptographically secure random generation
- Suitable for generating passwords, tokens, and security keys

## Requirements

- Python 3.6+
- No external dependencies
