# Task Manager CLI

A command-line task management application written in Python.

## Features

- **Add Tasks**: Create tasks with titles and optional descriptions
- **List Tasks**: View all tasks or filter by pending status
- **Complete/Uncomplete**: Mark tasks as done or reopen them
- **Update Tasks**: Modify task titles and descriptions
- **Delete Tasks**: Remove individual tasks
- **Clear Completed**: Bulk remove all completed tasks
- **Statistics**: View completion rates and task counts
- **Persistence**: Tasks are saved to JSON file automatically

## Installation

No external dependencies required - uses only Python standard library.

```bash
# Python 3.7+ required
python task_manager.py --help
```

## Usage

### Add a Task
```bash
python task_manager.py add "Buy groceries"
python task_manager.py add "Write report" -d "Q4 financial report"
```

### List Tasks
```bash
python task_manager.py list              # All tasks
python task_manager.py list --pending    # Only pending tasks
python task_manager.py list -v           # Verbose (show descriptions)
```

### Complete a Task
```bash
python task_manager.py complete 1        # Mark task #1 as done
python task_manager.py uncomplete 1      # Mark task #1 as pending
```

### Update a Task
```bash
python task_manager.py update 1 -t "New title"
python task_manager.py update 1 -d "New description"
```

### Delete a Task
```bash
python task_manager.py delete 1
```

### Clear Completed Tasks
```bash
python task_manager.py clear
```

### View Statistics
```bash
python task_manager.py stats
```

## Example Session

```bash
$ python task_manager.py add "Learn Python"
Added task #1: Learn Python

$ python task_manager.py add "Build CLI app" -d "Task manager project"
Added task #2: Build CLI app

$ python task_manager.py list
[ ] #1: Learn Python
[ ] #2: Build CLI app

$ python task_manager.py complete 1
Completed task #1: Learn Python

$ python task_manager.py list
[x] #1: Learn Python
[ ] #2: Build CLI app

$ python task_manager.py stats
Task Statistics:
  Total tasks: 2
  Completed: 1
  Pending: 1
  Completion rate: 50.0%
```

## Files

- `task_manager.py` - Main application code
- `test_task_manager.py` - Unit tests (25 tests)
- `tasks.json` - Data persistence file (auto-created)
- `README.md` - This file

## Running Tests

```bash
python -m pytest test_task_manager.py -v
```

## Requirements

- Python 3.7+
- No external dependencies

## Development Roadmap

Future iterations may include:
- Priority levels (high, medium, low)
- Due dates and reminders
- Categories/tags for organization
- Search functionality
- Export to different formats
- Colorful terminal output
