"""
ViMax Unit Tests
"""
