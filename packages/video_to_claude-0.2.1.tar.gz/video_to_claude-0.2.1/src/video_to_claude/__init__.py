"""video-to-claude: Translate video files into a format Claude can experience."""

from .core import VideoProcessor

__version__ = "0.2.0"
__all__ = ["VideoProcessor", "__version__"]
