"""Tests for video-to-claude."""
