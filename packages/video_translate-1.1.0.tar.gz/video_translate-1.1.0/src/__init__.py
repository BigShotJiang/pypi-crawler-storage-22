"""video-translate application"""
