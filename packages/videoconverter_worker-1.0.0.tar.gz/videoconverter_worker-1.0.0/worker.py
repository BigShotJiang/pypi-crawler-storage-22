# -*- coding: utf-8 -*-
"""
Python Worker：从 queue 目录读取任务并执行切分/去字幕/合成，与 Java BackendWorker 行为一致。
用法:
  python worker.py [--data-dir DIR] [--path-replace OLD=NEW] [--workers N]
  或设置环境变量: VIDEOCONVERTER_DATA_DIR, VIDEOCONVERTER_PATH_REPLACE (OLD=NEW)
"""
import argparse
import logging
import sys
import time
from pathlib import Path

from task_queue import QueueStore
from metadata import load_metadata, get_processed_chunks, get_pending_chunks, update_chunk_processed
from ffmpeg_runner import (
    split_video_to_chunks,
    run_desubtitle,
    merge_chunks,
    get_duration,
)

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
    datefmt="%Y-%m-%d %H:%M:%S",
)
logger = logging.getLogger("worker")


def process_split_task(store: QueueStore, task: dict) -> None:
    task_id = task["task_id"]
    input_file = task["input_file"]
    output_dir = task["output_dir"]
    config = task.get("config") or {}
    range_start = config.get("startTime", 0) or 0
    range_end = config.get("endTime", 0) or 0

    store.add_log(task_id, "INFO", f"开始切分视频: {Path(input_file).name} (范围: {range_start} - {range_end}秒)")
    metadata, video_id = split_video_to_chunks(input_file, output_dir, 120.0, range_start, range_end)
    store.add_log(task_id, "INFO", f"切分完成: {metadata['totalChunks']} 个小块，元数据: {metadata.get('_metadataPath', '')}")

    store.complete_task(task_id)

    # 为每个 chunk 创建去字幕任务
    chunk_files = []
    for ch in metadata.get("chunks") or []:
        rel = ch.get("originalPath", "")
        if rel:
            chunk_path = Path(output_dir) / rel
            chunk_files.append(str(chunk_path))

    for chunk_file in chunk_files:
        store.create_desubtitle_task(chunk_file, output_dir, config, task_id, video_id)
    store.add_log(task_id, "INFO", f"已创建 {len(chunk_files)} 个去字幕任务")


def process_desubtitle_task(store: QueueStore, task: dict) -> None:
    task_id = task["task_id"]
    input_file = task["input_file"]
    output_dir = task["output_dir"]
    video_id = task.get("video_id") or ""
    config = dict(task.get("config") or {})

    input_path = Path(input_file)
    if not input_path.exists():
        store.fail_task(task_id, f"输入文件不存在: {input_file}")
        return

    store.add_log(task_id, "INFO", f"开始去字幕: {input_path.name}")

    output_dir_for_file = Path(output_dir) / video_id if video_id else Path(output_dir)
    output_dir_for_file.mkdir(parents=True, exist_ok=True)
    output_name = input_path.stem + "_desub.mp4"
    output_file = output_dir_for_file / output_name

    config["inputPath"] = input_file
    config["outputPath"] = str(output_file)
    if video_id:
        config["startTime"] = 0
        config["endTime"] = 0
        config["forceKeyframeAtStart"] = True

    try:
        run_desubtitle(config, input_file, str(output_file))
    except Exception as e:
        store.fail_task(task_id, str(e))
        store.add_log(task_id, "WARN", str(e))
        return

    store.complete_task(task_id)
    store.add_log(task_id, "INFO", f"去字幕完成: {output_name}")

    if video_id:
        metadata_path = Path(output_dir) / video_id / "metadata.json"
        if metadata_path.exists():
            chunk_id = input_path.stem
            try:
                update_chunk_processed(str(metadata_path), chunk_id, str(output_file))
                check_and_create_merge_task(store, video_id, output_dir, config)
            except Exception as e:
                logger.warning("更新 metadata 或检查合成失败: videoId=%s, chunkId=%s, %s", video_id, chunk_id, e)


def check_and_create_merge_task(store: QueueStore, video_id: str, output_dir: str, config: dict) -> None:
    metadata_path = Path(output_dir) / video_id / "metadata.json"
    if not metadata_path.exists():
        return
    data = load_metadata(str(metadata_path))
    chunks = data.get("chunks") or []
    total = len(chunks)
    processed = get_processed_chunks(data)
    pending = get_pending_chunks(data)
    existing = store.get_tasks_by_video_id(video_id)
    has_merge = any(t.get("task_type") == "MERGE" for t in existing)

    if total > 0 and len(processed) == total and not pending and not has_merge:
        store.create_merge_task(video_id, output_dir, config)
        logger.info("自动创建合成任务: videoId=%s, 已处理 %d/%d 块", video_id, len(processed), total)


def process_merge_task(store: QueueStore, task: dict) -> None:
    task_id = task["task_id"]
    video_id = task.get("video_id")
    output_dir = task["output_dir"]

    store.add_log(task_id, "INFO", f"开始合成视频: videoId={video_id}")

    metadata_path = Path(output_dir) / video_id / "metadata.json"
    if not metadata_path.exists():
        store.fail_task(task_id, f"元数据文件不存在: {metadata_path}")
        return

    data = load_metadata(str(metadata_path))
    processed = get_processed_chunks(data)
    if not processed:
        store.fail_task(task_id, "没有已处理的 chunk")
        return

    start_time = processed[0]["startTime"]
    end_time = processed[-1]["endTime"]
    output_file = Path(output_dir) / f"{video_id}_merged.mp4"

    store.add_log(task_id, "INFO", f"合并 {len(processed)} 个小块，时间范围: {start_time} - {end_time}秒")

    try:
        merge_chunks(data, start_time, end_time, str(output_file))
        store.complete_task(task_id)
        store.add_log(task_id, "INFO", f"合成完成: {output_file.name}")
    except Exception as e:
        store.fail_task(task_id, str(e))
        store.add_log(task_id, "WARN", str(e))


def process_one_click_compose_task(store: QueueStore, task: dict) -> None:
    task_id = task["task_id"]
    input_file = task["input_file"]
    output_dir = task["output_dir"]
    config = task.get("config") or {}
    range_start = config.get("startTime", 0) or 0
    range_end = config.get("endTime", 0) or 0

    store.add_log(task_id, "INFO", f"开始一键合成: {Path(input_file).name} (videoId={task.get('video_id', '')})")

    metadata, folder_video_id = split_video_to_chunks(input_file, output_dir, 120.0, range_start, range_end)
    store.add_log(task_id, "INFO", f"切分完成: {metadata['totalChunks']} 个小块")

    store.complete_task(task_id)

    chunk_files = []
    for ch in metadata.get("chunks") or []:
        rel = ch.get("originalPath", "")
        if rel:
            chunk_files.append(str(Path(output_dir) / rel))

    for cf in chunk_files:
        store.create_desubtitle_task(cf, output_dir, config, task_id, folder_video_id)
    store.add_log(task_id, "INFO", f"已创建 {len(chunk_files)} 个去字幕任务")


def work_loop(store: QueueStore) -> None:
    while True:
        try:
            if store.is_paused():
                time.sleep(1)
                continue

            task = store.acquire_pending_task()
            if task is None:
                time.sleep(1)
                continue

            task_id = task["task_id"]
            task_type = task.get("task_type", "")
            logger.info("开始处理任务: %s (类型: %s)", task_id, task_type)

            try:
                if task_type == "SPLIT":
                    process_split_task(store, task)
                elif task_type == "DESUBTITLE":
                    process_desubtitle_task(store, task)
                elif task_type == "MERGE":
                    process_merge_task(store, task)
                elif task_type == "ONE_CLICK_COMPOSE":
                    process_one_click_compose_task(store, task)
                else:
                    store.fail_task(task_id, f"未知任务类型: {task_type}")
            except Exception as e:
                logger.exception("任务处理失败: %s", task_id)
                store.fail_task(task_id, str(e))
                store.add_log(task_id, "WARN", str(e))

        except KeyboardInterrupt:
            logger.info("收到中断，退出")
            break
        except Exception as e:
            logger.exception("工作循环异常: %s", e)
            time.sleep(5)


def main() -> int:
    parser = argparse.ArgumentParser(description="VideoConverter Python Worker")
    parser.add_argument(
        "--data-dir",
        default=None,
        help="数据目录（默认 $VIDEOCONVERTER_DATA_DIR 或 ~/.videoconverter/data）",
    )
    parser.add_argument(
        "--path-replace",
        default=None,
        help="路径前缀替换，便于本机任务拷到服务器: OLD=NEW，如 /Users/me/videos=/data/videos",
    )
    parser.add_argument(
        "--workers",
        type=int,
        default=1,
        help="并发 worker 数（默认 1，多进程时由外部起多个 worker 进程）",
    )
    args = parser.parse_args()

    data_dir = args.data_dir or __import__("os").environ.get(
        "VIDEOCONVERTER_DATA_DIR",
        str(Path.home() / ".videoconverter" / "data"),
    )
    path_replace = None
    if args.path_replace:
        if "=" in args.path_replace:
            a, b = args.path_replace.split("=", 1)
            path_replace = (a.strip(), b.strip())
    env_replace = __import__("os").environ.get("VIDEOCONVERTER_PATH_REPLACE")
    if env_replace and "=" in env_replace and path_replace is None:
        a, b = env_replace.split("=", 1)
        path_replace = (a.strip(), b.strip())

    store = QueueStore(data_dir, path_replace=path_replace)
    logger.info("数据目录: %s", data_dir)
    logger.info("队列目录: %s", store.queue_dir)
    if path_replace:
        logger.info("路径替换: %s -> %s", path_replace[0], path_replace[1])

    work_loop(store)
    return 0


if __name__ == "__main__":
    sys.exit(main())
