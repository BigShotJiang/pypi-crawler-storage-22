import os
import platform
import subprocess
import shutil
import tempfile

import sys
from shutil import which

def check_command(cmd, install_tip):
    if not which(cmd):
        raise EnvironmentError(f"{cmd} not found. Install it: {install_tip}")

def run_subprocess(cmd, cwd=None):
    print(f"Running: {' '.join(cmd)}")
    try:
        result = subprocess.run(cmd, cwd=cwd, check=True, capture_output=True, text=True)
        print(result.stdout)
        if result.stderr:
            print(f"Warnings/Errors: {result.stderr}")
        return result
    except subprocess.CalledProcessError as e:
        print(f"Command failed with code {e.returncode}: {e.stderr}")
        raise

def build_rnnoise():
    # Force Linux detection when running in Docker
    if os.path.exists("/.dockerenv") or os.environ.get("DOCKER_CONTAINER"):
        os_sys = "Linux"
    else:
        os_sys = platform.system()
    repo_url = "https://github.com/xiph/rnnoise.git"
    
    git_tip = "Install git (e.g., apt install git on Debian/Ubuntu, brew install git on macOS, or Chocolatey on Windows)."
    check_command("git", git_tip)
    
    with tempfile.TemporaryDirectory() as tmpdir:
        run_subprocess(["git", "clone", repo_url, tmpdir])
        os.chdir(tmpdir)
        if os_sys == "Darwin" or os_sys == "Linux":
            # Check required Unix build tools
            unix_tip = "Install build tools (e.g., apt install build-essential autoconf automake libtool on Debian/Ubuntu; brew install autoconf automake libtool on macOS)."
            for tool in ["autoconf", "automake", "libtool", "make"]:
                check_command(tool, unix_tip)
            
            # Generate build files and compile
            run_subprocess(["./autogen.sh"])
            run_subprocess(["./configure"])
            run_subprocess(["make"])
            lib_dir = ".libs"
            
            # Force Linux .so file when running in Docker container
            if os.path.exists("/.dockerenv") or os.environ.get("DOCKER_CONTAINER"):
                lib_file = "librnnoise.so"
                print(f"🔧 Docker detected, forcing .so file: {lib_file}")
            else:
                lib_file = "librnnoise.dylib" if os_sys == "Darwin" else "librnnoise.so"
                print(f"🔧 Host system detected: {os_sys}, using: {lib_file}")
            
            built_lib = os.path.join(lib_dir, lib_file)
        elif os_sys == "Windows":
            # Check nmake for Visual Studio-based build
            nmake_tip = "Install Visual Studio (community edition) and run this script from Developer Command Prompt. Alternatively, use MSYS2 (install via https://www.msys2.org/) and run make in the repo."
            check_command("nmake", nmake_tip)
            
            os.chdir("msvc")
            # Assumes Visual Studio is installed; run from Developer Command Prompt if needed
            run_subprocess(["nmake", "/f", "Makefile.ms"])
            built_lib = "rnnoise.dll"  # Adjust if name differs after build
        else:
            raise ValueError(f"Unsupported OS: {os_sys}. Manual build required (clone repo and follow README).")
        
        if not os.path.exists(built_lib):
            raise FileNotFoundError(f"Build failed: {built_lib} not found. Ensure build tools are installed and environment is set up (e.g., in containers, add tools via Dockerfile/package manager).")
        
        script_dir = os.path.dirname(os.path.abspath(__file__))
        target_dir = os.path.join(script_dir, "files")
        os.makedirs(target_dir, exist_ok=True)
        
        # Force .so files when running in Docker
        if os.path.exists("/.dockerenv") or os.environ.get("DOCKER_CONTAINER"):
            # Look for shared library specifically
            shared_lib = os.path.join(lib_dir, "librnnoise.so")
            static_lib = os.path.join(lib_dir, "librnnoise.a")
            
            if os.path.exists(shared_lib):
                source_lib = shared_lib
                print(f"🔧 Found shared library: {source_lib}")
            elif os.path.exists(static_lib):
                # If no shared library, create one from static library
                print(f"🔧 Creating shared library from static library")
                # Extract object files from static library
                run_subprocess(["ar", "-x", static_lib])
                # Create shared library from object files
                obj_files = [f for f in os.listdir(".") if f.endswith(".o")]
                run_subprocess(["gcc", "-shared", "-o", shared_lib] + obj_files + ["-lm"])
                source_lib = shared_lib
            else:
                raise FileNotFoundError(f"No librnnoise library found in {lib_dir}")
            
            target_lib = os.path.join(target_dir, "librnnoise.so")
            shutil.copy(source_lib, target_lib)
            print(f"🔧 Copied {source_lib} to {target_lib}")
            
            # Also create a symlink for compatibility
            symlink_path = os.path.join(target_dir, "librnnoise.dylib")
            if os.path.exists(symlink_path):
                os.remove(symlink_path)
            os.symlink("librnnoise.so", symlink_path)
            print(f"🔧 Created symlink: librnnoise.dylib -> librnnoise.so")
            
            # Copy to the mounted volume location
            mounted_target = "/output/librnnoise.so"
            shutil.copy(source_lib, mounted_target)
            print(f"🔧 Copied to mounted volume: {mounted_target}")
        else:
            shutil.copy(built_lib, os.path.join(target_dir, os.path.basename(built_lib)))

if __name__ == "__main__":
    try:
        build_rnnoise()
        print("RNNoise library built successfully for your OS.")
    except Exception as e:
        print(f"Build failed: {e}")
        print("If in a container/cloud/terminal, ensure tools are installed (e.g., via apt/brew/Chocolatey) or build manually per RNNoise README: https://github.com/xiph/rnnoise")
        sys.exit(1)