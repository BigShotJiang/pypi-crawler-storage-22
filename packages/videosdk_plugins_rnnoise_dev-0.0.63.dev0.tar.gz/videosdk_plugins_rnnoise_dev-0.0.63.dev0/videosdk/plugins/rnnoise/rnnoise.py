import ctypes
import numpy as np
import os
import platform

script_dir = os.path.dirname(os.path.abspath(__file__))


sys_name = platform.system()
if sys_name == "Darwin":
    lib_name = "librnnoise.dylib"
elif sys_name == "Linux":
    lib_name = "librnnoise.so"
elif sys_name == "Windows":
    lib_name = "rnnoise.dll"
else:
    raise OSError(f"Unsupported OS: {sys_name}")

lib_path = os.path.join(script_dir, "files", lib_name)

try:
    lib = ctypes.cdll.LoadLibrary(lib_path)
except OSError as e:
    raise OSError(
        f"Error loading rnnoise library at {lib_path}. "
        f"It may be corrupted or incompatible with your platform. "
        f"Original error: {e}"
    ) from e

# Define the correct function signatures
lib.rnnoise_create.argtypes = [ctypes.c_void_p]  # RNNModel *model (can be NULL)
lib.rnnoise_create.restype = ctypes.c_void_p
lib.rnnoise_destroy.argtypes = [ctypes.c_void_p]
lib.rnnoise_process_frame.argtypes = [ctypes.c_void_p, ctypes.POINTER(ctypes.c_float), ctypes.POINTER(ctypes.c_float)]
lib.rnnoise_process_frame.restype = ctypes.c_float

class RNN(object):
	def __init__(self):
		# Pass NULL (None) for the model parameter to use the default model
		self.obj = lib.rnnoise_create(None)
		if self.obj is None:
			raise RuntimeError("Failed to create RNNoise instance")
	
	def process_frame(self, inbuf):
		# Create a copy of the input buffer to avoid modifying the original
		if isinstance(inbuf, bytes):
			# Convert bytes to numpy array
			audio_data = np.frombuffer(inbuf, dtype=np.int16)
		else:
			audio_data = np.array(inbuf, dtype=np.int16)
		
		# Ensure we have exactly 480 samples
		if len(audio_data) != 480:
			raise ValueError(f"Expected 480 samples, got {len(audio_data)}")
		
		# Convert to float32 and normalize
		audio_float = audio_data.astype(np.float32) / 32767.0
		
		# Create output buffer
		outbuf = np.zeros(480, dtype=np.float32)
		
		# Get pointers
		in_ptr = audio_float.ctypes.data_as(ctypes.POINTER(ctypes.c_float))
		out_ptr = outbuf.ctypes.data_as(ctypes.POINTER(ctypes.c_float))
		
		# Process the frame
		VodProb = lib.rnnoise_process_frame(self.obj, out_ptr, in_ptr)
		
		# Convert back to int16
		outbuf_int16 = (outbuf * 32767.0).astype(np.int16)
		
		return (VodProb, outbuf_int16.tobytes())

	def destroy(self):
		if self.obj is not None:
			lib.rnnoise_destroy(self.obj)
			self.obj = None