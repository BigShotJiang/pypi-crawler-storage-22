# VideoSDK CLI

Install the VideoSDK CLI using Python:

```sh
pip install videosdk-cli
```

---

## Authentication

### Login

```sh
videosdk auth login
```

### Logout

```sh
videosdk auth logout
```

---

## Agent Management

### Initialize Agent

```sh
videosdk agent init --name my-agent
```

### Build Docker Image

```sh
videosdk agent build --image myrepo/myagent:latest --file Dockerfile
```

### Push to Registry

```sh
videosdk agent push --image myrepo/myagent:latest --server docker.io --username user --password pass
```

### Deploy Agent

```sh
videosdk agent deploy [name] --image myrepo/myagent:latest --min-replica 1 --max-replica 5 --profile cpu-small --agent-id <agent-id> --env-secret my-secrets --image-pull-secret my-pull-secret --region us-east
```

---

## Version Management

### List Versions

```sh
videosdk agent version list --agent-id <agent-id>
```

### Update Version

```sh
videosdk agent version update --version-id <version-id> --min-replica 2 --max-replica 10 --profile cpu-medium --image-pull-secret my-secret
```

### Activate Version

```sh
videosdk agent version activate --version-id <version-id> --agent-id <agent-id>
```

### Deactivate Version

```sh
videosdk agent version deactivate --version-id <version-id> --force --agent-id <agent-id>
```

### Get Version Status

```sh
videosdk agent version status --version-id <version-id>
```

### Describe Version

```sh
videosdk agent version describe --version-id <version-id>
```

---

## Secret Management

### Create Secret Set

```sh
videosdk agent secrets create my-secrets --file .env --region us-east
```

Or interactively:

```sh
videosdk agent secrets create my-secrets
```

### Add Keys to Secret

```sh
videosdk agent secrets add my-secrets
```

### Remove Keys from Secret

```sh
videosdk agent secrets remove my-secrets
```

### Describe Secret

```sh
videosdk agent secrets describe my-secrets
```

### Delete Secret Set

```sh
videosdk agent secrets delete my-secrets
```

### List All Secrets

```sh
videosdk agent secrets list
```

### Create Image Pull Secret

```sh
videosdk agent image-pull-secret my-registry-secret --region us-east
```

---

## Session Management

### Start Session

```sh
videosdk agent session start --version-id <version-id> --room-id <room-id>
```

### Stop Session

```sh
videosdk agent session stop --room-id <room-id> --session-id <session-id> --end-session
```

### List Sessions

```sh
videosdk agent sessions --version-id <version-id> --agent-id <agent-id> --active --region us-east
```

---

## Templates

### List Templates

```sh
videosdk template list
```

Example output:

| Template id                 | File Name                      | Description                                         |
| --------------------------- | ------------------------------ | --------------------------------------------------- |
| ai-agent-cascading-pipeline | ai-agent-cascading-pipeline.py | AI Agent with a cascading, multi-provider pipeline. |
| ai-agent-real-time-pipeline | ai-agent-real-time-pipeline.py | AI Agent with a real-time pipeline.                 |

### Create Project from Template

```sh
videosdk template get -t ai-agent-cascading-pipeline my-app
```

---

## Run Local Agent

```sh
videosdk run my-app
```

This will:

1. Create/use a virtual environment
2. Install requirements
3. Run the agent in console mode

Example output:

```sh
Running project 'my-app'...
[✓] model_quantized.onnx already downloaded.
====================================================================================================
               Videosdk's AI Agent Console Mode
====================================================================================================
Session end callback configured
Waiting for participant...
Participant joined
2025-10-13 12:21:20,846 - INFO - agent output speech: Hello, how can I help you today?
Agent is running... (will exit automatically when participants leave)
```

---

## Command Reference

| Command                                  | Description              |
| ---------------------------------------- | ------------------------ |
| `videosdk auth login`                    | Login to VideoSDK        |
| `videosdk auth logout`                   | Logout from VideoSDK     |
| `videosdk agent init`                    | Initialize agent         |
| `videosdk agent build`                   | Build Docker image       |
| `videosdk agent push`                    | Push image to registry   |
| `videosdk agent deploy`                  | Deploy new version       |
| `videosdk agent version list`         | List versions            |
| `videosdk agent version update`       | Update version           |
| `videosdk agent version activate`     | Activate version         |
| `videosdk agent version deactivate`   | Deactivate version       |
| `videosdk agent version status`       | Get version status       |
| `videosdk agent version describe`     | Describe version         |
| `videosdk agent secrets create <name>`   | Create secret set        |
| `videosdk agent secrets add <name>`      | Add keys to secret       |
| `videosdk agent secrets remove <name>`   | Remove keys from secret  |
| `videosdk agent secrets describe <name>` | Describe secret          |
| `videosdk agent secrets delete <name>`   | Delete secret set        |
| `videosdk agent secrets list`            | List all secrets         |
| `videosdk agent image-pull-secret`       | Create image pull secret |
| `videosdk agent session start`           | Start agent session      |
| `videosdk agent session stop`            | Stop agent session       |
| `videosdk agent sessions`                | List sessions            |
| `videosdk template list`                 | List templates           |
| `videosdk template get`                  | Create from template     |
| `videosdk run`                           | Run local agent          |
