import asyncio
import click
from videosdk_cli.utils.config_manager import set_config_value
from videosdk_cli.utils.auth_api_client import AuthAPIClient
from videosdk_cli.utils.ui.theme import (
    console,
    print_header,
    print_success,
    print_info,
    PRIMARY,
    MUTED,
)
import os
import webbrowser


@click.group()
def auth_cli():
    """
    Authenticate with VideoSDK.

    Login or logout from your VideoSDK account. Authentication is required
    for deploying and managing agents.

    \b
    Commands:
      login   Authenticate with your VideoSDK account
      logout  Remove stored authentication token
    """
    pass


@auth_cli.command(name="login")
def login():
    """
    Login to your VideoSDK account.

    Opens a browser window for authentication. After successful login,
    your credentials are stored locally for future CLI commands.

    \b
    Example:
      $ videosdk auth login
    """
    try:
        asyncio.run(handle_auth())
    except KeyboardInterrupt:
        console.print(f"\n[{PRIMARY}]Authentication cancelled by user[/{PRIMARY}]")
    except Exception as e:
        raise click.ClickException(f"Authentication failed: Please try again")


@auth_cli.command(name="logout")
def logout():
    """
    Logout from your VideoSDK account.

    Removes the stored authentication token. You will need to login
    again to use authenticated commands.

    \b
    Example:
      $ videosdk auth logout
    """
    try:
        asyncio.run(handle_logout())
    except KeyboardInterrupt:
        console.print(f"\n[{PRIMARY}]Logout cancelled by user[/{PRIMARY}]")
    except Exception as e:
        raise click.ClickException(f"Logout failed: Please try again")


async def handle_auth():
    from videosdk_cli.utils.template_helper import API_BASE_URL, DASHBOARD_URL

    client = AuthAPIClient(api_base_url=API_BASE_URL)

    print_header("Authentication")
    print_info("Initiating browser authentication...")

    data = await client.start_auth()

    generated_url = DASHBOARD_URL + "/cli/confirm-auth?requestId=" + data["requestId"]
    webbrowser.open(generated_url)

    print_success(f"Opened authentication URL in browser")
    console.print(f"  [{MUTED}]{generated_url}[/{MUTED}]")
    console.print()

    requestId = data["requestId"]
    expires_in = data["expiresIn"]

    poll_interval = 3
    attempts = expires_in // poll_interval

    with console.status(
        f"[{PRIMARY}]Waiting for authentication...[/{PRIMARY}]", spinner="dots"
    ) as status:
        for i in range(attempts):
            await asyncio.sleep(poll_interval)

            auth_status = await client.check_status(requestId)

            if auth_status["status"] == "approved":
                set_config_value("VIDEOSDK_AUTH_TOKEN", auth_status["token"])
                status.stop()
                print_success("Successfully authenticated!")
                return

            if auth_status["status"] == "expired":
                status.stop()
                raise click.ClickException(
                    "Authentication link expired. Please run `videosdk auth login` again."
                )

    raise click.ClickException("Authentication timed out. Please try again.")


async def handle_logout():
    print_header("Logout")
    set_config_value("VIDEOSDK_AUTH_TOKEN", None)
    print_success("Successfully logged out")
