import click
import asyncio
import nest_asyncio
import sys
from dotenv import load_dotenv

load_dotenv()
from pathlib import Path
from videosdk_cli.auth import auth_cli
from videosdk_cli.templates import template_cli
from videosdk_cli.run_agent import run_agent
from videosdk_cli.utils import analytics
from videosdk_cli.build import agent_cli
from videosdk_cli.utils.ui.theme import (
    console,
    print_banner,
    print_error,
    print_warning,
    PRIMARY,
)
import atexit

load_dotenv()
nest_asyncio.apply()

CURRENT_CMD = " ".join([Path(sys.argv[0]).name] + sys.argv[1:])


def run_async(coro):
    loop = asyncio.get_event_loop()
    return loop.run_until_complete(coro)


class VideoSDKCLI(click.Group):
    """Custom Click Group that shows banner on help."""

    def format_help(self, ctx, formatter):
        print_banner(mini=False)
        super().format_help(ctx, formatter)


@click.group(cls=VideoSDKCLI)
@click.version_option(version="0.2.0", prog_name="VideoSDK CLI")
def cli():
    """
    Build and deploy AI agents with VideoSDK cloud infrastructure.

    \b
    GETTING STARTED
      $ videosdk auth login              # Authenticate
      $ videosdk agent init --name bot   # Create agent
      $ videosdk agent build             # Build Docker image
      $ videosdk agent push              # Push to registry
      $ videosdk agent deploy            # Deploy to cloud

    \b
    COMMON COMMANDS
      auth        Login/logout from VideoSDK
      agent       Manage agents, deployments, secrets, sessions
      template    Create projects from templates
      run         Run agent locally

    \b
    RESOURCES
      Docs:     https://docs.videosdk.live
      Discord:  https://discord.gg/HUe45teT
    """
    pass


# Add auth group (videosdk auth login / videosdk auth logout)
cli.add_command(auth_cli, name="auth")

# Add template group (videosdk template list / videosdk template get)
cli.add_command(template_cli, name="template")

# Add agent group with all subcommands
cli.add_command(agent_cli, name="agent")


@cli.command()
@click.argument("project_name")
def run(project_name):
    """
    Run a VideoSDK agent project locally.

    Starts the agent in console mode for local development and testing.
    Automatically creates a virtual environment and installs requirements.

    \b
    Arguments:
      PROJECT_NAME  Name of the project directory to run

    \b
    Example:
      $ videosdk run my-assistant
    """
    try:
        run_agent(project_name)
    except KeyboardInterrupt:
        raise
    except Exception as e:
        raise e


def log_command_at_exit():
    """Ensures analytics logging happens on exit (normal or KeyboardInterrupt)"""
    try:
        asyncio.run(analytics.log_command(CURRENT_CMD))
    except Exception as e:
        print(f"Failed to log analytics: {e}")


# atexit.register(log_command_at_exit)

if __name__ == "__main__":
    try:
        cli()
    except KeyboardInterrupt:
        console.print(f"\n[{PRIMARY}]Command interrupted by user[/{PRIMARY}]")
    except Exception as e:
        print_error(str(e))
