import asyncio
from rich.console import Console
from rich.table import Table
from videosdk_cli.utils.config_manager import (
    get_config_value,
    set_config_value,
    save_config,
)
from videosdk_cli.utils.api_client import (
    VideoSDKClient,
    VideoSDKTokenClient,
    AuthenticationError,
)
from InquirerPy import inquirer

console = Console()


async def list_projects():
    """Fetches and displays a list of your projects with arrow selection."""
    try:
        client = VideoSDKClient()
        data = await client.fetch_projects()

        projects = data.get("data", [])
        if not projects:
            console.print("[yellow]No projects found.[/yellow]")
            return

        table = Table(title="Available Projects", show_lines=True)
        table.add_column("No.", justify="right", style="cyan")
        table.add_column("Project Name", style="magenta")
        table.add_column("Created At", style="green")
        table.add_column("API Key", style="yellow")
        table.add_column("Status")

        for i, p in enumerate(projects, start=1):
            status = (
                "[green]Active[/green]"
                if not p.get("isDeactived")
                else "[red]Inactive[/red]"
            )
            table.add_row(
                str(i),
                p.get("name"),
                p.get("createdAt"),
                p.get("keyPair", {}).get("apiKey"),
                status,
            )

        console.print(table)

        choices = [f"{p['name']} ({p['keyPair']['apiKey']})" for p in projects]
        choice_label = await inquirer.select(
            message="Select a project:",
            choices=choices,
            pointer="👉",
            instruction="Use ↑ ↓ to navigate, Enter to select",
        ).execute_async()

        selected_index = choices.index(choice_label)
        selected = projects[selected_index]

        set_config_value("selected_project_name", selected["name"])
        set_config_value(
            "selected_project_api_key", selected.get("keyPair", {}).get("apiKey")
        )
        console.print(f"[green]✅ Selected project:[/green] {selected['name']}")

        await gen_token()

    except AuthenticationError as e:
        console.print(f"[red]Authentication error: {e}[/red]")
        await handle_auth_reset()

    except Exception as e:
        console.print(f"[red]Unexpected error: {e}[/red]")


async def gen_token():
    """Fetches VIDEOSDK_AUTH_TOKEN for the selected project."""
    project_name = get_config_value("selected_project_name")
    api_key = get_config_value("selected_project_api_key")
    auth_token = get_config_value("auth_token")

    if not api_key or not project_name:
        console.print(
            "[red]Project details not found. Please run:[/red] videosdk projects"
        )
        return
    if not auth_token:
        console.print(
            "[red]Authentication details not found. Please run:[/red] videosdk auth"
        )
        return

    try:
        expires_str = f"{365}d"

        client = VideoSDKTokenClient(auth_token, api_key, expires_str)
        data = await client.fetch_token()
        token = data.get("token")

        if token:
            console.print(f"[green]✅ Generated token:[/green]")
            set_config_value("VIDEOSDK_AUTH_TOKEN", token)
        else:
            console.print(
                "[red]❌ Token not found. Check your API key or auth token.[/red]"
            )

    except AuthenticationError as e:
        console.print(f"[red]Authentication error: {e}[/red]")
        await handle_auth_reset()

    except Exception as e:
        console.print(f"[red]Unexpected error: {e}[/red]")


async def handle_auth_reset():
    """Ask user before resetting auth token."""
    reset = await inquirer.confirm(
        message="Do you want to reset your authentication token?", default=False
    ).execute_async()

    if reset:
        save_config(None)
        console.print(
            "[yellow]Auth token cleared. Please run 'videosdk auth' again.[/yellow]"
        )
    else:
        console.print(
            "[yellow]Auth token not cleared. You may experience errors until re-authenticated.[/yellow]"
        )
