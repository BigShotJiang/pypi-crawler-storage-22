import subprocess
import sys
import json
from pathlib import Path
from rich.console import Console
import os
    
console = Console()


def get_executables(venv_path: Path):
    """Determine python and pip executables based on venv/conda."""
    is_windows = sys.platform == "win32"

    venv_path = Path(venv_path)

    if (venv_path / "Scripts").exists() or (venv_path / "bin").exists():
        python_exe = venv_path / ("Scripts/python.exe" if is_windows else "bin/python")
        pip_exe = venv_path / ("Scripts/pip.exe" if is_windows else "bin/pip")
    else:
        python_exe = venv_path / ("python.exe" if is_windows else "bin/python")
        pip_exe = venv_path / ("Scripts/pip.exe" if is_windows else "bin/pip")

    return python_exe, pip_exe


def run_agent(project_name: str):
    parent_dir = Path.cwd()
    project_dir = parent_dir / project_name

    if not project_dir.exists():
        console.print(f"[bold red]Error:[/bold red] Project '{project_name}' not found.")
        return

    config_path = project_dir / "config.json"
    if not config_path.exists():
        console.print(f"[bold red]Error:[/bold red] config.json not found in project '{project_name}'.")
        return

    with open(config_path, "r") as f:
        config = json.load(f)


    venv_path_str = config.get("venv_path", str(project_dir / "venv"))
    venv_path = Path(venv_path_str)
    python_executable, pip_executable = get_executables(venv_path)


    if not python_executable.exists():
        console.print(f"[bold yellow]Virtual environment not found. Creating...[/bold yellow]")
        subprocess.run([sys.executable, "-m", "venv", str(venv_path)], check=True)
        console.print("[green]✅ Virtual environment created[/green]")
        python_executable, pip_executable = get_executables(venv_path)


    if not config.get("requirements_installed", False):
        console.print("[cyan]Installing project requirements...[/cyan]")
        subprocess.run([str(pip_executable), "install", "-r", str(project_dir / "requirements.txt")], check=True)
        print("requirements", )
        config["requirements_installed"] = True
        with open(config_path, "w") as f:
            json.dump(config, f, indent=4)
        console.print("[green]✅ Requirements installed[/green]")


    template_file = config.get("template_file")
    template_path = project_dir / template_file

    if not template_path.exists():
        console.print(f"[bold red]Error:[/bold red] Template file '{template_file}' not found.")
        return

    console.print(f"[cyan]Running project '{project_name}'...[/cyan]")

    env_vars = os.environ.copy()
    env_file = project_dir / ".env"
    if env_file.exists():
        from dotenv import dotenv_values
        env_vars.update(dotenv_values(env_file))
    try:
        subprocess.run(
            [str(python_executable), str(template_path), "console"],
            env=env_vars,
            cwd=parent_dir,
            check=True
        )
    except subprocess.CalledProcessError as e:
        console.print(f"[bold red]Project exited with code {e.returncode}[/bold red]")
