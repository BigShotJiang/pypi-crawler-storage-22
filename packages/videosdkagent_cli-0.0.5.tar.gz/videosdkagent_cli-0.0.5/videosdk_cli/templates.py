import click
import asyncio
from pathlib import Path
from rich.console import Console
from rich.table import Table
from rich.progress import Progress, SpinnerColumn, TextColumn
from rich.prompt import Prompt

from videosdk_cli.utils import template_options, template_helper, videosdk_yaml_helper
from videosdk_cli.utils.videosdk_yaml_helper import AgentConfig

console = Console()


@click.group()
def template_cli():
    """
    Manage and create projects from VideoSDK templates.

    Templates provide pre-configured AI agent setups with different
    pipeline types (cascading, real-time) and provider combinations.

    \b
    Commands:
      list  Show all available templates
      get   Create a new project from a template
    """
    pass


@template_cli.command(name="list")
@click.option(
    "--refresh", "-r", is_flag=True, help="Force refresh template metadata from server"
)
def list_templates(refresh: bool):
    """
    List all available templates.

    Shows a table of all VideoSDK agent templates with their IDs,
    filenames, and descriptions.

    \b
    Examples:
      $ videosdk template list
      $ videosdk template list --refresh  # force refresh from server
    """
    asyncio.run(list_templates_async(refresh))


async def list_templates_async(force_refresh: bool = False):
    """Fetch and display templates from server/cache."""
    await template_helper.fetch_template_cache(force_refresh=force_refresh)

    kv = template_options.KeyValuePair()
    templates = kv.templates

    if not templates:
        console.print("[yellow]No templates found in template metadata.[/yellow]")
        return

    table = Table(title="Available VideoSDK Templates", show_lines=True)
    table.add_column("Template id", style="cyan", no_wrap=True)
    table.add_column("File Name", style="green", no_wrap=True)
    table.add_column("Description", style="white")

    for name, tpl in templates.items():
        table.add_row(name, tpl.file_name, tpl.description)

    console.print(table)


@template_cli.command(name="get")
@click.option(
    "--template",
    "-t",
    required=True,
    help="Template ID to create project from (see 'template list')",
)
@click.argument("app_name")
def create_project(template: str, app_name: str):
    """
    Create a new project from a template.

    Downloads the template code and sets up a complete project directory
    with configuration files, requirements, and environment variables.

    \b
    Arguments:
      APP_NAME  Name of the project directory to create

    \b
    Examples:
      $ videosdk template get -t ai-agent-cascading-pipeline my-assistant
      $ videosdk template get -t ai-agent-real-time-pipeline voice-bot
    """
    asyncio.run(create_project_async(template, app_name))


async def create_project_async(template_id: str, app_name: str):
    """Create project, fetch template code from server, prompt providers if needed."""
    await template_helper.fetch_template_cache()

    kv = template_options.KeyValuePair()
    tpl = kv.get_template(template_id)

    if not tpl:
        console.print(
            f"[bold red]Error:[/bold red] Template '[cyan]{template_id}[/cyan]' not found in cache."
        )
        return

    app_dir = Path(app_name)
    if app_dir.exists():
        console.print(
            f"[bold red]Error:[/bold red] Directory '[cyan]{app_name}[/cyan]' already exists."
        )
        return

    console.print(f"[cyan]→ Mode:[/cyan] {tpl.mode}")
    console.print(f"[cyan]→ Pipeline type:[/cyan] {tpl.pipe_type}")

    providers_dict = {}
    imports = []
    provider_modules = []

    if tpl.mode == "preconfig":
        if tpl.pipe_type == "cascading":
            STT, LLM, TTS = tpl.STT_options, tpl.LLM_options, tpl.TTS_options
            providers_dict = {"STT": STT, "LLM": LLM, "TTS": TTS}
        elif tpl.pipe_type == "realtime":
            [RealtimeProvider] = tpl.provider_options
            providers_dict = {"Realtime": RealtimeProvider}

        for provider in providers_dict.values():
            if isinstance(provider, list):
                for p in provider:
                    module, *_ = template_helper.PROVIDER_IMPORTS[p]
                    provider_modules.append(module)
            else:
                module, *_ = template_helper.PROVIDER_IMPORTS[provider]
                provider_modules.append(module)

    elif tpl.mode == "custom" and tpl.pipe_type == "cascading":
        STT = await template_helper.select_provider_arrow(
            "Select STT provider:", tpl.STT_options
        )
        LLM = await template_helper.select_provider_arrow(
            "Select LLM provider:", tpl.LLM_options
        )
        TTS = await template_helper.select_provider_arrow(
            "Select TTS provider:", tpl.TTS_options
        )
        providers_dict = {"STT": STT, "LLM": LLM, "TTS": TTS}
        imports, provider_modules = template_helper.generate_cascading_providers(
            providers_dict
        )

    api_keys = await template_helper.prompt_provider_api_keys(providers_dict)

    env_path = await template_helper.prompt_existing_env()
    if env_path and not env_path.exists():
        console.print(
            "[red]Provided environment path does not exist. A new venv will be created.[/red]"
        )
        env_path = None

    with Progress(
        SpinnerColumn(),
        TextColumn("[progress.description]{task.description}"),
        transient=True,
    ) as progress:
        progress.add_task(
            description=f"Creating project [cyan]{app_name}[/cyan]...", total=None
        )
        try:
            app_dir.mkdir(parents=True, exist_ok=True)
            template_helper.write_env_file(app_dir, providers_dict, api_keys)
            template_helper.write_requirements(
                app_dir, template_helper.STATIC_REQUIREMENTS + provider_modules
            )
            videosdk_yaml_helper.update_agent_config(
                app_dir, AgentConfig(templateId=template_id)
            )
        except Exception as e:
            console.print(f"[bold red]Error creating project files: {e}[/bold red]")
            return

    try:
        import aiohttp

        async with aiohttp.ClientSession() as session:
            url = f"{template_helper.CDN_BASE_URL}/{tpl.file_name}"
            async with session.get(url) as resp:
                if resp.status == 404:
                    console.print(
                        f"[bold red]Template '{template_id}' not found on server[/bold red]"
                    )
                    return
                resp.raise_for_status()
                template_code = await resp.text()
    except Exception as e:
        console.print(f"[bold red]Error fetching template code: {e}[/bold red]")
        return

    imports_str = "\n".join(imports) if imports else ""
    template_helper.write_template_file(
        app_dir, tpl.file_name, imports_str, template_code
    )

    template_helper.write_config(
        app_dir=app_dir,
        template_id=template_id,
        file_name=tpl.file_name,
        description=tpl.description,
        providers=providers_dict,
        env_path=str(env_path) if env_path else None,
        auto_configured=(tpl.mode == "preconfig"),
        requirements_installed=False,
    )

    console.print(
        f"[green]✅ Project '[bold cyan]{app_name}[/bold cyan]' created successfully![/green]"
    )
