import json
from pathlib import Path
from datetime import datetime
import click
from videosdk_cli.utils.config_manager import get_config_value

CONFIG_DIR = Path(click.get_app_dir("videosdk_config"))
CONFIG_DIR.mkdir(exist_ok=True)
ANALYTICS_FILE = CONFIG_DIR / "analytics.json"

_pending_analytics = []


async def log_command(command: str):
    """
    Log a CLI command for analytics.
    Send to server every 5 commands.
    """
    user_id = get_config_value("user_id") or "unknown"
    username = get_config_value("username") or "unknown"
    api_key = get_config_value("selected_project_api_key") or "unknown"

    entry = {
        "timestamp": datetime.now().isoformat(),
        "user_id": user_id,
        "username": username,
        "api_key": api_key,
        "command": command,
    }

    if ANALYTICS_FILE.exists():
        data = json.loads(ANALYTICS_FILE.read_text(encoding="utf-8"))
    else:
        data = {"count": 0, "entries": []}

    data["entries"].append(entry)
    data["count"] += 1

    ANALYTICS_FILE.write_text(json.dumps(data, indent=4), encoding="utf-8")

    if data["count"] >= 5:
        await send_analytics_to_server(data)
        ANALYTICS_FILE.write_text(json.dumps({"count": 0, "entries": []}, indent=4))


async def send_analytics_to_server(data):
    """
    Send analytics to your server endpoint.
    """
    import aiohttp
    from videosdk_cli.utils.template_helper import API_SERVER_URL

    url = f"{API_SERVER_URL}/analytics/collect/"
    try:
        async with aiohttp.ClientSession() as session:
            async with session.post(url, json=data) as resp:
                if resp.status == 200:
                    print("[green]Analytics sent successfully[/green]")
                else:
                    print(f"[red]Failed to send analytics: {resp.status}[/red]")
    except Exception as e:
        print(f"[red]Error sending analytics: {e}[/red]")
