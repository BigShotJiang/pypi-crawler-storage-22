import aiohttp
import logging
from videosdk_cli.utils.config_manager import (
    load_config,
    save_config,
    set_config_value,
    get_config_value,
)
from InquirerPy import inquirer

logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)


class AuthenticationError(Exception):
    """Raised when the stored authentication is invalid or expired."""

    pass


class VideoSDKClient:
    def __init__(self):
        from videosdk_cli.utils.template_helper import API_BASE_URL

        self.auth_token = get_config_value("VIDEOSDK_AUTH_TOKEN") or ""
        self.url = API_BASE_URL + "/v1/apikeys"
        self.headers = {
            "Authorization": self.auth_token,
            "Content-Type": "application/json",
        }
        self.res_data = None

    async def fetch_projects(self):
        async with aiohttp.ClientSession() as session:
            async with session.get(self.url, headers=self.headers) as resp:
                text = await resp.text()
                if 400 <= resp.status < 500:
                    logger.warning("Session expired or invalid credentials.")
                    reset = ask_reset_credentials()
                    if reset:
                        self._reset_credentials()
                    raise AuthenticationError(
                        f"Authentication failed ({resp.status}): {text}"
                    )
                resp.raise_for_status()
                self.res_data = await resp.json()
                return self.res_data

    def _reset_credentials(self):
        """Clear stored auth_token."""
        logger.info("Resetting stored credentials...")
        try:
            save_config(None)

        except Exception:
            config = load_config()
            config = None
            save_config(config)


class VideoSDKTokenClient:
    def __init__(self, auth_token, api_key, expiresIn):
        from videosdk_cli.utils.template_helper import API_BASE_URL

        self.url = API_BASE_URL + f"/v1/apikeys/{api_key}/token"
        self.headers = {"Authorization": auth_token, "Content-Type": "application/json"}
        self.payload = {
            "apiKey": api_key,
            "permissions": ["allow_join"],
            "expiresIn": expiresIn,
        }
        self.res_data = None

    async def fetch_token(self):
        async with aiohttp.ClientSession() as session:
            async with session.post(
                self.url, headers=self.headers, json=self.payload
            ) as resp:
                text = await resp.text()
                if 400 <= resp.status < 500:
                    logger.warning("Session expired or invalid credentials.")
                    reset = ask_reset_credentials()
                    if reset:
                        self._reset_credentials()
                    raise AuthenticationError(
                        f"Authentication failed ({resp.status}): {text}"
                    )
                resp.raise_for_status()
                self.res_data = await resp.json()
                return self.res_data

    def _reset_credentials(self):
        """Clear stored auth_token."""
        logger.info("Resetting stored credentials...")
        try:
            save_config(None)
        except Exception:
            config = load_config()
            config = None
            save_config(config)


def ask_reset_credentials():
    """Prompt user before clearing saved auth token."""
    result = inquirer.confirm(
        message="Request failed. Do you want to reset your stored authentication token?",
        default=False,
    ).execute()
    return result
