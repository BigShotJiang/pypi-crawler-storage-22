from videosdk_cli.utils.apis.videosdk_auth_api_client import VideoSDKAsyncClient
from typing import Optional


class DeploymentClient(VideoSDKAsyncClient):
    def __init__(self):
        super().__init__()

    async def create_version(
        self,
        agent_id: str,
        deployment_id: str,
        image_url: str,
        min_replica: int = 1,
        max_replica: int = 5,
        profile: str = "cpu-small",
        image_type: str = "public",
        image_cr: str = "docker_hub",
        name: Optional[str] = None,
        version_tag: Optional[str] = None,
        region: Optional[str] = None,
        image_pull_secret: Optional[str] = None,
        env_secret: Optional[str] = None,
        build_id: Optional[str] = None,
    ):
        """
        Create a new version for a deployment.

        Args:
            agent_id: The agent ID
            deployment_id: The deployment ID
            image_url: Docker image URL
            name: Name for this version
            version_tag: Version tag (e.g., 'main/0.0.2')
            min_replica: Minimum replicas
            max_replica: Maximum replicas
            profile: Compute profile
            region: Deployment region
            image_pull_secret: Secret for private registries
            env_secret: Environment secret ID
            build_id: Build log ID from build command
        """
        payload = {
            "name": name,
            "agentId": agent_id,
            "deploymentId": deployment_id,
            "image": {
                "imageType": image_type,
                "imageCR": image_cr,
                "imageUrl": image_url,
            },
            "minReplica": min_replica,
            "maxReplica": max_replica,
            "profile": profile,
            "region": region,
        }
        if version_tag is not None:
            payload["versionTag"] = version_tag
        if image_pull_secret is not None:
            payload.setdefault("image", {})["imagePullSecret"] = image_pull_secret
        if env_secret is not None:
            payload["envSecret"] = env_secret
        if build_id is not None:
            payload["buildId"] = build_id
        
        if env_secret is not None:
            await self._request("PUT",f"/ai/v1/cloud/deployments/{deployment_id}/update",json={"envSecret":env_secret})
        return await self._request("POST", "/ai/v1/cloud/versions", json=payload)

    async def update_version(
        self,
        version_id: str,
        image_url: Optional[str] = None,
        min_replica: Optional[int] = None,
        max_replica: Optional[int] = None,
        profile: Optional[str] = None,
        image_type: Optional[str] = None,
        image_cr: Optional[str] = None,
        image_pull_secret: Optional[str] = None,
        env_secret: Optional[str] = None,
    ):
        """
        Update an existing version.

        Args:
            version_id: The version ID to update
            agent_id: The agent ID
            Other params: Optional fields to update
        """
        payload = {}

        if min_replica is not None:
            payload["minReplica"] = min_replica

        if max_replica is not None:
            payload["maxReplica"] = max_replica

        if profile is not None:
            payload["profile"] = profile

        if env_secret is not None:
            payload["envSecret"] = env_secret

        image = {}

        if image_url is not None:
            image["imageUrl"] = image_url

        if image_type is not None:
            image["imageType"] = image_type

        if image_cr is not None:
            image["imageCR"] = image_cr

        if image_pull_secret is not None:
            image["imagePullSecret"] = image_pull_secret

        if image:
            payload["image"] = image
        return await self._request(
            "PUT", f"/ai/v1/cloud/versions/{version_id}", json=payload
        )

    async def deactivate_version(self, version_id: str, force: bool = False):
        """Deactivate a version."""
        response =  await self._request(
            "PUT",
            f"/ai/v1/cloud/versions/{version_id}/activate",
            json={"activate": False, "force": force},
        )
        # print(response)
        return response

    async def activate_version(self, version_id: str):
        """Activate a version."""
        return await self._request(
            "PUT",
            f"/ai/v1/cloud/versions/{version_id}/activate",
            json={"activate": True},
        )

    async def agent_init(
        self, name: Optional[str] = None, template: Optional[str] = None
    ):
        """
        Initialize a deployment (creates both agent and deployment).

        Args:
            name: Name for the deployment (optional, backend generates if not provided)
            template: Template ID to use (e.g., 'Template01')

        Returns:
            Response containing agentId, deploymentId, name, template, status
        """

        payload = {}

        if name:
            payload["name"] = name

        if template:
            payload["template"] = template

        return await self._request(
            "POST",
            "/ai/v1/cloud/deployments",
            json=payload if payload else None,
        )

    async def list_versions(
        self,
        agent_id: str,
        deployment_id: str,
        page: int = 1,
        per_page: int = 10,
        sort: int = -1,
    ):
        """List all versions for an agent."""
        query_params = {
            "agentId": agent_id,
            "deploymentId": deployment_id,
            "page": page,
            "perPage": per_page,
            "sort": sort,
        }

        query_string = "&".join([f"{k}={v}" for k, v in query_params.items()])
        url = f"/ai/v1/cloud/versions?{query_string}"

        return await self._request("GET", url)

    async def agent_sessions_list(
        self,
        agent_id: str,
        deployment_id: str,
        version_id: Optional[str] = None,
        room_id: Optional[str] = None,
        session_id: Optional[str] = None,
        page: int = 1,
        per_page: int = 10,
        sort: int = -1,
    ):
        """List sessions for an agent, optionally filtered by version."""
        query_params = {
            "page": page,
            "perPage": per_page,
            "sort": sort,
        }

        if agent_id:
            query_params["agentId"] = agent_id
        if version_id:
            query_params["versionId"] = version_id
        if room_id:
            query_params["roomId"] = room_id
        if session_id:
            query_params["sessionId"] = session_id

        query_string = "&".join([f"{k}={v}" for k, v in query_params.items()])
        url = f"/ai/v1/cloud/deployments/{deployment_id}/sessions?{query_string}"

        return await self._request("GET", url)

    async def describe_version(
        self, deployment_id: str, version_id: Optional[str] = None
    ):
        """Get details of a specific version or the latest version."""
        if version_id is None:
            return await self._request(
                "GET", f"/ai/v1/cloud/deployments/{deployment_id}/latest"
            )
        return await self._request("GET", f"/ai/v1/cloud/versions/{version_id}")

    async def secret_set(
        self, name: str, secrets: dict, type: Optional[str] = "NORMAL"
    ):
        payload = {"name": name, "keys": secrets, "type": type}
        return await self._request("POST", "/ai/v1/cloud/secrets", json=payload)

    async def secret_list(self):
        return await self._request("GET", "/ai/v1/cloud/secrets")

    async def secret_remove(self, name: str):
        return await self._request("DELETE", f"/ai/v1/cloud/secrets/name/{name}")

    async def secret_get(self, name: str):
        return await self._request("GET", f"/ai/v1/cloud/secrets/name/{name}")

    async def secret_add_key(self, name: str, secrets: dict):
        # print(secrets)
        payload = secrets
        return await self._request(
            "PATCH", f"/ai/v1/cloud/secrets/keys/{name}", json=payload
        )

    async def secret_remove_key(self, name: str, keys: list[str]):
        payload = {"keys": keys}
        return await self._request(
            "DELETE", f"/ai/v1/cloud/secrets/keys/{name}", json=payload
        )

    async def agent_start(
        self,
        agent_id: str,
        version_id: Optional[str] = None,
        meeting_id: Optional[str] = None,
    ):
        """Start an agent session in a room."""
        if meeting_id is None:
            response = await self._request("POST", "/v2/rooms")
            meeting_id = response.get("roomId")
        payload = {
            "agentId": agent_id,
            "meetingId": meeting_id,
        }
        if version_id:
            payload["versionId"] = version_id
        response = await self._request(
            "POST",
            "/v2/agent/dispatch",
            json=payload,
        )
        # Return both the response and the meeting_id for downstream use
        return {"response": response, "roomId": meeting_id}

    async def agent_stop(self, meeting_id: str, session_id: str):
        return await self._request(
            "POST",
            f"/v2/sessions/end",
            json={"roomId": meeting_id, "sessionId": session_id},
        )

    async def agent_console_logs(
        self,
        deployment_id: str,
        agent_id: str,
        version_id: Optional[str] = None,
        limit: Optional[int] = None,
    ):
        """Get console logs for an agent, optionally filtered by version."""
        query_params = {}
        if version_id:
            query_params["versionId"] = version_id
        if limit is not None:
            query_params["perPage"] = limit
        if agent_id:
            query_params["agentId"] = agent_id

        query_string = "&".join([f"{k}={v}" for k, v in query_params.items()])
        url = f"/ai/v1/cloud/deployments/{deployment_id}/console-logs"
        if query_string:
            url = f"{url}?{query_string}"

        return await self._request("GET", url)

    async def get_build_log_presigned_url(self, deployment_id: str, tag: str):
        """
        Get a presigned URL for uploading build logs.

        Args:
            deployment_id: The deployment ID
            tag: The image tag (e.g., '1.0.0')

        Returns:
            Response containing buildId, presignedUrl, deploymentId, tag
        """
        payload = {
            "deploymentId": deployment_id,
            "tag": tag,
        }
        return await self._request(
            "POST", "/ai/v1/cloud/deployments/getPresignedUrl", json=payload
        )
