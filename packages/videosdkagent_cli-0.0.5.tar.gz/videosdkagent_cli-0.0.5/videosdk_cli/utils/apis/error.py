class VideoSDKError(Exception):
    """Base VideoSDK exception"""


class AuthenticationError(VideoSDKError):
    """Raised when auth token is invalid or expired"""


class APIRequestError(VideoSDKError):
    """Raised for non-auth API failures"""
