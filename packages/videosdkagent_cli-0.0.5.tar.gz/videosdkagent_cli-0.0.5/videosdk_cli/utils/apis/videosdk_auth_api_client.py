import os
import aiohttp
from videosdk_cli.utils.config_manager import get_config_value
from videosdk_cli.utils.apis.error import AuthenticationError, APIRequestError


class VideoSDKAsyncClient:
    def __init__(self):
        from videosdk_cli.utils.template_helper import API_BASE_URL

        self.auth_token = get_config_value("VIDEOSDK_AUTH_TOKEN") or ""
        self.base_url = API_BASE_URL.rstrip("/")

        self.headers = {
            "Authorization": self.auth_token,
            "Content-Type": "application/json",
        }

    async def _request(
        self,
        method: str,
        endpoint: str,
        *,
        session: aiohttp.ClientSession | None = None,
        **kwargs,
    ):
        """
        Common aiohttp request handler
        """
        url = endpoint if endpoint.startswith("http") else f"{self.base_url}{endpoint}"
        close_session = False

        if session is None:
            session = aiohttp.ClientSession(headers=self.headers)
            close_session = True

        try:
            async with session.request(method, url, **kwargs) as resp:
                # 🔐 Common auth handling
                if resp.status in (401, 403):
                    raise AuthenticationError(
                        "Authentication failed. Please check your VIDEOSDK_AUTH_TOKEN."
                    )

                if resp.status >= 400:
                    text = await resp.text()
                    raise APIRequestError(f"Request failed [{resp.status}]: {text}")

                # auto-detect JSON vs text
                content_type = resp.headers.get("Content-Type", "")
                if "application/json" in content_type:
                    return await resp.json()
                return await resp.text()

        finally:
            if close_session:
                await session.close()
