import aiohttp


class AuthAPIClient:
    """
    Client for VideoSDK CLI authentication flow.
    Responsible ONLY for talking to your backend auth APIs.
    """

    def __init__(self, api_base_url: str):
        self.base_url = api_base_url.rstrip("/")

    async def start_auth(self) -> dict:
        """
        Starts the auth flow.

        Expected response:
        {
            "verify_url": "...",
            "request_id": "...",
            "expires_in": 600
        }
        """
        async with aiohttp.ClientSession() as session:
            async with session.post(f"{self.base_url}/v2/cli/request/start") as resp:
                resp.raise_for_status()
                return await resp.json()

    async def check_status(self, requestId: str) -> dict:
        """
        Polls auth status.

        Expected approved response:
        {
            "status": "approved",
            "project_token": "VIDEOSDK_AUTH_TOKEN"
        }

        Other responses:
        { "status": "pending" }
        { "status": "expired" }
        """
        async with aiohttp.ClientSession() as session:
            async with session.get(
                f"{self.base_url}/v2/cli/request/status",
                params={"requestId": requestId},
            ) as resp:
                resp.raise_for_status()
                return await resp.json()
