import json
import click
from pathlib import Path

CONFIG_DIR = Path(click.get_app_dir("videosdk_config"))
CONFIG_FILE = CONFIG_DIR / "config.json"



def load_config():
    """
    Load the configuration from the standard user config directory.
    For Windows : C:/Users/User_name/AppData/Roaming/videosdk_config/config.json
    For mac/linux :  ~/.config/videosdk_config/config.json

    Returns:
        dict or None: Configuration dictionary, or None if file is empty or missing.
    """
    if not CONFIG_FILE.is_file():
        return None

    try:
        with open(CONFIG_FILE, "r") as f:
            content = f.read().strip()
            if not content:
                return None
            return json.loads(content)
    
    except json.JSONDecodeError:
        print(f"[WARNING] Config file at {CONFIG_FILE} is invalid. A new one will be created on next save.")
        return None
    
    except Exception as e:
        print(f"[ERROR] An unexpected error occurred while loading the config file: {e}")
        return None




def save_config(config: dict):
    """Save the configuration to the standard user config directory."""
    try:
        CONFIG_DIR.mkdir(parents=True, exist_ok=True)
        with open(CONFIG_FILE, "w") as f:
            json.dump(config, f, indent=2)
    
    except Exception as e:
        print(f"[ERROR] Unable to save config to {CONFIG_FILE}: {e}")



def get_config_value(key: str, default=None):
    """A helper function to safely get a single value from the config."""
    config = load_config()
    
    if not config:
        return default
    return config.get(key, default)



def set_config_value(key: str, value):
    """A helper function to safely set a single value in the config."""
    config = load_config() or {}
    config[key] = value
    save_config(config)
