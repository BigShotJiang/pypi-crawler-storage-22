class AuthenticationError(Exception):
    """Custom exception for API authentication failures (e.g., 401 Unauthorized)."""
    pass