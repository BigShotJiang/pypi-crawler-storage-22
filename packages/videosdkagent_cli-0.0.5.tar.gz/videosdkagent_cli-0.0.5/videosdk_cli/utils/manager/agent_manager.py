from genericpath import exists
import click
from typing import Optional
from pathlib import Path
from dotenv import dotenv_values
import os
import re
from videosdk_cli.utils.apis.deployment_client import DeploymentClient
from videosdk_cli.utils.videosdk_yaml_helper import update_agent_config
from videosdk_cli.utils.videosdk_yaml_helper import AgentConfig, DeployConfig
from InquirerPy import inquirer
from rich.table import Table
from videosdk_cli.utils.ui.kv_blocks import print_kv_blocks
from videosdk_cli.utils.ui.theme import (
    console,
    print_success,
    print_error,
    print_warning,
    print_info,
    PRIMARY,
    MUTED,
    SUCCESS,
    ERROR,
)


async def init_agent(
    app_dir: Path, name: Optional[str] = None, template: Optional[str] = None
):
    client = DeploymentClient()

    # Call backend - now creates both agent and deployment
    response = await client.agent_init(name=name, template=template)
    print(response)

    agent_id = response.get("agentId")
    deployment_id = response.get("id")
    agent_name = response.get("name") or "agent-test"

    if not agent_id or not deployment_id:
        raise RuntimeError("Invalid response from deployment init API")

    # Build AgentConfig dataclass
    agent_config = AgentConfig(
        id=agent_id,
        name=agent_name,
    )

    # Build DeployConfig dataclass with deploymentId
    deploy_config = DeployConfig(
        id=deployment_id,
    )

    # Update videosdk.yaml with both agent and deploy config
    update_agent_config(
        app_dir=app_dir,
        agent_config=agent_config,
        deploy_config=deploy_config,
    )

    return response


async def list_versions_manager(
    agent_id: str,
    deployment_id: str,
    page: int = 1,
    per_page: int = 10,
    sort: int = -1,
):
    client = DeploymentClient()
    try:
        response = await client.list_versions(
            agent_id, deployment_id, page, per_page, sort
        )
        versions = response.get("versions", [])

        if not versions:
            print_warning("No versions found")
            return

        table = Table(
            title=f"[bold {PRIMARY}]Versions[/bold {PRIMARY}]",
            show_lines=True,
            header_style=f"bold {PRIMARY}",
            border_style=MUTED,
        )

        table.add_column("Version ID", style=MUTED, no_wrap=True)
        table.add_column("Name", style=PRIMARY, no_wrap=True)
        table.add_column("Version Tag", style="white")
        table.add_column("Region", style="white")
        table.add_column("Profile", style="white")
        table.add_column("Active", style=MUTED, no_wrap=True)
        table.add_column("Created At", style="white")

        for v in versions:
            created = v.get("createdAt", "N/A").replace("T", " ").replace("Z", "")

            table.add_row(
                v.get("id", "N/A"),
                v.get("name", "N/A"),
                v.get("versionTag", "N/A"),
                v.get("region", "N/A"),
                v.get("profile", "N/A"),
                "Yes" if v.get("active") else "No",
                created,
            )

        console.print(table)
        return response
    except Exception as e:
        raise e


async def list_sessions_manager(
    agent_id: str,
    deployment_id: str,
    version_id: Optional[str] = None,
    room_id: Optional[str] = None,
    session_id: Optional[str] = None,
    page: int = 1,
    per_page: int = 10,
    sort: int = -1,
):
    client = DeploymentClient()
    try:
        response = await client.agent_sessions_list(
            agent_id=agent_id,
            deployment_id=deployment_id,
            version_id=version_id,
            room_id=room_id,
            session_id=session_id,
            page=page,
            per_page=per_page,
            sort=sort,
        )
        sessions = response.get("sessions", [])
        if not sessions:
            print_warning("No sessions found")
            return

        table = Table(
            title=f"[bold {PRIMARY}]Sessions[/bold {PRIMARY}]",
            show_lines=True,
            header_style=f"bold {PRIMARY}",
            border_style=MUTED,
        )

        # Columns: Session ID, Room ID, Version ID, Status, Duration
        table.add_column("Session ID", style=PRIMARY, no_wrap=True)
        table.add_column("Room ID", style="white", no_wrap=True)
        table.add_column("Version ID", style=MUTED, no_wrap=True)
        table.add_column("Status", style="white")
        table.add_column("Duration", style="white")

        for s in sessions:
            # Compute duration as "Xm Ys" from start and end times, or "-" if unavailable
            from datetime import datetime, timezone

            start_raw = s.get("start")
            end_raw = s.get("end")

            if start_raw:
                # Handle ISO format with potential Z suffix
                start_raw = start_raw.replace("Z", "+00:00")
                try:
                    start_dt = datetime.fromisoformat(start_raw)
                except ValueError:
                    # Fallback for formats that might not match standard ISO exactly if needed
                    start_dt = datetime.strptime(
                        start_raw.split(".")[0], "%Y-%m-%dT%H:%M:%S"
                    )

                if end_raw:
                    end_raw = end_raw.replace("Z", "+00:00")
                    try:
                        end_dt = datetime.fromisoformat(end_raw)
                    except ValueError:
                        end_dt = datetime.strptime(
                            end_raw.split(".")[0], "%Y-%m-%dT%H:%M:%S"
                        )

                    delta = end_dt - start_dt
                else:
                    # For running sessions, duration is up to now
                    end_dt = datetime.now(timezone.utc)
                    # Ensure start_dt is timezone-aware if end_dt is
                    if start_dt.tzinfo is None:
                        start_dt = start_dt.replace(tzinfo=timezone.utc)
                    delta = end_dt - start_dt

                total_seconds = int(delta.total_seconds())
                minutes = total_seconds // 60
                seconds = total_seconds % 60
                duration = f"{minutes}m {seconds}s"
            else:
                duration = "-"

            # Set display status: running if ended is None, else ended
            display_status = "running" if end_raw is None else "ended"

            table.add_row(
                s.get("sessionId", "N/A"),
                s.get("roomId", "N/A"),
                s.get("versionId", "N/A"),
                display_status,
                duration,
            )

        console.print(table)
        return response

    except Exception as e:
        raise e


async def describe_version_manager(agent_id: str, version_id: Optional[str] = None):
    client = DeploymentClient()
    try:
        response = await client.describe_version(agent_id, version_id)
        # print(response)
        data_to_print = {}
        if response:
            data_to_print = {
                "Agent ID": response.get("agentId", "N/A"),
                "Name": response.get("name", "N/A"),
                "Version Tag": response.get("versionTag", "N/A"),
                "Region": response.get("region", "N/A"),
                "Profile": response.get("profile", "N/A"),
                "Version ID": response.get("id", "N/A"),
                "Deployment ID": response.get("deploymentId", "N/A"),
                "Created At": response.get("createdAt", "N/A")
                .replace("T", " ")
                .replace("Z", ""),
                "minReplica": response.get("minReplica", "N/A"),
                "maxReplica": response.get("maxReplica", "N/A"),
                "Registry": response.get("image", {}).get("imageCR", "N/A"),
                "Image": response.get("image", {}).get("imageUrl", "N/A"),
                "Active": response.get("active", "N/A"),
                "Status": response.get("status", "N/A"),
            }

        print_kv_blocks([data_to_print])

    except Exception as e:
        raise e


def parse_env_file(env_file: Path) -> dict:
    if not env_file.exists():
        raise click.ClickException("Env file does not exist")

    env_vars = dotenv_values(env_file)

    if not env_vars:
        raise click.ClickException("Env file is empty or invalid")

    # Convert OrderedDict -> dict
    return dict(env_vars)


async def secret_set_manager(name: str, file: Optional[str] = None):
    client = DeploymentClient()
    try:
        console.print(f"Secret Name: [green]{name}[/green]")

        # 🔒 Validate secret name
        if not re.fullmatch(r"[a-z0-9_-]+", name):
            console.print(
                "❌ Invalid secret name.\n"
                "Rules:\n"
                "  • must be lowercase\n"
                "  • no spaces\n"
                "  • allowed characters: a-z, 0-9, -, _",
            )
            raise click.Abort()

        secrets = {}

        if file:
            console.print(f"File: [green]{file}[/green]")
            secrets = parse_env_file(Path(os.getcwd()) / file)

        else:
            while True:
                key = click.prompt("Enter key", type=str)
                if not re.fullmatch(r"^[A-Za-z0-9_-]+$", key):
                    console.print(
                        "❌ Invalid key.\n"
                        "Rules:\n"
                        "  • must be lowercase\n"
                        "  • no spaces\n"
                        "  • allowed characters: a-z, 0-9, -, _",
                    )
                    continue

                value = click.prompt("Enter value", type=str, hide_input=True)

                secrets[key] = value

                choice = inquirer.select(
                    message="Add another secret?",
                    choices=["Yes", "No"],
                    default="No",
                ).execute()

                if choice == "No":
                    break

        if not secrets:
            console.print("No secrets provided. Aborting.")
            return

        console.print("\nSecrets to be saved:")
        for k in secrets:
            console.print(f"- {k}: ******")

        action = inquirer.select(
            message="Confirm action",
            choices=["Save secrets", "Cancel"],
            default="Save secrets",
        ).execute()

        if action == "Cancel":
            console.print("[yellow]Cancelled. No secrets were saved.[/yellow]")
            return

        console.print("\nSaving secrets...")
        response = await client.secret_set(name, secrets)
        console.print("Secrets saved successfully.")
        return response
    except Exception as e:
        raise e


async def list_secret_manager():
    client = DeploymentClient()
    try:
        response = await client.secret_list()
        data = response.get("data", [])

        if not data:
            print_warning("No secrets found")
            return

        table = Table(
            title=f"[bold {PRIMARY}]Secrets[/bold {PRIMARY}]",
            show_lines=True,
            header_style=f"bold {PRIMARY}",
            border_style=MUTED,
        )

        table.add_column("Name", style=PRIMARY, no_wrap=True)
        # table.add_column("Secret ID", style=MUTED)
        table.add_column("Type", style="white")

        for d in data:
            table.add_row(
                d.get("name", "N/A"),
                # d.get("id", "N/A"),
                d.get("type", "N/A"),
            )

        console.print(table)
        print_success("Secrets listed successfully")
    except Exception as e:
        raise e


async def remove_secret_set(name: str):
    client = DeploymentClient()
    try:
        response = await client.secret_remove(name)
        print_success("Secret removed successfully")
    except Exception as e:
        raise e


async def describe_secret_set(name: str):
    client = DeploymentClient()
    try:
        response = await client.secret_get(name)
        data_to_print = {}
        data = response.get("data", {})
        if data:
            data_to_print = {
                "Name": data.get("name", "N/A"),
                "Secret ID": data.get("secretId", "N/A"),
                "Type": data.get("type", "N/A"),
            }
        print_kv_blocks([data_to_print])

        # Keys table
        keys = data.get("keys", {})

        if not keys:
            print_info("No keys found")
            return

        table = Table(
            title=f"[bold {PRIMARY}]Secret Keys[/bold {PRIMARY}]",
            show_header=True,
            header_style=f"bold {PRIMARY}",
            border_style=MUTED,
        )

        table.add_column("Key", style=PRIMARY, no_wrap=True)
        table.add_column("Value", style="white")

        for k in keys:
            table.add_row(k, keys.get(k, "N/A"))

        console.print(table)
    except Exception as e:
        raise e


async def add_secret_set(name: str):
    client = DeploymentClient()
    try:
        console.print("[bold blue]Adding secret...[/bold blue]")
        secrets = {}

        while True:
            key = click.prompt("Enter key", type=str)
            value = click.prompt("Enter value", type=str, hide_input=True)

            secrets[key] = value

            choice = inquirer.select(
                message="Add another secret?",
                choices=["Yes", "No"],
                default="No",
            ).execute()

            if choice == "No":
                break

        if not secrets:
            console.print("No secrets provided. Aborting.")
            return

        console.print("\nSecrets to be saved:")
        for k in secrets:
            console.print(f"- {k}: ******")

        action = inquirer.select(
            message="Confirm action",
            choices=["Save secrets", "Cancel"],
            default="Save secrets",
        ).execute()

        if action == "Cancel":
            console.print("[yellow]Cancelled. No secrets were saved.[/yellow]")
            return

        response = await client.secret_add_key(name, secrets)

        console.print("Secret added successfully.")
    except Exception as e:
        raise e


async def remove_secret_set_key(name: str):
    client = DeploymentClient()
    try:
        console.print("[bold blue]Removing secret...[/bold blue]")
        keys = []
        while True:
            key = click.prompt("Enter key", type=str)
            keys.append(key)

            choice = inquirer.select(
                message="Remove another key?",
                choices=["Yes", "No"],
                default="No",
            ).execute()

            if choice == "No":
                break
        if not keys:
            console.print("No keys provided.")
            return
        response = await client.secret_remove_key(name, keys)
        console.print("Secret removed successfully.")
    except Exception as e:
        raise e


async def image_pull_secret_manager(name: str):
    client = DeploymentClient()
    try:
        console.print("[bold blue]Setting image pull secret...[/bold blue]")
        console.print(f"Secret Name: [green]{name}[/green]")
        server = click.prompt("Enter server url", type=str)
        username = click.prompt("Enter username", type=str)
        password = click.prompt("Enter password", type=str, hide_input=True)
        response = await client.secret_set(
            name,
            {"serverName": server, "USERNAME": username, "PASSWORD": password},
            type="IMAGE_PULL",
        )
        console.print("Image pull secret set successfully.")
    except Exception as e:
        raise e


async def version_logs_manager(
    agent_id: str,
    deployment_id: str,
    version_id: Optional[str] = None,
    limit: Optional[int] = None,
):
    client = DeploymentClient()
    try:
        response = await client.agent_console_logs(
            deployment_id=deployment_id,
            agent_id=agent_id,
            version_id=version_id,
            limit=limit,
        )
        logs = response.get("logs", [])

        if not logs:
            print_warning("No logs found")
            return

        # Print logs in a readable format
        for log_entry in logs:
            timestamp = log_entry.get("timestamp", "")
            message = log_entry.get("log", "")
            level = log_entry.get("level", "info").upper()

            # Format timestamp
            if timestamp:
                timestamp = timestamp.replace("T", " ").replace("Z", "")

            # Color based on level
            if level == "ERROR":
                console.print(f"[{level}] {message}")
            elif level == "WARN" or level == "WARNING":
                console.print(f"[{level}] {message}")
            else:
                console.print(f"[{level}] {message}")

        return response
    except Exception as e:
        raise e
