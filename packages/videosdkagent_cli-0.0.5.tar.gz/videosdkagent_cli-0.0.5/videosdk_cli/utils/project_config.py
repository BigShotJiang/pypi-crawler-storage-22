import yaml
import click
import os
from pathlib import Path

def load_project_config(search_path=None):
    """
    Load the project configuration from videosdk.yaml or videosdk.yml.
    
    Args:
        search_path (Path, optional): Directory to search in. Defaults to current working directory.
        
    Returns:
        dict or None: Configuration dictionary if found, None otherwise.
    """
    if search_path is None:
        search_path = Path(os.getcwd())
    else:
        search_path = Path(search_path)
        
    config_path = search_path / "videosdk.yaml"
    if not config_path.exists():
        config_path = search_path / "videosdk.yml"
        
    if not config_path.exists():
        return None
        
    try:
        with open(config_path, 'r') as f:
            return yaml.safe_load(f)
    except Exception as e:
        # We perform a lenient load here. Validation errors should generally be handled 
        # by the caller or result in None/empty dict depending on strictness required.
        # But per requirements we usually just want the config if valid.
        # For now, if it fails to parse, we might return None or let the error bubble?
        # The prompt said "if not there in yaml we will throw error" only if required config is missing.
        # So if the file exists but is invalid, that's trickier. 
        # Let's print a warning and return None for now to be safe, 
        # preventing a crash if the file is just empty or garbage.
        click.echo(f"[WARNING] Failed to load config from {config_path}: {e}", err=True)
        return None

def get_config_option(cli_value, config_keys, default=None, required=True, fail_message=None):
    """
    Get a configuration option resolving priority: CLI > videosdk.yaml > Error (if required) > Default.
    
    Args:
        cli_value: The value provided via CLI (e.g. from click.option).
        config_keys (list[str]): List of keys to navigate the config dict (e.g. ['agent', 'image']).
        default: Default value if not found.
        required (bool): If True, raise UsageError if value is not found in CLI or config.
        fail_message (str, optional): Custom error message for UsageError.
        
    Returns:
        The resolved value.
    """
    # 1. Check CLI value
    if cli_value is not None:
        return cli_value
        
    # 2. Check Project Config
    config = load_project_config()
    if config:
        value = config
        for key in config_keys:
            if isinstance(value, dict):
                value = value.get(key)
            else:
                value = None
                break
        
        if value is not None:
            return value
            
    # 3. Check Default
    if default is not None:
        return default
        
    # 4. Fail if required/no default
    if required:
        if fail_message:
            raise click.UsageError(fail_message)
        else:
            key_path = ".".join(config_keys)
            raise click.UsageError(f"Missing required configuration: '{key_path}'. Please provide it via CLI or videosdk.yaml.")
            
    return None
