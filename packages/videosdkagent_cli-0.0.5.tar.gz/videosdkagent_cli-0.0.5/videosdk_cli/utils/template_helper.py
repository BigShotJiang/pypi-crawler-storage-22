from pathlib import Path
import json
import aiohttp
from datetime import datetime, timedelta
from rich.console import Console
from InquirerPy import inquirer
from videosdk_cli.utils.config_manager import get_config_value
import os

console = Console()

CACHE_DIR = Path.home() / ".videosdk"
CACHE_DIR.mkdir(exist_ok=True)
CACHE_FILE = CACHE_DIR / "template_cache.json"
TIMESTAMP_FILE = CACHE_DIR / "template_cache_timestamp.txt"
CDN_BASE_URL = "https://cdn.videosdk.live"
API_BASE_URL = "https://api.videosdk.live"
DASHBOARD_URL = "https://stage.app.videosdk.live"


PROVIDER_IMPORTS = {
    "DeepgramSTT": (
        "videosdk.plugins.deepgram",
        "DeepgramSTT",
        "STT",
        "deepgram",
        "DEEPGRAM_API_KEY",
    ),
    "GoogleSTT": (
        "videosdk.plugins.google",
        "GoogleSTT",
        "STT",
        "google-cloud-speech",
        "GOOGLE_API_KEY",
    ),
    "OpenAISTT": (
        "videosdk.plugins.openai",
        "OpenAISTT",
        "STT",
        "openai",
        "OPENAI_API_KEY",
    ),
    "OpenAILLM": (
        "videosdk.plugins.openai",
        "OpenAILLM",
        "LLM",
        "openai",
        "OPENAI_API_KEY",
    ),
    "GoogleLLM": (
        "videosdk.plugins.google",
        "GoogleLLM",
        "LLM",
        "google-cloud-language",
        "GOOGLE_API_KEY",
    ),
    "ElevenLabsTTS": (
        "videosdk.plugins.elevenlabs",
        "ElevenLabsTTS",
        "TTS",
        "elevenlabs",
        "ELEVENLABS_API_KEY",
    ),
    "OpenAITTS": (
        "videosdk.plugins.openai",
        "OpenAITTS",
        "TTS",
        "openai",
        "OPENAI_API_KEY",
    ),
    "GoogleTTS": (
        "videosdk.plugins.google",
        "GoogleTTS",
        "TTS",
        "google-cloud-texttospeech",
        "GOOGLE_API_KEY",
    ),
    "DeepgramTTS": (
        "videosdk.plugins.deepgram",
        "DeepgramTTS",
        "TTS",
        "deepgram",
        "DEEPGRAM_API_KEY",
    ),
    "OpenAIRealtime": (
        "videosdk.plugins.openai",
        "OpenAIRealtime",
        "Realtime",
        "openai",
        "OPENAI_API_KEY",
    ),
    "GeminiRealtime": (
        "videosdk.plugins.google",
        "GeminiRealtime",
        "Realtime",
        "google-cloud-realtime",
        "GOOGLE_API_KEY",
    ),
}

STATIC_REQUIREMENTS = [
    "videosdk",
    "aiohttp",
    "rich",
    "videosdk.agents",
    "videosdk.plugins.silero",
    "videosdk.plugins.turn_detector",
]


async def fetch_template_cache(force_refresh=False):
    """Fetch template metadata JSON from server if cache missing or expired."""
    if TIMESTAMP_FILE.exists() and not force_refresh:
        ts = datetime.fromisoformat(TIMESTAMP_FILE.read_text(encoding="utf-8"))
        if datetime.now() - ts < timedelta(hours=24) and CACHE_FILE.exists():
            console.print("[green]Using cached template metadata[/green]")
            return

    token = get_config_value("VIDEOSDK_AUTH_TOKEN")
    if not token:
        console.print("[red]VIDEOSDK_AUTH_TOKEN not set[/red]")
        return

    console.print("Fetching latest template metadata from server...")

    try:
        import aiohttp

        timeout = aiohttp.ClientTimeout(total=10)
        async with aiohttp.ClientSession(timeout=timeout) as session:
            async with session.get(
                f"{API_BASE_URL}/v2/cli/templates",
                headers={
                    "Accept": "application/json",
                    "Authorization": f"{token}",
                },
            ) as resp:
                if resp.status != 200:
                    console.print(
                        f"[red]Failed to fetch template metadata: {resp.status}[/red]"
                    )
                    return
                data = await resp.json()
                templateResponse = data.get("templates", {})
                CACHE_FILE.write_text(
                    json.dumps(templateResponse, indent=4), encoding="utf-8"
                )
                TIMESTAMP_FILE.write_text(datetime.now().isoformat(), encoding="utf-8")
                console.print("[green]Template metadata cache updated.[/green]")

    except Exception as e:
        console.print(f"[red]Error fetching template metadata: {e}[/red]")


async def select_provider_arrow(prompt_message: str, options: list[str]) -> str:
    """Arrow-based selection for providers."""
    choice = await inquirer.select(
        message=prompt_message,
        choices=options,
        pointer="👉",
        instruction="Use ↑ ↓ to navigate, Enter to select",
    ).execute_async()
    return choice


def generate_cascading_providers(providers: dict):
    """Generate imports and modules for cascading pipeline."""
    imports = []
    provider_modules = []
    for key in ["STT", "LLM", "TTS"]:
        provider_class = providers.get(key)
        if provider_class and provider_class in PROVIDER_IMPORTS:
            module, class_name, _, _, _ = PROVIDER_IMPORTS[provider_class]
            imports.append(f"from {module} import {class_name}")
            provider_modules.append(module)
    return imports, provider_modules


def generate_realtime_providers(providers: dict):
    """Generate imports and modules for realtime pipeline."""
    imports = []
    provider_modules = []
    provider_class = providers.get("Realtime")
    if provider_class and provider_class in PROVIDER_IMPORTS:
        module, class_name, _, _, _ = PROVIDER_IMPORTS[provider_class]
        imports.append(f"from {module} import {class_name}")
        provider_modules.append(module)
    return imports, provider_modules


def write_template_file(
    app_dir: Path, filename: str, imports_str: str, template_code: str
):
    file_path = app_dir / filename
    file_path.write_text(f"{imports_str}\n\n{template_code}", encoding="utf-8")


def write_config(
    app_dir: Path,
    template_id: str,
    file_name: str,
    description: str,
    providers: dict,
    env_path: str = None,
    auto_configured: bool = True,
    requirements_installed: bool = False,
):
    """Write project config.json with both template ID and file name."""
    config_data = {
        "template_id": template_id,
        "template_file": file_name,
        "description": description,
        "providers": providers,
        "auto_configured": auto_configured,
        "requirements_installed": requirements_installed,
    }
    if env_path:
        config_data["venv_path"] = env_path

    (app_dir / "config.json").write_text(
        json.dumps(config_data, indent=4), encoding="utf-8"
    )


def write_requirements(app_dir: Path, requirements: list):
    (app_dir / "requirements.txt").write_text(
        "\n".join(sorted(set(requirements))), encoding="utf-8"
    )


def write_env_file(app_dir: Path, selected_providers: dict, api_keys: dict):
    """Create a .env file with API keys and auth token."""
    from collections import OrderedDict

    auth_token = get_config_value("VIDEOSDK_AUTH_TOKEN") or ""

    env_vars = OrderedDict()
    env_vars["VIDEOSDK_AUTH_TOKEN"] = auth_token

    for provider in selected_providers.values():
        env_var_name = PROVIDER_IMPORTS.get(
            provider, (None, None, None, None, f"{provider.upper()}_API_KEY")
        )[-1]
        env_vars[env_var_name] = api_keys.get(provider, "")

    env_content = "\n".join(f"{key}={value}" for key, value in env_vars.items())
    (app_dir / ".env").write_text(env_content, encoding="utf-8")


async def prompt_provider_api_keys(providers: dict, api_keys: dict = None) -> dict:
    """Ask user for API keys for selected providers. Skip if already in api_keys."""
    if api_keys is None:
        api_keys = {}

    for provider in providers.values():
        if provider in api_keys:
            continue

        key = await inquirer.text(
            message=f"Enter API key for {provider}:",
            validate=lambda val: len(val.strip()) > 0 or "API key cannot be empty",
        ).execute_async()

        api_keys[provider] = key

    return api_keys


async def prompt_existing_env():
    """Ask user whether to use an existing Python environment."""
    use_existing = await select_provider_arrow(
        "Do you want to use an existing Python environment (venv/conda)?",
        ["No, create new venv", "Yes, I have an environment"],
    )
    if use_existing == "Yes, I have an environment":
        path = input("Enter the path to your environment: ").strip()
        return Path(path)
    return None
