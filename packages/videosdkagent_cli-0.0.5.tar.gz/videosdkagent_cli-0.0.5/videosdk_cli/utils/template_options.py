from pathlib import Path
import json
from dataclasses import dataclass
from datetime import datetime, timedelta

CACHE_DIR = Path.home() / ".videosdk"
CACHE_DIR.mkdir(exist_ok=True)
CACHE_FILE = CACHE_DIR / "template_cache.json"
CACHE_TIMESTAMP_FILE = CACHE_DIR / "template_cache_timestamp.txt"

@dataclass
class Template:
    """Represents a VideoSDK template."""
    file_name: str
    description: str
    mode: str
    pipe_type: str
    STT_options: list = None
    LLM_options: list = None
    TTS_options: list = None
    provider_options: list = None

class KeyValuePair:
    """Loads templates from cached JSON metadata."""
    def __init__(self, cache_file=CACHE_FILE):
        self.templates = {}
        if cache_file.exists():
            try:
                data = json.loads(cache_file.read_text(encoding="utf-8"))
                for name, info in data.items():
                    self.templates[name] = Template(
                        file_name=info.get("file_name"),
                        description=info.get("description"),
                        mode=info.get("mode"),
                        pipe_type=info.get("pipe_type"),
                        STT_options=info.get("STT_options"),
                        LLM_options=info.get("LLM_options"),
                        TTS_options=info.get("TTS_options"),
                        provider_options=info.get("provider_options")
                    )
            except Exception as e:
                print(f"[red]Failed to load template cache: {e}[/red]")
                self.templates = {}

    def get_template_names(self):
        """Return list of template names."""
        return list(self.templates.keys())

    def get_template(self, name: str):
        """Return Template object by name."""
        return self.templates.get(name)
