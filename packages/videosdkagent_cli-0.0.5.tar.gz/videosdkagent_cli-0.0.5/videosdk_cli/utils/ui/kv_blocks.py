def print_kv_blocks(items):
    max_key_len = max(len(k) for item in items for k in item.keys())

    for idx, item in enumerate(items):
        for key, value in item.items():
            print(f"{key.ljust(max_key_len)} : {value}")
        if idx != len(items) - 1:
            print()
