import asyncio
import contextlib
from rich.progress import Progress, BarColumn, TextColumn, TimeElapsedColumn


async def run_with_progress(
    coro,
    *,
    console,
    title: str = "Working",
    duration: float = 10.0,
):
    with Progress(
        TextColumn(f"[bold cyan]{title}"),
        BarColumn(bar_width=None),
        TextColumn("{task.percentage:>3.0f}%"),
        TimeElapsedColumn(),
        console=console,
    ) as progress:

        task_id = progress.add_task("progress", total=100)
        start_time = asyncio.get_event_loop().time()

        api_task = asyncio.create_task(coro)

        try:
            while True:
                elapsed = asyncio.get_event_loop().time() - start_time

                # Check if task is done - complete immediately if so
                if api_task.done():
                    result = await api_task
                    progress.update(task_id, completed=100)
                    return result

                # Update progress based on elapsed time (up to 95% until task completes)
                # Duration is the maximum expected time
                percent = min((elapsed / duration) * 95, 95)
                progress.update(task_id, completed=percent)

                # If we've exceeded the maximum duration, break and wait for task
                if elapsed >= duration:
                    # Task might still be running, wait for it
                    result = await api_task
                    progress.update(task_id, completed=100)
                    return result

                await asyncio.sleep(0.1)

        except asyncio.CancelledError:
            raise

        finally:
            if not api_task.done():
                api_task.cancel()

            with contextlib.suppress(
                asyncio.CancelledError,
                Exception,
            ):
                await api_task
