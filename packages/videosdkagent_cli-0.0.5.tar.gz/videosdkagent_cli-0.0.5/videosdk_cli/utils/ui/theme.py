"""
VideoSDK CLI Theme and Styling

Brand Colors:
- Primary: #D1BCFE (light purple/lavender)
- Secondary: #37265E (dark purple)
"""

from rich.console import Console
from rich.theme import Theme
from rich.panel import Panel
from rich.text import Text
from rich.style import Style

# VideoSDK Brand Colors
PRIMARY = "#D1BCFE"
SECONDARY = "#37265E"
SUCCESS = "#50FA7B"
ERROR = "#FF5555"
WARNING = "#FFB86C"
INFO = "#8BE9FD"
MUTED = "#6272A4"

# Custom theme for Rich
VIDEOSDK_THEME = Theme(
    {
        "primary": PRIMARY,
        "secondary": SECONDARY,
        "success": SUCCESS,
        "error": ERROR,
        "warning": WARNING,
        "info": INFO,
        "muted": MUTED,
        "header": f"bold {PRIMARY}",
        "highlight": f"bold {PRIMARY}",
        "command": f"bold {INFO}",
        "path": f"italic {MUTED}",
    }
)

# Create themed console
console = Console(theme=VIDEOSDK_THEME)


# ASCII Art Banner - Simple and clean
BANNER = f"""
[{PRIMARY}]╭────────────────────────────────────────────────────────────────────╮[/{PRIMARY}]
[{PRIMARY}]│[/{PRIMARY}]                                                                    [{PRIMARY}]│[/{PRIMARY}]
[{PRIMARY}]│[/{PRIMARY}]  [bold {PRIMARY}]██╗   ██╗██╗██████╗ ███████╗ ██████╗ ███████╗██████╗ ██╗  ██╗[/bold {PRIMARY}]  [{PRIMARY}]│[/{PRIMARY}]
[{PRIMARY}]│[/{PRIMARY}]  [bold {PRIMARY}]██║   ██║██║██╔══██╗██╔════╝██╔═══██╗██╔════╝██╔══██╗██║ ██╔╝[/bold {PRIMARY}]  [{PRIMARY}]│[/{PRIMARY}]
[{PRIMARY}]│[/{PRIMARY}]  [bold {PRIMARY}]██║   ██║██║██║  ██║█████╗  ██║   ██║███████╗██║  ██║█████╔╝[/bold {PRIMARY}]   [{PRIMARY}]│[/{PRIMARY}]
[{PRIMARY}]│[/{PRIMARY}]  [bold {PRIMARY}]╚██╗ ██╔╝██║██║  ██║██╔══╝  ██║   ██║╚════██║██║  ██║██╔═██╗[/bold {PRIMARY}]   [{PRIMARY}]│[/{PRIMARY}]
[{PRIMARY}]│[/{PRIMARY}]  [bold {PRIMARY}] ╚████╔╝ ██║██████╔╝███████╗╚██████╔╝███████║██████╔╝██║  ██╗[/bold {PRIMARY}]  [{PRIMARY}]│[/{PRIMARY}]
[{PRIMARY}]│[/{PRIMARY}]  [bold {PRIMARY}]  ╚═══╝  ╚═╝╚═════╝ ╚══════╝ ╚═════╝ ╚══════╝╚═════╝ ╚═╝  ╚═╝[/bold {PRIMARY}]  [{PRIMARY}]│[/{PRIMARY}]
[{PRIMARY}]│[/{PRIMARY}]                                                                    [{PRIMARY}]│[/{PRIMARY}]
[{PRIMARY}]│[/{PRIMARY}]        [{MUTED}]Your Complete Platform for Real-Time Communication[/{MUTED}]        [{PRIMARY}]│[/{PRIMARY}]
[{PRIMARY}]│[/{PRIMARY}]                                                                    [{PRIMARY}]│[/{PRIMARY}]
[{PRIMARY}]╰────────────────────────────────────────────────────────────────────╯[/{PRIMARY}]
"""

MINI_BANNER = """[bold #D1BCFE]◆ VideoSDK CLI[/bold #D1BCFE] [muted]v0.2.0[/muted]"""


def print_banner(mini: bool = True):
    """Print the VideoSDK banner."""
    if mini:
        console.print(MINI_BANNER)
        console.print()
    else:
        console.print(BANNER)


def print_header(text: str):
    """Print a styled header."""
    console.print()
    console.print(f"[bold {PRIMARY}]◆[/bold {PRIMARY}] [bold white]{text}[/bold white]")
    console.print()


def print_success(text: str):
    """Print a success message."""
    console.print(f"[{SUCCESS}]✓[/{SUCCESS}] {text}")


def print_error(text: str):
    """Print an error message."""
    console.print(f"[{ERROR}]✗[/{ERROR}] [bold {ERROR}]{text}[/bold {ERROR}]")


def print_warning(text: str):
    """Print a warning message."""
    console.print(f"[{WARNING}]![/{WARNING}] {text}")


def print_info(text: str):
    """Print an info message."""
    console.print(f"[{INFO}]ℹ[/{INFO}] {text}")


def print_step(text: str, step: int = None, total: int = None):
    """Print a step in a process."""
    if step and total:
        console.print(
            f"[{PRIMARY}]▸[/{PRIMARY}] [{MUTED}][{step}/{total}][/{MUTED}] {text}"
        )
    else:
        console.print(f"[{PRIMARY}]▸[/{PRIMARY}] {text}")


def print_key_value(key: str, value: str):
    """Print a key-value pair."""
    console.print(f"  [{MUTED}]{key}:[/{MUTED}] [{PRIMARY}]{value}[/{PRIMARY}]")


def print_divider():
    """Print a divider line."""
    console.print(f"[{MUTED}]{'─' * 60}[/{MUTED}]")


def create_styled_table(title: str = None):
    """Create a styled table with VideoSDK theme."""
    from rich.table import Table

    table = Table(
        title=f"[bold {PRIMARY}]{title}[/bold {PRIMARY}]" if title else None,
        show_header=True,
        header_style=f"bold {PRIMARY}",
        border_style=MUTED,
        title_style=f"bold {PRIMARY}",
        show_lines=True,
        row_styles=[f"on {SECONDARY}20", ""],  # Alternating row colors
    )
    return table


def styled_panel(content: str, title: str = None, subtitle: str = None):
    """Create a styled panel."""
    return Panel(
        content,
        title=f"[bold {PRIMARY}]{title}[/bold {PRIMARY}]" if title else None,
        subtitle=f"[{MUTED}]{subtitle}[/{MUTED}]" if subtitle else None,
        border_style=PRIMARY,
        padding=(1, 2),
    )
