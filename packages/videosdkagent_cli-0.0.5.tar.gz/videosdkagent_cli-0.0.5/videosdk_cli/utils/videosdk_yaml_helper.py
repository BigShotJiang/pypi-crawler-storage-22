import yaml
from pathlib import Path
from dataclasses import dataclass, asdict, field
from typing import Optional


@dataclass
class AgentConfig:
    templateId: Optional[str] = None
    id: Optional[str] = None
    name: Optional[str] = None
    description: Optional[str] = None
    image: Optional[str] = None  # Legacy v1.0 support

    @classmethod
    def from_dict(cls, data: dict):
        # Filter keys to only those present in the dataclass
        return cls(**{k: v for k, v in data.items() if k in cls.__annotations__})


@dataclass
class BuildLogsConfig:
    id: Optional[str] = None  # buildId from presigned URL response
    enabled: Optional[bool] = None

    @classmethod
    def from_dict(cls, data: dict):
        if data is None:
            return cls()
        return cls(id=data.get("id"), enabled=data.get("enabled"))


@dataclass
class BuildConfig:
    file: Optional[str] = None
    image: Optional[str] = None
    logs: Optional[BuildLogsConfig] = None

    @classmethod
    def from_dict(cls, data: dict):
        if data is None:
            return cls()
        logs_data = data.get("logs")
        return cls(
            file=data.get("file"),
            image=data.get("image"),
            logs=BuildLogsConfig.from_dict(logs_data) if logs_data else None,
        )


@dataclass
class ReplicasConfig:
    min: Optional[int] = None
    max: Optional[int] = None

    @classmethod
    def from_dict(cls, data: dict):
        if data is None:
            return cls()
        return cls(**{k: v for k, v in data.items() if k in cls.__annotations__})


@dataclass
class DeployConfig:
    id: Optional[str] = None  # deploymentId from API
    replicas: Optional[ReplicasConfig] = None
    profile: Optional[str] = None
    region: Optional[str] = None

    @classmethod
    def from_dict(cls, data: dict):
        if data is None:
            return cls()
        replicas_data = data.get("replicas")
        return cls(
            id=data.get("id"),
            replicas=ReplicasConfig.from_dict(replicas_data) if replicas_data else None,
            profile=data.get("profile"),
            region=data.get("region"),
        )


@dataclass
class SecretsConfig:
    env: Optional[str] = None
    image_pull: Optional[str] = None  # maps from 'image-pull' in YAML

    @classmethod
    def from_dict(cls, data: dict):
        if data is None:
            return cls()
        return cls(env=data.get("env"), image_pull=data.get("image-pull"))


@dataclass
class VideosdkYamlConfig:
    version: Optional[str] = None
    agent: Optional[AgentConfig] = None
    build: Optional[BuildConfig] = None
    deploy: Optional[DeployConfig] = None
    secrets: Optional[SecretsConfig] = None

    @classmethod
    def from_dict(cls, data: dict):
        agent_data = data.get("agent", {})
        build_data = data.get("build")
        deploy_data = data.get("deploy")
        secrets_data = data.get("secrets")

        # If agent_data is None (key exists but empty), default to empty dict
        if agent_data is None:
            agent_data = {}

        return cls(
            version=data.get("version"),
            agent=AgentConfig.from_dict(agent_data),
            build=BuildConfig.from_dict(build_data) if build_data else None,
            deploy=DeployConfig.from_dict(deploy_data) if deploy_data else None,
            secrets=SecretsConfig.from_dict(secrets_data) if secrets_data else None,
        )


def update_agent_config(
    app_dir: Path,
    agent_config: AgentConfig = None,
    deploy_config: DeployConfig = None,
    build_config: BuildConfig = None,
    secrets_config: SecretsConfig = None,
):
    """
    Update the videosdk.yaml with agent, deploy, build, and/or secrets configuration.

    Args:
        app_dir: Directory where videosdk.yaml is located
        agent_config: AgentConfig dataclass with agent fields to update
        deploy_config: DeployConfig dataclass with deploy fields to update
        build_config: BuildConfig dataclass with build fields to update
        secrets_config: SecretsConfig dataclass with secrets fields to update
    """
    videosdk_dir = app_dir
    videosdk_dir.mkdir(parents=True, exist_ok=True)

    config_file = videosdk_dir / "videosdk.yaml"

    config_data = {}

    if config_file.exists():
        try:
            with open(config_file, "r") as f:
                config_data = yaml.safe_load(f) or {}
        except yaml.YAMLError:
            pass

    # Load into dataclass structure
    yaml_config = VideosdkYamlConfig.from_dict(config_data)

    # Update agent fields if provided
    if agent_config:
        if yaml_config.agent is None:
            yaml_config.agent = AgentConfig()
        updates = asdict(agent_config)
        for key, value in updates.items():
            if value is not None and hasattr(yaml_config.agent, key):
                setattr(yaml_config.agent, key, value)

    # Update deploy fields if provided
    if deploy_config:
        if yaml_config.deploy is None:
            yaml_config.deploy = DeployConfig()
        updates = asdict(deploy_config)
        for key, value in updates.items():
            if value is not None and hasattr(yaml_config.deploy, key):
                # Handle nested ReplicasConfig
                if key == "replicas" and isinstance(value, dict):
                    if yaml_config.deploy.replicas is None:
                        yaml_config.deploy.replicas = ReplicasConfig()
                    for rkey, rvalue in value.items():
                        if rvalue is not None:
                            setattr(yaml_config.deploy.replicas, rkey, rvalue)
                else:
                    setattr(yaml_config.deploy, key, value)

    # Update build fields if provided
    if build_config:
        if yaml_config.build is None:
            yaml_config.build = BuildConfig()
        updates = asdict(build_config)
        for key, value in updates.items():
            if value is not None and hasattr(yaml_config.build, key):
                # Handle nested BuildLogsConfig
                if key == "logs" and isinstance(value, dict):
                    if yaml_config.build.logs is None:
                        yaml_config.build.logs = BuildLogsConfig()
                    for lkey, lvalue in value.items():
                        if lvalue is not None:
                            setattr(yaml_config.build.logs, lkey, lvalue)
                else:
                    setattr(yaml_config.build, key, value)

    # Update secrets fields if provided
    if secrets_config:
        if yaml_config.secrets is None:
            yaml_config.secrets = SecretsConfig()
        updates = asdict(secrets_config)
        for key, value in updates.items():
            if value is not None and hasattr(yaml_config.secrets, key):
                setattr(yaml_config.secrets, key, value)

    # Convert back to dict and clean None values
    raw_output = asdict(yaml_config)

    output_data = clean_nones(raw_output)

    # Write to YAML
    with open(config_file, "w") as f:
        yaml.dump(output_data, f, default_flow_style=False, sort_keys=False)


# Helper to remove None values recursively
def clean_nones(value):
    if isinstance(value, dict):
        return {k: clean_nones(v) for k, v in value.items() if v is not None}
    if isinstance(value, list):
        return [clean_nones(v) for v in value if v is not None]
    return value
