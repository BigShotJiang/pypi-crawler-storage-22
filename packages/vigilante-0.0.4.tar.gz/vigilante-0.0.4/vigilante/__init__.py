__version__ = "0.0.4"
__author__ = "Mustafa Yavuz Ak"
__all__ = ["__version__", "__author__"]

def info():
    return "Vigilante is a Vigilante. Good luck y'all!"