import sys

from vimgolf.vimgolf import main

if __name__ == "__main__":
    sys.exit(main())
