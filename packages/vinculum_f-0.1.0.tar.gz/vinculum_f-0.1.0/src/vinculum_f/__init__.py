"""
VINCULUM-F: High-performance trajectory divergence analysis engine.

This package provides optimized implementations of geometric similarity 
measures, specifically the Discrete Fréchet Distance and Dynamic Time Warping, 
utilizing LLVM-based JIT acceleration for maximum throughput.
"""

from .core import frechet_distance, dynamic_time_warping

__version__ = "0.1.0"
__all__ = ["frechet_distance", "dynamic_time_warping"]