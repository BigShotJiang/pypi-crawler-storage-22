"""
Core computational engine for VINCULUM-F.
Contains Numba-accelerated implementations of trajectory divergence algorithms.
"""

import numpy as np
from numba import njit

@njit(cache=True)
def _euclidean_distance(p1, p2):
    """
    Calculate the L2 norm (Euclidean distance) between two multidimensional points.
    
    Optimized to eliminate intermediate array allocations during JIT compilation.
    
    Args:
        p1 (np.ndarray): Coordinate vector of the first point.
        p2 (np.ndarray): Coordinate vector of the second point.
        
    Returns:
        float64: The scalar Euclidean distance.
    """
    dist_sq = 0.0
    for i in range(len(p1)):
        diff = p1[i] - p2[i]
        dist_sq += diff * diff
    return np.sqrt(dist_sq)

@njit(cache=True)
def _discrete_frechet(p, q):
    """
    Internal JIT-accelerated Discrete Fréchet Distance calculation.
    
    Implements the coupling measure between two polygonal chains. The algorithm 
    utilizes a dynamic programming approach to find the minimum coupling length.
    
    Complexity:
        Temporal: O(nm)
        Spatial: O(min(n, m)) - achieved via iterative row updates.
        
    Args:
        p (np.ndarray): Contiguous float64 array of shape (n, d).
        q (np.ndarray): Contiguous float64 array of shape (m, d).
        
    Returns:
        float64: The Discrete Fréchet Distance.
    """
    n = p.shape[0]
    m = q.shape[0]
    
    # Space optimization: ensure m is the smaller dimension
    if n < m:
        return _discrete_frechet(q, p)
    
    # DP vector representing the current row computation
    dp = np.empty(m, dtype=np.float64)
    
    # Initialization: Origin point
    dp[0] = _euclidean_distance(p[0], q[0])
    
    # Initialization: First row (i=0)
    for j in range(1, m):
        dp[j] = max(dp[j-1], _euclidean_distance(p[0], q[j]))
        
    # Iterative computation of subsequent rows
    for i in range(1, n):
        prev_diag = dp[0]
        # Update first element of current row
        dp[0] = max(dp[0], _euclidean_distance(p[i], q[0]))
        
        for j in range(1, m):
            dist = _euclidean_distance(p[i], q[j])
            # recurrence: L(i,j) = max(d(pi, qj), min(L(i-1, j), L(i, j-1), L(i-1, j-1)))
            current_val = max(dist, min(dp[j], dp[j-1], prev_diag))
            prev_diag = dp[j]
            dp[j] = current_val
            
    return dp[m-1]

def frechet_distance(path_a, path_b):
    """
    Interface for Discrete Fréchet Distance calculation between two trajectories.
    
    The Discrete Fréchet Distance measures the similarity between two sequences 
    of points that accounts for the location and ordering of the points along 
    the curves.
    
    Args:
        path_a (array_like): An (n, d) array representing the primary trajectory.
        path_b (array_like): An (m, d) array representing the secondary trajectory.
        
    Returns:
        float: The Discrete Fréchet Distance (Convergence Leash).
        
    Raises:
        ValueError: If inputs are not 2D, have mismatched dimensions, or are empty.
    """
    p = np.ascontiguousarray(path_a, dtype=np.float64)
    q = np.ascontiguousarray(path_b, dtype=np.float64)
    
    if p.ndim != 2 or q.ndim != 2:
        raise ValueError("Paths must be 2D arrays (n_points, dimensions)")
        
    if p.shape[1] != q.shape[1]:
        raise ValueError("Trajectories must have the same number of dimensions")
        
    if len(p) == 0 or len(q) == 0:
        raise ValueError("Trajectories cannot be empty")
        
    return _discrete_frechet(p, q)

@njit(cache=True)
def _dtw(p, q):
    """
    Internal JIT-accelerated Dynamic Time Warping (DTW) calculation.
    
    Calculates the optimal alignment between two sequences by minimizing the 
    cumulative distance.
    
    Complexity:
        Temporal: O(nm)
        Spatial: O(min(n, m)) - achieved via iterative row updates.
        
    Args:
        p (np.ndarray): Contiguous float64 array of shape (n, d).
        q (np.ndarray): Contiguous float64 array of shape (m, d).
        
    Returns:
        float64: Total cumulative DTW distance.
    """
    n = p.shape[0]
    m = q.shape[0]
    
    if n < m:
        return _dtw(q, p)
    
    dp = np.empty(m, dtype=np.float64)
    
    # Initialization: Origin point
    dp[0] = _euclidean_distance(p[0], q[0])
    
    # Initialization: First row (i=0)
    for j in range(1, m):
        dp[j] = dp[j-1] + _euclidean_distance(p[0], q[j])
        
    # Iterative computation of subsequent rows
    for i in range(1, n):
        prev_diag = dp[0]
        # Update first element of current row
        dp[0] += _euclidean_distance(p[i], q[0])
        
        for j in range(1, m):
            dist = _euclidean_distance(p[i], q[j])
            # recurrence: D(i,j) = d(pi, qj) + min(D(i-1, j), D(i, j-1), D(i-1, j-1))
            current_val = dist + min(dp[j], dp[j-1], prev_diag)
            prev_diag = dp[j]
            dp[j] = current_val
            
    return dp[m-1]

def dynamic_time_warping(path_a, path_b):
    """
    Interface for Dynamic Time Warping (DTW) distance calculation.
    
    DTW is an algorithm for measuring similarity between two temporal sequences 
    which may vary in speed. It finds the optimal non-linear alignment.
    
    Args:
        path_a (array_like): An (n, d) array representing the primary trajectory.
        path_b (array_like): An (m, d) array representing the secondary trajectory.
        
    Returns:
        float: The cumulative DTW distance.
        
    Raises:
        ValueError: If inputs are not 2D, have mismatched dimensions, or are empty.
    """
    p = np.ascontiguousarray(path_a, dtype=np.float64)
    q = np.ascontiguousarray(path_b, dtype=np.float64)
    
    if p.ndim != 2 or q.ndim != 2:
        raise ValueError("Paths must be 2D arrays (n_points, dimensions)")
        
    if p.shape[1] != q.shape[1]:
        raise ValueError("Trajectories must have the same number of dimensions")
        
    if len(p) == 0 or len(q) == 0:
        raise ValueError("Trajectories cannot be empty")
        
    return _dtw(p, q)