import numpy as np
import pytest
from vinculum_f import frechet_distance, dynamic_time_warping

def test_identical_paths():
    path = np.array([[0, 0], [1, 1], [2, 2]], dtype=np.float64)
    assert frechet_distance(path, path) == 0.0
    assert dynamic_time_warping(path, path) == 0.0

def test_simple_offset():
    path_a = np.array([[0, 0], [1, 0], [2, 0]], dtype=np.float64)
    path_b = np.array([[0, 1], [1, 1], [2, 1]], dtype=np.float64)
    # Fréchet distance should be 1.0
    assert pytest.approx(frechet_distance(path_a, path_b)) == 1.0
    # DTW distance should be 3.0 (sum of distances 1+1+1)
    assert pytest.approx(dynamic_time_warping(path_a, path_b)) == 3.0

def test_dtw_warping():
    path_a = np.array([[0, 0], [1, 1], [1, 1], [2, 2]], dtype=np.float64)
    path_b = np.array([[0, 0], [1, 1], [2, 2]], dtype=np.float64)
    # DTW should handle point repetition and result in 0.0
    assert pytest.approx(dynamic_time_warping(path_a, path_b)) == 0.0

def test_dtw_offset_sum():
    path_a = np.array([[0, 0], [1, 1], [2, 2]], dtype=np.float64)
    path_b = np.array([[0, 0.5], [1, 1.5], [2, 2.5]], dtype=np.float64)
    # Sum of distances: 0.5 + 0.5 + 0.5 = 1.5
    assert pytest.approx(dynamic_time_warping(path_a, path_b)) == 1.5

def test_diagonal_paths():
    path_a = np.array([[0, 0], [2, 2]], dtype=np.float64)
    path_b = np.array([[0, 2], [2, 0]], dtype=np.float64)
    # Max distance at start/end is 2.0. Min leash to cover both paths is 2.0.
    assert pytest.approx(frechet_distance(path_a, path_b)) == 2.0

def test_different_lengths():
    path_a = np.array([[0, 0], [1, 1], [2, 2]], dtype=np.float64)
    path_b = np.array([[0, 0], [2, 2]], dtype=np.float64)
    # The distance should be sqrt(2) since (1,1) must be matched with either (0,0) or (2,2)
    assert pytest.approx(frechet_distance(path_a, path_b)) == np.sqrt(2)

def test_empty_input():
    with pytest.raises(ValueError):
        frechet_distance(np.array([]), np.array([[0, 0]]))

def test_dimension_mismatch():
    path_a = np.array([[0, 0]], dtype=np.float64)
    path_b = np.array([[0, 0, 0]], dtype=np.float64)
    with pytest.raises(ValueError):
        frechet_distance(path_a, path_b)
