import numpy as np
import time
import pytest
from vinculum_f import frechet_distance, dynamic_time_warping

def test_large_scale_performance():
    """Verify performance metrics for large trajectories."""
    # Scale: 5000 points each, 3D space
    n_points = 5000
    dims = 3
    
    path_a = np.random.rand(n_points, dims).astype(np.float64)
    path_b = np.random.rand(n_points, dims).astype(np.float64)
    
    # First execution (includes JIT compilation overhead if cache is cold)
    start_time = time.time()
    dist_f_1 = frechet_distance(path_a, path_b)
    duration_1 = time.time() - start_time
    
    # Second execution (should be pure JIT-accelerated execution)
    start_time = time.time()
    dist_f_2 = frechet_distance(path_a, path_b)
    duration_2 = time.time() - start_time
    
    print(f"\nFréchet (5000x5000): Cold={duration_1:.4f}s, Warm={duration_2:.4f}s")
    
    # DTW Test
    start_time = time.time()
    dist_d = dynamic_time_warping(path_a, path_b)
    duration_d = time.time() - start_time
    print(f"DTW (5000x5000): {duration_d:.4f}s")
    
    assert np.isfinite(dist_f_1)
    assert dist_f_1 == dist_f_2
    assert np.isfinite(dist_d)
    
    # Target: 5k x 5k should be sub-second on modern hardware with JIT
    # We don't assert strict time to avoid CI failures, but we log it.

def test_memory_stability():
    """Verify system stability under repeated high-load cycles."""
    n_points = 2000
    dims = 2
    cycles = 10
    
    for i in range(cycles):
        path_a = np.random.rand(n_points, dims).astype(np.float64)
        path_b = np.random.rand(n_points, dims).astype(np.float64)
        
        dist_f = frechet_distance(path_a, path_b)
        dist_d = dynamic_time_warping(path_a, path_b)
        
        assert np.isfinite(dist_f)
        assert np.isfinite(dist_d)
