import numpy as np
import pytest
from hypothesis import given, strategies as st
from hypothesis.extra.numpy import arrays
from vinculum_f import frechet_distance, dynamic_time_warping

# Precision tolerance for floating point comparisons
TOLERANCE = 1e-9

def test_translation_invariance():
    """Trajectories translated by the same vector must maintain distance."""
    path_a = np.array([[0.0, 0.0], [1.0, 1.0], [2.0, 0.0]], dtype=np.float64)
    path_b = np.array([[0.0, 1.0], [1.0, 2.0], [2.0, 1.0]], dtype=np.float64)
    
    offset = np.array([100.5, -50.2], dtype=np.float64)
    
    d1_f = frechet_distance(path_a, path_b)
    d2_f = frechet_distance(path_a + offset, path_b + offset)
    
    d1_d = dynamic_time_warping(path_a, path_b)
    d2_d = dynamic_time_warping(path_a + offset, path_b + offset)
    
    assert pytest.approx(d1_f, abs=TOLERANCE) == d2_f
    assert pytest.approx(d1_d, abs=TOLERANCE) == d2_d

def test_high_dimensionality():
    """Verify stability in 128-dimensional space."""
    dims = 128
    path_a = np.random.rand(10, dims).astype(np.float64)
    path_b = np.random.rand(12, dims).astype(np.float64)
    
    # Should not raise any exceptions and return a finite float
    dist_f = frechet_distance(path_a, path_b)
    dist_d = dynamic_time_warping(path_a, path_b)
    
    assert np.isfinite(dist_f)
    assert np.isfinite(dist_d)
    assert dist_f >= 0
    assert dist_d >= 0

@given(
    arrays(
        dtype=np.float64, 
        shape=st.tuples(st.integers(1, 20), st.integers(1, 3)),
        elements=st.floats(min_value=-1e6, max_value=1e6)
    )
)
def test_identity_property(path):
    """The distance from a path to itself must be exactly zero."""
    assert pytest.approx(frechet_distance(path, path), abs=TOLERANCE) == 0.0
    assert pytest.approx(dynamic_time_warping(path, path), abs=TOLERANCE) == 0.0

@given(
    path_a=arrays(
        dtype=np.float64, 
        shape=st.tuples(st.integers(1, 10), st.just(2)),
        elements=st.floats(min_value=-1e3, max_value=1e3)
    ),
    path_b=arrays(
        dtype=np.float64, 
        shape=st.tuples(st.integers(1, 10), st.just(2)),
        elements=st.floats(min_value=-1e3, max_value=1e3)
    )
)
def test_symmetry(path_a, path_b):
    """Distance(A, B) must equal Distance(B, A)."""
    assert pytest.approx(frechet_distance(path_a, path_b), abs=TOLERANCE) == frechet_distance(path_b, path_a)
    assert pytest.approx(dynamic_time_warping(path_a, path_b), abs=TOLERANCE) == dynamic_time_warping(path_b, path_a)

def test_numerical_extremes():
    """Verify stability with extremely small differences."""
    path_a = np.array([[0, 0], [1, 1]], dtype=np.float64)
    path_b = np.array([[0, 1e-12], [1, 1 + 1e-12]], dtype=np.float64)
    
    dist_f = frechet_distance(path_a, path_b)
    dist_d = dynamic_time_warping(path_a, path_b)
    
    assert dist_f > 0
    assert dist_d > 0
    assert dist_f < 1e-10
    assert dist_d < 1e-10

def test_triangle_inequality_frechet():
    """Discrete Fréchet distance satisfies the triangle inequality."""
    A = np.array([[0, 0], [1, 1]], dtype=np.float64)
    B = np.array([[0, 1], [1, 2]], dtype=np.float64)
    C = np.array([[1, 1], [2, 2]], dtype=np.float64)
    
    d_ab = frechet_distance(A, B)
    d_bc = frechet_distance(B, C)
    d_ac = frechet_distance(A, C)
    
    assert d_ac <= d_ab + d_bc + TOLERANCE
