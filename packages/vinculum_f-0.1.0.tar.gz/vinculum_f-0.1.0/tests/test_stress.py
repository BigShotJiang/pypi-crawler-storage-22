import numpy as np
import pytest
from vinculum_f import frechet_distance, dynamic_time_warping

def test_stress_large_trajectories():
    """Stress test to identify memory saturation limits."""
    # 20,000 points each -> ~3.2 GB per matrix
    n_points = 20000
    dims = 2
    
    print(f"\nInitiating stress test: {n_points}x{n_points} trajectories...")
    
    path_a = np.random.rand(n_points, dims).astype(np.float64)
    path_b = np.random.rand(n_points, dims).astype(np.float64)
    
    try:
        dist_f = frechet_distance(path_a, path_b)
        print(f"Fréchet result: {dist_f}")
        
        dist_d = dynamic_time_warping(path_a, path_b)
        print(f"DTW result: {dist_d}")
        
    except MemoryError:
        print("Memory limit exceeded as anticipated.")
        raise
