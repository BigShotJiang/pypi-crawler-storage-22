"""A minimal model for testing."""
