"""This package contains all exceptions raised by knitting_machine. These exceptions represent violations of the allowed state of the knitting machine."""
