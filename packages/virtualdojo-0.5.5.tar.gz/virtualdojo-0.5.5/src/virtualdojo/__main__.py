"""Entry point for running as `python -m virtualdojo`."""

from virtualdojo.cli import app

if __name__ == "__main__":
    app()
