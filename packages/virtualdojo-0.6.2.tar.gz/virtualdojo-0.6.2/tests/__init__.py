"""Tests for VirtualDojo CLI."""
