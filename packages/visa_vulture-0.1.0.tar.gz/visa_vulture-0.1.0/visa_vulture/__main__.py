"""Allow running as: python -m visa_vulture"""

from .main import main

if __name__ == "__main__":
    raise SystemExit(main())
