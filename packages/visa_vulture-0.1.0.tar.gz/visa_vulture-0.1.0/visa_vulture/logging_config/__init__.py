"""Logging setup."""

from .setup import setup_logging, GUILogHandler

__all__ = ["setup_logging", "GUILogHandler"]
