"""Coordination between model and view."""

from .equipment_presenter import EquipmentPresenter

__all__ = ["EquipmentPresenter"]
