"""Test plan data structures."""

from dataclasses import dataclass, field
from enum import Enum
from typing import Sequence

# Plan type constants
PLAN_TYPE_POWER_SUPPLY = "power_supply"
PLAN_TYPE_SIGNAL_GENERATOR = "signal_generator"

# Hard validation limits (values beyond these are physically unreasonable)
# These cause errors and block test plan loading
HARD_LIMIT_POWER_MIN_DBM = -200.0  # Below thermal noise floor
HARD_LIMIT_POWER_MAX_DBM = 60.0  # 1 MW - beyond any practical equipment
HARD_LIMIT_FREQUENCY_MAX_HZ = 100e12  # 100 THz - beyond RF/microwave range
HARD_LIMIT_VOLTAGE_MAX_V = 10000.0  # Safety limit for lab equipment
HARD_LIMIT_CURRENT_MAX_A = 1000.0  # Safety limit for lab equipment


class ModulationType(Enum):
    """Supported modulation types for signal generators."""

    NONE = "none"
    AM = "am"
    FM = "fm"
    # Future: PSK = "psk", QAM = "qam", etc.


@dataclass
class ModulationConfig:
    """Base configuration for modulation.

    This is the base class for modulation configurations.
    Subclasses define specific parameters for each modulation type.
    """

    modulation_type: ModulationType
    modulation_frequency: float  # Hz - frequency of modulating signal

    def __post_init__(self) -> None:
        """Validate common modulation values."""
        if self.modulation_frequency <= 0:
            raise ValueError(
                f"modulation_frequency must be > 0, got {self.modulation_frequency}"
            )


@dataclass
class AMModulationConfig(ModulationConfig):
    """AM-specific modulation configuration."""

    depth: float = 50.0  # Percentage (0-100%)

    def __post_init__(self) -> None:
        """Validate AM modulation values."""
        super().__post_init__()
        if not 0 <= self.depth <= 100:
            raise ValueError(f"AM depth must be 0-100%, got {self.depth}")


@dataclass
class FMModulationConfig(ModulationConfig):
    """FM-specific modulation configuration."""

    deviation: float = 1000.0  # Hz

    def __post_init__(self) -> None:
        """Validate FM modulation values."""
        super().__post_init__()
        if self.deviation <= 0:
            raise ValueError(f"FM deviation must be > 0, got {self.deviation}")


@dataclass
class TestStep:
    """Base class for test plan steps.

    Contains common elements shared by all instrument-specific test steps.
    This class should not be instantiated directly - use a subclass like
    PowerSupplyTestStep or SignalGeneratorTestStep.
    """

    step_number: int
    duration_seconds: float
    description: str = ""
    absolute_time_seconds: float = 0.0  # Computed by TestPlan

    def __post_init__(self) -> None:
        """Validate common step values."""
        if self.duration_seconds < 0:
            raise ValueError(
                f"duration_seconds must be >= 0, got {self.duration_seconds}"
            )


@dataclass
class PowerSupplyTestStep(TestStep):
    """A single step in a power supply test plan."""

    voltage: float = 0.0
    current: float = 0.0

    def __post_init__(self) -> None:
        """Validate step values."""
        super().__post_init__()
        if self.voltage < 0:
            raise ValueError(f"voltage must be >= 0, got {self.voltage}")
        if self.current < 0:
            raise ValueError(f"current must be >= 0, got {self.current}")


@dataclass
class SignalGeneratorTestStep(TestStep):
    """A single step in a signal generator test plan."""

    frequency: float = 0.0  # Hz
    power: float = 0.0  # dBm (can be negative)
    modulation_enabled: bool = False  # Per-step modulation toggle

    def __post_init__(self) -> None:
        """Validate step values."""
        super().__post_init__()
        if self.frequency < 0:
            raise ValueError(f"frequency must be >= 0, got {self.frequency}")


@dataclass
class TestPlan:
    """
    A complete test plan with multiple steps.

    Test plans define sequences of instrument settings to apply
    during a test run. Each step specifies a duration (how long it
    lasts) and the plan computes absolute times as cumulative sums.
    The plan_type field determines which execution path is used and
    what step types are expected.
    """

    name: str
    plan_type: str
    steps: Sequence[TestStep] = field(default_factory=list)
    description: str = ""
    modulation_config: ModulationConfig | None = None  # For signal generator plans

    def __post_init__(self) -> None:
        """Compute absolute times from step durations."""
        self._compute_absolute_times()

    def _compute_absolute_times(self) -> None:
        """Set absolute_time_seconds on each step as cumulative sum of durations."""
        sorted_steps = sorted(self.steps, key=lambda s: s.step_number)
        cumulative = 0.0
        for step in sorted_steps:
            step.absolute_time_seconds = cumulative
            cumulative += step.duration_seconds

    @property
    def total_duration(self) -> float:
        """Get total test duration in seconds."""
        if not self.steps:
            return 0.0
        return sum(step.duration_seconds for step in self.steps)

    @property
    def step_count(self) -> int:
        """Get number of steps in the plan."""
        return len(self.steps)

    def duration_from_step(self, step_number: int) -> float:
        """
        Get total duration from a given step number to the end of the plan.

        Args:
            step_number: 1-based step number to start from

        Returns:
            Total duration in seconds from step_number onward (inclusive)
        """
        return sum(
            step.duration_seconds
            for step in self.steps
            if step.step_number >= step_number
        )

    def get_step(self, step_number: int) -> TestStep | None:
        """
        Get a step by number.

        Args:
            step_number: 1-based step number

        Returns:
            TestStep or None if not found
        """
        for step in self.steps:
            if step.step_number == step_number:
                return step
        return None

    def validate(self) -> list[str]:
        """
        Validate the test plan.

        Returns:
            List of validation error messages (empty if valid)
        """
        errors: list[str] = []

        if not self.name:
            errors.append("Test plan name is required")

        if not self.steps:
            errors.append("Test plan must have at least one step")
            return errors

        return errors

    def __str__(self) -> str:
        """String representation."""
        return (
            f"TestPlan('{self.name}', {self.step_count} steps, {self.total_duration}s)"
        )
