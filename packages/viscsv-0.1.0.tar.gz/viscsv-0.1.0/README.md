# VisCSV

![Python](https://img.shields.io/badge/Python-3.10%2B-3776AB?logo=python&logoColor=white)
![Pandas](https://img.shields.io/badge/Pandas-2.x-150458?logo=pandas&logoColor=white)
![License](https://img.shields.io/badge/License-MIT-000000?logo=opensourceinitiative&logoColor=white)

VisCSV turns CSV data (with image paths) into a clean, interactive HTML table.  
Simple API, fast preview, no server required.

## Highlights

- Image columns support (local paths or URLs)
- Smart type inference (number, datetime, boolean, json, code)
- Drag to reorder columns
- Resize column widths
- Built-in horizontal/vertical scrolling
- Chunked loading for large datasets

## Quickstart

```python
from viscsv import preview

preview("data.csv", output="output")
```

Open `output/viewer.html` in your browser.

## With Image Columns

```python
from viscsv import preview

preview("data.csv", image="image_path", output="output")
```

## Use the Class API

```python
from viscsv import VisCSV

vc = VisCSV(image="image")
vc.add("imgs/1.jpg", label="cat", score=0.98)
vc.add([
    {"image": "imgs/2.jpg", "label": "dog", "score": 0.87},
    {"image": "imgs/3.jpg", "label": "fox", "score": 0.72},
])
vc.build(output="output")
```

## Type Hints (Optional)

```python
preview(
    "data.csv",
    output="output",
    type_hints={"payload": "json", "created_at": "datetime"},
)
```

## Large Datasets

```python
preview("big.csv", output="output", chunk_size=2000)
```

## Links

- 中文说明: [README-ch.md](README-ch.md)
