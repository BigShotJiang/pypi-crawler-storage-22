import json
from pathlib import Path
from typing import Iterable


def write_meta_jsonl(meta_path: Path, records: Iterable[dict]) -> None:
    with meta_path.open("w", encoding="utf-8") as f:
        for r in records:
            f.write(json.dumps(r, ensure_ascii=False) + "\n")


def write_meta_chunk_js(meta_path: Path, records: list[dict]) -> None:
    payload = (
        "window.__VISCSV_LAST_CHUNK__ = "
        + json.dumps(records, ensure_ascii=False)
        + ";"
    )
    meta_path.write_text(payload, encoding="utf-8")
