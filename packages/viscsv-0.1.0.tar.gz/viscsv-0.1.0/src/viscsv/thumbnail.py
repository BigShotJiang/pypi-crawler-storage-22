from pathlib import Path
from PIL import Image, ImageDraw


def _save_image(img: Image.Image, dst: Path, quality: int) -> None:
    ext = dst.suffix.lower()
    if ext == ".png":
        img.save(dst, "PNG", optimize=True)
    else:
        img.save(dst, "JPEG", quality=quality)


def make_thumbnail(src: Path, dst: Path, size: int, quality: int = 85) -> bool:
    try:
        img = Image.open(src)
        img.thumbnail((size, size))
        _save_image(img, dst, quality)
        return True
    except Exception:
        img = Image.new("RGB", (size, size), (235, 235, 235))
        draw = ImageDraw.Draw(img)
        draw.rectangle([(0, 0), (size - 1, size - 1)], outline=(190, 190, 190))
        draw.line([(0, 0), (size - 1, size - 1)], fill=(200, 200, 200), width=2)
        draw.line([(0, size - 1), (size - 1, 0)], fill=(200, 200, 200), width=2)
        _save_image(img, dst, quality)
        return False
