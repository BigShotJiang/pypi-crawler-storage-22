from pathlib import Path
import json


HTML_TEMPLATE = """<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title>VisCSV Viewer</title>
<style>
:root {
  --bg: #f4f5f7;
  --panel: #ffffff;
  --ink: #1b1f24;
  --muted: #5b6472;
  --accent: #2a5d7c;
  --accent-soft: #e0ecf4;
  --border: #e2e6ea;
  --shadow: 0 8px 30px rgba(16, 24, 40, 0.08);
  --mono: "IBM Plex Mono", "SFMono-Regular", Consolas, "Liberation Mono", Menlo, monospace;
  --sans: "Source Sans 3", "Segoe UI", "Helvetica Neue", Arial, sans-serif;
}

* { box-sizing: border-box; }
body {
  margin: 0;
  font-family: var(--sans);
  color: var(--ink);
  background: radial-gradient(1200px 600px at 10% -10%, #f0f6fb, transparent),
              radial-gradient(900px 500px at 100% 10%, #f2f0fb, transparent),
              var(--bg);
  height: 100vh;
  overflow: hidden;
}

.page {
  height: 100vh;
  display: flex;
  flex-direction: column;
  overflow: hidden;
}

header {
  padding: 22px 36px 12px;
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 16px;
}

h1 {
  margin: 0 0 6px;
  font-weight: 700;
  font-size: 26px;
}

.subtitle {
  color: var(--muted);
  font-size: 14px;
}

.actions {
  display: flex;
  gap: 10px;
  flex-wrap: wrap;
}

.action-btn {
  border: 1px solid var(--border);
  background: var(--panel);
  border-radius: 999px;
  padding: 8px 14px;
  font-size: 13px;
  cursor: pointer;
  box-shadow: var(--shadow);
}

.drawer {
  display: none;
  grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
  gap: 14px;
  padding: 10px 36px 18px;
}

.drawer.active {
  display: grid;
}

.group {
  background: var(--panel);
  border: 1px solid var(--border);
  border-radius: 12px;
  padding: 12px 14px;
  box-shadow: var(--shadow);
  display: grid;
  gap: 8px;
}

.group label {
  font-size: 12px;
  color: var(--muted);
  text-transform: uppercase;
  letter-spacing: 0.06em;
}

.group input,
.group select {
  border: 1px solid var(--border);
  border-radius: 8px;
  padding: 8px 10px;
  font-size: 14px;
  outline: none;
  background: #fff;
}

.stats {
  display: grid;
  gap: 6px;
  font-size: 13px;
  color: var(--muted);
}

.stats strong {
  color: var(--ink);
}

.table-wrap {
  padding: 10px 36px 10px;
  overflow: auto;
  flex: 1 1 auto;
}

table {
  width: max-content;
  min-width: 100%;
  table-layout: auto;
  border-collapse: collapse;
  background: var(--panel);
  border-radius: 14px;
  overflow: hidden;
  box-shadow: var(--shadow);
}

thead th {
  position: sticky;
  top: 0;
  background: #f8fafc;
  border-bottom: 1px solid var(--border);
  text-align: left;
  font-size: 13px;
  padding: 12px;
  z-index: 2;
  min-width: 140px;
  white-space: nowrap;
}

.th-wrap {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 8px;
}

.col-resizer {
  width: 6px;
  height: 22px;
  cursor: col-resize;
  border-radius: 4px;
  background: rgba(0, 0, 0, 0.06);
  flex: 0 0 auto;
}

thead th.sorted {
  background: var(--accent-soft);
  color: var(--accent);
}

tbody td {
  border-bottom: 1px solid var(--border);
  padding: 10px 12px;
  font-size: 13px;
  vertical-align: top;
  max-width: 320px;
  word-break: break-word;
  white-space: normal;
  min-width: 140px;
}

tbody tr:hover {
  background: #f7fafc;
}

.preview {
  width: 120px;
}

.preview img {
  width: 110px;
  height: 110px;
  object-fit: cover;
  border-radius: 10px;
  border: 1px solid #d7dee6;
  cursor: pointer;
  background: #fff;
}

.cell-image img {
  width: 100%;
  height: auto;
  max-height: 160px;
  object-fit: cover;
  border-radius: 10px;
  border: 1px solid #d7dee6;
  cursor: pointer;
  background: #fff;
}

.cell-number {
  text-align: right;
  font-variant-numeric: tabular-nums;
}

.cell-code {
  font-family: var(--mono);
  background: #f3f4f6;
  border-radius: 6px;
  padding: 6px 8px;
  display: block;
  width: 100%;
  box-sizing: border-box;
}

.cell-json {
  font-family: var(--mono);
  white-space: pre-wrap;
  background: #f8fafc;
  border-radius: 8px;
  padding: 8px 10px;
  display: block;
  width: 100%;
  box-sizing: border-box;
}

.cell-date {
  font-family: var(--mono);
}


.badge {
  display: inline-block;
  padding: 2px 8px;
  border-radius: 999px;
  background: var(--accent-soft);
  color: var(--accent);
  font-size: 11px;
  margin-right: 6px;
}

.value-null {
  color: #9aa4af;
  font-family: var(--mono);
}

.footer {
  padding: 6px 36px 12px;
  color: var(--muted);
  font-size: 12px;
}

@media (max-width: 860px) {
  header { padding: 18px 18px 8px; flex-direction: column; align-items: flex-start; }
  .drawer, .table-wrap, .footer { padding-left: 18px; padding-right: 18px; }
  .cell-image img { width: 90px; height: 90px; }
}
</style>
</head>
<body>
<div class="page">

<header>
  <div>
    <h1>VisCSV Image Table</h1>
    <div class="subtitle">Focus on the data preview. Controls are tucked into drawers.</div>
  </div>
  <div class="actions">
    <button class="action-btn" data-toggle="search">Search</button>
    <button class="action-btn" data-toggle="filter">Filter</button>
    <button class="action-btn" data-toggle="sort">Sort</button>
    <button class="action-btn" data-toggle="stats">Stats</button>
  </div>
</header>

<section class="drawer" id="drawer-search">
  <div class="group">
    <label for="searchInput">Search</label>
    <input id="searchInput" placeholder="Search all columns" autocomplete="off">
    <div class="stats"><span>Total: <strong id="totalCount">0</strong></span>
    <span>Filtered: <strong id="filteredCount">0</strong></span></div>
  </div>
</section>

<section class="drawer" id="drawer-filter">
  <div class="group">
    <label>Filter</label>
    <select id="filterColumn"></select>
    <input id="filterValue" placeholder="Contains" autocomplete="off">
  </div>
</section>

<section class="drawer" id="drawer-sort">
  <div class="group">
    <label>Sort</label>
    <select id="sortColumn"></select>
    <select id="sortDir">
      <option value="asc">Ascending</option>
      <option value="desc">Descending</option>
    </select>
  </div>
</section>

<section class="drawer" id="drawer-stats">
  <div class="group">
    <label>Stats Column</label>
    <select id="statsColumn"></select>
    <div class="stats" id="statsPanel"></div>
  </div>
</section>

<section class="table-wrap">
  <table>
    <thead>
      <tr>
        {headers}
      </tr>
    </thead>
    <tbody id="tbody"></tbody>
  </table>
</section>

<div class="footer">
  Tip: Use the filter to quickly narrow a column, then sort for easier comparison.
</div>

<script>
const batchSize = {batch_size};
const columns = {columns};
const columnTypes = {column_types};
const imageColumn = {image_column};
const imageColumns = {image_columns};
const chunkCount = {chunk_count};

const placeholder =
  "data:image/svg+xml;charset=utf-8," +
  encodeURIComponent(`<svg xmlns='http://www.w3.org/2000/svg' width='120' height='120'>
  <rect width='100%' height='100%' fill='#f1f3f5'/>
  <path d='M10 10L110 110M110 10L10 110' stroke='#cbd5e1' stroke-width='4'/>
  </svg>`);

let data = [];
let view = [];
let cursor = 0;

const tbody = document.getElementById("tbody");
const totalCount = document.getElementById("totalCount");
const filteredCount = document.getElementById("filteredCount");
const filterColumn = document.getElementById("filterColumn");
const filterValue = document.getElementById("filterValue");
const sortColumn = document.getElementById("sortColumn");
const sortDir = document.getElementById("sortDir");
const searchInput = document.getElementById("searchInput");
const statsColumn = document.getElementById("statsColumn");
const statsPanel = document.getElementById("statsPanel");
const colSpan = columns.length;
const table = document.querySelector("table");
const tableWrap = document.querySelector(".table-wrap");

const drawers = {
  search: document.getElementById("drawer-search"),
  filter: document.getElementById("drawer-filter"),
  sort: document.getElementById("drawer-sort"),
  stats: document.getElementById("drawer-stats"),
};

let columnsOrder = [...columns];
const columnWidths = {};

document.querySelectorAll("[data-toggle]").forEach(btn => {
  btn.addEventListener("click", () => {
    const key = btn.getAttribute("data-toggle");
    Object.entries(drawers).forEach(([k, el]) => {
      el.classList.toggle("active", k === key ? !el.classList.contains("active") : false);
    });
  });
});

function setOptions(select, items) {
  select.innerHTML = items.map(v => `<option value="${v}">${v}</option>`).join("");
}

function normalizeValue(value) {
  if (value === null || value === undefined) return "";
  return String(value).toLowerCase();
}

function parseNumber(value) {
  const n = Number(value);
  return Number.isFinite(n) ? n : null;
}

function parseDate(value) {
  const t = Date.parse(value);
  return Number.isFinite(t) ? t : null;
}

function compareValues(a, b, type) {
  if (type === "number") {
    const na = parseNumber(a);
    const nb = parseNumber(b);
    if (na === null && nb === null) return 0;
    if (na === null) return -1;
    if (nb === null) return 1;
    return na - nb;
  }
  if (type === "datetime") {
    const ta = parseDate(a);
    const tb = parseDate(b);
    if (ta === null && tb === null) return 0;
    if (ta === null) return -1;
    if (tb === null) return 1;
    return ta - tb;
  }
  if (type === "boolean") {
    const ba = Boolean(a);
    const bb = Boolean(b);
    return (ba === bb) ? 0 : (ba ? 1 : -1);
  }
  const sa = normalizeValue(a);
  const sb = normalizeValue(b);
  if (sa < sb) return -1;
  if (sa > sb) return 1;
  return 0;
}

function sortView() {
  const col = sortColumn.value;
  const dir = sortDir.value === "desc" ? -1 : 1;
  const type = columnTypes[col] || "string";
  view.sort((a, b) => compareValues(a[col], b[col], type) * dir);
}

function applyFilters() {
  if (!data.length) {
    tbody.innerHTML = `<tr><td colspan="${colSpan}" class="value-null">No data</td></tr>`;
    updateCounts();
    statsPanel.innerHTML = "<span>No data</span>";
    return;
  }
  const q = searchInput.value.trim().toLowerCase();
  const fcol = filterColumn.value;
  const fval = filterValue.value.trim().toLowerCase();

  view = data.filter(row => {
    if (q) {
      const match = columns.some(c => normalizeValue(row[c]).includes(q));
      if (!match) return false;
    }
    if (fval) {
      return normalizeValue(row[fcol]).includes(fval);
    }
    return true;
  });

  sortView();
  cursor = 0;
  tbody.innerHTML = "";
  highlightSorted();
  renderBatch();
  updateCounts();
  updateStats();
}

function highlightSorted() {
  const col = sortColumn.value;
  document.querySelectorAll("thead th").forEach(th => {
    th.classList.toggle("sorted", th.getAttribute("data-col") === col);
  });
}

function renderBatch() {
  for (let i = cursor; i < Math.min(cursor + batchSize, view.length); i++) {
    const d = view[i];
    let row = "<tr>";
    for (const c of columnsOrder) {
      row += renderCell(d, c);
    }
    row += "</tr>";
    tbody.insertAdjacentHTML("beforeend", row);
  }
  cursor += batchSize;
}

function renderCell(row, col) {
  const v = row[col];
  const type = columnTypes[col] || "string";
  const dataCol = `data-col="${col}"`;
  const widthStyle = columnWidths[col] ? ` style="width:${columnWidths[col]}px;min-width:${columnWidths[col]}px"` : "";
  if (v === null || v === undefined || v === "") {
    return `<td ${dataCol}${widthStyle} class="value-null">null</td>`;
  }
  if ((type === "image" || imageColumns.includes(col)) && imageColumns.length) {
    const imgMap = row.__img_id__ || {};
    const imgId = imgMap[col];
    const raw = String(v);
    const src = imgId ? `thumbs/${imgId}` : (raw.startsWith("http") ? raw : placeholder);
    const openTarget = imgId ? `images/${imgId}` : (raw.startsWith("http") ? raw : null);
    return `<td ${dataCol}${widthStyle} class="cell-image">` +
           `<img src="${src}" loading="lazy" alt="image"` +
           (openTarget ? ` onclick="window.open('${openTarget}')"` : "") +
           `>` +
           `</td>`;
  }
  if (type === "number") {
    return `<td ${dataCol}${widthStyle} class="cell-number">${v}</td>`;
  }
  if (type === "boolean") {
    return `<td ${dataCol}${widthStyle}><span class="badge">${String(Boolean(v))}</span></td>`;
  }
  if (type === "datetime") {
    const t = parseDate(v);
    const text = t ? new Date(t).toLocaleString() : String(v);
    const iso = t ? new Date(t).toISOString() : String(v);
    return `<td ${dataCol}${widthStyle} class="cell-date" title="${iso}">${text}</td>`;
  }
  const s = String(v);
  if (type === "json" || s.trim().startsWith("{") || s.trim().startsWith("[")) {
    try {
      const obj = JSON.parse(s);
      return `<td ${dataCol}${widthStyle}><pre class="cell-json">${JSON.stringify(obj, null, 2)}</pre></td>`;
    } catch (e) {
      return `<td ${dataCol}${widthStyle}>${escapeHtml(s)}</td>`;
    }
  }
  if (type === "markdown") {
    return `<td ${dataCol}${widthStyle}>${escapeHtml(s)}</td>`;
  }
  if (type === "code" || s.includes(";") || (s.includes("{") && s.includes("}"))) {
    return `<td ${dataCol}${widthStyle}><code class="cell-code">${escapeHtml(s)}</code></td>`;
  }
  return `<td ${dataCol}${widthStyle}>${escapeHtml(s)}</td>`;
}

function escapeHtml(str) {
  return str
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#39;");
}

function renderHeader() {
  const thead = document.querySelector("thead tr");
  thead.innerHTML = columnsOrder.map(c => {
    const w = columnWidths[c];
    const style = w ? ` style="width:${w}px;min-width:${w}px"` : "";
    return `<th data-col="${c}" draggable="true"${style}><div class="th-wrap"><span>${c}</span><span class="col-resizer" data-resize="${c}"></span></div></th>`;
  }).join("");
  attachDragHandlers();
  attachResizeHandlers();
}

function attachDragHandlers() {
  const headers = document.querySelectorAll("thead th");
  headers.forEach(th => {
    th.addEventListener("dragstart", e => {
      e.dataTransfer.setData("text/plain", th.getAttribute("data-col"));
    });
    th.addEventListener("dragover", e => e.preventDefault());
    th.addEventListener("drop", e => {
      e.preventDefault();
      const from = e.dataTransfer.getData("text/plain");
      const to = th.getAttribute("data-col");
      if (!from || !to || from === to) return;
      const fromIdx = columnsOrder.indexOf(from);
      const toIdx = columnsOrder.indexOf(to);
      columnsOrder.splice(fromIdx, 1);
      columnsOrder.splice(toIdx, 0, from);
      tbody.innerHTML = "";
      cursor = 0;
      renderHeader();
      highlightSorted();
      renderBatch();
    });
  });
}

function attachResizeHandlers() {
  document.querySelectorAll(".col-resizer").forEach(resizer => {
    resizer.addEventListener("mousedown", e => {
      e.preventDefault();
      e.stopPropagation();
      const col = resizer.getAttribute("data-resize");
      const th = resizer.closest("th");
      const startX = e.clientX;
      const startWidth = th.getBoundingClientRect().width;

      function onMove(ev) {
        const delta = ev.clientX - startX;
        const next = Math.max(80, Math.round(startWidth + delta));
        columnWidths[col] = next;
        th.style.width = `${next}px`;
        th.style.minWidth = `${next}px`;
        document.querySelectorAll(`td[data-col="${col}"]`).forEach(td => {
          td.style.width = `${next}px`;
          td.style.minWidth = `${next}px`;
        });
      }

      function onUp() {
        window.removeEventListener("mousemove", onMove);
        window.removeEventListener("mouseup", onUp);
      }

      window.addEventListener("mousemove", onMove);
      window.addEventListener("mouseup", onUp);
    });
  });
}

function updateCounts() {
  totalCount.textContent = data.length;
  filteredCount.textContent = view.length;
}

function updateStats() {
  const col = statsColumn.value;
  const type = columnTypes[col] || "string";
  const values = view.map(r => r[col]).filter(v => v !== null && v !== undefined && v !== "");
  if (values.length === 0) {
    statsPanel.innerHTML = "<span>No data</span>";
    return;
  }

  if (type === "number") {
    const nums = values.map(v => parseNumber(v)).filter(v => v !== null);
    if (!nums.length) {
      statsPanel.innerHTML = "<span>No numeric data</span>";
      return;
    }
    const min = Math.min(...nums);
    const max = Math.max(...nums);
    const mean = nums.reduce((a, b) => a + b, 0) / nums.length;
    statsPanel.innerHTML = `<span class="badge">number</span>
      <div>count: <strong>${nums.length}</strong></div>
      <div>min: <strong>${min.toFixed(3)}</strong></div>
      <div>max: <strong>${max.toFixed(3)}</strong></div>
      <div>mean: <strong>${mean.toFixed(3)}</strong></div>`;
    return;
  }

  if (type === "boolean") {
    const counts = { true: 0, false: 0 };
    values.forEach(v => counts[Boolean(v)]++);
    statsPanel.innerHTML = `<span class="badge">boolean</span>
      <div>true: <strong>${counts.true}</strong></div>
      <div>false: <strong>${counts.false}</strong></div>`;
    return;
  }

  if (type === "datetime") {
    const times = values.map(v => parseDate(v)).filter(v => v !== null);
    if (!times.length) {
      statsPanel.innerHTML = "<span>No datetime data</span>";
      return;
    }
    const min = new Date(Math.min(...times)).toISOString();
    const max = new Date(Math.max(...times)).toISOString();
    statsPanel.innerHTML = `<span class="badge">datetime</span>
      <div>count: <strong>${times.length}</strong></div>
      <div>min: <strong>${min}</strong></div>
      <div>max: <strong>${max}</strong></div>`;
    return;
  }

  const freq = new Map();
  values.forEach(v => {
    const key = String(v);
    freq.set(key, (freq.get(key) || 0) + 1);
  });
  const top = Array.from(freq.entries()).sort((a, b) => b[1] - a[1]).slice(0, 5);
  statsPanel.innerHTML = `<span class="badge">string</span>` +
    top.map(([k, v]) => `<div>${k}: <strong>${v}</strong></div>`).join("");
}

function init() {
  setOptions(filterColumn, columns);
  setOptions(sortColumn, columns);
  setOptions(statsColumn, columns);

  filterColumn.value = columns[0];
  sortColumn.value = columns[0];
  statsColumn.value = columns[0];

  [searchInput, filterValue].forEach(el => el.addEventListener("input", applyFilters));
  [filterColumn, sortColumn, sortDir, statsColumn].forEach(el => el.addEventListener("change", applyFilters));

  renderHeader();
}

init();
loadChunks();

window.addEventListener("scroll", () => {
  if (window.innerHeight + window.scrollY >= document.body.offsetHeight - 400) {
    renderBatch();
  }
});

function loadChunks() {
  let index = 0;
  function loadNext() {
    if (index >= chunkCount) {
      applyFilters();
      return;
    }
    const script = document.createElement("script");
    script.src = `meta_${String(index).padStart(4, "0")}.js`;
    script.onload = () => {
      const chunk = Array.isArray(window.__VISCSV_LAST_CHUNK__) ? window.__VISCSV_LAST_CHUNK__ : [];
      if (chunk.length) {
        data = data.concat(chunk);
      }
      window.__VISCSV_LAST_CHUNK__ = [];
      applyFilters();
      index += 1;
      loadNext();
    };
    script.onerror = () => {
      index += 1;
      loadNext();
    };
    document.body.appendChild(script);
  }
  loadNext();
}
</script>

</div>
</body>
</html>
"""


def write_viewer(
    html_path: Path,
    columns: list[str],
    column_types: dict[str, str],
    image_column: str,
    image_columns: list[str],
    batch_size: int,
    chunk_count: int,
):
    headers = "".join(f"<th data-col=\"{c}\">{c}</th>" for c in columns)
    html = HTML_TEMPLATE
    html = html.replace("{headers}", headers)
    html = html.replace("{columns}", json.dumps(columns))
    html = html.replace("{column_types}", json.dumps(column_types))
    html = html.replace("{image_column}", json.dumps(image_column))
    html = html.replace("{image_columns}", json.dumps(image_columns))
    html = html.replace("{batch_size}", str(batch_size))
    html = html.replace("{chunk_count}", str(chunk_count))
    html_path.write_text(html, encoding="utf-8")
