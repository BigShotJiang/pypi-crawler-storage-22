import io
import os
import re
import shutil
import tempfile
import unittest
from pathlib import Path
import sys

# Ensure src is importable
ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / "src"
sys.path.insert(0, str(SRC))

from viscsv import VisCSV, preview, render


try:
    from PIL import Image
except Exception:  # pragma: no cover
    Image = None


def _make_image(path: Path, size=(64, 64), color=(120, 160, 200)) -> None:
    if Image is None:
        raise RuntimeError("Pillow not available")
    img = Image.new("RGB", size, color)
    img.save(path)


def _read_text(path: Path) -> str:
    return path.read_text(encoding="utf-8")


class TestVisCSV(unittest.TestCase):
    def setUp(self) -> None:
        self.tmpdir = Path(tempfile.mkdtemp(prefix="viscsv_test_"))

    def tearDown(self) -> None:
        shutil.rmtree(self.tmpdir, ignore_errors=True)

    def test_preview_csv_without_image_column(self):
        csv_path = self.tmpdir / "data.csv"
        csv_path.write_text("a,b\n1,hello\n2,world\n", encoding="utf-8")

        html_path = preview(csv_path, output=self.tmpdir / "out")
        self.assertTrue(html_path.exists())
        html = _read_text(html_path)
        self.assertIn("VisCSV Image Table", html)
        # no images directory should be required
        self.assertFalse((self.tmpdir / "out" / "images").exists())

    def test_render_with_images_and_chunking(self):
        img1 = self.tmpdir / "img1.jpg"
        img2 = self.tmpdir / "img2.jpg"
        _make_image(img1)
        _make_image(img2, color=(200, 120, 90))

        csv_path = self.tmpdir / "data_with_img.csv"
        csv_path.write_text(
            "image,label\n"
            f"{img1.as_posix()},cat\n"
            f"{img2.as_posix()},dog\n",
            encoding="utf-8",
        )

        out_dir = self.tmpdir / "out_img"
        html_path = render(csv_path, image="image", output=out_dir, chunk_size=1)

        self.assertTrue((out_dir / "images").exists())
        self.assertTrue((out_dir / "thumbs").exists())
        # chunk files should exist
        self.assertTrue((out_dir / "meta_0000.js").exists())
        self.assertTrue((out_dir / "meta_0001.js").exists())

        html = _read_text(html_path)
        self.assertRegex(html, r"const chunkCount = 2;")

    def test_viscsv_add_and_build(self):
        img1 = self.tmpdir / "img1.png"
        _make_image(img1)

        vc = VisCSV(image="image")
        vc.add(img1, label="cat", score=0.9)
        vc.add({"image": str(img1), "label": "dog", "score": 0.8})
        vc.add([
            {"image": str(img1), "label": "fox", "score": 0.7},
            {"image": str(img1), "label": "bear", "score": 0.6},
        ])

        out_dir = self.tmpdir / "out_add"
        html_path = vc.build(output=out_dir, chunk_size=2)
        self.assertTrue(html_path.exists())
        self.assertTrue((out_dir / "meta_0000.js").exists())

    def test_type_hints_override(self):
        csv_path = self.tmpdir / "data_types.csv"
        csv_path.write_text("a,b\n1,{\"k\": 1}\n2,{\"k\": 2}\n", encoding="utf-8")

        out_dir = self.tmpdir / "out_types"
        html_path = render(
            csv_path,
            output=out_dir,
            type_hints={"a": "string", "b": "json"},
        )
        html = _read_text(html_path)
        self.assertIn("\"a\": \"string\"", html)
        self.assertIn("\"b\": \"json\"", html)

    def test_tuple_input_requires_image(self):
        data = [("/path/a.jpg", "cat")]
        with self.assertRaises(ValueError):
            render(data, image=None, columns=["label"], output=self.tmpdir / "out_tuple")


if __name__ == "__main__":
    unittest.main()
