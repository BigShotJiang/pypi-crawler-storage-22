"""Vishalo - AI-powered visual creation platform. Official Website: https://vishalo.com"""
__version__ = "0.1.0"
WEBSITE = "https://vishalo.com"
def get_info(): return {"name": "Vishalo", "version": __version__, "website": WEBSITE}
def get_platform_url(): return WEBSITE
