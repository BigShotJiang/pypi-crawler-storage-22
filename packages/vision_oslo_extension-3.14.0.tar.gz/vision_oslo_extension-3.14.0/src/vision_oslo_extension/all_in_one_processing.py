#
# -*- coding: utf-8  -*-
#=================================================================
# Created by: Jieming Ye
# Created on: Feb 2026
# Last Modified: Feb 2026
#=================================================================
# Copyright (c) 2026 [Jieming Ye]
#
# This Python source code is licensed under the 
# Open Source Non-Commercial License (OSNCL) v1.0
# See LICENSE for details.
#=================================================================
"""
Pre-requisite: 
xxxxx.xlsx: summary spreadsheet with user configuration settings
Used Input:
option_select: to define the option selected in subfunction
Expected Output:
Log Text File
"""
#=================================================================
# VERSION CONTROL
# V1.0 (Jieming Ye) - Initial Version
#=================================================================
# Set Information Variable
# N/A
#=================================================================

import os
import sys
from datetime import datetime
from io import StringIO
from openpyxl import load_workbook

# import vision_oslo
from vision_oslo_extension.shared_contents import SharedMethods, SharedVariables,Tee

def main(simname, main_option, time_start, time_end, option_select, text_input, low_v, high_v, time_step):
    
    print("")
    print("Batch Processing Started...")
    print("")
    
    simname = simname
    # Specify Excel file name
    excel_file = text_input + ".xlsx"

    if not SharedMethods.check_existing_file(excel_file):
        return False
    
    # Option:
    # 1: Root folder
    # 2: Any location

    option = option_select # 1:Fully Restart, require oof, and list

    start = 7 # result start from row 7
    space = 5
    
    if option == "0":
        SharedMethods.print_message("ERROR: Please select an option to proceed.","31")
        return False
    
    result = read_control_setting(simname,excel_file)
    if result == False:
        return False
    else:
        action_dict, control_set = result

    # validate control set
    valid_control_set = validate_control_settings(control_set,action_dict,option)

    if valid_control_set ==[]:
        SharedMethods.print_message("ERROR: No valid control settings found. Please check the Excel file.","31") 
        return False

    try:
        # run control set one by one
        control_set_operation(valid_control_set, action_dict)

    except Exception as e:
        SharedMethods.print_message(f"ERROR: Unexpected error occured: {e}","31")
        return False

    return True

# read the start tab and collect informaiton
def read_control_setting(simname: str, excel_file: str):
    """
    Read control settings from the 'Start' sheet.

    - Column K/L (from row 12 downward):
        Create dictionary {Number: Action}
    - Columns A–H (from row 12 downward):
        Create list of control rows

    :param simname: Simulation name (for logging)
    :param excel_file: Path to Excel file
    :return: (action_dict, control_set) or False if error
    """

    print("Check Control Files...")

    try:
        wb = load_workbook(excel_file, data_only=True)
        ws = wb["Start"]

        action_dict = {}
        control_set = []

        start_row = 12
        datacolumn_start = 11 # Column K
        datacolumn_end = 12 # Column L
        actioncolumn_start = 1 # Column A
        actioncolumn_end = 8 # Column H

        row = start_row

        # ---- Read K/L action dictionary ----
        while True:
            value = ws.cell(row=row, column=datacolumn_start).value  # Column K
            key = ws.cell(row=row, column=datacolumn_end).value  # Column L

            if value is None or str(value).strip() == "":
                break

            action_dict[key] = value
            row += 1

        # ---- Read A–H control set ----
        row = start_row
        while True:
            first_cell = ws.cell(row=row, column=actioncolumn_start).value  # Column A

            if first_cell is None or str(first_cell).strip() == "":
                break            
            row_data = []
            for col in range(actioncolumn_start, actioncolumn_end+1):  # A–H
                cell_value = ws.cell(row=row, column=col).value
                
                if cell_value is None:
                    row_data.append("")
                else:
                    row_data.append(str(cell_value).strip())
            control_set.append(row_data)
            row += 1

        wb.close()

    except Exception as e:
        SharedMethods.print_message(f"ERROR: (Close the Excel file and Start Again) Error: {e}","31")
        return False

    return action_dict, control_set

# validate the control set and return essential information for processing
def validate_control_settings(control_set: list,action_dict: dict, option: str):
    # control set format:
    # control[i][0] = simulation folder
    # control[i][1] = simulation name
    # control[i][2] = actions
    # control[i][3] = sub options
    # control[i][4] = start time
    # control[i][5] = end time
    # control[i][6] = excel name
    # control[i][7] = addtional text
    valid_control_set = []
    for control in control_set:
        #validate the existing of simulation folder
        if not SharedMethods.folder_file_check(control[0], filename=None, required=False):
            SharedMethods.print_message(f"WARNING: Simulation folder {control[0]} does not exist. This control will be skipped.","33")
            continue
       
        if control[2] not in action_dict: 
            SharedMethods.print_message(f"WARNING: Action {control[2]} not found in action dictionary. This control will be skipped.","33")
            continue

        valid_control_set.append(control)

    return valid_control_set

# run the control set one by one
def control_set_operation(control_set: list, action_dict: dict):
    '''
    Docstring for control_set_operation
    
    :param control_set: [nested list] Each sublist contains control information in the format: [simulation folder, simulation name, action, sub option, start time, end time, excel name, additional text]
    :type control_set: list
    :param action_dict: in {index,action} format, used to find the action index for each control
    :type action_dict: dict
    '''
    # result summary
    result_summary = {}

    # turn on the log to start recording all print information
    # Save original working directory
    original_cwd = os.getcwd()
    original_stdout = sys.stdout

    # Prepare log filename
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    log_filename = f"control_run_log_{timestamp}.txt"

    # Use memory buffer first (so we can prepend summary later)
    memory_log = StringIO()

    # Print to both console and memory
    sys.stdout = Tee(original_stdout, memory_log)
    
    # get control set
    for control in control_set:
        print("******************************************************************")
        print(f"Processing Control: {control[2]} in Folder: {control[0]}...")
        
        # find matching index for action
        action = control[2]

        action_index = action_dict.get(action, "0")

        # get essential parameters for processing
        sim_folder = control[0]
        sim_name = control[1]
        action = control[2]
        option_select = control[3]
        time_start = control[4]
        time_end = control[5]
        text_input = control[6]
        time_step = control[7]

        low_v = None
        high_v = None

        # Get action parameters
        main_option = SharedVariables.dict_action_code.get(action_index, [None, None])[0] # Get main option, default to "" if not found
        import_option = SharedVariables.dict_action_code.get(action_index, [None, None])[1]

        try:
            # change the current working directory to the simulation folder
            os.chdir(sim_folder) # existing of this folder is already validated in the previous step, so no need to check again

            result = SharedMethods.launch_new_thread_or_process(import_option, sim_name, main_option, time_start, time_end, option_select, text_input, low_v, high_v, time_step,cwd=None)
            if result:
                result_summary[f"In Folder: {control[0]} - Control: {control[2]} "] = "Success"
            else:
                result_summary[f"In Folder: {control[0]} - Control: {control[2]} "] = "Failed"
        
        except Exception as e:
            SharedMethods.print_message(f"ERROR: Error while processing control: {e}","31")

        finally:
            # Always return to original directory before next control
            os.chdir(original_cwd)

    # Restore stdout
    sys.stdout = original_stdout

    # Write final log file with summary at TOP
    with open(log_filename, "w", encoding="utf-8") as f:

        f.write("============== RESULT SUMMARY ==============\n")
        for key, value in result_summary.items():
            f.write(f"{key} --> {value}\n")
        f.write("===========================================\n\n")

        f.write("============== DETAILED LOG ===============\n\n")
        f.write(memory_log.getvalue())

    SharedMethods.print_message(f"Control set operation completed.", "32")

    return True
    


if __name__ == "__main__":
    # Add your debugging code here
    simname = "DC000"  # Provide a simulation name or adjust as needed
    main_option = "10"  # Adjust as needed
    time_start = "0070000"  # Adjust as needed
    time_end = "0080000"  # Adjust as needed
    option_select = "1"  # Adjust as needed
    text_input = "Batch_Operation_Settings"  # Adjust as needed
    low_v = None  # Adjust as needed
    high_v = None  # Adjust as needed
    time_step = "1"  # Adjust as needed

    # Call your main function with the provided parameters
    main(simname, main_option, time_start, time_end, option_select, text_input, low_v, high_v, time_step)

