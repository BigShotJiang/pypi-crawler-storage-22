# visor_vari

**Librería que Permite la visualización de grandes conjuntos de datos en sistemas**

`visor_vari` es una herramienta de debugging que permite monitorear el estado de las variables durante la ejecución de un programa Python, ofreciendo una alternativa visual y organizada.

## 📦 Instalación

### Forma recomendada:

Desde la carpeta raíz del paquete (donde está setup.py):

```bash
pip install -e .
```

Esta opción crea un enlace simbólico, por lo que cualquier cambio en el código se refleja inmediatamente sin necesidad de reinstalar.

ir a github: https://github.com/Metal-Alcyone-zero/visor_vari

### Forma normal:

```bash
# Instalación normal
pip install visor-vari
```

## 🚀 Uso Básico

```python
from visor_vari import refer, gentil

# Asigna tus variables a las celdas del visor
a = 10
b = 15

refer.selda_0 = a
refer.selda_1 = b

# Visualiza los valores
gentil()

# Las variables pueden cambiar durante la ejecución
refer.selda_0 = 43

c = 17
refer.selda_41 = c

# Visualiza los nuevos valores
gentil()
```

## 📊 Características

- **81 celdas de almacenamiento**: `selda_0` hasta `selda_80` para monitorear múltiples variables
- **8 modos de visualización**: 4 modos sin ventana (consola) y 4 con ventana Tkinter
- **Seguimiento en tiempo real**: Detecta y muestra cambios en las variables durante la ejecución
- **Fácil integración**: Solo necesitas importar y usar

## 🎯 Modos de Operación

1. **Modo simple** (`gentil()`): Muestra variables una a una
2. **Modo serie** (`gentil(n, "serie")`): Muestra series de variables por grupo
3. **Modo serie con rieles** (`riel()` + `gentil()`): Visualización puntual en serie
4. **Modo paralelo** (`gentil(n, "paralelo")`): Visualización de todas las variables en paralelo

## 📝 Ejemplo Completo

```python
from visor_vari import refer, gentil, riel

def mi_funcion():
    x = 5
    y = 10
    
    # Guardar en el visor
    refer.selda_0 = x
    refer.selda_1 = y
    
    # Ver valores
    gentil()
    
    # Realizar operaciones
    x = x + y
    refer.selda_0 = x
    
    # Ver cambios
    gentil()

mi_funcion()
```

## 📚 Documentación Adicional

Para más información sobre los modos de visualización, consulta:

```python
from visor_vari.readme_visor import readme, readme_tipos
```

## 🔧 Requisitos

- Python 3.6+
- tkinter (incluido con Python)

## 📄 Licencia

Licencia pública de Mozilla versión 2.0

## 🤝 Contribuciones

Las contribuciones son bienvenidas.
