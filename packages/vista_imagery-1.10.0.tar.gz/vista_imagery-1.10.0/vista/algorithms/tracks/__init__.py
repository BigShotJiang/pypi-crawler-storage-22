"""Track processing algorithms."""
