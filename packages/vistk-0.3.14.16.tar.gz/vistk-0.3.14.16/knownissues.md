# Issues

## Unresolved

### Project Setup

#### Hangs on VIS new

Found 0.3.6

Known work-arounds:

- Ctrl+C and continue process

## Resolved

### Form/Template

#### Relative path breaks after .exe is created

Found 0.3.3
Fixed 0.3.6

#### Form Extracts Wrong

Found 0.3.6
Fixed 0.3.7
