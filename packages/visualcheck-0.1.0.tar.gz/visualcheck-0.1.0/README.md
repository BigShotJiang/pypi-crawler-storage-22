# visualcheck

Visual regression checking with **Figma-first baselines**, **pixel diff + SSIM**, **ignore regions**, and a **self-contained HTML report**.

## Install

```bash
pip install visualcheck
playwright install chromium
```

## Quickstart

Create `visualcheck.yaml`:

```yaml
project: consumer_website
suite: daily_sanity

envs:
  qa: "https://qa.example.com"
  prod: "https://www.example.com"

views:
  desktop_profiles: ["desktop_1440x900"]
  mobile_devices: ["iPhone 15 Pro Max", "iPhone 13 mini", "Pixel 7"]

pages:
  - id: home
    url: "/"

baseline:
  priority: ["figma", "runtime"]
  create_if_missing: true
  never_overwrite: true
  on_created: "INFO"

compare:
  resize_on_mismatch: true
  mismatch_level: "WARN"
  thresholds:
    max_pixel_diff_pct: 0.10
    min_ssim: 0.995

ignore_regions:
  global:
    selectors: ["#cookie-banner", ".chat-widget"]
```

Run:

```bash
visualcheck run --env qa
```

## Baseline rules (locked)

For each snapshot+view:
1) If a **Figma baseline** exists: use it
2) Else if a **runtime baseline** exists: use it
3) Else: capture and **create baseline** (INFO: `BASELINE_CREATED`)

Baselines live at repo root:

- `visual_baseline/<project>/<suite>/figma/...`
- `visual_baseline/<project>/<suite>/runtime/...`

Run outputs go under:

- `test_report/<project>/visual_runs/<run_id>/...`

## License
MIT
