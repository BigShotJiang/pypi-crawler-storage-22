from __future__ import annotations

import json
from pathlib import Path
from typing import Optional

import typer

app = typer.Typer(add_completion=False, help="visualcheck: visual regression checking (MVP scaffold)")


@app.command()
def run(
    env: str = typer.Option(..., help="Environment key from visualcheck.yaml (e.g. qa/prod)"),
    config: Path = typer.Option(Path("visualcheck.yaml"), help="Path to visualcheck.yaml"),
):
    """Run capture+diff+report. (MVP scaffold)"""
    if not config.exists():
        raise typer.BadParameter(f"Config not found: {config}")

    typer.echo(f"visualcheck v0.1.0 (scaffold)\nconfig={config}\nenv={env}")
    typer.echo("Next: implement capture+baseline+diff+report.")


@app.command("figma-sync")
def figma_sync(
    config: Path = typer.Option(Path("visualcheck.yaml"), help="Path to visualcheck.yaml"),
):
    """Sync Figma frames into figma baseline folder. (planned)"""
    typer.echo("figma sync: planned")


@app.command()
def diff(
    baseline: Path = typer.Option(..., help="Baseline folder"),
    current: Path = typer.Option(..., help="Current screenshots folder"),
    out: Path = typer.Option(Path("report"), help="Output report folder"),
):
    """Diff-only mode. (planned)"""
    typer.echo(json.dumps({"baseline": str(baseline), "current": str(current), "out": str(out)}))
