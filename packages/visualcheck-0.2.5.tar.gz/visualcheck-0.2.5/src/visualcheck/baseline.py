from __future__ import annotations

import shutil
from pathlib import Path
from typing import Optional, Tuple

from .utils import ensure_dir, slug


def baseline_root(cfg: dict) -> Path:
    # baselines live at repo root next to config
    root = Path(cfg["__root__"])
    return root / "visual_baseline" / cfg["project"] / cfg["suite"]


def run_root(cfg: dict, run_id: str) -> Path:
    root = Path(cfg["__root__"])
    return root / "test_report" / cfg["project"] / "visual_runs" / run_id


def baseline_path(cfg: dict, kind: str, view_id: str, snapshot_id: str) -> Path:
    return baseline_root(cfg) / kind / slug(view_id) / f"{slug(snapshot_id)}.png"


def resolve_baseline(cfg: dict, view_id: str, snapshot_id: str) -> Tuple[Optional[Path], str]:
    """Return (path, kind). kind is figma/runtime/none.

    If a figma baseline is configured but not present on disk, attempt a sync
    from the Figma API (if configured) and re-check. This allows workflows where
    the authoritative baseline lives in Figma and should be used before creating
    a runtime baseline.
    """
    for kind in cfg["baseline"]["priority"]:
        p = baseline_path(cfg, kind, view_id, snapshot_id)
        if p.exists():
            # If figma baseline exists, make it the authoritative runtime baseline
            if kind == "figma":
                try:
                    runtime_p = baseline_path(cfg, "runtime", view_id, snapshot_id)
                    ensure_dir(runtime_p.parent)
                    # overwrite runtime baseline with figma baseline so Figma is authoritative
                    shutil.copy2(p, runtime_p)
                    return runtime_p, "figma"
                except Exception:
                    # If copying fails, return the figma path
                    return p, "figma"
            return p, kind

    # If figma is configured as a priority and missing locally, try to fetch it
    if "figma" in (cfg["baseline"]["priority"] or []):
        try:
            summary = figma_sync_baselines(cfg)  # best-effort
            # after sync, re-check for figma baseline
            p = baseline_path(cfg, "figma", view_id, snapshot_id)
            if p.exists():
                try:
                    runtime_p = baseline_path(cfg, "runtime", view_id, snapshot_id)
                    ensure_dir(runtime_p.parent)
                    shutil.copy2(p, runtime_p)
                    return runtime_p, "figma"
                except Exception:
                    return p, "figma"
        except Exception:
            # never fail; always fall through to runtime/none
            pass

    return None, "none"


def ensure_runtime_baseline(
    cfg: dict,
    view_id: str,
    snapshot_id: str,
    current_png: Path,
) -> Tuple[Optional[Path], str]:
    """Create runtime baseline if missing and allowed. Never overwrites."""
    p = baseline_path(cfg, "runtime", view_id, snapshot_id)
    if p.exists():
        return p, "runtime"

    if not cfg["baseline"].get("create_if_missing", False):
        return None, "none"

    ensure_dir(p.parent)
    shutil.copy2(current_png, p)
    return p, "runtime_created"


def approve_current_as_runtime(cfg: dict, env: str, run_id: str, force: bool = False) -> dict:
    rr = run_root(cfg, run_id)
    current_dir = rr / "current"
    if not current_dir.exists():
        raise FileNotFoundError(f"Current screenshots not found: {current_dir}")

    copied = []
    skipped = []

    for png in current_dir.rglob("*.png"):
        rel = png.relative_to(current_dir)
        # rel: view_id/snapshot_id.png
        parts = rel.parts
        if len(parts) < 2:
            continue
        view_id = parts[0]
        snapshot_id = Path(parts[-1]).stem
        dest = baseline_path(cfg, "runtime", view_id, snapshot_id)
        ensure_dir(dest.parent)
        if dest.exists() and not force:
            skipped.append({"dest": str(dest), "reason": "exists (use --force)"})
            continue
        shutil.copy2(png, dest)
        copied.append({"src": str(png), "dest": str(dest)})

    return {"env": env, "run_id": run_id, "copied": copied, "skipped": skipped}
