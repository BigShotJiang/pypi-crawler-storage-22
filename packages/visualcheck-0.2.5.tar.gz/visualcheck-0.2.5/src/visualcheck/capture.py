from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Dict, List, Optional, Tuple

from PIL import Image, ImageDraw
from playwright.sync_api import Browser, Page, sync_playwright

from .utils import ensure_dir, slug
from .views import resolve_view_configs


def _collect_ignore_regions(cfg: dict, snapshot_id: str, local: Optional[dict]) -> dict:
    ignore = {"selectors": [], "rects": []}

    global_block = (cfg.get("ignore_regions") or {}).get("global") or {}
    by_snapshot = (cfg.get("ignore_regions") or {}).get("by_snapshot") or {}
    snap_block = by_snapshot.get(snapshot_id) or {}

    for block in [global_block, snap_block, local or {}]:
        ignore["selectors"].extend(block.get("selectors") or [])
        ignore["rects"].extend(block.get("rects") or [])

    # de-dupe selectors
    ignore["selectors"] = list(dict.fromkeys(ignore["selectors"]))
    return ignore


def _mask_png(png_path: Path, rects: List[Tuple[float, float, float, float]]) -> None:
    if not rects:
        return
    img = Image.open(png_path).convert("RGBA")
    draw = ImageDraw.Draw(img)
    for x, y, w, h in rects:
        draw.rectangle([x, y, x + w, y + h], fill=(255, 0, 255, 255))
    img.save(png_path)


def _rects_from_selectors(page: Page, selectors: List[str]) -> List[Tuple[float, float, float, float]]:
    rects: List[Tuple[float, float, float, float]] = []
    for sel in selectors:
        try:
            # query_selector_all is usually faster/less blocking than locator.count on heavy pages
            els = page.query_selector_all(sel)
            for el in els[:10]:
                bb = el.bounding_box()
                if bb:
                    rects.append((bb["x"], bb["y"], bb["width"], bb["height"]))
        except Exception:
            # ignore selector failures (dynamic pages)
            continue
    return rects


def _mask_from_ignore(page: Page, png_path: Path, ignore: dict) -> None:
    rects: List[Tuple[float, float, float, float]] = []
    rects.extend(_rects_from_selectors(page, ignore.get("selectors") or []))
    for r in ignore.get("rects") or []:
        rects.append((r["x"], r["y"], r["width"], r["height"]))
    _mask_png(png_path, rects)


def _abs_url(base: str, url: str) -> str:
    if url.startswith("http://") or url.startswith("https://"):
        return url
    return base.rstrip("/") + "/" + url.lstrip("/")


def capture_all(cfg: dict, env: str, out_dir: Path, headed: bool = False, slow_mo_ms: int = 0) -> dict:
    base_url = cfg["envs"].get(env)
    if not base_url:
        raise ValueError(f"Unknown env '{env}'. Known: {sorted(cfg['envs'].keys())}")

    ensure_dir(out_dir)
    manifest: List[dict] = []

    with sync_playwright() as p:
        views = resolve_view_configs(cfg, p.devices)
        browser: Browser = p.chromium.launch(headless=not headed, slow_mo=slow_mo_ms or None)
        try:
            for view_id, context_kwargs in views:
                context = browser.new_context(**context_kwargs)
                page = context.new_page()
                page.set_default_timeout(30000)
                page.set_default_navigation_timeout(45000)

                view_out = ensure_dir(out_dir / slug(view_id))

                # Pages
                for pg in cfg.get("pages", []) or []:
                    snap_id = pg["id"]
                    url = _abs_url(base_url, pg["url"])
                    print(f"[capture] view={view_id} snapshot={snap_id} url={url}")
                    page.goto(url, wait_until="domcontentloaded")
                    # Wait for the configured wait_for selector if present, then allow extra time for lazy loads.
                    if pg.get("wait_for"):
                        page.wait_for_selector(pg["wait_for"], timeout=30000)

                    # Optional additional wait and smart auto-scroll to ensure page fully renders dynamic content
                    extra_wait_ms = int(cfg.get('capture', {}).get('extra_wait_ms', 1000))
                    scroll_times = int(cfg.get('capture', {}).get('scrolls', 5))
                    scroll_delay = int(cfg.get('capture', {}).get('scroll_delay_ms', 700))

                    page.wait_for_timeout(extra_wait_ms)

                    # gentle auto-scroll to trigger lazy-loading images/content
                    try:
                        for i in range(max(1, scroll_times)):
                            page.keyboard.press('PageDown')
                            page.wait_for_timeout(scroll_delay)
                    except Exception:
                        # ignore if page doesn't accept keyboard events
                        try:
                            # fallback to mouse wheel
                            for i in range(max(1, scroll_times)):
                                page.mouse.wheel(0, 800)
                                page.wait_for_timeout(scroll_delay)
                        except Exception:
                            pass

                    full_page = bool(pg.get("full_page", True))
                    png_path = view_out / f"{slug(snap_id)}.png"
                    page.screenshot(path=str(png_path), full_page=full_page)

                    ignore = _collect_ignore_regions(cfg, snap_id, pg.get("ignore_regions"))
                    _mask_from_ignore(page, png_path, ignore)

                    manifest.append(
                        {
                            "type": "page",
                            "snapshot_id": snap_id,
                            "view_id": view_id,
                            "url": url,
                            "png": str(png_path),
                        }
                    )

                # Flows
                for flow in cfg.get("flows", []) or []:
                    flow_id = flow["id"]
                    start = _abs_url(base_url, flow["start_url"])
                    page.goto(start, wait_until="domcontentloaded")
                    page.wait_for_timeout(300)

                    for step in flow.get("steps", []) or []:
                        act = step["action"]
                        if act == "goto":
                            page.goto(_abs_url(base_url, step["url"]), wait_until="domcontentloaded")
                        elif act == "click":
                            page.locator(step["selector"]).click(timeout=30000)
                        elif act == "fill":
                            page.locator(step["selector"]).fill(step.get("text", ""), timeout=30000)
                        elif act == "press":
                            page.keyboard.press(step["key"])
                        elif act == "wait":
                            page.wait_for_timeout(int(step.get("ms", 0)))
                        elif act == "wait_for_selector":
                            page.wait_for_selector(step["selector"], timeout=30000)
                        else:
                            raise ValueError(f"Unknown flow step action: {act}")

                    for snap in flow.get("snapshots", []) or []:
                        snap_id = f"{flow_id}__{snap['id']}"
                        if snap.get("wait_for"):
                            page.wait_for_selector(snap["wait_for"], timeout=30000)
                        page.wait_for_timeout(500)
                        full_page = bool(snap.get("full_page", True))
                        png_path = view_out / f"{slug(snap_id)}.png"
                        page.screenshot(path=str(png_path), full_page=full_page)

                        ignore = _collect_ignore_regions(cfg, snap_id, snap.get("ignore_regions"))
                        _mask_from_ignore(page, png_path, ignore)

                        manifest.append(
                            {
                                "type": "flow",
                                "flow_id": flow_id,
                                "snapshot_id": snap_id,
                                "view_id": view_id,
                                "url": page.url,
                                "png": str(png_path),
                            }
                        )

                context.close()
        finally:
            browser.close()

    return {"env": env, "base_url": base_url, "out_dir": str(out_dir), "manifest": manifest}
