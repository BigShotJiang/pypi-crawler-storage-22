from __future__ import annotations

import json
from pathlib import Path
from typing import Optional

import typer
from rich.console import Console
from rich.table import Table

from .config import load_config
from .figma import figma_sync_baselines
from .runner import run_visualcheck
from .diff_engine import diff_folders
from .baseline import approve_current_as_runtime

app = typer.Typer(add_completion=False, help="visualcheck: visual regression checking")
console = Console()


@app.command()
def run(
    env: str = typer.Option(..., help="Environment key from visualcheck.yaml (e.g. qa/prod)"),
    config: Path = typer.Option(Path("visualcheck.yaml"), help="Path to visualcheck.yaml"),
    run_id: Optional[str] = typer.Option(None, help="Override run id (default: timestamp)"),
    headed: bool = typer.Option(False, help="Run browser headed"),
    slow_mo_ms: int = typer.Option(0, help="Slow motion in ms for Playwright actions"),
    workers: int = typer.Option(1, help="Parallel workers for capture (1 recommended for stability)"),
):
    """Capture + baseline resolve + diff + HTML report."""
    cfg = load_config(config)
    result = run_visualcheck(cfg, env=env, run_id=run_id, headed=headed, slow_mo_ms=slow_mo_ms, workers=workers)

    table = Table(title=f"visualcheck results ({result['status']})")
    table.add_column("id")
    table.add_column("view")
    table.add_column("status")
    table.add_column("pixel_diff_%", justify="right")
    table.add_column("ssim", justify="right")

    for r in result["results"]:
        table.add_row(
            r["snapshot_id"],
            r["view_id"],
            r["status"],
            f"{r.get('pixel_diff_pct', 0):.4f}",
            f"{r.get('ssim', 0):.6f}",
        )

    console.print(table)
    console.print(f"Report: {result['report_html']}")


@app.command()
def capture(
    env: str = typer.Option(..., help="Environment key from visualcheck.yaml"),
    config: Path = typer.Option(Path("visualcheck.yaml"), help="Path to visualcheck.yaml"),
    out: Path = typer.Option(Path("current"), help="Output folder for screenshots"),
    headed: bool = typer.Option(False, help="Run browser headed"),
    slow_mo_ms: int = typer.Option(0, help="Slow motion in ms for Playwright actions"),
):
    """Capture-only mode (no baseline/diff/report)."""
    cfg = load_config(config)
    result = run_visualcheck(
        cfg,
        env=env,
        run_id="capture_only",
        headed=headed,
        slow_mo_ms=slow_mo_ms,
        workers=1,
        capture_only=True,
        capture_out=out,
    )
    console.print(json.dumps(result, indent=2))


@app.command("figma-sync")
def figma_sync(
    config: Path = typer.Option(Path("visualcheck.yaml"), help="Path to visualcheck.yaml"),
):
    """Sync Figma frames into figma baseline folder."""
    cfg = load_config(config)
    summary = figma_sync_baselines(cfg)
    console.print(json.dumps(summary, indent=2))


@app.command()
def diff(
    baseline: Path = typer.Option(..., help="Baseline folder (pngs, nested ok)"),
    current: Path = typer.Option(..., help="Current screenshots folder (pngs, nested ok)"),
    out: Path = typer.Option(Path("report"), help="Output report folder"),
    max_pixel_diff_pct: float = typer.Option(0.10, help="Max allowed pixel diff percent"),
    min_ssim: float = typer.Option(0.995, help="Min allowed SSIM"),
    resize_on_mismatch: bool = typer.Option(True, help="Resize current to baseline size when different"),
    mismatch_level: str = typer.Option("WARN", help="WARN or FAIL"),
):
    """Diff-only mode across two folders."""
    out.mkdir(parents=True, exist_ok=True)
    result = diff_folders(
        baseline_dir=baseline,
        current_dir=current,
        out_dir=out,
        thresholds={"max_pixel_diff_pct": max_pixel_diff_pct, "min_ssim": min_ssim},
        resize_on_mismatch=resize_on_mismatch,
        mismatch_level=mismatch_level,
    )
    console.print(json.dumps(result, indent=2))


@app.command()
def approve(
    env: str = typer.Option(..., help="Environment key from visualcheck.yaml"),
    config: Path = typer.Option(Path("visualcheck.yaml"), help="Path to visualcheck.yaml"),
    run_id: str = typer.Option(..., help="Run id that produced current screenshots"),
    force: bool = typer.Option(False, help="Overwrite existing runtime baselines"),
):
    """Promote a run's current screenshots to runtime baselines (explicit action)."""
    cfg = load_config(config)
    summary = approve_current_as_runtime(cfg, env=env, run_id=run_id, force=force)
    console.print(json.dumps(summary, indent=2))
