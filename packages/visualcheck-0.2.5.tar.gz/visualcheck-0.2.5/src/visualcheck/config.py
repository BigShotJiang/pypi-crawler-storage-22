from __future__ import annotations

import os
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict

import yaml
from jsonschema import Draft202012Validator


class ConfigError(ValueError):
    pass


def _load_schema() -> dict:
    schema_path = Path(__file__).parent / "schemas" / "visualcheck.schema.json"
    return yaml.safe_load(schema_path.read_text()) if schema_path.suffix in {".yaml", ".yml"} else __import__("json").loads(schema_path.read_text())


def validate_config(data: dict) -> None:
    schema = _load_schema()
    validator = Draft202012Validator(schema)
    errors = sorted(validator.iter_errors(data), key=lambda e: e.path)
    if errors:
        msg = "\n".join([f"- {list(e.path)}: {e.message}" for e in errors])
        raise ConfigError(f"Invalid visualcheck config:\n{msg}")


def _expand_envs(data: dict) -> dict:
    # allow ${VAR} expansion in env URLs
    envs = data.get("envs", {})
    new_envs = {}
    for k, v in envs.items():
        if isinstance(v, str):
            new_envs[k] = os.path.expandvars(v)
        else:
            new_envs[k] = v
    data = dict(data)
    data["envs"] = new_envs
    return data


def load_config(path: Path) -> dict:
    if not path.exists():
        raise ConfigError(f"Config not found: {path}")
    data = yaml.safe_load(path.read_text()) or {}
    if not isinstance(data, dict):
        raise ConfigError("Config root must be a mapping/object")
    data = _expand_envs(data)
    # defaults
    data.setdefault("flows", [])
    data.setdefault("ignore_regions", {})
    validate_config(data)
    data["__path__"] = str(path)
    data["__root__"] = str(path.parent.resolve())
    return data
