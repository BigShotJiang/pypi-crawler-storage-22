from __future__ import annotations

import json
from pathlib import Path
from typing import Dict, Optional, Tuple

import cv2
import numpy as np
from PIL import Image
from skimage.metrics import structural_similarity as ssim

from .utils import ensure_dir, iter_pngs


def _load_rgb(p: Path) -> np.ndarray:
    img = Image.open(p).convert("RGB")
    return np.array(img)


def _resize_to(img: np.ndarray, size_wh: Tuple[int, int]) -> np.ndarray:
    w, h = size_wh
    return cv2.resize(img, (w, h), interpolation=cv2.INTER_AREA)


def diff_images(
    baseline_png: Path,
    current_png: Path,
    diff_png: Path,
    resize_on_mismatch: bool,
) -> dict:
    b = _load_rgb(baseline_png)
    c = _load_rgb(current_png)

    warn = []
    if b.shape != c.shape:
        if resize_on_mismatch:
            warn.append(f"SIZE_MISMATCH_RESIZED baseline={b.shape} current={c.shape}")
            c = _resize_to(c, (b.shape[1], b.shape[0]))
        else:
            warn.append(f"SIZE_MISMATCH baseline={b.shape} current={c.shape}")

    # compute pixel diff %
    diff = cv2.absdiff(b, c)
    diff_gray = cv2.cvtColor(diff, cv2.COLOR_RGB2GRAY)
    # consider pixel different if any channel differs by >0
    diff_mask = diff_gray > 0
    diff_pixels = int(np.count_nonzero(diff_mask))
    total_pixels = int(diff_mask.size)
    pixel_diff_pct = (diff_pixels / total_pixels) * 100.0 if total_pixels else 0.0

    # SSIM on grayscale
    b_gray = cv2.cvtColor(b, cv2.COLOR_RGB2GRAY)
    c_gray = cv2.cvtColor(c, cv2.COLOR_RGB2GRAY)
    ssim_val = float(ssim(b_gray, c_gray, data_range=255))

    # diff heatmap
    heat = cv2.normalize(diff_gray, None, 0, 255, cv2.NORM_MINMAX)
    heat = cv2.applyColorMap(heat.astype(np.uint8), cv2.COLORMAP_JET)
    overlay = cv2.addWeighted(c[:, :, ::-1], 0.65, heat, 0.35, 0)  # BGR
    ensure_dir(diff_png.parent)
    cv2.imwrite(str(diff_png), overlay)

    return {
        "pixel_diff_pct": pixel_diff_pct,
        "ssim": ssim_val,
        "warnings": warn,
    }


def diff_folders(
    baseline_dir: Path,
    current_dir: Path,
    out_dir: Path,
    thresholds: Dict[str, float],
    resize_on_mismatch: bool,
    mismatch_level: str,
) -> dict:
    ensure_dir(out_dir)
    results = []

    base_pngs = list(iter_pngs(baseline_dir))
    base_index = {p.relative_to(baseline_dir).as_posix(): p for p in base_pngs}

    for cur in iter_pngs(current_dir):
        rel = cur.relative_to(current_dir).as_posix()
        base = base_index.get(rel)
        if not base:
            results.append({"rel": rel, "status": "NO_BASELINE", "current": str(cur)})
            continue

        diff_png = out_dir / "diff" / rel
        metrics = diff_images(base, cur, diff_png, resize_on_mismatch=resize_on_mismatch)

        mismatch = (metrics["pixel_diff_pct"] > thresholds["max_pixel_diff_pct"]) or (
            metrics["ssim"] < thresholds["min_ssim"]
        )
        status = "PASS"
        if mismatch:
            status = mismatch_level

        results.append(
            {
                "rel": rel,
                "status": status,
                "baseline": str(base),
                "current": str(cur),
                "diff": str(diff_png),
                **metrics,
            }
        )

    report_json = out_dir / "report.json"
    out = {
        "baseline_dir": str(baseline_dir),
        "current_dir": str(current_dir),
        "out_dir": str(out_dir),
        "thresholds": thresholds,
        "resize_on_mismatch": resize_on_mismatch,
        "mismatch_level": mismatch_level,
        "results": results,
    }
    report_json.write_text(json.dumps(out, indent=2))
    return out
