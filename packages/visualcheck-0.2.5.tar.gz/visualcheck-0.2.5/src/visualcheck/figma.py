from __future__ import annotations

import os
from pathlib import Path
from typing import Dict, List, Optional

import requests

from .baseline import baseline_path
from .utils import ensure_dir, slug


class FigmaError(RuntimeError):
    pass


from decouple import config

def _get_token(cfg: dict) -> Optional[str]:
    fig = cfg.get("figma") or {}
    token_env = fig.get("token_env") or "FIGMA_TOKEN"
    # Prefer .env (python-decouple); fall back to common host env var OPENCLAW_FIGMA_TOKEN
    # and then to the direct environment variable if present.
    return config(token_env, default=os.environ.get('OPENCLAW_FIGMA_TOKEN') or os.environ.get(token_env))


def _figma_headers(token: str) -> dict:
    return {"X-Figma-Token": token}


def figma_sync_baselines(cfg: dict) -> dict:
    """Download configured Figma frame node_ids as PNG into figma baseline folder.

    Config:
      figma:
        token_env: FIGMA_TOKEN
        file_key: abcd...
        frames:
          - id: home
            node_id: 123:456
            view_id: desktop_1440x900   # optional

    If view_id is omitted, baseline is written under a special 'figma' view folder of that frame for all views.
    """

    fig = cfg.get("figma") or {}
    if not fig:
        return {"status": "SKIPPED", "reason": "figma section not configured"}

    token = _get_token(cfg)
    if not token:
        return {"status": "SKIPPED", "reason": "Figma token not found in env"}

    file_key = fig.get("file_key")
    frames = fig.get("frames") or []
    if not file_key or not frames:
        return {"status": "SKIPPED", "reason": "figma.file_key or figma.frames missing"}

    downloaded = []
    skipped = []

    for fr in frames:
        snap_id = fr["id"]
        node_id = fr["node_id"]
        view_id = fr.get("view_id") or "figma"

        # request image URL
        url = f"https://api.figma.com/v1/images/{file_key}?ids={node_id}&format=png&scale=1"
        r = requests.get(url, headers=_figma_headers(token), timeout=30)
        if r.status_code != 200:
            skipped.append({"id": snap_id, "node_id": node_id, "reason": f"figma images api {r.status_code}"})
            continue
        data = r.json()
        img_url = (data.get("images") or {}).get(node_id)
        if not img_url:
            skipped.append({"id": snap_id, "node_id": node_id, "reason": "no image url"})
            continue

        ir = requests.get(img_url, timeout=60)
        if ir.status_code != 200:
            skipped.append({"id": snap_id, "node_id": node_id, "reason": f"download {ir.status_code}"})
            continue

        dest = baseline_path(cfg, "figma", view_id, snap_id)
        ensure_dir(dest.parent)
        if dest.exists():
            skipped.append({"id": snap_id, "dest": str(dest), "reason": "exists"})
            continue
        dest.write_bytes(ir.content)
        downloaded.append({"id": snap_id, "dest": str(dest)})

    return {"status": "OK", "downloaded": downloaded, "skipped": skipped}
