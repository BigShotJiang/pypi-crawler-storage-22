from __future__ import annotations

import json
from pathlib import Path
from typing import List

from jinja2 import Environment, FileSystemLoader, select_autoescape

from .utils import ensure_dir


def _env() -> Environment:
    tpl_dir = Path(__file__).parent / "templates"
    return Environment(
        loader=FileSystemLoader(str(tpl_dir)),
        autoescape=select_autoescape(["html"]),
    )


def write_report(out_dir: Path, report: dict) -> dict:
    ensure_dir(out_dir)
    (out_dir / "report.json").write_text(json.dumps(report, indent=2))

    env = _env()
    tpl = env.get_template("report.html")

    html = tpl.render(**report)
    html_path = out_dir / "report.html"
    html_path.write_text(html, encoding="utf-8")
    return {"report_json": str(out_dir / "report.json"), "report_html": str(html_path)}
