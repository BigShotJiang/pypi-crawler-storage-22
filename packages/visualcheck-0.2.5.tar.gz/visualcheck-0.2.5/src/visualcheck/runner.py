from __future__ import annotations

import datetime as dt
import shutil
from pathlib import Path
from typing import Optional

from rich.console import Console

from .baseline import ensure_runtime_baseline, resolve_baseline, run_root
from .capture import capture_all
from .diff_engine import diff_images
from .report import write_report
from .utils import ensure_dir, now_run_id, slug

console = Console()


def run_visualcheck(
    cfg: dict,
    env: str,
    run_id: Optional[str] = None,
    headed: bool = False,
    slow_mo_ms: int = 0,
    workers: int = 1,
    capture_only: bool = False,
    capture_out: Optional[Path] = None,
) -> dict:
    run_id = run_id or now_run_id()
    rr = run_root(cfg, run_id)
    ensure_dir(rr)

    current_dir = capture_out if capture_only and capture_out else rr / "current"
    ensure_dir(current_dir)

    cap = capture_all(cfg, env=env, out_dir=current_dir, headed=headed, slow_mo_ms=slow_mo_ms)
    if capture_only:
        return {"status": "CAPTURED", "run_id": run_id, **cap}

    thresholds = cfg["compare"]["thresholds"]
    resize_on_mismatch = bool(cfg["compare"].get("resize_on_mismatch", True))
    mismatch_level = cfg["compare"].get("mismatch_level", "WARN")

    diff_dir = rr / "diff"
    ensure_dir(diff_dir)

    results = []
    overall = "PASS"

    # For each captured png in manifest, resolve baseline and diff.
    for item in cap["manifest"]:
        snapshot_id = item["snapshot_id"]
        view_id = item["view_id"]
        current_png = Path(item["png"])

        baseline_png, baseline_kind = resolve_baseline(cfg, view_id, snapshot_id)
        created = False
        if baseline_png is None:
            baseline_png, kind2 = ensure_runtime_baseline(cfg, view_id, snapshot_id, current_png)
            if kind2 == "runtime_created":
                created = True
                baseline_kind = "runtime_created"

        if baseline_png is None:
            status = "NO_BASELINE"
            results.append(
                {
                    "snapshot_id": snapshot_id,
                    "view_id": view_id,
                    "status": status,
                    "baseline_kind": "none",
                    "baseline": None,
                    "current": str(current_png),
                    "diff": None,
                    "pixel_diff_pct": None,
                    "ssim": None,
                    "warnings": ["BASELINE_MISSING"],
                }
            )
            overall = "FAIL" if overall != "FAIL" else overall
            continue

        diff_png = diff_dir / slug(view_id) / f"{slug(snapshot_id)}.png"
        metrics = diff_images(
            baseline_png=baseline_png,
            current_png=current_png,
            diff_png=diff_png,
            resize_on_mismatch=resize_on_mismatch,
        )

        mismatch = (metrics["pixel_diff_pct"] > thresholds["max_pixel_diff_pct"]) or (
            metrics["ssim"] < thresholds["min_ssim"]
        )
        status = "PASS"
        if mismatch:
            status = mismatch_level
        if created:
            # baseline created => INFO/WARN/FAIL as configured
            created_level = cfg["baseline"].get("on_created", "INFO")
            metrics["warnings"].append("BASELINE_CREATED")
            if created_level == "WARN" and status == "PASS":
                status = "WARN"
            if created_level == "FAIL":
                status = "FAIL"

        if status == "FAIL":
            overall = "FAIL"
        elif status == "WARN" and overall == "PASS":
            overall = "WARN"

        results.append(
            {
                "snapshot_id": snapshot_id,
                "view_id": view_id,
                "status": status,
                "baseline_kind": baseline_kind,
                "baseline": str(baseline_png),
                "current": str(current_png),
                "diff": str(diff_png),
                **metrics,
            }
        )

    # Copy images into report folder to keep HTML self-contained
    report_dir = rr / "report"
    assets_dir = ensure_dir(report_dir / "assets")

    for r in results:
        # current always exists
        cur_src = Path(r["current"])
        cur_rel = Path("assets") / "current" / slug(r["view_id"]) / f"{slug(r['snapshot_id'])}.png"
        ensure_dir((report_dir / cur_rel).parent)
        shutil.copy2(cur_src, report_dir / cur_rel)
        r["current_rel"] = cur_rel.as_posix()

        if r.get("baseline"):
            base_src = Path(r["baseline"])
            base_rel = Path("assets") / "baseline" / slug(r["view_id"]) / f"{slug(r['snapshot_id'])}.png"
            ensure_dir((report_dir / base_rel).parent)
            shutil.copy2(base_src, report_dir / base_rel)
            r["baseline_rel"] = base_rel.as_posix()
        else:
            r["baseline_rel"] = None

        if r.get("diff"):
            diff_src = Path(r["diff"])
            diff_rel = Path("assets") / "diff" / slug(r["view_id"]) / f"{slug(r['snapshot_id'])}.png"
            ensure_dir((report_dir / diff_rel).parent)
            shutil.copy2(diff_src, report_dir / diff_rel)
            r["diff_rel"] = diff_rel.as_posix()
        else:
            r["diff_rel"] = None

    report = {
        "project": cfg["project"],
        "suite": cfg["suite"],
        "env": env,
        "run_id": run_id,
        "generated_at": dt.datetime.now().isoformat(timespec="seconds"),
        "status": overall,
        "config": cfg.get("__path__"),
        "thresholds": thresholds,
        "results": results,
    }

    paths = write_report(report_dir, report)
    report.update(paths)
    return report
