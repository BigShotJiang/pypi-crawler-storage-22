from typing import List, Type, Tuple
import logging

import requests
from ai_haley_kg_domain.model.KGInteraction import KGInteraction
from typing_extensions import TypedDict
from vital_ai_vitalsigns.query.part_list import PartList
from vital_ai_vitalsigns.query.result_list import ResultList
from vital_ai_vitalsigns.service.vital_namespace import VitalNamespace
from vital_ai_vitalsigns.service.vital_service_status import VitalServiceStatus

from vital_agent_kg_utils.vital_agent_rest_resource_client.tool_service_interface import ToolServiceInterface
from vital_agent_kg_utils.vital_agent_rest_resource_client.tools.place_search.tool_handler import \
    PlaceSearchToolHandler
from vital_agent_kg_utils.vital_agent_rest_resource_client.tools.tool_parameters import ToolParameters
from vital_agent_kg_utils.vital_agent_rest_resource_client.tools.tool_request import ToolRequest
from vital_agent_kg_utils.vital_agent_rest_resource_client.tools.tool_response import ToolResponse
from vital_agent_kg_utils.vital_agent_rest_resource_client.tools.tool_results import ToolResults
from vital_agent_kg_utils.vital_agent_rest_resource_client.tools.weather.models import WeatherOutput, WeatherData
from vital_agent_kg_utils.vital_agent_rest_resource_client.tools.weather.tool_handler import WeatherToolHandler
from vital_agent_kg_utils.vital_agent_rest_resource_client.tools.web_search.tool_handler import WebSearchToolHandler


# client to the python webservice which provides access to tools


class VitalAgentRestResourceClient(ToolServiceInterface):

    def __init__(self, config:dict, jwt_token: str = None):
        self.config = config
        self.jwt_token = jwt_token
        self.logger = logging.getLogger(__name__)

    # Tools

    def handle_tool_request(self, tool_name: str, tool_parameters: ToolParameters) -> ToolResponse:

        # TODO
        # check tool_name to determine validation and handler

        tool_request = ToolRequest(
            tool=tool_name,
            tool_input=tool_parameters
        )

        tool_endpoint = self.config.get("tool_endpoint")

        # url = "http://localhost:8008/tool"
        # url = "http://internal-vital-agent-resource-rest-lb-1305845817.us-east-1.elb.amazonaws.com:8008/tool"
        # url = "http://vital-agent-resource-rest-lb.apichatai.com:8008/tool"

        url = f"{tool_endpoint}/tool"
       
        tool_request_dict = tool_request.to_dict()

        # Prepare headers
        headers = {"Content-Type": "application/json"}
        if self.jwt_token:
            headers["Authorization"] = f"Bearer {self.jwt_token}"

        response = requests.post(url, json=tool_request_dict, headers=headers)

        self.logger.info(f"Tool request to {url} - Status Code: {response.status_code}")
        
        response_json = response.json()
        self.logger.debug(f"Response JSON: {response_json}")

        if tool_name == "weather_tool":
            handler = WeatherToolHandler()
            weather_results = handler.handle_response(tool_parameters, response_json)
            tool_response = ToolResponse.create_success(
                tool_output=weather_results,
                duration_ms=0  # Could extract from response_json if available
            )
            return tool_response

        if tool_name == "place_search_tool":
            handler = PlaceSearchToolHandler()
            place_search_results = handler.handle_response(tool_parameters, response_json)
            tool_response = ToolResponse.create_success(
                tool_output=place_search_results,
                duration_ms=0  # Could extract from response_json if available
            )
            return tool_response

        if tool_name == "google_address_validation_tool":
            from vital_agent_kg_utils.vital_agent_rest_resource_client.tools.google_address_validation.tool_handler import AddressValidationToolHandler
            handler = AddressValidationToolHandler()
            address_validation_results = handler.handle_response(tool_parameters, response_json)
            tool_response = ToolResponse.create_success(
                tool_output=address_validation_results,
                duration_ms=0  # Could extract from response_json if available
            )
            return tool_response

        if tool_name == "google_web_search_tool":
            handler = WebSearchToolHandler()
            web_search_results = handler.handle_response(tool_parameters, response_json)
            tool_response = ToolResponse.create_success(
                tool_output=web_search_results,
                duration_ms=0  # Could extract from response_json if available
            )
            return tool_response

        # unknown tool
        tool_results = ToolResults()

        tool_response = ToolResponse(
            tool_name=tool_name,
            tool_parameters=tool_parameters,
            tool_results=tool_results
        )

        return tool_response

    