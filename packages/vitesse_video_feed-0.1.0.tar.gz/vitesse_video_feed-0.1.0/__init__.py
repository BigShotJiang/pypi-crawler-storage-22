"""
Vitesse Video Feed - Stream video feeds to a Vitesse Gateway.

This library provides a simple interface for streaming video feeds to a
Vitesse video engine with WebRTC, handling all the complexity of connection
management, codec negotiation, and transport lifecycle.

Quick Start::

    from vitesse_video_feed import VideoFeedClient, VideoFeedConfig, CameraInfo

    config = VideoFeedConfig(gateway_url="192.168.1.100", use_https=True)
    client = VideoFeedClient(client_id="my-app", config=config)

    await client.connect()
    await client.add_camera("cam-1", my_camera_source)

Classes:
    VideoFeedClient: Main client for connecting and streaming video.
    VideoFeedConfig: Configuration for connection settings.
    CameraSource: Protocol defining the camera source interface.
    CameraInfo: Metadata about a camera feed (name, resolution, etc.).
    CameraSourceAdapter: Adapter for wrapping existing camera implementations.
    FeedClientCallbacks: Callback interface for connection/camera events.
"""

from typing import TYPE_CHECKING

from .interfaces import (
    CameraSource as CameraSource,
    CameraInfo as CameraInfo,
    CameraSourceAdapter as CameraSourceAdapter,
    FeedClientCallbacks as FeedClientCallbacks,
    NoOpCallbacks as NoOpCallbacks,
)
from .client import VideoFeedClient as VideoFeedClient
from .video_track import VideoTrack as VideoTrack
from .config import VideoFeedConfig as VideoFeedConfig

__version__ = "0.1.0"
__all__ = [
    "VideoFeedClient",
    "VideoFeedConfig",
    "CameraSource",
    "CameraInfo",
    "CameraSourceAdapter",
    "FeedClientCallbacks",
    "NoOpCallbacks",
    "VideoTrack",
]
