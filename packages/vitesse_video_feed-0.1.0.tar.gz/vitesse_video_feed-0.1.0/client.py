"""
Video Feed Client for streaming to Vitesse Gateway.
"""

import asyncio
import atexit
import signal
import ssl
import threading
import logging
import weakref
from typing import Dict, Optional, Any
from concurrent.futures import ThreadPoolExecutor

try:
    from pymediasoup import Device
    from pymediasoup.transport import Transport
    from pymediasoup.producer import Producer
    from pymediasoup import AiortcHandler
    from aiortc import VideoStreamTrack
    import aiohttp
    _DEPS_AVAILABLE = True
except ImportError:
    _DEPS_AVAILABLE = False
    Device = None
    Transport = None
    Producer = None

try:
    import orjson
    def _json_dumps(obj):
        return orjson.dumps(obj).decode('utf-8')
    def _json_loads(s):
        return orjson.loads(s)
except ImportError:
    import json
    _json_dumps = json.dumps
    _json_loads = json.loads

from .interfaces import CameraSource, CameraInfo, FeedClientCallbacks, NoOpCallbacks
from .video_track import VideoTrack, create_video_track
from .config import VideoFeedConfig


logger = logging.getLogger("vitesse_video_feed")

# Registry of active clients for cleanup on exit
_active_clients: weakref.WeakSet = weakref.WeakSet()
_cleanup_registered = False
_original_sigint = None
_original_sigterm = None


def _cleanup_all_clients():
    """Clean up all active clients on process exit."""
    for client in list(_active_clients):
        try:
            client._sync_cleanup()
        except Exception as e:
            logger.debug(f"Error during exit cleanup: {e}")


def _signal_handler(signum, frame):
    """Handle termination signals by cleaning up clients."""
    logger.info(f"Received signal {signum}, cleaning up...")
    _cleanup_all_clients()

    # Call original handler if it exists
    if signum == signal.SIGINT and _original_sigint:
        if callable(_original_sigint):
            _original_sigint(signum, frame)
        elif _original_sigint == signal.SIG_DFL:
            raise KeyboardInterrupt
    elif signum == signal.SIGTERM and _original_sigterm:
        if callable(_original_sigterm):
            _original_sigterm(signum, frame)


def _register_cleanup():
    """Register cleanup handlers (called once)."""
    global _cleanup_registered, _original_sigint, _original_sigterm
    if _cleanup_registered:
        return
    _cleanup_registered = True

    # Register atexit handler
    atexit.register(_cleanup_all_clients)

    # Register signal handlers (save originals to chain)
    try:
        _original_sigint = signal.signal(signal.SIGINT, _signal_handler)
        _original_sigterm = signal.signal(signal.SIGTERM, _signal_handler)
    except (ValueError, OSError):
        # Signal handling not available (e.g., not main thread)
        pass


class VideoFeedClient:
    """Client for streaming video feeds to a Vitesse Gateway.

    This client handles connection management, codec negotiation, transport
    lifecycle, and video streaming via WebRTC. It provides automatic reconnection,
    stale transport recovery, and graceful cleanup.

    Args:
        client_id: Unique identifier for this client connection.
        config: Configuration including gateway URL and connection settings.
        callbacks: Optional callbacks for connection and camera events.

    Attributes:
        connected: Boolean indicating if currently connected to the gateway.
        client_id: The client identifier string.
        config: The VideoFeedConfig instance.

    Note:
        The client automatically registers cleanup handlers for SIGINT, SIGTERM,
        and atexit. Resources will be freed even if ``disconnect()`` is not called.
    """

    def __init__(
        self,
        client_id: str,
        config: VideoFeedConfig,
        callbacks: Optional[FeedClientCallbacks] = None
    ):
        """Initialize the video feed client.

        Args:
            client_id: Unique identifier for this client
            config: Configuration including gateway URL and connection settings
            callbacks: Optional callbacks for client events
        """
        if not _DEPS_AVAILABLE:
            raise ImportError(
                "Required dependencies not available. "
                "Install with: pip install aiortc aiohttp pymediasoup"
            )

        # Configuration
        self.config = config
        self.callbacks = callbacks or NoOpCallbacks()

        # URLs are already normalized by config
        self._primary_url = config.gateway_url
        self._priority_url = config.priority_gateway_url
        self._active_url: Optional[str] = None  # The URL that's actually working

        self.client_id = client_id

        # Internal components
        self._device: Optional[Device] = None
        self._send_transport: Optional[Transport] = None
        self._producers: Dict[str, Producer] = {}

        # Camera management
        self._camera_sources: Dict[str, CameraSource] = {}
        self._camera_tracks: Dict[str, VideoTrack] = {}

        # Connection state
        self._connected = False
        self._connecting = False
        self._stop_reconnect = False

        # Internal events
        self._transport_connected_event: Optional[asyncio.Event] = None
        self._transport_stale = False

        # HTTP session
        self._session: Optional[aiohttp.ClientSession] = None
        self._transport_info: Optional[Dict] = None

        # Thread safety
        self._executor = ThreadPoolExecutor(max_workers=1, thread_name_prefix="VideoFeed")
        self._loop_lock = threading.Lock()
        self._loop_shutdown = threading.Event()
        self._event_loop: Optional[asyncio.AbstractEventLoop] = None

        # Router capabilities cache
        self._router_capabilities: Optional[Dict] = None

        # Register for automatic cleanup on exit
        _active_clients.add(self)
        _register_cleanup()

        logger.debug(f"VideoFeedClient initialized: {client_id}")

    def __del__(self):
        """Destructor - ensure cleanup happens if not already done."""
        try:
            if getattr(self, '_connected', False) or getattr(self, '_connecting', False):
                self._sync_cleanup()
        except Exception:
            pass

    @property
    def connected(self) -> bool:
        """Check if client is connected."""
        return self._connected

    def _get_h264_codec(self) -> Optional[Any]:
        """Get H264 codec from capabilities if available."""
        if not self._device or not self._device.rtpCapabilities:
            return None

        codecs = self._device.rtpCapabilities.codecs or []
        for codec in codecs:
            if hasattr(codec, 'mimeType') and codec.mimeType == "video/H264":
                return codec
        return None

    async def connect(self) -> bool:
        """Connect to the gateway.

        Tries priority_gateway_url first (if configured), then falls back to gateway_url.
        If all URLs fail and reconnect_interval_s > 0, waits and retries the full cycle.

        Returns:
            True if connection successful, False otherwise.
        """
        if self._connected or self._connecting:
            return self._connected

        self._connecting = True
        self._stop_reconnect = False
        reconnect_cycle = 0

        while not self._stop_reconnect:
            reconnect_cycle += 1

            # Check max cycles (0 = infinite)
            if self.config.max_reconnect_cycles > 0 and reconnect_cycle > self.config.max_reconnect_cycles:
                logger.error(f"Max reconnection cycles ({self.config.max_reconnect_cycles}) reached")
                break

            if reconnect_cycle > 1:
                logger.info(f"Reconnection cycle {reconnect_cycle} starting...")

            # Build list of URLs to try: priority first, then primary
            urls_to_try = []
            if self._priority_url:
                urls_to_try.append(("priority", self._priority_url))
            urls_to_try.append(("primary", self._primary_url))

            for url_type, url in urls_to_try:
                if self._stop_reconnect:
                    break

                logger.info(f"Attempting {url_type} gateway: {url}")

                for attempt in range(self.config.retry_attempts):
                    if self._stop_reconnect:
                        break

                    try:
                        if attempt > 0:
                            logger.info(f"Connection attempt {attempt + 1}/{self.config.retry_attempts}")
                            await asyncio.sleep(min(2 ** attempt, self.config.retry_interval_s))

                        # Create HTTP session
                        await self._create_session(url)

                        # Fetch capabilities
                        async with self._session.get(f"{url}/capabilities") as response:
                            capabilities_data = await response.json()
                            self._router_capabilities = capabilities_data.get('routerRtpCapabilities')

                        # Create device
                        handler_factory = AiortcHandler.createFactory()
                        self._device = Device(handlerFactory=handler_factory)
                        await self._device.load(self._router_capabilities)

                        # Set active URL before creating transport (transport needs it)
                        self._active_url = url

                        # Create transport
                        success = await self._create_transport()
                        if not success:
                            raise Exception("Failed to create transport")
                        self._connected = True
                        self._connecting = False
                        self.callbacks.on_connected()

                        logger.info(f"Connected successfully via {url_type} URL: {url}")
                        return True

                    except Exception as e:
                        logger.error(f"Connection attempt {attempt + 1} to {url_type} failed: {e}")
                        if attempt < self.config.retry_attempts - 1:
                            await self._cleanup_partial()

                # Clean up before trying next URL
                await self._cleanup_partial()
                logger.info(f"{url_type} URL failed, trying next...")

            # All URLs exhausted for this cycle
            if self.config.reconnect_interval_s > 0 and not self._stop_reconnect:
                logger.info(f"All gateway URLs exhausted. Retrying in {self.config.reconnect_interval_s}s...")
                await asyncio.sleep(self.config.reconnect_interval_s)
            else:
                # No reconnection configured, give up
                break

        self._connecting = False
        self.callbacks.on_connection_failed("All gateway URLs exhausted")
        await self._cleanup()
        return False

    async def _create_session(self, url: str):
        """Create HTTP session configured for the given URL."""
        if self._session:
            await self._session.close()

        timeout = aiohttp.ClientTimeout(total=30, connect=10, sock_read=20)

        # Use SSL context only for HTTPS URLs
        if url.startswith('https://'):
            ssl_context = ssl.create_default_context()
            ssl_context.check_hostname = False
            ssl_context.verify_mode = ssl.CERT_NONE
            connector = aiohttp.TCPConnector(ssl=ssl_context)
        else:
            # HTTP - explicitly disable SSL for internal container networks
            connector = aiohttp.TCPConnector(ssl=False)

        self._session = aiohttp.ClientSession(timeout=timeout, connector=connector)

    async def _cleanup_partial(self):
        """Clean up partial connection state for retry."""
        try:
            if self._session:
                await self._session.close()
                self._session = None
            self._device = None
            self._send_transport = None
            self._transport_info = None
        except Exception as e:
            logger.debug(f"Error during partial cleanup: {e}")

    def _rewrite_ice_candidates(self, ice_candidates: list) -> list:
        """Rewrite ICE candidate IPs to use the gateway IP we connected to.

        The video engine binds to 0.0.0.0 and returns its container IP in candidates.
        We always rewrite candidates to use the IP we connected with (resolved if DNS).
        This ensures aiortc/aioice can properly establish ICE connectivity.
        """
        if not self._active_url or not ice_candidates:
            return ice_candidates

        try:
            from urllib.parse import urlparse
            import socket

            parsed = urlparse(self._active_url)
            hostname = parsed.hostname

            if not hostname:
                return ice_candidates

            # Resolve hostname to IP if it's a DNS name
            try:
                socket.inet_aton(hostname)
                target_ip = hostname  # Already an IP
            except socket.error:
                # DNS name - resolve it
                try:
                    target_ip = socket.gethostbyname(hostname)
                    logger.debug(f"Resolved DNS '{hostname}' to IP: {target_ip}")
                except socket.gaierror:
                    logger.warning(f"Failed to resolve DNS name '{hostname}', using original candidates")
                    return ice_candidates

            # Rewrite candidates to use the resolved IP
            rewritten = []
            for candidate in ice_candidates:
                if candidate.get('ip') != target_ip:
                    rewritten.append({
                        **candidate,
                        'ip': target_ip,
                        'address': target_ip
                    })
                else:
                    rewritten.append(candidate)

            logger.debug(f"Rewrote ICE candidates to use IP: {target_ip}")
            return rewritten

        except Exception as e:
            logger.warning(f"Failed to rewrite ICE candidates: {e}")
            return ice_candidates

    async def _create_transport(self) -> bool:
        """Create send transport."""
        try:
            self._transport_connected_event = asyncio.Event()

            url = f"{self._active_url}/offer"
            data = {
                "connectionId": self.client_id,
                "connectionType": "vitesse",
                "rtpCapabilities": self._device.rtpCapabilities.dict(exclude_none=True)
            }

            timeout = aiohttp.ClientTimeout(total=10)

            async with self._session.post(url, json=data, timeout=timeout) as response:
                if response.status != 200:
                    error = await response.text()
                    logger.error(f"Failed to create transport: {error}")
                    return False
                self._transport_info = await response.json()

            # Rewrite ICE candidates to use the IP we connected to
            rewritten_candidates = self._rewrite_ice_candidates(
                self._transport_info['iceCandidates']
            )

            self._send_transport = self._device.createSendTransport(
                id=self._transport_info['transportId'],
                iceParameters=self._transport_info['iceParameters'],
                iceCandidates=rewritten_candidates,
                dtlsParameters=self._transport_info['dtlsParameters'],
                sctpParameters=self._transport_info.get('sctpParameters')
            )

            await self._setup_transport_events()
            return True

        except Exception as e:
            logger.error(f"Error creating transport: {e}")
            return False

    async def _setup_transport_events(self):
        """Set up event handlers for transport."""
        transport_connected = False

        @self._send_transport.on("connect")
        async def on_connect(dtls_parameters):
            nonlocal transport_connected
            if transport_connected:
                return

            try:
                url = f"{self._active_url}/connect-transport"
                data = {
                    "transportId": self._send_transport.id,
                    "dtlsParameters": dtls_parameters.dict(exclude_none=True)
                }

                timeout = aiohttp.ClientTimeout(total=10)

                async with self._session.post(url, json=data, timeout=timeout) as response:
                    if response.status != 200:
                        error_text = await response.text()
                        if "already called" in error_text:
                            transport_connected = True
                            self._transport_connected_event.set()
                            return
                        elif "not found" in error_text.lower():
                            self._transport_stale = True
                            return
                        else:
                            raise Exception(f"Transport connection failed: {error_text}")

                transport_connected = True
                self._transport_connected_event.set()

            except Exception as e:
                logger.error(f"Error in connect handler: {e}")
                if "already called" not in str(e):
                    raise

        @self._send_transport.on("transportclose")
        async def on_transport_close():
            logger.warning("Transport closed")
            self._connected = False

        @self._send_transport.on("produce")
        async def on_produce(kind, rtp_parameters, app_data):
            camera_id = app_data.get("cameraId", "unknown")

            # Wait for transport connection
            max_wait = 15.0
            poll_interval = 0.5
            elapsed = 0.0

            while elapsed < max_wait:
                if self._transport_stale:
                    raise Exception(f"Transport stale for {camera_id}")
                try:
                    await asyncio.wait_for(
                        self._transport_connected_event.wait(),
                        timeout=poll_interval
                    )
                    break
                except asyncio.TimeoutError:
                    elapsed += poll_interval
            else:
                raise Exception(f"Timeout waiting for transport for {camera_id}")

            # Get camera info
            camera_info = {}
            if camera_id in self._camera_sources:
                source = self._camera_sources[camera_id]
                camera_info = source.info.to_dict()

            url = f"{self._active_url}/produce"
            data = {
                "transportId": self._send_transport.id,
                "kind": kind,
                "rtpParameters": rtp_parameters.dict(exclude_none=True),
                "cameraId": camera_id,
                "cameraInfo": camera_info
            }

            timeout = aiohttp.ClientTimeout(total=15)

            async with self._session.post(url, json=data, timeout=timeout) as response:
                if response.status != 200:
                    error = await response.text()
                    raise Exception(f"Failed to produce: {error}")
                result = await response.json()
                return result["id"]

    async def add_camera(
        self,
        camera_id: str,
        camera_source: CameraSource,
        target_fps: Optional[int] = None,
        target_resolution: Optional[tuple] = None
    ) -> bool:
        """Add a camera and start streaming.

        Args:
            camera_id: Unique identifier for this camera
            camera_source: CameraSource providing video frames
            target_fps: Optional override for target FPS
            target_resolution: Optional override for target resolution

        Returns:
            True if camera was added successfully.
        """
        if not self._connected or not self._send_transport:
            logger.error(f"Cannot add camera {camera_id} - not connected")
            return False

        try:
            if not self._device.canProduce("video"):
                logger.error(f"Cannot produce video for {camera_id}")
                return False

            # Check for stale transport
            if self._transport_stale:
                success = await self._recreate_transport()
                if not success:
                    self.callbacks.on_camera_add_failed(camera_id, "Transport recreation failed")
                    return False

            # Store camera source
            self._camera_sources[camera_id] = camera_source

            # Create video track
            info = camera_source.info
            track = create_video_track(
                camera_id=camera_id,
                camera_source=camera_source,
                target_fps=target_fps or info.framerate,
                target_resolution=target_resolution or info.resolution
            )
            self._camera_tracks[camera_id] = track

            await asyncio.sleep(0.5)

            # Test the track
            try:
                for _ in range(5):
                    result = await asyncio.wait_for(track.recv(), timeout=0.5)
                    if result:
                        break
                    await asyncio.sleep(0.2)
            except asyncio.TimeoutError:
                pass

            # Get H264 codec if available
            preferred_codec = self._get_h264_codec()

            # Produce the track
            try:
                if preferred_codec:
                    producer = await self._send_transport.produce(
                        track=track,
                        codec=preferred_codec,
                        stopTracks=False,
                        appData={"cameraId": camera_id}
                    )
                else:
                    producer = await self._send_transport.produce(
                        track=track,
                        stopTracks=False,
                        appData={"cameraId": camera_id}
                    )
            except Exception as e:
                if "not found" in str(e).lower() or self._transport_stale:
                    success = await self._recreate_transport()
                    if not success:
                        self.callbacks.on_camera_add_failed(camera_id, "Transport recreation failed")
                        return False

                    if preferred_codec:
                        producer = await self._send_transport.produce(
                            track=track,
                            codec=preferred_codec,
                            stopTracks=False,
                            appData={"cameraId": camera_id}
                        )
                    else:
                        producer = await self._send_transport.produce(
                            track=track,
                            stopTracks=False,
                            appData={"cameraId": camera_id}
                        )
                else:
                    raise

            self._producers[camera_id] = producer

            if producer.paused:
                producer.resume()

            @producer.on("trackended")
            def on_trackended():
                logger.debug(f"Track ended for {camera_id}")

            @producer.on("transportclose")
            def on_transportclose():
                logger.debug(f"Transport closed for {camera_id}")

            @producer.on("close")
            def on_close():
                logger.warning(f"Producer closed for camera: {camera_id}")

            self.callbacks.on_camera_added(camera_id)
            return True

        except Exception as e:
            logger.error(f"Failed to add camera {camera_id}: {e}")
            self.callbacks.on_camera_add_failed(camera_id, str(e))
            return False

    async def remove_camera(self, camera_id: str) -> bool:
        """Remove a camera and stop streaming.

        Args:
            camera_id: ID of the camera to remove

        Returns:
            True if camera was removed successfully.
        """
        try:
            producer_id = None

            if camera_id in self._producers:
                producer_id = self._producers[camera_id].id

            # Stop track
            if camera_id in self._camera_tracks:
                track = self._camera_tracks[camera_id]
                track.cleanup()
                del self._camera_tracks[camera_id]

            # Close producer
            if camera_id in self._producers:
                producer = self._producers[camera_id]
                await producer.close()
                del self._producers[camera_id]

            # Remove source
            if camera_id in self._camera_sources:
                del self._camera_sources[camera_id]

            # Notify gateway
            if producer_id and self._session:
                try:
                    url = f"{self._active_url}/remove-producer"
                    data = {"producerId": producer_id}
                    timeout = aiohttp.ClientTimeout(total=5)
                    async with self._session.post(url, json=data, timeout=timeout) as response:
                        pass
                except Exception as e:
                    logger.debug(f"Error notifying producer removal: {e}")

            self.callbacks.on_camera_removed(camera_id)
            return True

        except Exception as e:
            logger.error(f"Error removing camera {camera_id}: {e}")
            return False

    async def _recreate_transport(self) -> bool:
        """Recreate transport after it becomes stale."""
        try:
            self._transport_stale = False

            if self._send_transport:
                try:
                    await self._send_transport.close()
                except:
                    pass

            self._transport_connected_event = asyncio.Event()

            url = f"{self._active_url}/offer"
            data = {
                "connectionId": self.client_id,
                "connectionType": "vitesse",
                "rtpCapabilities": self._device.rtpCapabilities.dict(exclude_none=True)
            }

            timeout = aiohttp.ClientTimeout(total=10)

            async with self._session.post(url, json=data, timeout=timeout) as response:
                if response.status != 200:
                    return False
                self._transport_info = await response.json()

            # Rewrite ICE candidates to use the IP we connected to
            rewritten_candidates = self._rewrite_ice_candidates(
                self._transport_info['iceCandidates']
            )

            self._send_transport = self._device.createSendTransport(
                id=self._transport_info['transportId'],
                iceParameters=self._transport_info['iceParameters'],
                iceCandidates=rewritten_candidates,
                dtlsParameters=self._transport_info['dtlsParameters'],
                sctpParameters=self._transport_info.get('sctpParameters')
            )

            await self._setup_transport_events()
            return True

        except Exception as e:
            logger.error(f"Error recreating transport: {e}")
            return False

    async def disconnect(self) -> None:
        """Disconnect from the gateway and release all resources.

        Closes all producers, transport, and HTTP session. Stops any
        ongoing reconnection attempts.
        """
        self._connected = False
        self._stop_reconnect = True  # Stop any reconnection attempts
        self._loop_shutdown.set()
        await self._cleanup()
        # Remove from active clients registry
        _active_clients.discard(self)
        self.callbacks.on_disconnected("Disconnected")

    def _sync_cleanup(self):
        """Synchronous cleanup for use in signal handlers and atexit.

        Attempts to run async cleanup in the event loop if available,
        otherwise does minimal synchronous cleanup.
        """
        if not self._connected and not self._connecting:
            return

        self._connected = False
        self._stop_reconnect = True
        self._loop_shutdown.set()

        # Try to run async cleanup
        try:
            loop = self._event_loop or asyncio.get_event_loop()
            if loop.is_running():
                # Schedule cleanup but don't wait
                asyncio.run_coroutine_threadsafe(self._cleanup(), loop)
            else:
                # Run cleanup synchronously
                loop.run_until_complete(self._cleanup())
        except Exception:
            # Fallback: minimal sync cleanup
            try:
                for track in self._camera_tracks.values():
                    try:
                        track.cleanup()
                    except:
                        pass
                self._camera_tracks.clear()
                self._camera_sources.clear()
                self._executor.shutdown(wait=False)
            except:
                pass

        logger.info(f"Client {self.client_id} cleaned up")

    async def _cleanup(self):
        """Clean up all resources."""
        try:
            for producer in self._producers.values():
                try:
                    await producer.close()
                except:
                    pass
            self._producers.clear()

            if self._send_transport:
                try:
                    await self._send_transport.close()
                except:
                    pass
                self._send_transport = None

            for track in self._camera_tracks.values():
                try:
                    track.cleanup()
                except:
                    pass
            self._camera_tracks.clear()
            self._camera_sources.clear()

            if self._session:
                try:
                    await asyncio.wait_for(self._session.close(), timeout=2.0)
                except:
                    pass
                self._session = None

            self._executor.shutdown(wait=False)
            self._device = None

        except Exception as e:
            logger.error(f"Error during cleanup: {e}")

    # Thread-safe scheduling methods

    def schedule_add_camera(
        self,
        camera_id: str,
        camera_source: CameraSource,
        callback: Optional[callable] = None
    ):
        """Schedule camera addition (thread-safe).

        Args:
            camera_id: Unique identifier for this camera
            camera_source: CameraSource providing video frames
            callback: Optional callback(success: bool) called when complete
        """
        if not self._event_loop:
            if callback:
                callback(False)
            return

        future = asyncio.run_coroutine_threadsafe(
            self.add_camera(camera_id, camera_source),
            self._event_loop
        )

        def handle_result(f):
            try:
                success = f.result()
                if callback:
                    callback(success)
            except Exception:
                if callback:
                    callback(False)

        future.add_done_callback(handle_result)

    def schedule_remove_camera(self, camera_id: str, callback: Optional[callable] = None):
        """Schedule camera removal (thread-safe).

        Args:
            camera_id: ID of the camera to remove
            callback: Optional callback(success: bool) called when complete
        """
        if not self._event_loop:
            if callback:
                callback(False)
            return

        future = asyncio.run_coroutine_threadsafe(
            self.remove_camera(camera_id),
            self._event_loop
        )

        def handle_result(f):
            try:
                success = f.result()
                if callback:
                    callback(success)
            except Exception:
                if callback:
                    callback(False)

        future.add_done_callback(handle_result)

    def set_event_loop(self, loop: asyncio.AbstractEventLoop):
        """Set the event loop for async operations.

        Args:
            loop: The asyncio event loop to use
        """
        self._event_loop = loop
