"""
Configuration for the Vitesse Video Feed library.
"""

from dataclasses import dataclass, field
from typing import Tuple, Optional, Callable
import logging


# Default logger - can be replaced by users
_default_logger = logging.getLogger("vitesse_video_feed")


@dataclass
class VideoFeedConfig:
    """Configuration for the video feed client.

    Attributes:
        gateway_url: Primary URL of the gateway (can be full URL or just host/IP).
            If only host is provided, protocol and port are determined by use_https.
        priority_gateway_url: Optional high-priority URL to try first before gateway_url.
            Useful for internal/container networks. If connection fails, falls back to gateway_url.
        use_https: If True, uses HTTPS on port 7901. If False, uses HTTP on port 7900.
            Only applies when gateway_url is a bare host/IP without protocol.
        connection_timeout_ms: Timeout for connection attempts in milliseconds
        retry_attempts: Number of retry attempts for failed connections per URL
        retry_interval_s: Seconds to wait between retry attempts
        reconnect_interval_s: Seconds to wait before full reconnection cycle (0 to disable)
        max_reconnect_cycles: Maximum reconnection cycles (0 for infinite)
        default_resolution: Default video resolution (width, height)
        default_framerate: Default frames per second
        logger: Optional custom logger (uses default if not provided)
    """
    gateway_url: str
    priority_gateway_url: Optional[str] = None
    use_https: bool = True
    connection_timeout_ms: int = 10000
    retry_attempts: int = 3
    retry_interval_s: float = 2.0
    reconnect_interval_s: float = 10.0
    max_reconnect_cycles: int = 0  # 0 = infinite
    default_resolution: Tuple[int, int] = (480, 360)
    default_framerate: int = 15
    logger: Optional[logging.Logger] = None

    def __post_init__(self):
        """Validate configuration after initialization."""
        if not self.gateway_url:
            raise ValueError("gateway_url is required")

        # Normalize URLs - add protocol and port if not specified
        self.gateway_url = self._normalize_url(self.gateway_url, self.use_https)
        if self.priority_gateway_url:
            # Priority URL uses opposite protocol (internal = HTTP)
            self.priority_gateway_url = self._normalize_url(
                self.priority_gateway_url, not self.use_https
            )

        # Use default logger if none provided
        if self.logger is None:
            self.logger = _default_logger

        # Validate resolution
        if self.default_resolution[0] <= 0 or self.default_resolution[1] <= 0:
            raise ValueError(f"Invalid resolution: {self.default_resolution}")

        # Validate framerate
        if self.default_framerate <= 0 or self.default_framerate > 60:
            raise ValueError(f"Invalid framerate: {self.default_framerate}. Must be 1-60")

    @staticmethod
    def _normalize_url(url: str, use_https: bool) -> str:
        """Normalize URL by adding protocol and port if not specified."""
        # Already has protocol - return as-is
        if url.startswith('http://') or url.startswith('https://'):
            return url

        # Bare host/IP - add protocol and port
        if use_https:
            return f"https://{url}:7901"
        else:
            return f"http://{url}:7900"

    def get_logger(self) -> logging.Logger:
        """Get the configured logger."""
        return self.logger or _default_logger
