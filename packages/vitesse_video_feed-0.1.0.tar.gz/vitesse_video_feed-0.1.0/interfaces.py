"""
Interfaces for the Vitesse Video Feed library.

These interfaces define the contract that camera sources must implement
and the callbacks for client events.
"""

from abc import ABC
from dataclasses import dataclass
from typing import Optional, Tuple, Dict, Any, Protocol, runtime_checkable, List, Callable
import numpy as np


@dataclass
class CameraInfo:
    """Information about a camera feed.

    Attributes:
        name: Human-readable name for the camera
        resolution: Tuple of (width, height) in pixels
        framerate: Target frames per second
        description: Optional description of the camera feed
        tags: Optional list of tags for categorization
        location: Optional location string
    """
    name: str
    resolution: Tuple[int, int]
    framerate: int = 15
    description: Optional[str] = None
    tags: Optional[List[str]] = None
    location: Optional[str] = None

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary for serialization."""
        result = {
            "name": self.name,
            "resolution": f"{self.resolution[0]}x{self.resolution[1]}",
            "framerate": self.framerate,
            "encoding": "h264"
        }
        # Only include optional fields if set
        if self.description is not None:
            result["description"] = self.description
        if self.tags is not None:
            result["tags"] = self.tags
        if self.location is not None:
            result["location"] = self.location
        return result


@runtime_checkable
class CameraSource(Protocol):
    """Protocol defining what a camera source must implement.

    Camera sources provide video frames to the client.
    Implementations can be USB cameras, IP cameras, synthetic feeds, etc.
    """

    def get_frame(self) -> Optional[np.ndarray]:
        """Get the latest video frame.

        Returns:
            BGR numpy array of shape (height, width, 3), or None if no frame available.
            The frame should be at the resolution specified in the camera info.
        """
        ...

    def is_active(self) -> bool:
        """Check if the camera source is actively producing frames.

        Returns:
            True if the source is active and can provide frames.
        """
        ...

    @property
    def info(self) -> CameraInfo:
        """Get camera information.

        Returns:
            CameraInfo describing this camera source.
        """
        ...


class CameraSourceAdapter:
    """Adapter to convert existing camera interfaces to CameraSource protocol.

    Use this when you have an existing camera implementation that doesn't
    match the CameraSource protocol exactly.

    Example:
        source = CameraSourceAdapter(
            get_frame_fn=my_camera.read,
            is_active_fn=my_camera.is_open,
            camera_info=CameraInfo(name="My Cam", resolution=(640, 480))
        )
    """

    def __init__(
        self,
        get_frame_fn: Callable[[], Optional[np.ndarray]],
        is_active_fn: Callable[[], bool],
        camera_info: CameraInfo
    ) -> None:
        """Initialize the adapter.

        Args:
            get_frame_fn: Callable that returns a frame (RGB numpy array or None).
            is_active_fn: Callable that returns bool indicating if source is active.
            camera_info: CameraInfo describing this source.
        """
        self._get_frame = get_frame_fn
        self._is_active = is_active_fn
        self._info = camera_info

    def get_frame(self) -> Optional[np.ndarray]:
        return self._get_frame()

    def is_active(self) -> bool:
        return self._is_active()

    @property
    def info(self) -> CameraInfo:
        return self._info


class FeedClientCallbacks(ABC):
    """Callbacks for client events.

    Implement this class to receive notifications about connection and camera events.
    All methods have default empty implementations, so you only need to
    override the ones you care about.
    """

    def on_connected(self) -> None:
        """Called when successfully connected to the gateway."""
        pass

    def on_disconnected(self, reason: str) -> None:
        """Called when disconnected from the gateway.

        Args:
            reason: Description of why the disconnection occurred.
        """
        pass

    def on_connection_failed(self, error: str) -> None:
        """Called when connection to the gateway fails.

        Args:
            error: Description of the error that occurred.
        """
        pass

    def on_camera_added(self, camera_id: str) -> None:
        """Called when a camera is successfully added and streaming.

        Args:
            camera_id: The camera ID that was added.
        """
        pass

    def on_camera_add_failed(self, camera_id: str, error: str) -> None:
        """Called when adding a camera fails.

        Args:
            camera_id: The camera ID that failed to add.
            error: Description of the error.
        """
        pass

    def on_camera_removed(self, camera_id: str) -> None:
        """Called when a camera is removed.

        Args:
            camera_id: The camera ID that was removed.
        """
        pass


class NoOpCallbacks(FeedClientCallbacks):
    """Default no-op implementation of callbacks."""
    pass
