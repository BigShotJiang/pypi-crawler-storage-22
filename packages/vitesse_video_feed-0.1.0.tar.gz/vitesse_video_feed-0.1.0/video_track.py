"""
Video track implementation for streaming frames.
"""

import asyncio
import fractions
import numpy as np
from typing import Optional, TYPE_CHECKING

try:
    from aiortc import VideoStreamTrack
    from av import VideoFrame
    import cv2
    _DEPS_AVAILABLE = True
except ImportError:
    _DEPS_AVAILABLE = False
    VideoStreamTrack = object

if TYPE_CHECKING:
    from .interfaces import CameraSource


class MediaStreamError(Exception):
    """Raised when a media stream encounters an error."""
    pass


class VideoTrack(VideoStreamTrack if _DEPS_AVAILABLE else object):
    """Video track that streams frames from a CameraSource.

    Handles frame timing, color conversion, and resolution management.
    """

    kind = "video"

    def __init__(
        self,
        camera_id: str,
        camera_source: 'CameraSource',
        target_fps: int = 15,
        target_resolution: tuple = (480, 360)
    ):
        """Initialize the video track.

        Args:
            camera_id: Unique identifier for this camera
            camera_source: CameraSource providing video frames
            target_fps: Target frames per second
            target_resolution: Target resolution as (width, height)
        """
        if _DEPS_AVAILABLE:
            super().__init__()

        self.camera_id = camera_id
        self.camera_source = camera_source
        self._start_time: Optional[float] = None
        self._frame_count = 0

        self.target_fps = target_fps
        self.target_resolution = target_resolution

        self._frame_interval = 1.0 / float(self.target_fps)
        self._consecutive_failures = 0
        self._stopped = False

        # Cache for resize optimization
        self._last_frame_shape: Optional[tuple] = None
        self._needs_resize = True

    def stop(self):
        """Stop the track (no-op to keep track running)."""
        pass

    def cleanup(self):
        """Actually stop the track and release resources."""
        self._stopped = True

    async def recv(self):
        """Receive the next video frame.

        Returns:
            Video frame ready for streaming.

        Raises:
            MediaStreamError: If the track has been stopped.
        """
        if not _DEPS_AVAILABLE:
            raise MediaStreamError("Required dependencies not available")

        if self._stopped:
            raise MediaStreamError("Track stopped")

        if self._start_time is None:
            self._start_time = asyncio.get_event_loop().time()

        # Calculate target time for this frame
        target_time = self._start_time + (self._frame_count * self._frame_interval)
        current_time = asyncio.get_event_loop().time()

        # Wait if ahead of schedule
        if current_time < target_time:
            await asyncio.sleep(target_time - current_time)

        pts = int(self._frame_count * 1000 / self.target_fps)

        frame = None
        if self.camera_source:
            try:
                if not self.camera_source.is_active():
                    self._stopped = True
                    raise MediaStreamError("Camera source stopped")
                frame = self.camera_source.get_frame()
            except Exception:
                self._consecutive_failures += 1

        if frame is not None:
            try:
                self._consecutive_failures = 0

                # Check if resize is needed (only when frame shape changes)
                if self._last_frame_shape != frame.shape:
                    self._last_frame_shape = frame.shape
                    frame_h, frame_w = frame.shape[:2]
                    target_w, target_h = self.target_resolution
                    self._needs_resize = (frame_w != target_w or frame_h != target_h)

                # Resize only if needed
                if self._needs_resize:
                    frame = cv2.resize(
                        frame,
                        self.target_resolution,
                        interpolation=cv2.INTER_LINEAR
                    )

                # Convert BGR to RGB
                frame_rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
                av_frame = VideoFrame.from_ndarray(frame_rgb, format="rgb24")
                av_frame.pts = pts
                av_frame.time_base = fractions.Fraction(1, 1000)
                self._frame_count += 1

                return av_frame

            except Exception:
                self._consecutive_failures += 1

        # Return black frame if no frame available
        black_frame = np.zeros(
            (self.target_resolution[1], self.target_resolution[0], 3),
            dtype=np.uint8
        )
        av_frame = VideoFrame.from_ndarray(black_frame, format="rgb24")
        av_frame.pts = pts
        av_frame.time_base = fractions.Fraction(1, 1000)
        self._frame_count += 1
        return av_frame


def create_video_track(
    camera_id: str,
    camera_source: 'CameraSource',
    target_fps: Optional[int] = None,
    target_resolution: Optional[tuple] = None
) -> VideoTrack:
    """Create a video track from a camera source.

    Args:
        camera_id: Unique identifier for this camera
        camera_source: CameraSource providing video frames
        target_fps: Target FPS (defaults to camera_source.info.framerate)
        target_resolution: Target resolution (defaults to camera_source.info.resolution)

    Returns:
        VideoTrack instance ready for streaming.
    """
    info = camera_source.info

    if target_fps is None:
        target_fps = info.framerate

    if target_resolution is None:
        target_resolution = info.resolution

    return VideoTrack(
        camera_id=camera_id,
        camera_source=camera_source,
        target_fps=target_fps,
        target_resolution=target_resolution
    )
