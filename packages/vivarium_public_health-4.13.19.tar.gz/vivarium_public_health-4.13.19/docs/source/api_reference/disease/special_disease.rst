.. automodule:: vivarium_public_health.disease.special_disease
