# Security Policy

If you discover a security issue, please do not open a public issue.
Instead, contact the maintainers privately.
