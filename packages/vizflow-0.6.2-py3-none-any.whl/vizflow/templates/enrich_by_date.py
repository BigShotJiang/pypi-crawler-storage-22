#!/usr/bin/env python
"""Template: Cluster batch job -- enrich one date -> Delta Lake (append).

Same enrichment pipeline as enrich_to_delta.py, but designed for batch
processing: takes --date argument and uses mode="append" for incremental
Delta Lake writes. Run once per date via job scheduler.

Derived enrichments (mid, spread, return, touch, markout) are NOT stored here.
They are computed lazily at analysis time (see explore_dashboard.py template).

To use this template:
  1. Copy: vf.templates.copy_template("enrich_by_date.py", "my_batch.py")
  2. Edit CONFIG section with your cluster paths and schemas
  3. Edit FORWARD MERGE CONFIG with your horizons and ref_cols
  4. Run: python my_batch.py --date 20240827

Output: enriched/base/ and enriched/forward/ (Delta Lake, append mode)

Requires: pip install deltalake
"""
from __future__ import annotations

import argparse
from pathlib import Path

import polars as pl
import vizflow as vf

try:
    import deltalake  # noqa: F401
except ImportError:
    raise ImportError("deltalake required. Install: pip install deltalake")


# ═══════════════════════════════════════════════════════════════
# CONFIG — edit for your cluster environment
# ═══════════════════════════════════════════════════════════════
ALPHA_DIR = Path("/gpfs/.../jyao/alpha")
ALPHA_PATTERN = "alpha_{date}.feather"
ALPHA_SCHEMA = "jyao_v20251114"

TRADE_DIR = Path("/gpfs/.../ylin/trade/sc_0")
TRADE_PATTERN = "{date}.meords"
TRADE_SCHEMA = "sim_standard"

OUTPUT_DIR = Path("./enriched")
MARKET = "CN"


# ═══════════════════════════════════════════════════════════════
# FORWARD MERGE CONFIG — edit for your analysis
# ═══════════════════════════════════════════════════════════════
HORIZONS = [-10, -5, -1, 0, 1, 5, 10, 30, 60, 120, 180, 300, 600, 1200, 1800, 2400, 3600]
REF_COLS = ["bid_px0", "ask_px0", "bid_size0", "ask_size0"]
ALPHA_PRED_COLS = ["x_10s", "x_60s", "x_3m", "x_30m"]

TRADE_TIME_COL = "update_exchange_ts"
ALPHA_TIME_COL = "ticktime"


# ═══════════════════════════════════════════════════════════════
# TRADE ENRICHMENT (before merge)
# ═══════════════════════════════════════════════════════════════
fill_qty = (
    pl.col("order_filled_qty")
    - pl.col("order_filled_qty").shift(1).over("order_id").fill_null(0)
)
fill_notional = (
    pl.col("order_filled_notional")
    - pl.col("order_filled_notional").shift(1).over("order_id").fill_null(0)
)
time_to_fill = pl.col("update_exchange_ts") - pl.col("create_exchange_ts")

TRADE_ENRICHMENTS = [
    fill_qty.alias("fill_qty"),
    fill_notional.alias("fill_notional"),
    time_to_fill.alias("time_to_fill"),
]


# ═══════════════════════════════════════════════════════════════
# PROCESS ONE DATE
# ═══════════════════════════════════════════════════════════════
def process_date(date: str) -> tuple[pl.DataFrame, pl.DataFrame]:
    """Process one date: enrich + merge forward.

    Returns:
        (df_base, df_forward) tuple
    """
    elapsed_trade = f"elapsed_{TRADE_TIME_COL}"
    elapsed_alpha = f"elapsed_{ALPHA_TIME_COL}"

    # Load
    lf_trade = (
        vf.scan_trade(date)
        .filter(pl.col("order_filled_qty") > 0)
        .with_columns(TRADE_ENRICHMENTS)
        .pipe(vf.parse_time, TRADE_TIME_COL)
    )
    lf_alpha = vf.scan_alpha(date).pipe(vf.parse_time, ALPHA_TIME_COL)

    # Alpha predictions -> trade via asof join
    df_trade = lf_trade.collect()
    df_alpha_preds = (
        lf_alpha.select(["ukey", elapsed_alpha] + ALPHA_PRED_COLS).collect()
    )
    df_trade = (
        df_trade
        .sort(["ukey", elapsed_trade])
        .join_asof(
            df_alpha_preds.sort(["ukey", elapsed_alpha]),
            left_on=elapsed_trade,
            right_on=elapsed_alpha,
            by="ukey",
            strategy="backward",
        )
    )

    # Forward merge
    df = vf.merge_forward(
        df_trade, lf_alpha,
        ref_cols=REF_COLS,
        horizons=HORIZONS,
        trade_time_col=elapsed_trade,
        ref_time_col=elapsed_alpha,
    )

    # Base table: trade-level columns (no forward columns)
    forward_col_names = [
        f"{col}_{vf.horizon_suffix(h)}" for col in REF_COLS for h in HORIZONS
    ]
    base_cols = [c for c in df.columns if c not in forward_col_names]
    df_base = df.select(base_cols)

    # Forward table: melted long format
    # Cast size columns for uniform forward_value type in melt
    size_cast = [
        pl.col(f"{col}_{vf.horizon_suffix(h)}").cast(pl.Float64)
        for col in ["bid_size0", "ask_size0"]
        for h in HORIZONS
        if f"{col}_{vf.horizon_suffix(h)}" in df.columns
    ]
    if size_cast:
        df = df.with_columns(size_cast)
    df_forward = vf.melt_forward(df, ref_cols=REF_COLS, horizons=HORIZONS, id_cols=["seq", "data_date"])

    return df_base, df_forward


# ═══════════════════════════════════════════════════════════════
# CLI + MAIN
# ═══════════════════════════════════════════════════════════════
def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--date", required=True, help="Date in YYYYMMDD format")
    args = parser.parse_args()

    vf.set_config(vf.Config(
        alpha_dir=ALPHA_DIR,
        alpha_pattern=ALPHA_PATTERN,
        alpha_schema=ALPHA_SCHEMA,
        trade_dir=TRADE_DIR,
        trade_pattern=TRADE_PATTERN,
        trade_schema=TRADE_SCHEMA,
        market=MARKET,
    ))

    print(f"Processing {args.date}...")
    df_base, df_forward = process_date(args.date)
    print(f"  {len(df_base)} fills, {len(df_base.columns)} base columns")
    print(f"  {len(df_forward)} forward rows (long format)")

    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

    # Append mode for incremental batch processing
    df_base.write_delta(
        str(OUTPUT_DIR / "base"),
        mode="append",
        delta_write_options={"partition_by": ["data_date"]},
    )

    if len(df_forward) > 0:
        df_forward.write_delta(
            str(OUTPUT_DIR / "forward"),
            mode="append",
            delta_write_options={"partition_by": ["data_date", "ref_col", "horizon_ms"]},
        )

    print(f"  Saved to {OUTPUT_DIR}")


if __name__ == "__main__":
    main()
