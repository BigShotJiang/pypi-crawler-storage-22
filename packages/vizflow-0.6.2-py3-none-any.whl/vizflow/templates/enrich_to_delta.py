#!/usr/bin/env python
"""Template: Enrich raw trade/alpha data -> Delta Lake.

Pipeline:
  scan_trade -> fill enrichment -> parse_time
  scan_alpha -> parse_time
  asof join (alpha predictions -> trade)
  merge_forward (bid/ask/size at multiple horizons)
  base/forward split -> Delta Lake with Hive partitioning

Derived enrichments (mid, spread, return, touch, markout) are NOT stored here.
They are computed lazily at analysis time (see explore_dashboard.py template).

To use this template:
  1. Copy: vf.templates.copy_template("enrich_to_delta.py", "my_enrich.py")
  2. Edit CONFIG section with your data paths and schemas
  3. Edit FORWARD MERGE CONFIG with your horizons and ref_cols
  4. Run: python my_enrich.py

Output: enriched/base/ (trade-level) and enriched/forward/ (long format, Delta Lake)

Requires: pip install deltalake
"""
from __future__ import annotations

from pathlib import Path

import polars as pl
import vizflow as vf

try:
    from deltalake import write_deltalake
except ImportError:
    raise ImportError("deltalake required. Install: pip install deltalake")


# ═══════════════════════════════════════════════════════════════
# CONFIG — edit for your environment
# ═══════════════════════════════════════════════════════════════
vf.set_config(vf.Config(
    alpha_dir=Path("data/jyao/alpha"),
    alpha_pattern="alpha_{date}.feather",
    alpha_schema="jyao_v20251114",
    trade_dir=Path("data/ylin/trade"),
    trade_pattern="{date}.meords",
    trade_schema="ylin_v20251204",
    market="CN",
))

OUTPUT_DIR = Path("./enriched")
DATE = "20240827"


# ═══════════════════════════════════════════════════════════════
# FORWARD MERGE CONFIG — edit for your analysis
# ═══════════════════════════════════════════════════════════════
HORIZONS = [-10, -5, -1, 0, 1, 5, 10, 30, 60, 120, 180, 300, 600, 1200, 1800, 2400, 3600]
REF_COLS = ["bid_px0", "ask_px0", "bid_size0", "ask_size0"]
ALPHA_PRED_COLS = ["x_10s", "x_60s", "x_3m", "x_30m"]
TRADE_TIME_COL = "update_exchange_ts"
ALPHA_TIME_COL = "ticktime"


# ═══════════════════════════════════════════════════════════════
# TRADE ENRICHMENT (fill-level from cumulative)
# ═══════════════════════════════════════════════════════════════
fill_qty = (
    pl.col("order_filled_qty")
    - pl.col("order_filled_qty").shift(1).over("order_id").fill_null(0)
)
fill_notional = (
    pl.col("order_filled_notional")
    - pl.col("order_filled_notional").shift(1).over("order_id").fill_null(0)
)


# ═══════════════════════════════════════════════════════════════
# PROCESS
# ═══════════════════════════════════════════════════════════════
def main():
    print(f"Processing date {DATE}...")
    print(f"  Horizons: {HORIZONS}")
    print(f"  Ref cols: {REF_COLS}")

    elapsed_trade = f"elapsed_{TRADE_TIME_COL}"
    elapsed_alpha = f"elapsed_{ALPHA_TIME_COL}"

    # Load + enrich + parse time
    lf_trade = (
        vf.scan_trade(DATE)
        .filter(pl.col("order_filled_qty") > 0)
        .with_columns([
            fill_qty.alias("fill_qty"),
            fill_notional.alias("fill_notional"),
        ])
        .pipe(vf.parse_time, TRADE_TIME_COL)
    )
    lf_alpha = vf.scan_alpha(DATE).pipe(vf.parse_time, ALPHA_TIME_COL)

    # Bring alpha predictions to trade rows via asof join
    df_trade = lf_trade.collect()
    df_alpha_preds = (
        lf_alpha.select(["ukey", elapsed_alpha] + ALPHA_PRED_COLS).collect()
    )
    df_trade = (
        df_trade
        .sort(["ukey", elapsed_trade])
        .join_asof(
            df_alpha_preds.sort(["ukey", elapsed_alpha]),
            left_on=elapsed_trade,
            right_on=elapsed_alpha,
            by="ukey",
            strategy="backward",
        )
    )
    print(f"  alpha predictions joined: {ALPHA_PRED_COLS}")

    # merge_forward: raw price/size columns at each horizon
    df = vf.merge_forward(
        df_trade, lf_alpha,
        ref_cols=REF_COLS,
        horizons=HORIZONS,
        trade_time_col=elapsed_trade,
        ref_time_col=elapsed_alpha,
    )
    print(f"  merge_forward: {len(df)} rows, {len(df.columns)} columns")

    # Base table: trade-level columns (no forward columns)
    forward_col_names = [
        f"{col}_{vf.horizon_suffix(h)}" for col in REF_COLS for h in HORIZONS
    ]
    base_cols = [c for c in df.columns if c not in forward_col_names]
    df_base = df.select(base_cols)

    # Forward table: melted long format
    # Cast size columns for uniform forward_value type
    size_cast = [
        pl.col(f"{col}_{vf.horizon_suffix(h)}").cast(pl.Float64)
        for col in ["bid_size0", "ask_size0"]
        for h in HORIZONS
        if f"{col}_{vf.horizon_suffix(h)}" in df.columns
    ]
    if size_cast:
        df = df.with_columns(size_cast)
    df_forward = vf.melt_forward(df, ref_cols=REF_COLS, horizons=HORIZONS, id_cols=["seq", "data_date"])

    print(f"  base: {len(df_base)} rows, {len(df_base.columns)} columns")
    print(f"  forward: {len(df_forward)} rows (long format)")

    # Write Delta Lake with Hive partitioning
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

    write_deltalake(
        str(OUTPUT_DIR / "base"),
        df_base.to_arrow(),
        mode="overwrite",
        partition_by=["data_date"],
    )

    if len(df_forward) > 0:
        write_deltalake(
            str(OUTPUT_DIR / "forward"),
            df_forward.to_arrow(),
            mode="overwrite",
            partition_by=["data_date", "ref_col", "horizon_ms"],
        )

    print(f"  Saved to {OUTPUT_DIR}")


if __name__ == "__main__":
    main()
