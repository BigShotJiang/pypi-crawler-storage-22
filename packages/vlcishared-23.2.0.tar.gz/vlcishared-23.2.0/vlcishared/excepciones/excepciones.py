class ExtensionFicheroInvalidaError(Exception):
    """Se lanza cuando un fichero no tiene la extensión esperada."""
    pass