# prompts
from .simple_prompts import *
from .e5mistral import load_e5mistral_prompt
from .instructor import load_instructor_prompt
from .tart import load_tart_prompt
from .sfr import load_sfe_prompt
from .e5mistral_multilingual import load_e5mistral_multilingual_prompt
