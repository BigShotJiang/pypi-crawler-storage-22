qrel_file = "/u6/s8sharif/MMEB-V2/visdoc-tasks/pyserini/qrels/qrels.mmeb-visdoc-ViDoSeek-doc.test.txt"
q_doc_pairs = {}
with open(qrel_file, "r") as f:
    for line in f:
        qid, _, docid, score = line.strip().split()
        if (qid, docid) not in q_doc_pairs:
            q_doc_pairs[(qid, docid)] = []
        q_doc_pairs[(qid, docid)].append(score)
        if len(q_doc_pairs[(qid, docid)]) > 1:
            print("qid: ", qid, "docid: ", docid, "scores: ", q_doc_pairs[(qid, docid)])



    for line in f:
        qid, _, docid, score = line.strip().split()
        print(qid, docid)