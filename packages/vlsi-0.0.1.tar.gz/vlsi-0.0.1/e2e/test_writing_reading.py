import pytest
from tempfile import TemporaryDirectory
from pathlib import Path
from typing import Union
import hashlib
from concurrent.futures import ThreadPoolExecutor
import struct

import requests
import nibabel as nib
import numpy as np

from vlsi import WritableSpatialIndex, ReadableSpatialIndex

# extracted from siibra-configuration a281669d824037973aedaf2a3b625c38bcf5ba86 (from jugit)
colin27_jba30_hg_maps = {
    "AcbL (Lateral Accumbens, Ventral Striatum) - left hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/AcbL/AcbL_pmap_l_N10_nlin2Stdcolin27_5.0_public_81120cd10e215bc8389672c821a21cf0.nii.gz",
    "AcbM (Medial Accumbens, Ventral Striatum) - left hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/AcbM/AcbM_pmap_l_N10_nlin2Stdcolin27_5.0_public_85171d73dc6e5abb4be78eb97e8dd223.nii.gz",
    "Area 1 (PostCG) - left hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/Area-1/Area-1_pmap_l_N10_nlin2Stdcolin27_12.1_public_4c84a10b377d411a63f2185557219b30.nii.gz",
    "Area 25.25a (sACC) - left hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/Area-25.25a/Area-25.25a_pmap_l_N10_nlin2Stdcolin27_20.1_publicP_ecafdc626fa81116a215bff0d41fea8f.nii.gz",
    "Area 25.25p (sACC) - left hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/Area-25.25p/Area-25.25p_pmap_l_N10_nlin2Stdcolin27_20.1_publicP_c94b47a8c224ba2e5c6c3747b248c1a8.nii.gz",
    "Area 2 (PostCS) - left hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/Area-2/Area-2_pmap_l_N10_nlin2Stdcolin27_7.1_public_0f22a34e441eb1dd35f0a14075b9b724.nii.gz",
    "Area 33 (ACC) - left hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/Area-33/Area-33_pmap_l_N10_nlin2Stdcolin27_20.1_public_070b480b08747d2b9a273da6ddb82bad.nii.gz",
    "Area 3a (PostCG) - left hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/Area-3a/Area-3a_pmap_l_N10_nlin2Stdcolin27_12.1_public_9055774bd49849f12a9011e757d96031.nii.gz",
    "Area 3b (PostCG) - left hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/Area-3b/Area-3b_pmap_l_N10_nlin2Stdcolin27_12.1_public_ffdaa14312333289d8c9bcc68fdff162.nii.gz",
    "Area 44 (IFG) - left hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/Area-44/Area-44_pmap_l_N10_nlin2Stdcolin27_9.2_public_976cf1b63bfcf13989b193c3ec581f4e.nii.gz",
    "Area 45 (IFG) - left hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/Area-45/Area-45_pmap_l_N10_nlin2Stdcolin27_9.2_public_7c1358f21b8b097e672064e2a079ebdd.nii.gz",
    "Area 4a (PreCG) - left hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/Area-4a/Area-4a_pmap_l_N10_nlin2Stdcolin27_13.1_public_f700256fbce90b5aa6c9ab763ff133ea.nii.gz",
    "Area 4p (PreCG) - left hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/Area-4p/Area-4p_pmap_l_N10_nlin2Stdcolin27_13.1_public_37534fab05a08cd867cd463d37fc4308.nii.gz",
    "Area 5Ci (SPL) - left hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/Area-5Ci/Area-5Ci_pmap_l_N10_nlin2Stdcolin27_9.2_public_f1af075959901b00590732b05fbc135f.nii.gz",
    "Area 5L (SPL) - left hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/Area-5L/Area-5L_pmap_l_N10_nlin2Stdcolin27_9.2_public_ad2f7b10322096bc86713a5c8a60be47.nii.gz",
    "Area 5M (SPL) - left hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/Area-5M/Area-5M_pmap_l_N10_nlin2Stdcolin27_9.2_public_f7a7e16d5754095c2c8c606d1916de54.nii.gz",
    "Area 6d1 (PreCG) - left hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/Area-6d1/Area-6d1_pmap_l_N10_nlin2Stdcolin27_7.1_public_9ab710b8a12b38865ffa73ed70646954.nii.gz",
    "Area 6d2 (PreCG) - left hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/Area-6d2/Area-6d2_pmap_l_N10_nlin2Stdcolin27_7.1_public_4dfb788fc07b90654f57665e8fc9ef0b.nii.gz",
    "Area 6d3 (SFS) - left hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/Area-6d3/Area-6d3_pmap_l_N10_nlin2Stdcolin27_7.1_public_47925f620312464a179c4c83c22b13ab.nii.gz",
    "Area 6ma (preSMA, mesial SFG) - left hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/Area-6ma/Area-6ma_pmap_l_N10_nlin2Stdcolin27_12.1_public_ef7a1cc5f484a160e1cf0f9095468f14.nii.gz",
    "Area 6mp (SMA, mesial SFG) - left hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/Area-6mp/Area-6mp_pmap_l_N10_nlin2Stdcolin27_12.1_public_c4a202bb3137c29e4c51e26f6232c7e0.nii.gz",
    "Area 7A (SPL) - left hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/Area-7A/Area-7A_pmap_l_N10_nlin2Stdcolin27_9.2_public_3d944564765a86bb498fe754c6af978b.nii.gz",
    "Area 7M (SPL) - left hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/Area-7M/Area-7M_pmap_l_N10_nlin2Stdcolin27_9.2_public_0b0847798a728239d2baf94abde893fe.nii.gz",
    "Area 7P (SPL) - left hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/Area-7P/Area-7P_pmap_l_N10_nlin2Stdcolin27_9.2_public_01fd1b2516a74b29e7bf43dc35040fd7.nii.gz",
    "Area 7PC (SPL) - left hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/Area-7PC/Area-7PC_pmap_l_N10_nlin2Stdcolin27_9.2_public_f140a6a205e5f977b667980303426910.nii.gz",
    "Area 8d1 (SFG) - left hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/Area-8d1/Area-8d1_pmap_l_N10_nlin2Stdcolin27_4.2_public_f0207093d81f6b74393124fc40cd66fb.nii.gz",
    "Area 8d2 (SFG) - left hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/Area-8d2/Area-8d2_pmap_l_N10_nlin2Stdcolin27_4.2_public_4b3fa6e640b6d507db3ee6040148511a.nii.gz",
    "Area 8v1 (MFG) - left hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/Area-8v1/Area-8v1_pmap_l_N10_nlin2Stdcolin27_4.2_public_5f250e63a488b38dc217f1141ad8e62f.nii.gz",
    "Area 8v2 (MFG) - left hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/Area-8v2/Area-8v2_pmap_l_N10_nlin2Stdcolin27_4.2_public_06542717e6f5934d5ed316bb2e2267a9.nii.gz",
    "Area CoS1 (CoS) - left hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/Area-CoS1/Area-CoS1_pmap_l_N10_nlin2Stdcolin27_7.2_public_fe6b546a36ca6de361d505868028bd7e.nii.gz",
    "Area FG1 (FusG) - left hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/Area-FG1/Area-FG1_pmap_l_N10_nlin2Stdcolin27_3.2_public_51d01476a52a05da9e7120c12ed23fe8.nii.gz",
    "Area FG2 (FusG) - left hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/Area-FG2/Area-FG2_pmap_l_N10_nlin2Stdcolin27_3.2_public_5177b4237dbc54aae915c50bdc2a2f4e.nii.gz",
    "Area FG3 (FusG) - left hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/Area-FG3/Area-FG3_pmap_l_N10_nlin2Stdcolin27_7.2_public_eb54156b8c89b5027860a03727de868b.nii.gz",
    "Area FG4 (FusG) - left hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/Area-FG4/Area-FG4_pmap_l_N10_nlin2Stdcolin27_7.2_public_0e159409451b7730155dcaac2e3e2635.nii.gz",
    "Area Fo1 (OFC) - left hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/Area-Fo1/Area-Fo1_pmap_l_N10_nlin2Stdcolin27_5.2_public_dfad2c1bdab565f634b5445ad46fd056.nii.gz",
    "Area Fo2 (OFC) - left hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/Area-Fo2/Area-Fo2_pmap_l_N10_nlin2Stdcolin27_5.2_public_2d3943d56fcc52f54ad55cbba15db587.nii.gz",
    "Area Fo3 (OFC) - left hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/Area-Fo3/Area-Fo3_pmap_l_N10_nlin2Stdcolin27_5.2_public_8b2af70967046c169aa024866b76da29.nii.gz",
    "Area Fo4 (OFC) - left hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/Area-Fo4/Area-Fo4_pmap_l_N10_nlin2Stdcolin27_3.2_public_5fa9f6decb33f853984e18a4c8d609ae.nii.gz",
    "Area Fo5 (OFC) - left hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/Area-Fo5/Area-Fo5_pmap_l_N10_nlin2Stdcolin27_3.2_public_3625d93190a95c667f85464391820f2e.nii.gz",
    "Area Fo6 (OFC) - left hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/Area-Fo6/Area-Fo6_pmap_l_N10_nlin2Stdcolin27_3.2_public_ec9ee7e1f6f6b71c5ee29196cdc024d7.nii.gz",
    "Area Fo7 (OFC) - left hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/Area-Fo7/Area-Fo7_pmap_l_N10_nlin2Stdcolin27_3.2_public_4c72844d128079cf3c3c3dec9cc8f827.nii.gz",
    "Area Fp1 (FPole) - left hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/Area-Fp1/Area-Fp1_pmap_l_N10_nlin2Stdcolin27_5.1_public_13d1fd6a7fae68363e5bd11509b41773.nii.gz",
    "Area Fp2 (FPole) - left hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/Area-Fp2/Area-Fp2_pmap_l_N10_nlin2Stdcolin27_5.1_public_bbcf9e86c50902622de833ad3f8675ec.nii.gz",
    "Area IFJ1 (IFS,PreCS) - left hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/Area-IFJ1/Area-IFJ1_pmap_l_N10_nlin2Stdcolin27_3.2_public_796978c333952620cc2c28d912e934d8.nii.gz",
    "Area IFJ2 (IFS,PreCS) - left hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/Area-IFJ2/Area-IFJ2_pmap_l_N10_nlin2Stdcolin27_3.2_public_c8825bb8a4a53176aad0fd38a02dc36f.nii.gz",
    "Area IFS1 (IFS) - left hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/Area-IFS1/Area-IFS1_pmap_l_N10_nlin2Stdcolin27_3.2_public_7eb8eee6fe3db1883d9ec97616555839.nii.gz",
    "Area IFS2 (IFS) - left hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/Area-IFS2/Area-IFS2_pmap_l_N10_nlin2Stdcolin27_3.2_public_f2ea945eef46641ab6671229880c8261.nii.gz",
    "Area IFS3 (IFS) - left hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/Area-IFS3/Area-IFS3_pmap_l_N10_nlin2Stdcolin27_3.2_public_8889a54909ef8ba88df0817825066613.nii.gz",
    "Area IFS4 (IFS) - left hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/Area-IFS4/Area-IFS4_pmap_l_N10_nlin2Stdcolin27_3.2_public_10970f419f4a19193ba88532fc0fc7dc.nii.gz",
    "Area Ia1 (Insula) - left hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/Area-Ia1/Area-Ia1_pmap_l_N10_nlin2Stdcolin27_5.1_public_9c051941676d9058aec281be42c3dd7c.nii.gz",
    "Area Ia2 (Insula) - left hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/Area-Ia2/Area-Ia2_pmap_l_N10_nlin2Stdcolin27_4.0_public_4149a608caf7870dc1bf8a8362d0c746.nii.gz",
    "Area Ia3 (Insula) - left hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/Area-Ia3/Area-Ia3_pmap_l_N10_nlin2Stdcolin27_4.0_public_5bb75d65da28512a99877864730f0415.nii.gz",
    "Area Id10 (Insula) - left hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/Area-Id10/Area-Id10_pmap_l_N10_nlin2Stdcolin27_4.0_public_504faeed34b26daac72bf8899c308161.nii.gz",
    "Area Id1 (Insula) - left hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/Area-Id1/Area-Id1_pmap_l_N10_nlin2Stdcolin27_14.2_public_27dbfa6f07ea240725a81762f6c6d7c0.nii.gz",
    "Area Id2 (Insula) - left hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/Area-Id2/Area-Id2_pmap_l_N10_nlin2Stdcolin27_9.1_public_fb7a82f8093abb94ac8c1e3ca28e324d.nii.gz",
    "Area Id3 (Insula) - left hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/Area-Id3/Area-Id3_pmap_l_N10_nlin2Stdcolin27_9.1_public_b7e92c8d7d63f1f09066360163fb6dc3.nii.gz",
    "Area Id4 (Insula) - left hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/Area-Id4/Area-Id4_pmap_l_N10_nlin2Stdcolin27_5.1_public_10e447bd9ad1d28c350674365aefbcef.nii.gz",
    "Area Id5 (Insula) - left hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/Area-Id5/Area-Id5_pmap_l_N10_nlin2Stdcolin27_5.1_public_a279cded8fc6017738199b340400f61d.nii.gz",
    "Area Id6 (Insula) - left hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/Area-Id6/Area-Id6_pmap_l_N10_nlin2Stdcolin27_5.1_public_c4269403bb6aff21e01a8fbb31769702.nii.gz",
    "Area Id7 (Insula) - left hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/Area-Id7/Area-Id7_pmap_l_N10_nlin2Stdcolin27_8.1_public_5d41cc72e64aee186272592a358461d4.nii.gz",
    "Area Id8 (Insula) - left hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/Area-Id8/Area-Id8_pmap_l_N10_nlin2Stdcolin27_4.0_public_934328798b24891d52041661ac3b12f3.nii.gz",
    "Area Id9 (Insula) - left hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/Area-Id9/Area-Id9_pmap_l_N10_nlin2Stdcolin27_4.0_public_61d11d0ffaad1cfb93f76573cdacb4b2.nii.gz",
    "Area Ig1 (Insula) - left hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/Area-Ig1/Area-Ig1_pmap_l_N10_nlin2Stdcolin27_14.2_public_18221853a3fbfc681ec2b679382f6d3c.nii.gz",
    "Area Ig2 (Insula) - left hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/Area-Ig2/Area-Ig2_pmap_l_N10_nlin2Stdcolin27_14.2_public_73c90ab3a9261dbd631c8694ff1d46d6.nii.gz",
    "Area Ig3 (Insula) - left hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/Area-Ig3/Area-Ig3_pmap_l_N10_nlin2Stdcolin27_5.1_public_673dd6891bb7332207f355960b7231b0.nii.gz",
    "Area MFG1 (MFG) - left hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/Area-MFG1/Area-MFG1_pmap_l_N10_nlin2Stdcolin27_9.0_public_6114d32558eaa277bb4d46f0524ce52f.nii.gz",
    "Area MFG2 (MFG) - left hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/Area-MFG2/Area-MFG2_pmap_l_N10_nlin2Stdcolin27_9.0_public_ba39198ca8bf42d6ccfd2cc643619ad4.nii.gz",
    "Area OP1 (POperc) - left hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/Area-OP1/Area-OP1_pmap_l_N10_nlin2Stdcolin27_12.2_public_cfa7a81c353d2d8175262aa8a5261f5e.nii.gz",
    "Area OP2 (POperc) - left hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/Area-OP2/Area-OP2_pmap_l_N10_nlin2Stdcolin27_12.2_public_40bd0a9aaa657d7c4cb74a3a603ea17e.nii.gz",
    "Area OP3 (POperc) - left hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/Area-OP3/Area-OP3_pmap_l_N10_nlin2Stdcolin27_12.2_public_0923bb66427d768e4a1d65488de76d4b.nii.gz",
    "Area OP4 (POperc) - left hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/Area-OP4/Area-OP4_pmap_l_N10_nlin2Stdcolin27_12.2_public_f4dc37ccf911e351008136b0605f9d0c.nii.gz",
    "Area Op5 (Frontal Operculum) - left hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/Area-Op5/Area-Op5_pmap_l_N10_nlin2Stdcolin27_3.2_public_cedf748a6eb642e6158d19092de8aed4.nii.gz",
    "Area Op6 (Frontal Operculum) - left hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/Area-Op6/Area-Op6_pmap_l_N10_nlin2Stdcolin27_3.2_public_031b287124ae1d43de62a7fb8416f56b.nii.gz",
    "Area Op7 (Frontal Operculum) - left hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/Area-Op7/Area-Op7_pmap_l_N10_nlin2Stdcolin27_3.2_public_83e46c99404013736b44d4849d426797.nii.gz",
    "Area Op8 (Frontal Operculum) - left hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/Area-Op8/Area-Op8_pmap_l_N10_nlin2Stdcolin27_6.2_public_a136e548f7a61016bc7245606cc8169b.nii.gz",
    "Area Op9 (Frontal Operculum) - left hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/Area-Op9/Area-Op9_pmap_l_N10_nlin2Stdcolin27_6.2_public_d160880398c3a7b7cde2bb571b7cea00.nii.gz",
    "Area PF (IPL) - left hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/Area-PF/Area-PF_pmap_l_N10_nlin2Stdcolin27_11.2_public_b3c1f94978f7460ef6e0ef9231db6344.nii.gz",
    "Area PFcm (IPL) - left hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/Area-PFcm/Area-PFcm_pmap_l_N10_nlin2Stdcolin27_11.2_public_559b44fa2c19e19432a10622287571f0.nii.gz",
    "Area PFm (IPL) - left hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/Area-PFm/Area-PFm_pmap_l_N10_nlin2Stdcolin27_11.2_public_1e135f7ba5bb1b511b9483189f10bd16.nii.gz",
    "Area PFop (IPL) - left hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/Area-PFop/Area-PFop_pmap_l_N10_nlin2Stdcolin27_11.2_public_7f231290f39f018a0ba79830af3e700f.nii.gz",
    "Area PFt (IPL) - left hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/Area-PFt/Area-PFt_pmap_l_N10_nlin2Stdcolin27_11.2_public_f13ac36a27fab5a1524bb5b963798b9b.nii.gz",
    "Area PGa (IPL) - left hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/Area-PGa/Area-PGa_pmap_l_N10_nlin2Stdcolin27_11.2_public_f6efd3562ebcdfe186dbd05cd4db658e.nii.gz",
    "Area PGp (IPL) - left hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/Area-PGp/Area-PGp_pmap_l_N10_nlin2Stdcolin27_11.2_public_c05c616e1f446bb34b886067edd27dfb.nii.gz",
    "Area Ph1 (PhG) - left hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/Area-Ph1/Area-Ph1_pmap_l_N10_nlin2Stdcolin27_7.2_public_44519bb13063414aa2e8d7d056779dce.nii.gz",
    "Area Ph2 (PhG) - left hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/Area-Ph2/Area-Ph2_pmap_l_N10_nlin2Stdcolin27_7.2_public_6a3a66a29852730a4dca06bd5574a5f0.nii.gz",
    "Area Ph3 (PhG) - left hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/Area-Ph3/Area-Ph3_pmap_l_N10_nlin2Stdcolin27_7.2_public_8b4d37773eb2e73c598c5dd4818f5c56.nii.gz",
    "Area SFS1 (SFS) - left hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/Area-SFS1/Area-SFS1_pmap_l_N10_nlin2Stdcolin27_9.0_public_12538dfa5d89c1ce8d690904e5d2ccb0.nii.gz",
    "Area SFS2 (SFS) - left hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/Area-SFS2/Area-SFS2_pmap_l_N10_nlin2Stdcolin27_9.0_public_5991accbce23b5a91dc78f2dcdd993e6.nii.gz",
    "Area STS1 (STS) - left hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/Area-STS1/Area-STS1_pmap_l_N10_nlin2Stdcolin27_5.3_public_c1ac698445aa4ef4847d88846bd12e12.nii.gz",
    "Area STS2 (STS) - left hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/Area-STS2/Area-STS2_pmap_l_N10_nlin2Stdcolin27_5.3_public_4f5f72b50f3fe45e2f52062b015d17da.nii.gz",
    "Area TE 1.0 (HESCHL) - left hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/Area-TE-1.0/Area-TE-1.0_pmap_l_N10_nlin2Stdcolin27_6.2_public_f3a802ef208b63fadc0d1b28726e4abd.nii.gz",
    "Area TE 1.1 (HESCHL) - left hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/Area-TE-1.1/Area-TE-1.1_pmap_l_N10_nlin2Stdcolin27_6.2_public_e43c9f2224a6266e3a9acc7f79b9f885.nii.gz",
    "Area TE 1.2 (HESCHL) - left hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/Area-TE-1.2/Area-TE-1.2_pmap_l_N10_nlin2Stdcolin27_6.2_public_7e9f6a20dac7c3670cc0b0c293e58367.nii.gz",
    "Area TE 2.1 (STG) - left hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/Area-TE-2.1/Area-TE-2.1_pmap_l_N10_nlin2Stdcolin27_6.2_public_766a50650a46db545a15d946bbaba9f7.nii.gz",
    "Area TE 2.2 (STG) - left hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/Area-TE-2.2/Area-TE-2.2_pmap_l_N10_nlin2Stdcolin27_6.2_public_483fc8013c319690e0367baf95f13a6b.nii.gz",
    "Area TE 3 (STG) - left hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/Area-TE-3/Area-TE-3_pmap_l_N10_nlin2Stdcolin27_6.2_public_dfbae8b8f5b4a5dd8399eb31816ad8a6.nii.gz",
    "Area TI (STG) - left hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/Area-TI/Area-TI_pmap_l_N10_nlin2Stdcolin27_6.2_public_6d0cb72829f9a9b8531d8add6a63979b.nii.gz",
    "Area TPJ (STG/SMG) - left hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/Area-TPJ/Area-TPJ_pmap_l_N10_nlin2Stdcolin27_6.2_public_12520ff9e985f5b463f5aa595d0780dc.nii.gz",
    "Area TeI (STG) - left hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/Area-TeI/Area-TeI_pmap_l_N10_nlin2Stdcolin27_6.2_public_16b41ba77f621457904be132632a8c10.nii.gz",
    "Area hIP1 (IPS) - left hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/Area-hIP1/Area-hIP1_pmap_l_N10_nlin2Stdcolin27_7.2_public_1b7070271159579a31872a1470f2ae8f.nii.gz",
    "Area hIP2 (IPS) - left hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/Area-hIP2/Area-hIP2_pmap_l_N10_nlin2Stdcolin27_7.2_public_00bfe1f4017ff4d5d0dbf8b821177f57.nii.gz",
    "Area hIP3 (IPS) - left hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/Area-hIP3/Area-hIP3_pmap_l_N10_nlin2Stdcolin27_9.2_public_8340319b5cf6f91a0f442dbd0b614c11.nii.gz",
    "Area hIP4 (IPS) - left hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/Area-hIP4/Area-hIP4_pmap_l_N10_nlin2Stdcolin27_7.3_public_52b3269ebf4e03d81405178a8cd432e4.nii.gz",
    "Area hIP5 (IPS) - left hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/Area-hIP5/Area-hIP5_pmap_l_N10_nlin2Stdcolin27_7.3_public_178e7ccca6a861df6262c1f3d2c64e78.nii.gz",
    "Area hIP6 (IPS) - left hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/Area-hIP6/Area-hIP6_pmap_l_N10_nlin2Stdcolin27_7.3_public_32a985a745ec729c27b8cc878ed09bc2.nii.gz",
    "Area hIP7 (IPS) - left hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/Area-hIP7/Area-hIP7_pmap_l_N10_nlin2Stdcolin27_7.3_public_65f37379ffb418c0cc0d82db66f1e75f.nii.gz",
    "Area hIP8 (IPS) - left hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/Area-hIP8/Area-hIP8_pmap_l_N10_nlin2Stdcolin27_7.3_public_f251f2ab93b9ca4c478409c1198cca20.nii.gz",
    "Area hOc1 (V1, 17, CalcS) - left hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/Area-hOc1/Area-hOc1_pmap_l_N10_nlin2Stdcolin27_4.2_public_2a5e0119ddd68703a41a0f7fb5464725.nii.gz",
    "Area hOc2 (V2, 18) - left hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/Area-hOc2/Area-hOc2_pmap_l_N10_nlin2Stdcolin27_4.2_public_41f060b2558f2404daf9e46344fb132d.nii.gz",
    "Area hOc3d (Cuneus) - left hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/Area-hOc3d/Area-hOc3d_pmap_l_N10_nlin2Stdcolin27_4.2_public_42f1cc9d91ba4cbd8e720fd3d89dc8df.nii.gz",
    "Area hOc3v (LingG) - left hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/Area-hOc3v/Area-hOc3v_pmap_l_N10_nlin2Stdcolin27_5.2_public_89a9c54dbcdc0e784ea8f99ef46b3f64.nii.gz",
    "Area hOc4d (Cuneus) - left hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/Area-hOc4d/Area-hOc4d_pmap_l_N10_nlin2Stdcolin27_4.2_public_e91075b7ab8a96ac0404f79825a80fdf.nii.gz",
    "Area hOc4la (LOC) - left hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/Area-hOc4la/Area-hOc4la_pmap_l_N10_nlin2Stdcolin27_5.2_public_18a0381fafec389ba28ccf3f388ee559.nii.gz",
    "Area hOc4lp (LOC) - left hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/Area-hOc4lp/Area-hOc4lp_pmap_l_N10_nlin2Stdcolin27_5.2_public_0d556fd55978804e79e2b8e7adc22f0a.nii.gz",
    "Area hOc4v (LingG) - left hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/Area-hOc4v/Area-hOc4v_pmap_l_N10_nlin2Stdcolin27_5.2_public_e8f71a38cf370bd547aa40e789997809.nii.gz",
    "Area hOc5 (LOC) - left hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/Area-hOc5/Area-hOc5_pmap_l_N10_nlin2Stdcolin27_4.2_public_a378532a118c5e628ded11e83362c062.nii.gz",
    "Area hOc6 (POS) - left hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/Area-hOc6/Area-hOc6_pmap_l_N10_nlin2Stdcolin27_7.3_public_f8e7514f9173380f644d84e7a8b4673a.nii.gz",
    "Area hPO1 (POS) - left hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/Area-hPO1/Area-hPO1_pmap_l_N10_nlin2Stdcolin27_7.3_public_154cefbeb094a1573e99f0409ac5da74.nii.gz",
    "Area p24ab.p24a (pACC) - left hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/Area-p24ab.p24a/Area-p24ab.p24a_pmap_l_N10_nlin2Stdcolin27_20.1_publicP_bbc32233fb0ca6932b2e3e62748a77af.nii.gz",
    "Area p24ab.p24b (pACC) - left hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/Area-p24ab.p24b/Area-p24ab.p24b_pmap_l_N10_nlin2Stdcolin27_20.1_publicP_196add3cdabe5c6010790c31e6d0db24.nii.gz",
    "Area p24c.pd24cd (pACC) - left hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/Area-p24c.pd24cd/Area-p24c.pd24cd_pmap_l_N10_nlin2Stdcolin27_20.1_publicP_42a84e3d87670dd839320f7b5144e098.nii.gz",
    "Area p24c.pd24cv (pACC) - left hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/Area-p24c.pd24cv/Area-p24c.pd24cv_pmap_l_N10_nlin2Stdcolin27_20.1_publicP_457c3ddf27ab06595c60472bf2cd3d9e.nii.gz",
    "Area p24c.pv24c (pACC) - left hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/Area-p24c.pv24c/Area-p24c.pv24c_pmap_l_N10_nlin2Stdcolin27_20.1_publicP_150fc2975486a42e44ca3796da06c0a0.nii.gz",
    "Area p32 (pACC) - left hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/Area-p32/Area-p32_pmap_l_N10_nlin2Stdcolin27_20.1_public_bed882ee377f0cb7614e90fd152d02ea.nii.gz",
    "Area s24.s24a (sACC) - left hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/Area-s24.s24a/Area-s24.s24a_pmap_l_N10_nlin2Stdcolin27_20.1_publicP_fd943a3b7fa5a24e6edd6a94d78b84fb.nii.gz",
    "Area s24.s24b (sACC) - left hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/Area-s24.s24b/Area-s24.s24b_pmap_l_N10_nlin2Stdcolin27_20.1_publicP_ab82dd21d2db85276c59b9f4efea6ce2.nii.gz",
    "Area s32 (sACC) - left hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/Area-s32/Area-s32_pmap_l_N10_nlin2Stdcolin27_20.1_public_f141b66c310b4996581d1252649fe250.nii.gz",
    "BST (Bed Nucleus) - left hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/BST/BST_pmap_l_N10_nlin2Stdcolin27_6.1_public_ad0a2604d082e614072fdbe0086f1d24.nii.gz",
    "CA1 (Hippocampus) - left hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/CA1/CA1_pmap_l_N10_nlin2Stdcolin27_13.2_public_2dc6e36aa5e1422363c92ef0f2e039f1.nii.gz",
    "CA2 (Hippocampus) - left hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/CA2/CA2_pmap_l_N10_nlin2Stdcolin27_13.2_public_b674f83ff6cb3d0bc622c621ba723f40.nii.gz",
    "CA3 (Hippocampus) - left hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/CA3/CA3_pmap_l_N10_nlin2Stdcolin27_13.2_public_a4f4365cb55fd94ce7200411a723b4fd.nii.gz",
    "CGL (Metathalamus) - left hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/CGL/CGL_pmap_l_N10_nlin2Stdcolin27_10.0_public_88cf5b9bf8cb35e33a37122eadb64099.nii.gz",
    "CGM (Metathalamus) - left hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/CGM/CGM_pmap_l_N10_nlin2Stdcolin27_10.0_public_aa4856685cde8d23c75e6333bd8bcfa2.nii.gz",
    "CM.AAA (Amygdala) - left hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/CM.AAA/CM.AAA_pmap_l_N10_nlin2Stdcolin27_8.2_publicP_79801c2e10c5ccdb3b1e445a06f0342b.nii.gz",
    "CM.Ce (Amygdala) - left hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/CM.Ce/CM.Ce_pmap_l_N10_nlin2Stdcolin27_8.2_publicP_01adab8b80c0cd54dcc0ceed938517de.nii.gz",
    "CM.Me (Amygdala) - left hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/CM.Me/CM.Me_pmap_l_N10_nlin2Stdcolin27_8.2_publicP_a778fc7f8651bfae67a358221ba269af.nii.gz",
    "Ch 123 (Basal Forebrain) - left hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/Ch-123/Ch-123_pmap_l_N10_nlin2Stdcolin27_4.3_public_a4e41485b3e9c89350d1fcd6914d567e.nii.gz",
    "Ch 4 (Basal Forebrain) - left hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/Ch-4/Ch-4_pmap_l_N10_nlin2Stdcolin27_4.3_public_9eb942fe0694f7a25b34bca8cbd89a00.nii.gz",
    "DG (Hippocampus) - left hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/DG/DG_pmap_l_N10_nlin2Stdcolin27_13.2_public_66b908507dfffed2d3b0412d33f2f349.nii.gz",
    "Dorsal Dentate Nucleus (Cerebellum) - left hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/Dorsal-Dentate-Nucleus/Dorsal-Dentate-Nucleus_pmap_l_N10_nlin2Stdcolin27_6.3_public_1c91a3a7826d48c3b105c903512fe26f.nii.gz",
    "Entorhinal Cortex - left hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/Entorhinal-Cortex/Entorhinal-Cortex_pmap_l_N10_nlin2Stdcolin27_13.2_public_6f175ac256953b7f3a52ba555afd747e.nii.gz",
    "Fastigial Nucleus (Cerebellum) - left hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/Fastigial-Nucleus/Fastigial-Nucleus_pmap_l_N10_nlin2Stdcolin27_6.3_public_3c098fe0a66935266328de3d6b21a79d.nii.gz",
    "Frontal-I (GapMap) - left hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/Frontal-I/Frontal-I_pmap_l_N10_nlin2Stdcolin27_11.4_public_a7cc632a8d736bd5eb0d4b0d3a5476e4.nii.gz",
    "Frontal-II (GapMap) - left hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/Frontal-II/Frontal-II_pmap_l_N10_nlin2Stdcolin27_11.4_public_1e9bf5fa07fa67620188f9dfe939ffd1.nii.gz",
    "Frontal-to-Occipital (GapMap) - left hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/Frontal-to-Occipital/Frontal-to-Occipital_pmap_l_N10_nlin2Stdcolin27_11.4_public_34b7790135adbb57b6abaf443c7434fb.nii.gz",
    "Frontal-to-Temporal-I (GapMap) - left hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/Frontal-to-Temporal-I/Frontal-to-Temporal-I_pmap_l_N10_nlin2Stdcolin27_11.4_public_10035a3aec586eb83ea6e9b85a4b8fd8.nii.gz",
    "Frontal-to-Temporal-II (GapMap) - left hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/Frontal-to-Temporal-II/Frontal-to-Temporal-II_pmap_l_N10_nlin2Stdcolin27_11.4_public_2fde8bd234f1e0fd474f3f7207b39481.nii.gz",
    "FuCd (Fundus of Caudate Nucleus, Ventral Striatum) - left hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/FuCd/FuCd_pmap_l_N10_nlin2Stdcolin27_5.0_public_782d31df358f57d9fe76a5cda49f617e.nii.gz",
    "FuP (Fundus of Putamen, Ventral Striatum) - left hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/FuP/FuP_pmap_l_N10_nlin2Stdcolin27_5.0_public_aed3b255aa06c71dc329766be82998be.nii.gz",
    "HATA (Hippocampus) - left hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/HATA/HATA_pmap_l_N10_nlin2Stdcolin27_13.2_public_f45ea9d1275d61eeec0ada69f05bab62.nii.gz",
    "HC-Transsubiculum (Hippocampus) - left hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/HC-Transsubiculum/HC-Transsubiculum_pmap_l_N10_nlin2Stdcolin27_13.2_public_97ffe2e3d8928341ca69ddfd07e93cda.nii.gz",
    "IF.ice (Amygdala) - left hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/IF.ice/IF.ice_pmap_l_N10_nlin2Stdcolin27_8.2_publicP_6777b1725f08bd6ec9155b450a2a83a6.nii.gz",
    "IF.iol (Amygdala) - left hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/IF.iol/IF.iol_pmap_l_N10_nlin2Stdcolin27_8.2_publicP_2be8d042f061f038c0cc712dc086d1fc.nii.gz",
    "IF.ld (Amygdala) - left hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/IF.ld/IF.ld_pmap_l_N10_nlin2Stdcolin27_8.2_publicP_5e1ea01a40100e46a30201a156d965c7.nii.gz",
    "Interposed Nucleus (Cerebellum) - left hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/Interposed-Nucleus/Interposed-Nucleus_pmap_l_N10_nlin2Stdcolin27_6.3_public_a69f95726d7cb674eed905fd55f5b78a.nii.gz",
    "LB.Bl (Amygdala) - left hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/LB.Bl/LB.Bl_pmap_l_N10_nlin2Stdcolin27_8.2_publicP_80ac7dac784793189f28ea20b480c5c4.nii.gz",
    "LB.Bm (Amygdala) - left hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/LB.Bm/LB.Bm_pmap_l_N10_nlin2Stdcolin27_8.2_publicP_8e49eb0fdbc70173260fee7f7a15a9fa.nii.gz",
    "LB.La (Amygdala) - left hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/LB.La/LB.La_pmap_l_N10_nlin2Stdcolin27_8.2_publicP_bab12bf495fac605f241acc3112bddd9.nii.gz",
    "LB.Pl (Amygdala) - left hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/LB.Pl/LB.Pl_pmap_l_N10_nlin2Stdcolin27_8.2_publicP_5b78e56ab18cdc3e06c356674ece7da3.nii.gz",
    "MF.icm (Amygdala) - left hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/MF.icm/MF.icm_pmap_l_N10_nlin2Stdcolin27_8.2_publicP_eb7b1e9f03a512d59f62060095693f68.nii.gz",
    "MF.lm (Amygdala) - left hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/MF.lm/MF.lm_pmap_l_N10_nlin2Stdcolin27_8.2_publicP_a197c0bec2d97fe5669911827b5872d4.nii.gz",
    "SF.AHi (Amygdala) - left hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/SF.AHi/SF.AHi_pmap_l_N10_nlin2Stdcolin27_8.2_publicP_c96ee0245f9b417e539bc872f77036da.nii.gz",
    "SF.APir (Amygdala) - left hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/SF.APir/SF.APir_pmap_l_N10_nlin2Stdcolin27_8.2_publicP_0397374a5ecf0fcc9962f8bb25c2e5e6.nii.gz",
    "SF.VCo (Amygdala) - left hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/SF.VCo/SF.VCo_pmap_l_N10_nlin2Stdcolin27_8.2_publicP_669c5107fa199451586191a949e1c90f.nii.gz",
    "STN (Subthalamus) - left hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/STN/STN_pmap_l_N10_nlin2Stdcolin27_5.0_public_933919932729bf767a29a5e9ed109890.nii.gz",
    "Subiculum.PaS (Hippocampus) - left hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/Subiculum.PaS/Subiculum.PaS_pmap_l_N10_nlin2Stdcolin27_13.2_publicP_aee6402ca4a0ddc7106e0559c602393b.nii.gz",
    "Subiculum.PreS (Hippocampus) - left hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/Subiculum.PreS/Subiculum.PreS_pmap_l_N10_nlin2Stdcolin27_13.2_publicP_f122dc4e91ea2d35c379b049e52384f2.nii.gz",
    "Subiculum.ProS (Hippocampus) - left hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/Subiculum.ProS/Subiculum.ProS_pmap_l_N10_nlin2Stdcolin27_13.2_publicP_2864f44ca243a72d08eab51a09d652ac.nii.gz",
    "Subiculum.Sub (Hippocampus) - left hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/Subiculum.Sub/Subiculum.Sub_pmap_l_N10_nlin2Stdcolin27_13.2_publicP_23e4881868a686910a2ef2ddb744bdbb.nii.gz",
    "Temporal-to-Parietal (GapMap) - left hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/Temporal-to-Parietal/Temporal-to-Parietal_pmap_l_N10_nlin2Stdcolin27_11.4_public_6419ad510d07f169d22f36c86e1087dc.nii.gz",
    "Terminal islands (Basal Forebrain) - left hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/Terminal-islands/Terminal-islands_pmap_l_N10_nlin2Stdcolin27_4.0_public_5a3b42aa37df625defb3d54af086db6b.nii.gz",
    "Tuberculum (Basal Forebrain) - left hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/Tuberculum/Tuberculum_pmap_l_N10_nlin2Stdcolin27_4.0_public_bb838d2ec9ddb731897633610b3a8d36.nii.gz",
    "VP (Ventral Pallidum) - left hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/VP/VP_pmap_l_N10_nlin2Stdcolin27_5.0_public_6a491fbeb743d9c1ba024f61a488f3d2.nii.gz",
    "VTM (Amygdala) - left hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/VTM/VTM_pmap_l_N10_nlin2Stdcolin27_8.2_public_fe720f60bf19ee96d70c2c3ac9ea5630.nii.gz",
    "Ventral Dentate Nucleus (Cerebellum) - left hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/Ventral-Dentate-Nucleus/Ventral-Dentate-Nucleus_pmap_l_N10_nlin2Stdcolin27_6.3_public_ddea164f554cdf58706097c90d2f4517.nii.gz",
    "AcbL (Lateral Accumbens, Ventral Striatum) - right hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/AcbL/AcbL_pmap_r_N10_nlin2Stdcolin27_5.0_public_482f83e1200519b8a66ebff27aa7705e.nii.gz",
    "AcbM (Medial Accumbens, Ventral Striatum) - right hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/AcbM/AcbM_pmap_r_N10_nlin2Stdcolin27_5.0_public_90c6b6365e5a6d1ce0e395cc15e3c945.nii.gz",
    "Area 1 (PostCG) - right hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/Area-1/Area-1_pmap_r_N10_nlin2Stdcolin27_12.1_public_9c1529cb2a30ee86e6cd6442dddf6bec.nii.gz",
    "Area 25.25a (sACC) - right hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/Area-25.25a/Area-25.25a_pmap_r_N10_nlin2Stdcolin27_20.1_publicP_5efda1aa2f9ec000b9af10ea9d125886.nii.gz",
    "Area 25.25p (sACC) - right hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/Area-25.25p/Area-25.25p_pmap_r_N10_nlin2Stdcolin27_20.1_publicP_c89f46c3bb8109bfc135802ec8b26c1b.nii.gz",
    "Area 2 (PostCS) - right hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/Area-2/Area-2_pmap_r_N10_nlin2Stdcolin27_7.1_public_21107ae4dcab2686b31b9cba4d8b426c.nii.gz",
    "Area 33 (ACC) - right hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/Area-33/Area-33_pmap_r_N10_nlin2Stdcolin27_20.1_public_333f36b91ef2031fb9debbbd1a9ea190.nii.gz",
    "Area 3a (PostCG) - right hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/Area-3a/Area-3a_pmap_r_N10_nlin2Stdcolin27_12.1_public_82cf26c72a85d3589896958d4272eff7.nii.gz",
    "Area 3b (PostCG) - right hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/Area-3b/Area-3b_pmap_r_N10_nlin2Stdcolin27_12.1_public_fbb2282b00af2669750f5000cecc64d0.nii.gz",
    "Area 44 (IFG) - right hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/Area-44/Area-44_pmap_r_N10_nlin2Stdcolin27_9.2_public_e64be012d7698a7b363b9373e19405b3.nii.gz",
    "Area 45 (IFG) - right hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/Area-45/Area-45_pmap_r_N10_nlin2Stdcolin27_9.2_public_42debf617a6dc9ccc9062ec11854f9f7.nii.gz",
    "Area 4a (PreCG) - right hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/Area-4a/Area-4a_pmap_r_N10_nlin2Stdcolin27_13.1_public_374855fb44bb92e37fee627233c9995d.nii.gz",
    "Area 4p (PreCG) - right hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/Area-4p/Area-4p_pmap_r_N10_nlin2Stdcolin27_13.1_public_0b4eca02b7773d2f8eca2d380a141ddc.nii.gz",
    "Area 5Ci (SPL) - right hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/Area-5Ci/Area-5Ci_pmap_r_N10_nlin2Stdcolin27_9.2_public_0aab2e013e12dda8359128b9847f3c9f.nii.gz",
    "Area 5L (SPL) - right hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/Area-5L/Area-5L_pmap_r_N10_nlin2Stdcolin27_9.2_public_6f5612c4aaac62340ab052659a87ffde.nii.gz",
    "Area 5M (SPL) - right hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/Area-5M/Area-5M_pmap_r_N10_nlin2Stdcolin27_9.2_public_16bcdc2ffe60a86966bce86c44f95984.nii.gz",
    "Area 6d1 (PreCG) - right hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/Area-6d1/Area-6d1_pmap_r_N10_nlin2Stdcolin27_7.1_public_60eb3c73c42fbd24bca0af0bee702da1.nii.gz",
    "Area 6d2 (PreCG) - right hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/Area-6d2/Area-6d2_pmap_r_N10_nlin2Stdcolin27_7.1_public_1da21814cbe7b15bc3094b91cfa57d32.nii.gz",
    "Area 6d3 (SFS) - right hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/Area-6d3/Area-6d3_pmap_r_N10_nlin2Stdcolin27_7.1_public_be9e7ce0ea7dea3782c30e1715104ebd.nii.gz",
    "Area 6ma (preSMA, mesial SFG) - right hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/Area-6ma/Area-6ma_pmap_r_N10_nlin2Stdcolin27_12.1_public_fdd1748594ed36a32679921c0ff24b12.nii.gz",
    "Area 6mp (SMA, mesial SFG) - right hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/Area-6mp/Area-6mp_pmap_r_N10_nlin2Stdcolin27_12.1_public_00f507cf4b38c3df6775be5f64057e03.nii.gz",
    "Area 7A (SPL) - right hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/Area-7A/Area-7A_pmap_r_N10_nlin2Stdcolin27_9.2_public_d93c43966cc6829c21d82a01f9437bac.nii.gz",
    "Area 7M (SPL) - right hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/Area-7M/Area-7M_pmap_r_N10_nlin2Stdcolin27_9.2_public_d612d3f68be04af61f68f4f9ffcfe23a.nii.gz",
    "Area 7P (SPL) - right hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/Area-7P/Area-7P_pmap_r_N10_nlin2Stdcolin27_9.2_public_91a3305bf392f834d0c536fe1fabab2f.nii.gz",
    "Area 7PC (SPL) - right hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/Area-7PC/Area-7PC_pmap_r_N10_nlin2Stdcolin27_9.2_public_438ccbc483fca0755306d173346b03f1.nii.gz",
    "Area 8d1 (SFG) - right hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/Area-8d1/Area-8d1_pmap_r_N10_nlin2Stdcolin27_4.2_public_b8971b0a45e2f131fdb353e61d6f6e61.nii.gz",
    "Area 8d2 (SFG) - right hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/Area-8d2/Area-8d2_pmap_r_N10_nlin2Stdcolin27_4.2_public_2b82698db6ba3087530a21585a1a4944.nii.gz",
    "Area 8v1 (MFG) - right hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/Area-8v1/Area-8v1_pmap_r_N10_nlin2Stdcolin27_4.2_public_b5bb03803bfb661fc5dad93e4d3670ab.nii.gz",
    "Area 8v2 (MFG) - right hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/Area-8v2/Area-8v2_pmap_r_N10_nlin2Stdcolin27_4.2_public_3f49192ae703505e469d2a47f2ade792.nii.gz",
    "Area CoS1 (CoS) - right hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/Area-CoS1/Area-CoS1_pmap_r_N10_nlin2Stdcolin27_7.2_public_ef1f080be58d0db9c9336843b127ac7b.nii.gz",
    "Area FG1 (FusG) - right hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/Area-FG1/Area-FG1_pmap_r_N10_nlin2Stdcolin27_3.2_public_0496a799320d5742f9d13861dd52f295.nii.gz",
    "Area FG2 (FusG) - right hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/Area-FG2/Area-FG2_pmap_r_N10_nlin2Stdcolin27_3.2_public_cbee4d0793539c4a5036b8874e84d14c.nii.gz",
    "Area FG3 (FusG) - right hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/Area-FG3/Area-FG3_pmap_r_N10_nlin2Stdcolin27_7.2_public_fdcd219c22295f776fd94cfb74d0d693.nii.gz",
    "Area FG4 (FusG) - right hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/Area-FG4/Area-FG4_pmap_r_N10_nlin2Stdcolin27_7.2_public_0c59996946bd9183e6294ed9a3db3682.nii.gz",
    "Area Fo1 (OFC) - right hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/Area-Fo1/Area-Fo1_pmap_r_N10_nlin2Stdcolin27_5.2_public_dfd189766f6a1f5eafc6690e3ef3bbd7.nii.gz",
    "Area Fo2 (OFC) - right hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/Area-Fo2/Area-Fo2_pmap_r_N10_nlin2Stdcolin27_5.2_public_d102385f8738ef6f2d329496cf26b576.nii.gz",
    "Area Fo3 (OFC) - right hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/Area-Fo3/Area-Fo3_pmap_r_N10_nlin2Stdcolin27_5.2_public_5624efc582d8e468307993b0ded5a962.nii.gz",
    "Area Fo4 (OFC) - right hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/Area-Fo4/Area-Fo4_pmap_r_N10_nlin2Stdcolin27_3.2_public_8aa448ef897ed0be3fa1b27545c5ba3d.nii.gz",
    "Area Fo5 (OFC) - right hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/Area-Fo5/Area-Fo5_pmap_r_N10_nlin2Stdcolin27_3.2_public_374cb906591ab265fdecf88edf4a601d.nii.gz",
    "Area Fo6 (OFC) - right hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/Area-Fo6/Area-Fo6_pmap_r_N10_nlin2Stdcolin27_3.2_public_ea2a5f8bf4afa6ecbc3b20c3d1da7862.nii.gz",
    "Area Fo7 (OFC) - right hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/Area-Fo7/Area-Fo7_pmap_r_N10_nlin2Stdcolin27_3.2_public_4732d901d3b444191112cb481bb6f402.nii.gz",
    "Area Fp1 (FPole) - right hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/Area-Fp1/Area-Fp1_pmap_r_N10_nlin2Stdcolin27_5.1_public_ce310fa501f9e7cd7237cc3d0828a53b.nii.gz",
    "Area Fp2 (FPole) - right hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/Area-Fp2/Area-Fp2_pmap_r_N10_nlin2Stdcolin27_5.1_public_270f779e72bc5d2a24e3c1b141701ee2.nii.gz",
    "Area IFJ1 (IFS,PreCS) - right hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/Area-IFJ1/Area-IFJ1_pmap_r_N10_nlin2Stdcolin27_3.2_public_4bd137f8250acdada24fb549de334fc2.nii.gz",
    "Area IFJ2 (IFS,PreCS) - right hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/Area-IFJ2/Area-IFJ2_pmap_r_N10_nlin2Stdcolin27_3.2_public_0ec3afbe78f92b1fce1e28302665f8f9.nii.gz",
    "Area IFS1 (IFS) - right hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/Area-IFS1/Area-IFS1_pmap_r_N10_nlin2Stdcolin27_3.2_public_38fffa2f0f2b17bb2c11f445f253a520.nii.gz",
    "Area IFS2 (IFS) - right hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/Area-IFS2/Area-IFS2_pmap_r_N10_nlin2Stdcolin27_3.2_public_275b82921d9b3d967f19610615479b0d.nii.gz",
    "Area IFS3 (IFS) - right hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/Area-IFS3/Area-IFS3_pmap_r_N10_nlin2Stdcolin27_3.2_public_703a1fcfb74537bb54b8ab89de0be335.nii.gz",
    "Area IFS4 (IFS) - right hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/Area-IFS4/Area-IFS4_pmap_r_N10_nlin2Stdcolin27_3.2_public_7b8649a9938572f85d719094f6df5762.nii.gz",
    "Area Ia1 (Insula) - right hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/Area-Ia1/Area-Ia1_pmap_r_N10_nlin2Stdcolin27_5.1_public_94743dca18ee270b0135303068e9de94.nii.gz",
    "Area Ia2 (Insula) - right hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/Area-Ia2/Area-Ia2_pmap_r_N10_nlin2Stdcolin27_4.0_public_542992ec41160147868bb3b61060df42.nii.gz",
    "Area Ia3 (Insula) - right hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/Area-Ia3/Area-Ia3_pmap_r_N10_nlin2Stdcolin27_4.0_public_a18943163e17e47dccc464db6a33e71c.nii.gz",
    "Area Id10 (Insula) - right hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/Area-Id10/Area-Id10_pmap_r_N10_nlin2Stdcolin27_4.0_public_15b447abd44f24d9e97d5a991ee33ae2.nii.gz",
    "Area Id1 (Insula) - right hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/Area-Id1/Area-Id1_pmap_r_N10_nlin2Stdcolin27_14.2_public_c9bc1717e3f246e7e8953591e7374a4e.nii.gz",
    "Area Id2 (Insula) - right hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/Area-Id2/Area-Id2_pmap_r_N10_nlin2Stdcolin27_9.1_public_0a62d13226b0c3565fb79e18c35d63aa.nii.gz",
    "Area Id3 (Insula) - right hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/Area-Id3/Area-Id3_pmap_r_N10_nlin2Stdcolin27_9.1_public_dcb41eb09522a7cd2f507e2f9321381e.nii.gz",
    "Area Id4 (Insula) - right hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/Area-Id4/Area-Id4_pmap_r_N10_nlin2Stdcolin27_5.1_public_09afbdc3dc7cb2b6694f5c5413c44fed.nii.gz",
    "Area Id5 (Insula) - right hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/Area-Id5/Area-Id5_pmap_r_N10_nlin2Stdcolin27_5.1_public_787f3e3d2af8489b14e136a622ede88f.nii.gz",
    "Area Id6 (Insula) - right hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/Area-Id6/Area-Id6_pmap_r_N10_nlin2Stdcolin27_5.1_public_d45e0d65a76a76934d5643ea00c82c03.nii.gz",
    "Area Id7 (Insula) - right hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/Area-Id7/Area-Id7_pmap_r_N10_nlin2Stdcolin27_8.1_public_4147b5478cebb305f557f7821f3c29d2.nii.gz",
    "Area Id8 (Insula) - right hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/Area-Id8/Area-Id8_pmap_r_N10_nlin2Stdcolin27_4.0_public_c9415aa990201f5e3e23a233e67f3ad8.nii.gz",
    "Area Id9 (Insula) - right hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/Area-Id9/Area-Id9_pmap_r_N10_nlin2Stdcolin27_4.0_public_15b434839db4faf3af73779e81c7b2c3.nii.gz",
    "Area Ig1 (Insula) - right hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/Area-Ig1/Area-Ig1_pmap_r_N10_nlin2Stdcolin27_14.2_public_abe70671418d4ab641ebb5c57cf5c864.nii.gz",
    "Area Ig2 (Insula) - right hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/Area-Ig2/Area-Ig2_pmap_r_N10_nlin2Stdcolin27_14.2_public_9a7a17f0ba12cde5ba63a5f461778268.nii.gz",
    "Area Ig3 (Insula) - right hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/Area-Ig3/Area-Ig3_pmap_r_N10_nlin2Stdcolin27_5.1_public_d1bea543d09dc8fa50e02a1a12014e11.nii.gz",
    "Area MFG1 (MFG) - right hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/Area-MFG1/Area-MFG1_pmap_r_N10_nlin2Stdcolin27_9.0_public_4488b8a809fbb417a478f441f74ef8ca.nii.gz",
    "Area MFG2 (MFG) - right hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/Area-MFG2/Area-MFG2_pmap_r_N10_nlin2Stdcolin27_9.0_public_42b40d2cab2da1ca51fa66d8f52e60ce.nii.gz",
    "Area OP1 (POperc) - right hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/Area-OP1/Area-OP1_pmap_r_N10_nlin2Stdcolin27_12.2_public_310e29a800afaec4d777714418f70509.nii.gz",
    "Area OP2 (POperc) - right hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/Area-OP2/Area-OP2_pmap_r_N10_nlin2Stdcolin27_12.2_public_709d2b22ef5e0d420f042e172c407595.nii.gz",
    "Area OP3 (POperc) - right hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/Area-OP3/Area-OP3_pmap_r_N10_nlin2Stdcolin27_12.2_public_4c463ff14db5054ea55bdfc44f3f4c3f.nii.gz",
    "Area OP4 (POperc) - right hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/Area-OP4/Area-OP4_pmap_r_N10_nlin2Stdcolin27_12.2_public_e08945fc38646d2c6ea6d8031eab1516.nii.gz",
    "Area Op5 (Frontal Operculum) - right hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/Area-Op5/Area-Op5_pmap_r_N10_nlin2Stdcolin27_3.2_public_0b4a05e69278b86b70b1004a7c89bd3d.nii.gz",
    "Area Op6 (Frontal Operculum) - right hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/Area-Op6/Area-Op6_pmap_r_N10_nlin2Stdcolin27_3.2_public_b61132bb1a66e027ef07e721910cf6a6.nii.gz",
    "Area Op7 (Frontal Operculum) - right hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/Area-Op7/Area-Op7_pmap_r_N10_nlin2Stdcolin27_3.2_public_8ff9da9d604c1be78817afd0165063e5.nii.gz",
    "Area Op8 (Frontal Operculum) - right hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/Area-Op8/Area-Op8_pmap_r_N10_nlin2Stdcolin27_6.2_public_13eb630733525d7cc0d1f7d1038bbcc5.nii.gz",
    "Area Op9 (Frontal Operculum) - right hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/Area-Op9/Area-Op9_pmap_r_N10_nlin2Stdcolin27_6.2_public_0499f0fc1b057199d76b392d589a8049.nii.gz",
    "Area PF (IPL) - right hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/Area-PF/Area-PF_pmap_r_N10_nlin2Stdcolin27_11.2_public_bb7ecaabdff4e6d44b028e9490d90a79.nii.gz",
    "Area PFcm (IPL) - right hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/Area-PFcm/Area-PFcm_pmap_r_N10_nlin2Stdcolin27_11.2_public_3f808b4121b14ab96be6ddd90470f386.nii.gz",
    "Area PFm (IPL) - right hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/Area-PFm/Area-PFm_pmap_r_N10_nlin2Stdcolin27_11.2_public_6c8a9e109e30fd4a38bf7fa2549face7.nii.gz",
    "Area PFop (IPL) - right hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/Area-PFop/Area-PFop_pmap_r_N10_nlin2Stdcolin27_11.2_public_bc7421cc2e7e52bd4e9ac4f5c67faa93.nii.gz",
    "Area PFt (IPL) - right hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/Area-PFt/Area-PFt_pmap_r_N10_nlin2Stdcolin27_11.2_public_2bd603cad9ea3c1ade7c864675163921.nii.gz",
    "Area PGa (IPL) - right hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/Area-PGa/Area-PGa_pmap_r_N10_nlin2Stdcolin27_11.2_public_dcba73a67276727558b4e6f48320960e.nii.gz",
    "Area PGp (IPL) - right hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/Area-PGp/Area-PGp_pmap_r_N10_nlin2Stdcolin27_11.2_public_7aad7b16e09e86946787936e67bcc2b4.nii.gz",
    "Area Ph1 (PhG) - right hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/Area-Ph1/Area-Ph1_pmap_r_N10_nlin2Stdcolin27_7.2_public_9d27e0a11d0ff40d712bedcab676a438.nii.gz",
    "Area Ph2 (PhG) - right hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/Area-Ph2/Area-Ph2_pmap_r_N10_nlin2Stdcolin27_7.2_public_a8d4ca874d7058dc06c8cba2b9e026ed.nii.gz",
    "Area Ph3 (PhG) - right hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/Area-Ph3/Area-Ph3_pmap_r_N10_nlin2Stdcolin27_7.2_public_dfd1c8476804c1fc3784f8f42d03999e.nii.gz",
    "Area SFS1 (SFS) - right hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/Area-SFS1/Area-SFS1_pmap_r_N10_nlin2Stdcolin27_9.0_public_ec6c66ab92a89277a744274b832003c0.nii.gz",
    "Area SFS2 (SFS) - right hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/Area-SFS2/Area-SFS2_pmap_r_N10_nlin2Stdcolin27_9.0_public_e80e63c8e74723c5b47c4a685790ee37.nii.gz",
    "Area STS1 (STS) - right hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/Area-STS1/Area-STS1_pmap_r_N10_nlin2Stdcolin27_5.3_public_ba2af2fc5b0a333770161252a4e585e6.nii.gz",
    "Area STS2 (STS) - right hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/Area-STS2/Area-STS2_pmap_r_N10_nlin2Stdcolin27_5.3_public_d57f94136109ef7af5373ad33fd9163e.nii.gz",
    "Area TE 1.0 (HESCHL) - right hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/Area-TE-1.0/Area-TE-1.0_pmap_r_N10_nlin2Stdcolin27_6.2_public_0f6a081caa3f20a185157ace40748db6.nii.gz",
    "Area TE 1.1 (HESCHL) - right hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/Area-TE-1.1/Area-TE-1.1_pmap_r_N10_nlin2Stdcolin27_6.2_public_398ba1369f8bf46e8f0a3b4e4c5444d3.nii.gz",
    "Area TE 1.2 (HESCHL) - right hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/Area-TE-1.2/Area-TE-1.2_pmap_r_N10_nlin2Stdcolin27_6.2_public_c09fdc082e938888beea815aca594406.nii.gz",
    "Area TE 2.1 (STG) - right hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/Area-TE-2.1/Area-TE-2.1_pmap_r_N10_nlin2Stdcolin27_6.2_public_b73295ab0d75186041f702c9e3d79a14.nii.gz",
    "Area TE 2.2 (STG) - right hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/Area-TE-2.2/Area-TE-2.2_pmap_r_N10_nlin2Stdcolin27_6.2_public_20afb712ed258c64a3cc48c7f5c9e156.nii.gz",
    "Area TE 3 (STG) - right hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/Area-TE-3/Area-TE-3_pmap_r_N10_nlin2Stdcolin27_6.2_public_c5c302c4ace880a723a9cba5479ed668.nii.gz",
    "Area TI (STG) - right hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/Area-TI/Area-TI_pmap_r_N10_nlin2Stdcolin27_6.2_public_656bbacca9ec4cbe8a07d1ea461d8a63.nii.gz",
    "Area TPJ (STG/SMG) - right hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/Area-TPJ/Area-TPJ_pmap_r_N10_nlin2Stdcolin27_6.2_public_8e5fd1cd13cf15ea4ef7ea7a62a28b96.nii.gz",
    "Area TeI (STG) - right hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/Area-TeI/Area-TeI_pmap_r_N10_nlin2Stdcolin27_6.2_public_2d27ff3d009f434b0bbf4c766f5bef03.nii.gz",
    "Area hIP1 (IPS) - right hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/Area-hIP1/Area-hIP1_pmap_r_N10_nlin2Stdcolin27_7.2_public_076041c8de858b80e59f7618089d60e6.nii.gz",
    "Area hIP2 (IPS) - right hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/Area-hIP2/Area-hIP2_pmap_r_N10_nlin2Stdcolin27_7.2_public_54c63e31f2bdb752de91697793d5f4cb.nii.gz",
    "Area hIP3 (IPS) - right hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/Area-hIP3/Area-hIP3_pmap_r_N10_nlin2Stdcolin27_9.2_public_a085108a03f7d9de549f3607d280646c.nii.gz",
    "Area hIP4 (IPS) - right hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/Area-hIP4/Area-hIP4_pmap_r_N10_nlin2Stdcolin27_7.3_public_12e6215449548fb4428216e5fd90f0a8.nii.gz",
    "Area hIP5 (IPS) - right hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/Area-hIP5/Area-hIP5_pmap_r_N10_nlin2Stdcolin27_7.3_public_52d574566ec8279bca137f9b486de27e.nii.gz",
    "Area hIP6 (IPS) - right hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/Area-hIP6/Area-hIP6_pmap_r_N10_nlin2Stdcolin27_7.3_public_36e4aad9cb8bb398cdffd1019faec4e8.nii.gz",
    "Area hIP7 (IPS) - right hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/Area-hIP7/Area-hIP7_pmap_r_N10_nlin2Stdcolin27_7.3_public_e863eb7756207650005c4d68a92d82a1.nii.gz",
    "Area hIP8 (IPS) - right hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/Area-hIP8/Area-hIP8_pmap_r_N10_nlin2Stdcolin27_7.3_public_b5688e899a78ab1988a0c697d3d19346.nii.gz",
    "Area hOc1 (V1, 17, CalcS) - right hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/Area-hOc1/Area-hOc1_pmap_r_N10_nlin2Stdcolin27_4.2_public_621c6ff06192e91defe6cf463d81e0a9.nii.gz",
    "Area hOc2 (V2, 18) - right hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/Area-hOc2/Area-hOc2_pmap_r_N10_nlin2Stdcolin27_4.2_public_b7d5950dc12f38605f32fc07851bd03f.nii.gz",
    "Area hOc3d (Cuneus) - right hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/Area-hOc3d/Area-hOc3d_pmap_r_N10_nlin2Stdcolin27_4.2_public_70704b6acaecc356d409dad02c673e7e.nii.gz",
    "Area hOc3v (LingG) - right hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/Area-hOc3v/Area-hOc3v_pmap_r_N10_nlin2Stdcolin27_5.2_public_4c20b044274ed18e909c2ae6d3a8c90c.nii.gz",
    "Area hOc4d (Cuneus) - right hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/Area-hOc4d/Area-hOc4d_pmap_r_N10_nlin2Stdcolin27_4.2_public_e27098c9264065fd2957e121f5a8c73c.nii.gz",
    "Area hOc4la (LOC) - right hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/Area-hOc4la/Area-hOc4la_pmap_r_N10_nlin2Stdcolin27_5.2_public_bc2b8551ae0405f8380a6250a278bb55.nii.gz",
    "Area hOc4lp (LOC) - right hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/Area-hOc4lp/Area-hOc4lp_pmap_r_N10_nlin2Stdcolin27_5.2_public_a6cbed7398255aceeee383fbc13f40a8.nii.gz",
    "Area hOc4v (LingG) - right hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/Area-hOc4v/Area-hOc4v_pmap_r_N10_nlin2Stdcolin27_5.2_public_89509f1467d326dff746efed579e07d6.nii.gz",
    "Area hOc5 (LOC) - right hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/Area-hOc5/Area-hOc5_pmap_r_N10_nlin2Stdcolin27_4.2_public_10476c3a637efc2a4b035efae20fe992.nii.gz",
    "Area hOc6 (POS) - right hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/Area-hOc6/Area-hOc6_pmap_r_N10_nlin2Stdcolin27_7.3_public_05e018263c0f1a4feb8fd35950273e87.nii.gz",
    "Area hPO1 (POS) - right hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/Area-hPO1/Area-hPO1_pmap_r_N10_nlin2Stdcolin27_7.3_public_56672dc5c107d60723e3cb94e307bcdd.nii.gz",
    "Area p24ab.p24a (pACC) - right hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/Area-p24ab.p24a/Area-p24ab.p24a_pmap_r_N10_nlin2Stdcolin27_20.1_publicP_322034494134e901dc8b6424f089e064.nii.gz",
    "Area p24ab.p24b (pACC) - right hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/Area-p24ab.p24b/Area-p24ab.p24b_pmap_r_N10_nlin2Stdcolin27_20.1_publicP_001aeae3e6f6693f282f613b581642d2.nii.gz",
    "Area p24c.pd24cd (pACC) - right hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/Area-p24c.pd24cd/Area-p24c.pd24cd_pmap_r_N10_nlin2Stdcolin27_20.1_publicP_4a7abe57ceeeba8e679dcee4df563aef.nii.gz",
    "Area p24c.pd24cv (pACC) - right hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/Area-p24c.pd24cv/Area-p24c.pd24cv_pmap_r_N10_nlin2Stdcolin27_20.1_publicP_14126346e9eacec70e62253c58151219.nii.gz",
    "Area p24c.pv24c (pACC) - right hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/Area-p24c.pv24c/Area-p24c.pv24c_pmap_r_N10_nlin2Stdcolin27_20.1_publicP_1d83bb07990c1f773b3c33d6f97c10a2.nii.gz",
    "Area p32 (pACC) - right hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/Area-p32/Area-p32_pmap_r_N10_nlin2Stdcolin27_20.1_public_b8e78064d88981503f0ab68f1c1a5d66.nii.gz",
    "Area s24.s24a (sACC) - right hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/Area-s24.s24a/Area-s24.s24a_pmap_r_N10_nlin2Stdcolin27_20.1_publicP_5de97799c2ac239fcd9465555fac17a2.nii.gz",
    "Area s24.s24b (sACC) - right hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/Area-s24.s24b/Area-s24.s24b_pmap_r_N10_nlin2Stdcolin27_20.1_publicP_550f187db366f23361c4035f036208d3.nii.gz",
    "Area s32 (sACC) - right hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/Area-s32/Area-s32_pmap_r_N10_nlin2Stdcolin27_20.1_public_06271811aa3f5b71b1908089c8fcdd9a.nii.gz",
    "BST (Bed Nucleus) - right hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/BST/BST_pmap_r_N10_nlin2Stdcolin27_6.1_public_4f33034bb3d9db0abdb644d626de2751.nii.gz",
    "CA1 (Hippocampus) - right hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/CA1/CA1_pmap_r_N10_nlin2Stdcolin27_13.2_public_484e092f3482797f3a3c8c94f37466c3.nii.gz",
    "CA2 (Hippocampus) - right hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/CA2/CA2_pmap_r_N10_nlin2Stdcolin27_13.2_public_6719e25798892ca8cf22bb2890646403.nii.gz",
    "CA3 (Hippocampus) - right hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/CA3/CA3_pmap_r_N10_nlin2Stdcolin27_13.2_public_f55323d52cac86f70c70c3af63552746.nii.gz",
    "CGL (Metathalamus) - right hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/CGL/CGL_pmap_r_N10_nlin2Stdcolin27_10.0_public_555c33f4511047f02f65f266e3c1ab5d.nii.gz",
    "CGM (Metathalamus) - right hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/CGM/CGM_pmap_r_N10_nlin2Stdcolin27_10.0_public_f0aa2e8515da3abe4937f52a60122383.nii.gz",
    "CM.AAA (Amygdala) - right hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/CM.AAA/CM.AAA_pmap_r_N10_nlin2Stdcolin27_8.2_publicP_e2883d8c5e2afd692815df56e4d6f503.nii.gz",
    "CM.Ce (Amygdala) - right hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/CM.Ce/CM.Ce_pmap_r_N10_nlin2Stdcolin27_8.2_publicP_dd7826a0b17404090c2c5f2a0df15dac.nii.gz",
    "CM.Me (Amygdala) - right hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/CM.Me/CM.Me_pmap_r_N10_nlin2Stdcolin27_8.2_publicP_78da0bebbba7cda724fe1f3381e5d7ad.nii.gz",
    "Ch 123 (Basal Forebrain) - right hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/Ch-123/Ch-123_pmap_r_N10_nlin2Stdcolin27_4.3_public_7a6ddcc313ecc2c4542f35fae437b1e3.nii.gz",
    "Ch 4 (Basal Forebrain) - right hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/Ch-4/Ch-4_pmap_r_N10_nlin2Stdcolin27_4.3_public_cd209a3342172b5bb70b19aa5307cb9a.nii.gz",
    "DG (Hippocampus) - right hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/DG/DG_pmap_r_N10_nlin2Stdcolin27_13.2_public_4caa945fb4cf9e05fc43732f770387ca.nii.gz",
    "Dorsal Dentate Nucleus (Cerebellum) - right hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/Dorsal-Dentate-Nucleus/Dorsal-Dentate-Nucleus_pmap_r_N10_nlin2Stdcolin27_6.3_public_98d0908fd38de72f91287f1e4c834f5d.nii.gz",
    "Entorhinal Cortex - right hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/Entorhinal-Cortex/Entorhinal-Cortex_pmap_r_N10_nlin2Stdcolin27_13.2_public_99a0f5a5e5caea70de32b16260afcc74.nii.gz",
    "Fastigial Nucleus (Cerebellum) - right hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/Fastigial-Nucleus/Fastigial-Nucleus_pmap_r_N10_nlin2Stdcolin27_6.3_public_ef4e4de7575d641bf79fdff1a48b6212.nii.gz",
    "Frontal-I (GapMap) - right hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/Frontal-I/Frontal-I_pmap_r_N10_nlin2Stdcolin27_11.4_public_0a7a2600009b10d50e9d8f30ac5329b7.nii.gz",
    "Frontal-II (GapMap) - right hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/Frontal-II/Frontal-II_pmap_r_N10_nlin2Stdcolin27_11.4_public_8152206ff97937c992d1ac00cd947717.nii.gz",
    "Frontal-to-Occipital (GapMap) - right hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/Frontal-to-Occipital/Frontal-to-Occipital_pmap_r_N10_nlin2Stdcolin27_11.4_public_8b8081abca20ea2c9f79290f28c1adf5.nii.gz",
    "Frontal-to-Temporal-I (GapMap) - right hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/Frontal-to-Temporal-I/Frontal-to-Temporal-I_pmap_r_N10_nlin2Stdcolin27_11.4_public_f88e012f6ad4471098eb50c9790cbd6c.nii.gz",
    "Frontal-to-Temporal-II (GapMap) - right hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/Frontal-to-Temporal-II/Frontal-to-Temporal-II_pmap_r_N10_nlin2Stdcolin27_11.4_public_63b7540d93439aade7771a3943e5947b.nii.gz",
    "FuCd (Fundus of Caudate Nucleus, Ventral Striatum) - right hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/FuCd/FuCd_pmap_r_N10_nlin2Stdcolin27_5.0_public_8fe115a20a53b21d405a9a5255059f85.nii.gz",
    "FuP (Fundus of Putamen, Ventral Striatum) - right hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/FuP/FuP_pmap_r_N10_nlin2Stdcolin27_5.0_public_b24d3cb8a2798423ea54fded2f87f053.nii.gz",
    "HATA (Hippocampus) - right hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/HATA/HATA_pmap_r_N10_nlin2Stdcolin27_13.2_public_8f2e32d3454236391124e6695721e214.nii.gz",
    "HC-Transsubiculum (Hippocampus) - right hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/HC-Transsubiculum/HC-Transsubiculum_pmap_r_N10_nlin2Stdcolin27_13.2_public_563d42c9f737d269ff8f91e9f1510c89.nii.gz",
    "IF.ice (Amygdala) - right hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/IF.ice/IF.ice_pmap_r_N10_nlin2Stdcolin27_8.2_publicP_4ac4c75d037254988913341ed5c23975.nii.gz",
    "IF.iol (Amygdala) - right hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/IF.iol/IF.iol_pmap_r_N10_nlin2Stdcolin27_8.2_publicP_8decf081493ee3ab3a98d199efdd4078.nii.gz",
    "IF.ld (Amygdala) - right hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/IF.ld/IF.ld_pmap_r_N10_nlin2Stdcolin27_8.2_publicP_a6cc32b153d27fd12715ebb10386f237.nii.gz",
    "Interposed Nucleus (Cerebellum) - right hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/Interposed-Nucleus/Interposed-Nucleus_pmap_r_N10_nlin2Stdcolin27_6.3_public_e6ac7fffa112ce09d44101ebbe2fbb3d.nii.gz",
    "LB.Bl (Amygdala) - right hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/LB.Bl/LB.Bl_pmap_r_N10_nlin2Stdcolin27_8.2_publicP_301a1f77810fd4120d020ce2cc4b204e.nii.gz",
    "LB.Bm (Amygdala) - right hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/LB.Bm/LB.Bm_pmap_r_N10_nlin2Stdcolin27_8.2_publicP_659363cf6ced78efcb277615399d51ba.nii.gz",
    "LB.La (Amygdala) - right hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/LB.La/LB.La_pmap_r_N10_nlin2Stdcolin27_8.2_publicP_37b9c27be656715bcb45c61009d258f5.nii.gz",
    "LB.Pl (Amygdala) - right hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/LB.Pl/LB.Pl_pmap_r_N10_nlin2Stdcolin27_8.2_publicP_09cac22a214d854ea289c4598d274bb3.nii.gz",
    "MF.icm (Amygdala) - right hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/MF.icm/MF.icm_pmap_r_N10_nlin2Stdcolin27_8.2_publicP_be5c6ce47c28f080c1dd5e3da320863a.nii.gz",
    "MF.lm (Amygdala) - right hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/MF.lm/MF.lm_pmap_r_N10_nlin2Stdcolin27_8.2_publicP_1d74c2b4325eac7de974d47eb441dfd8.nii.gz",
    "SF.AHi (Amygdala) - right hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/SF.AHi/SF.AHi_pmap_r_N10_nlin2Stdcolin27_8.2_publicP_697e76b621bf4004e8e33da640b942b1.nii.gz",
    "SF.APir (Amygdala) - right hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/SF.APir/SF.APir_pmap_r_N10_nlin2Stdcolin27_8.2_publicP_615764ce9e18bf3b88e8a606d9a320ca.nii.gz",
    "SF.VCo (Amygdala) - right hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/SF.VCo/SF.VCo_pmap_r_N10_nlin2Stdcolin27_8.2_publicP_970953a21ce0246ffd53af6333470998.nii.gz",
    "STN (Subthalamus) - right hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/STN/STN_pmap_r_N10_nlin2Stdcolin27_5.0_public_bc0377f4305770926d3beb874360816d.nii.gz",
    "Subiculum.PaS (Hippocampus) - right hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/Subiculum.PaS/Subiculum.PaS_pmap_r_N10_nlin2Stdcolin27_13.2_publicP_f977995caf3fa082c20aee1263b8144a.nii.gz",
    "Subiculum.PreS (Hippocampus) - right hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/Subiculum.PreS/Subiculum.PreS_pmap_r_N10_nlin2Stdcolin27_13.2_publicP_3e8dfacd5b42f5cf6fe702e368fcf561.nii.gz",
    "Subiculum.ProS (Hippocampus) - right hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/Subiculum.ProS/Subiculum.ProS_pmap_r_N10_nlin2Stdcolin27_13.2_publicP_7a776de38afd2b16d43a40ab7fc4de4c.nii.gz",
    "Subiculum.Sub (Hippocampus) - right hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/Subiculum.Sub/Subiculum.Sub_pmap_r_N10_nlin2Stdcolin27_13.2_publicP_400464d8ee3cd5981f8a0818a4f91bd7.nii.gz",
    "Temporal-to-Parietal (GapMap) - right hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/Temporal-to-Parietal/Temporal-to-Parietal_pmap_r_N10_nlin2Stdcolin27_11.4_public_115ca6f617eede28d4e31c63689410d5.nii.gz",
    "Terminal islands (Basal Forebrain) - right hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/Terminal-islands/Terminal-islands_pmap_r_N10_nlin2Stdcolin27_4.0_public_b52e8afb86491fe573a28b5ecd804bdd.nii.gz",
    "Tuberculum (Basal Forebrain) - right hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/Tuberculum/Tuberculum_pmap_r_N10_nlin2Stdcolin27_4.0_public_98cbba2e02b041dc476c537b9ab29ada.nii.gz",
    "VP (Ventral Pallidum) - right hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/VP/VP_pmap_r_N10_nlin2Stdcolin27_5.0_public_c40a4ec7bf5e3aa593a6fa1a61be9498.nii.gz",
    "VTM (Amygdala) - right hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/VTM/VTM_pmap_r_N10_nlin2Stdcolin27_8.2_public_189ce4b17626ae284b4e45662695a2e0.nii.gz",
    "Ventral Dentate Nucleus (Cerebellum) - right hemisphere": "https://data-proxy.ebrains.eu/api/v1/public/buckets/d-d69b70e2-3002-4eaf-9c61-9c56f019bbc8/probabilistic_maps_pmaps_175areas/Ventral-Dentate-Nucleus/Ventral-Dentate-Nucleus_pmap_r_N10_nlin2Stdcolin27_6.3_public_6b33bfed2ba43d92b68944ed0f45446a.nii.gz",
}


def _encode_regionname(regionname: str) -> str:
    return hashlib.md5(regionname.encode("utf-8")).hexdigest()[:6]


def _encode_data(encoded_rname: str, prob: float):
    b = encoded_rname.encode("utf-8")
    assert len(b) == 6
    # 6 bytes + 4 bytes
    return b + struct.pack("<f", prob)

def _decode_data(b: bytes):
    assert len(b) == 10
    return b[:6].decode("utf-8"), struct.unpack("<f", b[6:10])[0]


@pytest.fixture(scope="session")
def local_file():

    name = "foo"
    sess = requests.Session()
    
    def _download(url: str, dest: Union[str, Path]):
        resp = sess.get(url)
        resp.raise_for_status()
        with open(dest, "wb") as fp:
            fp.write(resp.content)

    with TemporaryDirectory() as _dir:
        affine = None
        shape = None

        filenames = [
            (Path(_dir) / _encode_regionname(rname)).with_suffix(".nii.gz")
            for rname in colin27_jba30_hg_maps.keys()
        ]
        with ThreadPoolExecutor() as ex:
            list(
                ex.map(
                    _download,
                    colin27_jba30_hg_maps.values(),
                    filenames
                )
            )
        
        idx_name = Path(_dir) / name

        writable_idx = WritableSpatialIndex(idx_name)

        for f in filenames:
            encoded_rname = f.name.removesuffix(".nii.gz")
            nii: nib.Nifti1Image = nib.load(f)

            if affine is None:
                affine = nii.affine
            else:
                assert np.all(affine == nii.affine)
            
            if shape is None:
                shape = nii.shape
            else:
                assert shape == nii.shape
        
            imgdata = np.asanyarray(nii.dataobj)
            X, Y, Z = [v.astype("int32") for v in np.where(imgdata > 0)]

            data = [
                _encode_data(encoded_rname, prob)
                for x, y, z, prob in zip(X, Y, Z, imgdata[X, Y, Z])
            ]
            writable_idx.write(list(zip(X, Y, Z)), data)

        writable_idx.save(affine=affine, shape=shape)
        yield idx_name

jba30_colin_args = [
    (
        [72, 142, 119],
        {
            "d35d2d": 0.0003129999968223274,
            "c4d406": 0.3191109895706177,
            "6652b2": 0.28016701340675354,
            "943ce3": 9.999999974752427e-07,
            "23e136": 0.0006760000251233578,
            "749a1e": 0.3054789900779724,
            "ef6127": 0.0942310020327568,
            "1f3c97": 2.099999983329326e-05,
        }
    ),
    (
        [136, 216, 111],
        {"a72203": 0.3991990089416504, "ab1fe3": 0.08381400257349014},
    ),
]


@pytest.mark.parametrize(
    "pos, expected",
    [
        *[
            pytest.param(
                [p],
                [ex],
                id=f"single-pos-idx-{idx}"
            )for idx, (p, ex) in enumerate(jba30_colin_args)
        ],
        pytest.param(
            [arg[0] for arg in jba30_colin_args],
            [arg[1] for arg in jba30_colin_args],
            id="merged-array",
        ),
    ],
)
def test_written_spatial_index(pos, expected, local_file: Path):
    idx = ReadableSpatialIndex(local_file)
    lb = idx.read(pos)

    assert len(lb) == len(pos)
    assert len(expected) == len(lb)

    for b, ex in zip(lb, expected):
        assert len(b) % 10 == 0, f"expecting multiple of exactly 10 bytes"
        decoded_d = {}
        while len(b) > 0:
            _b = b[:10]
            rname, prob = _decode_data(_b)
            assert rname not in decoded_d
            decoded_d[rname] = prob
            b = b[10:]

        assert decoded_d == ex