## SSH Key Management
- `ssh_key_management.py`: Generate/manage SSH keys and configure VM for SSH access

## Version Check
- `version_check.sh`: Check installed version of vm_tool
