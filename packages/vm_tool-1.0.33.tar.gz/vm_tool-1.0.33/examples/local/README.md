# Local Examples

Use `template_local_setup.py` as your starting point for any local VM setup scenario. Other files are legacy or specific examples and can be removed if you only want the template.
