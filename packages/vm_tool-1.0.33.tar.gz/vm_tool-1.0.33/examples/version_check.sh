#!/bin/bash
# Check installed version of vm_tool
vm_tool --version
