# Cloud Examples

Use `template_cloud_setup.py` as your starting point for any cloud VM setup scenario. Other files are legacy or specific examples and can be removed if you only want the template.
