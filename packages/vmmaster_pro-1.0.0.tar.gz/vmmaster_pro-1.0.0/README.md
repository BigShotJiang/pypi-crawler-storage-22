# VMMaster

**VMMaster** is a professional, high-level Python library for managing virtual machines, designed to provide an experience similar to **VirtualBox**. It offers a robust API for full VM lifecycle management, advanced storage controllers, and complex network configurations.

## Key Features

- **VirtualBox-like API**: Familiar interface for those who have used VBoxManage or the VirtualBox SDK.
- **Extensive OS Support**: Pre-configured profiles for over 50+ operating systems, including:
  - **Windows**: 11, 10, Server 2022, etc.
  - **Linux**: Ubuntu, Debian, CentOS, Fedora, Arch, etc.
  - **Unix**: FreeBSD, OpenBSD, Solaris.
  - **Others**: macOS, Android-x86, ChromeOS.
- **Advanced Storage**: Support for VDI, VMDK, and VHD formats with snapshot capabilities.
- **Networking**: NAT, Bridged, Host-only, and Internal network modes.
- **Scalability**: Over 40,000 lines of optimized code for enterprise-grade virtualization management.

## Installation

```bash
pip install vmmaster-pro
```

## Quick Start

```python
from vmmaster import create_vbox_instance

# Initialize the VMMaster instance
vbox = create_vbox_instance()

# Create a new Virtual Machine
vm = vbox.get_machine("My_New_VM")
print(f"Managing VM: {vm['name']} - Status: {vm['state']}")
```

## Documentation

Comprehensive documentation is available in the `docs/` folder.

## License

MIT License
