'''
VMMaster: A professional virtual machine management library.
Inspired by VirtualBox, designed for power users.
'''

__version__ = "1.0.0"
__author__ = "User"

from .core.engine import VMEngine
from .core.storage import StorageController
from .network.adapter import NetworkAdapter
from .os_support.profiles import OSRegistry
from .api.vbox_api import VirtualBoxAPI

def create_vbox_instance():
    """Returns a VirtualBox-like API instance."""
    return VirtualBoxAPI()
