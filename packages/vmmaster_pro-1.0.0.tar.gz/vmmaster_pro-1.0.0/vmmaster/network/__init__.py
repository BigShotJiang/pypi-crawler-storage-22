from .adapter import NetworkAdapter
