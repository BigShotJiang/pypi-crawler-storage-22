"""
Text injection module for Vocalinux
"""

from . import text_injector
