# Vocalyx

Real-time voice assistant with Speech-to-Text, GPT, and Text-to-Speech (Soprano TTS).

## Install

```bash
pip install vocalyx
```

## Project structure

All components live in the `vocalyx` package:

- `vocalyx/tts_server` – TTS WebSocket server (Soprano + GPT streaming)
- `vocalyx/stt_server` – STT WebSocket server (RealtimeSTT)
- `vocalyx/client` – Voice assistant client connecting STT and TTS

## Usage

Run in three terminals:

```bash
# Terminal 1
vocalyx-stt

# Terminal 2
vocalyx-tts

# Terminal 3
vocalyx
```

Create a `.env` file with `OPENAI_API_KEY` for GPT streaming.

## Requirements

- Python 3.10+
- `portaudio`, `ffmpeg` (system dependencies)
- Microphone and audio output

## License

MIT
