"""Vocalyx - Real-time voice assistant with STT, GPT, and TTS."""

__version__ = "0.2.1"
