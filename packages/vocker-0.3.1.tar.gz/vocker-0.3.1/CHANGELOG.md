# Changelog

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/).

## [Unreleased]

## [0.3.1] - 2026-02-02

### Changed

- Compress only to LZMA instead of both LZMA and zstandard. Decompression isn't even
  implemented yet for zstandard.

## [0.3.0] - 2026-01-27

### Changed

- Reimplement file deduplication bookkeeping to improve performance by moving most of the
  SQLAlchemy ORM-based logic to SQLAlchemy Core SQL statements. The performance increased by
  a factor of 3.

## [0.2.0] - 2025-12-18

### Changed

- Remove strictyaml dependency and replace with JSON.

## [0.1.0] - 2025-12-17

### Added

- Initial version.
