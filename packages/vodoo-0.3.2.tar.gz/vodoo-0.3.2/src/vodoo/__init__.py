__version__ = "0.3.2"


def hello() -> str:
    return "Hello from vodoo!"
