"""Vodoo — Python library and CLI for Odoo.

Quick start as a library (sync)::

    from vodoo import OdooClient, OdooConfig

    config = OdooConfig(
        url="https://my-instance.odoo.com",
        database="mydb",
        username="bot@example.com",
        password="secret",
    )
    client = OdooClient(config)

    # Domain namespaces on the client
    tickets = client.helpdesk.list(limit=10)
    ticket = client.helpdesk.get(42)
    client.helpdesk.comment(42, "Deployed to staging")

    # Generic client for any model
    partners = client.search_read("res.partner", fields=["name", "email"], limit=5)

Quick start (async)::

    from vodoo import AsyncOdooClient, OdooConfig

    config = OdooConfig(...)

    async with AsyncOdooClient(config) as client:
        tickets = await client.helpdesk.list(limit=10)
        leads = await client.crm.list(limit=5)
"""

from importlib.metadata import PackageNotFoundError, version

try:
    __version__: str = version("vodoo")
except PackageNotFoundError:
    # Editable install without a tag, or running from source checkout
    __version__ = "0.0.0.dev0"

from vodoo.aio.client import AsyncOdooClient
from vodoo.client import OdooClient
from vodoo.config import OdooConfig
from vodoo.content import HTML, Markdown
from vodoo.exceptions import (
    AuthenticationError,
    ConfigurationError,
    FieldParsingError,
    OdooAccessDeniedError,
    OdooAccessError,
    OdooMissingError,
    OdooUserError,
    OdooValidationError,
    RecordNotFoundError,
    RecordOperationError,
    TransportError,
    VodooError,
)
from vodoo.transport import RetryConfig

__all__ = [
    "HTML",
    "AsyncOdooClient",
    "AuthenticationError",
    "ConfigurationError",
    "FieldParsingError",
    "Markdown",
    "OdooAccessDeniedError",
    "OdooAccessError",
    "OdooClient",
    "OdooConfig",
    "OdooMissingError",
    "OdooUserError",
    "OdooValidationError",
    "RecordNotFoundError",
    "RecordOperationError",
    "RetryConfig",
    "TransportError",
    "VodooError",
]
