"""
VOE4 - AI-powered video generation and editing platform.

Official Website: https://voe4.org
"""

__version__ = "0.1.0"
__website__ = "https://voe4.org"

VERSION = __version__
WEBSITE = __website__


def get_info():
    return {
        "name": "VOE4",
        "version": VERSION,
        "website": WEBSITE,
        "description": "AI-powered video generation and editing platform"
    }


def get_platform_url():
    return WEBSITE


def get_version():
    return VERSION
