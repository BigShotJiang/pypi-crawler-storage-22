# CHANGELOG

<!-- version list -->

## v1.0.3 (2026-02-16)

### Bug Fixes

- Add vibecoder script alias alongside voice-vibecoder
  ([`13c6a1c`](https://github.com/snokam/voice-vibecoder/commit/13c6a1c859f3d3463189143d539d5940e901f5bb))


## v1.0.2 (2026-02-16)

### Bug Fixes

- Rename script entry to voice-vibecoder so uvx voice-vibecoder works
  ([`b7933f2`](https://github.com/snokam/voice-vibecoder/commit/b7933f29b9ebd1d532b80b3d61e51d46e66917ae))


## v1.0.1 (2026-02-16)

### Bug Fixes

- Rename PyPI package to voice-vibecoder
  ([`174ddad`](https://github.com/snokam/voice-vibecoder/commit/174ddad9278fd341087af1223e1e45bfdca01f19))


## v1.0.0 (2026-02-16)

- Initial Release
