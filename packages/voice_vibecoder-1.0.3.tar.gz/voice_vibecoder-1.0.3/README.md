# Olaf The Vibecoder

A voice-controlled coding assistant that combines OpenAI's Realtime API for voice conversation with Claude Code for autonomous coding tasks.

## Quick Start

```bash
# Install and run
pip install voice-vibecoder
vibecoder

# Or run directly with uv (no install needed)
uvx voice-vibecoder
```

On first launch, press **s** to configure your OpenAI API key.

## Features

- Voice conversation via OpenAI Realtime API (supports OpenAI and Azure)
- Multi-instance Claude Code agents running in separate git worktrees
- Git diff visualization with file tree and colorized hunks
- Session persistence across restarts
- Push-to-talk and voice activity detection modes
- Multi-language support (English, Norwegian, Swedish)

## Requirements

- Python 3.10+
- An OpenAI API key with Realtime API access
- [PortAudio](http://www.portaudio.com/) for microphone input (`brew install portaudio` on macOS)
- [Claude Code](https://docs.anthropic.com/en/docs/claude-code) CLI installed

## Usage as a Library

Embed the voice coding screen in your own Textual app:

```python
from pathlib import Path
from vibecoder import VoiceCodingApp, VoiceCodingScreen, VoiceConfig

# Standalone app with custom config
config = VoiceConfig(
    app_name="My Coding Assistant",
    config_dir=Path.home() / ".my-app",
    data_dir=Path.home() / ".my-app",
    log_dir=Path.home() / ".my-app" / "logs",
    on_startup=lambda send: send("Hello from startup!"),
)
VoiceCodingApp(config=config).run()

# Or embed the screen in your own Textual app
screen = VoiceCodingScreen(repo_root, config=config)
```

## Configuration

Settings are stored using platform-standard directories:

| Platform | Config | Data | Logs |
|----------|--------|------|------|
| macOS | `~/Library/Application Support/voice-code-assistant/` | `~/Library/Application Support/voice-code-assistant/` | `~/Library/Logs/voice-code-assistant/` |
| Linux | `~/.config/voice-code-assistant/` | `~/.local/share/voice-code-assistant/` | `~/.local/state/voice-code-assistant/log/` |

Git worktrees are created as siblings of your project directory (e.g., `../my-project-feat-login`).

## Keyboard Shortcuts

| Key | Action |
|-----|--------|
| `q` / `Esc` | Quit |
| `m` | Toggle mute |
| `s` | Settings |
| `c` | Cancel current Claude task |
| `Space` | Push-to-talk (when in PTT mode) |

## License

MIT
