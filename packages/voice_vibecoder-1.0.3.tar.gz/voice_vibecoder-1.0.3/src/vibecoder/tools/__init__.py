"""Tool definitions and handlers for the Realtime API session.

Re-exports the public API so existing imports keep working.
"""

from vibecoder.tools.definitions import TOOL_DEFINITIONS
from vibecoder.tools.dispatch import (
    configure,
    handle_tool_call,
    cancel_all_tasks,
    cancel_active_task,
    cancel_instance_task,
)

__all__ = [
    "TOOL_DEFINITIONS",
    "configure",
    "handle_tool_call",
    "cancel_all_tasks",
    "cancel_active_task",
    "cancel_instance_task",
]
