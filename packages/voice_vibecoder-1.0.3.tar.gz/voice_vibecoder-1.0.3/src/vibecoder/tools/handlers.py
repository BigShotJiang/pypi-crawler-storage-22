"""Tool handlers for branch management, status, diff, and UI commands.

Each function handles one tool call from the dispatcher in dispatch.py.
"""

import subprocess

from vibecoder.instances import ClaudeInstance, InstanceStatus
from vibecoder.tools import dispatch as _dispatch
from vibecoder.tools.dispatch import (
    HELPER_INSTANCE_NAME,
    _resolve_instance,
    cancel_all_tasks,
    cancel_instance_task,
)
from vibecoder.worktrees import remove_worktree, resolve_worktree_path


def get_startup_context() -> str:
    """Build a context string with current instances and worktrees for the system prompt."""
    parts = []

    if _dispatch._registry:
        instances = _dispatch._registry.get_all()
        if instances:
            parts.append("Active instances:")
            for inst in instances:
                parts.append(f"  - {inst.branch} ({inst.status.value})")

    if _dispatch._repo_root:
        from vibecoder.worktrees import list_worktrees

        active_branches = set()
        if _dispatch._registry:
            active_branches = {inst.branch for inst in _dispatch._registry.get_all()}
        worktrees = list_worktrees(_dispatch._repo_root)
        available = [wt for wt in worktrees if wt.branch and wt.branch not in active_branches and not wt.is_main]
        if available:
            parts.append("Available worktrees (not yet active):")
            for wt in available:
                parts.append(f"  - {wt.branch}")

    if not parts:
        return ""
    return "Current state:\n" + "\n".join(parts)


def _handle_create_branch_instance(branch: str) -> str:
    if not branch.strip():
        return "Error: branch name is required."
    if not _dispatch._registry or not _dispatch._repo_root:
        return "Error: tools not configured."

    existing = _dispatch._registry.get_by_branch(branch)
    if existing:
        return f"Instance for branch '{branch}' already exists (status: {existing.status.value})."

    try:
        worktree_path = resolve_worktree_path(branch, _dispatch._repo_root)
    except subprocess.CalledProcessError as e:
        return f"Error creating worktree for '{branch}': {e.stderr or e}"

    instance = _dispatch._registry.create_instance(branch, str(worktree_path))
    return f"Created instance for '{branch}'."


def _handle_get_claude_status(branch: str | None = None) -> str:
    if not _dispatch._registry:
        return "No Claude instances."

    if branch:
        instance = _dispatch._registry.get_by_branch(branch)
        if not instance:
            return f"No instance for branch '{branch}'."
        return _format_instance_status(instance)

    instances = _dispatch._registry.get_all()
    if not instances:
        return "No Claude instances."
    if len(instances) == 1:
        return _format_instance_status(instances[0])

    parts = []
    for inst in instances:
        parts.append(f"[{inst.branch}] {_format_instance_status(inst)}")
    return "\n".join(parts)


def _format_instance_status(instance: ClaudeInstance) -> str:
    if instance.status == InstanceStatus.WAITING_INPUT:
        q = instance.pending_question
        formatted = q.get("formatted", "") if q else ""
        return f"Waiting for input on '{instance.branch}': {formatted}"
    elif instance.status == InstanceStatus.RUNNING:
        snippet = instance.output_buffer[-500:] if instance.output_buffer else ""
        status = f"Working on '{instance.branch}'."
        if snippet:
            status += f"\n\n{snippet}"
        return status
    elif instance.output_buffer:
        snippet = instance.output_buffer[:500]
        return f"Done on '{instance.branch}':\n{snippet}"
    else:
        return f"Idle on '{instance.branch}'."


def _handle_cancel_claude(branch: str | None = None) -> str:
    if not _dispatch._registry:
        return "No active Claude task to cancel."

    if branch:
        instance = _dispatch._registry.get_by_branch(branch)
        if not instance:
            return f"No instance for branch '{branch}'."
        if cancel_instance_task(instance):
            return "Cancelled."
        return f"No active task on '{branch}'."

    count = cancel_all_tasks()
    if count > 0:
        return "Cancelled."
    return "No active tasks."


def _handle_reset_claude(branch: str | None = None) -> str:
    if not _dispatch._registry:
        return "No instances to reset."

    if branch:
        instance = _dispatch._registry.get_by_branch(branch)
        if not instance:
            return f"No instance for branch '{branch}'."
        cancel_instance_task(instance)
        instance.session_id = ""
        instance.first_call = True
        return "Reset."

    for inst in _dispatch._registry.get_all():
        cancel_instance_task(inst)
        inst.session_id = ""
        inst.first_call = True
    return "Reset."


def _handle_list_branches() -> str:
    from vibecoder.worktrees import list_worktrees

    parts = []

    # Active instances
    if _dispatch._registry:
        instances = _dispatch._registry.get_all()
        if instances:
            parts.append("Active instances:")
            for inst in instances:
                status_icons = {
                    "idle": "○", "running": "⏳", "waiting_input": "❓", "error": "✗",
                }
                icon = status_icons.get(inst.status.value, "?")
                parts.append(f"  {icon} {inst.branch} ({inst.status.value})")

    # Available worktrees not yet registered
    if _dispatch._repo_root:
        active_branches = set()
        if _dispatch._registry:
            active_branches = {inst.branch for inst in _dispatch._registry.get_all()}
        worktrees = list_worktrees(_dispatch._repo_root)
        available = [wt for wt in worktrees if wt.branch and wt.branch not in active_branches]
        if available:
            parts.append("\nAvailable worktrees (use create_branch_instance to activate):")
            for wt in available:
                label = f"  {wt.branch}"
                if wt.is_main:
                    label += " (main)"
                parts.append(label)

    if not parts:
        return "No active instances and no worktrees found."
    return "\n".join(parts)


def _handle_answer_question(answer: str, branch: str | None = None) -> str:
    if not answer.strip():
        return "Error: empty answer."

    instance = _resolve_instance(branch)
    if not instance:
        if branch:
            return f"No instance for branch '{branch}'."
        return "No Claude instance available."

    future = instance.pending_answer
    bg_loop = instance._bg_loop

    if not future or not bg_loop:
        return f"Claude on '{instance.branch}' has no pending question."

    if future.done():
        return f"Claude on '{instance.branch}' already received an answer."

    try:
        bg_loop.call_soon_threadsafe(future.set_result, answer)
    except RuntimeError:
        return f"Claude on '{instance.branch}' is no longer running."

    return "Answered."


def _fuzzy_match_file(query: str, paths: list[str]) -> str | None:
    """Fuzzy match a file query against a list of paths."""
    q = query.lower()
    # Exact full path
    exact = [p for p in paths if p == query]
    if exact:
        return exact[0]
    # Exact basename
    by_name = [p for p in paths if p.rsplit("/", 1)[-1].lower() == q]
    if len(by_name) == 1:
        return by_name[0]
    # Substring in full path
    partial = [p for p in paths if q in p.lower()]
    if len(partial) == 1:
        return partial[0]
    if partial:
        return min(partial, key=len)
    return None


def _handle_show_diff(branch: str | None = None, file: str | None = None) -> str:
    from vibecoder.ui.diff_view import get_diff_files, get_diff_content, format_diff_content

    instance = _resolve_instance(branch)

    if not instance and branch and _dispatch._repo_root:
        from vibecoder.worktrees import list_worktrees

        from vibecoder.tools.dispatch import _fuzzy_match_branch

        worktrees = list_worktrees(_dispatch._repo_root)
        wt_branches = [w.branch for w in worktrees if w.branch]
        matched = _fuzzy_match_branch(branch, wt_branches)
        wt = next((w for w in worktrees if w.branch == matched), None) if matched else None
        if wt:
            worktree_path = str(wt.path)
            files = get_diff_files(worktree_path)
            if file:
                matched_file = _fuzzy_match_file(file, [f.path for f in files])
                if matched_file:
                    files = [f for f in files if f.path == matched_file]
                    raw_diff = get_diff_content(worktree_path, file_path=matched_file)
                else:
                    return f"No file matching '{file}' in changes on '{branch}'."
            else:
                raw_diff = get_diff_content(worktree_path)
            if not files:
                return f"No changes on '{branch}' vs main."
            file_list = ", ".join(f.path for f in files[:10])
            summary = f"'{branch}' has {len(files)} changed file(s): {file_list}\n\n{raw_diff}"
            return summary

    if not instance:
        if branch:
            return f"No instance for branch '{branch}'."
        return "No instance available."

    files = get_diff_files(instance.worktree_path)

    matched_file = None
    if file:
        matched_file = _fuzzy_match_file(file, [f.path for f in files])
        if matched_file:
            raw_diff = get_diff_content(instance.worktree_path, file_path=matched_file)
        else:
            return f"No file matching '{file}' in changes on '{instance.branch}'."
    else:
        raw_diff = get_diff_content(instance.worktree_path)

    diff_lines = format_diff_content(raw_diff)

    if _dispatch._registry and _dispatch._registry.on_ui_command:
        _dispatch._registry.on_ui_command(instance.instance_id, "show_diff", {
            "files": files,
            "diff_lines": diff_lines,
        })

    file_count = len(files)
    if file_count == 0:
        return f"No changes on '{instance.branch}' vs main."
    if matched_file:
        return f"Showing diff for '{matched_file}' on '{instance.branch}'."
    return f"Showing diff for '{instance.branch}': {file_count} file{'s' if file_count != 1 else ''} changed."


def _handle_show_output(branch: str | None = None) -> str:
    # Also exit fullscreen if active — "go back" / "show output" should restore normal view
    if _dispatch._registry and _dispatch._registry.fullscreen_id:
        fs_id = _dispatch._registry.fullscreen_id
        if _dispatch._registry.on_ui_command:
            _dispatch._registry.on_ui_command(fs_id, "fullscreen", {})

    instance = _resolve_instance(branch)
    if not instance:
        if branch:
            return f"No instance for branch '{branch}'."
        return "No instance available."

    if _dispatch._registry and _dispatch._registry.on_ui_command:
        _dispatch._registry.on_ui_command(instance.instance_id, "show_output", {})

    return "Switched to output view."


def _handle_toggle_fullscreen(branch: str | None = None) -> str:
    # When no branch specified, un-fullscreen whichever panel is currently fullscreened
    if not branch and _dispatch._registry:
        fs_id = _dispatch._registry.fullscreen_id
        if fs_id and _dispatch._registry.on_ui_command:
            _dispatch._registry.on_ui_command(fs_id, "fullscreen", {})
            return "Toggled."

    instance = _resolve_instance(branch)
    if not instance:
        if branch:
            return f"No instance for branch '{branch}'."
        return "No instance available."

    if _dispatch._registry and _dispatch._registry.on_ui_command:
        _dispatch._registry.on_ui_command(instance.instance_id, "fullscreen", {})

    return "Toggled."


def _handle_remove_branch_instance(branch: str) -> str:
    if not branch.strip():
        return "Error: branch name is required."
    if not _dispatch._registry:
        return "No instances."
    if branch == HELPER_INSTANCE_NAME:
        return "Cannot remove the helper instance."

    instance = _resolve_instance(branch)
    if not instance:
        return f"No instance for branch '{branch}'."

    cancel_instance_task(instance)

    if _dispatch._registry.on_ui_command:
        _dispatch._registry.on_ui_command(instance.instance_id, "remove", {})

    _dispatch._registry.remove_instance(instance.instance_id)
    return f"Removed '{branch}'."


def _handle_delete_worktree(branch: str, delete_branch: bool = False) -> str:
    if not branch.strip():
        return "Error: branch name is required."
    if not _dispatch._repo_root:
        return "Error: repo root not configured."

    # Fuzzy match against worktree branches
    from vibecoder.tools.dispatch import _fuzzy_match_branch
    from vibecoder.worktrees import list_worktrees

    worktrees = list_worktrees(_dispatch._repo_root)
    wt_branches = [w.branch for w in worktrees if w.branch and not w.is_main]
    resolved = _fuzzy_match_branch(branch, wt_branches) or branch

    # Remove active instance first if one exists
    if _dispatch._registry:
        instance = _dispatch._registry.get_by_branch(resolved)
        if instance:
            if instance.branch == HELPER_INSTANCE_NAME:
                return "Cannot delete the helper instance worktree."
            cancel_instance_task(instance)
            if _dispatch._registry.on_ui_command:
                _dispatch._registry.on_ui_command(instance.instance_id, "remove", {})
            _dispatch._registry.remove_instance(instance.instance_id)

    try:
        remove_worktree(resolved, _dispatch._repo_root, delete_branch=delete_branch)
    except ValueError as e:
        return f"Error: {e}"
    except subprocess.CalledProcessError as e:
        return f"Error removing worktree: {e.stderr or e}"

    msg = f"Deleted worktree for '{resolved}'."
    if delete_branch:
        msg += " Branch also deleted."
    return msg
