"""CallbackMixin — event and callback handlers for VoiceCodingScreen.

Handles audio, transcripts, Claude output routing, instance status
changes, UI commands, and tool call logging.
"""

import asyncio

from textual.widgets import RichLog

from vibecoder.instances import InstanceStatus
from vibecoder.ui.styles import _CATEGORY_STYLES


class CallbackMixin:
    """Mixin providing callback methods for VoiceCodingScreen."""

    def _send_audio_chunk(self, base64_data: str) -> None:
        if self._loop and self._session and self._session.connected:
            asyncio.run_coroutine_threadsafe(
                self._session.send_audio(base64_data), self._loop
            )

    def _on_audio(self, base64_pcm: str) -> None:
        if self._audio:
            self._audio.play_audio(base64_pcm)

    def _on_transcript(self, role: str, text: str) -> None:
        if role == "user":
            self.app.call_from_thread(
                self._log, f"[bold blue]You:[/bold blue] {text}"
            )
        else:
            self.app.call_from_thread(
                self._log, f"[bold green]ChatGPT:[/bold green] {text}"
            )

    def _on_interrupt(self) -> None:
        if self._audio:
            self._audio.clear_playback()

    def _on_claude_output(self, instance_id: str, line: str) -> None:
        """Route all Claude output to the instance's grid panel."""
        if not self._session:
            return

        inst = self._session.registry.get_by_id(instance_id)
        if not inst or not inst.output_widget:
            return

        category = None
        display_line = line
        if ":" in line:
            prefix, rest = line.split(":", 1)
            if prefix in _CATEGORY_STYLES:
                category = prefix
                display_line = rest

        if category:
            style = _CATEGORY_STYLES[category]
            styled = f"[{style}]{display_line}[/{style}]"
        else:
            styled = f"[dim]{display_line}[/dim]"

        self._state.add_instance_line(inst.branch, styled)
        self.app.call_from_thread(self._write_to_output, inst.output_widget, styled)
        self._write_log_file(f"[{inst.branch}] {display_line}")

    def _write_to_output(self, widget: RichLog, text: str) -> None:
        try:
            widget.write(text)
        except Exception:
            pass

    def _on_instance_status(self, instance_id: str, status: InstanceStatus) -> None:
        """Update panel header when instance status changes."""
        self.app.call_from_thread(self._handle_instance_status, instance_id, status)

    def _handle_instance_status(self, instance_id: str, status: InstanceStatus) -> None:
        if not self._session:
            return

        try:
            self.query_one(f"#panel-{instance_id}")
        except Exception:
            inst = self._session.registry.get_by_id(instance_id)
            if inst:
                self._create_instance_panel(instance_id, inst.branch)

        self._update_instance_header(instance_id, status)
        self._update_status_bar("ready")

    def _on_ui_command(self, instance_id: str, action: str, data: dict) -> None:
        """Handle UI commands from tool handlers (called from thread pool)."""
        self.app.call_from_thread(self._handle_ui_command, instance_id, action, data)

    def _handle_ui_command(self, instance_id: str, action: str, data: dict) -> None:
        if action == "show_diff":
            self._show_diff_view(instance_id, data)
        elif action == "show_output":
            self._hide_diff_view(instance_id)
        elif action == "fullscreen":
            self._toggle_fullscreen(instance_id)
        elif action == "remove":
            self._remove_instance_panel(instance_id)

    def _on_status(self, status: str) -> None:
        self.app.call_from_thread(self._update_status_bar, status)

    def _on_tool_call(self, name: str, arguments: dict) -> None:
        if name == "send_to_claude":
            msg = arguments.get("message", "")
            branch = arguments.get("branch", "")
            preview = msg[:100] + "..." if len(msg) > 100 else msg
            branch_label = f" [{branch}]" if branch else ""
            self.app.call_from_thread(
                self._log,
                f"\n[bold yellow]>>> Sending to Claude{branch_label}:[/bold yellow] {preview}",
            )
        elif name == "create_branch_instance":
            branch = arguments.get("branch", "")
            self.app.call_from_thread(
                self._log,
                f"[yellow]Creating instance for branch '{branch}'...[/yellow]",
            )
        elif name == "get_claude_status":
            self.app.call_from_thread(
                self._log, "[dim]Checking Claude status...[/dim]"
            )
        elif name == "cancel_claude":
            self.app.call_from_thread(
                self._log, "[yellow]Cancelling Claude task...[/yellow]"
            )
        elif name == "reset_claude":
            self.app.call_from_thread(
                self._log, "[yellow]Resetting Claude session...[/yellow]"
            )
        elif name == "list_branches":
            self.app.call_from_thread(
                self._log, "[dim]Listing branches...[/dim]"
            )
        elif name == "show_diff":
            branch = arguments.get("branch", "")
            label = f" [{branch}]" if branch else ""
            self.app.call_from_thread(
                self._log, f"[dim]Showing diff{label}...[/dim]"
            )
        elif name == "remove_branch_instance":
            branch = arguments.get("branch", "")
            self.app.call_from_thread(
                self._log, f"[yellow]Removing '{branch}'...[/yellow]"
            )
