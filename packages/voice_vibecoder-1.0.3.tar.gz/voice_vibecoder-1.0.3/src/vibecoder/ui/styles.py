"""CSS, constants, and style helpers for the voice coding screen."""

import re

from vibecoder.instances import InstanceStatus
from vibecoder.tools.dispatch import HELPER_INSTANCE_NAME

VOICE_SCREEN_CSS = """
VoiceCodingScreen {
    background: $surface;
}

#voice-container {
    height: 100%;
}

#claude-grid {
    width: 100%;
    height: 1fr;
    grid-size: 1;
    grid-gutter: 0 0;
    display: block;
}

.claude-panel {
    border: solid $panel;
    width: 1fr;
    height: 1fr;
}

.claude-header {
    height: 1;
    padding: 0 1;
    text-align: center;
}

.claude-header-idle {
    background: $panel;
}

.claude-header-running {
    background: $warning-darken-2;
    color: $text;
}

.claude-header-waiting_input {
    background: $secondary-darken-2;
    color: $text;
}

.claude-header-error {
    background: $error-darken-2;
    color: $text;
}

.claude-output {
    height: 1fr;
    padding: 0 1;
}

.diff-container {
    layout: horizontal;
    height: 1fr;
}

.diff-file-list {
    width: 24;
    border-right: solid $panel;
    padding: 0;
    overflow-y: auto;
}

.diff-content {
    width: 1fr;
    padding: 0 1;
}

#voice-transcript {
    height: auto;
    max-height: 8;
    border: solid $panel;
    background: $surface;
    padding: 0 1;
}

#voice-status-bar {
    height: 3;
    padding: 0 2;
    content-align: center middle;
    text-align: center;
    background: $panel;
}
"""

_RICH_TAG_RE = re.compile(r"\[/?[a-z][a-z0-9 _#=-]*\]", re.IGNORECASE)

_CATEGORY_STYLES = {
    "tool_call": "bold yellow",
    "tool_result": "dim",
    "file_edit": "green",
    "bash": "cyan",
    "text": "dim",
}

_STATUS_ICONS = {
    InstanceStatus.IDLE: "[dim]○[/dim]",
    InstanceStatus.RUNNING: "[yellow]⏳[/yellow]",
    InstanceStatus.WAITING_INPUT: "[magenta]❓[/magenta]",
    InstanceStatus.ERROR: "[red]✗[/red]",
}


def strip_markup(text: str) -> str:
    return _RICH_TAG_RE.sub("", text)
