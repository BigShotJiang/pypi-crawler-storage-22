"""Voice provider protocol and event types.

Defines a provider-agnostic interface for real-time voice conversation.
Implementations handle the specifics of a particular API (OpenAI Realtime,
Gemini Live, etc.) while the session layer works with these abstract events.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, AsyncIterator, Protocol


# -- Events emitted by a VoiceProvider --


@dataclass
class AudioDelta:
    """Chunk of audio to play back."""
    delta: str  # base64-encoded PCM16


@dataclass
class TranscriptDelta:
    """Incremental assistant transcript."""
    delta: str


@dataclass
class TranscriptDone:
    """Final assistant transcript."""
    transcript: str


@dataclass
class UserTranscript:
    """Completed user speech transcription."""
    transcript: str


@dataclass
class SpeechStarted:
    """User started speaking (VAD detected)."""


@dataclass
class SpeechStopped:
    """User stopped speaking."""


@dataclass
class AudioCommitted:
    """Audio buffer was committed (PTT or VAD)."""


@dataclass
class ResponseCreated:
    """Provider started generating a response."""


@dataclass
class FunctionCall:
    """Provider wants to call a tool."""
    call_id: str
    name: str
    arguments: dict[str, Any]


@dataclass
class ResponseDone:
    """Provider finished its response turn."""


@dataclass
class VoiceError:
    """Non-fatal error from the provider."""
    message: str
    is_ignorable: bool = False


VoiceEvent = (
    AudioDelta | TranscriptDelta | TranscriptDone | UserTranscript
    | SpeechStarted | SpeechStopped | AudioCommitted | ResponseCreated
    | FunctionCall | ResponseDone | VoiceError
)


class VoiceProvider(Protocol):
    """Interface for a real-time voice conversation provider."""

    async def connect(self) -> None: ...
    async def disconnect(self) -> None: ...
    async def configure(
        self,
        instructions: str,
        voice: str,
        tools: list[dict],
        vad_config: dict | None,
    ) -> None: ...
    async def send_audio(self, base64_chunk: str) -> None: ...
    async def commit_audio(self) -> None: ...
    async def cancel_response(self) -> None: ...
    async def request_response(self) -> None: ...
    async def inject_message(self, text: str) -> None: ...
    async def send_tool_result(self, call_id: str, output: str) -> None: ...
    async def update_session(self, instructions: str) -> None: ...
    def listen(self) -> AsyncIterator[VoiceEvent]: ...
