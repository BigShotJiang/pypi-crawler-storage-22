"""OpenAI Realtime API voice provider.

Implements the VoiceProvider protocol using the OpenAI Realtime WebSocket API.
Supports both direct OpenAI and Azure OpenAI endpoints.
"""

from __future__ import annotations

import json
import logging
from typing import Any, AsyncIterator

import websockets

from vibecoder.voice_providers import (
    AudioCommitted,
    AudioDelta,
    FunctionCall,
    ResponseCreated,
    ResponseDone,
    SpeechStarted,
    SpeechStopped,
    TranscriptDelta,
    TranscriptDone,
    UserTranscript,
    VoiceError,
    VoiceEvent,
)

logger = logging.getLogger(__name__)


class OpenAIVoiceProvider:
    """VoiceProvider implementation for the OpenAI Realtime API."""

    def __init__(
        self,
        ws_url: str,
        ws_headers: dict[str, str],
        transcription_model: str = "gpt-4o-mini-transcribe",
    ) -> None:
        self._ws_url = ws_url
        self._ws_headers = ws_headers
        self._transcription_model = transcription_model
        self._ws: Any = None

    async def connect(self) -> None:
        self._ws = await websockets.connect(
            self._ws_url, additional_headers=self._ws_headers
        )

    async def disconnect(self) -> None:
        if self._ws:
            try:
                await self._ws.close()
            except Exception:
                pass
            self._ws = None

    async def configure(
        self,
        instructions: str,
        voice: str,
        tools: list[dict],
        vad_config: dict | None,
    ) -> None:
        if not self._ws:
            return

        session_config: dict[str, Any] = {
            "type": "session.update",
            "session": {
                "modalities": ["text", "audio"],
                "instructions": instructions,
                "voice": voice,
                "input_audio_format": "pcm16",
                "output_audio_format": "pcm16",
                "input_audio_transcription": {"model": self._transcription_model},
                "tools": tools,
            },
        }

        if vad_config is None:
            session_config["session"]["turn_detection"] = None
        else:
            session_config["session"]["turn_detection"] = vad_config

        await self._ws.send(json.dumps(session_config))

    async def send_audio(self, base64_chunk: str) -> None:
        if not self._ws:
            return
        try:
            await self._ws.send(json.dumps({
                "type": "input_audio_buffer.append",
                "audio": base64_chunk,
            }))
        except Exception:
            pass

    async def commit_audio(self) -> None:
        if not self._ws:
            return
        try:
            await self._ws.send(json.dumps({"type": "input_audio_buffer.commit"}))
            await self._ws.send(json.dumps({"type": "response.create"}))
        except Exception:
            pass

    async def cancel_response(self) -> None:
        if not self._ws:
            return
        try:
            await self._ws.send(json.dumps({"type": "response.cancel"}))
        except Exception:
            pass

    async def request_response(self) -> None:
        if not self._ws:
            return
        try:
            await self._ws.send(json.dumps({"type": "response.create"}))
        except Exception:
            pass

    async def inject_message(self, text: str) -> None:
        if not self._ws:
            return
        item_msg = {
            "type": "conversation.item.create",
            "item": {
                "type": "message",
                "role": "user",
                "content": [{"type": "input_text", "text": text}],
            },
        }
        await self._ws.send(json.dumps(item_msg))
        await self._ws.send(json.dumps({"type": "response.create"}))

    async def update_session(self, instructions: str) -> None:
        if not self._ws:
            return
        msg = {
            "type": "session.update",
            "session": {"instructions": instructions},
        }
        await self._ws.send(json.dumps(msg))

    async def send_tool_result(self, call_id: str, output: str) -> None:
        if not self._ws:
            return
        item_msg = {
            "type": "conversation.item.create",
            "item": {
                "type": "function_call_output",
                "call_id": call_id,
                "output": output,
            },
        }
        await self._ws.send(json.dumps(item_msg))
        await self._ws.send(json.dumps({"type": "response.create"}))

    async def listen(self) -> AsyncIterator[VoiceEvent]:
        if not self._ws:
            return
        async for raw in self._ws:
            try:
                msg = json.loads(raw)
            except json.JSONDecodeError:
                continue
            event = self._map_event(msg)
            if event is not None:
                yield event

    def _map_event(self, msg: dict) -> VoiceEvent | None:
        msg_type = msg.get("type", "")

        if msg_type == "response.audio.delta":
            return AudioDelta(delta=msg.get("delta", ""))

        elif msg_type == "response.audio_transcript.delta":
            return TranscriptDelta(delta=msg.get("delta", ""))

        elif msg_type == "response.audio_transcript.done":
            return TranscriptDone(transcript=msg.get("transcript", ""))

        elif msg_type == "conversation.item.input_audio_transcription.completed":
            return UserTranscript(transcript=msg.get("transcript", "").strip())

        elif msg_type == "input_audio_buffer.speech_started":
            return SpeechStarted()

        elif msg_type == "input_audio_buffer.speech_stopped":
            return SpeechStopped()

        elif msg_type == "input_audio_buffer.committed":
            return AudioCommitted()

        elif msg_type == "response.created":
            return ResponseCreated()

        elif msg_type == "response.function_call_arguments.done":
            args_str = msg.get("arguments", "{}")
            try:
                arguments = json.loads(args_str)
            except json.JSONDecodeError:
                arguments = {}
            return FunctionCall(
                call_id=msg.get("call_id", ""),
                name=msg.get("name", ""),
                arguments=arguments,
            )

        elif msg_type == "response.done":
            return ResponseDone()

        elif msg_type == "error":
            error = msg.get("error", {})
            error_msg = error.get("message", str(error))
            is_ignorable = "cancel" in error_msg.lower()
            return VoiceError(message=error_msg, is_ignorable=is_ignorable)

        return None
