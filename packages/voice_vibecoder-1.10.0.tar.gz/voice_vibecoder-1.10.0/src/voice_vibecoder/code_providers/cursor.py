"""Cursor Agent CLI runner.

Implements the AgentRunner protocol by spawning `cursor-agent` as a subprocess
and parsing its NDJSON stream output. Supports session resume via --resume.

Event format (from cursor-agent --output-format stream-json):
  {"type":"system","subtype":"init","session_id":"...","model":"..."}
  {"type":"user","message":{"role":"user","content":[...]},"session_id":"..."}
  {"type":"assistant","message":{"role":"assistant","content":[...]},"session_id":"..."}
  {"type":"tool_call","subtype":"started"|"completed",...}
  {"type":"result","subtype":"success","result":"...","session_id":"..."}
"""

from __future__ import annotations

import asyncio
import json
import logging
from typing import Any, Awaitable, Callable

from voice_vibecoder.code_providers import AgentOutput, AgentResult

logger = logging.getLogger(__name__)

MAX_DIFF_LINES = 20


def _cursor_edit_diff(tool_name: str, inp: dict) -> list[AgentOutput]:
    """Extract diff lines from a Cursor tool_call event if edit data is present."""
    outputs: list[AgentOutput] = []
    old = inp.get("old_string", "") or inp.get("old_text", "")
    new = inp.get("new_string", "") or inp.get("new_text", "") or inp.get("content", "")

    if tool_name in ("write_file", "Write") and not old and new:
        line_count = len(new.splitlines())
        if line_count:
            outputs.append(AgentOutput(category="tool_result", content=f"({line_count} lines)"))
        return outputs

    if not old and not new:
        return outputs

    removed = old.splitlines() if old else []
    added = new.splitlines() if new else []
    count = 0
    for line in removed:
        if count >= MAX_DIFF_LINES:
            outputs.append(AgentOutput(category="diff_del", content="..."))
            break
        outputs.append(AgentOutput(category="diff_del", content=line))
        count += 1
    for line in added:
        if count >= MAX_DIFF_LINES:
            outputs.append(AgentOutput(category="diff_add", content="..."))
            break
        outputs.append(AgentOutput(category="diff_add", content=line))
        count += 1
    return outputs


class CursorRunner:
    """AgentRunner implementation using the Cursor CLI (cursor-agent)."""

    def __init__(self) -> None:
        self._process: asyncio.subprocess.Process | None = None

    async def run(
        self,
        message: str,
        cwd: str,
        session_id: str | None = None,
        on_output: Callable[[AgentOutput], None] | None = None,
        can_use_tool: Callable[[str, dict, Any], Awaitable[Any]] | None = None,
    ) -> AgentResult:
        args = [
            "cursor-agent",
            "-p",
            "--output-format", "stream-json",
            "--force",
        ]
        if session_id:
            args.extend(["--resume", session_id])
        args.append(message)

        self._process = await asyncio.create_subprocess_exec(
            *args,
            cwd=cwd,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
        )

        result_text = ""
        result_session_id: str | None = None

        try:
            assert self._process.stdout is not None
            while True:
                line = await self._process.stdout.readline()
                if not line:
                    break
                try:
                    event = json.loads(line)
                except json.JSONDecodeError:
                    continue

                etype = event.get("type", "")

                # Capture session_id from any event
                sid = event.get("session_id")
                if sid:
                    result_session_id = sid

                # Map to output (may yield multiple lines for multi-line text)
                for output in self._map_event(event):
                    if on_output:
                        on_output(output)

                if etype == "result":
                    result_text = event.get("result", "")

        except asyncio.CancelledError:
            self.cancel()
            raise

        await self._process.wait()

        if not result_text and self._process.returncode != 0:
            assert self._process.stderr is not None
            stderr = await self._process.stderr.read()
            if stderr:
                result_text = f"Cursor error (exit {self._process.returncode}): {stderr.decode(errors='replace')[:500]}"

        self._process = None
        return AgentResult(text=result_text, session_id=result_session_id)

    def cancel(self) -> bool:
        if self._process and self._process.returncode is None:
            self._process.terminate()
            return True
        return False

    @staticmethod
    def _map_event(event: dict) -> list[AgentOutput]:
        etype = event.get("type", "")
        subtype = event.get("subtype", "")

        if etype == "assistant":
            msg = event.get("message", {})
            content_blocks = msg.get("content", [])
            texts = []
            for block in content_blocks:
                if isinstance(block, dict) and block.get("type") == "text":
                    texts.append(block.get("text", ""))
                elif isinstance(block, str):
                    texts.append(block)
            # Split into one output per line to avoid multi-line blobs
            outputs = []
            for text in texts:
                for line in text.splitlines():
                    line = line.strip()
                    if line:
                        outputs.append(AgentOutput(category="text", content=line))
            return outputs

        elif etype == "tool_call":
            tool_name = event.get("name", "") or event.get("tool", "")
            if subtype == "started":
                desc = event.get("description", "") or f"[{tool_name}]"
                is_edit = tool_name in ("edit_file", "write_file", "Edit", "Write")
                category = (
                    "file_edit" if is_edit
                    else "bash" if tool_name in ("run_command", "Bash")
                    else "tool_call"
                )
                outputs: list[AgentOutput] = [AgentOutput(category=category, content=desc)]
                if is_edit:
                    inp = event.get("input", {}) or event.get("params", {})
                    outputs.extend(_cursor_edit_diff(tool_name, inp))
                return outputs
            elif subtype == "completed":
                content = event.get("result", "") or event.get("output", "")
                if content:
                    preview = str(content)[:200] + ("..." if len(str(content)) > 200 else "")
                    return [AgentOutput(category="tool_result", content=preview)]

        elif etype == "result":
            if event.get("is_error"):
                return [AgentOutput(category="text", content=f"[ERROR] {event.get('result', '')}")]

        return []
