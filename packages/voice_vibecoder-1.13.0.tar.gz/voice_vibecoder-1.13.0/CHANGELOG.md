# CHANGELOG

<!-- version list -->

## v1.13.0 (2026-02-16)


## v1.12.0 (2026-02-16)

### Continuous Integration

- Update release workflow for version checking logic
  ([`1954217`](https://github.com/snokam/voice-vibecoder/commit/19542172741a253ba75eac0143873d3333791586))

### Features

- **cursor**: Set limit for large NDJSON lines in cursor
  ([`6d5f816`](https://github.com/snokam/voice-vibecoder/commit/6d5f816b2b09cc8e5906a16c82b37326e02019f6))


## v1.11.0 (2026-02-16)


## v1.10.0 (2026-02-16)

### Features

- **help**: Add help modal for shortcuts and usage guide
  ([`d6c7cef`](https://github.com/snokam/voice-vibecoder/commit/d6c7cef8ada876baf1329c074406f5491615871c))

### Refactoring

- Update _get_repo_root to return tuple with status
  ([`e1dfdf4`](https://github.com/snokam/voice-vibecoder/commit/e1dfdf41baba14968372ef95ffde7111b3d4fcb7))

- **ui**: Move imports inside _play_audio method
  ([`7f4f4ae`](https://github.com/snokam/voice-vibecoder/commit/7f4f4aee2765e04df81daa0516fa760bff0d27d9))


## v1.9.0 (2026-02-16)


## v1.8.0 (2026-02-16)

### Features

- Add centralized agent registry and output truncation
  ([`bad0a19`](https://github.com/snokam/voice-vibecoder/commit/bad0a19630340a87aa3b284643c035e0a09c39de))


## v1.7.0 (2026-02-16)


## v1.6.0 (2026-02-16)


## v1.5.0 (2026-02-16)


## v1.4.0 (2026-02-16)


## v1.3.0 (2026-02-16)


## v1.2.0 (2026-02-16)


## v1.1.0 (2026-02-16)

### Features

- Implement voice provider connection testing methods
  ([`4ce0b59`](https://github.com/snokam/voice-vibecoder/commit/4ce0b59a7571dc4d4b9e3917ebae6526ce0bb939))


## v1.0.3 (2026-02-16)

### Bug Fixes

- Add vibecoder script alias alongside voice-vibecoder
  ([`13c6a1c`](https://github.com/snokam/voice-vibecoder/commit/13c6a1c859f3d3463189143d539d5940e901f5bb))


## v1.0.2 (2026-02-16)

### Bug Fixes

- Rename script entry to voice-vibecoder so uvx voice-vibecoder works
  ([`b7933f2`](https://github.com/snokam/voice-vibecoder/commit/b7933f29b9ebd1d532b80b3d61e51d46e66917ae))


## v1.0.1 (2026-02-16)

### Bug Fixes

- Rename PyPI package to voice-vibecoder
  ([`174ddad`](https://github.com/snokam/voice-vibecoder/commit/174ddad9278fd341087af1223e1e45bfdca01f19))


## v1.0.0 (2026-02-16)

- Initial Release
