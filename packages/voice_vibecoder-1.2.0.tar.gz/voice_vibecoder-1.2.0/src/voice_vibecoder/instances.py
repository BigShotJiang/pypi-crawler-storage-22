"""Instance registry for managing multiple Claude Code processes.

Each instance represents a Claude CLI process running in a specific git worktree.
The registry provides thread-safe access and callback-based notifications for
output, progress, status changes, and task completion.

State is persisted to <state_dir>/realtime-instances.json so instances (with their
session IDs and worktree paths) survive across voice coding sessions.
"""

from __future__ import annotations

import json
import logging
import threading
import uuid
from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path
from typing import Any, Callable

logger = logging.getLogger(__name__)

# Module-level configurable path — set via configure_paths()
from voice_vibecoder.app_config import _default_data_dir

STATE_PATH = _default_data_dir() / "realtime-instances.json"


def configure_paths(data_dir: Path) -> None:
    """Set the instance state file path based on the configured data directory."""
    global STATE_PATH
    STATE_PATH = data_dir / "realtime-instances.json"


class InstanceStatus(Enum):
    IDLE = "idle"
    RUNNING = "running"
    WAITING_INPUT = "waiting_input"
    ERROR = "error"


@dataclass
class ClaudeInstance:
    instance_id: str
    branch: str
    worktree_path: str
    session_id: str = ""
    status: InstanceStatus = InstanceStatus.IDLE
    output_buffer: str = ""
    first_call: bool = True
    last_activity: str = ""
    # Pending interactive tool data (AskUserQuestion / EnterPlanMode)
    pending_question: dict[str, Any] | None = None
    # asyncio.Future for waiting on user's answer (set by can_use_tool callback)
    pending_answer: Any = None
    # Background thread's event loop (for cross-thread future resolution)
    _bg_loop: Any = None
    # asyncio.Task running the SDK query (for cancellation)
    _bg_task: Any = None
    # UI widget refs — set by screen.py after panel creation
    header_widget: Any = None
    output_widget: Any = None


class InstanceRegistry:
    """Thread-safe registry of Claude instances indexed by id and branch."""

    def __init__(self) -> None:
        self._instances: dict[str, ClaudeInstance] = {}
        self._branch_index: dict[str, str] = {}
        self._lock = threading.Lock()

        # Callbacks — set by session/screen
        self.on_output: Callable[[str, str], None] | None = None
        self.on_task_complete: Callable[[str, str], None] | None = None
        self.on_progress: Callable[[str, str], None] | None = None
        self.on_status_change: Callable[[str, InstanceStatus], None] | None = None
        self.on_question: Callable[[str, dict], None] | None = None
        # UI view callbacks (diff, fullscreen, remove)
        self.on_ui_command: Callable[[str, str, Any], None] | None = None
        # Fired when instances are created or removed (for refreshing instructions)
        self.on_instance_change: Callable[[], None] | None = None
        # Tracks which instance_id is currently fullscreened (set by screen)
        self.fullscreen_id: str | None = None

    def create_instance(self, branch: str, worktree_path: str) -> ClaudeInstance:
        with self._lock:
            if branch in self._branch_index:
                return self._instances[self._branch_index[branch]]
            instance = ClaudeInstance(
                instance_id=uuid.uuid4().hex[:8],
                branch=branch,
                worktree_path=worktree_path,
            )
            self._instances[instance.instance_id] = instance
            self._branch_index[branch] = instance.instance_id
        self._save_state()
        # Fire status change so the UI can create a panel immediately
        if self.on_status_change:
            self.on_status_change(instance.instance_id, instance.status)
        if self.on_instance_change:
            self.on_instance_change()
        return instance

    def get_by_branch(self, branch: str) -> ClaudeInstance | None:
        with self._lock:
            iid = self._branch_index.get(branch)
            return self._instances.get(iid) if iid else None

    def get_by_id(self, instance_id: str) -> ClaudeInstance | None:
        with self._lock:
            return self._instances.get(instance_id)

    def get_all(self) -> list[ClaudeInstance]:
        with self._lock:
            return list(self._instances.values())

    def get_default(self) -> ClaudeInstance | None:
        with self._lock:
            if not self._instances:
                return None
            return next(iter(self._instances.values()))

    def remove_instance(self, instance_id: str) -> None:
        with self._lock:
            inst = self._instances.pop(instance_id, None)
            if inst:
                self._branch_index.pop(inst.branch, None)
        self._save_state()
        if self.on_instance_change:
            self.on_instance_change()

    def update_status(self, instance_id: str, status: InstanceStatus) -> None:
        with self._lock:
            inst = self._instances.get(instance_id)
            if inst:
                inst.status = status
        if self.on_status_change:
            self.on_status_change(instance_id, status)

    def has_running_instance(self, branch: str) -> bool:
        with self._lock:
            iid = self._branch_index.get(branch)
            if not iid:
                return False
            inst = self._instances.get(iid)
            return inst is not None and inst.status == InstanceStatus.RUNNING

    @property
    def count(self) -> int:
        with self._lock:
            return len(self._instances)

    # -- Persistence --

    def _save_state(self) -> None:
        """Persist instance metadata (branch, path, session_id) to disk."""
        try:
            with self._lock:
                data = [
                    {
                        "instance_id": inst.instance_id,
                        "branch": inst.branch,
                        "worktree_path": inst.worktree_path,
                        "session_id": inst.session_id,
                        "output_buffer": inst.output_buffer[-5000:] if inst.output_buffer else "",
                    }
                    for inst in self._instances.values()
                ]
            STATE_PATH.parent.mkdir(parents=True, exist_ok=True)
            tmp = STATE_PATH.with_suffix(".tmp")
            tmp.write_text(json.dumps(data, indent=2))
            tmp.replace(STATE_PATH)
        except Exception as e:
            logger.warning("Failed to save instance state: %s", e)

    def load_state(self) -> list[ClaudeInstance]:
        """Load previously saved instances from disk.

        Returns the loaded instances (already registered). Validates that
        worktree paths still exist on disk before restoring.
        """
        if not STATE_PATH.exists():
            return []
        try:
            data = json.loads(STATE_PATH.read_text())
        except (json.JSONDecodeError, OSError) as e:
            logger.warning("Failed to load instance state: %s", e)
            return []

        loaded = []
        with self._lock:
            for entry in data:
                branch = entry.get("branch", "")
                worktree_path = entry.get("worktree_path", "")
                session_id = entry.get("session_id", "")
                instance_id = entry.get("instance_id", uuid.uuid4().hex[:8])

                output_buffer = entry.get("output_buffer", "")

                if not branch or not worktree_path:
                    continue
                # Skip if already registered (e.g. current branch added at startup)
                if branch in self._branch_index:
                    # Update session_id so we can resume the old session
                    existing = self._instances[self._branch_index[branch]]
                    if session_id:
                        existing.session_id = session_id
                        existing.first_call = False
                    if output_buffer:
                        existing.output_buffer = output_buffer
                    loaded.append(existing)
                    continue
                # Verify worktree still exists
                if not Path(worktree_path).exists():
                    logger.info("Skipping saved instance '%s': path gone", branch)
                    continue

                instance = ClaudeInstance(
                    instance_id=instance_id,
                    branch=branch,
                    worktree_path=worktree_path,
                    session_id=session_id,
                    first_call=not bool(session_id),
                    output_buffer=output_buffer,
                )
                self._instances[instance.instance_id] = instance
                self._branch_index[branch] = instance.instance_id
                loaded.append(instance)

        return loaded
