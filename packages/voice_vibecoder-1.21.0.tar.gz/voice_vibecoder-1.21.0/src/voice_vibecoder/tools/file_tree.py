"""File tree data gathering for worktree panels.

Builds a complete file tree from a git worktree, showing all tracked files
with their status (modified, new, deleted, or unchanged). This provides full
project context so users can understand the complete structure. Provides
periodic updates via a background timer while an agent is running.
"""

import logging
import subprocess
import threading
from pathlib import PurePosixPath

logger = logging.getLogger(__name__)

MAX_ENTRIES = 1500  # Show full project structure


def _merge_base(worktree_path: str) -> str:
    """Get the merge-base commit between main and HEAD."""
    result = subprocess.run(
        ["git", "merge-base", "main", "HEAD"],
        cwd=worktree_path,
        capture_output=True,
        text=True,
        timeout=10,
    )
    return result.stdout.strip() if result.returncode == 0 else "main"


def get_file_tree(worktree_path: str) -> dict:
    """Get complete file tree with status for a worktree.

    Shows all tracked files in the project with their status (modified, new,
    deleted, unchanged) to provide full project context.

    Returns:
        {"root": "branch-name", "entries": [{"path": "...", "status": "..."}],
         "summary": {"modified": N, "new": N, "deleted": N, "unchanged": N}}
    """
    try:
        # Get branch name
        branch_result = subprocess.run(
            ["git", "rev-parse", "--abbrev-ref", "HEAD"],
            cwd=worktree_path,
            capture_output=True,
            text=True,
            timeout=10,
        )
        root = branch_result.stdout.strip() if branch_result.returncode == 0 else "unknown"

        base = _merge_base(worktree_path)

        # Get modified/deleted files vs merge-base
        diff_result = subprocess.run(
            ["git", "diff", "--name-status", base],
            cwd=worktree_path,
            capture_output=True,
            text=True,
            timeout=10,
        )

        changed: dict[str, str] = {}  # path -> status
        if diff_result.returncode == 0:
            for line in diff_result.stdout.strip().splitlines():
                if not line.strip():
                    continue
                parts = line.split("\t", 1)
                if len(parts) == 2:
                    status_code = parts[0][0]
                    path = parts[1]
                    if status_code == "M":
                        changed[path] = "modified"
                    elif status_code == "A":
                        changed[path] = "new"
                    elif status_code == "D":
                        changed[path] = "deleted"
                    elif status_code in ("R", "C"):
                        changed[path] = "modified"

        # Get untracked files
        untracked_result = subprocess.run(
            ["git", "ls-files", "--others", "--exclude-standard"],
            cwd=worktree_path,
            capture_output=True,
            text=True,
            timeout=10,
        )
        if untracked_result.returncode == 0:
            for path in untracked_result.stdout.strip().splitlines():
                path = path.strip()
                if path and path not in changed:
                    changed[path] = "new"

        # Get all tracked files to show complete project structure
        all_files_result = subprocess.run(
            ["git", "ls-files"],
            cwd=worktree_path,
            capture_output=True,
            text=True,
            timeout=10,
        )

        unchanged_paths: set[str] = set()
        if all_files_result.returncode == 0:
            for f in all_files_result.stdout.strip().splitlines():
                f = f.strip()
                if f and f not in changed:
                    unchanged_paths.add(f)

        # Build entries list
        entries: list[dict] = []
        for path, status in sorted(changed.items()):
            entries.append({"path": path, "status": status})
        for path in sorted(unchanged_paths):
            entries.append({"path": path, "status": "unchanged"})

        # Cap total entries
        entries = entries[:MAX_ENTRIES]

        # Summary counts
        summary = {"modified": 0, "new": 0, "deleted": 0, "unchanged": 0}
        for e in entries:
            s = e["status"]
            if s in summary:
                summary[s] += 1

        return {"root": root, "entries": entries, "summary": summary}

    except Exception as e:
        logger.warning("Failed to build file tree: %s", e)
        return {"root": "unknown", "entries": [], "summary": {"modified": 0, "new": 0, "deleted": 0, "unchanged": 0}}


# -- Timer management for periodic updates --

_timers: dict[str, threading.Timer] = {}
_UPDATE_INTERVAL = 5.0  # seconds


def _fire_update(instance_id: str, worktree_path: str, registry) -> None:
    """Fire a single file tree update and schedule the next one."""
    try:
        tree_data = get_file_tree(worktree_path)
        if registry and registry.on_ui_command:
            registry.on_ui_command(instance_id, "file_tree", tree_data)
    except Exception as e:
        logger.debug("File tree update failed for %s: %s", instance_id, e)

    # Schedule next update (only if still registered)
    if instance_id in _timers:
        timer = threading.Timer(
            _UPDATE_INTERVAL,
            _fire_update,
            args=(instance_id, worktree_path, registry),
        )
        timer.daemon = True
        _timers[instance_id] = timer
        timer.start()


def start_file_tree_updates(instance_id: str, worktree_path: str, registry) -> None:
    """Start periodic file tree updates for an instance."""
    stop_file_tree_updates(instance_id)  # Clean up any existing timer

    # Fire immediately, then every _UPDATE_INTERVAL seconds
    timer = threading.Timer(
        0.1,  # near-immediate first update
        _fire_update,
        args=(instance_id, worktree_path, registry),
    )
    timer.daemon = True
    _timers[instance_id] = timer
    timer.start()


def stop_file_tree_updates(instance_id: str) -> None:
    """Stop the periodic timer for an instance."""
    timer = _timers.pop(instance_id, None)
    if timer:
        timer.cancel()
