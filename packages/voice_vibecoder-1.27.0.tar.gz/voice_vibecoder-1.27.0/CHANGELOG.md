# CHANGELOG

<!-- version list -->

## v1.27.0 (2026-02-17)

### Features

- Show file tree for all instances including idle feature branches
  ([`26cfda2`](https://github.com/snokam/voice-vibecoder/commit/26cfda2bc82b3b796a42343ec2ed9bc3cf848e8c))


## v1.26.0 (2026-02-17)

### Features

- Add helpful description text to helper instance
  ([`0354d54`](https://github.com/snokam/voice-vibecoder/commit/0354d54c61eda202471bd946eb2d8b9323b60747))


## v1.25.0 (2026-02-17)

### Features

- Convert file tree to hierarchical structure with auto-expand
  ([`44d74f8`](https://github.com/snokam/voice-vibecoder/commit/44d74f8d42fb1df5d1eefdaf90a77ec4b5a63391))


## v1.24.2 (2026-02-17)

### Bug Fixes

- Use dedicated test ACR (crsnkmtest) in snøkam-t subscription
  ([`9160af8`](https://github.com/snokam/voice-vibecoder/commit/9160af8d1179d54656818e07a7650a23c6520508))


## v1.24.1 (2026-02-17)

### Bug Fixes

- Use platform-t subscription for ACR in test deployment
  ([`26a029a`](https://github.com/snokam/voice-vibecoder/commit/26a029a675a6d51c2da935cbf9999fe3175d5127))


## v1.24.0 (2026-02-17)

### Features

- Use dedicated production ACR (crsnkmprod)
  ([`5969867`](https://github.com/snokam/voice-vibecoder/commit/59698673458d216b40d97ee7a83f6b172a06d7ec))


## v1.23.0 (2026-02-17)

### Features

- Use GitHub environments snkm-p and snkm-t for deployments
  ([`89108e1`](https://github.com/snokam/voice-vibecoder/commit/89108e166c3b277ede8c0fa21b125f389af35b01))


## v1.22.1 (2026-02-17)

### Bug Fixes

- Deploy to correct container app in snøkam tenant
  ([`bcb1da1`](https://github.com/snokam/voice-vibecoder/commit/bcb1da1b4460266706f9f9e703394d5f11334053))


## v1.22.0 (2026-02-17)

### Bug Fixes

- Include agentType in instance status change messages
  ([`f0790b9`](https://github.com/snokam/voice-vibecoder/commit/f0790b91ae94e453f0ab13b48f85c640210d8d68))


## v1.21.0 (2026-02-17)

### Chores

- Remove debug logging from agent_task
  ([`a9627a6`](https://github.com/snokam/voice-vibecoder/commit/a9627a6d39e306ee1857cdc4e11af1dba3c67ce4))

### Features

- Add OpenClaw integration with OAuth support
  ([`d8da351`](https://github.com/snokam/voice-vibecoder/commit/d8da3515d3ff145e6180922a9e1458155f105e20))

- Show complete project structure in file tree
  ([`9c9d185`](https://github.com/snokam/voice-vibecoder/commit/9c9d1853d2370be50b5aa5659ff7f1841a86251d))


## v1.20.0 (2026-02-17)

### Chores

- Remove accidentally committed serverless deployment files
  ([`2def1ff`](https://github.com/snokam/voice-vibecoder/commit/2def1ff3ec68472603ab1fae7fb5be8c6d834f07))

### Features

- Persist voice transcripts to backend state
  ([`32a9ad3`](https://github.com/snokam/voice-vibecoder/commit/32a9ad3fa5ca6008f2082e945b8119829e6eac9a))


## v1.19.0 (2026-02-17)

### Features

- Add sync_state API and per-user state storage
  ([`7d5094a`](https://github.com/snokam/voice-vibecoder/commit/7d5094a4f5161e0300ceec3b4afd2a1f91d3dc12))


## v1.18.3 (2026-02-17)

### Bug Fixes

- Send output buffer to frontend on reconnect
  ([`131d5da`](https://github.com/snokam/voice-vibecoder/commit/131d5da2a28165e3eaeaf6221f444a9f1d78e5f9))


## v1.18.2 (2026-02-17)

### Bug Fixes

- Preserve PATH and environment variables for agents
  ([`aad070c`](https://github.com/snokam/voice-vibecoder/commit/aad070c8cd73bab4df1fe758a27d75960d250804))


## v1.18.1 (2026-02-17)

### Bug Fixes

- Remove GitHub token env var reference until secret is configured
  ([`0a6d910`](https://github.com/snokam/voice-vibecoder/commit/0a6d9107a59703c6174938fdba1dd2acdef22f47))


## v1.18.0 (2026-02-17)


## v1.17.0 (2026-02-17)

### Features

- Add serverless container management API for users
  ([`9ecd09e`](https://github.com/snokam/voice-vibecoder/commit/9ecd09e202f81777007b19eb028929ab624b5f11))


## v1.16.0 (2026-02-17)


## v1.15.0 (2026-02-17)

### Features

- Send file tree to UI after agent task completes
  ([`71c72bf`](https://github.com/snokam/voice-vibecoder/commit/71c72bf0a3d8dde5b3f0fa356daa320680fa9e67))

### Refactoring

- Remove redundant _send_file_tree in favor of file_tree module
  ([`7788d35`](https://github.com/snokam/voice-vibecoder/commit/7788d353f405a6e41df4c427c9ad5f0e4bdd4912))


## v1.14.0 (2026-02-17)

### Bug Fixes

- Accept both v1 and v2 Azure AD token formats in JWT validation
  ([`6820ce3`](https://github.com/snokam/voice-vibecoder/commit/6820ce3a8b91cdd089b3218fcec4a9a738bc5627))

- Create /worktrees dir for non-root user in container
  ([`fc0be99`](https://github.com/snokam/voice-vibecoder/commit/fc0be9969f320c6f089514cb439f7853208ac770))

- Sync existing instances to web client on connect
  ([`7bb600c`](https://github.com/snokam/voice-vibecoder/commit/7bb600cd66c072e5a04cbeb0282c69e1c90e8f91))

- **security**: Harden WebSocket server auth and Docker build
  ([`d45c2cd`](https://github.com/snokam/voice-vibecoder/commit/d45c2cdf124c4d5d3ab35501ec7b880aabfa78d5))

### Build System

- Multi-stage Dockerfile for ACR Build compatibility
  ([`eb08e96`](https://github.com/snokam/voice-vibecoder/commit/eb08e96012ecc5dac24ae70cff3db0ed847bfc1a))

- Update Dockerfile for user permissions and setup
  ([`6516b1a`](https://github.com/snokam/voice-vibecoder/commit/6516b1aaefdb216ec163173ebb694c7d43f2f2da))

### Continuous Integration

- Add deploy workflows for test and prod
  ([`1cd3451`](https://github.com/snokam/voice-vibecoder/commit/1cd345135eb75702d964db0559c8c6c7a439067f))

### Features

- Add WebSocket server and CLI entry point
  ([`35a6536`](https://github.com/snokam/voice-vibecoder/commit/35a6536e0a4c4d3604caa2d24a3bb26e1048d8aa))

- Wire up on_tool_call and on_ui_command callbacks for web client
  ([`ecc907e`](https://github.com/snokam/voice-vibecoder/commit/ecc907ec6bf16c7ce6518182b1d4d79878f4b933))

- **docker**: Add Dockerfile for container deployment
  ([`d1f2e8f`](https://github.com/snokam/voice-vibecoder/commit/d1f2e8fdbebfaf34d0ff24078b126d85a82636b8))


## v1.13.0 (2026-02-16)


## v1.12.0 (2026-02-16)

### Continuous Integration

- Update release workflow for version checking logic
  ([`1954217`](https://github.com/snokam/voice-vibecoder/commit/19542172741a253ba75eac0143873d3333791586))

### Features

- **cursor**: Set limit for large NDJSON lines in cursor
  ([`6d5f816`](https://github.com/snokam/voice-vibecoder/commit/6d5f816b2b09cc8e5906a16c82b37326e02019f6))


## v1.11.0 (2026-02-16)


## v1.10.0 (2026-02-16)

### Features

- **help**: Add help modal for shortcuts and usage guide
  ([`d6c7cef`](https://github.com/snokam/voice-vibecoder/commit/d6c7cef8ada876baf1329c074406f5491615871c))

### Refactoring

- Update _get_repo_root to return tuple with status
  ([`e1dfdf4`](https://github.com/snokam/voice-vibecoder/commit/e1dfdf41baba14968372ef95ffde7111b3d4fcb7))

- **ui**: Move imports inside _play_audio method
  ([`7f4f4ae`](https://github.com/snokam/voice-vibecoder/commit/7f4f4aee2765e04df81daa0516fa760bff0d27d9))


## v1.9.0 (2026-02-16)


## v1.8.0 (2026-02-16)

### Features

- Add centralized agent registry and output truncation
  ([`bad0a19`](https://github.com/snokam/voice-vibecoder/commit/bad0a19630340a87aa3b284643c035e0a09c39de))


## v1.7.0 (2026-02-16)


## v1.6.0 (2026-02-16)


## v1.5.0 (2026-02-16)


## v1.4.0 (2026-02-16)


## v1.3.0 (2026-02-16)


## v1.2.0 (2026-02-16)


## v1.1.0 (2026-02-16)

### Features

- Implement voice provider connection testing methods
  ([`4ce0b59`](https://github.com/snokam/voice-vibecoder/commit/4ce0b59a7571dc4d4b9e3917ebae6526ce0bb939))


## v1.0.3 (2026-02-16)

### Bug Fixes

- Add vibecoder script alias alongside voice-vibecoder
  ([`13c6a1c`](https://github.com/snokam/voice-vibecoder/commit/13c6a1c859f3d3463189143d539d5940e901f5bb))


## v1.0.2 (2026-02-16)

### Bug Fixes

- Rename script entry to voice-vibecoder so uvx voice-vibecoder works
  ([`b7933f2`](https://github.com/snokam/voice-vibecoder/commit/b7933f29b9ebd1d532b80b3d61e51d46e66917ae))


## v1.0.1 (2026-02-16)

### Bug Fixes

- Rename PyPI package to voice-vibecoder
  ([`174ddad`](https://github.com/snokam/voice-vibecoder/commit/174ddad9278fd341087af1223e1e45bfdca01f19))


## v1.0.0 (2026-02-16)

- Initial Release
