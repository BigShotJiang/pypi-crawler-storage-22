# Docker OAuth Setup Guide

Complete guide for running voice-vibecoder in Docker with OAuth authentication for Salesforce, Microsoft Graph, and other services.

## Overview

Voice-vibecoder uses Azure AD OAuth with On-Behalf-Of (OBO) flow to access user data in:
- Microsoft Graph (Outlook, Calendar, OneDrive)
- Salesforce (CRM, contacts, opportunities)
- Other Azure-integrated services

This works seamlessly in **both Docker and Azure** environments.

## Architecture

```
User Browser                 Docker Container
    │                             │
    ├─► Azure AD Login            │
    │   (authenticate)             │
    │                              │
    ├─► Grant permissions          │
    │                              │
    └─► Redirect with code ────►  │
                                   │
                          voice-vibecoder
                          - Exchanges code for user token
                          - Performs OBO token exchange
                          - Stores tokens in volume
                                   │
                                   ├─► OpenClaw Skills
                                   │   (with injected tokens)
                                   │
                                   ├─► Microsoft Graph API
                                   └─► Salesforce API
```

## Prerequisites

### 1. Azure AD App Registration

Create an Azure AD app registration with these settings:

**Redirect URIs:**
- `http://localhost:8765/callback` (for local Docker)
- `https://your-deployment.azurewebsites.net/callback` (for Azure)

**API Permissions:**
- `Microsoft Graph`:
  - `Mail.Read`
  - `Mail.Send`
  - `Mail.ReadWrite`
  - `Calendars.ReadWrite`
  - `User.Read`
- `Salesforce`:
  - `full` (or specific permissions)
  - `refresh_token`
  - `openid`

**Client Secret:**
- Create a client secret (needed for OBO flow)
- Copy the value immediately (shown only once)

### 2. Environment Variables

Create `.env` file in project root:

```bash
# Azure AD Configuration
AZURE_AD_TENANT_ID=your-tenant-id
AZURE_AD_CLIENT_ID=your-client-id
AZURE_AD_SECRET=your-client-secret

# OpenAI (for voice)
OPENAI_API_KEY=your-openai-key

# Salesforce (optional - only if using service-level auth)
SALESFORCE_CONSUMER_KEY=your-salesforce-key
SALESFORCE_CONSUMER_SECRET=your-salesforce-secret

# Default user email (for email operations)
DEFAULT_USER_EMAIL=your.email@company.com

# OpenClaw Gateway (usually default)
OPENCLAW_GATEWAY_URL=ws://openclaw:18789

# Claude API (for code editing)
ANTHROPIC_API_KEY=your-anthropic-key
```

## Running in Docker

### Docker Compose (Recommended)

```bash
# Start services
docker-compose up -d

# View logs
docker-compose logs -f voice-vibecoder

# First-time OAuth setup (see below)
docker-compose exec voice-vibecoder vibecoder --login

# Use voice-vibecoder
docker-compose exec voice-vibecoder vibecoder
```

### OAuth Flow in Docker

#### Option 1: Device Code Flow (Headless/SSH)

Best for:
- Headless servers
- SSH sessions
- CI/CD pipelines

```bash
# Start voice-vibecoder with device code login
docker-compose run voice-vibecoder vibecoder --login --device-code

# Output:
# ============================================================
# AZURE AD AUTHENTICATION
# ============================================================
# To sign in, use a web browser to open the page
# https://microsoft.com/devicelogin
# and enter the code ABC12DEF to authenticate.
# ============================================================

# On your local machine/phone:
# 1. Open https://microsoft.com/devicelogin
# 2. Enter code ABC12DEF
# 3. Sign in with your account
# 4. Grant permissions
# 5. Return to terminal - login complete!
```

#### Option 2: Interactive Browser Flow (Docker Desktop)

Best for:
- Local Docker Desktop
- Development environments

```bash
# Port 8765 must be exposed for OAuth callback
docker-compose run -p 8765:8765 voice-vibecoder vibecoder --login

# This will:
# 1. Open your default browser
# 2. Navigate to Azure AD login
# 3. After login, redirect to http://localhost:8765/callback
# 4. Tokens stored in Docker volume
```

### Token Persistence

Tokens are stored in a Docker volume, persisting across:
- Container restarts
- Image updates
- System reboots

**Volume locations:**
```yaml
volumes:
  # User tokens (OAuth)
  - vibecoder-auth:/root/.voice-vibecoder/auth

  # OpenClaw sessions
  - openclaw-data:/root/.openclaw/agents
```

**View stored tokens:**
```bash
docker-compose exec voice-vibecoder ls -la /root/.voice-vibecoder/auth
```

**Clear tokens (force re-login):**
```bash
docker-compose exec voice-vibecoder rm -rf /root/.voice-vibecoder/auth/*
```

## Running in Azure

### Azure Container Instances

```bash
# Create container with managed identity
az container create \
  --resource-group voice-vibecoder-rg \
  --name voice-vibecoder \
  --image ghcr.io/snokam/voice-vibecoder:latest \
  --assign-identity \
  --environment-variables \
    AZURE_AD_TENANT_ID=$TENANT_ID \
    AZURE_AD_CLIENT_ID=$CLIENT_ID \
    DEFAULT_USER_EMAIL=$USER_EMAIL \
  --secure-environment-variables \
    AZURE_AD_SECRET=$CLIENT_SECRET \
    OPENAI_API_KEY=$OPENAI_KEY \
    ANTHROPIC_API_KEY=$ANTHROPIC_KEY \
  --ports 8765 \
  --dns-name-label voice-vibecoder-yourname
```

**OAuth Redirect URI for Azure:**
```
https://voice-vibecoder-yourname.region.azurecontainer.io:8765/callback
```

Add this to your Azure AD app registration.

### Azure App Service

```bash
# Deploy to App Service
az webapp create \
  --resource-group voice-vibecoder-rg \
  --plan voice-vibecoder-plan \
  --name voice-vibecoder-app \
  --deployment-container-image-name ghcr.io/snokam/voice-vibecoder:latest

# Configure app settings
az webapp config appsettings set \
  --resource-group voice-vibecoder-rg \
  --name voice-vibecoder-app \
  --settings \
    AZURE_AD_TENANT_ID=$TENANT_ID \
    AZURE_AD_CLIENT_ID=$CLIENT_ID \
    AZURE_AD_SECRET=$CLIENT_SECRET \
    DEFAULT_USER_EMAIL=$USER_EMAIL \
    OPENAI_API_KEY=$OPENAI_KEY \
    ANTHROPIC_API_KEY=$ANTHROPIC_KEY
```

**OAuth Redirect URI for App Service:**
```
https://voice-vibecoder-app.azurewebsites.net/callback
```

### Managed Identity (Azure Only)

For production Azure deployments, use Managed Identity instead of client secrets:

```bash
# Enable managed identity
az webapp identity assign \
  --resource-group voice-vibecoder-rg \
  --name voice-vibecoder-app

# Grant permissions to Microsoft Graph
az ad app permission add \
  --id $CLIENT_ID \
  --api 00000003-0000-0000-c000-000000000000 \
  --api-permissions \
    e1fe6dd8-ba31-4d61-89e7-88639da4683d=Scope \
    b633e1c5-b582-4048-a93e-9f11b44c7e96=Scope
```

Voice-vibecoder automatically detects and uses Managed Identity when available.

## Connecting Services

### Connect Microsoft Outlook/Calendar

```bash
# Login with Microsoft Graph permissions
docker-compose run voice-vibecoder vibecoder --login

# Permissions required:
# - Mail.Read
# - Mail.Send
# - Mail.ReadWrite
# - Calendars.ReadWrite
```

**Test email access:**
```
You: "Summarize my unread emails"
→ OpenClaw routes to snokam-email skill
→ Skill uses GRAPH_TOKEN
→ Queries Microsoft Graph API
→ Returns email summary
```

### Connect Salesforce

**Option 1: User OAuth (Recommended)**

```bash
# Login includes Salesforce permissions
docker-compose run voice-vibecoder vibecoder --login

# During login, also authenticate with Salesforce
# Permissions required:
# - full (or specific permissions)
# - refresh_token
# - openid
```

**Option 2: Service-Level OAuth**

Add to `.env`:
```bash
SALESFORCE_CONSUMER_KEY=your-connected-app-key
SALESFORCE_CONSUMER_SECRET=your-connected-app-secret
```

**Test Salesforce access:**
```
You: "Draft a follow-up for contact John Doe"
→ OpenClaw routes to snokam-salesforce skill
→ Skill uses SALESFORCE_TOKEN
→ Queries Salesforce API
→ Generates follow-up email
```

## Troubleshooting

### "Failed to acquire token" Error

**Problem:** OAuth flow fails during login

**Solution:**
1. Check redirect URI matches Azure AD app registration
2. Verify port 8765 is accessible (not blocked by firewall)
3. Ensure `.env` file has correct credentials
4. Try device code flow instead: `--device-code`

### "No user token available for OBO exchange"

**Problem:** Not logged in or token expired

**Solution:**
```bash
# Re-authenticate
docker-compose run voice-vibecoder vibecoder --login

# Tokens are stored, but may expire after 1 hour
# Refresh tokens allow automatic renewal
```

### "OBO token exchange failed"

**Problem:** Client secret incorrect or app permissions missing

**Solution:**
1. Verify `AZURE_AD_SECRET` in `.env`
2. Check Azure AD app has required API permissions
3. Ensure permissions are **granted** (admin consent if needed)
4. Verify client secret hasn't expired

### Tokens Not Persisting

**Problem:** Must re-login after every container restart

**Solution:**
```bash
# Check volume is mounted
docker volume inspect voice-vibecoder_vibecoder-auth

# Verify token directory exists
docker-compose exec voice-vibecoder ls /root/.voice-vibecoder/auth
```

### Skills Can't Access APIs

**Problem:** Skills get 401 Unauthorized errors

**Solution:**
```bash
# Check tokens are being injected
docker-compose logs openclaw | grep TOKEN

# Verify OBO exchange is working
docker-compose logs voice-vibecoder | grep "OBO token"

# Test token manually
docker-compose exec voice-vibecoder env | grep TOKEN
```

## Security Best Practices

### 1. Never Commit Secrets

```bash
# Add to .gitignore
.env
.env.local
*.key
*.pem
auth/tokens/*
```

### 2. Rotate Client Secrets

```bash
# Create new secret in Azure AD
# Update .env
# Restart containers
docker-compose down && docker-compose up -d
```

### 3. Use Managed Identity in Production

For Azure deployments, always prefer Managed Identity over client secrets.

### 4. Limit Permissions

Only grant minimum required permissions:
- **Email**: Mail.Read (if only reading)
- **Calendar**: Calendars.Read (if only viewing)
- **Salesforce**: Specific objects, not `full`

### 5. Monitor Token Usage

```bash
# Check token refresh frequency
docker-compose logs voice-vibecoder | grep "Token refreshed"

# Alert on unusual API calls
# (configure via Azure Monitor or Application Insights)
```

## Advanced Configuration

### Custom OAuth Redirect Port

```yaml
# docker-compose.yml
services:
  voice-vibecoder:
    ports:
      - "9000:9000"  # Custom port
    environment:
      - OAUTH_REDIRECT_PORT=9000
```

Update Azure AD app redirect URI to `http://localhost:9000/callback`.

### Multiple User Support

```bash
# User 1 login
docker-compose run -e USER_SESSION=user1 voice-vibecoder vibecoder --login

# User 2 login
docker-compose run -e USER_SESSION=user2 voice-vibecoder vibecoder --login

# Switch users
docker-compose run -e USER_SESSION=user1 voice-vibecoder vibecoder
```

### Token Encryption

```yaml
# docker-compose.yml
services:
  voice-vibecoder:
    environment:
      - TOKEN_ENCRYPTION_KEY=${TOKEN_ENCRYPTION_KEY}
```

Tokens stored on disk are encrypted with this key.

## Support

- **OAuth Issues**: Check Azure AD app configuration
- **Token Issues**: Review `docker-compose logs`
- **Permission Issues**: Verify API permissions in Azure AD
- **Docker Issues**: Ensure volumes are mounted correctly

For more help, see:
- [Azure AD OAuth Documentation](https://docs.microsoft.com/en-us/azure/active-directory/develop/v2-oauth2-auth-code-flow)
- [Microsoft Graph Permissions](https://docs.microsoft.com/en-us/graph/permissions-reference)
- [Salesforce OAuth](https://help.salesforce.com/s/articleView?id=sf.remoteaccess_oauth_flows.htm)
