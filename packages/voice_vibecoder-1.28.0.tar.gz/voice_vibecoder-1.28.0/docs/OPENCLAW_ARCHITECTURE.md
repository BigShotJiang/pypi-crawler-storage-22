# OpenClaw Integration Architecture

## Overview

Transform voice-vibecoder from a coding-only assistant into a general-purpose voice AI assistant where OpenClaw acts as the task router and brain, delegating to specialized skills based on the user's intent.

## Architecture Diagram

```
┌──────────────────────────────────────┐
│  Voice-Vibecoder (UI Layer)          │
│  - OpenAI Realtime API (voice I/O)   │
│  - Textual TUI (visual feedback)     │
│  - Session management                │
└────────────────┬─────────────────────┘
                 │ WebSocket/HTTP
                 ▼
        ┌────────────────────┐
        │  OpenClaw Gateway  │ ← Task Router & AI Brain
        │  ws://127.0.0.1:18789 │
        └──────────┬──────────┘
                   │
                   ├─► [code-editor] Skill
                   │   └─► Claude Code CLI
                   │       (file editing in git worktrees)
                   │
                   ├─► [salesforce-assistant] Skill
                   │   └─► chatgpt-function API
                   │       (Salesforce follow-ups)
                   │
                   ├─► [email-manager] Skill
                   │   └─► Outlook/Gmail APIs
                   │       (email operations)
                   │
                   ├─► [web-research] Skill
                   │   └─► OpenClaw browser automation
                   │       (scraping, search)
                   │
                   ├─► [calendar-manager] Skill
                   │   └─► Google Calendar API
                   │       (scheduling, meetings)
                   │
                   ├─► [document-processor] Skill
                   │   └─► PDF/doc reading & summarization
                   │
                   └─► [system-automation] Skill
                       └─► Bash commands, file ops, cron
```

## Communication Protocol

### Connection Methods

**Option 1: WebSocket (Preferred for streaming)**
- Connect to `ws://127.0.0.1:18789`
- Handshake with connect request
- Send requests, receive streaming events
- Maintains persistent connection for real-time updates

**Option 2: HTTP API (Simpler fallback)**
- POST to `http://127.0.0.1:18789/tools/invoke`
- Request/response model
- Good for simple queries, no streaming

### WebSocket Protocol

#### 1. Connection Handshake

```javascript
// Client connects to ws://127.0.0.1:18789
// Server sends challenge:
{
  "type": "event",
  "event": "connect.challenge",
  "payload": {
    "nonce": "...",
    "ts": 1737264000000
  }
}

// Client responds with connect request:
{
  "type": "connect",
  "protocol": "gateway-2026.1",
  "client": {
    "name": "voice-vibecoder",
    "version": "1.0.0"
  },
  "role": "operator",
  "scopes": ["operator.read", "operator.write"],
  "auth": {
    "token": "<bearer_token_if_required>"
  }
}

// Server acknowledges:
{
  "type": "event",
  "event": "connect.ok",
  "payload": {
    "protocol": "gateway-2026.1",
    "deviceToken": "..."
  }
}
```

#### 2. Sending Agent Tasks

```javascript
// Send request to agent
{
  "type": "req",
  "id": "<unique_request_id>",
  "method": "agent.execute",  // or sessions.send for direct message
  "params": {
    "sessionKey": "voice-vibecoder:main",
    "message": "Fix the authentication bug in login component",
    "context": {
      "cwd": "/path/to/worktree",
      "branch": "feat-auth-fix"
    }
  }
}
```

#### 3. Receiving Streaming Events

```javascript
// Tool execution started
{
  "type": "event",
  "event": "tool.execution.started",
  "payload": {
    "tool": "code-editor",
    "sessionKey": "voice-vibecoder:main"
  }
}

// Tool output streaming
{
  "type": "event",
  "event": "tool.execution.update",
  "payload": {
    "tool": "code-editor",
    "output": "[Edit] login.tsx",
    "category": "file_edit"
  }
}

// Tool execution completed
{
  "type": "event",
  "event": "tool.execution.completed",
  "payload": {
    "tool": "code-editor",
    "result": "Fixed authentication flow",
    "sessionKey": "voice-vibecoder:main"
  }
}

// Response to original request
{
  "type": "res",
  "id": "<request_id>",
  "ok": true,
  "payload": {
    "result": "Fixed authentication flow by updating token validation",
    "sessionId": "voice-vibecoder:main:abc123"
  }
}
```

### HTTP API (Fallback)

```bash
POST http://127.0.0.1:18789/tools/invoke
Authorization: Bearer <token>
Content-Type: application/json

{
  "tool": "agent.execute",
  "sessionKey": "voice-vibecoder:main",
  "args": {
    "message": "Draft follow-up for contact ID 12345",
    "skill": "salesforce-assistant"
  }
}
```

## Implementation Components

### 1. OpenClawRouter (New)

```python
# src/voice_vibecoder/code_providers/openclaw.py

class OpenClawRouter:
    """Routes tasks through OpenClaw Gateway."""

    async def run(
        self,
        message: str,
        cwd: str,
        session_id: str | None = None,
        on_output: Callable[[AgentOutput], None] | None = None,
        can_use_tool: Callable[[str, dict, Any], Awaitable[Any]] | None = None,
    ) -> AgentResult:
        """Execute task via OpenClaw Gateway."""
        # 1. Connect to WebSocket
        # 2. Send agent.execute request
        # 3. Stream events → map to AgentOutput
        # 4. Return AgentResult
```

### 2. Event Mapping

Map OpenClaw events to voice-vibecoder's `AgentOutput` categories:

| OpenClaw Event | AgentOutput Category |
|---|---|
| tool.execution.update (file edit) | `file_edit` |
| tool.execution.update (bash) | `bash` |
| tool.execution.update (other tool) | `tool_call` |
| agent response text | `text` |
| tool result | `tool_result` |
| diff lines | `diff_add` / `diff_del` |

### 3. Session Management

- Each voice-vibecoder instance maps to an OpenClaw session
- Session key format: `voice-vibecoder:{branch}` or `voice-vibecoder:main`
- OpenClaw maintains conversation history across restarts
- Sessions persist in `~/.openclaw/agents/<agentId>/sessions`

## OpenClaw Skills

Skills live in `~/.openclaw/workspace/skills/snokam-*` directories.

### Skill 1: code-editor

```markdown
---
name: code-editor
description: Edit code files using Claude Code in git worktrees
requires:
  bins:
    - claude
---

# Code Editor Skill

When the user asks to write, edit, refactor, or fix code:

1. Ensure we're in the correct git worktree: `cd $WORKTREE_PATH`
2. Execute Claude Code: `claude "$TASK"`
3. Stream output back to voice-vibecoder

Example: "Fix the authentication bug" → `cd ~/project-auth && claude "Fix authentication bug"`
```

### Skill 2: salesforce-assistant

```markdown
---
name: salesforce-assistant
description: Salesforce follow-ups and contact management via chatgpt-function API
requires:
  env:
    - CHATGPT_API_TOKEN
  bins:
    - curl
    - jq
---

# Salesforce Assistant Skill

## Generate Follow-up Email for Contact

When user asks to draft follow-up for a contact:

```bash
curl "https://chatgpt.api.snokam.no/api/v1.0/sales/contact/$CONTACT_ID/followup" \
  -H "Authorization: Bearer $CHATGPT_API_TOKEN" \
  | jq -r '.result'
```

## Generate Follow-up Email for Company

When user asks to draft follow-up for a company:

```bash
curl "https://chatgpt.api.snokam.no/api/v1.0/sales/company/$COMPANY_NAME/followup" \
  -H "Authorization: Bearer $CHATGPT_API_TOKEN" \
  | jq -r '.result'
```
```

### Skill 3: email-manager

```markdown
---
name: email-manager
description: Email operations using Outlook/Gmail APIs
requires:
  env:
    - EMAIL_API_TOKEN
---

# Email Manager Skill

## Search Emails

Search for emails matching a query:
- Keywords: "invoice", "meeting notes", etc.
- Sender: "from:boss@company.com"
- Date range: "after:2026-02-01"

## Send Email

Draft and send emails with:
- To/CC/BCC recipients
- Subject and body
- Attachments (if provided)

## Summarize Unread

Fetch unread emails and provide summary with:
- Sender
- Subject
- Key points
- Action items
```

### Skill 4: web-research

```markdown
---
name: web-research
description: Web research using OpenClaw's built-in browser automation
---

# Web Research Skill

Uses OpenClaw's browser automation capabilities to:

1. Search Google/Bing for topics
2. Navigate to result pages
3. Extract and read content
4. Summarize findings
5. Compare multiple sources

Example: "Research how Netflix handles video streaming"
→ Search → Read top 5 articles → Summarize architecture patterns
```

### Skill 5: calendar-manager

```markdown
---
name: calendar-manager
description: Calendar operations using Google Calendar API
requires:
  env:
    - GOOGLE_CALENDAR_TOKEN
---

# Calendar Manager Skill

## Create Meeting

Schedule meetings with:
- Title and description
- Date/time (natural language: "next Tuesday at 2pm")
- Attendees
- Duration

## Find Available Slots

Check availability for:
- Specific people
- Time ranges
- Duration needed

## List Today's Events

Show today's calendar with:
- Time
- Event name
- Attendees
```

## Usage Examples

### Coding Task
```
User: "Fix the authentication bug in the login component"
→ OpenClaw routes to: code-editor skill
→ Skill executes: claude "Fix authentication bug in login component"
→ Voice-vibecoder shows: file edits, diffs, tool calls
```

### Sales Task
```
User: "Draft follow-ups for all contacts from the Oslo conference"
→ OpenClaw routes to: salesforce-assistant skill
→ Skill calls: chatgpt-function API → Salesforce integration
→ Voice-vibecoder shows: generated email drafts
```

### Mixed Workflow
```
User: "Research our competitor's pricing, then update our pricing page"
→ Step 1: OpenClaw routes to web-research skill
  → Browser automation searches and summarizes
→ Step 2: OpenClaw routes to code-editor skill
  → Claude Code updates pricing.tsx
→ Voice-vibecoder shows: research results, then code changes
```

### Email + Calendar
```
User: "Find available time next week for a 1-hour meeting with the team and send invites"
→ Step 1: calendar-manager checks availability
→ Step 2: calendar-manager creates event
→ Step 3: email-manager sends invites
→ Voice-vibecoder shows: available slots, created event, sent emails
```

## Benefits

1. **Unified Interface** - Single voice app for all work tasks
2. **Specialized Tools** - Each skill uses the best tool for the job
3. **Extensible** - Add new skills without changing voice-vibecoder
4. **Reuse Existing** - chatgpt-function becomes a skill
5. **Smart Routing** - OpenClaw decides which skill to use
6. **Persistent Memory** - Conversation context across sessions

## Migration Path

### Phase 1: Add OpenClaw as Option (Week 1)
- Implement `OpenClawRouter` alongside `ClaudeRunner` and `CursorRunner`
- Add to registry as selectable agent
- Test with existing coding workflow

### Phase 2: Create Basic Skills (Week 2)
- code-editor (delegates to Claude Code)
- salesforce-assistant (calls chatgpt-function)
- General Q&A (uses Claude/GPT)

### Phase 3: Expand Skills (Week 3-4)
- email-manager
- calendar-manager
- web-research
- document-processor

### Phase 4: Make OpenClaw Default (Week 5)
- Switch default from Claude → OpenClaw
- Update UI to show skill-based routing
- Enhance TUI for non-code tasks

## Technical Considerations

### Authentication
- OpenClaw Gateway may require token auth
- Configure in `~/.openclaw/config.json`:
  ```json
  {
    "gateway": {
      "auth": {
        "token": "your-secure-token"
      }
    }
  }
  ```

### Error Handling
- Connection failures → fallback to direct Claude Code
- Skill not found → route to general Q&A skill
- Timeout → cancel and retry with simpler prompt

### Performance
- WebSocket keeps connection alive → low latency
- Streaming events → real-time feedback in TUI
- Session persistence → no re-initialization overhead

### Security
- Skills run with user's permissions
- Environment variables for API tokens
- Optional TLS for remote OpenClaw Gateway

## Future Enhancements

1. **Multi-Agent Workflows** - Chain multiple skills in sequence
2. **Approval Gates** - Ask user before executing sensitive operations
3. **Cron Jobs** - "Check for new PRs every hour"
4. **Webhooks** - "When I get an email from X, create a task"
5. **Learning** - OpenClaw learns user preferences over time
6. **Remote Gateway** - Connect to team's shared OpenClaw instance

## Sources

- [OpenClaw Gateway Protocol](https://docs.openclaw.ai/gateway/protocol)
- [OpenClaw Tools Invoke API](https://docs.openclaw.ai/gateway/tools-invoke-http-api)
- [OpenClaw Skills Documentation](https://docs.openclaw.ai/tools/skills)
- [OpenClaw GitHub](https://github.com/openclaw/openclaw)
