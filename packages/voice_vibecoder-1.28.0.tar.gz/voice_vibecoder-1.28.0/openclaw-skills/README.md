# OpenClaw Skills for Voice-Vibecoder

This directory contains OpenClaw skills that extend voice-vibecoder from a coding-only assistant to a general-purpose voice AI assistant.

## Skills Overview

| Skill | Description | Key Dependencies |
|-------|-------------|------------------|
| **snokam-code-editor** | Code editing using Claude Code in git worktrees | `claude` CLI |
| **snokam-salesforce** | Salesforce follow-ups via chatgpt-function API | `curl`, `jq`, API token |
| **snokam-email** | Email operations via Microsoft Graph API | `curl`, `jq`, API token |
| **snokam-research** | Web research using browser automation | OpenClaw browser tools |

## Installation

### 1. Install OpenClaw

```bash
npm install -g openclaw
# or
yarn global add openclaw
```

### 2. Start OpenClaw Gateway

```bash
openclaw gateway start
```

The gateway runs on `ws://127.0.0.1:18789` by default.

### 3. Copy Skills to OpenClaw

```bash
# Copy all Snokam skills to OpenClaw workspace
cp -r openclaw-skills/snokam-* ~/.openclaw/workspace/skills/
```

### 4. Verify Skills are Loaded

```bash
openclaw skills list
```

You should see:
- snokam-code-editor
- snokam-salesforce
- snokam-email
- snokam-research

### 5. Configure API Tokens

Edit `~/.openclaw/config.json`:

```json
{
  "skills": {
    "snokam-salesforce": {
      "env": {
        "CHATGPT_API_TOKEN": "your-token-here"
      }
    },
    "snokam-email": {
      "env": {
        "EMAIL_API_TOKEN": "your-token-here"
      }
    }
  }
}
```

Or set environment variables:

```bash
export CHATGPT_API_TOKEN="your-token-here"
export EMAIL_API_TOKEN="your-token-here"
```

### 6. Test Skills

```bash
# Test code editor
openclaw message send --message "List all TypeScript files in src/" --skill snokam-code-editor

# Test salesforce
openclaw message send --message "Draft a follow-up for contact 12345" --skill snokam-salesforce

# Test email
openclaw message send --message "Summarize my unread emails" --skill snokam-email

# Test research
openclaw message send --message "Research Netflix's video streaming architecture" --skill snokam-research
```

## Integration with Voice-Vibecoder

### Step 1: Update Voice-Vibecoder to Use OpenClaw

The voice-vibecoder codebase needs to be updated to route tasks through OpenClaw Gateway instead of calling Claude directly.

See `docs/OPENCLAW_ARCHITECTURE.md` for the complete integration design.

### Step 2: Configure Default Agent

In voice-vibecoder settings, set OpenClaw as the default agent:

```json
{
  "default_agent": "openclaw",
  "openclaw_gateway_url": "ws://127.0.0.1:18789"
}
```

### Step 3: Use Voice Commands

Now you can use voice commands for any task:

**Coding:**
```
"Fix the authentication bug in the login component"
→ Routes to: snokam-code-editor
→ Uses: Claude Code
```

**Sales:**
```
"Draft follow-ups for contacts from the Oslo conference"
→ Routes to: snokam-salesforce
→ Uses: chatgpt-function API → Salesforce
```

**Email:**
```
"Summarize my unread emails from today"
→ Routes to: snokam-email
→ Uses: chatgpt-function API → Outlook
```

**Research:**
```
"Research our competitor's pricing strategy"
→ Routes to: snokam-research
→ Uses: OpenClaw browser automation
```

## Skill Development

### Adding a New Skill

1. Create skill directory:
```bash
mkdir -p ~/.openclaw/workspace/skills/snokam-my-skill
```

2. Create `SKILL.md`:
```markdown
---
name: snokam-my-skill
description: Brief description of what the skill does
requires:
  bins:
    - required-command
  env:
    - REQUIRED_ENV_VAR
---

# Skill Name

Describe when to use this skill and how it works.

## Examples

Show usage examples with expected inputs and outputs.
```

3. Reload skills:
```bash
openclaw skills reload
```

### Skill Best Practices

- **Clear descriptions**: Help OpenClaw route tasks correctly
- **Specific triggers**: Define when to use this skill vs others
- **Error handling**: Handle missing dependencies gracefully
- **Output formatting**: Structure output for readability
- **Documentation**: Provide examples for common use cases

### Testing Skills

```bash
# Test skill directly
openclaw message send --message "your test message" --skill skill-name

# Test with streaming output
openclaw message send --message "your test message" --skill skill-name --stream

# Test with different session
openclaw message send --message "your test message" --skill skill-name --session test-session
```

## Troubleshooting

### Skill Not Found

```bash
# Check if skill is in the right location
ls ~/.openclaw/workspace/skills/

# Reload skills
openclaw skills reload

# Check OpenClaw logs
tail -f ~/.openclaw/logs/gateway.log
```

### API Token Issues

```bash
# Verify tokens are set
echo $CHATGPT_API_TOKEN
echo $EMAIL_API_TOKEN

# Test API directly
curl -H "Authorization: Bearer $CHATGPT_API_TOKEN" \
  https://chatgpt.api.snokam.no/api/v1.0/question?input=test
```

### Dependencies Missing

```bash
# Install required tools
brew install curl jq  # macOS
apt-get install curl jq  # Linux

# Install Claude Code
npm install -g @anthropics/claude-code
# or follow: https://docs.anthropic.com/claude-code
```

### Gateway Not Running

```bash
# Check if gateway is running
openclaw gateway status

# Start gateway if not running
openclaw gateway start

# Check gateway logs
openclaw gateway logs
```

## Advanced Configuration

### Custom Gateway URL

If running OpenClaw Gateway on a different port or remote server:

```json
{
  "gateway": {
    "url": "ws://your-server:18789",
    "auth": {
      "token": "your-gateway-token"
    }
  }
}
```

### Skill-Specific Settings

Configure per-skill settings:

```json
{
  "skills": {
    "snokam-code-editor": {
      "config": {
        "default_worktree_path": "/Users/you/projects",
        "claude_model": "claude-sonnet-4-5"
      }
    },
    "snokam-salesforce": {
      "config": {
        "default_company_filter": "Norway",
        "max_followups_per_batch": 10
      }
    }
  }
}
```

### Logging

Enable debug logging for skill development:

```json
{
  "logging": {
    "level": "debug",
    "skills": {
      "snokam-code-editor": "trace",
      "snokam-salesforce": "debug"
    }
  }
}
```

## Performance Tips

1. **Cache API responses**: Avoid redundant API calls
2. **Use streaming**: For long-running tasks
3. **Parallel execution**: OpenClaw can run multiple skills concurrently
4. **Session reuse**: Maintain context across multiple tasks
5. **Rate limiting**: Respect API rate limits

## Security

- **Never commit API tokens** to version control
- **Use environment variables** or secure config files
- **Rotate tokens regularly**
- **Limit skill permissions** to what's needed
- **Monitor API usage** for unexpected activity

## Support

- Documentation: `docs/OPENCLAW_ARCHITECTURE.md`
- Issues: https://github.com/snokam/voice-vibecoder/issues
- OpenClaw Docs: https://docs.openclaw.ai

## License

MIT - Same as voice-vibecoder
