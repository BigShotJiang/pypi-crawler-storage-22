---
name: snokam-code-editor
description: Edit code files using Claude Code in git worktrees for Snokam projects
requires:
  bins:
    - claude
homepage: https://github.com/snokam/voice-vibecoder
---

# Snokam Code Editor

This skill delegates code editing tasks to Claude Code CLI, which provides specialized file editing, git awareness, and autonomous coding capabilities.

## When to Use

Use this skill when the user asks to:
- Write new code or features
- Edit existing code files
- Refactor code
- Fix bugs
- Add tests
- Update documentation in code repos

## How It Works

The skill executes Claude Code in the appropriate git worktree with the user's task.

### Basic Usage

When the user asks to edit code:

```bash
claude "$TASK"
```

### With Specific Directory

If a worktree path or branch is mentioned:

```bash
cd "$WORKTREE_PATH" && claude "$TASK"
```

### With Session Resume

If continuing a previous coding session:

```bash
claude --resume "$SESSION_ID" "$TASK"
```

## Examples

### Fix a Bug
```
User: "Fix the authentication bug in the login component"
→ claude "Fix the authentication bug in the login component"
```

### Add a Feature
```
User: "Add a logout button to the user profile page"
→ claude "Add a logout button to the user profile page"
```

### Refactor Code
```
User: "Refactor the API client to use async/await"
→ claude "Refactor the API client to use async/await"
```

### Multiple Files
```
User: "Update both the login form and the auth service to support 2FA"
→ claude "Update both the login form and the auth service to support 2FA"
```

## Output Format

The skill streams Claude Code's output, which includes:
- Text responses explaining what's being done
- Tool calls (Read, Edit, Write, Bash, etc.)
- File edit diffs showing changes
- Tool results

This output is formatted by voice-vibecoder's TUI into a visual display showing:
- File edits with syntax highlighting
- Diffs with +/- lines
- Tool execution status
- Agent reasoning

## Environment

Claude Code uses:
- Working directory from voice-vibecoder context
- Git repository detection
- Session persistence in ~/.claude/sessions
- User's Claude API key from environment
- MCP servers configured in .mcp.json

## Error Handling

If Claude Code fails:
- Check that `claude` CLI is installed and in PATH
- Verify ANTHROPIC_API_KEY is set
- Ensure working directory is a git repository
- Check for file permission issues

## Integration

This skill is called by OpenClaw when:
1. User's voice command is recognized as a coding task
2. OpenClaw routes to `snokam-code-editor` skill
3. Skill executes `claude` command
4. Output streams back through OpenClaw → voice-vibecoder
5. TUI displays real-time progress and results
