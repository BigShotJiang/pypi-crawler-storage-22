---
name: snokam-email
description: Email operations using Microsoft Graph API with OBO tokens
requires:
  env:
    - GRAPH_TOKEN
    - DEFAULT_USER_EMAIL
  bins:
    - curl
    - jq
homepage: https://graph.microsoft.com
---

# Snokam Email Manager

This skill directly accesses Microsoft Graph API using On-Behalf-Of tokens from voice-vibecoder.

## When to Use

Use this skill when the user asks to:
- Search for emails by keyword, sender, or date
- List unread emails
- Get email details
- Create draft emails
- Send emails

## Authentication

Tokens are provided by voice-vibecoder via `$GRAPH_TOKEN` environment variable.
This token is obtained through OAuth On-Behalf-Of flow acting as the authenticated user.

## API Examples

### List Recent Emails

Get the 10 most recent emails:

```bash
curl -s "https://graph.microsoft.com/v1.0/users/${DEFAULT_USER_EMAIL}/messages?\$top=10&\$select=subject,from,receivedDateTime,isRead" \
  -H "Authorization: Bearer $GRAPH_TOKEN" \
  | jq '.value[] | {subject, from: .from.emailAddress.address, received: .receivedDateTime, isRead}'
```

### List Unread Emails

Get unread emails:

```bash
curl -s "https://graph.microsoft.com/v1.0/users/${DEFAULT_USER_EMAIL}/messages?\$filter=isRead eq false&\$top=20&\$select=subject,from,receivedDateTime,bodyPreview" \
  -H "Authorization: Bearer $GRAPH_TOKEN" \
  | jq '.value[] | {subject, from: .from.emailAddress.address, preview: .bodyPreview[:100]}'
```

### Search Emails

Search by keyword:

```bash
KEYWORD="invoice"
curl -s "https://graph.microsoft.com/v1.0/users/${DEFAULT_USER_EMAIL}/messages?\$search=\"$KEYWORD\"&\$top=10" \
  -H "Authorization: Bearer $GRAPH_TOKEN" \
  | jq '.value[] | {subject, from: .from.emailAddress.address, received: .receivedDateTime}'
```

### Create Draft Email

Create a draft:

```bash
curl -s "https://graph.microsoft.com/v1.0/users/${DEFAULT_USER_EMAIL}/messages" \
  -H "Authorization: Bearer $GRAPH_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "subject": "Follow-up Meeting",
    "body": {
      "contentType": "HTML",
      "content": "<p>Hi,</p><p>Following up on our discussion...</p>"
    },
    "toRecipients": [
      {
        "emailAddress": {
          "address": "client@example.com"
        }
      }
    ]
  }' \
  | jq '{id, subject}'
```

## Examples

### Search for Emails
```
User: "Find all emails from boss@company.com about the project"
→ Query: "Find all emails from boss@company.com about the project"
→ Returns: List of matching emails with subjects and dates
```

### Summarize Unread Emails
```
User: "Summarize my unread emails"
→ Query: "Summarize my unread emails"
→ Returns: Bullet-point summary of unread messages with:
  - Sender
  - Subject
  - Key points
  - Action items
```

### Search by Date Range
```
User: "Show me emails from last week about invoices"
→ Query: "Show me emails from last week about invoices"
→ Returns: Filtered email list
```

### Draft Email
```
User: "Draft an email to client@acme.com about the meeting reschedule"
→ Query: "Draft an email to client@acme.com about rescheduling our meeting to next Tuesday"
→ Returns: Draft email content
```

### Find Attachments
```
User: "Find emails with PDF attachments from this month"
→ Query: "Find emails with PDF attachments from this month"
→ Returns: List of emails with PDF attachments
```

## Response Examples

### Search Results
```
Found 3 emails:

1. From: boss@company.com
   Subject: Project Update - Q1 Goals
   Date: 2026-02-15
   Preview: "Hi team, here are the updated Q1 goals..."

2. From: boss@company.com
   Subject: RE: Project Timeline
   Date: 2026-02-12
   Preview: "Thanks for the update. Can we discuss..."

3. From: boss@company.com
   Subject: Project Budget Approval
   Date: 2026-02-10
   Preview: "The budget has been approved..."
```

### Unread Summary
```
You have 5 unread emails:

Priority:
- From: client@acme.com - "Contract Review Needed"
  → Needs signature by Friday

- From: team@company.com - "Production Issue Alert"
  → Server downtime, requires immediate attention

General:
- From: newsletter@tech.com - "Weekly Digest"
- From: hr@company.com - "Benefits Enrollment"
- From: alerts@github.com - "PR Review Request"
```

## Advanced Usage

### Complex Queries

Combine multiple search criteria:

```
User: "Find unread emails from last 2 days about invoices or payments, excluding newsletters"
→ API handles complex filtering via natural language understanding
```

### Email Actions

The API can perform actions (if permissions allow):

```
User: "Mark all emails from newsletters as read"
→ API: Finds newsletter emails + marks as read
→ Returns: "Marked 15 emails as read"
```

### Email Composition with Context

```
User: "Reply to the latest email from client@acme.com saying we'll reschedule to next week"
→ API: Finds latest email + drafts reply with context
→ Returns: Draft reply ready to send
```

## Integration with Salesforce

Combine with salesforce skill for powerful workflows:

```
User: "Find the email thread with Acme Corp and draft a follow-up"
→ Step 1: snokam-email finds email thread
→ Step 2: snokam-salesforce drafts follow-up using Salesforce data
→ Returns: Context-aware follow-up email
```

## Streaming Mode

For real-time responses on longer queries:

```bash
curl -N "https://chatgpt.api.snokam.no/api/v1.0/question/async?input=$QUERY&addApiTools=true" \
  -H "Authorization: Bearer $EMAIL_API_TOKEN"
```

## Environment Setup

Set your API token (same as Salesforce):

```bash
export EMAIL_API_TOKEN="$CHATGPT_API_TOKEN"
```

## Permissions

The API requires Microsoft Graph API permissions:
- Mail.Read - Read emails
- Mail.Send - Send emails
- Mail.ReadWrite - Mark as read/unread
- MailboxSettings.Read - Get mailbox settings

These are configured in the chatgpt-function Azure app registration.

## Error Handling

Common issues:
- **401 Unauthorized**: Check EMAIL_API_TOKEN is valid
- **403 Forbidden**: User doesn't have permission for requested operation
- **404 Not Found**: Email or folder doesn't exist
- **429 Too Many Requests**: Rate limited, retry after delay

## Rate Limiting

- Max 100 email API calls per minute
- Max 1000 per hour
- Search queries count as single call
- Batch operations may count multiple

## Privacy & Security

- All API calls over HTTPS
- OAuth2 user authentication
- Email content never stored by chatgpt-function
- Logs only metadata (sender, subject, date)
- Full compliance with data retention policies

## Integration Flow

1. User: "Summarize my unread emails"
2. OpenClaw routes to `snokam-email` skill
3. Skill calls chatgpt-function Q&A API
4. API queries Microsoft Graph → Outlook
5. AI summarizes email content
6. Response streams back to voice-vibecoder
7. User hears/sees summary in TUI
