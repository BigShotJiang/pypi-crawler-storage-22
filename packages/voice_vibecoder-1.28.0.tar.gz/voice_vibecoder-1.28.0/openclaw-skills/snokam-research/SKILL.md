---
name: snokam-research
description: Web research and information gathering using browser automation and search
---

# Snokam Web Research

This skill performs web research by leveraging OpenClaw's built-in browser automation capabilities, web search, and content extraction tools.

## When to Use

Use this skill when the user asks to:
- Research a topic or technology
- Find information about competitors
- Compare products or services
- Gather data from websites
- Summarize web content
- Monitor websites for changes

## Built-in OpenClaw Tools

This skill uses OpenClaw's native capabilities:

### 1. Web Search

Search Google, Bing, or DuckDuckGo:

```
When user asks to research a topic:
- Use OpenClaw's web_search tool
- Query: "$USER_TOPIC"
- Get top 10 results with titles and snippets
```

### 2. Browser Automation

Navigate and interact with web pages:

```
When user asks to extract information from a website:
- Use OpenClaw's browser tool
- Navigate to URL
- Extract relevant content
- Take screenshots if needed
- Follow links to gather more data
```

### 3. Content Extraction

Read and process web content:

```
When user provides a URL or article:
- Fetch the content
- Extract main text (remove ads, navigation)
- Summarize key points
- Identify important data/facts
```

## Examples

### Research a Technology
```
User: "Research how Netflix handles video streaming at scale"

Process:
1. web_search: "Netflix video streaming architecture"
2. Visit top 3 technical articles
3. Extract key points about:
   - CDN strategy
   - Encoding pipeline
   - Adaptive bitrate streaming
4. Summarize findings
```

### Competitor Analysis
```
User: "What are our competitors' pricing models?"

Process:
1. web_search: "[competitor name] pricing"
2. Navigate to pricing pages
3. Extract pricing tiers and features
4. Create comparison table
5. Analyze differences
```

### Monitor Website Changes
```
User: "Check if Stripe's API documentation has been updated since last week"

Process:
1. Navigate to Stripe docs
2. Extract current content
3. Compare with previous snapshot (if available)
4. Highlight changes
```

### Find Latest Information
```
User: "What are the latest developments in AI agents?"

Process:
1. web_search: "AI agents 2026 latest developments"
2. Filter results by date (last 30 days)
3. Visit top news sources and blogs
4. Summarize key trends and announcements
```

### Product Comparison
```
User: "Compare AWS Lambda vs Google Cloud Functions pricing"

Process:
1. web_search: "AWS Lambda pricing 2026"
2. web_search: "Google Cloud Functions pricing 2026"
3. Navigate to pricing pages
4. Extract pricing tables
5. Create side-by-side comparison
6. Highlight cost differences for common use cases
```

## Output Format

### Research Summary

```
Topic: Netflix Video Streaming Architecture

Key Findings:
1. CDN Strategy
   - Open Connect CDN with 17,000+ servers globally
   - 95% of traffic served from ISP networks
   - Source: Netflix Tech Blog

2. Encoding Pipeline
   - Per-title encoding optimization
   - 1,500+ encoding profiles
   - AV1 codec for 30% bandwidth savings
   - Source: Netflix Research

3. Adaptive Bitrate
   - Dynamic Optimizer for network conditions
   - Predictive caching based on viewing patterns
   - Source: AWS re:Invent 2025 talk

Summary:
Netflix uses a multi-layered approach combining global CDN,
advanced encoding, and ML-driven optimization to deliver
high-quality video at scale.

Sources:
- https://netflixtechblog.com/...
- https://research.netflix.com/...
- https://youtube.com/watch?v=...
```

### Competitor Comparison

```
Pricing Comparison: Project Management Tools

Asana:
- Free: Up to 15 users
- Premium: $10.99/user/month
- Business: $24.99/user/month
Source: https://asana.com/pricing

Monday.com:
- Free: Up to 2 users
- Basic: $8/user/month
- Standard: $10/user/month
- Pro: $16/user/month
Source: https://monday.com/pricing

Jira:
- Free: Up to 10 users
- Standard: $7.75/user/month
- Premium: $15.25/user/month
Source: https://www.atlassian.com/software/jira/pricing

Analysis:
- Monday.com offers lowest entry price for small teams
- Asana has most generous free tier
- Jira provides best value for software development teams
```

## Advanced Features

### Multi-Step Research

Chain multiple research steps:

```
User: "Research competitor pricing, then suggest how we should price our product"

Process:
1. Step 1: Research competitor pricing (web research)
2. Step 2: Analyze market positioning
3. Step 3: Recommend pricing strategy
4. (Optional) Step 4: Draft pricing page content (code-editor skill)
```

### Content Monitoring

Set up periodic checks:

```
User: "Monitor TechCrunch for articles about our company"

Setup:
- web_search: "site:techcrunch.com [company name]"
- Schedule: Daily at 9am
- Alert: If new articles found, summarize and notify
```

### Data Extraction

Extract structured data from websites:

```
User: "Get the top 10 trending repositories on GitHub today"

Process:
1. Navigate to github.com/trending
2. Extract repository data:
   - Name
   - Stars
   - Description
   - Language
3. Format as table
```

## Integration with Other Skills

### Research → Code

```
User: "Research how to implement OAuth2, then add it to our app"

Flow:
1. snokam-research: Find OAuth2 implementation guides
2. snokam-research: Summarize best practices
3. snokam-code-editor: Implement OAuth2 using findings
```

### Research → Sales

```
User: "Research Acme Corp's tech stack, then draft a personalized pitch"

Flow:
1. snokam-research: Find their tech stack from job postings, blog, etc.
2. snokam-salesforce: Get contact info from Salesforce
3. snokam-salesforce: Generate pitch mentioning their tech stack
```

## Browser Automation Examples

### Login and Extract Data

```
When user needs data from authenticated site:
1. Navigate to login page
2. Fill credentials (from secure storage)
3. Navigate to target page
4. Extract data
5. Logout
```

### Form Filling

```
When user asks to fill out forms:
1. Navigate to form URL
2. Fill fields based on user data
3. Submit or save draft
4. Confirm submission
```

### Screenshots

```
When user asks for visual proof:
1. Navigate to URL
2. Wait for page load
3. Take full-page screenshot
4. Save or display in TUI
```

## Error Handling

Common issues:
- **Page not loading**: Retry with timeout increase
- **Content blocked**: Try alternative sources
- **Rate limited**: Implement backoff, use rotation
- **Stale data**: Check last-modified dates
- **CAPTCHA**: Alert user, may need manual intervention

## Rate Limiting & Ethics

- Respect robots.txt
- Don't overwhelm servers (max 1 req/second per domain)
- Cache results to avoid redundant requests
- Use official APIs when available
- Identify as OpenClaw bot in User-Agent

## Privacy

- Clear browser data after sensitive research
- Don't store credentials in logs
- Respect site privacy policies
- Use incognito mode for sensitive topics

## Performance

- Parallel searches for faster results
- Cache frequently accessed pages
- Prefetch related content
- Use headless browser for speed
- Abort slow requests after timeout

## Integration Flow

1. User: "Research our competitor's pricing"
2. OpenClaw routes to `snokam-research` skill
3. Skill uses browser automation + web search
4. Extracts and summarizes information
5. Results stream back to voice-vibecoder
6. User sees formatted research report in TUI
