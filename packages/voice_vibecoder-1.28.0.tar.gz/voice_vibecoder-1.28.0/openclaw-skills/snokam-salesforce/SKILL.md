---
name: snokam-salesforce
description: Salesforce operations using direct API access with OBO tokens
requires:
  env:
    - SALESFORCE_TOKEN
  bins:
    - curl
    - jq
homepage: https://snokam.my.salesforce.com
---

# Snokam Salesforce Assistant

This skill directly accesses Salesforce REST API using On-Behalf-Of tokens from voice-vibecoder.

## When to Use

Use this skill when the user asks to:
- Find contacts or companies
- Get contact/account information
- Query Salesforce data
- List recent activities

## Authentication

Tokens are provided by voice-vibecoder via `$SALESFORCE_TOKEN` environment variable.
This token is obtained through OAuth On-Behalf-Of flow acting as the authenticated user.

## API Examples

### Query Contacts

Search for a contact by name:

```bash
CONTACT_NAME="John Doe"
SOQL="SELECT Id, Name, Email, Phone, Account.Name FROM Contact WHERE Name LIKE '%${CONTACT_NAME}%' LIMIT 10"

curl -s "https://snokam.my.salesforce.com/services/data/v62.0/query?q=$(echo $SOQL | jq -sRr @uri)" \
  -H "Authorization: Bearer $SALESFORCE_TOKEN" \
  | jq '.records'
```

### Get Contact Details

Get full details for a contact by ID:

```bash
CONTACT_ID="003XXXXXXXXXXXXXXX"

curl -s "https://snokam.my.salesforce.com/services/data/v62.0/sobjects/Contact/$CONTACT_ID" \
  -H "Authorization: Bearer $SALESFORCE_TOKEN" \
  | jq '.'
```

### Query Accounts (Companies)

Search for an account by name:

```bash
COMPANY_NAME="Acme Corp"
SOQL="SELECT Id, Name, Industry, Website, Phone, Owner.Name FROM Account WHERE Name LIKE '%${COMPANY_NAME}%' LIMIT 5"

curl -s "https://snokam.my.salesforce.com/services/data/v62.0/query?q=$(echo $SOQL | jq -sRr @uri)" \
  -H "Authorization: Bearer $SALESFORCE_TOKEN" \
  | jq '.records'
```

## Examples

### Follow-up for Specific Contact
```
User: "Draft a follow-up email for contact ID 12345"
→ curl https://chatgpt.api.snokam.no/api/v1.0/sales/contact/12345/followup
→ Returns: Generated email draft
```

### Follow-up for Company
```
User: "Draft a follow-up for Acme Corporation"
→ curl https://chatgpt.api.snokam.no/api/v1.0/sales/company?companyName=Acme%20Corporation
→ Returns: Generated email draft
```

### Batch Follow-ups
```
User: "Draft follow-ups for all contacts from last week's conference"
→ First, query Salesforce for contacts (via Q&A API)
→ Then, call followup endpoint for each contact
→ Returns: Multiple email drafts
```

### General Question
```
User: "What's the status of the deal with Microsoft?"
→ curl https://chatgpt.api.snokam.no/api/v1.0/question?input=What's%20the%20status%20of%20the%20deal%20with%20Microsoft
→ Returns: Answer based on Salesforce data
```

## Response Format

### Successful Follow-up Generation
```json
{
  "success": true,
  "message": "Follow-up email generated successfully",
  "result": "Subject: Following up on our conversation\n\nHi John,\n\n...",
  "contactId": "12345",
  "companyName": "Acme Corp"
}
```

### Error Response
```json
{
  "error": "Contact not found",
  "message": "Please provide a valid contact ID"
}
```

## Environment Setup

Set your API token in the environment:

```bash
export CHATGPT_API_TOKEN="your-secure-token-here"
```

Or configure in OpenClaw's config:

```json
{
  "skills": {
    "snokam-salesforce": {
      "apiKey": "your-secure-token-here"
    }
  }
}
```

## Integration Flow

1. User makes voice command: "Draft follow-up for contact 12345"
2. OpenClaw recognizes it as a Salesforce task
3. Routes to `snokam-salesforce` skill
4. Skill calls chatgpt-function API
5. API queries Salesforce, uses AI to generate email
6. Result streams back through OpenClaw → voice-vibecoder
7. User sees generated email in TUI

## Advanced Usage

### Streaming Responses

For longer conversations, use the async endpoint:

```bash
curl -N "https://chatgpt.api.snokam.no/api/v1.0/question/async?input=$QUESTION" \
  -H "Authorization: Bearer $CHATGPT_API_TOKEN"
```

This streams the response in real-time.

### Custom Prompts

Add custom context to the follow-up:

```bash
curl -s "https://chatgpt.api.snokam.no/api/v1.0/sales/contact/$CONTACT_ID/followup" \
  -H "Authorization: Bearer $CHATGPT_API_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "additionalContext": "Mention the pricing discussion from last meeting"
  }' \
  | jq -r '.result'
```

## Error Handling

If API calls fail:
- Check that CHATGPT_API_TOKEN is set correctly
- Verify the API is accessible (https://chatgpt.api.snokam.no)
- Check contact/company IDs are valid
- Review API logs for detailed errors

## Rate Limiting

The chatgpt-function API has rate limits:
- Max 100 requests per minute
- Max 1000 requests per hour
- Streaming responses count as single request

## Security

- API token is required for all requests
- OAuth2 authentication for user-specific data
- All requests over HTTPS
- Tokens stored securely in environment/config
