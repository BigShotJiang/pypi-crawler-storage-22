"""Application-level configuration for voice-vibecoder.

VoiceConfig lets embedders customize directories, startup behavior,
system instructions, and the default helper instance name.

Standalone defaults use platformdirs (XDG on Linux, ~/Library on macOS, AppData on Windows).
Embedders can override any directory to colocate everything (e.g. ~/.snokam/).
"""

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Callable

from platformdirs import user_config_dir, user_data_dir, user_log_dir

_APP_NAME = "voice-vibecoder"


def _default_config_dir() -> Path:
    return Path(user_config_dir(_APP_NAME))


def _default_data_dir() -> Path:
    return Path(user_data_dir(_APP_NAME))


def _default_log_dir() -> Path:
    return Path(user_log_dir(_APP_NAME))


@dataclass
class VoiceConfig:
    """Configuration passed to VoiceCodingScreen and propagated to all modules."""

    app_name: str = "Voice Code Assistant"

    # Settings (API keys, model config) — e.g. realtime.json
    config_dir: Path = field(default_factory=_default_config_dir)

    # Runtime state (instances, session transcript) — e.g. realtime-instances.json
    data_dir: Path = field(default_factory=_default_data_dir)

    # Conversation logs
    log_dir: Path = field(default_factory=_default_log_dir)

    # Directory where git worktrees are created for branch instances.
    # Default: None → resolved at runtime to repo_root.parent (sibling dirs).
    worktrees_dir: Path | None = None

    # Called after session connects.
    # Signature: on_startup(send_to_agent, switch_agent)
    #   send_to_agent(message, branch=None, agent=None) -> str
    #   switch_agent(agent, branch=None) -> str
    on_startup: Callable | None = None

    # Override default system instructions per language key ("no", "en", "sv").
    system_instructions: dict[str, str] | None = None

    # Name of the default helper instance.
    default_instance_name: str = "helper"
