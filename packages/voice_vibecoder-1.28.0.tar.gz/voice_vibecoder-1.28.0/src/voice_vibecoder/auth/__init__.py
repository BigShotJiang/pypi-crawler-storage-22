"""Azure AD authentication for voice-vibecoder."""

from voice_vibecoder.auth.azure_auth import (
    AzureAuthenticator,
    get_authenticator,
    ensure_authenticated,
)

__all__ = [
    "AzureAuthenticator",
    "get_authenticator",
    "ensure_authenticated",
]
