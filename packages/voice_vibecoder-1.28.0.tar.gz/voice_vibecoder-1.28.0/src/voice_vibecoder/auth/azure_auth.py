"""Azure AD authentication with On-Behalf-Of token flow.

Handles user login and OBO token exchange for downstream APIs like
Microsoft Graph and Salesforce.
"""

import os
import logging
from typing import Optional
from msal import ConfidentialClientApplication, PublicClientApplication
import webbrowser
from http.server import HTTPServer, BaseHTTPRequestHandler
from urllib.parse import urlparse, parse_qs
import threading

logger = logging.getLogger(__name__)

# Azure AD configuration
TENANT_ID = os.getenv("AZURE_AD_TENANT_ID")
CLIENT_ID = os.getenv("AZURE_AD_CLIENT_ID")
CLIENT_SECRET = os.getenv("AZURE_AD_SECRET")  # Only needed for OBO exchange

# OAuth scopes
USER_SCOPES = [
    "https://graph.microsoft.com/.default",
    "offline_access",  # For refresh tokens
]

# Downstream API scopes for OBO
GRAPH_SCOPE = "https://graph.microsoft.com/.default"
SALESFORCE_SCOPE = "https://snokam.my.salesforce.com/.default"


class AuthCallbackHandler(BaseHTTPRequestHandler):
    """Handles OAuth callback from Azure AD."""

    auth_code: Optional[str] = None

    def do_GET(self):
        """Handle OAuth redirect."""
        query = parse_qs(urlparse(self.path).query)

        if 'code' in query:
            AuthCallbackHandler.auth_code = query['code'][0]
            self.send_response(200)
            self.send_header('Content-type', 'text/html')
            self.end_headers()
            self.wfile.write(b"""
                <html><body>
                <h1>Authentication successful!</h1>
                <p>You can close this window and return to voice-vibecoder.</p>
                <script>window.close();</script>
                </body></html>
            """)
        else:
            self.send_response(400)
            self.end_headers()

    def log_message(self, format, *args):
        """Suppress HTTP server logs."""
        pass


class AzureAuthenticator:
    """Handles Azure AD authentication and OBO token exchange."""

    def __init__(self):
        if not all([TENANT_ID, CLIENT_ID]):
            raise ValueError(
                "AZURE_AD_TENANT_ID and AZURE_AD_CLIENT_ID must be set. "
                "For OBO token exchange, AZURE_AD_SECRET is also required."
            )

        # Public client for user login
        self.public_app = PublicClientApplication(
            client_id=CLIENT_ID,
            authority=f"https://login.microsoftonline.com/{TENANT_ID}"
        )

        # Confidential client for OBO exchange
        if CLIENT_SECRET:
            self.confidential_app = ConfidentialClientApplication(
                client_id=CLIENT_ID,
                client_credential=CLIENT_SECRET,
                authority=f"https://login.microsoftonline.com/{TENANT_ID}"
            )
        else:
            self.confidential_app = None

        self.user_token: Optional[str] = None
        self.refresh_token: Optional[str] = None

    def login_interactive(self, redirect_port: int = 8765) -> bool:
        """
        Perform interactive user login via browser.

        Args:
            redirect_port: Port for OAuth redirect (default: 8765)

        Returns:
            True if login successful
        """
        redirect_uri = f"http://localhost:{redirect_port}/callback"

        # Get auth URL
        auth_url = self.public_app.get_authorization_request_url(
            scopes=USER_SCOPES,
            redirect_uri=redirect_uri
        )

        logger.info("Opening browser for Azure AD login...")
        webbrowser.open(auth_url)

        # Start callback server
        AuthCallbackHandler.auth_code = None
        server = HTTPServer(('localhost', redirect_port), AuthCallbackHandler)

        # Wait for callback
        logger.info(f"Waiting for OAuth callback on port {redirect_port}...")
        while AuthCallbackHandler.auth_code is None:
            server.handle_request()

        auth_code = AuthCallbackHandler.auth_code
        server.server_close()

        if not auth_code:
            logger.error("Failed to get authorization code")
            return False

        # Exchange code for token
        result = self.public_app.acquire_token_by_authorization_code(
            code=auth_code,
            scopes=USER_SCOPES,
            redirect_uri=redirect_uri
        )

        if "access_token" in result:
            self.user_token = result["access_token"]
            self.refresh_token = result.get("refresh_token")
            logger.info("Login successful!")
            return True
        else:
            error = result.get("error_description", result.get("error", "Unknown error"))
            logger.error(f"Failed to acquire token: {error}")
            return False

    def login_device_code(self) -> bool:
        """
        Perform device code flow login (for headless/Docker environments).

        Returns:
            True if login successful
        """
        flow = self.public_app.initiate_device_flow(scopes=USER_SCOPES)

        if "user_code" not in flow:
            raise ValueError("Failed to create device flow")

        # Show device code to user
        print("\n" + "="*60)
        print("AZURE AD AUTHENTICATION")
        print("="*60)
        print(flow["message"])
        print("="*60 + "\n")

        # Wait for user to complete authentication
        result = self.public_app.acquire_token_by_device_flow(flow)

        if "access_token" in result:
            self.user_token = result["access_token"]
            self.refresh_token = result.get("refresh_token")
            logger.info("Login successful!")
            return True
        else:
            error = result.get("error_description", result.get("error", "Unknown error"))
            logger.error(f"Failed to acquire token: {error}")
            return False

    def refresh_user_token(self) -> bool:
        """
        Refresh user token using refresh token.

        Returns:
            True if refresh successful
        """
        if not self.refresh_token:
            logger.warning("No refresh token available")
            return False

        result = self.public_app.acquire_token_by_refresh_token(
            refresh_token=self.refresh_token,
            scopes=USER_SCOPES
        )

        if "access_token" in result:
            self.user_token = result["access_token"]
            self.refresh_token = result.get("refresh_token", self.refresh_token)
            logger.info("Token refreshed successfully")
            return True
        else:
            logger.error("Failed to refresh token")
            return False

    def get_obo_token(self, scope: str) -> Optional[str]:
        """
        Exchange user token for downstream API token (On-Behalf-Of flow).

        Args:
            scope: Target API scope (e.g., "https://graph.microsoft.com/.default")

        Returns:
            Access token for downstream API, or None if exchange fails
        """
        if not self.confidential_app:
            logger.error("OBO requires CLIENT_SECRET to be set")
            return None

        if not self.user_token:
            logger.error("No user token available for OBO exchange")
            return None

        result = self.confidential_app.acquire_token_on_behalf_of(
            user_assertion=self.user_token,
            scopes=[scope]
        )

        if "access_token" in result:
            logger.info(f"OBO token acquired for scope: {scope}")
            return result["access_token"]
        else:
            error = result.get("error_description", result.get("error", "Unknown error"))
            logger.error(f"OBO token exchange failed: {error}")
            return None

    def get_graph_token(self) -> Optional[str]:
        """Get Microsoft Graph API token via OBO."""
        return self.get_obo_token(GRAPH_SCOPE)

    def get_salesforce_token(self) -> Optional[str]:
        """Get Salesforce API token via OBO."""
        return self.get_obo_token(SALESFORCE_SCOPE)

    def get_all_downstream_tokens(self) -> dict[str, Optional[str]]:
        """
        Get all downstream API tokens for OpenClaw skills.

        Returns:
            Dictionary of token names to tokens
        """
        return {
            "GRAPH_TOKEN": self.get_graph_token(),
            "SALESFORCE_TOKEN": self.get_salesforce_token(),
        }


# Global authenticator instance
_authenticator: Optional[AzureAuthenticator] = None


def get_authenticator() -> AzureAuthenticator:
    """Get or create global authenticator instance."""
    global _authenticator
    if _authenticator is None:
        _authenticator = AzureAuthenticator()
    return _authenticator


def ensure_authenticated(use_device_code: bool = False) -> AzureAuthenticator:
    """
    Ensure user is authenticated, prompting for login if needed.

    Args:
        use_device_code: Use device code flow instead of interactive browser

    Returns:
        Authenticated AzureAuthenticator instance
    """
    auth = get_authenticator()

    if auth.user_token:
        # Try to refresh if we have a refresh token
        if auth.refresh_token:
            if auth.refresh_user_token():
                return auth
        # Token still valid, return as-is
        return auth

    # Need to login
    logger.info("Authentication required")

    if use_device_code:
        success = auth.login_device_code()
    else:
        success = auth.login_interactive()

    if not success:
        raise RuntimeError("Authentication failed")

    return auth
