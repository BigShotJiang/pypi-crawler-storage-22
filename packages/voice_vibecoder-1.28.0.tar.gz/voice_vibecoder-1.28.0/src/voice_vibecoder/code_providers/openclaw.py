"""OpenClaw Gateway router.

Routes tasks through OpenClaw Gateway which delegates to specialized skills
(coding, email, sales, research, etc.). Handles WebSocket communication,
token injection, and event streaming.
"""

from __future__ import annotations

import asyncio
import json
import logging
import os
import uuid
from typing import Any, Awaitable, Callable

import aiohttp

from voice_vibecoder.code_providers import AgentOutput, AgentResult
from voice_vibecoder.auth import get_authenticator

logger = logging.getLogger(__name__)


class OpenClawRouter:
    """AgentRunner implementation using OpenClaw Gateway."""

    def __init__(self, gateway_url: str = "ws://127.0.0.1:18789"):
        """
        Initialize OpenClaw router.

        Args:
            gateway_url: WebSocket URL of OpenClaw Gateway
        """
        self._gateway_url = gateway_url
        self._ws: aiohttp.ClientWebSocketResponse | None = None
        self._session: aiohttp.ClientSession | None = None

    async def run(
        self,
        message: str,
        cwd: str,
        session_id: str | None = None,
        on_output: Callable[[AgentOutput], None] | None = None,
        can_use_tool: Callable[[str, dict, Any], Awaitable[Any]] | None = None,
    ) -> AgentResult:
        """
        Execute task via OpenClaw Gateway.

        Args:
            message: User's task/question
            cwd: Working directory
            session_id: Session ID for context persistence
            on_output: Callback for streaming output
            can_use_tool: Callback for tool permission (not used by OpenClaw)

        Returns:
            AgentResult with response and session ID
        """
        # Get auth tokens for skills
        tokens = self._get_downstream_tokens()

        try:
            # Create session if needed
            if self._session is None or self._session.closed:
                self._session = aiohttp.ClientSession()

            # Connect to OpenClaw Gateway
            async with self._session.ws_connect(self._gateway_url) as ws:
                self._ws = ws

                # Handshake
                await self._handshake(ws)

                # Send task
                request_id = str(uuid.uuid4())
                await self._send_agent_task(ws, request_id, message, cwd, session_id, tokens)

                # Stream responses
                result = await self._stream_responses(ws, request_id, on_output)

                self._ws = None
                return result

        except asyncio.CancelledError:
            self.cancel()
            raise
        except Exception as e:
            logger.error(f"OpenClaw error: {e}")
            raise RuntimeError(f"Failed to communicate with OpenClaw Gateway: {e}") from e

    def cancel(self) -> bool:
        """Cancel running task."""
        if self._ws and not self._ws.closed:
            asyncio.create_task(self._ws.close())
            return True
        return False

    async def _handshake(self, ws: aiohttp.ClientWebSocketResponse) -> None:
        """
        Perform OpenClaw Gateway handshake.

        Args:
            ws: WebSocket connection
        """
        # Wait for challenge
        msg = await ws.receive()
        if msg.type != aiohttp.WSMsgType.TEXT:
            raise RuntimeError("Expected challenge from OpenClaw Gateway")

        challenge = json.loads(msg.data)
        if challenge.get("event") != "connect.challenge":
            raise RuntimeError(f"Unexpected event: {challenge.get('event')}")

        # Send connect response
        await ws.send_json({
            "type": "connect",
            "protocol": "gateway-2026.1",
            "client": {
                "name": "voice-vibecoder",
                "version": "1.0.0"
            },
            "role": "operator",
            "scopes": ["operator.read", "operator.write"],
            "auth": {
                # Add auth token if configured
                "token": os.getenv("OPENCLAW_AUTH_TOKEN")
            } if os.getenv("OPENCLAW_AUTH_TOKEN") else {}
        })

        # Wait for acknowledgment
        msg = await ws.receive()
        if msg.type != aiohttp.WSMsgType.TEXT:
            raise RuntimeError("Expected acknowledgment from OpenClaw Gateway")

        ack = json.loads(msg.data)
        if ack.get("event") != "connect.ok":
            raise RuntimeError(f"Connection failed: {ack}")

        logger.info("Connected to OpenClaw Gateway")

    async def _send_agent_task(
        self,
        ws: aiohttp.ClientWebSocketResponse,
        request_id: str,
        message: str,
        cwd: str,
        session_id: str | None,
        tokens: dict[str, str | None],
    ) -> None:
        """
        Send agent execution request to OpenClaw.

        Args:
            ws: WebSocket connection
            request_id: Unique request ID
            message: User's task
            cwd: Working directory
            session_id: Session key
            tokens: Downstream API tokens
        """
        # Build environment with tokens
        env = {k: v for k, v in tokens.items() if v is not None}
        env["CWD"] = cwd

        await ws.send_json({
            "type": "req",
            "id": request_id,
            "method": "agent.execute",
            "params": {
                "sessionKey": session_id or "voice-vibecoder:main",
                "message": message,
                "env": env,  # Inject tokens into skill environment
            }
        })

        logger.info(f"Sent task to OpenClaw: {message[:100]}")

    async def _stream_responses(
        self,
        ws: aiohttp.ClientWebSocketResponse,
        request_id: str,
        on_output: Callable[[AgentOutput], None] | None,
    ) -> AgentResult:
        """
        Stream responses from OpenClaw Gateway.

        Args:
            ws: WebSocket connection
            request_id: Request ID to match responses
            on_output: Callback for streaming output

        Returns:
            Final agent result
        """
        result_text = ""
        result_session_id: str | None = None

        async for msg in ws:
            if msg.type != aiohttp.WSMsgType.TEXT:
                continue

            try:
                data = json.loads(msg.data)
            except json.JSONDecodeError:
                logger.warning(f"Invalid JSON from OpenClaw: {msg.data}")
                continue

            msg_type = data.get("type")

            # Response to our request
            if msg_type == "res" and data.get("id") == request_id:
                if data.get("ok"):
                    payload = data.get("payload", {})
                    result_text = payload.get("result", "")
                    result_session_id = payload.get("sessionId")
                    break  # Task complete
                else:
                    error = data.get("error", "Unknown error")
                    raise RuntimeError(f"OpenClaw error: {error}")

            # Streaming events
            elif msg_type == "event":
                output = self._map_event(data)
                if output and on_output:
                    on_output(output)

        return AgentResult(text=result_text, session_id=result_session_id)

    @staticmethod
    def _map_event(event: dict) -> AgentOutput | None:
        """
        Map OpenClaw event to AgentOutput.

        Args:
            event: Event from OpenClaw Gateway

        Returns:
            AgentOutput or None if event should be ignored
        """
        event_name = event.get("event", "")
        payload = event.get("payload", {})

        # Tool execution events
        if event_name == "tool.execution.started":
            tool = payload.get("tool", "unknown")
            return AgentOutput(category="tool_call", content=f"[{tool}]")

        elif event_name == "tool.execution.update":
            category = payload.get("category", "text")
            content = payload.get("output", "")

            # Map OpenClaw categories to AgentOutput categories
            category_map = {
                "file_edit": "file_edit",
                "bash": "bash",
                "diff_add": "diff_add",
                "diff_del": "diff_del",
                "tool_result": "tool_result",
                "text": "text",
            }

            mapped_category = category_map.get(category, "text")
            return AgentOutput(category=mapped_category, content=content)

        elif event_name == "tool.execution.completed":
            tool = payload.get("tool", "unknown")
            result = payload.get("result", "")
            if result:
                return AgentOutput(category="tool_result", content=result[:200])

        # Assistant text response
        elif event_name == "assistant.message":
            content = payload.get("content", "")
            if content:
                return AgentOutput(category="text", content=content)

        return None

    def _get_downstream_tokens(self) -> dict[str, str | None]:
        """
        Get downstream API tokens via OBO exchange.

        Returns:
            Dictionary of token names to tokens
        """
        try:
            auth = get_authenticator()

            # Skip if not authenticated (will use service-level auth)
            if not auth.user_token:
                logger.info("No user authentication, using service-level auth")
                return {}

            # Get all downstream tokens
            tokens = auth.get_all_downstream_tokens()
            logger.info(f"Retrieved {sum(1 for v in tokens.values() if v)} downstream tokens")
            return tokens

        except Exception as e:
            logger.warning(f"Failed to get downstream tokens: {e}")
            return {}
