"""Tool dispatch, configuration, and cancellation.

Module-level state holds the registry and config. The dispatcher routes
tool calls to handler functions in handlers.py and agent_task.py.
"""

import logging
from pathlib import Path
from typing import Any

from voice_vibecoder.config import PermissionMode
from voice_vibecoder.instances import AgentInstance, InstanceRegistry

logger = logging.getLogger(__name__)

_registry: InstanceRegistry | None = None
_repo_root: Path | None = None
_agent_timeout: int = 300
_permission_mode: PermissionMode = "bypass"
_enabled_agents: list[str] = ["claude"]

HELPER_INSTANCE_NAME = "helper"


def configure(
    registry: InstanceRegistry,
    repo_root: Path,
    agent_timeout: int = 300,
    permission_mode: PermissionMode = "bypass",
    enabled_agents: list[str] | None = None,
) -> None:
    global _registry, _repo_root, _agent_timeout, _permission_mode, _enabled_agents
    _registry = registry
    _repo_root = repo_root
    _agent_timeout = agent_timeout
    _permission_mode = permission_mode
    _enabled_agents = enabled_agents or ["claude"]


def _default_agent_type() -> str:
    """Return the first enabled agent type."""
    return _enabled_agents[0] if _enabled_agents else "claude"


def _fuzzy_match_branch(query: str, branches: list[str]) -> str | None:
    """Find a branch by exact match, then substring, shortest wins on ties."""
    exact = [b for b in branches if b == query]
    if exact:
        return exact[0]
    partial = [b for b in branches if query in b]
    if len(partial) == 1:
        return partial[0]
    if partial:
        return min(partial, key=len)
    return None


def _resolve_instance(branch: str | None) -> AgentInstance | None:
    if not _registry:
        return None
    if branch:
        inst = _registry.get_by_branch(branch)
        if inst:
            return inst
        # Fuzzy match against registered branches
        all_branches = [i.branch for i in _registry.get_all()]
        matched = _fuzzy_match_branch(branch, all_branches)
        if matched:
            return _registry.get_by_branch(matched)
        return None
    return _registry.get_default()


def cancel_instance_task(instance: AgentInstance) -> bool:
    bg_loop = instance._bg_loop
    bg_task = instance._bg_task
    if not bg_loop or not bg_task or bg_task.done():
        return False
    bg_loop.call_soon_threadsafe(bg_task.cancel)
    return True


def cancel_all_tasks() -> int:
    if not _registry:
        return 0
    count = 0
    for inst in _registry.get_all():
        if cancel_instance_task(inst):
            count += 1
    return count


def cancel_active_task() -> bool:
    if not _registry:
        return False
    inst = _registry.get_default()
    return cancel_instance_task(inst) if inst else False


def handle_tool_call(name: str, arguments: dict[str, Any]) -> str:
    from voice_vibecoder.tools.agent_task import _handle_send_to_agent
    from voice_vibecoder.tools.handlers import (
        _handle_answer_question,
        _handle_cancel_agent,
        _handle_create_branch_instance,
        _handle_delete_worktree,
        _handle_get_agent_status,
        _handle_list_branches,
        _handle_remove_branch_instance,
        _handle_reset_agent,
        _handle_show_diff,
        _handle_show_output,
        _handle_switch_agent,
        _handle_toggle_fullscreen,
    )

    if name == "send_to_agent":
        return _handle_send_to_agent(
            arguments.get("message", ""),
            arguments.get("branch"),
            arguments.get("agent"),
        )
    elif name == "switch_agent":
        return _handle_switch_agent(
            arguments.get("agent", ""),
            arguments.get("branch"),
        )
    elif name == "create_branch_instance":
        return _handle_create_branch_instance(arguments.get("branch", ""))
    elif name == "get_agent_status":
        return _handle_get_agent_status(arguments.get("branch"))
    elif name == "cancel_agent":
        return _handle_cancel_agent(arguments.get("branch"))
    elif name == "reset_agent":
        return _handle_reset_agent(arguments.get("branch"))
    elif name == "list_branches":
        return _handle_list_branches()
    elif name == "answer_agent_question":
        return _handle_answer_question(
            arguments.get("answer", ""),
            arguments.get("branch"),
        )
    elif name == "show_diff":
        return _handle_show_diff(arguments.get("branch"), arguments.get("file"))
    elif name == "show_output":
        return _handle_show_output(arguments.get("branch"))
    elif name == "toggle_fullscreen":
        return _handle_toggle_fullscreen(arguments.get("branch"))
    elif name == "remove_branch_instance":
        return _handle_remove_branch_instance(arguments.get("branch", ""))
    elif name == "delete_worktree":
        return _handle_delete_worktree(
            arguments.get("branch", ""),
            arguments.get("delete_branch", False),
        )
    return f"Unknown tool: {name}"
