"""Agent orchestration — sending tasks, background threading, voice relay.

Handles the lifecycle of sending a task to a coding agent, running it in a
background thread, and relaying interactive questions back through voice.
"""

import asyncio
import json
import logging
import threading
from pathlib import Path
from typing import Any

from voice_vibecoder.code_providers import AgentOutput, AgentRunner, truncate_output
from voice_vibecoder.code_providers.registry import get_agent
from voice_vibecoder.instances import AgentInstance, InstanceStatus

logger = logging.getLogger(__name__)

ANSWER_TIMEOUT = 300  # 5 min to answer a question

_CLAUDE_JSON = Path.home() / ".claude.json"

# Cached MCP servers — loaded once per session, files rarely change
_mcp_cache: dict[str, dict] | None = None


def _load_mcp_servers() -> dict[str, dict]:
    """Load MCP servers (cached after first call)."""
    global _mcp_cache
    if _mcp_cache is not None:
        return _mcp_cache

    from voice_vibecoder.tools.dispatch import _repo_root

    servers: dict[str, dict] = {}

    if _repo_root:
        mcp_json = Path(_repo_root) / ".mcp.json"
        if mcp_json.exists():
            try:
                data = json.loads(mcp_json.read_text())
                servers.update(data.get("mcpServers", {}))
            except Exception as e:
                logger.warning("Failed to read .mcp.json: %s", e)

    if _repo_root and _CLAUDE_JSON.exists():
        try:
            data = json.loads(_CLAUDE_JSON.read_text())
            project_key = str(Path(_repo_root))
            project_data = data.get("projects", {}).get(project_key, {})
            local_servers = project_data.get("mcpServers", {})
            servers.update(local_servers)
        except Exception as e:
            logger.warning("Failed to read ~/.claude.json: %s", e)

    _mcp_cache = servers
    return servers


def _create_runner(agent_type: str, permission_mode: str, mcp_servers: dict | None) -> AgentRunner:
    """Create the appropriate AgentRunner for the given agent type."""
    return get_agent(agent_type).runner_factory(
        permission_mode=permission_mode,
        mcp_servers=mcp_servers,
    )


def _handle_send_to_agent(message: str, branch: str | None = None, agent: str | None = None) -> str:
    from voice_vibecoder.tools.dispatch import (
        _default_agent_type, _fuzzy_match_branch, _registry, _repo_root, _resolve_instance,
    )

    if not message.strip():
        return "Error: empty message"

    # Resolve agent type early so auto-created instances get the right type
    target_agent = agent or _default_agent_type()

    instance = _resolve_instance(branch)
    if not instance and branch and _registry and _repo_root:
        # Auto-create: fuzzy match against worktree branches, then resolve
        from voice_vibecoder.worktrees import list_worktrees, resolve_worktree_path

        worktrees = list_worktrees(_repo_root)
        wt_branches = [wt.branch for wt in worktrees if wt.branch and not wt.is_main]
        resolved_branch = _fuzzy_match_branch(branch, wt_branches) or branch
        try:
            worktree_path = resolve_worktree_path(resolved_branch, _repo_root)
            instance = _registry.create_instance(resolved_branch, str(worktree_path), agent_type=target_agent)
        except Exception:
            return f"Could not create instance for '{branch}'."

    if not instance:
        if branch:
            return f"No instance for branch '{branch}'."
        return "No agent instance available."

    # Update agent type if switching on an existing instance
    resolved_agent = agent or instance.agent_type or target_agent
    if resolved_agent != instance.agent_type:
        instance.agent_type = resolved_agent
        instance.session_id = ""  # Clear session when switching agents
        if _registry:
            _registry._save_state()

    if instance.status == InstanceStatus.RUNNING:
        return (
            f"Agent on '{instance.branch}' is already working on a task. "
            "Use get_agent_status to check progress, or cancel_agent to stop it."
        )

    # Set RUNNING before spawning thread to prevent race with duplicate calls
    from voice_vibecoder.tools.dispatch import _registry

    instance.output_buffer = ""

    # Show the user's prompt and a separator in the panel
    if _registry and _registry.on_output:
        _registry.on_output(instance.instance_id, "separator:")
        preview = message[:200] + ("..." if len(message) > 200 else "")
        _registry.on_output(instance.instance_id, f"user_prompt:{preview}")

    if _registry:
        _registry.update_status(instance.instance_id, InstanceStatus.RUNNING)

    thread = threading.Thread(
        target=_run_agent_background,
        args=(instance, message),
        daemon=True,
    )
    thread.start()

    agent_label = get_agent(instance.agent_type).label
    return f"Sent to {agent_label}."


def _run_agent_background(instance: AgentInstance, message: str) -> None:

    loop = asyncio.new_event_loop()
    asyncio.set_event_loop(loop)
    instance._bg_loop = loop

    try:
        loop.run_until_complete(_run_agent_async(instance, message))
    finally:
        # Cancel any pending answer Future so _ask_user_via_voice doesn't hang
        pending = instance.pending_answer
        if pending and not pending.done():
            loop.call_soon_threadsafe(pending.cancel)
        instance.pending_answer = None
        instance.pending_question = None
        loop.close()
        instance._bg_loop = None
        instance._bg_task = None


async def _run_agent_async(instance: AgentInstance, message: str) -> None:
    from voice_vibecoder.tools.dispatch import _permission_mode, _registry, _repo_root

    iid = instance.instance_id
    instance._bg_task = asyncio.current_task()

    mcp_servers = _load_mcp_servers()

    runner = _create_runner(instance.agent_type, _permission_mode, mcp_servers)

    def on_output(output: AgentOutput) -> None:
        if _registry and _registry.on_output:
            _registry.on_output(iid, f"{output.category}:{output.content}")
        instance.last_activity = output.content[:200]
        instance.output_buffer += output.content + "\n"
        if len(instance.output_buffer) > 50_000:
            instance.output_buffer = instance.output_buffer[-30_000:]

    async def can_use_tool(tool_name: str, input_data: dict, context: Any) -> Any:
        if tool_name == "AskUserQuestion":
            return await _ask_user_via_voice(instance, input_data)
        if tool_name == "ExitPlanMode":
            return await _approve_plan_via_voice(instance, input_data)
        return True  # auto-approve everything else

    try:
        result = await runner.run(
            message=message,
            cwd=str(instance.worktree_path),
            session_id=instance.session_id or None,
            on_output=on_output,
            can_use_tool=can_use_tool,
        )
    except asyncio.CancelledError:
        instance._bg_task = None
        if _registry:
            _registry.update_status(iid, InstanceStatus.IDLE)
        _deliver_result(iid, "Agent task was cancelled.")
        return
    except Exception as e:
        logger.error("Agent error [%s]: %s", iid, e, exc_info=True)
        instance._bg_task = None
        if _registry:
            _registry.update_status(iid, InstanceStatus.ERROR)
        _deliver_result(iid, str(e))
        return

    instance._bg_task = None
    if result.session_id:
        instance.session_id = result.session_id
        instance.first_call = False
        if _registry:
            _registry._save_state_now()  # session_id must persist immediately
    instance.output_buffer = result.text

    if _registry:
        _registry.update_status(iid, InstanceStatus.IDLE)

    if not result.text:
        _deliver_result(iid, "Agent completed the task with no output.")
    else:
        _deliver_result(iid, truncate_output(result.text))


def _deliver_result(instance_id: str, result: str) -> None:
    from voice_vibecoder.tools.dispatch import _registry

    if _registry and _registry.on_task_complete:
        _registry.on_task_complete(instance_id, result)


def _format_question_for_voice(questions: list[dict]) -> str:
    if not questions:
        return "The agent has a question but no details were provided."
    parts = []
    for q in questions:
        text = q.get("question", "")
        options = q.get("options", [])
        if text:
            parts.append(text)
        if options:
            opt_strs = [f"- {o.get('label', '')}: {o.get('description', '')}" for o in options]
            parts.append("\n".join(opt_strs))
    return "\n".join(parts)


async def _wait_for_user_answer(
    instance: AgentInstance,
    tool_name: str,
    formatted_text: str,
    input_data: dict[str, Any],
) -> str | None:
    """Common logic: set up a Future, notify UI, and wait for the user's answer."""
    from voice_vibecoder.tools.dispatch import _registry

    iid = instance.instance_id

    loop = asyncio.get_running_loop()
    future: asyncio.Future[str] = loop.create_future()
    instance.pending_answer = future
    instance.pending_question = {
        "tool": tool_name,
        "input": input_data,
        "formatted": formatted_text,
    }

    if _registry:
        if _registry.on_output:
            _registry.on_output(iid, f"question:{formatted_text}")
        _registry.update_status(iid, InstanceStatus.WAITING_INPUT)
        if _registry.on_question:
            _registry.on_question(iid, instance.pending_question)

    try:
        answer = await asyncio.wait_for(future, timeout=ANSWER_TIMEOUT)
    except (asyncio.TimeoutError, asyncio.CancelledError):
        instance.pending_answer = None
        instance.pending_question = None
        if _registry:
            _registry.update_status(iid, InstanceStatus.RUNNING)
        return None

    instance.pending_answer = None
    instance.pending_question = None
    if _registry:
        _registry.update_status(iid, InstanceStatus.RUNNING)

    return answer


async def _ask_user_via_voice(
    instance: AgentInstance, input_data: dict[str, Any],
) -> str | None:
    """Route AskUserQuestion to voice and wait for the user's answer."""
    questions = input_data.get("questions", [])
    voice_text = _format_question_for_voice(questions)
    return await _wait_for_user_answer(instance, "AskUserQuestion", voice_text, input_data)


async def _approve_plan_via_voice(
    instance: AgentInstance, input_data: dict[str, Any],
) -> str | None:
    """Route ExitPlanMode to voice for plan approval."""
    answer = await _wait_for_user_answer(
        instance, "ExitPlanMode",
        "The agent has a plan ready. Should it proceed with the implementation?",
        input_data,
    )
    if answer is None:
        return None

    words = set(answer.lower().strip().split())
    reject_words = {"no", "reject", "nei", "nej", "don't", "ikke", "inte", "nope", "nah"}
    if words & reject_words:
        return None

    return answer
