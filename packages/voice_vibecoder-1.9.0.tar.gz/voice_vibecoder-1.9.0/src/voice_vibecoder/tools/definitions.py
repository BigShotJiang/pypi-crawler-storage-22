"""OpenAI Realtime API tool definitions.

Pure data — no logic. Each entry maps to a function_call tool that ChatGPT
can invoke during a voice session.
"""

from typing import Any

TOOL_DEFINITIONS: list[dict[str, Any]] = [
    {
        "type": "function",
        "name": "send_to_agent",
        "description": (
            "Send a task to the coding agent. Returns immediately — the agent works in the background. "
            "IMPORTANT: For ANY task that changes code (features, fixes, refactoring, tests, "
            "config), you MUST provide the branch parameter. The 'helper' instance (no branch) "
            "is ONLY for non-code tasks: Jira, CI, questions, research. "
            "If no instance exists for the branch, one is auto-created. "
            "Branch names are fuzzy-matched — e.g. 'branding' matches 'feat/branding-refresh'. "
            "Ask the user which branch if unclear."
        ),
        "parameters": {
            "type": "object",
            "properties": {
                "message": {
                    "type": "string",
                    "description": "The coding task or question for the agent",
                },
                "branch": {
                    "type": "string",
                    "description": "Target branch name. Omit for the default helper instance.",
                },
                "agent": {
                    "type": "string",
                    "description": (
                        "Agent to use: 'claude' or 'cursor'. "
                        "Sets the agent for this branch. Defaults to the primary enabled agent."
                    ),
                },
            },
            "required": ["message"],
        },
    },
    {
        "type": "function",
        "name": "create_branch_instance",
        "description": (
            "Create a new agent instance panel without sending a task. "
            "Usually not needed — send_to_agent auto-creates instances. "
            "Use this only if you want a panel visible before any task is sent."
        ),
        "parameters": {
            "type": "object",
            "properties": {
                "branch": {
                    "type": "string",
                    "description": "The git branch name (e.g. 'feat/login', 'fix/bug-123')",
                },
                "agent": {
                    "type": "string",
                    "description": (
                        "Agent to use: 'claude' or 'cursor'. "
                        "Defaults to the primary enabled agent."
                    ),
                },
            },
            "required": ["branch"],
        },
    },
    {
        "type": "function",
        "name": "get_agent_status",
        "description": (
            "Check if the coding agent is currently running a task and get its latest output. "
            "Optionally specify a branch to check a specific instance."
        ),
        "parameters": {
            "type": "object",
            "properties": {
                "branch": {
                    "type": "string",
                    "description": "Branch name to check. Optional — omit for all instances.",
                },
            },
        },
    },
    {
        "type": "function",
        "name": "cancel_agent",
        "description": (
            "Cancel the currently running agent task. Use when the user says cancel, stop, or abort. "
            "Optionally specify a branch to cancel a specific instance."
        ),
        "parameters": {
            "type": "object",
            "properties": {
                "branch": {
                    "type": "string",
                    "description": "Branch name to cancel. Optional — omit to cancel all.",
                },
            },
        },
    },
    {
        "type": "function",
        "name": "reset_agent",
        "description": (
            "Reset an agent session. Starts fresh with no memory of previous commands. "
            "Use when user says 'start fresh', 'new session', or 'reset'. "
            "Optionally specify a branch to reset a specific instance."
        ),
        "parameters": {
            "type": "object",
            "properties": {
                "branch": {
                    "type": "string",
                    "description": "Branch name to reset. Optional — omit to reset all.",
                },
            },
        },
    },
    {
        "type": "function",
        "name": "list_branches",
        "description": "List all active agent instances and available git worktrees/branches.",
        "parameters": {"type": "object", "properties": {}},
    },
    {
        "type": "function",
        "name": "answer_agent_question",
        "description": (
            "Answer a question that the coding agent asked via voice. Use this when the agent "
            "is waiting for user input (status: waiting_input). The user answers "
            "verbally and you forward their answer here."
        ),
        "parameters": {
            "type": "object",
            "properties": {
                "answer": {
                    "type": "string",
                    "description": "The user's answer to the agent's question, forwarded verbatim.",
                },
                "branch": {
                    "type": "string",
                    "description": "Target branch name. Optional — omit if there is only one instance.",
                },
            },
            "required": ["answer"],
        },
    },
    {
        "type": "function",
        "name": "show_diff",
        "description": (
            "Show git diff for an instance. Replaces the agent output panel "
            "with a GitHub-style diff view (file list + colorized diff). "
            "Use the file parameter to show only a specific file's diff. "
            "File names are fuzzy-matched — e.g. 'config' matches 'src/config.ts'."
        ),
        "parameters": {
            "type": "object",
            "properties": {
                "branch": {
                    "type": "string",
                    "description": "Branch name. Omit for the helper instance.",
                },
                "file": {
                    "type": "string",
                    "description": "File name or partial path to filter the diff to a single file.",
                },
            },
        },
    },
    {
        "type": "function",
        "name": "show_output",
        "description": (
            "Switch back to normal view. Exits fullscreen if active, "
            "and switches from diff view back to agent output. "
            "Use when the user says 'go back', 'normal view', or 'show output'."
        ),
        "parameters": {
            "type": "object",
            "properties": {
                "branch": {
                    "type": "string",
                    "description": "Branch name. Omit for the helper instance.",
                },
            },
        },
    },
    {
        "type": "function",
        "name": "toggle_fullscreen",
        "description": (
            "Toggle fullscreen for one panel. Hides all other panels. "
            "Call again to restore the grid view."
        ),
        "parameters": {
            "type": "object",
            "properties": {
                "branch": {
                    "type": "string",
                    "description": "Branch name. Omit for the helper instance.",
                },
            },
        },
    },
    {
        "type": "function",
        "name": "remove_branch_instance",
        "description": (
            "Remove a branch instance and its panel. "
            "Cannot remove the helper instance. Cancels any running agent task."
        ),
        "parameters": {
            "type": "object",
            "properties": {
                "branch": {
                    "type": "string",
                    "description": "Branch name to remove.",
                },
            },
            "required": ["branch"],
        },
    },
    {
        "type": "function",
        "name": "delete_worktree",
        "description": (
            "Delete a git worktree and optionally its branch. "
            "Also removes the agent instance if one exists. "
            "Cannot delete the main worktree."
        ),
        "parameters": {
            "type": "object",
            "properties": {
                "branch": {
                    "type": "string",
                    "description": "The branch name of the worktree to delete.",
                },
                "delete_branch": {
                    "type": "boolean",
                    "description": "Also delete the git branch. Defaults to false.",
                },
            },
            "required": ["branch"],
        },
    },
]
