"""PanelMixin — instance panel management for VoiceCodingScreen.

Handles creating, updating, toggling fullscreen, and removing agent
instance panels in the grid layout.
"""

import math

from textual.containers import Grid, Vertical
from textual.widgets import Static, RichLog

from voice_vibecoder.code_providers.registry import get_badge
from voice_vibecoder.instances import AgentInstance, InstanceStatus
from voice_vibecoder.ui.styles import _STATUS_ICONS


def _format_header(inst: AgentInstance, status: InstanceStatus | None = None) -> str:
    """Format panel header: icon + branch + agent badge."""
    s = status or inst.status
    icon = _STATUS_ICONS.get(s, "[dim]?[/dim]")
    badge = get_badge(inst.agent_type)
    return f"{icon} {inst.branch}  {badge}"


def _calculate_grid_size(item_count: int, max_columns: int = 4) -> tuple[int, int]:
    """Calculate optimal (columns, rows) for a grid layout."""
    if item_count <= 0:
        return (1, 1)
    if item_count == 1:
        return (1, 1)
    if item_count == 2:
        return (2, 1)
    cols = min(math.ceil(math.sqrt(item_count)), max_columns)
    rows = math.ceil(item_count / cols)
    return (cols, rows)


def _apply_grid_size(grid_widget, item_count: int, max_columns: int = 4) -> None:
    """Apply optimal grid dimensions to a Textual Grid widget."""
    cols, rows = _calculate_grid_size(item_count, max_columns)
    grid_widget.styles.grid_size_columns = cols
    grid_widget.styles.grid_size_rows = rows


class PanelMixin:
    """Mixin providing panel management methods for VoiceCodingScreen."""

    def _create_panels_batch(self, instances: list) -> None:
        """Create all panels in one mount call for faster startup."""
        panels = []
        for inst in instances:
            header_text = _format_header(inst)
            header = Static(
                header_text,
                classes="agent-header agent-header-idle",
                id=f"header-{inst.instance_id}",
            )
            output = RichLog(
                highlight=True,
                markup=True,
                classes="agent-output",
                id=f"output-{inst.instance_id}",
            )
            panel = Vertical(
                header,
                output,
                classes="agent-panel",
                id=f"panel-{inst.instance_id}",
            )
            inst.header_widget = header
            inst.output_widget = output
            panels.append(panel)

        try:
            grid = self.query_one("#agent-grid", Grid)
            grid.styles.display = "block"
            grid.mount_all(panels)
            _apply_grid_size(grid, len(panels), max_columns=3)
        except Exception:
            pass

    def _create_instance_panel(self, instance_id: str, branch: str) -> None:
        """Create a new panel in the grid for an agent instance."""
        inst = self._session.registry.get_by_id(instance_id) if self._session else None
        header_text = _format_header(inst) if inst else f"{_STATUS_ICONS[InstanceStatus.IDLE]} {branch}"
        header = Static(
            header_text,
            classes="agent-header agent-header-idle",
            id=f"header-{instance_id}",
        )
        output = RichLog(
            highlight=True,
            markup=True,
            classes="agent-output",
            id=f"output-{instance_id}",
        )
        panel = Vertical(
            header,
            output,
            classes="agent-panel",
            id=f"panel-{instance_id}",
        )

        if inst:
            inst.header_widget = header
            inst.output_widget = output

        try:
            grid = self.query_one("#agent-grid", Grid)
            grid.styles.display = "block"
            grid.mount(panel)
            panel_count = len(grid.children)
            _apply_grid_size(grid, panel_count, max_columns=3)
        except Exception:
            pass

    def _update_instance_header(self, instance_id: str, status: InstanceStatus) -> None:
        if not self._session:
            return
        inst = self._session.registry.get_by_id(instance_id)
        if not inst or not inst.header_widget:
            return

        inst.header_widget.update(_format_header(inst, status))

        header = inst.header_widget
        header.remove_class("agent-header-idle", "agent-header-running", "agent-header-waiting_input", "agent-header-error")
        header.add_class(f"agent-header-{status.value}")

    def _show_diff_view(self, instance_id: str, data: dict) -> None:
        """Replace agent output with a diff view in the panel."""
        from voice_vibecoder.ui.diff_view import create_diff_view, format_file_list

        if not self._session:
            return
        inst = self._session.registry.get_by_id(instance_id)
        if not inst:
            return

        if inst.output_widget:
            inst.output_widget.styles.display = "none"

        files = data.get("files", [])
        diff_lines = data.get("diff_lines", [])

        # Reuse existing diff view if present — avoids mount timing issues
        try:
            file_list_widget = self.query_one(f"#diff-files-{instance_id}", Static)
            diff_log = self.query_one(f"#diff-log-{instance_id}", RichLog)
            file_list_widget.update(format_file_list(files))
            diff_log.clear()
            for line in diff_lines:
                diff_log.write(line)
            return
        except Exception:
            pass

        # First time — create and mount
        diff_view, diff_log = create_diff_view(instance_id, files, diff_lines)

        try:
            panel = self.query_one(f"#panel-{instance_id}")
            panel.mount(diff_view)
            for line in diff_lines:
                diff_log.write(line)
        except Exception:
            pass

    def _hide_diff_view(self, instance_id: str) -> None:
        """Remove diff view and restore agent output."""
        if not self._session:
            return
        inst = self._session.registry.get_by_id(instance_id)
        if not inst:
            return

        try:
            diff_view = self.query_one(f"#diff-view-{instance_id}")
            diff_view.remove()
        except Exception:
            pass

        if inst.output_widget:
            inst.output_widget.styles.display = "block"

    def _toggle_fullscreen(self, instance_id: str) -> None:
        """Toggle fullscreen for a panel."""
        try:
            grid = self.query_one("#agent-grid", Grid)
            transcript = self.query_one("#voice-transcript", RichLog)
        except Exception:
            return

        if self._fullscreen_id == instance_id:
            self._fullscreen_id = None
            self._state._fullscreen_branch = None
            if self._session:
                self._session.registry.fullscreen_id = None
            transcript.styles.display = "block"
            for panel in grid.query(".agent-panel"):
                panel.styles.display = "block"
            panel_count = len(grid.children)
            _apply_grid_size(grid, panel_count, max_columns=3)
        else:
            self._fullscreen_id = instance_id
            if self._session:
                self._session.registry.fullscreen_id = instance_id
                inst = self._session.registry.get_by_id(instance_id)
                if inst:
                    self._state._fullscreen_branch = inst.branch
            transcript.styles.display = "none"
            for panel in grid.query(".agent-panel"):
                pid = getattr(panel, "id", "") or ""
                if pid == f"panel-{instance_id}":
                    panel.styles.display = "block"
                else:
                    panel.styles.display = "none"
            grid.styles.grid_size_columns = 1
            grid.styles.grid_size_rows = 1

    def _remove_instance_panel(self, instance_id: str) -> None:
        """Remove a panel from the grid."""
        if self._session:
            inst = self._session.registry.get_by_id(instance_id)
            if inst:
                self._state.remove_instance(inst.branch)

        if self._fullscreen_id == instance_id:
            self._fullscreen_id = None
            try:
                transcript = self.query_one("#voice-transcript", RichLog)
                transcript.styles.display = "block"
            except Exception:
                pass

        try:
            panel = self.query_one(f"#panel-{instance_id}")
            panel.remove()
            grid = self.query_one("#agent-grid", Grid)
            panel_count = len(grid.children)
            if panel_count > 0:
                _apply_grid_size(grid, panel_count, max_columns=3)
        except Exception:
            pass
