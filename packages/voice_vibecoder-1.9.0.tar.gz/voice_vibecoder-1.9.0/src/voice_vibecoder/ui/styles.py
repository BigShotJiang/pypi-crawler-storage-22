"""CSS, constants, and style helpers for the voice coding screen."""

import re

from voice_vibecoder.instances import InstanceStatus
from voice_vibecoder.tools.dispatch import HELPER_INSTANCE_NAME

VOICE_SCREEN_CSS = """
VoiceCodingScreen {
    background: $surface;
}

#voice-container {
    height: 100%;
}

#agent-grid {
    width: 100%;
    height: 1fr;
    grid-size: 1;
    grid-gutter: 0 0;
    display: block;
}

.agent-panel {
    border: solid $panel;
    width: 1fr;
    height: 1fr;
}

.agent-header {
    height: 1;
    padding: 0 1;
    text-align: center;
}

.agent-header-idle {
    background: $panel;
}

.agent-header-running {
    background: $warning-darken-2;
    color: $text;
}

.agent-header-waiting_input {
    background: $secondary-darken-2;
    color: $text;
}

.agent-header-error {
    background: $error-darken-2;
    color: $text;
}

.agent-output {
    height: 1fr;
    padding: 0 1;
}

.diff-container {
    layout: horizontal;
    height: 1fr;
}

.diff-file-list {
    width: 24;
    border-right: solid $panel;
    padding: 0;
    overflow-y: auto;
}

.diff-content {
    width: 1fr;
    padding: 0 1;
}

#voice-transcript {
    height: auto;
    max-height: 8;
    border: solid $panel;
    background: $surface;
    padding: 0 1;
}

#voice-status-bar {
    height: 3;
    padding: 0 2;
    content-align: center middle;
    text-align: center;
    background: $panel;
}

"""

_RICH_TAG_RE = re.compile(r"\[/?[a-z][a-z0-9 _#=-]*\]", re.IGNORECASE)

_CATEGORY_STYLES = {
    "tool_call": "bold yellow",
    "tool_result": "dim",
    "file_edit": "green",
    "bash": "cyan",
    "text": "",
    "user_prompt": "bold blue",
    "separator": "dim",
    "question": "bold magenta",
    "result_done": "bold green",
    "result_error": "bold red",
}

_STATUS_ICONS = {
    InstanceStatus.IDLE: "[dim]○[/dim]",
    InstanceStatus.RUNNING: "[yellow]⏳[/yellow]",
    InstanceStatus.WAITING_INPUT: "[magenta]❓[/magenta]",
    InstanceStatus.ERROR: "[red]✗[/red]",
}


def _format_output_line(category: str | None, text: str, agent_type: str = "claude") -> str:
    """Format an output line for the agent panel with clear visual hierarchy."""
    from voice_vibecoder.code_providers.registry import get_agent
    agent_color = get_agent(agent_type).color

    if category == "user_prompt":
        return f"[bold blue]▶ You:[/bold blue] {text}"

    if category == "separator":
        return f"[dim]{'─' * 40}[/dim]"

    if category == "question":
        return f"[bold magenta]❓ Question:[/bold magenta] {text}"

    if category == "result_done":
        return f"[bold green]✓[/bold green] {text}"

    if category == "result_error":
        return f"[bold red]✗[/bold red] {text}"

    if category == "text":
        # Agent narration — check for [DONE] / [ERROR] prefixes
        stripped = text.strip()
        if stripped.startswith("[DONE]"):
            return f"[bold green]✓[/bold green] {stripped[6:].strip()}"
        if stripped.startswith("[ERROR]"):
            return f"[bold red]✗[/bold red] {stripped[7:].strip()}"
        return f"[{agent_color}]{text}[/{agent_color}]"

    if category == "tool_call":
        return f"  [bold yellow]⚡ {text}[/bold yellow]"

    if category == "file_edit":
        return f"  [green]✎ {text}[/green]"

    if category == "bash":
        return f"  [cyan]$ {text}[/cyan]"

    if category == "tool_result":
        return f"  [dim]  ↳ {text}[/dim]"

    # Unknown category
    if category and category in _CATEGORY_STYLES:
        style = _CATEGORY_STYLES[category]
        if style:
            return f"[{style}]{text}[/{style}]"
    return f"[dim]{text}[/dim]"


def strip_markup(text: str) -> str:
    return _RICH_TAG_RE.sub("", text)
