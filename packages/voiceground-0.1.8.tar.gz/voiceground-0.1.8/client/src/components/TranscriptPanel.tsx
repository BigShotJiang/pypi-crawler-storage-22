import { useMemo, useState } from 'react';
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from '@/components/ui/accordion';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Checkbox } from '@/components/ui/checkbox';
import { ScrollArea } from '@/components/ui/scroll-area';
import type { VoicegroundEvent, VoicegroundContextEntry } from '@/types';

type TranscriptEntry =
  | { role: 'user'; text: string; timestamp: number }
  | { role: 'bot'; text: string; timestamp: number }
  | {
      role: 'tool_call';
      text: string;
      timestamp: number;
      name?: string;
      arguments?: unknown;
      result?: unknown;
    };

interface TranscriptPanelProps {
  events: VoicegroundEvent[];
}

/** Convert backend transcript (from aggregators) to display entries. Uses index as timestamp for ordering. */
function transcriptFromBackend(entries: VoicegroundContextEntry[]): TranscriptEntry[] {
  return entries.map((e, i) => {
    const timestamp = i;
    if (e.role === 'user') {
      return { role: 'user', text: e.content ?? '', timestamp };
    }
    if (e.role === 'bot') {
      return { role: 'bot', text: e.content ?? '', timestamp };
    }
    const name = e.name ?? 'tool';
    const text = typeof e.result === 'object' && e.result !== null && 'message' in e.result
      ? String((e.result as { message?: string }).message)
      : name;
    return {
      role: 'tool_call',
      text,
      timestamp,
      name,
      arguments: e.arguments,
      result: e.result,
    };
  });
}

function extractTranscript(events: VoicegroundEvent[]): TranscriptEntry[] {
  const transcript: TranscriptEntry[] = [];
  
  // First pass: collect all TTS end event timestamps (to detect which LLM events have corresponding TTS)
  const ttsEndTimestamps = new Set<number>();
  const ttsStartToEndMap = new Map<number, number>(); // Map TTS start time to end time
  
  // Build a map of TTS start -> end times
  const ttsStarts = new Map<string, number>(); // category+source -> start timestamp
  for (const event of events) {
    if (event.category === 'tts' && event.type === 'start') {
      const key = `${event.category}-${event.source}`;
      ttsStarts.set(key, event.timestamp);
    } else if (event.category === 'tts' && event.type === 'end') {
      const key = `${event.category}-${event.source}`;
      const startTime = ttsStarts.get(key);
      if (startTime !== undefined) {
        ttsStartToEndMap.set(startTime, event.timestamp);
        ttsStarts.delete(key);
      }
      if (event.data.text) {
        ttsEndTimestamps.add(event.timestamp);
      }
    }
  }
  
  // Second pass: extract transcriptions
  for (const event of events) {
    // STT end events contain user transcriptions
    const sttText = event.category === 'stt' && event.type === 'end' ? (event.data.text as string | undefined) : undefined;
    if (sttText) {
      transcript.push({
        role: 'user',
        text: sttText,
        timestamp: event.timestamp,
      });
    }

    // TTS end events contain bot responses (what was actually spoken by TTS)
    const ttsText = event.category === 'tts' && event.type === 'end' ? (event.data.text as string | undefined) : undefined;
    if (ttsText) {
      transcript.push({
        role: 'bot',
        text: ttsText,
        timestamp: event.timestamp,
      });
    }
    // Fallback: Use LLM end events only if there's no TTS end event nearby (within 5 seconds)
    else if (event.category === 'llm' && event.type === 'end') {
      const llmText = event.data.text as string | undefined;
      if (llmText) {
        const hasTTSNearby = Array.from(ttsEndTimestamps).some(
          ttsTime => ttsTime > event.timestamp && ttsTime - event.timestamp < 5
        );
        if (!hasTTSNearby) {
          transcript.push({
            role: 'bot',
            text: llmText,
            timestamp: event.timestamp,
          });
        }
      }
    }

    // Tool call start: show tool invocation in transcript
    if (event.category === 'tool_call' && event.type === 'start') {
      const operation = (event.data.operation as string) ?? (event.data.description as string) ?? 'tool';
      const description = (event.data.description as string) ?? operation;
      transcript.push({
        role: 'tool_call',
        text: description,
        timestamp: event.timestamp,
        name: operation,
      });
    }
  }

  // Sort by timestamp
  return transcript.sort((a, b) => a.timestamp - b.timestamp);
}

export function TranscriptPanel({ events }: TranscriptPanelProps) {
  const [showToolCalls, setShowToolCalls] = useState(true);

  const transcript = useMemo(() => {
    const fromBackend = window.__VOICEGROUND_CONTEXT__;
    if (fromBackend?.length) {
      return transcriptFromBackend(fromBackend);
    }
    return extractTranscript(events);
  }, [events]);

  const visibleTranscript = useMemo(
    () =>
      showToolCalls
        ? transcript
        : transcript.filter((entry) => entry.role !== 'tool_call'),
    [transcript, showToolCalls]
  );

  if (transcript.length === 0) {
    return (
      <Card className="h-full border-border/50">
        <CardHeader className="pb-3">
          <CardTitle className="text-base font-semibold">Transcript</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-center py-8 text-muted-foreground text-sm">
            No transcript available
          </div>
        </CardContent>
      </Card>
    );
  }
  
  return (
    <Card className="h-full border-border/50 flex flex-col">
      <CardHeader className="pb-3 flex-shrink-0 space-y-2">
        <CardTitle className="text-base font-semibold">
          Transcript
          <span className="text-xs text-muted-foreground font-normal ml-2">
            ({visibleTranscript.length} {visibleTranscript.length === 1 ? 'message' : 'messages'})
          </span>
        </CardTitle>
        <label
          htmlFor="show-tool-calls"
          className="flex items-center gap-2 text-xs text-muted-foreground cursor-pointer select-none"
        >
          <Checkbox
            id="show-tool-calls"
            checked={showToolCalls}
            onCheckedChange={(checked) => setShowToolCalls(checked === true)}
          />
          Show tool calls
        </label>
      </CardHeader>
      <CardContent className="flex-1 min-h-0 px-0">
        <ScrollArea className="h-full px-6">
          <div className="space-y-4 pb-4">
            {visibleTranscript.map((entry, idx) => (
              <div
                key={idx}
                className="flex gap-3 justify-start"
              >
                <div className={`flex-shrink-0 w-16 text-xs font-medium pt-1 ${
                  entry.role === 'user'
                    ? 'text-blue-400'
                    : entry.role === 'bot'
                      ? 'text-green-400'
                      : 'text-amber-500'
                }`}>
                  {entry.role === 'tool_call' ? 'TOOL' : entry.role.toUpperCase()}
                </div>
                <div className={`flex-1 min-w-0 rounded-lg px-3 py-2 text-sm ${
                  entry.role === 'user'
                    ? 'bg-blue-500/10 border border-blue-500/20'
                    : entry.role === 'bot'
                      ? 'bg-green-500/10 border border-green-500/20'
                      : 'bg-amber-500/10 border border-amber-500/20'
                }`}>
                  {entry.role === 'tool_call' ? (
                    <Accordion type="single" collapsible className="w-full">
                      <AccordionItem value={`tool-${idx}`} className="border-none">
                        <AccordionTrigger className="py-2 hover:no-underline hover:bg-transparent">
                          <span className="font-medium break-words text-left">
                            {entry.name ?? entry.text}
                          </span>
                        </AccordionTrigger>
                        <AccordionContent className="pt-0">
                          {entry.arguments != null && (
                            <pre className="mt-1 text-xs text-muted-foreground whitespace-pre-wrap break-all">
                              {typeof entry.arguments === 'string'
                                ? entry.arguments
                                : JSON.stringify(entry.arguments, null, 2)}
                            </pre>
                          )}
                          {entry.result != null && (
                            <pre className="mt-1 text-xs text-muted-foreground whitespace-pre-wrap break-all">
                              {typeof entry.result === 'string'
                                ? entry.result
                                : JSON.stringify(entry.result, null, 2)}
                            </pre>
                          )}
                        </AccordionContent>
                      </AccordionItem>
                    </Accordion>
                  ) : (
                    <p className="leading-relaxed whitespace-pre-wrap break-words">
                      {entry.text}
                    </p>
                  )}
                  <div className="text-xs text-muted-foreground mt-1">
                    {new Date(entry.timestamp * 1000).toLocaleTimeString('en-US', {
                      hour12: false,
                      hour: '2-digit',
                      minute: '2-digit',
                      second: '2-digit',
                    })}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </ScrollArea>
      </CardContent>
    </Card>
  );
}
