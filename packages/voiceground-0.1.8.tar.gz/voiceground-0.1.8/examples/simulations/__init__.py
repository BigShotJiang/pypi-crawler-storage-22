"""Simulation examples for Voiceground."""
