"""VoicegroundObserver - Track conversation events from pipecat pipelines."""

import uuid
from typing import TYPE_CHECKING

from pipecat.frames.frames import CancelFrame, EndFrame, StartFrame
from pipecat.observers.base_observer import BaseObserver, FrameProcessed, FramePushed

from voiceground.evaluations import BaseEvaluator, EvaluationDefinition, EvaluationResult
from voiceground.events import VoicegroundEvent
from voiceground.services.context_collection_service import ObserverContextCollectionService
from voiceground.services.evaluation_service import ObserverEvaluationService
from voiceground.services.event_collection_service import ObserverEventCollectionService

if TYPE_CHECKING:
    from voiceground.reporters.base import BaseReporter


class VoicegroundObserver(BaseObserver):
    """Observer for tracking conversation events in pipecat pipelines.

    Composes context collection, event collection, and evaluation services.
    Emits events, context (transcript) entries, and evaluation results to reporters via callbacks.
    """

    def __init__(
        self,
        reporters: list["BaseReporter"] | None = None,
        conversation_id: str | None = None,
        evaluations: list[EvaluationDefinition] | None = None,
        default_evaluator: BaseEvaluator | None = None,
    ):
        super().__init__()
        self._reporters: list[BaseReporter] = reporters or []
        self._conversation_id: str = conversation_id or str(uuid.uuid4())
        self._ended: bool = False
        self._evaluation_results: list[EvaluationResult] = []

        self._context_collection_service = ObserverContextCollectionService(
            on_context_entry=self._dispatch_context_entry,
        )
        self._event_service = ObserverEventCollectionService(
            emit_event=self._emit_event,
        )
        self._evaluation_service = ObserverEvaluationService(
            evaluations=evaluations,
            default_evaluator=default_evaluator,
            on_evaluations=self._dispatch_evaluations,
        )

    async def _emit_event(self, event: VoicegroundEvent) -> None:
        """Emit an event to all registered reporters."""
        for reporter in self._reporters:
            await reporter.on_event(event)

    async def _dispatch_context_entry(self, entry: dict) -> None:
        """Notify all reporters of a context entry (called when a frame is processed)."""
        for reporter in self._reporters:
            await reporter.on_context_entry(entry)

    async def _dispatch_evaluations(self, results: list[EvaluationResult]) -> None:
        """Store and emit evaluation results to all reporters."""
        self._evaluation_results = results
        for reporter in self._reporters:
            await reporter.on_evaluations(results)

    @property
    def _evaluator(self):
        """Backward compatibility: evaluator used by the evaluation service."""
        return self._evaluation_service._evaluator

    def add_reporter(self, reporter: "BaseReporter") -> None:
        """Add a reporter to receive events."""
        self._reporters.append(reporter)

    def remove_reporter(self, reporter: "BaseReporter") -> None:
        """Remove a reporter."""
        self._reporters.remove(reporter)

    async def end(self) -> None:
        """End the observation session and finalize all reporters."""
        if self._ended:
            return

        await self._context_collection_service.flush_pending()
        transcript = self._context_collection_service.get_entries()
        await self._evaluation_service.run(transcript)

        for reporter in self._reporters:
            await reporter.on_end()

        self._ended = True

    async def on_push_frame(self, data: FramePushed) -> None:
        """Handle frame push events."""
        frame = data.frame

        if isinstance(frame, StartFrame):
            if not hasattr(self, "_started"):
                self._started = True
                for reporter in self._reporters:
                    await reporter.on_start(self._conversation_id)
            return

        if isinstance(frame, (EndFrame, CancelFrame)):
            await self.end()
            return

        await self._event_service.process_push_frame(data)

    async def on_process_frame(self, data: FrameProcessed) -> None:
        """Handle frame process events (context collection at aggregators)."""
        await self._context_collection_service.process_frame(data)
