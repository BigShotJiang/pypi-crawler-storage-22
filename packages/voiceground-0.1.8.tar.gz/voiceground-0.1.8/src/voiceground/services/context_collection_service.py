"""Context collection service for VoicegroundObserver.

Collects context (transcript) from frames that reach context aggregators:
- User: TranscriptionFrame at user aggregator
- Assistant: TTSTextFrame, TTSSpeakFrame (voice) or LLMTextFrame (text-only) at assistant aggregator
"""

from collections.abc import Awaitable, Callable
from typing import Any, TypedDict

from pipecat.frames.frames import (
    FunctionCallResultFrame,
    FunctionCallsStartedFrame,
    LLMFullResponseEndFrame,
    LLMTextFrame,
    TranscriptionFrame,
    TTSSpeakFrame,
    TTSTextFrame,
)
from pipecat.observers.base_observer import FrameProcessed
from pipecat.processors.aggregators.llm_response import (
    LLMAssistantContextAggregator,
    LLMUserContextAggregator,
)
from pipecat.processors.aggregators.llm_response_universal import (
    LLMAssistantAggregator,
    LLMUserAggregator,
)

OnContextEntry = Callable[[dict[str, Any]], Awaitable[None]]


class PendingToolCall(TypedDict):
    """Stored when a tool call starts; merged with result when it completes."""

    name: str
    arguments: dict[str, Any]


class ObserverContextCollectionService:
    """Collects conversation context from frames at context aggregators.

    Used by VoicegroundObserver to build context from:
    - TranscriptionFrame when processed by the user context aggregator
    - TTSTextFrame, TTSSpeakFrame, or LLMTextFrame when processed by the assistant
      context aggregator (flushed on LLMFullResponseEndFrame)
    - Tool calls: name/arguments from FunctionCallsStartedFrame, result from
      FunctionCallResultFrame (both at assistant context aggregator)

    When on_context_entry is set, it is called for each new entry as soon as the frame
    is processed (user, bot, or tool_call).
    """

    def __init__(
        self,
        on_context_entry: OnContextEntry | None = None,
    ) -> None:
        self._voiceground_context: list[dict] = []  # [{"role": "user"|"bot"|"tool_call", ...}, ...]
        self._voiceground_current_bot_content: str | None = None
        self._on_context_entry = on_context_entry
        self._voiceground_pending_tool_calls: dict[str, PendingToolCall] = {}

    async def process_frame(self, data: FrameProcessed) -> None:
        """Process a frame event and collect context when at user/assistant aggregators.
        Calls on_context_entry for each new entry as it is collected.
        """
        processor = data.processor
        frame = data.frame

        # Assistant context aggregator: collect bot text and tool calls
        if isinstance(
            processor,
            (LLMAssistantContextAggregator, LLMAssistantAggregator),
        ):
            if isinstance(frame, (TTSTextFrame, TTSSpeakFrame, LLMTextFrame)):
                text = getattr(frame, "text", "") or ""
                if text:
                    if self._voiceground_current_bot_content is None:
                        self._voiceground_current_bot_content = ""
                    self._voiceground_current_bot_content += text
            elif isinstance(frame, LLMFullResponseEndFrame):
                if self._voiceground_current_bot_content is not None:
                    entry = {"role": "bot", "content": self._voiceground_current_bot_content}
                    self._voiceground_context.append(entry)
                    self._voiceground_current_bot_content = None
                    if self._on_context_entry:
                        await self._on_context_entry(entry)
            elif isinstance(frame, FunctionCallsStartedFrame):
                for func_call in frame.function_calls:
                    tid: str = func_call.tool_call_id
                    args = func_call.arguments
                    self._voiceground_pending_tool_calls[tid] = PendingToolCall(
                        name=func_call.function_name,
                        arguments=dict(args) if args else {},
                    )
            elif isinstance(frame, FunctionCallResultFrame):
                pending: PendingToolCall | None = self._voiceground_pending_tool_calls.pop(
                    frame.tool_call_id, None
                )
                if pending is None:
                    return

                tool_entry: dict[str, Any] = {
                    "role": "tool_call",
                    "name": pending["name"],
                    "arguments": pending["arguments"],
                    "result": frame.result,
                }
                self._voiceground_context.append(tool_entry)
                if self._on_context_entry:
                    await self._on_context_entry(tool_entry)

        # User context aggregator: collect user text
        if isinstance(
            processor,
            (LLMUserContextAggregator, LLMUserAggregator),
        ):
            if isinstance(frame, TranscriptionFrame):
                if self._voiceground_current_bot_content is not None:
                    entry = {"role": "bot", "content": self._voiceground_current_bot_content}
                    self._voiceground_context.append(entry)
                    self._voiceground_current_bot_content = None
                    if self._on_context_entry:
                        await self._on_context_entry(entry)
                text = getattr(frame, "text", "") or ""
                if text:
                    entry = {"role": "user", "content": text}
                    self._voiceground_context.append(entry)
                    if self._on_context_entry:
                        await self._on_context_entry(entry)

    def get_entries(self) -> list[dict]:
        """Return full context entries (user, bot, tool_call). Includes any pending bot turn."""
        result = list(self._voiceground_context)
        if self._voiceground_current_bot_content is not None:
            result.append({"role": "bot", "content": self._voiceground_current_bot_content})
        return [e for e in result if e.get("role") in ("user", "bot", "tool_call")]

    def has_entries(self) -> bool:
        """True if any context has been collected (entries or pending bot content)."""
        return (
            len(self._voiceground_context) > 0 or self._voiceground_current_bot_content is not None
        )

    async def flush_pending(self) -> None:
        """Flush any pending bot turn (not yet closed by LLMFullResponseEndFrame).
        Appends it to context so get_entries() and evaluation see the full transcript.
        If on_context_entry is set, calls it with the pending entry. Call at end of session.
        """
        entry = self._pop_pending_bot_entry()
        if entry is not None:
            self._voiceground_context.append(entry)
            if self._on_context_entry:
                await self._on_context_entry(entry)

    def _pop_pending_bot_entry(self) -> dict | None:
        """Return and clear any pending bot turn."""
        if self._voiceground_current_bot_content is None:
            return None
        entry = {"role": "bot", "content": self._voiceground_current_bot_content}
        self._voiceground_current_bot_content = None
        return entry
