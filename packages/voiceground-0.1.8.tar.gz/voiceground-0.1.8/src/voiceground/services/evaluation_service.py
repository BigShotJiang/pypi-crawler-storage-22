"""Evaluation service for VoicegroundObserver.

Runs evaluations on a transcript and emits results via a callback.
"""

from collections.abc import Awaitable, Callable
from typing import TYPE_CHECKING

from loguru import logger

from voiceground.evaluations import EvaluationDefinition, EvaluationResult
from voiceground.evaluator import VoicegroundEvaluator

if TYPE_CHECKING:
    from voiceground.evaluations import BaseEvaluator

OnEvaluations = Callable[[list[EvaluationResult]], Awaitable[None]]


class ObserverEvaluationService:
    """Runs conversation evaluations and emits results via callback.

    Uses VoicegroundEvaluator to run evaluations on a transcript;
    calls on_evaluations with the result list (or empty on error).
    """

    def __init__(
        self,
        evaluations: list[EvaluationDefinition] | None = None,
        default_evaluator: "BaseEvaluator | None" = None,
        on_evaluations: OnEvaluations | None = None,
    ) -> None:
        self._evaluator = VoicegroundEvaluator(
            evaluations=evaluations or [],
            default_evaluator=default_evaluator,
        )
        self._on_evaluations = on_evaluations

    async def run(self, transcript: list[dict]) -> None:
        """Run evaluations on the transcript and emit results via on_evaluations."""
        if not self._on_evaluations:
            return
        if not transcript or not self._evaluator._evaluations:
            await self._on_evaluations([])
            return
        try:
            results = await self._evaluator.evaluate_conversation(transcript)
            await self._on_evaluations(results)
        except Exception as e:
            logger.error(f"Evaluation failed with error: {e}", exc_info=True)
            await self._on_evaluations([])
