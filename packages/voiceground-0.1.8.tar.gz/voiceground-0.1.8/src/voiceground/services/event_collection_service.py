"""Event collection service for VoicegroundObserver.

Tracks pipeline frame push events and emits VoicegroundEvents based on
category configuration (gates, accumulators, triggers).
"""

import uuid
from collections.abc import Awaitable, Callable
from dataclasses import dataclass, field
from typing import Any

from pipecat.frames.frames import (
    BotStartedSpeakingFrame,
    BotStoppedSpeakingFrame,
    FunctionCallCancelFrame,
    FunctionCallResultFrame,
    FunctionCallsStartedFrame,
    LLMContextFrame,
    LLMFullResponseEndFrame,
    LLMRunFrame,
    LLMTextFrame,
    TranscriptionFrame,
    TTSAudioRawFrame,
    TTSStartedFrame,
    TTSStoppedFrame,
    TTSTextFrame,
    UserStartedSpeakingFrame,
    UserStoppedSpeakingFrame,
    VADUserStartedSpeakingFrame,
)
from pipecat.observers.base_observer import FramePushed
from pipecat.processors.aggregators.llm_response import (
    LLMAssistantContextAggregator,
    LLMUserContextAggregator,
)
from pipecat.processors.aggregators.llm_response_universal import (
    LLMAssistantAggregator,
    LLMUserAggregator,
)
from pipecat.processors.aggregators.openai_llm_context import OpenAILLMContextFrame
from pipecat.processors.frame_processor import FrameDirection
from pipecat.services.llm_service import LLMService

from voiceground.events import EventCategory, EventType, VoicegroundEvent

# Type for async event emission callback
EmitEventCallback = Callable[[VoicegroundEvent], Awaitable[None]]


@dataclass
class FrameTrigger:
    """Trigger configuration for a specific frame type.

    Attributes:
        frame: The frame type that can trigger this event.
        source_class: Only trigger if source is an instance of one of these classes.
        direction: Only trigger if frame is pushed in this direction (None = any direction).
        data_extractor: Optional function to extract event data from the frame.
    """

    frame: type
    source_class: tuple[type, ...] | None = None
    direction: FrameDirection | None = None
    data_extractor: Callable[[Any], dict[str, Any]] | None = field(default=None)


@dataclass
class EventTrigger:
    """Trigger configuration for an event type."""

    frame_triggers: list[FrameTrigger]


@dataclass
class CategoryEvents:
    """Event configuration for a category.

    Attributes:
        category: The event category.
        description: Human-readable description.
        start: Start event trigger (optional).
        end: End event trigger (optional).
        first_byte: First byte event trigger (optional).
        data_accumulator: Function to accumulate data from frames (optional).
    """

    category: EventCategory
    description: str = ""
    start: EventTrigger | None = None
    end: EventTrigger | None = None
    first_byte: EventTrigger | None = None
    data_accumulator: Callable[[Any, dict[str, Any]], dict[str, Any]] | None = field(default=None)


# =============================================================================
# EVENT CONFIGURATION - Edit this to customize event tracking
# =============================================================================

CATEGORIES: list[CategoryEvents] = [
    # --- User Speech ---
    CategoryEvents(
        category=EventCategory.USER_SPEAK,
        start=EventTrigger(frame_triggers=[FrameTrigger(frame=UserStartedSpeakingFrame)]),
        end=EventTrigger(
            frame_triggers=[
                FrameTrigger(
                    frame=UserStoppedSpeakingFrame,
                    direction=FrameDirection.DOWNSTREAM,
                )
            ]
        ),
    ),
    # --- Bot Speech ---
    CategoryEvents(
        category=EventCategory.BOT_SPEAK,
        start=EventTrigger(frame_triggers=[FrameTrigger(frame=BotStartedSpeakingFrame)]),
        end=EventTrigger(
            frame_triggers=[
                FrameTrigger(
                    frame=BotStoppedSpeakingFrame,
                    direction=FrameDirection.DOWNSTREAM,
                )
            ]
        ),
    ),
    # --- STT (Speech-to-Text) ---
    CategoryEvents(
        category=EventCategory.STT,
        start=EventTrigger(frame_triggers=[FrameTrigger(frame=VADUserStartedSpeakingFrame)]),
        end=EventTrigger(
            frame_triggers=[
                FrameTrigger(
                    frame=TranscriptionFrame,
                    data_extractor=lambda f: {"text": getattr(f, "text", "") or ""},
                )
            ]
        ),
    ),
    # --- LLM (Large Language Model) ---
    CategoryEvents(
        category=EventCategory.LLM,
        start=EventTrigger(
            frame_triggers=[
                FrameTrigger(
                    frame=LLMContextFrame,
                    source_class=(LLMUserContextAggregator,),
                ),
                FrameTrigger(
                    frame=LLMContextFrame,
                    source_class=(LLMAssistantContextAggregator,),
                    direction=FrameDirection.UPSTREAM,
                ),
                FrameTrigger(
                    frame=OpenAILLMContextFrame,
                    source_class=(LLMUserContextAggregator,),
                ),
                FrameTrigger(
                    frame=OpenAILLMContextFrame,
                    source_class=(LLMAssistantContextAggregator,),
                    direction=FrameDirection.UPSTREAM,
                ),
                FrameTrigger(
                    frame=LLMContextFrame,
                    source_class=(LLMUserAggregator,),
                ),
                FrameTrigger(
                    frame=LLMContextFrame,
                    source_class=(LLMAssistantAggregator,),
                    direction=FrameDirection.UPSTREAM,
                ),
                FrameTrigger(frame=LLMRunFrame),
            ]
        ),
        end=EventTrigger(
            frame_triggers=[
                FrameTrigger(
                    frame=LLMFullResponseEndFrame,
                    source_class=(LLMService,),
                )
            ]
        ),
        first_byte=EventTrigger(frame_triggers=[FrameTrigger(frame=LLMTextFrame)]),
        data_accumulator=lambda frame, acc: {
            **acc,
            "text": acc.get("text", "") + (getattr(frame, "text", "") or ""),
        }
        if isinstance(frame, LLMTextFrame)
        else acc,
    ),
    # --- TTS (Text-to-Speech) ---
    CategoryEvents(
        category=EventCategory.TTS,
        start=EventTrigger(frame_triggers=[FrameTrigger(frame=TTSStartedFrame)]),
        end=EventTrigger(frame_triggers=[FrameTrigger(frame=TTSStoppedFrame)]),
        first_byte=EventTrigger(frame_triggers=[FrameTrigger(frame=TTSAudioRawFrame)]),
        data_accumulator=lambda frame, acc: {
            **acc,
            "text": acc.get("text", "") + (getattr(frame, "text", "") or ""),
        }
        if isinstance(frame, TTSTextFrame)
        else acc,
    ),
    # --- Tool Calling (Function Calling) ---
    CategoryEvents(
        category=EventCategory.TOOL_CALL,
        description="LLM function/tool calling",
        start=EventTrigger(
            frame_triggers=[
                FrameTrigger(
                    frame=FunctionCallsStartedFrame,
                    data_extractor=lambda f: {
                        "description": ", ".join(fc.function_name for fc in f.function_calls),
                        "operation": ", ".join(fc.function_name for fc in f.function_calls),
                    }
                    if f.function_calls
                    else {},
                )
            ]
        ),
        end=EventTrigger(
            frame_triggers=[
                FrameTrigger(
                    frame=FunctionCallResultFrame,
                    data_extractor=lambda f: {"operation": f.function_name},
                ),
                FrameTrigger(
                    frame=FunctionCallCancelFrame,
                    data_extractor=lambda f: {"operation": f.function_name},
                ),
            ]
        ),
    ),
    # --- System: Context Aggregation ---
    CategoryEvents(
        category=EventCategory.SYSTEM,
        description="Context aggregation timeout",
        start=EventTrigger(
            frame_triggers=[
                FrameTrigger(
                    frame=TranscriptionFrame,
                    data_extractor=lambda f: {"operation": "context_aggregation_timeout"},
                )
            ]
        ),
        end=EventTrigger(
            frame_triggers=[
                FrameTrigger(
                    frame=LLMContextFrame,
                    source_class=(LLMUserContextAggregator,),
                    data_extractor=lambda f: {"operation": "context_aggregation_timeout"},
                ),
                FrameTrigger(
                    frame=OpenAILLMContextFrame,
                    source_class=(LLMUserContextAggregator,),
                    data_extractor=lambda f: {"operation": "context_aggregation_timeout"},
                ),
                FrameTrigger(
                    frame=LLMRunFrame,
                    source_class=(LLMUserContextAggregator,),
                    data_extractor=lambda f: {"operation": "context_aggregation_timeout"},
                ),
                FrameTrigger(
                    frame=LLMContextFrame,
                    source_class=(LLMUserAggregator,),
                    data_extractor=lambda f: {"operation": "context_aggregation_timeout"},
                ),
                FrameTrigger(
                    frame=LLMRunFrame,
                    source_class=(LLMUserAggregator,),
                    data_extractor=lambda f: {"operation": "context_aggregation_timeout"},
                ),
            ]
        ),
    ),
]


class ObserverEventCollectionService:
    """Collects pipeline frame push events and emits VoicegroundEvents.

    Uses category configuration (gates, accumulators, triggers) to detect
    start/end/first_byte events and emit them via the provided callback.
    """

    def __init__(self, *, emit_event: EmitEventCallback) -> None:
        self._emit_event = emit_event
        self._processed_frames: set[int] = set()
        self._category_ready: dict[EventCategory, bool] = {}
        self._first_byte_pending: dict[EventCategory, bool] = {}
        self._category_accumulated_data: dict[EventCategory, dict[str, Any]] = {}
        self._tool_calls: dict[str, dict] = {}
        self._init_gates()

    def _init_gates(self) -> None:
        for cat_config in CATEGORIES:
            if cat_config.start:
                self._category_ready[cat_config.category] = True
            if cat_config.first_byte:
                self._first_byte_pending[cat_config.category] = True
            if cat_config.data_accumulator:
                self._category_accumulated_data[cat_config.category] = {}

    def get_tool_calls(self) -> dict[str, dict]:
        """Return tracked tool calls for transcript building."""
        return self._tool_calls

    async def process_push_frame(self, data: FramePushed) -> bool:
        """Process a frame push event. Returns False if frame was already processed (caller may skip)."""
        frame = data.frame
        if frame.id in self._processed_frames:
            return False
        self._processed_frames.add(frame.id)

        timestamp = data.timestamp
        source_name = data.source.name if hasattr(data.source, "name") else ""

        # Update data accumulators for active categories
        for cat_config in CATEGORIES:
            if cat_config.data_accumulator and not self._category_ready.get(
                cat_config.category, True
            ):
                acc_data = self._category_accumulated_data.get(cat_config.category, {})
                self._category_accumulated_data[cat_config.category] = cat_config.data_accumulator(
                    frame, acc_data
                )

        # Process each category
        for cat_config in CATEGORIES:
            category = cat_config.category

            if cat_config.start:
                gate_open = self._category_ready.get(category, True)
                if gate_open and await self._try_emit(
                    category,
                    EventType.START,
                    cat_config.start,
                    frame,
                    timestamp,
                    source_name,
                    data.source,
                    data.direction,
                ):
                    self._category_ready[category] = False
                    if category in self._first_byte_pending:
                        self._first_byte_pending[category] = True
                    if cat_config.data_accumulator:
                        self._category_accumulated_data[category] = {}

            if cat_config.first_byte and self._first_byte_pending.get(category, False):
                if await self._try_emit(
                    category,
                    EventType.FIRST_BYTE,
                    cat_config.first_byte,
                    frame,
                    timestamp,
                    source_name,
                    data.source,
                    data.direction,
                ):
                    self._first_byte_pending[category] = False

            if cat_config.end:
                matched_end_trigger: FrameTrigger | None = None
                for frame_trigger in cat_config.end.frame_triggers:
                    if isinstance(frame, frame_trigger.frame):
                        if not self._check_source(frame_trigger.source_class, data.source):
                            continue
                        if (
                            frame_trigger.direction is not None
                            and data.direction != frame_trigger.direction
                        ):
                            continue
                        matched_end_trigger = frame_trigger
                        break

                if matched_end_trigger:
                    frame_data: dict[str, Any] = {}
                    if matched_end_trigger.data_extractor:
                        frame_data = matched_end_trigger.data_extractor(frame)
                    accumulated_data = self._category_accumulated_data.get(category, {})
                    if cat_config.data_accumulator and accumulated_data:
                        event_data = {**frame_data, **accumulated_data}
                    else:
                        event_data = frame_data
                    event = self._create_event(
                        category, EventType.END, timestamp, source_name, event_data
                    )
                    await self._emit_event(event)
                    if cat_config.data_accumulator:
                        self._category_accumulated_data[category] = {}
                    self._category_ready[category] = True

        return True

    def _create_event(
        self,
        category: EventCategory,
        event_type: EventType,
        timestamp: int,
        source: str = "",
        data: dict[str, Any] | None = None,
    ) -> VoicegroundEvent:
        timestamp_seconds = timestamp / 1_000_000_000
        return VoicegroundEvent(
            id=str(uuid.uuid4()),
            timestamp=timestamp_seconds,
            category=category,
            type=event_type,
            source=source,
            data=data or {},
        )

    def _check_source(
        self,
        source_class: tuple[type, ...] | None,
        source_obj: object,
    ) -> bool:
        if source_class is not None:
            return isinstance(source_obj, source_class)
        return True

    async def _try_emit(
        self,
        category: EventCategory,
        event_type: EventType,
        trigger: EventTrigger,
        frame: Any,
        timestamp: int,
        source_name: str,
        source_obj: object,
        direction: FrameDirection,
    ) -> bool:
        matched_trigger: FrameTrigger | None = None
        for frame_trigger in trigger.frame_triggers:
            if isinstance(frame, frame_trigger.frame):
                if not self._check_source(frame_trigger.source_class, source_obj):
                    continue
                if frame_trigger.direction is not None and direction != frame_trigger.direction:
                    continue
                matched_trigger = frame_trigger
                break
        else:
            return False

        event_data: dict[str, Any] = {}
        if matched_trigger.data_extractor:
            event_data = matched_trigger.data_extractor(frame)

        if category == EventCategory.TOOL_CALL:
            self._track_tool_call(event_type, frame, event_data)

        event = self._create_event(category, event_type, timestamp, source_name, event_data)
        await self._emit_event(event)
        return True

    def _track_tool_call(
        self, event_type: EventType, frame: Any, event_data: dict[str, Any]
    ) -> None:
        if event_type == EventType.START and isinstance(frame, FunctionCallsStartedFrame):
            for func_call in frame.function_calls:
                self._tool_calls[func_call.tool_call_id] = {
                    "name": func_call.function_name,
                    "arguments": func_call.arguments,
                    "result": None,
                }
        elif event_type == EventType.END and isinstance(frame, FunctionCallResultFrame):
            if frame.tool_call_id in self._tool_calls:
                self._tool_calls[frame.tool_call_id]["result"] = frame.result
