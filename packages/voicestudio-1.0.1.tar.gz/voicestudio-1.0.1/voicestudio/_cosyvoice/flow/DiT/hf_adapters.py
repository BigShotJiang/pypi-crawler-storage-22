"""
HuggingFace Transformers Adapter Module

Wrapper classes that replace x_transformers components with HuggingFace Transformers implementations.
Maintains API compatibility with existing CosyVoice code while using HF's optimized implementations.

Main Components:
- RotaryEmbedding: HF-based replacement for x_transformers.RotaryEmbedding
- apply_rotary_pos_emb: HF-compatible implementation of x_transformers.apply_rotary_pos_emb
- RMSNorm: Recommend using existing CosyVoice modules.RMSNorm (already optimized)
"""

from __future__ import annotations

import torch
import torch.nn.functional as F
from torch import nn
from torch.amp import autocast

from transformers.models.llama.modeling_llama import LlamaRotaryEmbedding, LlamaRMSNorm


class RotaryEmbedding(LlamaRotaryEmbedding):
    """
    HF Transformers-based implementation of x_transformers.RotaryEmbedding

    Inherits from transformers.models.llama.modeling_llama.LlamaRotaryEmbedding,
    providing full x_transformers API compatibility through method overrides.

    x_transformers RoPE provides the following features:
    1. forward_from_seq_len(seq_len) -> (freqs, scale) method
    2. xPos scaling support (use_xpos=True)
    3. Base rescaling support (NTK-aware scaling)
    4. Interpolation factor support

    Args:
        dim: Rotation embedding dimension (typically head_dim)
        use_xpos: Whether to use xPos scaling (default: False)
        scale_base: xPos scale base (default: 512)
        interpolation_factor: Position interpolation factor (default: 1.0)
        base: RoPE base frequency (default: 10000)
        base_rescale_factor: Base rescaling factor (default: 1.0, NTK-aware)
    """

    def __init__(
        self,
        dim: int,
        use_xpos: bool = False,
        scale_base: int = 512,
        interpolation_factor: float = 1.0,
        base: float = 10000,
        base_rescale_factor: float = 1.0,
    ):
        # Skip parent class __init__ to avoid config requirement
        # Call nn.Module.__init__ directly
        nn.Module.__init__(self)

        # NTK-aware rescaling (same as x_transformers)
        # https://www.reddit.com/r/LocalLLaMA/comments/14lz7j5/ntkaware_scaled_rope_allows_llama_models_to_have/
        base *= base_rescale_factor ** (dim / (dim - 2))

        # Calculate inverse frequency (exactly as x_transformers)
        inv_freq = 1.0 / (base ** (torch.arange(0, dim, 2).float() / dim))
        self.register_buffer("inv_freq", inv_freq, persistent=False)

        # Interpolation factor
        assert interpolation_factor >= 1.0
        self.interpolation_factor = interpolation_factor

        # xPos scaling (optional)
        if not use_xpos:
            self.register_buffer("scale", None, persistent=False)
            self.scale_base = None
        else:
            # xPos formula from x_transformers
            scale = (torch.arange(0, dim, 2) + 0.4 * dim) / (1.4 * dim)
            self.register_buffer("scale", scale, persistent=False)
            self.scale_base = scale_base

    def forward_from_seq_len(self, seq_len: int):
        """
        Generate RoPE from sequence length

        Args:
            seq_len: Sequence length

        Returns:
            tuple: (freqs, xpos_scale)
                - freqs: RoPE frequencies of shape [seq_len, dim]
                - xpos_scale: xPos scale of shape [seq_len, dim//2] (1.0 if use_xpos=False)
        """
        device = self.inv_freq.device
        t = torch.arange(seq_len, device=device)
        return self.forward(t)

    @autocast("cuda", enabled=False)
    def forward(self, t: torch.Tensor, offset: int = 0):
        """
        Args:
            t: position indices [n] or [b, n]
            offset: position offset (default: 0)

        Returns:
            tuple: (freqs, scale)
                - freqs: [1, n, dim] or [b, n, dim] RoPE frequencies
                - scale: xPos scale or 1.0
        """
        max_pos = t.max() + 1

        # Convert t to [b, n] shape
        if t.ndim == 1:
            t = t.unsqueeze(0)  # [n] -> [1, n]

        # Calculate frequencies (exactly as x_transformers formula)
        # freqs[b, i, j] = t[b, i] * inv_freq[j] / interpolation_factor
        freqs = torch.einsum("b i , j -> b i j", t.type_as(self.inv_freq), self.inv_freq)
        freqs = freqs / self.interpolation_factor

        # Dimension duplication: [b, n, dim//2] -> [b, n, dim]
        # x_transformers way: stack + flatten
        freqs = torch.stack((freqs, freqs), dim=-1)  # [b, n, dim//2, 2]
        freqs = freqs.flatten(-2)  # [b, n, dim]

        # xPos scaling calculation (optional)
        if self.scale is None:
            return freqs, 1.0

        # xPos scale formula (x_transformers)
        # power = (t - (max_pos // 2)) / scale_base
        # scale = self.scale ** power
        power = (t - (max_pos // 2)) / self.scale_base
        scale = self.scale ** power.unsqueeze(-1)  # [b, n, 1]

        # Dimension duplication (x_transformers way)
        scale = torch.stack((scale, scale), dim=-1)  # [b, n, dim//2, 2]
        scale = scale.flatten(-2)  # [b, n, dim]

        return freqs, scale


def rotate_half(x: torch.Tensor) -> torch.Tensor:
    """
    Rotate half of tensor x

    x_transformers implementation:
        x = rearrange(x, '... (d r) -> ... d r', r=2)
        x1, x2 = x.unbind(dim=-1)
        return rearrange(torch.stack((-x2, x1), dim=-1), '... d r -> ... (d r)')

    Args:
        x: Tensor of shape [..., dim]

    Returns:
        Rotated tensor [..., dim]
    """
    # [..., dim] -> [..., dim//2, 2]
    x = x.unflatten(-1, (-1, 2))
    x1, x2 = x.unbind(dim=-1)
    # Rotation: (x1, x2) -> (-x2, x1)
    x = torch.stack((-x2, x1), dim=-1)
    # [..., dim//2, 2] -> [..., dim]
    return x.flatten(-2)


@autocast("cuda", enabled=False)
def apply_rotary_pos_emb(
    t: torch.Tensor,
    freqs: torch.Tensor,
    scale: float | torch.Tensor = 1.0
) -> torch.Tensor:
    """
    Fully compatible implementation of x_transformers.apply_rotary_pos_emb

    Key features from original x_transformers implementation:
    1. Scale parameter support (for xPos)
    2. Partial RoPE support (rot_dim < t.shape[-1])
    3. Automatic broadcasting
    4. Preserves original dtype

    Args:
        t: Query or key tensor of shape [batch, heads, seq_len, dim]
        freqs: RoPE frequencies of shape [1, seq_len, dim] or [batch, seq_len, dim]
        scale: xPos scale (float or tensor)

    Returns:
        Tensor with RoPE applied
    """
    rot_dim = freqs.shape[-1]
    seq_len = t.shape[-2]
    orig_dtype = t.dtype

    # Match sequence length
    freqs = freqs[:, -seq_len:, :]
    if isinstance(scale, torch.Tensor):
        scale = scale[:, -seq_len:, :]

    # Broadcasting: [b, n, d] -> [b, 1, n, d] (for [b, h, n, d] tensor)
    if t.ndim == 4 and freqs.ndim == 3:
        freqs = freqs.unsqueeze(1)

        if isinstance(scale, torch.Tensor):
            scale = scale.unsqueeze(1)

    # Support partial RoPE (Wang et al. GPT-J)
    # If rot_dim is smaller than total dim, only rotate the first part
    t_rotated = t[..., :rot_dim]
    t_unrotated = t[..., rot_dim:]

    # Apply RoPE (x_transformers formula)
    # t' = t * cos(freq) * scale + rotate_half(t) * sin(freq) * scale
    t_rotated = (t_rotated * freqs.cos() * scale) + (rotate_half(t_rotated) * freqs.sin() * scale)

    # Concatenate with unrotated part
    out = torch.cat((t_rotated, t_unrotated), dim=-1)

    # Restore original dtype
    return out.type(orig_dtype)


class RMSNorm(LlamaRMSNorm):
    """
    HF Transformers-based implementation of x_transformers.RMSNorm

    Inherits from transformers.models.llama.modeling_llama.LlamaRMSNorm,
    which provides an optimized implementation of RMS normalization.

    Note: CosyVoice already has an optimized RMSNorm implementation in cosyvoice/flow/DiT/modules.py
    that uses PyTorch 2.4+'s native F.rms_norm which may be faster.

    This class inherits HF's LlamaRMSNorm for consistency with HuggingFace ecosystem.

    x_transformers.RMSNorm characteristics:
    - Uses F.normalize(x, dim=-1) * scale * gamma approach
    - Has unit_offset option (adjusts gamma initialization)

    CosyVoice modules.RMSNorm characteristics:
    - Uses PyTorch 2.4+ F.rms_norm (faster)
    - Standard RMS normalization formula

    HF LlamaRMSNorm characteristics (inherited):
    - float32 casting + rsqrt approach
    - Standard implementation
    - Compatible with HuggingFace ecosystem
    """

    def __init__(self, dim: int, eps: float = 1e-6):
        """
        Args:
            dim: Normalization dimension
            eps: Epsilon for numerical stability
        """
        # Call parent class (LlamaRMSNorm) __init__
        # LlamaRMSNorm uses 'hidden_size' instead of 'dim'
        super().__init__(hidden_size=dim, eps=eps)