"""REST API for voicetest.

Thin wrapper over the core API (voicetest.api). All business logic
lives in api.py - this module just handles HTTP concerns.

Run with: voicetest serve
Or: uvicorn voicetest.rest:app --reload
"""

import asyncio
from datetime import UTC, datetime
import json
import os
from pathlib import Path
import tempfile
from typing import Any

from fastapi import APIRouter, BackgroundTasks, FastAPI, HTTPException, UploadFile, WebSocket
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel
from starlette.websockets import WebSocketDisconnect, WebSocketState

from voicetest import api
from voicetest.container import get_container, get_importer_registry, get_session
from voicetest.demo import get_demo_agent, get_demo_tests
from voicetest.executor import RunJob, get_executor_factory
from voicetest.exporters.test_cases import export_tests
from voicetest.models.agent import AgentGraph, GlobalMetric, MetricsConfig
from voicetest.models.results import Message, MetricResult, TestResult, TestRun
from voicetest.models.test_case import RunOptions, TestCase
from voicetest.platforms.registry import PlatformRegistry
from voicetest.retry import RetryError
from voicetest.settings import Settings, load_settings, save_settings
from voicetest.storage.repositories import (
    AgentRepository,
    RunRepository,
    TestCaseRepository,
)


# Active runs: run_id -> {"cancel": Event, "websockets": set[WebSocket], "message_queue": list}
_active_runs: dict[str, dict[str, Any]] = {}

_initialized = False


def init_storage() -> None:
    """Initialize storage and register linked agents."""
    global _initialized

    get_session()
    _initialized = True

    linked_agents = os.environ.get("VOICETEST_LINKED_AGENTS", "")
    if linked_agents:
        for agent_path in linked_agents.split(","):
            if agent_path.strip():
                _register_linked_agent(Path(agent_path.strip()))


def _register_linked_agent(path: Path) -> None:
    """Register a linked agent from filesystem if not already registered."""
    repo = get_agent_repo()
    existing = repo.list_all()
    for agent in existing:
        if agent.get("source_path") == str(path):
            return

    name = path.stem
    repo.create(
        name=name,
        source_type="linked",
        source_path=str(path),
    )


def get_agent_repo() -> AgentRepository:
    """Get the agent repository from the DI container."""
    if not _initialized:
        init_storage()
    return get_container().resolve(AgentRepository)


def get_test_case_repo() -> TestCaseRepository:
    """Get the test case repository from the DI container."""
    if not _initialized:
        init_storage()
    return get_container().resolve(TestCaseRepository)


def get_run_repo() -> RunRepository:
    """Get the run repository from the DI container."""
    if not _initialized:
        init_storage()
    return get_container().resolve(RunRepository)


def _find_web_dist() -> Path | None:
    """Find the web dist folder, checking both dev and installed locations."""
    # Development: relative to package root
    dev_path = Path(__file__).parent.parent / "web" / "dist"
    if dev_path.exists():
        return dev_path

    # Installed: in site-packages alongside voicetest
    installed_path = Path(__file__).parent.parent / "web" / "dist"
    if installed_path.exists():
        return installed_path

    return None


WEB_DIST = _find_web_dist()

app = FastAPI(
    title="voicetest",
    description="Voice agent test harness API",
    version="0.1.0",
)

# Add CORS middleware to allow cross-origin requests
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

router = APIRouter(prefix="/api")


# Request/Response models


class ImportRequest(BaseModel):
    """Request to import an agent config."""

    config: dict[str, Any]
    source: str | None = None


class RemoteAgentInfo(BaseModel):
    """Information about a remote agent on a platform."""

    id: str
    name: str


class PlatformStatusResponse(BaseModel):
    """Response from platform status check."""

    configured: bool
    platform: str


class PlatformInfo(BaseModel):
    """Information about a platform."""

    name: str
    configured: bool
    env_key: str
    required_env_keys: list[str]


class ConfigurePlatformRequest(BaseModel):
    """Request to configure platform credentials."""

    api_key: str
    api_secret: str | None = None


class ExportToPlatformRequest(BaseModel):
    """Request to export an agent to a platform."""

    graph: AgentGraph
    name: str | None = None


class ExportToPlatformResponse(BaseModel):
    """Response from exporting an agent to a platform."""

    id: str
    name: str
    platform: str


class SyncStatusResponse(BaseModel):
    """Response from sync status check."""

    can_sync: bool
    reason: str | None = None
    platform: str | None = None
    remote_id: str | None = None
    needs_configuration: bool = False


class SyncToPlatformRequest(BaseModel):
    """Request to sync an agent to its source platform."""

    graph: AgentGraph


class SyncToPlatformResponse(BaseModel):
    """Response from syncing an agent to a platform."""

    id: str
    name: str
    platform: str
    synced: bool


class ExportRequest(BaseModel):
    """Request to export an agent graph."""

    graph: AgentGraph
    format: str


class RunTestRequest(BaseModel):
    """Request to run a single test."""

    graph: AgentGraph
    test_case: TestCase
    options: RunOptions | None = None


class RunTestsRequest(BaseModel):
    """Request to run multiple tests."""

    graph: AgentGraph
    test_cases: list[TestCase]
    options: RunOptions | None = None


class EvaluateRequest(BaseModel):
    """Request to evaluate a transcript."""

    transcript: list[Message]
    metrics: list[str]


class CreateAgentRequest(BaseModel):
    """Request to create an agent from config or file path."""

    name: str
    config: dict[str, Any] | None = None
    path: str | None = None
    source: str | None = None


class UpdateAgentRequest(BaseModel):
    """Request to update an agent."""

    name: str | None = None
    default_model: str | None = None
    graph_json: str | None = None


class UpdateMetricsConfigRequest(BaseModel):
    """Request to update an agent's metrics configuration."""

    threshold: float = 0.7
    global_metrics: list[GlobalMetric] = []


class CreateTestCaseRequest(BaseModel):
    """Request to create a test case."""

    name: str
    user_prompt: str
    metrics: list[str] = []
    dynamic_variables: dict[str, Any] = {}
    tool_mocks: list[Any] = []
    type: str = "simulation"
    llm_model: str | None = None
    includes: list[str] = []
    excludes: list[str] = []
    patterns: list[str] = []


class StartRunRequest(BaseModel):
    """Request to start a test run."""

    test_ids: list[str] | None = None
    options: RunOptions | None = None


class ExportTestsRequest(BaseModel):
    """Request to export test cases."""

    format: str = "retell"
    test_ids: list[str] | None = None  # None means all tests


class ImporterInfo(BaseModel):
    """Importer information for API response."""

    source_type: str
    description: str
    file_patterns: list[str]


# Endpoints


@router.get("/health")
async def health() -> dict[str, str]:
    """Health check endpoint."""
    return {"status": "ok"}


class ExportFormatInfo(BaseModel):
    """Export format information for API response."""

    id: str
    name: str
    description: str


@router.get("/importers", response_model=list[ImporterInfo])
async def list_importers() -> list[ImporterInfo]:
    """List available importers."""
    importers = api.list_importers()
    return [
        ImporterInfo(
            source_type=imp.source_type,
            description=imp.description,
            file_patterns=imp.file_patterns,
        )
        for imp in importers
    ]


@router.get("/exporters", response_model=list[ExportFormatInfo])
async def list_exporters() -> list[ExportFormatInfo]:
    """List available export formats."""
    formats = api.list_export_formats()
    return [ExportFormatInfo(**f) for f in formats]


@router.post("/agents/import", response_model=AgentGraph)
async def import_agent(request: ImportRequest) -> AgentGraph:
    """Import an agent from config."""
    try:
        return await api.import_agent(request.config, source=request.source)
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e)) from None


@router.post("/agents/import-file", response_model=AgentGraph)
async def import_agent_file(file: UploadFile, source: str | None = None) -> AgentGraph:
    """Import an agent from an uploaded file (XLSForm, JSON, etc.)."""
    if not file.filename:
        raise HTTPException(status_code=400, detail="No filename provided")

    suffix = Path(file.filename).suffix
    try:
        with tempfile.NamedTemporaryFile(suffix=suffix, delete=False) as tmp:
            content = await file.read()
            tmp.write(content)
            tmp_path = tmp.name

        try:
            return await api.import_agent(tmp_path, source=source)
        finally:
            Path(tmp_path).unlink(missing_ok=True)
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e)) from None


@router.post("/agents/export")
async def export_agent(request: ExportRequest) -> dict[str, str]:
    """Export an agent graph to a format."""
    try:
        content = await api.export_agent(request.graph, format=request.format)
        return {"content": content, "format": request.format}
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e)) from None


def _build_run_options(settings: Settings, request_options: RunOptions | None) -> RunOptions:
    """Build RunOptions from settings, with request options for run params only.

    Models come from settings (can be None if not configured).
    Run parameters (max_turns, timeout, verbose, flow_judge, streaming) come from
    request if provided, otherwise from settings.
    """
    return RunOptions(
        agent_model=settings.models.agent,
        simulator_model=settings.models.simulator,
        judge_model=settings.models.judge,
        max_turns=request_options.max_turns if request_options else settings.run.max_turns,
        timeout_seconds=request_options.timeout_seconds if request_options else 60.0,
        verbose=(request_options.verbose if request_options else False) or settings.run.verbose,
        flow_judge=(
            (request_options.flow_judge if request_options else False) or settings.run.flow_judge
        ),
        streaming=settings.run.streaming,
        test_model_precedence=settings.run.test_model_precedence,
    )


@router.post("/runs/single", response_model=TestResult)
async def run_test(request: RunTestRequest) -> TestResult:
    """Run a single test case."""
    settings = load_settings()
    settings.apply_env()
    options = _build_run_options(settings, request.options)
    return await api.run_test(
        request.graph,
        request.test_case,
        options=options,
    )


@router.post("/runs", response_model=TestRun)
async def run_tests(request: RunTestsRequest) -> TestRun:
    """Run multiple test cases."""
    settings = load_settings()
    settings.apply_env()
    options = _build_run_options(settings, request.options)
    return await api.run_tests(
        request.graph,
        request.test_cases,
        options=options,
    )


@router.post("/evaluate", response_model=list[MetricResult])
async def evaluate_transcript(request: EvaluateRequest) -> list[MetricResult]:
    """Evaluate a transcript against metrics."""
    return await api.evaluate_transcript(
        request.transcript,
        request.metrics,
    )


@router.get("/settings", response_model=Settings)
async def get_settings() -> Settings:
    """Get current settings from .voicetest.toml."""
    return load_settings()


@router.get("/settings/defaults", response_model=Settings)
async def get_default_settings() -> Settings:
    """Get default settings (not from file)."""
    return Settings()


@router.put("/settings", response_model=Settings)
async def update_settings(settings: Settings) -> Settings:
    """Update settings in .voicetest.toml."""
    save_settings(settings)
    return settings


@router.get("/agents")
async def list_agents() -> list[dict]:
    """List all agents."""
    return get_agent_repo().list_all()


@router.get("/agents/{agent_id}")
async def get_agent(agent_id: str) -> dict:
    """Get agent by ID."""
    repo = get_agent_repo()
    agent = repo.get(agent_id)
    if not agent:
        raise HTTPException(status_code=404, detail="Agent not found")
    return agent


@router.get("/agents/{agent_id}/graph", response_model=AgentGraph)
async def get_agent_graph(agent_id: str) -> AgentGraph:
    """Get the AgentGraph for an agent."""
    repo = get_agent_repo()
    agent = repo.get(agent_id)
    if not agent:
        raise HTTPException(status_code=404, detail="Agent not found")
    try:
        result = repo.load_graph(agent)
        if isinstance(result, Path):
            return get_importer_registry().import_agent(result)
        return result
    except FileNotFoundError as e:
        raise HTTPException(status_code=404, detail=str(e)) from None


@router.post("/agents")
async def create_agent(request: CreateAgentRequest) -> dict:
    """Create an agent from config dict or file path."""
    if not request.config and not request.path:
        raise HTTPException(status_code=400, detail="Either config or path is required")

    # Validate and resolve path before attempting import
    absolute_path: str | None = None
    if request.path:
        path = Path(request.path)
        if not path.exists():
            raise HTTPException(status_code=400, detail=f"File not found: {request.path}")
        if not path.is_file():
            raise HTTPException(status_code=400, detail=f"Path is not a file: {request.path}")
        try:
            path.read_text()
        except PermissionError:
            raise HTTPException(
                status_code=400, detail=f"Permission denied: {request.path}"
            ) from None
        # Convert to absolute path for storage
        absolute_path = str(path.resolve())

    try:
        source = absolute_path if absolute_path else request.config
        graph = await api.import_agent(source, source=request.source)
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e)) from None
    except FileNotFoundError:
        raise HTTPException(status_code=400, detail=f"File not found: {request.path}") from None
    except json.JSONDecodeError as e:
        raise HTTPException(status_code=400, detail=f"Invalid JSON: {e}") from None
    except PermissionError:
        raise HTTPException(status_code=400, detail=f"Permission denied: {request.path}") from None

    repo = get_agent_repo()
    return repo.create(
        name=request.name,
        source_type=graph.source_type,
        source_path=absolute_path,
        graph_json=graph.model_dump_json(),
    )


@router.post("/agents/upload")
async def create_agent_from_file(
    file: UploadFile,
    name: str | None = None,
    source: str | None = None,
) -> dict:
    """Create an agent from an uploaded file (XLSForm, JSON, etc.)."""
    if not file.filename:
        raise HTTPException(status_code=400, detail="No filename provided")

    agent_name = name or Path(file.filename).stem
    suffix = Path(file.filename).suffix

    try:
        with tempfile.NamedTemporaryFile(suffix=suffix, delete=False) as tmp:
            content = await file.read()
            tmp.write(content)
            tmp_path = tmp.name

        try:
            graph = await api.import_agent(tmp_path, source=source)
        finally:
            Path(tmp_path).unlink(missing_ok=True)
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e)) from None

    repo = get_agent_repo()
    return repo.create(
        name=agent_name,
        source_type=graph.source_type,
        graph_json=graph.model_dump_json(),
    )


@router.put("/agents/{agent_id}")
async def update_agent(agent_id: str, request: UpdateAgentRequest) -> dict:
    """Update an agent."""
    repo = get_agent_repo()
    agent = repo.get(agent_id)
    if not agent:
        raise HTTPException(status_code=404, detail="Agent not found")

    graph_json = request.graph_json
    if graph_json is None and request.default_model is not None and agent.get("graph_json"):
        # Update default_model in existing stored graph
        graph_data = json.loads(agent["graph_json"])
        graph_data["default_model"] = request.default_model if request.default_model else None
        graph_json = json.dumps(graph_data)

    return repo.update(agent_id, name=request.name, graph_json=graph_json)


@router.delete("/agents/{agent_id}")
async def delete_agent(agent_id: str) -> dict:
    """Delete an agent."""
    repo = get_agent_repo()
    agent = repo.get(agent_id)
    if not agent:
        raise HTTPException(status_code=404, detail="Agent not found")

    repo.delete(agent_id)
    return {"status": "deleted", "id": agent_id}


@router.get("/agents/{agent_id}/metrics-config")
async def get_metrics_config(agent_id: str) -> dict:
    """Get an agent's metrics configuration."""
    repo = get_agent_repo()
    agent = repo.get(agent_id)
    if not agent:
        raise HTTPException(status_code=404, detail="Agent not found")

    config = repo.get_metrics_config(agent_id)
    return config.model_dump()


@router.put("/agents/{agent_id}/metrics-config")
async def update_metrics_config(agent_id: str, request: UpdateMetricsConfigRequest) -> dict:
    """Update an agent's metrics configuration."""
    repo = get_agent_repo()
    agent = repo.get(agent_id)
    if not agent:
        raise HTTPException(status_code=404, detail="Agent not found")

    config = MetricsConfig(
        threshold=request.threshold,
        global_metrics=request.global_metrics,
    )
    repo.update_metrics_config(agent_id, config)
    return config.model_dump()


@router.get("/agents/{agent_id}/tests")
async def list_tests_for_agent(agent_id: str) -> list[dict]:
    """List all test cases for an agent."""
    return get_test_case_repo().list_for_agent(agent_id)


@router.post("/agents/{agent_id}/tests/export")
async def export_tests_for_agent(agent_id: str, request: ExportTestsRequest) -> list[dict]:
    """Export test cases for an agent to a specified format."""
    repo = get_test_case_repo()

    if request.test_ids:
        records = [repo.get(tid) for tid in request.test_ids if repo.get(tid)]
    else:
        records = repo.list_for_agent(agent_id)

    if not records:
        return []

    test_cases = [repo.to_model(r) for r in records]

    try:
        return export_tests(test_cases, request.format)
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e)) from None


@router.post("/agents/{agent_id}/tests")
async def create_test_case(agent_id: str, request: CreateTestCaseRequest) -> dict:
    """Create a test case for an agent."""
    test_case = TestCase(
        name=request.name,
        user_prompt=request.user_prompt,
        metrics=request.metrics,
        dynamic_variables=request.dynamic_variables,
        tool_mocks=request.tool_mocks,
        type=request.type,
        llm_model=request.llm_model,
        includes=request.includes,
        excludes=request.excludes,
        patterns=request.patterns,
    )
    return get_test_case_repo().create(agent_id, test_case)


@router.put("/tests/{test_id}")
async def update_test_case(test_id: str, request: CreateTestCaseRequest) -> dict:
    """Update a test case."""
    repo = get_test_case_repo()
    test = repo.get(test_id)
    if not test:
        raise HTTPException(status_code=404, detail="Test case not found")

    test_case = TestCase(
        name=request.name,
        user_prompt=request.user_prompt,
        metrics=request.metrics,
        dynamic_variables=request.dynamic_variables,
        tool_mocks=request.tool_mocks,
        type=request.type,
        llm_model=request.llm_model,
        includes=request.includes,
        excludes=request.excludes,
        patterns=request.patterns,
    )
    return repo.update(test_id, test_case)


@router.delete("/tests/{test_id}")
async def delete_test_case(test_id: str) -> dict:
    """Delete a test case."""
    repo = get_test_case_repo()
    test = repo.get(test_id)
    if not test:
        raise HTTPException(status_code=404, detail="Test case not found")

    repo.delete(test_id)
    return {"status": "deleted", "id": test_id}


class LoadDemoResponse(BaseModel):
    """Response from loading demo data."""

    agent_id: str
    agent_name: str
    test_count: int
    created: bool


@router.post("/demo", response_model=LoadDemoResponse)
async def load_demo() -> LoadDemoResponse:
    """Load demo agent and tests into the database.

    If the demo agent already exists, returns its info without creating duplicates.
    """
    demo_agent_config = get_demo_agent()
    demo_tests = get_demo_tests()

    graph = await api.import_agent(demo_agent_config)

    agent_repo = get_agent_repo()
    test_repo = get_test_case_repo()

    existing = agent_repo.list_all()
    demo_agent = next((a for a in existing if a.get("name") == "Demo Healthcare Agent"), None)

    if demo_agent:
        test_count = len(test_repo.list_for_agent(demo_agent["id"]))
        return LoadDemoResponse(
            agent_id=demo_agent["id"],
            agent_name=demo_agent["name"],
            test_count=test_count,
            created=False,
        )

    agent = agent_repo.create(
        name="Demo Healthcare Agent",
        source_type=graph.source_type,
        graph_json=graph.model_dump_json(),
    )

    for test_data in demo_tests:
        test_case = TestCase(**test_data)
        test_repo.create(agent["id"], test_case)

    return LoadDemoResponse(
        agent_id=agent["id"],
        agent_name=agent["name"],
        test_count=len(demo_tests),
        created=True,
    )


@router.get("/gallery")
async def list_gallery() -> list[dict]:
    """List available test gallery fixtures."""
    gallery_dir = Path(__file__).parent / "fixtures" / "test_gallery"
    if not gallery_dir.exists():
        return []

    fixtures = []
    for file in gallery_dir.glob("*.json"):
        try:
            data = json.loads(file.read_text())
            fixtures.append(
                {
                    "id": file.stem,
                    "name": data.get("name", file.stem),
                    "description": data.get("description", ""),
                    "tests": data.get("tests", []),
                }
            )
        except (json.JSONDecodeError, KeyError):
            continue

    return fixtures


@router.get("/agents/{agent_id}/runs")
async def list_runs_for_agent(agent_id: str, limit: int = 50) -> list[dict]:
    """List all runs for an agent."""
    return get_run_repo().list_for_agent(agent_id, limit)


@router.get("/runs/{run_id}")
async def get_run(run_id: str) -> dict:
    """Get a run with all results."""
    run_repo = get_run_repo()
    run = run_repo.get_with_results(run_id)
    if not run:
        raise HTTPException(status_code=404, detail="Run not found")

    # Detect orphaned run: not completed but not actively running
    if run["completed_at"] is None and run_id not in _active_runs:
        run_repo.complete(run_id)
        run["completed_at"] = datetime.now(UTC).isoformat()

    # Fix inconsistent state: run complete but results still "running"
    if run["completed_at"] is not None:
        for result in run["results"]:
            if result["status"] == "running":
                run_repo.mark_result_error(result["id"], "Run orphaned - backend stopped")
                result["status"] = "error"
                result["error_message"] = "Run orphaned - backend stopped"

    return run


@router.delete("/runs/{run_id}")
async def delete_run(run_id: str) -> dict:
    """Delete a run and all its results."""
    run_repo = get_run_repo()
    run = run_repo.get_with_results(run_id)
    if not run:
        raise HTTPException(status_code=404, detail="Run not found")

    # Don't allow deleting active runs
    if run_id in _active_runs:
        raise HTTPException(status_code=400, detail="Cannot delete an active run")

    run_repo.delete(run_id)
    return {"status": "deleted", "id": run_id}


async def _broadcast_run_update(run_id: str, data: dict) -> None:
    """Broadcast update to all WebSocket clients watching this run."""
    if run_id not in _active_runs:
        return
    message = json.dumps(data)
    websockets = _active_runs[run_id]["websockets"]
    if not websockets:
        # Queue message for replay when WebSocket connects
        _active_runs[run_id]["message_queue"].append(message)
        return
    dead_sockets = []
    for ws in websockets:
        try:
            await ws.send_text(message)
        except Exception:
            dead_sockets.append(ws)
    for ws in dead_sockets:
        _active_runs[run_id]["websockets"].discard(ws)


def _is_run_cancelled(run_id: str, result_id: str | None = None) -> bool:
    """Check if run or specific test is cancelled."""
    if run_id not in _active_runs:
        return False
    cancelled = _active_runs[run_id].get("cancelled_tests", set())
    if result_id and result_id in cancelled:
        return True
    return _active_runs[run_id]["cancel"].is_set()


async def _execute_run(
    run_id: str,
    agent_id: str,
    test_records: list[dict],
    result_ids: dict[str, str],
    options: RunOptions,
) -> None:
    """Execute tests for a run in the background."""
    # _active_runs[run_id] is set up in start_run() before this task starts

    agent_repo = get_agent_repo()
    test_case_repo = get_test_case_repo()
    run_repo = get_run_repo()

    agent = agent_repo.get(agent_id)
    if not agent:
        return

    try:
        result = agent_repo.load_graph(agent)
        graph = get_importer_registry().import_agent(result) if isinstance(result, Path) else result
    except (FileNotFoundError, ValueError):
        return

    # Load metrics config for global metrics
    metrics_config = agent_repo.get_metrics_config(agent_id)

    try:
        for test_record in test_records:
            # Get pre-created result ID
            result_id = result_ids[test_record["id"]]

            # Check if this specific test was cancelled before it started
            if run_id in _active_runs and result_id in _active_runs[run_id]["cancelled_tests"]:
                run_repo.mark_result_cancelled(result_id)
                await _broadcast_run_update(
                    run_id,
                    {"type": "test_cancelled", "result_id": result_id},
                )
                continue

            # Check if entire run is cancelled
            if _is_run_cancelled(run_id):
                # Mark ALL remaining tests (including current) as cancelled
                remaining_idx = test_records.index(test_record)
                for remaining_record in test_records[remaining_idx:]:
                    remaining_result_id = result_ids[remaining_record["id"]]
                    run_repo.mark_result_cancelled(remaining_result_id)
                    await _broadcast_run_update(
                        run_id,
                        {"type": "test_cancelled", "result_id": remaining_result_id},
                    )
                break

            test_case = test_case_repo.to_model(test_record)

            # Broadcast that test is now actively running
            await _broadcast_run_update(
                run_id,
                {
                    "type": "test_started",
                    "result_id": result_id,
                    "test_case_id": test_record["id"],
                    "test_name": test_case.name,
                },
            )

            async def make_on_turn(rid: str, transcript_ref: list[Message]):
                async def on_turn(transcript: list) -> None:
                    nonlocal transcript_ref
                    # Check for cancellation
                    if _is_run_cancelled(run_id, rid):
                        raise asyncio.CancelledError("Test cancelled by user")
                    # Track transcript for error recovery
                    transcript_ref.clear()
                    transcript_ref.extend(transcript)
                    run_repo.update_transcript(rid, transcript)
                    await _broadcast_run_update(
                        run_id,
                        {
                            "type": "transcript_update",
                            "result_id": rid,
                            "transcript": [m.model_dump() for m in transcript],
                        },
                    )

                return on_turn

            def make_on_token(rid: str):
                async def on_token(token: str, source: str) -> None:
                    await _broadcast_run_update(
                        run_id,
                        {
                            "type": "token_update",
                            "result_id": rid,
                            "token": token,
                            "source": source,
                        },
                    )

                return on_token

            def make_on_error(rid: str):
                async def on_error(error: RetryError) -> None:
                    await _broadcast_run_update(
                        run_id,
                        {
                            "type": "retry_error",
                            "result_id": rid,
                            "error_type": error.error_type,
                            "message": error.message,
                            "attempt": error.attempt,
                            "max_attempts": error.max_attempts,
                            "retry_after": error.retry_after,
                        },
                    )

                return on_error

            # Track transcript for error cases
            last_transcript: list[Message] = []

            try:
                result = await api.run_test(
                    graph,
                    test_case,
                    options=options,
                    metrics_config=metrics_config,
                    on_turn=await make_on_turn(result_id, last_transcript),
                    on_token=make_on_token(result_id) if options.streaming else None,
                    on_error=make_on_error(result_id),
                )
                run_repo.complete_result(result_id, result)
                await _broadcast_run_update(
                    run_id,
                    {
                        "type": "test_completed",
                        "result_id": result_id,
                        "status": result.status,
                    },
                )
            except asyncio.CancelledError:
                cancelled_result = TestResult(
                    test_name=test_case.name,
                    status="error",
                    transcript=last_transcript,
                    error_message="Cancelled by user",
                )
                run_repo.complete_result(result_id, cancelled_result)
                await _broadcast_run_update(
                    run_id,
                    {
                        "type": "test_cancelled",
                        "result_id": result_id,
                    },
                )
            except Exception as e:
                error_result = TestResult(
                    test_name=test_case.name,
                    status="error",
                    transcript=last_transcript,
                    error_message=str(e),
                )
                run_repo.complete_result(result_id, error_result)
                await _broadcast_run_update(
                    run_id,
                    {
                        "type": "test_error",
                        "result_id": result_id,
                        "error": str(e),
                    },
                )

        run_repo.complete(run_id)
        await _broadcast_run_update(run_id, {"type": "run_completed"})
    finally:
        # Clean up after a delay to allow final messages
        await asyncio.sleep(1)
        _active_runs.pop(run_id, None)


@router.websocket("/runs/{run_id}/ws")
async def run_websocket(websocket: WebSocket, run_id: str):
    """WebSocket for streaming run updates and receiving cancel commands."""
    try:
        await websocket.accept()
    except Exception as e:
        print(f"[WS] Failed to accept connection for run {run_id}: {e}")
        return

    # Send current state BEFORE registering for broadcasts to avoid race condition
    # where test_started arrives before state and then state overwrites it
    try:
        run = get_run_repo().get_with_results(run_id)
        if not run:
            # Run not found - send error and close
            await websocket.send_json({"type": "error", "message": "Run not found"})
            await websocket.close(code=1008)  # Policy violation
            return
        msg = json.dumps({"type": "state", "run": run})
        await websocket.send_text(msg)

        # If run is already complete (not in _active_runs), send run_completed and close
        if run.get("completed_at") and run_id not in _active_runs:
            await websocket.send_json({"type": "run_completed"})
            await websocket.close(code=1000)  # Normal closure
            return

    except WebSocketDisconnect:
        print(f"[WS] Client disconnected during state send for run {run_id}")
        return
    except Exception as e:
        print(f"[WS] Error sending state for run {run_id}: {type(e).__name__}: {e}")
        try:
            if websocket.client_state == WebSocketState.CONNECTED:
                await websocket.close(code=1011)  # Unexpected condition
        except Exception:
            pass
        return

    # Now register this WebSocket and get any queued messages
    queued_messages = []
    if run_id in _active_runs:
        _active_runs[run_id]["websockets"].add(websocket)
        queued_messages = _active_runs[run_id]["message_queue"]
        _active_runs[run_id]["message_queue"] = []

    try:
        # Replay any messages that were queued before connection
        for msg in queued_messages:
            await websocket.send_text(msg)

        # Listen for commands
        while True:
            data = await websocket.receive_json()
            if data.get("type") == "cancel_test" and run_id in _active_runs:
                result_id = data.get("result_id")
                if result_id:
                    _active_runs[run_id]["cancelled_tests"].add(result_id)
            elif data.get("type") == "cancel_run" and run_id in _active_runs:
                _active_runs[run_id]["cancel"].set()
    except WebSocketDisconnect:
        # Normal disconnect - client closed connection
        pass
    except Exception as e:
        print(f"[WS] Exception in websocket handler for run {run_id}: {type(e).__name__}: {e}")
    finally:
        if run_id in _active_runs:
            _active_runs[run_id]["websockets"].discard(websocket)


class BackgroundTaskExecutor:
    """Default executor using FastAPI BackgroundTasks."""

    def __init__(self, background_tasks: BackgroundTasks):
        self.background_tasks = background_tasks

    def submit(self, job: RunJob) -> None:
        """Submit job to run in background."""
        self.background_tasks.add_task(
            _execute_run,
            job.run_id,
            job.agent_id,
            job.test_records,
            job.result_ids,
            job.options,
        )


@router.post("/agents/{agent_id}/runs")
async def start_run(
    agent_id: str,
    request: StartRunRequest,
    background_tasks: BackgroundTasks,
) -> dict:
    """Start a new test run. Tests execute in background, poll GET /runs/{id} for results."""
    agent_repo = get_agent_repo()
    agent = agent_repo.get(agent_id)
    if not agent:
        raise HTTPException(status_code=404, detail="Agent not found")

    test_case_repo = get_test_case_repo()
    if request.test_ids:
        test_records = [
            test_case_repo.get(tid) for tid in request.test_ids if test_case_repo.get(tid)
        ]
    else:
        test_records = test_case_repo.list_for_agent(agent_id)

    if not test_records:
        raise HTTPException(status_code=400, detail="No test cases to run")

    run_repo = get_run_repo()
    run = run_repo.create(agent_id)

    # Create all pending results upfront so they appear immediately in UI
    # Map test_case_id -> result_id for the background task to use
    result_ids: dict[str, str] = {}
    for test_record in test_records:
        result_id = run_repo.create_pending_result(
            run["id"], test_record["id"], test_record["name"]
        )
        result_ids[test_record["id"]] = result_id

    settings = load_settings()
    settings.apply_env()
    options = _build_run_options(settings, request.options)

    # Set up active run tracking BEFORE background task starts
    # so WebSocket connections can register immediately
    _active_runs[run["id"]] = {
        "cancel": asyncio.Event(),
        "websockets": set(),
        "cancelled_tests": set(),
        "message_queue": [],
    }

    # Create job and submit to executor
    job = RunJob(
        run_id=run["id"],
        agent_id=agent_id,
        test_records=test_records,
        result_ids=result_ids,
        options=options,
    )

    # Use custom executor if configured, otherwise default to BackgroundTasks
    executor_factory = get_executor_factory()
    if executor_factory:
        executor = executor_factory()
        executor.submit(job)
    else:
        executor = BackgroundTaskExecutor(background_tasks)
        executor.submit(job)

    return {
        "id": run["id"],
        "agent_id": agent_id,
        "started_at": run["started_at"],
        "test_count": len(test_records),
    }


# Platform integration endpoints


def _get_platform_registry():
    """Get the platform registry from the DI container."""
    return get_container().resolve(PlatformRegistry)


def _validate_platform(platform: str) -> None:
    """Validate platform name using registry."""
    registry = _get_platform_registry()
    if not registry.has_platform(platform):
        raise HTTPException(status_code=400, detail=f"Invalid platform: {platform}")


def _is_platform_configured(platform: str) -> bool:
    """Check if a platform is configured using registry."""
    registry = _get_platform_registry()
    settings = load_settings()
    return registry.is_configured(platform, settings)


def _get_platform_api_key(platform: str) -> str | None:
    """Get API key for a platform using registry."""
    registry = _get_platform_registry()
    settings = load_settings()
    return registry.get_api_key(platform, settings)


def _get_configured_platform_client(platform: str) -> tuple[Any, Any]:
    """Get validated, configured platform client and SDK client.

    Args:
        platform: Platform identifier.

    Returns:
        Tuple of (PlatformClient, SDK client).

    Raises:
        HTTPException: If platform invalid or not configured.
    """
    _validate_platform(platform)
    if not _is_platform_configured(platform):
        raise HTTPException(status_code=400, detail=f"{platform} API key not configured")
    api_key = _get_platform_api_key(platform)
    registry = _get_platform_registry()
    platform_client = registry.get(platform)
    client = platform_client.get_client(api_key)
    return platform_client, client


@router.get("/platforms", response_model=list[PlatformInfo])
async def list_platforms() -> list[PlatformInfo]:
    """List all available platforms and their configuration status."""
    registry = _get_platform_registry()
    settings = load_settings()
    platforms = []
    for platform_name in registry.list_platforms():
        platforms.append(
            PlatformInfo(
                name=platform_name,
                configured=registry.is_configured(platform_name, settings),
                env_key=registry.get_env_key(platform_name),
                required_env_keys=registry.get_required_env_keys(platform_name),
            )
        )
    return platforms


@router.get("/platforms/{platform}/status", response_model=PlatformStatusResponse)
async def get_platform_status(platform: str) -> PlatformStatusResponse:
    """Check if a platform API key is configured."""
    _validate_platform(platform)
    return PlatformStatusResponse(
        configured=_is_platform_configured(platform),
        platform=platform,
    )


@router.post("/platforms/{platform}/configure", response_model=PlatformStatusResponse)
async def configure_platform(
    platform: str, request: ConfigurePlatformRequest
) -> PlatformStatusResponse:
    """Configure platform credentials. Returns 409 if already configured."""
    _validate_platform(platform)

    if _is_platform_configured(platform):
        raise HTTPException(
            status_code=409,
            detail=f"{platform} credentials are already configured. Use Settings to change them.",
        )

    registry = _get_platform_registry()
    required_keys = registry.get_required_env_keys(platform)
    settings = load_settings()

    # Set the primary API key
    env_key = registry.get_env_key(platform)
    settings.env[env_key] = request.api_key

    # Set the API secret if provided and required
    if request.api_secret and len(required_keys) > 1:
        # Find the secret key (usually ends with _SECRET)
        secret_keys = [k for k in required_keys if k.endswith("_SECRET")]
        if secret_keys:
            settings.env[secret_keys[0]] = request.api_secret

    save_settings(settings)
    settings.apply_env()

    return PlatformStatusResponse(configured=True, platform=platform)


@router.get("/platforms/{platform}/agents", response_model=list[RemoteAgentInfo])
async def list_platform_agents(platform: str) -> list[RemoteAgentInfo]:
    """List agents from any supported platform."""
    platform_client, client = _get_configured_platform_client(platform)

    try:
        agents = platform_client.list_agents(client)
        return [RemoteAgentInfo(**a) for a in agents]
    except Exception as e:
        raise HTTPException(
            status_code=500, detail=f"Failed to list {platform} agents: {e}"
        ) from None


@router.post("/platforms/{platform}/agents/{agent_id}/import", response_model=AgentGraph)
async def import_platform_agent(platform: str, agent_id: str) -> AgentGraph:
    """Import an agent from any supported platform by ID."""
    platform_client, client = _get_configured_platform_client(platform)

    try:
        registry = _get_platform_registry()
        config = platform_client.get_agent(client, agent_id)
        importer = registry.get_importer(platform)
        if not importer:
            raise ValueError(f"No importer for platform: {platform}")
        return importer.import_agent(config)
    except Exception as e:
        raise HTTPException(
            status_code=500, detail=f"Failed to import {platform} agent: {e}"
        ) from None


@router.post("/platforms/{platform}/export", response_model=ExportToPlatformResponse)
async def export_to_platform(
    platform: str, request: ExportToPlatformRequest
) -> ExportToPlatformResponse:
    """Export an agent graph to any supported platform."""
    platform_client, client = _get_configured_platform_client(platform)

    try:
        registry = _get_platform_registry()
        exporter = registry.get_exporter(platform)
        if not exporter:
            raise ValueError(f"No exporter for platform: {platform}")
        config = exporter(request.graph)

        result = platform_client.create_agent(client, config, request.name)
        return ExportToPlatformResponse(
            id=result["id"],
            name=result["name"],
            platform=platform,
        )
    except Exception as e:
        raise HTTPException(
            status_code=500, detail=f"Failed to export to {platform}: {e}"
        ) from None


@router.get("/agents/{agent_id}/sync-status", response_model=SyncStatusResponse)
async def get_sync_status(agent_id: str) -> SyncStatusResponse:
    """Check if an agent can be synced to its source platform."""
    repo = get_agent_repo()
    agent = repo.get(agent_id)
    if not agent:
        raise HTTPException(status_code=404, detail="Agent not found")

    try:
        result = repo.load_graph(agent)
        graph = get_importer_registry().import_agent(result) if isinstance(result, Path) else result
    except (FileNotFoundError, ValueError):
        return SyncStatusResponse(
            can_sync=False,
            reason="Agent graph not available",
        )

    source_metadata = graph.source_metadata or {}
    source_type = graph.source_type

    registry = _get_platform_registry()
    if not registry.has_platform(source_type):
        return SyncStatusResponse(
            can_sync=False,
            reason=f"Source '{source_type}' is not a supported platform",
        )

    if not registry.supports_update(source_type):
        return SyncStatusResponse(
            can_sync=False,
            reason=f"{source_type} does not support syncing",
            platform=source_type,
        )

    remote_id_key = registry.get_remote_id_key(source_type)
    if not remote_id_key:
        return SyncStatusResponse(
            can_sync=False,
            reason=f"{source_type} does not track remote IDs",
            platform=source_type,
        )

    remote_id = source_metadata.get(remote_id_key)
    if not remote_id:
        return SyncStatusResponse(
            can_sync=False,
            reason=f"No remote ID found (missing {remote_id_key} in source_metadata)",
            platform=source_type,
        )

    if not _is_platform_configured(source_type):
        return SyncStatusResponse(
            can_sync=False,
            reason=f"{source_type} API key not configured",
            platform=source_type,
            remote_id=remote_id,
            needs_configuration=True,
        )

    return SyncStatusResponse(
        can_sync=True,
        platform=source_type,
        remote_id=remote_id,
    )


@router.post("/agents/{agent_id}/sync", response_model=SyncToPlatformResponse)
async def sync_to_platform(agent_id: str, request: SyncToPlatformRequest) -> SyncToPlatformResponse:
    """Sync an agent to its source platform."""
    repo = get_agent_repo()
    agent = repo.get(agent_id)
    if not agent:
        raise HTTPException(status_code=404, detail="Agent not found")

    graph = request.graph
    source_metadata = graph.source_metadata or {}
    source_type = graph.source_type

    registry = _get_platform_registry()
    if not registry.has_platform(source_type):
        raise HTTPException(
            status_code=400, detail=f"Source '{source_type}' is not a supported platform"
        )

    if not registry.supports_update(source_type):
        raise HTTPException(status_code=400, detail=f"{source_type} does not support syncing")

    remote_id_key = registry.get_remote_id_key(source_type)
    if not remote_id_key:
        raise HTTPException(status_code=400, detail=f"{source_type} does not track remote IDs")

    remote_id = source_metadata.get(remote_id_key)
    if not remote_id:
        raise HTTPException(
            status_code=400,
            detail=f"No remote ID found (missing {remote_id_key} in source_metadata)",
        )

    platform_client, client = _get_configured_platform_client(source_type)

    try:
        exporter = registry.get_exporter(source_type)
        if not exporter:
            raise ValueError(f"No exporter for platform: {source_type}")
        config = exporter(graph)

        result = platform_client.update_agent(client, remote_id, config)
        return SyncToPlatformResponse(
            id=result["id"],
            name=result["name"],
            platform=source_type,
            synced=True,
        )
    except Exception as e:
        raise HTTPException(
            status_code=500, detail=f"Failed to sync to {source_type}: {e}"
        ) from None


def create_app() -> FastAPI:
    """Create the FastAPI app (for programmatic use)."""
    return app


# Include API router
app.include_router(router)

# SPA static file serving (must be after API routes)
if WEB_DIST is not None:
    app.mount("/assets", StaticFiles(directory=WEB_DIST / "assets"), name="static")

    @app.get("/{path:path}")
    async def serve_spa(path: str) -> FileResponse:
        """Serve the SPA for all non-API routes."""
        if WEB_DIST is None:
            raise HTTPException(status_code=404, detail="Web UI not found")
        file_path = WEB_DIST / path
        if file_path.is_file():
            return FileResponse(file_path)
        return FileResponse(WEB_DIST / "index.html")
