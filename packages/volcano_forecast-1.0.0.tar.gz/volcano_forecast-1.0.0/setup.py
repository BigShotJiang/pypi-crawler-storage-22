from setuptools import setup, find_packages
import os

# قراءة README.md
with open('README.md', 'r', encoding='utf-8') as f:
    long_description = f.read()

# البحث عن الحزم في src
package_dir = {}
packages = []

if os.path.exists('src'):
    package_dir = {'': 'src'}
    packages = find_packages(where='src')
else:
    # إذا لم يكن هناك src، ابحث في المجلد الحالي
    packages = find_packages()

setup(
    name="volcano-forecast",
    version="1.0.0",
    author="Samir Baladi",
    author_email="gitdeeper@gmail.com",
    description="Multi-parameter volcanic unrest monitoring and eruption forecasting framework",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://gitlab.com/gitdeeper3/volcano",
    package_dir=package_dir,
    packages=packages,
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Science/Research",
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 3",
    ],
    python_requires=">=3.8",
    install_requires=[
        "numpy>=1.21.0",
        "scipy>=1.7.0",
        "pandas>=1.3.0",
        "matplotlib>=3.4.0",
    ],
)
