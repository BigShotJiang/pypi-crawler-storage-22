"""
Tests for validation.
"""

def test_example():
    """Example test."""
    assert True

if __name__ == "__main__":
    test_example()
    print("All tests passed!")
