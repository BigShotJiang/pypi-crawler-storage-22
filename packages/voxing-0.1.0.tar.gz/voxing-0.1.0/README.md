# Voxing
TUI for local voice / text assistant on macos

## Testing

Run the test suite:
```bash
uv run pytest
```

Update visual snapshots after UI changes:
```bash
uv run pytest --snapshot-update
```

TODO:
- Ability to run via `uvx voxing`?
