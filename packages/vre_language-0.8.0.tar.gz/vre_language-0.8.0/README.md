# What does "VRE language" mean?

This is a [Domain-Specific Language (DSL)](https://en.wikipedia.org/wiki/Domain-specific_language) to be used in a [Virtual Research Environment](https://en.wikipedia.org/wiki/Virtual_research_environment). It is a computer language using domain-specific notations and abstractions rather than such commonly used in general purpose languages such as Python. For example, in our DSL there are no for-loops and classes (that are used in Python) and no workflows and workflow node objects (used in workflow DSLs). But we have objects such as atoms and molecules and semantics to perform specific operations on these.

# Requirements

## Domain concepts

The DSL totally depends on how we define our domain. In this VRE language, we define our domain as *materials modelling* domain that is a subdomain of *scientific computing* and has subdomains such as *atomistic modeling* and *molecular modeling*. Particularly, support of physical units by the language is a common concept for all these domains. Nevertheless, these domains can still be defined in different ways. Therefore, we base *our domain definition* on a set of use cases. For an example use case, look at [this repository](https://gitlab.kit.edu/kit/virtmat-tools/oxycat-use-case). You are welcome to contribute with further uses cases and extend the VRE language.

## Requirements from the community and the target platform

Apart from the domain-specific notations, our VRE language has to satisfy further requirements.

### Full life cycle of modeling, simulation and data analysis

A model should be accessible and extensible dynamically, at any time. This is what we call *persistence* and *dynamics* of the model. To satisfy this requirement, we connect the interpreter to a workflow management system equipped with a database.

### Jupyter front-end system

This poses a challenge for models with persistence and on the other hand a new [Jupyter](https://jupyter.org/) kernel with the VRE language interpreter had to be developed. Currently, VRE Language includes a full fledged Jupyter kernel that can be used in Jupyter Console, Jupyter Notebook and Jupyter Lab.

### Transparent workflow management system and workload management system

This is not obvious and also not trivial to implement. Particularly, notations in the program code about the granularity (which statements belong to the same workflow node) and the computing resources needed (such as computing time, number of CPUs, memory, disk space, ...) are necessary for computational performance or other practical reasons but difficult to hide completely from the language. Currently, the workflow management system [FireWorks](https://materialsproject.github.io/fireworks/) and workload management system [Slurm](https://slurm.schedmd.com/) are supported.

### Python as interpreter language

This requirement is due to the fact that a plenty of libraries (APIs) for Python in the domain already exist: the [Atomic Simulation Environment (ASE)](https://wiki.fysik.dtu.dk/ase/), [Python Materials Genomics (Pymatgen)](https://pymatgen.org/) and [PyIron](https://pyiron.org/), to name only a few. These libraries cover the most relevant aspects of their domains but still are used in the general-purpose language Python. The use of Python implies in turn that a workflow management system and system of physical units providing Python APIs are required.

# History

Originally this package has been developed in a [VirtMat project](https://www.materials.kit.edu/virtmat_current_projects.php).

# Development status

The current developement status of the VRE language is *beta*. If you detect bugs or suggest missing features, you can file an [issue](https://gitlab.kit.edu/kit/virtmat-tools/vre-language/-/issues).

If you want to use workflows for modeling and data analysis using Python in Jupyter you can use [VRE middleware](https://gitlab.kit.edu/kit/virtmat-tools/vre-middleware) (currently in *beta* state).

# Documentation

An installation guide and comprehensive documentation is provided on [these pages](https://vre-language.readthedocs.io).

# Support

If you need support or have any questions about VRE Language please write a message to virtmat-tools@lists.kit.edu.

# Citing the VRE Language package

If you find the VRE Language package useful in your research please cite:

> Ivan Kondov, Rodrigo Cortés Mejía, Marvin Müller, Nikolai Pfisterer, Sruthy Sreenivasan  
Domain Specific Language for Materials Modeling  
M. Paszynski et al. (Eds.): International Conference on Computational Science (ICCS) 2025 Workshops, LNCS 15909, pp. 1–16, 2025.  
https://doi.org/10.1007/978-3-031-97564-6_18

# Contributing

You are welcome to contribute to VRE Language. More details can be found [here](CONTRIBUTING.md).
