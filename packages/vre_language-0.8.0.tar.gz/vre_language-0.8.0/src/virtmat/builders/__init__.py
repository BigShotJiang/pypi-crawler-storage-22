"""
A collection of structure builders based on ASE
"""
import pandas
from virtmat.language.utilities.amml import AMMLStructure
from virtmat.language.utilities.ase_params import spec, check_params_mandatory
from virtmat.language.utilities.ase_params import check_params_invalid, check_params_types
from virtmat.language.utilities.ase_params import check_params_units, check_params_values
from virtmat.language.utilities.ase_params import get_params_magnitudes


BUILDERS = [k for k, v in spec.items() if v.get('otype') == 'builder']
TOOLS1 = [k for k, v in spec.items() if v.get('otype') == 'build tool']
TOOLS2 = [k for k, v in spec.items() if v.get('otype') == 'build tool 2']
TOOLS = TOOLS1 + TOOLS2


def _factory(fname, otype):
    mod = __import__(spec[fname]['module'], {}, None, [spec[fname]['class']])
    func = getattr(mod, spec[fname]['class'])

    def check_params(tab):
        check_params_mandatory(fname, tab)
        check_params_invalid(fname, tab)
        check_params_types(fname, tab)
        check_params_units(fname, tab)
        check_params_values(fname, tab)

    def builder_wrapper(tab: pandas.DataFrame = None, name: str = None) -> AMMLStructure:
        name = name or fname
        if tab is None:
            check_params_mandatory(fname, pandas.DataFrame())
            return AMMLStructure.from_ase(func(), name=name)
        check_params(tab)
        atoms_list = []
        for _, row in tab.iterrows():
            atoms_list.append(func(**get_params_magnitudes(dict(row), fname)))
        return AMMLStructure.from_ase(atoms_list, name=name)

    def tool_wrapper(struct: AMMLStructure, tab: pandas.DataFrame = None) -> AMMLStructure:
        if tab is None:
            check_params_mandatory(fname, pandas.DataFrame())
            atoms_list = [func(a) for a in struct.to_ase()]
            return AMMLStructure.from_ase(atoms_list, name=struct.name)
        check_params(tab)
        params_list = [get_params_magnitudes(dict(r), fname) for _, r in tab.iterrows()]
        atoms_list = []
        for atoms in struct.to_ase():
            for dct in params_list:
                atoms_list.append(func(atoms, **dct))
        return AMMLStructure.from_ase(atoms_list, name=struct.name)

    def tool2_wrapper(struct1: AMMLStructure, struct2: AMMLStructure,
                      tab: pandas.DataFrame = None) -> AMMLStructure:
        if tab is None:
            check_params_mandatory(fname, pandas.DataFrame())
            atoms_list = [func(a1, a2) for a2 in struct2.to_ase() for a1 in struct1.to_ase()]
            return AMMLStructure.from_ase(atoms_list, name=struct1.name)
        check_params(tab)
        params_list = [get_params_magnitudes(dict(r), fname) for _, r in tab.iterrows()]
        atoms_list = []
        for atoms1 in struct1.to_ase():
            for atoms2 in struct2.to_ase():
                for dct in params_list:
                    atoms_list.append(func(atoms1, atoms2, **dct))
        return AMMLStructure.from_ase(atoms_list, name=struct1.name)

    wrappers = {'builder': builder_wrapper, 'build tool': tool_wrapper,
                'build tool 2': tool2_wrapper}
    wrapper = wrappers[otype]
    setattr(wrapper, '__name__', fname)
    setattr(wrapper, '__qualname__', fname)
    setattr(wrapper, '__module__', __name__)
    return wrapper


for _func_name in BUILDERS:
    globals()[_func_name] = _factory(_func_name, otype='builder')

for _func_name in TOOLS1:
    globals()[_func_name] = _factory(_func_name, otype='build tool')

for _func_name in TOOLS2:
    globals()[_func_name] = _factory(_func_name, otype='build tool 2')
