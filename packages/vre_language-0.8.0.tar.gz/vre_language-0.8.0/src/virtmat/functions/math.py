"""provide pint-wrapped versions of some functions from python's math module"""
import math
from virtmat.language.utilities.units import ureg

# Current issues:
# 1. Error: "no signature found for builtin <built-in function log>" -> create a custom lambda func
# 2. Functions with *args do not work with 0 or more than one parameter but they should
# 3. For many functions (e.g. acos, asin, exp, log, ...) the pint wrapper raises an exception
#    workaround: use '' instead of 'dimensionless' in the parameter specs

comb = ureg.wraps('dimensionless', ('', ''))(math.comb)
perm = ureg.wraps('dimensionless', ('', ''))(math.perm)
factorial = ureg.wraps('dimensionless', '')(math.factorial)
gcd = ureg.wraps('=A', '=A')(math.gcd)  # not working, a pint issue with *args signature
isqrt = ureg.wraps('=A**(1/2)', '=A')(math.isqrt)
lcm = ureg.wraps('=A', '=A')(math.lcm)  # not working, a pint issue with *args signature

ceil = ureg.wraps('=A', '=A')(math.ceil)
fabs = ureg.wraps('=A', '=A')(math.fabs)
floor = ureg.wraps('=A', '=A')(math.floor)
# fma = ureg.wraps('=A*B', ('=A', ('=A', '=B', '=A*B'))(math.fma)  # python 3.13
fmod = ureg.wraps('=A**0', ('=A', '=A'))(math.fmod)
modf = ureg.wraps(('=A', '=A'), '=A')(math.modf)
remainder = ureg.wraps('=A**0', ('=A', '=A'))(math.remainder)
trunc = ureg.wraps('=A', '=A')(math.trunc)

exp = ureg.wraps('dimensionless', '')(math.exp)
# exp2 = ureg.wraps('dimensionless', '')(math.exp2)  # python 3.11
log = ureg.wraps('dimensionless', '')(lambda x: math.log(x))  # pylint: disable=unnecessary-lambda
log2 = ureg.wraps('dimensionless', '')(math.log2)
log10 = ureg.wraps('dimensionless', '')(math.log10)
sqrt = ureg.wraps('=A**(1/2)', '=A')(math.sqrt)

isclose = ureg.wraps(None, ('=A', '=A', '', '=A'), strict=False)(math.isclose)
isfinite = ureg.wraps(None, '=A')(math.isfinite)

degrees = ureg.wraps('radians', 'degrees')(math.degrees)
radians = ureg.wraps('degrees', 'radians')(math.radians)
cos = ureg.wraps('dimensionless', 'radians')(math.cos)
sin = ureg.wraps('dimensionless', 'radians')(math.sin)
tan = ureg.wraps('dimensionless', 'radians')(math.tan)
acos = ureg.wraps('radians', '')(math.acos)
asin = ureg.wraps('radians', '')(math.asin)
atan = ureg.wraps('radians', '')(math.atan)
atan2 = ureg.wraps('radians', ('=A', '=A'))(math.atan2)

cosh = ureg.wraps('dimensionless', '')(math.cosh)
sinh = ureg.wraps('dimensionless', '')(math.sinh)
tanh = ureg.wraps('dimensionless', '')(math.tanh)
acosh = ureg.wraps('dimensionless', '')(math.acosh)
asinh = ureg.wraps('dimensionless', '')(math.asinh)
atanh = ureg.wraps('dimensionless', '')(math.atanh)

erf = ureg.wraps('dimensionless', '')(math.erf)
erfc = ureg.wraps('dimensionless', '')(math.erfc)
gamma = ureg.wraps('dimensionless', '')(math.gamma)
lgamma = ureg.wraps('dimensionless', '')(math.lgamma)
