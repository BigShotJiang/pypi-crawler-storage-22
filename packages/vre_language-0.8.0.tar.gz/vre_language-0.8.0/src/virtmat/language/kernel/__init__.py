"""a jupyter kernel for textS/textM"""

__version__ = '0.1'

from .kernel import VMKernel
