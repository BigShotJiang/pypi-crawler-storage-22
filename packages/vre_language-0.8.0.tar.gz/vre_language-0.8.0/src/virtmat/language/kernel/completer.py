"""code completer for the jupyter kernel"""
from textx import metamodel_from_str
from textx.exceptions import TextXSyntaxError, TextXSemanticError
from virtmat.language.utilities.logging import get_logger
from virtmat.language.utilities.textx import get_identifiers, get_expected


class TextXCompleter:  # not covered
    """a completer for textX based languages to be used with jupyter"""
    __ids = []
    matches = []

    def __init__(self, grammar_str, **kwargs):
        self.meta = metamodel_from_str(grammar_str, **kwargs)
        self.logger = get_logger(__name__ + '.completer')
        self.options = get_expected(self.meta, '%')[2]
        self.logger.debug('generated options: %s', self.options)

    def __setattr__(self, name, value):
        if name == 'model':
            self.__ids = [i.name for i in get_identifiers(value)]
        super().__setattr__(name, value)

    def complete(self, text, cursor_pos):
        """the method as required by do_complete() kernel method"""
        self.logger.debug('text: %s, cursor_pos: %s', repr(text), cursor_pos)
        self.matches = []
        offset = 0
        stripped_text = text.strip()
        if stripped_text:
            self.matches, offset = get_expected(self.meta, text, self.options, self.__ids)[:2]
        if not self.matches:
            self.matches = [o for o in self.options if o.startswith(stripped_text)]
            self.matches.extend([o for o in self.__ids if o.startswith(stripped_text)])
        self.logger.debug('%s matches: %s', repr(text), self.matches)
        return self.matches, cursor_pos - len(text) - offset, cursor_pos

    def get_complete(self, text):
        """return completeness status used in the do_is_complete() kernel method"""
        try:
            self.meta.model_from_str(text)
        except TextXSyntaxError as err:
            curr_line_len = len(text.split('\n')[-1])
            offset = curr_line_len - err.col + 1
            assert offset >= 0
            if offset == 0:
                return 'incomplete'
            return 'invalid'
        except TextXSemanticError:
            pass
        return 'complete'
