"""
This module contains an IPython kernel for VRE Language
"""
import os
from ipykernel.ipkernel import IPythonKernel
from ipykernel.kernelapp import IPKernelApp
import matplotlib
from textx import textx_isinstance
from fireworks import LaunchPad
from fireworks.fw_config import LAUNCHPAD_LOC
from fireworks.user_objects.queue_adapters.common_adapter import CommonAdapter
from virtmat.middleware.resconfig import get_resconfig_loc, configure
from virtmat.language.interpreter.session import Session
from virtmat.language.interpreter.session_manager import get_prettytable
from virtmat.language.interpreter.session_manager import expand_query_prefix
from virtmat.language.interpreter.session_manager import get_session_metamodel
from virtmat.language.utilities.textx import GRAMMAR_LOC, GrammarString
from virtmat.language.utilities.compatibility import get_grammar_version
from virtmat.language.utilities.help import HELP_TOP_MESSAGE
from virtmat.language.utilities.errors import format_textxerr_msg, get_err_type
from virtmat.language.utilities.errors import ERROR_HANDLER_OPTIONS
from virtmat.language.utilities.errors import RuntimeTypeError, QueryError
from virtmat.language.utilities.errors import ModelNotFoundError, ConfigurationError
from virtmat.language.utilities.ioops import get_datastore_config, GRIDFS_DATASTORE
from virtmat.language.utilities.formatters import formatter
from virtmat.language.utilities.fireworks import get_models_overview, get_model_history
from virtmat.language.utilities.fireworks import rerun_vars, cancel_vars
from virtmat.language.utilities.fireworks import get_model_tag, get_lost_reserved_running
from virtmat.language.utilities.fireworks import object_from_file, get_wflows_from_user_query
from virtmat.language.utilities.serializable import tag_serialize
from virtmat.language.utilities.warnings import warnings, TextSUserWarning
from virtmat.language.utilities import logging
from .completer import TextXCompleter


def setup_resconfig(resconfig_loc=None):
    """setup resource configuration"""
    if resconfig_loc is None:
        resconfig_loc = get_resconfig_loc()
    if not os.path.exists(resconfig_loc):
        configure(resconfig_loc)


class VMKernel(IPythonKernel):
    """This is the jupyter kernel class for the vre-language package"""
    banner = 'Welcome to textS/textM. Type %help for some help.'
    implementation = 'vmkernel'
    implementation_version = '0.1'
    language = 'vre-language'
    language_version = get_grammar_version(GrammarString().string)
    language_info = {
        'name': 'vre-language',
        'mimetype': 'text/x-vre-language',
        'file_extension': '.vm',
        'pygments_lexer': 'vre-language',
    }
    execution_count = 0
    enable_logging = False
    logging_level = 'CRITICAL'
    logfile = None
    ignore_warnings = False
    qadapter_file = None
    resconfig_loc = None

    def __init__(self, *args, **kwargs):
        self.logger = logging.get_logger(__name__)
        self.logger.info('Initializing')
        super().__init__(*args, **kwargs)
        ERROR_HANDLER_OPTIONS.raise_err = True

        logging.LOGGING_LEVEL = logging.get_logging_level(self.logging_level)
        if not self.enable_logging:
            logging.disable_logging()
            if logging.LOGGING_LEVEL > 20:
                warnings.filterwarnings('ignore')
        elif self.logfile:
            logging.logging.basicConfig(filename=self.logfile)
        warnings.filterwarnings('default', category=TextSUserWarning)
        if self.ignore_warnings:
            warnings.filterwarnings('ignore', category=TextSUserWarning)
        setup_resconfig(self.resconfig_loc)
        if LAUNCHPAD_LOC is None:
            if 'MONGOMOCK_SERVERSTORE_FILE' not in os.environ:
                msg = ('Neither default Launchpad file configured nor custom '
                       'Launchpad file is specified.')
                raise ConfigurationError(msg)
            lp_path = None
            self.lpad = LaunchPad()
            config_dir = os.path.dirname(os.environ['MONGOMOCK_SERVERSTORE_FILE'])
        else:
            lp_path = LAUNCHPAD_LOC
            self.lpad = object_from_file(LaunchPad, lp_path)
            config_dir = os.path.dirname(lp_path)
        GRIDFS_DATASTORE.add(get_datastore_config(launchpad=lp_path), self.lpad)
        qadapter = self.qadapter_file and object_from_file(CommonAdapter, self.qadapter_file)
        self.kwargs = {'autorun': False,
                       'async_run': False,
                       'config_dir': config_dir,
                       'detect_duplicates': True,
                       'lp_path': lp_path,
                       'model_path': None,
                       'on_demand': False,
                       'qadapter': qadapter,
                       'sleep_time': 30,
                       'unique_launchdir': True}
        self.vmlang_session = Session(self.lpad, grammar_path=GRAMMAR_LOC, **self.kwargs)
        self.uuid = self.vmlang_session.uuids[0]
        self.metamodel = get_session_metamodel()
        self.completer = TextXCompleter(GrammarString().string)
        self.completer.model = self.vmlang_session.get_model(uuid=self.uuid)
        s_grammar = os.path.join(os.path.dirname(GRAMMAR_LOC), 'session.tx')
        self.s_completer = TextXCompleter(GrammarString(s_grammar).string)
        matplotlib.use('ipympl')

    def get_model_value(self, *args, **kwargs):
        """evaluated version of get_model() of the Session class"""
        return getattr(self.vmlang_session.get_model(*args, uuid=self.uuid, **kwargs), 'value', '')

    def _send_stdout_stream(self, output):
        """send a stream type message to stdout"""
        content = {'name': 'stdout', 'text': output + '\n'}
        self.send_response(self.iopub_socket, 'stream', content)

    def process_error(self, err_type, err_msg):
        """process error to a response to jupyter and return a dict"""
        # the message type 'error' does not work in jupyter console:
        # dct = {'ename': err_type, 'evalue': err_msg, 'traceback': []}
        # self.send_response(self.iopub_socket, 'error', dct)
        # ename and evalue needed by jupyter console with IPythonKernel base
        dct = {'name': 'stderr', 'text': f'{err_type}: {err_msg}',
               'ename': err_type, 'evalue': err_msg}
        self.send_response(self.iopub_socket, 'stream', dct)
        dct_er = {'status': 'error', 'execution_count': self.execution_count}
        dct_er.update(dct)
        return dct_er

    def error_handler(self, func, *args, **kwargs):
        """jupyter kernel specific error handler"""
        try:
            return func(*args, **kwargs)
        except Exception as err:
            err_type = get_err_type(err) or type(err).__name__
            return self.process_error(err_type, format_textxerr_msg(err))

    async def do_execute(self, code, silent, store_history=True, user_expressions=None,
                         allow_stdin=False, *, cell_meta=None, cell_id=None):
        model = self.error_handler(self.metamodel.model_from_str, code)
        if isinstance(model, dict) and model.get('status') == 'error':
            return model
        if textx_isinstance(model, self.metamodel['Magic']):
            return (self.error_handler(self._process_magic, model) or
                    {'status': 'ok', 'execution_count': self.execution_count,
                     'payload': [], 'user_expressions': {}})
        if textx_isinstance(model, self.metamodel['Program']):
            return self._process_model(code, silent)
        assert textx_isinstance(model, self.metamodel['Expression'])
        return self._process_model(f'print({code})', silent)

    def _process_model(self, code, silent):
        """process texts/textm program (code)"""
        output = self.error_handler(self.get_model_value, code)
        if isinstance(output, dict) and output.get('status') == 'error':
            return output
        model = self.vmlang_session.get_model(uuid=self.uuid)
        if self.uuid is None:
            self.uuid = model.uuid
            assert self.uuid == self.vmlang_session.uuids[0]
        self.completer.model = model
        if not silent:
            stream_content = {'name': 'stdout', 'text': output}
            self.send_response(self.iopub_socket, 'stream', stream_content)
        return {'status': 'ok', 'execution_count': self.execution_count,
                'payload': [], 'user_expressions': {}}

    def _process_magic(self, session_model):
        """handler of magic command inputs"""
        # use dictionary-based factory pattern for magic commands
        commands = {
            'uuid': self._handle_uuid,
            'help': self._handle_help,
            'stop': self._handle_stop,
            'start': self._handle_start,
            'sleep': self._handle_sleep,
            'new': self._handle_new,
            'vary': self._handle_vary,
            'hist': self._handle_history,
            'history': self._handle_history,
            'tag': self._handle_tag,
            'find': self._handle_find,
            'rerun': self._handle_rerun,
            'cancel': self._handle_cancel,
            'logging': self._handle_logging,
            'logfile': self._handle_logfile,
            'load': self._handle_load,
            'launchpad': self._handle_launchpad,
            'qadapter': self._handle_qadapter,
            'warnings': self._handle_warnings,
            'async': self._handle_async,
            'on_demand': self._handle_on_demand,
            'unique_launchdir': self._handle_unique_launchdir,
            'detect_duplicates': self._handle_detect_duplicates
        }
        self.logger.debug('process_magic: %s', session_model.com)
        if session_model.com in ('exit', 'bye', 'close', 'quit'):
            self.vmlang_session.stop_runner()
            return {'status': 'ok', 'execution_count': self.execution_count,
                    'payload': [{'source': 'ask_exit', 'keepkernel': False}],
                    'user_expressions': {}}
        return commands[session_model.com](session_model)

    def _handle_stop(self, _):
        self.vmlang_session.stop_runner()
        self.kwargs['autorun'] = False

    def _handle_start(self, _):
        self.vmlang_session.start_runner()
        self.kwargs['autorun'] = True

    def _handle_sleep(self, session_model):
        if self.vmlang_session.wfe:
            if session_model.arg is None:
                self._send_stdout_stream(str(self.vmlang_session.wfe.sleep_time))
            else:
                self.vmlang_session.wfe.sleep_time = session_model.arg
                self.kwargs['sleep_time'] = session_model.arg

    def _handle_new(self, session_model):
        self.kwargs['model_path'] = session_model.arg
        self.vmlang_session.stop_runner()
        self.vmlang_session = Session(self.lpad, create_new=not self.kwargs['model_path'],
                                      grammar_path=GRAMMAR_LOC, **self.kwargs)
        self.uuid = self.vmlang_session.uuids[0]
        model = self.vmlang_session.get_model(uuid=self.uuid)
        self.completer.model = model
        output = f'Started new session with uuids {formatter(self.vmlang_session.uuids)}'
        content = {'name': 'stderr', 'text': output}
        self.send_response(self.iopub_socket, 'stream', content)
        if session_model.arg:
            self._send_stdout_stream('\n' + getattr(model, 'value', ''))

    def _handle_vary(self, _):
        output = f'vary: {formatter(self.vmlang_session.get_vary_df())}\n'
        content = {'name': 'stdout', 'text': output}
        self.send_response(self.iopub_socket, 'stream', content)

    def _handle_history(self, _):
        if not self.uuid:
            content = {'name': 'stderr', 'text': 'No model is currently loaded.'}
            self.send_response(self.iopub_socket, 'stream', content)
            return
        self._send_stdout_stream(f'{get_prettytable(get_model_history(self.lpad, self.uuid))}')
        if self.vmlang_session.wfe:
            unres_vars, lostj_vars = get_lost_reserved_running(wfengine=self.vmlang_session.wfe)
        else:
            unres_vars, lostj_vars = get_lost_reserved_running(self.lpad, self.uuid)
        output = f'Lost RESERVED: {formatter(unres_vars)}\nLost RUNNING: {formatter(lostj_vars)}'
        self._send_stdout_stream(output)

    def _handle_tag(self, _):
        if self.uuid:
            self._send_stdout_stream(formatter(get_model_tag(self.lpad, self.uuid)))

    def _handle_find(self, session_model):
        query = session_model.arg.value
        self.logger.debug('process_magic: find %s', formatter(query))
        try:
            q_dict = expand_query_prefix(tag_serialize(query))
        except RuntimeTypeError as err:
            self.logger.error('process_magic: %s', str(err))
            raise QueryError(err) from err

        self.logger.debug('process_magic: query: %s', q_dict)
        matching_uuids = get_wflows_from_user_query(self.lpad, q_dict)
        if matching_uuids:
            if session_model.load_one:
                if self.uuid not in matching_uuids:
                    self._switch_model(matching_uuids[0])
                    output = (f'uuids: {formatter(self.uuid)}, '
                              f'{formatter(self.vmlang_session.uuids)}')
                    self._send_stdout_stream(output)
            else:
                output = repr(get_prettytable(get_models_overview(self.lpad, matching_uuids)))
                self._send_stdout_stream(output)

    def _handle_rerun(self, session_model):
        if not self.uuid:
            content = {'name': 'stderr', 'text': 'No model is currently loaded.'}
            self.send_response(self.iopub_socket, 'stream', content)
            return
        rerun_vars(self.lpad, self.uuid, session_model.args)

    def _handle_cancel(self, session_model):
        if not self.uuid:
            content = {'name': 'stderr', 'text': 'No model is currently loaded.'}
            self.send_response(self.iopub_socket, 'stream', content)
            return
        cancel_vars(self.lpad, self.uuid, session_model.args)

    def _handle_uuid(self, session_model):
        uuid = session_model.arg
        if uuid is None:
            uuids_msg = f'uuids: {formatter(self.uuid)} {formatter(self.vmlang_session.uuids)}\n'
            self.send_response(self.iopub_socket, 'stream', {'name': 'stdout', 'text': uuids_msg})
        elif uuid != self.uuid:
            self._switch_model(uuid)
            self._send_stdout_stream(f'Switched to model with UUID: {uuid}')

    def _handle_help(self, _):
        self._send_stdout_stream(HELP_TOP_MESSAGE)

    def _switch_model(self, new_uuid):
        """switch from one to another model"""
        if new_uuid in self.vmlang_session.uuids:
            self.uuid = new_uuid
        else:
            self.vmlang_session.stop_runner()
            try:
                self.vmlang_session = Session(self.lpad, uuid=new_uuid, **self.kwargs)
            except ModelNotFoundError as err:
                if self.kwargs['autorun']:
                    self.vmlang_session.start_runner()
                raise err
            self.uuid = new_uuid
            self.completer.model = self.vmlang_session.get_model(uuid=self.uuid)

    def _handle_logging(self, session_model):
        """set the logging level or turn logging off"""
        level = session_model.arg
        if level is None:
            if self.enable_logging:
                curr_level = logging.logging.getLevelName(logging.LOGGING_LEVEL)
                self._send_stdout_stream(f'Current level: {curr_level}')
            else:
                self._send_stdout_stream('Logging not activated.')
        elif level.lower() == 'off':
            logging.disable_logging()
            self.enable_logging = False
        elif level.lower() == 'on' and not self.enable_logging:
            logging.enable_logging()
            self.enable_logging = True
        else:
            if not self.enable_logging:
                logging.enable_logging()
                self.enable_logging = True
            logging.LOGGING_LEVEL = logging.get_logging_level(level)
            if logging.LOGGING_LEVEL > 20:
                warnings.filterwarnings('ignore')
        self.logger = logging.get_logger(__name__)

    def _handle_warnings(self, session_model):
        """turn on/off warnings"""
        if session_model.arg is None:
            self._send_stdout_stream('off' if self.ignore_warnings else 'on')
        elif session_model.arg.lower() == 'off':
            warnings.filterwarnings('ignore')
            self.ignore_warnings = True
        else:
            warnings.resetwarnings()
            warnings.filterwarnings('default', category=TextSUserWarning)
            self.ignore_warnings = False

    def _handle_logfile(self, session_model):
        """set a file for logging"""
        if session_model.arg:
            logging.logging.basicConfig(filename=session_model.arg)
            self.logfile = session_model.arg
        elif self.logfile is None:
            self._send_stdout_stream('No logfile.')
        else:
            output = f'Current logfile: {os.path.abspath(self.logfile)}'
            self._send_stdout_stream(output)

    def _handle_load(self, session_model):
        """load vre-language model from a file"""
        model = self.error_handler(self.vmlang_session.get_model, uuid=self.uuid,
                                   model_path=session_model.arg)
        if self.uuid is None:
            self.uuid = self.vmlang_session.uuids[0]
        if isinstance(model, dict) and model.get('status') == 'error':
            return model
        if model:
            self.completer.model = model
            self._send_stdout_stream(getattr(model, 'value', ''))
        return None

    def _handle_launchpad(self, session_model):
        """select launchpad file"""
        if session_model.arg is None:
            self._send_stdout_stream(f'{self.vmlang_session.lp_path}')
        else:
            lp_path = os.path.abspath(session_model.arg)
            if lp_path != os.path.abspath(self.vmlang_session.lp_path):
                self.vmlang_session.stop_runner()
                self.lpad = object_from_file(LaunchPad, lp_path)
                self.kwargs['lp_path'] = lp_path
                self.kwargs['config_dir'] = os.path.dirname(lp_path)
                self.vmlang_session = Session(self.lpad, grammar_path=GRAMMAR_LOC, **self.kwargs)
                self.uuid = self.vmlang_session.uuids[0]
                content = {'name': 'stderr', 'text': f'Switched to launchpad {lp_path}\n'}
                self.send_response(self.iopub_socket, 'stream', content)

    def _handle_qadapter(self, session_model):
        """specify default qadapter file"""
        if session_model.arg is None:
            output = formatter(self.qadapter_file) if self.qadapter_file else 'No qadapter file.'
            self._send_stdout_stream(output)
        elif session_model.arg:
            qadapter_path = os.path.abspath(session_model.arg)
            self.kwargs['qadapter'] = object_from_file(CommonAdapter, qadapter_path)
            self.qadapter_file = qadapter_path
            if self.kwargs['async_run']:
                assert self.vmlang_session.wfe
                self.vmlang_session.stop_runner()
                wfe_keys = ('qadapter', 'sleep_time', 'unique_launchdir')
                wfe_kwargs = {k: v for k, v in self.kwargs.items() if k in wfe_keys}
                self.vmlang_session.init_async_run(self.kwargs['config_dir'], wfe_kwargs)

    def _handle_async(self, session_model):
        """toggle async evaluation in a background thread"""
        current = 'on' if self.kwargs['async_run'] else 'off'
        if session_model.arg is None:
            self._send_stdout_stream(current)
        elif current != session_model.arg.lower():
            if session_model.arg.lower() == 'off':
                self.vmlang_session.stop_runner()
                self.vmlang_session.wfe = None
                self.kwargs['async_run'] = False
                self.vmlang_session.async_run = self.kwargs['async_run']
            else:
                self.kwargs['async_run'] = True
                self.vmlang_session.async_run = self.kwargs['async_run']
                wfe_keys = ('qadapter', 'sleep_time', 'unique_launchdir')
                wfe_kwargs = {k: v for k, v in self.kwargs.items() if k in wfe_keys}
                self.vmlang_session.init_async_run(self.kwargs['config_dir'], wfe_kwargs)

    def _handle_on_demand(self, session_model):
        """toggle on-demand evaluation"""
        current = 'on' if self.kwargs['on_demand'] else 'off'
        if session_model.arg is None:
            self._send_stdout_stream(current)
        elif current != session_model.arg.lower():
            if session_model.arg.lower() == 'off':
                self.kwargs['on_demand'] = False
                if self.vmlang_session.wfe:
                    self.vmlang_session.wfe.nodes_torun = None
            else:
                self.kwargs['on_demand'] = True
                if self.vmlang_session.wfe:
                    self.vmlang_session.wfe.nodes_torun = []
            self.vmlang_session.on_demand = self.kwargs['on_demand']

    def _handle_unique_launchdir(self, session_model):
        """toggle evaluation in unique launchdir"""
        current = 'on' if self.kwargs['unique_launchdir'] else 'off'
        if session_model.arg is None:
            self._send_stdout_stream(current)
        elif current != session_model.arg.lower():
            if session_model.arg.lower() == 'off':
                self.kwargs['unique_launchdir'] = False
            else:
                self.kwargs['unique_launchdir'] = True
            self.vmlang_session.unique_launchdir = self.kwargs['unique_launchdir']
            if self.vmlang_session.wfe:
                self.vmlang_session.wfe.unique_launchdir = self.kwargs['unique_launchdir']

    def _handle_detect_duplicates(self, session_model):
        """toggle duplicates detection"""
        current = 'on' if self.kwargs['detect_duplicates'] else 'off'
        if session_model.arg is None:
            self._send_stdout_stream(current)
        elif current != session_model.arg.lower():
            if session_model.arg.lower() == 'off':
                self.kwargs['detect_duplicates'] = False
            else:
                self.kwargs['detect_duplicates'] = True
            self.vmlang_session.detect_duplicates = self.kwargs['detect_duplicates']

    def do_complete(self, code, cursor_pos):
        self.logger.debug('complete_request: code: %s, cursor: %s', repr(code), cursor_pos)
        matches, start, currpos = self.completer.complete(code, cursor_pos)
        if not matches:  # maybe better use the get_completed to check if code invalid
            matches, start, currpos = self.s_completer.complete(code, cursor_pos)
        log_msg = 'complete_reply: matches: %s, cursor_start: %s, cursor_end: %s'
        self.logger.debug(log_msg, matches, start, currpos)
        return {'matches': matches, 'cursor_start': start, 'cursor_end': currpos,
                'metadata': {}, 'status': 'ok'}

    def do_is_complete(self, code):
        # indent different from '' does not work because it intermingles with the code
        self.logger.debug('is_complete_request: code: %s', repr(code))
        status = 'complete' if code.strip() == '' else self.s_completer.get_complete(code)
        if status == 'invalid':
            status = self.completer.get_complete(code)
        # status is one of 'complete', 'incomplete', 'invalid', 'unknown'
        self.logger.debug('is_complete_reply: indent: %s, status: %s', repr(''), status)
        return {'indent': '', 'status': status}

    def do_shutdown(self, restart):
        """this method does not seem to be called by the app/frontend"""
        self.logger.debug('shutdown_request: restart: %s', restart)
        reply = super().do_shutdown(restart)
        assert reply['status'] == 'ok'
        assert reply['restart'] == restart
        self.vmlang_session.stop_runner()
        self.logger.debug('shutdown_reply: status: %s, restart: %s', 'ok', restart)
        return {'status': 'ok', 'restart': restart}

    def do_apply(self, content, bufs, msg_id, reply_metadata):
        raise NotImplementedError

    def do_clear(self):
        raise NotImplementedError

    async def do_debug_request(self, msg):
        raise NotImplementedError


if __name__ == '__main__':
    IPKernelApp.launch_instance(kernel_class=VMKernel)
