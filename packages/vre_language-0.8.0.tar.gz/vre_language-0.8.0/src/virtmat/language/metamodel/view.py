"""module for data visualization"""
from virtmat.language.utilities.types import NC
from virtmat.language.utilities.errors import textxerror_wrap, error_handler
from virtmat.language.utilities.warnings import warnings, TextSUserWarning
from virtmat.language.utilities.logging import get_logger
from virtmat.language.utilities.viewers import display_seaborn
from virtmat.language.utilities.ase_viewers import display_amml_structure
from virtmat.language.utilities.ase_viewers import display_amml_trajectory
from virtmat.language.utilities.ase_viewers import display_vibration
from virtmat.language.utilities.ase_viewers import display_bs, display_eos, display_neb
from virtmat.language.utilities.ase_viewers import display_waterfall

get_logger(__name__).info('Initializing')


@error_handler
@textxerror_wrap
def display(self, show=True):
    """define display() method in View metamodel class"""
    if any(par.value is NC for par in self.params):
        par = next(p for p in self.params if p.value is NC)
        msg = 'parameter value is not computed yet'
        warnings.warn(TextSUserWarning(msg, obj=par))
        return
    if self.mode in ('lineplot', 'scatterplot'):
        display_seaborn(self, show=show)
    elif self.mode == 'bs':
        display_bs(self, show=show)
    elif self.mode == 'eos':
        display_eos(self, show=show)
    elif self.mode == 'neb':
        display_neb(self, show=show)
    elif self.mode == 'vibration':
        display_vibration(self, show=show)
    elif self.mode == 'trajectory':
        display_amml_trajectory(self, show=show)
    elif self.mode == 'waterfall':
        display_waterfall(self, show=show)
    else:
        assert self.mode == 'structure'
        display_amml_structure(self, show=show)


def add_display(metamodel):
    """add display method to the View metamodel class"""
    setattr(metamodel['View'], 'display', display)
