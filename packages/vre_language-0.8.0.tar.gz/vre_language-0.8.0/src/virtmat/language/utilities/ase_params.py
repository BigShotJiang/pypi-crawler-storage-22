"""
definitions of ASE calculators, algorithms with their parameters with
types, units, default values and outputs with types, units and default values
"""
import numbers
import math
import types
import numpy
import pandas
import pint
from ase.data import chemical_symbols
from ase.collections import g2
from ase.build.molecule import extra
from virtmat.language.utilities.errors import RuntimeTypeError, InvalidUnitError
from virtmat.language.utilities.errors import RuntimeValueError
from virtmat.language.utilities.units import ureg
from virtmat.language.utilities.formatters import formatter
from virtmat.language.utilities.ase_tasks import calc_tasks
from virtmat.language.utilities.ase_units import convert_to_ase_units, MAGMOM_AU
from virtmat.language.utilities.ase_units import calc_pars as calc_pars_units
from virtmat.language.utilities.ase_types import calc_pars as calc_pars_types
from virtmat.language.utilities.ase_defaults import calc_pars as calc_pars_defaults
from virtmat.language.utilities.ase_choices import calc_pars as calc_pars_choices
from virtmat.language.utilities.types import is_numeric_scalar, is_numeric_array
from virtmat.language.utilities.types import NA, ScalarBoolean
from virtmat.language.utilities.lists import list_apply

spec = {
  'vasp': {
    'module': 'virtmat.language.utilities.ase_wrappers',
    'class': 'Vasp',
    'modulefile': {'name': 'vasp', 'verspec': '>=5.0.0'},
    'modulefiles': None,  # further required modulefiles, like {'intel': '==10.0'}
    'envvars': {'VASP_COMMAND': 'vasp_std'},  # environment vars with their default values
    'properties': ['energy', 'dipole', 'forces', 'stress', 'vibrational_energies',
                   'energy_minimum', 'transition_state', 'trajectory', 'magmom',
                   'magmoms']
  },
  'turbomole': {
    'module': 'ase.calculators.turbomole',
    'class': 'Turbomole',
    'modulefile': {'name': 'turbomole', 'verspec': '>=7.0'},
    'properties': ['energy', 'forces', 'vibrational_energies', 'energy_minimum',
                   'transition_state', 'dipole']
  },
  'lj': {
    'module': 'ase.calculators.lj',
    'class': 'LennardJones',
    'properties': ['energy', 'forces']
  },
  'lennardjones': {
    'module': 'ase.calculators.lj',
    'class': 'LennardJones',
    'properties': ['energy', 'forces']
  },
  'emt': {
    'module': 'ase.calculators.emt',
    'class': 'EMT',
    'properties': ['energy', 'forces', 'stress']
  },
  'free_electrons': {
    'module': 'ase.calculators.test',
    'class': 'FreeElectrons',
    'properties': ['energy', 'band_structure']
  },
  'elk': {
    'module': 'ase.calculators.elk',
    'class': 'ELK',
    'modulefile': {'name': 'elk', 'verspec': '>=6.0.0'},
    'profile': {
        'class': 'ElkProfile',
        'module': 'ase.calculators.elk',
        'envvars': {'ELK_COMMAND': '', 'ELK_SPPATH': ''},
        'kwargs': {
            'command': 'ELK_COMMAND',
            'sppath': 'ELK_SPPATH'
        }
     },
    'properties': ['energy', 'forces']
  },
  'BFGS': {
    'module': 'ase.optimize',
    'class': 'BFGS',
    'otype': 'algorithm',
    'requires_dof': True,
    'many_to_one': False,
    'calc_task': ['single point'],
    'properties': ['trajectory'],
    'params': {
      'steps': {
        'default': ureg.Quantity(100000000),
        'type': numbers.Integral,
        'units': 'dimensionless',
        'method': 'run',
      },
      'maxstep': {
        'default': ureg.Quantity(0.2, 'angstrom'),
        'type': numbers.Real,
        'units': 'angstrom',
        'method': 'class',
      },
      'trajectory': {
        'default': NA,
        'type': bool,
        'units': None,
        'method': 'class',
      },
      'logfile': {
        'default': NA,
        'type': bool,
        'units': None,
        'method': 'class',
      },
      'interval': {
        'default': ureg.Quantity(1),
        'type': numbers.Integral,
        'units': 'dimensionless',
        'method': 'class',
      },
      'fmax': {
        'default': ureg.Quantity(0.05, 'eV / angstrom'),
        'type': numbers.Real,
        'units': 'eV / angstrom',
        'method': 'run',
      },
      'alpha': {
        'default': ureg.Quantity(70.0, 'eV * angstrom ** (-2)'),
        'type': numbers.Real,
        'units': 'eV * angstrom ** (-2)',
        'method': 'class',
      },
    }
  },
  'LBFGS': {
    'module': 'ase.optimize',
    'class': 'LBFGS',
    'otype': 'algorithm',
    'requires_dof': True,
    'many_to_one': False,
    'calc_task': ['single point'],
    'properties': ['trajectory'],
    'params': {
      'steps': {
        'default': ureg.Quantity(100000000),
        'type': numbers.Integral,
        'units': 'dimensionless',
        'method': 'run',
      },
      'maxstep': {
        'default': ureg.Quantity(0.2, 'angstrom'),
        'type': numbers.Real,
        'units': 'angstrom',
        'method': 'class',
      },
      'trajectory': {
        'default': NA,
        'type': bool,
        'units': None,
        'method': 'class',
      },
      'logfile': {
        'default': NA,
        'type': bool,
        'units': None,
        'method': 'class',
      },
      'interval': {
        'default': ureg.Quantity(1),
        'type': numbers.Integral,
        'units': 'dimensionless',
        'method': 'class',
      },
      'fmax': {
        'default': ureg.Quantity(0.05, 'eV / angstrom'),
        'type': numbers.Real,
        'units': 'eV / angstrom',
        'method': 'run',
      },
      'memory': {
        'default': ureg.Quantity(100),
        'type': numbers.Integral,
        'units': 'dimensionless',
        'method': 'class',
      },
      'damping': {
        'default': ureg.Quantity(1.0),
        'type': numbers.Real,
        'units': 'dimensionless',
        'method': 'class',
      },
      'alpha': {
        'default': ureg.Quantity(70.0, 'eV * angstrom ** (-2)'),
        'type': numbers.Real,
        'units': 'eV * angstrom ** (-2)',
        'method': 'class',
      },
    }
  },
  'LBFGSLineSearch': {
    'module': 'ase.optimize',
    'class': 'LBFGSLineSearch',
    'otype': 'algorithm',
    'requires_dof': True,
    'many_to_one': False,
    'calc_task': ['single point'],
    'properties': ['trajectory'],
    'params': {
      'steps': {
        'default': ureg.Quantity(100000000),
        'type': numbers.Integral,
        'units': 'dimensionless',
        'method': 'run',
      },
      'maxstep': {
        'default': ureg.Quantity(0.2, 'angstrom'),
        'type': numbers.Real,
        'units': 'angstrom',
        'method': 'class',
      },
      'trajectory': {
        'default': NA,
        'type': bool,
        'units': None,
        'method': 'class',
      },
      'logfile': {
        'default': NA,
        'type': bool,
        'units': None,
        'method': 'class',
      },
      'interval': {
        'default': ureg.Quantity(1),
        'type': numbers.Integral,
        'units': 'dimensionless',
        'method': 'class',
      },
      'fmax': {
        'default': ureg.Quantity(0.05, 'eV / angstrom'),
        'type': numbers.Real,
        'units': 'eV / angstrom',
        'method': 'run',
      },
      'memory': {
        'default': ureg.Quantity(100),
        'type': numbers.Integral,
        'units': 'dimensionless',
        'method': 'class',
      },
      'damping': {
        'default': ureg.Quantity(1.0),
        'type': numbers.Real,
        'units': 'dimensionless',
        'method': 'class',
      },
      'alpha': {
        'default': ureg.Quantity(70.0, 'eV * angstrom ** (-2)'),
        'type': numbers.Real,
        'units': 'eV * angstrom ** (-2)',
        'method': 'class',
      },
    }
  },
  'QuasiNewton': {
    'module': 'ase.optimize',
    'class': 'QuasiNewton',
    'otype': 'algorithm',
    'requires_dof': True,
    'many_to_one': False,
    'calc_task': ['single point'],
    'properties': ['trajectory'],
    'params': {
      'steps': {
        'default': ureg.Quantity(100000000),
        'type': numbers.Integral,
        'units': 'dimensionless',
        'method': 'run',
      },
      'maxstep': {
        'default': ureg.Quantity(0.2, 'angstrom'),
        'type': numbers.Real,
        'units': 'angstrom',
        'method': 'class',
      },
      'trajectory': {
        'default': NA,
        'type': bool,
        'units': None,
        'method': 'class',
      },
      'logfile': {
        'default': NA,
        'type': bool,
        'units': None,
        'method': 'class',
      },
      'interval': {
        'default': ureg.Quantity(1),
        'type': numbers.Integral,
        'units': 'dimensionless',
        'method': 'class',
      },
      'fmax': {
        'default': ureg.Quantity(0.05, 'eV / angstrom'),
        'type': numbers.Real,
        'units': 'eV / angstrom',
        'method': 'run',
      },
    }
  },
  'BFGSLineSearch': {
    'module': 'ase.optimize',
    'class': 'BFGSLineSearch',
    'otype': 'algorithm',
    'requires_dof': True,
    'many_to_one': False,
    'calc_task': ['single point'],
    'properties': ['trajectory'],
    'params': {
      'steps': {
        'default': ureg.Quantity(100000000),
        'type': numbers.Integral,
        'units': 'dimensionless',
        'method': 'run',
      },
      'maxstep': {
        'default': ureg.Quantity(0.2, 'angstrom'),
        'type': numbers.Real,
        'units': 'angstrom',
        'method': 'class',
      },
      'trajectory': {
        'default': NA,
        'type': bool,
        'units': None,
        'method': 'class',
      },
      'logfile': {
        'default': NA,
        'type': bool,
        'units': None,
        'method': 'class',
      },
      'interval': {
        'default': ureg.Quantity(1),
        'type': numbers.Integral,
        'units': 'dimensionless',
        'method': 'class',
      },
      'fmax': {
        'default': ureg.Quantity(0.05, 'eV / angstrom'),
        'type': numbers.Real,
        'units': 'eV / angstrom',
        'method': 'run',
      },
    }
  },
  'GPMin': {
    'module': 'ase.optimize',
    'class': 'GPMin',
    'otype': 'algorithm',
    'requires_dof': True,
    'many_to_one': False,
    'calc_task': ['single point'],
    'properties': ['trajectory'],
    'params': {
      'steps': {
        'default': ureg.Quantity(100000000),
        'type': numbers.Integral,
        'units': 'dimensionless',
        'method': 'class',
      },
      'trajectory': {
        'default': NA,
        'type': bool,
        'units': None,
        'method': 'class',
      },
      'logfile': {
        'default': NA,
        'type': bool,
        'units': None,
        'method': 'class',
      },
      'interval': {
        'default': ureg.Quantity(1),
        'type': numbers.Integral,
        'units': 'dimensionless',
        'method': 'class',
      },
      'fmax': {
        'default': ureg.Quantity(0.05, 'eV / angstrom'),
        'type': numbers.Real,
        'units': 'eV / angstrom',
        'method': 'run',
      },
      'prior': {
        'default': NA,
        'type': object,
        'units': None,
        'method': 'class',
      },
      'kernel': {
        'default': NA,
        'type': object,
        'units': None,
        'method': 'class',
      },
      'update_prior_strategy': {
        'default': 'maximum',
        'choices': ['maximum', 'init', 'average'],
        'type': str,
        'units': None,
        'method': 'class',
      },
      'update_hyperparams': {
        'default': False,
        'type': bool,
        'units': None,
        'method': 'class',
      },
      'noise': {
        'default': ureg.Quantity(0.005),
        'type': numbers.Real,
        'units': 'dimensionless',
        'method': 'class',
      },
      'weight': {
        'default': ureg.Quantity(1.0),
        'type': numbers.Real,
        'units': 'dimensionless',
        'method': 'class',
      },
      'scale': {
        'default': ureg.Quantity(0.4),
        'type': numbers.Real,
        'units': 'dimensionless',
        'method': 'class',
      },
    }
  },
  'FIRE': {
    'module': 'ase.optimize',
    'class': 'FIRE',
    'otype': 'algorithm',
    'requires_dof': True,
    'many_to_one': False,
    'calc_task': ['single point'],
    'properties': ['trajectory'],
    'params': {
      'steps': {
        'default': ureg.Quantity(100000000),
        'type': numbers.Integral,
        'units': 'dimensionless',
        'method': 'run',
      },
      'maxstep': {
        'default': ureg.Quantity(0.2, 'angstrom'),
        'type': numbers.Real,
        'units': 'angstrom',
        'method': 'class',
      },
      'trajectory': {
        'default': NA,
        'type': bool,
        'units': None,
        'method': 'class',
      },
      'logfile': {
        'default': NA,
        'type': bool,
        'units': None,
        'method': 'class',
      },
      'interval': {
        'default': ureg.Quantity(1),
        'type': numbers.Integral,
        'units': 'dimensionless',
        'method': 'class',
      },
      'fmax': {
        'default': ureg.Quantity(0.05, 'eV / angstrom'),
        'type': numbers.Real,
        'units': 'eV / angstrom',
        'method': 'run',
      },
      'dt': {
        'default': ureg.Quantity(0.1, 'angstrom * (amu / eV ) ** (1/2)'),
        'type': numbers.Real,
        'units': 'angstrom * (amu / eV ) ** (1/2)',
        'method': 'class',
      },
      'dtmax': {
        'default': ureg.Quantity(1.0, 'angstrom * (amu / eV ) ** (1/2)'),
        'type': numbers.Real,
        'units': 'angstrom * (amu / eV ) ** (1/2)',
        'method': 'class',
      },
      'downhill_check': {
        'default': False,
        'type': bool,
        'units': None,
        'method': 'class',
      },
    }
  },  # nb: 8 non-documented init parameters in FIRE: no explanation/no units
  'MDMin': {
    'module': 'ase.optimize',
    'class': 'MDMin',
    'otype': 'algorithm',
    'requires_dof': True,
    'many_to_one': False,
    'calc_task': ['single point'],
    'properties': ['trajectory'],
    'params': {
      'steps': {
        'default': ureg.Quantity(100000000),
        'type': numbers.Integral,
        'units': 'dimensionless',
        'method': 'run',
      },
      'maxstep': {
        'default': ureg.Quantity(0.2, 'angstrom'),
        'type': numbers.Real,
        'units': 'angstrom',
        'method': 'class',
      },
      'trajectory': {
        'default': NA,
        'type': bool,
        'units': None,
        'method': 'class',
      },
      'logfile': {
        'default': NA,
        'type': bool,
        'units': None,
        'method': 'class',
      },
      'interval': {
        'default': ureg.Quantity(1),
        'type': numbers.Integral,
        'units': 'dimensionless',
        'method': 'class',
      },
      'fmax': {
        'default': ureg.Quantity(0.05, 'eV / angstrom'),
        'type': numbers.Real,
        'units': 'eV / angstrom',
        'method': 'run',
      },
      'dt': {
        'default': ureg.Quantity(0.2, 'angstrom * (amu / eV ) ** (1/2)'),
        'type': numbers.Real,
        'units': 'angstrom * (amu / eV ) ** (1/2)',
        'method': 'class',
      },
    }
  },
  'RMSD': {
    'module': 'virtmat.language.utilities.ase_wrappers',
    'class': 'RMSD',
    'otype': 'algorithm',
    'requires_dof': True,
    'many_to_one': None,
    'properties': ['rmsd'],
    'params': {
      'reference': {
        'type': object,  # cannot be checked, always true
        'units': None,
        'method': 'run'
      },
      'adjust': {
        'default': True,
        'type': bool,
        'units': None,
        'method': 'run'
      },
    }
  },
  'RDF': {
    'module': 'virtmat.language.utilities.ase_wrappers',
    'class': 'RDF',
    'otype': 'algorithm',
    'requires_dof': False,
    'many_to_one': None,
    'properties': ['rdf_distance', 'rdf'],
    'params': {
      'rmax': {
        'default': NA,
        'type': numbers.Real,
        'units': 'angstrom',
        'method': 'run'
      },
      'nbins': {
        'default': ureg.Quantity(40),
        'type': numbers.Integral,
        'units': 'dimensionless',
        'method': 'run'
      },
      'neighborlist': {
        'default': NA,
        'type': pandas.DataFrame,
        'otype': 'algorithm',
        'units': None,
        'method': 'run'
      },
      'elements': {
        'default': NA,
        'type': str,
        'units': None,
        'method': 'run'
      }
    }
  },
  'VelocityDistribution': {
    'module': 'virtmat.language.utilities.ase_wrappers',
    'class': 'VelocityDistribution',
    'otype': 'algorithm',
    'requires_dof': False,
    'many_to_one': None,
    'properties': ['vdf', 'velocity'],
    'params': {
      'distribution': {
        'default': 'maxwell-boltzmann',  # phonon_harmonics not implemented
        'choices': ['maxwell-boltzmann', 'phonon_harmonics'],
        'type': str,
        'units': None,
        'method': 'class'
      },
      'temperature_K': {
        'type': numbers.Real,
        'units': 'kelvin',
        'method': 'class'
      },
      'force_temp': {
        'default': False,
        'type': bool,
        'units': None,
        'method': 'class'
      },
      'stationary': {
        'default': True,
        'type': bool,
        'units': None,
        'method': 'run'
      },
      'zero_rotation': {
        'default': True,
        'type': bool,
        'units': None,
        'method': 'run'
      },
      'preserve_temperature': {
        'default': True,
        'type': bool,
        'units': None,
        'method': 'run'
      },
      'nbins': {
        'default': ureg.Quantity(40),
        'type': numbers.Integral,
        'units': 'dimensionless',
        'method': 'run'
      },
    }
  },
  'EquationOfState': {
    'module': 'virtmat.language.utilities.ase_wrappers',
    'class': 'EOS',
    'otype': 'algorithm',
    'requires_dof': False,
    'many_to_one': True,
    'properties': ['minimum_energy', 'optimal_volume', 'bulk_modulus',
                   'eos_volume', 'eos_energy'],
    'params': {
      'energies': {
        'default': NA,
        'type': numpy.ndarray,
        'units': 'eV',
        'method': 'run'
      },
      'eos': {
        'default': 'sjeos',
        'choices': ['sjeos', 'taylor', 'murnaghan', 'birch', 'birchmurnaghan',
                    'pouriertarantola', 'vinet', 'antonschmidt', 'p3'],
        'type': str,
        'units': None,
        'method': 'run'
      },
      'filename': {
        'default': NA,
        'type': str,
        'units': None,
        'method': 'run'
      }
    }
  },
  'DensityOfStates': {
    'module': 'virtmat.language.utilities.ase_wrappers',
    'class': 'DensityOfStates',
    'otype': 'algorithm',
    'requires_dof': False,
    'many_to_one': False,
    'calc_task': ['single point'],
    'properties': ['dos_energy', 'dos'],
    'params': {
      'width': {
        'default': ureg.Quantity(0.1, 'eV'),
        'type': numbers.Real,
        'units': 'eV',
        'method': 'run'
      },
      'window': {
        'default': NA,
        'type': numpy.ndarray,
        'units': 'eV',
        'method': 'run'
      },
      'npts': {
        'default': ureg.Quantity(401),
        'type': numbers.Integral,
        'units': 'dimensionless',
        'method': 'run'
      },
      'spin': {
        'default': NA,
        'choices': [0, 1],
        'type': numbers.Integral,
        'units': 'dimensionless',
        'method': 'run'
      },
    }
  },
  'BandStructure': {
    'module': 'virtmat.language.utilities.ase_wrappers',
    'class': 'BandStructure',
    'otype': 'algorithm',
    'requires_dof': False,
    'many_to_one': False,
    'calc_task': ['single point'],
    'properties': ['band_structure'],
    'params': {
      'emin': {
        'default': NA,
        'type': numbers.Real,
        'units': 'eV',
        'method': 'run'
      },
      'emax': {
        'default': NA,
        'type': numbers.Real,
        'units': 'eV',
        'method': 'run'
      },
      'filename': {
        'default': NA,
        'type': str,
        'units': 'None',
        'method': 'run'
      }
    }
  },
  'VelocityVerlet': {
    'module': 'ase.md.verlet',
    'class': 'VelocityVerlet',
    'otype': 'algorithm',
    'requires_dof': True,
    'many_to_one': False,
    'calc_task': ['single point'],
    'properties': ['trajectory'],
    'params': {
      'steps': {
        'default': ureg.Quantity(50),
        'type': numbers.Integral,
        'units': 'dimensionless',
        'method': 'run',
      },
      'logfile': {
        'default': NA,
        'type': bool,
        'units': None,
        'method': 'class',
      },
      'trajectory': {
        'default': NA,
        'type': bool,
        'units': None,
        'method': 'class',
      },
      'interval': {
        'default': ureg.Quantity(1),
        'type': numbers.Integral,
        'units': 'dimensionless',
        'method': 'class',
      },
      'timestep': {
        'type': numbers.Real,
        'units': 'angstrom * (amu / eV ) ** (1/2)',
        'method': 'class',
      },
    }
  },
  'Langevin': {
    'module': 'ase.md.langevin',
    'class': 'Langevin',
    'otype': 'algorithm',
    'requires_dof': True,
    'many_to_one': False,
    'calc_task': ['single point'],
    'properties': ['trajectory'],
    'params': {
      'steps': {
        'default': ureg.Quantity(50),
        'type': numbers.Integral,
        'units': 'dimensionless',
        'method': 'run',
      },
      'logfile': {
        'default': NA,
        'type': bool,
        'units': None,
        'method': 'class',
      },
      'trajectory': {
        'default': NA,
        'type': bool,
        'units': None,
        'method': 'class',
      },
      'interval': {
        'default': ureg.Quantity(1),
        'type': numbers.Integral,
        'units': 'dimensionless',
        'method': 'class',
      },
      'timestep': {
        'type': numbers.Real,
        'units': 'angstrom * (amu / eV ) ** (1/2)',
        'method': 'class',
      },
      'temperature_K': {
        'type': numbers.Real,
        'units': 'K',
        'method': 'class',
      },
      'friction': {
        'type': numbers.Real,
        'units': 'angstrom ** (-1) * (amu / eV ) ** (-1/2)',
        'method': 'class',
      },
      'fixcm': {
        'default': True,
        'type': bool,
        'units': None,
        'method': 'class',
      },
    }
  },
  'NPT': {
    'module': 'ase.md.npt',
    'class': 'NPT',
    'otype': 'algorithm',
    'requires_dof': True,
    'many_to_one': False,
    'calc_task': ['single point'],
    'properties': ['trajectory'],
    'params': {
      'steps': {
        'default': ureg.Quantity(50),
        'type': numbers.Integral,
        'units': 'dimensionless',
        'method': 'run',
      },
      'logfile': {
        'default': NA,
        'type': bool,
        'units': None,
        'method': 'class',
      },
      'trajectory': {
        'default': NA,
        'type': bool,
        'units': None,
        'method': 'class',
      },
      'interval': {
        'default': ureg.Quantity(1),
        'type': numbers.Integral,
        'units': 'dimensionless',
        'method': 'class',
      },
      'timestep': {
        'type': numbers.Real,
        'units': 'angstrom * (amu / eV ) ** (1/2)',
        'method': 'class',
      },
      'temperature_K': {
        'type': numbers.Real,
        'units': 'K',
        'method': 'class',
      },
      'externalstress': {
        'type': numbers.Real,
        'units': 'eV / (angstrom ** 3)',
        'method': 'class',
      },
      'ttime': {
        'type': numbers.Real,
        'units': 'angstrom * (amu / eV ) ** (1/2)',
        'method': 'class',
      },
      'pfactor': {
        'type': numbers.Real,
        'units': 'amu  / angstrom',
        'method': 'class',
      },
    }
  },
  'Andersen': {
    'module': 'ase.md.andersen',
    'class': 'Andersen',
    'otype': 'algorithm',
    'requires_dof': True,
    'many_to_one': False,
    'calc_task': ['single point'],
    'properties': ['trajectory'],
    'params': {
      'steps': {
        'default': ureg.Quantity(50),
        'type': numbers.Integral,
        'units': 'dimensionless',
        'method': 'run',
      },
      'logfile': {
        'default': NA,
        'type': bool,
        'units': None,
        'method': 'class',
      },
      'trajectory': {
        'default': NA,
        'type': bool,
        'units': None,
        'method': 'class',
      },
      'interval': {
        'default': ureg.Quantity(1),
        'type': numbers.Integral,
        'units': 'dimensionless',
        'method': 'class',
      },
      'timestep': {
        'type': numbers.Real,
        'units': 'angstrom * (amu / eV ) ** (1/2)',
        'method': 'class',
      },
      'temperature_K': {
        'type': numbers.Real,
        'units': 'K',
        'method': 'class',
      },
      'andersen_prob': {
        'type': numbers.Real,
        'units': 'dimensionless',
        'method': 'class',
      },
      'fixcm': {
        'default': True,
        'type': bool,
        'units': None,
        'method': 'class',
      },
    }
  },
  'NVTBerendsen': {
    'module': 'ase.md.nvtberendsen',
    'class': 'NVTBerendsen',
    'otype': 'algorithm',
    'requires_dof': True,
    'many_to_one': False,
    'calc_task': ['single point'],
    'properties': ['trajectory'],
    'params': {
      'steps': {
        'default': ureg.Quantity(50),
        'type': numbers.Integral,
        'units': 'dimensionless',
        'method': 'run',
      },
      'logfile': {
        'default': NA,
        'type': bool,
        'units': None,
        'method': 'class',
      },
      'trajectory': {
        'default': NA,
        'type': bool,
        'units': None,
        'method': 'class',
      },
      'interval': {
        'default': ureg.Quantity(1),
        'type': numbers.Integral,
        'units': 'dimensionless',
        'method': 'class',
      },
      'timestep': {
        'type': numbers.Real,
        'units': 'angstrom * (amu / eV ) ** (1/2)',
        'method': 'class',
      },
      'temperature_K': {
        'type': numbers.Real,
        'units': 'K',
        'method': 'class',
      },
      'taut': {
        'type': numbers.Real,
        'units': 'angstrom * (amu / eV ) ** (1/2)',
        'method': 'class',
      },
      'fixcm': {
        'default': True,
        'type': bool,
        'units': None,
        'method': 'class',
      },
    }
  },
  'NPTBerendsen': {
    'module': 'ase.md.nptberendsen',
    'class': 'NPTBerendsen',
    'otype': 'algorithm',
    'requires_dof': True,
    'many_to_one': False,
    'calc_task': ['single point'],
    'properties': ['trajectory'],
    'params': {
      'steps': {
        'default': ureg.Quantity(50),
        'type': numbers.Integral,
        'units': 'dimensionless',
        'method': 'run',
      },
      'logfile': {
        'default': NA,
        'type': bool,
        'units': None,
        'method': 'class',
      },
      'trajectory': {
        'default': NA,
        'type': bool,
        'units': None,
        'method': 'class',
      },
      'interval': {
        'default': ureg.Quantity(1),
        'type': numbers.Integral,
        'units': 'dimensionless',
        'method': 'class',
      },
      'timestep': {
        'type': numbers.Real,
        'units': 'angstrom * (amu / eV ) ** (1/2)',
        'method': 'class',
      },
      'temperature_K': {
        'type': numbers.Real,
        'units': 'K',
        'method': 'class',
      },
      'pressure_au': {
        'type': numbers.Real,
        'units': 'eV / (angstrom ** 3)',
        'method': 'class',
      },
      'taut': {
        'default': ureg.Quantity(0.5, 'ps'),
        'type': numbers.Real,
        'units': 'angstrom * (amu / eV ) ** (1/2)',
        'method': 'class',
      },
      'taup': {
        'default': ureg.Quantity(1.0, 'ps'),
        'type': numbers.Real,
        'units': 'angstrom * (amu / eV ) ** (1/2)',
        'method': 'class',
      },
      'compressibility_au': {
        'type': numbers.Real,
        'units': 'angstrom ** 3 / eV',
        'method': 'class',
      },
      'fixcm': {
        'default': True,
        'type': bool,
        'units': None,
        'method': 'class',
      },
    }
  },
  'NEB': {
    'module': 'virtmat.language.utilities.ase_wrappers',
    'class': 'NudgedElasticBand',
    'otype': 'algorithm',
    'requires_dof': True,
    'many_to_one': True,
    'calc_task': ['single point'],
    'properties': ['neb_energy', 'forces', 'activation_energy', 'reaction_energy',
                   'maximum_force', 'trajectory'],
    'params': {
      'number_of_images': {
        'default': ureg.Quantity(3),
        'type': numbers.Integral,
        'units': 'dimensionless',
        'method': 'class',
      },
      'trajectory': {
        'default': True,
        'choices': [True],
        'type': bool,
        'units': None,
        'method': 'run',
      },
      'logfile': {
        'default': NA,
        'type': bool,
        'units': None,
        'method': 'run',
      },
      'interpolate_method': {
        'default': 'linear',
        'choices': ['linear', 'idpp'],
        'type': str,
        'units': None,
        'method': 'class',
      },
      'interpolate_mic': {
        'default': False,
        'type': bool,
        'units': None,
        'method': 'class',
      },
      'dynamic_relaxation': {
        'default': False,
        'type': bool,
        'units': None,
        'method': 'class',
      },
      'fmax': {
        'default': ureg.Quantity(0.05, 'eV/angstrom'),
        'type': numbers.Real,
        'units': 'eV/angstrom',
        'method': 'class',
      },
      'scale_fmax': {
        'default': ureg.Quantity(0.0, '1/angstrom'),
        'type': numbers.Real,
        'units': '1/angstrom',
        'method': 'class',
      },
      'k': {
        'default': ureg.Quantity(0.1, 'eV/angstrom'),
        'type': numbers.Real,
        'units': 'eV/angstrom',
        'method': 'class',
      },
      'climb': {
        'default': False,
        'type': bool,
        'units': None,
        'method': 'class',
      },
      'remove_rotation_and_translation': {
        'default': False,
        'type': bool,
        'units': None,
        'method': 'class',
      },
      'method': {
        'default': 'aseneb',
        'choices': ['aseneb', 'improvedtangent', 'eb', 'spline', 'string'],
        'type': str,
        'units': None,
        'method': 'class',
      },
      'optimizer': {
        'type': pandas.DataFrame,
        'otype': 'algorithm',
        'units': None,
        'method': 'run',
      },
      'fit': {
        'default': False,
        'type': bool,
        'units': None,
        'method': 'run',
      },
      'filename': {
        'default': NA,
        'type': str,
        'units': None,
        'method': 'run'
      }
    }
  },
  'Dimer': {
    'module': 'virtmat.language.utilities.ase_wrappers',
    'class': 'Dimer',
    'otype': 'algorithm',
    'requires_dof': True,
    'many_to_one': False,
    'calc_task': ['single point'],
    'properties': ['energy', 'forces', 'activation_energy', 'reaction_energy',
                   'maximum_force', 'trajectory'],
    'params': {
      'trajectory': {
        'default': NA,
        'type': bool,
        'units': None,
        'method': 'class',
      },
      'logfile': {
        'default': NA,
        'type': bool,
        'units': None,
        'method': 'class',
      },
      'eigenmode_logfile': {
        'default': NA,
        'type': str,
        'units': None,
        'method': 'class',
      },
      'eigenmode_method': {
        'default': 'dimer',
        'choices': ['dimer'],
        'type': str,
        'units': None,
        'method': 'class',
      },
      'f_rot_min': {
        'default': ureg.Quantity(0.1, 'eV/angstrom'),
        'type': numbers.Real,
        'units': 'eV/angstrom',
        'method': 'class',
      },
      'f_rot_max': {
        'default': ureg.Quantity(1.0, 'eV/angstrom'),
        'type': numbers.Real,
        'units': 'eV/angstrom',
        'method': 'class',
      },
      'max_num_rot': {
        'default': ureg.Quantity(1),
        'type': numbers.Integral,
        'units': 'dimensionless',
        'method': 'class',
      },
      'trial_angle': {
        'default': ureg.Quantity(math.pi/4.0, 'radians'),
        'type': numbers.Real,
        'units': 'radians',
        'method': 'class',
      },
      'trial_trans_step': {
        'default': ureg.Quantity(0.001, 'angstrom'),
        'type': numbers.Real,
        'units': 'angstrom',
        'method': 'class',
      },
      'maximum_translation': {
        'default': ureg.Quantity(0.1, 'angstrom'),
        'type': numbers.Real,
        'units': 'angstrom',
        'method': 'class',
      },
      'cg_translation': {
        'default': True,
        'type': bool,
        'units': None,
        'method': 'class',
      },
      'use_central_forces': {
        'default': True,
        'type': bool,
        'units': None,
        'method': 'class',
      },
      'dimer_separation': {
        'default': ureg.Quantity(0.0001, 'angstrom'),
        'type': numbers.Real,
        'units': 'angstrom',
        'method': 'class',
      },
      'initial_eigenmode_method': {
        'default': 'gauss',
        'choices': ['gauss', 'displacement'],
        'type': str,
        'units': None,
        'method': 'class',
      },
      'extrapolate_forces': {
        'default': False,
        'type': bool,
        'units': None,
        'method': 'class',
      },
      'displacement_method': {
        'default': 'gauss',
        'choices': ['gauss', 'vector'],
        'type': str,
        'units': None,
        'method': 'class',
      },
      'gauss_std': {
        'default': ureg.Quantity(0.1, 'angstrom'),
        'type': numbers.Real,
        'units': 'angstrom',
        'method': 'class',
      },
      'order': {
        'default': ureg.Quantity(1),
        'type': numbers.Integral,
        'units': 'dimensionless',
        'method': 'class',
      },
      'mask': {
        'default': NA,
        'type': numpy.ndarray,
        'units': None,
        'method': 'class',
      },
      'displacement_center': {
          'default': NA,
          'type': numpy.ndarray,
          'units': 'angstrom',
          'method': 'class'
      },
      'displacement_radius': {
          'default': NA,
          'type': numbers.Real,
          'units': 'angstrom',
          'method': 'class'
      },
      'number_of_displacement_atoms': {
          'default': NA,
          'type': numbers.Integral,
          'units': 'dimensionless',
          'method': 'class'
      },
      'target': {
        'default': NA,
        'type': object,  # cannot be checked, always true
        'units': None,
        'method': 'class',
      },
      'fmax': {
        'default': ureg.Quantity(0.05, 'eV / angstrom'),
        'type': numbers.Real,
        'units': 'eV / angstrom',
        'method': 'run',
      },
    }
  },
  'Vibrations': {
    'module': 'virtmat.language.utilities.ase_wrappers',
    'class': 'VibrationsWrapper',
    'otype': 'algorithm',
    'requires_dof': True,
    'many_to_one': False,
    'calc_task': ['single point'],
    'properties': ['hessian', 'vibrational_energies', 'vibrational_modes',
                   'energy_minimum', 'transition_state'],
    'params': {
      'delta': {
        'default': ureg.Quantity(0.01, 'angstrom'),
        'type': numbers.Real,
        'units': 'angstrom',
        'method': 'class',
      },
      'nfree': {
        'default': ureg.Quantity(2),
        'type': numbers.Integral,
        'units': 'dimensionless',
        'method': 'class',
      },
      'method': {
        'default': 'standard',
        'choices': ['standard', 'frederiksen'],
        'type': str,
        'units': None,
        'method': 'run',
      },
      'direction': {
        'default': 'central',
        'choices': ['central', 'forward', 'backward'],
        'type': str,
        'units': None,
        'method': 'run',
      },
      'all_atoms': {
        'default': False,
        'type': bool,
        'units': None,
        'method': 'run',
      },
      'imag_tol': {
        'default': ureg.Quantity(1e-5, 'eV'),
        'type': numbers.Real,
        'units': 'eV',
        'method': 'run',
      },
    }
  },
  'NeighborList': {
    'module': 'virtmat.language.utilities.ase_wrappers',
    'class': 'NeighborListWrapper',
    'otype': 'algorithm',
    'requires_dof': False,
    'many_to_one': False,
    'properties': ['neighbors', 'neighbor_offsets', 'connectivity_matrix',
                   'connected_components'],
    'params': {
      'cutoffs': {
        'default': NA,
        'type': numpy.ndarray,
        'units': 'angstrom',
        'method': 'class',
      },
      'skin': {
        'default': ureg.Quantity(0.3, 'angstrom'),
        'type': numbers.Real,
        'units': 'angstrom',
        'method': 'class',
      },
      'sorted': {
        'default': False,
        'type': bool,
        'units': None,
        'method': 'class',
      },
      'self_interaction': {
        'default': True,
        'type': bool,
        'units': None,
        'method': 'class',
      },
      'bothways': {
        'default': False,
        'type': bool,
        'units': None,
        'method': 'class',
      },
      'method': {
        'default': 'quadratic',
        'choices': ['quadratic', 'linear'],
        'type': str,
        'units': None,
        'method': 'class',
      },
    }
  },
  'bulk': {
    'module': 'ase.build',
    'class': 'bulk',
    'otype': 'builder',
    'params': {
      'name': {
        'type': str,
        'units': None,
      },
      'crystalstructure': {
        'type': str,
        'choices': ['sc', 'fcc', 'bcc', 'tetragonal', 'bct', 'hcp', 'rhombohedral',
                    'orthorhombic', 'mcl', 'diamond', 'zincblende', 'rocksalt',
                    'cesiumchloride', 'fluorite', 'wurtzite'],
        'units': None,
      },
      'a': {
        'default': NA,
        'type': numbers.Real,
        'units': 'angstrom',
      },
      'b': {
        'default': NA,
        'type': numbers.Real,
        'units': 'angstrom',
      },
      'c': {
        'default': NA,
        'type': numbers.Real,
        'units': 'angstrom',
      },
      'alpha': {
        'default': NA,
        'type': numbers.Real,
        'units': 'degrees',
      },
      'covera': {
        'default': NA,
        'type': numbers.Real,
        'units': 'dimensionless',
      },
      'u': {
        'default': NA,
        'type': numbers.Real,
        'units': 'angstrom',
      },
      'orthorhombic': {
        'default': False,
        'type': bool,
        'units': None,
      },
      'cubic': {
        'default': False,
        'type': bool,
        'units': None,
      },
    }
  },
  'molecule': {
    'module': 'ase.build',
    'class': 'molecule',
    'otype': 'builder',
    'params': {
      'name': {
        'type': str,
        'choices': g2.names+list(extra.keys()),
        'units': None,
      },
      'vacuum': {
        'default': NA,
        'type': numbers.Real,
        'units': 'angstrom',
      },
      'cell': {
        'default': NA,
        'type': numpy.ndarray,
        'units': 'angstrom',
      },
      'pbc': {
        'default': NA,
        'type': numpy.ndarray,
        'units': None,
      },
    }
  },
  'fcc100': {
    'module': 'ase.build',
    'class': 'fcc100',
    'otype': 'builder',
    'params': {
      'symbol': {
        'type': str,
        'choices': chemical_symbols,
        'units': None,
      },
      'size': {
        'type': numpy.ndarray,
        'units': 'dimensionless',
      },
      'a': {
        'default': NA,
        'type': numbers.Real,
        'units': 'angstrom',
      },
      'vacuum': {
        'default': NA,
        'type': numbers.Real,
        'units': 'angstrom',
      },
      'orthogonal': {
        'default': True,
        'type': bool,
        'units': None,
      },
      'periodic': {
        'default': False,
        'type': bool,
        'units': None,
      },
    }
  },
  'fcc110': {
    'module': 'ase.build',
    'class': 'fcc110',
    'otype': 'builder',
    'params': {
      'symbol': {
        'type': str,
        'choices': chemical_symbols,
        'units': None,
      },
      'size': {
        'type': numpy.ndarray,
        'units': 'dimensionless',
      },
      'a': {
        'default': NA,
        'type': numbers.Real,
        'units': 'angstrom',
      },
      'vacuum': {
        'default': NA,
        'type': numbers.Real,
        'units': 'angstrom',
      },
      'orthogonal': {
        'default': True,
        'type': bool,
        'units': None,
      },
      'periodic': {
        'default': False,
        'type': bool,
        'units': None,
      },
    }
  },
  'diamond100': {
    'module': 'ase.build',
    'class': 'diamond100',
    'otype': 'builder',
    'params': {
      'symbol': {
        'type': str,
        'choices': chemical_symbols,
        'units': None,
      },
      'size': {
        'type': numpy.ndarray,
        'units': 'dimensionless',
      },
      'a': {
        'default': NA,
        'type': numbers.Real,
        'units': 'angstrom',
      },
      'vacuum': {
        'default': NA,
        'type': numbers.Real,
        'units': 'angstrom',
      },
      'orthogonal': {
        'default': True,
        'type': bool,
        'units': None,
      },
      'periodic': {
        'default': False,
        'type': bool,
        'units': None,
      },
    }
  },
  'diamond111': {
    'module': 'ase.build',
    'class': 'diamond111',
    'otype': 'builder',
    'params': {
      'symbol': {
        'type': str,
        'choices': chemical_symbols,
        'units': None,
      },
      'size': {
        'type': numpy.ndarray,
        'units': 'dimensionless',
      },
      'a': {
        'default': NA,
        'type': numbers.Real,
        'units': 'angstrom',
      },
      'vacuum': {
        'default': NA,
        'type': numbers.Real,
        'units': 'angstrom',
      },
      'orthogonal': {
        'default': False,
        'type': bool,
        'units': None,
      },
      'periodic': {
        'default': False,
        'type': bool,
        'units': None,
      },
    }
  },
  'fcc111': {
    'module': 'ase.build',
    'class': 'fcc111',
    'otype': 'builder',
    'params': {
      'symbol': {
        'type': str,
        'choices': chemical_symbols,
        'units': None,
      },
      'size': {
        'type': numpy.ndarray,
        'units': 'dimensionless',
      },
      'a': {
        'default': NA,
        'type': numbers.Real,
        'units': 'angstrom',
      },
      'vacuum': {
        'default': NA,
        'type': numbers.Real,
        'units': 'angstrom',
      },
      'orthogonal': {
        'default': False,
        'type': bool,
        'units': None,
      },
      'periodic': {
        'default': False,
        'type': bool,
        'units': None,
      },
    }
  },
  'fcc211': {
    'module': 'ase.build',
    'class': 'fcc211',
    'otype': 'builder',
    'params': {
      'symbol': {
        'type': str,
        'choices': chemical_symbols,
        'units': None,
      },
      'size': {
        'type': numpy.ndarray,
        'units': 'dimensionless',
      },
      'a': {
        'default': NA,
        'type': numbers.Real,
        'units': 'angstrom',
      },
      'vacuum': {
        'default': NA,
        'type': numbers.Real,
        'units': 'angstrom',
      },
      'orthogonal': {
        'default': True,
        'choices': [True],
        'type': bool,
        'units': None,
      },
    }
  },
  'bcc100': {
    'module': 'ase.build',
    'class': 'bcc100',
    'otype': 'builder',
    'params': {
      'symbol': {
        'type': str,
        'choices': chemical_symbols,
        'units': None,
      },
      'size': {
        'type': numpy.ndarray,
        'units': 'dimensionless',
      },
      'a': {
        'default': NA,
        'type': numbers.Real,
        'units': 'angstrom',
      },
      'vacuum': {
        'default': NA,
        'type': numbers.Real,
        'units': 'angstrom',
      },
      'orthogonal': {
        'default': True,
        'type': bool,
        'units': None,
      },
      'periodic': {
        'default': False,
        'type': bool,
        'units': None,
      },
    }
  },
  'bcc110': {
    'module': 'ase.build',
    'class': 'bcc110',
    'otype': 'builder',
    'params': {
      'symbol': {
        'type': str,
        'choices': chemical_symbols,
        'units': None,
      },
      'size': {
        'type': numpy.ndarray,
        'units': 'dimensionless',
      },
      'a': {
        'default': NA,
        'type': numbers.Real,
        'units': 'angstrom',
      },
      'vacuum': {
        'default': NA,
        'type': numbers.Real,
        'units': 'angstrom',
      },
      'orthogonal': {
        'default': False,
        'type': bool,
        'units': None,
      },
      'periodic': {
        'default': False,
        'type': bool,
        'units': None,
      },
    }
  },
  'bcc111': {
    'module': 'ase.build',
    'class': 'bcc111',
    'otype': 'builder',
    'params': {
      'symbol': {
        'type': str,
        'choices': chemical_symbols,
        'units': None,
      },
      'size': {
        'type': numpy.ndarray,
        'units': 'dimensionless',
      },
      'a': {
        'default': NA,
        'type': numbers.Real,
        'units': 'angstrom',
      },
      'vacuum': {
        'default': NA,
        'type': numbers.Real,
        'units': 'angstrom',
      },
      'orthogonal': {
        'default': False,
        'type': bool,
        'units': None,
      },
      'periodic': {
        'default': False,
        'type': bool,
        'units': None,
      },
    }
  },
  'hcp10m10': {
    'module': 'ase.build',
    'class': 'hcp10m10',
    'otype': 'builder',
    'params': {
      'symbol': {
        'type': str,
        'choices': chemical_symbols,
        'units': None,
      },
      'size': {
        'type': numpy.ndarray,
        'units': 'dimensionless',
      },
      'a': {
        'default': NA,
        'type': numbers.Real,
        'units': 'angstrom',
      },
      'c': {
        'default': NA,
        'type': numbers.Real,
        'units': 'angstrom',
      },
      'vacuum': {
        'default': NA,
        'type': numbers.Real,
        'units': 'angstrom',
      },
      'orthogonal': {
        'default': True,
        'type': bool,
        'units': None,
      },
      'periodic': {
        'default': False,
        'type': bool,
        'units': None,
      },
    }
  },
  'hcp0001': {
    'module': 'ase.build',
    'class': 'hcp0001',
    'otype': 'builder',
    'params': {
      'symbol': {
        'type': str,
        'choices': chemical_symbols,
        'units': None,
      },
      'size': {
        'type': numpy.ndarray,
        'units': 'dimensionless',
      },
      'a': {
        'default': NA,
        'type': numbers.Real,
        'units': 'angstrom',
      },
      'c': {
        'default': NA,
        'type': numbers.Real,
        'units': 'angstrom',
      },
      'vacuum': {
        'default': NA,
        'type': numbers.Real,
        'units': 'angstrom',
      },
      'orthogonal': {
        'default': False,
        'type': bool,
        'units': None,
      },
      'periodic': {
        'default': False,
        'type': bool,
        'units': None,
      },
    }
  },
  'mx2': {
    'module': 'ase.build',
    'class': 'mx2',
    'otype': 'builder',
    'params': {
      'formula': {
        'type': str,
        'default': 'MoS2',
        'units': None,
      },
      'kind': {
        'default': '2H',
        'choices': ['2H', '1T'],
        'type': str,
        'units': None,
      },
      'a': {
        'default': ureg.Quantity(3.18, 'angstrom'),
        'type': numbers.Real,
        'units': 'angstrom',
      },
      'thickness': {
        'default': ureg.Quantity(3.19, 'angstrom'),
        'type': numbers.Real,
        'units': 'angstrom',
      },
      'size': {
        'type': numpy.ndarray,
        'default': numpy.array([1, 1, 1]),
        'units': 'dimensionless',
      },
      'vacuum': {
        'default': NA,
        'type': numbers.Real,
        'units': 'angstrom',
      },
    }
  },
  'graphene': {
    'module': 'ase.build',
    'class': 'graphene',
    'otype': 'builder',
    'params': {
      'formula': {
        'type': str,
        'default': 'C2',
        'units': None,
      },
      'a': {
        'default': ureg.Quantity(2.46, 'angstrom'),
        'type': numbers.Real,
        'units': 'angstrom',
      },
      'thickness': {
        'default': ureg.Quantity(0.0, 'angstrom'),
        'type': numbers.Real,
        'units': 'angstrom',
      },
      'size': {
        'type': numpy.ndarray,
        'default': numpy.array([1, 1, 1]),
        'units': 'dimensionless',
      },
      'vacuum': {
        'default': NA,
        'type': numbers.Real,
        'units': 'angstrom',
      },
    }
  },
  'nanotube': {
    'module': 'ase.build',
    'class': 'nanotube',
    'otype': 'builder',
    'params': {
      'n': {
        'type': numbers.Integral,
        'units': 'dimensionless',
      },
      'm': {
        'type': numbers.Integral,
        'units': 'dimensionless',
      },
      'length': {
        'default': ureg.Quantity(1),
        'type': numbers.Integral,
        'units': 'dimensionless',
      },
      'bond': {
        'default': ureg.Quantity(1.42, 'angstrom'),
        'type': numbers.Real,
        'units': 'angstrom',
      },
      'symbol': {
        'default': 'C',
        'choices': chemical_symbols,
        'type': str,
        'units': None,
      },
      'verbose': {
        'type': bool,
        'default': False,
        'units': None,
      },
      'vacuum': {
        'default': NA,
        'type': numbers.Real,
        'units': 'angstrom',
      },
    }
  },
  'graphene_nanoribbon': {
    'module': 'ase.build',
    'class': 'graphene_nanoribbon',
    'otype': 'builder',
    'params': {
      'n': {
        'type': numbers.Integral,
        'units': 'dimensionless',
      },
      'm': {
        'type': numbers.Integral,
        'units': 'dimensionless',
      },
      'type': {
        'default': 'zigzag',
        'choices': ['zigzag', 'armchair'],
        'type': str,
        'units': None,
      },
      'saturated': {
        'type': bool,
        'default': False,
        'units': None,
      },
      'C_H': {
        'default': ureg.Quantity(1.09, 'angstrom'),
        'type': numbers.Real,
        'units': 'angstrom',
      },
      'C_C': {
        'default': ureg.Quantity(1.42, 'angstrom'),
        'type': numbers.Real,
        'units': 'angstrom',
      },
      'vacuum': {
        'default': NA,
        'type': numbers.Real,
        'units': 'angstrom',
      },
      'magnetic': {
        'default': False,
        'type': bool,
        'units': None,
      },
      'initial_mag': {
        'default': ureg.Quantity(1.12, MAGMOM_AU),
        'type': numbers.Real,
        'units': MAGMOM_AU,
      },
      'sheet': {
        'default': False,
        'type': bool,
        'units': None,
      },
      'main_element': {
        'default': 'C',
        'choices': chemical_symbols,
        'type': str,
        'units': None,
      },
      'saturate_element': {
        'default': 'H',
        'choices': chemical_symbols,
        'type': str,
        'units': None,
      },
    }
  },
  'repeat': {
    'module': 'virtmat.language.utilities.ase_wrappers',
    'class': 'repeat',
    'otype': 'build tool',
    'params': {
      'rep': {
        'type': list,
        'units': None,
      },
    }
  },
  'center': {
    'module': 'virtmat.language.utilities.ase_wrappers',
    'class': 'center',
    'otype': 'build tool',
    'params': {
      'vacuum': {
        'type': numbers.Real,
        'default': NA,
        'units': 'angstrom',
      },
      'axis': {
        'type': list,
        'default': (ureg.Quantity(0), ureg.Quantity(1), ureg.Quantity(2)),
        'units': None,
      },
      'about': {
        'type': numpy.ndarray,
        'default': NA,
        'units': 'angstrom',
      },
    }
  },
  'translate': {
    'module': 'virtmat.language.utilities.ase_wrappers',
    'class': 'translate',
    'otype': 'build tool',
    'params': {
      'displacement': {
        'type': numpy.ndarray,
        'units': 'angstrom',
      },
    }
  },
  'rotate': {
    'module': 'virtmat.language.utilities.ase_wrappers',
    'class': 'rotate',
    'otype': 'build tool',
    'params': {
      'a': {
        'type': (numpy.ndarray, numbers.Real),
        'units': 'dimensionless',
      },
      'v': {
        'type': numpy.ndarray,
        'units': 'dimensionless',
      },
      'center': {
        'default': numpy.array([0, 0, 0]),
        'type': numpy.ndarray,
        'units': 'angstrom',
      },
      'rotate_cell': {
        'default': False,
        'type': bool,
        'units': None,
      },
    }
  },
  'euler_rotate': {
    'module': 'virtmat.language.utilities.ase_wrappers',
    'class': 'euler_rotate',
    'otype': 'build tool',
    'params': {
      'phi': {
        'default': ureg.Quantity(0.0, 'deg'),
        'type': numbers.Real,
        'units': 'deg',
      },
      'theta': {
        'default': ureg.Quantity(0.0, 'deg'),
        'type': numbers.Real,
        'units': 'deg',
      },
      'psi': {
        'default': ureg.Quantity(0.0, 'deg'),
        'type': numbers.Real,
        'units': 'deg',
      },
      'center': {
        'default': numpy.array([0, 0, 0]),
        'type': numpy.ndarray,
        'units': 'angstrom',
      },
    }
  },
  'rattle': {
    'module': 'virtmat.language.utilities.ase_wrappers',
    'class': 'rattle',
    'otype': 'build tool',
    'params': {
      'stdev': {
        'default': ureg.Quantity(0.001, 'angstrom'),
        'type': numbers.Real,
        'units': 'angstrom',
      },
      'seed': {
        'default': NA,
        'type': numbers.Integral,
        'units': 'dimensionless',
      },
      'rng': {
        'default': NA,
        'type': types.ModuleType,
        'units': None,
      },
    }
  },
  'wrap': {
    'module': 'virtmat.language.utilities.ase_wrappers',
    'class': 'wrap',
    'otype': 'build tool',
    'params': {
      'pbc': {
        'default': numpy.array([True, True, True]),
        'type': numpy.ndarray,
        'units': None,
      },
      'center': {
        'default': numpy.array([0.5, 0.5, 0.5]),
        'type': numpy.ndarray,
        'units': 'dimensionless',
      },
      'pretty_translation': {
        'default': False,
        'type': bool,
        'units': None,
      },
      'eps': {
        'default': ureg.Quantity(1e-07, 'angstrom'),
        'type': numbers.Real,
        'units': 'angstrom',
      },
    }
  },
  'cut': {
    'module': 'ase.build',
    'class': 'cut',
    'otype': 'build tool',
    'params': {
      'a': {
        'default': numpy.array([1, 0, 0]),
        'type': (numbers.Integral, numpy.ndarray),
        'units': 'dimensionless',
      },
      'b': {
        'default': numpy.array([0, 1, 0]),
        'type': (numbers.Integral, numpy.ndarray),
        'units': 'dimensionless',
      },
      'c': {
        'default': NA,
        'type': (numbers.Integral, numpy.ndarray),
        'units': 'dimensionless',
      },
      'clength': {
        'default': NA,
        'type': numbers.Real,
        'units': 'angstrom',
      },
      'origo': {
        'default': numpy.array([0, 0, 0]),
        'type': (numbers.Integral, numpy.ndarray),
        'units': 'dimensionless',
      },
      'nlayers': {
        'default': NA,
        'type': numbers.Integral,
        'units': 'dimensionless',
      },
      'extend': {
        'default': ureg.Quantity(1.0),
        'type': (numbers.Real, numpy.ndarray),
        'units': 'dimensionless',
      },
      'tolerance': {
        'default': ureg.Quantity(0.01, 'angstrom'),
        'type': numbers.Real,
        'units': 'angstrom',
      },
      'maxatoms': {
        'default': NA,
        'type': numbers.Integral,
        'units': 'dimensionless',
      },
    }
  },
  'stack': {
    'module': 'ase.build',
    'class': 'stack',
    'otype': 'build tool 2',
    'params': {
      'axis': {
        'default': ureg.Quantity(2),
        'type': numbers.Integral,
        'choices': [ureg.Quantity(0), ureg.Quantity(1), ureg.Quantity(2)],
        'units': 'dimensionless',
      },
      'cell': {
        'default': NA,
        'type': numpy.ndarray,
        'units': 'angstrom',
      },
      'fix': {
        'default': ureg.Quantity(0.5),
        'type': numbers.Real,
        'units': 'dimensionless',
      },
      'fmaxstrain': {
        'default': ureg.Quantity(0.5),
        'type': numbers.Real,
        'units': 'dimensionless',
      },
      'distance': {
        'default': NA,
        'type': numbers.Real,
        'units': 'angstrom',
      },
      'reorder': {
        'default': False,
        'type': bool,
        'units': None,
      },
      'output_strained': {
        'default': False,
        'type': bool,
        'units': None,
      },
    }
  },
  'sort': {
    'module': 'ase.build',
    'class': 'sort',
    'otype': 'build tool',
    'params': {
      'tags': {
        'default': NA,
        'type': numpy.ndarray,
        'units': 'dimensionless',
      },
    }
  },
  'niggli_reduce': {
    'module': 'virtmat.language.utilities.ase_wrappers',
    'class': 'niggli_reduce',
    'otype': 'build tool',
    'params': {}
  },
  'minimize_tilt': {
    'module': 'virtmat.language.utilities.ase_wrappers',
    'class': 'minimize_tilt',
    'otype': 'build tool',
    'params': {
      'order': {
        'default': numpy.array([0, 1, 2]),
        'type': numpy.ndarray,
        'units': 'dimensionless',
      },
      'fold_atoms': {
        'default': True,
        'type': bool,
        'units': None,
      },
    }
  },
  'minimize_rotation_and_translation': {
    'module': 'virtmat.language.utilities.ase_wrappers',
    'class': 'minimize_rotation_and_translation',
    'otype': 'build tool 2',
    'params': {}
  },
  'add_adsorbate_at_site': {
    'module': 'virtmat.language.utilities.ase_wrappers',
    'class': 'add_adsorbate',
    'otype': 'build tool 2',
    'params': {
      'height': {
        'type': numbers.Real,
        'units': 'angstrom',
      },
      'position': {
        'choices': ['ontop', 'bridge', 'hollow', 'longbridge', 'shortbridge',
                    'fcc', 'hcp'],
        'type': str,
        'units': None,
      },
      'offset': {
        'default': NA,
        'type': numpy.ndarray,
        'units': 'dimensionless',
      },
      'mol_index': {
        'default': 0,
        'type': numbers.Integral,
        'units': 'dimensionless',
      },
    }
  },
  'add_adsorbate_at_position': {
    'module': 'virtmat.language.utilities.ase_wrappers',
    'class': 'add_adsorbate',
    'otype': 'build tool 2',
    'params': {
      'height': {
        'type': numbers.Real,
        'units': 'angstrom',
      },
      'position': {
        'default': numpy.array([0., 0.]),
        'type': numpy.ndarray,
        'units': 'angstrom',
      },
      'offset': {
        'default': NA,
        'type': numpy.ndarray,
        'units': 'dimensionless',
      },
      'mol_index': {
        'default': 0,
        'type': numbers.Integral,
        'units': 'dimensionless',
      },
    }
  },
  'add_vacuum': {
    'module': 'virtmat.language.utilities.ase_wrappers',
    'class': 'add_vacuum',
    'otype': 'build tool',
    'params': {
      'vacuum': {
        'type': numbers.Real,
        'units': 'angstrom'
      },
    }
  },
  'surface_from_bulk': {
    'module': 'ase.build',
    'class': 'surface',
    'otype': 'build tool',
    'params': {
      'indices': {
        'type': numpy.ndarray,
        'units': 'dimensionless'
      },
      'layers': {
        'type': numbers.Integral,
        'units': 'dimensionless'
      },
      'vacuum': {
        'default': NA,
        'type': numbers.Real,
        'units': 'angstrom'
      },
      'tol': {
        'default': 1e-10,
        'type': numbers.Real,
        'units': 'dimensionless'
      },
      'periodic': {
        'default': False,
        'type': bool,
        'units': None
      },
    }
  },
  'surface_from_string': {
    'module': 'ase.build',
    'class': 'surface',
    'otype': 'builder',
    'params': {
      'lattice': {
        'type': str,
        'units': None
      },
      'indices': {
        'type': numpy.ndarray,
        'units': 'dimensionless'
      },
      'layers': {
        'type': numbers.Integral,
        'units': 'dimensionless'
      },
      'vacuum': {
        'default': NA,
        'type': numbers.Real,
        'units': 'angstrom'
      },
      'tol': {
        'default': 1e-10,
        'type': numbers.Real,
        'units': 'dimensionless'
      },
      'periodic': {
        'default': False,
        'type': bool,
        'units': None
      },
    }
  },
  'make_supercell': {
    'module': 'ase.build',
    'class': 'make_supercell',
    'otype': 'build tool',
    'params': {
      'P': {
        'type': numpy.ndarray,
        'units': 'dimensionless'
      },
      'wrap': {
        'default': True,
        'type': bool,
        'units': None
      },
      'order': {
        'type': str,
        'default': 'cell-major',
        'choices': ['cell-major', 'atom-major'],
        'units': None
      },
      'tol': {
        'default': 1e-5,
        'type': numbers.Real,
        'units': 'angstrom'
      },
    }
  },
}

for calc in ('vasp', 'turbomole', 'lj', 'lennardjones', 'emt', 'free_electrons', 'elk'):
    spec[calc]['params'] = {}
    spec[calc]['otype'] = 'calculator'
    spec[calc]['tasks'] = calc_tasks[calc]
    for key in calc_pars_units[calc].keys():
        _par = {'units': calc_pars_units[calc][key], 'type': calc_pars_types[calc][key]}
        if calc in calc_pars_defaults and key in calc_pars_defaults[calc]:
            _par['default'] = calc_pars_defaults[calc][key]
        if calc in calc_pars_choices and key in calc_pars_choices[calc]:
            _par['choices'] = calc_pars_choices[calc][key]
        spec[calc]['params'][key] = _par

par_units = {c: {k: v['units'] for k, v in u['params'].items()} for c, u in spec.items()}


def check_params_types(name, parameters):
    """check types of calculator and algorithm parameters (dynamic check)"""
    for par_ in parameters.columns:
        ptype = spec[name]['params'][par_]['type']
        if isinstance(ptype, tuple):
            ptype_r = ' or '.join(formatter(t) for t in ptype)
        else:
            ptype_r = formatter(ptype)
        method = spec[name]['otype']
        msg = f"Invalid parameter type in {method} '{name}': '{par_}' must be {ptype_r}"
        if not any(v is NA for v in parameters[par_]):
            for val in parameters[par_]:
                if is_numeric_scalar(val) or is_numeric_array(val):
                    if not isinstance(val.magnitude, ptype):
                        raise RuntimeTypeError(msg)  # not covered
                elif isinstance(val, ScalarBoolean):
                    if isinstance(ptype, tuple):
                        if bool not in ptype:
                            raise RuntimeTypeError(msg)  # not covered
                    elif ptype is not bool:
                        raise RuntimeTypeError(msg)  # not covered
                elif not isinstance(val, ptype):
                    raise RuntimeTypeError(msg)


def get_par_units(name, par, val):
    """auxiliary function to get the units of a calculator parameter"""
    params = par_units[name]
    try:
        par_def = params[par]
    except KeyError as err:  # not covered
        msg = f'parameter \"{par}\" has unknown units'
        raise InvalidUnitError(msg) from err
    if isinstance(par_def, types.FunctionType):
        return par_def(val)
    return par_def


def get_params_units(calc_name, params):
    """auxiliary function to get the units for a parameters dictionary"""
    units = {}
    for param, value in params.items():
        r_units = get_par_units(calc_name, param, value)
        if isinstance(r_units, list):
            r_units = [r(params) for r in r_units]
            r_units = next(r for r in r_units if r is not None)
        units[param] = r_units
    return units


def get_params_magnitudes(calc_params, calc_name):
    """converts parameters to canonical units and return their magnitudes"""

    def magnitude_from_quantity(q_, u_):
        rval = q_.to(u_).magnitude
        if isinstance(rval, numpy.generic):  # case: h2o_tm_res.vm:18
            return getattr(rval, 'item', lambda: rval)()
        return rval

    def magnitudes_from_list(unit, value):  # not covered
        return list_apply(lambda x: magnitude_from_quantity(x, unit), value)

    units = get_params_units(calc_name, calc_params)

    magnitudes = {}
    for par, val in calc_params.items():
        try:
            if isinstance(val, ureg.Quantity):
                magnitudes[par] = magnitude_from_quantity(val, units[par])
            elif isinstance(val, numpy.ndarray):  # not covered
                if issubclass(val.dtype.type, (numpy.bool_, numpy.str_)):
                    magnitudes[par] = val
                else:
                    assert issubclass(val.dtype.type, numpy.object_)
                    magnitudes[par] = magnitudes_from_list(units[par], val.tolist())
            elif isinstance(val, pandas.DataFrame):
                assert issubclass(pandas.DataFrame, spec[calc_name]['params'][par]['type'])
                if len(val) == 1:
                    dct = dict(next(val.iterrows())[1])
                    if ('otype' in spec[calc_name]['params'][par] and
                       spec[calc_name]['params'][par]['otype'] == 'algorithm'):
                        if 'parameters' in dct and dct['parameters'] is not None:
                            dct_ = dict(next(dct['parameters'].iterrows())[1])  # not covered
                        else:
                            dct_ = {}
                        dct['parameters'] = get_params_magnitudes(dct_, dct['name'])
                        magnitudes[par] = dct
                    else:
                        magnitudes[par] = get_params_magnitudes(dct, calc_name)
                else:  # not covered
                    assert len(val) == 0
                    magnitudes[par] = {}
            elif isinstance(val, (list, tuple)):
                magnitudes[par] = []
                for elem in val:
                    if isinstance(elem, ureg.Quantity):
                        magnitudes[par].append(convert_to_ase_units(elem).magnitude)
                    else:
                        magnitudes[par].append(elem)  # not covered
            elif val is NA:
                magnitudes[par] = None
            else:
                magnitudes[par] = val
        except pint.DimensionalityError as err:
            msg = (f'error with units of parameter \"{par}\": '
                   f'must be [{units[par]}] instead of [{val.units}]')
            raise InvalidUnitError(msg) from err
    return magnitudes


def check_params_units(name, parameters):
    """run-time check units of calculator and algorithm parameters"""
    for _, row in parameters.iterrows():
        get_params_magnitudes(dict(row), name)


def check_params_values(name, parameters):
    """run-time check string and integer parameters with finite number of valid choices"""
    choices = {p: v['choices'] for p, v in spec[name]['params'].items() if 'choices' in v}
    for pname in [p for p in parameters.columns if p in choices]:
        if not all(val in choices[pname] for val in parameters[pname] if val is not NA):
            invalid = next(v for v in parameters[pname] if v not in choices[pname])
            msg = (f"Parameter '{pname}' in {spec[name]['otype']} '{name}' "
                   f"should be one of {formatter(choices[pname])} but is '{invalid}'")
            raise RuntimeValueError(msg)


def check_params_invalid(name, parameters):
    """run-time check for invalid parameter names"""
    if not all(p in spec[name]['params'] for p in parameters.columns):
        inv_pars = tuple(p for p in parameters.columns if p not in spec[name]['params'])
        msg = f"Invalid parameters used in {spec[name]['otype']} '{name}': {formatter(inv_pars)}"
        raise RuntimeValueError(msg)


def check_params_mandatory(name, parameters):
    """run-time check for missing mandatory parameters"""
    par_mandatory = [k for k, v in spec[name]['params'].items() if 'default' not in v]
    if not all(p in parameters.columns for p in par_mandatory):
        inv_pars = tuple(p for p in par_mandatory if p not in parameters.columns)
        msg = f"Mandatory parameters missing in {spec[name]['otype']} '{name}': {inv_pars}"
        raise RuntimeValueError(msg)
