"""context management utility functions"""
import contextlib
import os
from tempfile import TemporaryDirectory
from fireworks.utilities.fw_utilities import create_datestamp_dir
from virtmat.middleware.utilities import module_cmd, module_load
from virtmat.middleware.exceptions import ResourceConfigurationError
from virtmat.middleware.resconfig import get_inactive_modules, get_inactive_envs
from virtmat.middleware.resconfig import get_worker_config
from virtmat.language.utilities import logging
from virtmat.language.utilities.warnings import warnings, TextSUserWarning


@contextlib.contextmanager
def launchdir(tmp_dir):
    """switch to a launch directory temporarily"""
    init_dir = os.getcwd()
    os.chdir(tmp_dir)
    try:
        yield
    finally:
        os.chdir(init_dir)


@contextlib.contextmanager
def setenv(varname, value):
    """set or change an environment variable temporarily"""
    var_bck = os.environ.get(varname)
    os.environ[varname] = str(value)
    try:
        yield
    finally:
        if var_bck is None:
            del os.environ[varname]
        else:
            os.environ[varname] = var_bck


@contextlib.contextmanager
def temp_environ():  # not covered
    """backup the current os.environ and create a context"""
    env_bck = os.environ.copy()
    try:
        yield
    finally:
        os.environ = env_bck


def in_temp_environ(func, env_dict):  # not covered
    """setup a temporary environment and perform a func evaluation there"""
    def decorator(*args, **kwargs):
        logger = logging.get_logger(__name__)
        with temp_environ():
            for mod in env_dict['modules']:
                logger.info(' loading module %s', mod)
                if mod.get('path'):
                    module_cmd('use', path=mod.pop('path'))
                module_load(**mod)
            for key, val in env_dict['envs'].items():
                logger.info(' setting variable %s: %s', key, val)
                if val is None:
                    del os.environ[key]
                else:
                    os.environ[key] = val
            return func(*args, **kwargs)
    return decorator


def setup_environ(func, res):
    """activate resources (modules, envvars) as needed and evaluate func"""
    def decorator(*args, **kwargs):
        logger = logging.get_logger(__name__)
        if not res['modules'] and not res['envs']:
            return func(*args, **kwargs)
        try:
            wcfg = get_worker_config()
            mods_inactive = get_inactive_modules(wcfg, **res['modules'])
            envs_inactive = get_inactive_envs(wcfg, **res['envs'])
        except ResourceConfigurationError as err:
            warnings.warn(TextSUserWarning(str(err)))
            logger.warning(' %s', err)
        else:
            if mods_inactive or envs_inactive:
                env_dict = {'modules': mods_inactive, 'envs': envs_inactive}
                logger.debug(' modules and envs to activate: %s', env_dict)
                return in_temp_environ(func, env_dict)(*args, **kwargs)
        logger.debug(' no changes needed in environment')
        return func(*args, **kwargs)
    return decorator


def in_unique_launchdir(func):
    """evaluate a function with file I/O in a temporary launch directory"""
    def decorator(*args, **kwargs):
        if os.environ.get('WORKFLOW_EVALUATION_MODE') == 'yes':
            return func(*args, **kwargs)

        def _launcher(logger, tmpdir):
            logger.debug('launchdir: %s', tmpdir)
            with launchdir(tmpdir):
                return func(*args, **kwargs)

        logger = logging.get_logger(__name__)
        if logging.LOGGING_LEVEL == logging.get_logging_level('DEBUG'):  # not covered
            tmpdir = create_datestamp_dir(os.getcwd(), logger, prefix='debug_')
            return _launcher(logger, tmpdir)
        with TemporaryDirectory() as tmpdir:
            return _launcher(logger, tmpdir)
    return decorator
