"""
unit tests for amml objects
"""
import numpy
import pandas
import pint_pandas
import pytest
import virtmat.language.utilities.ase_handlers as aseh
from ase import units
from ase.atoms import Atoms
from ase.calculators.singlepoint import SinglePointDFTCalculator, SinglePointKPoint
from pint import Quantity
from virtmat.language.utilities.ase_wrappers import DensityOfStates
from virtmat.language.utilities.units import ureg


class MockCalcVASP:
    """class to mimic a VASP calc object"""
    def __init__(self, vib_freq_real, vib_freq_img):
        self._vib_freq_real = vib_freq_real
        self._vib_freq_img = vib_freq_img

    def read_vib_freq(self):
        """class method to read vibrational frequencies"""
        return [self._vib_freq_real, self._vib_freq_img]


class MockCalcTM:
    """class to mock a Turbomole calc object"""
    def __init__(self, results):
        self.results = results


@pytest.fixture(name='vasp_results')
def mock_vasp_vibrational_results():
    """Fixture for mock VASP vibrational freq. results"""
    return [
        {'calc': MockCalcVASP([50.0, 100.0, 150.0], [-200.0])}  # in meV
    ]


@pytest.fixture(name='vasp_emin')
def mock_vasp_vibrational_emin():
    """Fixture to mock VASP normal modes of an energy minimum"""
    return [
        {'calc': MockCalcVASP([50.0, 100.0, 150.0, 200.0], [])}  # in meV
    ]


@pytest.fixture(name='vasp_bad_ts')
def mock_vasp_vibrational_bad_ts():
    """Fixture to mock VASP normal modes w/2 imaginary freqs"""
    return [
        {'calc': MockCalcVASP([50.0, 100.0], [-200.0, -150.0])}  # in meV
    ]


@pytest.fixture(name='tm_results')
def mock_tm_results():
    """Fixture for mock Turbomole results"""
    return [
        {
            'calc': MockCalcTM({
                    'electric dipole moment': {
                        'absolute value': {'value': 2.144309, 'units': 'debye'},
                        'vector': {'array': [0.596536, 0.596536, -2.4e-14], 'units': 'a.u.'}
                    },
                    'vibrational spectrum': [
                        {'irreducible representation': 'A',  # negative freq., skipped
                         'frequency': {'value': -200.0, 'units': 'cm^-1'}},
                        {'irreducible representation': 'A',
                         'frequency': {'value': 1605.13, 'units': 'cm^-1'}},
                        {'irreducible representation': '',  # no irrep, skipped
                         'frequency': {'value': 3526.96, 'units': 'cm^-1'}},
                        {'irreducible representation': 'A',
                         'frequency': {'value': 3641.33, 'units': 'cm^-1'}}
                    ]
            })
        }
    ]


@pytest.fixture(name='tm_emin')
def mock_tm_results_emin():
    """Fixture to mock Turbomole normal modes of an energy minimum"""
    return [
        {
            'calc': MockCalcTM({
                    'vibrational spectrum': [
                        {'irreducible representation': 'A1',
                         'frequency': {'value': 200.0, 'units': 'cm^-1'}},
                        {'irreducible representation': 'B2',
                         'frequency': {'value': 500.0, 'units': 'cm^-1'}},
                        {'irreducible representation': 'A1',
                         'frequency': {'value': 1500.0, 'units': 'cm^-1'}}
                    ]
            })
        }
    ]


@pytest.fixture(name='tm_bad_ts')
def mock_tm_results_bad_ts():
    """Fixture to mock Turbomole normal modes with 2 imag. frequencies"""
    return [
        {
            'calc': MockCalcTM({
                    'vibrational spectrum': [
                        {'irreducible representation': 'A',
                         'frequency': {'value': -250.0, 'units': 'cm^-1'}},
                        {'irreducible representation': 'A',
                         'frequency': {'value': -500.0, 'units': 'cm^-1'}},
                        {'irreducible representation': 'A',
                         'frequency': {'value': 1500.0, 'units': 'cm^-1'}}
                    ]
            })
        }
    ]


@pytest.fixture(name='ase_kpts')
def ase_atoms_with_kpts():
    """Fixture to mock atoms with kpoints required by ASE's DOS class"""
    atoms = Atoms('H')
    efermi = [0, 1]
    kpts = [SinglePointKPoint(1, 0, 0), SinglePointKPoint(1, 1, 0)]
    kpts[0].eps_n = [-2, -1, 1]
    kpts[0].f_n = [1, 0, 0]
    kpts[1].eps_n = [-2.5, -1.5, 0.5]
    kpts[1].f_n = [1, 0, 0]
    calc = SinglePointDFTCalculator(atoms, energy=0.0, efermi=efermi)
    calc.kpts = kpts
    atoms.calc = calc
    return atoms


def test_vasp_vibrational_energies_handler(vasp_results):
    """test VASP handler function for vibrational energies from normal modes"""
    series = aseh.vasp_vibrational_energies_handler(vasp_results)
    assert isinstance(series, pandas.Series)
    assert len(series) == len(vasp_results)
    vib_ener = series.iloc[0]
    assert isinstance(vib_ener, pandas.Series)
    assert vib_ener.name == 'vibrational_energies'
    assert isinstance(vib_ener.dtype, pint_pandas.PintType)
    assert vib_ener.dtype.units == 'electron_volt'
    expected_vals = numpy.array([50.0, 100.0, 150.0]) * 1.0e-3  # 3 real freqs.
    for val, expected in zip(vib_ener.values, expected_vals):
        assert pytest.approx(val.magnitude, rel=1e-6) == expected


def test_vasp_energy_minimum_handler(vasp_emin):
    """test VASP handler function to determine Emin from normal modes"""
    series = aseh.vasp_energy_minimum_handler(vasp_emin)
    assert isinstance(series, pandas.Series)
    assert len(series) == len(vasp_emin)
    assert bool(series.iloc[0]) is True  # only real modes


def test_vasp_energy_minimum_handler_with_ts(vasp_results):
    """test VASP energy minimum handler function with a TS"""
    series = aseh.vasp_energy_minimum_handler(vasp_results)
    assert isinstance(series, pandas.Series)
    assert len(series) == len(vasp_results)
    assert bool(series.iloc[0]) is False  # TS w/1 imagninary mode


def test_vasp_transition_state_handler(vasp_results):
    """test VASP handler function to determine TS from normal modes"""
    series = aseh.vasp_transition_state_handler(vasp_results)
    assert isinstance(series, pandas.Series)
    assert len(series) == len(vasp_results)
    assert bool(series.iloc[0]) is True  # one imaginary mode


def test_vasp_ts_handler_with_energy_min(vasp_emin):
    """test VASP TS handler function with energy minimum"""
    series = aseh.vasp_transition_state_handler(vasp_emin)
    assert isinstance(series, pandas.Series)
    assert len(series) == len(vasp_emin)
    assert bool(series.iloc[0]) is False  # an energy minimum


def test_vasp_ts_handler_with_invalid_ts(vasp_bad_ts):
    """test VASP TS handler function with invalid TS"""
    series = aseh.vasp_transition_state_handler(vasp_bad_ts)
    assert isinstance(series, pandas.Series)
    assert len(series) == len(vasp_bad_ts)
    assert bool(series.iloc[0]) is False  # invalid TS w/2 imag. modes


def test_tm_dipole_handler(tm_results):
    """test handler function for TM electric dipole moment"""
    ec_bohr = 'elementary_charge * bohr'
    series = aseh.tm_dipole_handler(tm_results)
    assert isinstance(series, pandas.Series)
    assert len(series) == len(tm_results)
    dip_vec = series.iloc[0]
    assert isinstance(dip_vec, Quantity)
    assert dip_vec.check('[length] * [charge]')
    assert dip_vec.units == ureg(ec_bohr).units
    dip_vec_d = dip_vec.to('D')
    assert dip_vec_d.units == 'debye'
    dip_norm_d = numpy.linalg.norm(dip_vec_d.magnitude)
    expect = tm_results[0]['calc'].results['electric dipole moment']['absolute value']['value']
    assert dip_norm_d == pytest.approx(expect, rel=1e-3)


def test_tm_vibrational_energies_handler(tm_results):
    """test handler function for vibrational energies from TM normal modes"""
    series = aseh.tm_vibrational_energies_handler(tm_results)
    assert isinstance(series, pandas.Series)
    assert len(series) == len(tm_results)
    vib_ener = series.iloc[0]
    assert isinstance(vib_ener, pandas.Series)
    assert vib_ener.name == 'vibrational_energies'
    assert all(vib_ener.index == [0, 1])  # only two valid modes
    assert isinstance(vib_ener.dtype, pint_pandas.PintType)
    assert vib_ener.dtype.units == 'electron_volt'
    expected_vals = [1605.13 * units.invcm, 3641.33 * units.invcm]
    for ven, expected in zip(vib_ener.values, expected_vals):
        assert pytest.approx(ven.magnitude, rel=1e-6) == expected
        assert ven.units == 'electron_volt'


def test_tm_energy_minimum_handler(tm_emin):
    """test handler function to determine Emin from TM normal modes"""
    series = aseh.tm_energy_minimum_handler(tm_emin)
    assert isinstance(series, pandas.Series)
    assert len(series) == len(tm_emin)
    assert bool(series.iloc[0]) is True  # no negative frequency


def test_tm_energy_minimum_handler_with_ts(tm_results):
    """test TM energy minimum handler function with a TS"""
    series = aseh.tm_energy_minimum_handler(tm_results)
    assert isinstance(series, pandas.Series)
    assert len(series) == len(tm_results)
    assert bool(series.iloc[0]) is False  # valid TS w/1 negative freq.


def test_tm_transition_state_handler(tm_results):
    """test handler function to determine TS from TM normal modes"""
    series = aseh.tm_transition_state_handler(tm_results)
    assert isinstance(series, pandas.Series)
    assert len(series) == len(tm_results)
    assert bool(series.iloc[0]) is True  # valid TS w/1 negative freq.


def test_tm_ts_handler_with_energy_min(tm_emin):
    """test Turbomole TS handler function with energy minimum"""
    series = aseh.tm_transition_state_handler(tm_emin)
    assert isinstance(series, pandas.Series)
    assert len(series) == len(tm_emin)
    assert bool(series.iloc[0]) is False  # an energy minimum


def test_tm_ts_handler_with_invalid_ts(tm_bad_ts):
    """test Turbomole TS handler function with invalid TS"""
    series = aseh.tm_transition_state_handler(tm_bad_ts)
    assert isinstance(series, pandas.Series)
    assert len(series) == len(tm_bad_ts)
    assert bool(series.iloc[0]) is False  # invalid TS w/2 negative freqs.


def test_density_of_states_wrapper(ase_kpts):
    """test wrapper algorithm to calculate the density of states"""
    dos_wrapper = DensityOfStates(ase_kpts)
    window = numpy.array([-3.0, 3.0])
    npts = 201
    width = 0.2
    dos_wrapper.run(width=width, window=window, npts=npts)
    assert isinstance(dos_wrapper.results, dict)
    assert set(dos_wrapper.results) == {"dos_energy", "dos"}
    d = dos_wrapper.results["dos"]
    e = dos_wrapper.results["dos_energy"]
    assert isinstance(d, numpy.ndarray) and isinstance(e, numpy.ndarray)
    assert len(d) == npts and len(e) == npts
    assert e[0] == pytest.approx(window[0])
    assert e[-1] == pytest.approx(window[1])
