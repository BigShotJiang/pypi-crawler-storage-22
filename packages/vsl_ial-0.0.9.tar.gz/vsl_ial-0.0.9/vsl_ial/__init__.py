import numpy as np
import numpy.typing as npt

__version__ = "0.0.9"
FArray = npt.NDArray[np.float32 | np.float64]
