Data as used in

Manuel Melgosa, Rafael Huertas, and Roy S. Berns,
Performance of recent advanced color-difference formulas using the standardized residual
sum of squares index,
Journal of the Optical Society of America A Vol. 25, Issue 7, pp. 1828-1834 (2008),
https://doi.org/10.1364/JOSAA.25.001828

The BFD-P data set is composed of BFD-D65, BFD-C, and BFD-M. Note that each of the three
data sets have their own reference white.
