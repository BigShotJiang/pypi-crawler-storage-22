from .eval import main


main()
