# VSM Rootkit Detector

VSM Rootkit Detector is an educational Linux security tool that demonstrates
basic rootkit detection techniques using cross-view process analysis.

## Features
- Cross-view process detection (/proc, ps, psutil)
- Repeated scans to reduce race-condition false positives
- Root privilege enforcement
- Command-line interface

## Installation
```bash
pip install vsm-rootkit-detector
