import argparse
import os
import sys

from .main import run_scan

def require_root():
    if os.geteuid() != 0:
        print("[!] Must be run as root")
        sys.exit(1)

def main():
    parser = argparse.ArgumentParser(
        description="Educational Linux Rootkit Detection Tool"
    )
    parser.add_argument("--repeats", type=int, default=3)
    parser.add_argument("--delay", type=int, default=1)

    args = parser.parse_args()

    require_root()
    results = run_scan(args.repeats, args.delay)

    print("\n========== ROOTKIT DETECTION REPORT ==========")

    if results:
        print("■ Consistently hidden processes detected:")
        for pid in results:
            print(f" - PID {pid}")
    else:
        print("✓ No hidden processes detected")

    print("============== SCAN COMPLETE ==============\n")

if __name__ == "__main__":
    main()
