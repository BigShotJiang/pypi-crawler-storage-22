def compare_pids(user_pids, system_pids, library_pids):
    """
    Cross-view PID comparison
    """
    user_set = set(user_pids)
    system_set = set(system_pids)
    library_set = set(library_pids)

    hidden = system_set - user_set - library_set
    return sorted(hidden)
