from .views.user_view import get_user_pids
from .views.system_view import get_system_pids
from .views.library_view import get_library_pids
from .comparator.compare import compare_pids
import time

def run_scan(repeats=3, delay=1, whitelist=None):
    """
    Run multiple scans to reduce race-condition false positives
    """
    whitelist = whitelist or []
    seen = {}

    for _ in range(repeats):
        user = get_user_pids()
        system = get_system_pids()
        library = get_library_pids()

        hidden = compare_pids(user, system, library)

        for pid in hidden:
            seen[pid] = seen.get(pid, 0) + 1

        time.sleep(delay)

    # Only flag consistently hidden PIDs
    stable = [
        pid for pid, count in seen.items()
        if count == repeats and pid not in whitelist
    ]

    return stable
