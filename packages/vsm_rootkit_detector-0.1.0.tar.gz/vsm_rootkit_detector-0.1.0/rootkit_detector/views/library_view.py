import psutil

def get_library_pids():
    """
    Collect process IDs using a system library (psutil)
    """
    return sorted(p.pid for p in psutil.process_iter())
