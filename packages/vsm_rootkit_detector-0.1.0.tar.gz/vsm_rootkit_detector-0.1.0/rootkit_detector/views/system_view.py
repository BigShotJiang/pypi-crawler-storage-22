import subprocess

def get_system_pids():
    """
    Collect process IDs using ps
    """
    pids = []
    try:
        output = subprocess.check_output(
            ["ps", "-e", "-o", "pid="],
            text=True
        )
        for line in output.splitlines():
            if line.strip().isdigit():
                pids.append(int(line.strip()))
    except Exception as e:
        raise RuntimeError(f"ps execution failed: {e}")

    return sorted(pids)
