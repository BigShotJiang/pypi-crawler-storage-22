import os

def get_user_pids():
    """
    Collect process IDs visible via /proc
    """
    return sorted(
        int(pid) for pid in os.listdir("/proc") if pid.isdigit()
    )
