"""Vuer CLI - Environment Manager for Vuer Hub."""

from params_proto import proto

from .add import Add
from .envs_publish import EnvsPublish
from .envs_pull import EnvsPull
from .remove import Remove
from .scripts.demcap import Demcap
from .scripts.minimap import Minimap
from .scripts.viz_ptc_cams import VizPtcCams
from .scripts.viz_ptc_proxie import VizPtcProxie
from .sync import Sync
from .upgrade import Upgrade


def entrypoint() -> int:
  """Console script entry point."""
  return _cli_entrypoint() or 0


@proto.cli(prog="vuer")
def _cli_entrypoint(
  command: Sync
  | Add
  | Remove
  | Upgrade
  | EnvsPublish
  | EnvsPull
  | Demcap
  | Minimap
  | VizPtcCams
  | VizPtcProxie,
):
  """Vuer Hub Environment Manager.

  Available commands:
    sync          - Sync environments from environment.json dependencies (like npm install)
    add           - Add an environment to environment.json and run sync
    remove        - Remove an environment from environment.json and run sync
    upgrade       - Upgrade an environment to the latest version
    envs-publish  - Publish an environment to the Vuer Hub
    envs-pull     - Pull/download an environment from the Vuer Hub
    demcap        - Extract data from MCAP files to readable formats
    minimap       - Visualize robot trajectory with depth point clouds
    viz_ptc_cams  - Visualize point clouds from multiple cameras
    viz_ptc_proxie - Visualize GLB robot model with point cloud

  Examples:
    vuer sync                    Sync all dependencies from environment.json
    vuer add my-env/1.2.3        Add an environment and sync
    vuer remove my-env/1.2.3     Remove an environment and sync
    vuer upgrade my-env          Upgrade an environment to latest version
    vuer envs-publish            Publish current environment to hub
    vuer envs-pull my-env/1.2.3  Pull an environment from hub
    vuer demcap --mcap-path /path/to/file.mcap  Extract data from MCAP file
    vuer minimap --data-dir /path/to/data --cmap turbo
    vuer viz_ptc_cams --data-dir /path/to/data --cameras nav_front_d455,nav_right_d455
    vuer viz_ptc_proxie --data-dir /path/to/data

  Environment variables:
    VUER_HUB_URL     - Base URL of the Vuer Hub API
    VUER_AUTH_TOKEN  - JWT token for API authentication
  """
  return command.run()
