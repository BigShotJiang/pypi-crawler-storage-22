"""Demcap command - extract data from MCAP files to readable formats."""

from dataclasses import dataclass
from pathlib import Path
from textwrap import dedent

from ..utils import print_error


@dataclass
class Demcap:
  """Extract data from MCAP files to readable formats.

  DESCRIPTION
      Extracts and organizes data from ROS2 MCAP bag files into human-readable
      formats. Supports RGB images, depth images, LiDAR point clouds, IMU data,
      camera intrinsics, TF transforms, odometry, and joint states.

      Output structure:
          <output_dir>/
          ├── images/           # RGB images per camera
          ├── depth/            # Depth images per camera
          ├── lidar/            # LiDAR point cloud data
          ├── imu/              # IMU sensor data (CSV)
          ├── transforms/       # TF transform data (CSV)
          ├── videos/           # Generated videos from images
          ├── camera_intrinsics.json
          ├── odometry.csv
          └── joint_states.csv

  EXAMPLES
      # Basic extraction (output to extracted_data/<mcap_name>/)
      vuer demcap /path/to/recording.mcap

      # Specify custom output directory
      vuer demcap /path/to/recording.mcap --output ./my_output

      # Skip video generation for faster extraction
      vuer demcap /path/to/recording.mcap --no-video

      # Extract specific time range (nanoseconds)
      vuer demcap /path/to/recording.mcap --start-time 1000000000 --end-time 2000000000

  DEPENDENCIES
      Requires: pip install 'vuer-cli[mcap]'
  """

  # Required: path to mcap file
  mcap_path: str

  # Optional arguments
  output: str = None  # Output directory (default: extracted_data/<mcap_filename>)
  no_video: bool = False  # Skip video creation from RGB images
  fps: int = 30  # Frame rate for output videos
  start_time: int = None  # Start timestamp in nanoseconds
  end_time: int = None  # End timestamp in nanoseconds

  def run(self) -> int:
    """Execute demcap command."""
    try:
      from .mcap_extractor import MCAPExtractor
    except ImportError as e:
      print_error(
        f"Missing dependencies for demcap command: {e}\n\n"
        "Install with:\n"
        "  pip install 'vuer-cli[mcap]'\n"
        "  # or: uv add 'vuer-cli[mcap]'"
      )
      return 1

    try:
      # Verify file exists
      mcap_path = Path(self.mcap_path)
      if not mcap_path.exists():
        raise FileNotFoundError(f"File {self.mcap_path} does not exist")

      # Determine output directory
      if self.output:
        output_dir = Path(self.output).absolute()
      else:
        mcap_name = mcap_path.stem
        output_dir = Path(f"extracted_data/{mcap_name}").absolute()

      output_dir.mkdir(parents=True, exist_ok=True)

      print(f"\nExtracting MCAP file: {self.mcap_path}")
      print(f"Output directory: {output_dir}")
      print(f"Create videos: {not self.no_video}")
      if self.start_time and self.end_time:
        print(f"Time range: {self.start_time} to {self.end_time}")
      print()

      # Create extractor instance
      extractor = MCAPExtractor(
        mcap_path=str(mcap_path),
        output_dir=str(output_dir),
        create_videos=not self.no_video,
        video_fps=self.fps,
        start_time_ns=self.start_time,
        end_time_ns=self.end_time,
      )

      # Extract all data
      extractor.extract_all()

      # Show extraction summary
      self._print_summary(extractor, output_dir)

      return 0

    except FileNotFoundError as e:
      print_error(str(e))
      return 1
    except Exception as e:
      print_error(f"Unexpected error: {e}")
      return 1

  def _print_summary(self, extractor, output_dir: Path):
    """Print summary of extracted data."""
    print(dedent(f"""
      {'=' * 80}
      EXTRACTION COMPLETE
      {'=' * 80}

      Extracted data locations:
        RGB images: {output_dir / 'images'}
        Depth images: {output_dir / 'depth'}
        LiDAR scans: {output_dir / 'lidar'}
        IMU data: {output_dir / 'imu'}
        Transforms: {output_dir / 'transforms'}
        Videos: {output_dir / 'videos'}
    """).strip())

    # Show camera intrinsics if available
    if extractor.camera_intrinsics:
      print("\nCamera intrinsics extracted:")
      for camera_name, info in extractor.camera_intrinsics.items():
        print(f"  {camera_name}: {info['width']}x{info['height']}")
        if info["K"] and len(info["K"]) == 9:
          fx, fy = info["K"][0], info["K"][4]
          cx, cy = info["K"][2], info["K"][5]
          print(f"    fx={fx:.2f}, fy={fy:.2f}, cx={cx:.2f}, cy={cy:.2f}")

    # Show IMU data stats
    if extractor.imu_data:
      print("\nIMU data extracted:")
      for topic_name, data_list in extractor.imu_data.items():
        print(f"  {topic_name}: {len(data_list)} records")

    # Show transform data stats
    if extractor.tf_data:
      print(f"\nTransform data: {len(extractor.tf_data)} records")

    # Show odometry data stats
    if extractor.odom_data:
      print(f"\nOdometry data: {len(extractor.odom_data)} records")

    # Show joint states data stats
    if extractor.joint_states_data:
      print(f"\nJoint states data: {len(extractor.joint_states_data)} records")

    print(dedent(f"""
      {'=' * 80}

      All data saved to: {output_dir}
      {'=' * 80}
    """).strip())
