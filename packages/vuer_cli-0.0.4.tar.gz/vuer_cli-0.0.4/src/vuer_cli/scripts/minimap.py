"""Minimap visualization with GLB model, camera frustums, and depth point clouds."""

import warnings
from dataclasses import dataclass
from pathlib import Path
from textwrap import dedent
from typing import List, Optional

from ..utils import print_error

warnings.filterwarnings("ignore", category=RuntimeWarning)


def create_camera_positions_around_center(radius=1.0, height=0.0):
  """Create four camera positions around a center point at 90-degree intervals."""
  import numpy as np

  positions = []
  for angle in [0, np.pi / 2, np.pi, 3 * np.pi / 2]:
    x = radius * np.cos(angle)
    y = radius * np.sin(angle)
    z = height
    positions.append([x, y, z])
  return positions


def create_camera_rotations_looking_at_center():
  """Create rotations for cameras to look at the center point."""
  import numpy as np

  return [
    [0, -np.pi / 2, np.pi / 2],
    [np.pi / 2, 0, 0],
    [-np.pi / 2, np.pi / 2, 0],
    [np.pi / 2, -np.pi, np.pi],
  ]


def collect_depth_frames(
  data_dir: str,
  camera_names: Optional[List[str]] = None,
  max_frames: Optional[int] = None,
  frame_step: int = 5,
):
  """Collect depth frame paths and their world transforms."""
  import numpy as np

  from .ptc_utils import PointCloudGenerator, load_robot_poses, load_static_transforms

  data_path = Path(data_dir)
  if not data_path.exists():
    print(f"  Data path does not exist: {data_path}")
    return []

  if camera_names is None:
    camera_names = ["nav_front_d455", "nav_right_d455"]

  print(f"  Looking for cameras: {camera_names}")

  try:
    robot_pose_interpolator = load_robot_poses(data_path)
    pose_time_min = robot_pose_interpolator.times[0]
    pose_time_max = robot_pose_interpolator.times[-1]
    print(f"  Loaded {len(robot_pose_interpolator.times)} robot poses")
  except Exception as e:
    print(f"  Failed to load robot poses: {e}")
    return []

  frames = []
  reference_camera = camera_names[0]
  first_camera_transform = np.eye(4)
  first_transform_set = False

  for cam_name in camera_names:
    try:
      print(f"  Processing camera: {cam_name}")
      static_transform = load_static_transforms(data_path, cam_name)
      generator = PointCloudGenerator(data_dir=str(data_path), camera_name=cam_name)

      pairs = generator._find_rgb_depth_pairs()
      pairs = [p for p in pairs if pose_time_min <= p["timestamp_s"] <= pose_time_max]
      print(f"    Found {len(pairs)} RGB-D pairs in time range")

      if max_frames:
        pairs = pairs[:max_frames:frame_step]
      else:
        pairs = pairs[::frame_step]

      print(f"    Using {len(pairs)} pairs after sampling")

      for pair in pairs:
        t_world_to_base = robot_pose_interpolator.interpolate_pose(pair["timestamp_s"])
        if t_world_to_base is None:
          continue

        t_base_to_camera = static_transform.get_transform()
        t_world_to_camera = t_world_to_base @ t_base_to_camera

        if cam_name == reference_camera and not first_transform_set:
          first_camera_transform = t_world_to_camera.copy()
          first_transform_set = True

        # Transform to reference frame
        t_ref = np.linalg.inv(first_camera_transform) @ t_world_to_camera

        # Flip XY for three.js coordinate system
        flip_xy = np.array([[-1, 0, 0, 0], [0, -1, 0, 0], [0, 0, 1, 0], [0, 0, 0, 1]])
        t_final = flip_xy @ t_ref

        # Extract position and rotation
        position = t_final[:3, 3].tolist()

        # Convert rotation matrix to euler angles (XYZ order)
        from scipy.spatial.transform import Rotation

        rot_matrix = t_final[:3, :3]
        rotation = Rotation.from_matrix(rot_matrix).as_euler("xyz").tolist()

        frames.append(
          {
            "depth_file": pair["depth_file"],
            "camera_name": cam_name,
            "timestamp_s": pair["timestamp_s"],
            "position": position,
            "rotation": rotation,
            "intrinsics": generator.intrinsics,
          }
        )
    except Exception as e:
      print(f"    Error processing {cam_name}: {e}")
      continue

  return frames


def create_proxie_group(
  group_id: int,
  initial_position=None,
  initial_rotation=None,
  opacity: float = 1.0,
  glb_url: str = None,
):
  """Create a group containing a GLB model with four camera frustums."""
  from vuer.schemas import Frustum, Glb, Group

  if initial_position is None:
    initial_position = [0, 0, 0]
  if initial_rotation is None:
    initial_rotation = [0, 0, 0]

  camera_positions = create_camera_positions_around_center(radius=0.1, height=1.625)
  camera_rotations = create_camera_rotations_looking_at_center()

  frustums = []
  for i, (pos, rot) in enumerate(zip(camera_positions, camera_rotations, strict=False)):
    offsets = {0: (0.20, 0.008), 1: (0.17, -0.025), 2: (0.18, 0.005), 3: (0.185, 0.02)}
    if i in offsets:
      pos[0] += offsets[i][0]
      pos[1] += offsets[i][1]

    frustums.append(
      Frustum(
        key=f"frustum-{group_id}-{i}",
        position=pos,
        rotation=rot,
        scale=0.1,
        fov=60,
        aspect=16 / 9,
        near=0.1,
        far=0.2,
        showFrustum=True,
        showImagePlane=True,
        showFocalPlane=False,
        colorFrustum="cyan",
      )
    )

  initial_position[0] += 0
  initial_position[1] += 2
  initial_position[2] += 0
  initial_rotation[0] += -1.57

  return Group(
    Glb(
      src=glb_url,
      position=[0, 0, 0],
      rotation=[1.57, 0, 0],
      scale=0.01,
      opacity=opacity,
      key=f"model-{group_id}",
    ),
    *frustums,
    position=initial_position,
    rotation=initial_rotation,
    scale=1.0,
    key=f"group-{group_id}",
  )


async def main_viz(
  sess,
  workspace,
  depth_frames: List[dict],
  cmap: str = "turbo",
  color_mode: str = "depth",
  fov: float = 58.0,
  max_depth: float = 10.0,
  num_groups: int = 3,
  group_spacing: float = 2.0,
  base_position: Optional[List[float]] = None,
  glb_url: str = None,
):
  """Main visualization with DepthPointCloud components."""
  import cv2

  from vuer.schemas import DepthPointCloud, DepthPointCloudProvider, Scene

  # png encoder for depth images
  def png_encode(image):
    """Encode image as PNG bytes."""
    _, buffer = cv2.imencode(".png", image)
    return buffer.tobytes()

  print("Loading scene...")

  # Create virtual file endpoints for each depth frame
  depth_point_clouds = []

  for i, frame in enumerate(depth_frames):
    depth_path = f"/depth/{i}.png"

    # Link the depth file to a virtual endpoint
    def make_loader(frame_info):
      def load_depth():
        depth = cv2.imread(str(frame_info["depth_file"]), cv2.IMREAD_UNCHANGED)
        return png_encode(depth)

      return load_depth

    workspace.link(make_loader(frame), depth_path)

    # Compute FOV from intrinsics if available
    frame_fov = fov
    if frame["intrinsics"]:
      fx = frame["intrinsics"].get("fx", None)
      height = frame["intrinsics"].get("height", None)
      if fx and height:
        import numpy as np

        frame_fov = 2 * np.arctan(height / (2 * fx)) * 180 / np.pi

    depth_point_clouds.append(
      DepthPointCloud(
        key=f"depth-pc-{i}",
        depth=depth_path,
        cmap=cmap,
        colorMode=color_mode,
        fov=frame_fov,
        position=frame["position"],
        rotation=frame["rotation"],
        maxDepth=max_depth,
      )
    )

  print(f"Created {len(depth_point_clouds)} depth point clouds")

  # Create robot model groups
  if num_groups > 1:
    opacity_values = [1.0 - (0.3 * i / (num_groups - 1)) for i in range(num_groups)]
  else:
    opacity_values = [1.0]

  groups = [
    create_proxie_group(
      i,
      [base_position[0], base_position[1], base_position[2] - i * group_spacing],
      [0, 0, 0],
      opacity_values[i],
      glb_url=glb_url,
    )
    for i in range(num_groups)
  ]

  # Build scene with DepthPointCloudProvider for high performance
  print("Setting up scene...")
  sess.upsert @ Scene(
    *groups,
    DepthPointCloudProvider(
      *depth_point_clouds,
      key="depth-provider",
      frustumCulling=True,
    ),
    up=[0, 1, 0],
  )

  print("Ready! Open browser to view.")
  await sess.forever()


@dataclass
class Minimap:
  """Visualize robot trajectory with depth point clouds in a minimap view.

  DESCRIPTION
      Creates an interactive 3D visualization combining a GLB robot model with
      camera frustums and depth-based point clouds using DepthPointCloud components.
      Uses Workspace virtual files for efficient depth image serving.

      Features:
      - High-performance depth point cloud rendering with frustum culling
      - Multiple robot model instances with configurable spacing
      - Four camera frustums per robot showing sensor coverage
      - Colormap support (turbo, viridis, inferno, jet)
      - Multiple color modes (depth, camZ, camDist, localY, worldY)

      The visualization server runs at http://localhost:8012 by default.

  INPUT FORMAT
      Requires extracted MCAP data (use 'vuer demcap' first):
          <data_dir>/
          ├── images/<camera>_color_image_*/    # RGB images
          ├── depth/<camera>_*/                  # Depth images
          ├── transforms/transforms.csv          # Robot poses
          └── camera_intrinsics.json             # Camera calibration

  EXAMPLES
      # Basic visualization
      vuer minimap --data-dir /path/to/extracted_data

      # Custom colormap and color mode
      vuer minimap --data-dir /path/to/data --cmap viridis --color-mode worldY

      # Sparse sampling for faster loading
      vuer minimap --data-dir /path/to/data --frame-step 10

      # Custom robot model groups
      vuer minimap --data-dir /path/to/data --num-groups 5 --group-spacing 1.0

  DEPENDENCIES
      Requires: pip install 'vuer-cli[viz]'
  """

  data_dir: str  # Path to extracted MCAP data directory

  # Depth point cloud options
  cameras: str = None  # Comma-separated camera names
  max_frames: int = None  # Max frames per camera
  frame_step: int = 5  # Process every Nth frame
  cmap: str = "turbo"  # Colormap (turbo, viridis, inferno, jet)
  color_mode: str = "depth"  # Color mode (depth, camZ, camDist, localY, worldY)
  fov: float = 58.0  # Default camera FOV (RealSense D435)
  max_depth: float = 10.0  # Maximum depth in meters

  # Model options
  assets_folder: str = None  # Static assets folder for GLB model
  glb_url: str = "proxie.glb"  # GLB model URL
  num_groups: int = 10  # Number of robot groups to create
  group_spacing: float = 0.5  # Spacing between groups along Z-axis
  base_position: str = "-2.0,-2.2,0"  # Starting position [x,y,z]

  # Server options
  host: str = "0.0.0.0"
  port: int = 8012

  def run(self) -> int:
    """Execute minimap command."""
    try:
      from vuer import Vuer, Workspace
    except ImportError as e:
      print_error(
        f"Missing dependencies for minimap command: {e}\n\n"
        "Install with:\n"
        "  pip install 'vuer-cli[viz]'\n"
        "  # or: uv add 'vuer-cli[viz]'"
      )
      return 1

    try:
      data_path = Path(self.data_dir)
      if not data_path.exists():
        raise FileNotFoundError(f"Data directory {self.data_dir} does not exist")

      camera_list = None
      if self.cameras:
        camera_list = [c.strip() for c in self.cameras.split(",")]

      base_pos_list = [float(x.strip()) for x in self.base_position.split(",")]

      # Collect depth frames
      print("Collecting depth frames...")
      depth_frames = collect_depth_frames(
        data_dir=self.data_dir,
        camera_names=camera_list,
        max_frames=self.max_frames,
        frame_step=self.frame_step,
      )

      if not depth_frames:
        print_error("No depth frames found in the data directory")
        return 1

      print(f"Found {len(depth_frames)} depth frames")

      # Create workspace for virtual files
      workspace = Workspace()

      # Set up assets folder
      assets_folder = self.assets_folder
      if not assets_folder:
        import vuer_cli

        assets_folder = Path(vuer_cli.__file__).parent.parent.parent / "assets"
        if not assets_folder.exists():
          assets_folder = None

      if assets_folder:
        print(f"Using assets folder: {assets_folder}")
        app = Vuer(host=self.host, port=self.port, workspace=assets_folder)
      else:
        app = Vuer(host=self.host, port=self.port)

      # Merge workspace into app
      app.workspace = workspace

      print(
        dedent(f"""
        Starting minimap visualization server...
          URL: http://localhost:{self.port}
          Depth frames: {len(depth_frames)}
          Colormap: {self.cmap}
          Color mode: {self.color_mode}
      """).strip()
      )

      @app.spawn(start=True)
      async def main_with_args(sess):
        print("Session started, loading data...")
        await main_viz(
          sess,
          workspace=workspace,
          depth_frames=depth_frames,
          cmap=self.cmap,
          color_mode=self.color_mode,
          fov=self.fov,
          max_depth=self.max_depth,
          num_groups=self.num_groups,
          group_spacing=self.group_spacing,
          base_position=base_pos_list,
          glb_url=self.glb_url,
        )

      return 0

    except FileNotFoundError as e:
      print_error(str(e))
      return 1
    except Exception as e:
      print_error(f"Unexpected error: {e}")
      import traceback

      traceback.print_exc()
      return 1
