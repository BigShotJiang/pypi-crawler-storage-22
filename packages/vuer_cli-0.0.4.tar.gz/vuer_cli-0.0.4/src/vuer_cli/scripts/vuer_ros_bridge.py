#!/usr/bin/env python3

import asyncio
import threading
from collections import defaultdict, deque

import rclpy
from geometry_msgs.msg import PoseStamped
from params_proto import proto
from rclpy.node import Node
from rclpy.qos import HistoryPolicy, QoSProfile, ReliabilityPolicy
from sensor_msgs.msg import CompressedImage
from vista_demo.image_util import compressed_depth_to_jpeg
from vuer import VuerClient
from vuer.events import ClientEvent


class MapPose(ClientEvent):
  etype = "ros.MAP_POSE"


class DepthMap(ClientEvent):
  etype = "ros.DEPTH_MAP"


def stamp_to_ns(stamp) -> int:
  return stamp.sec * 1_000_000_000 + stamp.nanosec


def pose_to_tf(msg: PoseStamped) -> dict:
  p = msg.pose.position
  q = msg.pose.orientation
  return {
    "timestamp": stamp_to_ns(msg.header.stamp),
    "frame_id": msg.header.frame_id,
    "position": {"x": p.x, "y": p.y, "z": p.z},
    "orientation": {"x": q.x, "y": q.y, "z": q.z, "w": q.w},
  }


def topic_to_camera_key(topic: str) -> str:
  parts = topic.strip("/").split("/")
  return parts[0] if parts else topic


RETRY_DELAY = 2.0


@proto.cli
def main(
  server_uri: str = "ws://localhost:8012",
  # topics
  pose_topic: str = "/map/pose",
  depth_topics: str = "",  # depth (compressedDepth)
  rgb_topics: str = "",  # rgb   (CompressedImage jpeg)
  jpg_quality: int = 80,
):
  """Vuer ROS Bridge - streams map pose and depth to Vuer server."""

  depth_list = depth_topics.split() if depth_topics else []
  rgb_list = rgb_topics.split() if rgb_topics else []

  print("=" * 60)
  print("Vuer ROS Bridge")
  print(f"Server:       {server_uri}")
  print("=" * 60)

  rclpy.init()
  node = Node("vuer_ros_bridge")

  sensor_qos = QoSProfile(
    reliability=ReliabilityPolicy.BEST_EFFORT,
    history=HistoryPolicy.KEEP_LAST,
    depth=1,
  )

  threading.Thread(target=rclpy.spin, args=(node,), daemon=True).start()

  async def run():
    loop = asyncio.get_event_loop()

    pose_queue: asyncio.Queue = asyncio.Queue(maxsize=1)
    depth_queue: asyncio.Queue = asyncio.Queue(maxsize=10)

    tf_history: deque[dict] = deque(maxlen=50)  # ~0.5s at 100Hz
    tf_lock = threading.Lock()
    frame_buffer: dict[str, dict] = defaultdict(dict)
    buffer_lock = threading.Lock()
    rgb_cameras = {topic_to_camera_key(t) for t in rgb_list}

    def push(queue: asyncio.Queue, item):
      try:
        loop.call_soon_threadsafe(queue.put_nowait, item)
      except asyncio.QueueFull:
        pass

    def find_closest_tf(target_ns: int) -> dict:
      with tf_lock:
        if not tf_history:
          return {}
        return min(tf_history, key=lambda t: abs(t["timestamp"] - target_ns))

    # -- ROS Callbacks --

    def on_pose(msg: PoseStamped):
      tf = pose_to_tf(msg)
      with tf_lock:
        tf_history.append(tf)
      push(pose_queue, tf)

    def on_image(msg: CompressedImage, topic: str, field: str):
      """Handle both depth and rgb. field is 'depth' or 'rgb'."""
      if not msg.data:
        return
      camera_key = topic_to_camera_key(topic)
      data = (
        compressed_depth_to_jpeg(bytes(msg.data), jpg_quality)
        if field == "depth"
        else bytes(msg.data)
      )

      with buffer_lock:
        frame_buffer[camera_key][field] = data
        frame_buffer[camera_key]["timestamp"] = stamp_to_ns(msg.header.stamp)

        buf = frame_buffer[camera_key]
        if "depth" not in buf:
          return
        if camera_key in rgb_cameras and "rgb" not in buf:
          return

        tf = find_closest_tf(buf["timestamp"])
        payload = {"camera_key": camera_key, "depth": buf["depth"], "baselink/tf": tf}
        if "rgb" in buf:
          payload["rgb"] = buf["rgb"]
        frame_buffer[camera_key] = {}

      push(depth_queue, payload)

    # -- Subscribe --

    if pose_topic:
      node.create_subscription(PoseStamped, pose_topic, on_pose, sensor_qos)

    for topic in depth_list:
      node.create_subscription(
        CompressedImage,
        topic,
        lambda msg, t=topic: on_image(msg, t, "depth"),
        sensor_qos,
      )

    for topic in rgb_list:
      node.create_subscription(
        CompressedImage,
        topic,
        lambda msg, t=topic: on_image(msg, t, "rgb"),
        sensor_qos,
      )

    # -- Async Handlers --

    async def pose_handler(client: VuerClient):
      sent = 0
      while True:
        tf = await pose_queue.get()
        while not pose_queue.empty():
          try:
            tf = pose_queue.get_nowait()
          except asyncio.QueueEmpty:
            break
        await client.send(MapPose(value=tf))
        sent += 1
        if sent % 500 == 0:
          print(f"[Pose] Sent {sent}")

    async def depth_handler(client: VuerClient):
      sent = 0
      while True:
        payload = await depth_queue.get()
        await client.send(DepthMap(value=payload))
        sent += 1
        if sent % 50 == 0:
          print(f"[Depth] Sent {sent} (cam: {payload.get('camera_key', '?')})")

    # -- Connect with retry --

    while True:
      try:
        print(f"\n[Vuer] Connecting to {server_uri}...")
        async with VuerClient(uri=server_uri) as client:
          print("[Vuer] Connected!")
          await asyncio.gather(pose_handler(client), depth_handler(client))
      except (ConnectionRefusedError, OSError) as e:
        print(f"[Vuer] Connection failed: {e}, retrying in {RETRY_DELAY}s...")
        await asyncio.sleep(RETRY_DELAY)
      except asyncio.CancelledError:
        break

  try:
    asyncio.run(run())
  except KeyboardInterrupt:
    print("\nShutting down...")
  finally:
    node.destroy_node()
    rclpy.shutdown()


if __name__ == "__main__":
  main()
