"""Login command - authenticate with Vuer Hub using OAuth Device Flow."""

import json
import os
import secrets
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict

from .utils import print_error

# Environment URLs mapping
ENV_URLS = {
    "dev": "https://staging-auth.vuer.ai",
    "production": "https://auth.vuer.ai",  # Update with actual production URL
}


@dataclass
class Login:
    """Authenticate with Vuer Hub using OAuth Device Flow.

    Opens browser for user authentication and saves credentials locally.
    """

    env: str = "dev"  # Environment to authenticate with (dev or production)

    def __call__(self) -> int:
        """Execute login command."""
        try:
            # Validate environment
            if self.env not in ENV_URLS:
                raise ValueError(
                    f"Invalid environment '{self.env}'. Must be one of: {', '.join(ENV_URLS.keys())}"
                )

            auth_url = ENV_URLS[self.env]
            print(f"[INFO] Authenticating with {self.env} environment...")
            print(f"[INFO] Auth server: {auth_url}")

            # Generate device secret hash (random string for this session)
            device_secret_hash = secrets.token_urlsafe(16)

            # Step 1: Start device flow
            print("[INFO] Starting device authentication flow...")
            device_data = start_device_flow(auth_url, device_secret_hash)

            user_code = device_data["user_code"]
            verification_uri = device_data["verification_uri"]
            verification_uri_complete = device_data.get(
                "verification_uri_complete")
            polling_url = device_data["polling_url"]
            expires_in = device_data["expires_in"]
            interval = device_data.get("interval", 5)

            # Step 2: Display instructions to user
            print("\n" + "=" * 60)
            print("AUTHENTICATION REQUIRED")
            print("=" * 60)
            print(f"\nPlease visit the following URL to authenticate:")
            print(f"\n  {verification_uri}\n")
            print(f"And enter this code: {user_code}")
            print(f"\nThis code will expire in {expires_in} seconds.")
            print("=" * 60 + "\n")

            # Step 3: Poll for authentication
            print("[INFO] Waiting for authentication...")
            print("[INFO] (Press Ctrl+C to cancel)\n")

            token_data = poll_for_token(
                polling_url=polling_url,
                device_secret_hash=device_secret_hash,
                interval=interval,
                expires_in=expires_in,
            )

            access_token = token_data["access_token"]
            refresh_token = token_data.get("refresh_token", "")
            token_type = token_data.get("token_type", "Bearer")

            # Step 4: Save credentials to environment file
            env_file_path = save_credentials(
                access_token=access_token,
                refresh_token=refresh_token,
                token_type=token_type,
                environment=self.env,
            )

            # Step 5: Set environment variables globally (platform-specific)
            set_global_env_vars(access_token, refresh_token)

            # Step 6: Automatically add to shell config (Unix-like systems)
            shell_config_updated = auto_configure_shell(env_file_path)

            print("\n" + "=" * 60)
            print("AUTHENTICATION SUCCESSFUL")
            print("=" * 60)
            print("\nCredentials have been saved and configured globally.")
            print("\nVuer CLI will automatically use these credentials.")
            print("You can now use other Vuer CLI commands immediately!")

            if shell_config_updated:
                print(f"\nShell configuration updated: {shell_config_updated}")
                print("Environment variables will be available in new terminal sessions.")

            print("\n" + "=" * 60 + "\n")

            return 0

        except KeyboardInterrupt:
            print("\n\n[INFO] Authentication cancelled by user.")
            return 1
        except ValueError as e:
            print_error(str(e))
            return 1
        except RuntimeError as e:
            print_error(str(e))
            return 1
        except Exception as e:
            print_error(f"Unexpected error during authentication: {e}")
            return 1


def start_device_flow(auth_url: str, device_secret_hash: str) -> Dict[
    str, Any]:
    """Start the device flow and get verification details.

    Args:
        auth_url: Base URL of the authentication server
        device_secret_hash: Random secret hash for this device session

    Returns:
        Device flow data including user_code, verification_uri, polling_url, etc.

    Raises:
        RuntimeError: If the API call fails
    """
    import requests

    url = f"{auth_url.rstrip('/')}/api/device-flow/start"
    payload = {
        "client_id": "vuer-cli",
        "device_secret_hash": device_secret_hash,
    }

    try:
        response = requests.post(url, json=payload, timeout=30)
        response.raise_for_status()
    except requests.exceptions.RequestException as e:
        raise RuntimeError(f"Failed to start device flow: {e}") from e

    data = response.json()

    # Validate response
    required_fields = ["user_code", "verification_uri", "polling_url",
                       "expires_in"]
    missing_fields = [f for f in required_fields if f not in data]
    if missing_fields:
        raise RuntimeError(
            f"Invalid response from auth server: missing fields {missing_fields}"
        )

    return data


def poll_for_token(
        polling_url: str,
        device_secret_hash: str,
        interval: int,
        expires_in: int,
) -> Dict[str, Any]:
    """Poll the authentication server until user completes authentication.

    Args:
        polling_url: URL to poll for token
        device_secret_hash: Same secret hash used in start_device_flow
        interval: Seconds to wait between polling attempts
        expires_in: Total seconds before the code expires

    Returns:
        Token data including access_token, refresh_token, token_type

    Raises:
        RuntimeError: If authentication fails or times out
    """
    import requests

    payload = {
        "client_id": "vuer-cli",
        "device_secret_hash": device_secret_hash,
    }

    start_time = time.time()
    attempt = 0

    while True:
        # Check if expired
        elapsed = time.time() - start_time
        if elapsed >= expires_in:
            raise RuntimeError(
                "Authentication timeout: verification code expired. Please try again."
            )

        attempt += 1
        dots = "." * (attempt % 4)
        remaining = int(expires_in - elapsed)
        print(
            f"\r[INFO] Waiting for authentication{dots:<3} ({remaining}s remaining)",
            end="",
            flush=True,
        )

        try:
            response = requests.post(polling_url, json=payload, timeout=30)

            # Successful authentication
            if response.status_code == 200:
                print("\n")  # New line after polling messages
                data = response.json()

                # Validate response
                if "access_token" not in data:
                    raise RuntimeError(
                        "Invalid response from auth server: missing access_token"
                    )

                return data

            # Still waiting for user to authenticate
            elif response.status_code in [202, 428]:
                # 202 = Accepted (still waiting)
                # 428 = Precondition Required (authorization pending)
                time.sleep(interval)
                continue

            # Check for authorization_pending in error response (some backends use 400)
            elif response.status_code == 400:
                try:
                    error_data = response.json()
                    error_msg = error_data.get("error", "")
                    if error_msg == "authorization_pending":
                        # Still waiting for user to complete authentication
                        time.sleep(interval)
                        continue
                    else:
                        # Real error
                        print("\n")
                        raise RuntimeError(
                            f"Authentication failed ({response.status_code}): {error_msg}"
                        )
                except ValueError:
                    # Not JSON, treat as error
                    print("\n")
                    error_msg = response.text or "Unknown error"
                    raise RuntimeError(
                        f"Authentication failed ({response.status_code}): {error_msg}"
                    )

            # Authentication denied or other error
            else:
                print("\n")  # New line before error
                try:
                    error_data = response.json()
                    error_msg = error_data.get("error", "Unknown error")
                except Exception:
                    error_msg = response.text or "Unknown error"
                raise RuntimeError(
                    f"Authentication failed ({response.status_code}): {error_msg}"
                )

        except requests.exceptions.RequestException as e:
            print("\n")  # New line before error
            raise RuntimeError(f"Failed to poll for token: {e}") from e


def save_credentials(
        access_token: str,
        refresh_token: str,
        token_type: str,
        environment: str,
) -> str:
    """Save credentials to both JSON config file and shell script.

    Args:
        access_token: JWT access token
        refresh_token: Refresh token
        token_type: Token type (usually "Bearer")
        environment: Environment name (dev/production)

    Returns:
        Path to the generated shell environment file
    """
    config_dir = Path.home() / ".vuer"
    config_dir.mkdir(parents=True, exist_ok=True)

    # Save to JSON file for Python code to read
    credentials_file = config_dir / "credentials"
    credentials = {
        "access_token": access_token,
        "refresh_token": refresh_token,
        "token_type": token_type,
        "environment": environment,
        "updated_at": time.time(),
    }

    try:
        with credentials_file.open("w", encoding="utf-8") as f:
            json.dump(credentials, f, indent=2)
        credentials_file.chmod(0o600)
    except Exception as e:
        raise RuntimeError(f"Failed to save credentials to JSON: {e}") from e

    # Save to shell script for users to source
    env_file = config_dir / "env.sh"
    env_content = f"""# Vuer CLI Authentication Configuration
# Generated on {time.strftime('%Y-%m-%d %H:%M:%S')}
# Environment: {environment}

export VUER_AUTH_TOKEN="{access_token}"
export REFRESH_TOKEN="{refresh_token}"
export TOKEN_TYPE="{token_type}"

# To use these credentials, run:
#   source ~/.vuer/env.sh
# Or add this line to your ~/.bashrc or ~/.zshrc:
#   source ~/.vuer/env.sh
"""

    try:
        with env_file.open("w", encoding="utf-8") as f:
            f.write(env_content)
        env_file.chmod(0o600)
        return str(env_file)
    except Exception as e:
        raise RuntimeError(
            f"Failed to save shell environment file: {e}") from e


def set_global_env_vars(access_token: str, refresh_token: str) -> None:
    """Set environment variables globally based on platform.

    On Windows: Uses setx to set user-level environment variables
    On macOS/Linux: Sets for current process (will be in shell config too)

    Args:
        access_token: JWT access token
        refresh_token: Refresh token
    """
    import platform
    import subprocess

    system = platform.system()

    if system == "Windows":
        # Use setx to set user-level environment variables on Windows
        try:
            subprocess.run(
                ["setx", "VUER_AUTH_TOKEN", access_token],
                check=False,
                capture_output=True,
            )
            if refresh_token:
                subprocess.run(
                    ["setx", "REFRESH_TOKEN", refresh_token],
                    check=False,
                    capture_output=True,
                )
        except Exception:
            pass  # Silently fail if setx not available
    else:
        # On Unix-like systems, set for current process
        # (will also be in shell config via auto_configure_shell)
        os.environ["VUER_AUTH_TOKEN"] = access_token
        if refresh_token:
            os.environ["REFRESH_TOKEN"] = refresh_token


def auto_configure_shell(env_file_path: str) -> str:
    """Automatically add source command to shell configuration file.

    Args:
        env_file_path: Path to the env.sh file to be sourced

    Returns:
        Path to the updated shell config file, or empty string if not updated
    """
    import platform

    # Only configure shell on Unix-like systems
    if platform.system() == "Windows":
        return ""

    # Detect shell and corresponding config file
    shell = os.environ.get("SHELL", "")
    config_file = None

    if "zsh" in shell:
        config_file = Path.home() / ".zshrc"
    elif "bash" in shell:
        config_file = Path.home() / ".bashrc"
        # Also check for .bash_profile on macOS
        bash_profile = Path.home() / ".bash_profile"
        if bash_profile.exists():
            config_file = bash_profile
    else:
        # Try to find config file based on what exists
        zshrc = Path.home() / ".zshrc"
        bashrc = Path.home() / ".bashrc"
        bash_profile = Path.home() / ".bash_profile"

        if zshrc.exists():
            config_file = zshrc
        elif bash_profile.exists():
            config_file = bash_profile
        elif bashrc.exists():
            config_file = bashrc

    if not config_file:
        return ""

    source_line = f"source {env_file_path}"

    try:
        # Check if already configured
        if config_file.exists():
            content = config_file.read_text(encoding="utf-8")
            # Check if the source line already exists
            if source_line in content or f"source ~/.vuer/env.sh" in content:
                return ""  # Already configured

        # Add source line to config file
        with config_file.open("a", encoding="utf-8") as f:
            f.write(f"\n# Vuer CLI authentication (auto-added by vuer login)\n")
            f.write(f"{source_line}\n")

        return str(config_file)

    except Exception:
        # If we can't modify the config file, just return empty
        return ""


def load_credentials() -> Dict[str, Any]:
    """Load credentials from local configuration file.

    Returns:
        Credentials dictionary, or empty dict if file doesn't exist
    """
    credentials_file = Path.home() / ".vuer" / "credentials"

    if not credentials_file.exists():
        return {}

    try:
        with credentials_file.open("r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return {}
