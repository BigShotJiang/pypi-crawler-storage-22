from vunnel.cli import run

run()
