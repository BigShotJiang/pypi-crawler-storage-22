w3lib Package
=============

:mod:`~w3lib.encoding` Module
-----------------------------

.. automodule:: w3lib.encoding
    :members:


:mod:`~w3lib.html` Module
-------------------------

.. automodule:: w3lib.html
    :members:


:mod:`~w3lib.http` Module
-------------------------

.. automodule:: w3lib.http
    :members:

:mod:`~w3lib.url` Module
------------------------

.. automodule:: w3lib.url
    :members:

    .. autoclass:: ParseDataURIResult
       :members:
