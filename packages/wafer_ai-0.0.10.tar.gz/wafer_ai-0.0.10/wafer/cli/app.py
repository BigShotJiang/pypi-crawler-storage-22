# ruff: noqa: PLR0913, E402
# PLR0913 (too many arguments) is suppressed because Typer CLI commands
# naturally have many parameters - each --flag becomes a function argument.
# E402 (module level import not at top) is suppressed because we intentionally
# load .env files before importing other modules that may read env vars.
"""Wafer CLI - GPU development toolkit for LLM coding agents.

Top-level groups:
  wafer target    Create and manage GPU targets and workspaces
  wafer tool      Run profiling, evaluation, and analysis tools
  wafer agent     AI assistant for GPU kernel development
  wafer settings  Auth, config, billing, deps, and onboarding
"""
from __future__ import annotations

import atexit
import os
import shutil
import sys
import time
from collections.abc import Callable
from pathlib import Path
from typing import TYPE_CHECKING, Any

import trio
import typer

if TYPE_CHECKING:
    from types import ModuleType

    from .global_config import ApiEnvironment, GlobalConfig
    from .targets_ops import TargetSSHInfo

from dotenv import load_dotenv

# Auto-load .env from current directory and ~/.wafer/.env
# This runs at import time so env vars are available before any config is accessed
load_dotenv()  # cwd/.env
load_dotenv(Path.home() / ".wafer" / ".env")  # ~/.wafer/.env
from .problems import (
    download_problems,
    get_problem_path,
    get_problems_path,
)
from .problems import (
    list_problems as list_problems_fn,
)

app = typer.Typer(
    help="GPU development toolkit for LLM coding agents",
    no_args_is_help=False,
    pretty_exceptions_show_locals=False,  # Don't dump local vars (makes tracebacks huge)
    # Keep add_completion=True: README documents wafer --install-completion for shell setup
)

_command_start_time: float | None = None

_command_outcome: str = "failure"
# Track normalized failure metadata for PostHog alerting
_command_failure_details: dict[str, str | int] | None = None


def _show_version(json_output: bool = False) -> None:
    """Show CLI version and environment, then exit."""
    from .analytics import _get_cli_version
    from .global_config import load_global_config
    from .output import json_response
    version = _get_cli_version()
    config = load_global_config()
    environment = config.environment
    if json_output:
        typer.echo(json_response(data={"version": version, "environment": environment}))
    else:
        typer.echo(f"wafer-ai {version} ({environment})")
    raise typer.Exit()


def _show_welcome() -> None:
    """Show first-run welcome message for unauthenticated users."""
    from .analytics import _get_cli_version

    version = _get_cli_version()
    typer.echo(f"Wafer CLI v{version} — GPU development toolkit for LLM coding agents")
    typer.echo("")
    typer.echo("Get started:")
    typer.echo("  wafer settings login              Authenticate with GitHub")
    typer.echo("  wafer settings guide quickstart   Quick start guide")
    typer.echo("  wafer settings demo               Interactive demos")
    typer.echo("  wafer settings deps check         Check local tool dependencies")
    typer.echo("")
    typer.echo("Works without login:")
    typer.echo("  wafer tool roofline ...           Roofline analysis")
    typer.echo("  wafer settings guide              CLI usage guide")
    typer.echo("")
    typer.echo("Run wafer --help to see all commands.")


def _get_command_path(ctx: typer.Context) -> tuple[str, str | None]:
    """Extract command and subcommand from Typer context.
    Returns:
        Tuple of (command, subcommand). subcommand may be None.
    """
    invoked = ctx.invoked_subcommand
    info_name = ctx.info_name or ""
    parent_cmd = None
    if ctx.parent and ctx.parent.info_name and ctx.parent.info_name != "wafer":
        parent_cmd = ctx.parent.info_name
    if parent_cmd:
        return parent_cmd, info_name
    return info_name or "unknown", invoked


def _mark_command_success() -> None:
    """Mark the current command as successful.
    Call this at the end of successful command execution.
    Commands that raise typer.Exit(1) or exceptions will remain marked as failures.
    """
    global _command_outcome
    _command_outcome = "success"


def _make_excepthook(
    original_excepthook: Callable[..., Any],
) -> Callable[..., Any]:
    assert callable(original_excepthook), "original_excepthook must be callable"
    assert original_excepthook is not None, "original_excepthook must not be None"

    def custom_excepthook(
        exc_type: type[BaseException],
        exc_value: BaseException,
        exc_traceback: object,
    ) -> None:
        global _command_outcome, _command_failure_details
        if exc_type is SystemExit:
            exit_code = exc_value.code if hasattr(exc_value, "code") else 1
            if exit_code != 0 and exit_code is not None:
                _command_outcome = "failure"
                _command_failure_details = {
                    "error_type": "SystemExit",
                    "error_message": str(exc_value),
                }
                if isinstance(exit_code, int):
                    _command_failure_details["exit_code"] = exit_code
        else:
            _command_outcome = "failure"
            _command_failure_details = {
                "error_type": exc_type.__name__,
                "error_message": str(exc_value),
                "exit_code": 1,
            }
            if os.environ.get("NO_COLOR"):
                print(f"\n>>> ERROR: {exc_type.__name__}: {exc_value}\n", file=sys.stderr)
            else:
                print(
                    f"\n\033[1;31m>>> ERROR: {exc_type.__name__}: {exc_value}\033[0m\n",
                    file=sys.stderr,
                )
        original_excepthook(exc_type, exc_value, exc_traceback)
    return custom_excepthook


def _make_exit_tracker(ctx: typer.Context, analytics: ModuleType) -> Callable[[], None]:
    assert ctx is not None, "ctx must not be None"
    assert hasattr(analytics, "track_command"), "analytics module must have track_command"

    def track_on_exit() -> None:
        command, subcommand = _get_command_path(ctx)
        if ctx.resilient_parsing:
            return
        duration_ms = None
        if _command_start_time is not None:
            duration_ms = int((time.time() - _command_start_time) * 1000)
        failure_props = _command_failure_details or {}
        exit_code = failure_props.get("exit_code")
        error_type = failure_props.get("error_type")
        error_message = failure_props.get("error_message")
        typed_exit_code = exit_code if isinstance(exit_code, int) else None
        typed_error_type = error_type if isinstance(error_type, str) else None
        typed_error_message = error_message if isinstance(error_message, str) else None
        analytics.track_command(
            command=command,
            subcommand=subcommand,
            outcome=_command_outcome,
            duration_ms=duration_ms,
            properties=failure_props if _command_outcome == "failure" else None,
        )
        if _command_outcome == "failure":
            analytics.track_command_failure(
                command=command,
                subcommand=subcommand,
                error_type=typed_error_type,
                error_message=typed_error_message,
                exit_code=typed_exit_code,
                duration_ms=duration_ms,
            )
    return track_on_exit


@app.callback(invoke_without_command=True)
def main_callback(
    ctx: typer.Context,
    version: bool = typer.Option(
        False,
        "--version",
        help="Show version and exit",
    ),
    json_output: bool = typer.Option(
        False,
        "--json",
        "-j",
        help="Output as JSON (used with --version or subcommands)",
    ),
    no_color: bool = typer.Option(
        False,
        "--no-color",
        help="Suppress colored output",
    ),
) -> None:
    """Initialize analytics and track command execution."""
    if no_color:
        os.environ["NO_COLOR"] = "1"
    if version:
        _show_version(json_output=json_output)
        return

    if ctx.invoked_subcommand is None and not ctx.resilient_parsing:
        from .auth import load_credentials

        creds = load_credentials()
        if creds is None:
            _show_welcome()
        else:
            typer.echo(ctx.get_help())
        raise typer.Exit(0)

    global _command_start_time, _command_outcome, _command_failure_details
    _command_start_time = time.time()
    _command_outcome = "success"
    _command_failure_details = None

    from . import analytics
    analytics.init_analytics()
    sys.excepthook = _make_excepthook(sys.excepthook)
    atexit.register(_make_exit_tracker(ctx, analytics))


def complete_target_name(incomplete: str) -> list[str]:
    """Autocomplete target names from ~/.wafer/targets/*.toml"""
    targets_dir = Path.home() / ".wafer" / "targets"
    if not targets_dir.exists():
        return []
    return [f.stem for f in targets_dir.glob("*.toml") if f.stem.startswith(incomplete)]


target_app = typer.Typer(
    name="target",
    help="Create, manage, and run code on GPU targets.",
    no_args_is_help=True,
)
pool_app = typer.Typer(help="Manage target pools for fleet-level evaluation.")
tool_app = typer.Typer(
    name="tool",
    help="Run profiling, evaluation, and analysis tools.",
    no_args_is_help=True,
)
settings_app = typer.Typer(
    name="settings",
    help="Auth, config, billing, deps, and onboarding.",
    no_args_is_help=True,
)
app.add_typer(target_app, name="target")
app.add_typer(tool_app, name="tool")
app.add_typer(settings_app, name="settings")

config_app = typer.Typer(help="Manage CLI configuration")
targets_app = typer.Typer(
    help="""Manage GPU targets for remote evaluation.
Targets define how to access GPUs. Use 'wafer target init' to set up:
  wafer target init ssh           # Your own GPU via SSH
  wafer target init runpod        # RunPod cloud GPUs
  wafer target init digitalocean  # DigitalOcean AMD GPUs
Then use with: wafer target run --name <name> -- wafer tool eval --task <task>"""
)
workspaces_app = typer.Typer(
    help="""Manage cloud GPU workspaces for remote development.
Workspaces are on-demand cloud GPU environments. Requires authentication (wafer settings login).
Available GPUs:
  MI300X  AMD Instinct MI300X (192GB HBM3, ROCm)
  B200    NVIDIA Blackwell B200 (180GB HBM3e, CUDA)
Commands:
  wafer target init workspace dev --gpu B200     # Create workspace
  wafer target run --name dev -- python x.py     # Run commands
  wafer target remove dev                        # Clean up"""
)
ssh_keys_app = typer.Typer(
    help="""Manage SSH public keys for workspace access.
Register your SSH public keys here. These keys are installed in all workspaces
you provision, enabling SSH access from any machine with your private key.
  wafer settings ssh-keys list              # List registered keys
  wafer settings ssh-keys add               # Add key (auto-detects ~/.ssh/id_ed25519.pub)
  wafer settings ssh-keys add ~/.ssh/id_rsa.pub --name laptop  # Add specific key
  wafer settings ssh-keys remove <key-id>   # Remove a key"""
)
targets_ops_app = typer.Typer(
    help="""Execute commands on configured GPU targets.
Run commands on targets. Use 'wafer target run' instead."""
)
billing_app = typer.Typer(help="Manage billing, credits, and subscription")

from wafer.cli.evaluate import app as evaluate_app
from wafer.cli.baseline import baseline_app

ncu_app = typer.Typer(help="Nsight Compute profiling and analysis")
nsys_app = typer.Typer(help="Nsight Systems profile analysis")
perfetto_app = typer.Typer(help="Perfetto trace analysis and SQL queries")
tracelens_app = typer.Typer(help="TraceLens performance reports")
from .distributed_traces import nvidia_distributed_traces_app

isa_app = typer.Typer(help="ISA analysis for AMD GPU kernels (.co, .s, .ll, .ttgir files)")
compare_app = typer.Typer(help="Compare GPU traces across platforms (AMD vs NVIDIA)")

target_app.add_typer(pool_app, name="pool")

tool_app.add_typer(evaluate_app, name="eval", rich_help_panel="Execution")
tool_app.add_typer(baseline_app, name="baseline", rich_help_panel="Execution")
tool_app.add_typer(ncu_app, name="ncu", rich_help_panel="NVIDIA Profiling")
tool_app.add_typer(nsys_app, name="nsys", rich_help_panel="NVIDIA Profiling")
tool_app.add_typer(perfetto_app, name="perfetto", rich_help_panel="NVIDIA Profiling")
tool_app.add_typer(tracelens_app, name="tracelens", rich_help_panel="NVIDIA Profiling")
tool_app.add_typer(nvidia_distributed_traces_app, name="nvidia-distributed-traces", rich_help_panel="NVIDIA Profiling")
tool_app.add_typer(isa_app, name="isa", rich_help_panel="AMD Profiling")
tool_app.add_typer(compare_app, name="compare", rich_help_panel="Analysis")

from .deps import deps_app

settings_app.add_typer(config_app, name="config")
settings_app.add_typer(billing_app, name="billing")

settings_app.add_typer(ssh_keys_app, name="ssh-keys")
settings_app.add_typer(deps_app, name="deps")

telemetry_app = typer.Typer(help="Control analytics and data retention settings")
settings_app.add_typer(telemetry_app, name="telemetry")


@telemetry_app.command("off")
def telemetry_off(
    json_output: bool = typer.Option(False, "--json", "-j", help="Output as JSON"),
) -> None:
    """Disable analytics and data retention."""
    from .global_config import (
        GlobalConfig,
        load_global_config,
        save_global_config,
    )
    from .output import json_response

    config = load_global_config()
    new_prefs = config.preferences.__class__(
        mode=config.preferences.mode,
        analytics_enabled=False,
        data_retention_enabled=False,
    )
    new_config = GlobalConfig(
        environment=config.environment,
        environments=config.environments,
        preferences=new_prefs,
        defaults=config.defaults,
    )
    save_global_config(new_config)

    if json_output:
        typer.echo(json_response(data={
            "analytics_enabled": False,
            "data_retention_enabled": False,
        }))
    else:
        typer.echo("Telemetry disabled.")
        typer.echo("  Analytics: disabled")
        typer.echo("  Data retention: disabled")


@telemetry_app.command("on")
def telemetry_on(
    json_output: bool = typer.Option(False, "--json", "-j", help="Output as JSON"),
) -> None:
    """Enable analytics and data retention (default)."""
    from .global_config import (
        GlobalConfig,
        load_global_config,
        save_global_config,
    )
    from .output import json_response

    config = load_global_config()
    new_prefs = config.preferences.__class__(
        mode=config.preferences.mode,
        analytics_enabled=True,
        data_retention_enabled=True,
    )
    new_config = GlobalConfig(
        environment=config.environment,
        environments=config.environments,
        preferences=new_prefs,
        defaults=config.defaults,
    )
    save_global_config(new_config)

    if json_output:
        typer.echo(json_response(data={
            "analytics_enabled": True,
            "data_retention_enabled": True,
        }))
    else:
        typer.echo("Telemetry enabled.")
        typer.echo("  Analytics: enabled")
        typer.echo("  Data retention: enabled")


@telemetry_app.command("status")
def telemetry_status(
    json_output: bool = typer.Option(False, "--json", "-j", help="Output as JSON"),
) -> None:
    """Show current analytics and data retention settings."""
    from .global_config import load_global_config
    from .output import json_response

    config = load_global_config()
    analytics = config.preferences.analytics_enabled
    retention = config.preferences.data_retention_enabled

    if json_output:
        typer.echo(json_response(data={
            "analytics_enabled": analytics,
            "data_retention_enabled": retention,
        }))
    else:
        a_status = "enabled" if analytics else "disabled"
        r_status = "enabled" if retention else "disabled"
        typer.echo(f"Analytics: {a_status}")
        typer.echo(f"Data retention: {r_status}")

def _roofline_list_gpus(get_all_gpus: Callable[[], list[str]], get_gpu_spec: Callable[..., Any], json_output: bool) -> None:
    assert callable(get_all_gpus), "get_all_gpus must be callable"
    assert callable(get_gpu_spec), "get_gpu_spec must be callable"

    if json_output:
        from .output import json_response
        gpu_list = []
        for name in get_all_gpus():
            spec = get_gpu_spec(name)
            gpu_list.append({
                "name": name,
                "full_name": spec.name,
                "peak_bandwidth_gbps": spec.peak_bandwidth_gbps,
                "peak_tflops_fp16": spec.peak_tflops_fp16,
                "peak_tflops_fp32": spec.peak_tflops_fp32,
            })
        typer.echo(json_response(data={"gpus": gpu_list}))
    else:
        typer.echo("Available GPUs:")
        for name in get_all_gpus():
            spec = get_gpu_spec(name)
            typer.echo(
                f"  {name}: {spec.peak_bandwidth_gbps:.0f} GB/s, {spec.peak_tflops_fp16:.0f} TFLOPS FP16"
            )


def _roofline_validate_args(
    gpu: str | None, bytes_moved: float | None, flops: float | None,
    time_ms: float | None, json_output: bool,
) -> None:
    assert isinstance(json_output, bool), "json_output must be a bool"
    assert isinstance(gpu, (str, type(None))), "gpu must be str or None"

    missing = []
    if gpu is None:
        missing.append("--gpu")
    if bytes_moved is None:
        missing.append("--bytes")
    if flops is None:
        missing.append("--flops")
    if time_ms is None:
        missing.append("--time-ms")
    if missing:
        if json_output:
            from .output import json_error
            typer.echo(json_error(f"Missing required options: {', '.join(missing)}"))
        else:
            typer.echo(f"Error: Missing required options: {', '.join(missing)}", err=True)
            typer.echo("", err=True)
            typer.echo("Run 'wafer tool roofline --help' for usage.", err=True)
        raise typer.Exit(1)


def _roofline_result_to_dict(result: Any) -> dict[str, Any]:
    assert result is not None, "result must not be None"
    assert hasattr(result, "gpu"), "result must have a gpu attribute"

    return {
        "gpu": result.gpu.name,
        "dtype": result.dtype.value,
        "bottleneck": result.bottleneck.value,
        "arithmetic_intensity": result.arithmetic_intensity,
        "ridge_point": result.ridge_point,
        "efficiency_pct": result.efficiency_pct,
        "bytes_moved": result.bytes_moved,
        "flops": result.flops,
        "actual_time_s": result.actual_time_s,
        "theoretical_time_s": result.theoretical_time_s,
        "memory_bound_time_s": result.memory_bound_time_s,
        "compute_bound_time_s": result.compute_bound_time_s,
        "peak_bandwidth_bytes_per_s": result.peak_bandwidth_bytes_per_s,
        "peak_flops_per_s": result.peak_flops_per_s,
        "achieved_compute_flops_per_s": result.achieved_compute_flops_per_s,
        "achieved_bandwidth_bytes_per_s": result.achieved_bandwidth_bytes_per_s,
        "compute_efficiency_pct": result.compute_efficiency_pct,
        "bandwidth_efficiency_pct": result.bandwidth_efficiency_pct,
    }


@tool_app.command("roofline", rich_help_panel="Analysis")
def roofline_cmd(
    gpu: str | None = typer.Option(
        None, "--gpu", "-g", help="GPU name (e.g., H100, B200, MI300X, A100)"
    ),
    bytes_moved: float | None = typer.Option(
        None, "--bytes", "-b", help="Theoretical minimum bytes moved"
    ),
    flops: float | None = typer.Option(None, "--flops", "-f", help="Theoretical minimum FLOPs"),
    time_ms: float | None = typer.Option(
        None, "--time-ms", "-t", help="Actual kernel time in milliseconds"
    ),
    dtype: str = typer.Option(
        "fp16", "--dtype", "-d", help="Data type for compute ceiling (fp16, fp32, bf16, fp8, int8)"
    ),
    list_gpus: bool = typer.Option(False, "--list-gpus", help="List available GPU specs and exit"),
    json_output: bool = typer.Option(False, "--json", "-j", help="Output as JSON"),
) -> None:
    """Analyze kernel performance against roofline model.
    The roofline model shows the theoretical speed-of-light (SOL) for your kernel
    based on whether it's memory-bound or compute-bound.
    You need to provide:
    - The GPU you ran on
    - Theoretical minimum bytes moved (not actual - what the algorithm requires)
    - Theoretical minimum FLOPs
    - Actual measured kernel time
    Example:
        # Analyze a matmul kernel (4096x4096x4096, FP16)
        # Theoretical: 2*M*N*K FLOPs = 137.4 TFLOP
        # Theoretical bytes: (M*K + K*N + M*N) * 2 = 100.7 MB
        wafer tool roofline --gpu H100 --bytes 100.7e6 --flops 137.4e12 --time-ms 85
        # Analyze a memory-bound elementwise add (1B elements FP32)
        # Reads 2 tensors, writes 1 = 12 GB total
        # 1B adds = 1 GFLOP
        wafer tool roofline --gpu H100 --bytes 12e9 --flops 1e9 --time-ms 4 --dtype fp32
        # List available GPUs
        wafer tool roofline --list-gpus
        # JSON output
        wafer tool roofline --gpu H100 --bytes 100.7e6 --flops 137.4e12 --time-ms 85 --json
    """
    from wafer.core.roofline import get_gpu_spec, roofline_analysis
    from wafer.core.roofline import list_gpus as get_all_gpus
    if list_gpus:
        _roofline_list_gpus(get_all_gpus, get_gpu_spec, json_output)
        return
    _roofline_validate_args(gpu, bytes_moved, flops, time_ms, json_output)
    try:
        result = roofline_analysis(
            gpu=gpu, dtype=dtype, bytes_moved=bytes_moved, flops=flops, time_ms=time_ms,
        )
    except ValueError as e:
        if json_output:
            from .output import json_error
            typer.echo(json_error(str(e)))
        else:
            typer.echo(f"Error: {e}", err=True)
        raise typer.Exit(1) from None
    if json_output:
        from .output import json_response
        typer.echo(json_response(data=_roofline_result_to_dict(result)))
    else:
        typer.echo(result.format_report())


from .distributed_traces import amd_distributed_traces_app

tool_app.add_typer(amd_distributed_traces_app, name="amd-distributed-traces", rich_help_panel="AMD Profiling")
skill_app = typer.Typer(help="Manage AI coding assistant skills (Claude Code, Codex)")
settings_app.add_typer(skill_app, name="skill")


@skill_app.command("install")
def skill_install(
    target: str = typer.Option(
        "all",
        "--target",
        "-t",
        help="Target tool: claude, codex, cursor, or all",
    ),
    force: bool = typer.Option(False, "--force", "-f", help="Overwrite existing skill"),
) -> None:
    """Install the wafer-guide skill for AI coding assistants.
    Installs the bundled skill to make wafer commands discoverable by
    Claude Code, OpenAI Codex CLI, and/or Cursor.
    Skills follow the open agent skills specification (agentskills.io).
    Examples:
        wafer settings skill install              # Install for all tools
        wafer settings skill install -t claude    # Install for Claude Code only
        wafer settings skill install -t codex     # Install for Codex CLI only
        wafer settings skill install -t cursor    # Install for Cursor only
        wafer settings skill install --force      # Overwrite existing installation
    """
    # Locate bundled skill
    skill_source = Path(__file__).parent / "skills" / "wafer-guide"
    if not skill_source.exists():
        typer.echo("Error: Bundled skill not found. Package may be corrupted.", err=True)
        raise typer.Exit(1)
    targets_to_install: list[tuple[str, Path]] = []
    if target in ("all", "claude"):
        targets_to_install.append((
            "Claude Code",
            Path.home() / ".claude" / "skills" / "wafer-guide",
        ))
    if target in ("all", "codex"):
        targets_to_install.append(("Codex CLI", Path.home() / ".codex" / "skills" / "wafer-guide"))
    if target in ("all", "cursor"):
        targets_to_install.append(("Cursor", Path.home() / ".cursor" / "skills" / "wafer-guide"))
    if not targets_to_install:
        typer.echo(
            f"Error: Unknown target '{target}'. Use: claude, codex, cursor, or all", err=True
        )
        raise typer.Exit(1)
    for tool_name, dest_path in targets_to_install:
        if dest_path.exists() or dest_path.is_symlink():
            if not force:
                typer.echo(f"  {tool_name}: Already installed at {dest_path}")
                typer.echo("             Use --force to overwrite")
                continue
            # Remove existing
            if dest_path.is_symlink():
                dest_path.unlink()
            else:
                import shutil
                shutil.rmtree(dest_path)
        dest_path.parent.mkdir(parents=True, exist_ok=True)
        dest_path.symlink_to(skill_source)
        typer.echo(f"  {tool_name}: Installed at {dest_path}")
    typer.echo("")
    typer.echo("Restart your AI assistant to load the new skill.")


@skill_app.command("uninstall")
def skill_uninstall(
    target: str = typer.Option(
        "all",
        "--target",
        "-t",
        help="Target tool: claude, codex, cursor, or all",
    ),
) -> None:
    """Uninstall the wafer-guide skill.
    Examples:
        wafer settings skill uninstall              # Uninstall from all tools
        wafer settings skill uninstall -t claude    # Uninstall from Claude Code only
        wafer settings skill uninstall -t cursor    # Uninstall from Cursor only
    """
    targets_to_uninstall: list[tuple[str, Path]] = []
    if target in ("all", "claude"):
        targets_to_uninstall.append((
            "Claude Code",
            Path.home() / ".claude" / "skills" / "wafer-guide",
        ))
    if target in ("all", "codex"):
        targets_to_uninstall.append((
            "Codex CLI",
            Path.home() / ".codex" / "skills" / "wafer-guide",
        ))
    if target in ("all", "cursor"):
        targets_to_uninstall.append((
            "Cursor",
            Path.home() / ".cursor" / "skills" / "wafer-guide",
        ))
    if not targets_to_uninstall:
        typer.echo(
            f"Error: Unknown target '{target}'. Use: claude, codex, cursor, or all", err=True
        )
        raise typer.Exit(1)
    for tool_name, dest_path in targets_to_uninstall:
        if not dest_path.exists():
            typer.echo(f"  {tool_name}: Not installed")
            continue
        if dest_path.is_symlink():
            dest_path.unlink()
        else:
            import shutil
            shutil.rmtree(dest_path)
        typer.echo(f"  {tool_name}: Uninstalled from {dest_path}")


@skill_app.command("status")
def skill_status(
    json_output: bool = typer.Option(False, "--json", "-j", help="Output as JSON"),
) -> None:
    """Show installation status of the wafer-guide skill.
    Examples:
        wafer settings skill status
        wafer settings skill status --json
    """
    from .output import json_response
    skill_source = Path(__file__).parent / "skills" / "wafer-guide"

    assert skill_source.exists(), f"Bundled skill missing at {skill_source}"

    installations = [
        ("Cursor", "cursor", Path.home() / ".cursor" / "skills" / "wafer-guide"),
        ("Claude Code", "claude", Path.home() / ".claude" / "skills" / "wafer-guide"),
        ("Codex CLI", "codex", Path.home() / ".codex" / "skills" / "wafer-guide"),
    ]

    if json_output:
        tools = []
        for display_name, flag, path in installations:
            installed = path.exists() or path.is_symlink()
            tools.append({
                "tool": display_name,
                "flag": flag,
                "installed": installed,
                "path": str(path),
            })
        typer.echo(json_response(data={
            "skill": "wafer-guide",
            "description": "GPU kernel development knowledge for AI coding assistants.",
            "bundled": True,
            "installations": tools,
        }))
        return

    typer.echo("wafer-guide (bundled)")
    typer.echo("  GPU kernel development knowledge for AI coding assistants.")
    typer.echo("")

    typer.echo("Installed for:")
    for display_name, flag, path in installations:
        if path.exists() or path.is_symlink():
            typer.echo(f"  {display_name + ':':<14} Installed")
        else:
            typer.echo(f"  {display_name + ':':<14} Not installed  (run: wafer settings skill install -t {flag})")


provider_auth_app = typer.Typer(help="Manage API keys for cloud GPU providers")
settings_app.add_typer(provider_auth_app, name="auth")


@provider_auth_app.command("login")
def provider_auth_login(
    provider: str = typer.Argument(
        ...,
        help="Provider name: runpod, digitalocean, modal, anthropic, or openai",
    ),
    api_key: str | None = typer.Option(
        None,
        "--api-key",
        "-k",
        help="API key (if not provided, reads from stdin)",
    ),
) -> None:
    """Save API key for a provider.
    Stores the key in ~/.wafer/auth.json. Environment variables
    (e.g., ANTHROPIC_API_KEY) take precedence over stored keys.
    Examples:
        wafer settings auth login anthropic --api-key sk-ant-xxx
        wafer settings auth login runpod --api-key rp_xxx
        wafer settings auth login openai --api-key sk-xxx
        echo $API_KEY | wafer settings auth login anthropic
    """
    import sys

    from wafer.core.auth import PROVIDERS, save_api_key
    # Validate provider
    if provider not in PROVIDERS:
        typer.echo(f"Error: Unknown provider '{provider}'", err=True)
        typer.echo(f"Valid providers: {', '.join(PROVIDERS.keys())}", err=True)
        raise typer.Exit(1)
    if api_key is None:
        if sys.stdin.isatty():
            typer.echo(f"Enter API key for {PROVIDERS[provider]['display_name']}:")
            api_key = typer.prompt("API key", hide_input=True)
        else:
            api_key = sys.stdin.read().strip()
    if not api_key:
        typer.echo("Error: No API key provided", err=True)
        raise typer.Exit(1)
    # Save the key
    save_api_key(provider, api_key)
    typer.echo(f"API key saved for {PROVIDERS[provider]['display_name']}")
    typer.echo("Stored in: ~/.wafer/auth.json")


@provider_auth_app.command("logout")
def provider_auth_logout(
    provider: str = typer.Argument(
        ...,
        help="Provider name: runpod, digitalocean, modal, anthropic, or openai",
    ),
) -> None:
    """Remove stored API key for a cloud GPU provider.
    Examples:
        wafer auth logout runpod
        wafer auth logout digitalocean
    """
    from wafer.core.auth import PROVIDERS, remove_api_key
    # Validate provider
    if provider not in PROVIDERS:
        typer.echo(f"Error: Unknown provider '{provider}'", err=True)
        typer.echo(f"Valid providers: {', '.join(PROVIDERS.keys())}", err=True)
        raise typer.Exit(1)
    if remove_api_key(provider):
        typer.echo(f"API key removed for {PROVIDERS[provider]['display_name']}")
    else:
        typer.echo(f"No stored API key found for {PROVIDERS[provider]['display_name']}")


@provider_auth_app.command("status")
def provider_auth_status(
    json_output: bool = typer.Option(False, "--json", "-j", help="Output as JSON"),
) -> None:
    """Show authentication status for all cloud GPU providers.
    Displays which providers have API keys configured and where
    the keys are coming from (environment variable or auth.json).
    Example:
        wafer settings auth status
        wafer settings auth status --json
    """
    from wafer.core.auth import get_all_auth_status

    from .output import json_response
    statuses = get_all_auth_status()

    if json_output:
        providers = []
        for s in statuses:
            providers.append({
                "provider": s.provider,
                "display_name": s.display_name,
                "authenticated": s.is_authenticated,
                "source": s.source if s.is_authenticated else None,
                "key_preview": s.key_preview if s.is_authenticated else None,
            })
        typer.echo(json_response(data={"providers": providers}))
        return

    typer.echo("Cloud GPU Provider Authentication Status")
    typer.echo("=" * 45)
    for status in statuses:
        if status.is_authenticated:
            source_str = f"({status.source})" if status.source else ""
            typer.echo(f"  {status.display_name}: ✓ {status.key_preview} {source_str}")
        else:
            typer.echo(f"  {status.display_name}: ✗ Not configured")
            typer.echo(f"      Run: wafer settings auth login {status.provider}")
            typer.echo(f"      Or set: {status.key_url}")
    typer.echo("")
    typer.echo("Note: Environment variables take precedence over stored keys.")


@config_app.command("init")
def config_init(
    environment: str = typer.Option(
        "prod",
        "--env",
        "-e",
        help="Initial API environment (staging, prod, local)",
    ),
) -> None:
    """Initialize config file with defaults.
    Creates ~/.wafer/config.toml with the specified environment.
    Examples:
        wafer settings config init                  # use prod environment
        wafer settings config init --env staging    # use staging environment
    """
    from .global_config import (
        BUILTIN_ENVIRONMENTS,
        CONFIG_FILE,
        init_config,
    )
    if environment not in BUILTIN_ENVIRONMENTS:
        typer.echo(
            f"Error: Unknown environment '{environment}'. "
            f"Available: {', '.join(BUILTIN_ENVIRONMENTS.keys())}",
            err=True,
        )
        raise typer.Exit(1)
    if CONFIG_FILE.exists():
        typer.echo(f"Config already exists: {CONFIG_FILE}")
        typer.echo("Use 'wafer settings config set' to modify settings.")
        raise typer.Exit(1)
    config = init_config(environment)
    env = config.get_api_environment()
    typer.echo(f"Created {CONFIG_FILE}")
    typer.echo(f"Environment: {environment}")
    typer.echo(f"API URL: {env.api_url}")


def _format_target_summary(target: object) -> str:
    """Format a single target as a one-line summary string.

    Extracts connection info and GPU type from the target dataclass.
    """
    _TYPE_MAP = {
        "BaremetalTarget": "baremetal",
        "VMTarget": "vm",
        "ModalTarget": "modal",
        "WorkspaceTarget": "workspace",
        "RunPodTarget": "runpod",
        "DigitalOceanTarget": "digitalocean",
        "LocalTarget": "local",
    }
    target_type = _TYPE_MAP.get(type(target).__name__, "unknown")

    details = ""
    if hasattr(target, "ssh_target"):
        details = f"  {target.ssh_target}"
    elif hasattr(target, "workspace_id"):
        details = f"  workspace:{target.workspace_id}"
    elif hasattr(target, "modal_app_name"):
        details = f"  app:{target.modal_app_name}"

    gpu = getattr(target, "gpu_type", None)
    if gpu:
        details += f"  ({gpu})"

    return f"[{target_type}]{details}"


def _show_targets() -> list[str]:
    """Return lines describing configured targets."""
    from .targets import get_default_target, list_targets, load_target

    lines: list[str] = []
    target_names = list_targets()

    if not target_names:
        lines.append("  None configured")
        lines.append("  Run 'wafer target init' to set up a target.")
        return lines

    default_target = get_default_target()
    for name in target_names:
        marker = " (default)" if name == default_target else ""
        try:
            target = load_target(name)
            summary = _format_target_summary(target)
            lines.append(f"  {name}{marker}  {summary}")
        except (FileNotFoundError, ValueError, TypeError, OSError):
            lines.append(f"  {name}{marker}  (error loading config)")

    return lines


def _show_docker_config() -> list[str]:
    """Return lines describing Docker execution configuration."""
    config_path = Path.home() / ".wafer" / "config.toml"
    if not config_path.exists():
        return ["  Not configured"]

    try:
        from wafer.core.config import WaferConfig, load_config

        _, project_cfg = load_config(config_path.parent)
        if project_cfg is None:
            return ["  Not configured"]
    except (ImportError, TypeError, FileNotFoundError, OSError):
        return ["  Not configured"]

    lines: list[str] = []
    if project_cfg.sandbox.enabled:
        lines.append("  Sandbox:     enabled")
    else:
        lines.append("  Sandbox:     disabled")
    if project_cfg.allowlist.allow:
        lines.append("  Allowlist:   " + ", ".join(project_cfg.allowlist.allow))
    if project_cfg.allowlist.block:
        lines.append("  Blocklist:   " + ", ".join(project_cfg.allowlist.block))
    if not lines:
        lines.append("  Default settings")
    return lines


def _show_cloud_providers() -> list[str]:
    """Return lines describing cloud provider auth status."""
    from wafer.core.auth import get_all_auth_status

    cloud_providers = {"runpod", "digitalocean", "modal"}
    lines: list[str] = []
    for status in get_all_auth_status():
        if status.provider not in cloud_providers:
            continue
        if status.is_authenticated:
            source_hint = f" (from {status.source})" if status.source else ""
            lines.append(f"  {status.display_name + ':':<20} Configured{source_hint}")
        else:
            lines.append(f"  {status.display_name + ':':<20} Not configured")
    return lines


def _config_show_json(global_cfg: GlobalConfig, api_env: ApiEnvironment, creds: Any, config_file: Path) -> dict[str, Any]:
    assert global_cfg is not None, "global_cfg must not be None"
    assert isinstance(config_file, Path), "config_file must be a Path"

    from .targets import get_default_target, list_targets, load_target
    target_names = list_targets()
    default_target = get_default_target()
    targets_data: list[dict[str, Any]] = []
    for name in target_names:
        entry: dict[str, Any] = {"name": name, "default": name == default_target}
        try:
            t = load_target(name)
            entry["type"] = type(t).__name__
            if hasattr(t, "ssh_target"):
                entry["ssh_target"] = t.ssh_target
            if hasattr(t, "gpu_type") and t.gpu_type:
                entry["gpu_type"] = t.gpu_type
        except (FileNotFoundError, ValueError, TypeError, OSError):
            entry["error"] = "failed to load config"
        targets_data.append(entry)
    providers_data: list[dict[str, Any]] = []
    try:
        from wafer.core.auth import get_all_auth_status
        cloud_providers = {"runpod", "digitalocean", "modal"}
        for s in get_all_auth_status():
            if s.provider not in cloud_providers:
                continue
            providers_data.append({
                "provider": s.provider,
                "display_name": s.display_name,
                "configured": s.is_authenticated,
                "source": s.source if s.is_authenticated else None,
            })
    except (ImportError, OSError, ValueError):
        pass
    return {
        "config_file": str(config_file),
        "config_file_exists": config_file.exists(),
        "api": {
            "environment": global_cfg.environment,
            "api_url": api_env.api_url,
            "authenticated": creds is not None,
            "email": creds.email if creds else None,
        },
        "defaults": {
            "mode": global_cfg.preferences.mode,
            "workspace": global_cfg.defaults.workspace,
            "gpu": global_cfg.defaults.gpu,
            "exec_timeout": global_cfg.defaults.exec_timeout,
        },
        "targets": targets_data,
        "cloud_providers": providers_data,
    }


def _config_show_text(global_cfg: GlobalConfig, api_env: ApiEnvironment, auth_line: str, config_file: Path) -> None:
    assert isinstance(auth_line, str), "auth_line must be a string"
    assert isinstance(config_file, Path), "config_file must be a Path"

    if config_file.exists():
        typer.echo(f"Config: {config_file}")
    else:
        typer.echo(f"Config: {config_file} (not found, using defaults)")
        typer.echo("  Run 'wafer config init' to create a config file.")
    typer.echo("\nAPI:")
    typer.echo(f"  Environment: {global_cfg.environment}")
    typer.echo(f"  API URL:     {api_env.api_url}")
    typer.echo(f"  Auth:        {auth_line}")
    mode = global_cfg.preferences.mode
    mode_desc = (
        "verbose status messages" if mode == "explicit" else "quiet output, use -v for details"
    )
    typer.echo("\nDefaults:")
    typer.echo(f"  Mode:        {mode} ({mode_desc})")
    if global_cfg.defaults.workspace:
        typer.echo(f"  Workspace:   {global_cfg.defaults.workspace}")
    typer.echo(f"  GPU:         {global_cfg.defaults.gpu}")
    typer.echo(f"  Timeout:     {global_cfg.defaults.exec_timeout}s")
    typer.echo("\nTargets:")
    for line in _show_targets():
        typer.echo(line)
    typer.echo("\nDocker:")
    for line in _show_docker_config():
        typer.echo(line)
    typer.echo("\nCloud Providers:")
    try:
        for line in _show_cloud_providers():
            typer.echo(line)
    except (ImportError, OSError, ValueError):
        typer.echo("  (unable to check provider status)")


@config_app.command("show")
def config_show_new(
    json_output: bool = typer.Option(False, "--json", "-j", help="Output as JSON"),
) -> None:
    """Show current configuration.

    Displays a unified view of all Wafer configuration: API settings,
    authentication, targets, Docker environments, and cloud providers.
    """
    from .auth import load_credentials
    from .global_config import CONFIG_FILE, load_global_config
    from .output import json_response

    global_cfg: GlobalConfig = load_global_config()
    api_env = global_cfg.get_api_environment()
    creds = load_credentials()

    if creds and creds.email:
        auth_line = creds.email
    elif creds:
        auth_line = "Logged in (run 'wafer whoami --verify' to check)"
    else:
        auth_line = "Not logged in (run 'wafer settings login')"

    if json_output:
        typer.echo(json_response(data=_config_show_json(global_cfg, api_env, creds, CONFIG_FILE)))
        return
    _config_show_text(global_cfg, api_env, auth_line, CONFIG_FILE)


def _config_set_field(config: GlobalConfig, section: str, field: str, value: str) -> GlobalConfig:
    assert isinstance(section, str) and section, "section must be a non-empty string"
    assert isinstance(field, str) and field, "field must be a non-empty string"

    from dataclasses import replace
    if section == "api":
        if field == "environment":
            if value not in config.environments:
                typer.echo(
                    f"Error: Unknown environment '{value}'. "
                    f"Available: {', '.join(config.environments.keys())}",
                    err=True,
                )
                raise typer.Exit(1)
            return replace(config, environment=value)
        typer.echo(f"Error: Unknown api field '{field}'. Available: environment", err=True)
        raise typer.Exit(1)
    if section == "defaults":
        if field == "workspace":
            new_defaults = replace(config.defaults, workspace=value if value else None)
            return replace(config, defaults=new_defaults)
        elif field == "gpu":
            return replace(config, defaults=replace(config.defaults, gpu=value))
        elif field == "exec_timeout":
            try:
                timeout = int(value)
                assert timeout > 0, "timeout must be positive"
            except (ValueError, AssertionError) as e:
                typer.echo(f"Error: exec_timeout must be a positive integer: {e}", err=True)
                raise typer.Exit(1) from None
            return replace(config, defaults=replace(config.defaults, exec_timeout=timeout))
        typer.echo(
            f"Error: Unknown defaults field '{field}'. Available: workspace, gpu, exec_timeout",
            err=True,
        )
        raise typer.Exit(1)
    if section == "preferences":
        if field == "mode":
            if value not in ("explicit", "implicit"):
                typer.echo(
                    f"Error: mode must be 'explicit' or 'implicit', got '{value}'", err=True,
                )
                raise typer.Exit(1)
            return replace(config, preferences=replace(config.preferences, mode=value))
        typer.echo(f"Error: Unknown preferences field '{field}'. Available: mode", err=True)
        raise typer.Exit(1)
    typer.echo(
        f"Error: Unknown section '{section}'. Available: api, defaults, preferences",
        err=True,
    )
    raise typer.Exit(1)


@config_app.command("set")
def config_set(
    key: str = typer.Argument(..., help="Config key (e.g., api.environment, defaults.workspace)"),
    value: str = typer.Argument(..., help="Value to set"),
) -> None:
    """Set a configuration value.
    Examples:
        wafer settings config set api.environment staging
        wafer settings config set defaults.workspace dev
        wafer settings config set defaults.exec_timeout 600
        wafer settings config set preferences.mode implicit
    """
    from .global_config import (
        CONFIG_FILE,
        GlobalConfig,
        clear_config_cache,
        load_global_config,
        save_global_config,
    )
    if CONFIG_FILE.exists():
        config = load_global_config()
    else:
        config = GlobalConfig()
    parts = key.split(".")
    if len(parts) != 2:
        typer.echo(f"Error: Invalid key format '{key}'. Use 'section.key' format.", err=True)
        typer.echo("Examples: api.environment, defaults.workspace, preferences.mode", err=True)
        raise typer.Exit(1)
    section, field = parts
    config = _config_set_field(config, section, field, value)
    save_global_config(config)
    clear_config_cache()
    typer.echo(f"Set {key} = {value}")


@config_app.command("get")
def config_get(
    key: str = typer.Argument(..., help="Config key to get (e.g., api.environment)"),
) -> None:
    """Get a configuration value.
    Examples:
        wafer settings config get api.environment
        wafer settings config get defaults.workspace
    """
    from .global_config import load_global_config
    config = load_global_config()
    parts = key.split(".")
    if len(parts) != 2:
        typer.echo(f"Error: Invalid key format '{key}'. Use 'section.key' format.", err=True)
        raise typer.Exit(1)
    section, field = parts
    if section == "api":
        if field == "environment":
            typer.echo(config.environment)
        elif field == "url":
            typer.echo(config.api_url)
        elif field == "supabase_url":
            typer.echo(config.supabase_url)
        else:
            typer.echo(f"Error: Unknown api field '{field}'", err=True)
            raise typer.Exit(1)
    elif section == "defaults":
        if field == "workspace":
            typer.echo(config.defaults.workspace or "")
        elif field == "gpu":
            typer.echo(config.defaults.gpu)
        elif field == "exec_timeout":
            typer.echo(str(config.defaults.exec_timeout))
        else:
            typer.echo(f"Error: Unknown defaults field '{field}'", err=True)
            raise typer.Exit(1)
    elif section == "preferences":
        if field == "mode":
            typer.echo(config.preferences.mode)
        else:
            typer.echo(f"Error: Unknown preferences field '{field}'", err=True)
            raise typer.Exit(1)
    else:
        typer.echo(f"Error: Unknown section '{section}'", err=True)
        raise typer.Exit(1)


# =============================================================================
# Agent template discovery helpers
# =============================================================================
def _get_template_search_paths() -> list:
    """Get template search paths including bundled CLI templates.
    Lightweight — only uses stdlib imports (pathlib, no heavy deps).
    """
    from wafer.cli.wevin_cli import get_wafer_template_search_paths
    return get_wafer_template_search_paths()


def _format_template_variable(
    var_name: str, defaults: dict[str, str]
) -> str | None:
    """Format a single template variable for display.
    Returns None for internal/auto-computed variables (e.g., target_flag).
    """
    # Skip internal auto-computed variables
    # why: these are derived from other args at runtime, not user-facing
    internal_suffixes = ("_flag", "_upper")
    if any(var_name.endswith(suffix) for suffix in internal_suffixes):
        return None
    default = defaults.get(var_name, "")
    if default:
        return f"{var_name} (default: {default})"
    return f"{var_name}"


def _format_template_entry(
    name: str,
    config: object,  # TemplateConfig - using object to avoid import at module level
) -> list[str]:
    """Format a single template for the --list-templates display."""
    lines: list[str] = []
    description = getattr(config, "description", "") or ""
    lines.append(f"  {name:<24}{description}")
    # Deduplicate variables (same var can appear multiple times in system prompt)
    raw_variables = config.get_variables() if hasattr(config, "get_variables") else []
    variables = list(dict.fromkeys(raw_variables))  # preserves order, removes dupes
    defaults = getattr(config, "defaults", {})
    # Show user-facing variables
    formatted_vars = []
    for v in variables:
        fmt = _format_template_variable(v, defaults)
        if fmt is not None:
            formatted_vars.append(fmt)
    if formatted_vars:
        lines.append(f"    Args: {', '.join(formatted_vars)}")
    # Generate example usage
    # why: quote values containing spaces so copy-paste into shell works
    example_args = ""
    for v in variables:
        internal_suffixes = ("_flag", "_upper")
        if any(v.endswith(suffix) for suffix in internal_suffixes):
            continue
        default = defaults.get(v, "")
        if default:
            arg = f"{v}={default}"
            # Shell-quote if value contains spaces or shell metacharacters
            if " " in default or "'" in default or '"' in default:
                example_args += f' --args "{arg}"'
            else:
                example_args += f" --args {arg}"
        else:
            example_args += f" --args {v}=<value>"
    lines.append(f"    Example: wafer agent -t {name}{example_args} \"<prompt>\"")
    return lines


def _handle_list_templates() -> None:
    """Display all available templates and exit.
    Runs before auth or heavy imports — only needs the template loader.
    """
    from wafer.cli.agent_config import list_bundled_templates
    from wafer.core.rollouts.templates.loader import load_all_templates

    search_paths = _get_template_search_paths()
    results = load_all_templates(search_paths)
    assert isinstance(results, list)

    # Track which templates we've already listed (Python templates)
    shown = set()

    typer.echo("Available agent templates:\n")
    for name, config, err in results:
        shown.add(name)
        if err or config is None:
            typer.echo(f"  {name:<24}(failed to load: {err})")
            typer.echo()
            continue
        for line in _format_template_entry(name, config):
            typer.echo(line)
        typer.echo()

    # Show bundled TOML templates that don't have a Python counterpart
    for toml_name in list_bundled_templates():
        if toml_name not in shown:
            typer.echo(f"  {toml_name:<24}(TOML template)")
            typer.echo(f"    Example: wafer agent -t {toml_name} \"your prompt\"")
            typer.echo()

    typer.echo("Use --args KEY=VALUE to pass template arguments (can be repeated).")
    typer.echo("Example: wafer agent -t trace-analyze --args trace=./my-trace.ncu-rep \"What's slow?\"")


def _validate_template_name(template_name: str) -> None:
    """Validate that a template name exists. Exits with helpful error if not.
    Runs before auth or heavy imports — uses lightweight file listing only.
    why: previously, bad template names silently hung waiting for auth + imports
    """
    from wafer.cli.agent_config import get_bundled_template_path, list_bundled_templates
    from wafer.core.rollouts.templates.loader import list_templates

    # Check bundled TOML templates first
    if get_bundled_template_path(template_name) is not None:
        return

    search_paths = _get_template_search_paths()
    available_py = list_templates(search_paths)
    assert isinstance(available_py, list)
    if template_name in available_py:
        return
    # Check if it's a file path that exists (templates can be loaded by path)
    from pathlib import Path
    if Path(template_name).expanduser().exists():
        return
    # Unknown template — fail fast with helpful error
    all_available = sorted(set(available_py + list_bundled_templates()))
    available_str = ", ".join(all_available) if all_available else "(none found)"
    typer.echo(
        f"Error: Unknown template '{template_name}'.\n"
        f"Available: {available_str}\n"
        f"Run 'wafer agent --list-templates' for details.",
        err=True,
    )
    raise typer.Exit(1)


def _agent_resolve_input(
    prompt: str | None, interactive: bool, simple: bool, json_output: bool,
) -> tuple[str | None, bool]:
    assert isinstance(interactive, bool), "interactive must be a bool"
    assert isinstance(simple, bool), "simple must be a bool"

    actual_prompt = prompt
    if not sys.stdin.isatty() and not actual_prompt:
        stdin_input = sys.stdin.read().strip()
        if stdin_input:
            actual_prompt = stdin_input
    has_tty = sys.stdin.isatty() and sys.stdout.isatty()
    use_tui = has_tty and not simple and not json_output
    if interactive:
        if not has_tty:
            print("Warning: --interactive requires a TTY, using simple mode", file=sys.stderr)
        else:
            use_tui = True
    return actual_prompt, use_tui


def _agent_parse_template_args(template_args: list[str] | None) -> dict[str, str] | None:
    assert template_args is None or isinstance(template_args, list), "template_args must be a list or None"
    assert template_args is None or all(isinstance(a, str) for a in template_args), "all template_args must be strings"

    if not template_args:
        return None
    parsed: dict[str, str] = {}
    for arg in template_args:
        if "=" not in arg:
            typer.echo(f"Invalid --args format: {arg!r}. Use KEY=VALUE", err=True)
            raise typer.Exit(1)
        key, value = arg.split("=", 1)
        parsed[key] = os.path.expanduser(value)
    return parsed


def _agent_validate_env(env: str | None, workspace: str | None, no_sandbox: bool) -> None:
    assert isinstance(no_sandbox, bool), "no_sandbox must be a bool"
    assert env is None or isinstance(env, str), "env must be str or None"

    if no_sandbox:
        print(
            "Warning: Sandbox disabled. You accept liability for any damage caused by the agent.",
            file=sys.stderr,
        )
    if env and env not in ("local", "workspace"):
        typer.echo(f"Unknown --env: {env!r}. Must be 'local' or 'workspace'.", err=True)
        raise typer.Exit(1)
    if workspace and env != "workspace":
        typer.echo("--workspace requires --env workspace", err=True)
        raise typer.Exit(1)
    if env == "workspace" and not workspace:
        typer.echo("--env workspace requires --workspace <id>", err=True)
        raise typer.Exit(1)


@app.command()
def agent(  # noqa: PLR0913
    prompt: str | None = typer.Argument(
        None,
        help="Prompt to send (reads from stdin if not provided and not interactive)",
    ),
    interactive: bool = typer.Option(
        False,
        "--interactive",
        "-i",
        help="Launch full interactive TUI mode (default when no prompt given)",
    ),
    simple: bool = typer.Option(
        False,
        "--simple",
        help="Use simple stdout mode instead of TUI (for scripts/pipes)",
    ),
    single_turn: bool | None = typer.Option(
        None,
        "--single-turn",
        "-s",
        is_flag=True,
        flag_value=True,
        help="Single-turn mode: answer once and exit",
    ),
    resume: str | None = typer.Option(
        None,
        "--resume",
        "-r",
        help="Resume session by ID (or 'last' for most recent)",
    ),
    from_turn: int | None = typer.Option(
        None,
        "--from-turn",
        help="Branch from specific turn (default: resume from end)",
    ),
    list_sessions: bool = typer.Option(
        False,
        "--list-sessions",
        help="List recent sessions and exit",
    ),
    get_session: str | None = typer.Option(
        None,
        "--get-session",
        help="Get session by ID and print messages (use with --json)",
    ),
    tools: str | None = typer.Option(
        None,
        "--tools",
        help="Comma-separated list of tools to enable (default: all)",
    ),
    allow_spawn: bool = typer.Option(
        False,
        "--allow-spawn",
        help="Allow wafer tool to spawn sub-wevin agents (blocked by default)",
    ),
    max_tool_fails: int | None = typer.Option(
        None,
        "--max-tool-fails",
        help="Exit after N consecutive tool failures",
    ),
    max_turns: int | None = typer.Option(
        None,
        "--max-turns",
        help="Max conversation turns (default: 10)",
    ),
    model: str | None = typer.Option(
        None,
        "--model",
        "-m",
        help="Model override (default: claude-opus-4-5)",
    ),
    json_output: bool = typer.Option(
        False,
        "--json",
        "-j",
        help="Output in JSON format (stream-json style)",
    ),
    list_templates: bool = typer.Option(
        False,
        "--list-templates",
        help="List available templates with descriptions and args, then exit",
    ),
    config: str | None = typer.Option(
        None,
        "--config",
        "-c",
        help="Path to agent config TOML file (overrides template defaults, overridden by CLI flags)",
    ),
    template: str | None = typer.Option(
        None,
        "--template",
        "-t",
        help="Run with template (use --list-templates to see all available)",
    ),
    template_args: list[str] | None = typer.Option(
        None,
        "--args",
        help="Template variable (KEY=VALUE, can be repeated)",
    ),
    no_sandbox: bool = typer.Option(
        False,
        "--no-sandbox",
        help="Disable OS-level sandboxing (YOU accept liability for any damage caused by the agent)",
    ),
    no_proxy: bool = typer.Option(
        False,
        "--no-proxy",
        help="Skip wafer proxy, use ANTHROPIC_API_KEY directly",
    ),
    env: str | None = typer.Option(
        None,
        "--env",
        help="Environment name (coding, remote-target, modal-sandbox). Uses --args for config.",
    ),
    workspace: str | None = typer.Option(
        None,
        "--workspace",
        help="Workspace ID (requires --env workspace)",
    ),
    output_format: str | None = typer.Option(
        None,
        "--output-format",
        help="Output format: 'stream-json' (Claude Code-compatible NDJSON) or 'chunk' (real-time deltas)",
    ),
) -> None:
    """AI assistant for GPU kernel development.
    Helps with CUDA/Triton kernel optimization, GPU documentation queries,
    and performance analysis. Launches interactive TUI by default.

    Examples:
        wafer agent                                    # interactive TUI
        wafer agent "What is TMEM in CuTeDSL?"        # TUI with initial prompt
        wafer agent -s "What is TMEM?"                 # single-turn (answer and exit)
        wafer agent -t ask-docs "query"                 # use a template
        wafer agent --resume last "follow up"          # resume session
    """
    if list_templates:
        _handle_list_templates()
        return
    if template:
        _validate_template_name(template)
    actual_prompt, use_tui = _agent_resolve_input(prompt, interactive, simple, json_output)
    parsed_template_args = _agent_parse_template_args(template_args)
    _agent_validate_env(env, workspace, no_sandbox)
    from wafer.cli.agent_config import get_bundled_template_path, load_agent_config
    from wafer.cli.wevin_cli import main as wevin_main

    file_config = load_agent_config(Path(config)) if config else None

    # -t <name> resolves to bundled TOML if available; Python template is fallback
    effective_template = template
    if template and not config:
        bundled_toml = get_bundled_template_path(template)
        if bundled_toml is not None:
            file_config = load_agent_config(bundled_toml)

    wevin_main(
        prompt=actual_prompt,
        interactive=use_tui,
        single_turn=single_turn,
        model=model,
        resume=resume,
        from_turn=from_turn,
        list_sessions=list_sessions,
        get_session=get_session,
        tools=tools.split(",") if tools else None,
        allow_spawn=allow_spawn,
        max_tool_fails=max_tool_fails,
        max_turns=max_turns,
        json_output=json_output,
        output_format=output_format,
        file_config=file_config,
        template=effective_template if effective_template else (file_config.template if file_config else None),
        template_args=parsed_template_args,
        no_sandbox=no_sandbox,
        no_proxy=no_proxy,
        env_name=env,
    )


@app.command(name="cloud-agent")
def cloud_agent_cmd(  # noqa: PLR0913
    prompt: str = typer.Argument(
        ...,
        help="Description of the changes to make",
    ),
    repo: str = typer.Option(
        ".",
        "--repo",
        help="Path or URL of the git repository (default: current directory)",
    ),
    branch: str | None = typer.Option(
        None,
        "--branch",
        "-b",
        help="Branch name (auto-generated if not provided)",
    ),
    base_branch: str | None = typer.Option(
        None,
        "--base",
        help="Base branch to create PR against (default: current branch)",
    ),
    model: str | None = typer.Option(
        None,
        "--model",
        "-m",
        help="Model override (default: claude-sonnet-4-5)",
    ),
    max_turns: int = typer.Option(
        50,
        "--max-turns",
        help="Maximum agent turns",
    ),
    json_output: bool = typer.Option(
        False,
        "--json",
        "-j",
        help="Output progress as NDJSON",
    ),
    no_proxy: bool = typer.Option(
        False,
        "--no-proxy",
        help="Skip wafer proxy, use ANTHROPIC_API_KEY directly",
    ),
    no_sandbox: bool = typer.Option(
        False,
        "--no-sandbox",
        help="Disable OS-level sandboxing",
    ),
    no_pr: bool = typer.Option(
        False,
        "--no-pr",
        help="Skip PR creation (just push the branch)",
    ),
) -> None:
    """Run a coding agent on a repo and create a PR with the changes.

    Takes a prompt describing what changes to make, runs an AI coding agent
    to implement them, then commits, pushes, and creates a pull request.

    Examples:
        wafer cloud-agent "Fix the auth bug in login.py"
        wafer cloud-agent --repo ~/myproject "Add unit tests for the API"
        wafer cloud-agent --repo https://github.com/org/repo "Add docstrings"
        wafer cloud-agent --branch fix/auth-bug "Fix authentication"
    """
    from wafer.cli.cloud_agent_cli import main as cloud_agent_main

    cloud_agent_main(
        prompt=prompt,
        repo=repo,
        branch=branch,
        base_branch=base_branch,
        model=model,
        max_turns=max_turns,
        json_output=json_output,
        no_proxy=no_proxy,
        no_sandbox=no_sandbox,
        no_pr=no_pr,
    )


def _login_interactive(port: int | None, no_device_code: bool) -> tuple[str, str | None, str | None]:
    assert isinstance(no_device_code, bool), "no_device_code must be a bool"
    assert port is None or isinstance(port, int), "port must be int or None"

    from .auth import browser_login, device_code_login
    is_ssh = bool(os.environ.get("SSH_CONNECTION") or os.environ.get("SSH_CLIENT"))
    try:
        if is_ssh and not no_device_code:
            typer.echo("SSH session detected - using device code authentication")
            typer.echo("   (No port forwarding required!)")
            typer.echo("")
            return device_code_login()
        if is_ssh:
            typer.echo("SSH session detected - using browser authentication")
            typer.echo("   Make sure you have port forwarding set up:")
            if port is None:
                port = 8765
            typer.echo(f"   ssh -L {port}:localhost:{port} user@host")
            typer.echo("")
        return browser_login(port=port)
    except (TimeoutError, RuntimeError) as e:
        typer.echo(f"Error: {e}", err=True)
        raise typer.Exit(1) from None
    except KeyboardInterrupt:
        typer.echo("\nCancelled", err=True)
        raise typer.Exit(1) from None


def _login_verify_token(token: str, verify_fn: Callable[..., Any]) -> Any:
    assert isinstance(token, str) and token.strip(), "token must be a non-empty string"
    assert callable(verify_fn), "verify_fn must be callable"

    import httpx
    typer.echo("Verifying token...")
    try:
        return verify_fn(token)
    except httpx.HTTPStatusError as e:
        if e.response.status_code == 401:
            typer.echo("Error: Invalid token", err=True)
        else:
            typer.echo(f"Error: API returned {e.response.status_code}", err=True)
        raise typer.Exit(1) from None
    except httpx.RequestError as e:
        typer.echo(f"Error: Could not reach API: {e}", err=True)
        raise typer.Exit(1) from None


@settings_app.command("login")
def login(
    token: str | None = typer.Option(
        None, "--token", "-t", help="Access token (skip browser OAuth)"
    ),
    port: int | None = typer.Option(
        None,
        "--port",
        "-p",
        help="Port for OAuth callback server (local only, ignored for SSH)",
    ),
    no_device_code: bool = typer.Option(
        False,
        "--no-device-code",
        help="Force browser OAuth even on SSH (requires port forwarding)",
    ),
) -> None:
    """Authenticate CLI with wafer-api via GitHub OAuth.

    Auto-detects SSH vs local: uses device code flow on SSH (no port forwarding),
    opens browser on local.

    Examples:
        wafer settings login                    # auto-detect (device code on SSH, browser on local)
        wafer settings login --token xyz        # manual token (no browser)
        wafer settings login --no-device-code   # force browser flow
    """
    from .auth import save_credentials, verify_token
    from .global_config import get_api_url, get_supabase_url, load_global_config
    config = load_global_config()
    typer.echo(f"Environment: {config.environment}")
    typer.echo(f"API: {get_api_url()}")
    typer.echo(f"Auth: {get_supabase_url()}")
    typer.echo("")
    if token is None:
        token, refresh_token, provider_token = _login_interactive(port, no_device_code)
    else:
        refresh_token = None
        provider_token = None
    if not token.strip():
        typer.echo("Error: Token cannot be empty", err=True)
        raise typer.Exit(1)
    token = token.strip()
    user_info = _login_verify_token(token, verify_token)
    save_credentials(token, refresh_token, user_info.email, provider_token)
    from . import analytics
    analytics.track_login(user_info.user_id, user_info.email)
    if user_info.email:
        typer.echo(f"Logged in as {user_info.email}")
    else:
        typer.echo(f"Logged in (user_id: {user_info.user_id})")
    typer.echo("Token saved to ~/.wafer/credentials.json")


@settings_app.command("logout")
def logout() -> None:
    """Remove stored credentials."""
    from . import analytics
    from .auth import clear_credentials

    # Note: track_logout() handles the case where user is not logged in
    analytics.track_logout()
    # Clear credentials and report result
    if clear_credentials():
        typer.echo("Logged out. Credentials removed.")
    else:
        typer.echo("Not logged in (no credentials found).")


def _whoami_token_status(creds: Any, token_expired_fn: Callable[..., bool]) -> tuple[bool, str | None]:
    assert creds is not None, "creds must not be None"
    assert callable(token_expired_fn), "token_expired_fn must be callable"

    import json as json_module
    token_valid = not token_expired_fn(creds.access_token)
    expires_in_str = None
    if creds.access_token:
        try:
            import base64
            payload_b64 = creds.access_token.split(".")[1]
            padded = payload_b64 + "=" * (-len(payload_b64) % 4)
            payload = json_module.loads(base64.urlsafe_b64decode(padded))
            remaining = payload["exp"] - time.time()
            if remaining > 0:
                if remaining < 60:
                    expires_in_str = f"{int(remaining)}s"
                elif remaining < 3600:
                    expires_in_str = f"{int(remaining / 60)}m"
                elif remaining < 86400:
                    expires_in_str = f"{int(remaining / 3600)}h {int((remaining % 3600) / 60)}m"
                else:
                    expires_in_str = f"{int(remaining / 86400)}d"
            else:
                expires_in_str = "expired"
                token_valid = False
        except Exception:
            pass
    return token_valid, expires_in_str


def _whoami_billing_info(token_valid: bool) -> tuple[str | None, str | None]:
    assert isinstance(token_valid, bool), "token_valid must be a bool"
    assert token_valid is True or token_valid is False, "token_valid must be exactly True or False"

    import json as json_module
    if not token_valid:
        return None, None
    try:
        from .billing import get_usage
        usage_json = get_usage(json_output=True)
        envelope = json_module.loads(usage_json)
        usage = envelope.get("data", {})
        tier = usage.get("tier", "unknown")
        tier_info = "Hacker" if tier.lower() == "start" else tier.capitalize()
        status = usage.get("status", "unknown")
        credits_limit = usage.get("credits_limit_cents", 0)
        if credits_limit == -1 or tier.lower() == "enterprise":
            credits_remaining = "unlimited"
        else:
            credits_cents = usage.get("credits_remaining_cents", 0)
            credits_remaining = f"${credits_cents / 100:.2f}"
        if status in ["past_due", "inactive", "cancelled"]:
            tier_info = f"{tier_info} ({status})"
        return tier_info, credits_remaining
    except Exception:
        return None, None


def _whoami_json(
    creds: Any, env_name: str, api_url: str, token_valid: bool,
    expires_in_str: str | None, tier_info: str | None, credits_remaining: str | None,
) -> None:
    assert creds is not None, "creds must not be None"
    assert isinstance(env_name, str) and env_name, "env_name must be a non-empty string"

    from .output import json_response
    result: dict = {
        "email": creds.email or "unknown",
        "environment": env_name,
        "api_url": api_url,
        "token_valid": token_valid,
    }
    if expires_in_str:
        result["token_expires_in"] = expires_in_str
    if tier_info:
        result["tier"] = tier_info
    if credits_remaining:
        result["credits_remaining"] = credits_remaining
    typer.echo(json_response(data=result))


def _whoami_text(
    creds: Any, env_name: str, api_url: str, token_valid: bool,
    expires_in_str: str | None, tier_info: str | None, credits_remaining: str | None,
) -> None:
    assert creds is not None, "creds must not be None"
    assert isinstance(env_name, str) and env_name, "env_name must be a non-empty string"

    lines = [creds.email or "Logged in"]
    lines.append(f"  Environment: {env_name} ({api_url})")
    if token_valid:
        if expires_in_str and expires_in_str != "expired":
            lines.append(f"  Token: valid (expires in {expires_in_str})")
        else:
            lines.append("  Token: valid")
    else:
        lines.append("  WARNING: Token expired. Run 'wafer settings login' to re-authenticate.")
    if tier_info:
        lines.append(f"  Tier: {tier_info}")
    if credits_remaining:
        if credits_remaining == "unlimited":
            lines.append("  Credits: unlimited")
        else:
            lines.append(f"  Credits: {credits_remaining} remaining")
    typer.echo("\n".join(lines))
    if not token_valid:
        raise typer.Exit(1)


@settings_app.command("whoami")
def whoami(
    json_output: bool = typer.Option(False, "--json", "-j", help="Output as JSON"),
) -> None:
    """Show current authenticated user and account information.
    Displays comprehensive authentication status including:
    - Email address
    - Environment (prod/staging/local)
    - Token validity and expiration
    - Subscription tier and credits
    """
    from .auth import _token_expired, load_credentials
    from .global_config import get_api_url, load_global_config
    creds = load_credentials()
    if creds is None:
        if json_output:
            from .output import json_error
            typer.echo(json_error("Not logged in"))
        else:
            typer.echo("Not logged in. Run: wafer settings login")
        raise typer.Exit(1)
    config = load_global_config()
    env_name = config.environment
    api_url = get_api_url()
    token_valid, expires_in_str = _whoami_token_status(creds, _token_expired)
    tier_info, credits_remaining = _whoami_billing_info(token_valid)
    if json_output:
        _whoami_json(creds, env_name, api_url, token_valid, expires_in_str, tier_info, credits_remaining)
    else:
        _whoami_text(creds, env_name, api_url, token_valid, expires_in_str, tier_info, credits_remaining)


def _status_check_config(checks: list[dict[str, Any]], config_dir: Path) -> None:
    assert isinstance(checks, list), "checks must be a list"
    assert isinstance(config_dir, Path), "config_dir must be a Path"

    if config_dir.exists() and config_dir.is_dir():
        checks.append({"name": "config_directory", "ok": True, "detail": str(config_dir)})
    else:
        checks.append({"name": "config_directory", "ok": False, "detail": f"{config_dir} not found"})


def _status_check_auth(checks: list[dict[str, Any]], load_creds_fn: Callable[..., Any], token_expired_fn: Callable[..., bool]) -> None:
    assert isinstance(checks, list), "checks must be a list"
    assert callable(load_creds_fn), "load_creds_fn must be callable"

    creds = load_creds_fn()
    if creds is None:
        checks.append({"name": "authentication", "ok": False, "detail": "Not logged in"})
    elif token_expired_fn(creds.access_token):
        checks.append({"name": "authentication", "ok": False, "detail": "Token expired"})
    else:
        checks.append({"name": "authentication", "ok": True, "detail": creds.email or "Authenticated"})


def _status_check_api(checks: list[dict[str, Any]], api_url: str) -> None:
    assert isinstance(checks, list), "checks must be a list"
    assert isinstance(api_url, str) and api_url, "api_url must be a non-empty string"

    import httpx
    try:
        with httpx.Client(timeout=10.0) as client:
            resp = client.get(f"{api_url}/health")
        if resp.status_code == 200:
            checks.append({"name": "api_reachable", "ok": True, "detail": api_url})
        else:
            checks.append({"name": "api_reachable", "ok": False, "detail": f"HTTP {resp.status_code}"})
    except httpx.ConnectError:
        checks.append({"name": "api_reachable", "ok": False, "detail": f"Connection failed ({api_url})"})
    except httpx.TimeoutException:
        checks.append({"name": "api_reachable", "ok": False, "detail": f"Timeout ({api_url})"})
    except httpx.RequestError as e:
        checks.append({"name": "api_reachable", "ok": False, "detail": f"Request failed: {e}"})


def _status_check_deps(checks: list[dict[str, Any]]) -> None:
    assert isinstance(checks, list), "checks must be a list"
    assert all(isinstance(c, dict) for c in checks), "all checks must be dicts"

    import platform as platform_module
    plat = platform_module.system().lower()
    deps_ok = True
    deps_detail = "OK"
    if plat == "linux":
        from .deps import DEPS_REGISTRY
        gpu_tools = ["ncu", "nsys", "rocprof", "rocprofv3"]
        any_gpu_tool = any(
            shutil.which(DEPS_REGISTRY[n].check_cmd) is not None
            for n in gpu_tools
            if n in DEPS_REGISTRY
        )
        if not any_gpu_tool:
            deps_ok = False
            deps_detail = "No GPU tools found (optional; run 'wafer settings deps check')"
    checks.append({"name": "deps", "ok": deps_ok, "detail": deps_detail})


def _status_print_text(checks: list[dict[str, Any]], all_ok: bool, check_sym: str, cross_sym: str) -> None:
    assert isinstance(checks, list) and checks, "checks must be a non-empty list"
    assert isinstance(all_ok, bool), "all_ok must be a bool"

    typer.echo("Wafer CLI Status")
    typer.echo("\u2500" * 30)
    for check in checks:
        symbol = check_sym if check["ok"] else cross_sym
        typer.echo(f"  {symbol} {check['name']}: {check['detail']}")
    if not all_ok:
        typer.echo("")
        typer.echo("Next steps:")
        for c in checks:
            if not c["ok"] and c["name"] == "authentication":
                typer.echo("  - Not logged in? Run: wafer settings login")
            elif not c["ok"] and c["name"] == "deps":
                typer.echo("  - Missing tools? Run: wafer settings deps check")
            elif not c["ok"] and c["name"] == "api_reachable":
                typer.echo("  - API unreachable. Check network or run: wafer settings login")


@settings_app.command("status")
def status(
    json_output: bool = typer.Option(False, "--json", "-j", help="Output as JSON"),
) -> None:
    """Check CLI health: version, config, auth, and API connectivity."""

    from .analytics import _get_cli_version
    from .auth import CHECK, CROSS, _token_expired, load_credentials
    from .global_config import CONFIG_DIR, get_api_url

    checks: list[dict] = []
    version = _get_cli_version()
    checks.append({"name": "cli_version", "ok": True, "detail": version})
    _status_check_config(checks, CONFIG_DIR)
    _status_check_auth(checks, load_credentials, _token_expired)
    _status_check_api(checks, get_api_url())
    _status_check_deps(checks)
    all_ok = all(c["ok"] for c in checks)
    if json_output:
        from .output import json_response
        data = {"cli_version": version, "all_ok": all_ok, "checks": checks}
        typer.echo(json_response(data=data, status="ok" if all_ok else "error"))
    else:
        _status_print_text(checks, all_ok, CHECK, CROSS)
    if all_ok:
        _mark_command_success()
    else:
        raise typer.Exit(1)


_GUIDE_SECTION_MAP = {
    "quickstart": "Quick Start", "quick": "Quick Start", "cloud": "Quick Start",
    "run": "Running Code on a GPU", "running": "Running Code on a GPU",
    "targets": "Managing Targets", "target": "Managing Targets", "manage": "Managing Targets",
    "docs": "Documentation Lookup", "documentation": "Documentation Lookup",
    "trace": "Trace Analysis", "analyze": "Trace Analysis", "analysis": "Trace Analysis",
    "evaluate": "Kernel Evaluation", "eval": "Kernel Evaluation",
    "optimize": "Kernel Optimization (AI-assisted)", "optimization": "Kernel Optimization (AI-assisted)",
    "commands": "Command Reference", "reference": "Command Reference", "ref": "Command Reference",
}


def _render_guide_markdown(content: str) -> None:
    assert isinstance(content, str) and content, "content must be a non-empty string"
    assert "#" in content, "content must contain markdown headers"

    from rich.console import Console
    from rich.markdown import Markdown
    Console().print(Markdown(content))


def _render_guide_section(content: str, section: str) -> None:
    assert isinstance(content, str) and content, "content must be a non-empty string"
    assert isinstance(section, str) and section, "section must be a non-empty string"

    from rich.console import Console
    from rich.markdown import Markdown
    section_lower = section.lower()
    if section_lower not in _GUIDE_SECTION_MAP:
        typer.echo(f"Error: Unknown section '{section}'", err=True)
        typer.echo("\nAvailable sections:", err=True)
        typer.echo("  quickstart, run, targets, docs, trace, evaluate, optimize, commands", err=True)
        raise typer.Exit(1)
    header = _GUIDE_SECTION_MAP[section_lower]
    section_content = _extract_section(content, header)
    if not section_content:
        typer.echo(f"Error: Section '{header}' not found in guide", err=True)
        raise typer.Exit(1)
    Console().print(Markdown(section_content))


@settings_app.command("guide")
def guide(
    section: str | None = typer.Argument(
        None,
        help="Show specific section: quickstart, run, targets, docs, trace, evaluate, optimize, commands",
    ),
    full: bool = typer.Option(
        False,
        "--full",
        "-f",
        help="Show full guide with rich formatting",
    ),
) -> None:
    """Show the Wafer CLI usage guide.
    By default, shows a table of contents. Use a section name to see specific content,
    or --full to see the entire guide with rich formatting.
    Examples:
      wafer settings guide                 # Show table of contents
      wafer settings guide quickstart      # Show Quick Start section
      wafer settings guide workspaces      # Show Workspaces section
      wafer settings guide --full          # Show full guide with formatting
    """
    guide_path = Path(__file__).parent / "GUIDE.md"
    if not guide_path.exists():
        typer.echo("Error: GUIDE.md not found", err=True)
        raise typer.Exit(1)
    content = guide_path.read_text()
    if full:
        _render_guide_markdown(content)
        return
    if section:
        _render_guide_section(content, section)
        return
    _show_guide_toc(content)


def _extract_section(content: str, header: str) -> str:
    """Extract a specific section from the guide markdown.
    Args:
        content: Full guide markdown content
        header: Section header to extract (e.g., "Quick Start")
    Returns:
        Section content including the header, up to the next ## header
    """
    lines = content.split("\n")
    section_lines = []
    in_section = False
    header_pattern = f"## {header}"
    for line in lines:
        if line.startswith(header_pattern):
            in_section = True
            section_lines.append(line)
        elif in_section:
            if line.startswith("## "):
                # Hit next section, stop
                break
            section_lines.append(line)
    return "\n".join(section_lines).strip()


def _show_guide_toc(content: str) -> None:
    """Show table of contents for the guide.
    Args:
        content: Full guide markdown content
    """
    from rich.console import Console
    from rich.panel import Panel
    from rich.text import Text
    lines = content.split("\n")
    title = ""
    sections = []
    for line in lines:
        if line.startswith("# "):
            title = line[2:].strip()
        elif line.startswith("## "):
            sections.append(line[3:].strip())
    console = Console()
    # Show title
    title_text = Text(title, style="bold cyan")
    console.print()
    console.print(title_text)
    console.print()
    # Show sections as a formatted list
    console.print("Available sections:", style="bold")
    console.print()
    section_aliases = [
        ("quickstart", "Quick Start"),
        ("run", "Running Code on a GPU"),
        ("targets", "Managing Targets"),
        ("docs", "Documentation Lookup"),
        ("trace", "Trace Analysis"),
        ("evaluate", "Kernel Evaluation"),
        ("optimize", "Kernel Optimization (AI-assisted)"),
        ("commands", "Command Reference"),
    ]
    for alias, section_name in section_aliases:
        console.print(f"  [cyan]wafer settings guide {alias:12}[/cyan]  {section_name}")
    console.print()
    # Show usage hint
    hint = Panel(
        "[dim]Use [cyan]wafer settings guide <section>[/cyan] to see specific content\n"
        "Use [cyan]wafer settings guide --full[/cyan] to see the entire guide with formatting[/dim]",
        border_style="dim",
    )
    console.print(hint)


@app.command("version")
def version_cmd(
    json_output: bool = typer.Option(False, "--json", "-j", help="Output as JSON"),
) -> None:
    """Show CLI version and exit."""
    _show_version(json_output=json_output)


demo_app = typer.Typer(
    help="""Interactive demos for Wafer workflows.
  wafer settings demo trace  Analyze a sample performance trace
  wafer settings demo eval   Run kernel evaluation on cloud GPU (requires login)"""
)
settings_app.add_typer(demo_app, name="demo")
DEMO_TRACES_URL = "https://github.com/wafer-ai/wafer/raw/main/packages/wafer-ai/wafer/cli/demo_data"
DEMO_DIR = Path.home() / ".cache" / "wafer" / "demo"


@demo_app.command("setup")
def demo_setup() -> None:
    """Download sample data for demos and tutorials.
    Downloads sample traces and kernels to ~/.cache/wafer/demo/
    Examples:
        wafer settings demo setup
        wafer settings demo traces     # list downloaded traces
        wafer tool perfetto query ~/.cache/wafer/demo/attention_trace.json "SELECT ..."
    """
    import shutil
    DEMO_DIR.mkdir(parents=True, exist_ok=True)
    # For now, copy bundled demo data from package
    # In future, could download from GitHub releases
    demo_source = Path(__file__).parent / "demo_data"
    if demo_source.exists():
        for f in demo_source.iterdir():
            dest = DEMO_DIR / f.name
            if not dest.exists():
                shutil.copy(f, dest)
                typer.echo(f"  ✓ {f.name}")
        typer.echo(f"\nDemo data ready at: {DEMO_DIR}")
    else:
        # Fallback: create minimal synthetic trace
        sample_trace = DEMO_DIR / "sample_trace.json"
        if not sample_trace.exists():
            sample_trace.write_text("""{
  "traceEvents": [
    {"name": "matmul_kernel", "cat": "kernel", "ph": "X", "ts": 0, "dur": 1500000, "pid": 1, "tid": 1},
    {"name": "relu_kernel", "cat": "kernel", "ph": "X", "ts": 1600000, "dur": 50000, "pid": 1, "tid": 1},
    {"name": "softmax_kernel", "cat": "kernel", "ph": "X", "ts": 1700000, "dur": 200000, "pid": 1, "tid": 1},
    {"name": "attention_kernel", "cat": "kernel", "ph": "X", "ts": 2000000, "dur": 3000000, "pid": 1, "tid": 1},
    {"name": "layernorm_kernel", "cat": "kernel", "ph": "X", "ts": 5100000, "dur": 100000, "pid": 1, "tid": 1}
  ]
}""")
            typer.echo("  ✓ sample_trace.json (synthetic)")
        typer.echo(f"\nDemo data ready at: {DEMO_DIR}")
    typer.echo("\nTry these commands:")
    typer.echo(f"  wafer tool perfetto tables {DEMO_DIR}/sample_trace.json")
    typer.echo(
        f"  wafer tool perfetto query {DEMO_DIR}/sample_trace.json "
        '"SELECT name, dur/1e6 as ms FROM slice ORDER BY dur DESC"'
    )


@demo_app.command("traces")
def demo_traces(
    json_output: bool = typer.Option(False, "--json", "-j", help="Output as JSON"),
) -> None:
    """List available demo traces.
    Shows demo traces in ~/.cache/wafer/demo/
    Run 'wafer settings demo setup' first to download sample data.
    """
    from .output import json_error, json_response
    if not DEMO_DIR.exists():
        if json_output:
            typer.echo(json_error("No demo data found. Run: wafer settings demo setup"))
        else:
            typer.echo("No demo data found. Run: wafer settings demo setup")
        raise typer.Exit(1)
    traces = list(DEMO_DIR.glob("*.json"))
    if not traces:
        if json_output:
            typer.echo(json_error("No traces found. Run: wafer settings demo setup"))
        else:
            typer.echo("No traces found. Run: wafer settings demo setup")
        raise typer.Exit(1)

    if json_output:
        trace_list = []
        for trace in sorted(traces):
            trace_list.append({
                "name": trace.name,
                "path": str(trace),
                "size_bytes": trace.stat().st_size,
            })
        typer.echo(json_response(data={"traces": trace_list, "demo_dir": str(DEMO_DIR)}))
        return

    typer.echo("Available demo traces:\n")
    for trace in sorted(traces):
        size_kb = trace.stat().st_size / 1024
        typer.echo(f"  {trace.name} ({size_kb:.1f} KB)")
        typer.echo(f"    {trace}")
    typer.echo("\nExample queries:")
    typer.echo("  # Slowest operations")
    typer.echo(
        f'  wafer tool perfetto query {traces[0]} "SELECT name, dur/1e6 as ms FROM slice ORDER BY dur DESC LIMIT 10"'
    )
    typer.echo("")
    typer.echo("  # Time breakdown by category")
    typer.echo(
        f'  wafer tool perfetto query {traces[0]} "SELECT cat, SUM(dur)/1e6 as total_ms FROM slice GROUP BY cat ORDER BY total_ms DESC"'
    )


@demo_app.command("trace")
def demo_trace(
    yes: bool = typer.Option(False, "--yes", "-y", help="Skip confirmation prompt"),
) -> None:
    """Demo: Analyze a performance trace.
    Creates a sample PyTorch trace and runs SQL queries on it.
    Example:
        wafer settings demo trace
        wafer settings demo trace -y  # skip confirmation
    """
    import subprocess
    if not yes:
        typer.echo("This demo will:")
        typer.echo("  1. Create a sample PyTorch-style trace")
        typer.echo("  2. Run SQL queries to find slowest kernels")
        typer.echo("")
        if not typer.confirm("Continue?"):
            raise typer.Exit(0)
    # Step 1: Setup demo data
    typer.echo("\n[1/2] Creating sample trace...")
    DEMO_DIR.mkdir(parents=True, exist_ok=True)
    sample_trace = DEMO_DIR / "sample_trace.json"
    sample_trace.write_text("""{
  "traceEvents": [
    {"name": "matmul_kernel", "cat": "kernel", "ph": "X", "ts": 0, "dur": 1500000, "pid": 1, "tid": 1},
    {"name": "relu_kernel", "cat": "kernel", "ph": "X", "ts": 1600000, "dur": 50000, "pid": 1, "tid": 1},
    {"name": "softmax_kernel", "cat": "kernel", "ph": "X", "ts": 1700000, "dur": 200000, "pid": 1, "tid": 1},
    {"name": "attention_kernel", "cat": "kernel", "ph": "X", "ts": 2000000, "dur": 3000000, "pid": 1, "tid": 1},
    {"name": "layernorm_kernel", "cat": "kernel", "ph": "X", "ts": 5100000, "dur": 100000, "pid": 1, "tid": 1}
  ]
}""")
    typer.echo(f"  Created: {sample_trace}")
    # Step 2: Query the trace
    typer.echo("\n[2/2] Finding slowest kernels...\n")
    typer.echo("-" * 60)
    result = subprocess.run(
        [
            "wafer",
            "tool",
            "perfetto",
            "query",
            str(sample_trace),
            "SELECT name, dur/1e6 as duration_ms FROM slice ORDER BY dur DESC",
        ],
        check=False,
    )
    typer.echo("-" * 60)
    if result.returncode == 0:
        typer.echo("\n✓ Demo complete! Try your own traces:")
        typer.echo('  wafer tool perfetto query <your_trace.json> "SELECT name, dur FROM slice"')
        typer.echo("")
        typer.echo("  Or use AI-assisted analysis:")
        typer.echo('  wafer agent -t trace-analyze --args trace=<your_trace.json> "What\'s slow?"')
    else:
        typer.echo("\n✗ Demo failed.")
        raise typer.Exit(1)


def _demo_eval_confirm() -> None:
    typer.echo("This demo will:")
    typer.echo("  1. Create a cloud GPU workspace (B200)")
    typer.echo("  2. Generate and upload a sample Triton kernel")
    typer.echo("  3. Run correctness + performance evaluation")
    typer.echo("  4. Delete the workspace")
    typer.echo("")
    typer.echo("  Note: Workspace usage is billed. Demo takes ~2-3 minutes.")
    typer.echo("")
    if not typer.confirm("Continue?"):
        raise typer.Exit(0)


def _demo_eval_create_workspace(subprocess: ModuleType, workspace_name: str) -> str:
    assert hasattr(subprocess, "run"), "subprocess must have a run method"
    assert isinstance(workspace_name, str) and workspace_name, "workspace_name must be a non-empty string"

    import json
    typer.echo(f"\n[1/4] Creating workspace '{workspace_name}'...")
    result = subprocess.run(
        ["wafer", "target", "init", "workspace", workspace_name, "--gpu", "B200", "--json"],
        capture_output=True, text=True, check=True,
    )
    ws_info = json.loads(result.stdout)
    workspace_id = ws_info.get("id", workspace_name)
    typer.echo(f"  Created: {workspace_id}")
    return workspace_id


_DEMO_TEST_SCRIPT = """\
import torch
import kernel
import reference
print(f"GPU: {torch.cuda.get_device_name(0)}")
inputs = reference.generate_input(n=1048576, seed=42)
out = kernel.custom_kernel(inputs)
ref = reference.ref_kernel(inputs)
correct = torch.allclose(out, ref)
print(f"Correctness: {correct}")
import time
for _ in range(10):
    kernel.custom_kernel(inputs)
torch.cuda.synchronize()
t0 = time.perf_counter()
for _ in range(100):
    kernel.custom_kernel(inputs)
torch.cuda.synchronize()
t1 = time.perf_counter()
print(f"Performance: {(t1-t0)/100*1e6:.1f} us/iter")
"""


def _demo_eval_run_kernel(subprocess: ModuleType, workspace_name: str, kernel_dir: Path) -> Any:
    assert isinstance(workspace_name, str) and workspace_name, "workspace_name must be a non-empty string"
    assert isinstance(kernel_dir, Path), "kernel_dir must be a Path"

    typer.echo("\n[3/4] Running evaluation on cloud GPU...\n")
    typer.echo("-" * 60)
    test_script = kernel_dir / "run_test.py"
    test_script.write_text(_DEMO_TEST_SCRIPT)
    eval_result = subprocess.run(
        [
            "wafer", "target", "run", "--name", workspace_name,
            "--sync", str(kernel_dir), "--", "bash", "-c",
            "cd /workspace && uv pip install -q --system triton && python run_test.py",
        ],
        check=False,
    )
    typer.echo("-" * 60)
    return eval_result


def _demo_eval_cleanup(subprocess: ModuleType, workspace_name: str, workspace_id: str, eval_result: Any) -> None:
    assert isinstance(workspace_name, str) and workspace_name, "workspace_name must be a non-empty string"
    assert isinstance(workspace_id, str) and workspace_id, "workspace_id must be a non-empty string"

    typer.echo(f"\n[4/4] Deleting workspace '{workspace_name}'...")
    subprocess.run(
        ["wafer", "target", "remove", "--yes", workspace_id],
        capture_output=True, check=False,
    )
    typer.echo("  Deleted")
    if eval_result.returncode == 0:
        typer.echo("\nDemo complete! To evaluate your own kernels:")
        typer.echo("")
        typer.echo("  # Using workspaces (no setup required):")
        typer.echo("  wafer target init workspace dev --gpu B200")
        typer.echo("  wafer target run --name dev --sync ./my-kernel -- python my_test.py")
        typer.echo("")
        typer.echo("  # Or using wafer tool eval:")
        typer.echo("  wafer target run --name dev -- wafer tool eval --task kernelbench")
    else:
        typer.echo("\nEvaluation failed, but workspace was cleaned up.")
        raise typer.Exit(1)


def _demo_eval_force_cleanup(subprocess: ModuleType, workspace_name: str) -> None:
    assert hasattr(subprocess, "run"), "subprocess must have a run method"
    assert isinstance(workspace_name, str) and workspace_name, "workspace_name must be a non-empty string"

    typer.echo(f"Attempting to cleanup workspace '{workspace_name}'...")
    subprocess.run(
        ["wafer", "target", "remove", "--yes", workspace_name],
        capture_output=True, check=False,
    )


def _write_demo_kernel_files(kernel_dir: Path) -> None:
    """Write demo kernel files for the eval demo."""
    (kernel_dir / "kernel.py").write_text(
        "import torch\nimport triton\nimport triton.language as tl\n\n"
        "@triton.jit\ndef add_kernel(x_ptr, y_ptr, out_ptr, n, BLOCK: tl.constexpr):\n"
        "    pid = tl.program_id(0)\n    offsets = pid * BLOCK + tl.arange(0, BLOCK)\n"
        "    mask = offsets < n\n    x = tl.load(x_ptr + offsets, mask=mask)\n"
        "    y = tl.load(y_ptr + offsets, mask=mask)\n"
        "    tl.store(out_ptr + offsets, x + y, mask=mask)\n\n"
        "def custom_kernel(inputs):\n    x, y = inputs\n    out = torch.empty_like(x)\n"
        "    n = x.numel()\n    add_kernel[(n + 1023) // 1024,](x, y, out, n, BLOCK=1024)\n"
        "    return out\n"
    )
    (kernel_dir / "reference.py").write_text(
        "import torch\n\ndef ref_kernel(inputs):\n    x, y = inputs\n    return x + y\n\n"
        "def generate_input(n=1048576, seed=42):\n    torch.manual_seed(seed)\n"
        "    return torch.randn(n, device='cuda'), torch.randn(n, device='cuda')\n"
    )


@demo_app.command("eval")
def demo_eval(
    yes: bool = typer.Option(False, "--yes", "-y", help="Skip confirmation prompt"),
) -> None:
    """Demo: Evaluate a kernel on a cloud GPU.
    Creates a workspace, runs a sample Triton kernel evaluation, and cleans up.
    Requires authentication (wafer settings login).
    Example:
        wafer settings demo eval
        wafer settings demo eval -y  # skip confirmation
    """
    import subprocess
    import tempfile
    import time

    from .auth import load_credentials
    creds = load_credentials()
    if not creds:
        typer.echo("Error: Not authenticated. Run: wafer settings login")
        raise typer.Exit(1)
    if not yes:
        _demo_eval_confirm()
    workspace_name = f"wafer-demo-{int(time.time()) % 100000}"
    try:
        workspace_id = _demo_eval_create_workspace(subprocess, workspace_name)
        typer.echo("\n[2/4] Generating sample kernel...")
        with tempfile.TemporaryDirectory() as tmpdir:
            kernel_dir = Path(tmpdir) / "demo-kernel"
            kernel_dir.mkdir(parents=True)
            _write_demo_kernel_files(kernel_dir)
            typer.echo("  Generated Triton vector-add kernel")
            eval_result = _demo_eval_run_kernel(subprocess, workspace_name, kernel_dir)
        _demo_eval_cleanup(subprocess, workspace_name, workspace_id, eval_result)
    except subprocess.CalledProcessError as e:
        error_msg = e.stderr.strip() if e.stderr else str(e)
        typer.echo(f"\n Error: {error_msg}")
        _demo_eval_force_cleanup(subprocess, workspace_name)
        raise typer.Exit(1) from None
    except KeyboardInterrupt:
        typer.echo(f"\n\nInterrupted. Cleaning up workspace '{workspace_name}'...")
        _demo_eval_force_cleanup(subprocess, workspace_name)
        raise typer.Exit(1) from None


init_app = typer.Typer(
    help="""Initialize a new accelerator target.
Choose based on your hardware access:
  local        Accelerator on current machine (no SSH)
  ssh          Your own hardware via SSH (GPU, Trainium, TPU, etc.)
  runpod       RunPod cloud GPUs (needs WAFER_RUNPOD_API_KEY)
  digitalocean DigitalOcean AMD MI300X (needs WAFER_AMD_DIGITALOCEAN_API_KEY)"""
)
target_app.add_typer(init_app, name="init")


@init_app.command("local")
def init_local(
    name: str = typer.Option("local", "--name", "-n", help="Target name"),
    gpu_ids: str = typer.Option("0", "--gpu-ids", "-g", help="Comma-separated device IDs (GPU/Neuron index)"),
) -> None:
    """Initialize a local target for accelerator on current machine.
    Detects your local accelerator (NVIDIA, AMD, Trainium, TPU) and configures
    a target for direct execution (no SSH).
    Examples:
        wafer target init local
        wafer target init local --name my-5090 --gpu-ids 0,1
    """
    from .targets import save_target
    try:
        parsed_gpu_ids = [int(g.strip()) for g in gpu_ids.split(",")]
    except ValueError:
        typer.echo(f"Error: Invalid GPU IDs '{gpu_ids}'. Use comma-separated integers.", err=True)
        raise typer.Exit(1) from None
    typer.echo("Detecting local GPU...")
    try:
        from wafer.core.gpu_detect import (
            detect_local_gpu,
            get_compute_capability,
            get_torch_requirements,
        )
        detected_gpu = detect_local_gpu()
        if detected_gpu:
            typer.echo(f"  Found: {detected_gpu.gpu_name}")
            if detected_gpu.vendor == "nvidia":
                typer.echo(f"  CUDA: {detected_gpu.driver_version}")
            elif detected_gpu.vendor == "amd":
                typer.echo(f"  ROCm: {detected_gpu.driver_version}")
            elif detected_gpu.vendor == "trainium":
                typer.echo(f"  Neuron: {detected_gpu.driver_version}")
            elif detected_gpu.vendor == "tpu":
                typer.echo("  TPU (XLA)")
            else:
                typer.echo(f"  Driver: {detected_gpu.driver_version}")
            typer.echo(f"  GPU count: {detected_gpu.gpu_count}")
            torch_reqs = get_torch_requirements(detected_gpu)
            compute_capability = get_compute_capability(detected_gpu)
            gpu_type = _extract_gpu_type(detected_gpu.gpu_name)
            typer.echo(f"  PyTorch: {torch_reqs.packages[0]}")
        else:
            typer.echo("  No accelerator detected (nvidia-smi/rocm-smi/neuron-ls not found)", err=True)
            raise typer.Exit(1)
    except ImportError as e:
        typer.echo(f"Error: Missing dependency: {e}", err=True)
        raise typer.Exit(1) from None
    target_data = {
        "name": name,
        "type": "local",
        "gpu_ids": parsed_gpu_ids,
        "gpu_type": gpu_type,
        "compute_capability": compute_capability,
        "torch_package": torch_reqs.packages[0],
        "torch_index_url": torch_reqs.index_url,
        "vendor": detected_gpu.vendor,
        "driver_version": detected_gpu.driver_version,
    }
    try:
        target = save_target(target_data)
        typer.echo(f"✓ Created target: {target.name}")
        typer.echo("  Type: Local (no SSH)")
        typer.echo(f"  GPU IDs: {parsed_gpu_ids}")
        typer.echo(f"  GPU Type: {gpu_type}")
        typer.echo(f"  Compute: {compute_capability}")
        typer.echo(f"  Torch: {torch_reqs.packages[0]}")
        typer.echo("")
        typer.echo(
            f"Usage: wafer target run --name {name} -- wafer tool eval --task kernelbench"
        )
    except (ValueError, AssertionError) as e:
        typer.echo(f"Error: {e}", err=True)
        raise typer.Exit(1) from None


_RUNPOD_GPU_CONFIGS = {
    "MI300X": {
        "gpu_type_id": "AMD Instinct MI300X OAM",
        "image": "rocm/pytorch:rocm7.0.2_ubuntu24.04_py3.12_pytorch_release_2.7.1",
        "compute_capability": "9.4",
    },
    "H100": {
        "gpu_type_id": "NVIDIA H100 80GB HBM3",
        "image": "runpod/pytorch:2.4.0-py3.11-cuda12.4.1-devel-ubuntu22.04",
        "compute_capability": "9.0",
    },
    "A100": {
        "gpu_type_id": "NVIDIA A100 80GB PCIe",
        "image": "runpod/pytorch:2.4.0-py3.11-cuda12.4.1-devel-ubuntu22.04",
        "compute_capability": "8.0",
    },
}


def _runpod_build_target_data(
    name: str, ssh_key: str, gpu_type: str, config: dict[str, str], keep_alive: bool,
) -> dict[str, Any]:
    assert isinstance(name, str) and name, "name must be a non-empty string"
    assert gpu_type in _RUNPOD_GPU_CONFIGS, f"gpu_type must be a valid GPU type: {gpu_type}"

    return {
        "name": name, "type": "runpod", "ssh_key": ssh_key,
        "gpu_type_id": config["gpu_type_id"], "gpu_count": 1,
        "container_disk_gb": 50, "image": config["image"],
        "provision_timeout": 900, "eval_timeout": 600,
        "keep_alive": keep_alive, "gpu_type": gpu_type,
        "compute_capability": config["compute_capability"],
        "gpu_ids": [0], "ncu_available": False,
    }


@init_app.command("runpod")
def init_runpod(
    name: str = typer.Option("runpod-mi300x", "--name", "-n", help="Target name"),
    gpu_type: str = typer.Option("MI300X", "--gpu", "-g", help="GPU type (MI300X, H100, A100)"),
    ssh_key: str = typer.Option("~/.ssh/id_ed25519", "--ssh-key", "-k", help="Path to SSH key"),
    keep_alive: bool = typer.Option(
        True, "--keep-alive/--no-keep-alive", help="Keep pod running after eval"
    ),
) -> None:
    """Initialize a RunPod target.
    Creates a target config for auto-provisioned RunPod GPUs.
    Requires WAFER_RUNPOD_API_KEY environment variable.
    Examples:
        wafer target init runpod
        wafer target init runpod --name my-runpod --gpu H100
    """
    import os

    from .targets import save_target

    api_key = os.environ.get("WAFER_RUNPOD_API_KEY", "")
    if not api_key:
        typer.echo("Error: WAFER_RUNPOD_API_KEY environment variable not set.", err=True)
        typer.echo("", err=True)
        typer.echo("Get your API key from: https://runpod.io/console/user/settings", err=True)
        typer.echo("Then run: export WAFER_RUNPOD_API_KEY=your_key_here", err=True)
        raise typer.Exit(1)
    if gpu_type not in _RUNPOD_GPU_CONFIGS:
        typer.echo(
            f"Error: Unknown GPU type '{gpu_type}'. Available: {', '.join(_RUNPOD_GPU_CONFIGS.keys())}",
            err=True,
        )
        raise typer.Exit(1)
    config = _RUNPOD_GPU_CONFIGS[gpu_type]
    target_data = _runpod_build_target_data(name, ssh_key, gpu_type, config, keep_alive)
    try:
        target = save_target(target_data)
        typer.echo(f"\u2713 Created target: {target.name}")
        typer.echo("  Type: RunPod")
        typer.echo(f"  GPU: {gpu_type}")
        typer.echo(f"  Image: {config['image']}")
        typer.echo(f"  Keep alive: {'Yes' if keep_alive else 'No'}")
        typer.echo("")
        typer.echo(
            f"Usage: wafer target run --name {name} -- wafer tool eval --task kernelbench"
        )
    except (ValueError, AssertionError) as e:
        typer.echo(f"Error: {e}", err=True)
        raise typer.Exit(1) from None


@init_app.command("digitalocean")
def init_digitalocean(
    name: str = typer.Option("do-mi300x", "--name", "-n", help="Target name"),
    region: str = typer.Option("atl1", "--region", "-r", help="Region (atl1)"),
    ssh_key: str = typer.Option("~/.ssh/id_ed25519", "--ssh-key", "-k", help="Path to SSH key"),
    keep_alive: bool = typer.Option(
        True, "--keep-alive/--no-keep-alive", help="Keep droplet running after eval"
    ),
) -> None:
    """Initialize a DigitalOcean target.
    Creates a target config for auto-provisioned DigitalOcean AMD GPUs (MI300X).
    Requires WAFER_AMD_DIGITALOCEAN_API_KEY environment variable.
    Examples:
        wafer target init digitalocean
        wafer target init digitalocean --name my-do --region atl1
    """
    import os

    from .targets import save_target
    api_key = os.environ.get("WAFER_AMD_DIGITALOCEAN_API_KEY", "")
    if not api_key:
        typer.echo("Error: WAFER_AMD_DIGITALOCEAN_API_KEY environment variable not set.", err=True)
        typer.echo("", err=True)
        typer.echo("Get your API key from the DigitalOcean AMD Developer Cloud portal.", err=True)
        typer.echo("Then run: export WAFER_AMD_DIGITALOCEAN_API_KEY=your_key_here", err=True)
        raise typer.Exit(1)
    target_data = {
        "name": name,
        "type": "digitalocean",
        "ssh_key": ssh_key,
        "region": region,
        "size_slug": "gpu-mi300x1-192gb-devcloud",
        "image": "amd-pytorchrocm7",  # PyTorch (ROCm7) marketplace image
        "provision_timeout": 600,
        "eval_timeout": 600,
        "keep_alive": keep_alive,
        "gpu_type": "MI300X",
        "compute_capability": "9.4",
        "gpu_ids": [0],
        "ncu_available": False,
    }
    try:
        target = save_target(target_data)
        typer.echo(f"✓ Created target: {target.name}")
        typer.echo("  Type: DigitalOcean")
        typer.echo("  GPU: MI300X")
        typer.echo(f"  Region: {region}")
        typer.echo(f"  Keep alive: {'Yes' if keep_alive else 'No'}")
        typer.echo("")
        typer.echo(
            f"Usage: wafer target run --name {name} -- wafer tool eval --task kernelbench"
        )
    except (ValueError, AssertionError) as e:
        typer.echo(f"Error: {e}", err=True)
        raise typer.Exit(1) from None


def _ssh_detect_gpu(host: str, ssh_key: str) -> tuple[Any, str | None, str | None]:
    assert isinstance(host, str) and host, "host must be a non-empty string"
    assert isinstance(ssh_key, str) and ssh_key, "ssh_key must be a non-empty string"

    typer.echo(f"Connecting to {host}...")
    detected_gpu, torch_package, torch_index_url = None, None, None
    try:
        import trio
        import trio_asyncio

        from wafer.core.async_ssh import AsyncSSHClient
        from wafer.core.gpu_detect import detect_remote_gpu, get_torch_requirements

        expanded_key = str(Path(ssh_key).expanduser())

        async def _detect() -> None:
            nonlocal detected_gpu, torch_package, torch_index_url
            async with trio_asyncio.open_loop():
                async with AsyncSSHClient(host, expanded_key) as client:
                    detected_gpu = await detect_remote_gpu(client)

        trio.run(_detect)
        if detected_gpu:
            typer.echo(f"  Found: {detected_gpu.gpu_name}")
            if detected_gpu.vendor == "nvidia":
                typer.echo(f"  CUDA: {detected_gpu.driver_version}")
            else:
                typer.echo(f"  ROCm: {detected_gpu.driver_version}")
            torch_reqs = get_torch_requirements(detected_gpu)
            torch_package = torch_reqs.packages[0]
            torch_index_url = torch_reqs.index_url
            typer.echo(f"  PyTorch: {torch_package}")
        else:
            typer.echo("  No GPU detected (nvidia-smi/rocm-smi not found)")
    except Exception as e:
        typer.echo(f"  Detection failed: {e}", err=True)
    return detected_gpu, torch_package, torch_index_url


def _ssh_compute_capability(detected_gpu: Any, gpu_type: str) -> str:
    assert isinstance(gpu_type, str) and gpu_type, "gpu_type must be a non-empty string"
    assert detected_gpu is None or hasattr(detected_gpu, "vendor"), "detected_gpu must have vendor attribute or be None"

    if detected_gpu:
        from wafer.core.gpu_detect import get_compute_capability
        return get_compute_capability(detected_gpu)
    gpu_upper = gpu_type.upper()
    if "TRAINIUM" in gpu_upper or "TRN1" in gpu_upper or "TRN2" in gpu_upper:
        return "0.0"
    if "TPU" in gpu_upper:
        return "0.0"
    compute_caps = {
        "B200": "10.0", "H100": "9.0", "A100": "8.0", "A10": "8.6",
        "V100": "7.0", "MI300X": "9.4", "MI250X": "9.0",
        "RTX 5090": "10.0", "RTX 4090": "8.9", "RTX 3090": "8.6",
    }
    return compute_caps.get(gpu_type, "8.0")


def _print_ssh_target_summary(
    target: Any, host: str, gpu_ids: list[int], gpu_type: str,
    compute_capability: str, ncu: bool, docker_image: str | None,
    torch_package: str | None, name: str,
) -> None:
    assert isinstance(name, str) and name, "name must be a non-empty string"
    assert isinstance(host, str) and host, "host must be a non-empty string"

    typer.echo(f"\u2713 Created target: {target.name}")
    typer.echo("  Type: Baremetal (SSH)")
    typer.echo(f"  Host: {host}")
    typer.echo(f"  GPU IDs: {gpu_ids}")
    typer.echo(f"  GPU Type: {gpu_type}")
    typer.echo(f"  Compute: {compute_capability}")
    typer.echo(f"  NCU: {'Yes' if ncu else 'No'}")
    if docker_image:
        typer.echo(f"  Docker: {docker_image}")
    if torch_package:
        typer.echo(f"  Torch: {torch_package}")
    typer.echo("")
    typer.echo(
        f"Usage: wafer target run --name {name} -- wafer tool eval --task kernelbench"
    )


@init_app.command("ssh")
def init_ssh(
    name: str = typer.Option(..., "--name", "-n", help="Target name"),
    host: str = typer.Option(..., "--host", "-H", help="SSH host (user@hostname:port)"),
    ssh_key: str = typer.Option("~/.ssh/id_ed25519", "--ssh-key", "-k", help="Path to SSH key"),
    gpu_ids: str = typer.Option("0", "--gpu-ids", "-g", help="Comma-separated device IDs (GPU/Neuron index)"),
    gpu_type: str | None = typer.Option(
        None, "--gpu-type", help="Accelerator type: B200, MI300X, Trainium, TPU, other (auto-detected if not specified)"
    ),
    vendor: str | None = typer.Option(
        None, "--vendor", "-v", help="Accelerator vendor: nvidia, amd, trainium, tpu, other"
    ),
    docker_image: str | None = typer.Option(
        None, "--docker-image", "-d", help="Docker image (optional)"
    ),
    ncu: bool = typer.Option(False, "--ncu/--no-ncu", help="NCU profiling available"),
    no_detect: bool = typer.Option(False, "--no-detect", help="Skip GPU auto-detection"),
) -> None:
    """Initialize an SSH target for your own GPU hardware.

    Auto-detects GPU type and selects compatible PyTorch version.

    Examples:
        wafer target init ssh --name my-gpu --host user@192.168.1.100:22
        wafer target init ssh --name lab-h100 --host ubuntu@gpu.lab.com:22 --ncu
    """
    from .targets import save_target
    try:
        parsed_gpu_ids = [int(g.strip()) for g in gpu_ids.split(",")]
    except ValueError:
        typer.echo(f"Error: Invalid GPU IDs '{gpu_ids}'. Use comma-separated integers.", err=True)
        raise typer.Exit(1) from None
    if ":" not in host:
        typer.echo(f"Error: Host must include port (user@hostname:port), got: {host}", err=True)
        typer.echo("Example: user@192.168.1.100:22", err=True)
        raise typer.Exit(1)
    detected_gpu, torch_package, torch_index_url = None, None, None
    if not no_detect:
        detected_gpu, torch_package, torch_index_url = _ssh_detect_gpu(host, ssh_key)
        if detected_gpu and not gpu_type:
            gpu_type = _extract_gpu_type(detected_gpu.gpu_name)
        elif not gpu_type:
            gpu_type = "B200"
            typer.echo(f"  Using default: {gpu_type}")
    if not gpu_type:
        gpu_type = "B200"
    compute_capability = _ssh_compute_capability(detected_gpu, gpu_type)
    target_data = {
        "name": name, "type": "baremetal", "ssh_target": host, "ssh_key": ssh_key,
        "gpu_ids": parsed_gpu_ids, "gpu_type": gpu_type,
        "compute_capability": compute_capability, "ncu_available": ncu,
    }
    if vendor is not None:
        if vendor not in _KNOWN_ACCELERATOR_TYPES:
            typer.echo(f"Error: vendor must be one of {_KNOWN_ACCELERATOR_TYPES}", err=True)
            raise typer.Exit(1)
        target_data["vendor"] = vendor
    if docker_image:
        target_data["docker_image"] = docker_image
    if torch_package:
        target_data["torch_package"] = torch_package
    if torch_index_url:
        target_data["torch_index_url"] = torch_index_url
    try:
        target = save_target(target_data)
        _print_ssh_target_summary(target, host, parsed_gpu_ids, gpu_type, compute_capability, ncu, docker_image, torch_package, name)
    except (ValueError, AssertionError) as e:
        typer.echo(f"Error: {e}", err=True)
        raise typer.Exit(1) from None


@init_app.command("workspace")
def init_workspace(
    name: str = typer.Argument(..., help="Workspace name"),
    gpu_type: str = typer.Option(
        "B200", "--gpu", "-g",
        help="Accelerator type: B200, MI300X, Trainium, TPU (default: B200). Backend may not support all.",
    ),
    environment_type: str = typer.Option("baremetal", "--env", "-e", help="Environment type"),
    image: str | None = typer.Option(None, "--image", "-i", help="Docker image"),
    wait: bool = typer.Option(False, "--wait", "-w", help="Wait for provisioning"),
    json_output: bool = typer.Option(False, "--json", "-j", help="Output as JSON"),
) -> None:
    """Create a cloud GPU workspace.

    Available GPUs:
        MI300X  AMD Instinct MI300X (192GB HBM3, ROCm)
        B200    NVIDIA Blackwell B200 (180GB HBM3e, CUDA)

    Examples:
        wafer target init workspace dev                  # B200 baremetal (defaults)
        wafer target init workspace dev --gpu MI300X     # AMD MI300X
        wafer target init workspace dev --wait           # Wait for provisioning
    """
    from .workspaces import create_workspace
    assert name, "Workspace name must be non-empty"
    try:
        result = create_workspace(
            name,
            gpu_type=gpu_type,
            environment_type=environment_type,
            image=image,
            wait=wait,
            json_output=json_output,
        )
        typer.echo(result)
    except RuntimeError as e:
        if json_output:
            from .output import json_error
            typer.echo(json_error(str(e)))
        else:
            typer.echo(f"Error: {e}", err=True)
        raise typer.Exit(1) from None


_KNOWN_GPU_TYPES = [
    "B200", "B100", "H200", "H100", "A100", "A10", "V100",
    "RTX 5090", "RTX 5080", "RTX 4090", "RTX 4080", "RTX 3090", "RTX 3080",
    "MI300X", "MI250X", "MI100",
    "Trainium2", "Trainium", "Trn2", "Trn1",
    "TPUv5", "TPUv4", "TPU",
]

_KNOWN_ACCELERATOR_TYPES = ("nvidia", "amd", "trainium", "tpu", "other")


def _extract_gpu_type(gpu_name: str) -> str:
    """Extract GPU type from full GPU name.
    Examples:
        "NVIDIA H100 80GB HBM3" -> "H100"
        "NVIDIA GeForce RTX 4090" -> "RTX 4090"
        "AMD Instinct MI300X OAM" -> "MI300X"
    """
    assert gpu_name, "GPU name must be non-empty"
    gpu_name_upper = gpu_name.upper()
    for gpu_type in _KNOWN_GPU_TYPES:
        if gpu_type in gpu_name_upper:
            return gpu_type
    return gpu_name.replace("NVIDIA ", "").replace("AMD ", "").strip()


def _resolve_target_type(name: str) -> tuple[str, dict | None]:
    """Determine if *name* is a workspace or a local host target.

    Returns ("workspace", ws_dict) or ("host", None).
    Raises RuntimeError if name is not found as either type,
    or if the name matches both (ambiguous).
    """
    assert name, "Target name must be non-empty"
    ws_match: dict | None = None
    try:
        from .workspaces import _list_workspaces_raw
        for ws in _list_workspaces_raw():
            if ws.get("name") == name or ws.get("id") == name:
                ws_match = ws
                break
    except RuntimeError:
        pass  # API unreachable or not authed
    from .targets import list_targets
    is_host = name in list_targets()
    if ws_match and is_host:
        raise RuntimeError(
            f"Target '{name}' exists as both a workspace and a host.\n"
            "  Remove one to resolve the ambiguity, or rename the host:\n"
            f"    wafer target remove {name}   (removes workspace)\n"
            f"    wafer target show {name}     (currently picks workspace)"
        )
    if ws_match:
        return ("workspace", ws_match)
    if is_host:
        return ("host", None)
    raise RuntimeError(
        f"Target '{name}' not found as workspace or host.\n"
        "  List targets: wafer target list\n"
        "  Create one:   wafer target init --help"
    )


def _resolve_show_status(quiet: bool, verbose: bool) -> bool:
    """Resolve show_status from quiet/verbose flags and user preferences."""
    if quiet:
        return False
    if verbose:
        return True
    from .global_config import get_preferences
    return get_preferences().mode == "explicit"


def _make_progress_callback(show_status: bool) -> Callable[[str], None]:
    """Create a progress callback that prints to stderr when show_status is True."""
    def on_progress(msg: str) -> None:
        if show_status:
            typer.echo(f"[wafer] {msg}", err=True)
    return on_progress


def _exit_with_error(msg: str) -> None:
    """Print error to stderr and exit with code 1."""
    typer.echo(f"Error: {msg}", err=True)
    raise typer.Exit(1) from None


def _gather_workspace_targets(gpu_filter: str | None = None, running_only: bool = False) -> list[tuple[str, str, dict]]:
    """Gather workspace targets, optionally filtered by GPU type.

    Returns list of (name, "workspace", ws_dict) tuples.
    """
    results: list[tuple[str, str, dict]] = []
    try:
        from .workspaces import _list_workspaces_raw
        for ws in _list_workspaces_raw():
            if running_only and ws.get("status") != "running":
                continue
            if gpu_filter and ws.get("gpu_type", "").upper() != gpu_filter.upper():
                continue
            results.append((ws["name"], "workspace", ws))
    except RuntimeError:
        pass  # API unreachable
    return results


def _gather_host_targets(gpu_filter: str | None = None) -> list[tuple[str, str]]:
    """Gather local host targets, optionally filtered by GPU type.

    Returns list of (name, "host") tuples.
    """
    from .targets import list_targets, load_target
    results: list[tuple[str, str]] = []
    for tname in list_targets():
        try:
            t = load_target(tname)
            if gpu_filter:
                t_gpu = getattr(t, "gpu_type", getattr(t, "gpu_type_id", ""))
                if t_gpu.upper() != gpu_filter.upper():
                    continue
            results.append((tname, "host"))
        except (FileNotFoundError, ValueError, TypeError):  # TypeError: malformed config
            pass
    return results


def _pick_from_candidates(candidates: list[tuple[str, str]], label: str) -> tuple[str, str]:
    """Interactive picker when multiple targets match. Returns (name, kind).

    In non-TTY mode, prints an error and exits.
    """
    assert len(candidates) > 1
    has_tty = sys.stdin.isatty() and sys.stdout.isatty()
    if has_tty:
        typer.echo(f"{label}:")
        for i, (cname, ckind) in enumerate(candidates, 1):
            typer.echo(f"  {i}. {cname} ({ckind})")
        choice = typer.prompt("Select target", type=int, default=1)
        if 1 <= choice <= len(candidates):
            return candidates[choice - 1]
        typer.echo("Invalid selection.", err=True)
        raise typer.Exit(1)
    names = ", ".join(c[0] for c in candidates)
    typer.echo(f"Error: {label}: {names}", err=True)
    typer.echo("  Use --name to specify which one.", err=True)
    raise typer.Exit(1)


def _get_workspace_ssh_creds(ws_data: dict) -> tuple[str, int, str]:
    """Extract and validate SSH credentials from workspace data.

    Returns (host, port, user). Exits if workspace not ready.
    """
    ssh_host = ws_data.get("ssh_host")
    ssh_port = ws_data.get("ssh_port")
    ssh_user = ws_data.get("ssh_user")
    if not ssh_host:
        _exit_with_error("Workspace SSH host not available yet. Wait a few seconds and retry.")
    if not ssh_port:
        _exit_with_error("Workspace SSH port not available yet. Wait a few seconds and retry.")
    if not ssh_user:
        _exit_with_error("Workspace SSH user not available yet. Wait a few seconds and retry.")
    assert ssh_host and ssh_port and ssh_user
    return ssh_host, int(ssh_port), ssh_user


def _build_workspace_ssh_args(host: str, port: int, user: str) -> list[str]:
    """Build SSH command args for a workspace connection."""
    return [
        "ssh",
        "-p", str(port),
        "-o", "StrictHostKeyChecking=no",
        "-o", "UserKnownHostsFile=/dev/null",
        f"{user}@{host}",
    ]


def _build_host_ssh_args(ssh_info: "TargetSSHInfo") -> list[str]:
    """Build SSH command args for a host target connection."""
    return [
        "ssh",
        "-i", str(ssh_info.key_path),
        "-p", str(ssh_info.port),
        "-o", "StrictHostKeyChecking=no",
        "-o", "UserKnownHostsFile=/dev/null",
        f"{ssh_info.user}@{ssh_info.host}",
    ]


def _format_workspace_list_item(ws: dict) -> tuple[str, dict]:
    """Format a workspace for list display. Returns (line, json_item)."""
    from .targets import get_default_target
    default = get_default_target()
    status = ws.get("status", "unknown")
    status_icon = {"running": "\u25cf", "creating": "\u25d0", "error": "\u2717"}.get(status, "?")
    gpu = ws.get("gpu_type", "N/A")
    marker = " *" if ws["name"] == default else ""
    line = f"  {status_icon} {(ws['name'] + marker):<22} {gpu:<10} workspace   {status}"
    json_item = {
        "name": ws["name"],
        "type": "workspace",
        "gpu_type": gpu,
        "status": status,
        "id": ws.get("id"),
        "default": ws["name"] == default,
    }
    return line, json_item


@target_app.command("list")
def unified_list(
    json_output: bool = typer.Option(False, "--json", "-j", help="Output as JSON"),
    sync: bool = typer.Option(
        False, "--sync", "-s",
        help="Live-check statuses (slower).",
    ),
) -> None:
    """List all targets (workspaces + hosts).

    Examples:
        wafer target list
        wafer target list --json
        wafer target list --sync
    """
    workspace_lines, ws_json_items = _list_workspace_items(sync)
    host_lines, host_json_items = _list_host_items()

    if json_output:
        from .output import json_response
        typer.echo(json_response(data={"targets": ws_json_items + host_json_items}))
        return

    if not workspace_lines and not host_lines:
        typer.echo("No targets found.")
        typer.echo("  Create one: wafer target init --help")
        return

    typer.echo("Targets:\n")
    for line in workspace_lines:
        typer.echo(line)
    for line in host_lines:
        typer.echo(line)
    from .targets import get_default_target
    default = get_default_target()
    if default:
        typer.echo(f"\n  * = default target ({default})")


def _list_workspace_items(sync: bool) -> tuple[list[str], list[dict]]:
    """Fetch workspaces and format for display. Returns (lines, json_items)."""
    lines: list[str] = []
    json_items: list[dict] = []
    try:
        import httpx
    except ImportError:
        return lines, json_items
    try:
        from .workspaces import _get_client
        api_url, headers = _get_client()
        params = {"sync_status": "true"} if sync else {}
        with httpx.Client(timeout=30.0, headers=headers) as client:
            response = client.get(f"{api_url}/v1/workspaces", params=params)
            response.raise_for_status()
            workspaces = response.json()
        assert isinstance(workspaces, list), "API must return a list"
        for ws in workspaces:
            line, item = _format_workspace_list_item(ws)
            lines.append(line)
            json_items.append(item)
    except (RuntimeError, httpx.HTTPStatusError, httpx.RequestError):
        pass  # API unreachable, not authed, or request failed
    return lines, json_items


def _list_host_items() -> tuple[list[str], list[dict]]:
    """Load local host targets and format for display. Returns (lines, json_items)."""
    from .targets import get_default_target, list_targets, load_target
    lines: list[str] = []
    json_items: list[dict] = []
    default = get_default_target()
    for name in list_targets():
        try:
            t = load_target(name)
            ttype = type(t).__name__.replace("Target", "").lower()
            gpu = getattr(t, "gpu_type", getattr(t, "gpu_type_id", ""))
            marker = " *" if name == default else ""
            lines.append(f"    {(name + marker):<22} {gpu:<10} {ttype}")
            json_items.append({
                "name": name, "type": ttype, "gpu_type": gpu, "default": name == default,
            })
        except (FileNotFoundError, ValueError, TypeError):  # TypeError: malformed config
            lines.append(f"    {name:<20} {'?':<10} error")
    return lines, json_items


@target_app.command("show")
def unified_show(
    name: str = typer.Argument(..., help="Target name"),
    json_output: bool = typer.Option(False, "--json", "-j", help="Output as JSON"),
) -> None:
    """Show details for a target (workspace or host).

    Examples:
        wafer target show dev
        wafer target show my-gpu --json
    """
    try:
        kind, ws = _resolve_target_type(name)
    except RuntimeError as e:
        _exit_with_error(str(e))
    assert kind in ("workspace", "host")

    if kind == "workspace":
        _show_workspace(name, json_output)
    else:
        _show_host(name, json_output)


def _show_workspace(name: str, json_output: bool) -> None:
    from .workspaces import get_workspace
    try:
        result = get_workspace(name, json_output=json_output)
        typer.echo(result)
    except RuntimeError as e:
        _exit_with_error(str(e))


def _show_host(name: str, json_output: bool) -> None:
    from .targets import get_target_info, load_target
    try:
        target = load_target(name)
    except FileNotFoundError as e:
        _exit_with_error(str(e))

    info = get_target_info(target)
    if json_output:
        from .output import json_response
        typer.echo(json_response(data={"name": name, **info}))
    else:
        typer.echo(f"Target: {name}")
        for key, value in info.items():
            typer.echo(f"  {key}: {value}")

    from wafer.core.utils.kernel_utils.targets.config import RunPodTarget
    if isinstance(target, RunPodTarget):
        _show_runpod_info(name)


def _show_runpod_info(name: str) -> None:
    try:
        from wafer.core.targets.runpod import get_pod_state
    except ImportError:
        return
    state = get_pod_state(name)
    if state:
        typer.echo(f"\n  Pod: {state.pod_id}")
        typer.echo(f"  SSH: {state.ssh_username}@{state.public_ip}:{state.ssh_port}")
        typer.echo(f"  Created: {state.created_at}")


@target_app.command("remove")
def unified_remove(
    name: str = typer.Argument(..., help="Target name"),
    yes: bool = typer.Option(False, "--yes", "-y", help="Skip confirmation"),
) -> None:
    """Remove a target (workspace or host).

    Examples:
        wafer target remove dev
        wafer target remove my-gpu -y
    """
    try:
        kind, ws = _resolve_target_type(name)
    except RuntimeError as e:
        _exit_with_error(str(e))
    assert kind in ("workspace", "host")

    if not yes:
        confirm = typer.confirm(f"Remove target '{name}'?")
        if not confirm:
            typer.echo("Cancelled.")
            raise typer.Exit(0)

    if kind == "workspace":
        from .workspaces import delete_workspace
        try:
            typer.echo(delete_workspace(name))
        except RuntimeError as e:
            _exit_with_error(str(e))
    else:
        from .targets import remove_target
        try:
            remove_target(name)
            typer.echo(f"Removed target: {name}")
        except FileNotFoundError as e:
            _exit_with_error(str(e))


@target_app.command("default")
def unified_default(
    name: str = typer.Argument(..., help="Target name to set as default"),
) -> None:
    """Set the default target.

    Example:
        wafer target default my-gpu
    """
    from .targets import set_default_target
    try:
        set_default_target(name)
        typer.echo(f"Default target set to: {name}")
    except FileNotFoundError as e:
        _exit_with_error(str(e))


@target_app.command("ssh")
def unified_ssh(
    name: str = typer.Argument(..., help="Target name"),
) -> None:
    """SSH into a target (workspace or host).

    Examples:
        wafer target ssh dev
        wafer target ssh my-gpu
    """
    import os as _os
    try:
        kind, ws = _resolve_target_type(name)
    except RuntimeError as e:
        _exit_with_error(str(e))
    assert kind in ("workspace", "host")

    if kind == "workspace":
        from .workspaces import get_workspace_raw
        try:
            ws_data = get_workspace_raw(name)
        except RuntimeError as e:
            _exit_with_error(str(e))
        host, port, user = _get_workspace_ssh_creds(ws_data)
        _os.execvp("ssh", _build_workspace_ssh_args(host, port, user))
    else:
        from .targets import load_target
        from .targets_ops import TargetExecError, get_target_ssh_info
        try:
            target = load_target(name)
        except FileNotFoundError as e:
            _exit_with_error(str(e))
        try:
            ssh_info = trio.run(get_target_ssh_info, target)
        except TargetExecError as e:
            _exit_with_error(str(e))
        _os.execvp("ssh", _build_host_ssh_args(ssh_info))


@target_app.command("sync")
def unified_sync(
    name: str = typer.Argument(..., help="Target name"),
    path: Path = typer.Argument(..., help="Local file or directory to sync"),
    remote_path: str | None = typer.Option(None, "--remote-path", "-r", help="Remote destination path"),
    verbose: bool = typer.Option(False, "--verbose", "-v", help="Show status messages"),
    quiet: bool = typer.Option(False, "--quiet", "-q", help="Suppress status messages"),
) -> None:
    """Sync local files to a target.

    Examples:
        wafer target sync dev ./my-project
        wafer target sync my-gpu ./kernel.py --remote-path /tmp/kernel.py
    """
    show_status = _resolve_show_status(quiet, verbose)
    if not path.exists():
        _exit_with_error(f"Path not found: {path}")
    try:
        kind, ws = _resolve_target_type(name)
    except RuntimeError as e:
        _exit_with_error(str(e))
    assert kind in ("workspace", "host")

    on_progress = _make_progress_callback(show_status)
    if show_status:
        typer.echo(f"[wafer] Syncing {path} to {kind} {name}...", err=True)

    if kind == "workspace":
        from .workspaces import sync_files
        try:
            sync_files(name, path.resolve(), on_progress=on_progress, remote_path=remote_path)
        except RuntimeError as e:
            _exit_with_error(str(e))
    else:
        from .targets import load_target
        from .targets_ops import TargetExecError, get_target_ssh_info, sync_to_target
        try:
            target = load_target(name)
            ssh_info = trio.run(get_target_ssh_info, target)
            sync_to_target(ssh_info, path.resolve(), remote_path=remote_path, on_progress=on_progress)
        except (FileNotFoundError, TargetExecError) as e:
            _exit_with_error(str(e))


@target_app.command("pull")
def unified_pull(
    name: str = typer.Argument(..., help="Target name"),
    remote_path: str = typer.Argument(..., help="Remote path to pull"),
    local_path: Path = typer.Argument(Path("."), help="Local destination (default: current directory)"),
    verbose: bool = typer.Option(False, "--verbose", "-v", help="Show status messages"),
    quiet: bool = typer.Option(False, "--quiet", "-q", help="Suppress status messages"),
) -> None:
    """Pull files from a target to local machine.

    Examples:
        wafer target pull dev kernel.py ./
        wafer target pull my-gpu /tmp/results ./results
    """
    show_status = _resolve_show_status(quiet, verbose)
    try:
        kind, ws = _resolve_target_type(name)
    except RuntimeError as e:
        _exit_with_error(str(e))
    assert kind in ("workspace", "host")

    on_progress = _make_progress_callback(show_status)
    if kind == "workspace":
        from .workspaces import pull_files
        try:
            file_count = pull_files(name, remote_path, local_path.resolve(), on_progress=on_progress)
            if show_status:
                typer.echo(f"[wafer] Pulled {file_count} files to {local_path}", err=True)
        except RuntimeError as e:
            _exit_with_error(str(e))
    else:
        from .targets import load_target
        from .targets_ops import TargetExecError, get_target_ssh_info, pull_from_target
        try:
            target = load_target(name)
            ssh_info = trio.run(get_target_ssh_info, target)
            pull_from_target(ssh_info, remote_path, local_path.resolve(), on_progress=on_progress)
        except (FileNotFoundError, TargetExecError) as e:
            _exit_with_error(str(e))


@target_app.command("probe")
def unified_probe(
    name: str = typer.Argument(..., help="Target name"),
) -> None:
    """Probe a target to discover available compilation backends.

    Examples:
        wafer target probe my-gpu
        wafer target probe dev
    """
    try:
        kind, ws = _resolve_target_type(name)
    except RuntimeError as e:
        _exit_with_error(str(e))
    assert kind in ("workspace", "host")

    typer.echo(f"Probing {kind}: {name}...")
    if kind == "workspace":
        capabilities = _probe_workspace(name)
    else:
        capabilities = _probe_host(name)
    _display_probe_results(name, capabilities)


def _probe_workspace(name: str) -> dict:
    """Run probe script on a workspace via SSH. Returns capabilities dict."""
    import json as _json
    import subprocess

    from .targets import _PROBE_SCRIPT
    from .workspaces import get_workspace_raw
    try:
        ws_data = get_workspace_raw(name)
    except RuntimeError as e:
        _exit_with_error(str(e))
    host, port, user = _get_workspace_ssh_creds(ws_data)
    escaped = _PROBE_SCRIPT.replace("'", "'\"'\"'")
    ssh_args = [
        "ssh", "-p", str(port),
        "-o", "StrictHostKeyChecking=no",
        "-o", "UserKnownHostsFile=/dev/null",
        "-o", "LogLevel=ERROR",
        f"{user}@{host}",
        f"python3 -c '{escaped}'",
    ]
    result = subprocess.run(ssh_args, capture_output=True, text=True, timeout=60)
    if result.returncode != 0:
        _exit_with_error(f"Probe failed: {result.stderr.strip()}")
    try:
        capabilities = _json.loads(result.stdout)
    except _json.JSONDecodeError:
        _exit_with_error("Could not parse probe output")
    assert isinstance(capabilities, dict), "Probe output must be a JSON object"
    return capabilities


def _probe_host(name: str) -> dict:
    """Run probe on a local host target. Returns capabilities dict."""
    from .targets import ProbeError, load_target, probe_target_capabilities
    try:
        target = load_target(name)
    except FileNotFoundError as e:
        _exit_with_error(str(e))
    try:
        capabilities = trio.run(probe_target_capabilities, target)
    except ProbeError as e:
        _exit_with_error(str(e))
    except BaseExceptionGroup as e:  # noqa: F821 (builtin in Python 3.11+)
        cause = e
        while isinstance(cause, BaseExceptionGroup) and len(cause.exceptions) == 1:  # noqa: F821
            cause = cause.exceptions[0]
        _exit_with_error(f"Unexpected error probing target: {type(cause).__name__}: {cause}")
    assert isinstance(capabilities, dict), "Probe must return a dict"
    return capabilities


def _display_probe_results(name: str, capabilities: dict) -> None:
    """Display probe results in a consistent format."""
    assert isinstance(capabilities, dict)
    assert name
    typer.echo(f"\nTarget: {name}")
    if capabilities.get("gpu_name"):
        typer.echo(f"  GPU: {capabilities['gpu_name']}")
    if capabilities.get("compute_capability"):
        typer.echo(f"  Compute: {capabilities['compute_capability']}")

    backends = capabilities.get("backends", {})
    triton_ver = backends.get("triton")
    _display_backends(backends, triton_ver)
    _display_python_env(capabilities, triton_ver)


def _display_backends(backends: dict, triton_ver: str | None) -> None:
    typer.echo("\n  Compilation Backends:")
    if triton_ver:
        typer.echo(f"    \u2713 Triton: {triton_ver}")
    else:
        typer.echo("    \u2717 Triton: not installed")
    if triton_ver and backends.get("torch"):
        typer.echo("    \u2713 torch.compile/inductor: available")
    else:
        typer.echo("    \u2717 torch.compile/inductor: requires Triton")
    if backends.get("hipcc"):
        typer.echo(f"    \u2713 HIP/hipcc: {backends['hipcc']}")
    elif backends.get("nvcc"):
        typer.echo(f"    \u2713 CUDA/nvcc: {backends['nvcc']}")
    else:
        typer.echo("    \u2717 No GPU compiler found")
    if backends.get("rocm_version"):
        typer.echo(f"    ROCm: {backends['rocm_version']}")
    if backends.get("cuda_version"):
        typer.echo(f"    CUDA: {backends['cuda_version']}")


def _display_python_env(capabilities: dict, triton_ver: str | None) -> None:
    typer.echo("\n  Python Environment:")
    typer.echo(f"    Python: {capabilities.get('python_version', 'unknown')}")
    packages = capabilities.get("packages", {})
    if packages.get("torch"):
        typer.echo(f"    PyTorch: {packages['torch']}")
    if triton_ver:
        typer.echo(f"    Triton: {triton_ver}")


def _parse_run_command(ctx: typer.Context) -> str:
    """Parse and validate the command from extra args. Returns command string."""
    import shlex
    command = list(ctx.args)
    if command and command[0] == "--":
        command = command[1:]
    if not command:
        _exit_with_error("No command specified. Usage: wafer target run -- <command>")
    assert len(command) >= 1
    if len(command) == 1:
        return command[0]
    return shlex.join(command)


def _resolve_run_target(
    name: str | None,
    gpu: str | None,
) -> tuple[str, str]:
    """Resolve which target to run on. Returns (target_name, kind).

    Resolution order:
    1. --name given: use that target directly
    2. --gpu given: find matching target(s), pick if multiple
    3. No flags: use default, or auto-select if only one exists
    """
    if name:
        try:
            kind, _ = _resolve_target_type(name)
            return name, kind
        except RuntimeError as e:
            _exit_with_error(str(e))

    if gpu:
        return _resolve_by_gpu(gpu)

    return _resolve_auto()


def _resolve_by_gpu(gpu: str) -> tuple[str, str]:
    """Find a target matching the given GPU type."""
    ws_targets = _gather_workspace_targets(gpu_filter=gpu, running_only=True)
    host_targets = _gather_host_targets(gpu_filter=gpu)
    candidates = [(n, k) for n, k, *_ in ws_targets] + list(host_targets)

    if not candidates:
        _exit_with_error(
            f"No target found with GPU type '{gpu}'.\n"
            "  List targets: wafer target list"
        )
    if len(candidates) == 1:
        return candidates[0]
    return _pick_from_candidates(candidates, f"Multiple targets with GPU '{gpu}'")


def _resolve_auto() -> tuple[str, str]:
    """Auto-select a target: use default, or the only available one."""
    from .targets import get_default_target
    default = get_default_target()
    if default:
        try:
            kind, _ = _resolve_target_type(default)
            return default, kind
        except RuntimeError:
            pass  # default target no longer exists, fall through to auto-select

    ws_targets = _gather_workspace_targets(running_only=True)
    host_targets = _gather_host_targets()
    candidates = [(n, k) for n, k, *_ in ws_targets] + list(host_targets)

    if not candidates:
        _exit_with_error(
            "No targets available.\n"
            "  Get started: wafer target init --help"
        )
    if len(candidates) == 1:
        return candidates[0]
    return _pick_from_candidates(candidates, "Multiple targets available")


def _sync_before_run(resolved_name: str, resolved_kind: str, sync_path: Path, show_status: bool) -> None:
    """Sync local files to the target before running a command."""
    assert resolved_kind in ("workspace", "host")
    if not sync_path.exists():
        _exit_with_error(f"Sync path not found: {sync_path}")
    if show_status:
        typer.echo(f"[wafer] Syncing {sync_path}...", err=True)
    on_progress = _make_progress_callback(show_status)

    if resolved_kind == "workspace":
        from .workspaces import sync_files
        try:
            sync_files(resolved_name, sync_path.resolve(), on_progress=on_progress)
        except RuntimeError as e:
            _exit_with_error(f"Sync failed: {e}")
    else:
        from .targets import load_target
        from .targets_ops import TargetExecError, get_target_ssh_info, sync_to_target
        try:
            target = load_target(resolved_name)
            ssh_info = trio.run(get_target_ssh_info, target)
            sync_to_target(ssh_info, sync_path.resolve(), on_progress=on_progress)
        except (FileNotFoundError, TargetExecError) as e:
            _exit_with_error(f"Sync failed: {e}")


def _exec_on_target(resolved_name: str, resolved_kind: str, command_str: str, timeout: int) -> int:
    """Execute a command on a resolved target. Returns exit code."""
    assert resolved_kind in ("workspace", "host")
    if resolved_kind == "workspace":
        from .workspaces import exec_command
        try:
            return exec_command(
                workspace_id=resolved_name,
                command=command_str,
                timeout_seconds=timeout,
            )
        except RuntimeError as e:
            _exit_with_error(str(e))
    else:
        from .targets import load_target
        from .targets_ops import TargetExecError, exec_on_target_sync, get_target_ssh_info
        try:
            target = load_target(resolved_name)
            ssh_info = trio.run(get_target_ssh_info, target)
        except (FileNotFoundError, TargetExecError) as e:
            _exit_with_error(str(e))
        try:
            return exec_on_target_sync(ssh_info, command_str, timeout)
        except TargetExecError as e:
            _exit_with_error(str(e))
    raise AssertionError("unreachable")  # _exit_with_error always raises


@target_app.command(
    "run",
    context_settings={
        "allow_interspersed_args": False,
        "ignore_unknown_options": True,
        "allow_extra_args": True,
    },
)
def unified_run(
    ctx: typer.Context,
    gpu: str | None = typer.Option(None, "--gpu", "-g", help="GPU type filter (e.g. B200, MI300X)"),
    name: str | None = typer.Option(None, "--name", "-n", help="Target name"),
    sync: Path | None = typer.Option(None, "--sync", "-s", help="Sync local directory before running"),
    timeout: int | None = typer.Option(None, "--timeout", "-t", help="Execution timeout in seconds"),
    verbose: bool = typer.Option(False, "--verbose", "-v", help="Show status messages"),
    quiet: bool = typer.Option(False, "--quiet", "-q", help="Suppress status messages"),
) -> None:
    """Run a command on a GPU target.

    Automatically resolves which target to use:
    1. --name given: use that target
    2. --gpu given: find a target with matching GPU type
    3. No flags: use default target, or auto-select if only one exists

    Examples:
        wafer target run -- python train.py
        wafer target run --gpu B200 -- python train.py
        wafer target run --name dev --sync . -- python train.py
        wafer target run --name my-gpu -- nvidia-smi
    """
    from .global_config import get_defaults

    command_str = _parse_run_command(ctx)
    resolved_name, resolved_kind = _resolve_run_target(name, gpu)
    show_status = _resolve_show_status(quiet, verbose)

    if sync is not None:
        _sync_before_run(resolved_name, resolved_kind, sync, show_status)

    effective_timeout = timeout
    if effective_timeout is None:
        effective_timeout = getattr(get_defaults(), "exec_timeout", 300)

    if show_status:
        typer.echo(f"[wafer] Target: {resolved_name} | Timeout: {effective_timeout}s", err=True)

    exit_code = _exec_on_target(resolved_name, resolved_kind, command_str, effective_timeout)

    if show_status:
        typer.echo(f"[wafer] Exit code: {exit_code}", err=True)
    raise typer.Exit(exit_code)


@pool_app.command("list")
def targets_pool_list() -> None:
    """List all configured target pools.
    Example:
        wafer target pool list
    """
    from .targets import get_pool, list_pools
    pools = list_pools()
    if not pools:
        typer.echo("No pools configured")
        typer.echo("")
        typer.echo("Define pools in ~/.wafer/config.toml:")
        typer.echo("  [pools.my-pool]")
        typer.echo('  targets = ["target-1", "target-2"]')
        return
    typer.echo("Configured pools:\n")
    for pool_name in pools:
        try:
            targets = get_pool(pool_name)
            typer.echo(f"  {pool_name}: {', '.join(targets)}")
        except (FileNotFoundError, ValueError) as e:
            typer.echo(f"  {pool_name}: (error: {e})")


@pool_app.command("create")
def targets_pool_create(
    name: str = typer.Argument(..., help="Pool name"),
    targets: list[str] = typer.Argument(..., help="Target names to include in pool"),
) -> None:
    """Create or update a target pool.
    Example:
        wafer target pool create mi300x-pool mi300x-1 mi300x-2 mi300x-3
    """
    from .targets import save_pool
    try:
        save_pool(name, targets)
        typer.echo(f"Pool '{name}' created with {len(targets)} targets")
    except FileNotFoundError as e:
        typer.echo(f"Error: {e}", err=True)
        raise typer.Exit(1) from None


@pool_app.command("status")
def targets_pool_status(
    name: str = typer.Argument(..., help="Pool name"),
) -> None:
    """Show status of targets in a pool (locked/available).
    Example:
        wafer target pool status mi300x-pool
    """
    from .target_lock import get_lock_holder, is_target_locked
    from .targets import get_pool
    try:
        targets = get_pool(name)
    except FileNotFoundError as e:
        typer.echo(f"Error: {e}", err=True)
        raise typer.Exit(1) from None
    typer.echo(f"Pool '{name}' ({len(targets)} targets):\n")
    available = 0
    for target_name in targets:
        locked = is_target_locked(target_name)
        if locked:
            pid = get_lock_holder(target_name)
            pid_str = f" (pid {pid})" if pid else ""
            typer.echo(f"  [busy]  {target_name}{pid_str}")
        else:
            typer.echo(f"  [free]  {target_name}")
            available += 1
    typer.echo("")
    typer.echo(f"Available: {available}/{len(targets)}")


@billing_app.callback(invoke_without_command=True)
def billing_usage(
    ctx: typer.Context,
    json_output: bool = typer.Option(False, "--json", "-j", help="Output as JSON"),
) -> None:
    """Show current billing usage and subscription info.
    Example:
        wafer billing
        wafer billing --json
    """
    # Only show usage if no subcommand was invoked
    if ctx.invoked_subcommand is not None:
        return
    from .billing import get_usage
    try:
        result = get_usage(json_output=json_output)
        typer.echo(result)
    except RuntimeError as e:
        if json_output:
            from .output import json_error
            typer.echo(json_error(str(e)))
        else:
            typer.echo(f"Error: {e}", err=True)
        raise typer.Exit(1) from None


@billing_app.command("topup")
def billing_topup(
    amount: int = typer.Argument(25, help="Amount in dollars ($10-$500)"),
    no_browser: bool = typer.Option(
        False, "--no-browser", help="Print URL instead of opening browser"
    ),
) -> None:
    """Add credits to your account.
    Opens a Stripe checkout page to add credits. Default amount is $25.
    Example:
        wafer billing topup        # Add $25
        wafer billing topup 100    # Add $100
        wafer billing topup --no-browser  # Print URL instead
    """
    import webbrowser

    from .billing import create_topup, validate_topup_amount
    amount_cents = amount * 100
    # Validate amount client-side before API call
    try:
        validate_topup_amount(amount_cents)
    except ValueError as e:
        typer.echo(f"Error: {e}", err=True)
        raise typer.Exit(1) from None
    try:
        result = create_topup(amount_cents)
        checkout_url = result.get("checkout_url")
        if not checkout_url:
            typer.echo("Error: No checkout URL received from API", err=True)
            raise typer.Exit(1) from None
        if no_browser:
            typer.echo(f"Complete your purchase at:\n{checkout_url}")
        else:
            typer.echo(f"Opening checkout for ${amount}...")
            webbrowser.open(checkout_url)
            typer.echo("Browser opened. Complete your purchase there.")
    except RuntimeError as e:
        typer.echo(f"Error: {e}", err=True)
        raise typer.Exit(1) from None


@billing_app.command("portal")
def billing_portal(
    no_browser: bool = typer.Option(
        False, "--no-browser", help="Print URL instead of opening browser"
    ),
) -> None:
    """Open Stripe billing portal.
    Manage your subscription, update payment method, or view invoices.
    Example:
        wafer billing portal
        wafer billing portal --no-browser
    """
    import webbrowser

    from .billing import get_portal_url
    try:
        result = get_portal_url()
        portal_url = result.get("portal_url")
        if not portal_url:
            typer.echo("Error: No portal URL received from API", err=True)
            raise typer.Exit(1) from None
        if no_browser:
            typer.echo(f"Billing portal:\n{portal_url}")
        else:
            typer.echo("Opening billing portal...")
            webbrowser.open(portal_url)
            typer.echo("Browser opened.")
    except RuntimeError as e:
        typer.echo(f"Error: {e}", err=True)
        raise typer.Exit(1) from None


@ssh_keys_app.command("list")
def ssh_keys_list(
    json_output: bool = typer.Option(False, "--json", "-j", help="Output as JSON"),
) -> None:
    """List all registered SSH public keys.
    Example:
        wafer settings ssh-keys list
        wafer settings ssh-keys list --json
    """
    from .ssh_keys import list_ssh_keys
    try:
        result = list_ssh_keys(json_output=json_output)
        typer.echo(result)
    except RuntimeError as e:
        if json_output:
            from .output import json_error
            typer.echo(json_error(str(e)))
        else:
            typer.echo(f"Error: {e}", err=True)
        raise typer.Exit(1) from e


@ssh_keys_app.command("add")
def ssh_keys_add(
    pubkey_path: Path | None = typer.Argument(
        None, help="Path to public key file (auto-detects ~/.ssh/id_ed25519.pub if not specified)"
    ),
    name: str | None = typer.Option(None, "--name", "-n", help="Friendly name for the key"),
    json_output: bool = typer.Option(False, "--json", "-j", help="Output as JSON"),
) -> None:
    """Add an SSH public key.
    If no path is specified, auto-detects keys from ~/.ssh/ in preference order:
    id_ed25519.pub, id_rsa.pub, id_ecdsa.pub.
    Example:
        wafer settings ssh-keys add                              # Auto-detect
        wafer settings ssh-keys add ~/.ssh/id_rsa.pub            # Specific file
        wafer settings ssh-keys add ~/.ssh/id_ed25519.pub --name laptop
    """
    from .ssh_keys import add_ssh_key
    try:
        result = add_ssh_key(pubkey_path=pubkey_path, name=name, json_output=json_output)
        typer.echo(result)
    except RuntimeError as e:
        if json_output:
            from .output import json_error
            typer.echo(json_error(str(e)))
        else:
            typer.echo(f"Error: {e}", err=True)
        raise typer.Exit(1) from e


@ssh_keys_app.command("remove")
def ssh_keys_remove(
    key_id: str = typer.Argument(..., help="UUID of the SSH key to remove"),
    json_output: bool = typer.Option(False, "--json", "-j", help="Output as JSON"),
) -> None:
    """Remove an SSH public key.
    Get the key ID from 'wafer settings ssh-keys list'.
    Example:
        wafer settings ssh-keys remove abc123-def456-...
    """
    from .ssh_keys import remove_ssh_key
    try:
        result = remove_ssh_key(key_id=key_id, json_output=json_output)
        typer.echo(result)
    except RuntimeError as e:
        if json_output:
            from .output import json_error
            typer.echo(json_error(str(e)))
        else:
            typer.echo(f"Error: {e}", err=True)
        raise typer.Exit(1) from e


@perfetto_app.command("query")
def perfetto_query(
    trace_path: Path = typer.Argument(..., help="Path to Perfetto trace file"),
    sql: str = typer.Argument(..., help="SQL query to execute"),
    json_output: bool = typer.Option(True, "--json", "-j", help="Output as JSON"),
) -> None:
    """Execute SQL query against a Perfetto trace.
    Starts trace_processor, loads the trace, executes the query, and returns results.
    Examples:
        wafer perfetto query trace.perfetto "SELECT * FROM slice LIMIT 10"
        wafer perfetto query trace.perfetto "SELECT name, dur FROM slice ORDER BY dur DESC LIMIT 5"
    """
    from wafer.core.lib.perfetto.perfetto_tool import PerfettoConfig, PerfettoTool
    config = PerfettoConfig(
        workspace_root=".",
        storage_dir=str(Path.home() / ".wafer" / "perfetto"),
    )
    tool = PerfettoTool(config)
    try:
        results, err = tool.query(sql, str(trace_path))
        if err:
            typer.echo(f"Error: {err}", err=True)
            raise typer.Exit(1)
        if json_output:
            from .output import json_response
            typer.echo(json_response(data={"results": results, "count": len(results or [])}))
        else:
            if not results:
                typer.echo("No results")
            else:
                # Simple table output
                if results:
                    headers = list(results[0].keys())
                    typer.echo("\t".join(headers))
                    for row in results:
                        typer.echo("\t".join(str(row.get(h, "")) for h in headers))
    except Exception as e:
        typer.echo(f"Error: {e}", err=True)
        raise typer.Exit(1) from None


# Common tables for --common flag (most useful for trace analysis)
COMMON_PERFETTO_TABLES = [
    "slice",
    "track",
    "thread",
    "process",
    "thread_track",
    "process_track",
    "counter",
    "counter_track",
    "sched_slice",
    "gpu_slice",
]


@perfetto_app.command("tables")
def perfetto_tables(
    trace_path: Path = typer.Argument(..., help="Path to Perfetto trace file"),
    common: bool = typer.Option(False, "--common", help="Show commonly used tables (default)"),
    tables_filter: str | None = typer.Option(
        None, "--tables", "-t", help="Comma-separated list of table names to show"
    ),
    all_tables: bool = typer.Option(False, "--all", help="Show all tables (including internal)"),
    json_output: bool = typer.Option(False, "--json", "-j", help="Output as JSON"),
) -> None:
    """List available tables in a Perfetto trace.
    Examples:
        wafer tool perfetto tables trace.json              # shows common tables (default)
        wafer tool perfetto tables trace.json --tables slice,track,thread
        wafer tool perfetto tables trace.json --all
    """
    from wafer.core.lib.perfetto.perfetto_tool import PerfettoConfig, PerfettoTool
    # Default to --common if no filter specified
    flag_count = sum([common, tables_filter is not None, all_tables])
    if flag_count == 0:
        common = True
        flag_count = 1
    if flag_count > 1:
        typer.echo("Error: Use only one of --common, --tables, or --all", err=True)
        raise typer.Exit(1)
    config = PerfettoConfig(
        workspace_root=".",
        storage_dir=str(Path.home() / ".wafer" / "perfetto"),
    )
    tool = PerfettoTool(config)
    try:
        all_table_names, err = tool.get_tables(str(trace_path))
        if err:
            typer.echo(f"Error: {err}", err=True)
            raise typer.Exit(1)
        all_table_names = all_table_names or []
        if all_tables:
            filtered = all_table_names
        elif common:
            # Show common tables that exist in this trace
            filtered = [t for t in COMMON_PERFETTO_TABLES if t in all_table_names]
        else:
            # --tables flag
            requested = [t.strip() for t in (tables_filter or "").split(",") if t.strip()]
            filtered = [t for t in requested if t in all_table_names]
            missing = [t for t in requested if t not in all_table_names]
            if missing:
                typer.echo(f"Warning: Tables not found: {', '.join(missing)}", err=True)
        if json_output:
            from .output import json_response
            typer.echo(json_response(data={"tables": filtered}))
        else:
            typer.echo(f"Found {len(filtered)} tables:")
            for table in filtered:
                typer.echo(f"  {table}")
    except Exception as e:
        typer.echo(f"Error: {e}", err=True)
        raise typer.Exit(1) from None


@perfetto_app.command("schema")
def perfetto_schema(
    trace_path: Path = typer.Argument(..., help="Path to Perfetto trace file"),
    table: str = typer.Argument(..., help="Table name"),
    json_output: bool = typer.Option(False, "--json", "-j", help="Output as JSON"),
) -> None:
    """Get schema for a table in a Perfetto trace.
    Examples:
        wafer perfetto schema trace.perfetto slice
        wafer perfetto schema trace.perfetto thread --json
    """
    from wafer.core.lib.perfetto.perfetto_tool import PerfettoConfig, PerfettoTool
    config = PerfettoConfig(
        workspace_root=".",
        storage_dir=str(Path.home() / ".wafer" / "perfetto"),
    )
    tool = PerfettoTool(config)
    try:
        columns, err = tool.get_schema(table, str(trace_path))
        if err:
            typer.echo(f"Error: {err}", err=True)
            raise typer.Exit(1)
        if json_output:
            from .output import json_response
            typer.echo(json_response(data={"table": table, "columns": columns}))
        else:
            typer.echo(f"Schema for table '{table}':")
            for col in columns or []:
                nullable = "NULL" if col.get("nullable") else "NOT NULL"
                typer.echo(f"  {col['name']}: {col['type']} {nullable}")
    except Exception as e:
        typer.echo(f"Error: {e}", err=True)
        raise typer.Exit(1) from None


@perfetto_app.command("check")
def perfetto_check(
    json_output: bool = typer.Option(False, "--json", "-j", help="Output as JSON"),
) -> None:
    """Check if trace_processor is available.
    Examples:
        wafer perfetto check
        wafer perfetto check --json
    """
    from wafer.core.lib.perfetto.perfetto_tool import PerfettoConfig, PerfettoTool
    config = PerfettoConfig(
        workspace_root=".",
        storage_dir=str(Path.home() / ".wafer" / "perfetto"),
    )
    tool = PerfettoTool(config)
    status = tool.check_processor()
    if json_output:
        from .output import json_response
        typer.echo(json_response(data=status.to_dict()))
    else:
        if status.available:
            typer.echo(f"✓ trace_processor available at {status.binary_path}")
            typer.echo(f"  Version: {status.version}")
            if not status.version_matches_ui:
                typer.echo(f"  ⚠ Version mismatch with UI (expected: {status.ui_version})")
        else:
            typer.echo(f"✗ trace_processor not available: {status.error}")
            typer.echo("  Run 'wafer perfetto check' to auto-download")


def _validate_ncu_rep_file(filepath: Path, json_output: bool) -> None:
    assert isinstance(filepath, Path), "filepath must be a Path"
    assert isinstance(json_output, bool), "json_output must be a bool"

    if not filepath.exists():
        _ncu_error_exit(f"File not found: {filepath}", json_output)
    if filepath.suffix != ".ncu-rep":
        _ncu_error_exit(f"Expected .ncu-rep file, got: {filepath.suffix}", json_output)


def _ncu_error_exit(msg: str, json_output: bool) -> None:
    assert isinstance(msg, str) and msg, "msg must be a non-empty string"
    assert isinstance(json_output, bool), "json_output must be a bool"

    if json_output:
        from .output import json_error
        typer.echo(json_error(msg))
    else:
        typer.echo(f"Error: {msg}", err=True)
    raise typer.Exit(1) from None


@ncu_app.command("analyze")
def ncu_analyze(
    filepath: Path = typer.Argument(..., help="Path to .ncu-rep profile file"),
    output_dir: Path | None = typer.Option(
        None, "--output-dir", "-o", help="Output directory for analysis files"
    ),
    json_output: bool = typer.Option(
        False, "--json", "-j", help="Output raw JSON instead of formatted text"
    ),
    remote: bool | None = typer.Option(
        None,
        "--remote/--local",
        help="Force remote (via API) or local analysis. Default: auto-detect (remote if NCU not installed locally)",
    ),
    target: str | None = typer.Option(
        None,
        "--target",
        "-t",
        help="Target for direct SSH mode. See 'wafer target list'",
    ),
    include_source: bool = typer.Option(
        False,
        "--include-source",
        "-s",
        help="Include SASS source correlation for each kernel (requires --remote)",
    ),
) -> None:
    """Analyze an NVIDIA Nsight Compute profile (.ncu-rep file).
    Returns kernel performance metrics including duration, occupancy,
    compute/memory throughput, and optimization recommendations.
    By default, uses local NCU if available, otherwise runs analysis
    remotely via wafer-api (requires authentication: wafer settings login).
    Use --target for direct SSH mode (like wafer target run --direct).
    Use --include-source to fetch SASS assembly with register/instruction data.
    Examples:
        wafer tool ncu analyze profile.ncu-rep
        wafer tool ncu analyze profile.ncu-rep --json
        wafer tool ncu analyze profile.ncu-rep --output-dir ./analysis
        wafer tool ncu analyze profile.ncu-rep --remote
        wafer tool ncu analyze profile.ncu-rep --target vultr-b200
        wafer tool ncu analyze profile.ncu-rep --include-source --json
    """
    _validate_ncu_rep_file(filepath, json_output)
    from .ncu_analyze import analyze_ncu_profile
    try:
        result = analyze_ncu_profile(
            filepath, output_dir=output_dir, json_output=json_output,
            remote=remote, target=target, include_source=include_source,
        )
        typer.echo(result)
    except (FileNotFoundError, RuntimeError) as e:
        _ncu_error_exit(str(e), json_output)


def _validate_ncu_run_args(command: list[str], directory: Path) -> None:
    assert isinstance(command, list), "command must be a list"
    assert isinstance(directory, Path), "directory must be a Path"

    if not command:
        typer.echo("Error: No command provided.", err=True)
        raise typer.Exit(1)
    if not directory.exists():
        typer.echo(f"Error: Directory not found: {directory}", err=True)
        raise typer.Exit(1)
    if not directory.is_dir():
        typer.echo(f"Error: Not a directory: {directory}", err=True)
        raise typer.Exit(1)


@ncu_app.command("run", context_settings={"allow_interspersed_args": False})
def ncu_run_cmd(
    command: list[str] = typer.Argument(..., help="Command to profile (e.g., python run.py)"),
    directory: Path = typer.Option(
        ".", "--dir", "-d", help="Directory to upload (default: current directory)"
    ),
    ncu_args: str = typer.Option(
        "", "--ncu-args", help='Extra NCU flags (e.g., "--set full --kernel-name mykernel")'
    ),
    requirements: Path | None = typer.Option(
        None, "--requirements", "-r", help="requirements.txt to install before profiling"
    ),
    output: Path | None = typer.Option(
        None, "--output", "-o", help="Local path to save .ncu-rep report"
    ),
    no_download: bool = typer.Option(
        False, "--no-download", help="Skip downloading the .ncu-rep report"
    ),
    exclude: list[str] | None = typer.Option(
        None, "--exclude", "-e", help="Glob patterns to exclude from upload"
    ),
    timeout: int = typer.Option(
        600, "--timeout", "-t", help="Max execution time in seconds (default: 600)"
    ),
    queue_timeout: int = typer.Option(
        300, "--queue-timeout", help="Max time to wait for GPU if all are busy (default: 300s)"
    ),
) -> None:
    """Run NCU profiling remotely on a wafer B200 GPU.
    Packages your code directory, uploads it to a B200 machine with hardware
    counter access, runs NCU on your command, and downloads the .ncu-rep report.

    GPU scheduling: B200 GPUs are shared with workspaces. If all GPUs are
    busy, your job enters a FIFO queue with position updates. Use
    --queue-timeout to control how long to wait (default: 5 minutes).

    Your directory is uploaded respecting .gitignore (if in a git repo).
    If a requirements.txt is found in the directory, dependencies are installed
    automatically before profiling.
    Examples:
        wafer tool ncu run python run.py
        wafer tool ncu run --dir ./src python run.py
        wafer tool ncu run --ncu-args="--set full" python run.py
        wafer tool ncu run --output profile.ncu-rep python run.py
        wafer tool ncu run --no-download python run.py
        wafer tool ncu run --exclude "*.dat" --exclude "data/" python run.py
    """
    _validate_ncu_run_args(command, directory)
    from .ncu_run import ncu_run
    try:
        exit_code = ncu_run(
            command=command, directory=directory, ncu_args=ncu_args,
            requirements=requirements, output=output, no_download=no_download,
            exclude=exclude, timeout=timeout, queue_timeout=queue_timeout,
        )
        raise typer.Exit(exit_code)
    except typer.Exit:
        raise
    except KeyboardInterrupt:
        typer.echo("\nInterrupted by user", err=True)
        raise typer.Exit(130) from None
    except Exception as e:
        typer.echo(f"Error: {e}", err=True)
        raise typer.Exit(1) from None


@nsys_app.command("analyze")
def nsys_analyze(
    filepath: Path = typer.Argument(..., help="Path to .nsys-rep profile file"),
    output_dir: Path | None = typer.Option(
        None, "--output-dir", "-o", help="Output directory for analysis files"
    ),
    json_output: bool = typer.Option(
        False, "--json", "-j", help="Output raw JSON instead of formatted text"
    ),
    remote: bool | None = typer.Option(
        None,
        "--remote/--local",
        help="Force remote (via API) or local analysis. Default: auto-detect (remote if nsys not installed locally)",
    ),
    target: str | None = typer.Option(
        None,
        "--target",
        "-t",
        help="Remote target: 'workspace:id' for workspace execution, or target name from ~/.wafer/targets/",
    ),
) -> None:
    """Analyze an NVIDIA Nsight Systems profile (.nsys-rep file).
    Returns timeline events, kernel information, memory usage, and diagnostics.
    By default, uses local nsys if available, otherwise runs analysis
    remotely via wafer-api (requires authentication: wafer settings login).
    Supports multiple execution modes:
    - Local: Uses local nsys CLI (no GPU required for analysis)
    - Remote API: Uploads file and runs analysis on Modal
    - Workspace: Runs analysis on a Wafer workspace via SSH
    - Target: Runs analysis on a configured target machine via SSH
    Examples:
        wafer tool nsys analyze profile.nsys-rep
        wafer tool nsys analyze profile.nsys-rep --json
        wafer tool nsys analyze profile.nsys-rep --local
        wafer tool nsys analyze profile.nsys-rep --remote
        wafer tool nsys analyze profile.nsys-rep --target workspace:abc123
        wafer tool nsys analyze profile.nsys-rep --target vultr-b200
        wafer tool nsys analyze profile.nsys-rep -o ./results/
    """
    from .nsys_analyze import analyze_nsys_profile
    if not filepath.exists():
        typer.echo(f"Error: File not found: {filepath}", err=True)
        raise typer.Exit(1)
    if filepath.suffix != ".nsys-rep":
        typer.echo(f"Error: Expected .nsys-rep file, got: {filepath.suffix}", err=True)
        raise typer.Exit(1)
    # Warn if both remote flag and target are specified
    if target and remote is not None:
        typer.echo(
            "Warning: --target overrides --remote/--local flag",
            err=True,
        )
    try:
        result = analyze_nsys_profile(
            filepath,
            json_output=json_output,
            remote=remote,
            target=target,
            output_dir=output_dir,
        )
        typer.echo(result)
    except FileNotFoundError as e:
        typer.echo(f"Error: {e}", err=True)
        raise typer.Exit(1) from None
    except (RuntimeError, ValueError, NotImplementedError) as e:
        typer.echo(f"Error: {e}", err=True)
        raise typer.Exit(1) from None


def _nsys_resolve_command(command: list[str] | str) -> str:
    assert isinstance(command, (list, str)), "command must be a list or string"
    assert command, "command must not be empty"

    import shlex
    if isinstance(command, list):
        if command and command[0] == "--":
            command = command[1:]
        if len(command) == 1:
            return command[0]
        return shlex.join(command)
    return command


def _nsys_build_options(
    command_str: str, output: str, trace: str | None,
    duration: int | None, extra_args: str | None,
) -> Any:
    assert isinstance(command_str, str), "command_str must be a string"
    assert isinstance(output, str) and output, "output must be a non-empty string"

    if not command_str:
        typer.echo("Error: No command specified", err=True)
        raise typer.Exit(1)
    from .nsys_profile import NSYSProfileOptions
    trace_list = trace.split(",") if trace else None
    return NSYSProfileOptions(
        command=command_str, output=output, trace=trace_list,
        duration=duration, extra_args=extra_args,
    )


def _nsys_execute(
    options: Any, target: str | None, analyze: bool,
    json_output: bool, verbose: bool,
) -> tuple[Any, Any]:
    assert options is not None, "options must not be None"
    assert isinstance(analyze, bool), "analyze must be a bool"

    from .nsys_analyze import _parse_target
    from .nsys_profile import (
        profile_and_analyze,
        profile_local,
        profile_remote_ssh,
        profile_workspace,
    )
    if analyze:
        return profile_and_analyze(
            options, target=target, json_output=json_output, verbose=verbose,
        )
    if target:
        target_type, target_id = _parse_target(target)
        if target_type == "workspace":
            profile_result = profile_workspace(target_id, options, verbose=verbose)
        else:
            profile_result = profile_remote_ssh(target_id, options, verbose=verbose)
    else:
        profile_result = profile_local(options, verbose=verbose)
    return profile_result, None


def _nsys_report_results(
    profile_result: Any, analysis_result: Any,
    verbose: bool, analyze: bool,
) -> None:
    assert profile_result is not None, "profile_result must not be None"
    assert isinstance(verbose, bool), "verbose must be a bool"

    if not profile_result.success:
        typer.echo(f"Error: {profile_result.error}", err=True)
        if profile_result.stderr:
            typer.echo(f"stderr: {profile_result.stderr}", err=True)
        raise typer.Exit(1)
    if verbose or not analyze:
        typer.echo(f"Profile created: {profile_result.output_path}")
    if analysis_result:
        if not analysis_result.success:
            typer.echo(f"Analysis error: {analysis_result.error}", err=True)
            raise typer.Exit(1)


@nsys_app.command("profile", context_settings={"allow_interspersed_args": False})
def nsys_profile(
    command: list[str] = typer.Argument(..., help="Command to profile"),
    output: str = typer.Option(
        "profile",
        "--output",
        "-o",
        help="Output filename (without .nsys-rep extension)",
    ),
    trace: str | None = typer.Option(
        None,
        "--trace",
        "-t",
        help="Trace APIs to capture (comma-separated: cuda,nvtx,osrt,cudnn,cublas). Default: cuda",
    ),
    duration: int | None = typer.Option(
        None,
        "--duration",
        "-d",
        help="Maximum profiling duration in seconds",
    ),
    target: str | None = typer.Option(
        None,
        "--target",
        help="Remote target: 'workspace:id' for workspace execution, or target name from ~/.wafer/targets/",
    ),
    analyze: bool = typer.Option(
        False,
        "--analyze",
        "-a",
        help="Automatically analyze the profile after completion",
    ),
    json_output: bool = typer.Option(
        False,
        "--json",
        "-j",
        help="Output analysis as JSON (only with --analyze)",
    ),
    verbose: bool = typer.Option(
        False,
        "--verbose",
        "-v",
        help="Show verbose progress messages",
    ),
    extra_args: str | None = typer.Option(
        None,
        "--extra",
        help="Extra arguments to pass to nsys profile",
    ),
) -> None:
    """Profile a command with NVIDIA Nsight Systems.
    Runs nsys profile on the specified command and generates a .nsys-rep file.
    Profiling requires an NVIDIA GPU. Use --target to run on a remote GPU server
    or workspace.
    Examples:
        wafer tool nsys profile -- python train.py
        wafer tool nsys profile -o gemm_profile -- ./gemm_kernel
        wafer tool nsys profile --trace cuda,nvtx -- python model.py
        wafer tool nsys profile --duration 60 -- ./long_running_app
        wafer tool nsys profile --target workspace:abc123 -- python test.py
        wafer tool nsys profile --target vultr-b200 -- ./benchmark
        wafer tool nsys profile --analyze -- python train.py
        wafer tool nsys profile --analyze --json -- ./kernel > results.json
    """
    command_str = _nsys_resolve_command(command)
    options = _nsys_build_options(command_str, output, trace, duration, extra_args)
    if verbose:
        typer.echo(f"[nsys] Command: {command_str}" + (f"  Target: {target}" if target else ""), err=True)
    profile_result, analysis_result = _nsys_execute(options, target, analyze, json_output, verbose)
    _nsys_report_results(profile_result, analysis_result, verbose, analyze)


rocprof_sdk_app = typer.Typer(help="ROCprofiler-SDK profiling tool commands")
tool_app.add_typer(rocprof_sdk_app, name="rocprof-sdk", rich_help_panel="AMD Profiling")


@rocprof_sdk_app.command("list-counters")
def rocprof_sdk_list_counters() -> None:
    """List available hardware counters for your GPU.
    Examples:
        wafer rocprof-sdk list-counters
        wafer rocprof-sdk list-counters | grep SQ_
    """
    from .rocprof_sdk import list_counters_command
    try:
        list_counters_command()
    except Exception as e:
        typer.echo(f"Error: {e}", err=True)
        raise typer.Exit(1) from None


@rocprof_sdk_app.command("profile")
def rocprof_sdk_profile(
    command: str = typer.Argument(..., help="Command to profile"),
    output_dir: str | None = typer.Option(None, "--output-dir", "-o", help="Output directory"),
    output_format: str = typer.Option(
        "csv", "--format", "-f", help="Output format (csv, json, rocpd, pftrace, otf2)"
    ),
    counters: str | None = typer.Option(
        None, "--counters", "-c", help="Comma-separated hardware counters"
    ),
    kernel_include: str | None = typer.Option(
        None, "--kernel-include", help="Include only kernels matching this regex"
    ),
    kernel_exclude: str | None = typer.Option(
        None, "--kernel-exclude", help="Exclude kernels matching this regex"
    ),
    trace_hip_runtime: bool = typer.Option(
        False, "--trace-hip-runtime", help="Enable HIP runtime API tracing"
    ),
    trace_hip_compiler: bool = typer.Option(
        False, "--trace-hip-compiler", help="Enable HIP compiler code tracing"
    ),
    trace_hsa: bool = typer.Option(False, "--trace-hsa", help="Enable HSA API tracing"),
    trace_marker: bool = typer.Option(False, "--trace-marker", help="Enable ROCTx marker tracing"),
    trace_memory_copy: bool = typer.Option(
        False, "--trace-memory-copy", help="Enable memory copy tracing"
    ),
    json_output: bool = typer.Option(False, "--json", "-j", help="Output as JSON"),
) -> None:
    """Profile a command with rocprofv3.
    Examples:
        wafer rocprof-sdk profile './my_kernel'
        wafer rocprof-sdk profile './app' --format csv --output-dir ./results
        wafer rocprof-sdk profile './kernel' --counters SQ_WAVES,L2_CACHE_HITS
        wafer rocprof-sdk profile './app' --kernel-include 'vectorAdd|matmul'
        wafer rocprof-sdk profile './app' --trace-hip-runtime --trace-memory-copy
    """
    from .rocprof_sdk import profile_command
    counter_list = counters.split(",") if counters else None
    try:
        result = profile_command(
            command,
            output_dir,
            output_format,
            counter_list,
            kernel_include,
            kernel_exclude,
            trace_hip_runtime,
            trace_hip_compiler,
            trace_hsa,
            trace_marker,
            trace_memory_copy,
            json_output,
        )
        if json_output:
            typer.echo(result)
    except Exception as e:
        typer.echo(f"Error: {e}", err=True)
        raise typer.Exit(1) from None


@rocprof_sdk_app.command("analyze")
def rocprof_sdk_analyze(
    file_path: Path = typer.Argument(
        ..., help="Path to rocprofiler output file (.csv, .json, .db)"
    ),
    json_output: bool = typer.Option(False, "--json", "-j", help="Output as JSON"),
) -> None:
    """Analyze a rocprofiler output file.
    Supports:
    - CSV stats files (stats_*.csv)
    - JSON trace files (*.json)
    - rocpd databases (*_results.db, *.rocpd)
    Examples:
        wafer rocprof-sdk analyze stats_kernel.csv
        wafer rocprof-sdk analyze results.json
        wafer rocprof-sdk analyze profile_results.db --json
    """
    from .rocprof_sdk import analyze_command
    if not file_path.exists():
        typer.echo(f"Error: File not found: {file_path}", err=True)
        raise typer.Exit(1)
    try:
        result = analyze_command(str(file_path), json_output)
        if json_output:
            typer.echo(result)
    except Exception as e:
        typer.echo(f"Error: {e}", err=True)
        raise typer.Exit(1) from None


rocprof_systems_app = typer.Typer(help="ROCprofiler-Systems profiling tool commands")
tool_app.add_typer(rocprof_systems_app, name="rocprof-systems", rich_help_panel="AMD Profiling")


@rocprof_systems_app.command("run")
def rocprof_systems_run(
    command: str = typer.Argument(..., help="Command to profile"),
    output_dir: str | None = typer.Option(None, "--output-dir", "-o", help="Output directory"),
    trace: bool = typer.Option(
        True, "--trace/--no-trace", help="Generate detailed trace (Perfetto)"
    ),
    profile: bool = typer.Option(False, "--profile", help="Generate call-stack-based profile"),
    flat_profile: bool = typer.Option(False, "--flat-profile", help="Generate flat profile"),
    sample: bool = typer.Option(False, "--sample", help="Enable sampling profiling"),
    host: bool = typer.Option(False, "--host", help="Enable host metrics"),
    device: bool = typer.Option(False, "--device", help="Enable device metrics"),
    wait: float | None = typer.Option(None, "--wait", help="Wait time before collecting (seconds)"),
    duration: float | None = typer.Option(
        None, "--duration", help="Duration of collection (seconds)"
    ),
    use_rocm: bool = typer.Option(True, "--use-rocm/--no-rocm", help="Enable ROCm backend"),
    use_sampling: bool = typer.Option(False, "--use-sampling", help="Enable sampling backend"),
    use_kokkosp: bool = typer.Option(
        False, "--use-kokkosp", help="Enable Kokkos profiling backend"
    ),
    use_mpip: bool = typer.Option(False, "--use-mpip", help="Enable MPI profiling backend"),
    use_rocpd: bool = typer.Option(False, "--use-rocpd", help="Enable rocpd database output"),
    json_output: bool = typer.Option(False, "--json", "-j", help="Output as JSON"),
) -> None:
    """Run system profiling with rocprof-sys-run.
    Examples:
        wafer rocprof-systems run './my_app'
        wafer rocprof-systems run './app' --trace --profile --output-dir ./results
        wafer rocprof-systems run './kernel' --host --device --duration 10
        wafer rocprof-systems run './app' --use-kokkosp --use-mpip
    """
    from .rocprof_systems import run_command
    try:
        result = run_command(
            command=command,
            output_dir=output_dir,
            trace=trace,
            profile=profile,
            flat_profile=flat_profile,
            sample=sample,
            host=host,
            device=device,
            wait=wait,
            duration=duration,
            use_rocm=use_rocm,
            use_sampling=use_sampling,
            use_kokkosp=use_kokkosp,
            use_mpip=use_mpip,
            use_rocpd=use_rocpd,
            json_output=json_output,
        )
        if json_output:
            typer.echo(result)
    except Exception as e:
        typer.echo(f"Error: {e}", err=True)
        raise typer.Exit(1) from None


@rocprof_systems_app.command("analyze")
def rocprof_systems_analyze(
    file_path: Path = typer.Argument(..., help="Path to rocprof-sys output file (.json, .txt)"),
    json_output: bool = typer.Option(False, "--json", "-j", help="Output as JSON"),
) -> None:
    """Analyze a rocprof-sys output file.
    Supports:
    - JSON files (wall_clock-*.json, metadata-*.json, functions-*.json)
    - Text files (wall-clock.txt)
    Examples:
        wafer rocprof-systems analyze wall_clock-12345.json
        wafer rocprof-systems analyze wall-clock.txt --json
    """
    from .rocprof_systems import analyze_command
    if not file_path.exists():
        typer.echo(f"Error: File not found: {file_path}", err=True)
        raise typer.Exit(1)
    try:
        result = analyze_command(str(file_path), json_output)
        if json_output:
            typer.echo(result)
    except Exception as e:
        typer.echo(f"Error: {e}", err=True)
        raise typer.Exit(1) from None


@rocprof_systems_app.command("sample")
def rocprof_systems_sample(
    command: str = typer.Argument(..., help="Command to profile"),
    output_dir: str | None = typer.Option(None, "--output-dir", "-o", help="Output directory"),
    frequency: int | None = typer.Option(
        None, "--frequency", "--freq", "-f", help="Sampling frequency in Hz"
    ),
    trace: bool = typer.Option(False, "--trace", help="Generate detailed trace"),
    profile: bool = typer.Option(False, "--profile", help="Generate call-stack profile"),
    flat_profile: bool = typer.Option(False, "--flat-profile", help="Generate flat profile"),
    host: bool = typer.Option(False, "--host", help="Enable host metrics"),
    device: bool = typer.Option(False, "--device", help="Enable device metrics"),
    wait: float | None = typer.Option(None, "--wait", help="Wait time (seconds)"),
    duration: float | None = typer.Option(None, "--duration", help="Duration (seconds)"),
    json_output: bool = typer.Option(False, "--json", "-j", help="Output as JSON"),
) -> None:
    """Run sampling profiling with rocprof-sys-sample.
    Examples:
        wafer rocprof-systems sample ./my_app --frequency 100
        wafer rocprof-systems sample ./kernel --freq 500 --output-dir ./results
    """
    from .rocprof_systems import sample_command
    try:
        result = sample_command(
            command=command,
            output_dir=output_dir,
            frequency=frequency,
            trace=trace,
            profile=profile,
            flat_profile=flat_profile,
            host=host,
            device=device,
            wait=wait,
            duration=duration,
            json_output=json_output,
        )
        if json_output:
            typer.echo(result)
    except Exception as e:
        typer.echo(f"Error: {e}", err=True)
        raise typer.Exit(1) from None


@rocprof_systems_app.command("instrument")
def rocprof_systems_instrument(
    command: str = typer.Argument(..., help="Command to instrument"),
    output_dir: str | None = typer.Option(None, "--output-dir", "-o", help="Output directory"),
    simulate: bool = typer.Option(False, "--simulate", help="Simulate without creating binary"),
    function_include: list[str] | None = typer.Option(
        None, "--function-include", help="Function patterns to include"
    ),
    function_exclude: list[str] | None = typer.Option(
        None, "--function-exclude", help="Function patterns to exclude"
    ),
    json_output: bool = typer.Option(False, "--json", "-j", help="Output as JSON"),
) -> None:
    """Run binary instrumentation with rocprof-sys-instrument.
    Examples:
        wafer rocprof-systems instrument ./my_app --simulate
        wafer rocprof-systems instrument ./kernel --output-dir ./results
    """
    from .rocprof_systems import instrument_command
    try:
        result = instrument_command(
            command=command,
            output_dir=output_dir,
            simulate=simulate,
            function_include=function_include,
            function_exclude=function_exclude,
            json_output=json_output,
        )
        if json_output:
            typer.echo(result)
    except Exception as e:
        typer.echo(f"Error: {e}", err=True)
        raise typer.Exit(1) from None


@rocprof_systems_app.command("query")
def rocprof_systems_query(
    components: bool = typer.Option(False, "--components", help="Query available components"),
    hw_counters: bool = typer.Option(False, "--hw-counters", help="Query hardware counters"),
    all_metrics: bool = typer.Option(False, "--all", help="Query all metrics"),
    filter_pattern: str | None = typer.Option(None, "--filter", help="Filter results"),
    json_output: bool = typer.Option(False, "--json", "-j", help="Output as JSON"),
) -> None:
    """Query available profiling metrics and components.
    Examples:
        wafer rocprof-systems query --components
        wafer rocprof-systems query --hw-counters
        wafer rocprof-systems query --components --filter cpu
    """
    from .rocprof_systems import query_command
    try:
        result = query_command(
            components=components,
            hw_counters=hw_counters,
            all_metrics=all_metrics,
            filter_pattern=filter_pattern,
            json_output=json_output,
        )
        if json_output:
            typer.echo(result)
    except Exception as e:
        typer.echo(f"Error: {e}", err=True)
        raise typer.Exit(1) from None


rocprof_compute_app = typer.Typer(help="ROCprofiler-Compute profiling tool commands")
tool_app.add_typer(rocprof_compute_app, name="rocprof-compute", rich_help_panel="AMD Profiling")


@rocprof_compute_app.command("profile")
def rocprof_compute_profile(
    command: str = typer.Argument(..., help="Command to profile"),
    name: str = typer.Option(..., "--name", "-n", help="Workload name"),
    path: str | None = typer.Option(None, "--path", "-p", help="Workload base path"),
    kernel: str | None = typer.Option(
        None, "--kernel", "-k", help="Kernel filter (comma-separated)"
    ),
    dispatch: str | None = typer.Option(
        None, "--dispatch", "-d", help="Dispatch filter (comma-separated)"
    ),
    block: str | None = typer.Option(None, "--block", "-b", help="Block filter (comma-separated)"),
    no_roof: bool = typer.Option(False, "--no-roof", help="Skip roofline data"),
    roof_only: bool = typer.Option(False, "--roof-only", help="Profile roofline only (fastest)"),
    hip_trace: bool = typer.Option(False, "--hip-trace", help="Enable HIP trace"),
    verbose: int = typer.Option(0, "--verbose", "-v", count=True, help="Increase verbosity"),
    json_output: bool = typer.Option(False, "--json", "-j", help="Output as JSON"),
) -> None:
    """Profile a command with rocprof-compute.
    Executes rocprof-compute profiling on the target command and generates
    analysis results including roofline data, memory analysis, and kernel statistics.
    Examples:
        wafer rocprof-compute profile --name vcopy -- './vcopy -n 1048576'
        wafer rocprof-compute profile -n test -b SQ,TCC -- './kernel'
        wafer rocprof-compute profile -n trace --hip-trace -- './app'
        wafer rocprof-compute profile -n test --roof-only -- './app'
    """
    from .rocprof_compute import profile_command
    try:
        result = profile_command(
            command,
            name,
            path,
            kernel,
            dispatch,
            block,
            no_roof,
            roof_only,
            hip_trace,
            verbose,
            json_output,
        )
        if json_output:
            typer.echo(result)
    except Exception as e:
        typer.echo(f"Error: {e}", err=True)
        raise typer.Exit(1) from None


@rocprof_compute_app.command("analyze")
def rocprof_compute_analyze(
    workload_path: Path = typer.Argument(..., help="Path to workload directory"),
    kernel: str | None = typer.Option(None, "--kernel", "-k", help="Kernel filter"),
    dispatch: str | None = typer.Option(None, "--dispatch", "-d", help="Dispatch filter"),
    block: str | None = typer.Option(None, "--block", "-b", help="Block filter"),
    output: str | None = typer.Option(None, "--output", "-o", help="Output file"),
    list_stats: bool = typer.Option(
        False, "--list-stats", help="List all detected kernels and dispatches"
    ),
    json_output: bool = typer.Option(False, "--json", "-j", help="Output as JSON"),
    gui: bool = typer.Option(
        False, "--gui", help="Launch interactive GUI viewer (bundled Python viewer by default)"
    ),
    port: int = typer.Option(8050, "--port", "-p", help="Port for GUI server"),
    external: bool = typer.Option(
        False,
        "--external",
        help="Use AMD's native rocprof-compute GUI instead of bundled (requires ROCm)",
    ),
) -> None:
    """Analyze a rocprof-compute workload directory.
    Parses workload data and displays kernel statistics, roofline analysis,
    and performance metrics. Can optionally launch an interactive GUI viewer.
    GUI Modes:
        --gui           Uses Wafer's bundled Python viewer (works anywhere, no ROCm needed)
        --gui --external Uses AMD's native rocprof-compute GUI (requires ROCm installation)
    Examples:
        wafer rocprof-compute analyze ./workloads/vcopy
        wafer rocprof-compute analyze ./workloads/test --json
        wafer rocprof-compute analyze ./workloads/app -d 0,1 -o filtered.csv
        wafer rocprof-compute analyze ./workloads/app --list-stats
        wafer rocprof-compute analyze ./workloads/app --gui
        wafer rocprof-compute analyze ./workloads/app --gui --port 9000
        wafer rocprof-compute analyze ./workloads/app --gui --external
    """
    from .rocprof_compute import analyze_command
    if not workload_path.exists():
        typer.echo(f"Error: Workload path not found: {workload_path}", err=True)
        raise typer.Exit(1)
    try:
        result = analyze_command(
            str(workload_path),
            kernel,
            dispatch,
            block,
            output,
            list_stats,
            json_output,
            gui,
            port,
            external,
        )
        if json_output or not gui:
            typer.echo(result)
    except Exception as e:
        typer.echo(f"Error: {e}", err=True)
        raise typer.Exit(1) from None


@rocprof_compute_app.command("list-metrics")
def rocprof_compute_list_metrics(
    arch: str = typer.Argument(..., help="Architecture (gfx90a, gfx942, etc.)"),
) -> None:
    """List available metrics for an architecture.
    Examples:
        wafer rocprof-compute list-metrics gfx90a
        wafer rocprof-compute list-metrics gfx942
    """
    from .rocprof_compute import list_metrics_command
    try:
        result = list_metrics_command(arch)
        if result:
            typer.echo(result)
    except Exception as e:
        typer.echo(f"Error: {e}", err=True)
        raise typer.Exit(1) from None


autotuner_app = typer.Typer(help="Hyperparameter sweep for performance engineering")
tool_app.add_typer(autotuner_app, name="autotuner", hidden=True)


def _setup_wafer_env() -> None:
    """Set environment variables for wafer-ai to use.
    Call this before using wafer functions that need API access.
    Respects explicit environment variable overrides:
    - WAFER_API_URL: If already set, uses that instead of config
    - WAFER_AUTH_TOKEN: If already set, uses that instead of cached token
    """
    from .auth import get_valid_token
    from .global_config import get_api_url

    os.environ["WAFER_API_URL"] = get_api_url()
    # Only set auth token if not explicitly provided in environment
    # This allows CI/service accounts to override with their own tokens
    if "WAFER_AUTH_TOKEN" not in os.environ:
        token = get_valid_token()
        if token:
            os.environ["WAFER_AUTH_TOKEN"] = token


@autotuner_app.command("list")
def autotuner_list(
    show_all: bool = typer.Option(
        False, "--all", help="Show all sweeps including pending and failed"
    ),
) -> None:
    """List sweeps for the current user.
    By default, only shows running and completed sweeps.
    Use --all to include pending and failed sweeps.
    Examples:
        wafer autotuner list
        wafer autotuner list --all
    """
    _setup_wafer_env()
    from .autotuner import list_command
    try:
        result = list_command(show_all=show_all)
        print(result)
    except ValueError as e:
        typer.echo(f"Error: {e}", err=True)
        raise typer.Exit(1) from None
    except Exception as e:
        typer.echo(f"Error: {e}", err=True)
        raise typer.Exit(1) from None


@autotuner_app.command("delete")
def autotuner_delete(
    sweep_id: str | None = typer.Argument(None, help="Sweep ID to delete (omit when using --all)"),
    delete_all: bool = typer.Option(
        False, "--all", help="Delete all sweeps (optionally filtered by --status)"
    ),
    status: str | None = typer.Option(
        None,
        "--status",
        help="Filter by status when using --all (pending, running, completed, failed)",
    ),
    yes: bool = typer.Option(False, "--yes", "-y", help="Skip confirmation prompt"),
) -> None:
    """Delete a sweep (or all sweeps) and their trials.
    WARNING: This permanently deletes sweeps and cannot be undone.
    Examples:
        # Delete single sweep
        wafer autotuner delete <sweep-id>
        wafer autotuner delete <sweep-id> --yes
        # Delete all sweeps
        wafer autotuner delete --all
        wafer autotuner delete --all --status pending
        wafer autotuner delete --all --status failed --yes
    """
    _setup_wafer_env()
    from .autotuner import delete_all_command, delete_command
    # Validate arguments
    if delete_all and sweep_id:
        typer.echo("Error: Cannot specify both sweep_id and --all flag", err=True)
        raise typer.Exit(1)
    if not delete_all and not sweep_id:
        typer.echo("Error: Must specify either sweep_id or --all flag", err=True)
        raise typer.Exit(1)
    if status and not delete_all:
        typer.echo("Error: --status can only be used with --all flag", err=True)
        raise typer.Exit(1)
    try:
        if delete_all:
            # Delete all sweeps
            if not yes:
                status_msg = f" with status '{status}'" if status else ""
                confirm = typer.confirm(f"Are you sure you want to delete all sweeps{status_msg}?")
                if not confirm:
                    typer.echo("Deletion cancelled.")
                    raise typer.Exit(0)
            result = delete_all_command(status_filter=status)
        else:
            # Delete single sweep
            if not yes:
                confirm = typer.confirm(f"Are you sure you want to delete sweep {sweep_id}?")
                if not confirm:
                    typer.echo("Deletion cancelled.")
                    raise typer.Exit(0)
            result = delete_command(sweep_id)
        print(result)
    except ValueError as e:
        typer.echo(f"Error: {e}", err=True)
        raise typer.Exit(1) from None
    except Exception as e:
        typer.echo(f"Error: {e}", err=True)
        raise typer.Exit(1) from None


@autotuner_app.command("run")
def autotuner_run(
    config_file: Path | None = typer.Argument(
        None, help="Path to JSON config file (required unless --resume)"
    ),
    parallel: int = typer.Option(
        4, "--parallel", "-p", help="Number of trials to run concurrently"
    ),
    resume: str | None = typer.Option(None, "--resume", "-r", help="Resume existing sweep by ID"),
) -> None:
    """Run hyperparameter sweep from JSON config or resume existing sweep.
    Examples:
        # Start new sweep
        wafer autotuner run config.json
        wafer autotuner run config.json --parallel 8
        # Resume failed/interrupted sweep
        wafer autotuner run --resume <sweep-id>
        wafer autotuner run --resume <sweep-id> --parallel 8
    """
    _setup_wafer_env()
    from .autotuner import run_sweep_command
    # Validate arguments
    if not resume and not config_file:
        typer.echo("Error: Must specify either config file or --resume <sweep-id>", err=True)
        raise typer.Exit(1)
    if resume and config_file:
        typer.echo("Error: Cannot specify both config file and --resume", err=True)
        raise typer.Exit(1)
    try:
        result = run_sweep_command(
            config_file=config_file, parallel=parallel, resume_sweep_id=resume
        )
        print(result)
    except FileNotFoundError as e:
        typer.echo(f"Error: {e}", err=True)
        raise typer.Exit(1) from None
    except ValueError as e:
        typer.echo(f"Error: {e}", err=True)
        raise typer.Exit(1) from None
    except Exception as e:
        typer.echo(f"Error: {e}", err=True)
        raise typer.Exit(1) from None


@autotuner_app.command("results")
def autotuner_results(
    sweep_id: str = typer.Argument(..., help="Sweep ID to retrieve"),
    mode: str = typer.Argument("list", help="Display mode: 'list', 'best', or trial number"),
    sort_by: str | None = typer.Option(
        None, "--sort-by", help="Metric name to sort by (list mode)"
    ),
    direction: str = typer.Option("maximize", "--direction", help="Sort direction (list mode)"),
    pareto: str | None = typer.Option(
        None, "--pareto", help="Comma-separated metrics for Pareto frontier (list mode)"
    ),
    show_all: bool = typer.Option(
        False, "--show-all", help="Include failed and constraint-violated trials (list mode)"
    ),
    limit: int | None = typer.Option(
        None, "--limit", help="Maximum number of results to show (list mode, default: all)"
    ),
    metric: str | None = typer.Option(
        None, "--metric", help="Metric to optimize (REQUIRED for best mode)"
    ),
) -> None:
    """Show sweep results (list/best/trial).
    Commands:
        wafer autotuner results <sweep-id>                    # List all results
        wafer autotuner results <sweep-id> --sort-by <metric> # List sorted
        wafer autotuner results <sweep-id> best --metric <m>  # Show best config
        wafer autotuner results <sweep-id> <N>                # Show trial N
    """
    from .autotuner import best_command, results_command, trial_command
    try:
        if mode == "best":
            if not metric:
                typer.echo("Error: --metric is required for 'best' mode", err=True)
                raise typer.Exit(1)
            result = best_command(sweep_id=sweep_id, metric=metric)
        elif mode == "list":
            result = results_command(
                sweep_id=sweep_id,
                sort_by=sort_by,
                direction=direction,
                pareto=pareto,
                show_all=show_all,
                limit=limit,
            )
        else:
            # Try to parse as trial number
            try:
                trial_number = int(mode)
                result = trial_command(sweep_id=sweep_id, trial_number=trial_number)
            except ValueError as e:
                typer.echo(
                    f"Error: Invalid mode '{mode}'. Use 'list', 'best', or a trial number.",
                    err=True,
                )
                raise typer.Exit(1) from e
        print(result)
    except ValueError as e:
        typer.echo(f"Error: {e}", err=True)
        raise typer.Exit(1) from None
    except Exception as e:
        typer.echo(f"Error: {e}", err=True)
        raise typer.Exit(1) from None


def _capture_setup_env() -> None:
    import os

    from .auth import get_valid_token
    from .global_config import get_api_url

    os.environ["WAFER_API_URL"] = get_api_url()
    if "WAFER_AUTH_TOKEN" not in os.environ:
        token = get_valid_token()
        if token:
            os.environ["WAFER_AUTH_TOKEN"] = token


def _capture_load_denylists(work_dir: Path) -> tuple[list[str] | None, list[str] | None]:
    assert isinstance(work_dir, Path), "work_dir must be a Path"
    assert work_dir.is_absolute(), f"work_dir must be an absolute path: {work_dir}"

    import tomllib
    config_code_denylist = None
    config_artifact_denylist = None
    global_config_path = Path.home() / ".wafer" / "capture.toml"
    if global_config_path.exists():
        try:
            with open(global_config_path, "rb") as f:
                data = tomllib.load(f)
            config_code_denylist = data.get("code_denylist")
            config_artifact_denylist = data.get("artifact_denylist")
        except Exception as e:
            typer.echo(f"\u26a0\ufe0f  Warning: Failed to load {global_config_path}: {e}", err=True)
    project_config_path = work_dir / ".wafer-capture.toml"
    if project_config_path.exists():
        try:
            with open(project_config_path, "rb") as f:
                pdata = tomllib.load(f)
            if "code_denylist" in pdata:
                config_code_denylist = pdata["code_denylist"]
            if "artifact_denylist" in pdata:
                config_artifact_denylist = pdata["artifact_denylist"]
        except Exception as e:
            typer.echo(f"\u26a0\ufe0f  Warning: Failed to load {project_config_path}: {e}", err=True)
    return config_code_denylist, config_artifact_denylist


def _capture_parse_sweep(sweep: list[str] | None) -> dict[str, list[str]]:
    assert sweep is None or isinstance(sweep, list), "sweep must be a list or None"
    assert sweep is None or all(isinstance(s, str) for s in sweep), "all sweep entries must be strings"

    sweep_vars: dict[str, list[str]] = {}
    if not sweep:
        return sweep_vars
    for sweep_spec in sweep:
        if "=" not in sweep_spec:
            typer.echo(f"Error: Invalid sweep format: {sweep_spec}", err=True)
            typer.echo("   Expected format: VAR=val1,val2,val3", err=True)
            raise typer.Exit(1)
        var_name, values_str = sweep_spec.split("=", 1)
        sweep_vars[var_name] = [v.strip() for v in values_str.split(",")]
    return sweep_vars


def _capture_build_combinations(
    sweep_vars: dict[str, list[str]], label: str, json_output: bool,
) -> tuple[list[tuple[str, ...]], list[str]]:
    assert isinstance(sweep_vars, dict), "sweep_vars must be a dict"
    assert isinstance(label, str) and label, "label must be a non-empty string"

    import itertools
    if sweep_vars:
        var_names = list(sweep_vars.keys())
        var_values = [sweep_vars[name] for name in var_names]
        combinations = list(itertools.product(*var_values))
        if not json_output:
            typer.echo(f"Running sweep: {label}")
            typer.echo(f"   Variables: {', '.join(var_names)}")
            typer.echo(f"   Total runs: {len(combinations)}")
            typer.echo()
        return combinations, var_names
    return [()], []


def _capture_result_to_dict(result: Any, label: str, cmd: str, sweep_info: dict[str, str]) -> dict[str, Any]:
    assert result is not None, "result must not be None"
    assert isinstance(label, str) and label, "label must be a non-empty string"

    data = {
        "id": result.id,
        "label": label,
        "command": cmd,
        "exit_code": result.exit_code,
        "duration_seconds": result.duration_seconds,
        "code_files": len(result.code_files),
        "artifacts": len(result.artifacts),
    }
    if result.metrics.stdout_metrics:
        data["metrics_count"] = len(result.metrics.stdout_metrics)
    if sweep_info:
        data["sweep"] = sweep_info
    return data


def _capture_print_result(result: Any) -> None:
    assert result is not None, "result must not be None"
    assert hasattr(result, "id"), "result must have an id attribute"

    typer.echo()
    typer.echo("\u2713 Capture complete")
    typer.echo(f"   ID: {result.id}")
    typer.echo(f"   Exit code: {result.exit_code}")
    typer.echo(f"   Duration: {result.duration_seconds:.2f}s")
    typer.echo(f"   Code files: {len(result.code_files)}")
    typer.echo(f"   Artifacts: {len(result.artifacts)}")
    if result.metrics.stdout_metrics:
        typer.echo(f"   Metrics: {len(result.metrics.stdout_metrics)}")
    typer.echo()


async def _capture_sweep_loop(
    combinations: list[tuple[str, ...]], var_names: list[str], sweep_vars: dict[str, list[str]],
    command: str, variant: str | None, label: str, work_dir: Path,
    tags: list[str] | None, code_denylist: list[str] | None,
    artifact_denylist: list[str] | None, json_output: bool,
    CaptureConfig: type, capture_fn: Callable[..., Any], execute_fn: Callable[..., Any],
    progress: Callable[[str], None],
) -> list[dict[str, Any]]:
    assert isinstance(combinations, list) and combinations, "combinations must be a non-empty list"
    assert isinstance(command, str) and command, "command must be a non-empty string"

    successful = 0
    failed = 0
    capture_results: list[dict] = []
    for idx, combo in enumerate(combinations, 1):
        substituted_cmd = command
        sweep_info = {}
        for var_name, value in zip(var_names, combo, strict=True):
            substituted_cmd = substituted_cmd.replace(f"{{{var_name}}}", value)
            sweep_info[var_name] = value
        run_variant = _capture_resolve_variant(sweep_vars, sweep_info, variant)
        denylist_kwargs = {}
        if code_denylist:
            denylist_kwargs["code_denylist"] = code_denylist
        if artifact_denylist:
            denylist_kwargs["artifact_denylist"] = artifact_denylist
        config = CaptureConfig(
            label=label, command=substituted_cmd, working_dir=work_dir,
            variant=run_variant, tags=tags or [], **denylist_kwargs,
        )
        try:
            if not json_output:
                _capture_print_run_header(sweep_vars, sweep_info, idx, len(combinations), label, substituted_cmd, work_dir)
            result = await capture_fn(config=config, runner=execute_fn, progress_callback=progress)
            capture_results.append(_capture_result_to_dict(result, label, substituted_cmd, sweep_info))
            if not json_output:
                _capture_print_result(result)
            successful += 1
        except Exception as e:
            if json_output:
                capture_results.append({"label": label, "command": substituted_cmd, "error": str(e)})
            else:
                typer.echo(f"\n\u2717 Capture failed: {e}", err=True)
                typer.echo()
            failed += 1
    _capture_print_summary(json_output, sweep_vars, combinations, successful, failed, capture_results)
    if failed > 0:
        raise typer.Exit(1)
    return capture_results


def _capture_resolve_variant(
    sweep_vars: dict[str, list[str]], sweep_info: dict[str, str], variant: str | None,
) -> str | None:
    assert isinstance(sweep_vars, dict), "sweep_vars must be a dict"
    assert isinstance(sweep_info, dict), "sweep_info must be a dict"

    if not sweep_vars:
        return variant
    variant_parts = [f"{k}={v}" for k, v in sweep_info.items()]
    run_variant = "_".join(variant_parts)
    if variant:
        run_variant = f"{variant}_{run_variant}"
    return run_variant


def _capture_print_run_header(
    sweep_vars: dict[str, list[str]], sweep_info: dict[str, str], idx: int, total: int,
    label: str, cmd: str, work_dir: Path,
) -> None:
    assert idx >= 1, f"idx must be >= 1, got {idx}"
    assert total >= 1, f"total must be >= 1, got {total}"

    if sweep_vars:
        typer.echo(f"[{idx}/{total}] {', '.join(f'{k}={v}' for k, v in sweep_info.items())}")
    else:
        typer.echo(f"Capturing: {label}")
    typer.echo(f"   Command: {cmd}")
    typer.echo(f"   Working dir: {work_dir}")
    typer.echo()


def _capture_print_summary(
    json_output: bool, sweep_vars: dict[str, list[str]], combinations: list[tuple[str, ...]],
    successful: int, failed: int, capture_results: list[dict[str, Any]],
) -> None:
    assert isinstance(json_output, bool), "json_output must be a bool"
    assert successful + failed == len(combinations), "successful + failed must equal total combinations"

    if json_output:
        from .output import json_response
        status = "ok" if failed == 0 else "error"
        data = {"captures": capture_results, "successful": successful, "failed": failed}
        typer.echo(json_response(data=data, status=status))
    elif sweep_vars and len(combinations) > 1:
        typer.echo("=" * 60)
        typer.echo(f"Sweep complete: {successful} successful, {failed} failed")


@tool_app.command("capture", rich_help_panel="Other")
def capture_command(  # noqa: PLR0915
    label: str = typer.Argument(
        ..., help="Label for this capture (e.g., 'baseline', 'optimized-v2')"
    ),
    command: str = typer.Argument(..., help="Command to execute and capture"),
    variant: str | None = typer.Option(
        None, "--variant", "-v", help="Variant identifier for grouping related captures"
    ),
    tags: list[str] | None = typer.Option(
        None, "--tag", "-t", help="Tags for categorization (can be specified multiple times)"
    ),  # noqa: B008
    working_dir: Path | None = typer.Option(
        None, "--dir", "-d", help="Working directory (default: current directory)"
    ),
    sweep: list[str] | None = typer.Option(
        None, "--sweep", "-s", help="Parameter sweep (format: VAR=val1,val2,val3)"
    ),  # noqa: B008
    code_denylist: list[str] | None = typer.Option(
        None,
        "--code-denylist",
        help="Patterns to exclude from code files (e.g., '*.log', '**/test/**')",
    ),  # noqa: B008
    artifact_denylist: list[str] | None = typer.Option(
        None,
        "--artifact-denylist",
        help="Patterns to exclude from artifacts (e.g., '*.tmp', '*.o')",
    ),  # noqa: B008
    json_output: bool = typer.Option(False, "--json", "-j", help="Output as JSON"),
) -> None:
    """Capture an execution snapshot for reproducibility and comparison.

    Records command output, artifacts, code, git/system context, and metrics.
    Data is uploaded to Supabase for later analysis.

    Examples:
        wafer capture baseline "python benchmark.py"
        wafer capture optimized "python benchmark.py" --variant v2
        wafer capture test-run "make && ./kernel" --tag cuda --tag fp16
        wafer capture batch-sizes "python train.py --batch-size {BATCH}" --sweep "BATCH=16,32,64,128"
    """
    _capture_setup_env()
    work_dir = working_dir.resolve() if working_dir else Path.cwd()
    config_code_denylist, config_artifact_denylist = _capture_load_denylists(work_dir)
    sweep_vars = _capture_parse_sweep(sweep)
    combinations, var_names = _capture_build_combinations(sweep_vars, label, json_output)
    effective_code_denylist = code_denylist or config_code_denylist
    effective_artifact_denylist = artifact_denylist or config_artifact_denylist

    from wafer.core.tools.capture_tool import CaptureConfig, capture, execute_command

    def progress(msg: str) -> None:
        if not json_output:
            typer.echo(f"  {msg}")

    async def run_capture_sweep() -> list[dict]:
        return await _capture_sweep_loop(
            combinations, var_names, sweep_vars, command, variant, label,
            work_dir, tags, effective_code_denylist, effective_artifact_denylist,
            json_output, CaptureConfig, capture, execute_command, progress,
        )

    trio.run(run_capture_sweep)


@tool_app.command("capture-list", rich_help_panel="Other")
def capture_list_command(
    label: str | None = typer.Option(None, "--label", "-l", help="Filter by label"),
    limit: int = typer.Option(100, "--limit", "-n", help="Maximum number of results"),
    offset: int = typer.Option(0, "--offset", "-o", help="Offset for pagination"),
    json_output: bool = typer.Option(False, "--json", "-j", help="Output as JSON"),
) -> None:
    """List captured executions.
    Query captures from the backend with optional filtering and pagination.
    Output can be formatted as a table (default) or JSON.
    Examples:
        # List all captures
        wafer capture-list
        wafer capture-list --label baseline
        wafer capture-list --json --limit 10
        # Pagination
        wafer capture-list --limit 20 --offset 20
    """
    import os

    from .auth import get_valid_token
    from .global_config import get_api_url

    os.environ["WAFER_API_URL"] = get_api_url()
    # Only set auth token if not explicitly provided in environment
    # This allows CI/service accounts to override with their own tokens
    if "WAFER_AUTH_TOKEN" not in os.environ:
        token = get_valid_token()
        if token:
            os.environ["WAFER_AUTH_TOKEN"] = token
    import trio

    from wafer.core.utils.backend import list_captures  # pragma: no cover

    async def run_list() -> None:
        try:
            captures = await list_captures(label=label, limit=limit, offset=offset)
            if json_output:
                from .output import json_response
                typer.echo(json_response(data={"captures": captures}))
            else:
                # Human-readable table output
                if not captures:
                    typer.echo("No captures found.")
                    return
                typer.echo(f"Found {len(captures)} captures:\n")
                # Print table header
                typer.echo(
                    f"{'ID':<36}  {'Label':<20}  {'Variant':<20}  {'Exit':<4}  {'Duration':<8}  {'Created'}"
                )
                typer.echo("-" * 120)
                # Print each capture
                for cap in captures:
                    cap_id = cap.get("id", "")[:36]
                    cap_label = cap.get("label", "")[:20]
                    cap_variant = (cap.get("variant") or "")[:20]
                    exit_code = cap.get("exit_code", "")
                    duration = f"{cap.get('duration_seconds', 0):.2f}s"
                    created = cap.get("created_at", "")[:19]  # Strip microseconds
                    typer.echo(
                        f"{cap_id:<36}  {cap_label:<20}  {cap_variant:<20}  {exit_code:<4}  {duration:<8}  {created}"
                    )
        except Exception as e:
            typer.echo(f"Error: Failed to list captures: {e}", err=True)
            raise typer.Exit(1) from None
    trio.run(run_list)


@tracelens_app.command("check")
def tracelens_check(
    json_output: bool = typer.Option(False, "--json", "-j", help="Output as JSON"),
) -> None:
    """Check if TraceLens is installed.
    Examples:
        wafer tracelens check
        wafer tracelens check --json
    """
    from .tracelens import check_command
    try:
        result = check_command(json_output)
        if json_output:
            typer.echo(result)
    except Exception as e:
        typer.echo(f"Error: {e}", err=True)
        raise typer.Exit(1) from None


@tracelens_app.command("report")
def tracelens_report(
    trace_path: str = typer.Argument(..., help="Path to trace file (.json, .zip, .gz, .pb)"),
    output: str | None = typer.Option(None, "--output", "-o", help="Output file path"),
    trace_format: str = typer.Option(
        "auto", "--format", "-f", help="Trace format: auto, pytorch, rocprof, jax"
    ),
    short_kernel: bool = typer.Option(
        False, "--short-kernel", help="Include short kernel analysis"
    ),
    kernel_details: bool = typer.Option(
        False, "--kernel-details", help="Include detailed kernel breakdown"
    ),
    json_output: bool = typer.Option(False, "--json", "-j", help="Output as JSON"),
) -> None:
    """Generate performance report from trace file.
    Generates an Excel report with hierarchical breakdowns, kernel statistics,
    and efficiency metrics (TFLOP/s, TB/s).
    Examples:
        wafer tracelens report trace.json
        wafer tracelens report trace.json --format pytorch --kernel-details
        wafer tracelens report rocprof_results.json --format rocprof -o analysis.xlsx
    """
    from .tracelens import report_command
    try:
        result = report_command(
            trace_path=trace_path,
            output_path=output,
            trace_format=trace_format,
            short_kernel=short_kernel,
            kernel_details=kernel_details,
            json_output=json_output,
        )
        if json_output:
            typer.echo(result)
    except RuntimeError:
        raise typer.Exit(1) from None


@tracelens_app.command("compare")
def tracelens_compare(
    baseline: str = typer.Argument(..., help="Path to baseline Excel report"),
    candidate: str = typer.Argument(..., help="Path to candidate Excel report"),
    output: str | None = typer.Option(None, "--output", "-o", help="Output comparison file"),
    baseline_name: str = typer.Option(
        "baseline", "--baseline-name", help="Display name for baseline"
    ),
    candidate_name: str = typer.Option(
        "candidate", "--candidate-name", help="Display name for candidate"
    ),
    json_output: bool = typer.Option(False, "--json", "-j", help="Output as JSON"),
) -> None:
    """Compare two performance reports.
    Quantifies differences between baseline and candidate reports.
    Useful for measuring optimization impact or regression detection.
    Examples:
        wafer tracelens compare baseline.xlsx candidate.xlsx
        wafer tracelens compare old.xlsx new.xlsx --baseline-name v1.0 --candidate-name v1.1
    """
    from .tracelens import compare_command
    try:
        result = compare_command(
            baseline_path=baseline,
            candidate_path=candidate,
            output_path=output,
            baseline_name=baseline_name,
            candidate_name=candidate_name,
            json_output=json_output,
        )
        if json_output:
            typer.echo(result)
    except RuntimeError:
        raise typer.Exit(1) from None


@tracelens_app.command("collective")
def tracelens_collective(
    trace_dir: str = typer.Argument(..., help="Directory containing trace files for all ranks"),
    world_size: int = typer.Option(..., "--world-size", "-w", help="Number of ranks (GPUs)"),
    output: str | None = typer.Option(None, "--output", "-o", help="Output file path"),
    json_output: bool = typer.Option(False, "--json", "-j", help="Output as JSON"),
) -> None:
    """Generate multi-rank collective performance report.
    Analyzes distributed training traces across multiple GPUs,
    providing communication analysis and scaling insights.
    Examples:
        wafer tracelens collective ./traces --world-size 8
        wafer tracelens collective ./multi_gpu_traces -w 4 -o collective_analysis.xlsx
    """
    from .tracelens import collective_command
    try:
        result = collective_command(
            trace_dir=trace_dir,
            world_size=world_size,
            output_path=output,
            json_output=json_output,
        )
        if json_output:
            typer.echo(result)
    except RuntimeError:
        raise typer.Exit(1) from None


@isa_app.command("analyze")
def isa_analyze(
    path: Path = typer.Argument(..., help="Path to file or directory to analyze"),
    json_output: bool = typer.Option(False, "--json", "-j", help="Output as JSON"),
    csv_output: bool = typer.Option(False, "--csv", help="Output as CSV"),
    recursive: bool = typer.Option(
        True, "--recursive/--no-recursive", "-r", help="Scan directories recursively"
    ),
    filter_expr: str | None = typer.Option(
        None, "--filter", "-f", help="Filter results (e.g., 'spills > 0')"
    ),
    output_file: Path | None = typer.Option(None, "--output", "-o", help="Write output to file"),
    kernel_index: int = typer.Option(0, "--kernel", "-k", help="Kernel index if multiple in file"),
) -> None:
    """Analyze AMD GPU ISA files (.co, .s, .ll, .ttgir).
    Performs static analysis to extract performance metrics like register
    pressure, spills, MFMA density, and occupancy limits.
    Supports:
      - AMD GPU code objects (.co) - Requires API authentication
      - AMDGCN ISA assembly (.s, .gcn, .asm) - Local parsing
      - LLVM-IR files (.ll) - Local parsing
      - TTGIR files (.ttgir, .ttir, .mlir) - Local parsing
    Examples:
        wafer tool isa analyze kernel.co              # Code object (needs login)
        wafer tool isa analyze kernel.s               # ISA assembly
        wafer tool isa analyze kernel.s --json        # Output as JSON
        wafer tool isa analyze ~/.triton/cache/ --filter 'spills > 0'
        wafer tool isa analyze . -r --csv -o metrics.csv
    """
    from .auth import get_auth_headers
    from .global_config import get_api_url
    from .kernel_scope import analyze_command
    api_url = get_api_url()
    auth_headers = get_auth_headers()
    try:
        output = analyze_command(
            path=str(path),
            json_output=json_output,
            csv_output=csv_output,
            recursive=recursive,
            filter_expr=filter_expr,
            output_file=str(output_file) if output_file else None,
            kernel_index=kernel_index,
            api_url=api_url,
            auth_headers=auth_headers,
        )
        typer.echo(output)
    except FileNotFoundError as e:
        typer.echo(f"Error: {e}", err=True)
        raise typer.Exit(1) from None
    except RuntimeError as e:
        typer.echo(f"Error: {e}", err=True)
        raise typer.Exit(1) from None
    except Exception as e:
        typer.echo(f"Error: {e}", err=True)
        raise typer.Exit(1) from None


@isa_app.command("metrics")
def isa_metrics() -> None:
    """List available metrics for ISA analysis.
    Shows all metrics that can be extracted from AMD GPU ISA files,
    along with their derivation.
    Examples:
        wafer tool isa metrics
    """
    from .kernel_scope import metrics_command
    output = metrics_command()
    typer.echo(output)


@isa_app.command("targets")
def isa_targets() -> None:
    """List supported GPU targets and their specifications.
    Shows hardware specs (VGPRs, SGPRs, LDS, etc.) for each supported
    AMD GPU architecture.
    Examples:
        wafer tool isa targets
    """
    from .kernel_scope import targets_command
    output = targets_command()
    typer.echo(output)


@compare_app.command("analyze")
def compare_analyze(
    trace1: Path = typer.Argument(..., help="First trace file (AMD or NVIDIA)", exists=True),
    trace2: Path = typer.Argument(..., help="Second trace file (AMD or NVIDIA)", exists=True),
    output: Path | None = typer.Option(None, "--output", "-o", help="Output file (default: stdout)"),
    format: str = typer.Option(
        "text",
        "--format",
        "-f",
        help="Output format: text, json",
    ),
    phase: str = typer.Option(
        "all",
        "--phase",
        help="Filter by phase: all, prefill, or decode",
    ),
    all: bool = typer.Option(False, "--all", help="Show all items without truncation"),
    stack_traces: bool = typer.Option(False, "--stack-traces", help="Show Python stack traces for operations"),
    grouped: bool = typer.Option(False, "--grouped", help="Group kernels by operation type (default: position order)"),
    max_graphs: int = typer.Option(1, "--max-graphs", help="Maximum number of CUDA graph patterns to show (default: 1)"),
    fusion: bool = typer.Option(False, "--fusion", help="Also show fusion analysis (kernel fusion differences)"),
    min_group_size: int = typer.Option(300, "--min-group-size", help="Minimum correlation group size for fusion analysis (default: 300)"),
    json: bool = typer.Option(False, "--json", hidden=True, help="Ignored (for compatibility with cliExecutor)"),
) -> None:
    """Compare GPU traces and generate performance report.
    Uses fused analyzer for ~50% faster performance - loads traces once and computes
    operation stats, graph matching, and fusion analysis in a single pass.
    Shows operation-level performance comparison with stack traces and kernel-to-kernel matching details.
    Examples:
        # Basic comparison (stdout) - shows 1:1 kernel matching
        wafer compare analyze amd_trace.json nvidia_trace.json
        # Include fusion analysis
        wafer compare analyze amd_trace.json nvidia_trace.json --fusion
        wafer compare analyze amd_trace.json nvidia_trace.json --grouped
        # Show all operations without truncation
        wafer compare analyze amd_trace.json nvidia_trace.json --all
        # Show Python stack traces
        wafer compare analyze amd_trace.json nvidia_trace.json --stack-traces
        wafer compare analyze amd_trace.json nvidia_trace.json --phase decode
        # Save to file
        wafer compare analyze amd_trace.json nvidia_trace.json -o report.txt
        # JSON output
        wafer compare analyze amd_trace.json nvidia_trace.json --format json -o report.json
    """
    from .trace_compare import compare_traces
    compare_traces(
        trace1=trace1,
        trace2=trace2,
        output=output,
        output_format=format,
        phase=phase,
        show_all=all,
        show_stack_traces=stack_traces,
        grouped=grouped,
        max_graphs=max_graphs,
        show_fusion=fusion,
        min_group_size=min_group_size,
    )
    _mark_command_success()


@compare_app.command("fusion")
def compare_fusion_cmd(
    trace1: Path = typer.Argument(..., help="First trace file (AMD or NVIDIA)", exists=True),
    trace2: Path = typer.Argument(..., help="Second trace file (AMD or NVIDIA)", exists=True),
    format: str = typer.Option(
        "text",
        "--format",
        "-f",
        help="Output format: text, json",
    ),
    output: Path | None = typer.Option(None, "--output", "-o", help="Output file (default: stdout)"),
    min_group_size: int = typer.Option(
        300,
        "--min-group-size",
        help="Minimum correlation group size to analyze (default: 300 for transformer layers)",
    ),
    legacy: bool = typer.Option(
        False,
        "--legacy",
        help="Use legacy signature-based matching instead of graph-based matching",
    ),
    json: bool = typer.Option(False, "--json", hidden=True, help="Ignored (for compatibility with cliExecutor)"),
) -> None:
    """Analyze kernel fusion differences using graph-based matching.
    Uses graph-based kernel matching to detect fusion differences between platforms.
    More accurate than legacy signature-based matching (use --legacy for old behavior).
    Examples:
        # Basic fusion analysis (stdout)
        wafer compare fusion amd_trace.json nvidia_trace.json
        # Save to file
        wafer compare fusion amd_trace.json nvidia_trace.json -o fusion_report.txt
        # JSON output to file
        wafer compare fusion amd_trace.json nvidia_trace.json --format json -o fusion.json
        wafer compare fusion amd_trace.json nvidia_trace.json --legacy
    """
    from .trace_compare import compare_fusion
    compare_fusion(
        trace1=trace1,
        trace2=trace2,
        output=output,
        format_type=format,
        min_group_size=min_group_size,
        use_graph_matching=not legacy,
    )
    _mark_command_success()


def main() -> None:
    """Entry point for wafer CLI."""
    global _command_outcome, _command_failure_details

    try:
        app()
    except SystemExit as exc:
        exit_code = exc.code if hasattr(exc, "code") else 1
        if exit_code not in (0, None):
            _command_outcome = "failure"
            if _command_failure_details is None:
                _command_failure_details = {
                    "error_type": "SystemExit",
                    "error_message": str(exc),
                }
                if isinstance(exit_code, int):
                    _command_failure_details["exit_code"] = exit_code
        raise
    except Exception as exc:
        _command_outcome = "failure"
        if _command_failure_details is None:
            _command_failure_details = {
                "error_type": type(exc).__name__,
                "error_message": str(exc),
                "exit_code": 1,
            }
        raise


if __name__ == "__main__":
    main()
