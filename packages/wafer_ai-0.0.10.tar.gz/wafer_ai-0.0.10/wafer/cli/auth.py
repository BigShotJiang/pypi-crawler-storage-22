"""CLI authentication and credential management.
Handles storing/loading credentials from ~/.wafer/credentials.json
and verifying tokens against the wafer-api.
Supports automatic token refresh using Supabase refresh tokens.
Token validity is checked locally via JWT exp claim — no network
round-trip on the hot path.
"""
import base64
import json
import logging
import socket
import sys
import time
import webbrowser
from dataclasses import dataclass
from http.server import BaseHTTPRequestHandler, HTTPServer
from pathlib import Path
from urllib.parse import parse_qs, urlparse

import httpx

from .global_config import get_api_url, get_supabase_url

logger = logging.getLogger(__name__)


def _safe_symbol(unicode_sym: str, ascii_fallback: str) -> str:
    """Return unicode symbol if terminal supports it, otherwise ASCII fallback."""
    if not sys.stdout.isatty():
        return ascii_fallback
    try:
        encoding = sys.stdout.encoding or "ascii"
        unicode_sym.encode(encoding)
        return unicode_sym
    except (UnicodeEncodeError, LookupError):
        return ascii_fallback


# Safe symbols for terminal output
CHECK = _safe_symbol("✓", "[OK]")
CROSS = _safe_symbol("✗", "[FAIL]")
CREDENTIALS_DIR = Path.home() / ".wafer"
CREDENTIALS_FILE = CREDENTIALS_DIR / "credentials.json"


@dataclass
class Credentials:
    """Stored credentials."""
    access_token: str
    refresh_token: str | None = None
    email: str | None = None
    provider_token: str | None = None  # GitHub OAuth token from Supabase


@dataclass
class UserInfo:
    """User info from token verification."""
    user_id: str
    email: str | None


# Tokens within this many seconds of expiry are treated as expired,
# giving enough margin for the real API call to complete.
_EXPIRY_MARGIN_SECONDS = 30


def _token_expired(token: str) -> bool:
    """Check if a JWT token has expired by decoding the exp claim locally.
    This avoids a network round-trip on every CLI command. We don't verify
    the signature — the server will do that when we actually use the token.
    We only stored this token ourselves, so we trust its structure.
    Returns True if the token is expired or unparseable (fail closed on
    the "is it still valid?" question).
    """
    try:
        payload_b64 = token.split(".")[1]
        # JWT base64url uses - and _ instead of + and /; pad to multiple of 4
        padded = payload_b64 + "=" * (-len(payload_b64) % 4)
        payload = json.loads(base64.urlsafe_b64decode(padded))
        exp = payload["exp"]
        remaining = exp - time.time()
        if remaining <= _EXPIRY_MARGIN_SECONDS:
            logger.debug("token expired (%.0fs past expiry)", -remaining)
            return True
        logger.debug("token valid (%.0fs remaining)", remaining)
        return False
    except Exception as exc:
        logger.warning("could not decode token exp claim: %s", exc)
        return True


def save_credentials(
    access_token: str,
    refresh_token: str | None = None,
    email: str | None = None,
    provider_token: str | None = None,
) -> None:
    """Save credentials to ~/.wafer/credentials.json.

    Merges with existing credentials so that fields not explicitly passed
    (e.g. provider_token during a token refresh) are preserved.
    """
    CREDENTIALS_DIR.mkdir(parents=True, exist_ok=True)
    # Load existing data to preserve fields not being updated
    existing: dict = {}
    if CREDENTIALS_FILE.exists():
        try:
            existing = json.loads(CREDENTIALS_FILE.read_text())
        except (json.JSONDecodeError, OSError):
            pass
    existing["access_token"] = access_token
    if refresh_token is not None:
        existing["refresh_token"] = refresh_token
    if email is not None:
        existing["email"] = email
    if provider_token is not None:
        existing["provider_token"] = provider_token
    CREDENTIALS_FILE.write_text(json.dumps(existing, indent=2))

    CREDENTIALS_FILE.chmod(0o600)


def load_credentials() -> Credentials | None:
    """Load credentials from ~/.wafer/credentials.json.
    Returns None if file doesn't exist or is invalid.
    """
    if not CREDENTIALS_FILE.exists():
        return None
    try:
        data = json.loads(CREDENTIALS_FILE.read_text())
        return Credentials(
            access_token=data["access_token"],
            refresh_token=data.get("refresh_token"),
            email=data.get("email"),
            provider_token=data.get("provider_token"),
        )
    except (json.JSONDecodeError, KeyError):
        return None


def clear_credentials() -> bool:
    """Remove credentials file.
    Returns True if file was removed, False if it didn't exist.
    """
    if CREDENTIALS_FILE.exists():
        CREDENTIALS_FILE.unlink()
        return True
    return False


def get_auth_headers() -> dict[str, str]:
    """Get Authorization headers with a valid token.
    Automatically refreshes expired tokens if a refresh token is available.
    Returns empty dict if not logged in or refresh fails.
    """
    token = get_valid_token()
    if token:
        return {"Authorization": f"Bearer {token}"}
    return {}


def verify_token(token: str) -> UserInfo:
    """Verify token with wafer-api and return user info.
    Raises:
        httpx.HTTPStatusError: If token is invalid (401) or other HTTP error
        httpx.RequestError: If API is unreachable
    """
    api_url = get_api_url()
    with httpx.Client(timeout=10.0) as client:
        response = client.post(
            f"{api_url}/v1/auth/verify",
            json={"token": token},
        )
        response.raise_for_status()
        data = response.json()
        return UserInfo(
            user_id=data["user_id"],
            email=data.get("email"),
        )


def refresh_access_token(refresh_token: str) -> tuple[str, str]:
    """Use refresh token to get a new access token from Supabase.
    Args:
        refresh_token: The refresh token from previous auth
    Returns:
        Tuple of (new_access_token, new_refresh_token)
    Raises:
        httpx.HTTPStatusError: If refresh fails (e.g., refresh token expired)
        httpx.RequestError: If Supabase is unreachable
    """
    from .global_config import get_supabase_anon_key
    supabase_url = get_supabase_url()
    anon_key = get_supabase_anon_key()
    with httpx.Client(timeout=10.0) as client:
        response = client.post(
            f"{supabase_url}/auth/v1/token?grant_type=refresh_token",
            json={"refresh_token": refresh_token},
            headers={
                "Content-Type": "application/json",
                "apikey": anon_key,
            },
        )
        response.raise_for_status()
        data = response.json()
        return data["access_token"], data["refresh_token"]


def get_valid_token() -> str | None:
    """Get a valid access token, refreshing if necessary.
    Checks the token's exp claim locally (no network call). If the token
    is expired and we have a refresh token, attempts to refresh via Supabase.
    Returns:
        Valid access token, or None if not logged in or refresh failed
    """
    creds = load_credentials()
    if not creds:
        logger.debug("no credentials file found")
        return None
    if not _token_expired(creds.access_token):
        return creds.access_token
    # Token expired — try refresh
    if not creds.refresh_token:
        logger.warning("token expired and no refresh token available")
        return None
    try:
        new_access, new_refresh = refresh_access_token(creds.refresh_token)
        save_credentials(new_access, new_refresh, creds.email)
        logger.debug("token refreshed successfully")
        return new_access
    except httpx.HTTPStatusError as e:
        logger.warning("token refresh failed: HTTP %d", e.response.status_code)
        return None
    except httpx.RequestError as e:
        logger.warning("token refresh failed (network): %s", e)
        return None


def _find_free_port() -> int:
    """Find a free port for the callback server."""
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.bind(("", 0))
        return s.getsockname()[1]


class OAuthCallbackHandler(BaseHTTPRequestHandler):
    """HTTP handler that catches the OAuth callback with access token."""
    access_token: str | None = None
    refresh_token: str | None = None
    provider_token: str | None = None
    error: str | None = None

    def log_message(self, format: str, *args: object) -> None:  # noqa: A002
        """Suppress default logging."""
        pass

    def do_GET(self) -> None:
        """Handle GET request - catch the callback or serve the HTML page."""
        parsed = urlparse(self.path)
        if parsed.path == "/callback":
            # This is the redirect from Supabase with hash fragment
            # But hash fragments aren't sent to server, so serve a page that extracts it
            html = """<!DOCTYPE html>
<html>
<head><meta charset="UTF-8"><title>Wafer CLI Login</title></head>
<body>
<h2>Completing login...</h2>
<script>
// Extract tokens from hash fragment
const hash = window.location.hash.substring(1);
const params = new URLSearchParams(hash);
const accessToken = params.get('access_token');
const refreshToken = params.get('refresh_token');
const providerToken = params.get('provider_token');
const error = params.get('error_description') || params.get('error');
if (accessToken) {
    // Send all tokens to our local server
    let url = '/token?access_token=' + encodeURIComponent(accessToken);
    if (refreshToken) {
        url += '&refresh_token=' + encodeURIComponent(refreshToken);
    }
    if (providerToken) {
        url += '&provider_token=' + encodeURIComponent(providerToken);
    }
    fetch(url)
        .then(() => {
            document.body.innerHTML = '<h2>✓ Login successful!</h2><p>You can close this window.</p>';
        });
} else if (error) {
    fetch('/token?error=' + encodeURIComponent(error));
    document.body.innerHTML = '<h2>✗ Login failed</h2><p>' + error + '</p>';
} else {
    document.body.innerHTML = '<h2>✗ No token received</h2>';
}
</script>
</body>
</html>"""
            self.send_response(200)
            self.send_header("Content-Type", "text/html; charset=utf-8")
            self.end_headers()
            self.wfile.write(html.encode())
        elif parsed.path == "/token":
            # JavaScript sends us the tokens
            params = parse_qs(parsed.query)
            if "access_token" in params:
                OAuthCallbackHandler.access_token = params["access_token"][0]
                if "refresh_token" in params:
                    OAuthCallbackHandler.refresh_token = params["refresh_token"][0]
                if "provider_token" in params:
                    OAuthCallbackHandler.provider_token = params["provider_token"][0]
            elif "error" in params:
                OAuthCallbackHandler.error = params["error"][0]
            self.send_response(200)
            self.send_header("Content-Type", "text/plain")
            self.end_headers()
            self.wfile.write(b"OK")
        else:
            self.send_response(404)
            self.end_headers()


def browser_login(timeout: int = 120, port: int | None = None) -> tuple[str, str | None, str | None]:
    """Open browser for GitHub OAuth and return tokens.
    Starts a local HTTP server, opens browser to Supabase OAuth,
    and waits for the callback with the tokens.
    Args:
        timeout: Seconds to wait for callback (default 120)
        port: Port for callback server. If None, finds a free port (default None)
    Returns:
        Tuple of (access_token, refresh_token, provider_token).
        refresh_token and provider_token may be None.
    Raises:
        TimeoutError: If no callback received within timeout
        RuntimeError: If OAuth flow failed
    """
    if port is None:
        port = _find_free_port()
    redirect_uri = f"http://localhost:{port}/callback"
    supabase_url = get_supabase_url()
    auth_url = f"{supabase_url}/auth/v1/authorize?provider=github&redirect_to={redirect_uri}"
    # Reset state
    OAuthCallbackHandler.access_token = None
    OAuthCallbackHandler.refresh_token = None
    OAuthCallbackHandler.provider_token = None
    OAuthCallbackHandler.error = None
    # Start local server
    server = HTTPServer(("localhost", port), OAuthCallbackHandler)
    server.timeout = 1  # Check for token every second
    # Open browser
    print("Opening browser for GitHub authentication...")
    print(f"If browser doesn't open, visit: {auth_url}")
    webbrowser.open(auth_url)
    # Wait for callback
    start = time.time()
    print("Waiting for authentication...", end="", flush=True)
    while time.time() - start < timeout:
        server.handle_request()
        if OAuthCallbackHandler.access_token:
            print(f" {CHECK}")
            server.server_close()
            return OAuthCallbackHandler.access_token, OAuthCallbackHandler.refresh_token, OAuthCallbackHandler.provider_token
        if OAuthCallbackHandler.error:
            print(f" {CROSS}")
            server.server_close()
            raise RuntimeError(f"OAuth failed: {OAuthCallbackHandler.error}")
    server.server_close()
    raise TimeoutError(f"No response within {timeout} seconds")


def device_code_login(timeout: int = 600) -> tuple[str, str | None, str | None]:
    """Authenticate using state-based flow (no browser/port forwarding needed).
    This is the SSH-friendly auth flow similar to GitHub CLI:
    1. Request a state token from the API
    2. Display the auth URL with state parameter
    3. User visits URL on any device and signs in normally
    4. Poll API until user completes authentication
    Args:
        timeout: Seconds to wait for authentication (default 600 = 10 minutes)
    Returns:
        Tuple of (access_token, refresh_token, provider_token).
        refresh_token and provider_token may be None.
    Raises:
        TimeoutError: If user doesn't authenticate within timeout
        RuntimeError: If auth flow failed
    """
    api_url = get_api_url()
    # Request state and auth URL
    with httpx.Client(timeout=10.0) as client:
        response = client.post(f"{api_url}/v1/auth/cli-auth/start", json={})
        response.raise_for_status()
        data = response.json()
    state = data["state"]
    auth_url = data["auth_url"]
    expires_in = data["expires_in"]
    # Display instructions to user
    print("\n" + "=" * 60)
    print("  WAFER CLI - Authentication")
    print("=" * 60)
    print(f"\n  Visit: {auth_url}")
    print("\n  Sign in with GitHub to complete authentication")
    print("\n" + "=" * 60 + "\n")
    # Poll for authentication
    start = time.time()
    poll_interval = 5  # Poll every 5 seconds
    last_poll = 0.0
    print("Waiting for authentication", end="", flush=True)
    while time.time() - start < min(timeout, expires_in):
        # Show progress dots
        if time.time() - last_poll >= poll_interval:
            print(".", end="", flush=True)
            # Poll the API
            with httpx.Client(timeout=10.0) as client:
                try:
                    response = client.post(
                        f"{api_url}/v1/auth/cli-auth/token", json={"state": state}
                    )
                    if response.status_code == 200:
                        # Success!
                        data = response.json()
                        print(f" {CHECK}\n")
                        return data["access_token"], data.get("refresh_token"), data.get("provider_token")
                    if response.status_code == 428:
                        # Still waiting
                        last_poll = time.time()
                        time.sleep(1)
                        continue
                    # Some other error
                    print(f" {CROSS}\n")
                    raise RuntimeError(
                        f"CLI auth flow failed: {response.status_code} {response.text}"
                    )
                except httpx.RequestError:
                    # Network error, retry
                    print("!", end="", flush=True)
                    last_poll = time.time()
                    time.sleep(1)
                    continue
        time.sleep(0.5)  # Small sleep to avoid busy loop
    print(f" {CROSS}\n")
    raise TimeoutError(f"Authentication not completed within {expires_in} seconds")
