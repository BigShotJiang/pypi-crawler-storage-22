"""Cloud Agent CLI — run a coding agent on a repo and create a PR.

Entry point: main() is called from app.py's `cloud-agent` command.
Follows the same pattern as wevin_cli.py for auth/endpoint setup.
"""
from __future__ import annotations

import json
import sys
import time
from pathlib import Path

import trio
from rich.console import Console, Group
from rich.live import Live
from rich.panel import Panel
from rich.text import Text


# ── Pipeline steps (fixed, known upfront) ─────────────────────────────────
_STEPS = [
    "Validate repository",
    "Create branch",
    "Run coding agent",
    "Commit changes",
    "Push branch",
    "Create pull request",
]


class CloudAgentDisplay:
    """Rich-based live display for cloud agent progress."""

    def __init__(self, prompt: str, repo_path: str) -> None:
        self.prompt = prompt
        self.repo_path = repo_path
        self.console = Console(stderr=True)

        # Step tracking: None=pending, "active", "done", "error"
        self.step_states: list[str | None] = [None] * len(_STEPS)
        self.step_details: list[str] = [""] * len(_STEPS)
        self.agent_lines: list[tuple[str, str]] = []
        self.start_time = time.monotonic()
        self._finished = False
        self._result_text: Text | None = None

        self._live: Live | None = None

    def _build_steps(self) -> Text:
        """Build the step list with status indicators."""
        lines = Text()
        for i, label in enumerate(_STEPS):
            state = self.step_states[i]
            if state == "done":
                indicator = Text("  \u2713 ", style="green")
                step_text = Text(label, style="dim")
            elif state == "active":
                indicator = Text("  \u25cf ", style="cyan")
                step_text = Text(label, style="bold")
            elif state == "error":
                indicator = Text("  \u2717 ", style="red")
                step_text = Text(label, style="red")
            else:
                indicator = Text("  \u00b7 ", style="dim")
                step_text = Text(label, style="dim")

            lines.append_text(indicator)
            lines.append_text(step_text)

            # Show detail for done/active steps
            detail = self.step_details[i]
            if detail and state in ("done", "active"):
                lines.append(f"  {detail}", style="dim")

            lines.append("\n")

        # Show agent activity log when agent step is active or done
        if self.step_states[2] in ("active", "done") and self.agent_lines:
            lines.append("\n")
            for style, text in self.agent_lines:
                lines.append(f"    {text}\n", style=style)

        return lines

    def _build_display(self) -> Group:
        """Build the full display."""
        elapsed = time.monotonic() - self.start_time
        elapsed_str = f"{elapsed:.0f}s"

        header = Text()
        header.append("  ", style="bold cyan")
        header.append(self.prompt, style="bold")
        header.append(f"\n  {self.repo_path}", style="dim")
        header.append(f"  ({elapsed_str})", style="dim")

        steps = self._build_steps()

        # Choose panel style based on finished state
        if self._finished:
            has_error = any(s == "error" for s in self.step_states)
            border_style = "red" if has_error else "green"
            title_style = "bold red" if has_error else "bold green"
            title = f"[{title_style}]cloud-agent[/{title_style}]"
        else:
            border_style = "cyan"
            title = "[bold]cloud-agent[/bold]"

        parts: list = [header, Text(), steps]

        # Show result info at the bottom when finished
        if self._finished and self._result_text:
            parts.append(Text())
            parts.append(self._result_text)

        return Group(
            Text(),  # blank line
            Panel(
                Group(*parts),
                title=title,
                border_style=border_style,
                expand=False,
                width=min(self.console.width, 80),
            ),
        )

    def start(self) -> None:
        """Start the live display."""
        self._live = Live(
            self._build_display(),
            console=self.console,
            refresh_per_second=4,
            transient=False,  # Keep all output in terminal after finish
        )
        self._live.start()

    def stop(self) -> None:
        """Stop the live display."""
        if self._live:
            self._live.stop()
            self._live = None

    def _refresh(self) -> None:
        """Refresh the live display."""
        if self._live:
            self._live.update(self._build_display())

    def _activate_step(self, index: int, detail: str = "") -> None:
        """Mark a step as active."""
        self.step_states[index] = "active"
        if detail:
            self.step_details[index] = detail
        self._refresh()

    def _complete_step(self, index: int, detail: str = "") -> None:
        """Mark a step as done."""
        self.step_states[index] = "done"
        if detail:
            self.step_details[index] = detail
        self._refresh()

    def _error_step(self, index: int, detail: str = "") -> None:
        """Mark a step as errored."""
        self.step_states[index] = "error"
        if detail:
            self.step_details[index] = detail
        self._refresh()

    def add_agent_line(self, text: str, style: str = "dim") -> None:
        """Add a line to the agent activity log."""
        self.agent_lines.append((style, text))
        self._refresh()

    def on_event(self, event_type: str, message: str) -> None:
        """Handle a cloud agent event, updating the display."""
        msg = message.lower()

        if event_type == "status":
            if "validating" in msg:
                self._activate_step(0)
            elif "repository validated" in msg:
                self._complete_step(0)
            elif "creating branch" in msg:
                self._activate_step(1, message.split("Creating branch ")[-1].rstrip("..."))
            elif "starting coding agent" in msg:
                self._activate_step(2)
            elif "agent completed" in msg:
                self._complete_step(2)
            elif "committing" in msg:
                self._activate_step(3)
            elif "pushing" in msg:
                self._activate_step(4)
            elif "creating pull request" in msg:
                self._activate_step(5)
        elif event_type == "git_progress":
            if "created branch" in msg:
                detail = message.split("Created branch ")[-1]
                self._complete_step(1, detail)
            elif "committed" in msg:
                detail = message.split("Committed: ")[-1]
                self._complete_step(3, detail)
            elif "pushed" in msg:
                self._complete_step(4)
        elif event_type == "agent_event":
            self.add_agent_line(message)
        elif event_type == "pr_created":
            self._complete_step(5)
        elif event_type == "error":
            # Mark the currently active step as errored
            for i, state in enumerate(self.step_states):
                if state == "active":
                    self._error_step(i, message)
                    break

    def show_result(
        self,
        pr_url: str | None,
        branch_name: str,
        error: str | None,
        local_path: str | None = None,
    ) -> None:
        """Update the live display with final result, then stop."""
        self._finished = True
        result = Text()

        if pr_url:
            result.append("  PR created: ", style="bold green")
            result.append(pr_url, style="underline cyan")
            result.append(f"\n  Branch: {branch_name}", style="dim")
        elif error:
            result.append(f"  {error}", style="red")
            if branch_name:
                result.append(f"\n  Branch: {branch_name}", style="dim")
            if local_path:
                result.append(f"\n  Changes preserved at: ", style="yellow")
                result.append(local_path, style="bold yellow")
        elif branch_name:
            result.append(f"  Branch: {branch_name}", style="bold green")

        self._result_text = result
        self._refresh()
        self.stop()


class CloudAgentFrontend:
    """Frontend that routes agent stream events to CloudAgentDisplay.

    Replaces NoneFrontend to prevent raw output from leaking to the terminal.
    Instead, tool calls and text are shown as compact lines in the TUI panel.
    """

    def __init__(self, display: CloudAgentDisplay) -> None:
        self.display = display
        self._current_text = ""

    async def start(self) -> None:
        pass

    async def stop(self) -> None:
        # Flush any remaining text
        if self._current_text:
            preview = self._current_text.strip().replace("\n", " ")[:80]
            if preview:
                self.display.add_agent_line(preview, style="dim italic")
            self._current_text = ""

    def _format_compact_header(self, tool_name: str, args: dict) -> str:
        """Format tool call as compact one-liner."""
        if not args:
            return f"{tool_name}()"
        key, value = next(iter(args.items()))
        if isinstance(value, str):
            value = value.replace("\n", " ").replace("\r", "")
            display = value[:40] + "..." if len(value) > 40 else value
            display = repr(display)
        else:
            display = repr(value)
            if len(display) > 40:
                display = display[:40] + "..."
        if len(args) > 1:
            return f"{tool_name}({key}={display}, ...)"
        return f"{tool_name}({key}={display})"

    async def handle_event(self, event: object) -> None:
        """Route stream events to the display."""
        from wafer.core.rollouts.dtypes import (
            TextDelta,
            ToolCallEnd,
            ToolResultReceived,
        )

        if isinstance(event, ToolCallEnd):
            header = self._format_compact_header(event.tool_call.name, dict(event.tool_call.args))
            self.display.add_agent_line(f"  {header}", style="dim")
            # Flush any buffered text before tool call
            self._current_text = ""
        elif isinstance(event, ToolResultReceived):
            if event.is_error:
                content = event.content if isinstance(event.content, str) else str(event.content)
                preview = content[:60] + "..." if len(content) > 60 else content
                self.display.add_agent_line(f"  Error: {preview}", style="red")
        elif isinstance(event, TextDelta):
            self._current_text += event.delta
            # Show text in chunks — flush on sentence boundaries
            if any(self._current_text.rstrip().endswith(c) for c in (".", "!", "?", "\n")):
                for line in self._current_text.strip().split("\n"):
                    line = line.strip()
                    if line:
                        self.display.add_agent_line(line, style="dim italic")
                self._current_text = ""

    async def get_input(self, prompt: str = "") -> str:
        """Cloud agent is non-interactive — should not be called."""
        return ""

    async def confirm_tool(self, tool_call: object) -> bool:
        """Auto-approve all tool calls in cloud agent mode."""
        return True

    def show_loader(self, text: str) -> None:
        pass

    def hide_loader(self) -> None:
        pass


def main(  # noqa: PLR0913
    prompt: str,
    repo: str = ".",
    branch: str | None = None,
    base_branch: str | None = None,
    model: str | None = None,
    max_turns: int = 50,
    json_output: bool = False,
    no_proxy: bool = False,
    no_sandbox: bool = False,
    no_pr: bool = False,
) -> None:
    """Run cloud agent in-process.

    Resolves auth, builds endpoint, runs the cloud agent, streams progress.
    """
    from wafer.cli.wevin_cli import _get_wafer_auth, _setup_wafer_env_vars
    from wafer.core.rollouts import Endpoint
    from wafer.core.tools.cloud_agent_tool import (
        CloudAgentConfig,
        CloudAgentEvent,
        run_cloud_agent,
    )

    # ── Auth ──────────────────────────────────────────────────────────────
    api_base, api_key, api_key_refresh = _get_wafer_auth(no_proxy=no_proxy)
    if not api_base or not api_key:
        sys.exit(1)
    _setup_wafer_env_vars(no_proxy)

    # ── Endpoint ──────────────────────────────────────────────────────────
    resolved_model = model or "claude-sonnet-4-5-20250929"
    provider, model_id = "anthropic", resolved_model
    if "/" in resolved_model:
        provider, model_id = resolved_model.split("/", 1)

    endpoint = Endpoint(
        provider=provider,
        model=model_id,
        api_base=api_base,
        api_key=api_key,
        api_key_refresh=api_key_refresh,
        thinking={"type": "enabled", "budget_tokens": 10000},
        max_tokens=16384,
    )

    # ── Config ────────────────────────────────────────────────────────────
    from wafer.core.tools.cloud_agent_tool.git_ops import is_remote_url

    repo_path = repo if is_remote_url(repo) else str(Path(repo).resolve())
    config = CloudAgentConfig(
        repo_path=repo_path,
        prompt=prompt,
        branch_name=branch,
        base_branch=base_branch,
        max_turns=max_turns,
        model=model,
        no_sandbox=no_sandbox,
        no_pr=no_pr,
    )

    # ── Display / event handler ───────────────────────────────────────────
    display: CloudAgentDisplay | None = None
    agent_frontend: CloudAgentFrontend | None = None
    if not json_output:
        display = CloudAgentDisplay(prompt, repo_path)
        agent_frontend = CloudAgentFrontend(display)

    async def on_event(event: CloudAgentEvent) -> None:
        if json_output:
            print(event.to_json(), flush=True)
        elif display:
            display.on_event(event.type, event.message)

    # ── Run ───────────────────────────────────────────────────────────────
    async def run() -> None:
        if json_output:
            print(json.dumps({"type": "status", "message": "Starting cloud agent..."}), flush=True)

        if display:
            display.start()

        try:
            result = await run_cloud_agent(
                config, endpoint, on_event, frontend=agent_frontend,
            )
        except BaseException:
            if display:
                display.stop()
            raise

        if json_output:
            print(
                json.dumps({
                    "type": "done",
                    "pr_url": result.pr_url,
                    "branch_name": result.branch_name,
                    "error": result.error,
                    "session_id": result.session_id,
                    "local_path": result.local_path,
                }),
                flush=True,
            )
        elif display:
            display.show_result(
                result.pr_url, result.branch_name, result.error, result.local_path,
            )

        if result.error and not result.pr_url:
            sys.exit(1)

    try:
        trio.run(run)
    except KeyboardInterrupt:
        if display:
            display.stop()
        Console(stderr=True).print("\n  Aborted.", style="yellow")
        sys.exit(1)
    except SystemExit:
        raise
    except Exception as e:
        if display:
            display.stop()
        Console(stderr=True).print(f"\n  Fatal error: {e}", style="bold red")
        sys.exit(1)
