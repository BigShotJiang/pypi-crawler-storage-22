---
name: wafer-guide
description: Accelerator kernel development with the Wafer CLI. Supports NVIDIA, AMD, Trainium, TPU. Use for CUDA/HIP kernels, profiling, or optimizing kernel performance.
---
<!-- AUTO-GENERATED FILE — DO NOT EDIT DIRECTLY.
     Regenerate with: just generate-skill
     Source template: SKILL.md.template -->

# Wafer CLI — Quick Reference

Accelerator development primitives for optimizing CUDA and HIP kernels. Supports NVIDIA, AMD, Trainium, TPU, and other accelerators for target configuration and execution.

## Installation

```bash
uv tool install wafer-ai

# Authenticate (one-time setup)
wafer settings login

# Register SSH keys (required before using workspaces)
wafer settings ssh-keys add
```

## Core Commands

- `wafer tool eval --task <name>` — test kernel correctness + benchmark speedup
- `wafer tool roofline` — roofline analysis (compute vs memory bound)
- `wafer tool ncu` / `wafer tool nsys` — NVIDIA profiling (NCU, NSYS)
- `wafer tool rocprof-compute` / `rocprof-sdk` / `rocprof-systems` — AMD profiling
- `wafer target init workspace` / `wafer target run` / `wafer target sync` — cloud GPU workspaces
- `wafer agent -t ask-docs` — GPU docs lookup (uses ask_docs tool via wafer API)
- `wafer target init` — configure GPU targets

## Detailed Guides

Load these with the `read` tool from the sub-guides directory below:
- `evaluate.md` — evaluation workflows, workspace+evaluate integration, target config
- `profiling.md` — trace analysis, roofline analysis, docs lookup
- `workspaces.md` — remote execution workflows
- `pitfalls.md` — common mistakes and fixes
- `commands.md` — full auto-generated command reference

## Important

```bash
# Query GPU documentation (uses wafer API — no local download needed)
wafer agent -t ask-docs "What is warp divergence?"
wafer agent -t ask-docs "What is a TiledMma in CUTLASS?"
```

### 2. Trace Analysis

Analyze NCU, NSYS, or PyTorch profiler traces:

```bash
# AI-assisted analysis
wafer agent -t trace-analyze --args trace=./profile.ncu-rep "Why is this kernel slow?"

# Direct trace queries (PyTorch/Perfetto JSON)
wafer tool perfetto query trace.json \
  "SELECT name, dur/1e6 as ms FROM slice WHERE cat='kernel' ORDER BY dur DESC LIMIT 10"

# NCU/NSYS analysis
wafer tool ncu analyze profile.ncu-rep
wafer tool nsys analyze profile.nsys-rep
```

### 3. Roofline Analysis

Analyze kernel performance against hardware limits:

```bash
# Compute-bound kernel (e.g., large matmul)
wafer tool roofline --gpu H100 --bytes 100.7e6 --flops 137.4e12 --time-ms 85

# Memory-bound kernel (e.g., elementwise op)
wafer tool roofline --gpu H100 --bytes 4e9 --flops 1e9 --time-ms 2

# JSON output for scripting
wafer tool roofline --gpu H100 --bytes 100.7e6 --flops 137.4e12 --time-ms 85 --json

# List supported GPUs
wafer tool roofline --list-gpus
```

Output includes: peak specs, achieved compute/bandwidth with % of peak, bottleneck classification (COMPUTE BOUND / MEMORY BOUND), and efficiency assessment.

### 4. Kernel Evaluation

Test correctness and measure speedup against a reference using the unified eval primitive:

```bash
# List available evaluation tasks
wafer tool eval --list-tasks

# Run evaluation for a specific task
wafer tool eval --task kernelbench
wafer tool eval --task gpumode
wafer tool eval --task aiter -- <test_cmd>
wafer tool eval --task vllm -- <args>

# Run evaluation on a GPU target (compose with target run)
wafer target run --name <target> -- wafer tool eval --task gpumode
```

### 5. Remote Execution (Workspaces)

Run on cloud GPU workspaces:

```bash
# Create a workspace with a specific GPU and environment type
wafer target init workspace my-workspace -g B200 -e baremetal

# List targets (shows SSH connection info: host, port)
wafer target list

# Sync local files to workspace (files land at /workspace/ on remote, NOT /workspace/<name>/)
wafer target sync my-workspace ./local-dir

# Execute commands on the workspace
wafer target run --name my-workspace -- "cd /workspace && python script.py"

# SSH into workspace (now standard: get connection info from `wafer target show`)
wafer target ssh my-workspace
```

**Important: Synced files land at `/workspace/` directly** — not at `/workspace/<workspace-name>/`. For example, if you sync a directory containing `kernel.py`, it will be at `/workspace/kernel.py` on the remote machine.

### 6. Workspace + Evaluate Integration

Run eval on a workspace by composing `wafer target run` with `wafer tool eval`:

```bash
# Step 1: Create workspace
wafer target init workspace my-workspace -g B200 -e baremetal

# Step 2: Run eval on the workspace
wafer target run --name my-workspace -- wafer tool eval --task gpumode

# Or sync files first and run
wafer target sync my-workspace ./my-kernel
wafer target run --name my-workspace -- wafer tool eval --task kernelbench
```

**Alternative:** Use `wafer target run` with a custom benchmark script:

```bash
wafer target sync my-workspace ./my-kernel
wafer target run --name my-workspace -- "cd /workspace && python run_benchmark.py"
```

## Common Pitfalls

| Mistake | Fix |
|---------|-----|
| `wafer tool eval gpumode --impl ...` | Use `wafer tool eval --task gpumode` (unified eval, no old flags) |
| `wafer tool eval --target <name>` | Compose with target run: `wafer target run --name <target> -- wafer tool eval --task <name>` |
| `wafer tool eval make-template` | Removed — no longer available |
| `cd /workspace/my-workspace/` on remote | Synced files land at `/workspace/`, not `/workspace/<name>/` |
| `kernel()` / `reference()` function names | GPUMode format requires `custom_kernel()`, `ref_kernel()`, and `generate_input()` |
| Missing `generate_input` in reference.py | The reference file must export both `ref_kernel` AND `generate_input` |

## Command Reference

{{ COMMAND_REFERENCE }}

## Target Configuration

Targets define GPU access methods. Initialize with:

```bash
wafer target init ssh          # Your own GPU via SSH
wafer target init runpod       # RunPod cloud GPUs
wafer target init digitalocean # DigitalOcean AMD GPUs
```

Then use: `wafer target run --name <name> -- wafer tool eval --task gpumode`
