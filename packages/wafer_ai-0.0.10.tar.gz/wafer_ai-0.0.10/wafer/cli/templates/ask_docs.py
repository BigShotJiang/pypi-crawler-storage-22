"""Template for querying GPU documentation.

Streams directly from the server-side docs agent — no local agent loop.
The server runs a multi-turn Sonnet agent with grep/read_file/list_files
tools against the corpus volume in a Modal sandbox.

Usage:
    wafer agent -t ask-docs "How do bank conflicts occur?"
    wafer agent -t ask-docs --args corpus=hip "Explain HIP streams"
"""

from wafer.core.rollouts.templates import TemplateConfig

template = TemplateConfig(
    name="ask-docs",
    description="Query GPU documentation to answer technical questions",
    direct_endpoint="/v1/docs/query",
    defaults={"corpus": "cuda"},
)
