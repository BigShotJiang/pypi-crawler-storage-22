"""Session management for agent development, training, and deployment.
DEPRECATED: This module is deprecated. Use rollouts directly:
    from wafer.core.rollouts import (
        AgentSession, SessionStore, FileSessionStore,
        EndpointConfig, EnvironmentConfig, Message, SessionStatus,
    )
This module re-exports from wafer.core.rollouts for backwards compatibility.
"""
# Re-export from wafer.core.rollouts for backwards compatibility
from wafer.core.rollouts import (
    AgentSession,
    EndpointConfig,
    EnvironmentConfig,
    FileSessionStore,
    Message,
    SessionStatus,
)
from wafer.core.rollouts.store import SessionStore

# AgentHooks and run_agent_with_session are deprecated
from wafer.core.sessions.agent import run_agent_with_session  # noqa: E402
from wafer.core.sessions.hooks import AgentHooks  # noqa: E402

# Backwards compatibility aliases
Status = SessionStatus
__all__ = [
    "AgentSession",
    "AgentHooks",
    "EndpointConfig",
    "EnvironmentConfig",
    "FileSessionStore",
    "Message",
    "SessionStore",
    "Status",
    "run_agent_with_session",
    "SessionStatus",
]
