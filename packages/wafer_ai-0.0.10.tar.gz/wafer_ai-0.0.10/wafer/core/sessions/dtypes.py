"""Data types for session management.

DEPRECATED: Use rollouts directly:
    from wafer.core.rollouts import Message, AgentSession, SessionStatus, EndpointConfig, EnvironmentConfig

This module re-exports from wafer.core.rollouts for backwards compatibility.
"""

from wafer.core.rollouts.dtypes import (
    AgentSession,
    EndpointConfig,
    EnvironmentConfig,
    Message,
    SessionStatus,
)

# Backwards compatibility alias
Status = SessionStatus

__all__ = [
    "AgentSession",
    "EndpointConfig",
    "EnvironmentConfig",
    "Message",
    "SessionStatus",
    "Status",
]
