# Wafer CLI Guide

GPU development primitives for LLM agents.

## Quick Start

Run code on a GPU in two commands:

```bash
wafer settings login                                         # One-time auth
wafer target init workspace dev --gpu B200                   # Create a GPU target
wafer target run -- python -c "import torch; print(torch.cuda.get_device_name(0))"
```

**Available GPUs:**

- `MI300X` - AMD Instinct MI300X (192GB HBM3, ROCm)
- `B200` - NVIDIA Blackwell B200 (180GB HBM3e, CUDA) - default

## Running Code on a GPU

Use `wafer target run` to execute commands on any target (workspace or SSH host):

```bash
# Auto-select a target (uses default if set)
wafer target run -- python train.py

# Pick a target by name
wafer target run --name dev -- python train.py

# Pick by GPU type
wafer target run --gpu MI300X -- ./benchmark.sh

# Sync local files before running
wafer target run --sync ./project -- python train.py

# Set a timeout (seconds)
wafer target run --timeout 300 -- python long_job.py
```

## Managing Targets

Targets are GPU environments you run code on. They can be cloud workspaces or your own SSH hosts.

```bash
wafer target list                                # List all targets
wafer target show dev                            # Show target details
wafer target ssh dev                             # Interactive SSH
wafer target sync dev ./project                  # Sync files to target
wafer target pull dev /remote/results ./local    # Pull files from target
wafer target probe dev                           # Probe GPU capabilities
wafer target default dev                         # Set default target
wafer target remove dev                          # Remove a target
```

**Creating targets:**

```bash
# Cloud workspace (no hardware required)
wafer target init workspace dev --gpu B200
wafer target init workspace amd-dev --gpu MI300X

# Your own SSH host
wafer target init ssh my-box

# Cloud providers
wafer target init runpod
wafer target init digitalocean
```

## Documentation Lookup

Answer GPU programming questions from wafer's documentation corpus.

```bash
# Query documentation (uses wafer API — no local download needed)
wafer agent -t ask-docs "What is warp divergence?"
wafer agent -t ask-docs "What is a TiledMma in CUTLASS?"
```

## Trace Analysis

Analyze performance traces from NCU, NSYS, or PyTorch profiler.

```bash
# AI-assisted analysis
wafer agent -t trace-analyze --args trace=./profile.ncu-rep "Why is this kernel slow?"
wafer agent -t trace-analyze --args trace=./trace.json "What's the bottleneck?"

# Direct trace queries (PyTorch/Perfetto JSON)
wafer tool perfetto tables trace.json
wafer tool perfetto query trace.json \
  "SELECT name, dur/1e6 as ms FROM slice WHERE cat='kernel' ORDER BY dur DESC LIMIT 10"

# NCU/NSYS analysis
wafer tool ncu analyze profile.ncu-rep
wafer tool nsys analyze profile.nsys-rep
```

## Kernel Evaluation

Test kernel correctness and measure speedup against a reference.

```bash
# Run evaluation on any target
wafer target run --name dev --sync ./my-kernel -- python test_kernel.py

# Or use the evaluate tool directly
wafer tool eval make-template ./my-kernel
wafer tool eval \
  --impl ./my-kernel/kernel.py \
  --reference ./my-kernel/reference.py \
  --test-cases ./my-kernel/test_cases.json \
  --target <target-name>
```

For target setup, see `wafer target init --help`.

## Kernel Optimization (AI-assisted)

Iteratively optimize a kernel with evaluation feedback.

```bash
wafer agent -t optimize-kernel \
  --args kernel=./my_kernel.cu \
  --args target=H100 \
  "Optimize this GEMM for memory bandwidth"
```

## Command Reference

```bash
wafer target init|list|show|remove|default  # Manage GPU targets
wafer target run|ssh|sync|pull|probe        # Run code and interact with targets
wafer target pool list|create|status        # Fleet-level target pools
wafer tool eval                             # Test kernel correctness/performance
wafer tool ncu|nsys|perfetto                # NVIDIA profiling tools
wafer tool isa|rocprof-compute              # AMD profiling tools
wafer agent -t <template>                   # AI-assisted workflows
wafer settings corpus list|download|path    # Manage documentation corpora
```
