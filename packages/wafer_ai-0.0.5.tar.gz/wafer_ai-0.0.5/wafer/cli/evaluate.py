"""Remote kernel evaluation for Wafer CLI.
Runs evaluate.py on a remote GPU target with the same interface as local execution.
"""
from __future__ import annotations

import json
import logging
import re
import shlex
import subprocess
from dataclasses import dataclass
from pathlib import Path
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from datetime import datetime

    from wafer.core.async_ssh import AsyncSSHClient
    from wafer.core.remote_env import PythonEnvState
    from wafer.core.ssh import SSHClient
    from wafer.core.utils.kernel_utils.deployment import DeploymentState
    from wafer.core.utils.kernel_utils.targets.config import TargetConfig

logger = logging.getLogger(__name__)
from wafer.core.utils.kernel_utils.targets.config import (
    BaremetalTarget,
    DigitalOceanTarget,
    LocalTarget,
    ModalTarget,
    RunPodTarget,
    VMTarget,
    WorkspaceTarget,
)

# Used to set PYTORCH_ROCM_ARCH for faster compilation (compile only for target arch)
AMD_CC_TO_ARCH = {
    "9.4": "gfx942",  # MI300X
    "9.0a": "gfx90a",  # MI200 series
    "9.08": "gfx908",  # MI100
    "9.06": "gfx906",  # MI50/60
    "10.30": "gfx1030",  # RDNA2
    "11.0": "gfx1100",  # RDNA3
}


def _get_rocm_arch(compute_capability: str) -> str | None:
    """Get ROCm architecture string from compute capability.
    Returns gfx* string for PYTORCH_ROCM_ARCH, or None if not found.
    """
    # Already a gfx string
    if compute_capability.startswith("gfx"):
        return compute_capability

    return AMD_CC_TO_ARCH.get(compute_capability)


_ANSI_ESCAPE = re.compile(r"\x1B(?:[@-Z\\-_]|\[[0-?]*[ -/]*[@-~])")


def _strip_ansi(text: str) -> str:
    """Strip ANSI escape codes and carriage returns from text."""
    return _ANSI_ESCAPE.sub("", text).replace("\r", "")


async def _ensure_docker_image(
    client: object,
    image: str,
) -> None:
    """Check if Docker image exists on remote, pull if needed.

    Separates the pull phase from execution so agents see clear progress
    instead of ANSI-garbled Docker pull output mixed with evaluation output.
    """
    check = await client.exec(f"docker image inspect {image} >/dev/null 2>&1")
    if check.exit_code == 0:
        return  # Image already available

    print(f"Pulling Docker image {image} (this may take several minutes)...", flush=True)
    pull_result = await client.exec(f"docker pull {image}")
    if pull_result.exit_code != 0:
        stderr = _strip_ansi(pull_result.stderr or pull_result.stdout)
        raise RuntimeError(f"Failed to pull Docker image {image}: {stderr}")
    print("Docker image ready.", flush=True)


def _build_docker_run_command(
    image: str,
    command: str,
    *,
    working_dir: str | None = None,
    env: dict[str, str] | None = None,
    gpus: str = "all",
    volumes: dict[str, str] | None = None,
    cap_add: list[str] | None = None,
) -> str:
    """Build a docker run command string for NVIDIA GPUs.
    Pure function: string in, string out. No side effects.
    Args:
        image: Docker image name (e.g., "nvcr.io/nvidia/cutlass:4.3-devel")
        command: Command to run inside container
        working_dir: Container working directory (optional)
        env: Environment variables as dict (optional)
        gpus: GPU access string ("all", "device=0", "device=0,1", etc.)
        volumes: Host:container volume mappings (optional)
        cap_add: Linux capabilities to add (e.g., ["SYS_ADMIN"] for NCU profiling)
    Returns:
        Complete docker run command string
    """
    parts = ["docker", "run", "--rm"]
    if cap_add:
        for cap in cap_add:
            parts.extend(["--cap-add", cap])
    # GPU access - use single quotes for the device spec to avoid shell escaping issues
    if gpus:
        parts.extend(["--gpus", f"'{gpus}'"])
    # Volume mounts
    if volumes:
        for host_path, container_path in volumes.items():
            parts.extend(["-v", f"{host_path}:{container_path}"])
    # Working directory
    if working_dir:
        parts.extend(["-w", working_dir])
    # Environment variables
    if env:
        for key, value in env.items():
            parts.extend(["-e", f"{key}={shlex.quote(value)}"])
    # Image and command
    parts.append(image)
    parts.append(f"bash -c {shlex.quote(command)}")
    return " ".join(parts)


def _build_docker_run_command_amd(
    image: str,
    command: str,
    *,
    working_dir: str | None = None,
    env: dict[str, str] | None = None,
    volumes: dict[str, str] | None = None,
) -> str:
    """Build a docker run command string for AMD GPUs (ROCm).
    Uses device passthrough instead of NVIDIA's --gpus flag.
    Args:
        image: Docker image name (e.g., "rocm/pytorch:rocm6.2_ubuntu22.04_py3.10_pytorch_release_2.3.0")
        command: Command to run inside container
        working_dir: Container working directory (optional)
        env: Environment variables as dict (optional)
        volumes: Host:container volume mappings (optional)
    Returns:
        Complete docker run command string
    """
    parts = ["docker", "run", "--rm"]
    # AMD GPU access via device passthrough
    parts.extend(["--device=/dev/kfd", "--device=/dev/dri", "--group-add", "video"])
    # Volume mounts
    if volumes:
        for host_path, container_path in volumes.items():
            parts.extend(["-v", f"{host_path}:{container_path}"])
    # Working directory
    if working_dir:
        parts.extend(["-w", working_dir])
    # Environment variables
    if env:
        for key, value in env.items():
            parts.extend(["-e", f"{key}={shlex.quote(value)}"])
    # Image and command
    parts.append(image)
    parts.append(f"bash -c {shlex.quote(command)}")
    return " ".join(parts)


@dataclass(frozen=True)
class EvaluateArgs:
    """Arguments for evaluate command.
    Mirrors evaluate.py's CLI args.
    """
    implementation: Path
    reference: Path
    test_cases: Path
    target_name: str
    benchmark: bool = False
    profile: bool = False
    defensive: bool = False
    sync_artifacts: bool = True
    gpu_id: int | None = None


@dataclass(frozen=True)
class KernelBenchEvaluateArgs:
    """Arguments for KernelBench format evaluate command.
    KernelBench format uses Model/ModelNew classes instead of functions.
    No test_cases file - reference defines get_inputs()/get_init_inputs().
    """
    implementation: Path  # Must define ModelNew class
    reference: Path  # Must define Model, get_inputs, get_init_inputs
    target_name: str
    benchmark: bool = False
    profile: bool = False
    inputs: Path | None = None  # Custom inputs file to override get_inputs()
    seed: int = 42  # Random seed for reproducibility
    defensive: bool = False
    backend: str | None = None  # Kernel backend for static validation
    sync_artifacts: bool = True
    gpu_id: int | None = None
    stages: str = "compile,correctness"  # Stages to run: compile, correctness, benchmark, defense
    prepare_only: bool = False  # Sync files and generate script but don't run
    timeout: int = 600  # Subprocess timeout in seconds


@dataclass
class FlashInferBenchEvaluateArgs:
    """Arguments for FlashInfer-Bench format evaluate command.
    FlashInfer-Bench uses Definition/Solution format from the official benchmark suite.
    Solutions implement a run() function that writes to pre-allocated output tensors.
    """
    definition: str  # Definition name (e.g., "rmsnorm_h4096")
    solution_dir: Path  # Directory containing solution.json and main.py
    target_name: str
    trace_dir: Path | None = None  # Path to flashinfer-trace (defaults to bundled)
    warmup_runs: int = 10
    iterations: int = 50
    rtol: float = 1e-2
    atol: float = 1e-2
    gpu_id: int | None = None


@dataclass(frozen=True)
class FlashInferBenchResult:
    """Result from FlashInfer-Bench evaluation."""
    success: bool
    passed: bool
    definition: str
    solution: str
    speedup: float | None = None
    latency_ms: float | None = None
    reference_latency_ms: float | None = None
    max_abs_error: float | None = None
    max_rel_error: float | None = None
    error_message: str | None = None


@dataclass(frozen=True)
class AiterEvaluateArgs:
    """Arguments for aiter operator evaluation on remote MI300X.
    Evaluates aiter operator optimizations by syncing the local aiter directory
    to the remote target and running op_tests.
    """
    aiter_dir: Path  # Local aiter directory with modifications
    target_name: str
    cmd: str  # Command to run (e.g., "python op_tests/test_gemm_a16w16.py --mnk 128,32,8192")
    timeout: int = 600  # Long timeout for JIT compilation
    gpu_id: int | None = None


@dataclass(frozen=True)
class VllmEvaluateArgs:
    """Arguments for vLLM kernel evaluation.
    vLLM evaluation differs from KernelBench:
    - Runs against a full vLLM repo (not standalone files)
    - Uses pytest for correctness (vLLM's existing tests)
    - Uses benchmark_serving.py for performance metrics
    """
    vllm_dir: Path  # Path to vLLM repository
    op_name: str  # Target op to evaluate (e.g., "fused_moe", "paged_attention")
    test_cmd: str  # pytest command for correctness
    bench_cmd: str  # benchmark_serving.py command for performance
    target_name: str  # Target to run on
    baseline_metrics: dict[str, float] | None = None  # Pre-computed baseline metrics
    gpu_id: int | None = None


@dataclass(frozen=True)
class VllmEvaluateResult:
    """Result from vLLM evaluation."""
    success: bool
    correctness_passed: bool
    metrics: dict[str, float]  # Raw metrics: throughput, ttft, tpot, etc.
    baseline_metrics: dict[str, float]  # Baseline for comparison
    error_message: str | None = None


@dataclass(frozen=True)
class HipblasltEvaluateArgs:
    """Arguments for hipBLASLt GEMM evaluation on remote MI300X.
    Evaluates hipBLASLt kernel optimizations via wafer target.
    Uses workspace exec for GPU command queueing to prevent conflicts.
    """
    hipblaslt_dir: Path  # Local hipBLASLt directory with modifications
    workspace_id: str  # Workspace name or ID
    shape: tuple[int, int, int]  # M, K, N dimensions
    dtype: str = "bf16"  # bf16, fp16, int8
    kernel: str | None = None  # Specific kernel to benchmark (optional)
    timeout: int = 1200  # Long timeout for build + benchmark


@dataclass(frozen=True)
class HipblasltEvaluateResult:
    """Result from hipBLASLt evaluation."""
    success: bool
    correct: bool  # Correctness check passed
    tflops: float | None  # TFLOPS achieved
    time_ms: float | None  # Time in milliseconds
    baseline_tflops: float | None = None  # For speedup calculation
    speedup: float | None = None
    shape: tuple[int, int, int] | None = None
    error_message: str | None = None


@dataclass(frozen=True)
class EvaluateResult:
    """Result from remote evaluation."""
    success: bool
    all_correct: bool | None  # None when correctness wasn't checked (compile-only, prepare-only)
    correctness_score: float
    geomean_speedup: float
    passed_tests: int
    total_tests: int
    error_message: str | None = None
    artifact_path: Path | None = None


def _check_python_file_has(path: Path, *names: str) -> list[str]:
    """Check if a Python file exports the given names.
    Uses AST parsing to find:
    - Function definitions: def name(...)
    - Class definitions: class name(...)
    - Assignments: name = ...
    - Imports: from module import name / from module import x as name
    Returns:
        List of names that are missing
    """
    import ast
    content = path.read_text()
    try:
        tree = ast.parse(content)
    except SyntaxError:
        # If we can't parse, let the runtime fail with a better error
        return []
    defined_names: set[str] = set()
    for node in ast.walk(tree):
        if isinstance(node, ast.FunctionDef | ast.AsyncFunctionDef):
            defined_names.add(node.name)
        elif isinstance(node, ast.ClassDef):
            defined_names.add(node.name)
        elif isinstance(node, ast.Assign):
            for target in node.targets:
                if isinstance(target, ast.Name):
                    defined_names.add(target.id)
        elif isinstance(node, ast.ImportFrom):
            for alias in node.names:
                defined_names.add(alias.asname or alias.name)
    return [name for name in names if name not in defined_names]


def _validate_files(args: EvaluateArgs) -> str | None:
    """Validate that all input files exist, have correct format, and expected signatures.
    Returns:
        Error message if validation fails, None if all valid
    """
    # Report ALL missing files at once so the user can fix them in one pass
    missing: list[str] = []
    if not args.implementation.exists():
        missing.append(f"  - {args.implementation}")
    if not args.reference.exists():
        missing.append(f"  - {args.reference}")
    if not args.test_cases.exists():
        missing.append(f"  - {args.test_cases}")
    if missing:
        files_list = "\n".join(missing)
        return (
            f"Files not found:\n{files_list}\n"
            "  Generate template files: wafer tool eval make-template ./my-kernel"
        )
    # Validate test_cases is valid JSON
    try:
        json.loads(args.test_cases.read_text())
    except json.JSONDecodeError:
        if args.test_cases.suffix == ".py":
            return (
                f"--test-cases must be a JSON file, not a Python file: {args.test_cases}\n"
                "Hint: For KernelBench problems, use 'wafer tool eval kernelbench' instead:\n"
                f"  wafer tool eval kernelbench --impl <impl.py> --reference {args.test_cases}"
            )
        return f"--test-cases must be valid JSON: {args.test_cases}"
    # Validate implementation has custom_kernel
    impl_missing = _check_python_file_has(args.implementation, "custom_kernel")
    if impl_missing:
        has_model_new = not _check_python_file_has(args.implementation, "ModelNew")
        if has_model_new:
            return (
                f"Implementation file missing 'custom_kernel' function: {args.implementation}\n"
                "Hint: This looks like KernelBench format. Use 'wafer tool eval kernelbench' instead:\n"
                f"  wafer tool eval kernelbench --impl {args.implementation} --reference <reference.py>"
            )
        return (
            f"Implementation file missing 'custom_kernel' function: {args.implementation}\n"
            "  Required: 'def custom_kernel(inputs)' function"
        )
    # Validate reference has ref_kernel and generate_input
    ref_missing = _check_python_file_has(args.reference, "ref_kernel", "generate_input")
    if ref_missing:
        has_kernelbench = not _check_python_file_has(args.reference, "Model", "get_inputs")
        if has_kernelbench:
            return (
                f"Reference file missing required functions: {', '.join(ref_missing)}\n"
                "Hint: This looks like KernelBench format. Use 'wafer tool eval kernelbench' instead:\n"
                f"  wafer tool eval kernelbench --impl <impl.py> --reference {args.reference}"
            )
        return (
            f"Reference file missing required functions: {', '.join(ref_missing)}\n"
            f"  File: {args.reference}\n"
            "  Required: 'ref_kernel' and 'generate_input' functions"
        )
    return None


def _select_gpu_id(
    target: BaremetalTarget | VMTarget | ModalTarget, gpu_id_override: int | None
) -> int:
    """Select GPU ID to use.
    Args:
        target: Target config
        gpu_id_override: Optional explicit GPU ID
    Returns:
        GPU ID to use
    """
    if gpu_id_override is not None:
        return gpu_id_override
    if isinstance(target, BaremetalTarget | VMTarget):
        return target.gpu_ids[0]
    # Modal doesn't have explicit GPU IDs
    return 0


def _build_docker_pip_install_cmd(target: BaremetalTarget | VMTarget) -> str:
    """Build pip install command for Docker container.
    Installs uv first, then uses uv to install packages (Modal-like approach).
    Uses --system flag to install to container's system Python (not any venv).
    Handles base CUDA images that may not have pip pre-installed.
    Args:
        target: Target config with pip_packages, torch_package, torch_index_url
    Returns:
        Shell command string to install dependencies
    """
    commands = []
    # Some base images (like nvidia/cuda) don't have pip or git, install them first
    commands.append(
        "(which pip > /dev/null 2>&1 && which git > /dev/null 2>&1) || "
        "(apt-get update && "
        "DEBIAN_FRONTEND=noninteractive apt-get install -y python3 python3-pip git > /dev/null)"
    )
    # Install uv (fast, reliable) - use pip3 for compatibility
    commands.append("pip3 install --break-system-packages uv")
    # Install torch with custom index if specified (like Modal's two-phase install)
    # (needed for Python 3.12+ with PEP 668 externally managed environments)
    if target.torch_package:
        if target.torch_index_url:
            commands.append(
                f"uv pip install --system --break-system-packages --index-url {target.torch_index_url} "
                f"--extra-index-url https://pypi.org/simple {target.torch_package}"
            )
        else:
            commands.append(
                f"uv pip install --system --break-system-packages {target.torch_package}"
            )
    # Install other packages
    if target.pip_packages:
        packages_str = " ".join(target.pip_packages)
        commands.append(f"uv pip install --system --break-system-packages {packages_str}")
    return " && ".join(commands)


def _get_wafer_root() -> Path:
    """Get wafer monorepo root directory.
    Walks up from this file to find the wafer repo root (contains apps/, packages/).
    """
    current = Path(__file__).resolve()
    for parent in [current] + list(current.parents):
        if (parent / "apps").is_dir() and (parent / "packages").is_dir():
            return parent
    raise RuntimeError(f"Could not find wafer root from {__file__}")


def _fail_eval(error_message: str, total_tests: int = 0) -> EvaluateResult:
    assert error_message, "error_message must be non-empty"
    assert total_tests >= 0, "total_tests must be non-negative"
    return EvaluateResult(
        success=False,
        all_correct=False,
        correctness_score=0.0,
        geomean_speedup=0.0,
        passed_tests=0,
        total_tests=total_tests,
        error_message=error_message,
    )


def _success_eval(
    all_correct: bool | None,
    correctness_score: float,
    geomean_speedup: float,
    passed_tests: int,
    total_tests: int,
    artifact_path: Path | None = None,
) -> EvaluateResult:
    assert passed_tests >= 0, "passed_tests must be non-negative"
    assert total_tests >= 0, "total_tests must be non-negative"
    return EvaluateResult(
        success=True,
        all_correct=all_correct,
        correctness_score=correctness_score,
        geomean_speedup=geomean_speedup,
        passed_tests=passed_tests,
        total_tests=total_tests,
        artifact_path=artifact_path,
    )


def _success_kernelbench(correct: bool, speedup: float) -> EvaluateResult:
    assert isinstance(correct, bool), "correct must be a bool"
    assert speedup >= 0.0, "speedup must be non-negative"
    return EvaluateResult(
        success=True,
        all_correct=correct,
        correctness_score=1.0 if correct else 0.0,
        geomean_speedup=speedup,
        passed_tests=1 if correct else 0,
        total_tests=1,
    )


def _fail_vllm(error_message: str, baseline: dict | None = None) -> VllmEvaluateResult:
    assert error_message, "error_message must be non-empty"
    assert isinstance(error_message, str), "error_message must be a string"
    return VllmEvaluateResult(
        success=False,
        correctness_passed=False,
        metrics={},
        baseline_metrics=baseline or {},
        error_message=error_message,
    )


def _fail_flashinfer(
    definition: str, solution_dir: str | Path, error_message: str
) -> FlashInferBenchResult:
    assert definition, "definition must be non-empty"
    assert error_message, "error_message must be non-empty"
    return FlashInferBenchResult(
        success=False,
        passed=False,
        definition=definition,
        solution=str(solution_dir),
        error_message=error_message,
    )


async def _write_remote_file(
    client: AsyncSSHClient,
    path: str,
    content: str,
    delimiter: str = "WAFER_EOF",
) -> str | None:
    assert client is not None, "client must not be None"
    assert path, "path must be non-empty"
    result = await client.exec(f"cat > '{path}' << '{delimiter}'\n{content}\n{delimiter}")
    if result.exit_code != 0:
        return result.stderr
    return None


async def _upload_eval_files(
    client: AsyncSSHClient,
    run_path: str,
    impl_code: str,
    ref_code: str,
    test_cases_data: dict | str | list,
) -> str | None:
    assert client is not None, "client must not be None"
    assert run_path, "run_path must be non-empty"
    err = await _write_remote_file(client, f"{run_path}/implementation.py", impl_code, "IMPL_EOF")
    if err:
        return f"Failed to write implementation: {err}"
    err = await _write_remote_file(client, f"{run_path}/reference.py", ref_code, "REF_EOF")
    if err:
        return f"Failed to write reference: {err}"
    err = await _write_remote_file(client, f"{run_path}/reference_kernel.py", ref_code, "REF_EOF")
    if err:
        return f"Failed to write reference_kernel: {err}"
    test_cases_json = json.dumps(test_cases_data, indent=2) if not isinstance(test_cases_data, str) else test_cases_data
    err = await _write_remote_file(client, f"{run_path}/test_cases.json", test_cases_json, "TESTS_EOF")
    if err:
        return f"Failed to write test cases: {err}"
    return None


def _get_defense_source_path() -> Path:
    assert __file__, "__file__ must be set"
    return (
        Path(__file__).parent.parent.parent.parent
        / "packages"
        / "wafer"
        / "wafer" / "core"
        / "utils"
        / "kernel_utils"
        / "defense.py"
    )


async def _upload_kernelbench_files(
    client: AsyncSSHClient,
    run_path: str,
    args: KernelBenchEvaluateArgs,
) -> tuple[str | None, str | None]:
    assert client is not None, "client must not be None"
    assert run_path, "run_path must be non-empty"
    impl_code = args.implementation.read_text()
    ref_code = args.reference.read_text()
    err = await _write_remote_file(client, f"{run_path}/implementation.py", impl_code, "IMPL_EOF")
    if err:
        return None, f"Failed to write implementation: {err}"
    err = await _write_remote_file(client, f"{run_path}/reference.py", ref_code, "REF_EOF")
    if err:
        return None, f"Failed to write reference: {err}"
    if args.inputs:
        inputs_code = args.inputs.read_text()
        err = await _write_remote_file(client, f"{run_path}/custom_inputs.py", inputs_code, "INPUTS_EOF")
        if err:
            return None, f"Failed to write custom inputs: {err}"
    err = await _write_remote_file(client, f"{run_path}/kernelbench_eval.py", KERNELBENCH_EVAL_SCRIPT, "EVAL_EOF")
    if err:
        return None, f"Failed to write eval script: {err}"
    defense_module_path = None
    if args.defensive:
        defense_path = _get_defense_source_path()
        if defense_path.exists():
            defense_code = defense_path.read_text()
            defense_module_path = f"{run_path}/defense.py"
            err = await _write_remote_file(client, defense_module_path, defense_code, "DEFENSE_EOF")
            if err:
                print(f"Warning: Failed to write defense module: {err}")
                defense_module_path = None
        else:
            print(f"Warning: defense.py not found at {defense_path}")
    return defense_module_path, None


def _build_kernelbench_eval_cmd(
    args: KernelBenchEvaluateArgs,
    eval_script_path: str,
    impl_path: str,
    ref_path: str,
    output_path: str,
    inputs_path: str | None = None,
    defense_module_path: str | None = None,
    python_exe: str = "python3",
) -> str:
    assert eval_script_path, "eval_script_path must be non-empty"
    assert impl_path, "impl_path must be non-empty"
    parts = [
        f"{python_exe} {eval_script_path}",
        f"--impl {impl_path}",
        f"--reference {ref_path}",
        f"--output {output_path}",
    ]
    if args.benchmark:
        parts.append("--benchmark")
    if args.profile:
        parts.append("--profile")
    if inputs_path:
        parts.append(f"--inputs {inputs_path}")
    if args.defensive and defense_module_path:
        parts.append("--defensive")
        parts.append(f"--defense-module {defense_module_path}")
    parts.append(f"--seed {args.seed}")
    parts.append(f"--stages {args.stages}")
    return " ".join(parts)


async def _stream_and_collect(client: AsyncSSHClient, cmd: str) -> list[str]:
    assert client is not None, "client must not be None"
    assert cmd, "cmd must be non-empty"
    log_lines = []
    async for line in client.exec_stream(cmd):
        clean = _strip_ansi(line)
        if clean or not line:
            print(clean, flush=True)
        log_lines.append(line)
    return log_lines


async def _read_remote_json(client: AsyncSSHClient, path: str) -> tuple[dict | None, str | None]:
    assert client is not None, "client must not be None"
    assert path, "path must be non-empty"
    cat_result = await client.exec(f"cat {path}")
    if cat_result.exit_code != 0:
        return None, cat_result.stderr or "File not found"
    try:
        return json.loads(cat_result.stdout), None
    except json.JSONDecodeError as e:
        return None, f"Failed to parse JSON: {e}"


def _parse_backend_results(results_data: dict) -> EvaluateResult:
    assert results_data is not None, "results_data must not be None"
    assert isinstance(results_data, dict), "results_data must be a dict"
    backends = results_data.get("backends", [])
    if not backends:
        return _fail_eval("No backend results found")
    backend = backends[0]
    correctness_tests = backend.get("correctness_tests", [])
    passed = sum(1 for t in correctness_tests if t.get("is_correct", False))
    total = len(correctness_tests)
    return _success_eval(
        all_correct=backend.get("all_correct", False),
        correctness_score=backend.get("correctness_score", 0.0),
        geomean_speedup=backend.get("geomean_speedup", 0.0),
        passed_tests=passed,
        total_tests=total,
    )


def _parse_kernelbench_json(results_data: dict) -> EvaluateResult:
    assert results_data is not None, "results_data must not be None"
    assert isinstance(results_data, dict), "results_data must be a dict"
    correct = results_data.get("correct", False)
    speedup = results_data.get("speedup", 0.0) or 0.0
    error = results_data.get("error")
    if error:
        return _fail_eval(error, total_tests=1)
    return _success_kernelbench(correct, speedup)


def _find_json_in_output(output: str) -> dict | None:
    assert isinstance(output, str), "output must be a string"
    for line in reversed(output.strip().split("\n")):
        if line.startswith("{"):
            try:
                return json.loads(line)
            except json.JSONDecodeError:
                continue
    return None


async def _upload_wafer_ai_source(
    client: AsyncSSHClient,
    workspace: str,
    target_name: str,
    target_type: str,
    use_sftp: bool = False,
) -> str | None:
    assert client is not None, "client must not be None"
    assert workspace, "workspace must be non-empty"
    wafer_root = _get_wafer_root()
    wafer_ai_path = wafer_root / "packages" / "wafer"
    print(f"Uploading wafer-ai from {wafer_ai_path}...")
    wafer_ai_remote = f"{workspace}/wafer"
    await client.exec(f"mkdir -p {wafer_ai_remote}")
    wafer_ai_workspace = await client.expand_path(wafer_ai_remote)
    upload_kwargs = {"recursive": True}
    if use_sftp:
        upload_kwargs["use_sftp"] = True
    upload_result = await client.upload_files(
        str(wafer_ai_path), wafer_ai_workspace, **upload_kwargs
    )
    upload_event = {
        "event": "wafer_ai_upload",
        "target": target_name,
        "target_type": target_type,
        "ssh_host": f"{client.user}@{client.host}:{client.port}",
        "local_path": str(wafer_ai_path),
        "remote_path": wafer_ai_workspace,
        "success": upload_result.success,
        "files_copied": upload_result.files_copied,
        "duration_seconds": upload_result.duration_seconds,
        "error_message": upload_result.error_message,
    }
    if upload_result.debug_info:
        upload_event["debug_info"] = upload_result.debug_info
    logger.info(json.dumps(upload_event))
    if not upload_result.success:
        print(f"ERROR: Upload failed: {upload_result.error_message}")
        if upload_result.debug_info:
            print(f"Debug info: {json.dumps(upload_result.debug_info, indent=2)}")
        return f"Failed to upload wafer-ai: {upload_result.error_message}"
    print(f"Uploaded {upload_result.files_copied} files")
    return None


async def _find_python_with_torch(client: AsyncSSHClient, candidates: list[str]) -> str:
    assert client is not None, "client must not be None"
    assert candidates, "candidates must be non-empty"
    for candidate in candidates:
        check = await client.exec(f"{candidate} -c 'import torch' 2>/dev/null && echo OK")
        if "OK" in check.stdout:
            print(f"Using Python: {candidate}")
            return candidate
    return "python3"


def _encode_defense_b64() -> str | None:
    import base64
    assert __file__, "__file__ must be set"
    defense_path = _get_defense_source_path()
    if defense_path.exists():
        return base64.b64encode(defense_path.read_bytes()).decode()
    print(f"Warning: defense.py not found at {defense_path}, falling back to basic defense")
    return None


async def _run_modal_subprocess(
    script: str,
    timeout_seconds: int,
    extra_buffer: int = 60,
) -> tuple[str, str, int]:
    assert script, "script must be non-empty"
    assert timeout_seconds > 0, "timeout_seconds must be positive"
    import subprocess
    import sys

    import trio

    def _run() -> tuple[str, str, int]:
        result = subprocess.run(
            [sys.executable, "-c", script],
            capture_output=True, text=True,
            timeout=timeout_seconds + extra_buffer,
        )
        return result.stdout, result.stderr, result.returncode
    return await trio.to_thread.run_sync(_run)


def _parse_modal_json_output(stdout: str) -> dict | None:
    assert isinstance(stdout, str), "stdout must be a string"
    return _find_json_in_output(stdout)


def _parse_modal_eval_result(result_json: dict) -> EvaluateResult:
    assert result_json is not None, "result_json must not be None"
    assert isinstance(result_json, dict), "result_json must be a dict"
    if "error" in result_json:
        return _fail_eval(result_json["error"])
    passed = result_json.get("passed", 0)
    total = result_json.get("total", 0)
    correctness = passed / total if total > 0 else 0.0
    return _success_eval(
        all_correct=result_json.get("all_correct", False),
        correctness_score=correctness,
        geomean_speedup=result_json.get("speedup", 0.0),
        passed_tests=passed,
        total_tests=total,
    )


_NO_TARGET_MSG = (
    "No target specified and no default set.\n"
    "Set up a target first:\n"
    "  wafer target init ssh --name my-gpu --host user@host:22\n"
    "  wafer target init runpod --gpu MI300X\n"
    "Then use: --target my-gpu (or set default: wafer target default my-gpu)"
)


def _resolve_target(target_name: str | None) -> tuple[TargetConfig | None, str | None, str | None]:
    from .targets import get_default_target, load_target
    if not target_name:
        target_name = get_default_target()
        if not target_name:
            return None, None, _NO_TARGET_MSG
    try:
        target = load_target(target_name)
    except FileNotFoundError:
        return None, None, f"Target not found: {target_name}. Run: wafer target list"
    return target, target_name, None


async def _ensure_docker_installed(client: AsyncSSHClient) -> str | None:
    assert client is not None, "client must not be None"
    docker_check = await client.exec("which docker")
    if docker_check.exit_code != 0:
        print("Docker not found, installing...")
        install_result = await client.exec(
            "apt-get update -qq && apt-get install -y -qq docker.io"
        )
        if install_result.exit_code != 0:
            return f"Failed to install Docker: {install_result.stderr}"
    return None


async def _ensure_rsync(client: AsyncSSHClient) -> None:
    assert client is not None, "client must not be None"
    print("Checking rsync...")
    result = await client.exec("which rsync || echo 'NOT_FOUND'")
    if "NOT_FOUND" in result.stdout:
        print("Installing rsync...")
        await client.exec("apt-get update && apt-get install -y rsync")


async def _ensure_rsync_and_ninja(client: AsyncSSHClient) -> None:
    assert client is not None, "client must not be None"
    print("Checking system dependencies...")
    result = await client.exec("which rsync && which ninja || echo 'MISSING'")
    if "MISSING" in result.stdout:
        print("Installing rsync and ninja...")
        await client.exec("apt-get update && apt-get install -y rsync ninja-build")


def _rocm_requirements() -> list[str]:
    return [
        "torch==2.5.1+rocm6.2",
        "numpy",
        "ninja",
        "setuptools",
        "trio",
        "httpx",
        "pydantic",
        "anyio",
        "pyyaml",
    ]


async def _setup_rocm_env(
    client: AsyncSSHClient, workspace: str, python_version: str = ">=3.10"
) -> tuple[PythonEnvState | None, str | None, str | None]:
    assert client is not None, "client must not be None"
    assert workspace, "workspace must be non-empty"
    ROCM_TORCH_INDEX_URL = "https://download.pytorch.org/whl/rocm6.2"
    print("Setting up Python environment with ROCm torch...")
    env_state, err = await _setup_cloud_python_env(
        client, workspace, _rocm_requirements(), python_version, ROCM_TORCH_INDEX_URL,
    )
    if err:
        return None, None, f"Failed to setup Python environment: {err}"
    python_exe = env_state.venv_python
    print(f"Using Python: {python_exe}")
    return env_state, python_exe, None


def _build_rocm_env_vars(
    gpu_id: int,
    compute_capability: str | None = None,
) -> str:
    assert isinstance(gpu_id, int), "gpu_id must be an integer"
    assert gpu_id >= 0, "gpu_id must be non-negative"
    rocm_arch = _get_rocm_arch(compute_capability) if compute_capability else None
    arch_env = f"PYTORCH_ROCM_ARCH={rocm_arch}" if rocm_arch else ""
    return f"HIP_VISIBLE_DEVICES={gpu_id} ROCM_PATH=/opt/rocm PYTHONUNBUFFERED=1 {arch_env}"


async def _sync_docker_artifacts(
    client: AsyncSSHClient,
    run_path: str,
    run_dir: str,
    profile: bool = False,
) -> Path | None:
    assert client is not None, "client must not be None"
    assert run_path, "run_path must be non-empty"
    local_artifact_dir = Path.cwd() / "wafer_artifacts" / run_dir
    local_artifact_dir.mkdir(parents=True, exist_ok=True)
    artifact_path = None
    try:
        download_result = await client.download_files(
            remote_path=f"{run_path}/results.json",
            local_path=str(local_artifact_dir / "results.json"),
        )
        if download_result.success:
            artifact_path = local_artifact_dir
            print(f"Artifacts saved to: {artifact_path}")
        else:
            print(f"Warning: Failed to sync results.json: {download_result.error_message}")
        if profile:
            ncu_check = await client.exec(f"test -d {run_path}/artifact/ncu")
            if ncu_check.exit_code == 0:
                local_ncu_dir = local_artifact_dir / "ncu"
                local_ncu_dir.mkdir(parents=True, exist_ok=True)
                ncu_result = await client.download_files(
                    remote_path=f"{run_path}/artifact/ncu",
                    local_path=str(local_ncu_dir),
                    recursive=True,
                )
                if ncu_result.success:
                    print(f"NCU profiles synced: {ncu_result.files_copied} files")
                else:
                    print(f"Warning: Failed to sync NCU profiles: {ncu_result.error_message}")
    except Exception as e:
        print(f"Warning: Failed to sync artifacts: {e}")
    return artifact_path


async def _run_eval_on_cloud_target(
    args: EvaluateArgs,
    client: AsyncSSHClient,
    env_state: PythonEnvState,
    python_exe: str,
    gpu_id: int,
    workspace: str,
    gpu_env_var: str = "HIP_VISIBLE_DEVICES",
    eval_timeout: int = 600,
) -> EvaluateResult:
    assert client is not None, "client must not be None"
    assert workspace, "workspace must be non-empty"
    import uuid
    from datetime import datetime
    impl_code = args.implementation.read_text()
    ref_code = args.reference.read_text()
    test_cases_data = json.loads(args.test_cases.read_text())
    unique_id = uuid.uuid4().hex[:8]
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    run_dir = f"wafer_eval_{timestamp}_{unique_id}"
    run_path = f"{workspace}/{run_dir}"
    print("Uploading evaluation files...")
    mkdir_result = await client.exec(f"mkdir -p {run_path}")
    if mkdir_result.exit_code != 0:
        return _fail_eval(f"Failed to create run directory: {mkdir_result.stderr}")
    err = await _upload_eval_files(client, run_path, impl_code, ref_code, test_cases_data)
    if err:
        return _fail_eval(err)
    print("Running evaluation...")
    venv_bin = env_state.venv_bin
    env_vars = f"PATH={venv_bin}:$PATH {gpu_env_var}={gpu_id} ROCM_PATH=/opt/rocm"
    eval_cmd = (
        f"cd {run_path} && "
        f"{env_vars} {python_exe} -m wafer.core.utils.kernel_utils.evaluate "
        f"--implementation {run_path}/implementation.py "
        f"--reference {run_path}/reference.py "
        f"--test-cases {run_path}/test_cases.json "
        f"--run-dir {run_path}"
    )
    if args.benchmark:
        eval_cmd += " --benchmark"
    if args.defensive:
        eval_cmd += " --defensive"
    import trio
    with trio.move_on_after(eval_timeout) as cancel_scope:
        result = await client.exec(eval_cmd)
    if cancel_scope.cancelled_caught:
        return _fail_eval(f"Evaluation timed out after {eval_timeout}s")
    stdout = result.stdout
    stderr = result.stderr
    if stdout:
        print(stdout)
    if result.exit_code != 0:
        error_parts = [f"Evaluation failed (exit code {result.exit_code}):"]
        if stdout:
            error_parts.append(f"stdout: {stdout}")
        if stderr:
            error_parts.append(f"stderr: {stderr}")
        return _fail_eval("\n".join(error_parts))
    return await _read_and_parse_eval_results(client, run_path)


async def _read_and_parse_eval_results(
    client: AsyncSSHClient, run_path: str
) -> EvaluateResult:
    assert client is not None, "client must not be None"
    assert run_path, "run_path must be non-empty"
    results_data, err = await _read_remote_json(client, f"{run_path}/results.json")
    if err:
        return _fail_eval(f"Failed to read results: {err}")
    backends = results_data.get("backends", [])
    if not backends:
        result_json = _find_json_in_output(json.dumps(results_data))
        if result_json and "passed" in result_json:
            passed = result_json.get("passed", 0)
            total = result_json.get("total", 0)
            correctness = passed / total if total > 0 else 0.0
            return _success_eval(
                all_correct=result_json.get("all_correct", False),
                correctness_score=correctness,
                geomean_speedup=result_json.get("speedup", 0.0),
                passed_tests=passed,
                total_tests=total,
            )
        return _parse_backend_results(results_data)
    return _parse_backend_results(results_data)


def _prepare_only_result(
    run_path: str,
    target_name: str,
    client_host: str,
    client_port: int,
    full_cmd: str,
    env_vars: str,
    eval_cmd: str,
) -> EvaluateResult:
    assert run_path, "run_path must be non-empty"
    assert target_name, "target_name must be non-empty"
    print(f"\n[wafer] Prepared evaluation at: {run_path}")
    print(f"[wafer] Target: {target_name} ({client_host}:{client_port})")
    print("[wafer] To run manually:")
    print(f"  ssh -p {client_port} root@{client_host} '{full_cmd}'")
    print("\n[wafer] Or wrap with rocprof:")
    print(
        f"  ssh -p {client_port} root@{client_host} 'cd {run_path} && {env_vars} rocprof -i counters.txt {eval_cmd}'"
    )
    return EvaluateResult(
        success=True,
        all_correct=None,
        correctness_score=0.0,
        geomean_speedup=0.0,
        passed_tests=0,
        total_tests=0,
        error_message=None,
    )


async def _run_kernelbench_on_remote(
    client: AsyncSSHClient,
    args: KernelBenchEvaluateArgs,
    run_path: str,
    env_vars: str,
    eval_cmd: str,
    output_path: str,
) -> EvaluateResult:
    assert client is not None, "client must not be None"
    assert run_path, "run_path must be non-empty"
    full_cmd = f"cd {run_path} && {env_vars} {eval_cmd}"
    if args.prepare_only:
        return _prepare_only_result(
            run_path, args.target_name, client.host, client.port,
            full_cmd, env_vars, eval_cmd,
        )
    log_lines = await _stream_and_collect(client, full_cmd)
    cat_result_data, err = await _read_remote_json(client, output_path)
    if err:
        log_tail = "\n".join(log_lines[-50:])
        return _fail_eval(f"Evaluation failed. Log tail:\n{log_tail}")
    return _parse_kernelbench_json(cat_result_data)


async def _run_kernelbench_docker_flow(
    client: AsyncSSHClient,
    args: KernelBenchEvaluateArgs,
    run_path: str,
    run_dir: str,
    workspace_path: str,
    container_workspace: str,
    gpu_id: int,
    docker_image: str,
    pip_install_cmd: str | None,
    env_dict: dict[str, str],
    use_amd: bool = False,
) -> EvaluateResult:
    assert client is not None, "client must not be None"
    assert docker_image, "docker_image must be non-empty"
    defense_module_path, err = await _upload_kernelbench_files(client, run_path, args)
    if err:
        return _fail_eval(err)
    print("Running KernelBench evaluation in Docker container...")
    container_run_path = f"{container_workspace}/{run_dir}"
    eval_cmd = _build_kernelbench_eval_cmd(
        args,
        eval_script_path=f"{container_run_path}/kernelbench_eval.py",
        impl_path=f"{container_run_path}/implementation.py",
        ref_path=f"{container_run_path}/reference.py",
        output_path=f"{container_run_path}/results.json",
        inputs_path=f"{container_run_path}/custom_inputs.py" if args.inputs else None,
        defense_module_path=f"{container_run_path}/defense.py" if defense_module_path else None,
    )
    full_cmd = f"{pip_install_cmd} && cd {container_run_path} && {eval_cmd}" if pip_install_cmd else f"cd {container_run_path} && {eval_cmd}"
    await _ensure_docker_image(client, docker_image)
    if use_amd:
        docker_cmd = _build_docker_run_command_amd(
            image=docker_image,
            command=full_cmd,
            working_dir=container_run_path,
            env=env_dict,
            volumes={workspace_path: container_workspace},
        )
    else:
        docker_cmd = _build_docker_run_command(
            image=docker_image,
            command=full_cmd,
            working_dir=container_run_path,
            env=env_dict,
            gpus="all",
            volumes={workspace_path: container_workspace},
        )
    print(f"Docker command: {docker_cmd[:100]}...")
    log_lines = await _stream_and_collect(client, docker_cmd)
    results_data, err = await _read_remote_json(client, f"{run_path}/results.json")
    if err:
        log_tail = "\n".join(log_lines[-50:])
        return _fail_eval(f"Evaluation failed. Log tail:\n{log_tail}")
    return _parse_kernelbench_json(results_data)


async def _run_kernelbench_on_cloud(
    client: AsyncSSHClient,
    args: KernelBenchEvaluateArgs,
    gpu_id: int,
    workspace_base: str,
    target: TargetConfig,
    python_candidates: list[str] | None = None,
    gpu_env_var: str = "HIP_VISIBLE_DEVICES",
) -> EvaluateResult:
    assert client is not None, "client must not be None"
    assert workspace_base, "workspace_base must be non-empty"
    from datetime import datetime
    if python_candidates is None:
        python_candidates = [
            "/opt/venv/bin/python3",
            "/opt/conda/envs/py_3.10/bin/python3",
            "/opt/conda/bin/python3",
        ]
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    run_dir = f"kernelbench_eval_{timestamp}"
    run_path = f"{workspace_base}/{run_dir}"
    await client.exec(f"mkdir -p {run_path}")
    print(f"Created run directory: {run_path}")
    defense_module_path, err = await _upload_kernelbench_files(client, run_path, args)
    if err:
        return _fail_eval(err)
    print("Running KernelBench evaluation (AMD/ROCm)...")
    python_exe = await _find_python_with_torch(client, python_candidates)
    output_path = f"{run_path}/results.json"
    inputs_path = f"{run_path}/custom_inputs.py" if args.inputs else None
    eval_cmd = _build_kernelbench_eval_cmd(
        args, f"{run_path}/kernelbench_eval.py", f"{run_path}/implementation.py",
        f"{run_path}/reference.py", output_path, inputs_path, defense_module_path,
        python_exe,
    )
    if gpu_env_var == "HIP_VISIBLE_DEVICES":
        env_vars = _build_rocm_env_vars(gpu_id, getattr(target, "compute_capability", None))
    else:
        env_vars = f"CUDA_VISIBLE_DEVICES={gpu_id} PYTHONUNBUFFERED=1"
    return await _run_kernelbench_on_remote(
        client, args, run_path, env_vars, eval_cmd, output_path,
    )


async def _setup_cloud_python_env(
    client: AsyncSSHClient,
    workspace: str,
    requirements: list[str],
    python_version: str,
    index_url: str,
) -> tuple[PythonEnvState | None, str | None]:
    assert client is not None, "client must not be None"
    assert workspace, "workspace must be non-empty"
    from wafer.core.remote_env import async_setup_python_env
    try:
        env_state = await async_setup_python_env(
            client=client,
            workspace=workspace,
            requirements=requirements,
            python_version=python_version,
            venv_path=".venv",
            index_url=index_url,
        )
        return env_state, None
    except Exception as e:
        return None, str(e)


async def _run_vllm_eval_on_remote(
    client: AsyncSSHClient,
    args: VllmEvaluateArgs,
    run_path: str,
    env_vars: str,
    python_exe: str = "python3",
) -> VllmEvaluateResult:
    assert client is not None, "client must not be None"
    assert run_path, "run_path must be non-empty"
    import json as json_module
    remote_vllm = f"{run_path}/vllm"
    print(f"Syncing vLLM directory to {remote_vllm}...")
    sync_result = await client.upload_files(
        local_path=str(args.vllm_dir),
        remote_path=remote_vllm,
        recursive=True,
    )
    if not sync_result.success:
        return _fail_vllm(
            f"Failed to sync vLLM directory: {sync_result.error_message}",
            args.baseline_metrics,
        )
    eval_script_path = f"{run_path}/vllm_eval.py"
    print("Uploading eval script...")
    err = await _write_remote_file(client, eval_script_path, VLLM_EVAL_SCRIPT, "EVAL_EOF")
    if err:
        return _fail_vllm(f"Failed to write eval script: {err}", args.baseline_metrics)
    output_path = f"{run_path}/results.json"
    escaped_test_cmd = shlex.quote(args.test_cmd)
    escaped_bench_cmd = shlex.quote(args.bench_cmd)
    eval_cmd = (
        f"{python_exe} {eval_script_path} "
        f"--vllm-dir {remote_vllm} "
        f"--test-cmd {escaped_test_cmd} "
        f"--bench-cmd {escaped_bench_cmd} "
        f"--output {output_path} "
        f"--timeout 600"
    )
    full_cmd = f"cd {run_path} && {env_vars} {eval_cmd}"
    print("Running vLLM evaluation...")
    print(f"  Test: {args.test_cmd}")
    print(f"  Bench: {args.bench_cmd}")
    log_lines: list[str] = []
    async for line in client.exec_stream(full_cmd):
        clean = _strip_ansi(line)
        if clean or not line:
            print(clean, end="")
        log_lines.append(line)
    read_result = await client.exec(f"cat {output_path}")
    if read_result.exit_code != 0:
        return _fail_vllm(
            f"Failed to read results: {read_result.stderr}", args.baseline_metrics
        )
    try:
        results = json_module.loads(read_result.stdout)
    except json_module.JSONDecodeError as e:
        return _fail_vllm(
            f"Failed to parse results JSON: {e}", args.baseline_metrics
        )
    return VllmEvaluateResult(
        success=results.get("success", False),
        correctness_passed=results.get("correctness_passed", False),
        metrics=results.get("metrics", {}),
        baseline_metrics=args.baseline_metrics or {},
        error_message=results.get("error"),
    )


async def run_evaluate_docker(
    args: EvaluateArgs,
    target: BaremetalTarget | VMTarget,
) -> EvaluateResult:
    """Run evaluation in Docker container on SSH-based target.
    Uses async SSH client for true non-blocking I/O.
    Uploads wafer-ai and runs evaluate.py directly with PYTHONPATH.
    No package installation needed - avoids rollouts dependency.
    Args:
        args: Evaluate arguments
        target: SSH target config with docker_image set
    Returns:
        Evaluation result
    """
    from datetime import datetime

    from wafer.core.async_ssh import AsyncSSHClient
    CONTAINER_WORKSPACE = "/workspace"
    REMOTE_WORKSPACE_BASE = "~/.wafer/workspaces"
    if not target.docker_image:
        raise ValueError("docker_image must be set for Docker execution")
    gpu_id = _select_gpu_id(target, args.gpu_id)
    print(f"Connecting to {target.ssh_target}...")
    async with AsyncSSHClient(target.ssh_target, target.ssh_key) as client:
        print(f"Using Docker image: {target.docker_image}")
        print(f"Using GPU {gpu_id}...")
        impl_code = args.implementation.read_text()
        ref_code = args.reference.read_text()
        test_cases_data = json.loads(args.test_cases.read_text())
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        run_dir = f"wafer_eval_{timestamp}"
        eval_workspace = f"{REMOTE_WORKSPACE_BASE}/eval_{timestamp}"
        await client.exec(f"mkdir -p {eval_workspace}")
        eval_workspace_expanded = await client.expand_path(eval_workspace)
        run_path = f"{eval_workspace_expanded}/{run_dir}"
        print("Uploading evaluation files...")
        mkdir_result = await client.exec(f"mkdir -p {run_path}")
        if mkdir_result.exit_code != 0:
            return _fail_eval(f"Failed to create run directory: {mkdir_result.stderr}")
        err = await _upload_eval_files(client, run_path, impl_code, ref_code, test_cases_data)
        if err:
            return _fail_eval(err)
        print("Running evaluation in Docker container...")
        container_run_path = f"{CONTAINER_WORKSPACE}/{run_dir}"
        docker_cmd = _build_docker_eval_command(
            args, target, container_run_path, gpu_id, eval_workspace_expanded, CONTAINER_WORKSPACE,
        )
        await _ensure_docker_image(client, target.docker_image)
        print(f"Docker command: {docker_cmd[:100]}...")
        log_lines = await _stream_and_collect(client, docker_cmd)
        results_data, parse_err = await _read_remote_json(client, f"{run_path}/results.json")
        if parse_err:
            log_tail = "\n".join(log_lines[-50:])
            return _fail_eval(f"Evaluation failed. Log tail:\n{log_tail}")
        result = _parse_backend_results(results_data)
        if not result.success:
            return result
        artifact_path = None
        if args.sync_artifacts:
            artifact_path = await _sync_docker_artifacts(client, run_path, run_dir, args.profile)
        return EvaluateResult(
            success=True,
            all_correct=result.all_correct,
            correctness_score=result.correctness_score,
            geomean_speedup=result.geomean_speedup,
            passed_tests=result.passed_tests,
            total_tests=result.total_tests,
            artifact_path=artifact_path,
        )


def _build_docker_eval_command(
    args: EvaluateArgs,
    target: BaremetalTarget | VMTarget,
    container_run_path: str,
    gpu_id: int,
    eval_workspace_expanded: str,
    container_workspace: str,
) -> str:
    assert container_run_path, "container_run_path must be non-empty"
    assert gpu_id >= 0, "gpu_id must be non-negative"
    pip_install_cmd = _build_docker_pip_install_cmd(target)
    install_cmd = (
        f"{pip_install_cmd} && uv pip install --system --break-system-packages wafer-ai"
    )
    python_cmd_parts = [
        "python3 -m wafer.core.utils.kernel_utils.evaluate",
        f"--implementation {container_run_path}/implementation.py",
        f"--reference {container_run_path}/reference.py",
        f"--test-cases {container_run_path}/test_cases.json",
        f"--run-dir {container_run_path}",
    ]
    if args.benchmark:
        python_cmd_parts.append("--benchmark")
    if args.profile:
        python_cmd_parts.append("--profile")
    if args.defensive:
        python_cmd_parts.append("--defensive")
    eval_cmd = " ".join(python_cmd_parts)
    full_cmd = f"{install_cmd} && cd {container_run_path} && {eval_cmd}"
    return _build_docker_run_command(
        image=target.docker_image,
        command=full_cmd,
        working_dir=container_run_path,
        env={"CUDA_VISIBLE_DEVICES": str(gpu_id), "PYTHONUNBUFFERED": "1"},
        gpus="all",
        volumes={eval_workspace_expanded: container_workspace},
        cap_add=["SYS_ADMIN"] if args.profile else None,
    )


async def run_evaluate_local(
    args: EvaluateArgs | KernelBenchEvaluateArgs,
    target: LocalTarget,
) -> EvaluateResult:
    """Run evaluation locally on the current machine.
    For LocalTarget - no SSH needed, runs directly.
    Args:
        args: Evaluate arguments
        target: Local target config
    Returns:
        Evaluation result
    """
    import os
    import subprocess
    import tempfile
    from datetime import datetime
    gpu_id = args.gpu_id if args.gpu_id is not None else target.gpu_ids[0]
    print(f"Running local evaluation on GPU {gpu_id}...")
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    with tempfile.TemporaryDirectory(prefix=f"wafer_eval_{timestamp}_") as run_path:
        run_path = Path(run_path)
        cmd_parts, defense_module_path = _prepare_local_eval_files(run_path, args)
        output_path = run_path / "results.json"
        env = _build_local_gpu_env(os.environ.copy(), target.vendor, gpu_id)
        print(f"Running: {' '.join(cmd_parts[:4])} ...")
        try:
            result = subprocess.run(
                cmd_parts,
                cwd=str(run_path),
                env=env,
                capture_output=True,
                text=True,
                timeout=getattr(args, "timeout", None) or 600,
            )
        except subprocess.TimeoutExpired:
            return _fail_eval("Evaluation timed out")
        if result.stdout:
            print(result.stdout)
        if result.stderr:
            print(result.stderr, file=__import__("sys").stderr)
        if result.returncode != 0:
            error_msg = result.stderr or result.stdout or "Unknown error"
            if len(error_msg) > 1000:
                error_msg = error_msg[:500] + "\n...\n" + error_msg[-500:]
            return _fail_eval(f"Evaluation failed:\n{error_msg}")
        if not output_path.exists():
            return _fail_eval("No results.json produced")
        try:
            results = json.loads(output_path.read_text())
        except json.JSONDecodeError as e:
            return _fail_eval(f"Failed to parse results: {e}")
        return EvaluateResult(
            success=True,
            all_correct=results.get("all_correct", False),
            correctness_score=results.get("correctness_score", 0.0),
            geomean_speedup=results.get("geomean_speedup", 0.0),
            passed_tests=results.get("passed_tests", 0),
            total_tests=results.get("total_tests", 0),
            benchmark_results=results.get("benchmark", {}),
        )


def _prepare_local_eval_files(
    run_path: Path, args: EvaluateArgs | KernelBenchEvaluateArgs
) -> tuple[list[str], Path | None]:
    assert run_path, "run_path must be non-empty"
    assert args is not None, "args must not be None"
    impl_path = run_path / "implementation.py"
    impl_path.write_text(args.implementation.read_text())
    ref_path = run_path / "reference.py"
    ref_path.write_text(args.reference.read_text())
    inputs_path = None
    if getattr(args, "inputs", None):
        inputs_path = run_path / "custom_inputs.py"
        inputs_path.write_text(args.inputs.read_text())
    eval_script_path = run_path / "kernelbench_eval.py"
    eval_script_path.write_text(KERNELBENCH_EVAL_SCRIPT)
    defense_module_path = None
    if args.defensive:
        defense_src = _get_defense_source_path()
        if defense_src.exists():
            defense_module_path = run_path / "defense.py"
            defense_module_path.write_text(defense_src.read_text())
        else:
            print(f"Warning: defense.py not found at {defense_src}")
    output_path = run_path / "results.json"
    cmd_parts = [
        "python3", str(eval_script_path),
        "--impl", str(impl_path),
        "--reference", str(ref_path),
        "--output", str(output_path),
        "--seed", str(getattr(args, "seed", 42)),
    ]
    if args.benchmark:
        cmd_parts.append("--benchmark")
    if args.profile:
        cmd_parts.append("--profile")
    if inputs_path:
        cmd_parts.extend(["--inputs", str(inputs_path)])
    if args.defensive and defense_module_path:
        cmd_parts.extend(["--defensive", "--defense-module", str(defense_module_path)])
    stages = getattr(args, "stages", None)
    if stages:
        cmd_parts.extend(["--stages", stages])
    return cmd_parts, defense_module_path


def _build_local_gpu_env(env: dict, vendor: str, gpu_id: int) -> dict:
    assert vendor in ("nvidia", "amd"), f"vendor must be 'nvidia' or 'amd', got '{vendor}'"
    assert gpu_id >= 0, "gpu_id must be non-negative"
    if vendor == "nvidia":
        env["CUDA_VISIBLE_DEVICES"] = str(gpu_id)
    else:  # AMD
        env["HIP_VISIBLE_DEVICES"] = str(gpu_id)
        env["ROCM_PATH"] = "/opt/rocm"
    return env


async def run_evaluate_ssh(
    args: EvaluateArgs,
    target: BaremetalTarget | VMTarget,
) -> EvaluateResult:
    """Run evaluation on SSH-based target (Baremetal or VM).
    Routes to Docker or venv execution based on target.docker_image.
    Args:
        args: Evaluate arguments
        target: SSH target config
    Returns:
        Evaluation result
    """
    if target.docker_image:
        return await run_evaluate_docker(args, target)
    from datetime import datetime

    from wafer.core.utils.kernel_utils.deployment import (
        DeploymentConfig,
        setup_deployment,
    )
    gpu_id = _select_gpu_id(target, args.gpu_id)
    config = DeploymentConfig(
        ssh_target=target.ssh_target,
        ssh_key=target.ssh_key,
        gpu_id=gpu_id,
    )
    print(f"Connecting to {target.ssh_target}...")
    state, err = await setup_deployment(config)
    if err:
        return _fail_eval(f"Deployment setup failed: {err}")
    assert state is not None
    print(f"Using GPU {gpu_id}...")
    impl_code = args.implementation.read_text()
    ref_code = args.reference.read_text()
    test_cases_data = json.loads(args.test_cases.read_text())
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    run_dir = f"wafer_eval_{timestamp}"
    workspace = state.workspace_path
    run_path = f"{workspace}/{run_dir}"
    client = state.ssh_client
    print("Uploading files...")
    err = _upload_eval_files_sync(client, run_path, impl_code, ref_code, test_cases_data)
    if err:
        return _fail_eval(err)
    print("Running evaluation...")
    eval_cmd = _build_ssh_eval_command(args, state, run_path, workspace)
    tmux_err = _run_ssh_eval_via_tmux(client, eval_cmd, run_path, gpu_id, datetime)
    if tmux_err:
        return _fail_eval(tmux_err)
    log_file = f"{run_path}/evaluate.log"
    result = _read_ssh_eval_results(client, run_path, log_file)
    if not result.success:
        return result
    artifact_path = _sync_ssh_artifacts(client, args, run_dir, run_path, log_file)
    return EvaluateResult(
        success=True,
        all_correct=result.all_correct,
        correctness_score=result.correctness_score,
        geomean_speedup=result.geomean_speedup,
        passed_tests=result.passed_tests,
        total_tests=result.total_tests,
        artifact_path=artifact_path,
    )


def _upload_eval_files_sync(
    client: SSHClient,
    run_path: str,
    impl_code: str,
    ref_code: str,
    test_cases_data: dict | str | list,
) -> str | None:
    assert client is not None, "client must not be None"
    assert run_path, "run_path must be non-empty"
    mkdir_result = client.exec(f"mkdir -p {run_path}")
    if mkdir_result.exit_code != 0:
        return f"Failed to create run directory: {mkdir_result.stderr}"
    files = [
        (f"{run_path}/implementation.py", impl_code, "IMPL_EOF"),
        (f"{run_path}/reference.py", ref_code, "REF_EOF"),
        (f"{run_path}/reference_kernel.py", ref_code, "REF_EOF"),
        (f"{run_path}/test_cases.json", json.dumps(test_cases_data, indent=2), "TESTS_EOF"),
    ]
    for path, content, delimiter in files:
        write_result = client.exec(f"cat > '{path}' << '{delimiter}'\n{content}\n{delimiter}")
        if write_result.exit_code != 0:
            return f"Failed to write {path.split('/')[-1]}: {write_result.stderr}"
    return None


def _build_ssh_eval_command(
    args: EvaluateArgs, state: DeploymentState, run_path: str, workspace: str
) -> str:
    assert run_path, "run_path must be non-empty"
    assert workspace, "workspace must be non-empty"
    async_wevin_root = "/".join(workspace.rstrip("/").split("/")[:-2])
    evaluate_script = f"{async_wevin_root}/wafer_utils/kernel_utils/evaluate.py"
    env_state = state.env_state
    parts = [
        f"cd {run_path} &&",
        f"PATH={env_state.venv_bin}:$PATH",
        f"{env_state.venv_python} {evaluate_script}",
        f"--implementation {run_path}/implementation.py",
        f"--reference {run_path}/reference.py",
        f"--test-cases {run_path}/test_cases.json",
        f"--run-dir {run_path}",
    ]
    if args.benchmark:
        parts.append("--benchmark")
    if args.profile:
        parts.append("--profile")
    if args.defensive:
        parts.append("--defensive")
    return " ".join(parts)


def _run_ssh_eval_via_tmux(
    client: SSHClient, eval_cmd: str, run_path: str, gpu_id: int, datetime_mod: type[datetime]
) -> str | None:
    assert client is not None, "client must not be None"
    assert eval_cmd, "eval_cmd must be non-empty"
    from wafer.core.remote_jobs import (
        LogStreamConfig,
        start_tmux_session,
        stream_log_until_complete,
    )
    session_name = f"wafer_eval_{datetime_mod.now().strftime('%H%M%S')}"
    log_file = f"{run_path}/evaluate.log"
    _, err = start_tmux_session(
        client=client,
        session_name=session_name,
        command=eval_cmd,
        workspace=run_path,
        log_file=log_file,
        env_vars={"CUDA_VISIBLE_DEVICES": str(gpu_id), "PYTHONUNBUFFERED": "1"},
    )
    if err:
        return f"Failed to start evaluation: {err}"
    stream_config = LogStreamConfig(
        session_name=session_name,
        log_file=log_file,
        timeout_sec=600,
        poll_interval_sec=2.0,
    )
    _ = stream_log_until_complete(client=client, config=stream_config)
    return None


def _read_ssh_eval_results(
    client: SSHClient, run_path: str, log_file: str
) -> EvaluateResult:
    assert client is not None, "client must not be None"
    assert run_path, "run_path must be non-empty"
    cat_result = client.exec(f"cat {run_path}/results.json")
    if cat_result.exit_code != 0:
        log_result = client.exec(f"tail -50 {log_file}")
        log_tail = log_result.stdout if log_result.exit_code == 0 else ""
        return _fail_eval(f"Evaluation failed. Log tail:\n{log_tail}")
    try:
        results_data = json.loads(cat_result.stdout)
    except json.JSONDecodeError as e:
        return _fail_eval(f"Failed to parse results: {e}")
    return _parse_backend_results(results_data)


def _sync_ssh_artifacts(
    client: SSHClient,
    args: EvaluateArgs,
    run_dir: str,
    run_path: str,
    log_file: str,
) -> Path | None:
    assert client is not None, "client must not be None"
    assert run_path, "run_path must be non-empty"
    if not args.sync_artifacts:
        return None
    local_artifact_dir = Path.cwd() / "wafer_artifacts" / run_dir
    local_artifact_dir.mkdir(parents=True, exist_ok=True)
    try:
        client.download_files(
            remote_path=f"{run_path}/results.json",
            local_path=str(local_artifact_dir / "results.json"),
        )
        client.download_files(
            remote_path=log_file,
            local_path=str(local_artifact_dir / "evaluate.log"),
        )
        print(f"Artifacts saved to: {local_artifact_dir}")
        return local_artifact_dir
    except Exception as e:
        print(f"Warning: Failed to sync artifacts: {e}")
        return None


def _modal_torch_config(gpu_type: str) -> tuple[str, str]:
    assert gpu_type, "gpu_type must be non-empty"
    if gpu_type in ("B200", "GB200"):
        return "https://download.pytorch.org/whl/cu130", "10.0"
    elif gpu_type == "H100":
        return "https://download.pytorch.org/whl/cu130", "9.0"
    return "https://download.pytorch.org/whl/cu124", "8.0"


def _modal_image_setup(
    torch_index: str,
    cuda_arch_list: str,
    extra_steps: str = "",
    extra_apt: str = "",
) -> str:
    assert torch_index, "torch_index must be non-empty"
    assert cuda_arch_list, "cuda_arch_list must be non-empty"
    apt_packages = '"git", "build-essential", "cmake", "ripgrep"'
    if extra_apt:
        apt_packages = f'"git", "build-essential", "cmake", {extra_apt}, "ripgrep"'
    return f'''
    image = (
        modal.Image.from_registry(
            "nvidia/cuda:12.9.0-devel-ubuntu22.04",
            add_python="3.12",
        )
        .apt_install({apt_packages})
        .pip_install(
            "torch",
            index_url="{torch_index}",
            extra_index_url="https://pypi.org/simple",
        )
        .pip_install(
            "numpy",
            "triton",
            "ninja",
        )
        {extra_steps}
        .env({{
            "CUDA_HOME": "/usr/local/cuda",
            "CPLUS_INCLUDE_PATH": "/usr/local/cuda/include",
            "LIBRARY_PATH": "/usr/local/cuda/lib64",
            "TORCH_CUDA_ARCH_LIST": "{cuda_arch_list}",
        }})
    )'''


def _inline_eval_load_preamble(quote_style: str = "'") -> str:
    assert quote_style in ("'", '"'), "quote_style must be single or double quote"
    q = quote_style
    return f"""
import json
import sys
import os
import importlib.util
os.chdir({q}/workspace{q})
sys.path.insert(0, {q}/workspace{q})
with open({q}test_cases.json{q}) as f:
    test_cases = json.load(f)
def load_fn(path, name):
    spec = importlib.util.spec_from_file_location({q}mod{q}, path)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return getattr(mod, name)
custom_kernel = load_fn({q}kernel.py{q}, {q}custom_kernel{q})
ref_kernel = load_fn({q}reference.py{q}, {q}ref_kernel{q})
generate_input = load_fn({q}reference.py{q}, {q}generate_input{q})
import torch
"""


def _inline_defense_setup_script(
    run_defensive: bool,
    quote_style: str = "'",
) -> str:
    assert quote_style in ("'", '"'), "quote_style must be single or double quote"
    q = quote_style
    _oq = '"' if q == "'" else "'"
    return f'''
run_defensive = {run_defensive}
defense = None
if run_defensive:
    try:
        defense = load_fn({q}defense.py{q}, {q}run_all_defenses{q})
        time_with_defenses = load_fn({q}defense.py{q}, {q}time_execution_with_defenses{q})
        print({q}[Defense] Defense module loaded{q})
        def _wrap_for_defense(kernel):
            return lambda *args: kernel(args)
        custom_kernel_for_defense = _wrap_for_defense(custom_kernel)
        ref_kernel_for_defense = _wrap_for_defense(ref_kernel)
    except Exception as e:
        print(f{q}[Defense] Warning: Could not load defense module: {{e}}{q})
        defense = None
'''


def _inline_benchmark_timing_script(
    run_benchmarks: bool,
    run_defensive: bool,
    quote_style: str = "'",
) -> str:
    assert quote_style in ("'", '"'), "quote_style must be single or double quote"
    q = quote_style
    oq = '"' if q == "'" else "'"
    return f'''
        impl_time_ms = 0.0
        ref_time_ms = 0.0
        if {run_benchmarks}:
            if run_defensive and defense is not None:
                inputs_list = list(inputs) if hasattr(inputs, {q}__iter__{q}) and not isinstance(inputs, torch.Tensor) else [inputs]
                all_passed, defense_results, _ = defense(custom_kernel_for_defense, *inputs_list)
                if not all_passed:
                    failed = [name for name, passed, _ in defense_results if not passed]
                    raise ValueError(f{oq}Defense checks failed: {{failed}}{oq})
                impl_times, _ = time_with_defenses(
                    custom_kernel_for_defense, inputs_list,
                    num_warmup=3, num_trials=10, verbose=False, run_defenses=False,
                )
                impl_time_ms = sum(impl_times) / len(impl_times)
                ref_times, _ = time_with_defenses(
                    ref_kernel_for_defense, inputs_list,
                    num_warmup=3, num_trials=10, verbose=False, run_defenses=False,
                )
                ref_time_ms = sum(ref_times) / len(ref_times)
            else:
                for _ in range(3):
                    custom_kernel(inputs)
                torch.cuda.synchronize()
                start = torch.cuda.Event(enable_timing=True)
                end = torch.cuda.Event(enable_timing=True)
                start.record()
                for _ in range(10):
                    custom_kernel(inputs)
                end.record()
                torch.cuda.synchronize()
                impl_time_ms = start.elapsed_time(end) / 10
                for _ in range(3):
                    ref_kernel(inputs)
                torch.cuda.synchronize()
                start.record()
                for _ in range(10):
                    ref_kernel(inputs)
                end.record()
                torch.cuda.synchronize()
                ref_time_ms = start.elapsed_time(end) / 10
            total_time_ms += impl_time_ms
            ref_total_time_ms += ref_time_ms
'''


def _inline_eval_results_script(quote_style: str = "'") -> str:
    assert quote_style in ("'", '"'), "quote_style must be single or double quote"
    q = quote_style
    return f'''
        results.append({{
            {q}name{q}: name,
            {q}correct{q}: correct,
            {q}impl_time_ms{q}: impl_time_ms,
            {q}ref_time_ms{q}: ref_time_ms,
        }})
    except Exception as e:
        results.append({{
            {q}name{q}: name,
            {q}correct{q}: False,
            {q}error{q}: str(e),
        }})
        all_correct = False
speedup = 0.0
if total_time_ms > 0 and ref_total_time_ms > 0:
    speedup = ref_total_time_ms / total_time_ms
passed = sum(1 for r in results if r.get({q}correct{q}, False))
total = len(results)
print(json.dumps({{
    {q}success{q}: True,
    {q}all_correct{q}: all_correct,
    {q}passed{q}: passed,
    {q}total{q}: total,
    {q}speedup{q}: speedup,
    {q}results{q}: results,
}}))
'''


def _inline_eval_loop_script(
    run_benchmarks: bool,
    run_defensive: bool,
    quote_style: str = "'",
) -> str:
    assert quote_style in ("'", '"'), "quote_style must be single or double quote"
    q = quote_style
    defense_setup = _inline_defense_setup_script(run_defensive, quote_style)
    benchmark_timing = _inline_benchmark_timing_script(run_benchmarks, run_defensive, quote_style)
    results_tail = _inline_eval_results_script(quote_style)
    return f'''{defense_setup}results = []
all_correct = True
total_time_ms = 0.0
ref_total_time_ms = 0.0
for tc in test_cases:
    name = tc.pop({q}name{q}, {q}test{q})
    try:
        inputs = generate_input(**tc)
        with torch.no_grad():
            ref_out = ref_kernel(inputs)
            impl_out = custom_kernel(inputs)
        if isinstance(ref_out, torch.Tensor):
            correct = torch.allclose(ref_out, impl_out, rtol=1e-3, atol=1e-3)
        else:
            correct = ref_out == impl_out
        if not correct:
            all_correct = False
{benchmark_timing}{results_tail}'''


def _modal_sandbox_file_write(
    impl_code_b64: str,
    ref_code_b64: str,
    test_cases_b64: str,
    run_defensive: bool,
    defense_code_b64: str | None,
) -> str:
    assert impl_code_b64, "impl_code_b64 must be non-empty"
    assert ref_code_b64, "ref_code_b64 must be non-empty"
    defense_block = ""
    if run_defensive and defense_code_b64 and defense_code_b64 != "None":
        defense_block = f'''
        if {run_defensive} and "{defense_code_b64}" and "{defense_code_b64}" != "None":
            proc = sandbox.exec("python", "-c", f"""
import base64
with open('/workspace/defense.py', 'w') as f:
    f.write(base64.b64decode('{defense_code_b64}').decode())
print('Defense module written')
""")
            proc.wait()
            if proc.returncode != 0:
                print(json.dumps({{"error": f"Failed to write defense module: {{proc.stderr.read()}}"}}))
                return'''
    return f'''
        sandbox.exec("mkdir", "-p", "/workspace").wait()
        proc = sandbox.exec("python", "-c", f"""
import base64
with open('/workspace/kernel.py', 'w') as f:
    f.write(base64.b64decode('{impl_code_b64}').decode())
with open('/workspace/reference.py', 'w') as f:
    f.write(base64.b64decode('{ref_code_b64}').decode())
with open('/workspace/reference_kernel.py', 'w') as f:
    f.write(base64.b64decode('{ref_code_b64}').decode())
with open('/workspace/test_cases.json', 'w') as f:
    f.write(base64.b64decode('{test_cases_b64}').decode())
print('Files written')
""")
        proc.wait()
        if proc.returncode != 0:
            print(json.dumps({{"error": f"Failed to write files: {{proc.stderr.read()}}"}}))
            return
{defense_block}'''


def _build_modal_sandbox_script(
    target: ModalTarget,
    impl_code_b64: str,
    ref_code_b64: str,
    test_cases_b64: str,
    run_benchmarks: bool,
    run_defensive: bool,
    defense_code_b64: str | None = None,
) -> str:
    assert impl_code_b64, "impl_code_b64 must be non-empty"
    assert ref_code_b64, "ref_code_b64 must be non-empty"
    gpu_type = target.gpu_type
    torch_index, cuda_arch_list = _modal_torch_config(gpu_type)
    image_setup = _modal_image_setup(torch_index, cuda_arch_list)
    file_write = _modal_sandbox_file_write(
        impl_code_b64, ref_code_b64, test_cases_b64, run_defensive, defense_code_b64,
    )
    eval_loop = _inline_eval_loop_script(run_benchmarks, run_defensive, quote_style="'")
    return f'''
import asyncio
import base64
import json
import sys
import modal
async def run_eval():
    app = modal.App.lookup("wafer-evaluate", create_if_missing=True)
{image_setup}
    sandbox = modal.Sandbox.create(
        app=app, image=image, gpu="{gpu_type}", timeout={target.timeout_seconds},
    )
    try:
{file_write}
        eval_script = """{_inline_eval_load_preamble("'")}{eval_loop}"""
        proc = sandbox.exec(
            "python", "-c", eval_script, timeout={target.timeout_seconds},
        )
        proc.wait()
        stdout = proc.stdout.read()
        stderr = proc.stderr.read()
        if proc.returncode != 0:
            print(json.dumps({{"error": f"Eval failed: {{stderr or stdout}}"}}))
            return
        for line in reversed(stdout.strip().split("\\n")):
            if line.startswith("{{"):
                print(line, flush=True)
                return
        print(json.dumps({{"error": f"No result JSON in output: {{stdout[:500]}}"}}))
    finally:
        sandbox.terminate()
asyncio.run(run_eval())
'''


async def run_evaluate_modal(
    args: EvaluateArgs,
    target: ModalTarget,
) -> EvaluateResult:
    """Run evaluation on Modal sandbox.
    Creates a Modal sandbox, uploads files, runs evaluate, and parses results.
    Uses subprocess to isolate Modal's asyncio from trio.
    """
    import base64
    import subprocess
    print(f"Creating Modal sandbox ({target.gpu_type})...")
    impl_code_b64 = base64.b64encode(args.implementation.read_bytes()).decode()
    ref_code_b64 = base64.b64encode(args.reference.read_bytes()).decode()
    test_cases_b64 = base64.b64encode(args.test_cases.read_bytes()).decode()
    defense_code_b64 = _encode_defense_b64() if args.defensive else None
    script = _build_modal_sandbox_script(
        target=target, impl_code_b64=impl_code_b64,
        ref_code_b64=ref_code_b64, test_cases_b64=test_cases_b64,
        run_benchmarks=args.benchmark, run_defensive=args.defensive,
        defense_code_b64=defense_code_b64,
    )
    try:
        stdout, stderr, returncode = await _run_modal_subprocess(
            script, target.timeout_seconds,
        )
    except subprocess.TimeoutExpired:
        return _fail_eval(f"Modal evaluation timed out after {target.timeout_seconds}s")
    except Exception as e:
        return _fail_eval(f"Failed to run Modal sandbox: {e}")
    if returncode != 0:
        return _fail_eval(f"Modal sandbox failed (exit {returncode}): {stderr or stdout}")
    result_json = _find_json_in_output(stdout)
    if result_json is None:
        return _fail_eval(f"No valid JSON result in output: {stdout[:500]}")
    return _parse_modal_eval_result(result_json)


def _inline_workspace_file_setup(
    impl_b64: str,
    ref_b64: str,
    tests_b64: str,
    run_defensive: bool,
    defense_b64: str,
) -> str:
    assert impl_b64, "impl_b64 must be non-empty"
    assert ref_b64, "ref_b64 must be non-empty"
    return f'''
import base64
import json
import sys
import os
import importlib.util
impl_code = base64.b64decode("{impl_b64}").decode()
ref_code = base64.b64decode("{ref_b64}").decode()
test_cases = json.loads(base64.b64decode("{tests_b64}").decode())
with open("/tmp/kernel.py", "w") as f:
    f.write(impl_code)
with open("/tmp/reference.py", "w") as f:
    f.write(ref_code)
run_defensive = {run_defensive}
defense_b64 = "{defense_b64}"
if run_defensive and defense_b64 and defense_b64 != "None":
    defense_code = base64.b64decode(defense_b64).decode()
    with open("/tmp/defense.py", "w") as f:
        f.write(defense_code)
def load_fn(path, name):
    spec = importlib.util.spec_from_file_location("mod", path)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return getattr(mod, name)
custom_kernel = load_fn("/tmp/kernel.py", "custom_kernel")
ref_kernel = load_fn("/tmp/reference.py", "ref_kernel")
generate_input = load_fn("/tmp/reference.py", "generate_input")
import torch
'''


def _inline_workspace_defense_setup(
    run_defensive: bool,
    defense_b64: str,
) -> str:
    assert isinstance(run_defensive, bool), "run_defensive must be a bool"
    assert isinstance(defense_b64, str), "defense_b64 must be a string"
    return '''
defense = None
if run_defensive and defense_b64 and defense_b64 != "None":
    try:
        defense = load_fn("/tmp/defense.py", "run_all_defenses")
        time_with_defenses = load_fn("/tmp/defense.py", "time_execution_with_defenses")
        print("[Defense] Defense module loaded")
        def _wrap_for_defense(kernel):
            return lambda *args: kernel(args)
        custom_kernel_for_defense = _wrap_for_defense(custom_kernel)
        ref_kernel_for_defense = _wrap_for_defense(ref_kernel)
    except Exception as e:
        print(f"[Defense] Warning: Could not load defense module: {e}")
        defense = None
'''


def _build_workspace_eval_script(
    impl_code: str,
    ref_code: str,
    test_cases_json: str,
    run_benchmarks: bool,
    run_defensive: bool = False,
    defense_code: str | None = None,
) -> str:
    assert impl_code, "impl_code must be non-empty"
    assert ref_code, "ref_code must be non-empty"
    import base64
    impl_b64 = base64.b64encode(impl_code.encode()).decode()
    ref_b64 = base64.b64encode(ref_code.encode()).decode()
    tests_b64 = base64.b64encode(test_cases_json.encode()).decode()
    defense_b64 = base64.b64encode(defense_code.encode()).decode() if defense_code else ""
    file_setup = _inline_workspace_file_setup(
        impl_b64, ref_b64, tests_b64, run_defensive, defense_b64,
    )
    defense_setup = _inline_workspace_defense_setup(run_defensive, defense_b64)
    benchmark_timing = _inline_benchmark_timing_script(run_benchmarks, run_defensive, '"')
    results_tail = _inline_eval_results_script('"')
    return f'''{file_setup}{defense_setup}results = []
all_correct = True
total_time_ms = 0.0
ref_total_time_ms = 0.0
for tc in test_cases:
    name = tc.pop("name", "test")
    try:
        inputs = generate_input(**tc)
        with torch.no_grad():
            ref_out = ref_kernel(inputs)
            impl_out = custom_kernel(inputs)
        if isinstance(ref_out, torch.Tensor):
            correct = torch.allclose(ref_out, impl_out, rtol=1e-3, atol=1e-3)
        else:
            correct = ref_out == impl_out
        if not correct:
            all_correct = False
{benchmark_timing}{results_tail}'''


def _exec_workspace_with_capture(
    workspace_id: str,
    eval_cmd: str,
    timeout_seconds: int,
) -> tuple[int, str]:
    assert workspace_id, "workspace_id must be non-empty"
    assert eval_cmd, "eval_cmd must be non-empty"
    import io
    import sys

    from .workspaces import exec_command
    captured_output = io.StringIO()
    original_stdout = sys.stdout
    sys.stdout = captured_output
    try:
        exit_code = exec_command(
            workspace_id=workspace_id,
            command=eval_cmd,
            timeout_seconds=timeout_seconds,
        )
    finally:
        sys.stdout = original_stdout
    return exit_code, captured_output.getvalue()


def _parse_workspace_output(output: str, exit_code: int) -> EvaluateResult:
    assert isinstance(output, str), "output must be a string"
    assert isinstance(exit_code, int), "exit_code must be an integer"
    result_json = _find_json_in_output(output)
    if result_json is None:
        if exit_code == 0:
            return _success_eval(
                all_correct=True, correctness_score=1.0,
                geomean_speedup=0.0, passed_tests=0, total_tests=0,
            )
        return _fail_eval(f"Evaluation failed with exit code {exit_code}")
    return _parse_modal_eval_result(result_json)


async def run_evaluate_workspace(
    args: EvaluateArgs,
    target: WorkspaceTarget,
) -> EvaluateResult:
    """Run evaluation on wafer-api managed workspace.
    Uses inline evaluation (no file sync needed) via workspace exec.
    The eval script is passed as a Python command with base64-encoded files.
    """
    import trio
    print(f"Using workspace: {target.workspace_id}")
    impl_code = args.implementation.read_text()
    ref_code = args.reference.read_text()
    test_cases_json = args.test_cases.read_text()
    defense_code = None
    if args.defensive:
        defense_path = _get_defense_source_path()
        if defense_path.exists():
            defense_code = defense_path.read_text()
        else:
            print(f"Warning: defense.py not found at {defense_path}, falling back to basic defense")
    eval_script = _build_workspace_eval_script(
        impl_code=impl_code, ref_code=ref_code,
        test_cases_json=test_cases_json, run_benchmarks=args.benchmark,
        run_defensive=args.defensive, defense_code=defense_code,
    )
    eval_cmd = f"python -c {shlex.quote(eval_script)}"
    print("Running evaluation...")
    try:
        exit_code, output = await trio.to_thread.run_sync(
            lambda: _exec_workspace_with_capture(
                target.workspace_id, eval_cmd, target.timeout_seconds,
            )
        )
    except Exception as e:
        return _fail_eval(f"Execution failed: {e}")
    print(output)
    return _parse_workspace_output(output, exit_code)


async def run_evaluate_runpod(
    args: EvaluateArgs,
    target: RunPodTarget,
) -> EvaluateResult:
    """Run evaluation on RunPod target.
    Provisions a RunPod pod (or reuses existing), runs evaluation via SSH,
    then cleans up based on keep_alive setting.
    Sets up a Python venv with ROCm torch using uv, then runs evaluation.
    Args:
        args: Evaluate arguments
        target: RunPod target config
    Returns:
        Evaluation result
    """
    from wafer.core.async_ssh import AsyncSSHClient
    from wafer.core.targets.runpod import RunPodError, runpod_ssh_context
    REMOTE_WORKSPACE = "/tmp/wafer_eval"
    print(f"Provisioning RunPod ({target.gpu_type_id})...")
    try:
        async with runpod_ssh_context(target) as ssh_info:
            ssh_target = f"{ssh_info.user}@{ssh_info.host}:{ssh_info.port}"
            print(f"Connected to RunPod: {ssh_target}")
            async with AsyncSSHClient(ssh_target, target.ssh_key) as client:
                await _ensure_rsync(client)
                env_state, python_exe, err = await _setup_rocm_env(client, REMOTE_WORKSPACE)
                if err:
                    return _fail_eval(err)
                try:
                    upload_err = await _upload_wafer_ai_source(
                        client, REMOTE_WORKSPACE, target.name, "runpod"
                    )
                    if upload_err:
                        return _fail_eval(upload_err)
                except Exception as e:
                    return _fail_eval(f"Failed to upload wafer-ai: {e}")
                gpu_id = args.gpu_id if args.gpu_id is not None else target.gpu_ids[0]
                print(f"Using GPU {gpu_id}...")
                return await _run_eval_on_cloud_target(
                    args, client, env_state, python_exe, gpu_id,
                    REMOTE_WORKSPACE, "HIP_VISIBLE_DEVICES", target.eval_timeout,
                )
    except RunPodError as e:
        return _fail_eval(f"RunPod error: {e}")


async def run_evaluate_digitalocean(
    args: EvaluateArgs,
    target: DigitalOceanTarget,
) -> EvaluateResult:
    """Run evaluation on DigitalOcean target.
    Provisions a DigitalOcean droplet (or reuses existing), bootstraps Python
    environment with uv, runs evaluation via SSH, then cleans up based on
    keep_alive setting.
    Args:
        args: Evaluate arguments
        target: DigitalOcean target config
    Returns:
        Evaluation result
    """
    import trio_asyncio

    from wafer.core.async_ssh import AsyncSSHClient
    from wafer.core.targets.digitalocean import DigitalOceanError, digitalocean_ssh_context
    REMOTE_WORKSPACE = "/tmp/wafer_eval"
    print(f"Provisioning DigitalOcean droplet ({target.size_slug})...")
    try:
        async with digitalocean_ssh_context(target) as ssh_info:
            ssh_target = f"{ssh_info.user}@{ssh_info.host}:{ssh_info.port}"
            print(f"Connected to DigitalOcean: {ssh_target}")
            async with trio_asyncio.open_loop():
                async with AsyncSSHClient(ssh_target, target.ssh_key) as client:
                    await _ensure_rsync_and_ninja(client)
                    env_state, python_exe, err = await _setup_rocm_env(
                        client, REMOTE_WORKSPACE, "3.10"
                    )
                    if err:
                        return _fail_eval(err)
                    try:
                        upload_err = await _upload_wafer_ai_source(
                            client, REMOTE_WORKSPACE, target.name, "digitalocean",
                            use_sftp=True,
                        )
                        if upload_err:
                            return _fail_eval(upload_err)
                    except Exception as e:
                        return _fail_eval(f"Failed to upload wafer-ai: {e}")
                    gpu_id = args.gpu_id if args.gpu_id is not None else target.gpu_ids[0]
                    print(f"Using GPU {gpu_id}...")
                    return await _run_eval_on_cloud_target(
                        args, client, env_state, python_exe, gpu_id,
                        REMOTE_WORKSPACE, "HIP_VISIBLE_DEVICES", target.eval_timeout,
                    )
    except DigitalOceanError as e:
        return _fail_eval(f"DigitalOcean error: {e}")


async def run_evaluate(args: EvaluateArgs) -> EvaluateResult:
    """Run evaluation on configured target."""
    err = _validate_files(args)
    if err:
        return _fail_eval(err)
    target, target_name, err = _resolve_target(args.target_name)
    if err:
        return _fail_eval(err)
    print(f"Using target: {target_name}")
    if isinstance(target, LocalTarget):
        return await run_evaluate_local(args, target)
    elif isinstance(target, BaremetalTarget | VMTarget):
        return await run_evaluate_ssh(args, target)
    elif isinstance(target, ModalTarget):
        return await run_evaluate_modal(args, target)
    elif isinstance(target, WorkspaceTarget):
        return await run_evaluate_workspace(args, target)
    elif isinstance(target, RunPodTarget):
        return await run_evaluate_runpod(args, target)
    elif isinstance(target, DigitalOceanTarget):
        return await run_evaluate_digitalocean(args, target)
    else:
        return _fail_eval(f"Unknown target type: {type(target)}")


# =============================================================================
# KernelBench Format Evaluation
# =============================================================================
# Inline evaluation script for KernelBench format
# This runs inside the Docker container on the remote GPU
KERNELBENCH_EVAL_SCRIPT = """
import gc
import json
import os
import sys
import time
import torch
import torch.nn as nn
from pathlib import Path
# This prevents stale cached extensions from being loaded when the pod is reused.
# Without this, if a kernel is modified but uses the same extension name,
# PyTorch would load the old cached .so instead of recompiling.
# We use a UUID-based directory instead of clearing the cache to avoid race conditions
# with other processes that might be using the cache.
import uuid
unique_cache_dir = f"/tmp/torch_extensions_{uuid.uuid4().hex[:8]}"
os.environ["TORCH_EXTENSIONS_DIR"] = unique_cache_dir
print(f"[KernelBench] Using unique extension cache: {unique_cache_dir}")
# Clear any stale GPU memory from previous runs at startup
# NOTE: empty_cache only frees memory from THIS process's PyTorch allocator.
# It won't free memory from dead/zombie processes - rocm-smi --showpids can show
# PIDs that no longer exist but still hold GPU memory. Those require a GPU reset
# (rocm-smi --gpureset) to fully clear. TODO: detect and warn about orphaned memory.
if torch.cuda.is_available():
    gc.collect()
    torch.cuda.empty_cache()
    torch.cuda.reset_peak_memory_stats()
def _calculate_timing_stats(times: list[float]) -> dict:
    '''Calculate median and IQR from timing samples.
    Returns dict with median, iqr_low (25th percentile), iqr_high (75th percentile),
    mean, min, max, and std.
    '''
    import statistics
    if not times:
        return {"median": 0, "iqr_low": 0, "iqr_high": 0, "mean": 0, "min": 0, "max": 0, "std": 0}
    sorted_times = sorted(times)
    n = len(sorted_times)
    # Median
    median = statistics.median(sorted_times)
    # Quartiles (25th and 75th percentile)
    # For small samples, use simple interpolation
    q1_idx = (n - 1) * 0.25
    q3_idx = (n - 1) * 0.75
    q1_low = int(q1_idx)
    q1_frac = q1_idx - q1_low
    iqr_low = sorted_times[q1_low] * (1 - q1_frac) + sorted_times[min(q1_low + 1, n - 1)] * q1_frac
    q3_low = int(q3_idx)
    q3_frac = q3_idx - q3_low
    iqr_high = sorted_times[q3_low] * (1 - q3_frac) + sorted_times[min(q3_low + 1, n - 1)] * q3_frac
    return {
        "median": median,
        "iqr_low": iqr_low,
        "iqr_high": iqr_high,
        "mean": statistics.mean(sorted_times),
        "min": min(sorted_times),
        "max": max(sorted_times),
        "std": statistics.stdev(sorted_times) if n > 1 else 0,
    }
def run_profiling(model, inputs, name, output_dir):
    '''Run torch.profiler and return summary stats.'''
    from torch.profiler import profile, ProfilerActivity

    activities = [ProfilerActivity.CPU]
    if torch.cuda.is_available():
        activities.append(ProfilerActivity.CUDA)
    # Warmup
    for _ in range(3):
        with torch.no_grad():
            _ = model(*inputs)
    torch.cuda.synchronize()
    # Profile
    with profile(
        activities=activities,
        record_shapes=True,
        with_stack=False,
        profile_memory=True,
    ) as prof:
        with torch.no_grad():
            _ = model(*inputs)
        torch.cuda.synchronize()
    key_averages = prof.key_averages()

    def get_gpu_time(e):
        # Try different attributes for GPU time
        if hasattr(e, 'cuda_time_total'):
            return e.cuda_time_total
        if hasattr(e, 'device_time_total'):
            return e.device_time_total
        if hasattr(e, 'self_cuda_time_total'):
            return e.self_cuda_time_total
        return 0
    gpu_events = [e for e in key_averages if get_gpu_time(e) > 0]
    gpu_events.sort(key=lambda e: get_gpu_time(e), reverse=True)
    stats = {
        "name": name,
        "total_gpu_time_ms": sum(get_gpu_time(e) for e in gpu_events) / 1000,
        "total_cpu_time_ms": sum(e.cpu_time_total for e in key_averages) / 1000,
        "num_gpu_kernels": len(gpu_events),
        "top_kernels": [],
    }
    # Top 5 kernels by GPU time
    for e in gpu_events[:5]:
        stats["top_kernels"].append({
            "name": e.key,
            "gpu_time_ms": get_gpu_time(e) / 1000,
            "cpu_time_ms": e.cpu_time_total / 1000,
            "calls": e.count,
        })
    # Save trace for visualization
    trace_path = Path(output_dir) / f"{name}_trace.json"
    prof.export_chrome_trace(str(trace_path))
    stats["trace_file"] = str(trace_path)
    return stats
def validate_custom_inputs(original_inputs, custom_inputs):
    '''Validate that custom inputs match the expected signature.
    Returns (is_valid, error_message).
    '''
    if len(original_inputs) != len(custom_inputs):
        return False, f"get_inputs() must return {len(original_inputs)} tensors, got {len(custom_inputs)}"
    for i, (orig, cust) in enumerate(zip(original_inputs, custom_inputs)):
        if not isinstance(cust, torch.Tensor):
            if not isinstance(orig, torch.Tensor):
                continue  # Both non-tensor, ok
            return False, f"Input {i}: expected Tensor, got {type(cust).__name__}"
        if not isinstance(orig, torch.Tensor):
            return False, f"Input {i}: expected {type(orig).__name__}, got Tensor"
        if orig.dtype != cust.dtype:
            return False, f"Input {i}: dtype mismatch - expected {orig.dtype}, got {cust.dtype}"
        if orig.dim() != cust.dim():
            return False, f"Input {i}: dimension mismatch - expected {orig.dim()}D, got {cust.dim()}D"
    return True, None
def analyze_diff(ref_output, new_output, rtol=1e-3, atol=1e-3, max_samples=5):
    '''Analyze differences between reference and implementation outputs.
    Returns a dict with detailed diff information.
    '''
    diff = (ref_output - new_output).abs()
    threshold = atol + rtol * ref_output.abs()
    wrong_mask = diff > threshold
    total_elements = ref_output.numel()
    wrong_count = wrong_mask.sum().item()
    # Basic stats
    max_diff = diff.max().item()
    max_diff_idx = tuple(torch.unravel_index(diff.argmax(), diff.shape))
    max_diff_idx = tuple(int(i) for i in max_diff_idx)  # Convert to Python ints
    # Relative error (avoid div by zero)
    ref_abs = ref_output.abs()
    nonzero_mask = ref_abs > 1e-8
    if nonzero_mask.any():
        rel_error = diff[nonzero_mask] / ref_abs[nonzero_mask]
        max_rel_error = rel_error.max().item()
        mean_rel_error = rel_error.mean().item()
    else:
        max_rel_error = float('inf') if max_diff > 0 else 0.0
        mean_rel_error = max_rel_error
    # Error histogram (buckets: <1e-6, 1e-6 to 1e-4, 1e-4 to 1e-2, 1e-2 to 1, >1)
    histogram = {
        '<1e-6': int((diff < 1e-6).sum().item()),
        '1e-6 to 1e-4': int(((diff >= 1e-6) & (diff < 1e-4)).sum().item()),
        '1e-4 to 1e-2': int(((diff >= 1e-4) & (diff < 1e-2)).sum().item()),
        '1e-2 to 1': int(((diff >= 1e-2) & (diff < 1)).sum().item()),
        '>1': int((diff >= 1).sum().item()),
    }
    result = {
        'max_diff': max_diff,
        'max_diff_idx': max_diff_idx,
        'mean_diff': diff.mean().item(),
        'max_rel_error': max_rel_error,
        'mean_rel_error': mean_rel_error,
        'total_elements': total_elements,
        'wrong_count': int(wrong_count),
        'wrong_pct': 100.0 * wrong_count / total_elements,
        'histogram': histogram,
        'samples': [],
    }
    if wrong_count > 0:
        wrong_indices = torch.nonzero(wrong_mask, as_tuple=False)
        # Take first N samples
        num_samples = min(max_samples, len(wrong_indices))
        for i in range(num_samples):
            idx = tuple(wrong_indices[i].tolist())
            ref_val = ref_output[idx].item()
            new_val = new_output[idx].item()
            diff_val = diff[idx].item()
            result['samples'].append({
                'index': idx,
                'ref': ref_val,
                'impl': new_val,
                'diff': diff_val,
            })
        # Try to detect pattern
        if wrong_count >= total_elements * 0.99:
            result['pattern'] = 'all_wrong'
        elif wrong_count < total_elements * 0.01:
            shape = ref_output.shape
            boundary_count = 0
            for idx in wrong_indices[:min(100, len(wrong_indices))]:
                idx_list = idx.tolist()
                is_boundary = any(i == 0 or i == s - 1 for i, s in zip(idx_list, shape))
                if is_boundary:
                    boundary_count += 1
            if boundary_count > len(wrong_indices[:100]) * 0.8:
                result['pattern'] = 'boundary_issue'
            else:
                result['pattern'] = 'scattered'
        else:
            result['pattern'] = 'partial'
    return result
def print_diff_analysis(analysis):
    '''Print a human-readable diff analysis.'''
    print(f"[KernelBench] Diff analysis:")
    # Max diff with location
    idx_str = ','.join(str(i) for i in analysis['max_diff_idx'])
    print(f"   Max diff: {analysis['max_diff']:.6f} at index [{idx_str}]")
    print(f"   Mean diff: {analysis['mean_diff']:.6f}")
    # Relative errors
    print(f"   Max relative error: {analysis['max_rel_error']:.2%}, Mean: {analysis['mean_rel_error']:.2%}")
    # Wrong count
    print(f"   Wrong elements: {analysis['wrong_count']:,} / {analysis['total_elements']:,} ({analysis['wrong_pct']:.2f}%)")
    # Histogram
    hist = analysis['histogram']
    print(f"   Error distribution: <1e-6: {hist['<1e-6']:,} | 1e-6~1e-4: {hist['1e-6 to 1e-4']:,} | 1e-4~1e-2: {hist['1e-4 to 1e-2']:,} | 1e-2~1: {hist['1e-2 to 1']:,} | >1: {hist['>1']:,}")
    if 'pattern' in analysis:
        pattern_desc = {
            'all_wrong': 'ALL elements wrong - likely algorithmic error or wrong weights',
            'boundary_issue': 'Mostly BOUNDARY elements wrong - check edge handling',
            'scattered': 'SCATTERED failures - numerical precision issue?',
            'partial': 'PARTIAL failures - check specific conditions',
        }
        print(f"   Pattern: {pattern_desc.get(analysis['pattern'], analysis['pattern'])}")
    if analysis['samples']:
        print(f"   Sample failures:")
        for s in analysis['samples']:
            idx_str = ','.join(str(i) for i in s['index'])
            print(f"      [{idx_str}]: ref={s['ref']:.6f} impl={s['impl']:.6f} (diff={s['diff']:.6f})")
def main():
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument("--impl", required=True)
    parser.add_argument("--reference", required=True)
    parser.add_argument("--inputs", help="Custom inputs file to override get_inputs()/get_init_inputs()")
    parser.add_argument("--benchmark", action="store_true")
    parser.add_argument("--profile", action="store_true")
    parser.add_argument("--defensive", action="store_true", help="Run full defense checks against reward hacking")
    parser.add_argument("--defense-module", help="Path to defense.py module")
    parser.add_argument("--seed", type=int, default=42, help="Random seed for reproducibility")
    parser.add_argument("--num-correct-trials", type=int, default=3)
    parser.add_argument("--num-perf-trials", type=int, default=10)
    parser.add_argument("--output", required=True)
    parser.add_argument("--stages", default="compile,correctness",
                        help="Comma-separated stages: compile, correctness, benchmark, defense")
    args = parser.parse_args()
    stages = set(args.stages.split(","))
    run_compile = "compile" in stages
    run_correctness = "correctness" in stages
    run_benchmark = "benchmark" in stages or args.benchmark
    run_defense = "defense" in stages or args.defensive
    print(f"[KernelBench] Stages: {args.stages}")
    defense_module = None
    if args.defensive and args.defense_module:
        try:
            import importlib.util
            defense_spec = importlib.util.spec_from_file_location("defense", args.defense_module)
            defense_module = importlib.util.module_from_spec(defense_spec)
            defense_spec.loader.exec_module(defense_module)
            print("[KernelBench] Defense module loaded")
        except Exception as e:
            print(f"[KernelBench] Warning: Could not load defense module: {e}")
    output_dir = Path(args.output).parent
    profile_dir = output_dir / "profiles"
    if args.profile:
        profile_dir.mkdir(exist_ok=True)
    results = {
        "compiled": False,
        "correct": False,
        "speedup": None,
        "runtime_ms": None,
        "reference_runtime_ms": None,
        "error": None,
    }
    try:
        import importlib.util
        ref_spec = importlib.util.spec_from_file_location("reference", args.reference)
        ref_module = importlib.util.module_from_spec(ref_spec)
        ref_spec.loader.exec_module(ref_module)
        Model = ref_module.Model
        get_inputs = ref_module.get_inputs
        get_init_inputs = ref_module.get_init_inputs
        if args.inputs:
            inputs_spec = importlib.util.spec_from_file_location("custom_inputs", args.inputs)
            inputs_module = importlib.util.module_from_spec(inputs_spec)
            inputs_spec.loader.exec_module(inputs_module)
            # Validate custom inputs match expected signature
            original_inputs = get_inputs()
            custom_get_inputs = inputs_module.get_inputs
            custom_inputs = custom_get_inputs()
            is_valid, error_msg = validate_custom_inputs(original_inputs, custom_inputs)
            if not is_valid:
                print(f"[KernelBench] Custom inputs validation failed: {error_msg}")
                results["error"] = f"Custom inputs validation failed: {error_msg}"
                raise ValueError(error_msg)
            # Override get_inputs (and optionally get_init_inputs)
            get_inputs = custom_get_inputs
            if hasattr(inputs_module, 'get_init_inputs'):
                get_init_inputs = inputs_module.get_init_inputs
            # Show what changed
            orig_shapes = [tuple(t.shape) if hasattr(t, 'shape') else type(t).__name__ for t in original_inputs]
            cust_shapes = [tuple(t.shape) if hasattr(t, 'shape') else type(t).__name__ for t in custom_inputs]
            print(f"[KernelBench] Using custom inputs: {orig_shapes} -> {cust_shapes}")
        impl_spec = importlib.util.spec_from_file_location("implementation", args.impl)
        impl_module = importlib.util.module_from_spec(impl_spec)
        impl_spec.loader.exec_module(impl_module)
        ModelNew = impl_module.ModelNew
        results["compiled"] = True
        print("[KernelBench] Modules loaded successfully")
        # Instantiate models with synchronized seeds for reproducible weights
        # (matches upstream KernelBench behavior in src/eval.py)
        seed = args.seed
        init_inputs = get_init_inputs()
        with torch.no_grad():
            torch.manual_seed(seed)
            torch.cuda.manual_seed(seed)
            ref_model = Model(*init_inputs).cuda().eval()
            torch.manual_seed(seed)
            torch.cuda.manual_seed(seed)
            new_model = ModelNew(*init_inputs).cuda().eval()
        print(f"[KernelBench] Models instantiated (seed={seed})")
        # Run correctness trials (if stage enabled)
        all_correct = True
        if not run_correctness:
            print("[KernelBench] Skipping correctness (not in stages)")
            results["correct"] = None  # Unknown - not checked
        else:
            for trial in range(args.num_correct_trials):
                inputs = get_inputs()
                inputs = [x.cuda() if isinstance(x, torch.Tensor) else x for x in inputs]
                with torch.no_grad():
                    ref_output = ref_model(*inputs)
                    new_output = new_model(*inputs)
                # Compare outputs
                if isinstance(ref_output, torch.Tensor):
                    if not torch.allclose(ref_output, new_output, rtol=1e-3, atol=1e-3):
                        all_correct = False
                        analysis = analyze_diff(ref_output, new_output)
                        results["error"] = f"Correctness failed on trial {trial+1}: max diff = {analysis['max_diff']}"
                        results["diff_analysis"] = analysis
                        print_diff_analysis(analysis)
                        # Save tensors for debugging
                        debug_dir = output_dir / "debug"
                        debug_dir.mkdir(exist_ok=True)
                        torch.save(ref_output.cpu(), debug_dir / "ref_output.pt")
                        torch.save(new_output.cpu(), debug_dir / "impl_output.pt")
                        torch.save(inputs[0].cpu() if inputs else None, debug_dir / "input.pt")
                        print(f"[KernelBench] Debug tensors saved to: {debug_dir}/")
                        break
                else:
                    for i, (r, n) in enumerate(zip(ref_output, new_output)):
                        if isinstance(r, torch.Tensor):
                            if not torch.allclose(r, n, rtol=1e-3, atol=1e-3):
                                all_correct = False
                                analysis = analyze_diff(r, n)
                                results["error"] = f"Correctness failed on trial {trial+1}, output {i}: max diff = {analysis['max_diff']}"
                                results["diff_analysis"] = analysis
                                print_diff_analysis(analysis)
                                # Save tensors for debugging
                                debug_dir = output_dir / "debug"
                                debug_dir.mkdir(exist_ok=True)
                                torch.save(r.cpu(), debug_dir / f"ref_output_{i}.pt")
                                torch.save(n.cpu(), debug_dir / f"impl_output_{i}.pt")
                                print(f"[KernelBench] Debug tensors saved to: {debug_dir}/")
                                break
                    if not all_correct:
                        break
            results["correct"] = all_correct
            print(f"[KernelBench] Correctness: {all_correct}")
        # Run benchmark if stage enabled (and correctness passed or skipped)
        should_benchmark = run_benchmark and (all_correct or not run_correctness)
        if should_benchmark:
            print("[KernelBench] Running benchmarks...")
            inputs = get_inputs()
            inputs = [x.cuda() if isinstance(x, torch.Tensor) else x for x in inputs]
            if run_defense and defense_module is not None:
                print("[KernelBench] Running defense checks on implementation...")
                run_all_defenses = defense_module.run_all_defenses
                time_with_defenses = defense_module.time_execution_with_defenses
                # Run defense checks on implementation
                all_passed, defense_results, _ = run_all_defenses(
                    lambda *x: new_model(*x),
                    *inputs,
                )
                results["defense_results"] = {
                    name: {"passed": passed, "message": msg}
                    for name, passed, msg in defense_results
                }
                if not all_passed:
                    failed = [name for name, passed, _ in defense_results if not passed]
                    results["error"] = f"Defense checks failed: {failed}"
                    print(f"[KernelBench] Defense checks FAILED: {failed}")
                    for name, passed, msg in defense_results:
                        status = "PASS" if passed else "FAIL"
                        print(f"   [{status}] {name}: {msg}")
                else:
                    print("[KernelBench] All defense checks passed")
                    # Time with defensive timing
                    impl_times, _ = time_with_defenses(
                        lambda: new_model(*inputs),
                        [],
                        num_warmup=5,
                        num_trials=args.num_perf_trials,
                        verbose=False,
                        run_defenses=False,  # Already ran above
                    )
                    new_stats = _calculate_timing_stats(impl_times)
                    results["runtime_ms"] = new_stats["median"]
                    results["runtime_stats"] = new_stats
                    # Reference timing
                    ref_times, _ = time_with_defenses(
                        lambda: ref_model(*inputs),
                        [],
                        num_warmup=5,
                        num_trials=args.num_perf_trials,
                        verbose=False,
                        run_defenses=False,
                    )
                    ref_stats = _calculate_timing_stats(ref_times)
                    results["reference_runtime_ms"] = ref_stats["median"]
                    results["reference_runtime_stats"] = ref_stats
                    results["speedup"] = ref_stats["median"] / new_stats["median"] if new_stats["median"] > 0 else 0
                    print(f"[KernelBench] New: {new_stats['median']:.3f}ms (IQR: {new_stats['iqr_low']:.3f}-{new_stats['iqr_high']:.3f}), Ref: {ref_stats['median']:.3f}ms (IQR: {ref_stats['iqr_low']:.3f}-{ref_stats['iqr_high']:.3f}), Speedup: {results['speedup']:.2f}x")
            else:
                # Standard timing without full defenses
                # Warmup BOTH models before benchmarking either
                # This ensures consistent GPU state and avoids MIOpen cache effects
                # that cause variance when warming up models sequentially
                for _ in range(5):
                    with torch.no_grad():
                        _ = new_model(*inputs)
                        _ = ref_model(*inputs)
                torch.cuda.synchronize()
                # Benchmark new model
                start = torch.cuda.Event(enable_timing=True)
                end = torch.cuda.Event(enable_timing=True)
                new_times = []
                for _ in range(args.num_perf_trials):
                    start.record()
                    with torch.no_grad():
                        _ = new_model(*inputs)
                    end.record()
                    torch.cuda.synchronize()
                    new_times.append(start.elapsed_time(end))
                new_stats = _calculate_timing_stats(new_times)
                results["runtime_ms"] = new_stats["median"]
                results["runtime_stats"] = new_stats
                # Benchmark reference model
                ref_times = []
                for _ in range(args.num_perf_trials):
                    start.record()
                    with torch.no_grad():
                        _ = ref_model(*inputs)
                    end.record()
                    torch.cuda.synchronize()
                    ref_times.append(start.elapsed_time(end))
                ref_stats = _calculate_timing_stats(ref_times)
                results["reference_runtime_ms"] = ref_stats["median"]
                results["reference_runtime_stats"] = ref_stats
                results["speedup"] = ref_stats["median"] / new_stats["median"] if new_stats["median"] > 0 else 0
                print(f"[KernelBench] New: {new_stats['median']:.3f}ms (IQR: {new_stats['iqr_low']:.3f}-{new_stats['iqr_high']:.3f}), Ref: {ref_stats['median']:.3f}ms (IQR: {ref_stats['iqr_low']:.3f}-{ref_stats['iqr_high']:.3f}), Speedup: {results['speedup']:.2f}x")
        # Run profiling if requested and correctness passed
        if args.profile and all_correct:
            print("[KernelBench] Running profiler...")
            inputs = get_inputs()
            inputs = [x.cuda() if isinstance(x, torch.Tensor) else x for x in inputs]
            try:
                # Profile implementation
                impl_stats = run_profiling(new_model, inputs, "implementation", str(profile_dir))
                results["profile_impl"] = impl_stats
                print(f"[KernelBench] Implementation profile:")
                print(f"   Total GPU time: {impl_stats['total_gpu_time_ms']:.3f}ms")
                print(f"   Kernels launched: {impl_stats['num_gpu_kernels']}")
                if impl_stats['top_kernels']:
                    print(f"   Top kernel: {impl_stats['top_kernels'][0]['name'][:60]}...")
                    print(f"              {impl_stats['top_kernels'][0]['gpu_time_ms']:.3f}ms")
                # Profile reference
                ref_stats = run_profiling(ref_model, inputs, "reference", str(profile_dir))
                results["profile_ref"] = ref_stats
                print(f"[KernelBench] Reference profile:")
                print(f"   Total GPU time: {ref_stats['total_gpu_time_ms']:.3f}ms")
                print(f"   Kernels launched: {ref_stats['num_gpu_kernels']}")
                if ref_stats['top_kernels']:
                    print(f"   Top kernel: {ref_stats['top_kernels'][0]['name'][:60]}...")
                    print(f"              {ref_stats['top_kernels'][0]['gpu_time_ms']:.3f}ms")
                print(f"[KernelBench] Profile traces saved to: {profile_dir}/")
            except Exception as prof_err:
                print(f"[KernelBench] Profiling failed: {prof_err}")
                results["profile_error"] = str(prof_err)
    except Exception as e:
        import traceback
        results["error"] = f"{type(e).__name__}: {e}\\n{traceback.format_exc()}"
        print(f"[KernelBench] Error: {results['error']}")
    # Write results
    with open(args.output, "w") as f:
        json.dump(results, f, indent=2)
    print(f"[KernelBench] Results written to {args.output}")
    # Cleanup GPU memory
    try:
        del ref_model, new_model
    except NameError:
        pass
    import gc
    gc.collect()
    if torch.cuda.is_available():
        torch.cuda.empty_cache()
if __name__ == "__main__":
    main()
"""


def _validate_kernelbench_files(args: KernelBenchEvaluateArgs) -> str | None:
    """Validate that KernelBench input files exist and have expected signatures.
    Returns:
        Error message if validation fails, None if all valid
    """
    if not args.implementation.exists():
        return f"Implementation file not found: {args.implementation}"
    if not args.reference.exists():
        return f"Reference file not found: {args.reference}"
    # Validate implementation has ModelNew class
    impl_missing = _check_python_file_has(args.implementation, "ModelNew")
    if impl_missing:
        has_custom_kernel = not _check_python_file_has(args.implementation, "custom_kernel")
        if has_custom_kernel:
            return (
                f"Implementation file missing 'ModelNew' class: {args.implementation}\n"
                "Hint: This looks like functional format. Use 'wafer tool eval gpumode' instead:\n"
                f"  wafer tool eval gpumode --impl {args.implementation} --reference <ref.py> --test-cases <tests.json>"
            )
        return (
            f"Implementation file missing 'ModelNew' class: {args.implementation}\n"
            "  KernelBench format requires a 'class ModelNew(nn.Module)' definition"
        )
    # Validate reference has Model, get_inputs, get_init_inputs
    ref_missing = _check_python_file_has(args.reference, "Model", "get_inputs", "get_init_inputs")
    if ref_missing:
        has_functional = not _check_python_file_has(args.reference, "ref_kernel", "generate_input")
        if has_functional:
            return (
                f"Reference file missing required definitions: {', '.join(ref_missing)}\n"
                "Hint: This looks like functional format. Use 'wafer tool eval gpumode' instead:\n"
                f"  wafer tool eval gpumode --impl <impl.py> --reference {args.reference} --test-cases <tests.json>"
            )
        return (
            f"Reference file missing required definitions: {', '.join(ref_missing)}\n"
            f"  File: {args.reference}\n"
            "  KernelBench format requires: 'class Model', 'get_inputs()', 'get_init_inputs()'"
        )
    # Static kernel validation if backend specified
    if args.backend:
        from wafer.core.utils.kernel_utils.static_checker import validate_kernel_static
        code = args.implementation.read_text()
        valid, errors, warnings = validate_kernel_static(code, backend=args.backend)
        # Print warnings (don't fail)
        for warning in warnings:
            logger.warning(f"Static check warning: {warning}")
        # Fail on errors
        if not valid:
            error_list = "\n  - ".join(errors)
            return (
                f"Static kernel validation failed for backend '{args.backend}':\n"
                f"  - {error_list}\n\n"
                f"The implementation must use {args.backend.upper()} kernel primitives.\n"
                "See KernelBench documentation for valid kernel patterns."
            )
    return None


def _modal_cutlass_install_steps() -> str:
    return """
        .run_commands([
            "git clone --depth 1 https://github.com/NVIDIA/cutlass.git /opt/cutlass",
            "ls -la /opt/cutlass/include/cutlass/util/ | head -5",
            "ln -sf /opt/cutlass/include/cute /usr/local/cuda/include/cute",
            "ln -sf /opt/cutlass/include/cutlass /usr/local/cuda/include/cutlass",
        ])
        .pip_install(
            "nvidia-cutlass-dsl",
            index_url="https://pypi.nvidia.com",
            extra_index_url="https://pypi.org/simple",
        )
    """


def _modal_kernelbench_file_writes(
    impl_code_b64: str,
    ref_code_b64: str,
    eval_script_b64: str,
    run_defensive: bool,
    defense_code_b64: str | None,
    inputs_code_b64: str | None,
) -> str:
    assert impl_code_b64, "impl_code_b64 must be non-empty"
    assert eval_script_b64, "eval_script_b64 must be non-empty"
    inputs_write = ""
    if inputs_code_b64:
        inputs_write = f'''
        proc = sandbox.exec("python", "-c", f"""
import base64
with open('/workspace/custom_inputs.py', 'w') as f:
    f.write(base64.b64decode('{inputs_code_b64}').decode())
print('Custom inputs written')
""")
        proc.wait()
'''
    defense_write = ""
    if run_defensive and defense_code_b64:
        defense_write = f'''
        proc = sandbox.exec("python", "-c", f"""
import base64
with open('/workspace/defense.py', 'w') as f:
    f.write(base64.b64decode('{defense_code_b64}').decode())
print('Defense module written')
""")
        proc.wait()
'''
    return f'''
        sandbox.exec("mkdir", "-p", "/workspace").wait()
        proc = sandbox.exec("python", "-c", f"""
import base64
with open('/workspace/implementation.py', 'w') as f:
    f.write(base64.b64decode('{impl_code_b64}').decode())
with open('/workspace/reference.py', 'w') as f:
    f.write(base64.b64decode('{ref_code_b64}').decode())
with open('/workspace/kernelbench_eval.py', 'w') as f:
    f.write(base64.b64decode('{eval_script_b64}').decode())
print('Files written')
""")
        proc.wait()
        if proc.returncode != 0:
            print(json.dumps({{"success": False, "error": f"Failed to write files: {{proc.stderr.read()}}"}}))
            return
{inputs_write}{defense_write}'''


def _modal_kernelbench_eval_cmd(
    seed: int,
    run_benchmarks: bool,
    run_defensive: bool,
    defense_code_b64: str | None,
    inputs_code_b64: str | None,
) -> str:
    assert isinstance(seed, int), "seed must be an integer"
    assert isinstance(run_benchmarks, bool), "run_benchmarks must be a bool"
    parts = [
        "python /workspace/kernelbench_eval.py",
        "--impl /workspace/implementation.py",
        "--reference /workspace/reference.py",
        "--output /workspace/results.json",
        f"--seed {seed}",
    ]
    if run_benchmarks:
        parts.append("--benchmark")
    if run_defensive and defense_code_b64:
        parts.append("--defensive")
        parts.append("--defense-module /workspace/defense.py")
    if inputs_code_b64:
        parts.append("--inputs /workspace/custom_inputs.py")
    return " ".join(parts)


def _modal_kernelbench_run_section(gpu_type: str, eval_cmd: str) -> str:
    assert gpu_type, "gpu_type must be non-empty"
    assert eval_cmd, "eval_cmd must be non-empty"
    return f'''
        print(f"Running KernelBench evaluation on {{'{gpu_type}'}}...")
        proc = sandbox.exec("bash", "-c", "{eval_cmd}")
        for line in proc.stdout:
            print(line, end="")
        for line in proc.stderr:
            print(line, end="", file=sys.stderr)
        proc.wait()
        if proc.returncode != 0:
            print(json.dumps({{"success": False, "error": f"Evaluation failed with exit code {{proc.returncode}}"}}))
            return
        result_proc = sandbox.exec("cat", "/workspace/results.json")
        result_data = result_proc.stdout.read()
        result_proc.wait()
        if result_data:
            results = json.loads(result_data)
            print("EVAL_RESULT_JSON:" + json.dumps(results))
        else:
            print(json.dumps({{"success": False, "error": "No results.json found"}}))
'''


def _build_modal_kernelbench_script(
    target: ModalTarget,
    impl_code_b64: str,
    ref_code_b64: str,
    eval_script_b64: str,
    run_benchmarks: bool,
    run_defensive: bool,
    defense_code_b64: str | None,
    seed: int,
    inputs_code_b64: str | None = None,
) -> str:
    assert impl_code_b64, "impl_code_b64 must be non-empty"
    assert ref_code_b64, "ref_code_b64 must be non-empty"
    gpu_type = target.gpu_type
    torch_index, cuda_arch_list = _modal_torch_config(gpu_type)
    cutlass_install = _modal_cutlass_install_steps()
    image_setup = _modal_image_setup(
        torch_index, cuda_arch_list,
        extra_steps=cutlass_install, extra_apt='"ninja-build"',
    )
    file_writes = _modal_kernelbench_file_writes(
        impl_code_b64, ref_code_b64, eval_script_b64,
        run_defensive, defense_code_b64, inputs_code_b64,
    )
    eval_cmd = _modal_kernelbench_eval_cmd(
        seed, run_benchmarks, run_defensive, defense_code_b64, inputs_code_b64,
    )
    run_section = _modal_kernelbench_run_section(gpu_type, eval_cmd)
    return f'''
import asyncio
import base64
import json
import sys
import modal
async def run_eval():
    app = modal.App.lookup("wafer-evaluate", create_if_missing=True)
{image_setup}
    sandbox = modal.Sandbox.create(
        app=app, image=image, gpu="{gpu_type}", timeout={target.timeout_seconds},
    )
    try:
{file_writes}{run_section}
    finally:
        sandbox.terminate()
asyncio.run(run_eval())
'''


def _parse_kernelbench_modal_output(stdout: str) -> EvaluateResult:
    assert isinstance(stdout, str), "stdout must be a string"
    result_json_str = None
    for line in stdout.split("\n"):
        if line.startswith("EVAL_RESULT_JSON:"):
            result_json_str = line[len("EVAL_RESULT_JSON:"):]
            break
    if not result_json_str:
        return _fail_eval("No results found in Modal output")
    try:
        results = json.loads(result_json_str)
    except json.JSONDecodeError as e:
        return _fail_eval(f"Failed to parse results JSON: {e}")
    if "error" in results and results.get("success") is False:
        return _fail_eval(results.get("error", "Unknown error"))
    return EvaluateResult(
        success=True,
        all_correct=results.get("all_correct", False),
        correctness_score=float(results.get("correctness_score", 0.0)),
        geomean_speedup=float(results.get("geomean_speedup", 0.0)),
        passed_tests=int(results.get("passed_tests", 0)),
        total_tests=int(results.get("total_tests", 0)),
        error_message=results.get("error"),
        test_results=results.get("test_results", []),
        compilation_time_s=results.get("compilation_time_s"),
        profiling_stats=results.get("profiling_stats"),
    )


async def run_evaluate_kernelbench_modal(
    args: KernelBenchEvaluateArgs,
    target: ModalTarget,
) -> EvaluateResult:
    """Run KernelBench format evaluation on Modal sandbox.
    Creates a Modal sandbox, uploads files, runs KernelBench eval, and parses results.
    Uses subprocess to isolate Modal's asyncio from trio.
    """
    import base64
    import subprocess
    import sys
    print(f"Creating Modal sandbox ({target.gpu_type}) for KernelBench evaluation...")
    impl_code_b64 = base64.b64encode(args.implementation.read_bytes()).decode()
    ref_code_b64 = base64.b64encode(args.reference.read_bytes()).decode()
    eval_script_b64 = base64.b64encode(KERNELBENCH_EVAL_SCRIPT.encode()).decode()
    inputs_code_b64 = None
    if args.inputs:
        inputs_code_b64 = base64.b64encode(args.inputs.read_bytes()).decode()
    defense_code_b64 = _encode_defense_b64() if args.defensive else None
    script = _build_modal_kernelbench_script(
        target=target, impl_code_b64=impl_code_b64,
        ref_code_b64=ref_code_b64, eval_script_b64=eval_script_b64,
        run_benchmarks=args.benchmark, run_defensive=args.defensive,
        defense_code_b64=defense_code_b64, seed=args.seed,
        inputs_code_b64=inputs_code_b64,
    )
    try:
        stdout, stderr, returncode = await _run_modal_subprocess(
            script, target.timeout_seconds, extra_buffer=120,
        )
    except subprocess.TimeoutExpired:
        return _fail_eval(f"Modal KernelBench evaluation timed out after {target.timeout_seconds}s")
    except Exception as e:
        return _fail_eval(f"Failed to run Modal sandbox: {e}")
    if stdout:
        for line in stdout.split("\n"):
            if not line.startswith("EVAL_RESULT_JSON:"):
                print(line)
    if stderr:
        print(stderr, file=sys.stderr)
    if returncode != 0:
        return _fail_eval(f"Modal sandbox failed (exit {returncode}): {stderr or stdout}")
    return _parse_kernelbench_modal_output(stdout)


async def run_evaluate_kernelbench_docker(
    args: KernelBenchEvaluateArgs,
    target: BaremetalTarget | VMTarget,
) -> EvaluateResult:
    """Run KernelBench format evaluation in Docker container on SSH-based target.
    Similar to run_evaluate_docker but uses KernelBench eval script instead.
    """
    from datetime import datetime

    from wafer.core.async_ssh import AsyncSSHClient
    CONTAINER_WORKSPACE = "/workspace"
    REMOTE_WORKSPACE_BASE = "~/.wafer/workspaces"
    if not target.docker_image:
        return _fail_eval("docker_image must be set for Docker execution")
    gpu_id = _select_gpu_id(target, args.gpu_id)
    print(f"Connecting to {target.ssh_target}...")
    async with AsyncSSHClient(target.ssh_target, target.ssh_key) as client:
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        run_dir = f"kernelbench_eval_{timestamp}"
        workspace_path = await client.expand_path(f"{REMOTE_WORKSPACE_BASE}/kernelbench")
        run_path = f"{workspace_path}/{run_dir}"
        await client.exec(f"mkdir -p {run_path}")
        print(f"Created run directory: {run_path}")
        pip_install_cmd = _build_docker_pip_install_cmd(target)
        return await _run_kernelbench_docker_flow(
            client, args, run_path, run_dir, workspace_path,
            CONTAINER_WORKSPACE, gpu_id, target.docker_image,
            pip_install_cmd,
            {"CUDA_VISIBLE_DEVICES": str(gpu_id), "PYTHONUNBUFFERED": "1"},
            use_amd=False,
        )


# Default ROCm PyTorch image for DigitalOcean AMD MI300X
DEFAULT_ROCM_DOCKER_IMAGE = "rocm/pytorch:rocm6.2_ubuntu22.04_py3.10_pytorch_release_2.3.0"


async def run_evaluate_kernelbench_digitalocean(
    args: KernelBenchEvaluateArgs,
    target: DigitalOceanTarget,
) -> EvaluateResult:
    """Run KernelBench format evaluation in Docker container on DigitalOcean AMD GPU.
    Uses ROCm Docker image with device passthrough for AMD GPUs.
    """
    from datetime import datetime

    import trio_asyncio

    from wafer.core.async_ssh import AsyncSSHClient
    from wafer.core.targets.digitalocean import digitalocean_ssh_context
    CONTAINER_WORKSPACE = "/workspace"
    REMOTE_WORKSPACE_BASE = "~/.wafer/workspaces"
    docker_image = DEFAULT_ROCM_DOCKER_IMAGE
    gpu_id = args.gpu_id if args.gpu_id is not None else target.gpu_ids[0]
    print("Provisioning/connecting to DigitalOcean droplet...")
    async with digitalocean_ssh_context(target) as ssh_info:
        ssh_target = f"{ssh_info.user}@{ssh_info.host}:{ssh_info.port}"
        print(f"Connected to {ssh_target}")
        async with trio_asyncio.open_loop():
            async with AsyncSSHClient(ssh_target, target.ssh_key) as client:
                err = await _ensure_docker_installed(client)
                if err:
                    return _fail_eval(err)
                timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
                run_dir = f"kernelbench_eval_{timestamp}"
                workspace_path = await client.expand_path(
                    f"{REMOTE_WORKSPACE_BASE}/kernelbench"
                )
                run_path = f"{workspace_path}/{run_dir}"
                await client.exec(f"mkdir -p {run_path}")
                print(f"Created run directory: {run_path}")
                rocm_arch = _get_rocm_arch(target.compute_capability)
                env_dict = {"HIP_VISIBLE_DEVICES": str(gpu_id), "PYTHONUNBUFFERED": "1"}
                if rocm_arch:
                    env_dict["PYTORCH_ROCM_ARCH"] = rocm_arch
                return await _run_kernelbench_docker_flow(
                    client, args, run_path, run_dir, workspace_path,
                    CONTAINER_WORKSPACE, gpu_id, docker_image,
                    None, env_dict, use_amd=True,
                )


async def run_evaluate_kernelbench_runpod(
    args: KernelBenchEvaluateArgs,
    target: RunPodTarget,
) -> EvaluateResult:
    """Run KernelBench format evaluation directly on RunPod AMD GPU.
    Runs evaluation script directly on host (no Docker) since RunPod pods
    already have PyTorch/ROCm installed.
    """
    from wafer.core.async_ssh import AsyncSSHClient
    from wafer.core.targets.runpod import RunPodError, runpod_ssh_context
    REMOTE_WORKSPACE_BASE = "/tmp/wafer_eval"
    gpu_id = args.gpu_id if args.gpu_id is not None else target.gpu_ids[0]
    print(f"Provisioning RunPod ({target.gpu_type_id})...")
    try:
        async with runpod_ssh_context(target) as ssh_info:
            ssh_target = f"{ssh_info.user}@{ssh_info.host}:{ssh_info.port}"
            print(f"Connected to RunPod: {ssh_target}")
            async with AsyncSSHClient(ssh_target, target.ssh_key) as client:
                return await _run_kernelbench_on_cloud(
                    client, args, gpu_id, REMOTE_WORKSPACE_BASE, target,
                )
    except RunPodError as e:
        return _fail_eval(f"RunPod error: {e}")


async def run_evaluate_kernelbench_baremetal_direct(
    args: KernelBenchEvaluateArgs,
    target: BaremetalTarget,
) -> EvaluateResult:
    """Run KernelBench format evaluation directly on NVIDIA target (no Docker).
    For targets that already have PyTorch/CUDA installed (e.g., workspace containers).
    Uses CUDA_VISIBLE_DEVICES for GPU selection.
    """
    # Reuse the AMD function but with CUDA env vars
    # The logic is identical, just the GPU env var is different
    return await _run_evaluate_kernelbench_baremetal_direct_impl(
        args, target, gpu_env_var="CUDA_VISIBLE_DEVICES"
    )


async def run_evaluate_kernelbench_baremetal_amd(
    args: KernelBenchEvaluateArgs,
    target: BaremetalTarget,
) -> EvaluateResult:
    """Run KernelBench format evaluation directly on AMD baremetal target.
    Runs evaluation script directly on host (no Docker) for AMD GPUs
    that have PyTorch/ROCm installed.
    """
    return await _run_evaluate_kernelbench_baremetal_direct_impl(
        args, target, gpu_env_var="HIP_VISIBLE_DEVICES"
    )


async def _run_evaluate_kernelbench_baremetal_direct_impl(
    args: KernelBenchEvaluateArgs,
    target: BaremetalTarget,
    gpu_env_var: str = "HIP_VISIBLE_DEVICES",
) -> EvaluateResult:
    """Internal implementation for direct baremetal evaluation.
    Runs evaluation script directly on host (no Docker).
    """
    from wafer.core.async_ssh import AsyncSSHClient
    REMOTE_WORKSPACE_BASE = "/tmp/wafer_eval"
    gpu_id = args.gpu_id if args.gpu_id is not None else target.gpu_ids[0]
    print(f"Connecting to {target.ssh_target}...")
    async with AsyncSSHClient(target.ssh_target, target.ssh_key) as client:
        return await _run_kernelbench_on_cloud(
            client, args, gpu_id, REMOTE_WORKSPACE_BASE, target,
            python_candidates=[
                "/opt/conda/envs/py_3.10/bin/python3",
                "/opt/conda/bin/python3",
            ],
            gpu_env_var=gpu_env_var,
        )


def _find_local_python_with_torch() -> str:
    import os
    import subprocess
    for candidate in [
        "/opt/venv/bin/python3",
        "/opt/conda/envs/py_3.10/bin/python3",
        "/opt/conda/bin/python3",
    ]:
        if os.path.isfile(candidate):  # noqa: ASYNC240
            try:
                check = subprocess.run(
                    [candidate, "-c", "import torch"],
                    capture_output=True,
                    timeout=10,
                )
                if check.returncode == 0:
                    print(f"Using Python: {candidate}")
                    return candidate
            except (subprocess.TimeoutExpired, OSError):
                continue
    return "python3"


def _prepare_local_kernelbench_dir(
    args: KernelBenchEvaluateArgs,
    run_path: Path,
) -> tuple[list[str], Path | None]:
    assert args is not None, "args must not be None"
    assert run_path, "run_path must be non-empty"
    impl_path = run_path / "implementation.py"
    impl_path.write_text(args.implementation.read_text())
    ref_path = run_path / "reference.py"
    ref_path.write_text(args.reference.read_text())
    inputs_path = None
    if args.inputs:
        inputs_path = run_path / "custom_inputs.py"
        inputs_path.write_text(args.inputs.read_text())
    eval_script_path = run_path / "kernelbench_eval.py"
    eval_script_path.write_text(KERNELBENCH_EVAL_SCRIPT)
    defense_module_path = None
    if args.defensive:
        defense_src = _get_defense_source_path()
        if defense_src.exists():
            defense_module_path = run_path / "defense.py"
            defense_module_path.write_text(defense_src.read_text())
    output_path = run_path / "results.json"
    cmd_parts = [
        _find_local_python_with_torch(), "-X", "faulthandler",
        str(eval_script_path),
        "--impl", str(impl_path),
        "--reference", str(ref_path),
        "--output", str(output_path),
        "--seed", str(args.seed),
        "--stages", args.stages,
    ]
    if args.benchmark:
        cmd_parts.append("--benchmark")
    if args.profile:
        cmd_parts.append("--profile")
    if inputs_path:
        cmd_parts.extend(["--inputs", str(inputs_path)])
    if args.defensive and defense_module_path:
        cmd_parts.extend(["--defensive", "--defense-module", str(defense_module_path)])
    return cmd_parts, output_path


def _build_local_gpu_env_kernelbench(
    target: LocalTarget,
    gpu_id: int,
) -> dict[str, str]:
    assert target is not None, "target must not be None"
    assert gpu_id >= 0, "gpu_id must be non-negative"
    import os
    env = os.environ.copy()
    env["PYTHONUNBUFFERED"] = "1"
    if target.vendor == "amd":
        env["HIP_VISIBLE_DEVICES"] = str(gpu_id)
        env["ROCM_PATH"] = "/opt/rocm"
        rocm_arch = _get_rocm_arch(target.compute_capability)
        if rocm_arch:
            env["PYTORCH_ROCM_ARCH"] = rocm_arch
    else:
        env["CUDA_VISIBLE_DEVICES"] = str(gpu_id)
    return env


def _parse_local_subprocess_failure(result: subprocess.CompletedProcess[str], output_path: Path) -> EvaluateResult | None:
    assert result is not None, "result must not be None"
    assert output_path, "output_path must be non-empty"
    if result.returncode != 0 and not output_path.exists():
        output_tail = result.stdout or ""
        if len(output_tail) > 1000:
            output_tail = output_tail[-1000:]
        signal_info = ""
        if result.returncode < 0:
            import signal as _signal
            try:
                sig_name = _signal.Signals(-result.returncode).name
            except (ValueError, AttributeError):
                sig_name = str(-result.returncode)
            signal_info = f" (signal {sig_name})"
        msg = (
            f"Eval script failed with exit code {result.returncode}{signal_info}:\n{output_tail}"
            if output_tail
            else f"Eval script failed with exit code {result.returncode}{signal_info} (no output)"
        )
        return _fail_eval(msg)
    if not output_path.exists():
        error_msg = result.stdout or "Unknown error"
        if len(error_msg) > 1000:
            error_msg = error_msg[:500] + "\n...\n" + error_msg[-500:]
        return _fail_eval(f"No results.json produced:\n{error_msg}")
    return None


async def run_evaluate_kernelbench_local(
    args: KernelBenchEvaluateArgs,
    target: LocalTarget,
) -> EvaluateResult:
    """Run KernelBench format evaluation locally on the current machine.
    No SSH, no Docker - runs the eval script directly via subprocess.
    Used for sandbox environments where the GPU is already local.
    """
    import subprocess
    import tempfile
    from datetime import datetime
    gpu_id = args.gpu_id if args.gpu_id is not None else target.gpu_ids[0]
    print(f"Running local KernelBench evaluation on GPU {gpu_id}...")
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    with tempfile.TemporaryDirectory(prefix=f"wafer_kbench_{timestamp}_") as run_path:
        run_path = Path(run_path)
        cmd_parts, output_path = _prepare_local_kernelbench_dir(args, run_path)
        env = _build_local_gpu_env_kernelbench(target, gpu_id)
        print(f"Running: {cmd_parts[0]} kernelbench_eval.py ...")
        try:
            result = subprocess.run(
                cmd_parts, cwd=str(run_path), env=env,
                stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                text=True, timeout=args.timeout or 600,
            )
        except subprocess.TimeoutExpired:
            return _fail_eval("Evaluation timed out")
        if result.stdout:
            print(result.stdout)
        failure = _parse_local_subprocess_failure(result, output_path)
        if failure:
            return failure
        try:
            results_data = json.loads(output_path.read_text())
        except json.JSONDecodeError as e:
            return _fail_eval(f"Failed to parse results: {e}")
        return _parse_kernelbench_json(results_data)


async def run_evaluate_kernelbench(args: KernelBenchEvaluateArgs) -> EvaluateResult:
    """Run KernelBench format evaluation on configured target."""
    err = _validate_kernelbench_files(args)
    if err:
        return _fail_eval(err)
    target, target_name, err = _resolve_target(args.target_name)
    if err:
        return _fail_eval(err)
    print(f"Using target: {target_name}")
    if isinstance(target, LocalTarget):
        return await run_evaluate_local(args, target)
    elif isinstance(target, DigitalOceanTarget):
        return await run_evaluate_kernelbench_digitalocean(args, target)
    elif isinstance(target, RunPodTarget):
        return await run_evaluate_kernelbench_runpod(args, target)
    elif isinstance(target, ModalTarget):
        return await run_evaluate_kernelbench_modal(args, target)
    elif isinstance(target, BaremetalTarget | VMTarget):
        return await _dispatch_kernelbench_baremetal(args, target, target_name)
    else:
        return _fail_eval(
            f"Target type '{type(target).__name__}' not yet supported for KernelBench format. "
            "Use a Local, DigitalOcean, RunPod, Baremetal, or VM target."
        )


async def _dispatch_kernelbench_baremetal(
    args: KernelBenchEvaluateArgs,
    target: BaremetalTarget | VMTarget,
    target_name: str,
) -> EvaluateResult:
    assert target is not None, "target must not be None"
    assert target_name, "target_name must be non-empty"
    if target.compute_capability and target.compute_capability.startswith("gfx"):
        return await run_evaluate_kernelbench_baremetal_amd(args, target)
    if getattr(target, "direct", False):
        return await run_evaluate_kernelbench_baremetal_direct(args, target)
    if not target.docker_image:
        return _fail_eval(
            f"Target '{target_name}' does not have docker_image set. "
            "KernelBench format requires Docker execution."
        )
    return await run_evaluate_kernelbench_docker(args, target)


# =============================================================================
# Aiter operator evaluation
# =============================================================================
AITER_EVAL_SCRIPT = '''#!/usr/bin/env python3
"""Aiter operator evaluation script.
Runs an aiter op_test and outputs JSON results.
"""
import json
import os
import re
import subprocess
import sys
import time
from pathlib import Path
def parse_op_test_output(output: str) -> dict:
    """Parse aiter op_test output for results."""
    result = {
        "passed": False,
        "passed_tests": 0,
        "total_tests": 0,
        "time_ms": None,
        "errors": [],
    }
    # "X passed" or "X passed, Y failed"
    pytest_match = re.search(r"(\\d+) passed", output)
    if pytest_match:
        result["passed_tests"] = int(pytest_match.group(1))
    failed_match = re.search(r"(\\d+) failed", output)
    if failed_match:
        result["total_tests"] = result["passed_tests"] + int(failed_match.group(1))
    else:
        result["total_tests"] = result["passed_tests"]
    # "[aiter] [checkAllclose atol=0.01 rtol=0.01 passed~]"
    passed_checks = len(re.findall(r"\\[aiter\\].*passed", output, re.IGNORECASE))
    warning_checks = len(re.findall(r"\\[aiter\\].*warning", output, re.IGNORECASE))
    failed_checks = len(re.findall(r"\\[aiter\\].*failed", output, re.IGNORECASE))
    if passed_checks > 0 or warning_checks > 0 or failed_checks > 0:
        # aiter's checkAllclose uses 3 states: passed (<5% elements off), warning (<=5% off),
        # failed (>5% off). Warnings are acceptable numerical precision issues.
        # See aiter/test_common.py checkAllclose() for the tol_err_ratio threshold.
        result["passed_tests"] = passed_checks + warning_checks
        result["total_tests"] = passed_checks + warning_checks + failed_checks
        result["passed"] = (failed_checks == 0) and (passed_checks + warning_checks > 0)
    elif result["passed_tests"] > 0:
        result["passed"] = result["passed_tests"] == result["total_tests"]
    # Look for patterns like "time: 1.23 ms", "latency: 1.23ms", "avg: 1.23 ms"
    time_matches = re.findall(
        r"(?:time|latency|avg|mean)[:\\s]+([\\d.]+)\\s*(?:ms|milliseconds)",
        output,
        re.IGNORECASE,
    )
    if time_matches:
        result["time_ms"] = float(time_matches[-1])
    # Also look for tabulated benchmark output
    # Common format: "| kernel | 1.234 ms |"
    table_times = re.findall(r"\\|[^|]+\\|\\s*([\\d.]+)\\s*ms\\s*\\|", output)
    if table_times:
        result["time_ms"] = float(table_times[-1])
    if "Traceback" in output:

        tb_start = output.rfind("Traceback")
        result["errors"].append(output[tb_start:tb_start + 500])
    return result
def main():
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument("--aiter-dir", required=True, help="Path to aiter directory")
    parser.add_argument("--cmd", required=True, help="Command to run (e.g., 'python op_tests/test_gemm.py --mnk 128,32,8192')")
    parser.add_argument("--output", required=True, help="Output JSON path")
    parser.add_argument("--timeout", type=int, default=600, help="Timeout in seconds")
    args = parser.parse_args()
    aiter_dir = Path(args.aiter_dir)
    output_path = Path(args.output)
    python_exe = "/opt/venv/bin/python"
    env = os.environ.copy()
    env["PATH"] = f"$HOME/.local/bin:/opt/venv/bin:{env.get('PATH', '')}"
    # Install uv if not available (much faster than pip)
    uv_check = subprocess.run(
        "command -v uv || echo 'NOT_FOUND'",
        shell=True,
        capture_output=True,
        text=True,
    )
    if "NOT_FOUND" in uv_check.stdout:
        print("[aiter-eval] Installing uv...")
        subprocess.run(
            "curl -LsSf https://astral.sh/uv/install.sh | sh",
            shell=True,
            capture_output=True,
            timeout=60,
        )
        env["PATH"] = f"$HOME/.local/bin:{env['PATH']}"
    # Install aiter in editable mode using uv
    print(f"[aiter-eval] Installing aiter from {aiter_dir}...")
    install_cmd = f'export PATH="$HOME/.local/bin:$PATH" && uv pip install -e {aiter_dir} --python {python_exe} --quiet'
    install_proc = subprocess.run(
        install_cmd,
        shell=True,
        cwd=str(aiter_dir),
        env=env,
        capture_output=True,
        text=True,
        timeout=120,
    )
    if install_proc.returncode != 0:
        print(f"[aiter-eval] uv install failed: {install_proc.stderr}")
        # Continue anyway - maybe aiter is already installed
    # Also install tabulate if needed (for output formatting)
    subprocess.run(
        f'export PATH="$HOME/.local/bin:$PATH" && uv pip install tabulate --python {python_exe} --quiet',
        shell=True,
        env=env,
        capture_output=True,
        timeout=30,
    )
    user_cmd = args.cmd
    if user_cmd.startswith("python "):
        user_cmd = f"{python_exe} {user_cmd[7:]}"
    elif user_cmd.startswith("python3 "):
        user_cmd = f"{python_exe} {user_cmd[8:]}"
    print(f"[aiter-eval] Running: {user_cmd}")
    print(f"[aiter-eval] Working directory: {aiter_dir}")
    start_time = time.time()
    try:
        proc = subprocess.run(
            user_cmd,
            shell=True,
            cwd=str(aiter_dir),
            env=env,
            capture_output=True,
            text=True,
            timeout=args.timeout,
        )
        elapsed = time.time() - start_time
        # Print output for logging
        print(proc.stdout)
        if proc.stderr:
            print(proc.stderr, file=sys.stderr)
        combined_output = proc.stdout + "\\n" + proc.stderr
        parsed = parse_op_test_output(combined_output)
        result = {
            "correct": parsed["passed"],
            "passed_tests": parsed["passed_tests"],
            "total_tests": parsed["total_tests"],
            "time_ms": parsed["time_ms"],
            "elapsed_seconds": elapsed,
            "exit_code": proc.returncode,
        }
        if parsed["errors"]:
            result["error"] = parsed["errors"][0]
    except subprocess.TimeoutExpired:
        result = {
            "correct": False,
            "error": f"Timeout after {args.timeout}s",
            "passed_tests": 0,
            "total_tests": 0,
        }
    except Exception as e:
        result = {
            "correct": False,
            "error": str(e),
            "passed_tests": 0,
            "total_tests": 0,
        }
    output_path.write_text(json.dumps(result, indent=2))
    print(f"[aiter-eval] Results written to {output_path}")
    print(json.dumps(result, indent=2))
if __name__ == "__main__":
    main()
'''


async def _run_aiter_on_remote(
    client: AsyncSSHClient,
    args: AiterEvaluateArgs,
    gpu_id: int,
    run_path: str,
    target: RunPodTarget,
) -> EvaluateResult:
    assert client is not None, "client must not be None"
    assert run_path, "run_path must be non-empty"
    import shlex as _shlex
    remote_aiter = f"{run_path}/aiter"
    print(f"Syncing aiter directory: {args.aiter_dir} -> {remote_aiter}", flush=True)
    upload_result = await client.upload_files(
        str(args.aiter_dir), remote_aiter, recursive=True,
        exclude=["__pycache__", "*.pyc", ".git", "*.egg-info", "build"],
    )
    if not upload_result.success:
        return _fail_eval(f"Failed to sync aiter directory: {upload_result.error_message}")
    print(
        f"Sync complete: {upload_result.files_copied} files, {upload_result.total_bytes} bytes",
        flush=True,
    )
    eval_script_path = f"{run_path}/aiter_eval.py"
    err = await _write_remote_file(client, eval_script_path, AITER_EVAL_SCRIPT, "EVAL_EOF")
    if err:
        return _fail_eval(f"Failed to write eval script: {err}")
    print(f"Running aiter evaluation: {args.cmd}")
    output_path = f"{run_path}/results.json"
    python_exe = "/opt/venv/bin/python"
    escaped_cmd = _shlex.quote(args.cmd)
    eval_cmd = " ".join([
        f"{python_exe} {eval_script_path}",
        f"--aiter-dir {remote_aiter}",
        f"--cmd {escaped_cmd}",
        f"--output {output_path}",
        f"--timeout {args.timeout}",
    ])
    env_vars = _build_rocm_env_vars(gpu_id, getattr(target, "compute_capability", None))
    env_vars += " PATH=/opt/venv/bin:$PATH"
    full_cmd = f"cd {run_path} && {env_vars} {eval_cmd}"
    log_lines = await _stream_and_collect(client, full_cmd)
    results_data, err = await _read_remote_json(client, output_path)
    if err:
        log_tail = "\n".join(log_lines[-50:])
        return _fail_eval(f"Evaluation failed. Log tail:\n{log_tail}")
    return _parse_aiter_json(results_data)


def _parse_aiter_json(results_data: dict) -> EvaluateResult:
    assert results_data is not None, "results_data must not be None"
    assert isinstance(results_data, dict), "results_data must be a dict"
    correct = results_data.get("correct", False)
    error = results_data.get("error")
    passed_tests = results_data.get("passed_tests", 0)
    total_tests = results_data.get("total_tests", 0)
    if error:
        return EvaluateResult(
            success=False, all_correct=False, correctness_score=0.0,
            geomean_speedup=0.0, passed_tests=passed_tests,
            total_tests=total_tests, error_message=error,
        )
    return EvaluateResult(
        success=True, all_correct=correct,
        correctness_score=passed_tests / total_tests if total_tests > 0 else 0.0,
        geomean_speedup=0.0, passed_tests=passed_tests, total_tests=total_tests,
    )


async def run_evaluate_aiter_runpod(
    args: AiterEvaluateArgs,
    target: RunPodTarget,
) -> EvaluateResult:
    """Run aiter operator evaluation on RunPod MI300X.
    Syncs the entire aiter directory to the remote, then runs op_test.
    Uses /opt/venv/bin/python which has PyTorch on RunPod rocm7 image.
    """
    from datetime import datetime

    from wafer.core.async_ssh import AsyncSSHClient
    from wafer.core.targets.runpod import RunPodError, runpod_ssh_context
    REMOTE_WORKSPACE_BASE = "/tmp/wafer_eval"
    gpu_id = args.gpu_id if args.gpu_id is not None else target.gpu_ids[0]
    print(f"Provisioning RunPod ({target.gpu_type_id})...", flush=True)
    try:
        async with runpod_ssh_context(target) as ssh_info:
            ssh_target = f"{ssh_info.user}@{ssh_info.host}:{ssh_info.port}"
            print(f"Connected to RunPod: {ssh_target}", flush=True)
            async with AsyncSSHClient(ssh_target, target.ssh_key) as client:
                timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
                run_path = f"{REMOTE_WORKSPACE_BASE}/aiter_eval_{timestamp}"
                await client.exec(f"mkdir -p {run_path}")
                print(f"Created run directory: {run_path}", flush=True)
                return await _run_aiter_on_remote(
                    client, args, gpu_id, run_path, target,
                )
    except RunPodError as e:
        return _fail_eval(f"RunPod error: {e}")


async def run_evaluate_aiter(
    args: AiterEvaluateArgs,
    target_name: str,
) -> EvaluateResult:
    """Run aiter evaluation, dispatching to the appropriate backend."""
    from wafer.cli.targets import load_target
    try:
        target = load_target(target_name)
    except FileNotFoundError:
        return EvaluateResult(
            success=False,
            all_correct=False,
            correctness_score=0.0,
            geomean_speedup=0.0,
            passed_tests=0,
            total_tests=0,
            error_message=f"Target '{target_name}' not found. Check 'wafer target list'.",
        )
    if isinstance(target, RunPodTarget):
        return await run_evaluate_aiter_runpod(args, target)
    else:
        return EvaluateResult(
            success=False,
            all_correct=False,
            correctness_score=0.0,
            geomean_speedup=0.0,
            passed_tests=0,
            total_tests=0,
            error_message=(
                f"Target type '{type(target).__name__}' not yet supported for aiter evaluation. "
                "Use a RunPod target with MI300X GPU."
            ),
        )


# =============================================================================
# vLLM kernel evaluation
# =============================================================================
# Eval script uploaded to remote and executed there.
# Handles: vLLM install, pytest correctness, benchmark, structured JSON output.
VLLM_EVAL_SCRIPT = '''#!/usr/bin/env python3
"""vLLM kernel evaluation script.
Runs pytest for correctness and kernel microbenchmarks for performance.
Outputs structured JSON results.
"""
import json
import os
import re
import subprocess
import sys
import time
from pathlib import Path
def parse_pytest_output(output: str) -> dict:
    """Parse pytest output for pass/fail counts."""
    result = {
        "passed": False,
        "passed_tests": 0,
        "failed_tests": 0,
        "total_tests": 0,
        "errors": [],
    }
    # pytest summary line: "X passed, Y failed, Z errors"
    passed_match = re.search(r"(\\d+) passed", output)
    failed_match = re.search(r"(\\d+) failed", output)
    error_match = re.search(r"(\\d+) error", output)
    if passed_match:
        result["passed_tests"] = int(passed_match.group(1))
    if failed_match:
        result["failed_tests"] = int(failed_match.group(1))
    if error_match:
        result["failed_tests"] += int(error_match.group(1))
    result["total_tests"] = result["passed_tests"] + result["failed_tests"]
    result["passed"] = result["failed_tests"] == 0 and result["passed_tests"] > 0
    if "FAILED" in output or "ERROR" in output:

        tb_match = re.search(r"(FAILED.*?(?=\\n\\n|FAILED|$))", output, re.DOTALL)
        if tb_match:
            result["errors"].append(tb_match.group(1)[:500])
    return result
def parse_benchmark_output(output: str) -> dict:
    """Parse benchmark output for metrics.
    Handles multiple output formats:
    - pytest --durations output (total time, per-test times)
    - Kernel microbenchmarks (time in us/ms, TFLOPS)
    - benchmark_serving.py (throughput, TTFT, TPOT)
    """
    metrics = {}
    # pytest summary: "54 passed in 23.59s" or "10 passed, 2 failed in 5.00s"
    pytest_total = re.search(r"(\\d+) passed.*?in (\\d+\\.?\\d*)s", output)
    if pytest_total:
        metrics["total_time_s"] = float(pytest_total.group(2))
        metrics["num_passed"] = int(pytest_total.group(1))
    # pytest --durations lines: "0.45s call     tests/foo.py::test_bar[...]"
    durations = re.findall(r"(\\d+\\.?\\d*)s call\\s+", output)
    if durations:
        times = [float(d) for d in durations]
        metrics["mean_test_time_s"] = sum(times) / len(times)
        metrics["max_test_time_s"] = max(times)
        metrics["min_test_time_s"] = min(times)
    # Throughput (tokens/s) - from benchmark_serving.py
    throughput_match = re.search(r"(\\d+\\.?\\d*)\\s*tokens/s", output)
    if throughput_match:
        metrics["throughput"] = float(throughput_match.group(1))
    # TTFT (Time To First Token) in ms
    ttft_match = re.search(r"Mean TTFT.*?(\\d+\\.?\\d*)\\s*(?:ms)?", output, re.IGNORECASE)
    if ttft_match:
        metrics["ttft_ms"] = float(ttft_match.group(1))
    # TPOT (Time Per Output Token) in ms
    tpot_match = re.search(r"Mean TPOT.*?(\\d+\\.?\\d*)\\s*(?:ms)?", output, re.IGNORECASE)
    if tpot_match:
        metrics["tpot_ms"] = float(tpot_match.group(1))
    # Kernel benchmark patterns
    time_patterns = [
        (r"(\\d+\\.?\\d*)\\s*us(?:\\b|\\s)", "time_us"),
        (r"(\\d+\\.?\\d*)\\s*ms(?:\\b|\\s)", "time_ms"),
        (r"Latency.*?(\\d+\\.?\\d*)\\s*(?:us|ms)", "latency"),
    ]
    for pattern, key in time_patterns:
        match = re.search(pattern, output, re.IGNORECASE)
        if match and key not in metrics:
            metrics[key] = float(match.group(1))
    # TFLOPS
    tflops_match = re.search(r"(\\d+\\.?\\d*)\\s*TFLOPS", output, re.IGNORECASE)
    if tflops_match:
        metrics["tflops"] = float(tflops_match.group(1))
    # GB/s bandwidth
    bandwidth_match = re.search(r"(\\d+\\.?\\d*)\\s*GB/s", output, re.IGNORECASE)
    if bandwidth_match:
        metrics["bandwidth_gbps"] = float(bandwidth_match.group(1))
    return metrics
def run_command(cmd: str, cwd: str, env: dict, timeout: int) -> tuple[int, str, str]:
    """Run command and return (exit_code, stdout, stderr).
    TODO: Stream output line-by-line instead of capturing all at once.
    Currently the SSH caller sees no progress until the entire eval script
    finishes, because capture_output=True buffers everything. Use Popen
    with line-by-line reads to print progress as tests run.
    """
    try:
        proc = subprocess.run(
            cmd,
            shell=True,
            cwd=cwd,
            env=env,
            capture_output=True,
            text=True,
            timeout=timeout,
        )
        return proc.returncode, proc.stdout, proc.stderr
    except subprocess.TimeoutExpired:
        return -1, "", f"Timeout after {timeout}s"
    except Exception as e:
        return -1, "", str(e)
def main():
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument("--vllm-dir", required=True, help="Path to vLLM directory")
    parser.add_argument("--test-cmd", required=True, help="Pytest command for correctness")
    parser.add_argument("--bench-cmd", required=True, help="Benchmark command")
    parser.add_argument("--output", required=True, help="Output JSON path")
    parser.add_argument("--timeout", type=int, default=600, help="Timeout per command in seconds")
    parser.add_argument("--skip-install", action="store_true", help="Skip vLLM install")
    args = parser.parse_args()
    vllm_dir = Path(args.vllm_dir)
    output_path = Path(args.output)

    env = os.environ.copy()
    env["PYTHONUNBUFFERED"] = "1"
    # We'll set PYTHONPATH later based on install method
    using_wheel = False
    python_exe = sys.executable
    result = {
        "success": False,
        "correctness_passed": False,
        "passed_tests": 0,
        "total_tests": 0,
        "metrics": {},
        "error": None,
        "install_time_s": 0,
        "test_time_s": 0,
        "bench_time_s": 0,
    }
    # Install vLLM if needed
    if not args.skip_install:
        print("[vllm-eval] Installing vLLM and test dependencies...")
        start = time.time()
        # Install test dependencies from vLLM's requirements files
        test_reqs = vllm_dir / "requirements" / "test.txt"
        rocm_test_reqs = vllm_dir / "requirements" / "rocm-test.txt"
        if test_reqs.exists():
            print(f"[vllm-eval] Installing test requirements from {test_reqs}...")
            test_install_cmd = f"{python_exe} -m pip install -r {test_reqs} --quiet"
            exit_code, stdout, stderr = run_command(test_install_cmd, str(vllm_dir), env, timeout=300)
            if exit_code != 0:
                print(f"[vllm-eval] Test reqs install warning: {stderr[:300]}")
        if rocm_test_reqs.exists():
            print(f"[vllm-eval] Installing ROCm test requirements from {rocm_test_reqs}...")
            rocm_install_cmd = f"{python_exe} -m pip install -r {rocm_test_reqs} --quiet"
            exit_code, stdout, stderr = run_command(rocm_install_cmd, str(vllm_dir), env, timeout=300)
            if exit_code != 0:
                print(f"[vllm-eval] ROCm test reqs install warning: {stderr[:300]}")
        # Fallback: install essential test deps directly if no requirements file
        if not test_reqs.exists():
            test_deps = "pytest pytest-asyncio pytest-timeout pydantic huggingface_hub transformers"
            print(f"[vllm-eval] Installing essential test deps: {test_deps}")
            test_install_cmd = f"{python_exe} -m pip install {test_deps} --quiet"
            exit_code, stdout, stderr = run_command(test_install_cmd, str(vllm_dir), env, timeout=300)
            if exit_code != 0:
                print(f"[vllm-eval] Test deps install warning: {stderr[:300]}")
        hip_check = f"{python_exe} -c \\"import torch; print(torch.version.hip)\\" 2>/dev/null"
        exit_code, stdout, stderr = run_command(hip_check, str(vllm_dir), env, timeout=30)
        is_rocm = exit_code == 0 and stdout.strip()
        if is_rocm:
            # First uninstall any existing vllm to avoid conflicts
            print("[vllm-eval] Installing vLLM from ROCm wheel...")
            rocm_index = "https://wheels.vllm.ai/rocm/0.15.0/rocm700"
            install_cmd = f"{python_exe} -m pip install vllm --extra-index-url {rocm_index} --quiet"
            exit_code, stdout, stderr = run_command(install_cmd, str(vllm_dir), env, timeout=600)
            if exit_code != 0:
                print(f"[vllm-eval] Install warning: {stderr[:500]}")
            using_wheel = True
        else:
            # CUDA: check if already installed, otherwise install from source
            check_cmd = f"{python_exe} -c \\"import vllm; print(vllm.__version__)\\" 2>/dev/null"
            exit_code, stdout, stderr = run_command(check_cmd, str(vllm_dir), env, timeout=30)
            if exit_code == 0:
                print(f"[vllm-eval] vLLM already installed: {stdout.strip()}")
            else:
                print("[vllm-eval] Installing vLLM from source...")
                install_cmd = f"{python_exe} -m pip install -e {vllm_dir} --quiet"
                exit_code, stdout, stderr = run_command(install_cmd, str(vllm_dir), env, timeout=600)
                if exit_code != 0:
                    print(f"[vllm-eval] Install warning: {stderr[:500]}")
        result["install_time_s"] = time.time() - start

    # Always run from vllm_dir (so relative paths like tests/ work),
    # but when using the wheel, remove vllm_dir from sys.path so the
    # source vllm/ package doesn't shadow the installed wheel.
    if using_wheel:
        # Exclude vllm_dir from PYTHONPATH to prevent source shadowing wheel
        env["PYTHONDONTWRITEBYTECODE"] = "1"
    else:
        existing_pythonpath = env.get("PYTHONPATH", "")
        env["PYTHONPATH"] = f"{vllm_dir}:{existing_pythonpath}" if existing_pythonpath else str(vllm_dir)
    if using_wheel:
        # Rename source vllm/ directory so it can't shadow the installed wheel.
        # Tests and benchmarks reference tests/ and benchmarks/ (not vllm/),
        # so renaming only affects the Python package, not the test files.
        source_pkg = vllm_dir / "vllm"
        renamed_pkg = vllm_dir / "_vllm_src"
        if source_pkg.is_dir() and not renamed_pkg.exists():
            source_pkg.rename(renamed_pkg)
            print(f"[vllm-eval] Renamed source vllm/ -> _vllm_src/ to avoid shadowing wheel")
    # Run correctness test
    print(f"[vllm-eval] Running correctness test: {args.test_cmd}")
    start = time.time()
    exit_code, stdout, stderr = run_command(args.test_cmd, str(vllm_dir), env, args.timeout)
    result["test_time_s"] = time.time() - start
    combined = stdout + "\\n" + stderr
    print(combined)
    parsed = parse_pytest_output(combined)
    result["correctness_passed"] = parsed["passed"]
    result["passed_tests"] = parsed["passed_tests"]
    result["total_tests"] = parsed["total_tests"]
    if not parsed["passed"]:
        result["error"] = f"Correctness failed: {parsed['errors'][0] if parsed['errors'] else 'unknown'}"
        result["success"] = True  # Eval ran, just failed correctness
        output_path.write_text(json.dumps(result, indent=2))
        print(f"[vllm-eval] Results: {json.dumps(result, indent=2)}")
        return
    print("[vllm-eval] Correctness passed!")
    # Run benchmark
    print(f"[vllm-eval] Running benchmark: {args.bench_cmd}")
    start = time.time()
    exit_code, stdout, stderr = run_command(args.bench_cmd, str(vllm_dir), env, args.timeout)
    result["bench_time_s"] = time.time() - start
    combined = stdout + "\\n" + stderr
    print(combined)
    if exit_code != 0:
        result["error"] = f"Benchmark failed: {stderr[:500]}"
        result["success"] = True
        output_path.write_text(json.dumps(result, indent=2))
        print(f"[vllm-eval] Results: {json.dumps(result, indent=2)}")
        return
    result["metrics"] = parse_benchmark_output(combined)
    result["success"] = True
    output_path.write_text(json.dumps(result, indent=2))
    print(f"[vllm-eval] Results: {json.dumps(result, indent=2)}")
if __name__ == "__main__":
    main()
'''


def _parse_vllm_benchmark_output(output: str) -> dict[str, float]:
    """Parse vLLM benchmark_serving.py output to extract metrics.
    Expected output format (from benchmark_serving.py):
        Throughput: 123.45 requests/s, 1234.56 tokens/s
        Mean TTFT (ms): 12.34
        Mean TPOT (ms): 1.23
        ...
    Returns dict with keys: throughput, ttft, tpot, etc.
    """
    import re
    metrics: dict[str, float] = {}
    # Throughput patterns
    throughput_match = re.search(r"(\d+\.?\d*)\s*tokens/s", output)
    if throughput_match:
        metrics["throughput"] = float(throughput_match.group(1))
    # TTFT (Time To First Token)
    ttft_match = re.search(r"Mean TTFT.*?(\d+\.?\d*)", output, re.IGNORECASE)
    if ttft_match:
        metrics["ttft"] = float(ttft_match.group(1))
    # TPOT (Time Per Output Token)
    tpot_match = re.search(r"Mean TPOT.*?(\d+\.?\d*)", output, re.IGNORECASE)
    if tpot_match:
        metrics["tpot"] = float(tpot_match.group(1))
    # ITL (Inter-Token Latency)
    itl_match = re.search(r"Mean ITL.*?(\d+\.?\d*)", output, re.IGNORECASE)
    if itl_match:
        metrics["itl"] = float(itl_match.group(1))
    return metrics


async def run_evaluate_vllm_ssh(
    args: VllmEvaluateArgs,
    target: BaremetalTarget | VMTarget,
) -> VllmEvaluateResult:
    """Run vLLM kernel evaluation on SSH target (baremetal/VM)."""
    import time

    from wafer.core.async_ssh import AsyncSSHClient
    REMOTE_WORKSPACE = "/tmp/wafer_vllm_eval"
    gpu_id = args.gpu_id if args.gpu_id is not None else target.gpu_ids[0]
    print(f"Connecting to {target.ssh_target}...")
    async with AsyncSSHClient(target.ssh_target, target.ssh_key) as client:
        run_path = f"{REMOTE_WORKSPACE}/run_{int(time.time())}"
        await client.exec(f"mkdir -p {run_path}")
        is_amd = target.compute_capability and target.compute_capability.startswith("gfx")
        gpu_env_var = "HIP_VISIBLE_DEVICES" if is_amd else "CUDA_VISIBLE_DEVICES"
        rocm_arch = _get_rocm_arch(target.compute_capability) if target.compute_capability else None
        arch_env = f"PYTORCH_ROCM_ARCH={rocm_arch}" if rocm_arch else ""
        env_vars = f"{gpu_env_var}={gpu_id} PYTHONUNBUFFERED=1 {arch_env}"
        return await _run_vllm_eval_on_remote(client, args, run_path, env_vars)


async def run_evaluate_vllm_runpod(
    args: VllmEvaluateArgs,
    target: RunPodTarget,
) -> VllmEvaluateResult:
    """Run vLLM kernel evaluation on RunPod target (MI300X ROCm7)."""
    from wafer.core.async_ssh import AsyncSSHClient
    from wafer.core.targets.runpod import RunPodError, runpod_ssh_context
    REMOTE_WORKSPACE = "/tmp/wafer_vllm_eval"
    print(f"Provisioning RunPod ({target.gpu_type_id})...")
    try:
        async with runpod_ssh_context(target) as ssh_info:
            ssh_target = f"{ssh_info.user}@{ssh_info.host}:{ssh_info.port}"
            print(f"Connected to RunPod: {ssh_target}")
            async with AsyncSSHClient(ssh_target, target.ssh_key) as client:
                await _ensure_rsync(client)
                gpu_id = args.gpu_id if args.gpu_id is not None else target.gpu_ids[0]
                import time
                run_path = f"{REMOTE_WORKSPACE}/run_{int(time.time())}"
                await client.exec(f"mkdir -p {run_path}")
                env_vars = _build_rocm_env_vars(gpu_id, target.compute_capability)
                env_vars += " PATH=/opt/venv/bin:$PATH"
                return await _run_vllm_eval_on_remote(
                    client, args, run_path, env_vars, "/opt/venv/bin/python",
                )
    except RunPodError as e:
        return _fail_vllm(f"RunPod error: {e}")


async def run_evaluate_vllm_digitalocean(
    args: VllmEvaluateArgs,
    target: DigitalOceanTarget,
) -> VllmEvaluateResult:
    """Run vLLM kernel evaluation on DigitalOcean target (MI300X)."""
    from wafer.core.async_ssh import AsyncSSHClient
    from wafer.core.targets.digitalocean import DigitalOceanError, digitalocean_ssh_context
    REMOTE_WORKSPACE = "/tmp/wafer_vllm_eval"
    print(f"Provisioning DigitalOcean droplet ({target.size_slug})...")
    try:
        async with digitalocean_ssh_context(target) as ssh_info:
            ssh_target = f"{ssh_info.user}@{ssh_info.host}:{ssh_info.port}"
            print(f"Connected to DigitalOcean: {ssh_target}")
            async with AsyncSSHClient(ssh_target, target.ssh_key) as client:
                await _ensure_rsync(client)
                gpu_id = args.gpu_id if args.gpu_id is not None else target.gpu_ids[0]
                import time
                run_path = f"{REMOTE_WORKSPACE}/run_{int(time.time())}"
                await client.exec(f"mkdir -p {run_path}")
                env_vars = _build_rocm_env_vars(gpu_id, target.compute_capability)
                return await _run_vllm_eval_on_remote(
                    client, args, run_path, env_vars,
                )
    except DigitalOceanError as e:
        return _fail_vllm(f"DigitalOcean error: {e}")


async def run_evaluate_vllm(args: VllmEvaluateArgs) -> VllmEvaluateResult:
    """Run vLLM evaluation on configured target.
    Args:
        args: vLLM evaluate arguments
    Returns:
        VllmEvaluateResult
    """
    from .targets import get_default_target, load_target
    target_name = args.target_name
    if not target_name:
        target_name = get_default_target()
        if not target_name:
            return VllmEvaluateResult(
                success=False,
                correctness_passed=False,
                metrics={},
                baseline_metrics={},
                error_message="No target specified and no default target configured",
            )
    try:
        target = load_target(target_name)
    except FileNotFoundError:
        return VllmEvaluateResult(
            success=False,
            correctness_passed=False,
            metrics={},
            baseline_metrics={},
            error_message=f"Target '{target_name}' not found",
        )
    if target is None:
        return VllmEvaluateResult(
            success=False,
            correctness_passed=False,
            metrics={},
            baseline_metrics={},
            error_message=f"Target '{target_name}' not found",
        )
    # Route to appropriate handler
    if isinstance(target, BaremetalTarget | VMTarget):
        return await run_evaluate_vllm_ssh(args, target)
    elif isinstance(target, RunPodTarget):
        return await run_evaluate_vllm_runpod(args, target)
    elif isinstance(target, DigitalOceanTarget):
        return await run_evaluate_vllm_digitalocean(args, target)
    else:
        return VllmEvaluateResult(
            success=False,
            correctness_passed=False,
            metrics={},
            baseline_metrics={},
            error_message=(
                f"Target type '{type(target).__name__}' not yet supported for vLLM evaluation. "
                "Use a Baremetal, VM, RunPod, or DigitalOcean target."
            ),
        )


# =============================================================================
# FlashInfer-Bench evaluation
# =============================================================================
FLASHINFER_BENCH_EVAL_SCRIPT = '''#!/usr/bin/env python3
"""FlashInfer-Bench evaluation script.
Runs a solution against a definition and outputs JSON results.
"""
import json
import sys
import time
from pathlib import Path
def main():
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument("--definition", required=True)
    parser.add_argument("--solution-dir", required=True, type=Path)
    parser.add_argument("--trace-dir", required=True, type=Path)
    parser.add_argument("--warmup-runs", type=int, default=10)
    parser.add_argument("--iterations", type=int, default=50)
    parser.add_argument("--rtol", type=float, default=1e-2)
    parser.add_argument("--atol", type=float, default=1e-2)
    args = parser.parse_args()
    results = {
        "success": False,
        "passed": False,
        "definition": args.definition,
        "solution": str(args.solution_dir),
        "speedup": None,
        "latency_ms": None,
        "reference_latency_ms": None,
        "max_abs_error": None,
        "max_rel_error": None,
        "error": None,
    }
    try:
        import torch
        print(f"[FlashInfer-Bench] PyTorch {torch.__version__}, CUDA available: {torch.cuda.is_available()}")
        if torch.cuda.is_available():
            print(f"[FlashInfer-Bench] GPU: {torch.cuda.get_device_name(0)}")
        definitions_dir = args.trace_dir / "definitions"
        def_file = None
        for subdir in definitions_dir.iterdir():
            candidate = subdir / f"{args.definition}.json"
            if candidate.exists():
                def_file = candidate
                break
        if def_file is None:
            results["error"] = f"Definition not found: {args.definition}"
            print(json.dumps(results))
            return
        with open(def_file) as f:
            definition = json.load(f)
        print(f"[FlashInfer-Bench] Loaded definition: {args.definition}")
        solution_json = args.solution_dir / "solution.json"
        if not solution_json.exists():
            results["error"] = f"solution.json not found in {args.solution_dir}"
            print(json.dumps(results))
            return
        with open(solution_json) as f:
            solution_meta = json.load(f)
        entry_point = solution_meta.get("spec", {}).get("entry_point", "main.py::run")
        module_file, func_name = entry_point.split("::")
        module_path = args.solution_dir / module_file
        if not module_path.exists():
            results["error"] = f"Solution module not found: {module_path}"
            print(json.dumps(results))
            return
        # Import solution
        import importlib.util
        spec = importlib.util.spec_from_file_location("solution_module", module_path)
        solution_module = importlib.util.module_from_spec(spec)
        sys.modules["solution_module"] = solution_module
        spec.loader.exec_module(solution_module)
        solution_fn = getattr(solution_module, func_name)
        print(f"[FlashInfer-Bench] Loaded solution: {solution_meta.get('name', 'unknown')}")
        ref_impl = definition.get("reference_implementation", "")
        if not ref_impl:
            results["error"] = "Definition has no reference_implementation"
            print(json.dumps(results))
            return
        ref_namespace = {"torch": torch}
        exec(ref_impl, ref_namespace)
        ref_fn = ref_namespace.get("run")
        if ref_fn is None:
            results["error"] = "Reference implementation has no run() function"
            print(json.dumps(results))
            return
        workloads_dir = args.trace_dir / "workloads"
        workload_file = None
        for subdir in workloads_dir.iterdir():
            candidate = subdir / f"{args.definition}.json"
            if candidate.exists():
                workload_file = candidate
                break
        if workload_file is None:
            # Try to use default workload from definition
            workload_configs = [definition.get("default_workload", {})]
            print("[FlashInfer-Bench] Using default workload from definition")
        else:
            with open(workload_file) as f:
                workload_data = json.load(f)
            workload_configs = workload_data.get("workloads", [workload_data])
            print(f"[FlashInfer-Bench] Loaded {len(workload_configs)} workload configs")
        # Run evaluation on first workload
        workload = workload_configs[0] if workload_configs else {}
        axes = workload.get("axes", definition.get("axes", {}))
        # Generate inputs based on definition
        inputs_spec = definition.get("inputs", [])
        outputs_spec = definition.get("outputs", [])
        input_tensors = []
        for inp in inputs_spec:
            shape = []
            for dim in inp.get("shape", []):
                if isinstance(dim, str):
                    shape.append(axes.get(dim, 1))
                else:
                    shape.append(dim)
            dtype_str = inp.get("dtype", "float32")
            dtype = getattr(torch, dtype_str)
            if dtype in (torch.float16, torch.float32, torch.float64, torch.bfloat16):
                tensor = torch.randn(shape, dtype=dtype, device="cuda")
            else:
                # For int/bool dtypes, use randint or zeros
                tensor = torch.randint(0, 100, shape, dtype=dtype, device="cuda")
            input_tensors.append(tensor)
        output_tensors = []
        for out in outputs_spec:
            shape = []
            for dim in out.get("shape", []):
                if isinstance(dim, str):
                    shape.append(axes.get(dim, 1))
                else:
                    shape.append(dim)
            dtype_str = out.get("dtype", "float32")
            dtype = getattr(torch, dtype_str)
            tensor = torch.zeros(shape, dtype=dtype, device="cuda")
            output_tensors.append(tensor)
        print(f"[FlashInfer-Bench] Input shapes: {[t.shape for t in input_tensors]}")
        print(f"[FlashInfer-Bench] Output shapes: {[t.shape for t in output_tensors]}")
        # Run reference
        ref_outputs = [t.clone() for t in output_tensors]
        ref_fn(*input_tensors, *ref_outputs)
        torch.cuda.synchronize()
        # Run solution
        sol_outputs = [t.clone().zero_() for t in output_tensors]
        solution_fn(*input_tensors, *sol_outputs)
        torch.cuda.synchronize()
        max_abs_error = 0.0
        max_rel_error = 0.0
        passed = True
        for i, (ref_out, sol_out) in enumerate(zip(ref_outputs, sol_outputs)):
            abs_diff = (ref_out - sol_out).abs()
            max_abs = abs_diff.max().item()
            max_abs_error = max(max_abs_error, max_abs)
            # Relative error (avoid div by zero)
            rel_diff = abs_diff / (ref_out.abs() + 1e-10)
            max_rel = rel_diff.max().item()
            max_rel_error = max(max_rel_error, max_rel)
            if not torch.allclose(ref_out, sol_out, rtol=args.rtol, atol=args.atol):
                passed = False
                print(f"[FlashInfer-Bench] Output {i} FAILED: max_abs={max_abs:.2e}, max_rel={max_rel:.2e}")
        results["max_abs_error"] = max_abs_error
        results["max_rel_error"] = max_rel_error
        results["passed"] = passed
        if passed:
            print(f"[FlashInfer-Bench] Correctness PASSED (max_abs={max_abs_error:.2e}, max_rel={max_rel_error:.2e})")
            # Benchmark
            # Warmup
            for _ in range(args.warmup_runs):
                sol_outputs_bench = [t.clone().zero_() for t in output_tensors]
                solution_fn(*input_tensors, *sol_outputs_bench)
            torch.cuda.synchronize()
            # Time solution
            start = time.perf_counter()
            for _ in range(args.iterations):
                sol_outputs_bench = [t.clone().zero_() for t in output_tensors]
                solution_fn(*input_tensors, *sol_outputs_bench)
            torch.cuda.synchronize()
            sol_time = (time.perf_counter() - start) / args.iterations * 1000  # ms
            # Time reference
            for _ in range(args.warmup_runs):
                ref_outputs_bench = [t.clone().zero_() for t in output_tensors]
                ref_fn(*input_tensors, *ref_outputs_bench)
            torch.cuda.synchronize()
            start = time.perf_counter()
            for _ in range(args.iterations):
                ref_outputs_bench = [t.clone().zero_() for t in output_tensors]
                ref_fn(*input_tensors, *ref_outputs_bench)
            torch.cuda.synchronize()
            ref_time = (time.perf_counter() - start) / args.iterations * 1000  # ms
            speedup = ref_time / sol_time if sol_time > 0 else 0.0
            results["latency_ms"] = sol_time
            results["reference_latency_ms"] = ref_time
            results["speedup"] = speedup
            print(f"[FlashInfer-Bench] Solution: {sol_time:.3f} ms")
            print(f"[FlashInfer-Bench] Reference: {ref_time:.3f} ms")
            print(f"[FlashInfer-Bench] Speedup: {speedup:.2f}x")
        else:
            results["error"] = f"Correctness failed: max_abs={max_abs_error:.2e}, max_rel={max_rel_error:.2e}"
        results["success"] = True
    except Exception as e:
        import traceback
        results["error"] = f"{type(e).__name__}: {e}\\n{traceback.format_exc()}"
    print(json.dumps(results))
if __name__ == "__main__":
    main()
'''


async def run_evaluate_flashinfer_bench(
    args: FlashInferBenchEvaluateArgs,
) -> FlashInferBenchResult:
    """Run FlashInfer-Bench evaluation on configured target.
    Args:
        args: FlashInfer-Bench evaluate arguments
    Returns:
        Evaluation result
    """
    from .targets import get_default_target, load_target
    # Validate solution directory
    if not args.solution_dir.exists():
        return FlashInferBenchResult(
            success=False,
            passed=False,
            definition=args.definition,
            solution=str(args.solution_dir),
            error_message=f"Solution directory not found: {args.solution_dir}",
        )
    solution_json = args.solution_dir / "solution.json"
    if not solution_json.exists():
        return FlashInferBenchResult(
            success=False,
            passed=False,
            definition=args.definition,
            solution=str(args.solution_dir),
            error_message=f"solution.json not found in {args.solution_dir}",
        )
    target_name = args.target_name
    if not target_name:
        target_name = get_default_target()
        if not target_name:
            return FlashInferBenchResult(
                success=False,
                passed=False,
                definition=args.definition,
                solution=str(args.solution_dir),
                error_message=(
                    "No target specified and no default set.\n"
                    "Set up a target: wafer target init ssh --name my-gpu --host user@host:22"
                ),
            )
    try:
        target = load_target(target_name)
    except FileNotFoundError:
        return FlashInferBenchResult(
            success=False,
            passed=False,
            definition=args.definition,
            solution=str(args.solution_dir),
            error_message=f"Target not found: {target_name}. Run: wafer target list",
        )
    print(f"Using target: {target_name}")
    # Dispatch to appropriate executor
    if isinstance(target, BaremetalTarget | VMTarget):
        return await run_evaluate_flashinfer_bench_baremetal(args, target)
    else:
        return FlashInferBenchResult(
            success=False,
            passed=False,
            definition=args.definition,
            solution=str(args.solution_dir),
            error_message=(
                f"Target type '{type(target).__name__}' not yet supported for FlashInfer-Bench. "
                "Use a Baremetal or VM target."
            ),
        )


async def _ensure_flashinfer_bench_repo(client: AsyncSSHClient) -> str | None:
    assert client is not None, "client must not be None"
    FLASHINFER_BENCH_REPO = "https://github.com/flashinfer-ai/flashinfer-bench.git"
    bench_check = await client.exec("test -d /tmp/flashinfer-bench && echo exists")
    if "exists" not in bench_check.stdout:
        print("Cloning flashinfer-bench repository...")
        clone_result = await client.exec(
            f"git clone --depth 1 {FLASHINFER_BENCH_REPO} /tmp/flashinfer-bench"
        )
        if clone_result.exit_code != 0:
            return f"Failed to clone flashinfer-bench: {clone_result.stderr}"
    else:
        print("Using existing flashinfer-bench installation")
    return None


async def _upload_solution_files(
    client: AsyncSSHClient,
    solution_dir: Path,
    remote_solution_path: str,
    definition: str,
) -> str | None:
    assert client is not None, "client must not be None"
    assert remote_solution_path, "remote_solution_path must be non-empty"
    import hashlib
    await client.exec(f"mkdir -p {remote_solution_path}")
    BINARY_SUFFIXES = {".pyc", ".pyo", ".so", ".o", ".a", ".pkl", ".pt", ".bin"}
    for file in solution_dir.iterdir():
        if not file.is_file() or file.suffix in BINARY_SUFFIXES:
            continue
        try:
            content = file.read_text()
        except UnicodeDecodeError:
            print(f"Skipping binary file: {file.name}")
            continue
        remote_file = f"{remote_solution_path}/{file.name}"
        delimiter = f"WAFER_EOF_{hashlib.md5(content.encode()).hexdigest()[:8]}"
        err = await _write_remote_file(client, remote_file, content, delimiter)
        if err:
            return f"Failed to upload {file.name}: {err}"
    print(f"Uploaded solution to {remote_solution_path}")
    return None


def _parse_flashinfer_json_output(
    stdout: str,
    stderr: str,
    definition: str,
    solution_dir: str,
) -> FlashInferBenchResult:
    assert definition, "definition must be non-empty"
    assert isinstance(stdout, str), "stdout must be a string"
    json_result = None
    if stdout:
        for line in stdout.strip().split("\n"):
            if not line.startswith("{"):
                print(line)
    if stdout:
        for line in stdout.strip().split("\n"):
            if line.startswith("{"):
                try:
                    json_result = json.loads(line)
                except json.JSONDecodeError:
                    pass
    if json_result is None:
        return _fail_flashinfer(
            definition, solution_dir,
            f"Failed to parse evaluation output.\nstdout: {stdout}\nstderr: {stderr}",
        )
    return FlashInferBenchResult(
        success=json_result.get("success", False),
        passed=json_result.get("passed", False),
        definition=definition,
        solution=solution_dir,
        speedup=json_result.get("speedup"),
        latency_ms=json_result.get("latency_ms"),
        reference_latency_ms=json_result.get("reference_latency_ms"),
        max_abs_error=json_result.get("max_abs_error"),
        max_rel_error=json_result.get("max_rel_error"),
        error_message=json_result.get("error"),
    )


async def run_evaluate_flashinfer_bench_baremetal(
    args: FlashInferBenchEvaluateArgs,
    target: BaremetalTarget,
) -> FlashInferBenchResult:
    """Run FlashInfer-Bench evaluation on a baremetal target via SSH."""
    from datetime import datetime

    from wafer.core.async_ssh import AsyncSSHClient
    REMOTE_WORKSPACE_BASE = "/tmp/wafer_flashinfer_bench"
    gpu_id = args.gpu_id if args.gpu_id is not None else target.gpu_ids[0]
    print(f"Connecting to {target.ssh_target}...")
    async with AsyncSSHClient(target.ssh_target, target.ssh_key) as client:
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        run_path = f"{REMOTE_WORKSPACE_BASE}/flashinfer_bench_{args.definition}_{timestamp}"
        await client.exec(f"mkdir -p {run_path}")
        print(f"Created run directory: {run_path}")
        err = await _ensure_flashinfer_bench_repo(client)
        if err:
            return _fail_flashinfer(args.definition, args.solution_dir, err)
        solution_path = f"{run_path}/solution"
        err = await _upload_solution_files(client, args.solution_dir, solution_path, args.definition)
        if err:
            return _fail_flashinfer(args.definition, args.solution_dir, err)
        eval_script_path = f"{run_path}/flashinfer_bench_eval.py"
        write_err = await _write_remote_file(
            client, eval_script_path, FLASHINFER_BENCH_EVAL_SCRIPT, "EVAL_EOF"
        )
        if write_err:
            return _fail_flashinfer(args.definition, args.solution_dir, f"Failed to write eval script: {write_err}")
        python_exe = await _find_python_with_torch(client, [
            "/opt/conda/envs/py_3.10/bin/python3", "/opt/conda/bin/python3", "python3",
        ])
        eval_cmd = (
            f"cd {run_path} && CUDA_VISIBLE_DEVICES={gpu_id} "
            f"{python_exe} flashinfer_bench_eval.py "
            f"--definition {args.definition} --solution-dir {solution_path} "
            f"--trace-dir /tmp/flashinfer-bench/flashinfer_trace "
            f"--warmup-runs {args.warmup_runs} --iterations {args.iterations} "
            f"--rtol {args.rtol} --atol {args.atol}"
        )
        print(f"Running evaluation for: {args.definition}")
        result = await client.exec(eval_cmd, timeout=600)
        return _parse_flashinfer_json_output(
            result.stdout, result.stderr, args.definition, str(args.solution_dir),
        )


# =============================================================================
# hipBLASLt GEMM evaluation
# =============================================================================
HIPBLASLT_EVAL_SCRIPT = '''#!/usr/bin/env python3
"""hipBLASLt GEMM evaluation script.
Uses PyTorch with hipBLASLt backend to benchmark GEMM operations.
Outputs JSON results with correctness and performance metrics.
"""
import json
import os
import sys
import time
from pathlib import Path
def main():
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument("--hipblaslt-dir", required=True, help="Path to hipBLASLt directory (unused with PyTorch)")
    parser.add_argument("--shape", required=True, help="M,K,N shape (e.g., 256,4096,11008)")
    parser.add_argument("--dtype", default="bf16", help="Data type (bf16, fp16, fp32)")
    parser.add_argument("--output", required=True, help="Output JSON path")
    parser.add_argument("--timeout", type=int, default=1200, help="Timeout in seconds")
    args = parser.parse_args()
    output_path = Path(args.output)
    try:
        m, k, n = map(int, args.shape.split(","))
    except ValueError:
        result = {"correct": False, "error": f"Invalid shape format: {args.shape}"}
        output_path.write_text(json.dumps(result, indent=2))
        return
    print(f"[hipblaslt-eval] Evaluating GEMM: M={m}, K={k}, N={n}, dtype={args.dtype}")
    try:
        import torch
    except ImportError:
        result = {"correct": False, "error": "PyTorch not installed"}
        output_path.write_text(json.dumps(result, indent=2))
        return
    if not torch.cuda.is_available():
        result = {"correct": False, "error": "CUDA/HIP not available"}
        output_path.write_text(json.dumps(result, indent=2))
        return
    device = torch.device("cuda:0")

    dtype_map = {
        "bf16": torch.bfloat16,
        "fp16": torch.float16,
        "fp32": torch.float32,
    }
    torch_dtype = dtype_map.get(args.dtype, torch.bfloat16)
    print(f"[hipblaslt-eval] Using device: {torch.cuda.get_device_name(0)}")
    print(f"[hipblaslt-eval] PyTorch version: {torch.__version__}")
    # A: (M, K), B: (K, N), C = A @ B: (M, N)
    A = torch.randn(m, k, dtype=torch_dtype, device=device)
    B = torch.randn(k, n, dtype=torch_dtype, device=device)
    # Warmup
    print("[hipblaslt-eval] Warming up...")
    for _ in range(10):
        C = torch.mm(A, B)
    torch.cuda.synchronize()
    # Benchmark
    print("[hipblaslt-eval] Running benchmark...")
    num_iters = 100
    start_events = [torch.cuda.Event(enable_timing=True) for _ in range(num_iters)]
    end_events = [torch.cuda.Event(enable_timing=True) for _ in range(num_iters)]
    for i in range(num_iters):
        start_events[i].record()
        C = torch.mm(A, B)
        end_events[i].record()
    torch.cuda.synchronize()
    times_ms = [s.elapsed_time(e) for s, e in zip(start_events, end_events)]
    avg_time_ms = sum(times_ms) / len(times_ms)
    min_time_ms = min(times_ms)
    # GEMM FLOPS = 2 * M * N * K (multiply-add)
    flops = 2 * m * n * k
    tflops = (flops / (avg_time_ms / 1000)) / 1e12
    # Correctness check: compare against CPU
    print("[hipblaslt-eval] Checking correctness...")
    A_cpu = A.float().cpu()
    B_cpu = B.float().cpu()
    C_expected = torch.mm(A_cpu, B_cpu)
    C_actual = C.float().cpu()
    rtol = 0.01 if torch_dtype in (torch.bfloat16, torch.float16) else 1e-5
    atol = 0.1 if torch_dtype in (torch.bfloat16, torch.float16) else 1e-5
    correct = torch.allclose(C_expected, C_actual, rtol=rtol, atol=atol)
    if not correct:
        max_diff = (C_expected - C_actual).abs().max().item()
        print(f"[hipblaslt-eval] WARNING: Max difference: {max_diff}")
    result = {
        "correct": correct,
        "tflops": round(tflops, 3),
        "time_ms": round(avg_time_ms, 4),
        "min_time_ms": round(min_time_ms, 4),
        "shape": [m, k, n],
        "dtype": args.dtype,
        "device": torch.cuda.get_device_name(0),
        "pytorch_version": torch.__version__,
    }
    print(f"[hipblaslt-eval] Results: correct={correct}, tflops={tflops:.3f}, time_ms={avg_time_ms:.4f}")
    output_path.write_text(json.dumps(result, indent=2))
    print(f"[hipblaslt-eval] Results written to {output_path}")
if __name__ == "__main__":
    main()
'''
# Valid dtypes for hipBLASLt evaluation
# INT8 excluded: torch.randn doesn't support int8, torch.mm doesn't accept int8 tensors
HIPBLASLT_VALID_DTYPES = frozenset({"bf16", "fp16"})


def _build_hipblaslt_eval_script(m: int, k: int, n: int, torch_dtype: str) -> str:
    """Build PyTorch benchmark script for GEMM evaluation.
    Returns a self-contained Python script that:
    - Creates random matrices A (M×K) and B (K×N)
    - Runs warmup iterations to stabilize GPU clocks
    - Benchmarks torch.mm() which uses hipBLASLt on AMD
    - Outputs JSON result with TFLOPS and timing
    """
    # Validate dimensions - catch invalid args early
    assert m > 0, "M dimension must be positive"
    assert k > 0, "K dimension must be positive"
    assert n > 0, "N dimension must be positive"
    assert torch_dtype in ("bfloat16", "float16"), f"Invalid torch_dtype: {torch_dtype}"
    return f'''
import torch
import time
import json
# Configuration - dimensions validated by caller
M, K, N = {m}, {k}, {n}
DTYPE = "{torch_dtype}"
WARMUP_RUNS = 10
BENCHMARK_RUNS = 100
dtype = getattr(torch, DTYPE)
device = torch.device("cuda:0")
A = torch.randn(M, K, dtype=dtype, device=device)
B = torch.randn(K, N, dtype=dtype, device=device)
# Warmup to stabilize GPU clocks
for _ in range(WARMUP_RUNS):
    C = torch.mm(A, B)
torch.cuda.synchronize()
# Timed benchmark
start = time.perf_counter()
for _ in range(BENCHMARK_RUNS):
    C = torch.mm(A, B)
torch.cuda.synchronize()
end = time.perf_counter()
# Metrics
total_time_s = end - start
time_per_op_ms = (total_time_s / BENCHMARK_RUNS) * 1000
flops = 2 * M * K * N  # GEMM is 2*M*K*N FLOPs (multiply-add)
tflops = (flops / (time_per_op_ms / 1000)) / 1e12
# Correctness: verify output shape and dtype match expectations
correct = C.shape == (M, N) and C.dtype == dtype
result = {{
    "success": True,
    "correct": correct,
    "tflops": round(tflops, 2),
    "time_ms": round(time_per_op_ms, 4),
    "shape": [M, K, N],
    "dtype": DTYPE
}}
print("HIPBLASLT_RESULT:" + json.dumps(result))
'''


def _parse_hipblaslt_output(
    output: str, exit_code: int, shape: tuple[int, int, int]
) -> HipblasltEvaluateResult:
    """Parse benchmark output to extract result JSON.
    Searches for HIPBLASLT_RESULT: marker in output and parses the JSON.
    Returns error result if marker not found or JSON is invalid.
    """
    import json as json_module
    # Validate inputs
    assert isinstance(output, str), "Output must be a string"
    assert len(shape) == 3, "Shape must be (M, K, N)"

    result_line = None
    for line in output.split("\n"):
        if line.startswith("HIPBLASLT_RESULT:"):
            result_line = line[len("HIPBLASLT_RESULT:"):]
            break
    if result_line is None:
        return HipblasltEvaluateResult(
            success=False,
            correct=False,
            tflops=None,
            time_ms=None,
            shape=shape,
            error_message=f"No result marker found. Exit code: {exit_code}. Output: {output[:500]}",
        )
    try:
        result_data = json_module.loads(result_line)
    except json_module.JSONDecodeError as e:
        return HipblasltEvaluateResult(
            success=False,
            correct=False,
            tflops=None,
            time_ms=None,
            shape=shape,
            error_message=f"Invalid JSON: {e}. Raw: {result_line[:200]}",
        )
    return HipblasltEvaluateResult(
        success=result_data.get("success", False),
        correct=result_data.get("correct", False),
        tflops=result_data.get("tflops"),
        time_ms=result_data.get("time_ms"),
        shape=tuple(result_data.get("shape", shape)),
        error_message=result_data.get("error"),
    )


def run_evaluate_hipblaslt_workspace(
    args: HipblasltEvaluateArgs,
) -> HipblasltEvaluateResult:
    """Run hipBLASLt GEMM benchmark via wafer target.
    Uses workspace exec for GPU command queueing to prevent conflicts.
    Preferred over direct SSH because it handles:
    - GPU command queueing (prevents concurrent kernel conflicts)
    - Automatic workspace resolution
    - Consistent ROCm/PyTorch environment
    """
    import base64
    import logging

    from .workspaces import exec_command_capture, sync_files
    logger = logging.getLogger(__name__)
    # Validate inputs - catch invalid args early (Tiger Style: assert preconditions)
    assert len(args.shape) == 3, f"Shape must be (M, K, N), got {args.shape}"
    assert args.dtype in HIPBLASLT_VALID_DTYPES, f"Invalid dtype: {args.dtype}"
    assert args.workspace_id, "workspace_id is required"
    assert args.timeout > 0, f"Timeout must be positive, got {args.timeout}"
    m, k, n = args.shape
    dtype_map = {"bf16": "bfloat16", "fp16": "float16"}
    torch_dtype = dtype_map[args.dtype]
    # Sync local modifications to workspace
    logger.info(f"Syncing {args.hipblaslt_dir} to workspace {args.workspace_id}")
    file_count, warning = sync_files(args.workspace_id, args.hipblaslt_dir)
    if warning:
        logger.warning(f"Sync warning: {warning}")
    logger.info(f"Synced {file_count} files")
    eval_script = _build_hipblaslt_eval_script(m, k, n, torch_dtype)
    script_b64 = base64.b64encode(eval_script.encode()).decode()
    command = f'/opt/venv/bin/python3 -c "import base64; exec(base64.b64decode(\'{script_b64}\').decode())"'
    logger.info(f"Running GEMM benchmark: M={m}, K={k}, N={n}, dtype={args.dtype}")
    exit_code, output = exec_command_capture(
        args.workspace_id,
        command,
        timeout_seconds=args.timeout,
        routing="gpu",
    )
    return _parse_hipblaslt_output(output, exit_code, args.shape)
