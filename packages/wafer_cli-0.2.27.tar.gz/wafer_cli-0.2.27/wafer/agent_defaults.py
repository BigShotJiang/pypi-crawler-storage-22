"""Shared agent defaults for kernel optimization tasks.

Single source of truth for bash allowlists and enabled tools used by both:
- CLI templates (apps/wafer-cli/wafer/templates/optimize_kernelbench.py)
- Eval configs (research/evals/optimize_kernelbench_eval/.../base_config.py)

Import from here instead of defining your own copy.
"""

from __future__ import annotations

# Tools available to the agent (coding environment tools)
ENABLED_TOOLS: list[str] = ["read", "write", "edit", "glob", "grep", "bash"]

# Bash commands allowed for kernel optimization agents.
# Uses prefix matching — "wafer evaluate" also allows "wafer evaluate kernelbench".
KERNELBENCH_BASH_ALLOWLIST: list[str] = [
    # Kernel evaluation
    "wafer evaluate",
    # Profiling — AMD
    "wafer amd rocprof-compute",
    "wafer amd rocprof-sdk",
    "wafer amd rocprof-systems",
    # Profiling — NVIDIA
    "wafer nvidia ncu",
    "wafer nvidia nsys",
    # Analysis
    "wafer compiler-analyze",
    # Sub-agents
    "wafer agent -t ask-docs",
    # General utilities
    "python",
    "python3",
    "timeout",
    "ls",
    "cat",
    "head",
    "tail",
    "wc",
    "pwd",
    "which",
]
