"""Template for KernelBench optimization.

Usage:
    # Run on a specific problem
    wafer agent -t optimize-kernelbench \
        --args reference=/path/to/problem.py \
        --args pool=kernelbench-pool \
        --args backend=hip \
        --json \
        "Optimize the Softmax kernel"

    # Watch in real-time with JSON streaming
    wafer agent -t optimize-kernelbench \
        --args reference=./23_Softmax.py \
        --json

Variables:
    - reference: Path to the KernelBench problem file (required)
    - pool: Target pool name (default: kernelbench-pool)
    - target: Single target name (alternative to pool)
    - backend: Backend type - hip or cuda (default: hip)
"""

try:
    from wafer_core.rollouts.templates import TemplateConfig
except ImportError:
    from rollouts.templates import TemplateConfig

from wafer.agent_defaults import ENABLED_TOOLS, KERNELBENCH_BASH_ALLOWLIST

# Task-specific instructions only — must stay in sync with the eval's SYSTEM_PROMPT
# in research/evals/optimize_kernelbench_eval/.../base_config.py.
# Run test_eval_cli_parity.py to verify.
# Wafer CLI command docs are auto-generated from --help text and composed
# at runtime by wevin_cli.py (see wafer.cli_instructions.build_cli_instructions).
# TODO: Consider having both eval and template import SYSTEM_PROMPT from a shared
# module so there's only one copy to maintain.
SYSTEM_PROMPT = """\
You are a GPU kernel optimization expert. Your task is to write optimized GPU kernels that are correct and faster than the PyTorch baseline.

## Kernel Format (KernelBench)

The reference file contains a PyTorch `Model` class. You must write a `ModelNew` class that:
1. Has the same `__init__` signature as `Model`
2. Has a `forward()` method with the same input/output signature
3. Uses custom $backend_upper kernels for the computation (NOT PyTorch ops like F.scaled_dot_product_attention or torch.matmul)

The reference file also provides:
- `get_inputs()` - generates test inputs for forward()
- `get_init_inputs()` - generates constructor arguments

## Workflow

1. Read the reference problem file to understand what `Model` does
2. Analyze the computation and identify optimization opportunities
3. Write an optimized `ModelNew` class with custom $backend_upper kernels using `__global__` kernel definitions and `torch.utils.cpp_extension.load_inline`
4. Test with: `wafer evaluate kernelbench $target_flag --backend $backend --impl optimized.py --reference <problem.py> --benchmark`
5. Iterate based on feedback until correct and fast

Your kernel MUST:
- Pass correctness tests (outputs match reference within tolerance)
- Achieve speedup > 1.0x over PyTorch baseline
- Use actual $backend_upper kernels (with `__global__` definitions), NOT PyTorch ops

You MUST run `wafer evaluate kernelbench` to verify your kernel. Your score depends on actual measured results."""

template = TemplateConfig(
    # Identity
    name="optimize-kernelbench",
    description="Optimize KernelBench problems",
    # System prompt (task-specific; CLI docs appended at runtime)
    system_prompt=SYSTEM_PROMPT,
    # Tools
    tools=ENABLED_TOOLS,
    bash_allowlist=KERNELBENCH_BASH_ALLOWLIST,
    # Model config
    model="anthropic/claude-opus-4-5-20251101",
    max_tokens=8192,
    # No thinking by default, can override with --thinking
    thinking=False,
    # Multi-turn for iterative optimization
    single_turn=False,
    # Template variables
    defaults={
        "reference": "./problem.py",
        "pool": "kernelbench-pool",
        "target": "",  # If set, overrides pool
        "backend": "hip",
        "backend_upper": "HIP",  # Auto-computed from backend
        "target_flag": "--pool kernelbench-pool",  # Auto-computed
    },
)
