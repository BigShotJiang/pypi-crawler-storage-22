"""CLI wrapper for trace comparison commands.

This module provides the CLI interface for the `wafer compare` commands.
All core logic is in wafer_core.lib.trace_compare.
"""

import sys
from pathlib import Path
from typing import Any

import typer

import json
import sys

from wafer_core.lib.trace_compare import (
    analyze_trace_pair,
    format_csv,
    format_json,
    format_text,
    ArchitectureType,
    detect_architecture,
)
from wafer_core.lib.trace_compare.loader import StreamingMetadata


def compare_traces(
    trace1: Path,
    trace2: Path,
    output: Path | None = None,
    output_format: str = "text",
    phase: str = "all",
    show_layers: bool = False,
    show_all: bool = False,
    show_stack_traces: bool = False,
    recommendations: bool = False,
) -> None:
    """Compare two GPU traces and generate performance report.

    Args:
        trace1: Path to first trace file (AMD or NVIDIA)
        trace2: Path to second trace file (AMD or NVIDIA)
        output: Optional output file path (default: stdout)
        output_format: Output format ('text', 'text-layers', 'csv', 'csv-layers', or 'json')
        phase: Filter by phase ('all', 'prefill', or 'decode')
        show_layers: Show layer-wise performance breakdown (text format only)
        show_all: Show all items without truncation (applies to layers, operations, kernels)
        show_stack_traces: Show Python stack traces for operations
    """
    # Validate files exist
    if not trace1.exists():
        typer.secho(f"❌ File not found: {trace1}", fg=typer.colors.RED, err=True)
        raise typer.Exit(1)

    if not trace2.exists():
        typer.secho(f"❌ File not found: {trace2}", fg=typer.colors.RED, err=True)
        raise typer.Exit(1)

    # Progress callback for JSON format (emits NDJSON to stdout)
    def progress_callback(stage: str, fraction: float) -> None:
        if output_format == 'json':
            progress_msg = json.dumps({"type": "progress", "stage": stage, "fraction": fraction})
            print(progress_msg, file=sys.stdout, flush=True)
        elif output_format != 'json':
            percent = int(fraction * 100)
            typer.echo(f"📊 {stage}: {percent}%", err=True)

    # Metadata callback for JSON format (emits NDJSON with early GPU info)
    def metadata_callback(meta1: StreamingMetadata, meta2: StreamingMetadata) -> None:
        if output_format == 'json':
            metadata_msg = json.dumps({
                "type": "metadata",
                "trace1": {
                    "platform": meta1.platform,
                    "gpu": meta1.gpu_name,
                    "file_size_mb": round(meta1.file_size_mb, 1),
                },
                "trace2": {
                    "platform": meta2.platform,
                    "gpu": meta2.gpu_name,
                    "file_size_mb": round(meta2.file_size_mb, 1),
                },
            })
            print(metadata_msg, file=sys.stdout, flush=True)
        else:
            typer.echo(f"📊 Trace 1: {meta1.platform} - {meta1.gpu_name} ({meta1.file_size_mb:.1f}MB)", err=True)
            typer.echo(f"📊 Trace 2: {meta2.platform} - {meta2.gpu_name} ({meta2.file_size_mb:.1f}MB)", err=True)

    # Analyze traces using unified API
    if output_format != 'json':
        typer.echo("📊 Loading traces...")

    try:
        result_obj = analyze_trace_pair(
            trace1,
            trace2,
            phase=phase,
            include_stacks=True,
            on_progress=progress_callback,
            on_metadata=metadata_callback,
        )
        
        results = {
            "metadata": result_obj.metadata,
            "operations": result_obj.operations,
            "layers": result_obj.layers,
            "warnings": [{"code": w.code, "severity": w.severity, "message": w.message, "suggestion": w.suggestion} for w in result_obj.warnings],
            "architecture": result_obj.architecture.value,
            "layer_alignments": result_obj.layer_alignments,
            "fusion_analysis": result_obj.fusion_analysis,
            "same_kernel_analysis": result_obj.same_kernel_analysis,
        }
    except ValueError as e:
        typer.secho(f"❌ {e}", fg=typer.colors.RED, err=True)
        raise typer.Exit(1)
    except Exception as e:
        typer.secho(f"❌ Error analyzing traces: {e}", fg=typer.colors.RED, err=True)
        raise typer.Exit(1)

    if output_format != 'json':
        meta = results["metadata"]
        if meta['trace1_platform'] == 'AMD':
            amd_gpu, nvidia_gpu = meta['trace1_gpu'], meta['trace2_gpu']
        else:
            amd_gpu, nvidia_gpu = meta['trace2_gpu'], meta['trace1_gpu']
        typer.echo(f"✅ Loaded: AMD ({amd_gpu}) vs NVIDIA ({nvidia_gpu})")
        
        # Display warnings
        warnings = results.get("warnings", [])
        if warnings:
            typer.echo()
            for warning in warnings:
                icon = "❌" if warning["severity"] == "error" else "⚠️" if warning["severity"] == "warning" else "ℹ️"
                typer.secho(f"{icon}  {warning['message']}", fg=typer.colors.YELLOW if warning["severity"] == "warning" else typer.colors.BLUE)
                if warning.get("suggestion"):
                    typer.secho(f"   Suggestion: {warning['suggestion']}", fg=typer.colors.BLUE)
    typer.echo()


    # Generate output based on format
    if output_format == "text":
        output_str = format_text(results, show_layers=show_layers, show_all=show_all, show_stack_traces=show_stack_traces)
    elif output_format == "text-layers":
        output_str = format_text(results, show_layers=True, show_all=show_all, show_stack_traces=show_stack_traces)
    elif output_format == "csv":
        output_str = format_csv(results, report_type="operations")
    elif output_format == "csv-layers":
        output_str = format_csv(results, report_type="layers")
    elif output_format == "json":
        output_str = format_json(results)
    else:
        typer.secho(f"❌ Unknown format: {output_format}", fg=typer.colors.RED, err=True)
        raise typer.Exit(1)

    # Write output
    if output:
        output.write_text(output_str)
        typer.secho(f"✅ Report saved to {output}", fg=typer.colors.GREEN)
    else:
        typer.echo(output_str)


def compare_align(
    trace1: Path,
    trace2: Path,
    output: Path | None = None,
    output_format: str = "json",
    phase: str = "all",
    layer: int | None = None,
) -> None:
    """Align kernels at layer level for exact kernel-to-kernel comparison.

    Args:
        trace1: Path to first trace file (AMD or NVIDIA)
        trace2: Path to second trace file (AMD or NVIDIA)
        output: Optional output file path (default: stdout)
        output_format: Output format ('json' only for now)
        phase: Filter by phase ('all', 'prefill', or 'decode')
        layer: Focus on specific layer number (optional)
    """
    # Validate files exist
    if not trace1.exists():
        typer.secho(f"❌ File not found: {trace1}", fg=typer.colors.RED, err=True)
        raise typer.Exit(1)

    if not trace2.exists():
        typer.secho(f"❌ File not found: {trace2}", fg=typer.colors.RED, err=True)
        raise typer.Exit(1)

    # Progress callback for JSON format (emits NDJSON to stdout)
    def progress_callback(stage: str, fraction: float) -> None:
        if output_format == 'json':
            progress_msg = json.dumps({"type": "progress", "stage": stage, "fraction": fraction})
            print(progress_msg, file=sys.stdout, flush=True)
        else:
            percent = int(fraction * 100)
            typer.echo(f"📊 {stage}: {percent}%", err=True)

    # Metadata callback for JSON format
    def metadata_callback(meta1: StreamingMetadata, meta2: StreamingMetadata) -> None:
        if output_format == 'json':
            metadata_msg = json.dumps({
                "type": "metadata",
                "trace1": {
                    "platform": meta1.platform,
                    "gpu": meta1.gpu_name,
                    "file_size_mb": round(meta1.file_size_mb, 1),
                },
                "trace2": {
                    "platform": meta2.platform,
                    "gpu": meta2.gpu_name,
                    "file_size_mb": round(meta2.file_size_mb, 1),
                },
            })
            print(metadata_msg, file=sys.stdout, flush=True)
        else:
            typer.echo(f"📊 Trace 1: {meta1.platform} - {meta1.gpu_name} ({meta1.file_size_mb:.1f}MB)", err=True)
            typer.echo(f"📊 Trace 2: {meta2.platform} - {meta2.gpu_name} ({meta2.file_size_mb:.1f}MB)", err=True)

    # Analyze traces using unified API
    if output_format != 'json':
        typer.echo("📊 Loading traces...")

    try:
        result_obj = analyze_trace_pair(
            trace1,
            trace2,
            phase=phase,
            include_stacks=True,
            on_progress=progress_callback,
            on_metadata=metadata_callback,
        )
        
        results = {
            "metadata": result_obj.metadata,
            "layer_alignments": result_obj.layer_alignments or [],
            "fusion_analysis": result_obj.fusion_analysis or {},
            "same_kernel_analysis": result_obj.same_kernel_analysis or {},
            "operations": result_obj.operations,
            "layers": result_obj.layers,
            "warnings": [{"code": w.code, "severity": w.severity, "message": w.message, "suggestion": w.suggestion} for w in result_obj.warnings],
            "architecture": result_obj.architecture.value,
        }
        
        if layer is not None:
            results["layer_alignments"] = [
                la for la in results["layer_alignments"] if la.get("layer") == layer
            ]
    except ValueError as e:
        typer.secho(f"❌ {e}", fg=typer.colors.RED, err=True)
        raise typer.Exit(1)
    except Exception as e:
        typer.secho(f"❌ Error analyzing traces: {e}", fg=typer.colors.RED, err=True)
        import traceback
        traceback.print_exc()
        raise typer.Exit(1)

    if output_format != 'json':
        meta = results["metadata"]
        typer.echo(f"✅ Loaded: {meta.get('amd_gpu', 'Unknown')} vs {meta.get('nvidia_gpu', 'Unknown')}")
        typer.echo(f"✅ Found {len(results['layer_alignments'])} layers")
        typer.echo()

    if output_format == "json":
        output_str = format_json(results)
    else:
        typer.secho(f"❌ Format {output_format} not yet supported for align command. Use 'json'.", fg=typer.colors.RED, err=True)
        raise typer.Exit(1)

    if output:
        output.write_text(output_str)
        typer.secho(f"✅ Report saved to {output}", fg=typer.colors.GREEN)
    else:
        typer.echo(output_str)
