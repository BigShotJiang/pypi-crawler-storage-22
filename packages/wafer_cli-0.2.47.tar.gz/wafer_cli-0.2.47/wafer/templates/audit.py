"""Template for auditing GPU kernels.

Usage:
    wafer agent -t audit --args dir=./my_project --args cmd="make && ./bench" "Find the performance bottleneck"
    wafer agent -t audit --args dir=. --args cmd="hipcc kernel.hip -o kernel && ./kernel" "Why is this slow?"
"""

try:
    from wafer.agent_defaults import AUDIT_BASH_ALLOWLIST, AUDIT_ENABLED_TOOLS
except ImportError:
    # Fallback for when wafer-cli package isn't installed
    AUDIT_ENABLED_TOOLS = ["read", "glob", "grep", "bash"]
    AUDIT_BASH_ALLOWLIST = [
        "ls",
        "cat",
        "head",
        "tail",
        "wc",
        "find",
        "grep",
        "rg",
        "pwd",
        "tree",
        "which",
        "diff",
        "sort",
        "mkdir",
        "make",
        "cmake",
        "nvcc",
        "hipcc",
        "g++",
        "gcc",
        "clang",
        "python",
        "python3",
        "./",
        "wafer evaluate",
        "wafer nvidia ncu",
        "wafer nvidia nsys",
        "wafer amd rocprof-compute",
        "wafer amd rocprof-sdk",
        "wafer amd rocprof-systems",
        "wafer compiler-analyze",
        "wafer agent -t ask-docs",
        "timeout",
    ]

try:
    from wafer_core.rollouts.templates import TemplateConfig
except ImportError:
    from rollouts.templates import TemplateConfig

template = TemplateConfig(
    # Identity
    name="audit",
    description="Audit GPU kernels for performance issues, correctness bugs, and optimization opportunities",
    # System prompt
    system_prompt="""You are a GPU kernel auditing expert. Your task is to analyze kernel code, identify problems, and explain what's wrong and how to fix it.

Working directory: $dir
Build/run command: $cmd

## Strategy

1. Read the kernel source code to understand what it does
2. Run the build/run command to compile and execute:
   ```bash
   $cmd
   ```
3. Analyze the output for errors, warnings, or performance data
4. For architectural questions about the target GPU (AMD MI300X, NVIDIA H100, etc.), query the documentation:
   ```bash
   wafer agent -t ask-docs --corpus amd "your question about MI300X architecture"
   wafer agent -t ask-docs --corpus cuda "your question about NVIDIA/CUDA"
   ```
   Use this for: wave/warp scheduling, occupancy limits, LDS/shared memory sizing, memory hierarchy, instruction throughput, XCD/GCD topology, MFMA/tensor core specifics.
5. Identify concrete issues in the code:
   - Correctness bugs (race conditions, out-of-bounds, incorrect results)
   - Performance problems (uncoalesced memory access, bank conflicts, low occupancy, warp divergence)
   - Architectural mismatches (tile sizes vs hardware limits, missing pipelining, suboptimal wave utilization)
   - Missed optimization opportunities (producer-consumer patterns, software pipelining, wave specialization)
6. For each issue, explain:
   - What the problem is
   - Where in the code it occurs (file + line)
   - Why it matters (quantify impact if possible, cite architecture specs)
   - How to fix it (concrete code change, not hand-waving)

## Output

Produce a structured audit report:
1. Summary (one paragraph)
2. Issues found (ranked by severity/impact)
3. Suggested fixes (concrete, actionable)

Be specific. "Use shared memory" is not useful. "Lines 45-62: the inner loop loads A[k][threadIdx.x] from global memory on every iteration. Tile this into shared memory with a 32x32 block to reduce global loads by 32x" is useful.

Focus on architectural issues, not just micro-optimizations:
- Is the tile size appropriate for the target GPU's wave/warp structure?
- Is there opportunity for pipelining or overlapping memory and compute?
- Could wave/warp specialization (producer-consumer pattern) help?
- Are occupancy limits being hit due to register or LDS/shared memory pressure?

IMPORTANT: Ground every claim in evidence from the code, profiler output, or architecture documentation. Use ask-docs for architectural facts you're unsure about.""",
    # Tools - read-only plus bash for compilation/profiling
    tools=AUDIT_ENABLED_TOOLS,
    bash_allowlist=AUDIT_BASH_ALLOWLIST,
    # Model config - use thinking for deep analysis
    model="anthropic/claude-sonnet-4-5-20250929",
    max_tokens=16384,
    thinking=True,
    thinking_budget=10000,
    # Multi-turn for follow-up questions
    single_turn=False,
    # Template variables
    defaults={
        "dir": ".",
        "cmd": "echo 'No build command provided'",
    },
)
