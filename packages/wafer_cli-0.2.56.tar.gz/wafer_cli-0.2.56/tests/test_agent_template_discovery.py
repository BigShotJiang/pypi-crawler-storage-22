"""Tests for agent template discovery improvements.

Covers:
- `wafer agent --list-templates` shows all templates with descriptions, args, examples
- `wafer agent -t <bad-name>` fails fast with helpful error
- `--template` help text references --list-templates (not hardcoded names)
- Template loader: list_templates, load_all_templates
- Format helpers: _format_template_variable, _format_template_entry
- Validation: _validate_template_name

Run with: PYTHONPATH=. uv run pytest tests/test_agent_template_discovery.py -v
"""

import re
from pathlib import Path

import pytest
from typer.testing import CliRunner

from wafer.cli import (
    _format_template_entry,
    _format_template_variable,
    _validate_template_name,
    app,
)

runner = CliRunner()

_ANSI_RE = re.compile(r'\x1b\[[0-9;]*m')


def _strip_ansi(text: str) -> str:
    return _ANSI_RE.sub('', text)


# Known bundled templates (should always exist in apps/wafer-cli/wafer/templates/)
EXPECTED_BUNDLED_TEMPLATES = [
    "aiter-optimize",
    "ask-docs",
    "audit",
    "optimize-flashinfer",
    "optimize-kernel",
    "optimize-kernelbench",
    "optimize-vllm",
    "trace-analyze",
]


# =============================================================================
# 1. --list-templates command
# =============================================================================


class TestListTemplates:
    """wafer agent --list-templates should show all templates with full info."""

    def test_list_templates_exits_zero(self) -> None:
        """--list-templates should exit cleanly."""
        result = runner.invoke(app, ["agent", "--list-templates"])
        assert result.exit_code == 0, f"Unexpected exit: {result.output}"

    def test_list_templates_header(self) -> None:
        """Output should start with 'Available agent templates'."""
        result = runner.invoke(app, ["agent", "--list-templates"])
        assert "Available agent templates" in result.output

    def test_list_templates_contains_all_bundled(self) -> None:
        """All bundled templates should appear in the output."""
        result = runner.invoke(app, ["agent", "--list-templates"])
        for name in EXPECTED_BUNDLED_TEMPLATES:
            assert name in result.output, f"Template '{name}' missing from output"

    def test_list_templates_shows_descriptions(self) -> None:
        """Each template should have a description, not just a name."""
        result = runner.invoke(app, ["agent", "--list-templates"])
        # Spot-check a few descriptions
        assert "GPU documentation" in result.output  # ask-docs
        assert "performance traces" in result.output  # trace-analyze
        assert "Optimize GPU kernel" in result.output  # optimize-kernel

    def test_list_templates_shows_args(self) -> None:
        """Templates with variables should show an 'Args:' line."""
        result = runner.invoke(app, ["agent", "--list-templates"])
        # trace-analyze has $trace variable
        assert "trace (default:" in result.output
        # optimize-kernel has $kernel and $target variables
        assert "kernel (default:" in result.output
        assert "target (default:" in result.output

    def test_list_templates_shows_examples(self) -> None:
        """Each template should have an 'Example:' line."""
        result = runner.invoke(app, ["agent", "--list-templates"])
        # Every template should have an example
        for name in EXPECTED_BUNDLED_TEMPLATES:
            assert f"wafer agent -t {name}" in result.output, (
                f"Missing example for template '{name}'"
            )

    def test_list_templates_shows_usage_hint(self) -> None:
        """Output should include a hint about --args KEY=VALUE usage."""
        result = runner.invoke(app, ["agent", "--list-templates"])
        assert "--args KEY=VALUE" in result.output

    def test_list_templates_hides_internal_variables(self) -> None:
        """Internal variables like target_flag and backend_upper should not appear."""
        result = runner.invoke(app, ["agent", "--list-templates"])
        # These are auto-computed internal variables
        assert "target_flag" not in result.output
        assert "backend_upper" not in result.output

    def test_list_templates_no_duplicate_args(self) -> None:
        """Template variables should not appear duplicated in the Args line."""
        result = runner.invoke(app, ["agent", "--list-templates"])
        lines = result.output.split("\n")
        for line in lines:
            if line.strip().startswith("Args:"):
                # Extract variable names from the Args line
                # Format: "    Args: kernel (default: ./kernel.cu), target (default: H100)"
                args_text = line.split("Args:")[1].strip()
                # Split on ", " but respect parentheses
                var_names = []
                for part in args_text.split("),"):
                    var_name = part.strip().split(" ")[0].strip(",")
                    if var_name:
                        var_names.append(var_name)
                # Check no duplicates
                assert len(var_names) == len(set(var_names)), (
                    f"Duplicate variable names in: {line.strip()}"
                )


# =============================================================================
# 2. Bad template name fails fast
# =============================================================================


class TestBadTemplateNameFailsFast:
    """wafer agent -t <bad-name> should fail immediately with helpful error."""

    def test_bad_template_exits_nonzero(self) -> None:
        """Bad template name should exit with non-zero code."""
        result = runner.invoke(app, ["agent", "-t", "nonexistent", "test prompt"])
        assert result.exit_code != 0

    def test_bad_template_shows_error_message(self) -> None:
        """Error should mention the bad template name."""
        result = runner.invoke(app, ["agent", "-t", "nonexistent", "test prompt"])
        assert "Unknown template" in result.output
        assert "nonexistent" in result.output

    def test_bad_template_lists_available(self) -> None:
        """Error should list all available template names."""
        result = runner.invoke(app, ["agent", "-t", "nonexistent", "test prompt"])
        for name in EXPECTED_BUNDLED_TEMPLATES:
            assert name in result.output, (
                f"Available template '{name}' missing from error output"
            )

    def test_bad_template_suggests_list_templates(self) -> None:
        """Error should tell user about --list-templates."""
        result = runner.invoke(app, ["agent", "-t", "nonexistent", "test prompt"])
        assert "--list-templates" in result.output

    def test_bad_template_similar_name(self) -> None:
        """Misspelled template should still fail fast with available list."""
        result = runner.invoke(app, ["agent", "-t", "ask-doc", "test"])
        assert result.exit_code != 0
        assert "Unknown template" in result.output
        assert "ask-docs" in result.output  # correct name should be in available list


# =============================================================================
# 3. --template help text updated
# =============================================================================


class TestTemplateHelpText:
    """--template help should reference --list-templates, not hardcode names."""

    def test_help_mentions_list_templates(self) -> None:
        """--help should mention --list-templates for template discovery."""
        result = runner.invoke(app, ["agent", "--help"])
        assert result.exit_code == 0
        clean = _strip_ansi(result.output)
        assert "--list-templates" in clean

    def test_help_does_not_hardcode_template_names(self) -> None:
        """--template help text should NOT contain hardcoded template names.
        why: the old help said 'ask-docs, trace-analyze, optimize-kernel' which
        was incomplete and would get stale as templates are added/removed.
        """
        result = runner.invoke(app, ["agent", "--help"])
        clean = _strip_ansi(result.output)
        lines = clean.split("\n")
        template_help_lines = [
            line for line in lines
            if "--template" in line and "-t" in line
        ]
        assert template_help_lines, "Could not find --template help line"
        template_help = " ".join(template_help_lines)
        assert "ask-docs, trace-analyze, optimize-kernel" not in template_help

    def test_list_templates_flag_in_help(self) -> None:
        """--list-templates should appear in the options list."""
        result = runner.invoke(app, ["agent", "--help"])
        clean = _strip_ansi(result.output)
        assert "--list-templates" in clean
        assert "List available templates" in clean


# =============================================================================
# 4. Template loader unit tests
# =============================================================================


class TestTemplateLoader:
    """Tests for list_templates() and load_all_templates() in loader.py."""

    def test_list_templates_returns_all_bundled(self) -> None:
        """list_templates should return all bundled template names."""
        from wafer_core.rollouts.templates.loader import list_templates
        bundled = Path(__file__).parent.parent / "wafer" / "templates"
        names = list_templates([bundled])
        assert isinstance(names, list)
        for name in EXPECTED_BUNDLED_TEMPLATES:
            assert name in names, f"Missing template: {name}"

    def test_list_templates_no_duplicates(self) -> None:
        """list_templates should not return duplicate names."""
        from wafer_core.rollouts.templates.loader import list_templates
        bundled = Path(__file__).parent.parent / "wafer" / "templates"
        names = list_templates([bundled])
        assert len(names) == len(set(names)), "Duplicate template names found"

    def test_list_templates_excludes_internal_files(self) -> None:
        """list_templates should skip __init__.py, base.py, loader.py."""
        from wafer_core.rollouts.templates.loader import list_templates
        bundled = Path(__file__).parent.parent / "wafer" / "templates"
        names = list_templates([bundled])
        assert "__init__" not in names
        assert "base" not in names
        assert "loader" not in names

    def test_load_all_templates_succeeds(self) -> None:
        """load_all_templates should load all bundled templates."""
        from wafer_core.rollouts.templates.loader import load_all_templates
        bundled = Path(__file__).parent.parent / "wafer" / "templates"
        results = load_all_templates([bundled])
        assert isinstance(results, list)
        assert len(results) == len(EXPECTED_BUNDLED_TEMPLATES)
        # All should load successfully
        for name, config, err in results:
            assert config is not None, f"Template '{name}' failed to load: {err}"
            assert err is None, f"Template '{name}' had error: {err}"

    def test_load_all_templates_has_descriptions(self) -> None:
        """Every loaded template should have a non-empty description."""
        from wafer_core.rollouts.templates.loader import load_all_templates
        bundled = Path(__file__).parent.parent / "wafer" / "templates"
        results = load_all_templates([bundled])
        for name, config, _err in results:
            if config is not None:
                assert config.description, f"Template '{name}' has empty description"

    def test_load_all_templates_handles_broken_template(self, tmp_path: Path) -> None:
        """load_all_templates should not crash on broken template files."""
        from wafer_core.rollouts.templates.loader import load_all_templates
        # Create a broken template file
        broken = tmp_path / "broken_template.py"
        broken.write_text("raise RuntimeError('intentionally broken')")
        results = load_all_templates([tmp_path])
        assert len(results) == 1
        name, config, err = results[0]
        assert name == "broken-template"
        assert config is None
        assert err is not None

    def test_load_all_templates_empty_directory(self, tmp_path: Path) -> None:
        """load_all_templates should return empty list for empty directory."""
        from wafer_core.rollouts.templates.loader import load_all_templates
        results = load_all_templates([tmp_path])
        assert results == []


# =============================================================================
# 5. Validation function unit tests
# =============================================================================


class TestValidateTemplateName:
    """Tests for _validate_template_name()."""

    def test_valid_template_passes(self) -> None:
        """Known template names should pass validation without error."""
        # Should not raise
        _validate_template_name("ask-docs")
        _validate_template_name("trace-analyze")
        _validate_template_name("optimize-kernel")

    def test_invalid_template_raises_exit(self) -> None:
        """Unknown template names should raise typer.Exit (click.exceptions.Exit)."""
        from click.exceptions import Exit
        with pytest.raises(Exit):
            _validate_template_name("nonexistent-template")

    def test_file_path_template_passes(self, tmp_path: Path) -> None:
        """File paths to existing files should pass validation."""
        template_file = tmp_path / "custom_template.py"
        template_file.write_text("# custom template")
        # Should not raise
        _validate_template_name(str(template_file))


# =============================================================================
# 6. Format helper unit tests
# =============================================================================


class TestFormatTemplateVariable:
    """Tests for _format_template_variable()."""

    def test_variable_with_default(self) -> None:
        """Variables with defaults should show the default value."""
        result = _format_template_variable("kernel", {"kernel": "./kernel.cu"})
        assert result == "kernel (default: ./kernel.cu)"

    def test_variable_without_default(self) -> None:
        """Variables without defaults should show just the name."""
        result = _format_template_variable("kernel", {})
        assert result == "kernel"

    def test_variable_with_empty_default(self) -> None:
        """Variables with empty string default should show just the name."""
        result = _format_template_variable("test_cmd", {"test_cmd": ""})
        assert result == "test_cmd"

    def test_internal_variable_target_flag(self) -> None:
        """target_flag should be hidden (returns None)."""
        result = _format_template_variable("target_flag", {"target_flag": "--pool x"})
        assert result is None

    def test_internal_variable_backend_upper(self) -> None:
        """backend_upper should be hidden (returns None)."""
        result = _format_template_variable("backend_upper", {"backend_upper": "HIP"})
        assert result is None

    def test_normal_variable_not_hidden(self) -> None:
        """Non-internal variables should not be hidden."""
        result = _format_template_variable("target", {"target": "H100"})
        assert result is not None
        assert "target" in result


class TestFormatTemplateEntry:
    """Tests for _format_template_entry()."""

    def test_entry_has_name_and_description(self) -> None:
        """Entry should show name and description."""
        from wafer_core.rollouts.templates import TemplateConfig
        config = TemplateConfig(
            name="test-template",
            description="A test template for unit tests",
            system_prompt="You are a test assistant.",
        )
        lines = _format_template_entry("test-template", config)
        assert any("test-template" in line for line in lines)
        assert any("A test template for unit tests" in line for line in lines)

    def test_entry_has_example(self) -> None:
        """Entry should include an example usage line."""
        from wafer_core.rollouts.templates import TemplateConfig
        config = TemplateConfig(
            name="test-template",
            description="Test",
            system_prompt="You are a $thing helper.",
            defaults={"thing": "GPU"},
        )
        lines = _format_template_entry("test-template", config)
        example_lines = [l for l in lines if "Example:" in l]
        assert len(example_lines) == 1
        assert "wafer agent -t test-template" in example_lines[0]
        assert "--args thing=GPU" in example_lines[0]

    def test_entry_with_no_variables(self) -> None:
        """Templates with no variables should not show Args line."""
        from wafer_core.rollouts.templates import TemplateConfig
        config = TemplateConfig(
            name="simple",
            description="Simple template",
            system_prompt="You are helpful.",
        )
        lines = _format_template_entry("simple", config)
        args_lines = [l for l in lines if "Args:" in l]
        assert len(args_lines) == 0

    def test_entry_deduplicates_variables(self) -> None:
        """Variables appearing multiple times in prompt should only show once."""
        from wafer_core.rollouts.templates import TemplateConfig
        config = TemplateConfig(
            name="dedup-test",
            description="Test dedup",
            system_prompt="Use $kernel to optimize $kernel for $target on $target.",
            defaults={"kernel": "./k.cu", "target": "H100"},
        )
        lines = _format_template_entry("dedup-test", config)
        args_line = [l for l in lines if "Args:" in l][0]
        # Each variable should appear exactly once in the Args line
        assert args_line.count("kernel") == 1
        assert args_line.count("target") == 1

    def test_entry_hides_internal_variables(self) -> None:
        """Internal variables (target_flag, backend_upper) should not appear in Args."""
        from wafer_core.rollouts.templates import TemplateConfig
        config = TemplateConfig(
            name="internal-test",
            description="Test internal var filtering",
            system_prompt="Run with $backend $target_flag $backend_upper",
            defaults={"backend": "hip", "target_flag": "--pool x", "backend_upper": "HIP"},
        )
        lines = _format_template_entry("internal-test", config)
        full_text = "\n".join(lines)
        assert "backend" in full_text  # user-facing var should appear
        assert "target_flag" not in full_text  # internal var hidden
        assert "backend_upper" not in full_text  # internal var hidden

    def test_entry_quotes_args_with_spaces(self) -> None:
        """Example args whose defaults contain spaces should be shell-quoted."""
        from wafer_core.rollouts.templates import TemplateConfig
        config = TemplateConfig(
            name="quote-test",
            description="Test quoting",
            system_prompt="Run: $cmd in $dir",
            defaults={"cmd": "echo 'hello world'", "dir": "."},
        )
        lines = _format_template_entry("quote-test", config)
        example_line = [l for l in lines if "Example:" in l][0]
        # The arg with spaces should be wrapped in double quotes
        assert '"cmd=echo \'hello world\'"' in example_line
        # The arg without spaces should NOT be quoted
        assert "--args dir=." in example_line
        assert '"dir=."' not in example_line


# =============================================================================
# 7. TemplateConfig.allow_network field
# =============================================================================


class TestTemplateConfigAllowNetwork:
    """TemplateConfig should accept allow_network field (used by aiter-optimize)."""

    def test_allow_network_default_false(self) -> None:
        """allow_network should default to False."""
        from wafer_core.rollouts.templates import TemplateConfig
        config = TemplateConfig(name="test", system_prompt="Test")
        assert config.allow_network is False

    def test_allow_network_can_be_set_true(self) -> None:
        """allow_network should be settable to True."""
        from wafer_core.rollouts.templates import TemplateConfig
        config = TemplateConfig(name="test", system_prompt="Test", allow_network=True)
        assert config.allow_network is True

    def test_aiter_optimize_template_loads(self) -> None:
        """aiter-optimize template should load without error (uses allow_network=True)."""
        from wafer_core.rollouts.templates.loader import load_template
        bundled = Path(__file__).parent.parent / "wafer" / "templates"
        config = load_template("aiter-optimize", search_paths=[bundled])
        assert config.name == "aiter-optimize"
        assert config.allow_network is True


# =============================================================================
# 8. Search paths helper
# =============================================================================


class TestSearchPaths:
    """Tests for get_wafer_template_search_paths()."""

    def test_search_paths_includes_bundled(self) -> None:
        """Search paths should include the wafer-cli bundled templates directory."""
        from wafer.wevin_cli import get_wafer_template_search_paths
        paths = get_wafer_template_search_paths()
        assert isinstance(paths, list)
        assert len(paths) >= 1
        # At least one path should contain the bundled templates
        bundled_found = any(
            (p / "ask_docs.py").exists() for p in paths
        )
        assert bundled_found, "Bundled templates directory not in search paths"

    def test_search_paths_bundled_first(self) -> None:
        """Bundled templates should be searched first (highest priority)."""
        from wafer.wevin_cli import get_wafer_template_search_paths
        paths = get_wafer_template_search_paths()
        # First path should be the bundled templates dir
        assert (paths[0] / "ask_docs.py").exists(), (
            "First search path should be bundled templates"
        )
