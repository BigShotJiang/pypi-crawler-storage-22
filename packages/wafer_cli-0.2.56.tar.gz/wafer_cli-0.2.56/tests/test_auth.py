"""Tests for authentication and credential management.

Tests the auth module's local JWT exp check, token refresh, and
network error handling.

Run with: PYTHONPATH=. uv run pytest tests/test_auth.py -v
"""

import base64
import json
import time
from unittest.mock import MagicMock, patch

import httpx
import pytest


def _make_jwt(exp: float, extra: dict | None = None) -> str:
    """Build a fake JWT with the given exp claim.

    The token has no valid signature — we only need the payload section
    for _token_expired() to decode.
    """
    header = base64.urlsafe_b64encode(json.dumps({"alg": "HS256"}).encode()).rstrip(b"=")
    payload_dict = {"exp": exp, "sub": "user_123"}
    if extra:
        payload_dict.update(extra)
    payload = base64.urlsafe_b64encode(json.dumps(payload_dict).encode()).rstrip(b"=")
    signature = base64.urlsafe_b64encode(b"fakesig").rstrip(b"=")
    return f"{header.decode()}.{payload.decode()}.{signature.decode()}"


# =============================================================================
# Unit Tests for _token_expired (pure function, no mocks needed)
# =============================================================================


class TestTokenExpired:
    """Test local JWT exp claim checking."""

    def test_valid_token_not_expired(self) -> None:
        """Token with exp far in the future is not expired."""
        from wafer.auth import _token_expired

        token = _make_jwt(exp=time.time() + 3600)
        assert _token_expired(token) is False

    def test_expired_token(self) -> None:
        """Token with exp in the past is expired."""
        from wafer.auth import _token_expired

        token = _make_jwt(exp=time.time() - 60)
        assert _token_expired(token) is True

    def test_token_within_margin_is_expired(self) -> None:
        """Token expiring within the margin (30s) is treated as expired."""
        from wafer.auth import _EXPIRY_MARGIN_SECONDS, _token_expired

        token = _make_jwt(exp=time.time() + _EXPIRY_MARGIN_SECONDS - 1)
        assert _token_expired(token) is True

    def test_token_just_outside_margin_is_valid(self) -> None:
        """Token expiring just beyond the margin is still valid."""
        from wafer.auth import _EXPIRY_MARGIN_SECONDS, _token_expired

        token = _make_jwt(exp=time.time() + _EXPIRY_MARGIN_SECONDS + 10)
        assert _token_expired(token) is False

    def test_garbage_token_is_expired(self) -> None:
        """Unparseable token is treated as expired (fail closed)."""
        from wafer.auth import _token_expired

        assert _token_expired("not-a-jwt") is True

    def test_missing_exp_claim_is_expired(self) -> None:
        """Token without exp claim is treated as expired."""
        from wafer.auth import _token_expired

        header = base64.urlsafe_b64encode(json.dumps({"alg": "HS256"}).encode()).rstrip(b"=")
        payload = base64.urlsafe_b64encode(json.dumps({"sub": "user_123"}).encode()).rstrip(b"=")
        sig = base64.urlsafe_b64encode(b"fakesig").rstrip(b"=")
        token = f"{header.decode()}.{payload.decode()}.{sig.decode()}"
        assert _token_expired(token) is True

    def test_empty_string_is_expired(self) -> None:
        """Empty string is treated as expired."""
        from wafer.auth import _token_expired

        assert _token_expired("") is True


# =============================================================================
# Unit Tests for get_valid_token
# =============================================================================


class TestGetValidToken:
    """Test that get_valid_token uses local exp check and handles refresh."""

    def test_returns_token_when_not_expired(self) -> None:
        """get_valid_token returns token directly when exp is in the future."""
        from wafer.auth import Credentials, get_valid_token

        valid_token = _make_jwt(exp=time.time() + 3600)
        mock_creds = Credentials(
            access_token=valid_token,
            refresh_token="test_refresh",
            email="test@example.com",
        )

        with patch("wafer.auth.load_credentials", return_value=mock_creds):
            result = get_valid_token()

        assert result == valid_token

    def test_returns_none_when_no_credentials(self) -> None:
        """get_valid_token returns None when no credentials are stored."""
        from wafer.auth import get_valid_token

        with patch("wafer.auth.load_credentials", return_value=None):
            result = get_valid_token()

        assert result is None

    def test_refreshes_expired_token(self) -> None:
        """get_valid_token refreshes and returns new token when expired."""
        from wafer.auth import Credentials, get_valid_token

        expired_token = _make_jwt(exp=time.time() - 60)
        new_token = _make_jwt(exp=time.time() + 3600)
        mock_creds = Credentials(
            access_token=expired_token,
            refresh_token="test_refresh",
            email="test@example.com",
        )

        with patch("wafer.auth.load_credentials", return_value=mock_creds):
            with patch("wafer.auth.refresh_access_token", return_value=(new_token, "new_refresh")):
                with patch("wafer.auth.save_credentials") as mock_save:
                    result = get_valid_token()

        assert result == new_token
        mock_save.assert_called_once_with(new_token, "new_refresh", "test@example.com")

    def test_returns_none_when_expired_and_no_refresh_token(self) -> None:
        """get_valid_token returns None when expired with no refresh token."""
        from wafer.auth import Credentials, get_valid_token

        expired_token = _make_jwt(exp=time.time() - 60)
        mock_creds = Credentials(
            access_token=expired_token,
            refresh_token=None,
            email="test@example.com",
        )

        with patch("wafer.auth.load_credentials", return_value=mock_creds):
            result = get_valid_token()

        assert result is None

    def test_returns_none_when_refresh_http_error(self) -> None:
        """get_valid_token returns None when refresh gets HTTP error."""
        from wafer.auth import Credentials, get_valid_token

        expired_token = _make_jwt(exp=time.time() - 60)
        mock_creds = Credentials(
            access_token=expired_token,
            refresh_token="test_refresh",
            email="test@example.com",
        )

        mock_response = MagicMock()
        mock_response.status_code = 401
        http_error = httpx.HTTPStatusError("401", request=MagicMock(), response=mock_response)

        with patch("wafer.auth.load_credentials", return_value=mock_creds):
            with patch("wafer.auth.refresh_access_token", side_effect=http_error):
                result = get_valid_token()

        assert result is None

    def test_returns_none_when_refresh_network_error(self) -> None:
        """get_valid_token returns None when refresh has network error."""
        from wafer.auth import Credentials, get_valid_token

        expired_token = _make_jwt(exp=time.time() - 60)
        mock_creds = Credentials(
            access_token=expired_token,
            refresh_token="test_refresh",
            email="test@example.com",
        )

        with patch("wafer.auth.load_credentials", return_value=mock_creds):
            with patch("wafer.auth.refresh_access_token", side_effect=httpx.ReadTimeout("timeout")):
                result = get_valid_token()

        assert result is None

    def test_no_network_call_when_token_valid(self) -> None:
        """get_valid_token makes NO network calls when token is not expired.

        This is the core fix: the old code called verify_token() (network)
        on every invocation. The new code only checks the JWT exp claim locally.
        """
        from wafer.auth import Credentials, get_valid_token

        valid_token = _make_jwt(exp=time.time() + 3600)
        mock_creds = Credentials(
            access_token=valid_token,
            refresh_token="test_refresh",
            email="test@example.com",
        )

        with patch("wafer.auth.load_credentials", return_value=mock_creds):
            with patch("wafer.auth.verify_token") as mock_verify:
                with patch("wafer.auth.refresh_access_token") as mock_refresh:
                    result = get_valid_token()

        assert result == valid_token
        mock_verify.assert_not_called()
        mock_refresh.assert_not_called()


# =============================================================================
# Unit Tests for get_auth_headers
# =============================================================================


class TestGetAuthHeaders:
    """Test get_auth_headers returns correct headers based on token validity."""

    def test_returns_bearer_token_when_valid(self) -> None:
        """get_auth_headers returns Bearer token when token is not expired."""
        from wafer.auth import Credentials, get_auth_headers

        valid_token = _make_jwt(exp=time.time() + 3600)
        mock_creds = Credentials(
            access_token=valid_token,
            refresh_token="test_refresh",
            email="test@example.com",
        )

        with patch("wafer.auth.load_credentials", return_value=mock_creds):
            result = get_auth_headers()

        assert result == {"Authorization": f"Bearer {valid_token}"}

    def test_returns_empty_dict_when_expired_and_refresh_fails(self) -> None:
        """get_auth_headers returns {} when token expired and refresh fails."""
        from wafer.auth import Credentials, get_auth_headers

        expired_token = _make_jwt(exp=time.time() - 60)
        mock_creds = Credentials(
            access_token=expired_token,
            refresh_token="test_refresh",
            email="test@example.com",
        )

        with patch("wafer.auth.load_credentials", return_value=mock_creds):
            with patch("wafer.auth.refresh_access_token", side_effect=httpx.ReadTimeout("timeout")):
                result = get_auth_headers()

        assert result == {}

    def test_returns_empty_dict_when_no_credentials(self) -> None:
        """get_auth_headers returns {} when not logged in."""
        from wafer.auth import get_auth_headers

        with patch("wafer.auth.load_credentials", return_value=None):
            result = get_auth_headers()

        assert result == {}


# =============================================================================
# Unit Tests for verify_token (still exists for explicit verification)
# =============================================================================


class TestVerifyTokenRaisesOnNetworkError:
    """Document that verify_token raises network errors (caller must handle)."""

    def test_verify_token_raises_read_timeout(self) -> None:
        """verify_token raises ReadTimeout when API times out."""
        from wafer.auth import verify_token

        with patch("wafer.auth.get_api_url", return_value="https://api.example.com"):
            with patch("httpx.Client") as mock_client_class:
                mock_client = MagicMock()
                mock_client.__enter__ = MagicMock(return_value=mock_client)
                mock_client.__exit__ = MagicMock(return_value=False)
                mock_client.post.side_effect = httpx.ReadTimeout("timeout")
                mock_client_class.return_value = mock_client

                with pytest.raises(httpx.ReadTimeout):
                    verify_token("test_token")

    def test_verify_token_raises_connect_error(self) -> None:
        """verify_token raises ConnectError when API is unreachable."""
        from wafer.auth import verify_token

        with patch("wafer.auth.get_api_url", return_value="https://api.example.com"):
            with patch("httpx.Client") as mock_client_class:
                mock_client = MagicMock()
                mock_client.__enter__ = MagicMock(return_value=mock_client)
                mock_client.__exit__ = MagicMock(return_value=False)
                mock_client.post.side_effect = httpx.ConnectError("refused")
                mock_client_class.return_value = mock_client

                with pytest.raises(httpx.ConnectError):
                    verify_token("test_token")


class TestGetWaferAuthExpiredMessage:
    """_get_wafer_auth must show 'expired' message when creds exist but refresh fails."""

    def test_shows_expired_message_when_creds_exist_but_refresh_fails(self) -> None:
        """Expired creds + failed refresh + no ANTHROPIC_API_KEY must print 'expired', not 'No API credentials found'."""
        import io
        import os

        from wafer.auth import Credentials
        from wafer.wevin_cli import _get_wafer_auth

        creds = Credentials(access_token="expired", refresh_token="x", email="u@t.com")
        stderr_capture = io.StringIO()
        with patch("wafer.auth.load_credentials", return_value=creds):
            with patch("wafer.auth.get_valid_token", return_value=None):
                with patch.dict(os.environ, {"ANTHROPIC_API_KEY": "", "WAFER_AUTH_TOKEN": ""}, clear=False):
                    with patch("sys.stderr", stderr_capture):
                        api_base, api_key, _ = _get_wafer_auth()

        assert api_base is None
        assert api_key is None
        err_text = stderr_capture.getvalue()
        assert "expired" in err_text.lower()
        assert "wafer settings login" in err_text.lower()
        assert "No API credentials found" not in err_text

    def test_tracks_auth_failure_when_expired(self) -> None:
        """Expired creds + failed refresh fires cli_auth_failure PostHog event."""
        import os

        from wafer.auth import Credentials
        from wafer.wevin_cli import _get_wafer_auth

        creds = Credentials(access_token="expired", refresh_token="x", email="u@t.com")
        with patch("wafer.auth.load_credentials", return_value=creds):
            with patch("wafer.auth.get_valid_token", return_value=None):
                with patch.dict(os.environ, {"ANTHROPIC_API_KEY": "", "WAFER_AUTH_TOKEN": ""}, clear=False):
                    with patch("wafer.wevin_cli._track_auth_failure") as mock_track:
                        _get_wafer_auth()

        mock_track.assert_called_once_with(
            "credentials_expired_refresh_failed", had_credentials=True, source="proxy",
        )

    def test_tracks_auth_failure_when_no_credentials(self) -> None:
        """No credentials fires cli_auth_failure with error_type='no_credentials'."""
        import os

        from wafer.wevin_cli import _get_wafer_auth

        with patch("wafer.auth.load_credentials", return_value=None):
            with patch("wafer.auth.get_valid_token", return_value=None):
                with patch.dict(os.environ, {"ANTHROPIC_API_KEY": "", "WAFER_AUTH_TOKEN": ""}, clear=False):
                    with patch("wafer.wevin_cli._track_auth_failure") as mock_track:
                        _get_wafer_auth()

        mock_track.assert_called_once_with(
            "no_credentials", had_credentials=False, source="proxy",
        )


class TestTokenRefreshLogging:
    """_make_wafer_token_refresh must log warnings on failure."""

    def test_token_refresh_logs_warning_on_failure(self) -> None:
        """Failed refresh logs a warning instead of silently returning None."""
        import asyncio

        from wafer.auth import Credentials

        creds = Credentials(access_token="tok", refresh_token="refresh", email="u@t.com")
        with patch("wafer.auth.load_credentials", return_value=creds):
            with patch("wafer.auth.refresh_access_token", side_effect=RuntimeError("network down")):
                with patch("logging.Logger.warning") as mock_warn:
                    from wafer.wevin_cli import _make_wafer_token_refresh
                    refresh_fn = _make_wafer_token_refresh()
                    result = asyncio.get_event_loop().run_until_complete(refresh_fn())

        assert result is None
        mock_warn.assert_called_once()
        assert "network down" in str(mock_warn.call_args)
