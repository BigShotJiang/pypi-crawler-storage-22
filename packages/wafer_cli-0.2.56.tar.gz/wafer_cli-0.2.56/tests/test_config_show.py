"""Tests for wafer config show. Covers config.toml with [api] only (no [default])."""

from pathlib import Path

import pytest
from typer.testing import CliRunner

from wafer.cli import app

runner = CliRunner()


def test_config_show_no_parse_error_when_only_api_section(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    """config show must not crash or show parse error when [default] section is missing."""
    config_dir = tmp_path / ".wafer"
    config_dir.mkdir()
    config_file = config_dir / "config.toml"
    config_file.write_text('[api]\nenvironment = "prod"\n')

    monkeypatch.setattr(Path, "home", lambda: tmp_path)
    monkeypatch.setattr("wafer.global_config.CONFIG_FILE", config_file)
    monkeypatch.setattr("wafer.global_config.CONFIG_DIR", config_dir)
    from wafer.global_config import clear_config_cache

    clear_config_cache()
    result = runner.invoke(app, ["settings", "config", "show"])

    assert result.exit_code == 0
    assert "Config must have [default] section" not in result.stdout
    assert "parse error" not in result.stdout.lower()
