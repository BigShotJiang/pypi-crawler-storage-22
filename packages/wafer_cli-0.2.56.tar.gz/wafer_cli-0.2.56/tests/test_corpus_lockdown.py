"""Tests to verify corpus lockdown — no local corpus access remains.

Covers:
- --corpus flag no longer exists on wafer agent
- wafer settings corpus subcommand no longer exists
- corpus.py module does not exist / cannot be imported
- No corpus paths appear in any template or environment config
- CI build sets correct DEFAULT_ENVIRONMENT for staging vs prod
- ask_docs tool resolves API URL correctly
"""
from __future__ import annotations

import importlib
import os
from pathlib import Path
from unittest.mock import patch

import pytest
from typer.testing import CliRunner

from wafer.cli import app

runner = CliRunner()


class TestCorpusFlagRemoved:
    """wafer agent should not have a --corpus flag."""

    def test_corpus_flag_not_in_agent_help(self) -> None:
        result = runner.invoke(app, ["agent", "--help"])
        assert result.exit_code == 0
        assert "--corpus" not in result.output

    def test_corpus_shortflag_not_in_agent_help(self) -> None:
        result = runner.invoke(app, ["agent", "--help"])
        # -c should not be a recognized option for corpus
        # (it might be used for something else, just check --corpus is gone)
        assert "--corpus" not in result.output


class TestCorpusSubcommandRemoved:
    """wafer settings corpus should not exist."""

    def test_corpus_subcommand_not_available(self) -> None:
        result = runner.invoke(app, ["settings", "corpus", "list"])
        # Should fail because corpus subcommand no longer exists
        assert result.exit_code != 0


class TestCorpusModuleRemoved:
    """corpus.py module should not exist."""

    def test_corpus_module_does_not_exist(self) -> None:
        corpus_path = Path(__file__).parent.parent / "wafer" / "corpus.py"
        assert not corpus_path.exists(), "corpus.py should be deleted"

    def test_corpus_module_cannot_be_imported(self) -> None:
        with pytest.raises(ImportError):
            importlib.import_module("wafer.corpus")

    def test_corpora_directory_does_not_exist(self) -> None:
        corpora_path = Path(__file__).parent.parent / "wafer" / "corpora"
        assert not corpora_path.exists(), "corpora/ directory should be deleted"


class TestNoCorpusPathsInTemplates:
    """Templates should not reference local corpus paths."""

    def test_ask_docs_template_uses_ask_docs_tool(self) -> None:
        from wafer_core.rollouts.templates.loader import load_template
        bundled = Path(__file__).parent.parent / "wafer" / "templates"
        config = load_template("ask-docs", search_paths=[bundled])
        assert "ask_docs" in config.tools
        assert "bash" not in config.tools
        assert "glob" not in config.tools

    def test_no_corpus_path_in_ask_docs_prompt(self) -> None:
        from wafer_core.rollouts.templates.loader import load_template
        bundled = Path(__file__).parent.parent / "wafer" / "templates"
        config = load_template("ask-docs", search_paths=[bundled])
        assert "corpus_path" not in config.system_prompt
        assert "working_dir" not in config.system_prompt

    def test_enabled_tools_include_ask_docs(self) -> None:
        from wafer.agent_defaults import (
            AITER_ENABLED_TOOLS,
            AUDIT_ENABLED_TOOLS,
            ENABLED_TOOLS,
            FLASHINFER_ENABLED_TOOLS,
            HIPBLASLT_ENABLED_TOOLS,
            VLLM_ENABLED_TOOLS,
        )
        for tools_list in [
            ENABLED_TOOLS, VLLM_ENABLED_TOOLS, AITER_ENABLED_TOOLS,
            FLASHINFER_ENABLED_TOOLS, HIPBLASLT_ENABLED_TOOLS, AUDIT_ENABLED_TOOLS,
        ]:
            assert "ask_docs" in tools_list


class TestStagingVsProdEnvironment:
    """CI build correctly sets DEFAULT_ENVIRONMENT for staging vs prod.

    The publish-python-package action uses sed to rewrite DEFAULT_ENVIRONMENT
    in global_config.py at build time:
    - staging (TestPyPI) -> DEFAULT_ENVIRONMENT = "staging"
    - production (PyPI) -> DEFAULT_ENVIRONMENT = "prod"
    """

    def test_default_environment_is_valid(self) -> None:
        from wafer.global_config import DEFAULT_ENVIRONMENT
        assert DEFAULT_ENVIRONMENT in ("staging", "prod", "local")

    def test_staging_api_url_is_staging_server(self) -> None:
        from wafer.global_config import BUILTIN_ENVIRONMENTS
        staging = BUILTIN_ENVIRONMENTS["staging"]
        assert "staging" in staging.api_url

    def test_prod_api_url_is_prod_server(self) -> None:
        from wafer.global_config import BUILTIN_ENVIRONMENTS
        prod = BUILTIN_ENVIRONMENTS["prod"]
        assert "api.wafer.ai" in prod.api_url

    def test_get_api_url_respects_env_override(self) -> None:
        from wafer.global_config import clear_config_cache, get_api_url
        clear_config_cache()
        with patch.dict(os.environ, {"WAFER_API_URL": "http://custom:9999"}):
            assert get_api_url() == "http://custom:9999"
        clear_config_cache()

    def test_staging_environment_uses_staging_url(self) -> None:
        """When config says 'staging', get_api_url returns staging URL."""
        from wafer.global_config import BUILTIN_ENVIRONMENTS, GlobalConfig, clear_config_cache
        staging_config = GlobalConfig(environment="staging")
        clear_config_cache()
        with (
            patch.dict(os.environ, {}, clear=True),
            patch("wafer.global_config.load_global_config", return_value=staging_config),
        ):
            from wafer.global_config import get_api_url
            url = get_api_url()
            assert url == BUILTIN_ENVIRONMENTS["staging"].api_url
        clear_config_cache()


class TestAskDocsApiUrlResolution:
    """ask_docs tool requires WAFER_API_URL from env."""

    def test_ask_docs_requires_wafer_api_url(self) -> None:
        """Tool requires WAFER_API_URL env var — no fallback."""
        from wafer_core.tools.ask_docs_tool import VALID_CORPORA
        assert len(VALID_CORPORA) > 0

    def test_ci_action_sets_default_environment(self) -> None:
        """Verify the CI action file has the sed command for DEFAULT_ENVIRONMENT."""
        action_path = Path(__file__).parent.parent.parent.parent.parent / ".github" / "actions" / "publish-python-package" / "action.yml"
        if not action_path.exists():
            pytest.skip("CI action file not found (not in full repo)")
        content = action_path.read_text()
        assert "DEFAULT_ENVIRONMENT" in content
        assert "staging" in content
        assert "prod" in content
