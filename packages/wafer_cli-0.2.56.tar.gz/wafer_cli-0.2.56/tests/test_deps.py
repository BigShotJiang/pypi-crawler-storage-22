"""Unit tests for the deps module (local tool dependency checking).

Run with: uv run pytest apps/wafer-cli/tests/test_deps.py -v
"""

from unittest.mock import patch

import pytest

from wafer.deps import DEPS_REGISTRY, DepSpec, check_all_deps, check_dep


# =============================================================================
# Registry validation
# =============================================================================


class TestDepsRegistry:
    """Validate the DEPS_REGISTRY structure."""

    def test_registry_not_empty(self):
        assert len(DEPS_REGISTRY) > 0

    def test_no_python_packages(self):
        """DEPS_REGISTRY should NOT include Python packages (triton, torch, nvtx).
        Those belong in TOOL_REGISTRY for remote targets."""
        python_pkgs = {"triton", "torch", "nvtx", "pytorch"}
        for name in DEPS_REGISTRY:
            assert name not in python_pkgs, f"{name} is a Python package, not a local dep"

    def test_required_fields(self):
        for name, spec in DEPS_REGISTRY.items():
            assert isinstance(spec, DepSpec)
            assert spec.name == name
            assert spec.description
            assert spec.check_cmd
            assert spec.platform in ("any", "nvidia", "amd")

    def test_expected_tools_present(self):
        expected = {"ncu", "nsys", "rocprof", "gh"}
        for tool in expected:
            assert tool in DEPS_REGISTRY, f"Expected {tool} in DEPS_REGISTRY"


# =============================================================================
# check_dep()
# =============================================================================


class TestCheckDep:
    """Test check_dep() function."""

    def test_returns_true_when_found(self):
        with patch("wafer.deps.shutil.which", return_value="/usr/bin/ncu"):
            assert check_dep("ncu") is True

    def test_returns_false_when_not_found(self):
        with patch("wafer.deps.shutil.which", return_value=None):
            assert check_dep("ncu") is False

    def test_raises_keyerror_for_unknown(self):
        with pytest.raises(KeyError):
            check_dep("nonexistent-tool-xyz")

    def test_uses_spec_check_cmd(self):
        """Verify shutil.which is called with the spec's check_cmd."""
        with patch("wafer.deps.shutil.which", return_value=None) as mock_which:
            check_dep("gh")
            mock_which.assert_called_once_with("gh")


# =============================================================================
# check_all_deps()
# =============================================================================


class TestCheckAllDeps:
    """Test check_all_deps() function."""

    def test_returns_dict_with_all_deps(self):
        with patch("wafer.deps.shutil.which", return_value=None):
            result = check_all_deps()
            assert set(result.keys()) == set(DEPS_REGISTRY.keys())

    def test_handles_mixed_installed(self):
        """Some tools installed, some not."""

        def selective_which(cmd):
            return "/usr/bin/gh" if cmd == "gh" else None

        with patch("wafer.deps.shutil.which", side_effect=selective_which):
            result = check_all_deps()
            assert result["gh"] is True
            assert result["ncu"] is False
