"""Unit tests for Distributed Traces CLI commands.

Tests the wafer tool nvidia-distributed-traces and amd-distributed-traces commands using CliRunner.

Run with: PYTHONPATH=apps/wafer-cli uv run pytest apps/wafer-cli/tests/test_distributed_traces_cli.py -v
"""

import json
import re
from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest
from typer.testing import CliRunner

from wafer.cli import app

runner = CliRunner()


def strip_ansi(text: str) -> str:
    """Remove ANSI escape codes from text."""
    ansi_escape = re.compile(r"\x1B(?:[@-Z\\-_]|\[[0-?]*[ -/]*[@-~])")
    return ansi_escape.sub("", text)


# ============================================================================
# Sample Trace Data
# ============================================================================

SAMPLE_PYTORCH_TRACE = {
    "traceEvents": [
        {
            "ph": "X",
            "cat": "cpu_op",
            "name": "nccl:all_reduce",
            "pid": 0,
            "tid": 0,
            "ts": 1000000,
            "dur": 5000,
            "args": {
                "message_size": 4194304,
                "sequence": 1,
            }
        },
        {
            "ph": "X",
            "cat": "cpu_op", 
            "name": "nccl:all_gather",
            "pid": 0,
            "tid": 0,
            "ts": 1010000,
            "dur": 3000,
            "args": {
                "message_size": 2097152,
                "sequence": 2,
            }
        },
        {
            "ph": "X",
            "cat": "kernel",
            "name": "volta_fp16_gemm",
            "pid": 0,
            "tid": 1,
            "ts": 1000000,
            "dur": 4000,
            "args": {"device": 0}
        },
    ]
}

SAMPLE_NCCL_INSPECTOR_LINES = [
    '{"type": "comm_init", "comm_id": "comm_0", "nranks": 4, "rank": 0}',
    '{"type": "coll_start", "comm_id": "comm_0", "seq": 1, "op": "allreduce", "count": 1048576, "datatype": "float32", "startNs": 1000000000}',
    '{"type": "coll_end", "comm_id": "comm_0", "seq": 1, "endNs": 1005000000}',
    '{"type": "coll_start", "comm_id": "comm_0", "seq": 2, "op": "allgather", "count": 524288, "datatype": "float32", "startNs": 1010000000}',
    '{"type": "coll_end", "comm_id": "comm_0", "seq": 2, "endNs": 1013000000}',
]


def create_multi_rank_traces(tmp_path: Path, num_ranks: int = 4) -> list[Path]:
    """Create trace files for multiple ranks."""
    files = []
    for rank in range(num_ranks):
        trace = {
            "traceEvents": [
                {
                    "ph": "X",
                    "cat": "cpu_op",
                    "name": "nccl:all_reduce",
                    "pid": rank,
                    "tid": 0,
                    "ts": 1000000 + rank * 100,
                    "dur": 5000 + rank * 500,  # Rank variation
                    "args": {"message_size": 4194304, "sequence": 1}
                },
                {
                    "ph": "X",
                    "cat": "cpu_op",
                    "name": "nccl:all_gather",
                    "pid": rank,
                    "tid": 0,
                    "ts": 1010000,
                    "dur": 3000 + rank * 300,
                    "args": {"message_size": 2097152, "sequence": 2}
                },
            ]
        }
        trace_file = tmp_path / f"trace_rank{rank}.json"
        trace_file.write_text(json.dumps(trace))
        files.append(trace_file)
    return files


# ============================================================================
# NVIDIA Analyze Command Tests
# ============================================================================

class TestNvidiaAnalyzeCommand:
    """Tests for wafer tool distributed-traces analyze command."""

    def test_analyze_single_trace(self, tmp_path: Path) -> None:
        """Should analyze a single trace file."""
        trace_file = tmp_path / "trace_rank0.json"
        trace_file.write_text(json.dumps(SAMPLE_PYTORCH_TRACE))

        result = runner.invoke(app, [
            "tool", "nvidia-distributed-traces", "analyze", str(trace_file)
        ])

        assert result.exit_code == 0, f"Failed: {result.output}"
        output = strip_ansi(result.stdout)
        assert "DISTRIBUTED TRACES ANALYSIS" in output
        assert "Ranks:" in output

    def test_analyze_multiple_traces(self, tmp_path: Path) -> None:
        """Should analyze multiple rank traces."""
        files = create_multi_rank_traces(tmp_path, 4)

        result = runner.invoke(app, [
            "tool", "nvidia-distributed-traces", "analyze",
            *[str(f) for f in files]
        ])

        assert result.exit_code == 0, f"Failed: {result.output}"
        output = strip_ansi(result.stdout)
        assert "Ranks: 4" in output

    def test_analyze_directory(self, tmp_path: Path) -> None:
        """Should analyze all trace files in a directory."""
        create_multi_rank_traces(tmp_path, 4)

        result = runner.invoke(app, [
            "tool", "nvidia-distributed-traces", "analyze", str(tmp_path)
        ])

        assert result.exit_code == 0, f"Failed: {result.output}"
        output = strip_ansi(result.stdout)
        assert "Ranks:" in output

    def test_analyze_json_output(self, tmp_path: Path) -> None:
        """Should output JSON when --json flag is used."""
        files = create_multi_rank_traces(tmp_path)

        result = runner.invoke(app, [
            "tool", "nvidia-distributed-traces", "analyze",
            *[str(f) for f in files],
            "--json"
        ])

        assert result.exit_code == 0, f"Failed: {result.output}"
        data = json.loads(result.stdout)
        assert "session" in data or "summary" in data

    def test_analyze_csv_output(self, tmp_path: Path) -> None:
        """Should output CSV when --format csv is used."""
        files = create_multi_rank_traces(tmp_path)

        result = runner.invoke(app, [
            "tool", "nvidia-distributed-traces", "analyze",
            *[str(f) for f in files],
            "--format", "csv"
        ])

        assert result.exit_code == 0, f"Failed: {result.output}"
        assert "rank" in result.stdout.lower() or "collective" in result.stdout.lower()

    def test_analyze_output_to_file(self, tmp_path: Path) -> None:
        """Should write output to file when -o is specified."""
        files = create_multi_rank_traces(tmp_path)
        output_file = tmp_path / "output.json"

        result = runner.invoke(app, [
            "tool", "nvidia-distributed-traces", "analyze",
            *[str(f) for f in files],
            "--json",
            "-o", str(output_file)
        ])

        assert result.exit_code == 0, f"Failed: {result.output}"
        assert output_file.exists()

    def test_analyze_with_interconnect(self, tmp_path: Path) -> None:
        """Should accept interconnect option."""
        files = create_multi_rank_traces(tmp_path)

        result = runner.invoke(app, [
            "tool", "nvidia-distributed-traces", "analyze",
            *[str(f) for f in files],
            "--interconnect", "nvlink4"
        ])

        assert result.exit_code == 0, f"Failed: {result.output}"

    def test_analyze_with_timeout(self, tmp_path: Path) -> None:
        """Should accept timeout option."""
        files = create_multi_rank_traces(tmp_path)

        result = runner.invoke(app, [
            "tool", "nvidia-distributed-traces", "analyze",
            *[str(f) for f in files],
            "--timeout", "300"
        ])

        assert result.exit_code == 0, f"Failed: {result.output}"

    def test_analyze_verbose(self, tmp_path: Path) -> None:
        """Should show verbose output."""
        files = create_multi_rank_traces(tmp_path)

        result = runner.invoke(app, [
            "tool", "nvidia-distributed-traces", "analyze",
            *[str(f) for f in files],
            "--verbose"
        ])

        assert result.exit_code == 0, f"Failed: {result.output}"
        output = strip_ansi(result.stdout)
        # Verbose should show more details
        assert "Loading" in output or "Collectives by Type" in output

    def test_analyze_file_not_found(self, tmp_path: Path) -> None:
        """Should fail with exit code 1 for missing file."""
        nonexistent = tmp_path / "missing.json"

        result = runner.invoke(app, [
            "tool", "nvidia-distributed-traces", "analyze", str(nonexistent)
        ])

        assert result.exit_code != 0
        output = result.output.lower()
        assert "error" in output or "not found" in output

    def test_analyze_empty_directory(self, tmp_path: Path) -> None:
        """Should handle empty directories gracefully."""
        empty_dir = tmp_path / "empty"
        empty_dir.mkdir()

        result = runner.invoke(app, [
            "tool", "nvidia-distributed-traces", "analyze", str(empty_dir)
        ])

        assert result.exit_code != 0
        output = result.output.lower()
        assert "no trace files" in output or "error" in output


# ============================================================================
# NVIDIA Compare Command Tests
# ============================================================================

class TestNvidiaCompareCommand:
    """Tests for wafer tool distributed-traces compare command."""

    def test_compare_two_traces(self, tmp_path: Path) -> None:
        """Should compare two trace sets."""
        baseline_dir = tmp_path / "baseline"
        baseline_dir.mkdir()
        comparison_dir = tmp_path / "comparison"
        comparison_dir.mkdir()

        create_multi_rank_traces(baseline_dir)
        create_multi_rank_traces(comparison_dir)

        result = runner.invoke(app, [
            "tool", "nvidia-distributed-traces", "compare",
            str(baseline_dir), str(comparison_dir)
        ])

        assert result.exit_code == 0, f"Failed: {result.output}"
        output = strip_ansi(result.stdout)
        assert "TRACE COMPARISON" in output or "Bandwidth" in output

    def test_compare_json_output(self, tmp_path: Path) -> None:
        """Should output JSON when --json is used."""
        baseline_dir = tmp_path / "baseline"
        baseline_dir.mkdir()
        comparison_dir = tmp_path / "comparison"
        comparison_dir.mkdir()

        create_multi_rank_traces(baseline_dir)
        create_multi_rank_traces(comparison_dir)

        result = runner.invoke(app, [
            "tool", "nvidia-distributed-traces", "compare",
            str(baseline_dir), str(comparison_dir),
            "--json"
        ])

        assert result.exit_code == 0, f"Failed: {result.output}"
        envelope = json.loads(result.stdout)
        assert envelope["status"] == "ok"
        data = envelope["data"]
        assert "baseline" in data
        assert "comparison" in data

    def test_compare_output_to_file(self, tmp_path: Path) -> None:
        """Should write comparison output to file."""
        baseline_dir = tmp_path / "baseline"
        baseline_dir.mkdir()
        comparison_dir = tmp_path / "comparison"
        comparison_dir.mkdir()
        output_file = tmp_path / "comparison.json"

        create_multi_rank_traces(baseline_dir)
        create_multi_rank_traces(comparison_dir)

        result = runner.invoke(app, [
            "tool", "nvidia-distributed-traces", "compare",
            str(baseline_dir), str(comparison_dir),
            "--json",
            "-o", str(output_file)
        ])

        assert result.exit_code == 0, f"Failed: {result.output}"
        assert output_file.exists()


# ============================================================================
# NVIDIA Metrics Command Tests
# ============================================================================

class TestNvidiaMetricsCommand:
    """Tests for wafer tool distributed-traces metrics command."""

    def test_metrics_displays_info(self) -> None:
        """Should display metrics information."""
        result = runner.invoke(app, [
            "tool", "nvidia-distributed-traces", "metrics"
        ])

        assert result.exit_code == 0
        output = strip_ansi(result.stdout)
        assert "DISTRIBUTED TRACES METRICS" in output
        assert "BANDWIDTH" in output
        assert "OVERLAP" in output
        assert "STRAGGLER" in output
        assert "HANG RISK" in output


# ============================================================================
# AMD Commands Tests
# ============================================================================

class TestAmdAnalyzeCommand:
    """Tests for wafer tool amd-distributed-traces analyze command."""

    def test_analyze_single_trace(self, tmp_path: Path) -> None:
        """Should analyze a single trace file."""
        trace_file = tmp_path / "trace_rank0.json"
        trace_file.write_text(json.dumps(SAMPLE_PYTORCH_TRACE))

        result = runner.invoke(app, [
            "tool", "amd-distributed-traces", "analyze", str(trace_file)
        ])

        assert result.exit_code == 0, f"Failed: {result.output}"
        output = strip_ansi(result.stdout)
        assert "DISTRIBUTED TRACES ANALYSIS" in output

    def test_analyze_xgmi_interconnect(self, tmp_path: Path) -> None:
        """Should accept xgmi interconnect for AMD."""
        files = create_multi_rank_traces(tmp_path)

        result = runner.invoke(app, [
            "tool", "amd-distributed-traces", "analyze",
            *[str(f) for f in files],
            "--interconnect", "xgmi"
        ])

        assert result.exit_code == 0, f"Failed: {result.output}"


class TestAmdMetricsCommand:
    """Tests for wafer tool amd-distributed-traces metrics command."""

    def test_metrics_displays_info(self) -> None:
        """Should display metrics information."""
        result = runner.invoke(app, [
            "tool", "amd-distributed-traces", "metrics"
        ])

        assert result.exit_code == 0
        output = strip_ansi(result.stdout)
        assert "DISTRIBUTED TRACES METRICS" in output


# ============================================================================
# Help Command Tests
# ============================================================================

class TestDistributedTracesHelp:
    """Tests for distributed-traces help text."""

    def test_nvidia_distributed_traces_help(self) -> None:
        """Should display help for nvidia distributed-traces."""
        result = runner.invoke(app, ["tool", "nvidia-distributed-traces", "--help"])

        assert result.exit_code == 0
        output = strip_ansi(result.stdout)
        assert "analyze" in output.lower()
        assert "collect" in output.lower()
        assert "compare" in output.lower()
        assert "metrics" in output.lower()

    def test_nvidia_analyze_help(self) -> None:
        """Should display help for analyze command."""
        result = runner.invoke(app, ["tool", "nvidia-distributed-traces", "analyze", "--help"])

        assert result.exit_code == 0
        output = strip_ansi(result.stdout)
        assert "Analyze NCCL" in output
        assert "--json" in output
        assert "--format" in output
        assert "--interconnect" in output

    def test_nvidia_compare_help(self) -> None:
        """Should display help for compare command."""
        result = runner.invoke(app, ["tool", "nvidia-distributed-traces", "compare", "--help"])

        assert result.exit_code == 0
        output = strip_ansi(result.stdout)
        assert "Compare" in output or "compare" in output

    def test_nvidia_collect_help(self) -> None:
        """Should display help for collect command."""
        result = runner.invoke(app, ["tool", "nvidia-distributed-traces", "collect", "--help"])

        assert result.exit_code == 0
        output = strip_ansi(result.stdout)
        assert "tracing" in output.lower() or "collection" in output.lower()

    def test_amd_distributed_traces_help(self) -> None:
        """Should display help for amd distributed-traces."""
        result = runner.invoke(app, ["tool", "amd-distributed-traces", "--help"])

        assert result.exit_code == 0
        output = strip_ansi(result.stdout)
        assert "RCCL" in output or "analyze" in output.lower()


# ============================================================================
# Output Format Tests
# ============================================================================

class TestOutputFormats:
    """Tests for output formatting."""

    def test_text_output_has_sections(self, tmp_path: Path) -> None:
        """Text output should have all sections."""
        files = create_multi_rank_traces(tmp_path)

        result = runner.invoke(app, [
            "tool", "nvidia-distributed-traces", "analyze",
            *[str(f) for f in files]
        ])

        assert result.exit_code == 0
        output = strip_ansi(result.stdout)
        assert "Bandwidth" in output
        assert "Overlap" in output
        assert "Straggler" in output
        assert "Hang Risk" in output

    def test_json_output_structure(self, tmp_path: Path) -> None:
        """JSON output should have required structure."""
        files = create_multi_rank_traces(tmp_path)

        result = runner.invoke(app, [
            "tool", "nvidia-distributed-traces", "analyze",
            *[str(f) for f in files],
            "--json"
        ])

        assert result.exit_code == 0
        data = json.loads(result.stdout)
        
        # Check for expected keys in output
        # The actual structure depends on implementation
        assert isinstance(data, dict)


# ============================================================================
# Straggler Detection Tests
# ============================================================================

class TestStragglerDetection:
    """Tests for straggler detection output."""

    def test_detects_slow_rank(self, tmp_path: Path) -> None:
        """Should detect when one rank is significantly slower."""
        # Create traces where rank 3 is much slower
        files = []
        for rank in range(4):
            slow_factor = 10 if rank == 3 else 1  # Rank 3 is 10x slower
            trace = {
                "traceEvents": [
                    {
                        "ph": "X",
                        "cat": "cpu_op",
                        "name": "nccl:all_reduce",
                        "pid": rank,
                        "tid": 0,
                        "ts": 1000000,
                        "dur": 5000 * slow_factor,
                        "args": {"message_size": 4194304, "sequence": 1}
                    },
                ]
            }
            trace_file = tmp_path / f"trace_rank{rank}.json"
            trace_file.write_text(json.dumps(trace))
            files.append(trace_file)

        result = runner.invoke(app, [
            "tool", "nvidia-distributed-traces", "analyze",
            *[str(f) for f in files]
        ])

        assert result.exit_code == 0
        output = strip_ansi(result.stdout)
        # Should mention straggler detection
        assert "Straggler" in output


# ============================================================================
# Edge Cases
# ============================================================================

class TestEdgeCases:
    """Tests for edge cases and error handling."""

    def test_single_rank_trace(self, tmp_path: Path) -> None:
        """Should handle single-rank traces."""
        trace_file = tmp_path / "trace.json"
        trace_file.write_text(json.dumps(SAMPLE_PYTORCH_TRACE))

        result = runner.invoke(app, [
            "tool", "nvidia-distributed-traces", "analyze", str(trace_file)
        ])

        assert result.exit_code == 0
        output = strip_ansi(result.stdout)
        assert "Ranks: 1" in output

    def test_invalid_json(self, tmp_path: Path) -> None:
        """Should handle invalid JSON gracefully."""
        bad_file = tmp_path / "bad.json"
        bad_file.write_text("not valid json")

        result = runner.invoke(app, [
            "tool", "nvidia-distributed-traces", "analyze", str(bad_file)
        ])

        assert result.exit_code != 0

    def test_empty_trace(self, tmp_path: Path) -> None:
        """Should handle empty trace files."""
        empty_trace = tmp_path / "empty.json"
        empty_trace.write_text('{"traceEvents": []}')

        result = runner.invoke(app, [
            "tool", "nvidia-distributed-traces", "analyze", str(empty_trace)
        ])

        # Should either succeed with warning or fail gracefully
        # depending on implementation
        assert "error" in result.output.lower() or result.exit_code == 0

    def test_glob_pattern_expansion(self, tmp_path: Path) -> None:
        """Should expand glob patterns."""
        create_multi_rank_traces(tmp_path, 4)

        # Use glob pattern
        result = runner.invoke(app, [
            "tool", "nvidia-distributed-traces", "analyze",
            str(tmp_path / "trace_rank*.json")
        ])

        assert result.exit_code == 0, f"Failed: {result.output}"
