"""Tests for Docker pull progress feedback and ANSI stripping.

Covers:
- _strip_ansi removes cursor movement, color codes, carriage returns
- _ensure_docker_image skips pull when image exists (async + sync)
- _ensure_docker_image pulls when image missing (async + sync)
- _ensure_docker_image raises on pull failure (async + sync)

Run with: uv run pytest apps/wafer-cli/tests/test_docker_progress.py -v
"""

import asyncio
from dataclasses import dataclass
from unittest.mock import AsyncMock, MagicMock

import pytest

# ---------------------------------------------------------------------------
# Test Group 1: _strip_ansi
# ---------------------------------------------------------------------------


class TestStripAnsi:
    """ANSI escape code stripping for clean Docker output."""

    def _strip(self, text: str) -> str:
        from wafer.evaluate import _strip_ansi

        return _strip_ansi(text)

    def test_strips_cursor_movement(self) -> None:
        raw = "\x1b[1A\x1b[2KSome text\x1b[1B"
        assert self._strip(raw) == "Some text"

    def test_strips_color_codes(self) -> None:
        raw = "\x1b[32mgreen text\x1b[0m"
        assert self._strip(raw) == "green text"

    def test_preserves_clean_text(self) -> None:
        clean = "No ANSI codes here"
        assert self._strip(clean) == clean

    def test_strips_carriage_return(self) -> None:
        raw = "progress: 50%\rprogress: 100%"
        assert self._strip(raw) == "progress: 50%progress: 100%"

    def test_real_docker_pull_output(self) -> None:
        raw = "\x1b[1A\x1b[2K4b3ffd8ccb52: Already exists \x1b[1B"
        assert self._strip(raw) == "4b3ffd8ccb52: Already exists "


# ---------------------------------------------------------------------------
# Test Group 2: _ensure_docker_image (async — evaluate.py)
# ---------------------------------------------------------------------------


@dataclass
class FakeExecResult:
    stdout: str = ""
    stderr: str = ""
    exit_code: int = 0


class TestEnsureDockerImage:
    """Async _ensure_docker_image from evaluate.py."""

    def test_image_exists_no_pull(self) -> None:
        from wafer.evaluate import _ensure_docker_image

        client = AsyncMock()
        client.exec.return_value = FakeExecResult(exit_code=0)

        asyncio.run(_ensure_docker_image(client, "nvidia/cuda:12.0"))

        # Only inspect was called, no pull
        client.exec.assert_called_once()
        call_cmd = client.exec.call_args[0][0]
        assert "docker image inspect" in call_cmd

    def test_image_missing_pulls(self, capsys: pytest.CaptureFixture) -> None:
        from wafer.evaluate import _ensure_docker_image

        client = AsyncMock()
        # First call: inspect fails (image not found)
        # Second call: pull succeeds
        client.exec.side_effect = [
            FakeExecResult(exit_code=1),
            FakeExecResult(exit_code=0, stdout="Pull complete"),
        ]

        asyncio.run(_ensure_docker_image(client, "nvidia/cuda:12.0"))

        assert client.exec.call_count == 2
        pull_cmd = client.exec.call_args_list[1][0][0]
        assert "docker pull" in pull_cmd
        captured = capsys.readouterr()
        assert "Pulling Docker image" in captured.out
        assert "Docker image ready" in captured.out

    def test_pull_failure_raises(self) -> None:
        from wafer.evaluate import _ensure_docker_image

        client = AsyncMock()
        client.exec.side_effect = [
            FakeExecResult(exit_code=1),
            FakeExecResult(exit_code=1, stderr="connection refused"),
        ]

        with pytest.raises(RuntimeError, match="Failed to pull Docker image"):
            asyncio.run(_ensure_docker_image(client, "nvidia/cuda:12.0"))


# ---------------------------------------------------------------------------
# Test Group 3: _ensure_docker_image sync (gpu_run.py)
# ---------------------------------------------------------------------------


class TestEnsureDockerImageSync:
    """Sync _ensure_docker_image from gpu_run.py."""

    def test_image_exists_no_pull(self) -> None:
        from wafer.gpu_run import _ensure_docker_image

        client = MagicMock()
        client.exec.return_value = FakeExecResult(exit_code=0)

        _ensure_docker_image(client, "nvidia/cuda:12.0")

        client.exec.assert_called_once()
        call_cmd = client.exec.call_args[0][0]
        assert "docker image inspect" in call_cmd

    def test_image_missing_pulls(self, capsys: pytest.CaptureFixture) -> None:
        from wafer.gpu_run import _ensure_docker_image

        client = MagicMock()
        client.exec.side_effect = [
            FakeExecResult(exit_code=1),
            FakeExecResult(exit_code=0, stdout="Pull complete"),
        ]

        _ensure_docker_image(client, "nvidia/cuda:12.0")

        assert client.exec.call_count == 2
        pull_cmd = client.exec.call_args_list[1][0][0]
        assert "docker pull" in pull_cmd
        captured = capsys.readouterr()
        assert "Pulling Docker image" in captured.out
        assert "Docker image ready" in captured.out

    def test_pull_failure_raises(self) -> None:
        from wafer.gpu_run import _ensure_docker_image

        client = MagicMock()
        client.exec.side_effect = [
            FakeExecResult(exit_code=1),
            FakeExecResult(exit_code=1, stderr="connection refused"),
        ]

        with pytest.raises(RuntimeError, match="Failed to pull Docker image"):
            _ensure_docker_image(client, "nvidia/cuda:12.0")
