"""Tests for wafer tool eval UX improvements.

Covers:
- Ghost flags removed from --help
- Error message lists all 7 subcommands
- make-template docstring mentions gpumode
- aiter --json flag

Run with: PYTHONPATH=apps/wafer-cli uv run pytest apps/wafer-cli/tests/test_evaluate_ux.py -v
"""

import json
import re
from dataclasses import dataclass
from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest
from typer.testing import CliRunner

from wafer.cli import app

runner = CliRunner()


# ---------------------------------------------------------------------------
# Test Group 1: Ghost flags removed from evaluate --help
# ---------------------------------------------------------------------------


class TestEvaluateGhostFlagsRemoved:
    """Ghost flags that appeared in --help but did nothing should be gone."""

    def _get_help(self) -> str:
        result = runner.invoke(app, ["tool", "eval", "--help"])
        return result.output

    def test_help_no_impl_flag(self) -> None:
        assert "--impl" not in self._get_help()

    def test_help_no_reference_flag(self) -> None:
        assert "--reference" not in self._get_help()

    def test_help_no_test_cases_flag(self) -> None:
        assert "--test-cases" not in self._get_help()

    def test_help_no_benchmark_flag(self) -> None:
        assert "--benchmark" not in self._get_help()

    def test_help_no_profile_flag(self) -> None:
        assert "--profile" not in self._get_help()

    def test_help_no_defensive_flag(self) -> None:
        assert "--defensive" not in self._get_help()

    def test_help_still_works(self) -> None:
        result = runner.invoke(app, ["tool", "eval", "--help"])
        assert result.exit_code == 0


# ---------------------------------------------------------------------------
# Test Group 2: Bare evaluate error lists ALL subcommands
# ---------------------------------------------------------------------------


class TestEvaluateErrorListsAllSubcommands:
    """Bare 'wafer tool eval' should exit 1 and list all 7 subcommands."""

    def _get_bare_output(self) -> tuple[int, str]:
        result = runner.invoke(app, ["tool", "eval"])
        return result.exit_code, result.output

    def test_bare_evaluate_exits_1(self) -> None:
        exit_code, _ = self._get_bare_output()
        assert exit_code == 1

    def test_error_lists_gpumode(self) -> None:
        _, output = self._get_bare_output()
        assert "gpumode" in output

    def test_error_lists_kernelbench(self) -> None:
        _, output = self._get_bare_output()
        assert "kernelbench" in output

    def test_error_lists_aiter(self) -> None:
        _, output = self._get_bare_output()
        assert "aiter" in output

    def test_error_lists_vllm(self) -> None:
        _, output = self._get_bare_output()
        assert "vllm" in output

    def test_error_lists_flashinfer_bench(self) -> None:
        _, output = self._get_bare_output()
        assert "flashinfer-bench" in output

    def test_error_lists_hipblaslt(self) -> None:
        _, output = self._get_bare_output()
        assert "hipblaslt" in output

    def test_error_lists_make_template(self) -> None:
        _, output = self._get_bare_output()
        assert "make-template" in output


# ---------------------------------------------------------------------------
# Test Group 3: make-template docstring
# ---------------------------------------------------------------------------


class TestMakeTemplateDocstring:
    """make-template --help should mention gpumode and functional format."""

    def _get_help(self) -> str:
        result = runner.invoke(app, ["tool", "eval", "make-template", "--help"])
        assert result.exit_code == 0
        return result.output

    def test_make_template_help_mentions_gpumode(self) -> None:
        assert "gpumode" in self._get_help()

    def test_make_template_help_mentions_functional(self) -> None:
        assert "functional" in self._get_help().lower()


# ---------------------------------------------------------------------------
# Test Group 4: aiter --json flag
# ---------------------------------------------------------------------------


@dataclass
class MockAiterResult:
    """Mock EvaluateResult for aiter tests."""

    success: bool
    all_correct: bool | None
    correctness_score: float
    geomean_speedup: float
    passed_tests: int
    total_tests: int
    error_message: str | None = None
    artifact_path: Path | None = None


class TestAiterJsonFlag:
    """aiter subcommand should support --json for machine-readable output."""

    def test_aiter_help_has_json_flag(self) -> None:
        result = runner.invoke(app, ["tool", "eval", "aiter", "--help"])
        assert result.exit_code == 0
        # Strip ANSI escape codes before checking (Typer rich output splits --json with color codes)
        clean = re.sub(r"\x1b\[[0-9;]*m", "", result.output)
        assert "--json" in clean

    @patch("trio_asyncio.run")
    def test_aiter_json_output(self, mock_trio_run: MagicMock, tmp_path: Path) -> None:
        """With --json, output should be valid JSON with expected keys."""
        mock_trio_run.return_value = MockAiterResult(
            success=True,
            all_correct=True,
            correctness_score=1.0,
            geomean_speedup=0.0,
            passed_tests=3,
            total_tests=3,
        )
        aiter_dir = tmp_path / "aiter"
        aiter_dir.mkdir()

        result = runner.invoke(app, [
            "tool", "eval", "aiter",
            "--aiter-dir", str(aiter_dir),
            "--cmd", "python test.py",
            "--target", "fake-target",
            "--json",
        ])
        assert result.exit_code == 0, f"Failed: {result.output}"

        envelope = json.loads(result.stdout)
        assert envelope["status"] == "ok"
        data = envelope["data"]
        assert "correct" in data
        assert "passed_tests" in data
        assert "total_tests" in data
        assert data["correct"] is True
        assert data["passed_tests"] == 3

    @patch("trio_asyncio.run")
    def test_aiter_text_output(self, mock_trio_run: MagicMock, tmp_path: Path) -> None:
        """Without --json, output should be human-readable, not JSON."""
        mock_trio_run.return_value = MockAiterResult(
            success=True,
            all_correct=True,
            correctness_score=1.0,
            geomean_speedup=0.0,
            passed_tests=3,
            total_tests=3,
        )
        aiter_dir = tmp_path / "aiter"
        aiter_dir.mkdir()

        result = runner.invoke(app, [
            "tool", "eval", "aiter",
            "--aiter-dir", str(aiter_dir),
            "--cmd", "python test.py",
            "--target", "fake-target",
        ])
        assert result.exit_code == 0, f"Failed: {result.output}"

        # Should NOT be valid JSON
        with pytest.raises(json.JSONDecodeError):
            json.loads(result.stdout)

        # Should contain human-readable text
        assert "passed" in result.stdout.lower() or "tests" in result.stdout.lower()
