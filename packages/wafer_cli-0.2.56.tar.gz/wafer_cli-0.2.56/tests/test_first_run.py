"""Integration tests for the first-run welcome experience and deps CLI.

Run with: uv run pytest apps/wafer-cli/tests/test_first_run.py -v
"""

import json
from unittest.mock import patch

from typer.testing import CliRunner

from wafer.auth import Credentials
from wafer.cli import app

runner = CliRunner()


def _mock_creds():
    return Credentials(
        access_token="fake-token",
        refresh_token="fake-refresh",
        email="test@example.com",
    )


# =============================================================================
# First-run welcome (no credentials)
# =============================================================================


class TestFirstRunWelcome:
    """Bare `wafer` with no credentials shows welcome message."""

    def test_bare_wafer_no_creds_shows_welcome(self):
        with patch("wafer.auth.load_credentials", return_value=None):
            result = runner.invoke(app, [])
            assert result.exit_code == 0, result.output
            assert "wafer login" in result.output
            assert "Wafer CLI" in result.output

    def test_bare_wafer_no_creds_not_help_dump(self):
        """Should NOT dump the full 22+ command help listing."""
        with patch("wafer.auth.load_credentials", return_value=None):
            result = runner.invoke(app, [])
            # Full help contains "Usage:" header and lots of commands
            assert result.output.count("Usage:") == 0

    def test_bare_wafer_no_creds_mentions_guide(self):
        with patch("wafer.auth.load_credentials", return_value=None):
            result = runner.invoke(app, [])
            assert "wafer guide" in result.output

    def test_bare_wafer_no_creds_mentions_demo(self):
        with patch("wafer.auth.load_credentials", return_value=None):
            result = runner.invoke(app, [])
            assert "wafer demo" in result.output

    def test_bare_wafer_no_creds_mentions_deps(self):
        with patch("wafer.auth.load_credentials", return_value=None):
            result = runner.invoke(app, [])
            assert "deps" in result.output


# =============================================================================
# Authenticated bare wafer
# =============================================================================


class TestAuthenticatedBareWafer:
    """Bare `wafer` with credentials shows help (existing behavior)."""

    def test_bare_wafer_with_creds_shows_help(self):
        with patch("wafer.auth.load_credentials", return_value=_mock_creds()):
            result = runner.invoke(app, [])
            assert result.exit_code == 0, result.output
            assert "Usage:" in result.output or "GPU development toolkit" in result.output

    def test_bare_wafer_with_creds_no_welcome(self):
        with patch("wafer.auth.load_credentials", return_value=_mock_creds()):
            result = runner.invoke(app, [])
            assert "Get started:" not in result.output


# =============================================================================
# --help flag
# =============================================================================


class TestHelpFlag:
    """--help always shows full help regardless of auth state."""

    def test_help_flag_no_creds(self):
        with patch("wafer.auth.load_credentials", return_value=None):
            result = runner.invoke(app, ["--help"])
            assert result.exit_code == 0
            assert "Usage:" in result.output or "GPU development toolkit" in result.output

    def test_help_flag_with_creds(self):
        with patch("wafer.auth.load_credentials", return_value=_mock_creds()):
            result = runner.invoke(app, ["--help"])
            assert result.exit_code == 0
            assert "Usage:" in result.output or "GPU development toolkit" in result.output


# =============================================================================
# wafer settings deps check
# =============================================================================


class TestDepsCheck:
    """Tests for wafer settings deps check command."""

    def test_deps_check_text_output(self):
        with patch("wafer.deps.shutil.which", return_value=None):
            result = runner.invoke(app, ["settings", "deps", "check"])
            assert result.exit_code == 0, result.output
            assert "ncu" in result.output
            assert "gh" in result.output

    def test_deps_check_json_output(self):
        with patch("wafer.deps.shutil.which", return_value=None):
            result = runner.invoke(app, ["settings", "deps", "check", "--json"])
            assert result.exit_code == 0, result.output
            envelope = json.loads(result.output)
            assert envelope["status"] == "ok"
            data = envelope["data"]
            assert "deps" in data
            assert isinstance(data["deps"], list)
            assert len(data["deps"]) > 0
            for item in data["deps"]:
                assert "name" in item
                assert "installed" in item

    def test_deps_check_shows_installed_tool(self):
        def selective_which(cmd):
            return "/usr/bin/gh" if cmd == "gh" else None

        with patch("wafer.deps.shutil.which", side_effect=selective_which):
            result = runner.invoke(app, ["settings", "deps", "check"])
            assert "installed" in result.output

    def test_deps_check_no_python_packages(self):
        """Output should not contain Python packages like triton/torch."""
        with patch("wafer.deps.shutil.which", return_value=None):
            result = runner.invoke(app, ["settings", "deps", "check"])
            assert "triton" not in result.output.lower()
            assert "torch" not in result.output.lower()
            assert "nvtx" not in result.output.lower()


# =============================================================================
# wafer settings deps install
# =============================================================================


class TestDepsInstall:
    """Tests for wafer settings deps install command."""

    def test_deps_install_unknown_tool(self):
        result = runner.invoke(app, ["settings", "deps", "install", "nonexistent-xyz"])
        assert result.exit_code != 0

    def test_deps_install_prints_hint(self):
        with patch("wafer.deps.shutil.which", return_value=None):
            result = runner.invoke(app, ["settings", "deps", "install", "gh"])
            assert result.exit_code == 0, result.output
            # Should show install command
            assert "install" in result.output.lower() or "gh" in result.output

    def test_deps_install_lists_available_on_error(self):
        result = runner.invoke(app, ["settings", "deps", "install", "fake-tool"])
        assert result.exit_code != 0
        # Error message (in exception) should list available tools
        combined = (result.output or "") + str(result.exception or "")
        assert "Available" in combined or "ncu" in combined
