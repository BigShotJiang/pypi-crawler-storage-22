"""Unit tests for wafer.inference (infer_upload_files)."""

from pathlib import Path

import pytest

from wafer.inference import infer_upload_files


def test_infer_upload_files_includes_command_references(tmp_path: Path) -> None:
    """Command tokens with file extensions are included."""
    kernel = tmp_path / "kernel.cu"
    kernel.write_text("")
    cmd = "nvcc kernel.cu -o kernel"
    result = infer_upload_files(cmd, tmp_path)
    assert kernel in result


def test_infer_upload_files_includes_common_build_files(tmp_path: Path) -> None:
    """Makefile, pyproject.toml, etc. are included when present."""
    makefile = tmp_path / "Makefile"
    makefile.write_text("all:")
    result = infer_upload_files("make", tmp_path)
    assert makefile in result


def test_infer_upload_files_returns_sorted_list(tmp_path: Path) -> None:
    """Result is sorted for deterministic output."""
    (tmp_path / "b.cu").write_text("")
    (tmp_path / "a.cu").write_text("")
    result = infer_upload_files("nvcc a.cu b.cu", tmp_path)
    assert result == sorted(result)
