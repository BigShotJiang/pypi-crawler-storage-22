"""Tests for --json output across CLI commands and make-template fix.

Tests that commands with --json produce valid, parseable JSON with the
expected structure. Uses mocks to avoid requiring GPU/network access.

Run with: PYTHONPATH=apps/wafer-cli uv run pytest apps/wafer-cli/tests/test_json_output.py -v
"""

import json
from dataclasses import dataclass
from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest
from typer.testing import CliRunner

from wafer.cli import app

runner = CliRunner()


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


@dataclass
class MockEvaluateResult:
    """Mock EvaluateResult matching the real dataclass fields."""

    success: bool
    all_correct: bool | None
    correctness_score: float
    geomean_speedup: float
    passed_tests: int
    total_tests: int
    error_message: str | None = None
    artifact_path: Path | None = None


def _make_success_result(
    *,
    speedup: float = 2.5,
    passed: int = 3,
    total: int = 3,
) -> MockEvaluateResult:
    return MockEvaluateResult(
        success=True,
        all_correct=True,
        correctness_score=1.0,
        geomean_speedup=speedup,
        passed_tests=passed,
        total_tests=total,
    )


def _make_failure_result(
    *,
    passed: int = 1,
    total: int = 3,
) -> MockEvaluateResult:
    return MockEvaluateResult(
        success=True,
        all_correct=False,
        correctness_score=passed / total,
        geomean_speedup=0.0,
        passed_tests=passed,
        total_tests=total,
    )


def _make_error_result(msg: str = "SSH connection failed") -> MockEvaluateResult:
    return MockEvaluateResult(
        success=False,
        all_correct=False,
        correctness_score=0.0,
        geomean_speedup=0.0,
        passed_tests=0,
        total_tests=0,
        error_message=msg,
    )


def _write_eval_files(tmp_path: Path) -> tuple[Path, Path, Path]:
    """Create minimal impl, reference, and test-cases files for evaluate."""
    impl = tmp_path / "impl.py"
    impl.write_text(
        "def custom_kernel(inputs):\n    return inputs\n"
    )
    ref = tmp_path / "ref.py"
    ref.write_text(
        "def ref_kernel(inputs):\n    return inputs\n"
        "def generate_input(**kwargs):\n    return {}\n"
    )
    tests = tmp_path / "tests.json"
    tests.write_text('[{"name": "small", "n": 128}]')
    return impl, ref, tests


# ===========================================================================
# Test Group 1: make-template Fix (Plan 004)
# ===========================================================================


class TestMakeTemplateFix:
    """Verify make-template prints 'wafer tool eval gpumode' in next-steps."""

    def test_make_template_prints_gpumode_in_next_steps(self, tmp_path: Path) -> None:
        """make-template output must contain 'wafer tool eval gpumode --impl'."""
        out_dir = tmp_path / "test-kernel"
        result = runner.invoke(app, ["tool", "eval", "make-template", str(out_dir)])
        assert result.exit_code == 0, f"Failed: {result.output}"

        # Correct form is present
        assert "wafer tool eval gpumode --impl" in result.stdout

        # Old wrong form (without gpumode) must NOT appear.
        # Remove the correct occurrences first to avoid false negatives.
        cleaned = result.stdout.replace("wafer tool eval gpumode", "")
        assert "wafer tool eval --impl" not in cleaned

        # Template files were created
        assert (out_dir / "kernel.py").exists()
        assert (out_dir / "reference.py").exists()
        assert (out_dir / "test_cases.json").exists()

    def test_make_template_force_overwrites(self, tmp_path: Path) -> None:
        """make-template --force should overwrite and still show gpumode."""
        out_dir = tmp_path / "test-kernel"
        out_dir.mkdir(parents=True)
        (out_dir / "kernel.py").write_text("# old content")

        result = runner.invoke(
            app, ["tool", "eval", "make-template", str(out_dir), "--force"]
        )
        assert result.exit_code == 0, f"Failed: {result.output}"
        assert "wafer tool eval gpumode --impl" in result.stdout


# ===========================================================================
# Test Group 2: evaluate gpumode --json
# ===========================================================================


_trio_asyncio_available = True
try:
    import trio_asyncio  # noqa: F401
except (ImportError, AttributeError):
    _trio_asyncio_available = False


@pytest.mark.skipif(not _trio_asyncio_available, reason="trio_asyncio incompatible with this Python version")
class TestEvaluateGpumodeJsonOutput:
    """Tests for evaluate gpumode --json/--jsonl output."""

    @patch("trio_asyncio.run")
    def test_gpumode_json_success(self, mock_trio_run: MagicMock, tmp_path: Path) -> None:
        """--json should emit valid JSON with standardized envelope on passing eval."""
        mock_trio_run.return_value = _make_success_result()
        impl, ref, tests = _write_eval_files(tmp_path)

        result = runner.invoke(app, [
            "tool", "eval", "gpumode",
            "--impl", str(impl),
            "--reference", str(ref),
            "--test-cases", str(tests),
            "--target", "fake-target",
            "--json",
        ])
        assert result.exit_code == 0, f"Failed: {result.output}"

        envelope = json.loads(result.stdout)
        assert envelope["status"] == "ok"
        data = envelope["data"]
        assert data["status"] == "success"
        assert data["correctness"]["passed"] is True
        assert data["correctness"]["tests_run"] == 3
        assert data["benchmark"]["speedup"] == 2.5

    @patch("trio_asyncio.run")
    def test_gpumode_json_correctness_failure(self, mock_trio_run: MagicMock, tmp_path: Path) -> None:
        """--json should emit envelope with inner status=failure when correctness fails."""
        mock_trio_run.return_value = _make_failure_result(passed=1, total=3)
        impl, ref, tests = _write_eval_files(tmp_path)

        result = runner.invoke(app, [
            "tool", "eval", "gpumode",
            "--impl", str(impl),
            "--reference", str(ref),
            "--test-cases", str(tests),
            "--target", "fake-target",
            "--json",
        ])
        # Exit code 1 because correctness failed
        assert result.exit_code == 1

        envelope = json.loads(result.stdout)
        assert envelope["status"] == "ok"
        data = envelope["data"]
        assert data["status"] == "failure"
        assert data["correctness"]["passed"] is False

    @patch("trio_asyncio.run")
    def test_gpumode_json_error(self, mock_trio_run: MagicMock, tmp_path: Path) -> None:
        """--json should emit envelope status=error when evaluation errors."""
        mock_trio_run.return_value = _make_error_result("SSH connection failed")
        impl, ref, tests = _write_eval_files(tmp_path)

        result = runner.invoke(app, [
            "tool", "eval", "gpumode",
            "--impl", str(impl),
            "--reference", str(ref),
            "--test-cases", str(tests),
            "--target", "fake-target",
            "--json",
        ])
        assert result.exit_code == 1

        envelope = json.loads(result.stdout)
        assert envelope["status"] == "error"
        assert "error" in envelope["data"]

    @patch("trio_asyncio.run")
    def test_gpumode_jsonl_streaming(self, mock_trio_run: MagicMock, tmp_path: Path) -> None:
        """--jsonl should emit NDJSON lines ending with a completed event."""
        mock_trio_run.return_value = _make_success_result()
        impl, ref, tests = _write_eval_files(tmp_path)

        result = runner.invoke(app, [
            "tool", "eval", "gpumode",
            "--impl", str(impl),
            "--reference", str(ref),
            "--test-cases", str(tests),
            "--target", "fake-target",
            "--jsonl",
        ])
        assert result.exit_code == 0, f"Failed: {result.output}"

        lines = [l for l in result.stdout.strip().split("\n") if l.strip()]
        assert len(lines) >= 2  # at least "started" + "completed"

        # Every line should be valid JSON
        events = []
        for line in lines:
            obj = json.loads(line)
            assert "event" in obj
            events.append(obj["event"])

        assert "completed" in events

    @patch("trio_asyncio.run")
    def test_gpumode_text_output_unchanged(self, mock_trio_run: MagicMock, tmp_path: Path) -> None:
        """Without --json, output should be human-readable, not JSON."""
        mock_trio_run.return_value = _make_success_result()
        impl, ref, tests = _write_eval_files(tmp_path)

        result = runner.invoke(app, [
            "tool", "eval", "gpumode",
            "--impl", str(impl),
            "--reference", str(ref),
            "--test-cases", str(tests),
            "--target", "fake-target",
        ])
        assert result.exit_code == 0, f"Failed: {result.output}"
        assert "Result: PASS" in result.stdout
        assert "Correctness:" in result.stdout
        assert "Speedup:" in result.stdout

        # Should NOT be valid JSON
        with pytest.raises(json.JSONDecodeError):
            json.loads(result.stdout)


# ===========================================================================
# Test Group 3: roofline --json
# ===========================================================================


class TestRooflineJsonOutput:
    """Tests for roofline --json output. No mocking needed (pure computation)."""

    def test_roofline_json_compute_bound(self) -> None:
        """Compute-bound matmul should return valid JSON envelope with correct bottleneck."""
        result = runner.invoke(app, [
            "tool", "roofline",
            "--gpu", "H100",
            "--bytes", "100.7e6",
            "--flops", "137.4e12",
            "--time-ms", "85",
            "--json",
        ])
        assert result.exit_code == 0, f"Failed: {result.output}"

        envelope = json.loads(result.stdout)
        assert envelope["status"] == "ok"
        data = envelope["data"]
        assert "H100" in data["gpu"]
        assert data["bottleneck"] == "compute"
        assert "efficiency_pct" in data
        assert 75 < data["efficiency_pct"] < 90
        assert "arithmetic_intensity" in data
        assert "ridge_point" in data
        assert data["arithmetic_intensity"] > data["ridge_point"]

    def test_roofline_json_memory_bound(self) -> None:
        """Memory-bound elementwise add should return bottleneck=memory."""
        result = runner.invoke(app, [
            "tool", "roofline",
            "--gpu", "H100",
            "--bytes", "4e9",
            "--flops", "1e9",
            "--time-ms", "2",
            "--json",
        ])
        assert result.exit_code == 0, f"Failed: {result.output}"

        envelope = json.loads(result.stdout)
        assert envelope["status"] == "ok"
        data = envelope["data"]
        assert data["bottleneck"] == "memory"
        assert data["arithmetic_intensity"] < data["ridge_point"]

    def test_roofline_list_gpus_json(self) -> None:
        """--list-gpus --json should return an envelope with gpus list."""
        result = runner.invoke(app, ["tool", "roofline", "--list-gpus", "--json"])
        assert result.exit_code == 0, f"Failed: {result.output}"

        envelope = json.loads(result.stdout)
        assert envelope["status"] == "ok"
        gpu_list = envelope["data"]["gpus"]
        assert isinstance(gpu_list, list)
        assert len(gpu_list) > 0

        # Check structure of first entry
        first = gpu_list[0]
        assert "name" in first
        assert "full_name" in first
        assert "peak_bandwidth_gbps" in first
        assert "peak_tflops_fp16" in first

        # Known GPUs should be present
        names = [g["name"] for g in gpu_list]
        assert "H100" in names
        assert "B200" in names

    def test_roofline_json_missing_args(self) -> None:
        """Missing required args should error even with --json."""
        result = runner.invoke(app, ["tool", "roofline", "--gpu", "H100", "--json"])
        assert result.exit_code != 0
        # Should mention missing options
        assert "Missing" in result.output or "missing" in result.output

    def test_roofline_text_output_unchanged(self) -> None:
        """Without --json, output should be the human-readable report."""
        result = runner.invoke(app, [
            "tool", "roofline",
            "--gpu", "H100",
            "--bytes", "1e9",
            "--flops", "1e12",
            "--time-ms", "1",
        ])
        assert result.exit_code == 0, f"Failed: {result.output}"
        assert "GPU:" in result.stdout
        assert "COMPUTE BOUND" in result.stdout or "MEMORY BOUND" in result.stdout
        assert "Efficiency" in result.stdout

        # Should NOT be valid JSON
        with pytest.raises(json.JSONDecodeError):
            json.loads(result.stdout)


# ===========================================================================
# Test Group 4: target config list --json
# ===========================================================================


class TestTargetsListJsonOutput:
    """Tests for target config list --json. Mocks target loading."""

    @patch("trio.run")
    @patch("wafer.targets.get_default_target")
    @patch("wafer.targets.list_targets")
    def test_targets_list_json_empty(
        self,
        mock_list: MagicMock,
        mock_default: MagicMock,
        mock_trio_run: MagicMock,
    ) -> None:
        """Empty target list should return envelope with empty targets array."""
        mock_list.return_value = []
        mock_default.return_value = None

        result = runner.invoke(app, ["target", "config", "list", "--json"])
        assert result.exit_code == 0, f"Failed: {result.output}"

        envelope = json.loads(result.stdout)
        assert envelope["status"] == "ok"
        assert envelope["data"]["targets"] == []

    @patch("trio.run")
    @patch("wafer.targets.get_default_target")
    @patch("wafer.targets.list_targets")
    def test_targets_list_json_with_targets(
        self,
        mock_list: MagicMock,
        mock_default: MagicMock,
        mock_trio_run: MagicMock,
    ) -> None:
        """Populated target list should return JSON array of target objects."""
        mock_list.return_value = ["vultr-b200", "modal-b200"]
        mock_default.return_value = "vultr-b200"
        mock_trio_run.return_value = [
            ("vultr-b200", "reachable", "user@1.2.3.4:22"),
            ("modal-b200", "serverless", ""),
        ]

        result = runner.invoke(app, ["target", "config", "list", "--json"])
        assert result.exit_code == 0, f"Failed: {result.output}"

        envelope = json.loads(result.stdout)
        assert envelope["status"] == "ok"
        targets = envelope["data"]["targets"]
        assert isinstance(targets, list)
        assert len(targets) == 2

        # First entry is default
        assert targets[0]["name"] == "vultr-b200"
        assert targets[0]["default"] is True
        assert targets[0]["status"] == "reachable"
        assert targets[0]["ssh_target"] == "user@1.2.3.4:22"

        # Second entry is not default
        assert targets[1]["name"] == "modal-b200"
        assert targets[1]["default"] is False
        assert targets[1]["status"] == "serverless"
        assert "ssh_target" not in targets[1]  # no ssh_target when empty

    @patch("trio.run")
    @patch("wafer.targets.get_default_target")
    @patch("wafer.targets.list_targets")
    def test_targets_list_text_output_unchanged(
        self,
        mock_list: MagicMock,
        mock_default: MagicMock,
        mock_trio_run: MagicMock,
    ) -> None:
        """Without --json, should print human-readable table."""
        mock_list.return_value = ["vultr-b200"]
        mock_default.return_value = "vultr-b200"
        mock_trio_run.return_value = [
            ("vultr-b200", "reachable", "user@1.2.3.4:22"),
        ]

        result = runner.invoke(app, ["target", "config", "list"])
        assert result.exit_code == 0, f"Failed: {result.output}"
        assert "Configured targets:" in result.stdout
        assert "vultr-b200" in result.stdout
        assert "(default)" in result.stdout
