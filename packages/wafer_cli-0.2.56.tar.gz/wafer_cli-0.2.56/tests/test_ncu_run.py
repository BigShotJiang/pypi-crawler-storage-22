"""Unit tests for NCU remote profiling CLI module.

Tests directory packaging, .gitignore filtering, tar.gz creation,
and SSE stream processing — all locally, no B200 needed.
"""

import os
import subprocess
import tarfile
import tempfile
from pathlib import Path

import pytest


# --- Directory Packaging ---


class TestCollectFilesForUpload:
    """Tests for _collect_files_for_upload — the directory scanning logic."""

    def test_collects_all_files_in_flat_dir(self) -> None:
        """All files in a simple directory are collected."""
        from wafer.ncu_run import _collect_files_for_upload

        with tempfile.TemporaryDirectory() as tmpdir:
            d = Path(tmpdir)
            (d / "run.py").write_text("print('hello')")
            (d / "kernel.py").write_text("# kernel")
            (d / "data.txt").write_text("data")

            files = _collect_files_for_upload(d)

            names = {f.name for f in files}
            assert "run.py" in names
            assert "kernel.py" in names
            assert "data.txt" in names

    def test_collects_nested_files(self) -> None:
        """Files in subdirectories are collected."""
        from wafer.ncu_run import _collect_files_for_upload

        with tempfile.TemporaryDirectory() as tmpdir:
            d = Path(tmpdir)
            (d / "run.py").write_text("import utils")
            (d / "utils").mkdir()
            (d / "utils" / "helper.py").write_text("# helper")

            files = _collect_files_for_upload(d)
            rel_paths = {str(f.relative_to(d)) for f in files}

            assert "run.py" in rel_paths
            assert "utils/helper.py" in rel_paths

    def test_excludes_pycache(self) -> None:
        """__pycache__ directories are excluded."""
        from wafer.ncu_run import _collect_files_for_upload

        with tempfile.TemporaryDirectory() as tmpdir:
            d = Path(tmpdir)
            (d / "run.py").write_text("print('hello')")
            (d / "__pycache__").mkdir()
            (d / "__pycache__" / "run.cpython-312.pyc").write_bytes(b"\x00")

            files = _collect_files_for_upload(d)
            names = {f.name for f in files}

            assert "run.py" in names
            assert "run.cpython-312.pyc" not in names

    def test_excludes_git_dir(self) -> None:
        """.git directory is excluded."""
        from wafer.ncu_run import _collect_files_for_upload

        with tempfile.TemporaryDirectory() as tmpdir:
            d = Path(tmpdir)
            (d / "run.py").write_text("print('hello')")
            (d / ".git").mkdir()
            (d / ".git" / "HEAD").write_text("ref: refs/heads/main")

            files = _collect_files_for_upload(d)
            names = {f.name for f in files}

            assert "run.py" in names
            assert "HEAD" not in names

    def test_excludes_ncu_rep_files(self) -> None:
        """Existing .ncu-rep files are excluded from upload."""
        from wafer.ncu_run import _collect_files_for_upload

        with tempfile.TemporaryDirectory() as tmpdir:
            d = Path(tmpdir)
            (d / "run.py").write_text("print('hello')")
            (d / "old_profile.ncu-rep").write_bytes(b"\x00" * 100)

            files = _collect_files_for_upload(d)
            names = {f.name for f in files}

            assert "run.py" in names
            assert "old_profile.ncu-rep" not in names

    def test_excludes_venv(self) -> None:
        """Virtual environment directories are excluded."""
        from wafer.ncu_run import _collect_files_for_upload

        with tempfile.TemporaryDirectory() as tmpdir:
            d = Path(tmpdir)
            (d / "run.py").write_text("print('hello')")
            (d / ".venv").mkdir()
            (d / ".venv" / "bin").mkdir()
            (d / ".venv" / "bin" / "python").write_text("#!/usr/bin/env python")

            files = _collect_files_for_upload(d)
            names = {f.name for f in files}

            assert "run.py" in names
            assert "python" not in names

    def test_custom_excludes(self) -> None:
        """Extra exclude patterns are applied."""
        from wafer.ncu_run import _collect_files_for_upload

        with tempfile.TemporaryDirectory() as tmpdir:
            d = Path(tmpdir)
            (d / "run.py").write_text("print('hello')")
            (d / "big_data.bin").write_bytes(b"\x00" * 100)

            files = _collect_files_for_upload(d, extra_excludes={"*.bin"})
            names = {f.name for f in files}

            assert "run.py" in names
            assert "big_data.bin" not in names

    def test_git_ls_files_used_in_git_repo(self) -> None:
        """In a git repo, git ls-files is used (respects .gitignore)."""
        from wafer.ncu_run import _collect_files_for_upload

        with tempfile.TemporaryDirectory() as tmpdir:
            d = Path(tmpdir)
            # Initialize a git repo
            subprocess.run(["git", "init"], cwd=d, capture_output=True, check=True)
            subprocess.run(
                ["git", "config", "user.email", "test@test.com"],
                cwd=d, capture_output=True, check=True,
            )
            subprocess.run(
                ["git", "config", "user.name", "Test"],
                cwd=d, capture_output=True, check=True,
            )

            # Create files
            (d / "tracked.py").write_text("# tracked")
            (d / "ignored.log").write_text("logs")

            # Create .gitignore
            (d / ".gitignore").write_text("*.log\n")

            # Git add tracked file
            subprocess.run(["git", "add", "tracked.py", ".gitignore"], cwd=d, capture_output=True, check=True)

            files = _collect_files_for_upload(d)
            names = {f.name for f in files}

            assert "tracked.py" in names
            assert ".gitignore" in names
            assert "ignored.log" not in names


# --- Tar.gz Packaging ---


class TestPackageDirectory:
    """Tests for package_directory — creating uploadable tar.gz archives."""

    def test_creates_valid_tarball(self) -> None:
        """package_directory produces a valid tar.gz."""
        from wafer.ncu_run import package_directory

        with tempfile.TemporaryDirectory() as tmpdir:
            d = Path(tmpdir)
            (d / "run.py").write_text("print('hello')")
            (d / "kernel.py").write_text("# kernel code")

            tarball_bytes, count = package_directory(d)

            assert count == 2
            assert len(tarball_bytes) > 0

            # Verify it's valid tar.gz
            import io
            buf = io.BytesIO(tarball_bytes)
            with tarfile.open(fileobj=buf, mode="r:gz") as tar:
                names = tar.getnames()
                assert "run.py" in names
                assert "kernel.py" in names

    def test_preserves_relative_paths(self) -> None:
        """Tarball entries have paths relative to the directory root."""
        from wafer.ncu_run import package_directory

        with tempfile.TemporaryDirectory() as tmpdir:
            d = Path(tmpdir)
            (d / "src").mkdir()
            (d / "src" / "model.py").write_text("# model")
            (d / "run.py").write_text("from src.model import *")

            tarball_bytes, count = package_directory(d)

            import io
            buf = io.BytesIO(tarball_bytes)
            with tarfile.open(fileobj=buf, mode="r:gz") as tar:
                names = tar.getnames()
                # Paths should be relative, not absolute
                assert "run.py" in names
                assert "src/model.py" in names
                # No absolute paths
                for name in names:
                    assert not name.startswith("/")

    def test_empty_directory_raises(self) -> None:
        """Empty directory raises AssertionError."""
        from wafer.ncu_run import package_directory

        with tempfile.TemporaryDirectory() as tmpdir:
            d = Path(tmpdir)
            with pytest.raises(AssertionError, match="No files found"):
                package_directory(d)

    def test_realistic_gpu_mode_project(self) -> None:
        """Packages a realistic GPU Mode kernel project correctly.

        This mimics what a GPU Mode community member would have:
        - A Python entry script
        - A Triton kernel file
        - A utils module
        - Some files that should be excluded
        """
        from wafer.ncu_run import package_directory

        with tempfile.TemporaryDirectory() as tmpdir:
            d = Path(tmpdir)

            # Realistic GPU Mode project structure
            (d / "run.py").write_text(
                "import torch\n"
                "from kernel import my_kernel\n"
                "x = torch.randn(1024, device='cuda')\n"
                "my_kernel(x)\n"
            )
            (d / "kernel.py").write_text(
                "import triton\n"
                "import triton.language as tl\n"
                "@triton.jit\n"
                "def my_kernel(x_ptr, n: tl.constexpr):\n"
                "    pid = tl.program_id(0)\n"
                "    offsets = pid * 128 + tl.arange(0, 128)\n"
                "    x = tl.load(x_ptr + offsets)\n"
                "    tl.store(x_ptr + offsets, x * 2)\n"
            )
            (d / "utils.py").write_text("# utility functions\n")
            (d / "requirements.txt").write_text("torch>=2.0\ntriton>=2.1\n")

            # Files that SHOULD be excluded
            (d / "__pycache__").mkdir()
            (d / "__pycache__" / "kernel.cpython-312.pyc").write_bytes(b"\x00")
            (d / "old_profile.ncu-rep").write_bytes(b"\x00" * 50)

            tarball_bytes, count = package_directory(d)

            # Should include the 4 real files (run.py, kernel.py, utils.py, requirements.txt)
            # Should NOT include __pycache__ or .ncu-rep
            import io
            buf = io.BytesIO(tarball_bytes)
            with tarfile.open(fileobj=buf, mode="r:gz") as tar:
                names = set(tar.getnames())
                assert "run.py" in names
                assert "kernel.py" in names
                assert "utils.py" in names
                assert "requirements.txt" in names
                # Excluded files
                assert not any("__pycache__" in n for n in names)
                assert not any(".ncu-rep" in n for n in names)


# --- SSE Stream Processing ---


class TestHandleSseLine:
    """Tests for _handle_sse_line — CLI-side SSE event processing."""

    def test_done_sets_done_flag(self) -> None:
        """[DONE] event sets the done flag."""
        from wafer.ncu_run import _handle_sse_line

        state: dict = {"exit_code": 0, "job_id": None, "done": False}
        _handle_sse_line("[DONE]", state)

        assert state["done"] is True

    def test_error_sets_exit_code(self) -> None:
        """[ERROR] event sets exit_code to 1."""
        from wafer.ncu_run import _handle_sse_line

        state: dict = {"exit_code": 0, "job_id": None, "done": False}
        _handle_sse_line("[ERROR] something broke", state)

        assert state["exit_code"] == 1
        assert state["done"] is True

    def test_exit_code_parsed(self) -> None:
        """[EXIT:N] event parses the exit code."""
        from wafer.ncu_run import _handle_sse_line

        state: dict = {"exit_code": 0, "job_id": None, "done": False}
        _handle_sse_line("[EXIT:42]", state)

        assert state["exit_code"] == 42

    def test_report_ready_captures_job_id(self) -> None:
        """[REPORT_READY:id] event captures the job ID."""
        from wafer.ncu_run import _handle_sse_line

        state: dict = {"exit_code": 0, "job_id": None, "done": False}
        _handle_sse_line("[REPORT_READY:abc123def]", state)

        assert state["job_id"] == "abc123def"

    def test_status_events_dont_affect_state(self) -> None:
        """[STATUS:...] events are informational only."""
        from wafer.ncu_run import _handle_sse_line

        state: dict = {"exit_code": 0, "job_id": None, "done": False}
        _handle_sse_line("[STATUS:UPLOADING]", state)

        assert state["exit_code"] == 0
        assert state["job_id"] is None
        assert state["done"] is False
