"""End-to-end tests for NCU remote profiling.

These tests require:
1. Authentication: `wafer settings login` (or WAFER_API_URL pointed at staging)
2. B200 GPU access: A running B200 target in the pool
3. Credits: Sufficient credits for a short NCU run

Run manually:
    cd apps/wafer-cli
    uv run pytest tests/test_ncu_run_e2e.py -v -s

Or with staging:
    WAFER_API_URL=https://wafer-api-staging.onrender.com uv run pytest tests/test_ncu_run_e2e.py -v -s
"""

import os
import subprocess
import tempfile
from pathlib import Path

import pytest

# Mark all tests in this file as E2E (skip in CI by default)
pytestmark = [
    pytest.mark.skipif(
        os.environ.get("RUN_E2E_TESTS") != "1",
        reason="Set RUN_E2E_TESTS=1 to run E2E tests (requires B200 + auth)",
    ),
]

# Path to the realistic GPU Mode test fixture
FIXTURE_DIR = Path(__file__).parent / "fixtures" / "gpu_mode_kernel"


class TestNcuRunE2E:
    """End-to-end tests for the full `wafer tool ncu run` flow."""

    def _run_wafer(self, *args: str, cwd: str | None = None) -> subprocess.CompletedProcess:
        """Run a wafer CLI command and return the result."""
        cmd = ["uv", "run", "wafer", *args]
        env = {**os.environ}
        if "WAFER_API_URL" not in env:
            # Default to staging for E2E tests
            env["WAFER_API_URL"] = "https://wafer-api-staging.onrender.com"

        return subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            cwd=cwd or str(Path(__file__).parent.parent),
            env=env,
            timeout=300,  # 5 min timeout for NCU runs
        )

    def test_ncu_run_help(self) -> None:
        """wafer tool ncu run --help shows usage."""
        result = self._run_wafer("tool", "ncu", "run", "--help")

        assert result.returncode == 0
        assert "Run NCU profiling remotely" in result.stdout
        assert "--dir" in result.stdout
        assert "--ncu-args" in result.stdout

    def test_ncu_run_no_command_fails(self) -> None:
        """wafer tool ncu run (no command) fails with error."""
        result = self._run_wafer("tool", "ncu", "run")

        # Should fail because no command provided
        assert result.returncode != 0

    def test_ncu_run_simple_python(self) -> None:
        """Full E2E: profile a simple Python script on B200.

        This is THE critical test — it validates the entire flow:
        1. Directory packaging (tar.gz)
        2. Upload to API
        3. SFTP to B200
        4. Docker execution with NCU
        5. SSE streaming
        6. Report download
        """
        with tempfile.TemporaryDirectory() as tmpdir:
            d = Path(tmpdir)
            # Minimal script that NCU can profile
            (d / "run.py").write_text(
                "import torch\n"
                "x = torch.randn(1024, device='cuda')\n"
                "y = x * 2  # Simple operation for NCU to profile\n"
                "print(f'Result shape: {y.shape}')\n"
            )

            result = self._run_wafer(
                "tool", "ncu", "run",
                "--dir", str(d),
                "--timeout", "120",
                "python", "run.py",
            )

            print("STDOUT:", result.stdout)
            print("STDERR:", result.stderr)

            # Should upload and start running
            assert "Packaging" in result.stdout
            assert "Uploading" in result.stdout

            # Should get NCU output (==PROF== lines)
            assert "==PROF==" in result.stdout or "RUNNING" in result.stdout

    def test_ncu_run_gpu_mode_fixture(self) -> None:
        """Full E2E: profile the GPU Mode test fixture (Triton kernel).

        This tests the realistic GPU Mode use case:
        - Multi-file project (run.py + requirements.txt)
        - Triton kernel that needs profiling
        - Requirements installation
        """
        if not FIXTURE_DIR.exists():
            pytest.skip(f"Fixture not found: {FIXTURE_DIR}")

        with tempfile.TemporaryDirectory() as output_dir:
            output_file = Path(output_dir) / "profile.ncu-rep"

            result = self._run_wafer(
                "tool", "ncu", "run",
                "--dir", str(FIXTURE_DIR),
                "--output", str(output_file),
                "--timeout", "180",
                "python", "run.py",
            )

            print("STDOUT:", result.stdout)
            print("STDERR:", result.stderr)

            # Should complete successfully
            assert "Packaging" in result.stdout
            assert "Uploading" in result.stdout

            # If NCU ran successfully, report should be downloaded
            if result.returncode == 0 and output_file.exists():
                # Report should be a valid NCU report (starts with NVR magic)
                header = output_file.read_bytes()[:3]
                assert header == b"NVR", f"Invalid report header: {header}"
                print(f"Report downloaded: {output_file.stat().st_size / 1024:.1f} KB")

    def test_ncu_run_with_ncu_args(self) -> None:
        """E2E: custom NCU flags are passed through."""
        with tempfile.TemporaryDirectory() as tmpdir:
            d = Path(tmpdir)
            (d / "run.py").write_text(
                "import torch\n"
                "x = torch.randn(1024, device='cuda')\n"
                "y = x * 2\n"
            )

            result = self._run_wafer(
                "tool", "ncu", "run",
                "--dir", str(d),
                "--ncu-args", "--set full",
                "--no-download",
                "--timeout", "120",
                "python", "run.py",
            )

            print("STDOUT:", result.stdout)
            print("STDERR:", result.stderr)

            # Should show the ncu args in the command
            assert "--set full" in result.stdout

    def test_ncu_run_no_download(self) -> None:
        """E2E: --no-download skips report download."""
        with tempfile.TemporaryDirectory() as tmpdir:
            d = Path(tmpdir)
            (d / "run.py").write_text(
                "import torch\n"
                "x = torch.randn(1024, device='cuda')\n"
                "y = x * 2\n"
            )

            result = self._run_wafer(
                "tool", "ncu", "run",
                "--dir", str(d),
                "--no-download",
                "--timeout", "120",
                "python", "run.py",
            )

            print("STDOUT:", result.stdout)

            # Should NOT contain download messages
            assert "Downloading report" not in result.stdout


class TestNcuRunDirPackaging:
    """E2E tests focused on directory packaging behavior."""

    def test_large_directory_with_exclusions(self) -> None:
        """Directories with lots of excludable content are packaged efficiently."""
        from wafer.ncu_run import package_directory

        with tempfile.TemporaryDirectory() as tmpdir:
            d = Path(tmpdir)

            # Create a realistic project with lots of junk
            (d / "run.py").write_text("print('hello')")
            (d / "kernel.cu").write_text("__global__ void k() {}")

            # Lots of excludable stuff
            (d / "__pycache__").mkdir()
            for i in range(50):
                (d / "__pycache__" / f"module_{i}.cpython-312.pyc").write_bytes(b"\x00" * 1000)

            (d / "node_modules").mkdir()
            (d / "node_modules" / "big_dep").mkdir()
            (d / "node_modules" / "big_dep" / "index.js").write_text("// big")

            (d / ".git").mkdir()
            (d / ".git" / "objects").mkdir()

            tarball, count = package_directory(d)

            # Should only include the 2 real files
            assert count == 2
            # Tarball should be tiny (just run.py + kernel.cu)
            assert len(tarball) < 1024  # < 1KB
