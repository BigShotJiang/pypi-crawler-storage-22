"""Local E2E integration test for NCU remote profiling.
Tests the FULL pipeline on this B200 machine:
1. Package a real directory → tar.gz (CLI code)
2. Extract tarball in a workspace (API code path)
3. Build the bare-metal NCU command (API code)
4. Execute NCU on a real GPU (actual profiling)
5. Verify .ncu-rep report generated with NVR magic bytes
Run directly:
    cd /home/dib/wafer/apps/wafer-cli
    python tests/test_ncu_run_local_e2e.py
NOTE: This test requires the wafer-api dependencies (fastapi, etc.)
and a real B200 GPU with NCU installed. It is skipped in standard
CI — it runs on the B200 machine directly.
"""
import os
import shutil
import subprocess
import tempfile
from pathlib import Path
import pytest
def _build_ncu_command_for_test(
    workspace_dir: str,
    user_command: list[str],
    ncu_args: str,
    requirements: str | None,
    gpu_id: int = 0,
) -> str:
    """Build NCU command for bare-metal execution — test-local copy.
    Mirrors the API's _build_ncu_command() so this test can run without
    importing the wafer-api package (which pulls in fastapi, etc.).
    If the two diverge, the real E2E run against the API will catch it.
    """
    import shlex
    workspace_path = f"{workspace_dir}/workspace"
    report_path = f"{workspace_path}/report.ncu-rep"
    parts = []
    parts.append(f"cd {shlex.quote(workspace_path)}")
    if requirements:
        parts.append("pip install -q -r requirements.txt 2>&1")
    ncu_parts = [f"CUDA_VISIBLE_DEVICES={gpu_id}", "ncu"]
    if ncu_args:
        ncu_parts.append(ncu_args)
    ncu_parts.append(f"--export {shlex.quote(report_path)}")
    # Quote each token individually to preserve arguments with spaces
    ncu_parts.extend(shlex.quote(tok) for tok in user_command)
    parts.append(" ".join(ncu_parts))
    return " && ".join(parts)

_has_ncu = shutil.which("ncu") is not None
_skip_reason = "NCU binary not found — test requires a B200 machine with NCU installed"
@pytest.mark.skipif(not _has_ncu, reason=_skip_reason)
def test_full_pipeline() -> None:
    """Test the complete NCU run pipeline on this B200."""
    print("\n" + "=" * 70)
    print("NCU RUN — FULL LOCAL E2E TEST")
    print("=" * 70)
    # --- Step 1: Create a realistic GPU Mode project ---
    print("\n[1/6] Creating test project...")
    with tempfile.TemporaryDirectory() as project_dir:
        d = Path(project_dir)
        (d / "run.py").write_text(
            "import torch\n"
            "x = torch.randn(1024, device='cuda')\n"
            "y = x * 2\n"
            "print(f'SUCCESS: Result shape={y.shape}, sum={y.sum().item():.2f}')\n"
        )
        (d / "helper.py").write_text("# Helper module\nVERSION = '1.0'\n")
        # Add some junk that should be excluded
        (d / "__pycache__").mkdir()
        (d / "__pycache__" / "run.cpython-312.pyc").write_bytes(b"\x00" * 100)
        print(f"  Project dir: {d}")
        print(f"  Files: {[f.name for f in d.rglob('*') if f.is_file()]}")
        # --- Step 2: Package directory (CLI code) ---
        print("\n[2/6] Packaging directory with CLI code...")
        from wafer.ncu_run import package_directory
        tarball_bytes, file_count = package_directory(d)
        size_kb = len(tarball_bytes) / 1024
        print(f"  Packaged {file_count} files ({size_kb:.1f} KB)")
        assert file_count == 2, f"Expected 2 files (run.py, helper.py), got {file_count}"
        assert size_kb < 10, f"Tarball too large: {size_kb:.1f} KB"
        # --- Step 3: Extract tarball in workspace (simulates API SFTP + extract) ---
        print("\n[3/6] Extracting tarball in workspace (simulates B200 SFTP)...")
        workspace_dir = tempfile.mkdtemp(prefix="wafer-ncu-run-test-")
        workspace_path = os.path.join(workspace_dir, "workspace")
        os.makedirs(workspace_path)
        # Write tarball (simulates SFTP upload)
        tarball_path = os.path.join(workspace_dir, "workspace.tar.gz")
        with open(tarball_path, "wb") as f:
            f.write(tarball_bytes)
        # Extract (simulates API extracting on B200)
        subprocess.run(
            ["tar", "xzf", tarball_path, "-C", workspace_path],
            capture_output=True,
            text=True,
            check=True,
        )
        os.remove(tarball_path)
        extracted_files = list(Path(workspace_path).rglob("*"))
        print(f"  Workspace: {workspace_path}")
        print(
            f"  Extracted: {[str(f.relative_to(workspace_path)) for f in extracted_files if f.is_file()]}"
        )
        assert (Path(workspace_path) / "run.py").exists(), "run.py not extracted!"
        assert (Path(workspace_path) / "helper.py").exists(), "helper.py not extracted!"
        # __pycache__ should NOT be here
        assert not (Path(workspace_path) / "__pycache__").exists(), (
            "__pycache__ should have been excluded!"
        )
        # --- Step 4: Build NCU command (test-local helper) ---
        print("\n[4/6] Building NCU command (API code)...")
        ncu_cmd = _build_ncu_command_for_test(
            workspace_dir=workspace_dir,
            user_command=["python", "run.py"],
            ncu_args="--set none",  # --set none because perf_event_paranoid=4
            requirements=None,
            gpu_id=0,
        )
        print(f"  Command: {ncu_cmd}")
        assert "docker" not in ncu_cmd, "Command should NOT use Docker!"
        assert "ncu" in ncu_cmd
        assert "python" in ncu_cmd
        assert "run.py" in ncu_cmd
        # --- Step 5: Execute NCU (real GPU profiling!) ---
        print("\n[5/6] Executing NCU on B200 GPU...")
        result = subprocess.run(
            ["bash", "-c", ncu_cmd],
            capture_output=True,
            text=True,
            timeout=120,
        )
        print(f"  Exit code: {result.returncode}")
        print(f"  Stdout ({len(result.stdout)} bytes):")
        for line in result.stdout.strip().split("\n"):
            print(f"    {line}")
        if result.stderr:
            print(f"  Stderr: {result.stderr[:200]}")
        assert result.returncode == 0, (
            f"NCU failed with exit code {result.returncode}: {result.stderr}"
        )
        assert "SUCCESS:" in result.stdout, f"User program didn't run! stdout: {result.stdout}"
        assert "==PROF==" in result.stdout, f"NCU profiler didn't attach! stdout: {result.stdout}"
        # --- Step 6: Verify report ---
        print("\n[6/6] Verifying .ncu-rep report...")
        report_path = os.path.join(workspace_path, "report.ncu-rep")
        assert os.path.exists(report_path), f"Report not generated at {report_path}"
        report_size = os.path.getsize(report_path)
        print(f"  Report: {report_path}")
        print(f"  Size: {report_size / 1024 / 1024:.1f} MB")
        # Verify NVR magic bytes
        with open(report_path, "rb") as f:
            magic = f.read(3)
        assert magic == b"NVR", f"Invalid report magic: {magic!r} (expected NVR)"
        print("  Magic bytes: NVR")
        # Cleanup
        subprocess.run(["rm", "-rf", workspace_dir], check=False)
    print("\n" + "=" * 70)
    print("ALL CHECKS PASSED — FULL PIPELINE WORKS!")
    print("=" * 70)
    print()
    print("What was tested:")
    print("  - CLI packages directory as tar.gz (excludes __pycache__)")
    print("  - Tarball extracts correctly on B200 workspace")
    print("  - NCU command built correctly (bare metal, no Docker)")
    print("  - NCU executes on real B200 GPU and profiles kernels")
    print("  - User program runs and produces output")
    print("  - .ncu-rep report generated with valid NVR header")
    print()
    print("What this means for GPU Mode:")
    print("  A user running `wafer tool ncu run python run.py` will:")
    print("  1. Have their directory packaged and uploaded")
    print("  2. NCU runs on our B200 bare metal")
    print("  3. Get real-time profiling output streamed back")
    print("  4. Download the .ncu-rep report automatically")
    print()
if __name__ == "__main__":
    test_full_pipeline()
