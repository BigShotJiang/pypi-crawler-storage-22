"""Tests for the `wafer status` health check command.

Tests written first (TDD RED phase) before implementation.

Run with: PYTHONPATH=. uv run pytest tests/test_status.py -v
"""

import json
from pathlib import Path
from unittest.mock import MagicMock, patch

import httpx
import pytest
from typer.testing import CliRunner

from wafer.auth import Credentials
from wafer.cli import app

runner = CliRunner()


def _make_mock_creds(expired: bool = False) -> Credentials:
    """Create mock credentials for testing."""
    return Credentials(
        access_token="fake-access-token",
        refresh_token="fake-refresh-token",
        email="test@example.com",
    )


def _mock_httpx_client_ok(api_url: str = "https://api.wafer.run"):
    """Return a mock httpx.Client whose .get() returns 200."""
    mock_client = MagicMock()
    mock_response = MagicMock()
    mock_response.status_code = 200
    mock_client.__enter__ = MagicMock(return_value=mock_client)
    mock_client.__exit__ = MagicMock(return_value=False)
    mock_client.get.return_value = mock_response
    return mock_client


# All-pass patches for the happy path
_HAPPY_PATCHES = {
    "wafer.analytics._get_cli_version": "1.2.3",
    "wafer.auth.load_credentials": _make_mock_creds(),
    "wafer.auth._token_expired": False,
    "wafer.global_config.get_api_url": "https://api.wafer.run",
    # Explicit: status command runs the deps check only when platform.system() == "linux".
    # CI runs on Linux without ncu/nsys/rocprof installed. The deps check is non-blocking
    # (doesn't set all_ok=False), but we still patch to "Darwin" so the happy-path output
    # shows all checks as ok=True (no warning noise in assertions).
    "platform.system": "Darwin",
}


def _apply_happy_patches(monkeypatch, tmp_path):
    """Apply all happy-path patches and return a context for additional overrides."""
    patches = []
    for target, return_value in _HAPPY_PATCHES.items():
        p = patch(target, return_value=return_value)
        p.start()
        patches.append(p)

    # CONFIG_DIR exists
    config_dir = tmp_path / ".wafer"
    config_dir.mkdir()
    p = patch("wafer.global_config.CONFIG_DIR", config_dir)
    p.start()
    patches.append(p)

    # httpx.Client returns 200
    mock_client = _mock_httpx_client_ok()
    p = patch("httpx.Client", return_value=mock_client)
    p.start()
    patches.append(p)

    return patches


def _stop_patches(patches):
    for p in patches:
        p.stop()


# =============================================================================
# Happy Path
# =============================================================================


class TestStatusAllPass:
    """All checks pass -- exit 0, symbols in output."""

    def test_all_checks_pass_text(self, tmp_path):
        patches = _apply_happy_patches(None, tmp_path)
        try:
            result = runner.invoke(app, ["settings", "status"])
            assert result.exit_code == 0, result.output
            # Should contain check symbols or [OK]
            assert ("✓" in result.output or "[OK]" in result.output)
        finally:
            _stop_patches(patches)

    def test_all_checks_pass_json(self, tmp_path):
        patches = _apply_happy_patches(None, tmp_path)
        try:
            result = runner.invoke(app, ["settings", "status", "--json"])
            assert result.exit_code == 0, result.output
            envelope = json.loads(result.output)
            assert envelope["status"] == "ok"
            data = envelope["data"]
            assert data["all_ok"] is True
            assert isinstance(data["checks"], list)
            assert len(data["checks"]) >= 4
        finally:
            _stop_patches(patches)


# =============================================================================
# Auth Failures
# =============================================================================


class TestStatusAuthFailures:
    """Authentication check failures."""

    def test_not_logged_in(self, tmp_path):
        patches = _apply_happy_patches(None, tmp_path)
        # Override: no credentials
        p = patch("wafer.auth.load_credentials", return_value=None)
        p.start()
        patches.append(p)
        try:
            result = runner.invoke(app, ["settings", "status"])
            assert result.exit_code == 1, result.output
            assert "not logged in" in result.output.lower()
        finally:
            _stop_patches(patches)

    def test_not_logged_in_json(self, tmp_path):
        patches = _apply_happy_patches(None, tmp_path)
        p = patch("wafer.auth.load_credentials", return_value=None)
        p.start()
        patches.append(p)
        try:
            result = runner.invoke(app, ["settings", "status", "--json"])
            assert result.exit_code == 1, result.output
            envelope = json.loads(result.output)
            assert envelope["status"] == "error"
            data = envelope["data"]
            auth_check = next(c for c in data["checks"] if c["name"] == "authentication")
            assert auth_check["ok"] is False
        finally:
            _stop_patches(patches)

    def test_token_expired(self, tmp_path):
        patches = _apply_happy_patches(None, tmp_path)
        p = patch("wafer.auth._token_expired", return_value=True)
        p.start()
        patches.append(p)
        try:
            result = runner.invoke(app, ["settings", "status"])
            assert result.exit_code == 1, result.output
            assert "expired" in result.output.lower()
        finally:
            _stop_patches(patches)

    def test_token_expired_json(self, tmp_path):
        patches = _apply_happy_patches(None, tmp_path)
        p = patch("wafer.auth._token_expired", return_value=True)
        p.start()
        patches.append(p)
        try:
            result = runner.invoke(app, ["settings", "status", "--json"])
            assert result.exit_code == 1, result.output
            envelope = json.loads(result.output)
            assert envelope["status"] == "error"
            data = envelope["data"]
            auth_check = next(c for c in data["checks"] if c["name"] == "authentication")
            assert auth_check["ok"] is False
        finally:
            _stop_patches(patches)


# =============================================================================
# API Reachability Failures
# =============================================================================


class TestStatusApiUnreachable:
    """API connectivity check failures."""

    def test_api_connect_error(self, tmp_path):
        patches = _apply_happy_patches(None, tmp_path)
        # Override: httpx.Client raises ConnectError
        mock_client = MagicMock()
        mock_client.__enter__ = MagicMock(return_value=mock_client)
        mock_client.__exit__ = MagicMock(return_value=False)
        mock_client.get.side_effect = httpx.ConnectError("Connection refused")
        p = patch("httpx.Client", return_value=mock_client)
        p.start()
        patches.append(p)
        try:
            result = runner.invoke(app, ["settings", "status"])
            assert result.exit_code == 1, result.output
            assert "connection failed" in result.output.lower() or "unreachable" in result.output.lower()
        finally:
            _stop_patches(patches)

    def test_api_timeout(self, tmp_path):
        patches = _apply_happy_patches(None, tmp_path)
        mock_client = MagicMock()
        mock_client.__enter__ = MagicMock(return_value=mock_client)
        mock_client.__exit__ = MagicMock(return_value=False)
        mock_client.get.side_effect = httpx.TimeoutException("Timed out")
        p = patch("httpx.Client", return_value=mock_client)
        p.start()
        patches.append(p)
        try:
            result = runner.invoke(app, ["settings", "status"])
            assert result.exit_code == 1, result.output
            assert "timeout" in result.output.lower()
        finally:
            _stop_patches(patches)

    def test_api_non_200(self, tmp_path):
        patches = _apply_happy_patches(None, tmp_path)
        mock_client = MagicMock()
        mock_client.__enter__ = MagicMock(return_value=mock_client)
        mock_client.__exit__ = MagicMock(return_value=False)
        mock_response = MagicMock()
        mock_response.status_code = 500
        mock_client.get.return_value = mock_response
        p = patch("httpx.Client", return_value=mock_client)
        p.start()
        patches.append(p)
        try:
            result = runner.invoke(app, ["settings", "status"])
            assert result.exit_code == 1, result.output
        finally:
            _stop_patches(patches)


# =============================================================================
# Config Directory
# =============================================================================


class TestStatusConfigDir:
    """Config directory check failures."""

    def test_config_dir_missing(self, tmp_path):
        patches = _apply_happy_patches(None, tmp_path)
        # Override: CONFIG_DIR points to non-existent path
        missing_dir = tmp_path / "nonexistent"
        p = patch("wafer.global_config.CONFIG_DIR", missing_dir)
        p.start()
        patches.append(p)
        try:
            result = runner.invoke(app, ["settings", "status"])
            assert result.exit_code == 1, result.output
            assert "not found" in result.output.lower()
        finally:
            _stop_patches(patches)


# =============================================================================
# JSON Structure Validation
# =============================================================================


class TestStatusJsonStructure:
    """Validate the complete JSON output schema."""

    def test_json_valid_structure(self, tmp_path):
        patches = _apply_happy_patches(None, tmp_path)
        try:
            result = runner.invoke(app, ["settings", "status", "--json"])
            assert result.exit_code == 0, result.output
            envelope = json.loads(result.output)

            # Envelope structure
            assert envelope["status"] == "ok"
            assert "data" in envelope
            data = envelope["data"]

            # Data fields
            assert "cli_version" in data
            assert isinstance(data["cli_version"], str)
            assert "all_ok" in data
            assert isinstance(data["all_ok"], bool)
            assert "checks" in data
            assert isinstance(data["checks"], list)

            # Each check has name, ok, detail
            for check in data["checks"]:
                assert "name" in check
                assert "ok" in check
                assert "detail" in check
                assert isinstance(check["name"], str)
                assert isinstance(check["ok"], bool)
                assert isinstance(check["detail"], str)

            # Expected check names
            check_names = {c["name"] for c in data["checks"]}
            assert "cli_version" in check_names
            assert "config_directory" in check_names
            assert "authentication" in check_names
            assert "api_reachable" in check_names
            assert "deps" in check_names
        finally:
            _stop_patches(patches)


class TestStatusNextSteps:
    """Next steps shown when checks fail."""

    def test_next_steps_when_not_logged_in(self, tmp_path):
        """Next steps include login hint when auth fails."""
        patches = _apply_happy_patches(None, tmp_path)
        p = patch("wafer.auth.load_credentials", return_value=None)
        p.start()
        patches.append(p)
        try:
            result = runner.invoke(app, ["settings", "status"])
            assert result.exit_code == 1, result.output
            assert "Next steps:" in result.output
            assert "wafer settings login" in result.output
        finally:
            _stop_patches(patches)
