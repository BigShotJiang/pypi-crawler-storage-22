"""Tests for token waste reduction changes.

Validates:
- SKILL.md is concise (index-only, sub-guides exist)
- AITER_SYSTEM_PROMPT is compact (no Key Directories section)
- Bash allowlists are composed from shared bases (set equality)
- CLI instruction filtering works with system_prompt parameter
"""

from __future__ import annotations

from pathlib import Path


# ── Skill index tests ────────────────────────────────────────────────────────

SKILL_DIR = Path(__file__).resolve().parent.parent / "wafer" / "skills" / "wafer-guide"


class TestSkillIndex:
    """SKILL.md should be a concise index pointing to sub-guides."""

    def test_skill_index_md_concise(self) -> None:
        skill_md = SKILL_DIR / "SKILL.md"
        assert skill_md.exists(), f"SKILL.md not found at {skill_md}"
        line_count = len(skill_md.read_text().splitlines())
        assert line_count < 250, f"SKILL.md is {line_count} lines, expected < 250"

    def test_sub_guides_exist(self) -> None:
        expected = ["evaluate.md", "profiling.md", "workspaces.md", "pitfalls.md", "commands.md"]
        for name in expected:
            path = SKILL_DIR / name
            assert path.exists(), f"Sub-guide {name} not found at {path}"

    def test_commands_md_is_auto_generated(self) -> None:
        commands_md = SKILL_DIR / "commands.md"
        assert commands_md.exists(), f"commands.md not found at {commands_md}"
        content = commands_md.read_text()
        assert "AUTO-GENERATED" in content, "commands.md should contain AUTO-GENERATED marker"


# ── System prompt size tests ─────────────────────────────────────────────────


class TestSystemPromptSize:
    """AITER_SYSTEM_PROMPT should be compact."""

    def test_aiter_prompt_under_3000_chars(self) -> None:
        from wafer.agent_defaults import AITER_SYSTEM_PROMPT

        assert len(AITER_SYSTEM_PROMPT) < 3000, (
            f"AITER_SYSTEM_PROMPT is {len(AITER_SYSTEM_PROMPT)} chars, expected < 3000"
        )

    def test_aiter_prompt_no_key_directories_section(self) -> None:
        from wafer.agent_defaults import AITER_SYSTEM_PROMPT

        assert "## Key Directories" not in AITER_SYSTEM_PROMPT, (
            "AITER_SYSTEM_PROMPT should not contain '## Key Directories' — "
            "it duplicates '## Finding Source Files'"
        )


# ── Bash allowlist composition tests ─────────────────────────────────────────


class TestBashAllowlistComposition:
    """Each allowlist should have exactly the expected elements."""

    def test_kernelbench_allowlist_elements(self) -> None:
        from wafer.agent_defaults import KERNELBENCH_BASH_ALLOWLIST

        expected = {
            "wafer tool eval",
            "wafer tool rocprof-compute",
            "wafer tool rocprof-sdk",
            "wafer tool rocprof-systems",
            "wafer tool ncu",
            "wafer tool nsys",
            "wafer compiler-analyze",
            "python",
            "python3",
            "timeout",
            "ls",
            "cat",
            "head",
            "tail",
            "wc",
            "pwd",
            "which",
        }
        assert set(KERNELBENCH_BASH_ALLOWLIST) == expected

    def test_aiter_allowlist_elements(self) -> None:
        from wafer.agent_defaults import AITER_BASH_ALLOWLIST

        expected = {
            "ls", "cat", "head", "tail", "wc", "find", "grep", "rg",
            "pwd", "tree", "which", "diff", "sort",
            "mkdir", "cp", "mv",
            "git diff", "git status", "git log",
            "hipcc", "g++", "gcc", "clang",
            "python", "python3", "pip", "pytest",
            "./",
            "wafer tool eval aiter",
            "wafer tool rocprof-compute", "wafer tool rocprof-sdk",
            "wafer tool rocprof-systems", "wafer tool isa",
            "timeout",
        }
        assert set(AITER_BASH_ALLOWLIST) == expected

    def test_vllm_allowlist_elements(self) -> None:
        from wafer.agent_defaults import VLLM_BASH_ALLOWLIST

        expected = {
            "wafer tool eval vllm",
            "pytest",
            "wafer tool rocprof-compute", "wafer tool rocprof-sdk",
            "wafer tool rocprof-systems",
            "wafer tool ncu", "wafer tool nsys",
            "wafer compiler-analyze",
            "python", "python3", "pip",
            "timeout",
            "ls", "cat", "head", "tail", "wc", "pwd", "which",
            "cd", "git",
        }
        assert set(VLLM_BASH_ALLOWLIST) == expected

    def test_flashinfer_allowlist_elements(self) -> None:
        from wafer.agent_defaults import FLASHINFER_BASH_ALLOWLIST

        expected = {
            "ls", "cat", "head", "tail", "wc", "find", "grep", "rg",
            "pwd", "tree", "which", "diff", "sort",
            "mkdir", "cp", "mv",
            "git diff", "git status", "git log", "git checkout",
            "nvcc", "g++", "gcc", "clang", "ninja", "cmake", "make",
            "python", "python3", "pip", "pytest",
            "./",
            "wafer tool ncu", "wafer tool nsys",
            "wafer compiler-analyze",
            "wafer tool eval flashinfer-bench",
            "timeout",
        }
        assert set(FLASHINFER_BASH_ALLOWLIST) == expected

    def test_hipblaslt_allowlist_elements(self) -> None:
        from wafer.agent_defaults import HIPBLASLT_BASH_ALLOWLIST

        expected = {
            "ls", "cat", "head", "tail", "wc", "find", "grep", "rg",
            "pwd", "tree", "which", "diff", "sort",
            "mkdir", "cp", "mv",
            "git diff", "git status", "git log", "git show", "git checkout",
            "hipcc", "cmake", "make", "ninja",
            "g++", "gcc", "clang",
            "python", "python3", "pip", "pytest",
            "./",
            "wafer tool eval hipblaslt",
            "wafer tool rocprof-compute", "wafer tool rocprof-sdk",
            "wafer tool rocprof-systems", "wafer tool isa",
            "timeout",
        }
        assert set(HIPBLASLT_BASH_ALLOWLIST) == expected

    def test_audit_allowlist_elements(self) -> None:
        from wafer.agent_defaults import AUDIT_BASH_ALLOWLIST

        expected = {
            "ls", "cat", "head", "tail", "wc", "find", "grep", "rg",
            "pwd", "tree", "which", "diff", "sort",
            "mkdir",
            "make", "cmake", "nvcc", "hipcc",
            "g++", "gcc", "clang",
            "python", "python3",
            "./",
            "wafer tool eval",
            "wafer tool ncu", "wafer tool nsys",
            "wafer tool rocprof-compute", "wafer tool rocprof-sdk",
            "wafer tool rocprof-systems", "wafer tool isa",
            "wafer compiler-analyze",
            "wafer tool exec",
            "timeout",
        }
        assert set(AUDIT_BASH_ALLOWLIST) == expected


# ── CLI instructions filtering tests ─────────────────────────────────────────


class TestCliInstructionsFiltering:
    """build_cli_instructions should support filtering by system_prompt."""

    def test_build_cli_instructions_without_system_prompt_unchanged(self) -> None:
        """Default behavior (no system_prompt) should document all wafer commands."""
        from wafer.agent_defaults import KERNELBENCH_BASH_ALLOWLIST
        from wafer.cli_instructions import build_cli_instructions

        result = build_cli_instructions(KERNELBENCH_BASH_ALLOWLIST)
        assert len(result) > 0, "Should produce non-empty instructions"
        assert "wafer tool eval" in result

    def test_build_cli_instructions_with_system_prompt_filters(self) -> None:
        """When system_prompt is provided, only matching commands are documented."""
        from wafer.agent_defaults import KERNELBENCH_BASH_ALLOWLIST
        from wafer.cli_instructions import build_cli_instructions

        # Prompt with no matching command (filter checks cmd.split()[1] in prompt)
        empty_filtered = build_cli_instructions(
            KERNELBENCH_BASH_ALLOWLIST, system_prompt="Use xyznonexistent to test."
        )
        assert empty_filtered == "", "Non-matching prompt should produce empty instructions"

        # Prompt that matches "tool" (all wafer tool eval/ncu/nsys/rocprof-* match)
        prompt = "You are an expert. Use wafer tool eval to test kernels."
        filtered = build_cli_instructions(KERNELBENCH_BASH_ALLOWLIST, system_prompt=prompt)
        assert "wafer tool eval" in filtered
