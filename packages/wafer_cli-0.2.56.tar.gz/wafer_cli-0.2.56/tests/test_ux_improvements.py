"""Tests for CLI UX improvements.

Tests error messages, billing output, skill status, evaluate validation,
agent template errors, help text trimming, workspace alias, emoji consistency,
legacy removal, panel cleanup, version subcommand, guide rendering,
--no-color, and fuzzy matching.

Run with: PYTHONPATH=. uv run pytest tests/test_ux_improvements.py -v
"""

from pathlib import Path
from unittest.mock import patch

from typer.testing import CliRunner

from wafer.cli import app

runner = CliRunner()


# =============================================================================
# 1. Docker config parse error
# =============================================================================


class TestDockerConfigError:
    """Docker config parse error should show actionable message."""

    def test_config_show_docker_not_configured(self) -> None:
        """When docker.ini has no [default] section, show helpful message."""
        result = runner.invoke(app, ["settings", "config", "show"])

        # Should not show parenthetical error format
        assert "(Docker config parse error" not in result.output
        # Should show the actionable message (if docker config exists but is broken)
        # or the "no Docker config" message (if it doesn't exist)
        assert result.exit_code == 0


# =============================================================================
# 2. Evaluate multi-file validation
# =============================================================================


class TestEvaluateMultiFileValidation:
    """Evaluate should report ALL missing files at once."""

    def test_all_missing_files_reported(self, tmp_path: Path) -> None:
        """When all 3 files are missing, error should list all of them."""
        from wafer.evaluate import EvaluateArgs, _validate_files

        args = EvaluateArgs(
            implementation=tmp_path / "nonexistent_impl.py",
            reference=tmp_path / "nonexistent_ref.py",
            test_cases=tmp_path / "nonexistent_tests.json",
            target_name="fake-target",
        )
        error = _validate_files(args)

        assert error is not None
        assert "nonexistent_impl.py" in error
        assert "nonexistent_ref.py" in error
        assert "nonexistent_tests.json" in error
        assert "make-template" in error

    def test_two_missing_files_reported(self, tmp_path: Path) -> None:
        """When 2 of 3 files are missing, both should be listed."""
        from wafer.evaluate import EvaluateArgs, _validate_files

        # Create only the implementation file
        impl = tmp_path / "kernel.py"
        impl.write_text("def custom_kernel(inputs): pass")

        args = EvaluateArgs(
            implementation=impl,
            reference=tmp_path / "nonexistent_ref.py",
            test_cases=tmp_path / "nonexistent_tests.json",
            target_name="fake-target",
        )
        error = _validate_files(args)

        assert error is not None
        assert "kernel.py" not in error  # impl exists, should NOT be listed
        assert "nonexistent_ref.py" in error
        assert "nonexistent_tests.json" in error

    def test_single_missing_file_with_suggestion(self, tmp_path: Path) -> None:
        """Even a single missing file should suggest make-template."""
        from wafer.evaluate import EvaluateArgs, _validate_files

        impl = tmp_path / "kernel.py"
        ref = tmp_path / "ref.py"
        impl.write_text("def custom_kernel(inputs): pass")
        ref.write_text("def ref_kernel(inputs): pass")

        args = EvaluateArgs(
            implementation=impl,
            reference=ref,
            test_cases=tmp_path / "nonexistent_tests.json",
            target_name="fake-target",
        )
        error = _validate_files(args)

        assert error is not None
        assert "nonexistent_tests.json" in error
        assert "make-template" in error

    def test_all_files_exist_no_error(self, tmp_path: Path) -> None:
        """When all files exist, validation passes (returns None)."""
        from wafer.evaluate import EvaluateArgs, _validate_files

        impl = tmp_path / "kernel.py"
        ref = tmp_path / "ref.py"
        tests = tmp_path / "tests.json"
        impl.write_text("def custom_kernel(inputs): pass")
        ref.write_text("def ref_kernel(inputs): pass\ndef generate_input(**kwargs): pass")
        tests.write_text('[{"M": 1024}]')

        args = EvaluateArgs(
            implementation=impl,
            reference=ref,
            test_cases=tests,
            target_name="fake-target",
        )
        error = _validate_files(args)

        assert error is None


# =============================================================================
# 3. Billing output overhaul
# =============================================================================


class TestBillingOutputOverhaul:
    """Billing output should be clear and non-confusing."""

    def test_balance_is_primary_number(self) -> None:
        """Balance (remaining + topup) should be the primary displayed number."""
        from wafer.billing import format_usage_text

        usage = {
            "tier": "pro",
            "status": "active",
            "credits_used_cents": 500,
            "credits_limit_cents": 1000,
            "credits_remaining_cents": 500,
            "topup_balance_cents": 1991459,
            "has_hardware_counters": True,
            "has_slack_access": False,
        }
        text = format_usage_text(usage)

        # Balance = remaining + topup = $5.00 + $19,914.59 = $19,919.59
        assert "Balance: $19919.59" in text

    def test_plan_allowance_shows_used_of_limit(self) -> None:
        """Plan allowance should show 'X used of Y/month' format."""
        from wafer.billing import format_usage_text

        usage = {
            "tier": "pro",
            "status": "active",
            "credits_used_cents": 500,
            "credits_limit_cents": 1000,
            "credits_remaining_cents": 500,
            "topup_balance_cents": 0,
            "has_hardware_counters": True,
            "has_slack_access": True,
        }
        text = format_usage_text(usage)

        assert "Plan allowance:" in text
        assert "$5.00 used of $10.00/month" in text

    def test_no_topup_line_when_zero(self) -> None:
        """Topup credits line should not appear when topup is 0."""
        from wafer.billing import format_usage_text

        usage = {
            "tier": "pro",
            "status": "active",
            "credits_used_cents": 500,
            "credits_limit_cents": 1000,
            "credits_remaining_cents": 500,
            "topup_balance_cents": 0,
            "has_hardware_counters": True,
            "has_slack_access": True,
        }
        text = format_usage_text(usage)

        assert "Topup" not in text

    def test_features_labeled_clearly(self) -> None:
        """Features should use descriptive names, not jargon."""
        from wafer.billing import format_usage_text

        usage = {
            "tier": "pro",
            "status": "active",
            "credits_used_cents": 0,
            "credits_limit_cents": 1000,
            "credits_remaining_cents": 1000,
            "topup_balance_cents": 0,
            "has_hardware_counters": True,
            "has_slack_access": True,
        }
        text = format_usage_text(usage)

        # Should NOT use old jargon
        assert "Hardware counters:" not in text
        assert "Slack support:" not in text
        # Should use descriptive names
        assert "Hardware performance counters (NCU/NSYS)" in text
        assert "Priority Slack support" in text

    def test_not_included_features_show_upgrade_path(self) -> None:
        """Features not included should point to billing portal."""
        from wafer.billing import format_usage_text

        usage = {
            "tier": "start",
            "status": "active",
            "credits_used_cents": 0,
            "credits_limit_cents": 0,
            "credits_remaining_cents": 0,
            "topup_balance_cents": 0,
            "has_hardware_counters": False,
            "has_slack_access": False,
        }
        text = format_usage_text(usage)

        assert "Not included" in text
        assert "wafer billing portal" in text

    def test_no_billing_summary_header(self) -> None:
        """Output should use 'Plan: X (status)' format, not 'Billing Summary'."""
        from wafer.billing import format_usage_text

        usage = {
            "tier": "pro",
            "status": "active",
            "credits_used_cents": 0,
            "credits_limit_cents": 1000,
            "credits_remaining_cents": 1000,
            "topup_balance_cents": 0,
            "has_hardware_counters": True,
            "has_slack_access": True,
        }
        text = format_usage_text(usage)

        assert "Billing Summary" not in text
        assert text.startswith("Plan: Pro (active)")


# =============================================================================
# 4. Skill status revamp
# =============================================================================


class TestSkillStatusRevamp:
    """Skill status should be user-friendly, not developer-facing."""

    def test_no_raw_path(self, tmp_path: Path) -> None:
        """Should NOT show raw filesystem paths."""
        fake_cli_dir = tmp_path / "fake_wafer"
        fake_cli_dir.mkdir()
        (fake_cli_dir / "skills" / "wafer-guide").mkdir(parents=True)
        (fake_cli_dir / "skills" / "wafer-guide" / "SKILL.md").write_text("# Test")
        fake_cli_file = fake_cli_dir / "cli.py"

        with patch("wafer.cli.__file__", str(fake_cli_file)):
            result = runner.invoke(app, ["settings", "skill", "status"])

        assert result.exit_code == 0
        # Should NOT contain raw path
        assert str(tmp_path) not in result.output
        assert "Exists: True" not in result.output

    def test_shows_description(self, tmp_path: Path) -> None:
        """Should show a human-readable description."""
        fake_cli_dir = tmp_path / "fake_wafer"
        fake_cli_dir.mkdir()
        (fake_cli_dir / "skills" / "wafer-guide").mkdir(parents=True)
        (fake_cli_dir / "skills" / "wafer-guide" / "SKILL.md").write_text("# Test")
        fake_cli_file = fake_cli_dir / "cli.py"

        with patch("wafer.cli.__file__", str(fake_cli_file)):
            result = runner.invoke(app, ["settings", "skill", "status"])

        assert result.exit_code == 0
        assert "wafer-guide (bundled)" in result.output
        assert "GPU kernel development" in result.output

    def test_shows_install_commands_for_missing(self, tmp_path: Path) -> None:
        """Uninstalled targets should show the install command."""
        fake_cli_dir = tmp_path / "fake_wafer"
        fake_cli_dir.mkdir()
        (fake_cli_dir / "skills" / "wafer-guide").mkdir(parents=True)
        (fake_cli_dir / "skills" / "wafer-guide" / "SKILL.md").write_text("# Test")
        fake_cli_file = fake_cli_dir / "cli.py"

        # Use a fake home dir so no real installations are detected
        fake_home = tmp_path / "fakehome"
        fake_home.mkdir()

        with (
            patch("wafer.cli.__file__", str(fake_cli_file)),
            patch("wafer.cli.Path.home", return_value=fake_home),
        ):
            result = runner.invoke(app, ["settings", "skill", "status"])

        assert result.exit_code == 0
        # Should suggest install commands for uninstalled targets
        assert "wafer settings skill install -t cursor" in result.output
        assert "wafer settings skill install -t claude" in result.output
        assert "wafer settings skill install -t codex" in result.output


# =============================================================================
# 5. Agent template error
# =============================================================================


class TestAgentTemplateError:
    """Agent template errors should list available templates."""

    def test_load_template_error_lists_available(self) -> None:
        """When template not found, should list available templates."""
        from wafer.wevin_cli import _load_template

        _, err = _load_template("nonexistent_template_xyz")

        assert err is not None
        # The error message itself comes from the loader,
        # but the CLI handler now prints available templates


# =============================================================================
# 6. Help text trimming
# =============================================================================


class TestHelpTextTrimming:
    """Help text should be concise."""

    def test_login_help_under_15_lines(self) -> None:
        """Login help text should be trimmed."""
        result = runner.invoke(app, ["settings", "login", "--help"])

        assert result.exit_code == 0
        # Should not contain the verbose SSH instructions
        assert "SSH Users (Easiest)" not in result.output
        assert "SSH with browser (Advanced)" not in result.output
        assert "Manual token option" not in result.output

    def test_capture_help_under_15_lines(self) -> None:
        """Capture help text should be trimmed."""
        result = runner.invoke(app, ["tool", "capture", "--help"])

        assert result.exit_code == 0
        # Should not contain the verbose denylist docs
        assert "Denylist Configuration" not in result.output
        assert "precedence: CLI > Project > Global" not in result.output

    def test_agent_help_under_15_lines(self) -> None:
        """Agent help text should be trimmed."""
        result = runner.invoke(app, ["agent", "--help"])

        assert result.exit_code == 0
        # Should not contain the verbose mode explanations
        assert "Simple mode for scripts/pipes" not in result.output
        assert "Run on a workspace" not in result.output

    def test_evaluate_help_concise(self) -> None:
        """Evaluate help text should be concise."""
        result = runner.invoke(app, ["tool", "eval", "--help"])

        assert result.exit_code == 0
        # Should not have the verbose checks explanation
        assert "Correctness: Does the kernel" not in result.output
        assert "Defense (--defensive): Detects" not in result.output


# =============================================================================
# 7. Workspace singular alias
# =============================================================================


class TestWorkspaceAlias:
    """'workspace' (singular) should work as alias for 'workspaces'."""

    def test_workspace_singular_shows_help(self) -> None:
        """wafer target workspace --help should work."""
        result_plural = runner.invoke(app, ["target", "workspace", "--help"])
        result_singular = runner.invoke(app, ["target", "workspace", "--help"])

        assert result_plural.exit_code == 0
        assert result_singular.exit_code == 0
        # Both should show the same help content
        assert "Manage cloud GPU workspaces" in result_singular.output

    def test_workspace_singular_hidden_from_main_help(self) -> None:
        """workspace (singular) should NOT appear in main --help."""
        result = runner.invoke(app, ["--help"])

        assert result.exit_code == 0
        # Only workspaces (plural) should appear
        assert "target" in result.output
        # The singular alias should be hidden
        lines = result.output.split("\n")
        workspace_lines = [
            line for line in lines if line.strip().startswith("workspace ")
        ]
        assert len(workspace_lines) == 0, "singular 'workspace' should be hidden"


# =============================================================================
# 2. Emoji consistency
# =============================================================================


class TestEmojiConsistency:
    """Capture commands should not use full-color emoji."""

    def test_no_full_color_emoji_in_capture_help(self) -> None:
        """Capture output should use plain text / unicode not full-color emoji."""
        import inspect

        from wafer import cli as cli_module

        source = inspect.getsource(cli_module)
        # These full-color emoji should not appear in the capture flow
        assert "\U0001f52c" not in source, "🔬 should be removed from capture"
        assert "\u2705" not in source, "✅ should be removed from capture"
        assert "\u274c" not in source, "❌ should be removed from capture"


# =============================================================================
# 3. config-show legacy alias removed
# =============================================================================


class TestConfigShowLegacyRemoved:
    """config-show legacy alias should be deleted."""

    def test_config_show_command_not_found(self) -> None:
        """wafer config-show should not be a valid command."""
        result = runner.invoke(app, ["config-show"])

        # Should fail -- legacy alias is removed
        assert result.exit_code != 0


# =============================================================================
# 4. Baseline no longer in lonely panel
# =============================================================================


class TestBaselinePanel:
    """baseline should be under tool, not in a separate 'Kernel Development' panel."""

    def test_no_kernel_development_panel(self) -> None:
        """wafer --help should not have a 'Kernel Development' panel."""
        result = runner.invoke(app, ["--help"])

        assert result.exit_code == 0
        assert "Kernel Development" not in result.output
        # baseline is under tool; verify it appears in tool --help
        tool_result = runner.invoke(app, ["tool", "--help"])
        assert tool_result.exit_code == 0
        assert "baseline" in tool_result.output


# =============================================================================
# 5. wafer version subcommand
# =============================================================================


class TestVersionSubcommand:
    """wafer version should work as a command."""

    def test_version_command(self) -> None:
        """wafer version should print version and exit cleanly."""
        result = runner.invoke(app, ["version"])

        assert result.exit_code == 0
        assert "wafer-cli" in result.output

    def test_version_flag_still_works(self) -> None:
        """--version flag should still work."""
        result = runner.invoke(app, ["--version"])

        assert result.exit_code == 0
        assert "wafer-cli" in result.output


# =============================================================================
# 6. Guide rendering
# =============================================================================


class TestGuideRendering:
    """guide command should render properly."""

    def test_guide_shows_toc_by_default(self) -> None:
        """wafer settings guide should show table of contents by default."""
        result = runner.invoke(app, ["settings", "guide"])

        assert result.exit_code == 0
        # Default mode shows TOC with section names
        assert "wafer settings guide" in result.output

    def test_guide_full_no_raw_fences(self) -> None:
        """wafer settings guide --full should not print raw ```bash fences."""
        result = runner.invoke(app, ["settings", "guide", "--full"])

        assert result.exit_code == 0
        # Rich Markdown rendering should handle fences
        assert "```bash" not in result.output
        assert "wafer" in result.output


# =============================================================================
# 7. --no-color flag
# =============================================================================


class TestNoColorFlag:
    """--no-color should suppress colored output."""

    def test_no_color_flag_accepted(self) -> None:
        """--no-color should be a valid global flag."""
        result = runner.invoke(app, ["--no-color", "--help"])

        assert result.exit_code == 0

    def test_no_color_sets_env(self) -> None:
        """--no-color should set NO_COLOR env var."""
        # Run version with --no-color to exercise the callback
        result = runner.invoke(app, ["--no-color", "version"])

        assert result.exit_code == 0
        assert "wafer-cli" in result.output


# =============================================================================
# 8. Fuzzy matching / did-you-mean (Typer built-in)
# =============================================================================


class TestFuzzyMatching:
    """Typos should get 'did you mean' suggestions (Typer built-in)."""

    def test_typo_suggests_similar_command(self) -> None:
        """wafer evluate (typo) should suggest similar command."""
        result = runner.invoke(app, ["evluate"])

        assert result.exit_code != 0
        # In the new 4-group structure, top-level commands are: target, tool, settings, agent
        assert "Did you mean" in result.output or result.exit_code != 0

    def test_agen_suggests_agent(self) -> None:
        """wafer agen (typo) should suggest 'agent'."""
        result = runner.invoke(app, ["agen"])

        assert result.exit_code != 0
        assert "Did you mean" in result.output
        assert "agent" in result.output

    def test_complete_garbage_no_suggestion(self) -> None:
        """Completely unrelated input should not crash."""
        result = runner.invoke(app, ["xyzzyplugh"])

        assert result.exit_code != 0
