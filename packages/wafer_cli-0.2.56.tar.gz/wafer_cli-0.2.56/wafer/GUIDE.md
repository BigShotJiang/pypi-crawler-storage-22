# Wafer CLI Guide

GPU development primitives for LLM agents.

## Quick Start: Cloud GPU (No Setup)

Run code on cloud GPUs instantly with workspaces:

```bash
wafer settings login                              # One-time auth
wafer target workspace create dev --gpu B200   # Create workspace (NVIDIA B200)
wafer target workspace exec dev -- python -c "import torch; print(torch.cuda.get_device_name(0))"
wafer target workspace sync dev ./my-project   # Sync files
wafer target workspace exec dev -- python train.py
```

**Available GPUs:**

- `MI300X` - AMD Instinct MI300X (192GB HBM3, ROCm)
- `B200` - NVIDIA Blackwell B200 (180GB HBM3e, CUDA) - default

## Documentation Lookup

Answer GPU programming questions from wafer's documentation corpus.

```bash
# Query documentation (uses wafer API — no local download needed)
wafer agent -t ask-docs "What is warp divergence?"
wafer agent -t ask-docs "What is a TiledMma in CUTLASS?"
```

## Trace Analysis

Analyze performance traces from NCU, NSYS, or PyTorch profiler.

```bash
# AI-assisted analysis
wafer agent -t trace-analyze --args trace=./profile.ncu-rep "Why is this kernel slow?"
wafer agent -t trace-analyze --args trace=./trace.json "What's the bottleneck?"

# Direct trace queries (PyTorch/Perfetto JSON)
wafer tool perfetto tables trace.json
wafer tool perfetto query trace.json \
  "SELECT name, dur/1e6 as ms FROM slice WHERE cat='kernel' ORDER BY dur DESC LIMIT 10"

# NCU/NSYS analysis
wafer tool ncu analyze profile.ncu-rep
wafer tool nsys analyze profile.nsys-rep
```

## Kernel Evaluation

Test kernel correctness and measure speedup against a reference.

```bash
# Using workspaces (no target setup required):
wafer target workspace create dev --gpu B200
wafer target workspace exec --sync ./my-kernel dev -- python test_kernel.py

# Or using configured targets (for your own hardware):
wafer tool eval make-template ./my-kernel
wafer tool eval \
  --impl ./my-kernel/kernel.py \
  --reference ./my-kernel/reference.py \
  --test-cases ./my-kernel/test_cases.json \
  --target <target-name>
```

For target setup, see `wafer target config --help`.

## Kernel Optimization (AI-assisted)

Iteratively optimize a kernel with evaluation feedback.

```bash
wafer agent -t optimize-kernel \
  --args kernel=./my_kernel.cu \
  --args target=H100 \
  "Optimize this GEMM for memory bandwidth"
```

## Workspaces

Cloud GPU environments with no setup required.

**Available GPUs:**

- `MI300X` - AMD Instinct MI300X (192GB HBM3, ROCm)
- `B200` - NVIDIA Blackwell B200 (180GB HBM3e, CUDA) - default

```bash
wafer target workspace create dev --gpu B200 --wait     # NVIDIA B200
wafer target workspace create amd-dev --gpu MI300X      # AMD MI300X
wafer target workspace list                             # List all
wafer target workspace sync dev ./project               # Sync files
wafer target workspace exec dev -- ./run.sh             # Run commands
wafer target workspace ssh dev                          # Interactive SSH
wafer target workspace delete dev                       # Cleanup
```

See `wafer target workspace --help` for details.

## Command Reference

```bash
wafer target workspace                  # Cloud GPU environments (no setup)
wafer tool eval                    # Test kernel correctness/performance
wafer tool ncu|nsys|perfetto    # NVIDIA profiling tools
wafer tool isa|rocprof-compute     # AMD profiling tools
wafer agent -t <template>         # AI-assisted workflows
wafer target config              # Configure your own GPU targets
```
