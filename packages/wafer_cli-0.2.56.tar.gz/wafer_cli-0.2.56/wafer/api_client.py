"""Wafer API client for remote GPU operations.
Thin client that calls wafer-api endpoints instead of direct SSH.
"""
from .global_config import get_api_url  # noqa: F401 - re-exported for backwards compat


def _get_auth_headers() -> dict[str, str]:
    """Get auth headers from stored credentials (lazy import to avoid circular)."""
    from .auth import get_auth_headers
    return get_auth_headers()
