# ruff: noqa: PLR0913, E402
# PLR0913 (too many arguments) is suppressed because Typer CLI commands
# naturally have many parameters - each --flag becomes a function argument.
# E402 (module level import not at top) is suppressed because we intentionally
# load .env files before importing other modules that may read env vars.
"""Wafer CLI - GPU development toolkit for LLM coding agents.

Top-level groups:
  wafer target    Create and manage GPU targets and workspaces
  wafer tool      Run profiling, evaluation, and analysis tools
  wafer agent     AI assistant for GPU kernel development
  wafer settings  Auth, config, billing, deps, and onboarding
"""
import atexit
import os
import shutil
import sys
import time
from pathlib import Path
import trio
import typer
from dotenv import load_dotenv
# Auto-load .env from current directory and ~/.wafer/.env
# This runs at import time so env vars are available before any config is accessed
load_dotenv()  # cwd/.env
load_dotenv(Path.home() / ".wafer" / ".env")  # ~/.wafer/.env
from .problems import (
    download_problems,
    get_problem_path,
    get_problems_path,
    list_problems as list_problems_fn,
)
app = typer.Typer(
    help="GPU development toolkit for LLM coding agents",
    no_args_is_help=False,
    pretty_exceptions_show_locals=False,  # Don't dump local vars (makes tracebacks huge)
    # Keep add_completion=True: README documents wafer --install-completion for shell setup
)

_command_start_time: float | None = None

_command_outcome: str = "failure"
# Track normalized failure metadata for PostHog alerting
_command_failure_details: dict[str, str | int] | None = None


def _show_version(json_output: bool = False) -> None:
    """Show CLI version and environment, then exit."""
    from .analytics import _get_cli_version
    from .global_config import load_global_config
    from .output import json_response
    version = _get_cli_version()
    config = load_global_config()
    environment = config.environment
    if json_output:
        typer.echo(json_response(data={"version": version, "environment": environment}))
    else:
        typer.echo(f"wafer-cli {version} ({environment})")
    raise typer.Exit()


def _show_welcome() -> None:
    """Show first-run welcome message for unauthenticated users."""
    from .analytics import _get_cli_version

    version = _get_cli_version()
    typer.echo(f"Wafer CLI v{version} — GPU development toolkit for LLM coding agents")
    typer.echo("")
    typer.echo("Get started:")
    typer.echo("  wafer login              Authenticate with GitHub")
    typer.echo("  wafer guide quickstart   Quick start guide")
    typer.echo("  wafer demo               Interactive demos")
    typer.echo("  wafer settings deps check   Check local tool dependencies")
    typer.echo("")
    typer.echo("Works without login:")
    typer.echo("  wafer roofline ...       Roofline analysis")
    typer.echo("  wafer guide              CLI usage guide")
    typer.echo("")
    typer.echo("Run wafer --help to see all commands.")


def _get_command_path(ctx: typer.Context) -> tuple[str, str | None]:
    """Extract command and subcommand from Typer context.
    Returns:
        Tuple of (command, subcommand). subcommand may be None.
    """
    invoked = ctx.invoked_subcommand
    info_name = ctx.info_name or ""
    parent_cmd = None
    if ctx.parent and ctx.parent.info_name and ctx.parent.info_name != "wafer":
        parent_cmd = ctx.parent.info_name
    if parent_cmd:
        return parent_cmd, info_name
    return info_name or "unknown", invoked
def _mark_command_success() -> None:
    """Mark the current command as successful.
    Call this at the end of successful command execution.
    Commands that raise typer.Exit(1) or exceptions will remain marked as failures.
    """
    global _command_outcome
    _command_outcome = "success"
@app.callback(invoke_without_command=True)
def main_callback(
    ctx: typer.Context,
    version: bool = typer.Option(
        False,
        "--version",
        help="Show version and exit",
    ),
    json_output: bool = typer.Option(
        False,
        "--json",
        "-j",
        help="Output as JSON (used with --version or subcommands)",
    ),
    no_color: bool = typer.Option(
        False,
        "--no-color",
        help="Suppress colored output",
    ),
) -> None:
    """Initialize analytics and track command execution."""
    if no_color:
        os.environ["NO_COLOR"] = "1"
    if version:
        _show_version(json_output=json_output)
        return

    # Handle bare `wafer` (no subcommand)
    if ctx.invoked_subcommand is None and not ctx.resilient_parsing:
        from .auth import load_credentials

        creds = load_credentials()
        if creds is None:
            _show_welcome()
        else:
            typer.echo(ctx.get_help())
        raise typer.Exit(0)

    global _command_start_time, _command_outcome, _command_failure_details
    _command_start_time = time.time()
    _command_outcome = "success"  # Default to success, mark failure on exceptions
    _command_failure_details = None

    # Initialize analytics (lazy import to avoid slowing down --help)
    from . import analytics
    analytics.init_analytics()
    # Install exception hook to catch SystemExit and mark failures
    # Also prints error message FIRST so it's visible even when traceback is truncated
    original_excepthook = sys.excepthook
    def custom_excepthook(
        exc_type: type[BaseException],
        exc_value: BaseException,
        exc_traceback: object,
    ) -> None:
        global _command_outcome, _command_failure_details
        # Mark as failure if SystemExit with non-zero code, or any other exception
        if exc_type is SystemExit:
            exit_code = exc_value.code if hasattr(exc_value, "code") else 1
            if exit_code != 0 and exit_code is not None:
                _command_outcome = "failure"
                _command_failure_details = {
                    "error_type": "SystemExit",
                    "error_message": str(exc_value),
                }
                if isinstance(exit_code, int):
                    _command_failure_details["exit_code"] = exit_code
        else:
            _command_outcome = "failure"
            _command_failure_details = {
                "error_type": exc_type.__name__,
                "error_message": str(exc_value),
                "exit_code": 1,
            }
            # Print error summary FIRST (before traceback) so it's visible even if truncated
            if os.environ.get("NO_COLOR"):
                print(f"\n>>> ERROR: {exc_type.__name__}: {exc_value}\n", file=sys.stderr)
            else:
                print(
                    f"\n\033[1;31m>>> ERROR: {exc_type.__name__}: {exc_value}\033[0m\n",
                    file=sys.stderr,
                )
        # Call original excepthook (prints the full traceback)
        original_excepthook(exc_type, exc_value, exc_traceback)
    sys.excepthook = custom_excepthook
    # Register tracking at exit to capture command outcome
    def track_on_exit() -> None:
        command, subcommand = _get_command_path(ctx)

        if ctx.resilient_parsing:
            return
        duration_ms = None
        if _command_start_time is not None:
            duration_ms = int((time.time() - _command_start_time) * 1000)

        failure_props = _command_failure_details or {}
        exit_code = failure_props.get("exit_code")
        error_type = failure_props.get("error_type")
        error_message = failure_props.get("error_message")

        typed_exit_code = exit_code if isinstance(exit_code, int) else None
        typed_error_type = error_type if isinstance(error_type, str) else None
        typed_error_message = error_message if isinstance(error_message, str) else None

        # Track the command execution with the recorded outcome
        analytics.track_command(
            command=command,
            subcommand=subcommand,
            outcome=_command_outcome,
            duration_ms=duration_ms,
            properties=failure_props if _command_outcome == "failure" else None,
        )

        if _command_outcome == "failure":
            analytics.track_command_failure(
                command=command,
                subcommand=subcommand,
                error_type=typed_error_type,
                error_message=typed_error_message,
                exit_code=typed_exit_code,
                duration_ms=duration_ms,
            )

    atexit.register(track_on_exit)
def complete_target_name(incomplete: str) -> list[str]:
    """Autocomplete target names from ~/.wafer/targets/*.toml"""
    targets_dir = Path.home() / ".wafer" / "targets"
    if not targets_dir.exists():
        return []
    return [f.stem for f in targets_dir.glob("*.toml") if f.stem.startswith(incomplete)]
target_app = typer.Typer(
    name="target",
    help="Create and manage GPU targets and workspaces.",
    no_args_is_help=True,
)
tool_app = typer.Typer(
    name="tool",
    help="Run profiling, evaluation, and analysis tools.",
    no_args_is_help=True,
)
settings_app = typer.Typer(
    name="settings",
    help="Auth, config, billing, deps, and onboarding.",
    no_args_is_help=True,
)
app.add_typer(target_app, name="target")
app.add_typer(tool_app, name="tool")
app.add_typer(settings_app, name="settings")

config_app = typer.Typer(help="Manage CLI configuration")
targets_app = typer.Typer(
    help="""Manage GPU targets for remote evaluation.
Targets define how to access GPUs. Use 'wafer target config init' to set up:
  wafer target config init ssh           # Your own GPU via SSH
  wafer target config init runpod        # RunPod cloud GPUs
  wafer target config init digitalocean  # DigitalOcean AMD GPUs
Then use with: wafer tool eval --target <name> ..."""
)
workspaces_app = typer.Typer(
    help="""Manage cloud GPU workspaces for remote development.
Workspaces are on-demand cloud GPU environments. Requires authentication (wafer settings login).
Available GPUs:
  MI300X  AMD Instinct MI300X (192GB HBM3, ROCm)
  B200    NVIDIA Blackwell B200 (180GB HBM3e, CUDA)
Commands:
  wafer target workspace create dev --gpu B200   # Create workspace
  wafer target workspace exec dev -- python x.py # Run commands
  wafer target workspace delete dev              # Clean up"""
)
ssh_keys_app = typer.Typer(
    help="""Manage SSH public keys for workspace access.
Register your SSH public keys here. These keys are installed in all workspaces
you provision, enabling SSH access from any machine with your private key.
  wafer settings ssh-keys list              # List registered keys
  wafer settings ssh-keys add               # Add key (auto-detects ~/.ssh/id_ed25519.pub)
  wafer settings ssh-keys add ~/.ssh/id_rsa.pub --name laptop  # Add specific key
  wafer settings ssh-keys remove <key-id>   # Remove a key"""
)
targets_ops_app = typer.Typer(
    help="""Execute commands on configured GPU targets.
Run commands on targets. Useful for exploratory work, debugging, or custom scripts.
  wafer tool exec my-target -- python test.py    # Run command
Supports: RunPod, DigitalOcean (auto-provisions), SSH targets (baremetal/vm).
Configure targets with: wafer target config init ..."""
)
billing_app = typer.Typer(help="Manage billing, credits, and subscription")

evaluate_app = typer.Typer(
    help="Test kernel correctness and performance",
    invoke_without_command=True,
)
kernelbench_app = typer.Typer(
    help="Evaluate kernels in KernelBench format (ModelNew class)",
    invoke_without_command=True,
)
evaluate_app.add_typer(kernelbench_app, name="kernelbench")
gpumode_app = typer.Typer(
    help="Evaluate kernels in GPUMode format (custom_kernel/ref_kernel functions)",
    invoke_without_command=True,
)
evaluate_app.add_typer(gpumode_app, name="gpumode")
aiter_app = typer.Typer(
    help="Evaluate aiter operator optimizations on AMD MI300X",
    invoke_without_command=True,
)
evaluate_app.add_typer(aiter_app, name="aiter")
vllm_app = typer.Typer(
    help="Evaluate vLLM kernel optimizations (correctness + serving benchmark)",
    invoke_without_command=True,
)
evaluate_app.add_typer(vllm_app, name="vllm")
flashinfer_bench_app = typer.Typer(
    help="Evaluate kernels using FlashInfer-Bench (official benchmark suite)",
    invoke_without_command=True,
)
evaluate_app.add_typer(flashinfer_bench_app, name="flashinfer-bench")
hipblaslt_app = typer.Typer(
    help="Evaluate hipBLASLt GEMM kernel optimizations on AMD MI300X",
    invoke_without_command=True,
)
evaluate_app.add_typer(hipblaslt_app, name="hipblaslt")
from wafer.baseline import baseline_app
ncu_app = typer.Typer(help="Nsight Compute profiling and analysis")
nsys_app = typer.Typer(help="Nsight Systems profile analysis")
perfetto_app = typer.Typer(help="Perfetto trace analysis and SQL queries")
tracelens_app = typer.Typer(help="TraceLens performance reports")
from .distributed_traces import nvidia_distributed_traces_app
isa_app = typer.Typer(help="ISA analysis for AMD GPU kernels (.co, .s, .ll, .ttgir files)")
compare_app = typer.Typer(help="Compare GPU traces across platforms (AMD vs NVIDIA)")

target_app.add_typer(workspaces_app, name="workspace")
target_app.add_typer(targets_app, name="config")

tool_app.add_typer(targets_ops_app, name="exec", rich_help_panel="Execution")
tool_app.add_typer(evaluate_app, name="eval", rich_help_panel="Execution")
tool_app.add_typer(baseline_app, name="baseline", rich_help_panel="Execution")
tool_app.add_typer(ncu_app, name="ncu", rich_help_panel="NVIDIA Profiling")
tool_app.add_typer(nsys_app, name="nsys", rich_help_panel="NVIDIA Profiling")
tool_app.add_typer(perfetto_app, name="perfetto", rich_help_panel="NVIDIA Profiling")
tool_app.add_typer(tracelens_app, name="tracelens", rich_help_panel="NVIDIA Profiling")
tool_app.add_typer(nvidia_distributed_traces_app, name="nvidia-distributed-traces", rich_help_panel="NVIDIA Profiling")
tool_app.add_typer(isa_app, name="isa", rich_help_panel="AMD Profiling")
tool_app.add_typer(compare_app, name="compare", rich_help_panel="Analysis")

from .deps import deps_app
settings_app.add_typer(config_app, name="config")
settings_app.add_typer(billing_app, name="billing")

settings_app.add_typer(ssh_keys_app, name="ssh-keys")
settings_app.add_typer(deps_app, name="deps")
@tool_app.command("roofline", rich_help_panel="Analysis")
def roofline_cmd(
    gpu: str | None = typer.Option(
        None, "--gpu", "-g", help="GPU name (e.g., H100, B200, MI300X, A100)"
    ),
    bytes_moved: float | None = typer.Option(
        None, "--bytes", "-b", help="Theoretical minimum bytes moved"
    ),
    flops: float | None = typer.Option(None, "--flops", "-f", help="Theoretical minimum FLOPs"),
    time_ms: float | None = typer.Option(
        None, "--time-ms", "-t", help="Actual kernel time in milliseconds"
    ),
    dtype: str = typer.Option(
        "fp16", "--dtype", "-d", help="Data type for compute ceiling (fp16, fp32, bf16, fp8, int8)"
    ),
    list_gpus: bool = typer.Option(False, "--list-gpus", help="List available GPU specs and exit"),
    json_output: bool = typer.Option(False, "--json", "-j", help="Output as JSON"),
) -> None:
    """Analyze kernel performance against roofline model.
    The roofline model shows the theoretical speed-of-light (SOL) for your kernel
    based on whether it's memory-bound or compute-bound.
    You need to provide:
    - The GPU you ran on
    - Theoretical minimum bytes moved (not actual - what the algorithm requires)
    - Theoretical minimum FLOPs
    - Actual measured kernel time
    Example:
        # Analyze a matmul kernel (4096x4096x4096, FP16)
        # Theoretical: 2*M*N*K FLOPs = 137.4 TFLOP
        # Theoretical bytes: (M*K + K*N + M*N) * 2 = 100.7 MB
        wafer tool roofline --gpu H100 --bytes 100.7e6 --flops 137.4e12 --time-ms 85
        # Analyze a memory-bound elementwise add (1B elements FP32)
        # Reads 2 tensors, writes 1 = 12 GB total
        # 1B adds = 1 GFLOP
        wafer tool roofline --gpu H100 --bytes 12e9 --flops 1e9 --time-ms 4 --dtype fp32
        # List available GPUs
        wafer tool roofline --list-gpus
        # JSON output
        wafer tool roofline --gpu H100 --bytes 100.7e6 --flops 137.4e12 --time-ms 85 --json
    """
    from wafer_core.roofline import get_gpu_spec, roofline_analysis
    from wafer_core.roofline import list_gpus as get_all_gpus
    if list_gpus:
        if json_output:
            from .output import json_response
            gpu_list = []
            for name in get_all_gpus():
                spec = get_gpu_spec(name)
                gpu_list.append({
                    "name": name,
                    "full_name": spec.name,
                    "peak_bandwidth_gbps": spec.peak_bandwidth_gbps,
                    "peak_tflops_fp16": spec.peak_tflops_fp16,
                    "peak_tflops_fp32": spec.peak_tflops_fp32,
                })
            typer.echo(json_response(data={"gpus": gpu_list}))
        else:
            typer.echo("Available GPUs:")
            for name in get_all_gpus():
                spec = get_gpu_spec(name)
                typer.echo(
                    f"  {name}: {spec.peak_bandwidth_gbps:.0f} GB/s, {spec.peak_tflops_fp16:.0f} TFLOPS FP16"
                )
        return
    # Validate required args for analysis
    missing = []
    if gpu is None:
        missing.append("--gpu")
    if bytes_moved is None:
        missing.append("--bytes")
    if flops is None:
        missing.append("--flops")
    if time_ms is None:
        missing.append("--time-ms")
    if missing:
        if json_output:
            from .output import json_error
            typer.echo(json_error(f"Missing required options: {', '.join(missing)}"))
        else:
            typer.echo(f"Error: Missing required options: {', '.join(missing)}", err=True)
            typer.echo("", err=True)
            typer.echo("Run 'wafer tool roofline --help' for usage.", err=True)
        raise typer.Exit(1)
    try:
        result = roofline_analysis(
            gpu=gpu,
            dtype=dtype,
            bytes_moved=bytes_moved,
            flops=flops,
            time_ms=time_ms,
        )
    except ValueError as e:
        if json_output:
            from .output import json_error
            typer.echo(json_error(str(e)))
        else:
            typer.echo(f"Error: {e}", err=True)
        raise typer.Exit(1) from None
    if json_output:
        from .output import json_response
        data = {
            "gpu": result.gpu.name,
            "dtype": result.dtype.value,
            "bottleneck": result.bottleneck.value,
            "arithmetic_intensity": result.arithmetic_intensity,
            "ridge_point": result.ridge_point,
            "efficiency_pct": result.efficiency_pct,
            "bytes_moved": result.bytes_moved,
            "flops": result.flops,
            "actual_time_s": result.actual_time_s,
            "theoretical_time_s": result.theoretical_time_s,
            "memory_bound_time_s": result.memory_bound_time_s,
            "compute_bound_time_s": result.compute_bound_time_s,
            "peak_bandwidth_bytes_per_s": result.peak_bandwidth_bytes_per_s,
            "peak_flops_per_s": result.peak_flops_per_s,
            "achieved_compute_flops_per_s": result.achieved_compute_flops_per_s,
            "achieved_bandwidth_bytes_per_s": result.achieved_bandwidth_bytes_per_s,
            "compute_efficiency_pct": result.compute_efficiency_pct,
            "bandwidth_efficiency_pct": result.bandwidth_efficiency_pct,
        }
        typer.echo(json_response(data=data))
    else:
        typer.echo(result.format_report())
from .distributed_traces import amd_distributed_traces_app
tool_app.add_typer(amd_distributed_traces_app, name="amd-distributed-traces", rich_help_panel="AMD Profiling")
skill_app = typer.Typer(help="Manage AI coding assistant skills (Claude Code, Codex)")
settings_app.add_typer(skill_app, name="skill")
@skill_app.command("install")
def skill_install(
    target: str = typer.Option(
        "all",
        "--target",
        "-t",
        help="Target tool: claude, codex, cursor, or all",
    ),
    force: bool = typer.Option(False, "--force", "-f", help="Overwrite existing skill"),
) -> None:
    """Install the wafer-guide skill for AI coding assistants.
    Installs the bundled skill to make wafer commands discoverable by
    Claude Code, OpenAI Codex CLI, and/or Cursor.
    Skills follow the open agent skills specification (agentskills.io).
    Examples:
        wafer settings skill install              # Install for all tools
        wafer settings skill install -t claude    # Install for Claude Code only
        wafer settings skill install -t codex     # Install for Codex CLI only
        wafer settings skill install -t cursor    # Install for Cursor only
        wafer settings skill install --force      # Overwrite existing installation
    """
    # Locate bundled skill
    skill_source = Path(__file__).parent / "skills" / "wafer-guide"
    if not skill_source.exists():
        typer.echo("Error: Bundled skill not found. Package may be corrupted.", err=True)
        raise typer.Exit(1)
    targets_to_install: list[tuple[str, Path]] = []
    if target in ("all", "claude"):
        targets_to_install.append((
            "Claude Code",
            Path.home() / ".claude" / "skills" / "wafer-guide",
        ))
    if target in ("all", "codex"):
        targets_to_install.append(("Codex CLI", Path.home() / ".codex" / "skills" / "wafer-guide"))
    if target in ("all", "cursor"):
        targets_to_install.append(("Cursor", Path.home() / ".cursor" / "skills" / "wafer-guide"))
    if not targets_to_install:
        typer.echo(
            f"Error: Unknown target '{target}'. Use: claude, codex, cursor, or all", err=True
        )
        raise typer.Exit(1)
    for tool_name, dest_path in targets_to_install:
        if dest_path.exists() or dest_path.is_symlink():
            if not force:
                typer.echo(f"  {tool_name}: Already installed at {dest_path}")
                typer.echo("             Use --force to overwrite")
                continue
            # Remove existing
            if dest_path.is_symlink():
                dest_path.unlink()
            else:
                import shutil
                shutil.rmtree(dest_path)
        dest_path.parent.mkdir(parents=True, exist_ok=True)
        dest_path.symlink_to(skill_source)
        typer.echo(f"  {tool_name}: Installed at {dest_path}")
    typer.echo("")
    typer.echo("Restart your AI assistant to load the new skill.")
@skill_app.command("uninstall")
def skill_uninstall(
    target: str = typer.Option(
        "all",
        "--target",
        "-t",
        help="Target tool: claude, codex, cursor, or all",
    ),
) -> None:
    """Uninstall the wafer-guide skill.
    Examples:
        wafer settings skill uninstall              # Uninstall from all tools
        wafer settings skill uninstall -t claude    # Uninstall from Claude Code only
        wafer settings skill uninstall -t cursor    # Uninstall from Cursor only
    """
    targets_to_uninstall: list[tuple[str, Path]] = []
    if target in ("all", "claude"):
        targets_to_uninstall.append((
            "Claude Code",
            Path.home() / ".claude" / "skills" / "wafer-guide",
        ))
    if target in ("all", "codex"):
        targets_to_uninstall.append((
            "Codex CLI",
            Path.home() / ".codex" / "skills" / "wafer-guide",
        ))
    if target in ("all", "cursor"):
        targets_to_uninstall.append((
            "Cursor",
            Path.home() / ".cursor" / "skills" / "wafer-guide",
        ))
    if not targets_to_uninstall:
        typer.echo(
            f"Error: Unknown target '{target}'. Use: claude, codex, cursor, or all", err=True
        )
        raise typer.Exit(1)
    for tool_name, dest_path in targets_to_uninstall:
        if not dest_path.exists():
            typer.echo(f"  {tool_name}: Not installed")
            continue
        if dest_path.is_symlink():
            dest_path.unlink()
        else:
            import shutil
            shutil.rmtree(dest_path)
        typer.echo(f"  {tool_name}: Uninstalled from {dest_path}")
@skill_app.command("status")
def skill_status(
    json_output: bool = typer.Option(False, "--json", "-j", help="Output as JSON"),
) -> None:
    """Show installation status of the wafer-guide skill.
    Examples:
        wafer settings skill status
        wafer settings skill status --json
    """
    from .output import json_response
    skill_source = Path(__file__).parent / "skills" / "wafer-guide"

    assert skill_source.exists(), f"Bundled skill missing at {skill_source}"

    installations = [
        ("Cursor", "cursor", Path.home() / ".cursor" / "skills" / "wafer-guide"),
        ("Claude Code", "claude", Path.home() / ".claude" / "skills" / "wafer-guide"),
        ("Codex CLI", "codex", Path.home() / ".codex" / "skills" / "wafer-guide"),
    ]

    if json_output:
        tools = []
        for display_name, flag, path in installations:
            installed = path.exists() or path.is_symlink()
            tools.append({
                "tool": display_name,
                "flag": flag,
                "installed": installed,
                "path": str(path),
            })
        typer.echo(json_response(data={
            "skill": "wafer-guide",
            "description": "GPU kernel development knowledge for AI coding assistants.",
            "bundled": True,
            "installations": tools,
        }))
        return

    typer.echo("wafer-guide (bundled)")
    typer.echo("  GPU kernel development knowledge for AI coding assistants.")
    typer.echo("")

    typer.echo("Installed for:")
    for display_name, flag, path in installations:
        if path.exists() or path.is_symlink():
            typer.echo(f"  {display_name + ':':<14} Installed")
        else:
            typer.echo(f"  {display_name + ':':<14} Not installed  (run: wafer settings skill install -t {flag})")


provider_auth_app = typer.Typer(help="Manage API keys for cloud GPU providers")
settings_app.add_typer(provider_auth_app, name="auth")
@provider_auth_app.command("login")
def provider_auth_login(
    provider: str = typer.Argument(
        ...,
        help="Provider name: runpod, digitalocean, modal, anthropic, or openai",
    ),
    api_key: str | None = typer.Option(
        None,
        "--api-key",
        "-k",
        help="API key (if not provided, reads from stdin)",
    ),
) -> None:
    """Save API key for a provider.
    Stores the key in ~/.wafer/auth.json. Environment variables
    (e.g., ANTHROPIC_API_KEY) take precedence over stored keys.
    Examples:
        wafer settings auth login anthropic --api-key sk-ant-xxx
        wafer settings auth login runpod --api-key rp_xxx
        wafer settings auth login openai --api-key sk-xxx
        echo $API_KEY | wafer settings auth login anthropic
    """
    import sys
    from wafer_core.auth import PROVIDERS, save_api_key
    # Validate provider
    if provider not in PROVIDERS:
        typer.echo(f"Error: Unknown provider '{provider}'", err=True)
        typer.echo(f"Valid providers: {', '.join(PROVIDERS.keys())}", err=True)
        raise typer.Exit(1)
    if api_key is None:
        if sys.stdin.isatty():
            typer.echo(f"Enter API key for {PROVIDERS[provider]['display_name']}:")
            api_key = typer.prompt("API key", hide_input=True)
        else:
            api_key = sys.stdin.read().strip()
    if not api_key:
        typer.echo("Error: No API key provided", err=True)
        raise typer.Exit(1)
    # Save the key
    save_api_key(provider, api_key)
    typer.echo(f"API key saved for {PROVIDERS[provider]['display_name']}")
    typer.echo("Stored in: ~/.wafer/auth.json")
@provider_auth_app.command("logout")
def provider_auth_logout(
    provider: str = typer.Argument(
        ...,
        help="Provider name: runpod, digitalocean, modal, anthropic, or openai",
    ),
) -> None:
    """Remove stored API key for a cloud GPU provider.
    Examples:
        wafer auth logout runpod
        wafer auth logout digitalocean
    """
    from wafer_core.auth import PROVIDERS, remove_api_key
    # Validate provider
    if provider not in PROVIDERS:
        typer.echo(f"Error: Unknown provider '{provider}'", err=True)
        typer.echo(f"Valid providers: {', '.join(PROVIDERS.keys())}", err=True)
        raise typer.Exit(1)
    if remove_api_key(provider):
        typer.echo(f"API key removed for {PROVIDERS[provider]['display_name']}")
    else:
        typer.echo(f"No stored API key found for {PROVIDERS[provider]['display_name']}")
@provider_auth_app.command("status")
def provider_auth_status(
    json_output: bool = typer.Option(False, "--json", "-j", help="Output as JSON"),
) -> None:
    """Show authentication status for all cloud GPU providers.
    Displays which providers have API keys configured and where
    the keys are coming from (environment variable or auth.json).
    Example:
        wafer settings auth status
        wafer settings auth status --json
    """
    from wafer_core.auth import get_all_auth_status
    from .output import json_response
    statuses = get_all_auth_status()

    if json_output:
        providers = []
        for s in statuses:
            providers.append({
                "provider": s.provider,
                "display_name": s.display_name,
                "authenticated": s.is_authenticated,
                "source": s.source if s.is_authenticated else None,
                "key_preview": s.key_preview if s.is_authenticated else None,
            })
        typer.echo(json_response(data={"providers": providers}))
        return

    typer.echo("Cloud GPU Provider Authentication Status")
    typer.echo("=" * 45)
    for status in statuses:
        if status.is_authenticated:
            source_str = f"({status.source})" if status.source else ""
            typer.echo(f"  {status.display_name}: ✓ {status.key_preview} {source_str}")
        else:
            typer.echo(f"  {status.display_name}: ✗ Not configured")
            typer.echo(f"      Run: wafer settings auth login {status.provider}")
            typer.echo(f"      Or set: {status.key_url}")
    typer.echo("")
    typer.echo("Note: Environment variables take precedence over stored keys.")
@config_app.command("init")
def config_init(
    environment: str = typer.Option(
        "prod",
        "--env",
        "-e",
        help="Initial API environment (staging, prod, local)",
    ),
) -> None:
    """Initialize config file with defaults.
    Creates ~/.wafer/config.toml with the specified environment.
    Examples:
        wafer settings config init                  # use prod environment
        wafer settings config init --env staging    # use staging environment
    """
    from .global_config import (
        BUILTIN_ENVIRONMENTS,
        CONFIG_FILE,
        init_config,
    )
    if environment not in BUILTIN_ENVIRONMENTS:
        typer.echo(
            f"Error: Unknown environment '{environment}'. "
            f"Available: {', '.join(BUILTIN_ENVIRONMENTS.keys())}",
            err=True,
        )
        raise typer.Exit(1)
    if CONFIG_FILE.exists():
        typer.echo(f"Config already exists: {CONFIG_FILE}")
        typer.echo("Use 'wafer settings config set' to modify settings.")
        raise typer.Exit(1)
    config = init_config(environment)
    env = config.get_api_environment()
    typer.echo(f"Created {CONFIG_FILE}")
    typer.echo(f"Environment: {environment}")
    typer.echo(f"API URL: {env.api_url}")


def _format_target_summary(target: object) -> str:
    """Format a single target as a one-line summary string.

    Extracts connection info and GPU type from the target dataclass.
    """
    _TYPE_MAP = {
        "BaremetalTarget": "baremetal",
        "VMTarget": "vm",
        "ModalTarget": "modal",
        "WorkspaceTarget": "workspace",
        "RunPodTarget": "runpod",
        "DigitalOceanTarget": "digitalocean",
        "LocalTarget": "local",
    }
    target_type = _TYPE_MAP.get(type(target).__name__, "unknown")

    details = ""
    if hasattr(target, "ssh_target"):
        details = f"  {target.ssh_target}"
    elif hasattr(target, "workspace_id"):
        details = f"  workspace:{target.workspace_id}"
    elif hasattr(target, "modal_app_name"):
        details = f"  app:{target.modal_app_name}"

    gpu = getattr(target, "gpu_type", None)
    if gpu:
        details += f"  ({gpu})"

    return f"[{target_type}]{details}"


def _show_targets() -> list[str]:
    """Return lines describing configured targets."""
    from .targets import get_default_target, list_targets, load_target

    lines: list[str] = []
    target_names = list_targets()

    if not target_names:
        lines.append("  None configured")
        lines.append("  Run 'wafer target config init' to set up a target.")
        return lines

    default_target = get_default_target()
    for name in target_names:
        marker = " (default)" if name == default_target else ""
        try:
            target = load_target(name)
            summary = _format_target_summary(target)
            lines.append(f"  {name}{marker}  {summary}")
        except (FileNotFoundError, ValueError, TypeError, OSError):
            lines.append(f"  {name}{marker}  (error loading config)")

    return lines


def _show_docker_config() -> list[str]:
    """Return lines describing Docker execution configuration."""
    config_path = Path.home() / ".wafer" / "config.toml"
    if not config_path.exists():
        return ["  Not configured"]

    try:
        from wafer_core.config import WaferConfig, load_config

        _, project_cfg = load_config(config_path.parent)
        if project_cfg is None:
            return ["  Not configured"]
    except (ImportError, TypeError, FileNotFoundError, OSError):
        return ["  Not configured"]

    lines: list[str] = []
    if project_cfg.sandbox.enabled:
        lines.append("  Sandbox:     enabled")
    else:
        lines.append("  Sandbox:     disabled")
    if project_cfg.allowlist.allow:
        lines.append("  Allowlist:   " + ", ".join(project_cfg.allowlist.allow))
    if project_cfg.allowlist.block:
        lines.append("  Blocklist:   " + ", ".join(project_cfg.allowlist.block))
    if not lines:
        lines.append("  Default settings")
    return lines


def _show_cloud_providers() -> list[str]:
    """Return lines describing cloud provider auth status."""
    from wafer_core.auth import get_all_auth_status

    cloud_providers = {"runpod", "digitalocean", "modal"}
    lines: list[str] = []
    for status in get_all_auth_status():
        if status.provider not in cloud_providers:
            continue
        if status.is_authenticated:
            source_hint = f" (from {status.source})" if status.source else ""
            lines.append(f"  {status.display_name + ':':<20} Configured{source_hint}")
        else:
            lines.append(f"  {status.display_name + ':':<20} Not configured")
    return lines


@config_app.command("show")
def config_show_new(
    json_output: bool = typer.Option(False, "--json", "-j", help="Output as JSON"),
) -> None:
    """Show current configuration.

    Displays a unified view of all Wafer configuration: API settings,
    authentication, targets, Docker environments, and cloud providers.
    """
    from .auth import load_credentials
    from .global_config import CONFIG_FILE, GlobalConfig, load_global_config
    from .output import json_response

    global_cfg: GlobalConfig = load_global_config()
    api_env = global_cfg.get_api_environment()
    creds = load_credentials()

    if creds and creds.email:
        auth_line = creds.email
    elif creds:
        auth_line = "Logged in (run 'wafer whoami --verify' to check)"
    else:
        auth_line = "Not logged in (run 'wafer login')"

    if json_output:
        from typing import Any
        # Targets
        from .targets import get_default_target, list_targets, load_target
        target_names = list_targets()
        default_target = get_default_target()
        targets_data: list[dict[str, Any]] = []
        for name in target_names:
            entry: dict[str, Any] = {"name": name, "default": name == default_target}
            try:
                t = load_target(name)
                entry["type"] = type(t).__name__
                if hasattr(t, "ssh_target"):
                    entry["ssh_target"] = t.ssh_target
                if hasattr(t, "gpu_type") and t.gpu_type:
                    entry["gpu_type"] = t.gpu_type
            except (FileNotFoundError, ValueError, TypeError, OSError):
                entry["error"] = "failed to load config"
            targets_data.append(entry)
        # Cloud providers
        providers_data: list[dict[str, Any]] = []
        try:
            from wafer_core.auth import get_all_auth_status
            cloud_providers = {"runpod", "digitalocean", "modal"}
            for s in get_all_auth_status():
                if s.provider not in cloud_providers:
                    continue
                providers_data.append({
                    "provider": s.provider,
                    "display_name": s.display_name,
                    "configured": s.is_authenticated,
                    "source": s.source if s.is_authenticated else None,
                })
        except (ImportError, OSError, ValueError):
            pass
        data: dict[str, Any] = {
            "config_file": str(CONFIG_FILE),
            "config_file_exists": CONFIG_FILE.exists(),
            "api": {
                "environment": global_cfg.environment,
                "api_url": api_env.api_url,
                "authenticated": creds is not None,
                "email": creds.email if creds else None,
            },
            "defaults": {
                "mode": global_cfg.preferences.mode,
                "workspace": global_cfg.defaults.workspace,
                "gpu": global_cfg.defaults.gpu,
                "exec_timeout": global_cfg.defaults.exec_timeout,
            },
            "targets": targets_data,
            "cloud_providers": providers_data,
        }
        typer.echo(json_response(data=data))
        return

    # Human-readable output
    if CONFIG_FILE.exists():
        typer.echo(f"Config: {CONFIG_FILE}")
    else:
        typer.echo(f"Config: {CONFIG_FILE} (not found, using defaults)")
        typer.echo("  Run 'wafer config init' to create a config file.")

    typer.echo("\nAPI:")
    typer.echo(f"  Environment: {global_cfg.environment}")
    typer.echo(f"  API URL:     {api_env.api_url}")
    typer.echo(f"  Auth:        {auth_line}")

    mode = global_cfg.preferences.mode
    mode_desc = (
        "verbose status messages" if mode == "explicit" else "quiet output, use -v for details"
    )
    typer.echo("\nDefaults:")
    typer.echo(f"  Mode:        {mode} ({mode_desc})")
    if global_cfg.defaults.workspace:
        typer.echo(f"  Workspace:   {global_cfg.defaults.workspace}")
    typer.echo(f"  GPU:         {global_cfg.defaults.gpu}")
    typer.echo(f"  Timeout:     {global_cfg.defaults.exec_timeout}s")

    typer.echo("\nTargets:")
    for line in _show_targets():
        typer.echo(line)

    typer.echo("\nDocker:")
    for line in _show_docker_config():
        typer.echo(line)

    typer.echo("\nCloud Providers:")
    try:
        for line in _show_cloud_providers():
            typer.echo(line)
    except (ImportError, OSError, ValueError):
        typer.echo("  (unable to check provider status)")


@config_app.command("set")
def config_set(
    key: str = typer.Argument(..., help="Config key (e.g., api.environment, defaults.workspace)"),
    value: str = typer.Argument(..., help="Value to set"),
) -> None:
    """Set a configuration value.
    Examples:
        wafer settings config set api.environment staging
        wafer settings config set defaults.workspace dev
        wafer settings config set defaults.exec_timeout 600
        wafer settings config set preferences.mode implicit
    """
    from dataclasses import replace
    from .global_config import (
        CONFIG_FILE,
        GlobalConfig,
        clear_config_cache,
        load_global_config,
        save_global_config,
    )
    if CONFIG_FILE.exists():
        config = load_global_config()
    else:
        config = GlobalConfig()
    parts = key.split(".")
    if len(parts) != 2:
        typer.echo(f"Error: Invalid key format '{key}'. Use 'section.key' format.", err=True)
        typer.echo("Examples: api.environment, defaults.workspace, preferences.mode", err=True)
        raise typer.Exit(1)
    section, field = parts
    if section == "api":
        if field == "environment":
            if value not in config.environments:
                typer.echo(
                    f"Error: Unknown environment '{value}'. "
                    f"Available: {', '.join(config.environments.keys())}",
                    err=True,
                )
                raise typer.Exit(1)
            config = replace(config, environment=value)
        else:
            typer.echo(f"Error: Unknown api field '{field}'. Available: environment", err=True)
            raise typer.Exit(1)
    elif section == "defaults":
        if field == "workspace":
            new_defaults = replace(config.defaults, workspace=value if value else None)
            config = replace(config, defaults=new_defaults)
        elif field == "gpu":
            new_defaults = replace(config.defaults, gpu=value)
            config = replace(config, defaults=new_defaults)
        elif field == "exec_timeout":
            try:
                timeout = int(value)
                assert timeout > 0, "timeout must be positive"
            except (ValueError, AssertionError) as e:
                typer.echo(f"Error: exec_timeout must be a positive integer: {e}", err=True)
                raise typer.Exit(1) from None
            new_defaults = replace(config.defaults, exec_timeout=timeout)
            config = replace(config, defaults=new_defaults)
        else:
            typer.echo(
                f"Error: Unknown defaults field '{field}'. Available: workspace, gpu, exec_timeout",
                err=True,
            )
            raise typer.Exit(1)
    elif section == "preferences":
        if field == "mode":
            if value not in ("explicit", "implicit"):
                typer.echo(
                    f"Error: mode must be 'explicit' or 'implicit', got '{value}'",
                    err=True,
                )
                raise typer.Exit(1)
            new_prefs = replace(config.preferences, mode=value)
            config = replace(config, preferences=new_prefs)
        else:
            typer.echo(f"Error: Unknown preferences field '{field}'. Available: mode", err=True)
            raise typer.Exit(1)
    else:
        typer.echo(
            f"Error: Unknown section '{section}'. Available: api, defaults, preferences",
            err=True,
        )
        raise typer.Exit(1)
    # Save and clear cache
    save_global_config(config)
    clear_config_cache()
    typer.echo(f"Set {key} = {value}")
@config_app.command("get")
def config_get(
    key: str = typer.Argument(..., help="Config key to get (e.g., api.environment)"),
) -> None:
    """Get a configuration value.
    Examples:
        wafer settings config get api.environment
        wafer settings config get defaults.workspace
    """
    from .global_config import load_global_config
    config = load_global_config()
    parts = key.split(".")
    if len(parts) != 2:
        typer.echo(f"Error: Invalid key format '{key}'. Use 'section.key' format.", err=True)
        raise typer.Exit(1)
    section, field = parts
    if section == "api":
        if field == "environment":
            typer.echo(config.environment)
        elif field == "url":
            typer.echo(config.api_url)
        elif field == "supabase_url":
            typer.echo(config.supabase_url)
        else:
            typer.echo(f"Error: Unknown api field '{field}'", err=True)
            raise typer.Exit(1)
    elif section == "defaults":
        if field == "workspace":
            typer.echo(config.defaults.workspace or "")
        elif field == "gpu":
            typer.echo(config.defaults.gpu)
        elif field == "exec_timeout":
            typer.echo(str(config.defaults.exec_timeout))
        else:
            typer.echo(f"Error: Unknown defaults field '{field}'", err=True)
            raise typer.Exit(1)
    elif section == "preferences":
        if field == "mode":
            typer.echo(config.preferences.mode)
        else:
            typer.echo(f"Error: Unknown preferences field '{field}'", err=True)
            raise typer.Exit(1)
    else:
        typer.echo(f"Error: Unknown section '{section}'", err=True)
        raise typer.Exit(1)


# =============================================================================
# Agent template discovery helpers
# =============================================================================
def _get_template_search_paths() -> list:
    """Get template search paths including wafer-cli bundled templates.
    Lightweight — only uses stdlib imports (pathlib, no heavy deps).
    """
    from wafer.wevin_cli import get_wafer_template_search_paths
    return get_wafer_template_search_paths()


def _format_template_variable(
    var_name: str, defaults: dict[str, str]
) -> str | None:
    """Format a single template variable for display.
    Returns None for internal/auto-computed variables (e.g., target_flag).
    """
    # Skip internal auto-computed variables
    # why: these are derived from other args at runtime, not user-facing
    internal_suffixes = ("_flag", "_upper")
    if any(var_name.endswith(suffix) for suffix in internal_suffixes):
        return None
    default = defaults.get(var_name, "")
    if default:
        return f"{var_name} (default: {default})"
    return f"{var_name}"


def _format_template_entry(
    name: str,
    config: object,  # TemplateConfig - using object to avoid import at module level
) -> list[str]:
    """Format a single template for the --list-templates display."""
    lines: list[str] = []
    description = getattr(config, "description", "") or ""
    lines.append(f"  {name:<24}{description}")
    # Deduplicate variables (same var can appear multiple times in system prompt)
    raw_variables = config.get_variables() if hasattr(config, "get_variables") else []
    variables = list(dict.fromkeys(raw_variables))  # preserves order, removes dupes
    defaults = getattr(config, "defaults", {})
    # Show user-facing variables
    formatted_vars = []
    for v in variables:
        fmt = _format_template_variable(v, defaults)
        if fmt is not None:
            formatted_vars.append(fmt)
    if formatted_vars:
        lines.append(f"    Args: {', '.join(formatted_vars)}")
    # Generate example usage
    # why: quote values containing spaces so copy-paste into shell works
    example_args = ""
    for v in variables:
        internal_suffixes = ("_flag", "_upper")
        if any(v.endswith(suffix) for suffix in internal_suffixes):
            continue
        default = defaults.get(v, "")
        if default:
            arg = f"{v}={default}"
            # Shell-quote if value contains spaces or shell metacharacters
            if " " in default or "'" in default or '"' in default:
                example_args += f' --args "{arg}"'
            else:
                example_args += f" --args {arg}"
        else:
            example_args += f" --args {v}=<value>"
    lines.append(f"    Example: wafer agent -t {name}{example_args} \"<prompt>\"")
    return lines


def _handle_list_templates() -> None:
    """Display all available templates and exit.
    Runs before auth or heavy imports — only needs the template loader.
    """
    from wafer_core.rollouts.templates.loader import load_all_templates
    search_paths = _get_template_search_paths()
    results = load_all_templates(search_paths)
    assert isinstance(results, list)
    typer.echo("Available agent templates:\n")
    for name, config, err in results:
        if err or config is None:
            typer.echo(f"  {name:<24}(failed to load: {err})")
            typer.echo()
            continue
        for line in _format_template_entry(name, config):
            typer.echo(line)
        typer.echo()
    typer.echo("Use --args KEY=VALUE to pass template arguments (can be repeated).")
    typer.echo("Example: wafer agent -t trace-analyze --args trace=./my-trace.ncu-rep \"What's slow?\"")


def _validate_template_name(template_name: str) -> None:
    """Validate that a template name exists. Exits with helpful error if not.
    Runs before auth or heavy imports — uses lightweight file listing only.
    why: previously, bad template names silently hung waiting for auth + imports
    """
    from wafer_core.rollouts.templates.loader import list_templates
    search_paths = _get_template_search_paths()
    available = list_templates(search_paths)
    assert isinstance(available, list)
    if template_name in available:
        return
    # Check if it's a file path that exists (templates can be loaded by path)
    from pathlib import Path
    if Path(template_name).expanduser().exists():
        return
    # Unknown template — fail fast with helpful error
    available_str = ", ".join(available) if available else "(none found)"
    typer.echo(
        f"Error: Unknown template '{template_name}'.\n"
        f"Available: {available_str}\n"
        f"Run 'wafer agent --list-templates' for details.",
        err=True,
    )
    raise typer.Exit(1)


@app.command()
def agent(  # noqa: PLR0913
    prompt: str | None = typer.Argument(
        None,
        help="Prompt to send (reads from stdin if not provided and not interactive)",
    ),
    interactive: bool = typer.Option(
        False,
        "--interactive",
        "-i",
        help="Launch full interactive TUI mode (default when no prompt given)",
    ),
    simple: bool = typer.Option(
        False,
        "--simple",
        help="Use simple stdout mode instead of TUI (for scripts/pipes)",
    ),
    single_turn: bool | None = typer.Option(
        None,
        "--single-turn",
        "-s",
        is_flag=True,
        flag_value=True,
        help="Single-turn mode: answer once and exit",
    ),
    resume: str | None = typer.Option(
        None,
        "--resume",
        "-r",
        help="Resume session by ID (or 'last' for most recent)",
    ),
    from_turn: int | None = typer.Option(
        None,
        "--from-turn",
        help="Branch from specific turn (default: resume from end)",
    ),
    list_sessions: bool = typer.Option(
        False,
        "--list-sessions",
        help="List recent sessions and exit",
    ),
    get_session: str | None = typer.Option(
        None,
        "--get-session",
        help="Get session by ID and print messages (use with --json)",
    ),
    tools: str | None = typer.Option(
        None,
        "--tools",
        help="Comma-separated list of tools to enable (default: all)",
    ),
    allow_spawn: bool = typer.Option(
        False,
        "--allow-spawn",
        help="Allow wafer tool to spawn sub-wevin agents (blocked by default)",
    ),
    max_tool_fails: int | None = typer.Option(
        None,
        "--max-tool-fails",
        help="Exit after N consecutive tool failures",
    ),
    max_turns: int | None = typer.Option(
        None,
        "--max-turns",
        help="Max conversation turns (default: 10)",
    ),
    model: str | None = typer.Option(
        None,
        "--model",
        "-m",
        help="Model override (default: claude-opus-4-5)",
    ),
    json_output: bool = typer.Option(
        False,
        "--json",
        "-j",
        help="Output in JSON format (stream-json style)",
    ),
    list_templates: bool = typer.Option(
        False,
        "--list-templates",
        help="List available templates with descriptions and args, then exit",
    ),
    template: str | None = typer.Option(
        None,
        "--template",
        "-t",
        help="Run with template (use --list-templates to see all available)",
    ),
    template_args: list[str] | None = typer.Option(
        None,
        "--args",
        help="Template variable (KEY=VALUE, can be repeated)",
    ),
    no_sandbox: bool = typer.Option(
        False,
        "--no-sandbox",
        help="Disable OS-level sandboxing (YOU accept liability for any damage caused by the agent)",
    ),
    no_proxy: bool = typer.Option(
        False,
        "--no-proxy",
        help="Skip wafer proxy, use ANTHROPIC_API_KEY directly",
    ),
    env: str | None = typer.Option(
        None,
        "--env",
        help="Environment name (coding, remote-target, runpod-sandbox, modal-sandbox). Uses --args for config.",
    ),
    workspace: str | None = typer.Option(
        None,
        "--workspace",
        help="Workspace ID (requires --env workspace)",
    ),
) -> None:
    """AI assistant for GPU kernel development.
    Helps with CUDA/Triton kernel optimization, GPU documentation queries,
    and performance analysis. Launches interactive TUI by default.

    Examples:
        wafer agent                                    # interactive TUI
        wafer agent "What is TMEM in CuTeDSL?"        # TUI with initial prompt
        wafer agent -s "What is TMEM?"                 # single-turn (answer and exit)
        wafer agent -t ask-docs "query"                 # use a template
        wafer agent --resume last "follow up"          # resume session
    """
    # Handle --list-templates early (no auth or heavy imports needed)
    if list_templates:
        _handle_list_templates()
        return
    # Validate template name early (fail fast before auth/imports)
    # why: bad template names previously hung silently waiting for auth
    if template:
        _validate_template_name(template)
    from wafer.wevin_cli import main as wevin_main
    # Read from stdin only if piped AND no prompt argument provided.
    # When a prompt is given via CLI args, don't touch stdin — the parent
    # process may hold the pipe open indefinitely (e.g., Cursor, Claude Code).
    actual_prompt = prompt
    stdin_input = None
    if not sys.stdin.isatty() and not actual_prompt:
        stdin_input = sys.stdin.read().strip()
        if stdin_input:
            actual_prompt = stdin_input

    # - Default to TUI when both stdin and stdout are TTYs
    # - Use simple mode when: --simple flag, piped input/output, or --json
    has_tty = sys.stdin.isatty() and sys.stdout.isatty()
    use_tui = has_tty and not simple and not json_output
    # If user explicitly asked for -i, try TUI but warn if no TTY
    if interactive:
        if not has_tty:
            print("Warning: --interactive requires a TTY, using simple mode", file=sys.stderr)
        else:
            use_tui = True
    parsed_template_args: dict[str, str] | None = None
    if template_args:
        parsed_template_args = {}
        for arg in template_args:
            if "=" not in arg:
                typer.echo(f"Invalid --args format: {arg!r}. Use KEY=VALUE", err=True)
                raise typer.Exit(1)
            key, value = arg.split("=", 1)
            # Expand ~ to home directory in values (common for file paths)
            parsed_template_args[key] = os.path.expanduser(value)
    # Warn user about sandbox disabled
    if no_sandbox:
        print(
            "Warning: Sandbox disabled. You accept liability for any damage caused by the agent.",
            file=sys.stderr,
        )
    # Validate --env / --workspace
    if env and env not in ("local", "workspace"):
        typer.echo(f"Unknown --env: {env!r}. Must be 'local' or 'workspace'.", err=True)
        raise typer.Exit(1)
    if workspace and env != "workspace":
        typer.echo("--workspace requires --env workspace", err=True)
        raise typer.Exit(1)
    if env == "workspace" and not workspace:
        typer.echo("--env workspace requires --workspace <id>", err=True)
        raise typer.Exit(1)
    wevin_main(
        prompt=actual_prompt,
        interactive=use_tui,
        single_turn=single_turn,
        model=model,
        resume=resume,
        from_turn=from_turn,
        list_sessions=list_sessions,
        get_session=get_session,
        tools=tools.split(",") if tools else None,
        allow_spawn=allow_spawn,
        max_tool_fails=max_tool_fails,
        max_turns=max_turns,
        json_output=json_output,
        template=template,
        template_args=parsed_template_args,
        no_sandbox=no_sandbox,
        no_proxy=no_proxy,
        env_name=env,
    )

@evaluate_app.callback(invoke_without_command=True)
def evaluate(ctx: typer.Context) -> None:
    """Run kernel evaluation on a remote GPU target.

    Checks correctness, performance (--benchmark), and defense (--defensive).

    Examples:
        wafer tool eval --impl kernel.py --reference ref.py --test-cases tests.json
        wafer tool eval --impl kernel.py --reference ref.py --test-cases tests.json --benchmark

    Subcommands: gpumode (recommended), kernelbench, make-template
    """
    # If a subcommand is being invoked, skip the main evaluation logic
    if ctx.invoked_subcommand is not None:
        return
    # Bare 'wafer tool eval' is no longer supported - must use subcommand
    typer.echo("Error: 'wafer tool eval' requires a subcommand.", err=True)
    typer.echo("", err=True)
    typer.echo("Available subcommands:", err=True)
    typer.echo(
        "  gpumode          Evaluate GPUMode format (custom_kernel/ref_kernel functions)", err=True
    )
    typer.echo("  kernelbench      Evaluate KernelBench format (ModelNew class)", err=True)
    typer.echo(
        "  aiter            Evaluate aiter operator optimizations on AMD MI300X", err=True
    )
    typer.echo("  vllm             Evaluate vLLM kernel optimizations", err=True)
    typer.echo(
        "  flashinfer-bench Evaluate kernels using FlashInfer-Bench", err=True
    )
    typer.echo(
        "  hipblaslt        Evaluate hipBLASLt GEMM kernel optimizations", err=True
    )
    typer.echo(
        "  make-template    Generate template files (GPUMode functional format)", err=True
    )
    typer.echo("", err=True)
    typer.echo("Examples:", err=True)
    typer.echo(
        "  wafer tool eval gpumode --impl kernel.py --reference ref.py --test-cases tests.json",
        err=True,
    )
    typer.echo(
        "  wafer tool eval kernelbench --impl impl.py --reference ref.py --benchmark", err=True
    )
    typer.echo("", err=True)
    typer.echo(
        "Run 'wafer tool eval <subcommand> --help' for options.",
        err=True,
    )
    raise typer.Exit(1)
TEMPLATE_KERNEL = '''\
import torch
import triton
import triton.language as tl
@triton.jit
def add_kernel(x_ptr, y_ptr, output_ptr, n_elements, BLOCK_SIZE: tl.constexpr):
    """Triton kernel for element-wise addition."""
    pid = tl.program_id(0)
    offsets = pid * BLOCK_SIZE + tl.arange(0, BLOCK_SIZE)
    mask = offsets < n_elements
    x = tl.load(x_ptr + offsets, mask=mask)
    y = tl.load(y_ptr + offsets, mask=mask)
    tl.store(output_ptr + offsets, x + y, mask=mask)
def custom_kernel(inputs: tuple[torch.Tensor, torch.Tensor]) -> torch.Tensor:
    """Your optimized kernel implementation.
    Args:
        inputs: Tuple from generate_input() - passed as single argument
    Returns:
        Output tensor matching ref_kernel output
    """
    x, y = inputs  # Unpack the input tuple
    output = torch.empty_like(x)
    n_elements = x.numel()
    grid = lambda meta: (triton.cdiv(n_elements, meta["BLOCK_SIZE"]),)
    add_kernel[grid](x, y, output, n_elements, BLOCK_SIZE=1024)
    return output
'''
TEMPLATE_REFERENCE = '''\
import torch
def ref_kernel(inputs: tuple[torch.Tensor, torch.Tensor]) -> torch.Tensor:
    """Ground truth implementation.
    Args:
        inputs: Tuple from generate_input() - passed as single argument
    Returns:
        Expected output tensor
    """
    x, y = inputs  # Unpack the input tuple
    return x + y
def generate_input(n: int, seed: int = 42, **kwargs) -> tuple[torch.Tensor, torch.Tensor]:
    """Generate test inputs based on test case parameters.
    Called with params from test_cases.json. The returned tuple is passed
    as a single argument to both ref_kernel and custom_kernel.
    Args:
        n: Size of tensors (from test case)
        seed: Random seed for reproducibility
        **kwargs: Any other params from test case
    Returns:
        Tuple of inputs (passed as single arg to kernels)
    """
    torch.manual_seed(seed)
    x = torch.randn(n, device="cuda", dtype=torch.float32)
    y = torch.randn(n, device="cuda", dtype=torch.float32)
    return (x, y)
'''
TEMPLATE_TEST_CASES = """\
[
  {"name": "small", "n": 1024, "seed": 42},
  {"name": "medium", "n": 65536, "seed": 42},
  {"name": "large", "n": 1048576, "seed": 42}
]
"""
@evaluate_app.command("make-template")
def evaluate_make_template(
    output_dir: Path = typer.Argument(
        Path("."),
        help="Directory to write template files (default: current directory)",
    ),
    force: bool = typer.Option(False, "--force", "-f", help="Overwrite existing files"),
) -> None:
    """Generate template files for GPUMode functional format evaluation.

    Creates three files: kernel.py, reference.py, test_cases.json.
    Run the generated templates with 'wafer tool eval gpumode'.
    For KernelBench format, use 'wafer tool eval kernelbench make-template' instead.

    Examples:
        wafer tool eval make-template                # Write to current directory
        wafer tool eval make-template ./my-kernel    # Write to specific directory
        wafer tool eval make-template --force        # Overwrite existing files
    """
    output_dir = output_dir.resolve()
    output_dir.mkdir(parents=True, exist_ok=True)
    files = [
        ("kernel.py", TEMPLATE_KERNEL),
        ("reference.py", TEMPLATE_REFERENCE),
        ("test_cases.json", TEMPLATE_TEST_CASES),
    ]
    for filename, content in files:
        path = output_dir / filename
        if path.exists() and not force:
            typer.echo(f"Skipping {path} (already exists, use --force to overwrite)")
            continue
        path.write_text(content)
        typer.echo(f"Created {path}")
    typer.echo("")
    typer.echo("Next steps:")
    typer.echo(f"  1. Edit {output_dir / 'kernel.py'} with your optimized implementation")
    typer.echo(f"  2. Edit {output_dir / 'reference.py'} with the ground truth + input generator")
    typer.echo(f"  3. Edit {output_dir / 'test_cases.json'} with your test parameters")
    typer.echo("  4. Run:")
    typer.echo(f"     wafer tool eval gpumode --impl {output_dir / 'kernel.py'} \\")
    typer.echo(f"         --reference {output_dir / 'reference.py'} \\")
    typer.echo(f"         --test-cases {output_dir / 'test_cases.json'} --benchmark")
def _get_kernelbench_root() -> Path | None:
    """Get KernelBench problems root, preferring downloaded location."""
    # First check downloaded location
    downloaded = get_problems_path("kernelbench")
    if downloaded is not None:
        kb_root = downloaded / "KernelBench"
        if kb_root.exists():
            return kb_root
        return downloaded
    # Fall back to legacy location (for development)
    legacy = Path(__file__).parent.parent.parent.parent / "research" / "KernelBench" / "KernelBench"
    if legacy.exists():
        return legacy
    return None
@kernelbench_app.command("download")
def kernelbench_download(
    force: bool = typer.Option(False, "--force", "-f", help="Re-download even if exists"),
) -> None:
    """Download KernelBench problems from GitHub.
    Downloads the problem set to ~/.cache/wafer/problems/kernelbench/
    Examples:
        wafer tool eval kernelbench download
        wafer tool eval kernelbench download --force  # Re-download
    """
    try:
        path = download_problems("kernelbench", force=force, verbose=True)
        typer.echo("")
        typer.echo(f"Problems available at: {path}")
        typer.echo("Run 'wafer tool eval kernelbench list-problems' to see available problems.")
    except Exception as e:
        typer.echo(f"Error downloading problems: {e}", err=True)
        raise typer.Exit(1) from None
@kernelbench_app.command("list-problems")
def kernelbench_list_problems() -> None:
    """List available KernelBench problems.
    Examples:
        wafer tool eval kernelbench list-problems
    """
    try:
        list_problems_fn("kernelbench", verbose=True)
    except ValueError as e:
        typer.echo(str(e), err=True)
        raise typer.Exit(1) from None
@kernelbench_app.callback(invoke_without_command=True)
def kernelbench_evaluate(  # noqa: PLR0913, PLR0915
    ctx: typer.Context,
    implementation: Path | None = typer.Option(
        None,
        "--implementation",
        "--impl",
        help="Path to implementation file (must define ModelNew)",
    ),
    reference: Path | None = typer.Option(
        None,
        "--reference",
        help="Path to reference file (must define Model, get_inputs, get_init_inputs)",
    ),
    target: str | None = typer.Option(
        None,
        "--target",
        "-t",
        help="GPU target name. See 'wafer target config list' for available targets.",
        autocompletion=complete_target_name,
    ),
    pool: str | None = typer.Option(
        None,
        "--pool",
        "-p",
        help="Target pool name. Acquires first available target from the pool. "
        "Define pools in ~/.wafer/config.toml under [pools.<name>].",
    ),
    benchmark: bool = typer.Option(False, "--benchmark", help="Run performance benchmarks"),
    profile: bool = typer.Option(False, "--profile", help="Enable profiling"),
    inputs: Path | None = typer.Option(
        None, "--inputs", help="Custom inputs file to override get_inputs()"
    ),
    seed: int = typer.Option(42, "--seed", help="Random seed for weight initialization"),
    defensive: bool = typer.Option(
        False, "--defensive", help="Enable defensive timing to detect evaluation hacking"
    ),
    backend: str | None = typer.Option(
        None,
        "--backend",
        help="Kernel backend for static validation (hip, cuda, triton, cute, tilelang, thunderkittens). "
        "When specified, validates that the implementation uses the correct backend primitives.",
    ),
    sync_artifacts: bool = typer.Option(
        True, "--sync-artifacts/--no-sync-artifacts", help="Download artifacts"
    ),
    gpu_id: int | None = typer.Option(None, "--gpu-id", help="Override GPU ID"),
    stages: str = typer.Option(
        "compile,correctness",
        "--stages",
        help="Comma-separated stages to run: compile, correctness, benchmark, defense. "
        "Use 'all' for compile,correctness,benchmark,defense. Default: compile,correctness",
    ),
    prepare_only: bool = typer.Option(
        False,
        "--prepare-only",
        help="Sync files and generate eval script but don't run. "
        "Prints the command to run manually (useful for wrapping with rocprof, etc.)",
    ),
    json_output: bool = typer.Option(
        False, "--json", "-j", help="Output as single JSON object (machine-readable)"
    ),
    jsonl_output: bool = typer.Option(
        False, "--jsonl", help="Output as streaming JSON Lines (one object per event)"
    ),
) -> None:
    """Run kernel evaluation in KernelBench format (ModelNew class).

    Expects ModelNew(nn.Module) in impl, Model + get_inputs() in reference.

    Examples:
        wafer tool eval kernelbench --impl my_kernel.py --reference problem.py
        wafer tool eval kernelbench --impl my_kernel.py --reference problem.py --benchmark
    """
    # If a subcommand is being invoked, skip the main evaluation logic
    if ctx.invoked_subcommand is not None:
        return
    # Validate required args when running evaluation (not subcommands)
    missing_args = []
    if implementation is None:
        missing_args.append("--impl")
    if reference is None:
        missing_args.append("--reference")
    if missing_args:
        typer.echo("Error: Missing required arguments", err=True)
        typer.echo(f"  Required: {', '.join(missing_args)}", err=True)
        typer.echo("", err=True)
        typer.echo(
            "Usage: wafer tool eval kernelbench --impl KERNEL.py --reference PROBLEM.py", err=True
        )
        typer.echo("", err=True)
        typer.echo("Run 'wafer tool eval kernelbench --help' for full options.", err=True)
        typer.echo(
            "Run 'wafer tool eval kernelbench make-template PROBLEM_ID DIR' to extract a problem.",
            err=True,
        )
        raise typer.Exit(1)
    # Validate --target and --pool are mutually exclusive
    if target and pool:
        typer.echo("Error: Cannot specify both --target and --pool", err=True)
        raise typer.Exit(1)
    from .evaluate import KernelBenchEvaluateArgs, run_evaluate_kernelbench
    from .output import OutputCollector, format_evaluate_result, get_output_format
    output_format = get_output_format(json_output, jsonl_output)
    collector = OutputCollector(format=output_format)
    # If pool specified, acquire a target from the pool
    resolved_target = target or ""
    pool_lock_context = None
    if pool:
        from .target_lock import acquire_from_pool
        from .targets import filter_pool_by_auth, get_pool
        try:
            pool_targets = get_pool(pool)
        except FileNotFoundError as e:
            collector.set_error("pool", "PoolNotFound", pool=pool, message=str(e))
            collector.finalize()
            raise typer.Exit(1) from None
        usable_targets, skipped = filter_pool_by_auth(pool_targets)
        if skipped:
            collector.emit("pool_auth_skip", targets=skipped)
        if not usable_targets:
            collector.set_error("pool", "NoUsableTargets", pool=pool)
            collector.finalize()
            raise typer.Exit(1) from None
        collector.emit("pool_acquire", pool=pool, count=len(usable_targets))
        pool_lock_context = acquire_from_pool(usable_targets)
        acquired_target = pool_lock_context.__enter__()
        if acquired_target is None:
            # Exit context manager before raising to avoid resource leak
            pool_lock_context.__exit__(None, None, None)
            collector.set_error("pool", "AllTargetsBusy", pool=pool, targets=usable_targets)
            collector.finalize()
            raise typer.Exit(1)
        collector.emit("pool_acquired", target=acquired_target)
        resolved_target = acquired_target
    collector.target = resolved_target
    # Expand 'all' stages shorthand
    resolved_stages = stages
    if stages == "all":
        resolved_stages = "compile,correctness,benchmark,defense"
    stage_set = set(resolved_stages.split(","))
    if benchmark and "benchmark" not in stage_set:
        stage_set.add("benchmark")
    if defensive and "defense" not in stage_set:
        stage_set.add("defense")
    resolved_stages = ",".join(
        sorted(
            stage_set,
            key=lambda s: (
                ["compile", "correctness", "benchmark", "defense"].index(s)
                if s in ["compile", "correctness", "benchmark", "defense"]
                else 99
            ),
        )
    )
    args = KernelBenchEvaluateArgs(
        implementation=implementation,
        reference=reference,
        target_name=resolved_target,
        benchmark=benchmark or "benchmark" in stage_set,
        profile=profile,
        inputs=inputs,
        seed=seed,
        defensive=defensive or "defense" in stage_set,
        backend=backend,
        sync_artifacts=sync_artifacts,
        gpu_id=gpu_id,
        stages=resolved_stages,
        prepare_only=prepare_only,
    )
    collector.emit("started", target=resolved_target)
    try:
        import trio_asyncio
        collector.emit("evaluation", status="running")
        result = trio_asyncio.run(run_evaluate_kernelbench, args)
    except KeyboardInterrupt:
        collector.set_error("evaluation", "Interrupted", message="Interrupted by user")
        collector.finalize()
        raise typer.Exit(130) from None
    except Exception as e:
        # Print to stdout so error flows through SSH to agent (stderr may be lost)
        import traceback
        print(f"Error: {e}")
        traceback.print_exc()
        collector.set_error("evaluation", "Exception", message=str(e))
        collector.finalize()
        raise typer.Exit(1) from None
    finally:
        # Release pool lock if we acquired one
        if pool_lock_context is not None:
            pool_lock_context.__exit__(None, None, None)
    eval_output = format_evaluate_result(result, target=resolved_target)
    collector._result = eval_output
    # Print results based on output format
    if result.success:
        collector.output_text_result(result)
        collector.finalize()
        # For prepare-only mode, success means we prepared successfully (don't check correctness)
        # For compile-only (all_correct is None), also treat as success
        if not prepare_only and result.all_correct is not None and not result.all_correct:
            raise typer.Exit(1)
    else:
        # Print to stdout so error flows through SSH to agent (stderr may be lost)
        print(f"Error: {result.error_message or 'Unknown error'}")
        collector.output_text_error(result.error_message or "Unknown error")
        collector.finalize()
        raise typer.Exit(1)
@kernelbench_app.command("make-template")
def kernelbench_make_template(
    problem: str = typer.Argument(
        ...,
        help="KernelBench problem ID (e.g., 'level1/1' or 'level1/1_Square_matrix_multiplication_')",
    ),
    output: Path = typer.Option(
        None, "--output", "-o", help="Output file path (default: ./<problem_name>.py)"
    ),
    force: bool = typer.Option(False, "--force", "-f", help="Overwrite existing file"),
) -> None:
    """Extract a KernelBench problem as a template file.
    The output file contains the reference Model class, get_inputs(), and get_init_inputs().
    You then create a separate implementation file with your ModelNew class.
    Examples:
        wafer tool eval kernelbench make-template level1/1
        wafer tool eval kernelbench make-template level1/1 --output ./matmul.py
        # Overwrite existing
        wafer tool eval kernelbench make-template level1/1 --force
    """
    kb_root = _get_kernelbench_root()
    if kb_root is None:
        typer.echo("Error: KernelBench problems not found.", err=True)
        typer.echo("Run 'wafer tool eval kernelbench download' to download problems.", err=True)
        raise typer.Exit(1)
    parts = problem.split("/")
    if len(parts) != 2:
        typer.echo(f"Error: Invalid problem ID '{problem}'. Expected format: level1/1", err=True)
        raise typer.Exit(1)
    level_str, problem_id_str = parts
    if not level_str.startswith("level"):
        level_str = f"level{level_str}"

    problem_dir = kb_root / level_str
    if not problem_dir.exists():
        typer.echo(f"Error: KernelBench level directory not found: {problem_dir}", err=True)
        typer.echo("Run 'wafer tool eval kernelbench download' to download problems.", err=True)
        raise typer.Exit(1)

    problem_files = list(problem_dir.glob(f"{problem_id_str}_*.py"))
    if not problem_files:
        # Try exact match if it's a full filename
        exact_match = problem_dir / f"{problem_id_str}.py"
        if exact_match.exists():
            problem_files = [exact_match]
        else:
            typer.echo(
                f"Error: No problem file found matching '{problem_id_str}' in {problem_dir}",
                err=True,
            )
            typer.echo("Available problems:", err=True)
            for f in sorted(problem_dir.glob("*.py"))[:10]:
                typer.echo(f"  {level_str}/{f.stem}", err=True)
            raise typer.Exit(1)
    if len(problem_files) > 1:
        typer.echo(f"Error: Multiple files match '{problem_id_str}':", err=True)
        for f in problem_files:
            typer.echo(f"  {f.name}", err=True)
        typer.echo("Please use a more specific ID.", err=True)
        raise typer.Exit(1)
    problem_file = problem_files[0]

    if output is None:
        output = Path.cwd() / problem_file.name
    output = output.resolve()
    if output.exists() and not force:
        typer.echo(f"Error: {output} already exists. Use --force to overwrite.", err=True)
        raise typer.Exit(1)
    # Copy the file
    content = problem_file.read_text()
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(content)
    typer.echo(f"Created {output}")
    typer.echo("")
    typer.echo("Next steps:")
    typer.echo(f"  1. Read {output} to understand the Model interface")
    typer.echo("  2. Create an implementation file with your ModelNew class:")
    typer.echo("")
    typer.echo("     import torch.nn as nn")
    typer.echo("")
    typer.echo("     class ModelNew(nn.Module):")
    typer.echo("         def __init__(self, ...):")
    typer.echo("             # Same signature as Model.__init__")
    typer.echo("             ...")
    typer.echo("")
    typer.echo("         def forward(self, ...):")
    typer.echo("             # Same signature as Model.forward")
    typer.echo("             # Your optimized implementation here")
    typer.echo("             ...")
    typer.echo("")
    typer.echo("  3. Run evaluation:")
    typer.echo(f"     wafer tool eval kernelbench --impl my_kernel.py --reference {output}")
@gpumode_app.command("download")
def gpumode_download(
    force: bool = typer.Option(False, "--force", "-f", help="Re-download even if exists"),
) -> None:
    """Download GPUMode reference kernels from GitHub.
    Downloads the problem set to ~/.cache/wafer/problems/gpumode/
    Examples:
        wafer tool eval gpumode download
        wafer tool eval gpumode download --force  # Re-download
    """
    try:
        path = download_problems("gpumode", force=force, verbose=True)
        typer.echo("")
        typer.echo(f"Problems available at: {path}")
        typer.echo("Run 'wafer tool eval gpumode list-problems' to see available problems.")
    except Exception as e:
        typer.echo(f"Error downloading problems: {e}", err=True)
        raise typer.Exit(1) from None
@gpumode_app.command("list-problems")
def gpumode_list_problems() -> None:
    """List available GPUMode problems.
    Examples:
        wafer tool eval gpumode list-problems
    """
    try:
        list_problems_fn("gpumode", verbose=True)
    except ValueError as e:
        typer.echo(str(e), err=True)
        raise typer.Exit(1) from None
@gpumode_app.command("make-template")
def gpumode_make_template(
    problem: str = typer.Option(
        ...,
        "--problem",
        "-p",
        help="Problem ID (e.g., 'pmpp/vectoradd_py' or 'amd/fp8-mm')",
    ),
    output: Path = typer.Option(
        None, "--output", "-o", help="Output directory (default: ./<problem_name>/)"
    ),
    force: bool = typer.Option(False, "--force", "-f", help="Overwrite existing files"),
) -> None:
    """Extract a GPUMode problem as template files.
    Creates a directory with reference.py, task.yml, and other problem files.
    You then create kernel.py with your custom_kernel implementation.
    Examples:
        wafer tool eval gpumode make-template --problem pmpp/vectoradd_py
        wafer tool eval gpumode make-template --problem pmpp/vectoradd_py --output ./my-kernel/
    """
    import shutil
    problem_path = get_problem_path("gpumode", problem)
    if problem_path is None:
        if get_problems_path("gpumode") is None:
            typer.echo("Error: GPUMode problems not downloaded.", err=True)
            typer.echo("Run 'wafer tool eval gpumode download' first.", err=True)
        else:
            typer.echo(f"Error: Problem '{problem}' not found.", err=True)
            typer.echo(
                "Run 'wafer tool eval gpumode list-problems' to see available problems.", err=True
            )
        raise typer.Exit(1)

    if output is None:
        output = Path.cwd() / problem.replace("/", "_")
    output = output.resolve()
    if output.exists() and not force:
        typer.echo(f"Error: {output} already exists. Use --force to overwrite.", err=True)
        raise typer.Exit(1)
    # Copy the problem directory
    if output.exists():
        shutil.rmtree(output)
    shutil.copytree(problem_path, output)
    typer.echo(f"Created {output}/")
    typer.echo("")
    typer.echo("Contents:")
    for f in sorted(output.iterdir()):
        if not f.name.startswith("."):
            typer.echo(f"  {f.name}")
    typer.echo("")
    typer.echo("Next steps:")
    typer.echo("  1. Read reference.py to understand the kernel interface")
    typer.echo("  2. Create kernel.py with your custom_kernel implementation:")
    typer.echo("")
    typer.echo("     def custom_kernel(data):")
    typer.echo("         # Your optimized implementation")
    typer.echo("         ...")
    typer.echo("")
    typer.echo("  3. Run evaluation:")
    typer.echo(
        f"     wafer tool eval gpumode --impl {output}/kernel.py --reference {output}/reference.py \\"
    )
    typer.echo(f"         --test-cases {output}/test_cases.json --target <target>")
@gpumode_app.callback(invoke_without_command=True)
def gpumode_evaluate(  # noqa: PLR0913, PLR0915
    ctx: typer.Context,
    implementation: Path | None = typer.Option(
        None, "--impl", "-i", help="Path to implementation kernel file"
    ),
    reference: Path | None = typer.Option(
        None, "--reference", help="Path to reference kernel file"
    ),
    test_cases: Path | None = typer.Option(
        None, "--test-cases", help="Path to test cases JSON file"
    ),
    target: str | None = typer.Option(
        None,
        "--target",
        "-t",
        help="GPU target name. See 'wafer target config list' for available targets.",
        autocompletion=complete_target_name,
    ),
    pool: str | None = typer.Option(
        None,
        "--pool",
        "-p",
        help="Target pool name. Acquires first available target from the pool. "
        "Define pools in ~/.wafer/config.toml under [pools.<name>].",
    ),
    benchmark: bool = typer.Option(False, "--benchmark", help="Run performance benchmarks"),
    profile: bool = typer.Option(False, "--profile", help="Enable profiling"),
    defensive: bool = typer.Option(
        False, "--defensive", help="Enable defensive timing to detect evaluation hacking"
    ),
    sync_artifacts: bool = typer.Option(
        True, "--sync-artifacts/--no-sync-artifacts", help="Download artifacts"
    ),
    gpu_id: int | None = typer.Option(None, "--gpu-id", help="Override GPU ID"),
    json_output: bool = typer.Option(
        False, "--json", "-j", help="Output as single JSON object (machine-readable)"
    ),
    jsonl_output: bool = typer.Option(
        False, "--jsonl", help="Output as streaming JSON Lines (one object per event)"
    ),
) -> None:
    """Run kernel evaluation in GPUMode format (functional). Recommended.

    Expects custom_kernel(inputs) in impl, ref_kernel(inputs) + generate_input() in reference.

    Examples:
        wafer tool eval gpumode --impl kernel.py --reference ref.py --test-cases tests.json
        wafer tool eval gpumode --impl kernel.py --reference ref.py --test-cases tests.json --benchmark
    """
    # If a subcommand is being invoked, skip the main evaluation logic
    if ctx.invoked_subcommand is not None:
        return
    # Validate required args when running evaluation (not subcommands)
    missing_args = []
    if implementation is None:
        missing_args.append("--impl/-i")
    if reference is None:
        missing_args.append("--reference")
    if test_cases is None:
        missing_args.append("--test-cases")
    if missing_args:
        typer.echo("Error: Missing required arguments", err=True)
        typer.echo(f"  Required: {', '.join(missing_args)}", err=True)
        typer.echo("", err=True)
        typer.echo(
            "Usage: wafer tool eval gpumode --impl KERNEL.py --reference REF.py --test-cases TESTS.json",
            err=True,
        )
        typer.echo("", err=True)
        typer.echo("Run 'wafer tool eval gpumode --help' for full options.", err=True)
        typer.echo("Run 'wafer tool eval gpumode download' to download problem sets.", err=True)
        raise typer.Exit(1)
    # Validate --target and --pool are mutually exclusive
    if target and pool:
        typer.echo("Error: Cannot specify both --target and --pool", err=True)
        raise typer.Exit(1)
    from .evaluate import EvaluateArgs, run_evaluate
    from .output import OutputCollector, format_evaluate_result, get_output_format
    output_format = get_output_format(json_output, jsonl_output)
    collector = OutputCollector(format=output_format, target=target)
    # If pool specified, acquire a target from the pool
    resolved_target = target or ""
    pool_lock_context = None
    if pool:
        from .target_lock import acquire_from_pool
        from .targets import filter_pool_by_auth, get_pool
        try:
            pool_targets = get_pool(pool)
        except FileNotFoundError as e:
            typer.echo(f"Error: {e}", err=True)
            raise typer.Exit(1) from None
        usable_targets, skipped = filter_pool_by_auth(pool_targets)
        if skipped:
            typer.echo(f"Skipping targets without auth: {', '.join(skipped)}", err=True)
        if not usable_targets:
            typer.echo(f"Error: No usable targets in pool '{pool}'", err=True)
            typer.echo("  All targets require authentication that is not configured.", err=True)
            typer.echo("  Run 'wafer settings auth status' to see which providers need setup.", err=True)
            raise typer.Exit(1) from None
        typer.echo(f"Acquiring target from pool '{pool}' ({len(usable_targets)} targets)...")
        pool_lock_context = acquire_from_pool(usable_targets)
        acquired_target = pool_lock_context.__enter__()
        if acquired_target is None:
            # Exit context manager before raising to avoid resource leak
            pool_lock_context.__exit__(None, None, None)
            typer.echo(f"Error: All targets in pool '{pool}' are busy", err=True)
            typer.echo(f"  Targets: {', '.join(usable_targets)}", err=True)
            raise typer.Exit(1)
        typer.echo(f"Acquired target: {acquired_target}")
        resolved_target = acquired_target
    args = EvaluateArgs(
        implementation=implementation,
        reference=reference,
        test_cases=test_cases,
        target_name=resolved_target,
        benchmark=benchmark,
        profile=profile,
        defensive=defensive,
        sync_artifacts=sync_artifacts,
        gpu_id=gpu_id,
    )
    collector.emit("started", target=resolved_target)
    try:
        import trio_asyncio
        collector.emit("evaluation", status="running")
        result = trio_asyncio.run(run_evaluate, args)
    except KeyboardInterrupt:
        collector.set_error("evaluation", "Interrupted", message="Interrupted by user")
        collector.finalize()
        raise typer.Exit(130) from None
    except Exception as e:
        error_msg = str(e)
        if hasattr(e, "exceptions") and e.exceptions:
            error_msg = "; ".join(f"{type(exc).__name__}: {exc}" for exc in e.exceptions)
        # Print to stdout in text mode so error flows through SSH to agent (stderr may be lost)
        if output_format.value == "text":
            print(f"Error: {error_msg}")
        collector.set_error("evaluation", "Exception", message=error_msg)
        collector.finalize()
        raise typer.Exit(1) from None
    finally:
        # Release pool lock if we acquired one
        if pool_lock_context is not None:
            pool_lock_context.__exit__(None, None, None)
    eval_output = format_evaluate_result(result, target=resolved_target)
    collector._result = eval_output
    # Print results based on output format
    if result.success:
        collector.output_text_result(result)
        # Artifact path is gpumode-specific; not in the shared output_text_result
        if result.artifact_path and output_format.value == "text":
            typer.echo(f"Artifacts: {result.artifact_path}")
        collector.finalize()
        if not result.all_correct:
            raise typer.Exit(1)
    else:
        collector.output_text_error(result.error_message or "Unknown error")
        collector.finalize()
        raise typer.Exit(1)
@aiter_app.callback(invoke_without_command=True)
def aiter_evaluate(
    ctx: typer.Context,
    aiter_dir: Path = typer.Option(
        ...,
        "--aiter-dir",
        help="Path to local aiter directory with modifications",
    ),
    cmd: str = typer.Option(
        ...,
        "--cmd",
        help="Command to run in aiter directory (e.g., 'python op_tests/test_gemm_a16w16.py --mnk 128,32,8192')",
    ),
    target: str | None = typer.Option(
        None,
        "--target",
        "-t",
        help="GPU target name. See 'wafer target config list' for available targets.",
        autocompletion=complete_target_name,
    ),
    pool: str | None = typer.Option(
        None,
        "--pool",
        "-p",
        help="Target pool name. Acquires first available target from the pool.",
    ),
    timeout: int = typer.Option(
        600, "--timeout", help="Timeout in seconds (default 600 for JIT compilation)"
    ),
    gpu_id: int | None = typer.Option(None, "--gpu-id", help="Override GPU ID"),
    json_output: bool = typer.Option(False, "--json", "-j", help="Output results as JSON"),
) -> None:
    """Evaluate aiter operator optimizations on AMD MI300X.
    Syncs the local aiter directory to the remote target, installs aiter,
    runs the specified command, and parses the output for test results.
    Examples:
        # Quick test with single shape
        wafer tool eval aiter --aiter-dir . --cmd "python op_tests/test_gemm_a16w16.py --mnk 128,32,8192" --target mi300x
        # Full test suite
        wafer tool eval aiter --aiter-dir . --cmd "python op_tests/test_gemm_a16w16.py" --pool mi300x-pool
        # Run with specific dtypes
        wafer tool eval aiter --aiter-dir . --cmd "python op_tests/test_activation.py -d bf16" --target mi300x
    """
    import trio_asyncio
    from .evaluate import AiterEvaluateArgs, run_evaluate_aiter

    if ctx.invoked_subcommand is not None:
        return
    # Validate aiter directory
    if not aiter_dir.exists():
        typer.echo(f"Error: aiter directory not found: {aiter_dir}", err=True)
        raise typer.Exit(1)
    # Resolve target
    if target is None and pool is None:
        typer.echo("Error: Either --target or --pool is required", err=True)
        raise typer.Exit(1)
    # Resolve pool if specified
    lock_ctx = None
    if pool:
        from .target_lock import acquire_from_pool
        from .targets import filter_pool_by_auth, get_pool
        try:
            pool_targets = get_pool(pool)
        except FileNotFoundError:
            typer.echo(f"Error: Pool '{pool}' not found", err=True)
            raise typer.Exit(1) from None
        usable_targets, _ = filter_pool_by_auth(pool_targets)
        if not usable_targets:
            typer.echo(f"Error: No usable targets in pool '{pool}'", err=True)
            raise typer.Exit(1)
        lock_ctx = acquire_from_pool(usable_targets)
        target_name = lock_ctx.__enter__()
        if target_name is None:
            lock_ctx.__exit__(None, None, None)
            typer.echo(f"Error: All targets in pool '{pool}' are busy", err=True)
            raise typer.Exit(1)
    else:
        target_name = target
    try:
        args = AiterEvaluateArgs(
            aiter_dir=aiter_dir.resolve(),
            target_name=target_name,
            cmd=cmd,
            timeout=timeout,
            gpu_id=gpu_id,
        )
        # Run evaluation (use trio_asyncio for asyncssh compatibility)
        result = trio_asyncio.run(run_evaluate_aiter, args, target_name)
        # Build output
        output = {
            "correct": result.all_correct,
            "passed_tests": result.passed_tests,
            "total_tests": result.total_tests,
            "correctness_score": result.correctness_score,
        }
        if result.error_message:
            output["error"] = result.error_message
        if json_output:
            from .output import json_response
            eval_status = "ok" if result.all_correct else "error"
            print(json_response(data=output, status=eval_status))
        else:
            from .auth import CHECK, CROSS
            if result.all_correct:
                typer.echo(f"{CHECK} All tests passed ({result.passed_tests}/{result.total_tests})")
            else:
                typer.echo(f"{CROSS} Tests failed ({result.passed_tests}/{result.total_tests})")
                typer.echo(f"  Correctness: {result.correctness_score:.1%}")
            if result.error_message:
                typer.echo(f"  Error: {result.error_message}")
        if not result.success:
            raise typer.Exit(1)
    finally:
        if lock_ctx:
            lock_ctx.__exit__(None, None, None)
@vllm_app.callback(invoke_without_command=True)
def vllm_evaluate(  # noqa: PLR0913
    ctx: typer.Context,
    vllm_dir: Path | None = typer.Option(
        None,
        "--vllm-dir",
        "-d",
        help="Path to vLLM repository (with your kernel modifications)",
    ),
    op_name: str | None = typer.Option(
        None,
        "--op",
        "-o",
        help="Target op to evaluate (e.g., 'fused_moe', 'paged_attention')",
    ),
    test_cmd: str | None = typer.Option(
        None,
        "--test-cmd",
        help="Pytest command for correctness test (e.g., 'pytest tests/kernels/moe/test_moe.py -v')",
    ),
    bench_cmd: str | None = typer.Option(
        None,
        "--bench-cmd",
        help="Benchmark command (e.g., 'python benchmarks/benchmark_serving.py ...')",
    ),
    target: str | None = typer.Option(
        None,
        "--target",
        "-t",
        help="GPU target name. See 'wafer target config list' for available targets.",
        autocompletion=complete_target_name,
    ),
    pool: str | None = typer.Option(
        None,
        "--pool",
        "-p",
        help="Target pool name. Acquires first available target from the pool.",
    ),
    gpu_id: int | None = typer.Option(None, "--gpu-id", help="Override GPU ID"),
    json_output: bool = typer.Option(
        False,
        "--json",
        "-j",
        help="Output results as JSON (for programmatic consumption)",
    ),
) -> None:
    """Evaluate vLLM kernel optimizations.

    Runs correctness tests (pytest) and performance benchmarks against a modified vLLM repo.

    Examples:
        wafer tool eval vllm --vllm-dir ./vllm --op fused_moe --test-cmd "pytest ..." --bench-cmd "python ..." -t my-gpu
    """
    import json as json_module
    # If a subcommand is being invoked, skip the main evaluation logic
    if ctx.invoked_subcommand is not None:
        return
    # Validate required args
    missing_args = []
    if vllm_dir is None:
        missing_args.append("--vllm-dir/-d")
    if op_name is None:
        missing_args.append("--op/-o")
    if test_cmd is None:
        missing_args.append("--test-cmd")
    if bench_cmd is None:
        missing_args.append("--bench-cmd")
    if missing_args:
        typer.echo("Error: Missing required arguments", err=True)
        typer.echo(f"  Required: {', '.join(missing_args)}", err=True)
        typer.echo("", err=True)
        typer.echo(
            "Usage: wafer tool eval vllm --vllm-dir PATH --op OP_NAME --test-cmd CMD --bench-cmd CMD",
            err=True,
        )
        raise typer.Exit(1)
    # Validate --target and --pool are mutually exclusive
    if target and pool:
        typer.echo("Error: Cannot specify both --target and --pool", err=True)
        raise typer.Exit(1)
    from .evaluate import VllmEvaluateArgs, run_evaluate_vllm
    # If pool specified, acquire a target from the pool
    resolved_target = target or ""
    pool_lock_context = None
    if pool:
        from .target_lock import acquire_from_pool
        from .targets import filter_pool_by_auth, get_pool
        try:
            pool_targets = get_pool(pool)
        except FileNotFoundError as e:
            typer.echo(f"Error: {e}", err=True)
            raise typer.Exit(1) from None
        usable_targets, skipped = filter_pool_by_auth(pool_targets)
        if skipped:
            typer.echo(f"Skipping targets without auth: {', '.join(skipped)}", err=True)
        if not usable_targets:
            typer.echo(f"Error: No usable targets in pool '{pool}'", err=True)
            raise typer.Exit(1) from None
        typer.echo(f"Acquiring target from pool '{pool}' ({len(usable_targets)} targets)...")
        pool_lock_context = acquire_from_pool(usable_targets)
        acquired_target = pool_lock_context.__enter__()
        if acquired_target is None:
            pool_lock_context.__exit__(None, None, None)
            typer.echo(f"Error: All targets in pool '{pool}' are busy", err=True)
            raise typer.Exit(1)
        typer.echo(f"Acquired target: {acquired_target}")
        resolved_target = acquired_target
    args = VllmEvaluateArgs(
        vllm_dir=vllm_dir,
        op_name=op_name,
        test_cmd=test_cmd,
        bench_cmd=bench_cmd,
        target_name=resolved_target,
        gpu_id=gpu_id,
    )
    try:
        import trio_asyncio
        result = trio_asyncio.run(run_evaluate_vllm, args)
    except KeyboardInterrupt:
        typer.echo("\nInterrupted by user", err=True)
        raise typer.Exit(130) from None
    except Exception as e:
        if hasattr(e, "exceptions") and e.exceptions:
            for exc in e.exceptions:
                typer.echo(f"Error: {type(exc).__name__}: {exc}", err=True)
        else:
            typer.echo(f"Error: {e}", err=True)
        raise typer.Exit(1) from None
    finally:
        # Release pool lock if we acquired one
        if pool_lock_context is not None:
            pool_lock_context.__exit__(None, None, None)
    # Output results
    if json_output:
        from .output import json_response
        output = {
            "success": result.success,
            "correctness_passed": result.correctness_passed,
            "metrics": result.metrics,
            "baseline_metrics": result.baseline_metrics,
            "error_message": result.error_message,
        }
        eval_status = "ok" if (result.success and result.correctness_passed) else "error"
        typer.echo(json_response(data=output, status=eval_status))
    else:
        _print_vllm_result(result)
    if not result.success or not result.correctness_passed:
        raise typer.Exit(1)
def _print_vllm_result(result: "VllmEvaluateResult") -> None:
    """Print vLLM evaluation result in human-readable format."""
    from .evaluate import VllmEvaluateResult
    typer.echo("")
    typer.echo("=" * 60)
    if not result.success:
        typer.echo(f"Error: {result.error_message}")
        typer.echo("=" * 60)
        return
    correctness_status = "PASS" if result.correctness_passed else "FAIL"
    typer.echo(f"Correctness: {correctness_status}")
    if result.metrics:
        typer.echo("Metrics:")
        for metric_name, value in result.metrics.items():
            typer.echo(f"  {metric_name}: {value:.2f}")
    if result.baseline_metrics and result.metrics:
        typer.echo("Speedup vs baseline:")
        for metric_name in result.metrics:
            if metric_name not in result.baseline_metrics:
                continue
            if result.baseline_metrics[metric_name] <= 0:
                continue
            baseline = result.baseline_metrics[metric_name]
            current = result.metrics[metric_name]
            speedup = current / baseline if metric_name == "throughput" else baseline / current
            typer.echo(f"  {metric_name}: {speedup:.2f}x")
    typer.echo("=" * 60)
@flashinfer_bench_app.callback(invoke_without_command=True)
def flashinfer_bench_evaluate(  # noqa: PLR0913
    ctx: typer.Context,
    definition: str | None = typer.Option(
        None,
        "--definition",
        "-d",
        help="Definition name to evaluate (e.g., 'gqa_paged_decode_h32_kv8_d128_ps1')",
    ),
    trace_dir: Path | None = typer.Option(
        None,
        "--trace-dir",
        help="Path to flashinfer-trace dataset (defaults to HuggingFace clone)",
    ),
    solution_dir: Path | None = typer.Option(
        None,
        "--solution-dir",
        "-s",
        help="Path to your solution directory",
    ),
    target: str | None = typer.Option(
        None,
        "--target",
        "-t",
        help="GPU target name. See 'wafer target config list' for available targets.",
        autocompletion=complete_target_name,
    ),
    pool: str | None = typer.Option(
        None,
        "--pool",
        "-p",
        help="Target pool name. Acquires first available target from the pool.",
    ),
    warmup_runs: int = typer.Option(10, "--warmup-runs", help="Number of warmup iterations"),
    iterations: int = typer.Option(50, "--iterations", help="Number of benchmark iterations"),
    rtol: float = typer.Option(1e-2, "--rtol", help="Relative tolerance for correctness"),
    atol: float = typer.Option(1e-2, "--atol", help="Absolute tolerance for correctness"),
    json_output: bool = typer.Option(
        False,
        "--json",
        "-j",
        help="Output results as JSON (for programmatic consumption)",
    ),
    list_definitions: bool = typer.Option(
        False,
        "--list",
        "-l",
        help="List available definitions from the trace dataset",
    ),
) -> None:
    """Evaluate kernels using FlashInfer-Bench (official benchmark suite).

    Examples:
        wafer tool eval flashinfer-bench --list
        wafer tool eval flashinfer-bench -d gqa_paged_decode_h32_kv8_d128_ps1 -s ./my_solution -t my-gpu
    """
    import json as json_module
    # If a subcommand is being invoked, skip the main evaluation logic
    if ctx.invoked_subcommand is not None:
        return
    if list_definitions:
        _list_flashinfer_bench_definitions(trace_dir)
        return
    # Validate required args for actual evaluation
    missing_args = []
    if definition is None:
        missing_args.append("--definition/-d")
    if solution_dir is None:
        missing_args.append("--solution-dir/-s")
    if target is None and pool is None:
        missing_args.append("--target/-t or --pool/-p")
    if missing_args:
        typer.echo("Error: Missing required arguments", err=True)
        typer.echo(f"  Required: {', '.join(missing_args)}", err=True)
        typer.echo("", err=True)
        typer.echo(
            "Usage: wafer tool eval flashinfer-bench --definition DEF --solution-dir PATH --target TARGET",
            err=True,
        )
        typer.echo("", err=True)
        typer.echo("Use --list to see available definitions", err=True)
        raise typer.Exit(1)
    # Resolve target from pool if needed
    resolved_target = target
    pool_lock_context = None
    if pool is not None:
        from .target_lock import acquire_from_pool
        from .targets import filter_pool_by_auth, get_pool
        try:
            pool_targets = get_pool(pool)
        except FileNotFoundError as e:
            typer.echo(f"Error: {e}", err=True)
            raise typer.Exit(1) from None
        usable_targets, skipped = filter_pool_by_auth(pool_targets)
        if skipped:
            typer.echo(f"Skipping targets without auth: {', '.join(skipped)}", err=True)
        if not usable_targets:
            typer.echo(f"Error: No usable targets in pool '{pool}'", err=True)
            raise typer.Exit(1) from None
        typer.echo(f"Acquiring target from pool '{pool}' ({len(usable_targets)} targets)...")
        pool_lock_context = acquire_from_pool(usable_targets)
        acquired_target = pool_lock_context.__enter__()
        if acquired_target is None:
            pool_lock_context.__exit__(None, None, None)
            typer.echo(f"Error: All targets in pool '{pool}' are busy", err=True)
            raise typer.Exit(1)
        typer.echo(f"Acquired target: {acquired_target}")
        resolved_target = acquired_target
    try:
        import trio_asyncio
        from .evaluate import FlashInferBenchEvaluateArgs, run_evaluate_flashinfer_bench
        args = FlashInferBenchEvaluateArgs(
            definition=definition,
            solution_dir=solution_dir,
            target_name=resolved_target,
            trace_dir=trace_dir,
            warmup_runs=warmup_runs,
            iterations=iterations,
            rtol=rtol,
            atol=atol,
        )
        result = trio_asyncio.run(run_evaluate_flashinfer_bench, args)
        result_dict = {
            "passed": result.passed,
            "definition": result.definition,
            "solution": result.solution,
            "speedup": result.speedup,
            "latency_ms": result.latency_ms,
            "reference_latency_ms": result.reference_latency_ms,
            "max_abs_error": result.max_abs_error,
            "max_rel_error": result.max_rel_error,
            "error": result.error_message,
        }
    except KeyboardInterrupt:
        typer.echo("\nInterrupted by user", err=True)
        raise typer.Exit(130) from None
    except Exception as e:
        typer.echo(f"Error: {e}", err=True)
        import traceback
        traceback.print_exc()
        raise typer.Exit(1) from None
    finally:
        if pool_lock_context is not None:
            pool_lock_context.__exit__(None, None, None)
    # Output results
    if json_output:
        from .output import json_response
        eval_status = "ok" if result_dict.get("passed", False) else "error"
        typer.echo(json_response(data=result_dict, status=eval_status))
    else:
        _print_flashinfer_bench_result(result_dict)
    if not result_dict.get("passed", False):
        raise typer.Exit(1)
def _list_flashinfer_bench_definitions(trace_dir: Path | None) -> None:
    """List available definitions from flashinfer-trace dataset."""
    # Default trace directory
    if trace_dir is None:
        trace_dir = Path.home() / ".cache" / "flashinfer_bench" / "dataset"
    if not trace_dir.exists():
        typer.echo("FlashInfer-Trace dataset not found locally.", err=True)
        typer.echo("", err=True)
        typer.echo("Clone it with:", err=True)
        typer.echo(
            "  git clone https://huggingface.co/datasets/flashinfer-ai/flashinfer-trace ~/.cache/flashinfer_bench/dataset",
            err=True,
        )
        raise typer.Exit(1)
    definitions_dir = trace_dir / "definitions"
    if not definitions_dir.exists():
        typer.echo(f"No definitions found in {trace_dir}", err=True)
        raise typer.Exit(1)
    typer.echo("Available FlashInfer-Bench definitions:")
    typer.echo("")
    for op_dir in sorted(definitions_dir.iterdir()):
        if not op_dir.is_dir():
            continue
        op_type = op_dir.name
        definitions = sorted(op_dir.glob("*.json"))
        if definitions:
            typer.echo(f"  {op_type}:")
            for def_file in definitions:
                def_name = def_file.stem
                typer.echo(f"    - {def_name}")
            typer.echo("")
def _print_flashinfer_bench_result(result: dict) -> None:
    """Print flashinfer-bench evaluation result in human-readable format."""
    typer.echo("")
    typer.echo("=" * 60)
    typer.echo(f"Definition: {result.get('definition', 'unknown')}")
    typer.echo(f"Solution: {result.get('solution', 'unknown')}")
    typer.echo("")
    if result.get("error"):
        typer.echo(f"Error: {result['error']}")
        typer.echo("=" * 60)
        return
    passed = result.get("passed", False)
    typer.echo(f"Status: {'PASSED' if passed else 'FAILED'}")
    if result.get("speedup") is not None:
        typer.echo(f"Speedup: {result['speedup']:.2f}x")
    if result.get("latency_ms") is not None:
        typer.echo(f"Latency: {result['latency_ms']:.3f} ms")
    if result.get("max_abs_error") is not None:
        typer.echo(f"Max Abs Error: {result['max_abs_error']:.2e}")
    if result.get("max_rel_error") is not None:
        typer.echo(f"Max Rel Error: {result['max_rel_error']:.2e}")
    typer.echo("=" * 60)
def _parse_hipblaslt_shape(shape: str) -> tuple[int, int, int] | None:
    """Parse M,K,N shape string. Returns (m, k, n) or None if invalid."""
    try:
        parts = shape.split(",")
        if len(parts) != 3:
            return None
        m, k, n = int(parts[0]), int(parts[1]), int(parts[2])
        if m <= 0 or k <= 0 or n <= 0:
            return None
        return (m, k, n)
    except ValueError:
        return None
def _format_hipblaslt_result(
    result: "HipblasltEvaluateResult", m: int, k: int, n: int, dtype: str, json_output: bool
) -> None:
    """Format and print hipblaslt evaluation results."""
    from .evaluate import HipblasltEvaluateResult
    assert isinstance(result, HipblasltEvaluateResult), "result must be HipblasltEvaluateResult"
    assert m > 0 and k > 0 and n > 0, "dimensions must be positive"
    if json_output:
        from .output import json_response
        output = {
            "success": result.success,
            "correct": result.correct,
            "tflops": result.tflops,
            "time_ms": result.time_ms,
            "shape": list(result.shape) if result.shape else [m, k, n],
            "dtype": dtype,
        }
        if result.error_message:
            output["error"] = result.error_message
        eval_status = "ok" if result.success else "error"
        print(json_response(data=output, status=eval_status))
    else:
        typer.echo("=" * 60)
        typer.echo("hipBLASLt Evaluation Results")
        typer.echo("=" * 60)
        typer.echo(f"Shape: M={m}, K={k}, N={n}")
        typer.echo(f"Dtype: {dtype}")
        typer.echo(f"Correct: {result.correct}")
        if result.tflops is not None:
            typer.echo(f"TFLOPS: {result.tflops:.2f}")
        if result.time_ms is not None:
            typer.echo(f"Time: {result.time_ms:.3f} ms")
        if result.error_message:
            typer.echo(f"Error: {result.error_message}")
        typer.echo("=" * 60)
@hipblaslt_app.callback(invoke_without_command=True)
def hipblaslt_evaluate(
    ctx: typer.Context,
    hipblaslt_dir: Path = typer.Option(
        ...,
        "--hipblaslt-dir",
        help="Path to local hipBLASLt directory with modifications",
    ),
    shape: str = typer.Option(
        ...,
        "--shape",
        "-s",
        help="GEMM shape as M,K,N (e.g., '256,4096,11008')",
    ),
    dtype: str = typer.Option(
        "bf16",
        "--dtype",
        "-d",
        help="Data type: bf16, fp16",
    ),
    workspace: str | None = typer.Option(
        None,
        "--workspace",
        "-w",
        help="Workspace name or ID. Uses default workspace if not specified.",
    ),
    timeout: int = typer.Option(
        1200, "--timeout", help="Timeout in seconds (default 1200 for build + benchmark)"
    ),
    json_output: bool = typer.Option(False, "--json", "-j", help="Output as JSON"),
) -> None:
    """Evaluate hipBLASLt GEMM kernel optimizations on AMD MI300X.
    Uses wafer target workspace for GPU command queueing to prevent conflicts.
    Examples:
        wafer tool eval hipblaslt --hipblaslt-dir . --shape 256,4096,11008
        wafer tool eval hipblaslt --hipblaslt-dir . --shape 256,4096,11008 --dtype fp16 --workspace mi300x
    """
    from .evaluate import HIPBLASLT_VALID_DTYPES, HipblasltEvaluateArgs, run_evaluate_hipblaslt_workspace
    from .workspaces import resolve_workspace
    if ctx.invoked_subcommand is not None:
        return
    # Validate inputs
    if dtype not in HIPBLASLT_VALID_DTYPES:
        typer.echo(f"Error: Invalid dtype '{dtype}'. Must be one of: {', '.join(sorted(HIPBLASLT_VALID_DTYPES))}", err=True)
        raise typer.Exit(1)
    if not hipblaslt_dir.exists():
        typer.echo(f"Error: hipBLASLt directory not found: {hipblaslt_dir}", err=True)
        raise typer.Exit(1)
    parsed_shape = _parse_hipblaslt_shape(shape)
    if parsed_shape is None:
        typer.echo(f"Error: Invalid shape format '{shape}'. Use M,K,N (e.g., '256,4096,11008')", err=True)
        raise typer.Exit(1)
    m, k, n = parsed_shape
    try:
        workspace_id = resolve_workspace(workspace)
    except RuntimeError as e:
        typer.echo(f"Error: {e}", err=True)
        raise typer.Exit(1) from None
    assert workspace_id, "workspace_id must be non-empty after resolution"
    args = HipblasltEvaluateArgs(
        hipblaslt_dir=hipblaslt_dir.resolve(),
        workspace_id=workspace_id,
        shape=(m, k, n),
        dtype=dtype,
        timeout=timeout,
    )
    result = run_evaluate_hipblaslt_workspace(args)
    _format_hipblaslt_result(result, m, k, n, dtype, json_output)
    if not result.success:
        raise typer.Exit(1)
@settings_app.command("login")
def login(
    token: str | None = typer.Option(
        None, "--token", "-t", help="Access token (skip browser OAuth)"
    ),
    port: int | None = typer.Option(
        None,
        "--port",
        "-p",
        help="Port for OAuth callback server (local only, ignored for SSH)",
    ),
    no_device_code: bool = typer.Option(
        False,
        "--no-device-code",
        help="Force browser OAuth even on SSH (requires port forwarding)",
    ),
) -> None:
    """Authenticate CLI with wafer-api via GitHub OAuth.

    Auto-detects SSH vs local: uses device code flow on SSH (no port forwarding),
    opens browser on local.

    Examples:
        wafer settings login                    # auto-detect (device code on SSH, browser on local)
        wafer settings login --token xyz        # manual token (no browser)
        wafer settings login --no-device-code   # force browser flow
    """
    import httpx
    from .auth import browser_login, device_code_login, save_credentials, verify_token
    from .global_config import get_api_url, get_supabase_url, load_global_config
    # Show which environment we're logging into
    config = load_global_config()
    typer.echo(f"Environment: {config.environment}")
    typer.echo(f"API: {get_api_url()}")
    typer.echo(f"Auth: {get_supabase_url()}")
    typer.echo("")
    # Auto-detect SSH
    is_ssh = bool(os.environ.get("SSH_CONNECTION") or os.environ.get("SSH_CLIENT"))
    # Choose auth method
    refresh_token = None
    if token is None:
        try:
            if is_ssh and not no_device_code:
                typer.echo("🔒 SSH session detected - using device code authentication")
                typer.echo("   (No port forwarding required!)")
                typer.echo("")
                token, refresh_token = device_code_login()
            else:
                if is_ssh:
                    typer.echo("🔒 SSH session detected - using browser authentication")
                    typer.echo("   Make sure you have port forwarding set up:")
                    if port is None:
                        port = 8765
                        typer.echo(f"   ssh -L {port}:localhost:{port} user@host")
                    else:
                        typer.echo(f"   ssh -L {port}:localhost:{port} user@host")
                    typer.echo("")
                token, refresh_token = browser_login(port=port)
        except TimeoutError as e:
            typer.echo(f"Error: {e}", err=True)
            raise typer.Exit(1) from None
        except RuntimeError as e:
            typer.echo(f"Error: {e}", err=True)
            raise typer.Exit(1) from None
        except KeyboardInterrupt:
            typer.echo("\nCancelled", err=True)
            raise typer.Exit(1) from None
    if not token.strip():
        typer.echo("Error: Token cannot be empty", err=True)
        raise typer.Exit(1)
    token = token.strip()
    # Verify token with API
    typer.echo("Verifying token...")
    try:
        user_info = verify_token(token)
    except httpx.HTTPStatusError as e:
        if e.response.status_code == 401:
            typer.echo("Error: Invalid token", err=True)
        else:
            typer.echo(f"Error: API returned {e.response.status_code}", err=True)
        raise typer.Exit(1) from None
    except httpx.RequestError as e:
        typer.echo(f"Error: Could not reach API: {e}", err=True)
        raise typer.Exit(1) from None
    # Save credentials (with refresh token if available)
    save_credentials(token, refresh_token, user_info.email)

    from . import analytics
    analytics.track_login(user_info.user_id, user_info.email)
    if user_info.email:
        typer.echo(f"Logged in as {user_info.email}")
    else:
        typer.echo(f"Logged in (user_id: {user_info.user_id})")
    typer.echo("Token saved to ~/.wafer/credentials.json")
@settings_app.command("logout")
def logout() -> None:
    """Remove stored credentials."""
    from . import analytics
    from .auth import clear_credentials

    # Note: track_logout() handles the case where user is not logged in
    analytics.track_logout()
    # Clear credentials and report result
    if clear_credentials():
        typer.echo("Logged out. Credentials removed.")
    else:
        typer.echo("Not logged in (no credentials found).")
@settings_app.command("whoami")
def whoami(
    json_output: bool = typer.Option(False, "--json", "-j", help="Output as JSON"),
) -> None:
    """Show current authenticated user and account information.
    Displays comprehensive authentication status including:
    - Email address
    - Environment (prod/staging/local)
    - Token validity and expiration
    - Subscription tier and credits
    """
    import json as json_module
    import time
    from .auth import _token_expired, get_valid_token, load_credentials, verify_token
    from .global_config import get_api_url, load_global_config
    creds = load_credentials()
    if creds is None:
        if json_output:
            from .output import json_error
            typer.echo(json_error("Not logged in"))
        else:
            typer.echo("Not logged in. Run: wafer settings login")
        raise typer.Exit(1)
    config = load_global_config()
    env_name = config.environment
    api_url = get_api_url()
    token_expired = _token_expired(creds.access_token)
    expires_in_str = None
    token_valid = not token_expired
    if creds.access_token:
        try:
            import base64
            payload_b64 = creds.access_token.split(".")[1]
            padded = payload_b64 + "=" * (-len(payload_b64) % 4)
            payload = json_module.loads(base64.urlsafe_b64decode(padded))
            exp = payload["exp"]
            remaining = exp - time.time()
            if remaining > 0:
                # Format as human-readable duration
                if remaining < 60:
                    expires_in_str = f"{int(remaining)}s"
                elif remaining < 3600:
                    expires_in_str = f"{int(remaining / 60)}m"
                elif remaining < 86400:
                    hours = int(remaining / 3600)
                    minutes = int((remaining % 3600) / 60)
                    expires_in_str = f"{hours}h {minutes}m"
                else:
                    days = int(remaining / 86400)
                    expires_in_str = f"{days}d"
            else:
                expires_in_str = "expired"
                token_valid = False
        except Exception:
            pass
    tier_info = None
    credits_remaining = None
    if token_valid:
        try:
            from .billing import get_usage
            usage_json = get_usage(json_output=True)
            envelope = json_module.loads(usage_json)
            usage = envelope.get("data", {})
            tier = usage.get("tier", "unknown")
            # Remap "start" to "Hacker" for display
            tier_info = "Hacker" if tier.lower() == "start" else tier.capitalize()
            status = usage.get("status", "unknown")
            credits_limit = usage.get("credits_limit_cents", 0)
            if credits_limit == -1 or tier.lower() == "enterprise":
                credits_remaining = "unlimited"
            else:
                credits_cents = usage.get("credits_remaining_cents", 0)
                credits_remaining = f"${credits_cents / 100:.2f}"
            # Include status in tier if it's concerning
            if status in ["past_due", "inactive", "cancelled"]:
                tier_info = f"{tier_info} ({status})"
        except Exception:
            # If billing API fails, continue without tier info
            pass
    # Output results
    if json_output:
        from .output import json_response
        result = {
            "email": creds.email or "unknown",
            "environment": env_name,
            "api_url": api_url,
            "token_valid": token_valid,
        }
        if expires_in_str:
            result["token_expires_in"] = expires_in_str
        if tier_info:
            result["tier"] = tier_info
        if credits_remaining:
            result["credits_remaining"] = credits_remaining
        typer.echo(json_response(data=result))
    else:
        # Human-readable format
        lines = [creds.email or "Logged in"]
        lines.append(f"  Environment: {env_name} ({api_url})")
        if token_valid:
            if expires_in_str and expires_in_str != "expired":
                lines.append(f"  Token: valid (expires in {expires_in_str})")
            else:
                lines.append("  Token: valid")
        else:
            lines.append("  WARNING: Token expired. Run 'wafer settings login' to re-authenticate.")
        if tier_info:
            lines.append(f"  Tier: {tier_info}")
        if credits_remaining:
            if credits_remaining == "unlimited":
                lines.append("  Credits: unlimited")
            else:
                lines.append(f"  Credits: {credits_remaining} remaining")
        typer.echo("\n".join(lines))
        # Exit with error code if token is expired
        if not token_valid:
            raise typer.Exit(1)


@settings_app.command("status")
def status(
    json_output: bool = typer.Option(False, "--json", "-j", help="Output as JSON"),
) -> None:
    """Check CLI health: version, config, auth, and API connectivity."""
    import json as json_module

    import httpx

    from .analytics import _get_cli_version
    from .auth import CHECK, CROSS, _token_expired, load_credentials
    from .global_config import CONFIG_DIR, get_api_url

    checks: list[dict] = []
    all_ok = True

    # 1. CLI Version (informational, always ok)
    version = _get_cli_version()
    checks.append({"name": "cli_version", "ok": True, "detail": version})

    # 2. Config Directory
    if CONFIG_DIR.exists() and CONFIG_DIR.is_dir():
        checks.append({"name": "config_directory", "ok": True, "detail": str(CONFIG_DIR)})
    else:
        all_ok = False
        checks.append({"name": "config_directory", "ok": False, "detail": f"{CONFIG_DIR} not found"})

    # 3. Authentication
    creds = load_credentials()
    if creds is None:
        all_ok = False
        checks.append({"name": "authentication", "ok": False, "detail": "Not logged in"})
    elif _token_expired(creds.access_token):
        all_ok = False
        checks.append({"name": "authentication", "ok": False, "detail": "Token expired"})
    else:
        detail = creds.email or "Authenticated"
        checks.append({"name": "authentication", "ok": True, "detail": detail})

    # 4. API Reachable
    api_url = get_api_url()
    try:
        with httpx.Client(timeout=10.0) as client:
            resp = client.get(f"{api_url}/health")
        if resp.status_code == 200:
            checks.append({"name": "api_reachable", "ok": True, "detail": api_url})
        else:
            all_ok = False
            checks.append({"name": "api_reachable", "ok": False, "detail": f"HTTP {resp.status_code}"})
    except httpx.ConnectError:
        all_ok = False
        checks.append({"name": "api_reachable", "ok": False, "detail": f"Connection failed ({api_url})"})
    except httpx.TimeoutException:
        all_ok = False
        checks.append({"name": "api_reachable", "ok": False, "detail": f"Timeout ({api_url})"})
    except httpx.RequestError as e:
        all_ok = False
        checks.append({"name": "api_reachable", "ok": False, "detail": f"Request failed: {e}"})

    # 5. Deps (on Linux: check for GPU tools, but non-blocking)
    # Missing GPU tools is a warning, not a failure. Cloud-only users and AMD
    # users with only rocprof-compute/rocprof-systems are still fully functional.
    import platform as platform_module
    plat = platform_module.system().lower()
    deps_ok = True
    deps_detail = "OK"
    if plat == "linux":
        from .deps import DEPS_REGISTRY
        gpu_tools = ["ncu", "nsys", "rocprof", "rocprofv3"]
        any_gpu_tool = any(
            shutil.which(DEPS_REGISTRY[n].check_cmd) is not None
            for n in gpu_tools
            if n in DEPS_REGISTRY
        )
        if not any_gpu_tool:
            # Non-blocking: warn but don't fail overall status
            deps_ok = False
            deps_detail = "No GPU tools found (optional; run 'wafer settings deps check')"
    checks.append({"name": "deps", "ok": deps_ok, "detail": deps_detail})

    # Output
    if json_output:
        from .output import json_response
        data = {"cli_version": version, "all_ok": all_ok, "checks": checks}
        status_val = "ok" if all_ok else "error"
        typer.echo(json_response(data=data, status=status_val))
    else:
        typer.echo("Wafer CLI Status")
        typer.echo("─" * 30)
        for check in checks:
            symbol = CHECK if check["ok"] else CROSS
            typer.echo(f"  {symbol} {check['name']}: {check['detail']}")

        if not all_ok:
            typer.echo("")
            typer.echo("Next steps:")
            auth_failed = next((c for c in checks if c["name"] == "authentication" and not c["ok"]), None)
            if auth_failed:
                typer.echo("  - Not logged in? Run: wafer settings login")
            deps_failed = next((c for c in checks if c["name"] == "deps" and not c["ok"]), None)
            if deps_failed:
                typer.echo("  - Missing tools? Run: wafer settings deps check")
            api_failed = next((c for c in checks if c["name"] == "api_reachable" and not c["ok"]), None)
            if api_failed:
                typer.echo("  - API unreachable. Check network or run: wafer settings login")

    if all_ok:
        _mark_command_success()
    else:
        raise typer.Exit(1)


@settings_app.command("guide")
def guide(
    section: str | None = typer.Argument(
        None,
        help="Show specific section: quickstart, docs, trace, evaluate, optimize, workspaces, commands",
    ),
    full: bool = typer.Option(
        False,
        "--full",
        "-f",
        help="Show full guide with rich formatting",
    ),
) -> None:
    """Show the Wafer CLI usage guide.
    By default, shows a table of contents. Use a section name to see specific content,
    or --full to see the entire guide with rich formatting.
    Examples:
      wafer settings guide                 # Show table of contents
      wafer settings guide quickstart      # Show Quick Start section
      wafer settings guide workspaces      # Show Workspaces section
      wafer settings guide --full          # Show full guide with formatting
    """
    from rich.console import Console
    from rich.markdown import Markdown
    guide_path = Path(__file__).parent / "GUIDE.md"
    if not guide_path.exists():
        typer.echo("Error: GUIDE.md not found", err=True)
        raise typer.Exit(1)
    content = guide_path.read_text()
    # Section name mapping (user-friendly name -> markdown header)
    section_map = {
        "quickstart": "Quick Start: Cloud GPU (No Setup)",
        "quick": "Quick Start: Cloud GPU (No Setup)",
        "cloud": "Quick Start: Cloud GPU (No Setup)",
        "docs": "Documentation Lookup",
        "documentation": "Documentation Lookup",
        "trace": "Trace Analysis",
        "analyze": "Trace Analysis",
        "analysis": "Trace Analysis",
        "evaluate": "Kernel Evaluation",
        "eval": "Kernel Evaluation",
        "optimize": "Kernel Optimization (AI-assisted)",
        "optimization": "Kernel Optimization (AI-assisted)",
        "workspaces": "Workspaces",
        "workspace": "Workspaces",
        "commands": "Command Reference",
        "reference": "Command Reference",
        "ref": "Command Reference",
    }
    # Show full guide with rich formatting
    if full:
        console = Console()
        md = Markdown(content)
        console.print(md)
        return
    # Show specific section
    if section:
        section_lower = section.lower()
        if section_lower not in section_map:
            typer.echo(f"Error: Unknown section '{section}'", err=True)
            typer.echo("\nAvailable sections:", err=True)
            typer.echo("  quickstart, docs, trace, evaluate, optimize, workspaces, commands", err=True)
            raise typer.Exit(1)
        header = section_map[section_lower]
        section_content = _extract_section(content, header)
        if not section_content:
            typer.echo(f"Error: Section '{header}' not found in guide", err=True)
            raise typer.Exit(1)
        console = Console()
        md = Markdown(section_content)
        console.print(md)
        return
    # Default: Show table of contents
    _show_guide_toc(content)
def _extract_section(content: str, header: str) -> str:
    """Extract a specific section from the guide markdown.
    Args:
        content: Full guide markdown content
        header: Section header to extract (e.g., "Quick Start: Cloud GPU (No Setup)")
    Returns:
        Section content including the header, up to the next ## header
    """
    lines = content.split("\n")
    section_lines = []
    in_section = False
    header_pattern = f"## {header}"
    for line in lines:
        if line.startswith(header_pattern):
            in_section = True
            section_lines.append(line)
        elif in_section:
            if line.startswith("## "):
                # Hit next section, stop
                break
            section_lines.append(line)
    return "\n".join(section_lines).strip()
def _show_guide_toc(content: str) -> None:
    """Show table of contents for the guide.
    Args:
        content: Full guide markdown content
    """
    from rich.console import Console
    from rich.panel import Panel
    from rich.text import Text
    lines = content.split("\n")
    title = ""
    sections = []
    for line in lines:
        if line.startswith("# "):
            title = line[2:].strip()
        elif line.startswith("## "):
            sections.append(line[3:].strip())
    console = Console()
    # Show title
    title_text = Text(title, style="bold cyan")
    console.print()
    console.print(title_text)
    console.print()
    # Show sections as a formatted list
    console.print("Available sections:", style="bold")
    console.print()
    section_aliases = [
        ("quickstart", "Quick Start: Cloud GPU (No Setup)"),
        ("docs", "Documentation Lookup"),
        ("trace", "Trace Analysis"),
        ("evaluate", "Kernel Evaluation"),
        ("optimize", "Kernel Optimization (AI-assisted)"),
        ("workspaces", "Workspaces"),
        ("commands", "Command Reference"),
    ]
    for alias, section_name in section_aliases:
        console.print(f"  [cyan]wafer settings guide {alias:12}[/cyan]  {section_name}")
    console.print()
    # Show usage hint
    hint = Panel(
        "[dim]Use [cyan]wafer settings guide <section>[/cyan] to see specific content\n"
        "Use [cyan]wafer settings guide --full[/cyan] to see the entire guide with formatting[/dim]",
        border_style="dim",
    )
    console.print(hint)
@app.command("version")
def version_cmd(
    json_output: bool = typer.Option(False, "--json", "-j", help="Output as JSON"),
) -> None:
    """Show CLI version and exit."""
    _show_version(json_output=json_output)
demo_app = typer.Typer(
    help="""Interactive demos for Wafer workflows.
  wafer settings demo trace  Analyze a sample performance trace
  wafer settings demo eval   Run kernel evaluation on cloud GPU (requires login)"""
)
settings_app.add_typer(demo_app, name="demo")
DEMO_TRACES_URL = "https://github.com/wafer-ai/wafer/raw/main/apps/wafer-cli/wafer/demo_data"
DEMO_DIR = Path.home() / ".cache" / "wafer" / "demo"
@demo_app.command("setup")
def demo_setup() -> None:
    """Download sample data for demos and tutorials.
    Downloads sample traces and kernels to ~/.cache/wafer/demo/
    Examples:
        wafer settings demo setup
        wafer settings demo traces     # list downloaded traces
        wafer tool perfetto query ~/.cache/wafer/demo/attention_trace.json "SELECT ..."
    """
    import shutil
    DEMO_DIR.mkdir(parents=True, exist_ok=True)
    # For now, copy bundled demo data from package
    # In future, could download from GitHub releases
    demo_source = Path(__file__).parent / "demo_data"
    if demo_source.exists():
        for f in demo_source.iterdir():
            dest = DEMO_DIR / f.name
            if not dest.exists():
                shutil.copy(f, dest)
                typer.echo(f"  ✓ {f.name}")
        typer.echo(f"\nDemo data ready at: {DEMO_DIR}")
    else:
        # Fallback: create minimal synthetic trace
        sample_trace = DEMO_DIR / "sample_trace.json"
        if not sample_trace.exists():
            sample_trace.write_text("""{
  "traceEvents": [
    {"name": "matmul_kernel", "cat": "kernel", "ph": "X", "ts": 0, "dur": 1500000, "pid": 1, "tid": 1},
    {"name": "relu_kernel", "cat": "kernel", "ph": "X", "ts": 1600000, "dur": 50000, "pid": 1, "tid": 1},
    {"name": "softmax_kernel", "cat": "kernel", "ph": "X", "ts": 1700000, "dur": 200000, "pid": 1, "tid": 1},
    {"name": "attention_kernel", "cat": "kernel", "ph": "X", "ts": 2000000, "dur": 3000000, "pid": 1, "tid": 1},
    {"name": "layernorm_kernel", "cat": "kernel", "ph": "X", "ts": 5100000, "dur": 100000, "pid": 1, "tid": 1}
  ]
}""")
            typer.echo("  ✓ sample_trace.json (synthetic)")
        typer.echo(f"\nDemo data ready at: {DEMO_DIR}")
    typer.echo("\nTry these commands:")
    typer.echo(f"  wafer tool perfetto tables {DEMO_DIR}/sample_trace.json")
    typer.echo(
        f"  wafer tool perfetto query {DEMO_DIR}/sample_trace.json "
        '"SELECT name, dur/1e6 as ms FROM slice ORDER BY dur DESC"'
    )
@demo_app.command("traces")
def demo_traces(
    json_output: bool = typer.Option(False, "--json", "-j", help="Output as JSON"),
) -> None:
    """List available demo traces.
    Shows demo traces in ~/.cache/wafer/demo/
    Run 'wafer settings demo setup' first to download sample data.
    """
    from .output import json_error, json_response
    if not DEMO_DIR.exists():
        if json_output:
            typer.echo(json_error("No demo data found. Run: wafer settings demo setup"))
        else:
            typer.echo("No demo data found. Run: wafer settings demo setup")
        raise typer.Exit(1)
    traces = list(DEMO_DIR.glob("*.json"))
    if not traces:
        if json_output:
            typer.echo(json_error("No traces found. Run: wafer settings demo setup"))
        else:
            typer.echo("No traces found. Run: wafer settings demo setup")
        raise typer.Exit(1)

    if json_output:
        trace_list = []
        for trace in sorted(traces):
            trace_list.append({
                "name": trace.name,
                "path": str(trace),
                "size_bytes": trace.stat().st_size,
            })
        typer.echo(json_response(data={"traces": trace_list, "demo_dir": str(DEMO_DIR)}))
        return

    typer.echo("Available demo traces:\n")
    for trace in sorted(traces):
        size_kb = trace.stat().st_size / 1024
        typer.echo(f"  {trace.name} ({size_kb:.1f} KB)")
        typer.echo(f"    {trace}")
    typer.echo("\nExample queries:")
    typer.echo("  # Slowest operations")
    typer.echo(
        f'  wafer tool perfetto query {traces[0]} "SELECT name, dur/1e6 as ms FROM slice ORDER BY dur DESC LIMIT 10"'
    )
    typer.echo("")
    typer.echo("  # Time breakdown by category")
    typer.echo(
        f'  wafer tool perfetto query {traces[0]} "SELECT cat, SUM(dur)/1e6 as total_ms FROM slice GROUP BY cat ORDER BY total_ms DESC"'
    )
@demo_app.command("trace")
def demo_trace(
    yes: bool = typer.Option(False, "--yes", "-y", help="Skip confirmation prompt"),
) -> None:
    """Demo: Analyze a performance trace.
    Creates a sample PyTorch trace and runs SQL queries on it.
    Example:
        wafer settings demo trace
        wafer settings demo trace -y  # skip confirmation
    """
    import subprocess
    if not yes:
        typer.echo("This demo will:")
        typer.echo("  1. Create a sample PyTorch-style trace")
        typer.echo("  2. Run SQL queries to find slowest kernels")
        typer.echo("")
        if not typer.confirm("Continue?"):
            raise typer.Exit(0)
    # Step 1: Setup demo data
    typer.echo("\n[1/2] Creating sample trace...")
    DEMO_DIR.mkdir(parents=True, exist_ok=True)
    sample_trace = DEMO_DIR / "sample_trace.json"
    sample_trace.write_text("""{
  "traceEvents": [
    {"name": "matmul_kernel", "cat": "kernel", "ph": "X", "ts": 0, "dur": 1500000, "pid": 1, "tid": 1},
    {"name": "relu_kernel", "cat": "kernel", "ph": "X", "ts": 1600000, "dur": 50000, "pid": 1, "tid": 1},
    {"name": "softmax_kernel", "cat": "kernel", "ph": "X", "ts": 1700000, "dur": 200000, "pid": 1, "tid": 1},
    {"name": "attention_kernel", "cat": "kernel", "ph": "X", "ts": 2000000, "dur": 3000000, "pid": 1, "tid": 1},
    {"name": "layernorm_kernel", "cat": "kernel", "ph": "X", "ts": 5100000, "dur": 100000, "pid": 1, "tid": 1}
  ]
}""")
    typer.echo(f"  Created: {sample_trace}")
    # Step 2: Query the trace
    typer.echo("\n[2/2] Finding slowest kernels...\n")
    typer.echo("-" * 60)
    result = subprocess.run(
        [
            "wafer",
            "tool",
            "perfetto",
            "query",
            str(sample_trace),
            "SELECT name, dur/1e6 as duration_ms FROM slice ORDER BY dur DESC",
        ],
        check=False,
    )
    typer.echo("-" * 60)
    if result.returncode == 0:
        typer.echo("\n✓ Demo complete! Try your own traces:")
        typer.echo('  wafer tool perfetto query <your_trace.json> "SELECT name, dur FROM slice"')
        typer.echo("")
        typer.echo("  Or use AI-assisted analysis:")
        typer.echo('  wafer agent -t trace-analyze --args trace=<your_trace.json> "What\'s slow?"')
    else:
        typer.echo("\n✗ Demo failed.")
        raise typer.Exit(1)
@demo_app.command("eval")
def demo_eval(
    yes: bool = typer.Option(False, "--yes", "-y", help="Skip confirmation prompt"),
) -> None:
    """Demo: Evaluate a kernel on a cloud GPU.
    Creates a workspace, runs a sample Triton kernel evaluation, and cleans up.
    Requires authentication (wafer settings login).
    Example:
        wafer settings demo eval
        wafer settings demo eval -y  # skip confirmation
    """
    import subprocess
    import tempfile
    import time
    from .auth import load_credentials
    creds = load_credentials()
    if not creds:
        typer.echo("Error: Not authenticated. Run: wafer settings login")
        raise typer.Exit(1)
    if not yes:
        typer.echo("This demo will:")
        typer.echo("  1. Create a cloud GPU workspace (B200)")
        typer.echo("  2. Generate and upload a sample Triton kernel")
        typer.echo("  3. Run correctness + performance evaluation")
        typer.echo("  4. Delete the workspace")
        typer.echo("")
        typer.echo("  Note: Workspace usage is billed. Demo takes ~2-3 minutes.")
        typer.echo("")
        if not typer.confirm("Continue?"):
            raise typer.Exit(0)
    workspace_name = f"wafer-demo-{int(time.time()) % 100000}"
    try:
        # Step 1: Create workspace
        typer.echo(f"\n[1/4] Creating workspace '{workspace_name}'...")
        result = subprocess.run(
            ["wafer", "target", "workspace", "create", workspace_name, "--gpu", "B200", "--json"],
            capture_output=True,
            text=True,
            check=True,
        )
        import json
        ws_info = json.loads(result.stdout)
        workspace_id = ws_info.get("id", workspace_name)
        typer.echo(f"  Created: {workspace_id}")
        # Step 2: Generate kernel template
        typer.echo("\n[2/4] Generating sample kernel...")
        with tempfile.TemporaryDirectory() as tmpdir:
            kernel_dir = Path(tmpdir) / "demo-kernel"
            subprocess.run(
                ["wafer", "tool", "eval", "make-template", str(kernel_dir)],
                capture_output=True,
                check=True,
            )
            typer.echo("  Generated Triton vector-add kernel")
            # Step 3: Run evaluation
            typer.echo("\n[3/4] Running evaluation on cloud GPU...\n")
            typer.echo("-" * 60)
            # Write a simple test script to avoid escaping hell
            test_script = kernel_dir / "run_test.py"
            test_script.write_text("""
import torch
import kernel
import reference
print(f"GPU: {torch.cuda.get_device_name(0)}")
# Test correctness
inputs = reference.generate_input(n=1048576, seed=42)
out = kernel.custom_kernel(inputs)
ref = reference.ref_kernel(inputs)
correct = torch.allclose(out, ref)
print(f"Correctness: {correct}")
# Benchmark
import time
for _ in range(10):
    kernel.custom_kernel(inputs)
torch.cuda.synchronize()
t0 = time.perf_counter()
for _ in range(100):
    kernel.custom_kernel(inputs)
torch.cuda.synchronize()
t1 = time.perf_counter()
print(f"Performance: {(t1-t0)/100*1e6:.1f} us/iter")
""")
            eval_result = subprocess.run(
                [
                    "wafer",
                    "target",
                    "workspace",
                    "exec",
                    "--sync",
                    str(kernel_dir),
                    workspace_name,
                    "--",
                    "bash",
                    "-c",
                    "cd /workspace && uv pip install -q --system triton && python run_test.py",
                ],
                check=False,
            )
            typer.echo("-" * 60)
        # Step 4: Cleanup
        typer.echo(f"\n[4/4] Deleting workspace '{workspace_name}'...")
        subprocess.run(
            ["wafer", "target", "workspace", "delete", workspace_id],
            capture_output=True,
            check=False,
        )
        typer.echo("  Deleted")
        if eval_result.returncode == 0:
            typer.echo("\n✓ Demo complete! To evaluate your own kernels:")
            typer.echo("")
            typer.echo("  # Using workspaces (no setup required):")
            typer.echo("  wafer target workspace create dev --gpu B200")
            typer.echo("  wafer target workspace exec --sync ./my-kernel dev -- python my_test.py")
            typer.echo("")
            typer.echo("  # Or using wafer tool eval with a configured target:")
            typer.echo("  wafer tool eval make-template ./my-kernel")
            typer.echo("  wafer tool eval gpumode --impl ./my-kernel/kernel.py \\")
            typer.echo("      --reference ./my-kernel/reference.py \\")
            typer.echo("      --test-cases ./my-kernel/test_cases.json \\")
            typer.echo("      --target <your-target>")
        else:
            typer.echo("\n✗ Evaluation failed, but workspace was cleaned up.")
            raise typer.Exit(1)
    except subprocess.CalledProcessError as e:
        error_msg = e.stderr.strip() if e.stderr else str(e)
        typer.echo(f"\n✗ Error: {error_msg}")
        # Try to cleanup on failure
        typer.echo(f"Attempting to cleanup workspace '{workspace_name}'...")
        subprocess.run(
            ["wafer", "target", "workspace", "delete", workspace_name],
            capture_output=True,
            check=False,
        )
        raise typer.Exit(1) from None
    except KeyboardInterrupt:
        typer.echo(f"\n\nInterrupted. Cleaning up workspace '{workspace_name}'...")
        subprocess.run(
            ["wafer", "target", "workspace", "delete", workspace_name],
            capture_output=True,
            check=False,
        )
        raise typer.Exit(1) from None
init_app = typer.Typer(
    help="""Initialize a new GPU target.
Choose based on your GPU access:
  local        GPU on current machine (no SSH)
  ssh          Your own hardware via SSH
  runpod       RunPod cloud GPUs (needs WAFER_RUNPOD_API_KEY)
  digitalocean DigitalOcean AMD MI300X (needs WAFER_AMD_DIGITALOCEAN_API_KEY)"""
)
targets_app.add_typer(init_app, name="init")
@init_app.command("local")
def init_local(
    name: str = typer.Option("local", "--name", "-n", help="Target name"),
    gpu_ids: str = typer.Option("0", "--gpu-ids", "-g", help="Comma-separated GPU IDs"),
) -> None:
    """Initialize a local target for GPU on current machine.
    Detects your local GPU and configures a target for direct execution
    (no SSH). Use this when running wafer on the same machine as the GPU.
    Examples:
        wafer target config init local
        wafer target config init local --name my-5090 --gpu-ids 0,1
    """
    from .targets import save_target
    try:
        parsed_gpu_ids = [int(g.strip()) for g in gpu_ids.split(",")]
    except ValueError:
        typer.echo(f"Error: Invalid GPU IDs '{gpu_ids}'. Use comma-separated integers.", err=True)
        raise typer.Exit(1) from None
    typer.echo("Detecting local GPU...")
    try:
        from wafer_core.gpu_detect import (
            detect_local_gpu,
            get_compute_capability,
            get_torch_requirements,
        )
        detected_gpu = detect_local_gpu()
        if detected_gpu:
            typer.echo(f"  Found: {detected_gpu.gpu_name}")
            if detected_gpu.vendor == "nvidia":
                typer.echo(f"  CUDA: {detected_gpu.driver_version}")
            else:
                typer.echo(f"  ROCm: {detected_gpu.driver_version}")
            typer.echo(f"  GPU count: {detected_gpu.gpu_count}")
            torch_reqs = get_torch_requirements(detected_gpu)
            compute_capability = get_compute_capability(detected_gpu)
            gpu_type = _extract_gpu_type(detected_gpu.gpu_name)
            typer.echo(f"  PyTorch: {torch_reqs.packages[0]}")
        else:
            typer.echo("  No GPU detected (nvidia-smi/rocm-smi not found)", err=True)
            raise typer.Exit(1)
    except ImportError as e:
        typer.echo(f"Error: Missing dependency: {e}", err=True)
        raise typer.Exit(1) from None
    target_data = {
        "name": name,
        "type": "local",
        "gpu_ids": parsed_gpu_ids,
        "gpu_type": gpu_type,
        "compute_capability": compute_capability,
        "torch_package": torch_reqs.packages[0],
        "torch_index_url": torch_reqs.index_url,
        "vendor": detected_gpu.vendor,
        "driver_version": detected_gpu.driver_version,
    }
    try:
        target = save_target(target_data)
        typer.echo(f"✓ Created target: {target.name}")
        typer.echo("  Type: Local (no SSH)")
        typer.echo(f"  GPU IDs: {parsed_gpu_ids}")
        typer.echo(f"  GPU Type: {gpu_type}")
        typer.echo(f"  Compute: {compute_capability}")
        typer.echo(f"  Torch: {torch_reqs.packages[0]}")
        typer.echo("")
        typer.echo(
            f"Usage: wafer tool eval --target {name} --impl kernel.py --reference ref.py --test-cases tests.json"
        )
    except (ValueError, AssertionError) as e:
        typer.echo(f"Error: {e}", err=True)
        raise typer.Exit(1) from None
@init_app.command("runpod")
def init_runpod(
    name: str = typer.Option("runpod-mi300x", "--name", "-n", help="Target name"),
    gpu_type: str = typer.Option("MI300X", "--gpu", "-g", help="GPU type (MI300X, H100, A100)"),
    ssh_key: str = typer.Option("~/.ssh/id_ed25519", "--ssh-key", "-k", help="Path to SSH key"),
    keep_alive: bool = typer.Option(
        True, "--keep-alive/--no-keep-alive", help="Keep pod running after eval"
    ),
) -> None:
    """Initialize a RunPod target.
    Creates a target config for auto-provisioned RunPod GPUs.
    Requires WAFER_RUNPOD_API_KEY environment variable.
    Examples:
        wafer target config init runpod
        wafer target config init runpod --name my-runpod --gpu H100
    """
    import os
    from .targets import save_target
    api_key = os.environ.get("WAFER_RUNPOD_API_KEY", "")
    if not api_key:
        typer.echo("Error: WAFER_RUNPOD_API_KEY environment variable not set.", err=True)
        typer.echo("", err=True)
        typer.echo("Get your API key from: https://runpod.io/console/user/settings", err=True)
        typer.echo("Then run: export WAFER_RUNPOD_API_KEY=your_key_here", err=True)
        raise typer.Exit(1)
    # GPU type mappings
    gpu_configs = {
        "MI300X": {
            "gpu_type_id": "AMD Instinct MI300X OAM",
            "image": "rocm/pytorch:rocm7.0.2_ubuntu24.04_py3.12_pytorch_release_2.7.1",
            "compute_capability": "9.4",
        },
        "H100": {
            "gpu_type_id": "NVIDIA H100 80GB HBM3",
            "image": "runpod/pytorch:2.4.0-py3.11-cuda12.4.1-devel-ubuntu22.04",
            "compute_capability": "9.0",
        },
        "A100": {
            "gpu_type_id": "NVIDIA A100 80GB PCIe",
            "image": "runpod/pytorch:2.4.0-py3.11-cuda12.4.1-devel-ubuntu22.04",
            "compute_capability": "8.0",
        },
    }
    if gpu_type not in gpu_configs:
        typer.echo(
            f"Error: Unknown GPU type '{gpu_type}'. Available: {', '.join(gpu_configs.keys())}",
            err=True,
        )
        raise typer.Exit(1)
    config = gpu_configs[gpu_type]
    target_data = {
        "name": name,
        "type": "runpod",
        "ssh_key": ssh_key,
        "gpu_type_id": config["gpu_type_id"],
        "gpu_count": 1,
        "container_disk_gb": 50,
        "image": config["image"],
        "provision_timeout": 900,
        "eval_timeout": 600,
        "keep_alive": keep_alive,
        "gpu_type": gpu_type,
        "compute_capability": config["compute_capability"],
        "gpu_ids": [0],
        "ncu_available": False,
    }
    try:
        target = save_target(target_data)
        typer.echo(f"✓ Created target: {target.name}")
        typer.echo("  Type: RunPod")
        typer.echo(f"  GPU: {gpu_type}")
        typer.echo(f"  Image: {config['image']}")
        typer.echo(f"  Keep alive: {'Yes' if keep_alive else 'No'}")
        typer.echo("")
        typer.echo(
            f"Usage: wafer tool eval --target {name} --impl kernel.py --reference ref.py --test-cases tests.json"
        )
    except (ValueError, AssertionError) as e:
        typer.echo(f"Error: {e}", err=True)
        raise typer.Exit(1) from None
@init_app.command("digitalocean")
def init_digitalocean(
    name: str = typer.Option("do-mi300x", "--name", "-n", help="Target name"),
    region: str = typer.Option("atl1", "--region", "-r", help="Region (atl1)"),
    ssh_key: str = typer.Option("~/.ssh/id_ed25519", "--ssh-key", "-k", help="Path to SSH key"),
    keep_alive: bool = typer.Option(
        True, "--keep-alive/--no-keep-alive", help="Keep droplet running after eval"
    ),
) -> None:
    """Initialize a DigitalOcean target.
    Creates a target config for auto-provisioned DigitalOcean AMD GPUs (MI300X).
    Requires WAFER_AMD_DIGITALOCEAN_API_KEY environment variable.
    Examples:
        wafer target config init digitalocean
        wafer target config init digitalocean --name my-do --region atl1
    """
    import os
    from .targets import save_target
    api_key = os.environ.get("WAFER_AMD_DIGITALOCEAN_API_KEY", "")
    if not api_key:
        typer.echo("Error: WAFER_AMD_DIGITALOCEAN_API_KEY environment variable not set.", err=True)
        typer.echo("", err=True)
        typer.echo("Get your API key from the DigitalOcean AMD Developer Cloud portal.", err=True)
        typer.echo("Then run: export WAFER_AMD_DIGITALOCEAN_API_KEY=your_key_here", err=True)
        raise typer.Exit(1)
    target_data = {
        "name": name,
        "type": "digitalocean",
        "ssh_key": ssh_key,
        "region": region,
        "size_slug": "gpu-mi300x1-192gb-devcloud",
        "image": "amd-pytorchrocm7",  # PyTorch (ROCm7) marketplace image
        "provision_timeout": 600,
        "eval_timeout": 600,
        "keep_alive": keep_alive,
        "gpu_type": "MI300X",
        "compute_capability": "9.4",
        "gpu_ids": [0],
        "ncu_available": False,
    }
    try:
        target = save_target(target_data)
        typer.echo(f"✓ Created target: {target.name}")
        typer.echo("  Type: DigitalOcean")
        typer.echo("  GPU: MI300X")
        typer.echo(f"  Region: {region}")
        typer.echo(f"  Keep alive: {'Yes' if keep_alive else 'No'}")
        typer.echo("")
        typer.echo(
            f"Usage: wafer tool eval --target {name} --impl kernel.py --reference ref.py --test-cases tests.json"
        )
    except (ValueError, AssertionError) as e:
        typer.echo(f"Error: {e}", err=True)
        raise typer.Exit(1) from None
@init_app.command("ssh")
def init_ssh(
    name: str = typer.Option(..., "--name", "-n", help="Target name"),
    host: str = typer.Option(..., "--host", "-H", help="SSH host (user@hostname:port)"),
    ssh_key: str = typer.Option("~/.ssh/id_ed25519", "--ssh-key", "-k", help="Path to SSH key"),
    gpu_ids: str = typer.Option("0", "--gpu-ids", "-g", help="Comma-separated GPU IDs"),
    gpu_type: str | None = typer.Option(
        None, "--gpu-type", help="GPU type (auto-detected if not specified)"
    ),
    docker_image: str | None = typer.Option(
        None, "--docker-image", "-d", help="Docker image (optional)"
    ),
    ncu: bool = typer.Option(False, "--ncu/--no-ncu", help="NCU profiling available"),
    no_detect: bool = typer.Option(False, "--no-detect", help="Skip GPU auto-detection"),
) -> None:
    """Initialize an SSH target for your own GPU hardware.

    Auto-detects GPU type and selects compatible PyTorch version.

    Examples:
        wafer target config init ssh --name my-gpu --host user@192.168.1.100:22
        wafer target config init ssh --name lab-h100 --host ubuntu@gpu.lab.com:22 --ncu
    """
    from .targets import save_target
    try:
        parsed_gpu_ids = [int(g.strip()) for g in gpu_ids.split(",")]
    except ValueError:
        typer.echo(f"Error: Invalid GPU IDs '{gpu_ids}'. Use comma-separated integers.", err=True)
        raise typer.Exit(1) from None
    # Validate host format
    if ":" not in host:
        typer.echo(f"Error: Host must include port (user@hostname:port), got: {host}", err=True)
        typer.echo("Example: user@192.168.1.100:22", err=True)
        raise typer.Exit(1)
    # Auto-detect GPU if not specified
    detected_gpu = None
    torch_package = None
    torch_index_url = None
    if not no_detect:
        typer.echo(f"Connecting to {host}...")
        try:
            import trio
            import trio_asyncio
            from wafer_core.async_ssh import AsyncSSHClient
            from wafer_core.gpu_detect import (
                detect_remote_gpu,
                get_compute_capability,
                get_torch_requirements,
            )
            expanded_key = str(Path(ssh_key).expanduser())
            async def _detect() -> None:
                nonlocal detected_gpu, torch_package, torch_index_url
                # Need trio_asyncio.open_loop() for asyncssh bridge
                async with trio_asyncio.open_loop():
                    async with AsyncSSHClient(host, expanded_key) as client:
                        detected_gpu = await detect_remote_gpu(client)
            trio.run(_detect)
            if detected_gpu:
                typer.echo(f"  Found: {detected_gpu.gpu_name}")
                if detected_gpu.vendor == "nvidia":
                    typer.echo(f"  CUDA: {detected_gpu.driver_version}")
                else:
                    typer.echo(f"  ROCm: {detected_gpu.driver_version}")
                torch_reqs = get_torch_requirements(detected_gpu)
                torch_package = torch_reqs.packages[0]  # Just torch, not all packages
                torch_index_url = torch_reqs.index_url
                typer.echo(f"  PyTorch: {torch_package}")
                if not gpu_type:
                    gpu_type = _extract_gpu_type(detected_gpu.gpu_name)
            else:
                typer.echo("  No GPU detected (nvidia-smi/rocm-smi not found)")
                if not gpu_type:
                    gpu_type = "B200"  # Default fallback
                    typer.echo(f"  Using default: {gpu_type}")
        except Exception as e:
            typer.echo(f"  Detection failed: {e}", err=True)
            if not gpu_type:
                gpu_type = "B200"
                typer.echo(f"  Using default: {gpu_type}")

    # Fallback if no detection
    if not gpu_type:
        gpu_type = "B200"

    # Compute capability mappings
    if detected_gpu:
        from wafer_core.gpu_detect import get_compute_capability
        compute_capability = get_compute_capability(detected_gpu)
    else:
        compute_caps = {
            "B200": "10.0",
            "H100": "9.0",
            "A100": "8.0",
            "A10": "8.6",
            "V100": "7.0",
            "MI300X": "9.4",
            "MI250X": "9.0",
            "RTX 5090": "10.0",
            "RTX 4090": "8.9",
            "RTX 3090": "8.6",
        }
        compute_capability = compute_caps.get(gpu_type, "8.0")
    target_data = {
        "name": name,
        "type": "baremetal",
        "ssh_target": host,
        "ssh_key": ssh_key,
        "gpu_ids": parsed_gpu_ids,
        "gpu_type": gpu_type,
        "compute_capability": compute_capability,
        "ncu_available": ncu,
    }
    if docker_image:
        target_data["docker_image"] = docker_image
    if torch_package:
        target_data["torch_package"] = torch_package
    if torch_index_url:
        target_data["torch_index_url"] = torch_index_url
    try:
        target = save_target(target_data)
        typer.echo(f"✓ Created target: {target.name}")
        typer.echo("  Type: Baremetal (SSH)")
        typer.echo(f"  Host: {host}")
        typer.echo(f"  GPU IDs: {parsed_gpu_ids}")
        typer.echo(f"  GPU Type: {gpu_type}")
        typer.echo(f"  Compute: {compute_capability}")
        typer.echo(f"  NCU: {'Yes' if ncu else 'No'}")
        if docker_image:
            typer.echo(f"  Docker: {docker_image}")
        if torch_package:
            typer.echo(f"  Torch: {torch_package}")
        typer.echo("")
        typer.echo(
            f"Usage: wafer tool eval --target {name} --impl kernel.py --reference ref.py --test-cases tests.json"
        )
    except (ValueError, AssertionError) as e:
        typer.echo(f"Error: {e}", err=True)
        raise typer.Exit(1) from None
def _extract_gpu_type(gpu_name: str) -> str:
    """Extract GPU type from full GPU name.
    Examples:
        "NVIDIA H100 80GB HBM3" -> "H100"
        "NVIDIA GeForce RTX 4090" -> "RTX 4090"
        "AMD Instinct MI300X OAM" -> "MI300X"
    """
    gpu_name_upper = gpu_name.upper()
    known_types = [
        "B200",
        "B100",
        "H200",
        "H100",
        "A100",
        "A10",
        "V100",
        "RTX 5090",
        "RTX 5080",
        "RTX 4090",
        "RTX 4080",
        "RTX 3090",
        "RTX 3080",
        "MI300X",
        "MI250X",
        "MI100",
    ]
    for gpu_type in known_types:
        if gpu_type in gpu_name_upper:
            return gpu_type
    # Fallback: return cleaned name
    return gpu_name.replace("NVIDIA ", "").replace("AMD ", "").strip()
@targets_app.command("add")
def targets_add(
    file_path: Path = typer.Argument(..., help="Path to target TOML file"),
) -> None:
    """Add a target from a TOML config file.
    Example:
        wafer target config add ~/configs/my-gpu.toml
    Target TOML schema (baremetal example):
        name = "my-gpu"
        type = "baremetal"
        ssh_target = "user@hostname"
        gpu_ids = [0]
        compute_capability = "9.0"
        ncu_available = true
        docker_image = "nvcr.io/nvidia/pytorch:24.01-py3"
    Available types: baremetal, vm, modal, workspace, runpod, digitalocean
    """
    from .targets import add_target_from_file, get_target_info
    try:
        target = add_target_from_file(file_path)
        typer.echo(f"Added target: {target.name}")
        info = get_target_info(target)
        for key, value in info.items():
            typer.echo(f"  {key}: {value}")
    except FileNotFoundError as e:
        typer.echo(f"Error: {e}", err=True)
        raise typer.Exit(1) from None
    except (ValueError, AssertionError) as e:
        typer.echo(f"Error: Invalid target config: {e}", err=True)
        raise typer.Exit(1) from None
@targets_app.command("list")
def targets_list(
    json_output: bool = typer.Option(False, "--json", "-j", help="Output as JSON"),
) -> None:
    """List all configured targets with live provider status.
    Example:
        wafer target config list
        wafer target config list --json
    """
    import socket
    import trio
    from .targets import get_default_target, list_targets, load_target, remove_target
    targets = list_targets()
    default = get_default_target()
    if not targets:
        if json_output:
            from .output import json_response
            typer.echo(json_response(data={"targets": []}))
        else:
            typer.echo("No targets configured.")
            typer.echo("Add one with: wafer target config add <path/to/target.toml>")
        return
    def _parse_ssh_target(ssh_target: str) -> tuple[str, int]:
        """Extract (host, port) from user@host:port string."""
        parts = ssh_target.rsplit(":", 1)
        host_part = parts[0]
        port = int(parts[1]) if len(parts) > 1 else 22
        if "@" in host_part:
            host = host_part.split("@", 1)[1]
        else:
            host = host_part
        return (host, port)
    async def _get_live_provider_endpoints() -> set[tuple[str, int]]:
        """Query RunPod + DO APIs. Returns set of live (ip, port) endpoints."""
        from wafer_core.targets.digitalocean import list_running_droplets
        from wafer_core.targets.runpod import sync_pods_from_api
        live_endpoints: set[tuple[str, int]] = set()
        async def _fetch_runpod() -> None:
            try:
                pods = await sync_pods_from_api()
                for p in pods:
                    live_endpoints.add((p.public_ip, p.ssh_port))
            except Exception:
                pass
        async def _fetch_do() -> None:
            try:
                droplets = await list_running_droplets()
                for d in droplets:
                    live_endpoints.add((d.public_ip, d.ssh_port))
            except Exception:
                pass
        async with trio.open_nursery() as nursery:
            nursery.start_soon(_fetch_runpod)
            nursery.start_soon(_fetch_do)
        return live_endpoints
    async def _get_target_status(
        name: str,
        live_endpoints: set[tuple[str, int]],
    ) -> tuple[str, str, str]:
        """Returns (name, status, ssh_info)."""
        from wafer_core.targets.digitalocean import (
            _remove_droplet_from_state,
            check_droplet_running,
            get_droplet_state,
        )
        from wafer_core.targets.runpod import (
            _remove_pod_from_state,
            check_pod_running,
            get_pod_state,
        )
        from wafer_core.utils.kernel_utils.targets.config import (
            BaremetalTarget,
            DigitalOceanTarget,
            ModalTarget,
            RunPodTarget,
        )
        try:
            target = load_target(name)
        except (FileNotFoundError, ValueError, AssertionError, TypeError):
            return (name, "error", "")
        if isinstance(target, RunPodTarget):
            pod = get_pod_state(name)
            if not pod:
                return (name, "no instance", "")
            if await check_pod_running(pod.pod_id):
                return (name, "running", f"{pod.ssh_username}@{pod.public_ip}:{pod.ssh_port}")
            _remove_pod_from_state(name)
            return (name, "stopped", "")
        if isinstance(target, DigitalOceanTarget):
            droplet = get_droplet_state(name)
            if not droplet:
                return (name, "no instance", "")
            if await check_droplet_running(droplet.droplet_id):
                return (
                    name,
                    "running",
                    f"{droplet.ssh_username}@{droplet.public_ip}:{droplet.ssh_port}",
                )
            _remove_droplet_from_state(name)
            return (name, "stopped", "")
        if isinstance(target, BaremetalTarget):
            ssh_target = target.ssh_target
            host, port = _parse_ssh_target(ssh_target)
            def _tcp_check() -> bool:
                try:
                    sock = socket.create_connection((host, port), timeout=2)
                    sock.close()
                    return True
                except OSError:
                    return False
            reachable = await trio.to_thread.run_sync(_tcp_check)
            if reachable:
                return (name, "reachable", ssh_target)
            # Unreachable + has a provider = backed by an ephemeral instance.
            # If not in the live provider listing, the instance is gone — remove config.
            if target.provider and (host, port) not in live_endpoints:
                remove_target(name)
                return (name, "removed (dead pod)", ssh_target)
            return (name, "unreachable", ssh_target)
        if isinstance(target, ModalTarget):
            return (name, "serverless", "")
        # Unknown target type
        return (name, "unknown", "")
    async def _gather_statuses() -> list[tuple[str, str, str]]:
        live_endpoints = await _get_live_provider_endpoints()
        results: list[tuple[str, str, str]] = [("", "", "")] * len(targets)
        async def _check(i: int, name: str) -> None:
            results[i] = await _get_target_status(name, live_endpoints)
        async with trio.open_nursery() as nursery:
            for i, name in enumerate(targets):
                nursery.start_soon(_check, i, name)
        return results
    statuses = trio.run(_gather_statuses)
    if json_output:
        from .output import json_response
        result = []
        for name, status, ssh_info in statuses:
            entry = {
                "name": name,
                "default": name == default,
                "status": status,
            }
            if ssh_info:
                entry["ssh_target"] = ssh_info
            result.append(entry)
        typer.echo(json_response(data={"targets": result}))
    else:
        typer.echo("Configured targets:")
        for name, status, ssh_info in statuses:
            marker = " (default)" if name == default else ""
            label = f"  {name}{marker}"
            detail = f"  {ssh_info}" if ssh_info else ""
            typer.echo(f"{label:<40}{status}{detail}")
@targets_app.command("show")
def targets_show(
    name: str = typer.Argument(..., help="Target name"),
) -> None:
    """Show details for a target.
    Example:
        wafer target config show modal-b200
    """
    from .targets import get_target_info, load_target
    try:
        target = load_target(name)
        typer.echo(f"Target: {name}")
        info = get_target_info(target)
        for key, value in info.items():
            typer.echo(f"  {key}: {value}")
    except FileNotFoundError as e:
        typer.echo(f"Error: {e}", err=True)
        raise typer.Exit(1) from None
@targets_app.command("probe")
def targets_probe(
    name: str = typer.Argument(..., help="Target name"),
) -> None:
    """Probe a target to discover available compilation backends.
    Connects to the target and checks what's available:
    - Triton
    - torch.compile/inductor
    - HIP/hipcc or CUDA/nvcc
    - ROCm or CUDA version
    - Python packages (torch, triton, etc.)
    Example:
        wafer target config probe runpod-mi300x
    """
    import trio
    from .targets import ProbeError, load_target, probe_target_capabilities
    try:
        target = load_target(name)
    except FileNotFoundError as e:
        typer.echo(f"Error: {e}", err=True)
        raise typer.Exit(1) from None
    typer.echo(f"Probing target: {name}...")
    try:
        capabilities = trio.run(probe_target_capabilities, target)
    except ProbeError as e:
        # ProbeError already has actionable context
        typer.echo(f"\nError: {e}", err=True)
        raise typer.Exit(1) from None
    except BaseException as e:
        # Unwrap ExceptionGroup (from Trio nurseries) to show the actual cause
        cause = e
        while isinstance(cause, BaseExceptionGroup) and len(cause.exceptions) == 1:
            cause = cause.exceptions[0]
        typer.echo(f"\nUnexpected error probing target: {type(cause).__name__}: {cause}", err=True)
        raise typer.Exit(1) from None
    # Display results
    typer.echo(f"\nTarget: {name}")
    if capabilities.get("gpu_name"):
        typer.echo(f"  GPU: {capabilities['gpu_name']}")
    if capabilities.get("compute_capability"):
        typer.echo(f"  Compute: {capabilities['compute_capability']}")
    typer.echo("\n  Compilation Backends:")
    backends = capabilities.get("backends", {})
    # Triton
    triton_ver = backends.get("triton")
    if triton_ver:
        typer.echo(f"    ✓ Triton: {triton_ver}")
    else:
        typer.echo("    ✗ Triton: not installed")
    # torch.compile
    if triton_ver and backends.get("torch"):
        typer.echo("    ✓ torch.compile/inductor: available")
    else:
        typer.echo("    ✗ torch.compile/inductor: requires Triton")
    # HIP/CUDA compiler
    if backends.get("hipcc"):
        typer.echo(f"    ✓ HIP/hipcc: {backends['hipcc']}")
    elif backends.get("nvcc"):
        typer.echo(f"    ✓ CUDA/nvcc: {backends['nvcc']}")
    else:
        typer.echo("    ✗ No GPU compiler found")
    # ROCm/CUDA version
    if capabilities.get("rocm_version"):
        typer.echo(f"    ROCm: {capabilities['rocm_version']}")
    if capabilities.get("cuda_version"):
        typer.echo(f"    CUDA: {capabilities['cuda_version']}")
    typer.echo("\n  Python Environment:")
    typer.echo(f"    Python: {capabilities.get('python_version', 'unknown')}")
    packages = capabilities.get("packages", {})
    if packages.get("torch"):
        typer.echo(f"    PyTorch: {packages['torch']}")
    if triton_ver:
        typer.echo(f"    Triton: {triton_ver}")
@targets_app.command("remove")
def targets_remove(
    name: str = typer.Argument(..., help="Target name"),
    force: bool = typer.Option(False, "--force", "-f", help="Skip confirmation"),
) -> None:
    """Remove a target.
    Example:
        wafer target config remove modal-b200
    """
    from .targets import remove_target
    if not force:
        confirm = typer.confirm(f"Remove target '{name}'?")
        if not confirm:
            typer.echo("Cancelled.")
            raise typer.Exit(0)
    try:
        remove_target(name)
        typer.echo(f"Removed target: {name}")
    except FileNotFoundError as e:
        typer.echo(f"Error: {e}", err=True)
        raise typer.Exit(1) from None
@targets_app.command("default")
def targets_default(
    name: str = typer.Argument(..., help="Target name to set as default"),
) -> None:
    """Set the default target.
    Example:
        wafer target config default modal-b200
    """
    from .targets import set_default_target
    try:
        set_default_target(name)
        typer.echo(f"Default target set to: {name}")
    except FileNotFoundError as e:
        typer.echo(f"Error: {e}", err=True)
        raise typer.Exit(1) from None
@targets_app.command("cleanup")
def targets_cleanup(
    name: str = typer.Argument(..., help="Target name to clean up (must be a RunPod target)"),
) -> None:
    """Terminate RunPod pod for a target.
    Only works for RunPod targets. Terminates any running pod associated
    with the target and removes it from the state file.
    Example:
        wafer target config cleanup runpod-mi300x
    """
    import trio
    from wafer_core.targets.runpod import cleanup_target, get_pod_state
    from .targets import load_target
    try:
        target = load_target(name)
    except FileNotFoundError as e:
        typer.echo(f"Error: {e}", err=True)
        raise typer.Exit(1) from None
    from wafer_core.utils.kernel_utils.targets.config import RunPodTarget
    if not isinstance(target, RunPodTarget):
        typer.echo(
            f"Error: {name} is not a RunPod target (type: {type(target).__name__})", err=True
        )
        raise typer.Exit(1) from None
    state = get_pod_state(name)
    if not state:
        typer.echo(f"No running pod found for target: {name}")
        return
    typer.echo(f"Found pod {state.pod_id} for target {name}")
    typer.echo(f"  IP: {state.public_ip}:{state.ssh_port}")
    typer.echo(f"  Created: {state.created_at}")
    typer.echo("Terminating...")
    async def _cleanup() -> bool:
        return await cleanup_target(name)
    success = trio.run(_cleanup)
    if success:
        typer.echo("Pod terminated successfully")
    else:
        typer.echo("Failed to terminate pod", err=True)
        raise typer.Exit(1) from None
# Known libraries that can be installed on targets
# TODO: Consider adding HipKittens to the default RunPod/DO Docker images
# so this install step isn't needed. For now, this command handles it.
# Architecture → branch mapping for libraries that ship per-arch branches.
# "default" is used when the detected arch has no explicit entry.
_ARCH_BRANCHES: dict[str, dict[str, str]] = {
    "hipkittens": {
        "gfx942": "cdna3",  # MI300X, MI325X
        "default": "main",  # MI350X, MI355X, and future CDNA4+
    },
}
INSTALLABLE_LIBRARIES: dict[str, dict[str, object]] = {
    "hipkittens": {
        "description": "HipKittens - AMD port of ThunderKittens",
        "git_url": "https://github.com/HazyResearch/HipKittens.git",
        "install_path": "/opt/hipkittens",
        "requires_amd": True,
    },
    # CK is already installed with ROCm 7.0, no action needed
    "repair-headers": {
        "description": "Repair ROCm thrust headers (fixes hipify corruption)",
        "custom_script": "apt-get update -qq && apt-get install --reinstall -y rocthrust >/dev/null 2>&1 && echo REPAIRED",
        "requires_amd": True,
    },
}
def _resolve_gfx_arch(target: object, ssh_cmd: list[str]) -> str | None:
    """Return the gfx architecture string for *target*.
    1. If the target config already carries a compute_capability, map it.
    2. Otherwise SSH in and probe with ``rocminfo``.
    Returns None only if detection fails entirely.
    """
    import subprocess
    from .evaluate import AMD_CC_TO_ARCH
    cc = getattr(target, "compute_capability", None)
    if cc and cc in AMD_CC_TO_ARCH:
        return AMD_CC_TO_ARCH[cc]
    typer.echo("  Detecting GPU architecture via rocminfo...")
    probe_script = "rocminfo 2>/dev/null | grep -oP 'gfx\\d+' | head -1"
    result = subprocess.run(
        ssh_cmd + [probe_script],
        capture_output=True,
        text=True,
        timeout=30,
    )
    arch = result.stdout.strip()
    if result.returncode == 0 and arch.startswith("gfx"):
        typer.echo(f"  Detected: {arch}")
        return arch
    typer.echo("  Warning: could not detect GPU architecture", err=True)
    return None
@targets_app.command("install")
def targets_install(
    name: str = typer.Argument(..., help="Target name"),
    library: str = typer.Argument(..., help="Library to install (hipkittens, repair-headers)"),
) -> None:
    """Install a library or run maintenance on a target (idempotent).
    Installs header-only libraries like HipKittens on remote targets.
    Safe to run multiple times - will skip if already installed.
    For libraries with per-architecture branches (e.g. HipKittens), the
    correct branch is selected automatically based on the target's GPU.
    Available libraries:
        hipkittens     - HipKittens (AMD ThunderKittens port)
        repair-headers - Fix ROCm thrust headers (after hipify corruption)
    Examples:
        wafer target config install runpod-mi300x hipkittens
        wafer target config install runpod-mi300x repair-headers
        wafer target config install do-mi300x hipkittens
    """
    import subprocess
    from .targets import load_target
    from .targets_ops import get_target_ssh_info
    if library not in INSTALLABLE_LIBRARIES:
        available = ", ".join(INSTALLABLE_LIBRARIES.keys())
        typer.echo(f"Error: Unknown library '{library}'. Available: {available}", err=True)
        raise typer.Exit(1)
    lib_info = INSTALLABLE_LIBRARIES[library]
    try:
        target = load_target(name)
    except FileNotFoundError as e:
        typer.echo(f"Error: {e}", err=True)
        raise typer.Exit(1) from None
    if lib_info.get("requires_amd"):
        from wafer_core.utils.kernel_utils.targets.config import (
            DigitalOceanTarget,
            RunPodTarget,
        )
        is_amd = isinstance(target, (RunPodTarget, DigitalOceanTarget))
        if not is_amd and hasattr(target, "compute_capability"):
            is_amd = target.compute_capability.startswith("9.")
        if not is_amd:
            typer.echo(f"Error: {library} requires an AMD GPU target", err=True)
            raise typer.Exit(1)
    typer.echo(f"Installing {library} on {name}...")
    typer.echo(f"  {lib_info['description']}")
    async def _install() -> bool:
        # get_target_ssh_info uses pure trio async (no asyncio bridging needed)
        # and we use subprocess for SSH, not AsyncSSHClient
        ssh_info = await get_target_ssh_info(target)
        ssh_cmd = [
            "ssh",
            "-o",
            "StrictHostKeyChecking=no",
            "-o",
            "UserKnownHostsFile=/dev/null",
            "-o",
            "ConnectTimeout=30",
            "-i",
            str(ssh_info.key_path),
            "-p",
            str(ssh_info.port),
            f"{ssh_info.user}@{ssh_info.host}",
        ]
        if "custom_script" in lib_info:
            install_script = str(lib_info["custom_script"])
            success_marker = "REPAIRED"
        else:
            install_path = lib_info["install_path"]
            git_url = lib_info["git_url"]
            # Resolve the branch for arch-aware libraries
            branch = "main"
            arch_map = _ARCH_BRANCHES.get(library)
            if arch_map:
                gfx = await trio.to_thread.run_sync(lambda: _resolve_gfx_arch(target, ssh_cmd))
                branch = arch_map.get(gfx, arch_map["default"]) if gfx else arch_map["default"]
                typer.echo(f"  Branch: {branch} (arch={gfx or 'unknown'})")
            # Idempotent: if already cloned, ensure correct branch & pull
            install_script = f"""
if [ -d "{install_path}" ]; then
    echo "ALREADY_INSTALLED: {install_path} exists"
    cd {install_path} && git fetch --quiet origin && git checkout {branch} --quiet && git pull --quiet origin {branch}
else
    echo "INSTALLING: cloning to {install_path}"
    git clone --quiet --branch {branch} {git_url} {install_path}
fi
echo "DONE"
"""
            success_marker = "DONE"
        def run_ssh() -> subprocess.CompletedProcess[str]:
            return subprocess.run(
                ssh_cmd + [install_script],
                capture_output=True,
                text=True,
                timeout=120,
            )
        result = await trio.to_thread.run_sync(run_ssh)
        if result.returncode != 0:
            typer.echo(f"Error: {result.stderr}", err=True)
            return False
        output = result.stdout.strip()
        if "ALREADY_INSTALLED" in output:
            typer.echo(f"  Already installed at {lib_info.get('install_path', 'N/A')}")
        elif "INSTALLING" in output:
            typer.echo(f"  Installed to {lib_info.get('install_path', 'N/A')}")
        elif "REPAIRED" in output:
            typer.echo("  ROCm headers repaired")
        return success_marker in output
    try:
        success = trio.run(_install)
    except Exception as e:
        typer.echo(f"Error: {e}", err=True)
        raise typer.Exit(1) from None
    if success:
        typer.echo(f"✓ {library} ready on {name}")
        # Print usage hint
        if library == "hipkittens":
            typer.echo("")
            typer.echo("Usage in load_inline:")
            typer.echo('  extra_include_paths=["/opt/hipkittens/include", "/opt/rocm/include/hip"]')
    else:
        typer.echo(f"Failed to install {library}", err=True)
        raise typer.Exit(1)
@targets_app.command("pods")
def targets_pods() -> None:
    """List all running RunPod pods.
    Shows pods from the state file that are still running.
    Example:
        wafer target config pods
    """
    import trio
    from wafer_core.targets.runpod import list_running_pods
    async def _list() -> list:
        return await list_running_pods()
    pods = trio.run(_list)
    if not pods:
        typer.echo("No running RunPod pods found")
        return
    typer.echo(f"Found {len(pods)} running pod(s):\n")
    for pod in pods:
        typer.echo(f"  Target: {pod.target_name}")
        typer.echo(f"  Pod ID: {pod.pod_id}")
        typer.echo(f"  SSH: {pod.ssh_username}@{pod.public_ip}:{pod.ssh_port}")
        typer.echo(f"  Created: {pod.created_at}")
        typer.echo()
# ── Pool commands ───────────────────────────────────────────────────────────
@targets_app.command("pool-list")
def targets_pool_list() -> None:
    """List all configured target pools.
    Example:
        wafer target config pool-list
    """
    from .targets import get_pool, list_pools
    pools = list_pools()
    if not pools:
        typer.echo("No pools configured")
        typer.echo("")
        typer.echo("Define pools in ~/.wafer/config.toml:")
        typer.echo("  [pools.my-pool]")
        typer.echo('  targets = ["target-1", "target-2"]')
        return
    typer.echo("Configured pools:\n")
    for pool_name in pools:
        try:
            targets = get_pool(pool_name)
            typer.echo(f"  {pool_name}: {', '.join(targets)}")
        except Exception as e:
            typer.echo(f"  {pool_name}: (error: {e})")
@targets_app.command("pool-create")
def targets_pool_create(
    name: str = typer.Argument(..., help="Pool name"),
    targets: list[str] = typer.Argument(..., help="Target names to include in pool"),
) -> None:
    """Create or update a target pool.
    Example:
        wafer target config pool-create mi300x-pool mi300x-1 mi300x-2 mi300x-3
    """
    from .targets import save_pool
    try:
        save_pool(name, targets)
        typer.echo(f"Pool '{name}' created with {len(targets)} targets")
    except FileNotFoundError as e:
        typer.echo(f"Error: {e}", err=True)
        raise typer.Exit(1) from None
@targets_app.command("pool-status")
def targets_pool_status(
    name: str = typer.Argument(..., help="Pool name"),
) -> None:
    """Show status of targets in a pool (locked/available).
    Example:
        wafer target config pool-status mi300x-pool
    """
    from .target_lock import get_lock_holder, is_target_locked
    from .targets import get_pool
    try:
        targets = get_pool(name)
    except FileNotFoundError as e:
        typer.echo(f"Error: {e}", err=True)
        raise typer.Exit(1) from None
    typer.echo(f"Pool '{name}' ({len(targets)} targets):\n")
    available = 0
    for target_name in targets:
        locked = is_target_locked(target_name)
        if locked:
            pid = get_lock_holder(target_name)
            pid_str = f" (pid {pid})" if pid else ""
            typer.echo(f"  [busy]  {target_name}{pid_str}")
        else:
            typer.echo(f"  [free]  {target_name}")
            available += 1
    typer.echo("")
    typer.echo(f"Available: {available}/{len(targets)}")
@billing_app.callback(invoke_without_command=True)
def billing_usage(
    ctx: typer.Context,
    json_output: bool = typer.Option(False, "--json", "-j", help="Output as JSON"),
) -> None:
    """Show current billing usage and subscription info.
    Example:
        wafer billing
        wafer billing --json
    """
    # Only show usage if no subcommand was invoked
    if ctx.invoked_subcommand is not None:
        return
    from .billing import get_usage
    try:
        result = get_usage(json_output=json_output)
        typer.echo(result)
    except RuntimeError as e:
        if json_output:
            from .output import json_error
            typer.echo(json_error(str(e)))
        else:
            typer.echo(f"Error: {e}", err=True)
        raise typer.Exit(1) from None
@billing_app.command("topup")
def billing_topup(
    amount: int = typer.Argument(25, help="Amount in dollars ($10-$500)"),
    no_browser: bool = typer.Option(
        False, "--no-browser", help="Print URL instead of opening browser"
    ),
) -> None:
    """Add credits to your account.
    Opens a Stripe checkout page to add credits. Default amount is $25.
    Example:
        wafer billing topup        # Add $25
        wafer billing topup 100    # Add $100
        wafer billing topup --no-browser  # Print URL instead
    """
    import webbrowser
    from .billing import create_topup, validate_topup_amount
    amount_cents = amount * 100
    # Validate amount client-side before API call
    try:
        validate_topup_amount(amount_cents)
    except ValueError as e:
        typer.echo(f"Error: {e}", err=True)
        raise typer.Exit(1) from None
    try:
        result = create_topup(amount_cents)
        checkout_url = result.get("checkout_url")
        if not checkout_url:
            typer.echo("Error: No checkout URL received from API", err=True)
            raise typer.Exit(1) from None
        if no_browser:
            typer.echo(f"Complete your purchase at:\n{checkout_url}")
        else:
            typer.echo(f"Opening checkout for ${amount}...")
            webbrowser.open(checkout_url)
            typer.echo("Browser opened. Complete your purchase there.")
    except RuntimeError as e:
        typer.echo(f"Error: {e}", err=True)
        raise typer.Exit(1) from None
@billing_app.command("portal")
def billing_portal(
    no_browser: bool = typer.Option(
        False, "--no-browser", help="Print URL instead of opening browser"
    ),
) -> None:
    """Open Stripe billing portal.
    Manage your subscription, update payment method, or view invoices.
    Example:
        wafer billing portal
        wafer billing portal --no-browser
    """
    import webbrowser
    from .billing import get_portal_url
    try:
        result = get_portal_url()
        portal_url = result.get("portal_url")
        if not portal_url:
            typer.echo("Error: No portal URL received from API", err=True)
            raise typer.Exit(1) from None
        if no_browser:
            typer.echo(f"Billing portal:\n{portal_url}")
        else:
            typer.echo("Opening billing portal...")
            webbrowser.open(portal_url)
            typer.echo("Browser opened.")
    except RuntimeError as e:
        typer.echo(f"Error: {e}", err=True)
        raise typer.Exit(1) from None
@ssh_keys_app.command("list")
def ssh_keys_list(
    json_output: bool = typer.Option(False, "--json", "-j", help="Output as JSON"),
) -> None:
    """List all registered SSH public keys.
    Example:
        wafer settings ssh-keys list
        wafer settings ssh-keys list --json
    """
    from .ssh_keys import list_ssh_keys
    try:
        result = list_ssh_keys(json_output=json_output)
        typer.echo(result)
    except RuntimeError as e:
        if json_output:
            from .output import json_error
            typer.echo(json_error(str(e)))
        else:
            typer.echo(f"Error: {e}", err=True)
        raise typer.Exit(1) from e
@ssh_keys_app.command("add")
def ssh_keys_add(
    pubkey_path: Path | None = typer.Argument(
        None, help="Path to public key file (auto-detects ~/.ssh/id_ed25519.pub if not specified)"
    ),
    name: str | None = typer.Option(None, "--name", "-n", help="Friendly name for the key"),
    json_output: bool = typer.Option(False, "--json", "-j", help="Output as JSON"),
) -> None:
    """Add an SSH public key.
    If no path is specified, auto-detects keys from ~/.ssh/ in preference order:
    id_ed25519.pub, id_rsa.pub, id_ecdsa.pub.
    Example:
        wafer settings ssh-keys add                              # Auto-detect
        wafer settings ssh-keys add ~/.ssh/id_rsa.pub            # Specific file
        wafer settings ssh-keys add ~/.ssh/id_ed25519.pub --name laptop
    """
    from .ssh_keys import add_ssh_key
    try:
        result = add_ssh_key(pubkey_path=pubkey_path, name=name, json_output=json_output)
        typer.echo(result)
    except RuntimeError as e:
        if json_output:
            from .output import json_error
            typer.echo(json_error(str(e)))
        else:
            typer.echo(f"Error: {e}", err=True)
        raise typer.Exit(1) from e
@ssh_keys_app.command("remove")
def ssh_keys_remove(
    key_id: str = typer.Argument(..., help="UUID of the SSH key to remove"),
    json_output: bool = typer.Option(False, "--json", "-j", help="Output as JSON"),
) -> None:
    """Remove an SSH public key.
    Get the key ID from 'wafer settings ssh-keys list'.
    Example:
        wafer settings ssh-keys remove abc123-def456-...
    """
    from .ssh_keys import remove_ssh_key
    try:
        result = remove_ssh_key(key_id=key_id, json_output=json_output)
        typer.echo(result)
    except RuntimeError as e:
        if json_output:
            from .output import json_error
            typer.echo(json_error(str(e)))
        else:
            typer.echo(f"Error: {e}", err=True)
        raise typer.Exit(1) from e
@workspaces_app.command("list")
def workspaces_list(
    json_output: bool = typer.Option(False, "--json", "-j", help="Output as JSON"),
    sync: bool = typer.Option(
        False, "--sync", "-s",
        help="Live-check container statuses via SSH (slower). Without this, uses cached status.",
    ),
) -> None:
    """List all workspaces.
    By default uses cached status for fast output. Use --sync to
    live-check each workspace's container status (requires SSH to targets).
    Example:
        wafer target workspace list
        wafer target workspace list --json
        wafer target workspace list --sync
    """
    from .workspaces import list_workspaces
    try:
        result = list_workspaces(json_output=json_output, sync_status=sync)
        typer.echo(result)
    except RuntimeError as e:
        if json_output:
            from .output import json_error
            typer.echo(json_error(str(e)))
        else:
            typer.echo(f"Error: {e}", err=True)
        raise typer.Exit(1) from None
@workspaces_app.command("create")
def workspaces_create(
    name: str = typer.Argument(..., help="Workspace name"),
    gpu_type: str = typer.Option(
        "B200", "--gpu", "-g", help="GPU type: MI300X (AMD) or B200 (NVIDIA, default)"
    ),
    environment_type: str = typer.Option(
        "baremetal", "--env", "-e", help="Environment type: baremetal (default) or modal"
    ),
    image: str | None = typer.Option(None, "--image", "-i", help="Docker image (optional)"),
    wait: bool = typer.Option(
        False, "--wait", "-w", help="Wait for provisioning and show SSH credentials"
    ),
    json_output: bool = typer.Option(False, "--json", "-j", help="Output as JSON"),
) -> None:
    """Create a new workspace.
    Available GPUs:
        MI300X  AMD Instinct MI300X (192GB HBM3, ROCm)
        B200    NVIDIA Blackwell B200 (180GB HBM3e, CUDA)
    Environment Types:
        baremetal  Direct hardware access (default)
        modal      Modal.com managed environment
    Example:
        wafer target workspace create my-kernel                      # B200 baremetal (defaults)
        wafer target workspace create my-kernel --gpu MI300X         # AMD MI300X baremetal
        wafer target workspace create my-kernel --env modal          # B200 modal
        wafer target workspace create my-kernel --gpu MI300X -e modal  # AMD MI300X modal
        wafer target workspace create my-kernel --image pytorch/pytorch:2.5.1-cuda12.4-cudnn9-devel
        wafer target workspace create my-kernel --wait
    """
    from .workspaces import create_workspace
    try:
        result = create_workspace(
            name,
            gpu_type=gpu_type,
            environment_type=environment_type,
            image=image,
            wait=wait,
            json_output=json_output,
        )
        typer.echo(result)
    except RuntimeError as e:
        if json_output:
            from .output import json_error
            typer.echo(json_error(str(e)))
        else:
            typer.echo(f"Error: {e}", err=True)
        raise typer.Exit(1) from None
@workspaces_app.command("delete")
def workspaces_delete(
    workspace_id: str = typer.Argument(..., help="Workspace ID to delete"),
    yes: bool = typer.Option(False, "--yes", "-y", help="Skip confirmation prompt"),
    json_output: bool = typer.Option(False, "--json", "-j", help="Output as JSON"),
) -> None:
    """Delete a workspace.
    Example:
        wafer target workspace delete ws_abc123
        wafer target workspace delete ws_abc123 -y
    """
    from .workspaces import delete_workspace
    try:
        if not yes:
            confirm = typer.confirm(f"Delete workspace '{workspace_id}'?")
            if not confirm:
                typer.echo("Cancelled.")
                raise typer.Exit(0)
        result = delete_workspace(workspace_id, json_output=json_output)
        typer.echo(result)
    except RuntimeError as e:
        if json_output:
            from .output import json_error
            typer.echo(json_error(str(e)))
        else:
            typer.echo(f"Error: {e}", err=True)
        raise typer.Exit(1) from None
@workspaces_app.command("show")
def workspaces_show(
    workspace_id: str = typer.Argument(..., help="Workspace ID to show"),
    json_output: bool = typer.Option(False, "--json", "-j", help="Output as JSON"),
) -> None:
    """Show details of a workspace.
    Example:
        wafer target workspace show ws_abc123
        wafer target workspace show ws_abc123 --json
    """
    from .workspaces import get_workspace
    try:
        result = get_workspace(workspace_id, json_output=json_output)
        typer.echo(result)
    except RuntimeError as e:
        if json_output:
            from .output import json_error
            typer.echo(json_error(str(e)))
        else:
            typer.echo(f"Error: {e}", err=True)
        raise typer.Exit(1) from None
@workspaces_app.command(
    "exec",
    context_settings={
        "allow_interspersed_args": False,
        "ignore_unknown_options": True,
        "allow_extra_args": True,
    },
)
def workspaces_exec(
    ctx: typer.Context,
    workspace: str | None = typer.Argument(
        None, help="Workspace name or ID (optional if default set)"
    ),
    timeout: int | None = typer.Option(
        None,
        "--timeout",
        "-t",
        help="Execution timeout in seconds (default: from config or 300)",
    ),
    sync: Path | None = typer.Option(
        None,
        "--sync",
        "-s",
        help="Sync local directory to workspace before executing",
    ),
    gpu: bool = typer.Option(False, "--gpu", help="Force GPU routing (default behavior)"),
    cpu: bool = typer.Option(False, "--cpu", help="Run in workspace container (no GPU)"),
    baremetal: bool = typer.Option(
        False, "--baremetal", help="Force baremetal target (for hardware counters like ncu/nsys)"
    ),
    pull_image: bool = typer.Option(False, "--pull-image", help="Pull image on target if missing"),
    verbose: bool = typer.Option(False, "--verbose", "-v", help="Show [wafer] status messages"),
    quiet: bool = typer.Option(False, "--quiet", "-q", help="Suppress [wafer] status messages"),
) -> None:
    """Execute a command in workspace.

    Auto-detects GPU vs CPU routing. Override with --gpu, --cpu, or --baremetal.

    Examples:
        wafer target workspace exec dev -- python train.py
        wafer target workspace exec -- python train.py             # uses default workspace
        wafer target workspace exec dev --sync . -- python train.py  # sync first, then run
    """
    from .global_config import get_defaults, get_preferences
    from .workspaces import exec_command, resolve_workspace, sync_files
    # Enforce option ordering to avoid treating CLI flags as remote commands
    known_options = {
        "--timeout",
        "-t",
        "--sync",
        "-s",
        "--gpu",
        "--cpu",
        "--baremetal",
        "--pull-image",
        "--verbose",
        "-v",
        "--quiet",
        "-q",
        "--help",
        "-h",
    }
    for arg in ctx.args:
        if arg == "--":
            break
        if arg in known_options:
            typer.echo(
                "Error: options must come before the workspace name. "
                "Example: wafer target workspace exec --pull-image dev -- python -V",
                err=True,
            )
            raise typer.Exit(1)
    # Validate mutually exclusive routing flags
    routing_flags = sum([gpu, cpu, baremetal])
    if routing_flags > 1:
        typer.echo("Error: --gpu, --cpu, and --baremetal are mutually exclusive", err=True)
        raise typer.Exit(1)

    routing: str | None = None
    if gpu:
        routing = "gpu"
    elif cpu:
        routing = "cpu"
    elif baremetal:
        routing = "baremetal"
    # Resolve workspace (specified, config default, or single workspace)
    try:
        resolved_workspace = resolve_workspace(workspace)
    except RuntimeError as e:
        typer.echo(f"Error: {e}", err=True)
        raise typer.Exit(1) from None
    effective_timeout = timeout
    if effective_timeout is None:
        defaults = get_defaults()
        effective_timeout = defaults.exec_timeout

    # --quiet flag overrides mode, --verbose flag forces verbose
    prefs = get_preferences()
    if quiet:
        show_status = False
    elif verbose:
        show_status = True
    else:
        show_status = prefs.mode == "explicit"
    if show_status:
        routing_label = routing or "auto"
        typer.echo(f"[wafer] Workspace: {resolved_workspace} (routing: {routing_label})", err=True)
    # Sync files if requested
    if sync is not None:
        if not sync.exists():
            typer.echo(f"Error: Sync path not found: {sync}", err=True)
            raise typer.Exit(1)
        if not sync.is_dir():
            typer.echo(f"Error: Sync path is not a directory: {sync}", err=True)
            raise typer.Exit(1)
        if show_status:
            typer.echo(f"[wafer] Syncing {sync}...", err=True)
        def on_progress(msg: str) -> None:
            if show_status:
                typer.echo(f"[wafer] {msg}", err=True)
        try:
            file_count, warning = sync_files(
                resolved_workspace, sync.resolve(), on_progress=on_progress
            )
        except RuntimeError as e:
            typer.echo(f"Error: {e}", err=True)
            raise typer.Exit(1) from None
    import shlex
    command = list(ctx.args)
    if command and command[0] == "--":
        command = command[1:]
    if not command:
        typer.echo("Error: No command specified", err=True)
        raise typer.Exit(1)
    if show_status:
        typer.echo(f"[wafer] Executing (timeout: {effective_timeout}s)...", err=True)
    # 1. Single element: user quoted the whole command (e.g., "echo hello world")
    #    -> use directly, don't re-quote
    # 2. Multiple elements: user passed separate args (e.g., -- python -c "print(1)")
    #    -> use shlex.join to properly quote args with spaces
    if len(command) == 1:
        command_str = command[0]
    else:
        command_str = shlex.join(command)
    try:
        exit_code = exec_command(
            workspace_id=resolved_workspace,
            command=command_str,
            timeout_seconds=effective_timeout,
            routing=routing,
            pull_image=pull_image,
        )
    except RuntimeError as e:
        typer.echo(f"Error: {e}", err=True)
        raise typer.Exit(1) from None
    if show_status:
        typer.echo(f"[wafer] Exit code: {exit_code}", err=True)
    raise typer.Exit(exit_code)
@workspaces_app.command("ssh")
def workspaces_ssh(
    workspace: str | None = typer.Argument(
        None, help="Workspace name or ID (optional if default set)"
    ),
) -> None:
    """SSH into a workspace.
    Examples:
        wafer target workspace ssh dev
        wafer target workspace ssh           # uses default workspace
    """
    import os
    from .workspaces import get_workspace_raw, resolve_workspace
    # Resolve workspace name/ID
    try:
        resolved_workspace = resolve_workspace(workspace)
    except RuntimeError as e:
        typer.echo(f"Error: {e}", err=True)
        raise typer.Exit(1) from None
    try:
        ws = get_workspace_raw(resolved_workspace)
    except RuntimeError as e:
        typer.echo(f"Error: {e}", err=True)
        raise typer.Exit(1) from None
    ssh_host = ws.get("ssh_host")
    ssh_port = ws.get("ssh_port")
    ssh_user = ws.get("ssh_user")
    if not ssh_host or not ssh_port or not ssh_user:
        typer.echo("Error: Workspace not ready. Wait a few seconds and retry.", err=True)
        raise typer.Exit(1)
    # Connect via SSH
    os.execvp(
        "ssh",
        [
            "ssh",
            "-p",
            str(ssh_port),
            "-o",
            "StrictHostKeyChecking=no",
            "-o",
            "UserKnownHostsFile=/dev/null",
            f"{ssh_user}@{ssh_host}",
        ],
    )
@workspaces_app.command("sync")
def workspaces_sync(
    workspace: str | None = typer.Argument(
        None, help="Workspace name or ID (optional if default set)"
    ),
    path: Path = typer.Argument(..., help="Local file or directory to sync"),
    verbose: bool = typer.Option(False, "--verbose", "-v", help="Show [wafer] status messages"),
    quiet: bool = typer.Option(False, "--quiet", "-q", help="Suppress [wafer] status messages"),
) -> None:
    """Sync local files to workspace.
    Uses rsync over SSH to sync files to the workspace's /workspace directory.
    If workspace is not specified, uses the default workspace.
    Syncing behavior:
    - Directories: syncs contents into /workspace/ (files appear at /workspace/*.py)
    - Single file: syncs the file itself to /workspace/filename
    Examples:
        wafer target workspace sync dev ./my-project    # Files → /workspace/*.py
        wafer target workspace sync ./my-project        # uses default workspace
        wafer target workspace sync dev .               # sync current directory contents
        wafer target workspace sync dev ./script.py     # File → /workspace/script.py
    """
    from .global_config import get_preferences
    from .workspaces import resolve_workspace, sync_files

    prefs = get_preferences()
    if quiet:
        show_status = False
    elif verbose:
        show_status = True
    else:
        show_status = prefs.mode == "explicit"
    # Validate path
    if not path.exists():
        typer.echo(f"Error: Path not found: {path}", err=True)
        raise typer.Exit(1)
    # Resolve workspace
    try:
        resolved_workspace = resolve_workspace(workspace)
    except RuntimeError as e:
        typer.echo(f"Error: {e}", err=True)
        raise typer.Exit(1) from None

    if path.is_file():
        dest_path = f"/workspace/{path.name}"
    else:
        dest_path = "/workspace/"
    if show_status:
        typer.echo(f"[wafer] Syncing {path} → {dest_path} (workspace: {resolved_workspace})", err=True)
    def on_progress(msg: str) -> None:
        if show_status:
            typer.echo(f"[wafer] {msg}", err=True)
    try:
        file_count, warning = sync_files(
            resolved_workspace, path.resolve(), on_progress=on_progress
        )
        # Show helpful tip after successful sync
        if show_status and file_count > 0:
            typer.echo(
                f"\n[wafer] Tip: Synced files are in /workspace/\n"
                f"[wafer] \n"
                f"[wafer]      Python/pip commands:  Work from /workspace automatically\n"
                f"[wafer]      Shell commands:       Start in /home/wafer (use absolute paths)\n"
                f"[wafer] \n"
                f"[wafer]      Examples:\n"
                f"[wafer]        wafer exec ws -- python script.py          ← runs /workspace/script.py\n"
                f"[wafer]        wafer exec ws -- ls                        ← lists /home/wafer\n"
                f"[wafer]        wafer exec ws -- ls /workspace             ← lists /workspace\n"
                f"[wafer]        wafer exec ws -- 'cd /workspace && ls'     ← lists /workspace",
                err=True
            )
    except RuntimeError as e:
        typer.echo(f"Error: {e}", err=True)
        raise typer.Exit(1) from None
@workspaces_app.command("pull")
def workspaces_pull(
    workspace: str = typer.Argument(..., help="Workspace name or ID"),
    remote_path: str = typer.Argument(
        ..., help="Remote path in workspace (relative to /workspace or absolute)"
    ),
    local_path: Path = typer.Argument(
        Path("."), help="Local destination path (default: current directory)"
    ),
    verbose: bool = typer.Option(False, "--verbose", "-v", help="Show [wafer] status messages"),
    quiet: bool = typer.Option(False, "--quiet", "-q", help="Suppress [wafer] status messages"),
) -> None:
    """Pull files from workspace to local machine.
    Uses rsync over SSH to download files from the workspace's /workspace directory.
    Examples:
        wafer target workspace pull dev kernel.py ./           # Pull single file
        wafer target workspace pull dev kernel.py ./my_kernel.py  # Pull and rename
        wafer target workspace pull dev /workspace/results ./  # Pull directory
    """
    from .global_config import get_preferences
    from .workspaces import pull_files

    prefs = get_preferences()
    if quiet:
        show_status = False
    elif verbose:
        show_status = True
    else:
        show_status = prefs.mode == "explicit"
    if show_status:
        typer.echo(f"[wafer] Pulling {remote_path} from workspace {workspace}...", err=True)
    def on_progress(msg: str) -> None:
        if show_status:
            typer.echo(f"[wafer] {msg}", err=True)
    try:
        file_count = pull_files(
            workspace, remote_path, local_path.resolve(), on_progress=on_progress
        )
        if show_status:
            typer.echo(f"[wafer] Pulled {file_count} files to {local_path}", err=True)
    except RuntimeError as e:
        typer.echo(f"Error: {e}", err=True)
        raise typer.Exit(1) from None
@targets_ops_app.command("exec", context_settings={"allow_interspersed_args": False})
def targets_exec(
    target: str = typer.Argument(
        ...,
        help="Target name",
        autocompletion=complete_target_name,
    ),
    command: list[str] = typer.Argument(..., help="Command to execute"),
    timeout: int | None = typer.Option(
        None,
        "--timeout",
        "-t",
        help="Execution timeout in seconds (default: 300)",
    ),
    verbose: bool = typer.Option(False, "--verbose", "-v", help="Show [wafer] status messages"),
    quiet: bool = typer.Option(False, "--quiet", "-q", help="Suppress [wafer] status messages"),
) -> None:
    """Execute a command on a configured target.

    Provisions cloud targets if needed, then runs via SSH.

    Examples:
        wafer tool exec my-gpu -- python train.py
        wafer tool exec my-gpu -- nvidia-smi
    """
    from .global_config import get_preferences
    from .targets import load_target
    from .targets_ops import TargetExecError, exec_on_target_sync, get_target_ssh_info

    prefs = get_preferences()
    if quiet:
        show_status = False
    elif verbose:
        show_status = True
    else:
        show_status = prefs.mode == "explicit"
    try:
        target_config = load_target(target)
    except FileNotFoundError as e:
        typer.echo(f"Error: {e}", err=True)
        typer.echo("List available targets with: wafer target config list", err=True)
        raise typer.Exit(1) from None
    except ValueError as e:
        typer.echo(f"Error loading target config: {e}", err=True)
        raise typer.Exit(1) from None
    if show_status:
        typer.echo(f"[wafer] Target: {target} ({type(target_config).__name__})", err=True)
    if show_status:
        typer.echo("[wafer] Connecting to target...", err=True)
    try:
        ssh_info = trio.run(get_target_ssh_info, target_config)
    except TargetExecError as e:
        typer.echo(f"Error: {e}", err=True)
        raise typer.Exit(1) from None
    if show_status:
        typer.echo(f"[wafer] Connected: {ssh_info.user}@{ssh_info.host}:{ssh_info.port}", err=True)
    if isinstance(command, list):
        import shlex
        # Remove leading "--" if present
        if command and command[0] == "--":
            command = command[1:]
        if not command:
            typer.echo("Error: No command specified", err=True)
            raise typer.Exit(1)
        if len(command) == 1:
            command_str = command[0]
        else:
            command_str = shlex.join(command)
    else:
        command_str = command
    # Default timeout
    effective_timeout = timeout if timeout is not None else 300
    if show_status:
        typer.echo(f"[wafer] Executing (timeout: {effective_timeout}s)...", err=True)
    # Execute
    try:
        exit_code = exec_on_target_sync(ssh_info, command_str, effective_timeout)
    except TargetExecError as e:
        typer.echo(f"Error: {e}", err=True)
        raise typer.Exit(1) from None
    if show_status:
        typer.echo(f"[wafer] Exit code: {exit_code}", err=True)
    raise typer.Exit(exit_code)
@perfetto_app.command("query")
def perfetto_query(
    trace_path: Path = typer.Argument(..., help="Path to Perfetto trace file"),
    sql: str = typer.Argument(..., help="SQL query to execute"),
    json_output: bool = typer.Option(True, "--json", "-j", help="Output as JSON"),
) -> None:
    """Execute SQL query against a Perfetto trace.
    Starts trace_processor, loads the trace, executes the query, and returns results.
    Examples:
        wafer perfetto query trace.perfetto "SELECT * FROM slice LIMIT 10"
        wafer perfetto query trace.perfetto "SELECT name, dur FROM slice ORDER BY dur DESC LIMIT 5"
    """
    from wafer_core.lib.perfetto.perfetto_tool import PerfettoConfig, PerfettoTool
    config = PerfettoConfig(
        workspace_root=".",
        storage_dir=str(Path.home() / ".wafer" / "perfetto"),
    )
    tool = PerfettoTool(config)
    try:
        results, err = tool.query(sql, str(trace_path))
        if err:
            typer.echo(f"Error: {err}", err=True)
            raise typer.Exit(1)
        if json_output:
            from .output import json_response
            typer.echo(json_response(data={"results": results, "count": len(results or [])}))
        else:
            if not results:
                typer.echo("No results")
            else:
                # Simple table output
                if results:
                    headers = list(results[0].keys())
                    typer.echo("\t".join(headers))
                    for row in results:
                        typer.echo("\t".join(str(row.get(h, "")) for h in headers))
    except Exception as e:
        typer.echo(f"Error: {e}", err=True)
        raise typer.Exit(1) from None
# Common tables for --common flag (most useful for trace analysis)
COMMON_PERFETTO_TABLES = [
    "slice",
    "track",
    "thread",
    "process",
    "thread_track",
    "process_track",
    "counter",
    "counter_track",
    "sched_slice",
    "gpu_slice",
]
@perfetto_app.command("tables")
def perfetto_tables(
    trace_path: Path = typer.Argument(..., help="Path to Perfetto trace file"),
    common: bool = typer.Option(False, "--common", help="Show commonly used tables (default)"),
    tables_filter: str | None = typer.Option(
        None, "--tables", "-t", help="Comma-separated list of table names to show"
    ),
    all_tables: bool = typer.Option(False, "--all", help="Show all tables (including internal)"),
    json_output: bool = typer.Option(False, "--json", "-j", help="Output as JSON"),
) -> None:
    """List available tables in a Perfetto trace.
    Examples:
        wafer tool perfetto tables trace.json              # shows common tables (default)
        wafer tool perfetto tables trace.json --tables slice,track,thread
        wafer tool perfetto tables trace.json --all
    """
    from wafer_core.lib.perfetto.perfetto_tool import PerfettoConfig, PerfettoTool
    # Default to --common if no filter specified
    flag_count = sum([common, tables_filter is not None, all_tables])
    if flag_count == 0:
        common = True
        flag_count = 1
    if flag_count > 1:
        typer.echo("Error: Use only one of --common, --tables, or --all", err=True)
        raise typer.Exit(1)
    config = PerfettoConfig(
        workspace_root=".",
        storage_dir=str(Path.home() / ".wafer" / "perfetto"),
    )
    tool = PerfettoTool(config)
    try:
        all_table_names, err = tool.get_tables(str(trace_path))
        if err:
            typer.echo(f"Error: {err}", err=True)
            raise typer.Exit(1)
        all_table_names = all_table_names or []
        if all_tables:
            filtered = all_table_names
        elif common:
            # Show common tables that exist in this trace
            filtered = [t for t in COMMON_PERFETTO_TABLES if t in all_table_names]
        else:
            # --tables flag
            requested = [t.strip() for t in (tables_filter or "").split(",") if t.strip()]
            filtered = [t for t in requested if t in all_table_names]
            missing = [t for t in requested if t not in all_table_names]
            if missing:
                typer.echo(f"Warning: Tables not found: {', '.join(missing)}", err=True)
        if json_output:
            from .output import json_response
            typer.echo(json_response(data={"tables": filtered}))
        else:
            typer.echo(f"Found {len(filtered)} tables:")
            for table in filtered:
                typer.echo(f"  {table}")
    except Exception as e:
        typer.echo(f"Error: {e}", err=True)
        raise typer.Exit(1) from None
@perfetto_app.command("schema")
def perfetto_schema(
    trace_path: Path = typer.Argument(..., help="Path to Perfetto trace file"),
    table: str = typer.Argument(..., help="Table name"),
    json_output: bool = typer.Option(False, "--json", "-j", help="Output as JSON"),
) -> None:
    """Get schema for a table in a Perfetto trace.
    Examples:
        wafer perfetto schema trace.perfetto slice
        wafer perfetto schema trace.perfetto thread --json
    """
    from wafer_core.lib.perfetto.perfetto_tool import PerfettoConfig, PerfettoTool
    config = PerfettoConfig(
        workspace_root=".",
        storage_dir=str(Path.home() / ".wafer" / "perfetto"),
    )
    tool = PerfettoTool(config)
    try:
        columns, err = tool.get_schema(table, str(trace_path))
        if err:
            typer.echo(f"Error: {err}", err=True)
            raise typer.Exit(1)
        if json_output:
            from .output import json_response
            typer.echo(json_response(data={"table": table, "columns": columns}))
        else:
            typer.echo(f"Schema for table '{table}':")
            for col in columns or []:
                nullable = "NULL" if col.get("nullable") else "NOT NULL"
                typer.echo(f"  {col['name']}: {col['type']} {nullable}")
    except Exception as e:
        typer.echo(f"Error: {e}", err=True)
        raise typer.Exit(1) from None
@perfetto_app.command("check")
def perfetto_check(
    json_output: bool = typer.Option(False, "--json", "-j", help="Output as JSON"),
) -> None:
    """Check if trace_processor is available.
    Examples:
        wafer perfetto check
        wafer perfetto check --json
    """
    from wafer_core.lib.perfetto.perfetto_tool import PerfettoConfig, PerfettoTool
    config = PerfettoConfig(
        workspace_root=".",
        storage_dir=str(Path.home() / ".wafer" / "perfetto"),
    )
    tool = PerfettoTool(config)
    status = tool.check_processor()
    if json_output:
        from .output import json_response
        typer.echo(json_response(data=status.to_dict()))
    else:
        if status.available:
            typer.echo(f"✓ trace_processor available at {status.binary_path}")
            typer.echo(f"  Version: {status.version}")
            if not status.version_matches_ui:
                typer.echo(f"  ⚠ Version mismatch with UI (expected: {status.ui_version})")
        else:
            typer.echo(f"✗ trace_processor not available: {status.error}")
            typer.echo("  Run 'wafer perfetto check' to auto-download")
@ncu_app.command("analyze")
def ncu_analyze(
    filepath: Path = typer.Argument(..., help="Path to .ncu-rep profile file"),
    output_dir: Path | None = typer.Option(
        None, "--output-dir", "-o", help="Output directory for analysis files"
    ),
    json_output: bool = typer.Option(
        False, "--json", "-j", help="Output raw JSON instead of formatted text"
    ),
    remote: bool | None = typer.Option(
        None,
        "--remote/--local",
        help="Force remote (via API) or local analysis. Default: auto-detect (remote if NCU not installed locally)",
    ),
    target: str | None = typer.Option(
        None,
        "--target",
        "-t",
        help="Target for direct SSH mode. See 'wafer target config list'.",
    ),
    include_source: bool = typer.Option(
        False,
        "--include-source",
        "-s",
        help="Include SASS source correlation for each kernel (requires --remote)",
    ),
) -> None:
    """Analyze an NVIDIA Nsight Compute profile (.ncu-rep file).
    Returns kernel performance metrics including duration, occupancy,
    compute/memory throughput, and optimization recommendations.
    By default, uses local NCU if available, otherwise runs analysis
    remotely via wafer-api (requires authentication: wafer settings login).
    Use --target for direct SSH mode (like wafer remote-run --direct).
    Use --include-source to fetch SASS assembly with register/instruction data.
    Examples:
        wafer tool ncu analyze profile.ncu-rep
        wafer tool ncu analyze profile.ncu-rep --json
        wafer tool ncu analyze profile.ncu-rep --output-dir ./analysis
        wafer tool ncu analyze profile.ncu-rep --remote
        wafer tool ncu analyze profile.ncu-rep --target vultr-b200
        wafer tool ncu analyze profile.ncu-rep --include-source --json
    """
    from .ncu_analyze import analyze_ncu_profile
    if not filepath.exists():
        if json_output:
            from .output import json_error
            typer.echo(json_error(f"File not found: {filepath}"))
        else:
            typer.echo(f"Error: File not found: {filepath}", err=True)
        raise typer.Exit(1)
    if filepath.suffix != ".ncu-rep":
        if json_output:
            from .output import json_error
            typer.echo(json_error(f"Expected .ncu-rep file, got: {filepath.suffix}"))
        else:
            typer.echo(f"Error: Expected .ncu-rep file, got: {filepath.suffix}", err=True)
        raise typer.Exit(1)
    try:
        result = analyze_ncu_profile(
            filepath,
            output_dir=output_dir,
            json_output=json_output,
            remote=remote,
            target=target,
            include_source=include_source,
        )
        typer.echo(result)
    except (FileNotFoundError, RuntimeError) as e:
        if json_output:
            from .output import json_error
            typer.echo(json_error(str(e)))
        else:
            typer.echo(f"Error: {e}", err=True)
        raise typer.Exit(1) from None
@ncu_app.command("run", context_settings={"allow_interspersed_args": False})
def ncu_run_cmd(
    command: list[str] = typer.Argument(..., help="Command to profile (e.g., python run.py)"),
    directory: Path = typer.Option(
        ".", "--dir", "-d", help="Directory to upload (default: current directory)"
    ),
    ncu_args: str = typer.Option(
        "", "--ncu-args", help='Extra NCU flags (e.g., "--set full --kernel-name mykernel")'
    ),
    requirements: Path | None = typer.Option(
        None, "--requirements", "-r", help="requirements.txt to install before profiling"
    ),
    output: Path | None = typer.Option(
        None, "--output", "-o", help="Local path to save .ncu-rep report"
    ),
    no_download: bool = typer.Option(
        False, "--no-download", help="Skip downloading the .ncu-rep report"
    ),
    exclude: list[str] | None = typer.Option(
        None, "--exclude", "-e", help="Glob patterns to exclude from upload"
    ),
    timeout: int = typer.Option(
        600, "--timeout", "-t", help="Max execution time in seconds (default: 600)"
    ),
    queue_timeout: int = typer.Option(
        300, "--queue-timeout", help="Max time to wait for GPU if all are busy (default: 300s)"
    ),
) -> None:
    """Run NCU profiling remotely on a wafer B200 GPU.
    Packages your code directory, uploads it to a B200 machine with hardware
    counter access, runs NCU on your command, and downloads the .ncu-rep report.

    GPU scheduling: B200 GPUs are shared with workspaces. If all GPUs are
    busy, your job enters a FIFO queue with position updates. Use
    --queue-timeout to control how long to wait (default: 5 minutes).

    Your directory is uploaded respecting .gitignore (if in a git repo).
    If a requirements.txt is found in the directory, dependencies are installed
    automatically before profiling.
    Examples:
        wafer tool ncu run python run.py
        wafer tool ncu run --dir ./src python run.py
        wafer tool ncu run --ncu-args="--set full" python run.py
        wafer tool ncu run --output profile.ncu-rep python run.py
        wafer tool ncu run --no-download python run.py
        wafer tool ncu run --exclude "*.dat" --exclude "data/" python run.py
    """
    from .ncu_run import ncu_run
    if not command:
        typer.echo("Error: No command provided.", err=True)
        raise typer.Exit(1)
    if not directory.exists():
        typer.echo(f"Error: Directory not found: {directory}", err=True)
        raise typer.Exit(1)
    if not directory.is_dir():
        typer.echo(f"Error: Not a directory: {directory}", err=True)
        raise typer.Exit(1)
    try:
        exit_code = ncu_run(
            command=command,
            directory=directory,
            ncu_args=ncu_args,
            requirements=requirements,
            output=output,
            no_download=no_download,
            exclude=exclude,
            timeout=timeout,
            queue_timeout=queue_timeout,
        )
        raise typer.Exit(exit_code)
    except typer.Exit:
        raise
    except KeyboardInterrupt:
        typer.echo("\nInterrupted by user", err=True)
        raise typer.Exit(130) from None
    except Exception as e:
        typer.echo(f"Error: {e}", err=True)
        raise typer.Exit(1) from None
@nsys_app.command("analyze")
def nsys_analyze(
    filepath: Path = typer.Argument(..., help="Path to .nsys-rep profile file"),
    output_dir: Path | None = typer.Option(
        None, "--output-dir", "-o", help="Output directory for analysis files"
    ),
    json_output: bool = typer.Option(
        False, "--json", "-j", help="Output raw JSON instead of formatted text"
    ),
    remote: bool | None = typer.Option(
        None,
        "--remote/--local",
        help="Force remote (via API) or local analysis. Default: auto-detect (remote if nsys not installed locally)",
    ),
    target: str | None = typer.Option(
        None,
        "--target",
        "-t",
        help="Remote target: 'workspace:id' for workspace execution, or target name from ~/.wafer/targets/",
    ),
) -> None:
    """Analyze an NVIDIA Nsight Systems profile (.nsys-rep file).
    Returns timeline events, kernel information, memory usage, and diagnostics.
    By default, uses local nsys if available, otherwise runs analysis
    remotely via wafer-api (requires authentication: wafer settings login).
    Supports multiple execution modes:
    - Local: Uses local nsys CLI (no GPU required for analysis)
    - Remote API: Uploads file and runs analysis on Modal
    - Workspace: Runs analysis on a Wafer workspace via SSH
    - Target: Runs analysis on a configured target machine via SSH
    Examples:
        wafer tool nsys analyze profile.nsys-rep
        wafer tool nsys analyze profile.nsys-rep --json
        wafer tool nsys analyze profile.nsys-rep --local
        wafer tool nsys analyze profile.nsys-rep --remote
        wafer tool nsys analyze profile.nsys-rep --target workspace:abc123
        wafer tool nsys analyze profile.nsys-rep --target vultr-b200
        wafer tool nsys analyze profile.nsys-rep -o ./results/
    """
    from .nsys_analyze import analyze_nsys_profile
    if not filepath.exists():
        typer.echo(f"Error: File not found: {filepath}", err=True)
        raise typer.Exit(1)
    if filepath.suffix != ".nsys-rep":
        typer.echo(f"Error: Expected .nsys-rep file, got: {filepath.suffix}", err=True)
        raise typer.Exit(1)
    # Warn if both remote flag and target are specified
    if target and remote is not None:
        typer.echo(
            "Warning: --target overrides --remote/--local flag",
            err=True,
        )
    try:
        result = analyze_nsys_profile(
            filepath,
            json_output=json_output,
            remote=remote,
            target=target,
            output_dir=output_dir,
        )
        typer.echo(result)
    except FileNotFoundError as e:
        typer.echo(f"Error: {e}", err=True)
        raise typer.Exit(1) from None
    except (RuntimeError, ValueError, NotImplementedError) as e:
        typer.echo(f"Error: {e}", err=True)
        raise typer.Exit(1) from None
@nsys_app.command("profile", context_settings={"allow_interspersed_args": False})
def nsys_profile(
    command: list[str] = typer.Argument(..., help="Command to profile"),
    output: str = typer.Option(
        "profile",
        "--output",
        "-o",
        help="Output filename (without .nsys-rep extension)",
    ),
    trace: str | None = typer.Option(
        None,
        "--trace",
        "-t",
        help="Trace APIs to capture (comma-separated: cuda,nvtx,osrt,cudnn,cublas). Default: cuda",
    ),
    duration: int | None = typer.Option(
        None,
        "--duration",
        "-d",
        help="Maximum profiling duration in seconds",
    ),
    target: str | None = typer.Option(
        None,
        "--target",
        help="Remote target: 'workspace:id' for workspace execution, or target name from ~/.wafer/targets/",
    ),
    analyze: bool = typer.Option(
        False,
        "--analyze",
        "-a",
        help="Automatically analyze the profile after completion",
    ),
    json_output: bool = typer.Option(
        False,
        "--json",
        "-j",
        help="Output analysis as JSON (only with --analyze)",
    ),
    verbose: bool = typer.Option(
        False,
        "--verbose",
        "-v",
        help="Show verbose progress messages",
    ),
    extra_args: str | None = typer.Option(
        None,
        "--extra",
        help="Extra arguments to pass to nsys profile",
    ),
) -> None:
    """Profile a command with NVIDIA Nsight Systems.
    Runs nsys profile on the specified command and generates a .nsys-rep file.
    Profiling requires an NVIDIA GPU. Use --target to run on a remote GPU server
    or workspace.
    Examples:
        wafer tool nsys profile -- python train.py
        wafer tool nsys profile -o gemm_profile -- ./gemm_kernel
        wafer tool nsys profile --trace cuda,nvtx -- python model.py
        wafer tool nsys profile --duration 60 -- ./long_running_app
        wafer tool nsys profile --target workspace:abc123 -- python test.py
        wafer tool nsys profile --target vultr-b200 -- ./benchmark
        wafer tool nsys profile --analyze -- python train.py
        wafer tool nsys profile --analyze --json -- ./kernel > results.json
    """
    import shlex
    from .nsys_analyze import _parse_target
    from .nsys_profile import (
        NSYSProfileOptions,
        profile_and_analyze,
        profile_local,
        profile_remote_ssh,
        profile_workspace,
    )
    if isinstance(command, list):
        # Remove leading "--" if present
        if command and command[0] == "--":
            command = command[1:]
        if len(command) == 1:
            command_str = command[0]
        else:
            command_str = shlex.join(command)
    else:
        command_str = command
    if not command_str:
        typer.echo("Error: No command specified", err=True)
        raise typer.Exit(1)
    trace_list = trace.split(",") if trace else None
    options = NSYSProfileOptions(
        command=command_str,
        output=output,
        trace=trace_list,
        duration=duration,
        extra_args=extra_args,
    )
    if verbose:
        typer.echo(f"[nsys] Command: {command_str}", err=True)
        if target:
            typer.echo(f"[nsys] Target: {target}", err=True)
    # Execute
    if analyze:
        profile_result, analysis_result = profile_and_analyze(
            options,
            target=target,
            json_output=json_output,
            verbose=verbose,
        )
    else:
        if target:
            target_type, target_id = _parse_target(target)
            if target_type == "workspace":
                profile_result = profile_workspace(target_id, options, verbose=verbose)
            else:
                profile_result = profile_remote_ssh(target_id, options, verbose=verbose)
        else:
            profile_result = profile_local(options, verbose=verbose)
        analysis_result = None
    # Report results
    if not profile_result.success:
        typer.echo(f"Error: {profile_result.error}", err=True)
        if profile_result.stderr:
            typer.echo(f"stderr: {profile_result.stderr}", err=True)
        raise typer.Exit(1)
    if verbose or not analyze:
        typer.echo(f"Profile created: {profile_result.output_path}")
    if analysis_result:
        if not analysis_result.success:
            typer.echo(f"Analysis error: {analysis_result.error}", err=True)
            raise typer.Exit(1)
rocprof_sdk_app = typer.Typer(help="ROCprofiler-SDK profiling tool commands")
tool_app.add_typer(rocprof_sdk_app, name="rocprof-sdk", rich_help_panel="AMD Profiling")
@rocprof_sdk_app.command("list-counters")
def rocprof_sdk_list_counters() -> None:
    """List available hardware counters for your GPU.
    Examples:
        wafer rocprof-sdk list-counters
        wafer rocprof-sdk list-counters | grep SQ_
    """
    from .rocprof_sdk import list_counters_command
    try:
        list_counters_command()
    except Exception as e:
        typer.echo(f"Error: {e}", err=True)
        raise typer.Exit(1) from None
@rocprof_sdk_app.command("profile")
def rocprof_sdk_profile(
    command: str = typer.Argument(..., help="Command to profile"),
    output_dir: str | None = typer.Option(None, "--output-dir", "-o", help="Output directory"),
    output_format: str = typer.Option(
        "csv", "--format", "-f", help="Output format (csv, json, rocpd, pftrace, otf2)"
    ),
    counters: str | None = typer.Option(
        None, "--counters", "-c", help="Comma-separated hardware counters"
    ),
    kernel_include: str | None = typer.Option(
        None, "--kernel-include", help="Include only kernels matching this regex"
    ),
    kernel_exclude: str | None = typer.Option(
        None, "--kernel-exclude", help="Exclude kernels matching this regex"
    ),
    trace_hip_runtime: bool = typer.Option(
        False, "--trace-hip-runtime", help="Enable HIP runtime API tracing"
    ),
    trace_hip_compiler: bool = typer.Option(
        False, "--trace-hip-compiler", help="Enable HIP compiler code tracing"
    ),
    trace_hsa: bool = typer.Option(False, "--trace-hsa", help="Enable HSA API tracing"),
    trace_marker: bool = typer.Option(False, "--trace-marker", help="Enable ROCTx marker tracing"),
    trace_memory_copy: bool = typer.Option(
        False, "--trace-memory-copy", help="Enable memory copy tracing"
    ),
    json_output: bool = typer.Option(False, "--json", "-j", help="Output as JSON"),
) -> None:
    """Profile a command with rocprofv3.
    Examples:
        wafer rocprof-sdk profile './my_kernel'
        wafer rocprof-sdk profile './app' --format csv --output-dir ./results
        wafer rocprof-sdk profile './kernel' --counters SQ_WAVES,L2_CACHE_HITS
        wafer rocprof-sdk profile './app' --kernel-include 'vectorAdd|matmul'
        wafer rocprof-sdk profile './app' --trace-hip-runtime --trace-memory-copy
    """
    from .rocprof_sdk import profile_command
    counter_list = counters.split(",") if counters else None
    try:
        result = profile_command(
            command,
            output_dir,
            output_format,
            counter_list,
            kernel_include,
            kernel_exclude,
            trace_hip_runtime,
            trace_hip_compiler,
            trace_hsa,
            trace_marker,
            trace_memory_copy,
            json_output,
        )
        if json_output:
            typer.echo(result)
    except Exception as e:
        typer.echo(f"Error: {e}", err=True)
        raise typer.Exit(1) from None
@rocprof_sdk_app.command("analyze")
def rocprof_sdk_analyze(
    file_path: Path = typer.Argument(
        ..., help="Path to rocprofiler output file (.csv, .json, .db)"
    ),
    json_output: bool = typer.Option(False, "--json", "-j", help="Output as JSON"),
) -> None:
    """Analyze a rocprofiler output file.
    Supports:
    - CSV stats files (stats_*.csv)
    - JSON trace files (*.json)
    - rocpd databases (*_results.db, *.rocpd)
    Examples:
        wafer rocprof-sdk analyze stats_kernel.csv
        wafer rocprof-sdk analyze results.json
        wafer rocprof-sdk analyze profile_results.db --json
    """
    from .rocprof_sdk import analyze_command
    if not file_path.exists():
        typer.echo(f"Error: File not found: {file_path}", err=True)
        raise typer.Exit(1)
    try:
        result = analyze_command(str(file_path), json_output)
        if json_output:
            typer.echo(result)
    except Exception as e:
        typer.echo(f"Error: {e}", err=True)
        raise typer.Exit(1) from None
rocprof_systems_app = typer.Typer(help="ROCprofiler-Systems profiling tool commands")
tool_app.add_typer(rocprof_systems_app, name="rocprof-systems", rich_help_panel="AMD Profiling")
@rocprof_systems_app.command("run")
def rocprof_systems_run(
    command: str = typer.Argument(..., help="Command to profile"),
    output_dir: str | None = typer.Option(None, "--output-dir", "-o", help="Output directory"),
    trace: bool = typer.Option(
        True, "--trace/--no-trace", help="Generate detailed trace (Perfetto)"
    ),
    profile: bool = typer.Option(False, "--profile", help="Generate call-stack-based profile"),
    flat_profile: bool = typer.Option(False, "--flat-profile", help="Generate flat profile"),
    sample: bool = typer.Option(False, "--sample", help="Enable sampling profiling"),
    host: bool = typer.Option(False, "--host", help="Enable host metrics"),
    device: bool = typer.Option(False, "--device", help="Enable device metrics"),
    wait: float | None = typer.Option(None, "--wait", help="Wait time before collecting (seconds)"),
    duration: float | None = typer.Option(
        None, "--duration", help="Duration of collection (seconds)"
    ),
    use_rocm: bool = typer.Option(True, "--use-rocm/--no-rocm", help="Enable ROCm backend"),
    use_sampling: bool = typer.Option(False, "--use-sampling", help="Enable sampling backend"),
    use_kokkosp: bool = typer.Option(
        False, "--use-kokkosp", help="Enable Kokkos profiling backend"
    ),
    use_mpip: bool = typer.Option(False, "--use-mpip", help="Enable MPI profiling backend"),
    use_rocpd: bool = typer.Option(False, "--use-rocpd", help="Enable rocpd database output"),
    json_output: bool = typer.Option(False, "--json", "-j", help="Output as JSON"),
) -> None:
    """Run system profiling with rocprof-sys-run.
    Examples:
        wafer rocprof-systems run './my_app'
        wafer rocprof-systems run './app' --trace --profile --output-dir ./results
        wafer rocprof-systems run './kernel' --host --device --duration 10
        wafer rocprof-systems run './app' --use-kokkosp --use-mpip
    """
    from .rocprof_systems import run_command
    try:
        result = run_command(
            command=command,
            output_dir=output_dir,
            trace=trace,
            profile=profile,
            flat_profile=flat_profile,
            sample=sample,
            host=host,
            device=device,
            wait=wait,
            duration=duration,
            use_rocm=use_rocm,
            use_sampling=use_sampling,
            use_kokkosp=use_kokkosp,
            use_mpip=use_mpip,
            use_rocpd=use_rocpd,
            json_output=json_output,
        )
        if json_output:
            typer.echo(result)
    except Exception as e:
        typer.echo(f"Error: {e}", err=True)
        raise typer.Exit(1) from None
@rocprof_systems_app.command("analyze")
def rocprof_systems_analyze(
    file_path: Path = typer.Argument(..., help="Path to rocprof-sys output file (.json, .txt)"),
    json_output: bool = typer.Option(False, "--json", "-j", help="Output as JSON"),
) -> None:
    """Analyze a rocprof-sys output file.
    Supports:
    - JSON files (wall_clock-*.json, metadata-*.json, functions-*.json)
    - Text files (wall-clock.txt)
    Examples:
        wafer rocprof-systems analyze wall_clock-12345.json
        wafer rocprof-systems analyze wall-clock.txt --json
    """
    from .rocprof_systems import analyze_command
    if not file_path.exists():
        typer.echo(f"Error: File not found: {file_path}", err=True)
        raise typer.Exit(1)
    try:
        result = analyze_command(str(file_path), json_output)
        if json_output:
            typer.echo(result)
    except Exception as e:
        typer.echo(f"Error: {e}", err=True)
        raise typer.Exit(1) from None
@rocprof_systems_app.command("sample")
def rocprof_systems_sample(
    command: str = typer.Argument(..., help="Command to profile"),
    output_dir: str | None = typer.Option(None, "--output-dir", "-o", help="Output directory"),
    frequency: int | None = typer.Option(
        None, "--frequency", "--freq", "-f", help="Sampling frequency in Hz"
    ),
    trace: bool = typer.Option(False, "--trace", help="Generate detailed trace"),
    profile: bool = typer.Option(False, "--profile", help="Generate call-stack profile"),
    flat_profile: bool = typer.Option(False, "--flat-profile", help="Generate flat profile"),
    host: bool = typer.Option(False, "--host", help="Enable host metrics"),
    device: bool = typer.Option(False, "--device", help="Enable device metrics"),
    wait: float | None = typer.Option(None, "--wait", help="Wait time (seconds)"),
    duration: float | None = typer.Option(None, "--duration", help="Duration (seconds)"),
    json_output: bool = typer.Option(False, "--json", "-j", help="Output as JSON"),
) -> None:
    """Run sampling profiling with rocprof-sys-sample.
    Examples:
        wafer rocprof-systems sample ./my_app --frequency 100
        wafer rocprof-systems sample ./kernel --freq 500 --output-dir ./results
    """
    from .rocprof_systems import sample_command
    try:
        result = sample_command(
            command=command,
            output_dir=output_dir,
            frequency=frequency,
            trace=trace,
            profile=profile,
            flat_profile=flat_profile,
            host=host,
            device=device,
            wait=wait,
            duration=duration,
            json_output=json_output,
        )
        if json_output:
            typer.echo(result)
    except Exception as e:
        typer.echo(f"Error: {e}", err=True)
        raise typer.Exit(1) from None
@rocprof_systems_app.command("instrument")
def rocprof_systems_instrument(
    command: str = typer.Argument(..., help="Command to instrument"),
    output_dir: str | None = typer.Option(None, "--output-dir", "-o", help="Output directory"),
    simulate: bool = typer.Option(False, "--simulate", help="Simulate without creating binary"),
    function_include: list[str] | None = typer.Option(
        None, "--function-include", help="Function patterns to include"
    ),
    function_exclude: list[str] | None = typer.Option(
        None, "--function-exclude", help="Function patterns to exclude"
    ),
    json_output: bool = typer.Option(False, "--json", "-j", help="Output as JSON"),
) -> None:
    """Run binary instrumentation with rocprof-sys-instrument.
    Examples:
        wafer rocprof-systems instrument ./my_app --simulate
        wafer rocprof-systems instrument ./kernel --output-dir ./results
    """
    from .rocprof_systems import instrument_command
    try:
        result = instrument_command(
            command=command,
            output_dir=output_dir,
            simulate=simulate,
            function_include=function_include,
            function_exclude=function_exclude,
            json_output=json_output,
        )
        if json_output:
            typer.echo(result)
    except Exception as e:
        typer.echo(f"Error: {e}", err=True)
        raise typer.Exit(1) from None
@rocprof_systems_app.command("query")
def rocprof_systems_query(
    components: bool = typer.Option(False, "--components", help="Query available components"),
    hw_counters: bool = typer.Option(False, "--hw-counters", help="Query hardware counters"),
    all_metrics: bool = typer.Option(False, "--all", help="Query all metrics"),
    filter_pattern: str | None = typer.Option(None, "--filter", help="Filter results"),
    json_output: bool = typer.Option(False, "--json", "-j", help="Output as JSON"),
) -> None:
    """Query available profiling metrics and components.
    Examples:
        wafer rocprof-systems query --components
        wafer rocprof-systems query --hw-counters
        wafer rocprof-systems query --components --filter cpu
    """
    from .rocprof_systems import query_command
    try:
        result = query_command(
            components=components,
            hw_counters=hw_counters,
            all_metrics=all_metrics,
            filter_pattern=filter_pattern,
            json_output=json_output,
        )
        if json_output:
            typer.echo(result)
    except Exception as e:
        typer.echo(f"Error: {e}", err=True)
        raise typer.Exit(1) from None
rocprof_compute_app = typer.Typer(help="ROCprofiler-Compute profiling tool commands")
tool_app.add_typer(rocprof_compute_app, name="rocprof-compute", rich_help_panel="AMD Profiling")
@rocprof_compute_app.command("profile")
def rocprof_compute_profile(
    command: str = typer.Argument(..., help="Command to profile"),
    name: str = typer.Option(..., "--name", "-n", help="Workload name"),
    path: str | None = typer.Option(None, "--path", "-p", help="Workload base path"),
    kernel: str | None = typer.Option(
        None, "--kernel", "-k", help="Kernel filter (comma-separated)"
    ),
    dispatch: str | None = typer.Option(
        None, "--dispatch", "-d", help="Dispatch filter (comma-separated)"
    ),
    block: str | None = typer.Option(None, "--block", "-b", help="Block filter (comma-separated)"),
    no_roof: bool = typer.Option(False, "--no-roof", help="Skip roofline data"),
    roof_only: bool = typer.Option(False, "--roof-only", help="Profile roofline only (fastest)"),
    hip_trace: bool = typer.Option(False, "--hip-trace", help="Enable HIP trace"),
    verbose: int = typer.Option(0, "--verbose", "-v", count=True, help="Increase verbosity"),
    json_output: bool = typer.Option(False, "--json", "-j", help="Output as JSON"),
) -> None:
    """Profile a command with rocprof-compute.
    Executes rocprof-compute profiling on the target command and generates
    analysis results including roofline data, memory analysis, and kernel statistics.
    Examples:
        wafer rocprof-compute profile --name vcopy -- './vcopy -n 1048576'
        wafer rocprof-compute profile -n test -b SQ,TCC -- './kernel'
        wafer rocprof-compute profile -n trace --hip-trace -- './app'
        wafer rocprof-compute profile -n test --roof-only -- './app'
    """
    from .rocprof_compute import profile_command
    try:
        result = profile_command(
            command,
            name,
            path,
            kernel,
            dispatch,
            block,
            no_roof,
            roof_only,
            hip_trace,
            verbose,
            json_output,
        )
        if json_output:
            typer.echo(result)
    except Exception as e:
        typer.echo(f"Error: {e}", err=True)
        raise typer.Exit(1) from None
@rocprof_compute_app.command("analyze")
def rocprof_compute_analyze(
    workload_path: Path = typer.Argument(..., help="Path to workload directory"),
    kernel: str | None = typer.Option(None, "--kernel", "-k", help="Kernel filter"),
    dispatch: str | None = typer.Option(None, "--dispatch", "-d", help="Dispatch filter"),
    block: str | None = typer.Option(None, "--block", "-b", help="Block filter"),
    output: str | None = typer.Option(None, "--output", "-o", help="Output file"),
    list_stats: bool = typer.Option(
        False, "--list-stats", help="List all detected kernels and dispatches"
    ),
    json_output: bool = typer.Option(False, "--json", "-j", help="Output as JSON"),
    gui: bool = typer.Option(
        False, "--gui", help="Launch interactive GUI viewer (bundled Python viewer by default)"
    ),
    port: int = typer.Option(8050, "--port", "-p", help="Port for GUI server"),
    external: bool = typer.Option(
        False,
        "--external",
        help="Use AMD's native rocprof-compute GUI instead of bundled (requires ROCm)",
    ),
) -> None:
    """Analyze a rocprof-compute workload directory.
    Parses workload data and displays kernel statistics, roofline analysis,
    and performance metrics. Can optionally launch an interactive GUI viewer.
    GUI Modes:
        --gui           Uses Wafer's bundled Python viewer (works anywhere, no ROCm needed)
        --gui --external Uses AMD's native rocprof-compute GUI (requires ROCm installation)
    Examples:
        wafer rocprof-compute analyze ./workloads/vcopy
        wafer rocprof-compute analyze ./workloads/test --json
        wafer rocprof-compute analyze ./workloads/app -d 0,1 -o filtered.csv
        wafer rocprof-compute analyze ./workloads/app --list-stats
        wafer rocprof-compute analyze ./workloads/app --gui
        wafer rocprof-compute analyze ./workloads/app --gui --port 9000
        wafer rocprof-compute analyze ./workloads/app --gui --external
    """
    from .rocprof_compute import analyze_command
    if not workload_path.exists():
        typer.echo(f"Error: Workload path not found: {workload_path}", err=True)
        raise typer.Exit(1)
    try:
        result = analyze_command(
            str(workload_path),
            kernel,
            dispatch,
            block,
            output,
            list_stats,
            json_output,
            gui,
            port,
            external,
        )
        if json_output or not gui:
            typer.echo(result)
    except Exception as e:
        typer.echo(f"Error: {e}", err=True)
        raise typer.Exit(1) from None
@rocprof_compute_app.command("list-metrics")
def rocprof_compute_list_metrics(
    arch: str = typer.Argument(..., help="Architecture (gfx90a, gfx942, etc.)"),
) -> None:
    """List available metrics for an architecture.
    Examples:
        wafer rocprof-compute list-metrics gfx90a
        wafer rocprof-compute list-metrics gfx942
    """
    from .rocprof_compute import list_metrics_command
    try:
        result = list_metrics_command(arch)
        if result:
            typer.echo(result)
    except Exception as e:
        typer.echo(f"Error: {e}", err=True)
        raise typer.Exit(1) from None
autotuner_app = typer.Typer(help="Hyperparameter sweep for performance engineering")
tool_app.add_typer(autotuner_app, name="autotuner", hidden=True)
def _setup_wafer_core_env() -> None:
    """Set environment variables for wafer-core to use.
    Call this before using any wafer-core functions that need API access.
    Respects explicit environment variable overrides:
    - WAFER_API_URL: If already set, uses that instead of config
    - WAFER_AUTH_TOKEN: If already set, uses that instead of cached token
    """
    from .auth import get_valid_token
    from .global_config import get_api_url

    os.environ["WAFER_API_URL"] = get_api_url()
    # Only set auth token if not explicitly provided in environment
    # This allows CI/service accounts to override with their own tokens
    if "WAFER_AUTH_TOKEN" not in os.environ:
        token = get_valid_token()
        if token:
            os.environ["WAFER_AUTH_TOKEN"] = token
@autotuner_app.command("list")
def autotuner_list(
    show_all: bool = typer.Option(
        False, "--all", help="Show all sweeps including pending and failed"
    ),
) -> None:
    """List sweeps for the current user.
    By default, only shows running and completed sweeps.
    Use --all to include pending and failed sweeps.
    Examples:
        wafer autotuner list
        wafer autotuner list --all
    """
    _setup_wafer_core_env()
    from .autotuner import list_command
    try:
        result = list_command(show_all=show_all)
        print(result)
    except ValueError as e:
        typer.echo(f"Error: {e}", err=True)
        raise typer.Exit(1) from None
    except Exception as e:
        typer.echo(f"Error: {e}", err=True)
        raise typer.Exit(1) from None
@autotuner_app.command("delete")
def autotuner_delete(
    sweep_id: str | None = typer.Argument(None, help="Sweep ID to delete (omit when using --all)"),
    delete_all: bool = typer.Option(
        False, "--all", help="Delete all sweeps (optionally filtered by --status)"
    ),
    status: str | None = typer.Option(
        None,
        "--status",
        help="Filter by status when using --all (pending, running, completed, failed)",
    ),
    yes: bool = typer.Option(False, "--yes", "-y", help="Skip confirmation prompt"),
) -> None:
    """Delete a sweep (or all sweeps) and their trials.
    WARNING: This permanently deletes sweeps and cannot be undone.
    Examples:
        # Delete single sweep
        wafer autotuner delete <sweep-id>
        wafer autotuner delete <sweep-id> --yes
        # Delete all sweeps
        wafer autotuner delete --all
        wafer autotuner delete --all --status pending
        wafer autotuner delete --all --status failed --yes
    """
    _setup_wafer_core_env()
    from .autotuner import delete_all_command, delete_command
    # Validate arguments
    if delete_all and sweep_id:
        typer.echo("Error: Cannot specify both sweep_id and --all flag", err=True)
        raise typer.Exit(1)
    if not delete_all and not sweep_id:
        typer.echo("Error: Must specify either sweep_id or --all flag", err=True)
        raise typer.Exit(1)
    if status and not delete_all:
        typer.echo("Error: --status can only be used with --all flag", err=True)
        raise typer.Exit(1)
    try:
        if delete_all:
            # Delete all sweeps
            if not yes:
                status_msg = f" with status '{status}'" if status else ""
                confirm = typer.confirm(f"Are you sure you want to delete all sweeps{status_msg}?")
                if not confirm:
                    typer.echo("Deletion cancelled.")
                    raise typer.Exit(0)
            result = delete_all_command(status_filter=status)
        else:
            # Delete single sweep
            if not yes:
                confirm = typer.confirm(f"Are you sure you want to delete sweep {sweep_id}?")
                if not confirm:
                    typer.echo("Deletion cancelled.")
                    raise typer.Exit(0)
            result = delete_command(sweep_id)
        print(result)
    except ValueError as e:
        typer.echo(f"Error: {e}", err=True)
        raise typer.Exit(1) from None
    except Exception as e:
        typer.echo(f"Error: {e}", err=True)
        raise typer.Exit(1) from None
@autotuner_app.command("run")
def autotuner_run(
    config_file: Path | None = typer.Argument(
        None, help="Path to JSON config file (required unless --resume)"
    ),
    parallel: int = typer.Option(
        4, "--parallel", "-p", help="Number of trials to run concurrently"
    ),
    resume: str | None = typer.Option(None, "--resume", "-r", help="Resume existing sweep by ID"),
) -> None:
    """Run hyperparameter sweep from JSON config or resume existing sweep.
    Examples:
        # Start new sweep
        wafer autotuner run config.json
        wafer autotuner run config.json --parallel 8
        # Resume failed/interrupted sweep
        wafer autotuner run --resume <sweep-id>
        wafer autotuner run --resume <sweep-id> --parallel 8
    """
    _setup_wafer_core_env()
    from .autotuner import run_sweep_command
    # Validate arguments
    if not resume and not config_file:
        typer.echo("Error: Must specify either config file or --resume <sweep-id>", err=True)
        raise typer.Exit(1)
    if resume and config_file:
        typer.echo("Error: Cannot specify both config file and --resume", err=True)
        raise typer.Exit(1)
    try:
        result = run_sweep_command(
            config_file=config_file, parallel=parallel, resume_sweep_id=resume
        )
        print(result)
    except FileNotFoundError as e:
        typer.echo(f"Error: {e}", err=True)
        raise typer.Exit(1) from None
    except ValueError as e:
        typer.echo(f"Error: {e}", err=True)
        raise typer.Exit(1) from None
    except Exception as e:
        typer.echo(f"Error: {e}", err=True)
        raise typer.Exit(1) from None
@autotuner_app.command("results")
def autotuner_results(
    sweep_id: str = typer.Argument(..., help="Sweep ID to retrieve"),
    mode: str = typer.Argument("list", help="Display mode: 'list', 'best', or trial number"),
    sort_by: str | None = typer.Option(
        None, "--sort-by", help="Metric name to sort by (list mode)"
    ),
    direction: str = typer.Option("maximize", "--direction", help="Sort direction (list mode)"),
    pareto: str | None = typer.Option(
        None, "--pareto", help="Comma-separated metrics for Pareto frontier (list mode)"
    ),
    show_all: bool = typer.Option(
        False, "--show-all", help="Include failed and constraint-violated trials (list mode)"
    ),
    limit: int | None = typer.Option(
        None, "--limit", help="Maximum number of results to show (list mode, default: all)"
    ),
    metric: str | None = typer.Option(
        None, "--metric", help="Metric to optimize (REQUIRED for best mode)"
    ),
) -> None:
    """Show sweep results (list/best/trial).
    Commands:
        wafer autotuner results <sweep-id>                    # List all results
        wafer autotuner results <sweep-id> --sort-by <metric> # List sorted
        wafer autotuner results <sweep-id> best --metric <m>  # Show best config
        wafer autotuner results <sweep-id> <N>                # Show trial N
    """
    from .autotuner import best_command, results_command, trial_command
    try:
        if mode == "best":
            if not metric:
                typer.echo("Error: --metric is required for 'best' mode", err=True)
                raise typer.Exit(1)
            result = best_command(sweep_id=sweep_id, metric=metric)
        elif mode == "list":
            result = results_command(
                sweep_id=sweep_id,
                sort_by=sort_by,
                direction=direction,
                pareto=pareto,
                show_all=show_all,
                limit=limit,
            )
        else:
            # Try to parse as trial number
            try:
                trial_number = int(mode)
                result = trial_command(sweep_id=sweep_id, trial_number=trial_number)
            except ValueError as e:
                typer.echo(
                    f"Error: Invalid mode '{mode}'. Use 'list', 'best', or a trial number.",
                    err=True,
                )
                raise typer.Exit(1) from e
        print(result)
    except ValueError as e:
        typer.echo(f"Error: {e}", err=True)
        raise typer.Exit(1) from None
    except Exception as e:
        typer.echo(f"Error: {e}", err=True)
        raise typer.Exit(1) from None
@tool_app.command("capture", rich_help_panel="Other")
def capture_command(  # noqa: PLR0915
    label: str = typer.Argument(
        ..., help="Label for this capture (e.g., 'baseline', 'optimized-v2')"
    ),
    command: str = typer.Argument(..., help="Command to execute and capture"),
    variant: str | None = typer.Option(
        None, "--variant", "-v", help="Variant identifier for grouping related captures"
    ),
    tags: list[str] | None = typer.Option(
        None, "--tag", "-t", help="Tags for categorization (can be specified multiple times)"
    ),  # noqa: B008
    working_dir: Path | None = typer.Option(
        None, "--dir", "-d", help="Working directory (default: current directory)"
    ),
    sweep: list[str] | None = typer.Option(
        None, "--sweep", "-s", help="Parameter sweep (format: VAR=val1,val2,val3)"
    ),  # noqa: B008
    code_denylist: list[str] | None = typer.Option(
        None,
        "--code-denylist",
        help="Patterns to exclude from code files (e.g., '*.log', '**/test/**')",
    ),  # noqa: B008
    artifact_denylist: list[str] | None = typer.Option(
        None,
        "--artifact-denylist",
        help="Patterns to exclude from artifacts (e.g., '*.tmp', '*.o')",
    ),  # noqa: B008
    json_output: bool = typer.Option(False, "--json", "-j", help="Output as JSON"),
) -> None:
    """Capture an execution snapshot for reproducibility and comparison.

    Records command output, artifacts, code, git/system context, and metrics.
    Data is uploaded to Supabase for later analysis.

    Examples:
        wafer capture baseline "python benchmark.py"
        wafer capture optimized "python benchmark.py" --variant v2
        wafer capture test-run "make && ./kernel" --tag cuda --tag fp16
        wafer capture batch-sizes "python train.py --batch-size {BATCH}" --sweep "BATCH=16,32,64,128"
    """
    import itertools
    import os
    import tomllib
    from .auth import get_valid_token
    from .global_config import get_api_url

    # wafer-core backend.py reads WAFER_API_URL and WAFER_AUTH_TOKEN from env
    os.environ["WAFER_API_URL"] = get_api_url()
    # Only set auth token if not explicitly provided in environment
    # This allows CI/service accounts to override with their own tokens
    if "WAFER_AUTH_TOKEN" not in os.environ:
        token = get_valid_token()
        if token:
            os.environ["WAFER_AUTH_TOKEN"] = token
    import trio
    from wafer_core.tools.capture_tool import (  # pragma: no cover
        CaptureConfig,
        capture,
        execute_command,
    )
    # Resolve working directory
    work_dir = working_dir.resolve() if working_dir else Path.cwd()
    config_code_denylist = None
    config_artifact_denylist = None
    # 1. Try global config (~/.wafer/capture.toml)
    global_config_path = Path.home() / ".wafer" / "capture.toml"
    if global_config_path.exists():
        try:
            with open(global_config_path, "rb") as f:
                capture_config_data = tomllib.load(f)
            config_code_denylist = capture_config_data.get("code_denylist")
            config_artifact_denylist = capture_config_data.get("artifact_denylist")
        except Exception as e:
            typer.echo(f"⚠️  Warning: Failed to load {global_config_path}: {e}", err=True)
    # 2. Try project-specific config (.wafer-capture.toml in working dir)
    project_config_path = work_dir / ".wafer-capture.toml"
    if project_config_path.exists():
        try:
            with open(project_config_path, "rb") as f:
                project_config_data = tomllib.load(f)
            # Project config overrides global config
            if "code_denylist" in project_config_data:
                config_code_denylist = project_config_data["code_denylist"]
            if "artifact_denylist" in project_config_data:
                config_artifact_denylist = project_config_data["artifact_denylist"]
        except Exception as e:
            typer.echo(f"⚠️  Warning: Failed to load {project_config_path}: {e}", err=True)
    sweep_vars: dict[str, list[str]] = {}
    if sweep:
        for sweep_spec in sweep:
            if "=" not in sweep_spec:
                typer.echo(f"Error: Invalid sweep format: {sweep_spec}", err=True)
                typer.echo("   Expected format: VAR=val1,val2,val3", err=True)
                raise typer.Exit(1)
            var_name, values_str = sweep_spec.split("=", 1)
            values = [v.strip() for v in values_str.split(",")]
            sweep_vars[var_name] = values
    # Generate all combinations (cartesian product) of sweep variables
    if sweep_vars:
        var_names = list(sweep_vars.keys())
        var_values = [sweep_vars[name] for name in var_names]
        combinations = list(itertools.product(*var_values))
        if not json_output:
            typer.echo(f"Running sweep: {label}")
            typer.echo(f"   Variables: {', '.join(var_names)}")
            typer.echo(f"   Total runs: {len(combinations)}")
            typer.echo()
    else:
        # Single run (no sweep)
        combinations = [()]
        var_names = []
    # Progress callback (suppressed in JSON mode)
    def progress(msg: str) -> None:
        if not json_output:
            typer.echo(f"  {msg}")
    async def run_capture_sweep() -> list[dict]:
        from .output import json_response
        successful = 0
        failed = 0
        capture_results: list[dict] = []
        for idx, combo in enumerate(combinations, 1):
            # Substitute variables in command
            substituted_cmd = command
            sweep_info = {}
            for var_name, value in zip(var_names, combo, strict=True):
                substituted_cmd = substituted_cmd.replace(f"{{{var_name}}}", value)
                sweep_info[var_name] = value
            if sweep_vars:
                variant_parts = [f"{k}={v}" for k, v in sweep_info.items()]
                run_variant = "_".join(variant_parts)
                if variant:
                    run_variant = f"{variant}_{run_variant}"
            else:
                run_variant = variant
            denylist_kwargs = {}
            # Code denylist: CLI flag takes precedence over config file
            if code_denylist:
                denylist_kwargs["code_denylist"] = code_denylist
            elif config_code_denylist:
                denylist_kwargs["code_denylist"] = config_code_denylist
            # Artifact denylist: CLI flag takes precedence over config file
            if artifact_denylist:
                denylist_kwargs["artifact_denylist"] = artifact_denylist
            elif config_artifact_denylist:
                denylist_kwargs["artifact_denylist"] = config_artifact_denylist
            config = CaptureConfig(
                label=label,
                command=substituted_cmd,
                working_dir=work_dir,
                variant=run_variant,
                tags=tags or [],
                **denylist_kwargs,
            )
            try:
                if not json_output:
                    if sweep_vars:
                        typer.echo(
                            f"[{idx}/{len(combinations)}] {', '.join(f'{k}={v}' for k, v in sweep_info.items())}"
                        )
                    else:
                        typer.echo(f"Capturing: {label}")
                    typer.echo(f"   Command: {substituted_cmd}")
                    typer.echo(f"   Working dir: {work_dir}")
                    typer.echo()
                result = await capture(
                    config=config, runner=execute_command, progress_callback=progress
                )
                result_data = {
                    "id": result.id,
                    "label": label,
                    "command": substituted_cmd,
                    "exit_code": result.exit_code,
                    "duration_seconds": result.duration_seconds,
                    "code_files": len(result.code_files),
                    "artifacts": len(result.artifacts),
                }
                if result.metrics.stdout_metrics:
                    result_data["metrics_count"] = len(result.metrics.stdout_metrics)
                if sweep_info:
                    result_data["sweep"] = sweep_info
                capture_results.append(result_data)
                if not json_output:
                    typer.echo()
                    typer.echo("✓ Capture complete")
                    typer.echo(f"   ID: {result.id}")
                    typer.echo(f"   Exit code: {result.exit_code}")
                    typer.echo(f"   Duration: {result.duration_seconds:.2f}s")
                    typer.echo(f"   Code files: {len(result.code_files)}")
                    typer.echo(f"   Artifacts: {len(result.artifacts)}")
                    if result.metrics.stdout_metrics:
                        typer.echo(f"   Metrics: {len(result.metrics.stdout_metrics)}")
                    typer.echo()
                successful += 1
            except Exception as e:
                if json_output:
                    capture_results.append({
                        "label": label,
                        "command": substituted_cmd,
                        "error": str(e),
                    })
                else:
                    typer.echo(f"\n✗ Capture failed: {e}", err=True)
                    typer.echo()
                failed += 1
        if json_output:
            status = "ok" if failed == 0 else "error"
            data = {"captures": capture_results, "successful": successful, "failed": failed}
            typer.echo(json_response(data=data, status=status))
        else:
            # Summary for sweep runs
            if sweep_vars and len(combinations) > 1:
                typer.echo("=" * 60)
                typer.echo(f"Sweep complete: {successful} successful, {failed} failed")
        if failed > 0:
            raise typer.Exit(1)
        return capture_results
    trio.run(run_capture_sweep)
@tool_app.command("capture-list", rich_help_panel="Other")
def capture_list_command(
    label: str | None = typer.Option(None, "--label", "-l", help="Filter by label"),
    limit: int = typer.Option(100, "--limit", "-n", help="Maximum number of results"),
    offset: int = typer.Option(0, "--offset", "-o", help="Offset for pagination"),
    json_output: bool = typer.Option(False, "--json", "-j", help="Output as JSON"),
) -> None:
    """List captured executions.
    Query captures from the backend with optional filtering and pagination.
    Output can be formatted as a table (default) or JSON.
    Examples:
        # List all captures
        wafer capture-list
        wafer capture-list --label baseline
        wafer capture-list --json --limit 10
        # Pagination
        wafer capture-list --limit 20 --offset 20
    """
    import os
    from .auth import get_valid_token
    from .global_config import get_api_url

    os.environ["WAFER_API_URL"] = get_api_url()
    # Only set auth token if not explicitly provided in environment
    # This allows CI/service accounts to override with their own tokens
    if "WAFER_AUTH_TOKEN" not in os.environ:
        token = get_valid_token()
        if token:
            os.environ["WAFER_AUTH_TOKEN"] = token
    import trio
    from wafer_core.utils.backend import list_captures  # pragma: no cover
    async def run_list() -> None:
        try:
            captures = await list_captures(label=label, limit=limit, offset=offset)
            if json_output:
                from .output import json_response
                typer.echo(json_response(data={"captures": captures}))
            else:
                # Human-readable table output
                if not captures:
                    typer.echo("No captures found.")
                    return
                typer.echo(f"Found {len(captures)} captures:\n")
                # Print table header
                typer.echo(
                    f"{'ID':<36}  {'Label':<20}  {'Variant':<20}  {'Exit':<4}  {'Duration':<8}  {'Created'}"
                )
                typer.echo("-" * 120)
                # Print each capture
                for cap in captures:
                    cap_id = cap.get("id", "")[:36]
                    cap_label = cap.get("label", "")[:20]
                    cap_variant = (cap.get("variant") or "")[:20]
                    exit_code = cap.get("exit_code", "")
                    duration = f"{cap.get('duration_seconds', 0):.2f}s"
                    created = cap.get("created_at", "")[:19]  # Strip microseconds
                    typer.echo(
                        f"{cap_id:<36}  {cap_label:<20}  {cap_variant:<20}  {exit_code:<4}  {duration:<8}  {created}"
                    )
        except Exception as e:
            typer.echo(f"Error: Failed to list captures: {e}", err=True)
            raise typer.Exit(1) from None
    trio.run(run_list)
@tracelens_app.command("check")
def tracelens_check(
    json_output: bool = typer.Option(False, "--json", "-j", help="Output as JSON"),
) -> None:
    """Check if TraceLens is installed.
    Examples:
        wafer tracelens check
        wafer tracelens check --json
    """
    from .tracelens import check_command
    try:
        result = check_command(json_output)
        if json_output:
            typer.echo(result)
    except Exception as e:
        typer.echo(f"Error: {e}", err=True)
        raise typer.Exit(1) from None
@tracelens_app.command("report")
def tracelens_report(
    trace_path: str = typer.Argument(..., help="Path to trace file (.json, .zip, .gz, .pb)"),
    output: str | None = typer.Option(None, "--output", "-o", help="Output file path"),
    trace_format: str = typer.Option(
        "auto", "--format", "-f", help="Trace format: auto, pytorch, rocprof, jax"
    ),
    short_kernel: bool = typer.Option(
        False, "--short-kernel", help="Include short kernel analysis"
    ),
    kernel_details: bool = typer.Option(
        False, "--kernel-details", help="Include detailed kernel breakdown"
    ),
    json_output: bool = typer.Option(False, "--json", "-j", help="Output as JSON"),
) -> None:
    """Generate performance report from trace file.
    Generates an Excel report with hierarchical breakdowns, kernel statistics,
    and efficiency metrics (TFLOP/s, TB/s).
    Examples:
        wafer tracelens report trace.json
        wafer tracelens report trace.json --format pytorch --kernel-details
        wafer tracelens report rocprof_results.json --format rocprof -o analysis.xlsx
    """
    from .tracelens import report_command
    try:
        result = report_command(
            trace_path=trace_path,
            output_path=output,
            trace_format=trace_format,
            short_kernel=short_kernel,
            kernel_details=kernel_details,
            json_output=json_output,
        )
        if json_output:
            typer.echo(result)
    except RuntimeError:
        raise typer.Exit(1) from None
@tracelens_app.command("compare")
def tracelens_compare(
    baseline: str = typer.Argument(..., help="Path to baseline Excel report"),
    candidate: str = typer.Argument(..., help="Path to candidate Excel report"),
    output: str | None = typer.Option(None, "--output", "-o", help="Output comparison file"),
    baseline_name: str = typer.Option(
        "baseline", "--baseline-name", help="Display name for baseline"
    ),
    candidate_name: str = typer.Option(
        "candidate", "--candidate-name", help="Display name for candidate"
    ),
    json_output: bool = typer.Option(False, "--json", "-j", help="Output as JSON"),
) -> None:
    """Compare two performance reports.
    Quantifies differences between baseline and candidate reports.
    Useful for measuring optimization impact or regression detection.
    Examples:
        wafer tracelens compare baseline.xlsx candidate.xlsx
        wafer tracelens compare old.xlsx new.xlsx --baseline-name v1.0 --candidate-name v1.1
    """
    from .tracelens import compare_command
    try:
        result = compare_command(
            baseline_path=baseline,
            candidate_path=candidate,
            output_path=output,
            baseline_name=baseline_name,
            candidate_name=candidate_name,
            json_output=json_output,
        )
        if json_output:
            typer.echo(result)
    except RuntimeError:
        raise typer.Exit(1) from None
@tracelens_app.command("collective")
def tracelens_collective(
    trace_dir: str = typer.Argument(..., help="Directory containing trace files for all ranks"),
    world_size: int = typer.Option(..., "--world-size", "-w", help="Number of ranks (GPUs)"),
    output: str | None = typer.Option(None, "--output", "-o", help="Output file path"),
    json_output: bool = typer.Option(False, "--json", "-j", help="Output as JSON"),
) -> None:
    """Generate multi-rank collective performance report.
    Analyzes distributed training traces across multiple GPUs,
    providing communication analysis and scaling insights.
    Examples:
        wafer tracelens collective ./traces --world-size 8
        wafer tracelens collective ./multi_gpu_traces -w 4 -o collective_analysis.xlsx
    """
    from .tracelens import collective_command
    try:
        result = collective_command(
            trace_dir=trace_dir,
            world_size=world_size,
            output_path=output,
            json_output=json_output,
        )
        if json_output:
            typer.echo(result)
    except RuntimeError:
        raise typer.Exit(1) from None
@isa_app.command("analyze")
def isa_analyze(
    path: Path = typer.Argument(..., help="Path to file or directory to analyze"),
    json_output: bool = typer.Option(False, "--json", "-j", help="Output as JSON"),
    csv_output: bool = typer.Option(False, "--csv", help="Output as CSV"),
    recursive: bool = typer.Option(
        True, "--recursive/--no-recursive", "-r", help="Scan directories recursively"
    ),
    filter_expr: str | None = typer.Option(
        None, "--filter", "-f", help="Filter results (e.g., 'spills > 0')"
    ),
    output_file: Path | None = typer.Option(None, "--output", "-o", help="Write output to file"),
    kernel_index: int = typer.Option(0, "--kernel", "-k", help="Kernel index if multiple in file"),
) -> None:
    """Analyze AMD GPU ISA files (.co, .s, .ll, .ttgir).
    Performs static analysis to extract performance metrics like register
    pressure, spills, MFMA density, and occupancy limits.
    Supports:
      - AMD GPU code objects (.co) - Requires API authentication
      - AMDGCN ISA assembly (.s, .gcn, .asm) - Local parsing
      - LLVM-IR files (.ll) - Local parsing
      - TTGIR files (.ttgir, .ttir, .mlir) - Local parsing
    Examples:
        wafer tool isa analyze kernel.co              # Code object (needs login)
        wafer tool isa analyze kernel.s               # ISA assembly
        wafer tool isa analyze kernel.s --json        # Output as JSON
        wafer tool isa analyze ~/.triton/cache/ --filter 'spills > 0'
        wafer tool isa analyze . -r --csv -o metrics.csv
    """
    from .auth import get_auth_headers
    from .global_config import get_api_url
    from .kernel_scope import analyze_command
    api_url = get_api_url()
    auth_headers = get_auth_headers()
    try:
        output = analyze_command(
            path=str(path),
            json_output=json_output,
            csv_output=csv_output,
            recursive=recursive,
            filter_expr=filter_expr,
            output_file=str(output_file) if output_file else None,
            kernel_index=kernel_index,
            api_url=api_url,
            auth_headers=auth_headers,
        )
        typer.echo(output)
    except FileNotFoundError as e:
        typer.echo(f"Error: {e}", err=True)
        raise typer.Exit(1) from None
    except RuntimeError as e:
        typer.echo(f"Error: {e}", err=True)
        raise typer.Exit(1) from None
    except Exception as e:
        typer.echo(f"Error: {e}", err=True)
        raise typer.Exit(1) from None
@isa_app.command("metrics")
def isa_metrics() -> None:
    """List available metrics for ISA analysis.
    Shows all metrics that can be extracted from AMD GPU ISA files,
    along with their derivation.
    Examples:
        wafer tool isa metrics
    """
    from .kernel_scope import metrics_command
    output = metrics_command()
    typer.echo(output)
@isa_app.command("targets")
def isa_targets() -> None:
    """List supported GPU targets and their specifications.
    Shows hardware specs (VGPRs, SGPRs, LDS, etc.) for each supported
    AMD GPU architecture.
    Examples:
        wafer tool isa targets
    """
    from .kernel_scope import targets_command
    output = targets_command()
    typer.echo(output)
@compare_app.command("analyze")
def compare_analyze(
    trace1: Path = typer.Argument(..., help="First trace file (AMD or NVIDIA)", exists=True),
    trace2: Path = typer.Argument(..., help="Second trace file (AMD or NVIDIA)", exists=True),
    output: Path | None = typer.Option(None, "--output", "-o", help="Output file (default: stdout)"),
    format: str = typer.Option(
        "text",
        "--format",
        "-f",
        help="Output format: text, json",
    ),
    phase: str = typer.Option(
        "all",
        "--phase",
        help="Filter by phase: all, prefill, or decode",
    ),
    all: bool = typer.Option(False, "--all", help="Show all items without truncation"),
    stack_traces: bool = typer.Option(False, "--stack-traces", help="Show Python stack traces for operations"),
    grouped: bool = typer.Option(False, "--grouped", help="Group kernels by operation type (default: position order)"),
    max_graphs: int = typer.Option(1, "--max-graphs", help="Maximum number of CUDA graph patterns to show (default: 1)"),
    fusion: bool = typer.Option(False, "--fusion", help="Also show fusion analysis (kernel fusion differences)"),
    min_group_size: int = typer.Option(300, "--min-group-size", help="Minimum correlation group size for fusion analysis (default: 300)"),
    json: bool = typer.Option(False, "--json", hidden=True, help="Ignored (for compatibility with cliExecutor)"),
) -> None:
    """Compare GPU traces and generate performance report.
    Uses fused analyzer for ~50% faster performance - loads traces once and computes
    operation stats, graph matching, and fusion analysis in a single pass.
    Shows operation-level performance comparison with stack traces and kernel-to-kernel matching details.
    Examples:
        # Basic comparison (stdout) - shows 1:1 kernel matching
        wafer compare analyze amd_trace.json nvidia_trace.json
        # Include fusion analysis
        wafer compare analyze amd_trace.json nvidia_trace.json --fusion
        wafer compare analyze amd_trace.json nvidia_trace.json --grouped
        # Show all operations without truncation
        wafer compare analyze amd_trace.json nvidia_trace.json --all
        # Show Python stack traces
        wafer compare analyze amd_trace.json nvidia_trace.json --stack-traces
        wafer compare analyze amd_trace.json nvidia_trace.json --phase decode
        # Save to file
        wafer compare analyze amd_trace.json nvidia_trace.json -o report.txt
        # JSON output
        wafer compare analyze amd_trace.json nvidia_trace.json --format json -o report.json
    """
    from .trace_compare import compare_traces
    compare_traces(
        trace1=trace1,
        trace2=trace2,
        output=output,
        output_format=format,
        phase=phase,
        show_all=all,
        show_stack_traces=stack_traces,
        grouped=grouped,
        max_graphs=max_graphs,
        show_fusion=fusion,
        min_group_size=min_group_size,
    )
    _mark_command_success()
@compare_app.command("fusion")
def compare_fusion_cmd(
    trace1: Path = typer.Argument(..., help="First trace file (AMD or NVIDIA)", exists=True),
    trace2: Path = typer.Argument(..., help="Second trace file (AMD or NVIDIA)", exists=True),
    format: str = typer.Option(
        "text",
        "--format",
        "-f",
        help="Output format: text, json",
    ),
    output: Path | None = typer.Option(None, "--output", "-o", help="Output file (default: stdout)"),
    min_group_size: int = typer.Option(
        300,
        "--min-group-size",
        help="Minimum correlation group size to analyze (default: 300 for transformer layers)",
    ),
    legacy: bool = typer.Option(
        False,
        "--legacy",
        help="Use legacy signature-based matching instead of graph-based matching",
    ),
    json: bool = typer.Option(False, "--json", hidden=True, help="Ignored (for compatibility with cliExecutor)"),
) -> None:
    """Analyze kernel fusion differences using graph-based matching.
    Uses graph-based kernel matching to detect fusion differences between platforms.
    More accurate than legacy signature-based matching (use --legacy for old behavior).
    Examples:
        # Basic fusion analysis (stdout)
        wafer compare fusion amd_trace.json nvidia_trace.json
        # Save to file
        wafer compare fusion amd_trace.json nvidia_trace.json -o fusion_report.txt
        # JSON output to file
        wafer compare fusion amd_trace.json nvidia_trace.json --format json -o fusion.json
        wafer compare fusion amd_trace.json nvidia_trace.json --legacy
    """
    from .trace_compare import compare_fusion
    compare_fusion(
        trace1=trace1,
        trace2=trace2,
        output=output,
        format_type=format,
        min_group_size=min_group_size,
        use_graph_matching=not legacy,
    )
    _mark_command_success()


def main() -> None:
    """Entry point for wafer CLI."""
    global _command_outcome, _command_failure_details

    try:
        app()
    except SystemExit as exc:
        exit_code = exc.code if hasattr(exc, "code") else 1
        if exit_code not in (0, None):
            _command_outcome = "failure"
            if _command_failure_details is None:
                _command_failure_details = {
                    "error_type": "SystemExit",
                    "error_message": str(exc),
                }
                if isinstance(exit_code, int):
                    _command_failure_details["exit_code"] = exit_code
        raise
    except Exception as exc:
        _command_outcome = "failure"
        if _command_failure_details is None:
            _command_failure_details = {
                "error_type": type(exc).__name__,
                "error_message": str(exc),
                "exit_code": 1,
            }
        raise


if __name__ == "__main__":
    main()
