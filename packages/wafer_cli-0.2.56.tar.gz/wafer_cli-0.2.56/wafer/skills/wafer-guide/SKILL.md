---
name: wafer-guide
description: GPU kernel development with the Wafer CLI. Use when working on CUDA/HIP kernels, profiling GPU code, or optimizing kernel performance.
---
<!-- AUTO-GENERATED FILE — DO NOT EDIT DIRECTLY.
     Regenerate with: just generate-skill
     Source template: SKILL.md.template -->

# Wafer CLI — Quick Reference

GPU development primitives for optimizing CUDA and HIP kernels.

## Installation

```bash
uv tool install wafer-cli

# Authenticate (one-time setup)
wafer settings login

# Register SSH keys (required before using workspaces)
wafer settings ssh-keys add
```

## Core Commands

- `wafer tool eval gpumode` — test kernel correctness + benchmark speedup
- `wafer tool roofline` — roofline analysis (compute vs memory bound)
- `wafer tool ncu` / `wafer tool nsys` — NVIDIA profiling (NCU, NSYS)
- `wafer tool rocprof-compute` / `rocprof-sdk` / `rocprof-systems` — AMD profiling
- `wafer target workspace create/exec/sync` — cloud GPU workspaces
- `wafer agent -t ask-docs` — GPU docs lookup (uses ask_docs tool via wafer API)
- `wafer target config init` — configure GPU targets

## Detailed Guides

Load these with the `read` tool from the sub-guides directory below:
- `evaluate.md` — evaluation workflows, workspace+evaluate integration, target config
- `profiling.md` — trace analysis, roofline analysis, docs lookup
- `workspaces.md` — remote execution workflows
- `pitfalls.md` — common mistakes and fixes
- `commands.md` — full auto-generated command reference

## Important

```bash
# Query GPU documentation (uses wafer API — no local download needed)
wafer agent -t ask-docs "What is warp divergence?"
wafer agent -t ask-docs "What is a TiledMma in CUTLASS?"
```

### 2. Trace Analysis

Analyze NCU, NSYS, or PyTorch profiler traces:

```bash
# AI-assisted analysis
wafer agent -t trace-analyze --args trace=./profile.ncu-rep "Why is this kernel slow?"

# Direct trace queries (PyTorch/Perfetto JSON)
wafer tool perfetto query trace.json \
  "SELECT name, dur/1e6 as ms FROM slice WHERE cat='kernel' ORDER BY dur DESC LIMIT 10"

# NCU/NSYS analysis
wafer tool ncu analyze profile.ncu-rep
wafer tool nsys analyze profile.nsys-rep
```

### 3. Roofline Analysis

Analyze kernel performance against hardware limits:

```bash
# Compute-bound kernel (e.g., large matmul)
wafer tool roofline --gpu H100 --bytes 100.7e6 --flops 137.4e12 --time-ms 85

# Memory-bound kernel (e.g., elementwise op)
wafer tool roofline --gpu H100 --bytes 4e9 --flops 1e9 --time-ms 2

# JSON output for scripting
wafer tool roofline --gpu H100 --bytes 100.7e6 --flops 137.4e12 --time-ms 85 --json

# List supported GPUs
wafer tool roofline --list-gpus
```

Output includes: peak specs, achieved compute/bandwidth with % of peak, bottleneck classification (COMPUTE BOUND / MEMORY BOUND), and efficiency assessment.

### 4. Kernel Evaluation (GPUMode Format)

Test correctness and measure speedup against a reference. The evaluate command uses a **subcommand** for the format — use `gpumode` for the standard kernel format:

```bash
# Generate template files
wafer tool eval make-template ./my-kernel
# Creates: kernel.py, reference.py, test_cases.json

# Run evaluation on a configured target
wafer tool eval gpumode \
  --impl ./my-kernel/kernel.py \
  --reference ./my-kernel/reference.py \
  --test-cases ./my-kernel/test_cases.json \
  --target <target-name>

# With benchmarking
wafer tool eval gpumode \
  --impl ./my-kernel/kernel.py \
  --reference ./my-kernel/reference.py \
  --test-cases ./my-kernel/test_cases.json \
  --target <target-name> \
  --benchmark

### 5. Remote Execution (Workspaces)

Run on cloud GPU workspaces:

```bash
# Create a workspace with a specific GPU and environment type
wafer target workspace create my-workspace -g B200 -e baremetal

# List workspaces (shows SSH connection info: host, port)
wafer target workspace list

# Sync local files to workspace (files land at /workspace/ on remote, NOT /workspace/<name>/)
wafer target workspace sync my-workspace ./local-dir

# Execute commands on the workspace
wafer target workspace exec my-workspace -- "cd /workspace && python script.py"

# SSH into workspace (now standard: get connection info from `wafer target config show`)
wafer target workspace ssh my-workspace
```

**Important: Synced files land at `/workspace/` directly** — not at `/workspace/<workspace-name>/`. For example, if you sync a directory containing `kernel.py`, it will be at `/workspace/kernel.py` on the remote machine.

### 6. Workspace + Evaluate Integration

Workspaces and targets are **separate concepts** in Wafer:
- **Workspaces** are cloud GPU VMs you create with `wafer target workspace create`
- **Targets** are execution configs used by `wafer tool eval` (SSH hosts, RunPod, etc.)

You **cannot** use a workspace name as a `--target` argument. If you want to use `wafer tool eval` against a workspace, you must register it as an SSH target first:

```bash
# Step 1: Create workspace
wafer target workspace create my-workspace -g B200 -e baremetal

# Step 2: Get the SSH connection info
wafer target workspace list
# Note the host IP and port from the output

# Step 3: Register workspace as an SSH target
wafer target config init ssh \
  --name my-target \
  --host wafer@<ip>:<port> \
  --gpu-type B200 \
  --no-detect

# Step 4: Now you can evaluate against it
wafer tool eval gpumode \
  -i ./kernel.py \
  --reference ./reference.py \
  --test-cases ./test_cases.json \
  -t my-target \
  --benchmark
```

**Simpler alternative:** If `wafer tool eval` has deployment issues, use `wafer target workspace exec` with a custom benchmark script instead:

```bash
# Sync your files (including a run_benchmark.py script)
wafer target workspace sync my-workspace ./my-kernel

# Run directly
wafer target workspace exec my-workspace -- "cd /workspace && python run_benchmark.py"
```

This is often simpler and more reliable for baremetal workspaces.

## Common Pitfalls

| Mistake | Fix |
|---------|-----|
| `wafer tool eval --impl ...` | Use `wafer tool eval gpumode --impl ...` (subcommand required) |
| Using workspace name as `--target` | Workspace names and target names are separate. Register the workspace as an SSH target first. |
| `cd /workspace/my-workspace/` on remote | Synced files land at `/workspace/`, not `/workspace/<name>/` |
| `kernel()` / `reference()` function names | GPUMode format requires `custom_kernel()`, `ref_kernel()`, and `generate_input()` |
| Missing `generate_input` in reference.py | The reference file must export both `ref_kernel` AND `generate_input` |
| `wafer tool eval` deployment errors | Fall back to `wafer target workspace exec` with a custom benchmark script |

## Command Reference

{{ COMMAND_REFERENCE }}

## Target Configuration

Targets define GPU access methods. Initialize with:

```bash
wafer target config init ssh          # Your own GPU via SSH
wafer target config init runpod       # RunPod cloud GPUs
wafer target config init digitalocean # DigitalOcean AMD GPUs
```

Then use: `wafer tool eval gpumode --target <name> ...`
