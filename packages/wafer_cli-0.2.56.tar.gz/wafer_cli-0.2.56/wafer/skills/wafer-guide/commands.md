<!-- AUTO-GENERATED FILE — DO NOT EDIT DIRECTLY.
     Regenerate with: just generate-skill
     Source template: SKILL.md.template -->

# Command Reference

### `wafer tool eval`
Test kernel correctness and performance

Subcommands:
  wafer tool eval make-template  Generate template files for GPUMode functional format evaluation.
  wafer tool eval kernelbench  Evaluate kernels in KernelBench format (ModelNew class)
  wafer tool eval gpumode  Evaluate kernels in GPUMode format (custom_kernel/ref_kernel functions)
  wafer tool eval aiter  Evaluate aiter operator optimizations on AMD MI300X
  wafer tool eval vllm  Evaluate vLLM kernel optimizations (correctness + serving benchmark)
  wafer tool eval flashinfer-bench  Evaluate kernels using FlashInfer-Bench (official benchmark suite)
  wafer tool eval hipblaslt  Evaluate hipBLASLt GEMM kernel optimizations on AMD MI300X

### `wafer tool`
Run profiling, evaluation, and analysis tools.

Subcommands:
  wafer tool roofline  Analyze kernel performance against roofline model.
  wafer tool capture  Capture an execution snapshot for reproducibility and comparison.
  wafer tool capture-list  List captured executions.
  wafer tool exec  Execute commands on configured GPU targets.
  wafer tool eval  Test kernel correctness and performance
  wafer tool baseline  Discover what kernel PyTorch dispatches to for a given operation.
  wafer tool ncu  Nsight Compute profiling and analysis
  wafer tool nsys  Nsight Systems profile analysis
  wafer tool perfetto  Perfetto trace analysis and SQL queries
  wafer tool tracelens  TraceLens performance reports
  wafer tool nvidia-distributed-traces  Analyze NCCL collective operations in distributed training traces
  wafer tool isa  ISA analysis for AMD GPU kernels (.co, .s, .ll, .ttgir files)
  wafer tool compare  Compare GPU traces across platforms (AMD vs NVIDIA)
  wafer tool amd-distributed-traces  Analyze RCCL collective operations in distributed training traces
  wafer tool rocprof-sdk  ROCprofiler-SDK profiling tool commands
  wafer tool rocprof-systems  ROCprofiler-Systems profiling tool commands
  wafer tool rocprof-compute  ROCprofiler-Compute profiling tool commands
  wafer tool autotuner  Hyperparameter sweep for performance engineering

### `wafer target workspace`
Manage cloud GPU workspaces for remote development.
Workspaces are on-demand cloud GPU environments. Requires authentication (wafer settings login).
Available GPUs:
  MI300X  AMD Instinct MI300X (192GB HBM3, ROCm)
  B200    NVIDIA Blackwell B200 (180GB HBM3e, CUDA)
Commands:
  wafer target workspace create dev --gpu B200   # Create workspace
  wafer target workspace exec dev -- python x.py # Run commands
  wafer target workspace delete dev              # Clean up

Subcommands:
  wafer target workspace list  List all workspaces.
  wafer target workspace create  Create a new workspace.
  wafer target workspace delete  Delete a workspace.
  wafer target workspace show  Show details of a workspace.
  wafer target workspace exec  Execute a command in workspace.
  wafer target workspace ssh  SSH into a workspace.
  wafer target workspace sync  Sync local files to workspace.
  wafer target workspace pull  Pull files from workspace to local machine.

### `wafer target config`
Manage GPU targets for remote evaluation.
Targets define how to access GPUs. Use 'wafer target config init' to set up:
  wafer target config init ssh           # Your own GPU via SSH
  wafer target config init runpod        # RunPod cloud GPUs
  wafer target config init digitalocean  # DigitalOcean AMD GPUs
Then use with: wafer tool eval --target <name> ...

Subcommands:
  wafer target config add  Add a target from a TOML config file.
  wafer target config list  List all configured targets with live provider status.
  wafer target config show  Show details for a target.
  wafer target config probe  Probe a target to discover available compilation backends.
  wafer target config remove  Remove a target.
  wafer target config default  Set the default target.
  wafer target config cleanup  Terminate RunPod pod for a target.
  wafer target config install  Install a library or run maintenance on a target (idempotent).
  wafer target config pods  List all running RunPod pods.
  wafer target config pool-list  List all configured target pools.
  wafer target config pool-create  Create or update a target pool.
  wafer target config pool-status  Show status of targets in a pool (locked/available).
  wafer target config init  Initialize a new GPU target.

### `wafer agent`
AI assistant for GPU kernel development.
Helps with CUDA/Triton kernel optimization, GPU documentation queries,
and performance analysis. Launches interactive TUI by default.

Examples:
    wafer agent                                    # interactive TUI
    wafer agent "What is TMEM in CuTeDSL?"        # TUI with initial prompt
    wafer agent -s "What is TMEM?"                 # single-turn (answer and exit)
    wafer agent -t ask-docs "query"                 # use a template
    wafer agent --resume last "follow up"          # resume session

Options:
  --interactive/-i  Launch full interactive TUI mode (default when no prompt given)
  --simple  Use simple stdout mode instead of TUI (for scripts/pipes)
  --single-turn/-s  Single-turn mode: answer once and exit
  --resume/-r TEXT  Resume session by ID (or 'last' for most recent)
  --from-turn INTEGER  Branch from specific turn (default: resume from end)
  --list-sessions  List recent sessions and exit
  --get-session TEXT  Get session by ID and print messages (use with --json)
  --tools TEXT  Comma-separated list of tools to enable (default: all)
  --allow-spawn  Allow wafer tool to spawn sub-wevin agents (blocked by default)
  --max-tool-fails INTEGER  Exit after N consecutive tool failures
  --max-turns INTEGER  Max conversation turns (default: 10)
  --model/-m TEXT  Model override (default: claude-opus-4-5)
  --json  Output in JSON format (stream-json style)
  --template/-t TEXT  Run with template (ask-docs, trace-analyze, optimize-kernel)
  --args TEXT  Template variable (KEY=VALUE, can be repeated)
  --no-sandbox  Disable OS-level sandboxing (YOU accept liability for any damage caused by the agent)
  --no-proxy  Skip wafer proxy, use ANTHROPIC_API_KEY directly
  --env TEXT  Environment name (coding, remote-target, runpod-sandbox, modal-sandbox). Uses --args for config.
  --workspace TEXT  Workspace ID (requires --env workspace)

### `wafer settings skill`
Manage AI coding assistant skills (Claude Code, Codex)

Subcommands:
  wafer settings skill install  Install the wafer-guide skill for AI coding assistants.
  wafer settings skill uninstall  Uninstall the wafer-guide skill.
  wafer settings skill status  Show installation status of the wafer-guide skill.
