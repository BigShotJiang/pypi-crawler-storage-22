# Kernel Evaluation (GPUMode Format)

Test correctness and measure speedup against a reference. The evaluate command uses a **subcommand** for the format — use `gpumode` for the standard kernel format:

```bash
# Generate template files
wafer evaluate make-template ./my-kernel
# Creates: kernel.py, reference.py, test_cases.json

# Run evaluation on a configured target
wafer evaluate gpumode \
  --impl ./my-kernel/kernel.py \
  --reference ./my-kernel/reference.py \
  --test-cases ./my-kernel/test_cases.json \
  --target <target-name>

# With benchmarking
wafer evaluate gpumode \
  --impl ./my-kernel/kernel.py \
  --reference ./my-kernel/reference.py \
  --test-cases ./my-kernel/test_cases.json \
  --target <target-name> \
  --benchmark
```

## Workspace + Evaluate Integration

Workspaces and targets are **separate concepts** in Wafer:
- **Workspaces** are cloud GPU VMs you create with `wafer workspaces create`
- **Targets** are execution configs used by `wafer evaluate` (SSH hosts, RunPod, etc.)

You **cannot** use a workspace name as a `--target` argument. If you want to use `wafer evaluate` against a workspace, you must register it as an SSH target first:

```bash
# Step 1: Create workspace
wafer workspaces create my-workspace -g B200 -e baremetal

# Step 2: Get the SSH connection info
wafer workspaces list
# Note the host IP and port from the output

# Step 3: Register workspace as an SSH target
wafer config targets init ssh \
  --name my-target \
  --host wafer@<ip>:<port> \
  --gpu-type B200 \
  --no-detect

# Step 4: Now you can evaluate against it
wafer evaluate gpumode \
  -i ./kernel.py \
  --reference ./reference.py \
  --test-cases ./test_cases.json \
  -t my-target \
  --benchmark
```

**Simpler alternative:** If `wafer evaluate` has deployment issues, use `wafer workspaces exec` with a custom benchmark script instead:

```bash
# Sync your files (including a run_benchmark.py script)
wafer workspaces sync my-workspace ./my-kernel

# Run directly
wafer workspaces exec my-workspace -- "cd /workspace && python run_benchmark.py"
```

## GPUMode Function Signatures

The GPUMode format requires these specific function names:
- `custom_kernel()` — your optimized kernel implementation
- `ref_kernel()` — reference implementation (in reference.py)
- `generate_input()` — input generator (in reference.py)

## Target Configuration

Targets define GPU access methods. Initialize with:

```bash
wafer config targets init ssh          # Your own GPU via SSH
wafer config targets init runpod       # RunPod cloud GPUs
wafer config targets init digitalocean # DigitalOcean AMD GPUs
```

Then use: `wafer evaluate gpumode --target <name> ...`
