# Common Pitfalls

- **Missing subcommand**: Use `wafer evaluate gpumode --impl ...` not `wafer evaluate --impl ...` (subcommand required)
- **Workspace != target**: Workspace names and target names are separate. Register the workspace as an SSH target first with `wafer config targets init ssh`
- **Wrong remote path**: Synced files land at `/workspace/`, not `/workspace/<name>/`
- **Wrong function names**: GPUMode format requires `custom_kernel()`, `ref_kernel()`, and `generate_input()` — not `kernel()` / `reference()`
- **Missing generate_input**: The reference file must export both `ref_kernel` AND `generate_input`
- **Deployment errors**: Fall back to `wafer workspaces exec` with a custom benchmark script
