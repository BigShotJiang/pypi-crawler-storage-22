# Remote Execution (Workspaces)

Run on cloud GPU workspaces:

```bash
# Create a workspace with a specific GPU and environment type
wafer workspaces create my-workspace -g B200 -e baremetal

# List workspaces (shows SSH connection info: host, port)
wafer workspaces list

# Sync local files to workspace (files land at /workspace/ on remote, NOT /workspace/<name>/)
wafer workspaces sync my-workspace ./local-dir

# Execute commands on the workspace
wafer workspaces exec my-workspace -- "cd /workspace && python script.py"

# SSH into workspace
wafer workspaces ssh my-workspace
```

**Important: Synced files land at `/workspace/` directly** — not at `/workspace/<workspace-name>/`. For example, if you sync a directory containing `kernel.py`, it will be at `/workspace/kernel.py` on the remote machine.
