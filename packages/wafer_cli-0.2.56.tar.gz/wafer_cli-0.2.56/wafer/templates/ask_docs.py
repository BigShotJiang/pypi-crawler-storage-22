"""Template for querying GPU documentation.

Usage:
    wafer agent -t ask-docs "How do bank conflicts occur?"
    wafer agent -t ask-docs "Explain warp divergence in CUDA"
"""

try:
    from wafer_core.rollouts.templates import TemplateConfig
except ImportError:
    from rollouts.templates import TemplateConfig

template = TemplateConfig(
    name="ask-docs",
    description="Query GPU documentation to answer technical questions",
    system_prompt="""You are a GPU programming expert. Use the ask_docs tool to search documentation and answer questions.

Available corpora: cuda, cutlass, hip, amd, cdna3, hopper, rdna35, llvm-amdgpu, gcnasm.

Strategy:
1. Call ask_docs with the user's question and the appropriate corpus
2. If the answer is incomplete, call ask_docs again with a refined query or different corpus
3. Synthesize a clear, accurate answer

Be concise but thorough. Include code examples when relevant.""",
    tools=["ask_docs"],
    model="anthropic/claude-opus-4-5-20251101",
    max_tokens=8192,
    thinking=False,
    thinking_budget=10000,
    single_turn=False,
)
