"""Template for FlashInfer kernel optimization.

Usage:
    # Optimize batch decode attention kernel
    wafer agent -t optimize-flashinfer \
        --args flashinfer_dir=/path/to/flashinfer \
        --args op=batch_decode_paged_kv \
        --args target=my-gpu-server \
        "Optimize the batch decode attention kernel for better throughput"

    # With custom test and benchmark commands
    wafer agent -t optimize-flashinfer \
        --args flashinfer_dir=./flashinfer \
        --args op=hopper_attention \
        --args test_cmd="pytest tests/attention/test_hopper.py -v" \
        --args bench_cmd="python benchmarks/bench_hopper_attention.py"

Variables:
    - flashinfer_dir: Path to FlashInfer repository (required)
    - op: Target op to optimize (required, e.g., batch_decode_paged_kv, hopper_attention)
    - target: Target name (default: uses default target)
    - pool: Target pool name (alternative to target)
    - test_cmd: Pytest command for correctness (auto-generated from op if not provided)
    - bench_cmd: Benchmark command (auto-generated from op if not provided)
"""

try:
    from wafer_core.rollouts.templates import TemplateConfig
except ImportError:
    from rollouts.templates import TemplateConfig

from wafer.agent_defaults import FLASHINFER_BASH_ALLOWLIST, FLASHINFER_ENABLED_TOOLS

# Default test commands per op (from FlashInfer's test structure)
DEFAULT_TEST_CMDS = {
    # Attention kernels
    "batch_decode_paged_kv": "pytest tests/attention/test_batch_decode_kernels.py -v -x",
    "batch_prefill": "pytest tests/attention/test_batch_prefill.py -v -x",
    "single_prefill": "pytest tests/attention/test_single_prefill.py -v -x",
    "hopper_attention": "pytest tests/attention/test_hopper.py -v -x",
    "hopper_fp8_attention": "pytest tests/attention/test_hopper_fp8_attention.py -v -x",
    "sliding_window": "pytest tests/attention/test_sliding_window.py -v -x",
    "deepseek_mla": "pytest tests/attention/test_deepseek_mla.py -v -x",
    "cascade_attention": "pytest tests/attention/test_batch_attention.py -v -x -k cascade",
    # GEMM kernels
    "mm_fp8": "pytest tests/gemm/test_mm_fp8.py -v -x",
    "grouped_gemm": "pytest tests/gemm/test_group_gemm.py -v -x",
    "bmm_fp8": "pytest tests/gemm/test_bmm_fp8.py -v -x",
    # MoE kernels
    "cutlass_fused_moe": "pytest tests/moe/test_trtllm_cutlass_fused_moe.py -v -x",
    "fused_moe_fp8": "pytest tests/moe/test_dpsk_fused_moe_fp8.py -v -x",
    # Other ops
    "rope": "pytest tests/attention/test_rope.py -v -x",
    "fused_add_rmsnorm": "pytest tests/norm/ -v -x",
    "sampling": "pytest tests/ -v -x -k sampling",
    "topk": "pytest tests/ -v -x -k topk",
    "softmax": "pytest tests/ -v -x -k softmax",
}

# Default benchmark commands per op
DEFAULT_BENCH_CMDS = {
    # Attention kernels - use unified benchmark framework
    "batch_decode_paged_kv": (
        "python benchmarks/flashinfer_benchmark.py "
        "--routine BatchDecodeWithPagedKVCacheWrapper "
        "--batch_size 32 --s_kv 2048 --num_qo_heads 32 --num_kv_heads 8 "
        "--head_dim_qk 128 --page_size 16"
    ),
    "batch_prefill": (
        "python benchmarks/flashinfer_benchmark.py "
        "--routine BatchPrefillWithPagedKVCacheWrapper "
        "--batch_size 8 --s_qo 512 --s_kv 2048 --num_qo_heads 32 --num_kv_heads 8 "
        "--head_dim_qk 128 --page_size 16"
    ),
    "single_prefill": "python benchmarks/bench_batch_attention.py",
    "hopper_attention": "python benchmarks/bench_hopper_attention.py",
    "hopper_fp8_attention": "python benchmarks/bench_hopper_fp8_attention.py",
    "sliding_window": "python benchmarks/bench_sliding_window.py",
    "deepseek_mla": "python benchmarks/bench_deepseek_mla.py",
    "cascade_attention": "python benchmarks/bench_batch_attention.py",
    # GEMM kernels
    "mm_fp8": "python benchmarks/bench_mm_fp8.py",
    "grouped_gemm": "python benchmarks/bench_hopper_grouped_gemm.py",
    "bmm_fp8": "python benchmarks/bench_mm_fp8.py",
    # MoE kernels
    "cutlass_fused_moe": "python benchmarks/bench_cutlass_fused_moe.py",
    "fused_moe_fp8": "python benchmarks/bench_cutlass_fused_moe.py",
    # Other ops
    "rope": "python benchmarks/bench_rope.py",
    "fused_add_rmsnorm": "python benchmarks/bench_fused_add_rmsnorm.py",
    "sampling": "python benchmarks/bench_sampling.py",
    "topk": "python benchmarks/bench_topk.py",
    "softmax": "python benchmarks/bench_softmax.py",
}

SYSTEM_PROMPT = """\
You are a GPU kernel optimization expert. Your task is to improve the performance
of a specific FlashInfer kernel while maintaining correctness.

## Target

You are optimizing the `$op` kernel in FlashInfer.
- FlashInfer directory: `$flashinfer_dir`
- Correctness test: `$test_cmd`
- Benchmark: `$bench_cmd`

## FlashInfer Architecture

FlashInfer uses JIT compilation - you can edit kernel code and changes are
automatically picked up on next use (no reinstall needed).

Key directories:
- `flashinfer/` - Python API wrappers
- `include/flashinfer/` - CUDA kernel templates (.cuh files) - **this is where the real kernels live**
- `csrc/` - C++ bindings
- `tests/` - pytest test suite
- `benchmarks/` - Performance benchmarks

## Workflow

1. **Understand the kernel**: Read the kernel implementation
   - Python API: `flashinfer/$op.py` (wrapper)
   - CUDA kernels: `include/flashinfer/attention/` or `include/flashinfer/*/`
   - The .cuh files contain the actual GPU code to optimize

2. **Run baseline benchmark**: Establish baseline performance
   ```bash
   cd $flashinfer_dir && $bench_cmd
   ```

3. **Analyze and optimize**: Identify optimization opportunities
   - Memory access patterns (coalescing, shared memory usage)
   - Occupancy and register pressure
   - Tiling strategies
   - Warp-level primitives
   - Hardware-specific optimizations (tensor cores, async copy, etc.)

4. **Modify the kernel**: Make your changes to the .cuh files
   - FlashInfer uses JIT, so changes are picked up automatically

5. **Validate correctness**: Run the test suite
   ```bash
   cd $flashinfer_dir && $test_cmd
   ```

6. **Measure improvement**: Run benchmark again and compare

7. **Iterate**: If correctness fails or performance regresses, adjust and retry

## Key Kernel Locations

- **Attention decode**: `include/flashinfer/attention/decode.cuh`
- **Attention prefill**: `include/flashinfer/attention/prefill.cuh`
- **Hopper attention**: `include/flashinfer/attention/hopper/`
- **MoE**: `flashinfer/fused_moe/` (uses CUTLASS)
- **GEMM**: `flashinfer/gemm/`

## Constraints

- The correctness test MUST pass after your changes
- Focus on the specific kernel identified (`$op`)
- Document your changes and reasoning
- FlashInfer kernels are highly optimized - even small improvements are valuable

## Key Metrics

- **throughput_gbps**: Memory bandwidth achieved (higher is better)
- **latency_ms**: Kernel execution time (lower is better)
- **tflops**: Compute throughput for GEMM kernels (higher is better)"""

template = TemplateConfig(
    # Identity
    name="optimize-flashinfer",
    description="Optimize FlashInfer kernels for better LLM inference performance",
    # System prompt (task-specific; CLI docs appended at runtime)
    system_prompt=SYSTEM_PROMPT,
    # Tools
    tools=FLASHINFER_ENABLED_TOOLS,
    bash_allowlist=FLASHINFER_BASH_ALLOWLIST,
    # Model config
    model="anthropic/claude-opus-4-5-20251101",
    max_tokens=8192,
    # No thinking by default, can override with --thinking
    thinking=False,
    # Multi-turn for iterative optimization
    single_turn=False,
    # Template variables
    defaults={
        "flashinfer_dir": "./flashinfer",
        "op": "batch_decode_paged_kv",
        "target": "",
        "pool": "",
        "test_cmd": "",  # Auto-filled from DEFAULT_TEST_CMDS[op] if empty
        "bench_cmd": "",  # Auto-filled from DEFAULT_BENCH_CMDS[op] if empty
        "target_flag": "",  # Auto-computed: --target X or --pool Y
    },
)
