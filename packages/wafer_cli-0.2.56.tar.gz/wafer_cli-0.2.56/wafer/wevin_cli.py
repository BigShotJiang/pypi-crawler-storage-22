"""Wafer Wevin CLI - thin wrapper that calls rollouts in-process.
Adds:
- Wafer auth (proxy token from ~/.wafer/credentials.json)
- Wafer templates (ask-docs, optimize-kernel, trace-analyze)
"""
from __future__ import annotations
import json
import logging
import os
import sys
import tempfile
from pathlib import Path
from typing import TYPE_CHECKING
if TYPE_CHECKING:
    from collections.abc import Awaitable, Callable
    from wafer_core.rollouts import Endpoint, Environment
    from wafer_core.rollouts.dtypes import StreamEvent, ToolCall
    from wafer_core.rollouts.templates import TemplateConfig
class StreamingChunkFrontend:
    """Frontend that emits real-time JSON chunk events.
    Designed for programmatic consumption by extensions/UIs.
    Emits events in the format expected by wevin-extension handleWevinEvent:
    - {type: 'session_start', session_id: '...', model: '...'}
    - {type: 'text_delta', delta: '...'}
    - {type: 'tool_call_start', tool_name: '...'}
    - {type: 'tool_call_end', tool_name: '...', args: {...}}
    - {type: 'tool_result', is_error: bool}
    - {type: 'session_end'}
    - {type: 'error', error: '...'}
    """
    def __init__(self, session_id: str | None = None, model: str | None = None) -> None:
        self._current_tool_call: dict | None = None
        self._session_id = session_id
        self._model = model
    def _emit(self, obj: dict) -> None:
        """Emit a single NDJSON line."""
        print(json.dumps(obj, ensure_ascii=False), flush=True)
    async def start(self) -> None:
        """Initialize frontend and emit session_start if session_id is known."""
        if self._session_id:
            self._emit({
                "type": "session_start",
                "session_id": self._session_id,
                "model": self._model,
            })
    def emit_session_start(self, session_id: str, model: str | None = None) -> None:
        """Emit session_start event (for new sessions created during run)."""
        self._emit({
            "type": "session_start",
            "session_id": session_id,
            "model": model or self._model,
        })
    async def stop(self) -> None:
        """Emit session_end event."""
        self._emit({"type": "session_end"})
    async def handle_event(self, event: StreamEvent) -> None:
        """Handle streaming event by emitting JSON."""
        from wafer_core.rollouts.dtypes import (
            StreamDone,
            StreamError,
            TextDelta,
            ThinkingDelta,
            ToolCallEnd,
            ToolCallStart,
            ToolResultReceived,
        )
        if isinstance(event, TextDelta):
            # Emit text delta immediately for real-time streaming
            self._emit({"type": "text_delta", "delta": event.delta})
        elif isinstance(event, ThinkingDelta):

            pass
        elif isinstance(event, ToolCallStart):
            # Emit tool_call_start event (ToolCallStart has flat attributes)
            self._current_tool_call = {
                "id": event.tool_call_id,
                "name": event.tool_name,
            }
            self._emit({"type": "tool_call_start", "tool_name": event.tool_name})
        elif isinstance(event, ToolCallEnd):
            # Emit tool_call_end event with tool name and args
            tool_call = event.tool_call
            self._emit({
                "type": "tool_call_end",
                "tool_name": tool_call.name,
                "args": tool_call.args if tool_call.args else {},
            })
        elif isinstance(event, ToolResultReceived):
            # Emit tool_result event with error details
            result_event = {"type": "tool_result", "is_error": event.is_error}
            # Include error message and content if available
            if event.error:
                result_event["error"] = event.error
            if event.content:
                if isinstance(event.content, list):
                    result_event["content"] = "\n".join(
                        str(item) if not isinstance(item, dict) else item.get("text", str(item))
                        for item in event.content
                    )
                else:
                    result_event["content"] = str(event.content)
            self._emit(result_event)
        elif isinstance(event, StreamDone):
            # Will be handled by stop()
            pass
        elif isinstance(event, StreamError):
            self._emit({"type": "error", "error": str(event.error)})
    async def get_input(self, prompt: str = "") -> str:
        """Get user input - not supported in JSON mode."""
        raise RuntimeError(
            "StreamingChunkFrontend does not support interactive input. "
            "Use -p to provide input or use -s for single-turn mode."
        )
    async def confirm_tool(self, tool_call: ToolCall) -> bool:
        """Auto-approve all tools in JSON mode."""
        return True
    def show_loader(self, text: str) -> None:
        """No-op for JSON mode."""
        pass
    def hide_loader(self) -> None:
        """No-op for JSON mode."""
        pass
def _make_wafer_token_refresh() -> Callable[[], Awaitable[str | None]]:
    """Create an async callback that refreshes the wafer proxy token via Supabase."""
    from .auth import load_credentials, refresh_access_token, save_credentials
    async def _refresh() -> str | None:
        creds = load_credentials()
        if not creds or not creds.refresh_token:
            return None
        try:
            new_access, new_refresh = refresh_access_token(creds.refresh_token)
            save_credentials(new_access, new_refresh, creds.email)
            return new_access
        except Exception as exc:
            logging.getLogger(__name__).warning("wafer token refresh failed: %s", exc)
            return None
    return _refresh
def _track_auth_failure(error_type: str, *, had_credentials: bool, source: str) -> None:
    """Send PostHog event for auth failures so the team has visibility."""
    from .analytics import track_event
    track_event("cli_auth_failure", {
        "error_type": error_type,
        "had_credentials": had_credentials,
        "source": source,
    })
def _get_wafer_auth(
    *, no_proxy: bool = False
) -> tuple[str | None, str | None, Callable[[], Awaitable[str | None]] | None]:
    """Get wafer auth credentials with fallback chain.
    Returns:
        (api_base, api_key, api_key_refresh) or (None, None, None) if no auth found.
        api_key_refresh is an async callback for mid-session token refresh (only set
        when using wafer proxy via credentials file).
    """
    from .auth import get_valid_token, load_credentials
    from .global_config import get_api_url
    if no_proxy:
        api_key = os.environ.get("ANTHROPIC_API_KEY", "")
        if not api_key:
            # Try auth.json stored key
            from wafer_core.auth import get_api_key
            api_key = get_api_key("anthropic") or ""
        if api_key:
            print("🔑 Using ANTHROPIC_API_KEY (--no-proxy)\n", file=sys.stderr)
            return "https://api.anthropic.com", api_key, None
        print(
            "❌ --no-proxy requires ANTHROPIC_API_KEY env var or `wafer settings auth login anthropic`\n",
            file=sys.stderr,
        )
        _track_auth_failure("no_api_key_no_proxy", had_credentials=False, source="no_proxy")
        return None, None, None
    wafer_token = os.environ.get("WAFER_AUTH_TOKEN", "")
    token_source = "WAFER_AUTH_TOKEN" if wafer_token else None
    # Try credentials file with automatic refresh
    had_credentials = False
    uses_credentials_file = False
    if not wafer_token:
        try:
            creds = load_credentials()
            had_credentials = creds is not None and bool(creds.access_token)
        except Exception:
            pass
        wafer_token = get_valid_token()
        if wafer_token:
            token_source = "~/.wafer/credentials.json"
            uses_credentials_file = True
    # If we have a valid wafer token, use it
    if wafer_token:
        api_url = get_api_url()
        print(f"🔑 Using wafer proxy ({token_source})\n", file=sys.stderr)
        # Only provide refresh callback when token came from credentials file
        # (env var tokens are managed externally)
        refresh = _make_wafer_token_refresh() if uses_credentials_file else None
        return f"{api_url}/v1/anthropic", wafer_token, refresh
    # Fall back to direct anthropic
    api_key = os.environ.get("ANTHROPIC_API_KEY", "")
    if api_key:
        if had_credentials:
            print(
                "⚠️  Wafer credentials expired/invalid, falling back to ANTHROPIC_API_KEY\n",
                file=sys.stderr,
            )
        else:
            print("🔑 Using ANTHROPIC_API_KEY\n", file=sys.stderr)
        return "https://api.anthropic.com", api_key, None
    if had_credentials and not wafer_token:
        print(
            "Error: Wafer credentials expired and refresh failed.\n"
            "  Run 'wafer settings login' to re-authenticate.\n",
            file=sys.stderr,
        )
        _track_auth_failure("credentials_expired_refresh_failed", had_credentials=True, source="proxy")
    else:
        print("Error: No API credentials found", file=sys.stderr)
        print("  Run 'wafer settings login' or set ANTHROPIC_API_KEY", file=sys.stderr)
        _track_auth_failure("no_credentials", had_credentials=False, source="proxy")
    return None, None, None
def _get_session_preview(session: object) -> str:
    """Extract first user message preview from a session."""
    messages = getattr(session, "messages", None)
    if not messages:
        return ""
    for msg in messages:
        if msg.role == "user" and isinstance(msg.content, str):
            preview = msg.content[:50].replace("\n", " ")
            if len(msg.content) > 50:
                preview += "..."
            return preview
    return ""
def _get_log_file_path() -> Path:
    """Get user-specific log file path, creating directory if needed.
    Uses ~/.wafer/logs/ to avoid permission issues with shared /tmp.
    """
    log_dir = Path.home() / ".wafer" / "logs"
    log_dir.mkdir(parents=True, exist_ok=True)
    return log_dir / "wevin_debug.log"
def _setup_logging(verbose_env: bool = False) -> None:
    """Configure logging.
    By default: file only (no console spam). Root at WARNING to suppress
    third-party noise (hpack, grpc). wafer loggers at DEBUG → file.
    When verbose_env=True (custom --env): adds a stderr handler at INFO
    so sandbox lifecycle events are visible in real time.
    """
    import logging.config
    log_file = _get_log_file_path()
    handlers: dict = {
        "file": {
            "class": "logging.handlers.RotatingFileHandler",
            "filename": str(log_file),
            "maxBytes": 10_000_000,
            "backupCount": 3,
            "formatter": "json",
            "level": "DEBUG",
        },
    }
    if verbose_env:
        handlers["stderr"] = {
            "class": "logging.StreamHandler",
            "stream": "ext://sys.stderr",
            "formatter": "brief",
            "level": "INFO",
        }
    wafer_handler_list = ["file", "stderr"] if verbose_env else ["file"]
    logging.config.dictConfig({
        "version": 1,
        "disable_existing_loggers": False,
        "formatters": {
            "json": {
                "format": '{"ts": "%(asctime)s", "level": "%(levelname)s", "logger": "%(name)s", "msg": "%(message)s"}',
            },
            "brief": {
                "format": "%(asctime)s %(levelname)-5s %(name)s: %(message)s",
                "datefmt": "%H:%M:%S",
            },
        },
        "handlers": handlers,
        "loggers": {
            # wafer loggers: DEBUG to file, INFO+ to stderr when verbose
            "wafer": {"level": "DEBUG", "handlers": wafer_handler_list, "propagate": False},
            # Suppress noisy third-party loggers
            "hpack": {"level": "WARNING"},
            "grpclib": {"level": "WARNING"},
            "modal": {"level": "INFO"},
        },
        "root": {"level": "WARNING", "handlers": ["file"]},
    })
def _unwrap_exception(e: BaseException) -> BaseException:
    """Unwrap ExceptionGroup from Trio to get the actual error."""
    actual = e
    while isinstance(actual, ExceptionGroup) and actual.exceptions:
        actual = actual.exceptions[0]
    return actual
def _build_endpoint(
    tpl: TemplateConfig,
    model_override: str | None,
    api_base: str,
    api_key: str,
    api_key_refresh: Callable[[], Awaitable[str | None]] | None = None,
) -> Endpoint:
    """Build an Endpoint from template config and auth."""
    from wafer_core.rollouts import Endpoint
    resolved_model = model_override or tpl.model
    provider, model_id = resolved_model.split("/", 1)
    thinking_config = (
        {"type": "enabled", "budget_tokens": tpl.thinking_budget} if tpl.thinking else None
    )
    return Endpoint(
        provider=provider,
        model=model_id,
        api_base=api_base,
        api_key=api_key,
        api_key_refresh=api_key_refresh,
        thinking=thinking_config,
        max_tokens=tpl.max_tokens,
    )
def _build_environment(  # noqa: PLR0913
    tpl: TemplateConfig,
    tools_override: list[str] | None,
    no_sandbox: bool = False,
    has_target: bool = False,
    template_args: dict[str, str] | None = None,
    env_type: str | None = None,
    workspace_id: str | None = None,
) -> Environment:
    """Build an environment from template config.
    env_type selects the environment backend:
    - None / "local": CodingEnvironment (default, runs tools locally)
    - "workspace": WorkspaceSandboxKernelbenchEnvironment (runs tools on remote workspace)
    Working directory priority:
    1. Template arg "dir" (--args dir=./my_project) — scopes agent to a directory
    2. Current working directory
    """
    dir_arg = (template_args or {}).get("dir")
    if dir_arg:
        working_dir = Path(dir_arg).resolve()
    else:
        working_dir = Path.cwd()
    resolved_tools = list(tools_override or tpl.tools)
    if env_type == "workspace":
        assert workspace_id, "--env workspace requires --workspace <id>"
        from optimize_kernelbench_eval.environments import WorkspaceSandboxKernelbenchEnvironment
        workspace_tools = [
            t for t in resolved_tools if t in ("bash", "read", "write", "edit", "glob", "grep")
        ]
        # Agent operates entirely on remote workspace — use empty temp dir
        # (eval flow uses make_workspace_environment_factory which provides per-sample dirs)
        ws_working_dir = Path(tempfile.mkdtemp(prefix="wafer_ws_"))
        env: Environment = WorkspaceSandboxKernelbenchEnvironment(
            workspace_id=workspace_id,
            working_dir=ws_working_dir,
            enabled_tools=workspace_tools or None,
            bash_allowlist=tpl.bash_allowlist,
        )  # type: ignore[assignment]
        return env
    # Default: local CodingEnvironment
    from wafer_core.environments.coding import CodingEnvironment
    from wafer_core.rollouts.templates import DANGEROUS_BASH_COMMANDS
    from wafer_core.sandbox import SandboxMode
    if tpl.include_skills and "skill" not in resolved_tools:
        resolved_tools.append("skill")
    sandbox_mode = SandboxMode.DISABLED if no_sandbox else SandboxMode.ENABLED
    # Enable network when a target is configured or ask_docs tool is enabled
    # (ask_docs calls wafer-api over HTTP)
    allow_network = has_target or "ask_docs" in resolved_tools
    env = CodingEnvironment(
        working_dir=working_dir,
        enabled_tools=resolved_tools,
        bash_allowlist=tpl.bash_allowlist,
        bash_denylist=DANGEROUS_BASH_COMMANDS,
        sandbox_mode=sandbox_mode,
        allow_network=allow_network,
    )  # type: ignore[assignment]
    return env
def _resolve_session_id(resume: str | None, session_store: object) -> str | None:
    """Resolve session ID from resume arg. Exits on error."""
    if not resume:
        return None
    session_id = resume if resume != "last" else session_store.get_latest_id_sync()  # type: ignore[union-attr]
    if not session_id:
        print("Error: No session to resume", file=sys.stderr)
        sys.exit(1)
    return session_id
def _get_default_template() -> TemplateConfig:
    """Return the default agent template with full wafer tooling."""
    from wafer_core.rollouts.templates import TemplateConfig
    return TemplateConfig(
        name="default",
        description="GPU kernel development assistant",
        system_prompt="""You are a GPU kernel development assistant. You help with CUDA/Triton kernel optimization, profiling, and debugging.
You have access to these tools:
**File tools:**
- read: Read file contents
- write: Create new files
- edit: Modify existing files
- glob: Find files by pattern
- grep: Search file contents
**Bash:** Run shell commands including wafer CLI tools:
- `wafer tool eval gpumode --impl kernel.py --reference ref.py --test-cases tests.json` - Test kernel correctness and performance
- `wafer tool ncu analyze <file.ncu-rep>` - Analyze NCU profiling reports
- `wafer tool nsys analyze <file.nsys-rep>` - Analyze Nsight Systems traces
- `wafer tool perfetto tables <trace.json>` - Query Perfetto traces
- `wafer target config list` - List available GPU targets
When asked to profile or analyze kernels, use the appropriate wafer commands. Be concise and focus on actionable insights.""",
        tools=["read", "write", "edit", "glob", "grep", "bash"],
    )
def get_wafer_template_search_paths() -> list[Path]:
    """Get template search paths including wafer-cli bundled templates.
    Prepends the wafer-cli bundled templates directory to the standard
    search paths so bundled templates take priority over global ones.
    """
    from wafer_core.rollouts.templates.loader import _get_search_paths
    bundled_templates = Path(__file__).parent / "templates"
    search_paths = _get_search_paths()
    if bundled_templates.exists():
        search_paths = [bundled_templates] + search_paths
    return search_paths


def _load_template(
    template_name: str, template_args: dict[str, str] | None = None
) -> tuple[TemplateConfig | None, str | None]:
    """Load a wafer template. Returns (template, error)."""
    try:
        from wafer_core.rollouts.templates import load_template
        search_paths = get_wafer_template_search_paths()
        template: TemplateConfig = load_template(template_name, search_paths=search_paths)
        # Interpolate prompt variables but keep the full config
        _ = template.interpolate_prompt(template_args or {})  # validates variables exist
        return template, None
    except Exception as e:
        return None, str(e)
def main(  # noqa: PLR0913, PLR0915
    prompt: str | None = None,
    interactive: bool = False,
    single_turn: bool | None = None,  # None = use template default
    model: str | None = None,
    resume: str | None = None,
    from_turn: int | None = None,
    tools: list[str] | None = None,
    allow_spawn: bool = False,
    max_tool_fails: int | None = None,
    max_turns: int | None = None,
    template: str | None = None,
    template_args: dict[str, str] | None = None,
    list_sessions: bool = False,
    get_session: str | None = None,
    json_output: bool = False,
    no_sandbox: bool = False,
    no_proxy: bool = False,
    env_name: str | None = None,
) -> None:
    """Run wevin agent in-process via rollouts."""
    from dataclasses import asdict
    import trio
    from wafer_core.rollouts import FileSessionStore
    session_store = FileSessionStore()
    if get_session:
        async def _get_session() -> None:
            try:
                session, err = await session_store.get(get_session)
                if err or not session:
                    if json_output:
                        from .output import json_error
                        print(json_error(err or f"Session {get_session} not found"))
                        sys.exit(1)
                    else:
                        print(f"Error: {err or 'Session not found'}", file=sys.stderr)
                        sys.exit(1)
                if json_output:
                    # Serialize messages to dicts
                    try:
                        messages_data = [asdict(msg) for msg in session.messages]
                    except Exception as e:
                        from .output import json_error
                        error_msg = f"Failed to serialize messages: {e}"
                        print(json_error(error_msg))
                        sys.exit(1)
                    from .output import json_response
                    print(
                        json_response(data={
                            "session_id": session.session_id,
                            "status": session.status.value,
                            "model": session.endpoint.model if session.endpoint else None,
                            "created_at": session.created_at,
                            "updated_at": session.updated_at,
                            "messages": messages_data,
                            "tags": session.tags,
                        })
                    )
                else:
                    print(f"Session: {session.session_id}")
                    print(f"Status: {session.status.value}")
                    print(f"Messages: {len(session.messages)}")
                    for i, msg in enumerate(session.messages):
                        # Fail fast if message can't be converted to string - corrupted data is a bug
                        content_preview = str(msg.content)[:100] if msg.content else ""
                        print(f"  [{i}] {msg.role}: {content_preview}...")
            except KeyboardInterrupt:
                # User cancelled - exit cleanly
                sys.exit(130)  # Standard exit code for SIGINT
            except Exception as e:
                # Any other error - log and exit with error
                error_msg = f"Failed to load session {get_session}: {e}"
                if json_output:
                    from .output import json_error
                    print(json_error(error_msg))
                else:
                    print(f"Error: {error_msg}", file=sys.stderr)
                sys.exit(1)
        try:
            trio.run(_get_session)
        except KeyboardInterrupt:
            sys.exit(130)
        except Exception as e:
            error_msg = f"Failed to run session loader: {e}"
            if json_output:
                from .output import json_error
                print(json_error(error_msg))
            else:
                print(f"Error: {error_msg}", file=sys.stderr)
            sys.exit(1)
        return
    if list_sessions:
        sessions = session_store.list_sync(limit=50)
        if json_output:
            sessions_data = []
            for s in sessions:
                sessions_data.append({
                    "session_id": s.session_id,
                    "status": s.status.value,
                    "model": s.endpoint.model if s.endpoint else None,
                    "created_at": s.created_at if hasattr(s, "created_at") else None,
                    "updated_at": s.updated_at if hasattr(s, "updated_at") else None,
                    "message_count": len(s.messages),
                    "preview": _get_session_preview(s),
                })
            from .output import json_response
            print(json_response(data={"sessions": sessions_data}))
        else:
            if not sessions:
                print("No sessions found.")
            else:
                print("Recent sessions:")
                for s in sessions:
                    preview = _get_session_preview(s)
                    print(f"  {s.session_id}  {preview}")
        return
    # Emit early event for JSON mode before heavy imports
    # This gives immediate feedback that the CLI started correctly
    if json_output:
        print(json.dumps({"type": "initializing"}), flush=True)
    from wafer_core.rollouts import Message, Trajectory
    from wafer_core.rollouts.frontends import NoneFrontend, RunnerConfig, run_interactive
    _setup_logging(verbose_env=env_name is not None)
    _agent_logger = logging.getLogger("wafer.agent")
    # Auth
    api_base, api_key, api_key_refresh = _get_wafer_auth(no_proxy=no_proxy)
    if not api_base or not api_key:
        sys.exit(1)
    assert api_base is not None
    assert api_key is not None
    # Set env vars so in-process tools (ask_docs) can reach wafer-api
    from .global_config import get_api_url
    if "WAFER_API_URL" not in os.environ:
        os.environ["WAFER_API_URL"] = get_api_url()
    if "WAFER_AUTH_TOKEN" not in os.environ and not no_proxy:
        from .auth import get_valid_token
        _token = get_valid_token()
        if _token:
            os.environ["WAFER_AUTH_TOKEN"] = _token
    if template:
        loaded_template, err = _load_template(template, template_args)
        if err or loaded_template is None:
            print(f"Error: Template not found: {template}", file=sys.stderr)
            print(f"  Detail: {err}", file=sys.stderr)
            # List available bundled templates
            bundled_dir = Path(__file__).parent / "templates"
            if bundled_dir.exists():
                names = sorted(p.stem for p in bundled_dir.iterdir() if p.suffix == ".py")
                if names:
                    print(f"  Available templates: {', '.join(names)}", file=sys.stderr)
            sys.exit(1)
        tpl = loaded_template
        base_system_prompt = tpl.interpolate_prompt(template_args or {})
        # Show template info when starting without a prompt
        if not prompt and tpl.description:
            print(f"Template: {tpl.name}", file=sys.stderr)
            print(f"  {tpl.description}", file=sys.stderr)
            print(file=sys.stderr)
    else:
        tpl = _get_default_template()
        base_system_prompt = tpl.system_prompt
    # Append skill metadata if skills are enabled
    if tpl.include_skills:
        from wafer_core.rollouts.skills import discover_skills, format_skill_metadata_for_prompt
        skill_metadata = discover_skills()
        if skill_metadata:
            skill_section = format_skill_metadata_for_prompt(skill_metadata)
            system_prompt = base_system_prompt + "\n\n" + skill_section
        else:
            system_prompt = base_system_prompt
    else:
        system_prompt = base_system_prompt
    # CLI args override template values
    resolved_single_turn = single_turn if single_turn is not None else tpl.single_turn
    # so the agent can reach remote GPUs via SSH/HTTPS.
    has_target = False
    try:
        from wafer.targets import get_default_target
        has_target = get_default_target() is not None
    except Exception:
        pass  # No target configured — network stays disabled
    endpoint = _build_endpoint(tpl, model, api_base, api_key, api_key_refresh)
    if env_name:
        from wafer_core.environments.registry import get_environment_factory
        factory = get_environment_factory(env_name)
        env_kwargs = dict(template_args or {})
        # Forward relevant CLI flags as kwargs
        if no_sandbox:
            env_kwargs["no_sandbox"] = True
        environment = factory(**env_kwargs)
        _agent_logger.info("Environment created: %s (env=%s)", type(environment).__name__, env_name)
    else:
        environment = _build_environment(
            tpl, tools, no_sandbox, has_target=has_target, template_args=template_args
        )
    # Session store
    session_store = FileSessionStore()
    session_id = _resolve_session_id(resume, session_store)
    async def run() -> None:
        nonlocal session_id

        if hasattr(environment, "setup"):
            await environment.setup()
        if session_id:
            existing_session, err = await session_store.get(session_id)
            if err:
                print(f"Error loading session: {err}", file=sys.stderr)
                sys.exit(1)
            assert existing_session is not None
            trajectory = Trajectory(messages=existing_session.messages)
        else:
            trajectory = Trajectory(messages=[Message(role="system", content=system_prompt)])
        try:
            if interactive:
                from wafer_core.rollouts.frontends.tui.interactive_agent import (
                    run_interactive_agent,
                )
                await run_interactive_agent(
                    trajectory,
                    endpoint,
                    environment,
                    session_store,
                    session_id,
                    theme_name="minimal",
                    debug=False,
                    debug_layout=False,
                    initial_prompt=prompt,
                )
            else:
                if json_output:
                    # Emit session_start if we have a session_id (from --resume)
                    model_name = endpoint.model if hasattr(endpoint, "model") else None
                    frontend = StreamingChunkFrontend(session_id=session_id, model=model_name)
                else:
                    frontend = NoneFrontend(show_tool_calls=True, show_thinking=False)
                config = RunnerConfig(
                    session_store=session_store,
                    session_id=session_id,
                    initial_prompt=prompt,
                    single_turn=resolved_single_turn,
                    hide_session_info=True,  # We print our own resume command
                )
                _agent_logger.info(
                    "Starting run_interactive (single_turn=%s, prompt=%s)",
                    resolved_single_turn,
                    bool(prompt),
                )
                states = await run_interactive(trajectory, endpoint, frontend, environment, config)
                _agent_logger.info("run_interactive completed (%d states)", len(states))
                # Emit session_start for new sessions (if session_id was None and we got one)
                if json_output and isinstance(frontend, StreamingChunkFrontend):
                    first_session_id = (
                        states[0].session_id if states and states[0].session_id else None
                    )
                    if first_session_id and not session_id:  # New session created
                        model_name = endpoint.model if hasattr(endpoint, "model") else None
                        frontend.emit_session_start(first_session_id, model_name)
                # Print resume command with full wafer agent prefix
                if states and states[-1].session_id:
                    print(f"\nResume with: wafer agent --resume {states[-1].session_id}")
        except KeyboardInterrupt:
            pass
        except BaseException as e:
            actual_error = _unwrap_exception(e)
            print(f"\n{type(actual_error).__name__}: {actual_error}", file=sys.stderr)
            sys.exit(1)
    # Some environments (e.g. Modal sandbox) use asyncio SDKs and need a bridge
    if env_name:
        from wafer_core.environments.registry import needs_asyncio_bridge
        if needs_asyncio_bridge(env_name):
            import trio_asyncio
            # Suppress grpclib Channel.__del__ RuntimeError during shutdown.
            # When gRPC channels are GC'd after trio_asyncio loop closes, the
            # __del__ tries to schedule cleanup and hits "can't nest run_until_complete".
            # This is harmless — the channels are being destroyed anyway.
            try:
                from grpclib.client import Channel as _GrpcChannel
                _orig_del = _GrpcChannel.__del__
                def _quiet_del(self: object) -> None:
                    try:
                        _orig_del(self)
                    except RuntimeError:
                        pass
                _GrpcChannel.__del__ = _quiet_del
            except ImportError:
                pass
            async def run_with_asyncio() -> None:
                async with trio_asyncio.open_loop():
                    await run()
            trio.run(run_with_asyncio)
            return
    trio.run(run)
