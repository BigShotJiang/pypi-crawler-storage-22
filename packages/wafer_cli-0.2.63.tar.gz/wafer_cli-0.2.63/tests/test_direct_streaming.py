"""Tests for direct endpoint streaming (_stream_direct_endpoint).

Tests SSE parsing, output formatting for tool_call/tool_result/text/error
events, and JSON mode re-emission.

Run with:
    PYTHONPATH=apps/wafer-cli uv run pytest apps/wafer-cli/tests/test_direct_streaming.py -v
"""
from __future__ import annotations

import json
from unittest.mock import AsyncMock, MagicMock, patch

import pytest
import trio

from wafer.wevin_cli import (
    _format_tool_call_summary,
    _format_tool_result_summary,
    _stream_direct_endpoint,
)


# ---------------------------------------------------------------------------
# Unit tests for formatting helpers
# ---------------------------------------------------------------------------


class TestFormatToolCallSummary:
    def test_grep(self) -> None:
        result = _format_tool_call_summary("grep", {"pattern": "shared memory"})
        assert result == 'searching: grep("shared memory")...'

    def test_read_file(self) -> None:
        result = _format_tool_call_summary("read_file", {"path": "./guide/memory.md"})
        assert result == "reading: ./guide/memory.md..."

    def test_list_files(self) -> None:
        result = _format_tool_call_summary("list_files", {"pattern": "*.md"})
        assert result == 'listing: find("*.md")...'

    def test_list_files_default(self) -> None:
        result = _format_tool_call_summary("list_files", {})
        assert result == 'listing: find("*")...'

    def test_unknown_tool(self) -> None:
        result = _format_tool_call_summary("some_tool", {"x": 1})
        assert "some_tool" in result


class TestFormatToolResultSummary:
    def test_no_matches(self) -> None:
        result = _format_tool_result_summary("grep", "No matches found.")
        assert result == "no results"

    def test_no_files(self) -> None:
        result = _format_tool_result_summary("list_files", "No files found matching pattern.")
        assert result == "no results"

    def test_error(self) -> None:
        result = _format_tool_result_summary("read_file", "Error: file not found")
        assert result.startswith("Error:")

    def test_grep_matches(self) -> None:
        content = "line1\nline2\nline3\n"
        result = _format_tool_result_summary("grep", content)
        assert "3 matches" in result

    def test_read_file_lines(self) -> None:
        content = "a\nb\nc\nd\ne\n"
        result = _format_tool_result_summary("read_file", content)
        assert "5 lines" in result

    def test_list_files_count(self) -> None:
        content = "./a.md\n./b.md\n"
        result = _format_tool_result_summary("list_files", content)
        assert "2 files" in result

    def test_unknown_tool_char_count(self) -> None:
        result = _format_tool_result_summary("unknown", "abcdef")
        assert "6 chars" in result


# ---------------------------------------------------------------------------
# SSE streaming integration tests (mocked httpx)
# ---------------------------------------------------------------------------


def _make_sse_lines(events: list[dict]) -> list[str]:
    """Build SSE lines from a list of event dicts."""
    lines = []
    for ev in events:
        lines.append(f"data: {json.dumps(ev)}")
    lines.append("data: [DONE]")
    return lines


class _FakeResponse:
    """Fake httpx streaming response."""

    def __init__(self, lines: list[str], status_code: int = 200) -> None:
        self.status_code = status_code
        self._lines = lines
        self._raw_body = b""

    async def aiter_lines(self):
        for line in self._lines:
            yield line

    async def aread(self) -> bytes:
        return self._raw_body

    async def __aenter__(self):
        return self

    async def __aexit__(self, *args):
        pass


class _FakeClient:
    """Fake httpx.AsyncClient that returns a _FakeResponse from .stream()."""

    def __init__(self, response: _FakeResponse) -> None:
        self._response = response
        self.last_url: str | None = None
        self.last_json: dict | None = None
        self.last_headers: dict | None = None

    def stream(self, method: str, url: str, *, json: dict | None = None, headers: dict | None = None):
        self.last_url = url
        self.last_json = json
        self.last_headers = headers
        return self._response

    async def __aenter__(self):
        return self

    async def __aexit__(self, *args):
        pass


class TestStreamDirectEndpoint:
    """Tests for _stream_direct_endpoint with mocked HTTP."""

    def _run(self, events: list[dict], *, json_output: bool = False, status_code: int = 200, **kwargs) -> tuple[_FakeClient, list[str], list[str]]:
        """Run _stream_direct_endpoint with mocked httpx, return (client, stdout_lines, stderr_lines)."""
        lines = _make_sse_lines(events)
        response = _FakeResponse(lines, status_code=status_code)
        client = _FakeClient(response)

        stdout_capture: list[str] = []
        stderr_capture: list[str] = []

        def mock_print(*args, **kw):
            file = kw.get("file")
            import sys
            text = " ".join(str(a) for a in args)
            if file is sys.stderr:
                stderr_capture.append(text)
            else:
                stdout_capture.append(text)

        async def _run_inner():
            with patch("httpx.AsyncClient", return_value=client):
                with patch("builtins.print", side_effect=mock_print):
                    await _stream_direct_endpoint(
                        api_url=kwargs.get("api_url", "https://api.wafer.ai"),
                        auth_token=kwargs.get("auth_token", "test-token"),
                        endpoint_path=kwargs.get("endpoint_path", "/v1/docs/query"),
                        query=kwargs.get("query", "How do bank conflicts work?"),
                        template_args=kwargs.get("template_args", None),
                        defaults=kwargs.get("defaults", {"corpus": "cuda"}),
                        json_output=json_output,
                    )

        trio.run(_run_inner)
        return client, stdout_capture, stderr_capture

    def test_text_events_stream_to_stdout(self) -> None:
        events = [
            {"type": "text", "content": "Bank conflicts occur "},
            {"type": "text", "content": "when threads access "},
            {"type": "text", "content": "the same bank."},
            {"type": "done"},
        ]
        _, stdout, stderr = self._run(events)
        text_output = "".join(stdout)
        assert "Bank conflicts occur " in text_output
        assert "when threads access " in text_output
        assert "the same bank." in text_output

    def test_tool_call_events_render_to_stderr(self) -> None:
        events = [
            {"type": "tool_call", "name": "grep", "input": {"pattern": "bank conflict"}},
            {"type": "tool_result", "name": "grep", "content": "line1\nline2\nline3\n"},
            {"type": "text", "content": "Answer here."},
            {"type": "done"},
        ]
        _, stdout, stderr = self._run(events)
        # tool_call and tool_result go to stderr (dim status)
        stderr_text = " ".join(stderr)
        assert "grep" in stderr_text
        # Text goes to stdout
        assert any("Answer here." in s for s in stdout)

    def test_tool_result_no_matches(self) -> None:
        events = [
            {"type": "tool_call", "name": "grep", "input": {"pattern": "nonexistent"}},
            {"type": "tool_result", "name": "grep", "content": "No matches found."},
            {"type": "text", "content": "No results."},
            {"type": "done"},
        ]
        _, _, stderr = self._run(events)
        stderr_text = " ".join(stderr)
        assert "no results" in stderr_text

    def test_error_event_to_stderr(self) -> None:
        events = [
            {"type": "error", "content": "Anthropic API error 500"},
        ]
        _, _, stderr = self._run(events)
        stderr_text = " ".join(stderr)
        assert "Anthropic API error 500" in stderr_text

    def test_request_body_merges_defaults_and_args(self) -> None:
        events = [{"type": "text", "content": "ok"}, {"type": "done"}]
        client, _, _ = self._run(
            events,
            defaults={"corpus": "cuda"},
            template_args={"corpus": "hip"},
            query="test question",
        )
        assert client.last_json is not None
        assert client.last_json["corpus"] == "hip"  # template_args override defaults
        assert client.last_json["query"] == "test question"

    def test_request_url_construction(self) -> None:
        events = [{"type": "text", "content": "ok"}, {"type": "done"}]
        client, _, _ = self._run(
            events,
            api_url="https://api.wafer.ai",
            endpoint_path="/v1/docs/query",
        )
        assert client.last_url == "https://api.wafer.ai/v1/docs/query"

    def test_request_url_strips_trailing_slash(self) -> None:
        events = [{"type": "text", "content": "ok"}, {"type": "done"}]
        client, _, _ = self._run(
            events,
            api_url="https://api.wafer.ai/",
            endpoint_path="/v1/docs/query",
        )
        assert client.last_url == "https://api.wafer.ai/v1/docs/query"

    def test_auth_header_sent(self) -> None:
        events = [{"type": "text", "content": "ok"}, {"type": "done"}]
        client, _, _ = self._run(events, auth_token="my-secret-token")
        assert client.last_headers is not None
        assert client.last_headers["Authorization"] == "Bearer my-secret-token"

    def test_json_mode_text_events(self) -> None:
        events = [
            {"type": "text", "content": "Hello "},
            {"type": "text", "content": "world"},
            {"type": "done"},
        ]
        _, stdout, _ = self._run(events, json_output=True)
        # In JSON mode, output is NDJSON lines
        json_events = [json.loads(line) for line in stdout if line.strip()]
        text_deltas = [e for e in json_events if e.get("type") == "text_delta"]
        assert len(text_deltas) == 2
        assert text_deltas[0]["delta"] == "Hello "
        assert text_deltas[1]["delta"] == "world"

    def test_json_mode_tool_events(self) -> None:
        events = [
            {"type": "tool_call_start", "name": "grep"},
            {"type": "tool_call", "name": "grep", "input": {"pattern": "warp"}},
            {"type": "tool_result", "name": "grep", "content": "line1\n"},
            {"type": "text", "content": "Answer"},
            {"type": "done"},
        ]
        _, stdout, _ = self._run(events, json_output=True)
        json_events = [json.loads(line) for line in stdout if line.strip()]
        types = [e["type"] for e in json_events]
        assert "tool_call_start" in types
        assert "tool_call_end" in types
        assert "tool_result" in types
        assert "text_delta" in types
        assert "session_end" in types
        # Exactly one tool_call_start (from tool_call_start event, not duplicated by tool_call event)
        assert types.count("tool_call_start") == 1

    def test_json_mode_error_event(self) -> None:
        events = [
            {"type": "error", "content": "Something went wrong"},
        ]
        _, stdout, _ = self._run(events, json_output=True)
        json_events = [json.loads(line) for line in stdout if line.strip()]
        error_events = [e for e in json_events if e.get("type") == "error"]
        assert len(error_events) == 1
        assert error_events[0]["error"] == "Something went wrong"

    def test_http_401_exits(self) -> None:
        response = _FakeResponse([], status_code=401)
        client = _FakeClient(response)

        with pytest.raises(SystemExit) as exc_info:
            async def _run_inner():
                with patch("httpx.AsyncClient", return_value=client):
                    await _stream_direct_endpoint(
                        api_url="https://api.wafer.ai",
                        auth_token="bad-token",
                        endpoint_path="/v1/docs/query",
                        query="test",
                        template_args=None,
                        defaults={"corpus": "cuda"},
                        json_output=False,
                    )
            trio.run(_run_inner)
        assert exc_info.value.code == 1

    def test_http_402_exits(self) -> None:
        response = _FakeResponse([], status_code=402)
        client = _FakeClient(response)

        with pytest.raises(SystemExit) as exc_info:
            async def _run_inner():
                with patch("httpx.AsyncClient", return_value=client):
                    await _stream_direct_endpoint(
                        api_url="https://api.wafer.ai",
                        auth_token="token",
                        endpoint_path="/v1/docs/query",
                        query="test",
                        template_args=None,
                        defaults={"corpus": "cuda"},
                        json_output=False,
                    )
            trio.run(_run_inner)
        assert exc_info.value.code == 1

    def test_multiple_tool_turns(self) -> None:
        events = [
            {"type": "tool_call", "name": "grep", "input": {"pattern": "bank conflict"}},
            {"type": "tool_result", "name": "grep", "content": "file.md:10:bank conflict\n"},
            {"type": "tool_call", "name": "read_file", "input": {"path": "./file.md"}},
            {"type": "tool_result", "name": "read_file", "content": "Full content here\n"},
            {"type": "text", "content": "Final answer."},
            {"type": "done"},
        ]
        _, stdout, stderr = self._run(events)
        stderr_text = " ".join(stderr)
        assert "grep" in stderr_text
        assert "reading" in stderr_text
        assert any("Final answer." in s for s in stdout)

    def test_sources_event_renders_to_stderr(self) -> None:
        events = [
            {"type": "text", "content": "Answer here."},
            {"type": "sources", "files": ["./memory.md", "./guide.md"]},
            {"type": "done"},
        ]
        _, _, stderr = self._run(events)
        stderr_text = " ".join(stderr)
        assert "Sources" in stderr_text
        assert "./memory.md" in stderr_text
        assert "./guide.md" in stderr_text

    def test_json_mode_sources_event(self) -> None:
        events = [
            {"type": "text", "content": "Answer"},
            {"type": "sources", "files": ["./memory.md"]},
            {"type": "done"},
        ]
        _, stdout, _ = self._run(events, json_output=True)
        json_events = [json.loads(line) for line in stdout if line.strip()]
        sources_events = [e for e in json_events if e.get("type") == "sources"]
        assert len(sources_events) == 1
        assert sources_events[0]["files"] == ["./memory.md"]

    def test_turn_start_renders_to_stderr(self) -> None:
        """turn_start event should print turn number to stderr."""
        events = [
            {"type": "turn_start", "turn": 1, "max_turns": 10},
            {"type": "text", "content": "Answer."},
            {"type": "done"},
        ]
        _, _, stderr = self._run(events)
        stderr_text = " ".join(stderr)
        assert "[Turn 1]" in stderr_text
        assert "Searching documentation" in stderr_text

    def test_tool_call_start_renders_to_stderr(self) -> None:
        """tool_call_start event should print tool name to stderr."""
        events = [
            {"type": "turn_start", "turn": 1, "max_turns": 10},
            {"type": "tool_call_start", "name": "grep"},
            {"type": "tool_call", "name": "grep", "input": {"pattern": "test"}},
            {"type": "tool_exec_start", "name": "grep", "index": 1, "total": 1},
            {"type": "tool_result", "name": "grep", "content": "match\n"},
            {"type": "text", "content": "Answer."},
            {"type": "done"},
        ]
        _, _, stderr = self._run(events)
        stderr_text = " ".join(stderr)
        assert "Calling grep" in stderr_text

    def test_tool_exec_start_renders_to_stderr(self) -> None:
        """tool_exec_start event should print tool execution progress to stderr."""
        events = [
            {"type": "turn_start", "turn": 1, "max_turns": 10},
            {"type": "tool_call_start", "name": "grep"},
            {"type": "tool_call", "name": "grep", "input": {"pattern": "test"}},
            {"type": "tool_exec_start", "name": "grep", "index": 2, "total": 5},
            {"type": "tool_result", "name": "grep", "content": "match\n"},
            {"type": "text", "content": "Answer."},
            {"type": "done"},
        ]
        _, _, stderr = self._run(events)
        stderr_text = " ".join(stderr)
        assert "Executing grep (2/5)" in stderr_text

    def test_turn_start_json_mode(self) -> None:
        """turn_start in JSON mode should emit a status event."""
        events = [
            {"type": "turn_start", "turn": 1, "max_turns": 10},
            {"type": "text", "content": "Answer"},
            {"type": "done"},
        ]
        _, stdout, _ = self._run(events, json_output=True)
        json_events = [json.loads(line) for line in stdout if line.strip()]
        status_events = [e for e in json_events if e.get("type") == "status"]
        assert len(status_events) == 1
        assert "Turn 1/10" in status_events[0]["message"]

    def test_tool_exec_start_json_mode(self) -> None:
        """tool_exec_start in JSON mode should emit a tool_exec_start event."""
        events = [
            {"type": "turn_start", "turn": 1, "max_turns": 10},
            {"type": "tool_call_start", "name": "grep"},
            {"type": "tool_call", "name": "grep", "input": {"pattern": "test"}},
            {"type": "tool_exec_start", "name": "grep", "index": 1, "total": 3},
            {"type": "tool_result", "name": "grep", "content": "match\n"},
            {"type": "text", "content": "Answer"},
            {"type": "done"},
        ]
        _, stdout, _ = self._run(events, json_output=True)
        json_events = [json.loads(line) for line in stdout if line.strip()]
        exec_events = [e for e in json_events if e.get("type") == "tool_exec_start"]
        assert len(exec_events) == 1
        assert exec_events[0]["tool_name"] == "grep"
        assert exec_events[0]["index"] == 1
        assert exec_events[0]["total"] == 3

    def test_full_progress_sequence(self) -> None:
        """Full event sequence renders all progress lines in correct order."""
        events = [
            {"type": "turn_start", "turn": 1, "max_turns": 10},
            {"type": "tool_call_start", "name": "grep"},
            {"type": "tool_call", "name": "grep", "input": {"pattern": "bank conflict"}},
            {"type": "tool_exec_start", "name": "grep", "index": 1, "total": 2},
            {"type": "tool_result", "name": "grep", "content": "file.md:10:bank conflict\n"},
            {"type": "tool_call_start", "name": "read_file"},
            {"type": "tool_call", "name": "read_file", "input": {"path": "./file.md"}},
            {"type": "tool_exec_start", "name": "read_file", "index": 2, "total": 2},
            {"type": "tool_result", "name": "read_file", "content": "Full content here\n"},
            {"type": "turn_start", "turn": 2, "max_turns": 10},
            {"type": "text", "content": "Final answer."},
            {"type": "done"},
        ]
        _, stdout, stderr = self._run(events)
        stderr_text = " ".join(stderr)
        assert "[Turn 1]" in stderr_text
        assert "Calling grep" in stderr_text
        assert "Executing grep (1/2)" in stderr_text
        assert "Executing read_file (2/2)" in stderr_text
        assert "[Turn 2]" in stderr_text
        assert any("Final answer." in s for s in stdout)
