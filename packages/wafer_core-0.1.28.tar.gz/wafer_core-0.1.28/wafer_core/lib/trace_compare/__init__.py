"""Trace comparison library for analyzing GPU traces across platforms.

This module provides functionality to compare performance traces from AMD and NVIDIA GPUs,
identifying kernel-level performance differences and fusion opportunities.
"""

from .analyzer import analyze_traces
from .api import TraceComparisonResult, analyze_trace_pair
from .architecture import ArchitectureType, detect_architecture
from .classifier import Op, classify
from .aligner import align_traces, TraceAlignment, LayerAlignment, KernelPair
from .formatter import (
    format_csv,
    format_json,
    format_text,
)
from .fusion_analyzer import analyze_fusion_from_alignment
from .same_kernel_analyzer import analyze_same_kernels_from_alignment
from .loader import load_trace, load_trace_streaming, StreamingMetadata
from .warnings import TraceWarning, detect_warnings

__all__ = [
    "Op",
    "classify",
    "load_trace",
    "load_trace_streaming",
    "StreamingMetadata",
    "analyze_traces",
    "format_text",
    "format_csv",
    "format_json",
    # New alignment exports
    "TraceComparisonResult",
    "analyze_trace_pair",
    "ArchitectureType",
    "detect_architecture",
    "TraceWarning",
    "detect_warnings",
    "align_traces",
    "TraceAlignment",
    "LayerAlignment",
    "KernelPair",
    "analyze_fusion_from_alignment",
    "analyze_same_kernels_from_alignment",
]
