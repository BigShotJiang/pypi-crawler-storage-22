"""Tests for trace comparison functionality."""
