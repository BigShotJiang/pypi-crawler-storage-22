// Utility functions header
#pragma once

__device__ float square(float x) {
    return x * x;
}

__device__ float cube(float x) {
    return x * x * x;
}
