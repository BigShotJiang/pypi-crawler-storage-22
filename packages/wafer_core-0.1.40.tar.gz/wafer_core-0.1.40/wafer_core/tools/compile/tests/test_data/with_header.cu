// Kernel using header
#include "utils.cuh"

__global__ void apply_square(float* data, int n) {
    int idx = blockIdx.x * blockDim.x + threadIdx.x;
    if (idx < n) {
        data[idx] = square(data[idx]);
    }
}
