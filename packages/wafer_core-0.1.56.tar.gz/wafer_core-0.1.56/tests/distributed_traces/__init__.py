"""Tests for distributed traces module."""
