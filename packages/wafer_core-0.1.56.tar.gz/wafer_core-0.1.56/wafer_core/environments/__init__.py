"""Wafer environments for agent execution."""

from wafer_core.environments.coding import CodingEnvironment
from wafer_core.environments.gpumode import GPUModeSimpleEnvironment
from wafer_core.environments.remote_target import RemoteTargetEnvironment

__all__ = ["CodingEnvironment", "GPUModeSimpleEnvironment", "RemoteTargetEnvironment"]
