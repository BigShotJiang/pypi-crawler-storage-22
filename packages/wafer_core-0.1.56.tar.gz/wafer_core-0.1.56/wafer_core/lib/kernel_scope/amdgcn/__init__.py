"""AMDGCN ISA parsing and analysis."""

from wafer_core.lib.kernel_scope.amdgcn.parser import parse_isa_file, parse_isa_text
from wafer_core.lib.kernel_scope.amdgcn.analyzer import analyze_isa, ISAAnalysis
from wafer_core.lib.kernel_scope.amdgcn.types import (
    ISAParseResult,
    KernelMetadata,
    InstructionInfo,
    InstructionCategory,
    PackableOpPair,
    PackableSequence,
    PackedOpportunityAnalysis,
)
from wafer_core.lib.kernel_scope.amdgcn.packed_opportunity_detector import (
    detect_packed_opportunities,
    detect_packable_pairs,
    format_packed_analysis,
    suggest_packed_rewrite,
)

__all__ = [
    "parse_isa_file",
    "parse_isa_text",
    "analyze_isa",
    "ISAAnalysis",
    "ISAParseResult",
    "KernelMetadata",
    "InstructionInfo",
    "InstructionCategory",
    # Packed operation opportunity detection
    "detect_packed_opportunities",
    "detect_packable_pairs",
    "format_packed_analysis",
    "suggest_packed_rewrite",
    "PackableOpPair",
    "PackableSequence",
    "PackedOpportunityAnalysis",
]
