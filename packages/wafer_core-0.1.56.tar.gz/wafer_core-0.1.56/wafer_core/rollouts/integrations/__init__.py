"""Integrations with external frameworks."""
