
from lsprotocol.types import CompletionItem


def handle_completion(uri: str, position, content: str) -> list[CompletionItem]:
    return []
