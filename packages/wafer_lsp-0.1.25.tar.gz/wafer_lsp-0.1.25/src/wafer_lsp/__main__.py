from wafer_lsp.server import server


def main():
    server.start_io()


if __name__ == "__main__":
    main()
