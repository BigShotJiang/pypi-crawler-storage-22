# Template tags module for wagtail-localize-intentional-blanks
