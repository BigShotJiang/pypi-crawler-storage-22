"""
Tests for wagtail-thumbnail-choice-block
"""
