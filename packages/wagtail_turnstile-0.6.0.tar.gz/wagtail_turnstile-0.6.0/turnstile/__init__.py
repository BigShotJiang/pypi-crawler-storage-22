default_app_config = "turnstyle.apps.TurnstileConfig"
__version__ = "0.6.0"
