from django.apps import AppConfig


class TurnstileConfig(AppConfig):
    name = "turnstile"
    label = "turnstile"
    verbose_name = "Wagtail Turnstile"
