class VideoChooser extends window.ImageChooser {
}
window.VideoChooser = VideoChooser;
