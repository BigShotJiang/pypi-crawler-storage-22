"""waitfor - Wait for conditions in automation and scripts."""

__version__ = "0.1.0"
