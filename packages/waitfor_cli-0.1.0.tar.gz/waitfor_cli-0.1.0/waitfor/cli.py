#!/usr/bin/env python3
"""waitfor - Wait for conditions (port, file, URL, process) in automation scripts."""

import click
import socket
import time
import os
import sys
import json
import subprocess
from pathlib import Path
from typing import Optional, Callable, Any, Dict
from urllib.request import urlopen, Request
from urllib.error import URLError, HTTPError


def wait_loop(
    check_fn: Callable[[], bool],
    condition_name: str,
    timeout: int,
    interval: float,
    quiet: bool,
    json_output: bool,
    invert: bool = False
) -> Dict[str, Any]:
    """Generic wait loop. Returns result dict."""
    start = time.time()
    attempts = 0
    
    while True:
        attempts += 1
        elapsed = time.time() - start
        
        try:
            result = check_fn()
            # If invert, we want the check to be False
            success = (not result) if invert else result
        except Exception as e:
            if not quiet and not json_output:
                click.echo(f"  Check error: {e}", err=True)
            success = invert  # Error counts as False, which is success if inverted
        
        if success:
            result_data = {
                "success": True,
                "condition": condition_name,
                "elapsed_seconds": round(elapsed, 2),
                "attempts": attempts
            }
            if json_output:
                click.echo(json.dumps(result_data))
            elif not quiet:
                click.echo(f"✓ {condition_name} (took {elapsed:.1f}s, {attempts} attempts)")
            return result_data
        
        if timeout > 0 and elapsed >= timeout:
            result_data = {
                "success": False,
                "condition": condition_name,
                "elapsed_seconds": round(elapsed, 2),
                "attempts": attempts,
                "error": f"Timeout after {timeout}s"
            }
            if json_output:
                click.echo(json.dumps(result_data))
            elif not quiet:
                click.echo(f"✗ Timeout waiting for {condition_name}", err=True)
            return result_data
        
        if not quiet and not json_output:
            click.echo(f"  Waiting for {condition_name}... ({elapsed:.0f}s)", err=True)
        
        time.sleep(interval)


@click.group()
@click.version_option()
def cli():
    """Wait for conditions in automation scripts.
    
    Useful for waiting on services, files, or processes before continuing.
    
    Examples:
    
        waitfor port 8080
        
        waitfor file /tmp/ready.flag
        
        waitfor url http://localhost:3000/health
        
        waitfor process nginx
    """
    pass


@cli.command("port")
@click.argument("port", type=int)
@click.option("-h", "--host", default="localhost", help="Host to check")
@click.option("-t", "--timeout", default=30, help="Timeout in seconds (0=forever)")
@click.option("-i", "--interval", default=1.0, help="Check interval in seconds")
@click.option("-q", "--quiet", is_flag=True, help="Suppress output")
@click.option("--json", "json_output", is_flag=True, help="JSON output")
@click.option("--closed", is_flag=True, help="Wait for port to be CLOSED instead")
def wait_port(port: int, host: str, timeout: int, interval: float, quiet: bool, json_output: bool, closed: bool):
    """Wait for a TCP port to be open (or closed with --closed)."""
    
    def check_port():
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        sock.settimeout(1)
        try:
            result = sock.connect_ex((host, port))
            return result == 0
        finally:
            sock.close()
    
    action = "closed" if closed else "open"
    condition = f"port {port} on {host} to be {action}"
    result = wait_loop(check_port, condition, timeout, interval, quiet, json_output, invert=closed)
    sys.exit(0 if result["success"] else 1)


@cli.command("file")
@click.argument("path")
@click.option("-t", "--timeout", default=30, help="Timeout in seconds (0=forever)")
@click.option("-i", "--interval", default=1.0, help="Check interval in seconds")
@click.option("-q", "--quiet", is_flag=True, help="Suppress output")
@click.option("--json", "json_output", is_flag=True, help="JSON output")
@click.option("--gone", is_flag=True, help="Wait for file to be GONE instead")
@click.option("--contains", "content", help="Wait for file to contain this string")
def wait_file(path: str, timeout: int, interval: float, quiet: bool, json_output: bool, gone: bool, content: Optional[str]):
    """Wait for a file to exist (or be gone with --gone)."""
    
    def check_file():
        p = Path(path)
        if not p.exists():
            return False
        if content:
            try:
                return content in p.read_text()
            except:
                return False
        return True
    
    if content:
        condition = f"file {path} to contain '{content}'"
    elif gone:
        condition = f"file {path} to be gone"
    else:
        condition = f"file {path} to exist"
    
    result = wait_loop(check_file, condition, timeout, interval, quiet, json_output, invert=gone)
    sys.exit(0 if result["success"] else 1)


@cli.command("url")
@click.argument("url")
@click.option("-t", "--timeout", default=30, help="Timeout in seconds (0=forever)")
@click.option("-i", "--interval", default=2.0, help="Check interval in seconds")
@click.option("-q", "--quiet", is_flag=True, help="Suppress output")
@click.option("--json", "json_output", is_flag=True, help="JSON output")
@click.option("--status", type=int, help="Expected HTTP status code (default: any 2xx)")
@click.option("--contains", "content", help="Response must contain this string")
def wait_url(url: str, timeout: int, interval: float, quiet: bool, json_output: bool, status: Optional[int], content: Optional[str]):
    """Wait for a URL to respond successfully."""
    
    def check_url():
        try:
            req = Request(url, headers={"User-Agent": "waitfor/1.0"})
            resp = urlopen(req, timeout=5)
            code = resp.getcode()
            
            if status and code != status:
                return False
            elif not status and not (200 <= code < 300):
                return False
            
            if content:
                body = resp.read().decode("utf-8", errors="ignore")
                return content in body
            
            return True
        except (URLError, HTTPError):
            return False
    
    condition = f"URL {url} to respond"
    if status:
        condition += f" with status {status}"
    if content:
        condition += f" containing '{content}'"
    
    result = wait_loop(check_url, condition, timeout, interval, quiet, json_output)
    sys.exit(0 if result["success"] else 1)


@cli.command("process")
@click.argument("name")
@click.option("-t", "--timeout", default=30, help="Timeout in seconds (0=forever)")
@click.option("-i", "--interval", default=1.0, help="Check interval in seconds")
@click.option("-q", "--quiet", is_flag=True, help="Suppress output")
@click.option("--json", "json_output", is_flag=True, help="JSON output")
@click.option("--gone", is_flag=True, help="Wait for process to be GONE instead")
def wait_process(name: str, timeout: int, interval: float, quiet: bool, json_output: bool, gone: bool):
    """Wait for a process to be running (or gone with --gone)."""
    
    def check_process():
        try:
            # Use pgrep for cross-platform process detection
            result = subprocess.run(
                ["pgrep", "-x", name],
                capture_output=True,
                timeout=5
            )
            return result.returncode == 0
        except:
            # Fallback: check ps output
            try:
                result = subprocess.run(
                    ["ps", "aux"],
                    capture_output=True,
                    text=True,
                    timeout=5
                )
                return name in result.stdout
            except:
                return False
    
    action = "to stop" if gone else "to start"
    condition = f"process '{name}' {action}"
    result = wait_loop(check_process, condition, timeout, interval, quiet, json_output, invert=gone)
    sys.exit(0 if result["success"] else 1)


@cli.command("command")
@click.argument("cmd")
@click.option("-t", "--timeout", default=30, help="Timeout in seconds (0=forever)")
@click.option("-i", "--interval", default=2.0, help="Check interval in seconds")
@click.option("-q", "--quiet", is_flag=True, help="Suppress output")
@click.option("--json", "json_output", is_flag=True, help="JSON output")
@click.option("--shell/--no-shell", default=True, help="Run through shell")
def wait_command(cmd: str, timeout: int, interval: float, quiet: bool, json_output: bool, shell: bool):
    """Wait for a command to exit with status 0."""
    
    def check_command():
        try:
            result = subprocess.run(
                cmd,
                shell=shell,
                capture_output=True,
                timeout=10
            )
            return result.returncode == 0
        except:
            return False
    
    condition = f"command '{cmd}' to succeed"
    result = wait_loop(check_command, condition, timeout, interval, quiet, json_output)
    sys.exit(0 if result["success"] else 1)


@cli.command("tcp")
@click.argument("host")
@click.argument("port", type=int)
@click.option("-t", "--timeout", default=30, help="Timeout in seconds (0=forever)")
@click.option("-i", "--interval", default=1.0, help="Check interval in seconds")
@click.option("-q", "--quiet", is_flag=True, help="Suppress output")
@click.option("--json", "json_output", is_flag=True, help="JSON output")
def wait_tcp(host: str, port: int, timeout: int, interval: float, quiet: bool, json_output: bool):
    """Wait for a remote TCP connection (host + port)."""
    
    def check_tcp():
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        sock.settimeout(2)
        try:
            result = sock.connect_ex((host, port))
            return result == 0
        finally:
            sock.close()
    
    condition = f"TCP connection to {host}:{port}"
    result = wait_loop(check_tcp, condition, timeout, interval, quiet, json_output)
    sys.exit(0 if result["success"] else 1)


def main():
    cli()


if __name__ == "__main__":
    main()
