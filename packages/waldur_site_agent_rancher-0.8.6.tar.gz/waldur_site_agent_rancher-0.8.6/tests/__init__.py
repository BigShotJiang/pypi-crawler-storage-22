"""Tests for Rancher plugin."""
