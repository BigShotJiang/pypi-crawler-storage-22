"""WalkieCode Desktop Client"""

__version__ = "0.2.1"
