"""
Comprehensive tests for checkout command.
"""

from unittest.mock import MagicMock, patch

import pytest
from click.testing import CliRunner

from wally_dev.cli import cli
from wally_dev.commands.checkout import checkout
from wally_dev.constants import EXIT_SUCCESS
from wally_dev.exceptions import NormLockedError, NormNotFoundError
from wally_dev.models import Norm


class TestCheckoutCommand:
    """Tests for checkout command."""

    @pytest.fixture
    def runner(self):
        return CliRunner()

    @pytest.fixture
    def mock_config(self):
        """Create a mock logged-in config."""
        config = MagicMock()
        config.is_logged_in = True
        config.user_id = "user123"
        config.organization_id = "org456"
        config.get_locked_norms.return_value = {}
        return config

    @pytest.fixture
    def mock_api_client(self):
        """Create a mock API client."""
        client = MagicMock()
        client.__enter__ = MagicMock(return_value=client)
        client.__exit__ = MagicMock(return_value=False)
        return client

    @pytest.fixture
    def sample_norms(self):
        """Create sample norms list."""
        return [
            Norm(id="norm1", name="NBR 17225", version="1.0", rules_count=10),
            Norm(id="norm2", name="WCAG 2.1", version="2.1", rules_count=50),
        ]

    def test_checkout_help(self, runner: CliRunner):
        """Test checkout help."""
        result = runner.invoke(cli, ["checkout", "--help"])
        assert result.exit_code == 0
        assert "checkout" in result.output.lower()

    def test_checkout_get_help(self, runner: CliRunner):
        """Test checkout get help."""
        result = runner.invoke(cli, ["checkout", "get", "--help"])
        assert result.exit_code == 0
        assert "--norm-id" in result.output

    def test_checkout_release_help(self, runner: CliRunner):
        """Test checkout release help."""
        result = runner.invoke(cli, ["checkout", "release", "--help"])
        assert result.exit_code == 0
        assert "--force" in result.output

    @patch("wally_dev.commands.checkout.LocalConfig")
    def test_checkout_not_logged_in(self, mock_config_class, runner: CliRunner):
        """Test checkout when not logged in."""
        mock_config = MagicMock()
        mock_config.is_logged_in = False
        mock_config_class.return_value = mock_config

        result = runner.invoke(checkout, ["--norm-id", "norm123"])
        assert (
            result.exit_code != 0
            or "login" in result.output.lower()
            or "autenticado" in result.output.lower()
        )

    @patch("wally_dev.commands.checkout.WorkspaceManager")
    @patch("wally_dev.commands.checkout.LocalConfig")
    def test_checkout_with_norm_id_success(
        self, mock_config_class, mock_workspace_class, runner: CliRunner
    ):
        """Test checkout with norm-id parameter."""
        mock_config = MagicMock()
        mock_config.is_logged_in = True
        mock_config.get_locked_norms.return_value = {}
        mock_config.is_norm_locked_locally.return_value = False

        mock_client = MagicMock()
        mock_client.__enter__ = MagicMock(return_value=mock_client)
        mock_client.__exit__ = MagicMock(return_value=False)
        mock_client.lock_norm.return_value = Norm(id="norm123", name="Test Norm", version="1.0")
        mock_client.export_testcases_zip.return_value = b"fake-zip-content"
        mock_client.export_examples_zip.return_value = b"fake-zip-content"

        mock_config.create_api_client.return_value = mock_client
        mock_config_class.return_value = mock_config

        mock_workspace = MagicMock()
        mock_workspace.extract_testcases_zip.return_value = 5
        mock_workspace.extract_examples_zip.return_value = 10
        mock_workspace_class.return_value = mock_workspace

        result = runner.invoke(checkout, ["--norm-id", "norm123"])
        # Should either succeed or show progress
        assert "norm123" in result.output.lower() or result.exit_code in [0, 1]

    @patch("wally_dev.commands.checkout.LocalConfig")
    def test_checkout_release_no_locked_norms(self, mock_config_class, runner: CliRunner):
        """Test checkout release when no norms are locked."""
        mock_config = MagicMock()
        mock_config.is_logged_in = True
        mock_config.get_locked_norms.return_value = {}
        mock_config.user_id = "user123"

        mock_client = MagicMock()
        mock_client.__enter__ = MagicMock(return_value=mock_client)
        mock_client.__exit__ = MagicMock(return_value=False)
        mock_client.list_norms.return_value = []
        mock_config.create_api_client.return_value = mock_client

        mock_config_class.return_value = mock_config

        result = runner.invoke(cli, ["checkout", "release"])
        assert "checkout" in result.output.lower() or "norma" in result.output.lower()

    @patch("wally_dev.commands.checkout.WorkspaceManager")
    @patch("wally_dev.commands.checkout.LocalConfig")
    def test_checkout_release_single_norm_with_force(
        self, mock_config_class, mock_workspace_class, runner: CliRunner
    ):
        """Test checkout release with single norm and --force flag."""
        mock_config = MagicMock()
        mock_config.is_logged_in = True
        mock_config.user_id = "user123"
        mock_config.get_locked_norms.return_value = {
            "norm123": {"norm_name": "Test Norm", "checkout_at": "2024-01-01", "testcase_count": 5}
        }

        mock_client = MagicMock()
        mock_client.__enter__ = MagicMock(return_value=mock_client)
        mock_client.__exit__ = MagicMock(return_value=False)
        mock_client.list_norms.return_value = []
        mock_client.unlock_norm.return_value = None
        mock_config.create_api_client.return_value = mock_client

        mock_config_class.return_value = mock_config

        mock_workspace = MagicMock()
        mock_workspace.delete_norm.return_value = True
        mock_workspace_class.return_value = mock_workspace

        result = runner.invoke(cli, ["checkout", "release", "--force"])
        assert (
            result.exit_code == 0
            or "liberado" in result.output.lower()
            or "sucesso" in result.output.lower()
        )

    @patch("wally_dev.commands.checkout.LocalConfig")
    def test_checkout_release_with_specific_norm_id(self, mock_config_class, runner: CliRunner):
        """Test checkout release with specific norm-id."""
        mock_config = MagicMock()
        mock_config.is_logged_in = True
        mock_config.user_id = "user123"
        mock_config.get_locked_norms.return_value = {
            "norm123": {"norm_name": "Test Norm", "checkout_at": "2024-01-01"}
        }

        mock_client = MagicMock()
        mock_client.__enter__ = MagicMock(return_value=mock_client)
        mock_client.__exit__ = MagicMock(return_value=False)
        mock_client.list_norms.return_value = []
        mock_config.create_api_client.return_value = mock_client

        mock_config_class.return_value = mock_config

        # Test with --force to skip confirmation
        result = runner.invoke(cli, ["checkout", "release", "--norm-id", "norm123", "--force"])
        assert "norm123" in result.output.lower() or result.exit_code in [0, 1]

    @patch("wally_dev.commands.checkout.LocalConfig")
    def test_checkout_release_norm_not_in_checkout(self, mock_config_class, runner: CliRunner):
        """Test checkout release with non-existent norm."""
        mock_config = MagicMock()
        mock_config.is_logged_in = True
        mock_config.user_id = "user123"
        mock_config.get_locked_norms.return_value = {"norm123": {"norm_name": "Test Norm"}}

        mock_client = MagicMock()
        mock_client.__enter__ = MagicMock(return_value=mock_client)
        mock_client.__exit__ = MagicMock(return_value=False)
        mock_client.list_norms.return_value = []
        mock_config.create_api_client.return_value = mock_client

        mock_config_class.return_value = mock_config

        result = runner.invoke(cli, ["checkout", "release", "--norm-id", "nonexistent"])
        assert (
            "não está em checkout" in result.output.lower() or "encontrada" in result.output.lower()
        )

    @patch("wally_dev.commands.checkout.LocalConfig")
    def test_checkout_release_cancelled_by_user(self, mock_config_class, runner: CliRunner):
        """Test checkout release cancelled by user."""
        mock_config = MagicMock()
        mock_config.is_logged_in = True
        mock_config.user_id = "user123"
        mock_config.get_locked_norms.return_value = {
            "norm123": {"norm_name": "Test Norm", "checkout_at": "2024-01-01"}
        }

        mock_client = MagicMock()
        mock_client.__enter__ = MagicMock(return_value=mock_client)
        mock_client.__exit__ = MagicMock(return_value=False)
        mock_client.list_norms.return_value = []
        mock_config.create_api_client.return_value = mock_client

        mock_config_class.return_value = mock_config

        # Simulate user typing 'n' for no
        result = runner.invoke(cli, ["checkout", "release", "--norm-id", "norm123"], input="n\n")
        assert "cancelad" in result.output.lower() or result.exit_code == 0

    @patch("wally_dev.commands.checkout.LocalConfig")
    def test_checkout_with_target_option(self, mock_config_class, runner: CliRunner):
        """Test checkout with --target option."""
        mock_config = MagicMock()
        mock_config.is_logged_in = True
        mock_config.get_locked_norms.return_value = {}
        mock_config.is_norm_locked_locally.return_value = False

        mock_client = MagicMock()
        mock_client.__enter__ = MagicMock(return_value=mock_client)
        mock_client.__exit__ = MagicMock(return_value=False)
        mock_client.list_norms.return_value = []
        mock_config.create_api_client.return_value = mock_client

        mock_config_class.return_value = mock_config

        result = runner.invoke(checkout, ["--norm-id", "norm123", "--target", "react"])
        # Should process with target filter
        assert "react" in result.output.lower() or result.exit_code in [0, 1]

    @patch("wally_dev.commands.checkout.LocalConfig")
    def test_checkout_with_force_option(self, mock_config_class, runner: CliRunner):
        """Test checkout with --force option."""
        mock_config = MagicMock()
        mock_config.is_logged_in = True
        mock_config.get_locked_norms.return_value = {}
        mock_config.is_norm_locked_locally.return_value = True

        mock_client = MagicMock()
        mock_client.__enter__ = MagicMock(return_value=mock_client)
        mock_client.__exit__ = MagicMock(return_value=False)
        mock_config.create_api_client.return_value = mock_client

        mock_config_class.return_value = mock_config

        result = runner.invoke(checkout, ["--norm-id", "norm123", "--force"])
        # Should proceed even if already exists
        assert result.exit_code in [0, 1] or "force" in result.output.lower()

    @patch("wally_dev.commands.checkout.LocalConfig")
    def test_checkout_norm_already_locked_by_other(self, mock_config_class, runner: CliRunner):
        """Test checkout when norm is locked by another user."""
        mock_config = MagicMock()
        mock_config.is_logged_in = True
        mock_config.user_id = "user123"
        mock_config.get_locked_norms.return_value = {}
        mock_config.is_norm_locked_locally.return_value = False

        mock_client = MagicMock()
        mock_client.__enter__ = MagicMock(return_value=mock_client)
        mock_client.__exit__ = MagicMock(return_value=False)
        mock_client.lock_norm.side_effect = NormLockedError("Norma bloqueada por outro usuário")
        mock_config.create_api_client.return_value = mock_client

        mock_config_class.return_value = mock_config

        result = runner.invoke(checkout, ["--norm-id", "norm123"])
        assert "bloqueada" in result.output.lower() or result.exit_code != 0

    @patch("wally_dev.commands.checkout.LocalConfig")
    def test_checkout_norm_not_found(self, mock_config_class, runner: CliRunner):
        """Test checkout when norm is not found."""
        mock_config = MagicMock()
        mock_config.is_logged_in = True
        mock_config.get_locked_norms.return_value = {}
        mock_config.is_norm_locked_locally.return_value = False

        mock_client = MagicMock()
        mock_client.__enter__ = MagicMock(return_value=mock_client)
        mock_client.__exit__ = MagicMock(return_value=False)
        mock_client.lock_norm.side_effect = NormNotFoundError("Norma não encontrada")
        mock_config.create_api_client.return_value = mock_client

        mock_config_class.return_value = mock_config

        result = runner.invoke(checkout, ["--norm-id", "nonexistent"])
        assert "não encontrada" in result.output.lower() or result.exit_code != 0


class TestCheckoutInteractive:
    """Tests for interactive checkout selection."""

    @pytest.fixture
    def runner(self):
        return CliRunner()

    @patch("wally_dev.commands.checkout.Settings")
    @patch("wally_dev.commands.checkout.LocalConfig")
    def test_checkout_interactive_no_norms_available(
        self, mock_config_class, mock_settings_class, runner: CliRunner
    ):
        """Test interactive checkout shows target selection."""
        mock_config = MagicMock()
        mock_config.is_logged_in = True
        mock_config.get_locked_norms.return_value = {}

        mock_client = MagicMock()
        mock_client.__enter__ = MagicMock(return_value=mock_client)
        mock_client.__exit__ = MagicMock(return_value=False)
        mock_client.list_norms.return_value = []
        mock_config.create_api_client.return_value = mock_client

        mock_config_class.return_value = mock_config

        result = runner.invoke(checkout)
        # When no --norm-id, checkout shows target selection (html, react, etc.)
        assert "target" in result.output.lower() or result.exit_code in (0, 1)

    @patch("wally_dev.commands.checkout.LocalConfig")
    def test_checkout_interactive_with_available_norms(self, mock_config_class, runner: CliRunner):
        """Test interactive checkout with available norms."""
        mock_config = MagicMock()
        mock_config.is_logged_in = True
        mock_config.get_locked_norms.return_value = {}

        sample_norms = [
            Norm(id="norm1", name="NBR 17225", version="1.0", rules_count=10),
            Norm(id="norm2", name="WCAG 2.1", version="2.1", rules_count=50),
        ]

        mock_client = MagicMock()
        mock_client.__enter__ = MagicMock(return_value=mock_client)
        mock_client.__exit__ = MagicMock(return_value=False)
        mock_client.list_norms.return_value = sample_norms
        mock_config.create_api_client.return_value = mock_client

        mock_config_class.return_value = mock_config

        # Select first norm
        result = runner.invoke(checkout, input="1\n")
        assert result.exit_code in [0, 1] or "norma" in result.output.lower()


class TestCheckoutRelease:
    """Tests for checkout release command."""

    @pytest.fixture
    def runner(self):
        return CliRunner()

    @patch("wally_dev.commands.checkout.WorkspaceManager")
    @patch("wally_dev.commands.checkout.LocalConfig")
    def test_release_success(self, mock_config_class, mock_workspace_class, runner: CliRunner):
        """Test successful release."""
        mock_config = MagicMock()
        mock_config.is_logged_in = True
        mock_config.user_id = "user123"
        mock_config.get_locked_norms.return_value = {
            "norm123": {"norm_name": "Test Norm", "checkout_at": "2024-01-01", "testcase_count": 5}
        }

        mock_client = MagicMock()
        mock_client.__enter__ = MagicMock(return_value=mock_client)
        mock_client.__exit__ = MagicMock(return_value=False)
        mock_client.list_norms.return_value = []
        mock_client.unlock_norm.return_value = None
        mock_config.create_api_client.return_value = mock_client
        mock_config_class.return_value = mock_config

        mock_workspace = MagicMock()
        mock_workspace.delete_norm.return_value = True
        mock_workspace_class.return_value = mock_workspace

        result = runner.invoke(checkout, ["release", "--force"])

        assert result.exit_code == 0 or "liberado" in result.output.lower()

    @patch("wally_dev.commands.checkout.WorkspaceManager")
    @patch("wally_dev.commands.checkout.LocalConfig")
    def test_release_unlock_failure(
        self, mock_config_class, mock_workspace_class, runner: CliRunner
    ):
        """Test release when server unlock fails."""
        from wally_dev.exceptions import WallyDevError

        mock_config = MagicMock()
        mock_config.is_logged_in = True
        mock_config.user_id = "user123"
        mock_config.get_locked_norms.return_value = {
            "norm123": {"norm_name": "Test Norm", "checkout_at": "2024-01-01"}
        }

        mock_client = MagicMock()
        mock_client.__enter__ = MagicMock(return_value=mock_client)
        mock_client.__exit__ = MagicMock(return_value=False)
        mock_client.list_norms.return_value = []
        mock_client.unlock_norm.side_effect = WallyDevError("unlock failed")
        mock_config.create_api_client.return_value = mock_client
        mock_config_class.return_value = mock_config

        result = runner.invoke(checkout, ["release", "--norm-id", "norm123", "--force"])

        # Should show error about unlock failure
        assert (
            "falhou" in result.output.lower()
            or "erro" in result.output.lower()
            or result.exit_code != 0
        )

    @patch("wally_dev.commands.checkout.WorkspaceManager")
    @patch("wally_dev.commands.checkout.LocalConfig")
    def test_release_with_force_unlock(
        self, mock_config_class, mock_workspace_class, runner: CliRunner
    ):
        """Test release with --force-unlock option."""
        mock_config = MagicMock()
        mock_config.is_logged_in = True
        mock_config.user_id = "user123"
        mock_config.get_locked_norms.return_value = {
            "norm123": {"norm_name": "Test Norm", "checkout_at": "2024-01-01"}
        }

        mock_client = MagicMock()
        mock_client.__enter__ = MagicMock(return_value=mock_client)
        mock_client.__exit__ = MagicMock(return_value=False)
        mock_client.list_norms.return_value = []
        mock_client.unlock_norm.return_value = None
        mock_config.create_api_client.return_value = mock_client
        mock_config_class.return_value = mock_config

        mock_workspace = MagicMock()
        mock_workspace.delete_norm.return_value = True
        mock_workspace_class.return_value = mock_workspace

        result = runner.invoke(checkout, ["release", "--force", "--force-unlock"])

        # Should pass with force-unlock
        assert result.exit_code in [0, 1]

    @patch("wally_dev.commands.checkout.LocalConfig")
    def test_release_multiple_norms_selection(self, mock_config_class, runner: CliRunner):
        """Test release with multiple norms requiring selection."""
        mock_config = MagicMock()
        mock_config.is_logged_in = True
        mock_config.user_id = "user123"
        mock_config.get_locked_norms.return_value = {
            "norm1": {"norm_name": "Norm 1", "checkout_at": "2024-01-01"},
            "norm2": {"norm_name": "Norm 2", "checkout_at": "2024-01-02"},
        }

        mock_client = MagicMock()
        mock_client.__enter__ = MagicMock(return_value=mock_client)
        mock_client.__exit__ = MagicMock(return_value=False)
        mock_client.list_norms.return_value = []
        mock_config.create_api_client.return_value = mock_client
        mock_config_class.return_value = mock_config

        # Select first norm then cancel
        result = runner.invoke(checkout, ["release"], input="1\nn\n")

        # Should show selection or ask for confirmation
        assert "selecio" in result.output.lower() or "norm" in result.output.lower()


class TestCheckoutDoCheckout:
    """Tests for _do_checkout function."""

    @pytest.fixture
    def runner(self):
        return CliRunner()

    @patch("wally_dev.commands.checkout.WorkspaceManager")
    @patch("wally_dev.commands.checkout.LocalConfig")
    def test_checkout_already_locked_by_me(
        self, mock_config_class, mock_workspace_class, runner: CliRunner
    ):
        """Test checkout when norm is already locked by current user."""
        mock_config = MagicMock()
        mock_config.is_logged_in = True
        mock_config.user_id = "user123"
        mock_config.get_locked_norms.return_value = {}
        mock_config.is_norm_locked_locally.return_value = False

        locked_norm = Norm(id="norm123", name="Test Norm", version="1.0", locked_by="user123")

        mock_client = MagicMock()
        mock_client.__enter__ = MagicMock(return_value=mock_client)
        mock_client.__exit__ = MagicMock(return_value=False)
        mock_client.get_norm.return_value = locked_norm
        mock_config.create_api_client.return_value = mock_client
        mock_config_class.return_value = mock_config

        # Select option to reconnect
        result = runner.invoke(checkout, ["--norm-id", "norm123", "--target", "html"], input="0\n")

        # Should show reconnect options
        assert (
            "reconectar" in result.output.lower()
            or "bloqueada" in result.output.lower()
            or result.exit_code in [0, 1]
        )

    @patch("wally_dev.commands.checkout.WorkspaceManager")
    @patch("wally_dev.commands.checkout.LocalConfig")
    def test_checkout_already_checked_out_locally(
        self, mock_config_class, mock_workspace_class, runner: CliRunner
    ):
        """Test checkout when already exists locally."""
        mock_config = MagicMock()
        mock_config.is_logged_in = True
        mock_config.get_locked_norms.return_value = {}
        mock_config.is_norm_locked_locally.return_value = True
        mock_config_class.return_value = mock_config

        mock_workspace = MagicMock()
        mock_workspace.get_workspace_info.return_value = {
            "path": "/workspace/norm123",
            "testcase_count": 5,
        }
        mock_workspace_class.return_value = mock_workspace

        result = runner.invoke(checkout, ["--norm-id", "norm123", "--target", "html"])

        # Should show already checked out message
        assert "já está em checkout" in result.output.lower() or result.exit_code == 0

    @patch("wally_dev.commands.checkout.WorkspaceManager")
    @patch("wally_dev.commands.checkout.LocalConfig")
    def test_checkout_with_force_overwrites(
        self, mock_config_class, mock_workspace_class, runner: CliRunner
    ):
        """Test checkout with --force overwrites existing."""
        mock_config = MagicMock()
        mock_config.is_logged_in = True
        mock_config.get_locked_norms.return_value = {}
        mock_config.is_norm_locked_locally.return_value = True
        mock_config_class.return_value = mock_config

        unlocked_norm = Norm(id="norm123", name="Test Norm", version="1.0", locked_by=None)

        mock_client = MagicMock()
        mock_client.__enter__ = MagicMock(return_value=mock_client)
        mock_client.__exit__ = MagicMock(return_value=False)
        mock_client.get_norm.return_value = unlocked_norm
        mock_client.lock_norm.return_value = unlocked_norm
        mock_client.export_testcases_zip.return_value = b"fake-zip"
        mock_client.export_examples_zip.return_value = b"fake-zip"
        mock_config.create_api_client.return_value = mock_client

        mock_workspace = MagicMock()
        mock_workspace.extract_testcases_zip.return_value = 0
        mock_workspace.extract_examples_zip.return_value = 0
        mock_workspace_class.return_value = mock_workspace

        result = runner.invoke(checkout, ["--norm-id", "norm123", "--target", "html", "--force"])

        # Should proceed with force
        assert result.exit_code in [0, 1]


class TestCheckoutTargetSelection:
    """Tests for target selection in checkout."""

    @pytest.fixture
    def runner(self):
        return CliRunner()

    @patch("wally_dev.commands.checkout.LocalConfig")
    def test_checkout_invalid_target(self, mock_config_class, runner: CliRunner):
        """Test checkout with invalid target."""
        mock_config = MagicMock()
        mock_config.is_logged_in = True
        mock_config_class.return_value = mock_config

        result = runner.invoke(checkout, ["--norm-id", "norm123", "--target", "invalid"])

        # Click should reject invalid choice
        assert result.exit_code != 0

    @patch("wally_dev.commands.checkout.WorkspaceManager")
    @patch("wally_dev.commands.checkout.LocalConfig")
    def test_checkout_shows_target_in_output(
        self, mock_config_class, mock_workspace_class, runner: CliRunner
    ):
        """Test checkout shows selected target."""
        mock_config = MagicMock()
        mock_config.is_logged_in = True
        mock_config.get_locked_norms.return_value = {}
        mock_config.is_norm_locked_locally.return_value = False
        mock_config_class.return_value = mock_config

        mock_client = MagicMock()
        mock_client.__enter__ = MagicMock(return_value=mock_client)
        mock_client.__exit__ = MagicMock(return_value=False)
        mock_client.list_norms.return_value = []
        mock_config.create_api_client.return_value = mock_client

        result = runner.invoke(checkout, ["--norm-id", "norm123", "--target", "react"])

        # Should show target in output
        assert "REACT" in result.output.upper() or result.exit_code in [0, 1]


class TestCheckoutSyncWithAPI:
    """Tests for checkout sync with API locked norms."""

    @pytest.fixture
    def runner(self):
        return CliRunner()

    @patch("wally_dev.commands.checkout.WorkspaceManager")
    @patch("wally_dev.commands.checkout.LocalConfig")
    def test_release_syncs_with_api(
        self, mock_config_class, mock_workspace_class, runner: CliRunner
    ):
        """Test release syncs with API for locked norms not in local config."""
        mock_config = MagicMock()
        mock_config.is_logged_in = True
        mock_config.user_id = "user123"
        mock_config.get_locked_norms.return_value = {}  # Empty local

        # API returns norm locked by user
        api_norm = Norm(id="norm-from-api", name="API Norm", version="1.0", locked_by="user123")

        mock_client = MagicMock()
        mock_client.__enter__ = MagicMock(return_value=mock_client)
        mock_client.__exit__ = MagicMock(return_value=False)
        mock_client.list_norms.return_value = [api_norm]
        mock_config.create_api_client.return_value = mock_client
        mock_config_class.return_value = mock_config

        result = runner.invoke(checkout, ["release"])

        # Should find the norm from API
        assert "norm-from-api" in result.output.lower() or "norma" in result.output.lower()

    @patch("wally_dev.commands.checkout.LocalConfig")
    def test_release_api_failure_continues(self, mock_config_class, runner: CliRunner):
        """Test release handles API failures gracefully."""
        from wally_dev.exceptions import WallyDevError

        mock_config = MagicMock()
        mock_config.is_logged_in = True
        mock_config.user_id = "user123"
        mock_config.get_locked_norms.return_value = {
            "norm1": {"norm_name": "Local Norm", "checkout_at": "2024-01-01"}
        }

        mock_client = MagicMock()
        mock_client.__enter__ = MagicMock(return_value=mock_client)
        mock_client.__exit__ = MagicMock(return_value=False)
        mock_client.list_norms.side_effect = WallyDevError("API error")
        mock_config.create_api_client.return_value = mock_client
        mock_config_class.return_value = mock_config

        result = runner.invoke(checkout, ["release"], input="n\n")

        # Should still work with local norms
        assert "Local Norm" in result.output or result.exit_code in [0, 1]


class TestSelectNormInteractive:
    """Tests for _select_norm_interactive function."""

    @pytest.fixture
    def runner(self):
        return CliRunner()

    @patch("wally_dev.commands.checkout.click.prompt")
    def test_select_norm_cancel(self, mock_prompt):
        """Test selecting norm cancel (0)."""
        from wally_dev.commands.checkout import _select_norm_interactive

        mock_config = MagicMock()
        mock_config.get_locked_norms.return_value = {}
        mock_config.user_id = "user123"

        mock_client = MagicMock()
        mock_client.list_norms.return_value = [
            Norm(id="norm1", name="NBR 17225", version="1.0"),
            Norm(id="norm2", name="WCAG 2.1", version="2.1"),
        ]
        mock_prompt.return_value = "0"

        result = _select_norm_interactive(mock_client, mock_config)

        assert result is None

    @patch("wally_dev.commands.checkout.click.prompt")
    def test_select_norm_valid_selection(self, mock_prompt):
        """Test selecting valid norm."""
        from wally_dev.commands.checkout import _select_norm_interactive

        mock_config = MagicMock()
        mock_config.get_locked_norms.return_value = {}
        mock_config.user_id = "user123"

        mock_client = MagicMock()
        mock_client.list_norms.return_value = [
            Norm(id="norm1", name="NBR 17225", version="1.0"),
            Norm(id="norm2", name="WCAG 2.1", version="2.1"),
        ]
        mock_prompt.return_value = "2"

        result = _select_norm_interactive(mock_client, mock_config)

        assert result == "norm2"

    @patch("wally_dev.commands.checkout.click.prompt")
    def test_select_norm_invalid_then_valid(self, mock_prompt):
        """Test invalid selection then valid."""
        from wally_dev.commands.checkout import _select_norm_interactive

        mock_config = MagicMock()
        mock_config.get_locked_norms.return_value = {}
        mock_config.user_id = "user123"

        mock_client = MagicMock()
        mock_client.list_norms.return_value = [
            Norm(id="norm1", name="NBR 17225", version="1.0"),
        ]
        mock_prompt.side_effect = ["5", "1"]

        result = _select_norm_interactive(mock_client, mock_config)

        assert result == "norm1"

    @patch("wally_dev.commands.checkout.click.prompt")
    def test_select_norm_non_numeric_then_valid(self, mock_prompt):
        """Test non-numeric input then valid."""
        from wally_dev.commands.checkout import _select_norm_interactive

        mock_config = MagicMock()
        mock_config.get_locked_norms.return_value = {}
        mock_config.user_id = "user123"

        mock_client = MagicMock()
        mock_client.list_norms.return_value = [
            Norm(id="norm1", name="NBR 17225", version="1.0"),
        ]
        mock_prompt.side_effect = ["abc", "1"]

        result = _select_norm_interactive(mock_client, mock_config)

        assert result == "norm1"


class TestSelectLockedNormInteractive:
    """Tests for _select_locked_norm_interactive function."""

    @patch("wally_dev.commands.checkout.click.prompt")
    def test_select_locked_norm_cancel(self, mock_prompt):
        """Test selecting locked norm cancel."""
        from wally_dev.commands.checkout import _select_locked_norm_interactive

        locked_norms = {
            "norm1": {"norm_name": "WCAG 2.1", "checkout_at": "2025-01-01", "testcase_count": 5},
        }
        mock_prompt.return_value = "0"

        result = _select_locked_norm_interactive(locked_norms)

        assert result is None

    @patch("wally_dev.commands.checkout.click.prompt")
    def test_select_locked_norm_valid(self, mock_prompt):
        """Test selecting valid locked norm."""
        from wally_dev.commands.checkout import _select_locked_norm_interactive

        locked_norms = {
            "norm1": {"norm_name": "WCAG 2.1", "checkout_at": "2025-01-01", "testcase_count": 5},
            "norm2": {"norm_name": "NBR 17225", "checkout_at": "2025-01-02", "testcase_count": 3},
        }
        mock_prompt.return_value = "2"

        result = _select_locked_norm_interactive(locked_norms)

        assert result == "norm2"

    @patch("wally_dev.commands.checkout.click.prompt")
    def test_select_locked_norm_invalid_then_valid(self, mock_prompt):
        """Test invalid then valid selection."""
        from wally_dev.commands.checkout import _select_locked_norm_interactive

        locked_norms = {
            "norm1": {"norm_name": "WCAG 2.1", "checkout_at": "2025-01-01"},
        }
        mock_prompt.side_effect = ["10", "1"]

        result = _select_locked_norm_interactive(locked_norms)

        assert result == "norm1"

    @patch("wally_dev.commands.checkout.click.prompt")
    def test_select_locked_norm_invalid_date_format(self, mock_prompt):
        """Test with invalid date format in checkout_at."""
        from wally_dev.commands.checkout import _select_locked_norm_interactive

        locked_norms = {
            "norm1": {"norm_name": "WCAG 2.1", "checkout_at": "invalid-date", "testcase_count": 5},
        }
        mock_prompt.return_value = "1"

        result = _select_locked_norm_interactive(locked_norms)

        assert result == "norm1"


class TestSelectTargetInteractive:
    """Tests for _select_target_interactive function."""

    @patch("wally_dev.commands.checkout.click.prompt")
    def test_select_target_cancel(self, mock_prompt):
        """Test selecting target cancel."""
        from wally_dev.commands.checkout import _select_target_interactive

        mock_prompt.return_value = "0"

        result = _select_target_interactive()

        assert result is None

    @patch("wally_dev.commands.checkout.click.prompt")
    def test_select_target_html(self, mock_prompt):
        """Test selecting HTML target."""
        from wally_dev.commands.checkout import _select_target_interactive

        mock_prompt.return_value = "1"

        result = _select_target_interactive()

        assert result == "html"

    @patch("wally_dev.commands.checkout.click.prompt")
    def test_select_target_invalid_then_valid(self, mock_prompt):
        """Test invalid then valid target selection."""
        from wally_dev.commands.checkout import _select_target_interactive

        mock_prompt.side_effect = ["99", "2"]

        result = _select_target_interactive()

        assert result == "react"


class TestCheckoutReconnectFlow:
    """Tests for checkout reconnect flow."""

    @pytest.fixture
    def runner(self):
        return CliRunner()

    @patch("wally_dev.commands.checkout.WorkspaceManager")
    @patch("wally_dev.commands.checkout.LocalConfig")
    def test_checkout_reconnect_only_option(
        self, mock_config_class, mock_workspace_class, runner: CliRunner
    ):
        """Test checkout with reconnect only (option 1)."""
        mock_config = MagicMock()
        mock_config.is_logged_in = True
        mock_config.user_id = "user123"
        mock_config.get_locked_norms.return_value = {}
        mock_config.is_norm_locked_locally.return_value = False

        # Norm is already locked by current user
        locked_norm = Norm(id="norm123", name="Test Norm", version="1.0", locked_by="user123")

        mock_client = MagicMock()
        mock_client.__enter__ = MagicMock(return_value=mock_client)
        mock_client.__exit__ = MagicMock(return_value=False)
        mock_client.get_norm.return_value = locked_norm
        mock_config.create_api_client.return_value = mock_client
        mock_config_class.return_value = mock_config

        mock_workspace = MagicMock()
        mock_workspace_class.return_value = mock_workspace

        # Select option 1 (reconnect only)
        result = runner.invoke(checkout, ["--norm-id", "norm123", "--target", "html"], input="1\n")

        # Should reconnect without downloading
        assert "reconectado" in result.output.lower() or result.exit_code == 0

    @patch("wally_dev.commands.checkout.WorkspaceManager")
    @patch("wally_dev.commands.checkout.LocalConfig")
    def test_checkout_full_download_option(
        self, mock_config_class, mock_workspace_class, runner: CliRunner
    ):
        """Test checkout with full download (option 2)."""
        mock_config = MagicMock()
        mock_config.is_logged_in = True
        mock_config.user_id = "user123"
        mock_config.get_locked_norms.return_value = {}
        mock_config.is_norm_locked_locally.return_value = False

        locked_norm = Norm(id="norm123", name="Test Norm", version="1.0", locked_by="user123")

        mock_client = MagicMock()
        mock_client.__enter__ = MagicMock(return_value=mock_client)
        mock_client.__exit__ = MagicMock(return_value=False)
        mock_client.get_norm.return_value = locked_norm
        mock_client.export_testcases_zip.return_value = b"fake-zip"
        mock_client.export_examples_zip.return_value = b"fake-zip"
        mock_config.create_api_client.return_value = mock_client
        mock_config_class.return_value = mock_config

        mock_workspace = MagicMock()
        mock_workspace.extract_testcases_zip.return_value = 5
        mock_workspace.extract_examples_zip.return_value = 3
        mock_workspace_class.return_value = mock_workspace

        # Select option 2 (full download)
        result = runner.invoke(checkout, ["--norm-id", "norm123", "--target", "html"], input="2\n")

        # Should download files
        assert result.exit_code in [0, 1]
        mock_workspace.extract_testcases_zip.assert_called() or "sucesso" in result.output.lower()


class TestCheckoutExportFailures:
    """Tests for checkout export failure handling."""

    @pytest.fixture
    def runner(self):
        return CliRunner()

    @patch("wally_dev.commands.checkout.WorkspaceManager")
    @patch("wally_dev.commands.checkout.LocalConfig")
    def test_checkout_testcases_export_fails(
        self, mock_config_class, mock_workspace_class, runner: CliRunner
    ):
        """Test checkout when testcases export fails."""
        mock_config = MagicMock()
        mock_config.is_logged_in = True
        mock_config.get_locked_norms.return_value = {}
        mock_config.is_norm_locked_locally.return_value = False

        norm = Norm(id="norm123", name="Test Norm", version="1.0")

        mock_client = MagicMock()
        mock_client.__enter__ = MagicMock(return_value=mock_client)
        mock_client.__exit__ = MagicMock(return_value=False)
        mock_client.get_norm.return_value = norm
        mock_client.lock_norm.return_value = norm
        mock_client.export_testcases_zip.side_effect = Exception("Export failed")
        mock_client.export_examples_zip.return_value = b"fake-zip"
        mock_config.create_api_client.return_value = mock_client
        mock_config_class.return_value = mock_config

        mock_workspace = MagicMock()
        mock_workspace.extract_examples_zip.return_value = 0
        mock_workspace_class.return_value = mock_workspace

        result = runner.invoke(checkout, ["--norm-id", "norm123", "--target", "html"])

        # Should continue even if export fails
        assert result.exit_code in [0, 1]

    @patch("wally_dev.commands.checkout.WorkspaceManager")
    @patch("wally_dev.commands.checkout.LocalConfig")
    def test_checkout_examples_export_fails(
        self, mock_config_class, mock_workspace_class, runner: CliRunner
    ):
        """Test checkout when examples export fails."""
        mock_config = MagicMock()
        mock_config.is_logged_in = True
        mock_config.get_locked_norms.return_value = {}
        mock_config.is_norm_locked_locally.return_value = False

        norm = Norm(id="norm123", name="Test Norm", version="1.0")

        mock_client = MagicMock()
        mock_client.__enter__ = MagicMock(return_value=mock_client)
        mock_client.__exit__ = MagicMock(return_value=False)
        mock_client.get_norm.return_value = norm
        mock_client.lock_norm.return_value = norm
        mock_client.export_testcases_zip.return_value = b"fake-zip"
        mock_client.export_examples_zip.side_effect = Exception("Examples export failed")
        mock_config.create_api_client.return_value = mock_client
        mock_config_class.return_value = mock_config

        mock_workspace = MagicMock()
        mock_workspace.extract_testcases_zip.return_value = 5
        mock_workspace_class.return_value = mock_workspace

        result = runner.invoke(checkout, ["--norm-id", "norm123", "--target", "html"])

        # Should continue even if examples export fails
        assert result.exit_code in [0, 1]


class TestCheckoutReleaseDetailed:
    """Detailed tests for checkout release."""

    @pytest.fixture
    def runner(self):
        return CliRunner()

    @patch("wally_dev.commands.checkout.WorkspaceManager")
    @patch("wally_dev.commands.checkout.LocalConfig")
    def test_release_deletes_workspace(
        self, mock_config_class, mock_workspace_class, runner: CliRunner
    ):
        """Test release deletes local workspace."""
        mock_config = MagicMock()
        mock_config.is_logged_in = True
        mock_config.user_id = "user123"
        mock_config.get_locked_norms.return_value = {
            "norm123": {"norm_name": "Test Norm", "checkout_at": "2024-01-01"}
        }

        mock_client = MagicMock()
        mock_client.__enter__ = MagicMock(return_value=mock_client)
        mock_client.__exit__ = MagicMock(return_value=False)
        mock_client.list_norms.return_value = []
        mock_client.unlock_norm.return_value = None
        mock_config.create_api_client.return_value = mock_client
        mock_config_class.return_value = mock_config

        mock_workspace = MagicMock()
        mock_workspace.delete_norm.return_value = True
        mock_workspace_class.return_value = mock_workspace

        result = runner.invoke(checkout, ["release", "--force"])

        # Should complete successfully
        assert result.exit_code in [0, EXIT_SUCCESS] or "liberado" in result.output.lower()

    @patch("wally_dev.commands.checkout.LocalConfig")
    def test_release_norm_not_in_checkout(self, mock_config_class, runner: CliRunner):
        """Test release when norm is not in checkout."""
        mock_config = MagicMock()
        mock_config.is_logged_in = True
        mock_config.user_id = "user123"
        mock_config.get_locked_norms.return_value = {}  # No local norms

        mock_client = MagicMock()
        mock_client.__enter__ = MagicMock(return_value=mock_client)
        mock_client.__exit__ = MagicMock(return_value=False)
        mock_client.list_norms.return_value = []
        mock_config.create_api_client.return_value = mock_client
        mock_config_class.return_value = mock_config

        result = runner.invoke(checkout, ["release", "--norm-id", "nonexistent"])

        assert "não está em checkout" in result.output.lower() or result.exit_code in [0, 1]


class TestCheckoutNoNormsAvailable:
    """Tests for checkout when no norms are available."""

    @pytest.fixture
    def runner(self):
        return CliRunner()

    @patch("wally_dev.commands.checkout.LocalConfig")
    def test_select_norm_no_norms_returns_none(self, mock_config_class, runner: CliRunner):
        """Test _select_norm_interactive returns None when no norms."""
        from wally_dev.commands.checkout import _select_norm_interactive

        mock_config = MagicMock()
        mock_config.get_locked_norms.return_value = {}

        mock_client = MagicMock()
        mock_client.list_norms.return_value = []  # No norms

        result = _select_norm_interactive(mock_client, mock_config)

        assert result is None


class TestSelectTargetInteractiveOptions:
    """Additional tests for _select_target_interactive."""

    @patch("wally_dev.commands.checkout.click.prompt")
    def test_select_target_react(self, mock_prompt):
        """Test selecting React target."""
        from wally_dev.commands.checkout import _select_target_interactive

        mock_prompt.return_value = "2"

        result = _select_target_interactive()

        assert result == "react"

    @patch("wally_dev.commands.checkout.click.prompt")
    def test_select_target_angular(self, mock_prompt):
        """Test selecting Angular target."""
        from wally_dev.commands.checkout import _select_target_interactive

        mock_prompt.return_value = "3"

        result = _select_target_interactive()

        assert result == "angular"

    @patch("wally_dev.commands.checkout.click.prompt")
    def test_select_target_vue(self, mock_prompt):
        """Test selecting Vue target."""
        from wally_dev.commands.checkout import _select_target_interactive

        mock_prompt.return_value = "4"

        result = _select_target_interactive()

        assert result == "vue"
