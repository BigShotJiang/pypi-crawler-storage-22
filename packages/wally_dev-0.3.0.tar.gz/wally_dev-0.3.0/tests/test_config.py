"""Tests for configuration module."""

import json
import os
from pathlib import Path
from unittest.mock import patch

import pytest

from wally_dev.config import LocalConfig, Settings


class TestSettings:
    """Tests for Settings class."""

    def test_default_values(self):
        """Test default settings values."""
        settings = Settings()
        assert settings.timeout == 30
        assert settings.max_retries == 3
        assert settings.workspace_dir == "workspace"

    def test_env_override(self):
        """Test environment variable override."""
        with patch.dict("os.environ", {"WALLY_DEV_TIMEOUT": "60"}):
            settings = Settings()
            assert settings.timeout == 60


class TestLocalConfig:
    """Tests for LocalConfig class."""

    @pytest.fixture
    def temp_config(self, tmp_path: Path) -> LocalConfig:
        """Create a LocalConfig with temporary file."""
        config_file = tmp_path / ".wally-dev.json"
        config = LocalConfig.__new__(LocalConfig)
        config.config_file = config_file
        config._data = {}
        return config

    def test_access_token_storage(self, temp_config: LocalConfig):
        """Test storing and retrieving access token."""
        temp_config.access_token = "test-token-123"

        # Load from file
        with open(temp_config.config_file) as f:
            data = json.load(f)
        assert data["access_token"] == "test-token-123"

    def test_is_logged_in(self, temp_config: LocalConfig):
        """Test login status check."""
        assert not temp_config.is_logged_in

        temp_config._data["access_token"] = "test-token"
        assert temp_config.is_logged_in

    def test_locked_norms_management(self, temp_config: LocalConfig):
        """Test locked norms tracking."""
        # Add locked norm
        temp_config.add_locked_norm("norm123", {"name": "Test Norm"})
        assert temp_config.is_norm_locked_locally("norm123")
        assert not temp_config.is_norm_locked_locally("norm456")

        # Remove locked norm
        temp_config.remove_locked_norm("norm123")
        assert not temp_config.is_norm_locked_locally("norm123")

    def test_clear_config(self, temp_config: LocalConfig):
        """Test clearing configuration."""
        temp_config.config_file.write_text('{"access_token": "test"}')
        temp_config._data = {"access_token": "test"}

        temp_config.clear()

        assert temp_config._data == {}
        assert not temp_config.config_file.exists()

    def test_refresh_token_storage(self, temp_config: LocalConfig):
        """Test storing and retrieving refresh token."""
        temp_config.refresh_token = "refresh-token-123"

        with open(temp_config.config_file) as f:
            data = json.load(f)
        assert data["refresh_token"] == "refresh-token-123"

    def test_user_id_storage(self, temp_config: LocalConfig):
        """Test storing and retrieving user ID."""
        temp_config.user_id = "user-123"

        with open(temp_config.config_file) as f:
            data = json.load(f)
        assert data["user_id"] == "user-123"

    def test_org_id_storage(self, temp_config: LocalConfig):
        """Test storing and retrieving org ID."""
        temp_config.organization_id = "org-123"

        with open(temp_config.config_file) as f:
            data = json.load(f)
        assert data["organization_id"] == "org-123"

    def test_get_locked_norms(self, temp_config: LocalConfig):
        """Test getting all locked norms."""
        temp_config.add_locked_norm("norm1", {"name": "Norm 1"})
        temp_config.add_locked_norm("norm2", {"name": "Norm 2"})

        norms = temp_config.get_locked_norms()

        assert "norm1" in norms
        assert "norm2" in norms
        assert norms["norm1"]["name"] == "Norm 1"

    def test_set_credentials_via_properties(self, temp_config: LocalConfig):
        """Test saving credentials via properties."""
        temp_config.access_token = "access-123"
        temp_config.refresh_token = "refresh-123"
        temp_config.user_id = "user-123"
        temp_config.organization_id = "org-123"

        assert temp_config.access_token == "access-123"
        assert temp_config.refresh_token == "refresh-123"
        assert temp_config.user_id == "user-123"
        assert temp_config.organization_id == "org-123"

    def test_clear_removes_credentials(self, temp_config: LocalConfig):
        """Test clearing credentials."""
        temp_config._data = {
            "access_token": "test",
            "refresh_token": "test",
            "user_id": "test",
            "organization_id": "test",
            "locked_norms": {"norm1": {}},
        }
        temp_config.config_file.parent.mkdir(parents=True, exist_ok=True)
        temp_config.config_file.write_text("{}")

        temp_config.clear()

        assert temp_config._data == {}
        assert temp_config.access_token is None

    def test_load_existing_config(self, tmp_path: Path):
        """Test loading existing config file."""
        config_file = tmp_path / ".wally-dev.json"
        config_file.write_text(
            json.dumps(
                {
                    "access_token": "existing-token",
                    "user_id": "existing-user",
                }
            )
        )

        config = LocalConfig.__new__(LocalConfig)
        config.config_file = config_file
        config._data = None
        config._load()

        assert config._data["access_token"] == "existing-token"
        assert config._data["user_id"] == "existing-user"

    def test_is_norm_locked_locally_empty(self, temp_config: LocalConfig):
        """Test checking lock for non-existent norm."""
        assert not temp_config.is_norm_locked_locally("nonexistent")

    def test_add_locked_norm_with_metadata(self, temp_config: LocalConfig):
        """Test adding locked norm with metadata."""
        from datetime import datetime

        temp_config.add_locked_norm(
            "norm123",
            {
                "norm_name": "Test Norm",
                "checkout_at": datetime.now().isoformat(),
                "version": "1.0",
            },
        )

        norms = temp_config.get_locked_norms()
        assert norms["norm123"]["norm_name"] == "Test Norm"
        assert "checkout_at" in norms["norm123"]

    def test_delete_access_token(self, temp_config: LocalConfig):
        """Test deleting access token by setting to None."""
        temp_config._data["access_token"] = "test-token"
        temp_config._save()

        temp_config.access_token = None

        assert "access_token" not in temp_config._data

    def test_delete_refresh_token(self, temp_config: LocalConfig):
        """Test deleting refresh token by setting to None."""
        temp_config._data["refresh_token"] = "test-token"
        temp_config._save()

        temp_config.refresh_token = None

        assert "refresh_token" not in temp_config._data

    def test_delete_user_email(self, temp_config: LocalConfig):
        """Test deleting user email by setting to None."""
        temp_config._data["user_email"] = "test@example.com"
        temp_config._save()

        temp_config.user_email = None

        assert "user_email" not in temp_config._data

    def test_delete_user_id(self, temp_config: LocalConfig):
        """Test deleting user id by setting to None."""
        temp_config._data["user_id"] = "user-123"
        temp_config._save()

        temp_config.user_id = None

        assert "user_id" not in temp_config._data

    def test_delete_organization_id(self, temp_config: LocalConfig):
        """Test deleting organization id by setting to None."""
        temp_config._data["organization_id"] = "org-123"
        temp_config._save()

        temp_config.organization_id = None

        assert "organization_id" not in temp_config._data

    def test_delete_backend_url(self, temp_config: LocalConfig):
        """Test deleting backend url by setting to None."""
        temp_config._data["backend_url"] = "https://example.com"
        temp_config._save()

        temp_config.backend_url = None

        assert "backend_url" not in temp_config._data

    def test_user_email_storage(self, temp_config: LocalConfig):
        """Test storing and retrieving user email."""
        temp_config.user_email = "test@example.com"

        with open(temp_config.config_file) as f:
            data = json.load(f)
        assert data["user_email"] == "test@example.com"
        assert temp_config.user_email == "test@example.com"

    def test_backend_url_storage(self, temp_config: LocalConfig):
        """Test storing and retrieving backend URL."""
        temp_config.backend_url = "https://custom.example.com"

        with open(temp_config.config_file) as f:
            data = json.load(f)
        assert data["backend_url"] == "https://custom.example.com"
        assert temp_config.backend_url == "https://custom.example.com"

    def test_update_tokens(self, temp_config: LocalConfig):
        """Test updating access and refresh tokens together."""
        temp_config.update_tokens("new-access-token", "new-refresh-token")

        assert temp_config._data["access_token"] == "new-access-token"
        assert temp_config._data["refresh_token"] == "new-refresh-token"

    def test_create_api_client(self, temp_config: LocalConfig):
        """Test creating API client from config."""
        temp_config._data = {
            "access_token": "test-access",
            "refresh_token": "test-refresh",
            "organization_id": "org-123",
            "backend_url": "https://api.example.com",
        }

        client = temp_config.create_api_client()

        assert client.base_url == "https://api.example.com"
        assert client.access_token == "test-access"
        assert client.refresh_token == "test-refresh"
        assert client.organization_id == "org-123"

    def test_create_api_client_with_settings(self, temp_config: LocalConfig):
        """Test creating API client with custom settings."""
        temp_config._data = {
            "access_token": "test-access",
            "refresh_token": "test-refresh",
        }
        settings = Settings()
        settings.backend_url = "https://settings.example.com"

        client = temp_config.create_api_client(settings=settings)

        assert client.base_url == "https://settings.example.com"

    def test_load_corrupted_config(self, tmp_path: Path):
        """Test loading corrupted config file."""
        config_file = tmp_path / ".wally-dev.json"
        config_file.write_text("not valid json {{{")

        config = LocalConfig.__new__(LocalConfig)
        config.config_file = config_file
        config._data = None
        config._load()

        assert config._data == {}

    def test_remove_nonexistent_locked_norm(self, temp_config: LocalConfig):
        """Test removing non-existent norm doesn't raise error."""
        temp_config._data = {"locked_norms": {"norm1": {}}}

        # Should not raise
        temp_config.remove_locked_norm("nonexistent")

        # Original norm should still be there
        assert "norm1" in temp_config._data["locked_norms"]


class TestGetConfigDir:
    """Tests for get_config_dir function."""

    def test_get_config_dir_with_xdg(self, tmp_path: Path):
        """Test config dir uses XDG_CONFIG_HOME when set."""
        from wally_dev.config import get_config_dir

        with patch.dict("os.environ", {"XDG_CONFIG_HOME": str(tmp_path)}):
            config_dir = get_config_dir()

        assert config_dir == tmp_path / "wally-dev"
        assert config_dir.exists()

    def test_get_config_dir_default(self):
        """Test config dir falls back to ~/.config when XDG not set."""
        from wally_dev.config import get_config_dir

        with patch.dict("os.environ", {}, clear=True):
            # Remove XDG_CONFIG_HOME if it exists
            os.environ.pop("XDG_CONFIG_HOME", None)
            config_dir = get_config_dir()

        assert ".config" in str(config_dir)
        assert "wally-dev" in str(config_dir)


class TestMainModule:
    """Tests for __main__.py module."""

    def test_main_module_execution(self, mocker):
        """Test that __main__.py calls main() correctly."""
        mock_main = mocker.patch("wally_dev.cli.main", return_value=0)

        # Import and execute main module
        import wally_dev.__main__  # noqa: F401

        # The module-level call only happens when __name__ == "__main__"
        # So we test the import works
        assert mock_main is not None
