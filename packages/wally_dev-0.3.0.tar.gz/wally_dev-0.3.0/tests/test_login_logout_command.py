"""
Comprehensive tests for login and logout commands.
"""

from unittest.mock import MagicMock, patch

import pytest
from click.testing import CliRunner

from wally_dev.cli import cli
from wally_dev.commands.login import login
from wally_dev.commands.logout import logout
from wally_dev.exceptions import InvalidCredentialsError, WallyDevError
from wally_dev.models import UserInfo


class MockLoginResponse:
    """Mock login response."""

    def __init__(self):
        self.access_token = "test-access-token"
        self.refresh_token = "test-refresh-token"
        self.user = UserInfo(
            id="user123",
            email="test@example.com",
            name="Test User",
        )


class MockOrganization:
    """Mock organization."""

    def __init__(self, id: str, name: str):
        self.id = id
        self.name = name


class TestLoginCommand:
    """Tests for login command."""

    @pytest.fixture
    def runner(self):
        return CliRunner()

    def test_login_help(self, runner: CliRunner):
        """Test login help."""
        result = runner.invoke(cli, ["login", "--help"])
        assert result.exit_code == 0
        assert "--username" in result.output

    @patch("wally_dev.commands.login.getpass")
    @patch("wally_dev.commands.login.LocalConfig")
    @patch("wally_dev.commands.login.WallyDevApiClient")
    def test_login_success_single_org(
        self, mock_client_class, mock_config_class, mock_getpass, runner: CliRunner
    ):
        """Test successful login with single organization."""
        mock_getpass.getpass.return_value = "password123"

        mock_config = MagicMock()
        mock_config.organization_id = None
        mock_config_class.return_value = mock_config

        mock_client = MagicMock()
        mock_client.__enter__ = MagicMock(return_value=mock_client)
        mock_client.__exit__ = MagicMock(return_value=False)
        mock_client.login.return_value = MockLoginResponse()
        mock_client.list_organizations.return_value = [MockOrganization("org1", "Test Org")]
        mock_client_class.return_value = mock_client

        result = runner.invoke(login, ["--username", "test@example.com"], input="1\n")
        assert (
            result.exit_code == 0
            or "sucesso" in result.output.lower()
            or "login" in result.output.lower()
        )

    @patch("wally_dev.commands.login.getpass")
    @patch("wally_dev.commands.login.LocalConfig")
    @patch("wally_dev.commands.login.WallyDevApiClient")
    def test_login_success_multiple_orgs(
        self, mock_client_class, mock_config_class, mock_getpass, runner: CliRunner
    ):
        """Test successful login with multiple organizations."""
        mock_getpass.getpass.return_value = "password123"

        mock_config = MagicMock()
        mock_config.organization_id = None
        mock_config_class.return_value = mock_config

        mock_client = MagicMock()
        mock_client.__enter__ = MagicMock(return_value=mock_client)
        mock_client.__exit__ = MagicMock(return_value=False)
        mock_client.login.return_value = MockLoginResponse()
        mock_client.list_organizations.return_value = [
            MockOrganization("org1", "Test Org 1"),
            MockOrganization("org2", "Test Org 2"),
        ]
        mock_client_class.return_value = mock_client

        result = runner.invoke(login, ["--username", "test@example.com"], input="2\n")
        assert result.exit_code == 0 or "organização" in result.output.lower()

    @patch("wally_dev.commands.login.getpass")
    @patch("wally_dev.commands.login.LocalConfig")
    @patch("wally_dev.commands.login.WallyDevApiClient")
    def test_login_no_organizations(
        self, mock_client_class, mock_config_class, mock_getpass, runner: CliRunner
    ):
        """Test login when user has no organizations."""
        mock_getpass.getpass.return_value = "password123"

        mock_config = MagicMock()
        mock_config_class.return_value = mock_config

        mock_client = MagicMock()
        mock_client.__enter__ = MagicMock(return_value=mock_client)
        mock_client.__exit__ = MagicMock(return_value=False)
        mock_client.login.return_value = MockLoginResponse()
        mock_client.list_organizations.return_value = []
        mock_client_class.return_value = mock_client

        result = runner.invoke(login, ["--username", "test@example.com"])
        assert "organização" in result.output.lower() or "nenhuma" in result.output.lower()

    @patch("wally_dev.commands.login.getpass")
    @patch("wally_dev.commands.login.LocalConfig")
    @patch("wally_dev.commands.login.WallyDevApiClient")
    def test_login_invalid_credentials(
        self, mock_client_class, mock_config_class, mock_getpass, runner: CliRunner
    ):
        """Test login with invalid credentials."""
        mock_getpass.getpass.return_value = "wrongpassword"

        mock_config = MagicMock()
        mock_config_class.return_value = mock_config

        mock_client = MagicMock()
        mock_client.__enter__ = MagicMock(return_value=mock_client)
        mock_client.__exit__ = MagicMock(return_value=False)
        mock_client.login.side_effect = InvalidCredentialsError("Invalid credentials")
        mock_client_class.return_value = mock_client

        result = runner.invoke(login, ["--username", "test@example.com"])
        assert result.exit_code != 0 or "erro" in result.output.lower()

    @patch("wally_dev.commands.login.getpass")
    @patch("wally_dev.commands.login.LocalConfig")
    @patch("wally_dev.commands.login.WallyDevApiClient")
    def test_login_api_error(
        self, mock_client_class, mock_config_class, mock_getpass, runner: CliRunner
    ):
        """Test login with API error."""
        mock_getpass.getpass.return_value = "password123"

        mock_config = MagicMock()
        mock_config_class.return_value = mock_config

        mock_client = MagicMock()
        mock_client.__enter__ = MagicMock(return_value=mock_client)
        mock_client.__exit__ = MagicMock(return_value=False)
        mock_client.login.side_effect = WallyDevError("API error")
        mock_client_class.return_value = mock_client

        result = runner.invoke(login, ["--username", "test@example.com"])
        assert result.exit_code != 0 or "erro" in result.output.lower()

    @patch("wally_dev.commands.login.getpass")
    @patch("wally_dev.commands.login.LocalConfig")
    @patch("wally_dev.commands.login.WallyDevApiClient")
    def test_login_prompts_for_username(
        self, mock_client_class, mock_config_class, mock_getpass, runner: CliRunner
    ):
        """Test login prompts for username when not provided."""
        mock_getpass.getpass.return_value = "password123"

        mock_config = MagicMock()
        mock_config_class.return_value = mock_config

        mock_client = MagicMock()
        mock_client.__enter__ = MagicMock(return_value=mock_client)
        mock_client.__exit__ = MagicMock(return_value=False)
        mock_client.login.return_value = MockLoginResponse()
        mock_client.list_organizations.return_value = [MockOrganization("org1", "Test")]
        mock_client_class.return_value = mock_client

        result = runner.invoke(login, input="test@example.com\n1\n")
        assert "email" in result.output.lower() or result.exit_code in [0, 1]

    @patch("wally_dev.commands.login.getpass")
    @patch("wally_dev.commands.login.LocalConfig")
    @patch("wally_dev.commands.login.WallyDevApiClient")
    def test_login_with_backend_url(
        self, mock_client_class, mock_config_class, mock_getpass, runner: CliRunner
    ):
        """Test login with custom backend URL."""
        mock_getpass.getpass.return_value = "password123"

        mock_config = MagicMock()
        mock_config_class.return_value = mock_config

        mock_client = MagicMock()
        mock_client.__enter__ = MagicMock(return_value=mock_client)
        mock_client.__exit__ = MagicMock(return_value=False)
        mock_client.login.return_value = MockLoginResponse()
        mock_client.list_organizations.return_value = [MockOrganization("org1", "Test")]
        mock_client_class.return_value = mock_client

        result = runner.invoke(
            login,
            ["--username", "test@example.com", "--backend-url", "https://custom.api.com"],
            input="1\n",
        )
        assert result.exit_code in [0, 1]


class TestLogoutCommand:
    """Tests for logout command."""

    @pytest.fixture
    def runner(self):
        return CliRunner()

    def test_logout_help(self, runner: CliRunner):
        """Test logout help."""
        result = runner.invoke(cli, ["logout", "--help"])
        assert result.exit_code == 0
        assert "--force" in result.output

    @patch("wally_dev.commands.logout.WorkspaceManager")
    @patch("wally_dev.commands.logout.LocalConfig")
    def test_logout_not_logged_in(self, mock_config_class, mock_workspace_class, runner: CliRunner):
        """Test logout when not logged in."""
        mock_config = MagicMock()
        mock_config.is_logged_in = False
        mock_config_class.return_value = mock_config

        result = runner.invoke(logout)
        assert result.exit_code == 0
        assert "não está logado" in result.output.lower() or "logado" in result.output.lower()

    @patch("wally_dev.commands.logout.WorkspaceManager")
    @patch("wally_dev.commands.logout.LocalConfig")
    def test_logout_success_no_locked_norms(
        self, mock_config_class, mock_workspace_class, runner: CliRunner
    ):
        """Test successful logout with no locked norms."""
        mock_config = MagicMock()
        mock_config.is_logged_in = True
        mock_config.get_locked_norms.return_value = {}
        mock_config_class.return_value = mock_config

        mock_workspace = MagicMock()
        mock_workspace_class.return_value = mock_workspace

        result = runner.invoke(logout, ["--force"])
        assert result.exit_code == 0 or "logout" in result.output.lower()

    @patch("wally_dev.commands.logout.WorkspaceManager")
    @patch("wally_dev.commands.logout.LocalConfig")
    def test_logout_with_locked_norms_force(
        self, mock_config_class, mock_workspace_class, runner: CliRunner
    ):
        """Test logout with locked norms using --force."""
        mock_config = MagicMock()
        mock_config.is_logged_in = True
        mock_config.get_locked_norms.return_value = {"norm123": {"norm_name": "Test Norm"}}

        mock_client = MagicMock()
        mock_client.__enter__ = MagicMock(return_value=mock_client)
        mock_client.__exit__ = MagicMock(return_value=False)
        mock_client.unlock_norm.return_value = None
        mock_config.create_api_client.return_value = mock_client

        mock_config_class.return_value = mock_config

        mock_workspace = MagicMock()
        mock_workspace.list_norms.return_value = ["norm123"]
        mock_workspace.delete_norm.return_value = True
        mock_workspace_class.return_value = mock_workspace

        result = runner.invoke(logout, ["--force"])
        assert (
            result.exit_code == 0
            or "sucesso" in result.output.lower()
            or "logout" in result.output.lower()
        )

    @patch("wally_dev.commands.logout.WorkspaceManager")
    @patch("wally_dev.commands.logout.LocalConfig")
    def test_logout_cancelled_by_user(
        self, mock_config_class, mock_workspace_class, runner: CliRunner
    ):
        """Test logout cancelled by user."""
        mock_config = MagicMock()
        mock_config.is_logged_in = True
        mock_config.get_locked_norms.return_value = {"norm123": {"norm_name": "Test Norm"}}
        mock_config_class.return_value = mock_config

        mock_workspace = MagicMock()
        mock_workspace_class.return_value = mock_workspace

        result = runner.invoke(logout, input="n\n")
        assert "cancelado" in result.output.lower() or result.exit_code == 0

    @patch("wally_dev.commands.logout.WorkspaceManager")
    @patch("wally_dev.commands.logout.LocalConfig")
    def test_logout_confirms_and_proceeds(
        self, mock_config_class, mock_workspace_class, runner: CliRunner
    ):
        """Test logout confirms and proceeds."""
        mock_config = MagicMock()
        mock_config.is_logged_in = True
        mock_config.get_locked_norms.return_value = {"norm123": {"norm_name": "Test Norm"}}

        mock_client = MagicMock()
        mock_client.__enter__ = MagicMock(return_value=mock_client)
        mock_client.__exit__ = MagicMock(return_value=False)
        mock_client.unlock_norm.return_value = None
        mock_config.create_api_client.return_value = mock_client

        mock_config_class.return_value = mock_config

        mock_workspace = MagicMock()
        mock_workspace.list_norms.return_value = ["norm123"]
        mock_workspace.delete_norm.return_value = True
        mock_workspace_class.return_value = mock_workspace

        result = runner.invoke(logout, input="y\n")
        assert result.exit_code == 0 or "sucesso" in result.output.lower()

    @patch("wally_dev.commands.logout.WorkspaceManager")
    @patch("wally_dev.commands.logout.LocalConfig")
    def test_logout_unlock_error_handled(
        self, mock_config_class, mock_workspace_class, runner: CliRunner
    ):
        """Test logout handles unlock errors gracefully."""
        mock_config = MagicMock()
        mock_config.is_logged_in = True
        mock_config.get_locked_norms.return_value = {"norm123": {"norm_name": "Test Norm"}}

        mock_client = MagicMock()
        mock_client.__enter__ = MagicMock(return_value=mock_client)
        mock_client.__exit__ = MagicMock(return_value=False)
        mock_client.unlock_norm.side_effect = WallyDevError("Unlock failed")
        mock_config.create_api_client.return_value = mock_client

        mock_config_class.return_value = mock_config

        mock_workspace = MagicMock()
        mock_workspace_class.return_value = mock_workspace

        result = runner.invoke(logout, ["--force"])
        # Should still complete even with errors
        assert result.exit_code in [0, 1]
