"""
Comprehensive tests for norms command.
"""

from unittest.mock import MagicMock, patch

import pytest
from click.testing import CliRunner

from wally_dev.cli import cli
from wally_dev.commands.norms import list_norms
from wally_dev.exceptions import APIError, ConnectionFailedError, PermissionDeniedError
from wally_dev.models import Norm


class TestNormsListCommand:
    """Tests for norms list command."""

    @pytest.fixture
    def runner(self):
        return CliRunner()

    @pytest.fixture
    def sample_norms(self):
        """Create sample norms list."""
        return [
            Norm(id="norm1", name="NBR 17225", version="1.0", rules_count=10),
            Norm(id="norm2", name="WCAG 2.1", version="2.1", rules_count=50),
            Norm(id="norm3", name="EAA", version="1.0", rules_count=25, locked_by="user789"),
        ]

    @patch("wally_dev.commands.norms.LocalConfig")
    def test_norms_list_not_logged_in(self, mock_config_class, runner: CliRunner):
        """Test norms list when not logged in."""
        mock_config = MagicMock()
        mock_config.is_logged_in = False
        mock_config_class.return_value = mock_config

        result = runner.invoke(list_norms)
        assert result.exit_code != 0 or "login" in result.output.lower()

    @patch("wally_dev.commands.norms.LocalConfig")
    def test_norms_list_empty(self, mock_config_class, runner: CliRunner):
        """Test norms list when no norms found."""
        mock_config = MagicMock()
        mock_config.is_logged_in = True

        mock_client = MagicMock()
        mock_client.__enter__ = MagicMock(return_value=mock_client)
        mock_client.__exit__ = MagicMock(return_value=False)
        mock_client.list_norms.return_value = []
        mock_config.create_api_client.return_value = mock_client

        mock_config_class.return_value = mock_config

        result = runner.invoke(list_norms)
        assert result.exit_code == 0
        assert "nenhuma" in result.output.lower() or "norma" in result.output.lower()

    @patch("wally_dev.commands.norms.LocalConfig")
    def test_norms_list_success(self, mock_config_class, runner: CliRunner, sample_norms):
        """Test norms list with results."""
        mock_config = MagicMock()
        mock_config.is_logged_in = True

        mock_client = MagicMock()
        mock_client.__enter__ = MagicMock(return_value=mock_client)
        mock_client.__exit__ = MagicMock(return_value=False)
        mock_client.list_norms.return_value = sample_norms
        mock_config.create_api_client.return_value = mock_client

        mock_config_class.return_value = mock_config

        result = runner.invoke(list_norms)
        assert result.exit_code == 0
        assert "NBR 17225" in result.output or "norma" in result.output.lower()

    @patch("wally_dev.commands.norms.LocalConfig")
    def test_norms_list_verbose(self, mock_config_class, runner: CliRunner, sample_norms):
        """Test norms list with verbose flag."""
        mock_config = MagicMock()
        mock_config.is_logged_in = True

        mock_client = MagicMock()
        mock_client.__enter__ = MagicMock(return_value=mock_client)
        mock_client.__exit__ = MagicMock(return_value=False)
        mock_client.list_norms.return_value = sample_norms
        mock_config.create_api_client.return_value = mock_client

        mock_config_class.return_value = mock_config

        result = runner.invoke(list_norms, ["--verbose"])
        assert result.exit_code == 0
        # Verbose should show more details

    @patch("wally_dev.commands.norms.LocalConfig")
    def test_norms_list_api_error(self, mock_config_class, runner: CliRunner):
        """Test norms list with API error."""
        mock_config = MagicMock()
        mock_config.is_logged_in = True

        mock_client = MagicMock()
        mock_client.__enter__ = MagicMock(return_value=mock_client)
        mock_client.__exit__ = MagicMock(return_value=False)
        mock_client.list_norms.side_effect = APIError("API Error")
        mock_config.create_api_client.return_value = mock_client

        mock_config_class.return_value = mock_config

        result = runner.invoke(list_norms)
        assert result.exit_code != 0 or "erro" in result.output.lower()

    @patch("wally_dev.commands.norms.LocalConfig")
    def test_norms_list_connection_error(self, mock_config_class, runner: CliRunner):
        """Test norms list with connection error."""
        mock_config = MagicMock()
        mock_config.is_logged_in = True

        mock_client = MagicMock()
        mock_client.__enter__ = MagicMock(return_value=mock_client)
        mock_client.__exit__ = MagicMock(return_value=False)
        mock_client.list_norms.side_effect = ConnectionFailedError("Connection failed")
        mock_config.create_api_client.return_value = mock_client

        mock_config_class.return_value = mock_config

        result = runner.invoke(list_norms)
        assert (
            result.exit_code != 0
            or "conexão" in result.output.lower()
            or "erro" in result.output.lower()
        )

    @patch("wally_dev.commands.norms.LocalConfig")
    def test_norms_list_permission_denied(self, mock_config_class, runner: CliRunner):
        """Test norms list with permission denied."""
        mock_config = MagicMock()
        mock_config.is_logged_in = True

        mock_client = MagicMock()
        mock_client.__enter__ = MagicMock(return_value=mock_client)
        mock_client.__exit__ = MagicMock(return_value=False)
        mock_client.list_norms.side_effect = PermissionDeniedError("Permission denied")
        mock_config.create_api_client.return_value = mock_client

        mock_config_class.return_value = mock_config

        result = runner.invoke(list_norms)
        assert result.exit_code != 0 or "permissão" in result.output.lower()


class TestNormsGroup:
    """Tests for norms command group."""

    @pytest.fixture
    def runner(self):
        return CliRunner()

    def test_norms_group_help(self, runner: CliRunner):
        """Test norms group help."""
        result = runner.invoke(cli, ["norms", "--help"])
        assert result.exit_code == 0
        assert "list" in result.output

    def test_norms_list_via_cli(self, runner: CliRunner):
        """Test norms list via CLI entry point."""
        result = runner.invoke(cli, ["norms", "list", "--help"])
        assert result.exit_code == 0
