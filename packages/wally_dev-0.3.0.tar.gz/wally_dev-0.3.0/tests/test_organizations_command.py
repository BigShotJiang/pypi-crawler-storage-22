"""
Tests for wally_dev organizations command.

Comprehensive test coverage for organization management functionality.
"""

from unittest.mock import MagicMock, patch

import click
import pytest
from click.testing import CliRunner

from wally_dev.commands.organizations import list_organizations, organizations, select_organization
from wally_dev.constants import EXIT_SUCCESS
from wally_dev.exceptions import TokenExpiredError, WallyDevError


class TestOrganizationsGroup:
    """Tests for organizations command group."""

    @pytest.fixture
    def runner(self):
        return CliRunner()

    def test_organizations_help(self, runner: CliRunner):
        """Test organizations help."""
        result = runner.invoke(organizations, ["--help"])
        assert result.exit_code == 0
        assert "organizações" in result.output.lower()


class TestListOrganizations:
    """Tests for organizations list command."""

    @pytest.fixture
    def runner(self):
        return CliRunner()

    @patch("wally_dev.commands.organizations.Settings")
    @patch("wally_dev.commands.organizations.LocalConfig")
    def test_list_not_authenticated(self, mock_config_cls, mock_settings_cls, runner: CliRunner):
        """Test list organizations when not authenticated."""
        mock_config = MagicMock()
        mock_config.access_token = None
        mock_config_cls.return_value = mock_config

        result = runner.invoke(list_organizations)

        # Command returns EXIT_ERROR_AUTH when not authenticated
        assert "autenticado" in result.output.lower()

    @patch("wally_dev.commands.organizations.WallyDevApiClient")
    @patch("wally_dev.commands.organizations.Settings")
    @patch("wally_dev.commands.organizations.LocalConfig")
    def test_list_no_organizations(
        self, mock_config_cls, mock_settings_cls, mock_api_client_cls, runner: CliRunner
    ):
        """Test list organizations with no orgs available."""
        mock_config = MagicMock()
        mock_config.access_token = "test-token"
        mock_config.backend_url = "https://api.test.com"
        mock_config.refresh_token = "test-refresh"
        mock_config_cls.return_value = mock_config

        mock_client = MagicMock()
        mock_client.__enter__ = MagicMock(return_value=mock_client)
        mock_client.__exit__ = MagicMock(return_value=False)
        mock_client.list_organizations.return_value = []
        mock_api_client_cls.return_value = mock_client

        result = runner.invoke(list_organizations)

        assert result.exit_code == EXIT_SUCCESS
        assert (
            "nenhuma organização" in result.output.lower()
            or "sem organizações" in result.output.lower()
        )

    @patch("wally_dev.commands.organizations.WallyDevApiClient")
    @patch("wally_dev.commands.organizations.Settings")
    @patch("wally_dev.commands.organizations.LocalConfig")
    def test_list_with_organizations(
        self, mock_config_cls, mock_settings_cls, mock_api_client_cls, runner: CliRunner
    ):
        """Test list organizations with available orgs."""
        mock_config = MagicMock()
        mock_config.access_token = "test-token"
        mock_config.backend_url = "https://api.test.com"
        mock_config.refresh_token = "test-refresh"
        mock_config.organization_id = "org1"
        mock_config_cls.return_value = mock_config

        # Create mock organizations
        mock_org1 = MagicMock()
        mock_org1.id = "org1"
        mock_org1.name = "Test Org 1"
        mock_org1.description = "Description 1"

        mock_org2 = MagicMock()
        mock_org2.id = "org2"
        mock_org2.name = "Test Org 2"
        mock_org2.description = "Description 2"

        mock_client = MagicMock()
        mock_client.__enter__ = MagicMock(return_value=mock_client)
        mock_client.__exit__ = MagicMock(return_value=False)
        mock_client.list_organizations.return_value = [mock_org1, mock_org2]
        mock_api_client_cls.return_value = mock_client

        result = runner.invoke(list_organizations)

        assert result.exit_code == EXIT_SUCCESS
        assert "test org" in result.output.lower()

    @patch("wally_dev.commands.organizations.WallyDevApiClient")
    @patch("wally_dev.commands.organizations.Settings")
    @patch("wally_dev.commands.organizations.LocalConfig")
    def test_list_no_current_org_selected(
        self, mock_config_cls, mock_settings_cls, mock_api_client_cls, runner: CliRunner
    ):
        """Test list organizations with no current org selected."""
        mock_config = MagicMock()
        mock_config.access_token = "test-token"
        mock_config.backend_url = "https://api.test.com"
        mock_config.refresh_token = "test-refresh"
        mock_config.organization_id = None  # No current org
        mock_config_cls.return_value = mock_config

        mock_org = MagicMock()
        mock_org.id = "org1"
        mock_org.name = "Test Org"
        mock_org.description = "Test"

        mock_client = MagicMock()
        mock_client.__enter__ = MagicMock(return_value=mock_client)
        mock_client.__exit__ = MagicMock(return_value=False)
        mock_client.list_organizations.return_value = [mock_org]
        mock_api_client_cls.return_value = mock_client

        result = runner.invoke(list_organizations)

        assert result.exit_code == EXIT_SUCCESS
        assert "nenhuma organização selecionada" in result.output.lower()

    @patch("wally_dev.commands.organizations.WallyDevApiClient")
    @patch("wally_dev.commands.organizations.Settings")
    @patch("wally_dev.commands.organizations.LocalConfig")
    def test_list_token_expired(
        self, mock_config_cls, mock_settings_cls, mock_api_client_cls, runner: CliRunner
    ):
        """Test list organizations with expired token."""
        mock_config = MagicMock()
        mock_config.access_token = "expired-token"
        mock_config.backend_url = "https://api.test.com"
        mock_config.refresh_token = "test-refresh"
        mock_config_cls.return_value = mock_config

        mock_client = MagicMock()
        mock_client.__enter__ = MagicMock(return_value=mock_client)
        mock_client.__exit__ = MagicMock(return_value=False)
        mock_client.list_organizations.side_effect = TokenExpiredError()
        mock_api_client_cls.return_value = mock_client

        result = runner.invoke(list_organizations)

        assert "expirou" in result.output.lower()

    @patch("wally_dev.commands.organizations.WallyDevApiClient")
    @patch("wally_dev.commands.organizations.Settings")
    @patch("wally_dev.commands.organizations.LocalConfig")
    def test_list_wally_dev_error(
        self, mock_config_cls, mock_settings_cls, mock_api_client_cls, runner: CliRunner
    ):
        """Test list organizations with WallyDevError."""
        mock_config = MagicMock()
        mock_config.access_token = "test-token"
        mock_config.backend_url = "https://api.test.com"
        mock_config.refresh_token = "test-refresh"
        mock_config_cls.return_value = mock_config

        mock_client = MagicMock()
        mock_client.__enter__ = MagicMock(return_value=mock_client)
        mock_client.__exit__ = MagicMock(return_value=False)
        error = WallyDevError("Test error")
        mock_client.list_organizations.side_effect = error
        mock_api_client_cls.return_value = mock_client

        result = runner.invoke(list_organizations)

        assert "test error" in result.output.lower() or "erro" in result.output.lower()

    @patch("wally_dev.commands.organizations.WallyDevApiClient")
    @patch("wally_dev.commands.organizations.Settings")
    @patch("wally_dev.commands.organizations.LocalConfig")
    def test_list_unexpected_error(
        self, mock_config_cls, mock_settings_cls, mock_api_client_cls, runner: CliRunner
    ):
        """Test list organizations with unexpected error."""
        mock_config = MagicMock()
        mock_config.access_token = "test-token"
        mock_config.backend_url = "https://api.test.com"
        mock_config.refresh_token = "test-refresh"
        mock_config_cls.return_value = mock_config

        mock_client = MagicMock()
        mock_client.__enter__ = MagicMock(return_value=mock_client)
        mock_client.__exit__ = MagicMock(return_value=False)
        mock_client.list_organizations.side_effect = Exception("Connection error")
        mock_api_client_cls.return_value = mock_client

        result = runner.invoke(list_organizations)

        assert "erro" in result.output.lower()


class TestSelectOrganization:
    """Tests for organizations select command."""

    @pytest.fixture
    def runner(self):
        return CliRunner()

    @patch("wally_dev.commands.organizations.Settings")
    @patch("wally_dev.commands.organizations.LocalConfig")
    def test_select_not_authenticated(self, mock_config_cls, mock_settings_cls, runner: CliRunner):
        """Test select organization when not authenticated."""
        mock_config = MagicMock()
        mock_config.access_token = None
        mock_config_cls.return_value = mock_config

        result = runner.invoke(select_organization)

        # Click doesn't propagate return values as exit codes by default
        assert "autenticado" in result.output.lower()

    @patch("wally_dev.commands.organizations.WallyDevApiClient")
    @patch("wally_dev.commands.organizations.Settings")
    @patch("wally_dev.commands.organizations.LocalConfig")
    def test_select_no_organizations(
        self, mock_config_cls, mock_settings_cls, mock_api_client_cls, runner: CliRunner
    ):
        """Test select organization with no orgs available."""
        mock_config = MagicMock()
        mock_config.access_token = "test-token"
        mock_config.backend_url = "https://api.test.com"
        mock_config.refresh_token = "test-refresh"
        mock_config_cls.return_value = mock_config

        mock_client = MagicMock()
        mock_client.__enter__ = MagicMock(return_value=mock_client)
        mock_client.__exit__ = MagicMock(return_value=False)
        mock_client.list_organizations.return_value = []
        mock_api_client_cls.return_value = mock_client

        result = runner.invoke(select_organization)

        # Check output message
        assert "organização" in result.output.lower()

    @patch("wally_dev.commands.organizations.click.prompt")
    @patch("wally_dev.commands.organizations.WallyDevApiClient")
    @patch("wally_dev.commands.organizations.Settings")
    @patch("wally_dev.commands.organizations.LocalConfig")
    def test_select_organization_success(
        self,
        mock_config_cls,
        mock_settings_cls,
        mock_api_client_cls,
        mock_prompt,
        runner: CliRunner,
    ):
        """Test selecting an organization successfully."""
        mock_config = MagicMock()
        mock_config.access_token = "test-token"
        mock_config.backend_url = "https://api.test.com"
        mock_config.refresh_token = "test-refresh"
        mock_config.organization_id = None
        mock_config_cls.return_value = mock_config

        mock_org = MagicMock()
        mock_org.id = "org1"
        mock_org.name = "Test Org"
        mock_org.description = "Test"

        mock_client = MagicMock()
        mock_client.__enter__ = MagicMock(return_value=mock_client)
        mock_client.__exit__ = MagicMock(return_value=False)
        mock_client.list_organizations.return_value = [mock_org]
        mock_api_client_cls.return_value = mock_client

        mock_prompt.return_value = "1"

        result = runner.invoke(select_organization)

        # Command should complete without error
        assert result.exception is None or result.exit_code == 0
        # Verify organization was shown
        assert "test org" in result.output.lower() or "organização" in result.output.lower()

    @patch("wally_dev.commands.organizations.click.prompt")
    @patch("wally_dev.commands.organizations.WallyDevApiClient")
    @patch("wally_dev.commands.organizations.Settings")
    @patch("wally_dev.commands.organizations.LocalConfig")
    def test_select_organization_cancel(
        self,
        mock_config_cls,
        mock_settings_cls,
        mock_api_client_cls,
        mock_prompt,
        runner: CliRunner,
    ):
        """Test canceling organization selection."""
        mock_config = MagicMock()
        mock_config.access_token = "test-token"
        mock_config.backend_url = "https://api.test.com"
        mock_config.refresh_token = "test-refresh"
        mock_config_cls.return_value = mock_config

        mock_org = MagicMock()
        mock_org.id = "org1"
        mock_org.name = "Test Org"
        mock_org.description = "Test"

        mock_client = MagicMock()
        mock_client.__enter__ = MagicMock(return_value=mock_client)
        mock_client.__exit__ = MagicMock(return_value=False)
        mock_client.list_organizations.return_value = [mock_org]
        mock_api_client_cls.return_value = mock_client

        # Simulate user pressing Ctrl+C to cancel (raises Abort after showing list)
        mock_prompt.side_effect = click.Abort()

        result = runner.invoke(select_organization)

        # Should show organization list before abort
        assert "test org" in result.output.lower() or "organização" in result.output.lower()

    @patch("wally_dev.commands.organizations.click.prompt")
    @patch("wally_dev.commands.organizations.WallyDevApiClient")
    @patch("wally_dev.commands.organizations.Settings")
    @patch("wally_dev.commands.organizations.LocalConfig")
    def test_select_organization_invalid_input(
        self,
        mock_config_cls,
        mock_settings_cls,
        mock_api_client_cls,
        mock_prompt,
        runner: CliRunner,
    ):
        """Test invalid input in organization selection."""
        mock_config = MagicMock()
        mock_config.access_token = "test-token"
        mock_config.backend_url = "https://api.test.com"
        mock_config.refresh_token = "test-refresh"
        mock_config_cls.return_value = mock_config

        mock_org = MagicMock()
        mock_org.id = "org1"
        mock_org.name = "Test Org"
        mock_org.description = "Test"

        mock_client = MagicMock()
        mock_client.__enter__ = MagicMock(return_value=mock_client)
        mock_client.__exit__ = MagicMock(return_value=False)
        mock_client.list_organizations.return_value = [mock_org]
        mock_api_client_cls.return_value = mock_client

        # First invalid, then valid
        mock_prompt.side_effect = ["5", "1"]

        result = runner.invoke(select_organization)

        # Command should show organization or error about invalid number
        assert "test org" in result.output.lower() or "organização" in result.output.lower()

    @patch("wally_dev.commands.organizations.WallyDevApiClient")
    @patch("wally_dev.commands.organizations.Settings")
    @patch("wally_dev.commands.organizations.LocalConfig")
    def test_select_token_expired(
        self, mock_config_cls, mock_settings_cls, mock_api_client_cls, runner: CliRunner
    ):
        """Test select organization with expired token."""
        mock_config = MagicMock()
        mock_config.access_token = "expired-token"
        mock_config.backend_url = "https://api.test.com"
        mock_config.refresh_token = "test-refresh"
        mock_config_cls.return_value = mock_config

        mock_client = MagicMock()
        mock_client.__enter__ = MagicMock(return_value=mock_client)
        mock_client.__exit__ = MagicMock(return_value=False)
        mock_client.list_organizations.side_effect = TokenExpiredError()
        mock_api_client_cls.return_value = mock_client

        result = runner.invoke(select_organization)

        # Check for session expired message
        assert "expirou" in result.output.lower() or "sessão" in result.output.lower()


class TestOrganizationsLongDescription:
    """Tests for edge cases with long descriptions."""

    @pytest.fixture
    def runner(self):
        return CliRunner()

    @patch("wally_dev.commands.organizations.WallyDevApiClient")
    @patch("wally_dev.commands.organizations.Settings")
    @patch("wally_dev.commands.organizations.LocalConfig")
    def test_list_long_description_truncated(
        self, mock_config_cls, mock_settings_cls, mock_api_client_cls, runner: CliRunner
    ):
        """Test that long descriptions are truncated."""
        mock_config = MagicMock()
        mock_config.access_token = "test-token"
        mock_config.backend_url = "https://api.test.com"
        mock_config.refresh_token = "test-refresh"
        mock_config.organization_id = "org1"
        mock_config_cls.return_value = mock_config

        mock_org = MagicMock()
        mock_org.id = "org1"
        mock_org.name = "Test Org"
        mock_org.description = "A" * 100  # Long description

        mock_client = MagicMock()
        mock_client.__enter__ = MagicMock(return_value=mock_client)
        mock_client.__exit__ = MagicMock(return_value=False)
        mock_client.list_organizations.return_value = [mock_org]
        mock_api_client_cls.return_value = mock_client

        result = runner.invoke(list_organizations)

        assert result.exit_code == EXIT_SUCCESS
        assert "..." in result.output  # Description was truncated

    @patch("wally_dev.commands.organizations.WallyDevApiClient")
    @patch("wally_dev.commands.organizations.Settings")
    @patch("wally_dev.commands.organizations.LocalConfig")
    def test_list_no_description(
        self, mock_config_cls, mock_settings_cls, mock_api_client_cls, runner: CliRunner
    ):
        """Test organizations with no description."""
        mock_config = MagicMock()
        mock_config.access_token = "test-token"
        mock_config.backend_url = "https://api.test.com"
        mock_config.refresh_token = "test-refresh"
        mock_config.organization_id = None
        mock_config_cls.return_value = mock_config

        mock_org = MagicMock()
        mock_org.id = "org1"
        mock_org.name = "Test Org"
        mock_org.description = None

        mock_client = MagicMock()
        mock_client.__enter__ = MagicMock(return_value=mock_client)
        mock_client.__exit__ = MagicMock(return_value=False)
        mock_client.list_organizations.return_value = [mock_org]
        mock_api_client_cls.return_value = mock_client

        result = runner.invoke(list_organizations)

        assert result.exit_code == EXIT_SUCCESS
