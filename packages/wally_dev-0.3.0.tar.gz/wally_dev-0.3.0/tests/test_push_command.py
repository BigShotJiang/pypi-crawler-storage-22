"""
Tests for wally_dev push command.

Comprehensive test coverage for testcase upload functionality.
"""

from unittest.mock import MagicMock, patch

from click.testing import CliRunner

from wally_dev.commands.push import _get_norm_for_push, push
from wally_dev.constants import EXIT_ERROR_API, EXIT_SUCCESS


class TestGetNormForPush:
    """Tests for _get_norm_for_push helper."""

    def test_no_locked_norms(self):
        """Test when no norms are in checkout."""
        config = MagicMock()
        config.get_locked_norms.return_value = {}

        result = _get_norm_for_push(config)

        assert result is None

    def test_single_locked_norm(self):
        """Test when exactly one norm is in checkout."""
        config = MagicMock()
        config.get_locked_norms.return_value = {
            "norm123": {"norm_name": "WCAG 2.1", "checkout_at": "2025-01-01T10:00:00"}
        }

        result = _get_norm_for_push(config)

        assert result == "norm123"

    @patch("wally_dev.commands.push.click.prompt")
    def test_multiple_locked_norms_select_first(self, mock_prompt):
        """Test selecting norm when multiple in checkout."""
        config = MagicMock()
        config.get_locked_norms.return_value = {
            "norm1": {"norm_name": "WCAG 2.1", "checkout_at": "2025-01-01"},
            "norm2": {"norm_name": "NBR 17225", "checkout_at": "2025-01-02"},
        }
        mock_prompt.return_value = "1"

        result = _get_norm_for_push(config)

        assert result == "norm1"

    @patch("wally_dev.commands.push.click.prompt")
    def test_multiple_locked_norms_select_second(self, mock_prompt):
        """Test selecting second norm from list."""
        config = MagicMock()
        config.get_locked_norms.return_value = {
            "norm1": {"norm_name": "WCAG 2.1", "checkout_at": "2025-01-01"},
            "norm2": {"norm_name": "NBR 17225", "checkout_at": "2025-01-02"},
        }
        mock_prompt.return_value = "2"

        result = _get_norm_for_push(config)

        assert result == "norm2"

    @patch("wally_dev.commands.push.click.prompt")
    def test_multiple_locked_norms_cancel(self, mock_prompt):
        """Test canceling norm selection."""
        config = MagicMock()
        config.get_locked_norms.return_value = {
            "norm1": {"norm_name": "WCAG 2.1", "checkout_at": "2025-01-01"},
            "norm2": {"norm_name": "NBR 17225", "checkout_at": "2025-01-02"},
        }
        mock_prompt.return_value = "0"

        result = _get_norm_for_push(config)

        assert result is None

    @patch("wally_dev.commands.push.click.prompt")
    def test_multiple_locked_norms_invalid_then_valid(self, mock_prompt):
        """Test invalid input followed by valid selection."""
        config = MagicMock()
        config.get_locked_norms.return_value = {
            "norm1": {"norm_name": "WCAG 2.1", "checkout_at": "2025-01-01"},
            "norm2": {"norm_name": "NBR 17225", "checkout_at": "2025-01-02"},
        }
        # First invalid, then valid
        mock_prompt.side_effect = ["5", "1"]

        result = _get_norm_for_push(config)

        assert result == "norm1"

    @patch("wally_dev.commands.push.click.prompt")
    def test_multiple_locked_norms_non_numeric(self, mock_prompt):
        """Test non-numeric input followed by valid selection."""
        config = MagicMock()
        config.get_locked_norms.return_value = {
            "norm1": {"norm_name": "WCAG 2.1", "checkout_at": "2025-01-01"},
        }
        mock_prompt.side_effect = ["abc", "1"]

        result = _get_norm_for_push(config)

        assert result == "norm1"


class TestPushCommand:
    """Tests for main push command."""

    @patch("wally_dev.commands.push.WorkspaceManager")
    @patch("wally_dev.commands.push.Settings")
    @patch("wally_dev.commands.push.LocalConfig")
    def test_push_not_logged_in(self, mock_config_cls, mock_settings_cls, mock_workspace_cls):
        """Test push when not logged in."""
        mock_config = MagicMock()
        mock_config.is_logged_in = False
        mock_config_cls.return_value = mock_config

        runner = CliRunner()
        result = runner.invoke(push)

        # Should raise NotLoggedInError and exit with error
        assert result.exit_code != EXIT_SUCCESS

    @patch("wally_dev.commands.push._get_norm_for_push")
    @patch("wally_dev.commands.push.WorkspaceManager")
    @patch("wally_dev.commands.push.Settings")
    @patch("wally_dev.commands.push.LocalConfig")
    def test_push_no_norm_selected(
        self, mock_config_cls, mock_settings_cls, mock_workspace_cls, mock_get_norm
    ):
        """Test push when no norm selected from interactive."""
        mock_config = MagicMock()
        mock_config.is_logged_in = True
        mock_config.get_locked_norms.return_value = {}  # No norms, triggers _get_norm_for_push
        mock_config_cls.return_value = mock_config
        mock_get_norm.return_value = None  # User cancelled selection

        runner = CliRunner()
        result = runner.invoke(push)

        # Should have called _get_norm_for_push
        mock_get_norm.assert_called_once()
        # Returns API error or empty output since no norm selected
        assert result.exit_code in (0, EXIT_ERROR_API)

    @patch("wally_dev.commands.push._get_norm_for_push")
    @patch("wally_dev.commands.push.WorkspaceManager")
    @patch("wally_dev.commands.push.Settings")
    @patch("wally_dev.commands.push.LocalConfig")
    def test_push_norm_not_checked_out(
        self, mock_config_cls, mock_settings_cls, mock_workspace_cls, mock_get_norm
    ):
        """Test push when norm is not checked out locally."""
        mock_config = MagicMock()
        mock_config.is_logged_in = True
        mock_config.is_norm_locked_locally.return_value = False
        mock_config_cls.return_value = mock_config
        mock_get_norm.return_value = "norm123"

        runner = CliRunner()
        result = runner.invoke(push)

        assert "não está em checkout" in result.output.lower()
        assert result.exit_code == EXIT_SUCCESS

    @patch("wally_dev.commands.push._get_norm_for_push")
    @patch("wally_dev.commands.push.WorkspaceManager")
    @patch("wally_dev.commands.push.Settings")
    @patch("wally_dev.commands.push.LocalConfig")
    def test_push_no_modifications(
        self, mock_config_cls, mock_settings_cls, mock_workspace_cls, mock_get_norm
    ):
        """Test push when no local modifications."""
        mock_config = MagicMock()
        mock_config.is_logged_in = True
        mock_config.is_norm_locked_locally.return_value = True
        mock_config_cls.return_value = mock_config
        mock_get_norm.return_value = "norm123"

        mock_workspace = MagicMock()
        mock_workspace.get_locally_modified_testcases.return_value = []
        mock_workspace_cls.return_value = mock_workspace

        runner = CliRunner()
        result = runner.invoke(push)

        assert "nenhuma alteração" in result.output.lower()
        assert result.exit_code == EXIT_SUCCESS

    @patch("wally_dev.commands.push._get_norm_for_push")
    @patch("wally_dev.commands.push.WorkspaceManager")
    @patch("wally_dev.commands.push.Settings")
    @patch("wally_dev.commands.push.LocalConfig")
    def test_push_with_explicit_norm_id(
        self, mock_config_cls, mock_settings_cls, mock_workspace_cls, mock_get_norm
    ):
        """Test push with explicit --norm-id."""
        mock_config = MagicMock()
        mock_config.is_logged_in = True
        mock_config.is_norm_locked_locally.return_value = True
        mock_config_cls.return_value = mock_config

        mock_workspace = MagicMock()
        mock_workspace.get_locally_modified_testcases.return_value = []
        mock_workspace_cls.return_value = mock_workspace

        runner = CliRunner()
        _ = runner.invoke(push, ["--norm-id", "explicit-norm"])

        # Should not call _get_norm_for_push when norm_id is explicit
        mock_get_norm.assert_not_called()

    @patch("wally_dev.commands.push.Confirm")
    @patch("wally_dev.commands.push._get_norm_for_push")
    @patch("wally_dev.commands.push.WorkspaceManager")
    @patch("wally_dev.commands.push.Settings")
    @patch("wally_dev.commands.push.LocalConfig")
    def test_push_cancelled_by_user(
        self, mock_config_cls, mock_settings_cls, mock_workspace_cls, mock_get_norm, mock_confirm
    ):
        """Test push cancelled by user confirmation."""
        mock_config = MagicMock()
        mock_config.is_logged_in = True
        mock_config.is_norm_locked_locally.return_value = True
        mock_config_cls.return_value = mock_config
        mock_get_norm.return_value = "norm123"

        # Create proper testcase mock with string attributes
        mock_testcase = MagicMock()
        mock_testcase.id = "tc1"
        mock_testcase.name = "Test Case Name"
        mock_testcase.code = True
        mock_testcase.examples = []

        mock_workspace = MagicMock()
        mock_workspace.get_locally_modified_testcases.return_value = ["tc1"]
        mock_workspace.get_testcase_changes.return_value = {
            "added": [],
            "modified": [],
            "deleted": [],
        }
        mock_workspace.load_testcase.return_value = mock_testcase
        mock_workspace_cls.return_value = mock_workspace

        # Mock API client context manager
        mock_client = MagicMock()
        mock_config.create_api_client.return_value.__enter__ = MagicMock(return_value=mock_client)
        mock_config.create_api_client.return_value.__exit__ = MagicMock(return_value=False)

        mock_confirm.ask.return_value = False

        runner = CliRunner()
        result = runner.invoke(push)

        assert "cancelado" in result.output.lower()

    @patch("wally_dev.commands.push._get_norm_for_push")
    @patch("wally_dev.commands.push.WorkspaceManager")
    @patch("wally_dev.commands.push.Settings")
    @patch("wally_dev.commands.push.LocalConfig")
    def test_push_force_flag(
        self, mock_config_cls, mock_settings_cls, mock_workspace_cls, mock_get_norm
    ):
        """Test push with --force flag skips confirmation."""
        mock_config = MagicMock()
        mock_config.is_logged_in = True
        mock_config.is_norm_locked_locally.return_value = True
        mock_config_cls.return_value = mock_config
        mock_get_norm.return_value = "norm123"

        mock_workspace = MagicMock()
        mock_workspace.get_locally_modified_testcases.return_value = []
        mock_workspace_cls.return_value = mock_workspace

        runner = CliRunner()
        result = runner.invoke(push, ["--force"])

        # Force flag allows push even with no modifications
        assert result.exit_code == EXIT_SUCCESS

    @patch("wally_dev.commands.push._get_norm_for_push")
    @patch("wally_dev.commands.push.WorkspaceManager")
    @patch("wally_dev.commands.push.Settings")
    @patch("wally_dev.commands.push.LocalConfig")
    def test_push_all_flag_empty_workspace(
        self, mock_config_cls, mock_settings_cls, mock_workspace_cls, mock_get_norm
    ):
        """Test push --all with empty workspace."""
        mock_config = MagicMock()
        mock_config.is_logged_in = True
        mock_config.is_norm_locked_locally.return_value = True
        mock_config_cls.return_value = mock_config
        mock_get_norm.return_value = "norm123"

        mock_workspace = MagicMock()
        mock_workspace.get_all_local_testcase_ids.return_value = []
        mock_workspace_cls.return_value = mock_workspace

        runner = CliRunner()
        result = runner.invoke(push, ["--all"])

        assert "nenhum caso de teste" in result.output.lower()
        assert result.exit_code == EXIT_SUCCESS


class TestPushWithModifications:
    """Tests for push with actual modifications."""

    @patch("wally_dev.commands.push.Confirm")
    @patch("wally_dev.commands.push._get_norm_for_push")
    @patch("wally_dev.commands.push.WorkspaceManager")
    @patch("wally_dev.commands.push.Settings")
    @patch("wally_dev.commands.push.LocalConfig")
    def test_push_with_added_files(
        self, mock_config_cls, mock_settings_cls, mock_workspace_cls, mock_get_norm, mock_confirm
    ):
        """Test push with newly added files."""
        mock_config = MagicMock()
        mock_config.is_logged_in = True
        mock_config.is_norm_locked_locally.return_value = True
        mock_config_cls.return_value = mock_config
        mock_get_norm.return_value = "norm123"

        mock_workspace = MagicMock()
        mock_workspace.get_locally_modified_testcases.return_value = ["tc1"]
        mock_workspace.get_testcase_changes.return_value = {
            "added": ["code/finder.py"],
            "modified": [],
            "deleted": [],
        }
        mock_testcase = MagicMock(id="tc1", name="Test", code=True, examples=[], rule_id="rule1")
        mock_workspace.load_testcase.return_value = mock_testcase
        mock_workspace_cls.return_value = mock_workspace

        # Mock API client
        mock_client = MagicMock()
        mock_client.get_testcase_files.return_value = []
        mock_config.create_api_client.return_value.__enter__ = MagicMock(return_value=mock_client)
        mock_config.create_api_client.return_value.__exit__ = MagicMock(return_value=False)

        mock_confirm.ask.return_value = True

        runner = CliRunner()
        result = runner.invoke(push)

        # Should show added files in changes
        assert "+1" in result.output or "novo" in result.output.lower()

    @patch("wally_dev.commands.push.Confirm")
    @patch("wally_dev.commands.push._get_norm_for_push")
    @patch("wally_dev.commands.push.WorkspaceManager")
    @patch("wally_dev.commands.push.Settings")
    @patch("wally_dev.commands.push.LocalConfig")
    def test_push_with_modified_files(
        self, mock_config_cls, mock_settings_cls, mock_workspace_cls, mock_get_norm, mock_confirm
    ):
        """Test push with modified files."""
        mock_config = MagicMock()
        mock_config.is_logged_in = True
        mock_config.is_norm_locked_locally.return_value = True
        mock_config_cls.return_value = mock_config
        mock_get_norm.return_value = "norm123"

        mock_workspace = MagicMock()
        mock_workspace.get_locally_modified_testcases.return_value = ["tc1"]
        mock_workspace.get_testcase_changes.return_value = {
            "added": [],
            "modified": ["code/validator.py"],
            "deleted": [],
        }
        mock_workspace.load_testcase.return_value = MagicMock(
            id="tc1", name="Test", code=True, examples=[]
        )
        mock_workspace_cls.return_value = mock_workspace

        # Mock API context
        mock_client = MagicMock()
        mock_config.create_api_client.return_value.__enter__ = MagicMock(return_value=mock_client)
        mock_config.create_api_client.return_value.__exit__ = MagicMock(return_value=False)

        mock_confirm.ask.return_value = True

        runner = CliRunner()
        result = runner.invoke(push)

        assert "~1" in result.output or "modificado" in result.output.lower()

    @patch("wally_dev.commands.push.Confirm")
    @patch("wally_dev.commands.push._get_norm_for_push")
    @patch("wally_dev.commands.push.WorkspaceManager")
    @patch("wally_dev.commands.push.Settings")
    @patch("wally_dev.commands.push.LocalConfig")
    def test_push_with_deleted_files(
        self, mock_config_cls, mock_settings_cls, mock_workspace_cls, mock_get_norm, mock_confirm
    ):
        """Test push with deleted files."""
        mock_config = MagicMock()
        mock_config.is_logged_in = True
        mock_config.is_norm_locked_locally.return_value = True
        mock_config_cls.return_value = mock_config
        mock_get_norm.return_value = "norm123"

        mock_workspace = MagicMock()
        mock_workspace.get_locally_modified_testcases.return_value = ["tc1"]
        mock_workspace.get_testcase_changes.return_value = {
            "added": [],
            "modified": [],
            "deleted": ["code/old.py"],
        }
        mock_workspace.load_testcase.return_value = MagicMock(
            id="tc1", name="Test", code=True, examples=[]
        )
        mock_workspace_cls.return_value = mock_workspace

        mock_client = MagicMock()
        mock_config.create_api_client.return_value.__enter__ = MagicMock(return_value=mock_client)
        mock_config.create_api_client.return_value.__exit__ = MagicMock(return_value=False)

        mock_confirm.ask.return_value = True

        runner = CliRunner()
        result = runner.invoke(push)

        assert "-1" in result.output or "modificado" in result.output.lower()


class TestPushErrorHandling:
    """Tests for push error handling."""

    @patch("wally_dev.commands.push.WorkspaceManager")
    @patch("wally_dev.commands.push.Settings")
    @patch("wally_dev.commands.push.LocalConfig")
    def test_push_api_error(self, mock_config_cls, mock_settings_cls, mock_workspace_cls):
        """Test push handles API errors."""
        mock_config = MagicMock()
        mock_config.is_logged_in = True
        mock_config.is_norm_locked_locally.return_value = True
        mock_config.get_locked_norms.return_value = {"norm1": {"norm_name": "Test"}}
        mock_config_cls.return_value = mock_config

        mock_workspace = MagicMock()
        mock_workspace.get_locally_modified_testcases.side_effect = Exception("API Error")
        mock_workspace_cls.return_value = mock_workspace

        runner = CliRunner()
        result = runner.invoke(push)

        assert result.exit_code == EXIT_ERROR_API or "erro" in result.output.lower()

    @patch("wally_dev.commands.push.WorkspaceManager")
    @patch("wally_dev.commands.push.Settings")
    @patch("wally_dev.commands.push.LocalConfig")
    def test_push_load_testcase_error(self, mock_config_cls, mock_settings_cls, mock_workspace_cls):
        """Test push handles testcase load errors gracefully."""
        mock_config = MagicMock()
        mock_config.is_logged_in = True
        mock_config.is_norm_locked_locally.return_value = True
        mock_config.get_locked_norms.return_value = {"norm1": {"norm_name": "Test"}}
        mock_config_cls.return_value = mock_config

        mock_workspace = MagicMock()
        mock_workspace.get_locally_modified_testcases.return_value = ["tc1"]
        mock_workspace.get_testcase_changes.return_value = {
            "added": [],
            "modified": [],
            "deleted": [],
        }
        mock_workspace.load_testcase.side_effect = Exception("Load failed")
        mock_workspace_cls.return_value = mock_workspace

        # Mock API client
        mock_client = MagicMock()
        mock_config.create_api_client.return_value.__enter__ = MagicMock(return_value=mock_client)
        mock_config.create_api_client.return_value.__exit__ = MagicMock(return_value=False)

        runner = CliRunner()
        result = runner.invoke(push)

        # Should handle gracefully with warning
        assert "aviso" in result.output.lower() or "não foi possível" in result.output.lower()


class TestPushMultipleTestcases:
    """Tests for push with multiple testcases."""

    @patch("wally_dev.commands.push.Confirm")
    @patch("wally_dev.commands.push._get_norm_for_push")
    @patch("wally_dev.commands.push.WorkspaceManager")
    @patch("wally_dev.commands.push.Settings")
    @patch("wally_dev.commands.push.LocalConfig")
    def test_push_multiple_testcases_truncated(
        self, mock_config_cls, mock_settings_cls, mock_workspace_cls, mock_get_norm, mock_confirm
    ):
        """Test push shows truncated list for many testcases."""
        mock_config = MagicMock()
        mock_config.is_logged_in = True
        mock_config.is_norm_locked_locally.return_value = True
        mock_config_cls.return_value = mock_config
        mock_get_norm.return_value = "norm123"

        # Create 15 testcase IDs
        testcase_ids = [f"tc{i}" for i in range(15)]

        mock_workspace = MagicMock()
        mock_workspace.get_locally_modified_testcases.return_value = testcase_ids
        mock_workspace.get_testcase_changes.return_value = {
            "added": [],
            "modified": ["f.py"],
            "deleted": [],
        }
        mock_workspace.load_testcase.return_value = MagicMock(
            id="tc", name="Test", code=True, examples=[]
        )
        mock_workspace_cls.return_value = mock_workspace

        mock_client = MagicMock()
        mock_config.create_api_client.return_value.__enter__ = MagicMock(return_value=mock_client)
        mock_config.create_api_client.return_value.__exit__ = MagicMock(return_value=False)

        mock_confirm.ask.return_value = False  # Cancel to avoid full execution

        runner = CliRunner()
        result = runner.invoke(push)

        # Should show truncation message
        assert "mais" in result.output.lower() or "5" in result.output


class TestPushAllFlag:
    """Tests for push --all functionality."""

    @patch("wally_dev.commands.push.Confirm")
    @patch("wally_dev.commands.push._get_norm_for_push")
    @patch("wally_dev.commands.push.WorkspaceManager")
    @patch("wally_dev.commands.push.Settings")
    @patch("wally_dev.commands.push.LocalConfig")
    def test_push_all_uploads_everything(
        self, mock_config_cls, mock_settings_cls, mock_workspace_cls, mock_get_norm, mock_confirm
    ):
        """Test push --all uploads all files."""
        mock_config = MagicMock()
        mock_config.is_logged_in = True
        mock_config.is_norm_locked_locally.return_value = True
        mock_config_cls.return_value = mock_config
        mock_get_norm.return_value = "norm123"

        mock_workspace = MagicMock()
        mock_workspace.get_all_local_testcase_ids.return_value = ["tc1", "tc2"]
        mock_workspace.load_testcase.return_value = MagicMock(
            id="tc", name="Test", code=True, examples=[], rule_id="rule1"
        )
        mock_workspace.get_all_testcase_files.return_value = ["code/finder.py", "code/validator.py"]
        mock_workspace_cls.return_value = mock_workspace

        mock_client = MagicMock()
        mock_client.get_testcase_files.return_value = []
        mock_config.create_api_client.return_value.__enter__ = MagicMock(return_value=mock_client)
        mock_config.create_api_client.return_value.__exit__ = MagicMock(return_value=False)

        mock_confirm.ask.return_value = True

        runner = CliRunner()
        result = runner.invoke(push, ["--all", "--force"])

        # Should process all files
        assert "enviando todos" in result.output.lower() or "2" in result.output


class TestPushFileUpload:
    """Tests for push file upload logic."""

    @patch("wally_dev.commands.push.Confirm")
    @patch("wally_dev.commands.push._get_norm_for_push")
    @patch("wally_dev.commands.push.WorkspaceManager")
    @patch("wally_dev.commands.push.Settings")
    @patch("wally_dev.commands.push.LocalConfig")
    def test_push_with_file_upload_success(
        self,
        mock_config_cls,
        mock_settings_cls,
        mock_workspace_cls,
        mock_get_norm,
        mock_confirm,
        tmp_path,
    ):
        """Test push successfully uploads files."""
        mock_config = MagicMock()
        mock_config.is_logged_in = True
        mock_config.is_norm_locked_locally.return_value = True
        mock_config_cls.return_value = mock_config
        mock_get_norm.return_value = "norm123"

        # Create actual files
        testcase_dir = tmp_path / "testcases" / "tc1"
        code_dir = testcase_dir / "code"
        code_dir.mkdir(parents=True)
        (code_dir / "finder.py").write_text("def find(html): return []")

        mock_workspace = MagicMock()
        mock_workspace.get_locally_modified_testcases.return_value = ["tc1"]
        mock_workspace.get_testcase_changes.return_value = {
            "added": [],
            "modified": ["code/finder.py"],
            "deleted": [],
        }
        mock_workspace.load_testcase.return_value = MagicMock(
            id="tc1", name="Test", code=True, examples=[], rule_id="rule1"
        )
        mock_workspace.get_testcase_dir.return_value = testcase_dir
        mock_workspace_cls.return_value = mock_workspace

        mock_client = MagicMock()
        mock_client.get_testcase_files.return_value = [{"path": "code/finder.py", "_id": "file123"}]
        mock_client.update_file_binary.return_value = None
        mock_config.create_api_client.return_value.__enter__ = MagicMock(return_value=mock_client)
        mock_config.create_api_client.return_value.__exit__ = MagicMock(return_value=False)

        mock_confirm.ask.return_value = True

        runner = CliRunner()
        result = runner.invoke(push, ["--force"])

        # Should succeed
        assert result.exit_code == EXIT_SUCCESS or "sucesso" in result.output.lower()


class TestPushExamplesUpload:
    """Tests for push examples upload."""

    @patch("wally_dev.commands.push.Confirm")
    @patch("wally_dev.commands.push._get_norm_for_push")
    @patch("wally_dev.commands.push.WorkspaceManager")
    @patch("wally_dev.commands.push.Settings")
    @patch("wally_dev.commands.push.LocalConfig")
    def test_push_uploads_examples(
        self,
        mock_config_cls,
        mock_settings_cls,
        mock_workspace_cls,
        mock_get_norm,
        mock_confirm,
        tmp_path,
    ):
        """Test push uploads HTML examples."""

        mock_config = MagicMock()
        mock_config.is_logged_in = True
        mock_config.is_norm_locked_locally.return_value = True
        mock_config_cls.return_value = mock_config
        mock_get_norm.return_value = "norm123"

        # Create example files
        testcase_dir = tmp_path / "testcases" / "tc1"
        examples_dir = testcase_dir / "examples"
        (examples_dir / "compliant").mkdir(parents=True)
        (examples_dir / "compliant" / "good.html").write_text("<html lang='pt'>Good</html>")

        tc_mock = MagicMock(
            id="tc1",
            name="Test",
            code=True,
            rule_id="rule1",
            examples=[MagicMock(id="ex1", name="compliant", expected_result="compliant")],
        )

        mock_workspace = MagicMock()
        mock_workspace.get_locally_modified_testcases.return_value = ["tc1"]
        mock_workspace.get_testcase_changes.return_value = {
            "added": [],
            "modified": [],
            "deleted": [],
        }
        mock_workspace.load_testcase.return_value = tc_mock
        mock_workspace.get_testcase_dir.return_value = testcase_dir
        mock_workspace_cls.return_value = mock_workspace

        api_testcase = MagicMock()
        api_testcase.examples = [MagicMock(id="ex1", name="compliant", expected_result="compliant")]

        mock_client = MagicMock()
        mock_client.get_testcase_files.return_value = []
        mock_client.get_testcase.return_value = api_testcase
        mock_client.update_example_binary.return_value = None
        mock_config.create_api_client.return_value.__enter__ = MagicMock(return_value=mock_client)
        mock_config.create_api_client.return_value.__exit__ = MagicMock(return_value=False)

        mock_confirm.ask.return_value = True

        runner = CliRunner()
        result = runner.invoke(push, ["--force"])

        # Should complete
        assert result.exit_code in [EXIT_SUCCESS, 0]


class TestPushFileUploadWithExistingFiles:
    """Tests for push file upload when files exist on server."""

    @patch("wally_dev.commands.push.Confirm")
    @patch("wally_dev.commands.push._get_norm_for_push")
    @patch("wally_dev.commands.push.WorkspaceManager")
    @patch("wally_dev.commands.push.Settings")
    @patch("wally_dev.commands.push.LocalConfig")
    def test_push_update_existing_file(
        self,
        mock_config_cls,
        mock_settings_cls,
        mock_workspace_cls,
        mock_get_norm,
        mock_confirm,
        tmp_path,
    ):
        """Test push updates existing file on server."""
        mock_config = MagicMock()
        mock_config.is_logged_in = True
        mock_config.is_norm_locked_locally.return_value = True
        mock_config_cls.return_value = mock_config
        mock_get_norm.return_value = "norm123"

        # Create actual files
        testcase_dir = tmp_path / "testcases" / "tc1"
        code_dir = testcase_dir / "code"
        code_dir.mkdir(parents=True)
        (code_dir / "finder.py").write_bytes(b"def find(html): return []")

        mock_workspace = MagicMock()
        mock_workspace.get_locally_modified_testcases.return_value = ["tc1"]
        mock_workspace.get_testcase_changes.return_value = {
            "added": [],
            "modified": ["code/finder.py"],
            "deleted": [],
        }
        mock_workspace.load_testcase.return_value = MagicMock(
            id="tc1", name="Test", code=True, examples=[], rule_id="rule1"
        )
        mock_workspace.get_testcase_dir.return_value = testcase_dir
        mock_workspace_cls.return_value = mock_workspace

        mock_client = MagicMock()
        mock_client.get_testcase_files.return_value = [{"path": "code/finder.py", "_id": "file123"}]
        mock_client.update_file_binary.return_value = {"_id": "file123"}
        mock_client.get_testcase.return_value = MagicMock(examples=[])
        mock_config.create_api_client.return_value.__enter__ = MagicMock(return_value=mock_client)
        mock_config.create_api_client.return_value.__exit__ = MagicMock(return_value=False)

        mock_confirm.ask.return_value = True

        runner = CliRunner()
        result = runner.invoke(push, ["--force"])

        # Should succeed or show modifications
        assert (
            result.exit_code == EXIT_SUCCESS
            or "sucesso" in result.output.lower()
            or "~1" in result.output
        )

    @patch("wally_dev.commands.push.Confirm")
    @patch("wally_dev.commands.push._get_norm_for_push")
    @patch("wally_dev.commands.push.WorkspaceManager")
    @patch("wally_dev.commands.push.Settings")
    @patch("wally_dev.commands.push.LocalConfig")
    def test_push_create_new_file_when_not_on_server(
        self,
        mock_config_cls,
        mock_settings_cls,
        mock_workspace_cls,
        mock_get_norm,
        mock_confirm,
        tmp_path,
    ):
        """Test push creates file when it doesn't exist on server."""
        mock_config = MagicMock()
        mock_config.is_logged_in = True
        mock_config.is_norm_locked_locally.return_value = True
        mock_config_cls.return_value = mock_config
        mock_get_norm.return_value = "norm123"

        # Create actual files
        testcase_dir = tmp_path / "testcases" / "tc1"
        code_dir = testcase_dir / "code"
        code_dir.mkdir(parents=True)
        (code_dir / "validator.py").write_bytes(b"def validate(element): return True")

        mock_workspace = MagicMock()
        mock_workspace.get_locally_modified_testcases.return_value = ["tc1"]
        mock_workspace.get_testcase_changes.return_value = {
            "added": ["code/validator.py"],
            "modified": [],
            "deleted": [],
        }
        mock_workspace.load_testcase.return_value = MagicMock(
            id="tc1", name="Test", code=True, examples=[], rule_id="rule1"
        )
        mock_workspace.get_testcase_dir.return_value = testcase_dir
        mock_workspace_cls.return_value = mock_workspace

        mock_client = MagicMock()
        mock_client.get_testcase_files.return_value = []  # No files on server
        mock_client.create_and_upload_file.return_value = {"_id": "new-file"}
        mock_client.get_testcase.return_value = MagicMock(examples=[])
        mock_config.create_api_client.return_value.__enter__ = MagicMock(return_value=mock_client)
        mock_config.create_api_client.return_value.__exit__ = MagicMock(return_value=False)

        mock_confirm.ask.return_value = True

        runner = CliRunner()
        result = runner.invoke(push, ["--force"])

        # Should succeed or show added files
        assert result.exit_code == EXIT_SUCCESS or "+1" in result.output

    @patch("wally_dev.commands.push.Confirm")
    @patch("wally_dev.commands.push._get_norm_for_push")
    @patch("wally_dev.commands.push.WorkspaceManager")
    @patch("wally_dev.commands.push.Settings")
    @patch("wally_dev.commands.push.LocalConfig")
    def test_push_delete_file_from_server(
        self,
        mock_config_cls,
        mock_settings_cls,
        mock_workspace_cls,
        mock_get_norm,
        mock_confirm,
        tmp_path,
    ):
        """Test push deletes file from server when deleted locally."""
        mock_config = MagicMock()
        mock_config.is_logged_in = True
        mock_config.is_norm_locked_locally.return_value = True
        mock_config_cls.return_value = mock_config
        mock_get_norm.return_value = "norm123"

        testcase_dir = tmp_path / "testcases" / "tc1"
        testcase_dir.mkdir(parents=True)

        mock_workspace = MagicMock()
        mock_workspace.get_locally_modified_testcases.return_value = ["tc1"]
        mock_workspace.get_testcase_changes.return_value = {
            "added": [],
            "modified": [],
            "deleted": ["code/old_file.py"],
        }
        mock_workspace.load_testcase.return_value = MagicMock(
            id="tc1", name="Test", code=True, examples=[], rule_id="rule1"
        )
        mock_workspace.get_testcase_dir.return_value = testcase_dir
        mock_workspace_cls.return_value = mock_workspace

        mock_client = MagicMock()
        mock_client.get_testcase_files.return_value = [
            {"path": "code/old_file.py", "_id": "del-file"}
        ]
        mock_client.delete_file.return_value = True
        mock_client.get_testcase.return_value = MagicMock(examples=[])
        mock_config.create_api_client.return_value.__enter__ = MagicMock(return_value=mock_client)
        mock_config.create_api_client.return_value.__exit__ = MagicMock(return_value=False)

        mock_confirm.ask.return_value = True

        runner = CliRunner()
        result = runner.invoke(push, ["--force"])

        # Should succeed or show deleted files
        assert result.exit_code == EXIT_SUCCESS or "-1" in result.output

    @patch("wally_dev.commands.push.Confirm")
    @patch("wally_dev.commands.push._get_norm_for_push")
    @patch("wally_dev.commands.push.WorkspaceManager")
    @patch("wally_dev.commands.push.Settings")
    @patch("wally_dev.commands.push.LocalConfig")
    def test_push_file_update_error(
        self,
        mock_config_cls,
        mock_settings_cls,
        mock_workspace_cls,
        mock_get_norm,
        mock_confirm,
        tmp_path,
    ):
        """Test push handles file update errors gracefully."""
        mock_config = MagicMock()
        mock_config.is_logged_in = True
        mock_config.is_norm_locked_locally.return_value = True
        mock_config_cls.return_value = mock_config
        mock_get_norm.return_value = "norm123"

        testcase_dir = tmp_path / "testcases" / "tc1"
        code_dir = testcase_dir / "code"
        code_dir.mkdir(parents=True)
        (code_dir / "finder.py").write_bytes(b"def find(html): return []")

        mock_workspace = MagicMock()
        mock_workspace.get_locally_modified_testcases.return_value = ["tc1"]
        mock_workspace.get_testcase_changes.return_value = {
            "added": [],
            "modified": ["code/finder.py"],
            "deleted": [],
        }
        mock_workspace.load_testcase.return_value = MagicMock(
            id="tc1", name="Test", code=True, examples=[], rule_id="rule1"
        )
        mock_workspace.get_testcase_dir.return_value = testcase_dir
        mock_workspace_cls.return_value = mock_workspace

        mock_client = MagicMock()
        mock_client.get_testcase_files.return_value = [{"path": "code/finder.py", "_id": "file123"}]
        mock_client.update_file_binary.side_effect = Exception("Upload failed")
        mock_client.get_testcase.return_value = MagicMock(examples=[])
        mock_config.create_api_client.return_value.__enter__ = MagicMock(return_value=mock_client)
        mock_config.create_api_client.return_value.__exit__ = MagicMock(return_value=False)

        mock_confirm.ask.return_value = True

        runner = CliRunner()
        result = runner.invoke(push, ["--force"])

        # Should show error but continue
        assert "✗" in result.output or "erro" in result.output.lower()


class TestPushAllFilesUpload:
    """Tests for push --all file upload."""

    @patch("wally_dev.commands.push.Confirm")
    @patch("wally_dev.commands.push._get_norm_for_push")
    @patch("wally_dev.commands.push.WorkspaceManager")
    @patch("wally_dev.commands.push.Settings")
    @patch("wally_dev.commands.push.LocalConfig")
    def test_push_all_uploads_all_files(
        self,
        mock_config_cls,
        mock_settings_cls,
        mock_workspace_cls,
        mock_get_norm,
        mock_confirm,
        tmp_path,
    ):
        """Test push --all uploads all files regardless of modification status."""
        mock_config = MagicMock()
        mock_config.is_logged_in = True
        mock_config.is_norm_locked_locally.return_value = True
        mock_config_cls.return_value = mock_config
        mock_get_norm.return_value = "norm123"

        testcase_dir = tmp_path / "testcases" / "tc1"
        code_dir = testcase_dir / "code"
        code_dir.mkdir(parents=True)
        (code_dir / "finder.py").write_bytes(b"def find(html): return []")
        (code_dir / "validator.py").write_bytes(b"def validate(el): return True")

        mock_workspace = MagicMock()
        mock_workspace.get_all_local_testcase_ids.return_value = ["tc1"]
        mock_workspace.load_testcase.return_value = MagicMock(
            id="tc1", name="Test", code=True, examples=[], rule_id="rule1"
        )
        mock_workspace.get_testcase_dir.return_value = testcase_dir
        mock_workspace.get_all_testcase_files.return_value = ["code/finder.py", "code/validator.py"]
        mock_workspace_cls.return_value = mock_workspace

        mock_client = MagicMock()
        mock_client.get_testcase_files.return_value = []
        mock_client.create_and_upload_file.return_value = {"_id": "new-file"}
        mock_client.get_testcase.return_value = MagicMock(examples=[])
        mock_config.create_api_client.return_value.__enter__ = MagicMock(return_value=mock_client)
        mock_config.create_api_client.return_value.__exit__ = MagicMock(return_value=False)

        mock_confirm.ask.return_value = True

        runner = CliRunner()
        result = runner.invoke(push, ["--all", "--force"])

        # Should complete or show files
        assert (
            result.exit_code == EXIT_SUCCESS
            or "tc1" in result.output
            or "enviando" in result.output.lower()
        )

    @patch("wally_dev.commands.push.Confirm")
    @patch("wally_dev.commands.push._get_norm_for_push")
    @patch("wally_dev.commands.push.WorkspaceManager")
    @patch("wally_dev.commands.push.Settings")
    @patch("wally_dev.commands.push.LocalConfig")
    def test_push_file_without_id_creates_new(
        self,
        mock_config_cls,
        mock_settings_cls,
        mock_workspace_cls,
        mock_get_norm,
        mock_confirm,
        tmp_path,
    ):
        """Test push creates file when server file has no ID."""
        mock_config = MagicMock()
        mock_config.is_logged_in = True
        mock_config.is_norm_locked_locally.return_value = True
        mock_config_cls.return_value = mock_config
        mock_get_norm.return_value = "norm123"

        testcase_dir = tmp_path / "testcases" / "tc1"
        code_dir = testcase_dir / "code"
        code_dir.mkdir(parents=True)
        (code_dir / "finder.py").write_bytes(b"def find(html): return []")

        mock_workspace = MagicMock()
        mock_workspace.get_locally_modified_testcases.return_value = ["tc1"]
        mock_workspace.get_testcase_changes.return_value = {
            "added": [],
            "modified": ["code/finder.py"],
            "deleted": [],
        }
        mock_workspace.load_testcase.return_value = MagicMock(
            id="tc1", name="Test", code=True, examples=[], rule_id="rule1"
        )
        mock_workspace.get_testcase_dir.return_value = testcase_dir
        mock_workspace_cls.return_value = mock_workspace

        mock_client = MagicMock()
        # Server file exists but has no ID
        mock_client.get_testcase_files.return_value = [{"path": "code/finder.py"}]  # No _id or id
        mock_client.create_and_upload_file.return_value = {"_id": "new-file"}
        mock_client.get_testcase.return_value = MagicMock(examples=[])
        mock_config.create_api_client.return_value.__enter__ = MagicMock(return_value=mock_client)
        mock_config.create_api_client.return_value.__exit__ = MagicMock(return_value=False)

        mock_confirm.ask.return_value = True

        runner = CliRunner()
        result = runner.invoke(push, ["--force"])

        # Should complete successfully
        assert result.exit_code == EXIT_SUCCESS or "~1" in result.output


class TestPushExamplesUploadDetailed:
    """Detailed tests for push examples upload with different scenarios."""

    @patch("wally_dev.commands.push.Confirm")
    @patch("wally_dev.commands.push._get_norm_for_push")
    @patch("wally_dev.commands.push.WorkspaceManager")
    @patch("wally_dev.commands.push.Settings")
    @patch("wally_dev.commands.push.LocalConfig")
    def test_push_non_compliant_examples(
        self,
        mock_config_cls,
        mock_settings_cls,
        mock_workspace_cls,
        mock_get_norm,
        mock_confirm,
        tmp_path,
    ):
        """Test push uploads non-compliant HTML examples."""
        mock_config = MagicMock()
        mock_config.is_logged_in = True
        mock_config.is_norm_locked_locally.return_value = True
        mock_config_cls.return_value = mock_config
        mock_get_norm.return_value = "norm123"

        testcase_dir = tmp_path / "testcases" / "tc1"
        examples_dir = testcase_dir / "examples"
        (examples_dir / "non-compliant").mkdir(parents=True)
        (examples_dir / "non-compliant" / "bad.html").write_text("<img>No alt</img>")

        mock_workspace = MagicMock()
        mock_workspace.get_locally_modified_testcases.return_value = ["tc1"]
        mock_workspace.get_testcase_changes.return_value = {
            "added": [],
            "modified": [],
            "deleted": [],
        }
        mock_workspace.load_testcase.return_value = MagicMock(
            id="tc1",
            name="Test",
            code=True,
            examples=[MagicMock(id="ex2", name="non-compliant", expected_result="non-compliant")],
            rule_id="rule1",
        )
        mock_workspace.get_testcase_dir.return_value = testcase_dir
        mock_workspace_cls.return_value = mock_workspace

        api_testcase = MagicMock()
        api_testcase.examples = [
            MagicMock(id="ex2", name="non-compliant", expected_result="non-compliant")
        ]

        mock_client = MagicMock()
        mock_client.get_testcase_files.return_value = []
        mock_client.get_testcase.return_value = api_testcase
        mock_client.update_example_binary.return_value = None
        mock_config.create_api_client.return_value.__enter__ = MagicMock(return_value=mock_client)
        mock_config.create_api_client.return_value.__exit__ = MagicMock(return_value=False)

        mock_confirm.ask.return_value = True

        runner = CliRunner()
        result = runner.invoke(push, ["--force"])

        # Should complete
        assert result.exit_code == EXIT_SUCCESS or "nenhuma alteração" in result.output.lower()

    @patch("wally_dev.commands.push.Confirm")
    @patch("wally_dev.commands.push._get_norm_for_push")
    @patch("wally_dev.commands.push.WorkspaceManager")
    @patch("wally_dev.commands.push.Settings")
    @patch("wally_dev.commands.push.LocalConfig")
    def test_push_examples_api_error(
        self,
        mock_config_cls,
        mock_settings_cls,
        mock_workspace_cls,
        mock_get_norm,
        mock_confirm,
        tmp_path,
    ):
        """Test push handles example API errors gracefully."""
        mock_config = MagicMock()
        mock_config.is_logged_in = True
        mock_config.is_norm_locked_locally.return_value = True
        mock_config_cls.return_value = mock_config
        mock_get_norm.return_value = "norm123"

        testcase_dir = tmp_path / "testcases" / "tc1"
        examples_dir = testcase_dir / "examples"
        (examples_dir / "compliant").mkdir(parents=True)
        (examples_dir / "compliant" / "good.html").write_text("<html lang='pt'>Good</html>")

        mock_workspace = MagicMock()
        mock_workspace.get_locally_modified_testcases.return_value = ["tc1"]
        mock_workspace.get_testcase_changes.return_value = {
            "added": [],
            "modified": [],
            "deleted": [],
        }
        mock_workspace.load_testcase.return_value = MagicMock(
            id="tc1",
            name="Test",
            code=True,
            examples=[MagicMock(id="ex1", name="compliant", expected_result="compliant")],
            rule_id="rule1",
        )
        mock_workspace.get_testcase_dir.return_value = testcase_dir
        mock_workspace_cls.return_value = mock_workspace

        mock_client = MagicMock()
        mock_client.get_testcase_files.return_value = []
        mock_client.get_testcase.side_effect = Exception("API error getting testcase")
        mock_config.create_api_client.return_value.__enter__ = MagicMock(return_value=mock_client)
        mock_config.create_api_client.return_value.__exit__ = MagicMock(return_value=False)

        mock_confirm.ask.return_value = True

        runner = CliRunner()
        result = runner.invoke(push, ["--force"])

        # Should complete (graceful handling)
        assert result.exit_code == EXIT_SUCCESS or "nenhuma alteração" in result.output.lower()


class TestPushGetNormSelection:
    """Tests for _get_norm_for_push with edge cases."""

    @patch("wally_dev.commands.push.click.prompt")
    def test_get_norm_invalid_number_out_of_range(self, mock_prompt):
        """Test selection with number out of range then valid."""
        config = MagicMock()
        config.get_locked_norms.return_value = {
            "norm1": {"norm_name": "WCAG 2.1", "checkout_at": "2025-01-01"},
            "norm2": {"norm_name": "NBR 17225", "checkout_at": "2025-01-02"},
        }
        # Invalid (out of range), then valid
        mock_prompt.side_effect = ["10", "2"]

        result = _get_norm_for_push(config)

        assert result == "norm2"
