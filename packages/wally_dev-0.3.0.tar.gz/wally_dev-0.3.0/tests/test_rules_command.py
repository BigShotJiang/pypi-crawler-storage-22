"""
Comprehensive tests for rules command.
"""

from unittest.mock import MagicMock, patch

import pytest
from click.testing import CliRunner

from wally_dev.cli import cli
from wally_dev.commands.rules import list_rules
from wally_dev.exceptions import (
    APIError,
    ConnectionFailedError,
    NormNotFoundError,
    PermissionDeniedError,
)
from wally_dev.models import Norm, Rule


class TestRulesListCommand:
    """Tests for rules list command."""

    @pytest.fixture
    def runner(self):
        return CliRunner()

    @pytest.fixture
    def sample_norm(self):
        """Create sample norm."""
        return Norm(id="norm123", name="WCAG 2.1", version="2.1")

    @pytest.fixture
    def sample_rules(self):
        """Create sample rules list."""
        return [
            Rule(
                id="rule1",
                name="Alt Text Required",
                description="Images must have alt text",
                norm_id="norm123",
                severity="critical",
                category="images",
                is_automatable=True,
            ),
            Rule(
                id="rule2",
                name="Lang Attribute",
                description="HTML must have lang attribute",
                norm_id="norm123",
                severity="high",
                category="document",
                is_automatable=True,
            ),
            Rule(
                id="rule3",
                name="Color Contrast",
                description="Text must have sufficient contrast",
                norm_id="norm123",
                severity="medium",
                category="visual",
                is_automatable=False,
            ),
        ]

    @patch("wally_dev.commands.rules.LocalConfig")
    def test_rules_list_not_logged_in(self, mock_config_class, runner: CliRunner):
        """Test rules list when not logged in."""
        mock_config = MagicMock()
        mock_config.is_logged_in = False
        mock_config_class.return_value = mock_config

        result = runner.invoke(list_rules, ["--norm-id", "norm123"])
        assert result.exit_code != 0 or "login" in result.output.lower()

    @patch("wally_dev.commands.rules.LocalConfig")
    def test_rules_list_empty(self, mock_config_class, runner: CliRunner, sample_norm):
        """Test rules list when no rules found."""
        mock_config = MagicMock()
        mock_config.is_logged_in = True

        mock_client = MagicMock()
        mock_client.__enter__ = MagicMock(return_value=mock_client)
        mock_client.__exit__ = MagicMock(return_value=False)
        mock_client.get_norm.return_value = sample_norm
        mock_client.get_rules_by_norm.return_value = []
        mock_config.create_api_client.return_value = mock_client

        mock_config_class.return_value = mock_config

        result = runner.invoke(list_rules, ["--norm-id", "norm123"])
        assert result.exit_code == 0
        assert "nenhuma" in result.output.lower() or "regra" in result.output.lower()

    @patch("wally_dev.commands.rules.LocalConfig")
    def test_rules_list_success(
        self, mock_config_class, runner: CliRunner, sample_norm, sample_rules
    ):
        """Test rules list with results."""
        mock_config = MagicMock()
        mock_config.is_logged_in = True

        mock_client = MagicMock()
        mock_client.__enter__ = MagicMock(return_value=mock_client)
        mock_client.__exit__ = MagicMock(return_value=False)
        mock_client.get_norm.return_value = sample_norm
        mock_client.get_rules_by_norm.return_value = sample_rules
        mock_config.create_api_client.return_value = mock_client

        mock_config_class.return_value = mock_config

        result = runner.invoke(list_rules, ["--norm-id", "norm123"])
        assert result.exit_code == 0
        assert "Alt Text" in result.output or "regra" in result.output.lower()

    @patch("wally_dev.commands.rules.LocalConfig")
    def test_rules_list_verbose(
        self, mock_config_class, runner: CliRunner, sample_norm, sample_rules
    ):
        """Test rules list with verbose flag."""
        mock_config = MagicMock()
        mock_config.is_logged_in = True

        mock_client = MagicMock()
        mock_client.__enter__ = MagicMock(return_value=mock_client)
        mock_client.__exit__ = MagicMock(return_value=False)
        mock_client.get_norm.return_value = sample_norm
        mock_client.get_rules_by_norm.return_value = sample_rules
        mock_config.create_api_client.return_value = mock_client

        mock_config_class.return_value = mock_config

        result = runner.invoke(list_rules, ["--norm-id", "norm123", "--verbose"])
        assert result.exit_code == 0
        # Verbose should include severity and category

    @patch("wally_dev.commands.rules.LocalConfig")
    def test_rules_list_norm_not_found(self, mock_config_class, runner: CliRunner):
        """Test rules list when norm not found."""
        mock_config = MagicMock()
        mock_config.is_logged_in = True

        mock_client = MagicMock()
        mock_client.__enter__ = MagicMock(return_value=mock_client)
        mock_client.__exit__ = MagicMock(return_value=False)
        mock_client.get_norm.side_effect = NormNotFoundError("Norm not found")
        mock_config.create_api_client.return_value = mock_client

        mock_config_class.return_value = mock_config

        result = runner.invoke(list_rules, ["--norm-id", "nonexistent"])
        assert result.exit_code != 0 or "não encontrada" in result.output.lower()

    @patch("wally_dev.commands.rules.LocalConfig")
    def test_rules_list_api_error(self, mock_config_class, runner: CliRunner, sample_norm):
        """Test rules list with API error."""
        mock_config = MagicMock()
        mock_config.is_logged_in = True

        mock_client = MagicMock()
        mock_client.__enter__ = MagicMock(return_value=mock_client)
        mock_client.__exit__ = MagicMock(return_value=False)
        mock_client.get_norm.return_value = sample_norm
        mock_client.get_rules_by_norm.side_effect = APIError("API Error")
        mock_config.create_api_client.return_value = mock_client

        mock_config_class.return_value = mock_config

        result = runner.invoke(list_rules, ["--norm-id", "norm123"])
        assert result.exit_code != 0 or "erro" in result.output.lower()

    @patch("wally_dev.commands.rules.LocalConfig")
    def test_rules_list_connection_error(self, mock_config_class, runner: CliRunner):
        """Test rules list with connection error."""
        mock_config = MagicMock()
        mock_config.is_logged_in = True

        mock_client = MagicMock()
        mock_client.__enter__ = MagicMock(return_value=mock_client)
        mock_client.__exit__ = MagicMock(return_value=False)
        mock_client.get_norm.side_effect = ConnectionFailedError("Connection failed")
        mock_config.create_api_client.return_value = mock_client

        mock_config_class.return_value = mock_config

        result = runner.invoke(list_rules, ["--norm-id", "norm123"])
        assert (
            result.exit_code != 0
            or "conexão" in result.output.lower()
            or "erro" in result.output.lower()
        )

    @patch("wally_dev.commands.rules.LocalConfig")
    def test_rules_list_permission_denied(self, mock_config_class, runner: CliRunner):
        """Test rules list with permission denied."""
        mock_config = MagicMock()
        mock_config.is_logged_in = True

        mock_client = MagicMock()
        mock_client.__enter__ = MagicMock(return_value=mock_client)
        mock_client.__exit__ = MagicMock(return_value=False)
        mock_client.get_norm.side_effect = PermissionDeniedError("Permission denied")
        mock_config.create_api_client.return_value = mock_client

        mock_config_class.return_value = mock_config

        result = runner.invoke(list_rules, ["--norm-id", "norm123"])
        assert result.exit_code != 0 or "permissão" in result.output.lower()


class TestRulesGroup:
    """Tests for rules command group."""

    @pytest.fixture
    def runner(self):
        return CliRunner()

    def test_rules_group_help(self, runner: CliRunner):
        """Test rules group help."""
        result = runner.invoke(cli, ["rules", "--help"])
        assert result.exit_code == 0
        assert "list" in result.output

    def test_rules_list_via_cli(self, runner: CliRunner):
        """Test rules list via CLI entry point."""
        result = runner.invoke(cli, ["rules", "list", "--help"])
        assert result.exit_code == 0
        assert "--norm-id" in result.output

    def test_rules_list_requires_norm_id(self, runner: CliRunner):
        """Test rules list requires --norm-id."""
        result = runner.invoke(cli, ["rules", "list"])
        assert result.exit_code != 0
