"""
Tests for wally_dev run command.

Comprehensive test coverage for local testcase execution.
"""

from unittest.mock import MagicMock, patch

from click.testing import CliRunner

from wally_dev.commands.run import (
    _find_norm_for_testcase,
    _load_examples_from_dir,
    _run_all_testcases,
    run,
)
from wally_dev.constants import EXIT_ERROR_RUNTIME, EXIT_SUCCESS
from wally_dev.models import ExampleTestCase


class TestFindNormForTestcase:
    """Tests for _find_norm_for_testcase helper."""

    def test_find_norm_success(self):
        """Test finding existing testcase norm."""
        workspace = MagicMock()
        workspace.list_norms.return_value = ["norm1", "norm2"]
        workspace.find_testcase_folder.side_effect = lambda n, i: "tc-1" if n == "norm2" else None

        result = _find_norm_for_testcase(workspace, "tc-1")

        assert result == "norm2"

    def test_find_norm_not_found(self):
        """Test testcase not found in any norm."""
        workspace = MagicMock()
        workspace.list_norms.return_value = ["norm1", "norm2"]
        workspace.find_testcase_folder.return_value = None

        result = _find_norm_for_testcase(workspace, "unknown")

        assert result is None

    def test_find_norm_empty_workspace(self):
        """Test empty workspace."""
        workspace = MagicMock()
        workspace.list_norms.return_value = []

        result = _find_norm_for_testcase(workspace, "tc-1")

        assert result is None


class TestLoadExamplesFromDir:
    """Tests for _load_examples_from_dir helper."""

    def test_load_examples_nonexistent_dir(self, tmp_path):
        """Test loading from non-existent directory."""
        examples = _load_examples_from_dir(tmp_path / "nonexistent")

        assert examples == []

    def test_load_compliant_html_examples(self, tmp_path):
        """Test loading compliant HTML examples."""
        examples_dir = tmp_path / "examples"
        compliant_dir = examples_dir / "compliant"
        compliant_dir.mkdir(parents=True)

        (compliant_dir / "test1.html").write_text('<html lang="pt">Test 1</html>')
        (compliant_dir / "test2.html").write_text('<html lang="en">Test 2</html>')

        examples = _load_examples_from_dir(examples_dir)

        assert len(examples) == 2
        assert all(ex.expected_result == "compliant" for ex in examples)
        assert "test1" in examples[0].name or "test2" in examples[0].name

    def test_load_non_compliant_html_examples(self, tmp_path):
        """Test loading non-compliant HTML examples."""
        examples_dir = tmp_path / "examples"
        non_compliant_dir = examples_dir / "non-compliant"
        non_compliant_dir.mkdir(parents=True)

        (non_compliant_dir / "bad1.html").write_text("<html>Missing lang</html>")

        examples = _load_examples_from_dir(examples_dir)

        assert len(examples) == 1
        assert examples[0].expected_result == "non-compliant"

    def test_load_mixed_examples(self, tmp_path):
        """Test loading both compliant and non-compliant examples."""
        examples_dir = tmp_path / "examples"

        compliant_dir = examples_dir / "compliant"
        compliant_dir.mkdir(parents=True)
        (compliant_dir / "good.html").write_text('<html lang="pt">Good</html>')

        non_compliant_dir = examples_dir / "non-compliant"
        non_compliant_dir.mkdir(parents=True)
        (non_compliant_dir / "bad.html").write_text("<html>Bad</html>")

        examples = _load_examples_from_dir(examples_dir)

        assert len(examples) == 2
        compliant_count = sum(1 for ex in examples if ex.expected_result == "compliant")
        non_compliant_count = sum(1 for ex in examples if ex.expected_result == "non-compliant")
        assert compliant_count == 1
        assert non_compliant_count == 1

    def test_load_jsx_examples(self, tmp_path):
        """Test loading JSX examples."""
        examples_dir = tmp_path / "examples"
        compliant_dir = examples_dir / "compliant"
        compliant_dir.mkdir(parents=True)

        (compliant_dir / "component.jsx").write_text("<div role='button'>Click</div>")

        examples = _load_examples_from_dir(examples_dir)

        assert len(examples) == 1
        assert "compliant/component.jsx" in examples[0].id

    def test_load_tsx_examples(self, tmp_path):
        """Test loading TSX examples."""
        examples_dir = tmp_path / "examples"
        compliant_dir = examples_dir / "compliant"
        compliant_dir.mkdir(parents=True)

        (compliant_dir / "component.tsx").write_text("<div role='button'>Click</div>")

        examples = _load_examples_from_dir(examples_dir)

        assert len(examples) == 1
        assert "compliant/component.tsx" in examples[0].id

    def test_load_vue_examples(self, tmp_path):
        """Test loading Vue examples."""
        examples_dir = tmp_path / "examples"
        compliant_dir = examples_dir / "compliant"
        compliant_dir.mkdir(parents=True)

        (compliant_dir / "component.vue").write_text("<template><div></div></template>")

        examples = _load_examples_from_dir(examples_dir)

        assert len(examples) == 1

    def test_load_svelte_examples(self, tmp_path):
        """Test loading Svelte examples."""
        examples_dir = tmp_path / "examples"
        compliant_dir = examples_dir / "compliant"
        compliant_dir.mkdir(parents=True)

        (compliant_dir / "component.svelte").write_text("<script>let x = 1;</script>")

        examples = _load_examples_from_dir(examples_dir)

        assert len(examples) == 1

    def test_empty_directories(self, tmp_path):
        """Test empty compliant/non-compliant directories."""
        examples_dir = tmp_path / "examples"
        (examples_dir / "compliant").mkdir(parents=True)
        (examples_dir / "non-compliant").mkdir(parents=True)

        examples = _load_examples_from_dir(examples_dir)

        assert examples == []


class TestRunAllTestcases:
    """Tests for _run_all_testcases helper."""

    @patch("wally_dev.commands.run._load_examples_from_dir")
    def test_run_all_no_norms(self, mock_load_examples):
        """Test running with no norms."""
        workspace = MagicMock()
        workspace.list_norms.return_value = []
        runner = MagicMock()

        result = _run_all_testcases(workspace, runner)

        assert result == EXIT_SUCCESS

    @patch("wally_dev.commands.run._load_examples_from_dir")
    def test_run_all_no_testcases(self, mock_load_examples):
        """Test running norm with no testcases."""
        workspace = MagicMock()
        workspace.list_norms.return_value = ["norm1"]
        workspace.get_workspace_info.return_value = {"testcases": []}
        runner = MagicMock()

        result = _run_all_testcases(workspace, runner)

        assert result == EXIT_SUCCESS

    @patch("wally_dev.commands.run._load_examples_from_dir")
    def test_run_all_code_not_found(self, mock_load_examples):
        """Test running when code directory not found."""
        workspace = MagicMock()
        workspace.list_norms.return_value = ["norm1"]
        workspace.get_workspace_info.return_value = {"testcases": ["tc1"]}
        workspace.load_testcase.return_value = MagicMock()

        testcase_dir = MagicMock()
        code_dir = MagicMock()
        code_dir.exists.return_value = False
        workspace.get_testcase_dir.return_value = testcase_dir
        workspace.get_testcase_code_dir.return_value = code_dir

        runner = MagicMock()

        result = _run_all_testcases(workspace, runner)

        assert result == EXIT_ERROR_RUNTIME

    @patch("wally_dev.commands.run._load_examples_from_dir")
    def test_run_all_no_examples(self, mock_load_examples):
        """Test running when no examples found."""
        mock_load_examples.return_value = []

        workspace = MagicMock()
        workspace.list_norms.return_value = ["norm1"]
        workspace.get_workspace_info.return_value = {"testcases": ["tc1"]}
        workspace.load_testcase.return_value = MagicMock()

        testcase_dir = MagicMock()
        testcase_dir.__truediv__ = MagicMock(return_value=testcase_dir)
        workspace.get_testcase_dir.return_value = testcase_dir

        code_dir = MagicMock()
        code_dir.exists.return_value = True
        workspace.get_testcase_code_dir.return_value = code_dir

        runner = MagicMock()

        result = _run_all_testcases(workspace, runner)

        assert result == EXIT_ERROR_RUNTIME

    @patch("wally_dev.commands.run._load_examples_from_dir")
    def test_run_all_examples_pass(self, mock_load_examples):
        """Test running when all examples pass."""
        example = ExampleTestCase(
            _id="test1",
            name="Test 1",
            description="Test",
            html="<html></html>",
            expected_result="compliant",
            explanation="Test case",
        )
        mock_load_examples.return_value = [example]

        workspace = MagicMock()
        workspace.list_norms.return_value = ["norm1"]
        workspace.get_workspace_info.return_value = {"testcases": ["tc1"]}
        workspace.load_testcase.return_value = MagicMock()

        testcase_dir = MagicMock()
        testcase_dir.__truediv__ = MagicMock(return_value=testcase_dir)
        workspace.get_testcase_dir.return_value = testcase_dir

        code_dir = MagicMock()
        code_dir.exists.return_value = True
        workspace.get_testcase_code_dir.return_value = code_dir

        # Mock runner result
        run_result = MagicMock()
        run_result.passed = True
        runner = MagicMock()
        runner.run_example.return_value = run_result

        result = _run_all_testcases(workspace, runner)

        assert result == EXIT_SUCCESS

    @patch("wally_dev.commands.run._load_examples_from_dir")
    def test_run_all_examples_fail(self, mock_load_examples):
        """Test running when some examples fail."""
        example = ExampleTestCase(
            _id="test1",
            name="Test 1",
            description="Test",
            html="<html></html>",
            expected_result="compliant",
            explanation="Test case",
        )
        mock_load_examples.return_value = [example]

        workspace = MagicMock()
        workspace.list_norms.return_value = ["norm1"]
        workspace.get_workspace_info.return_value = {"testcases": ["tc1"]}
        workspace.load_testcase.return_value = MagicMock()

        testcase_dir = MagicMock()
        testcase_dir.__truediv__ = MagicMock(return_value=testcase_dir)
        workspace.get_testcase_dir.return_value = testcase_dir

        code_dir = MagicMock()
        code_dir.exists.return_value = True
        workspace.get_testcase_code_dir.return_value = code_dir

        # Mock runner result - failure
        run_result = MagicMock()
        run_result.passed = False
        runner = MagicMock()
        runner.run_example.return_value = run_result

        result = _run_all_testcases(workspace, runner)

        assert result == EXIT_ERROR_RUNTIME

    @patch("wally_dev.commands.run._load_examples_from_dir")
    def test_run_all_exception_handling(self, mock_load_examples):
        """Test exception handling during testcase execution."""
        workspace = MagicMock()
        workspace.list_norms.return_value = ["norm1"]
        workspace.get_workspace_info.return_value = {"testcases": ["tc1"]}
        workspace.load_testcase.side_effect = Exception("Load error")

        runner = MagicMock()

        result = _run_all_testcases(workspace, runner)

        assert result == EXIT_ERROR_RUNTIME


class TestRunCommand:
    """Tests for main run command."""

    @patch("wally_dev.commands.run.TestCaseRunner")
    @patch("wally_dev.commands.run.WorkspaceManager")
    @patch("wally_dev.commands.run.LocalConfig")
    def test_run_not_logged_in(self, mock_config_cls, mock_workspace_cls, mock_runner_cls):
        """Test run command when not logged in."""
        mock_config = MagicMock()
        mock_config.is_logged_in = False
        mock_config_cls.return_value = mock_config

        runner = CliRunner()
        result = runner.invoke(run, ["--testcase", "tc1"])

        # Should raise NotLoggedInError and exit with error
        assert result.exit_code != EXIT_SUCCESS

    @patch("wally_dev.commands.run._run_all_testcases")
    @patch("wally_dev.commands.run.TestCaseRunner")
    @patch("wally_dev.commands.run.WorkspaceManager")
    @patch("wally_dev.commands.run.LocalConfig")
    def test_run_no_testcase_runs_all(
        self, mock_config_cls, mock_workspace_cls, mock_runner_cls, mock_run_all
    ):
        """Test run without testcase ID runs all testcases."""
        mock_config = MagicMock()
        mock_config.is_logged_in = True
        mock_config_cls.return_value = mock_config
        mock_run_all.return_value = EXIT_SUCCESS

        runner = CliRunner()
        result = runner.invoke(run)

        mock_run_all.assert_called_once()
        assert result.exit_code == EXIT_SUCCESS

    @patch("wally_dev.commands.run._find_norm_for_testcase")
    @patch("wally_dev.commands.run.TestCaseRunner")
    @patch("wally_dev.commands.run.WorkspaceManager")
    @patch("wally_dev.commands.run.LocalConfig")
    def test_run_testcase_not_found(
        self, mock_config_cls, mock_workspace_cls, mock_runner_cls, mock_find_norm
    ):
        """Test run with testcase not in workspace."""
        mock_config = MagicMock()
        mock_config.is_logged_in = True
        mock_config_cls.return_value = mock_config
        mock_find_norm.return_value = None

        runner = CliRunner()
        result = runner.invoke(run, ["--testcase", "unknown"], catch_exceptions=False)

        # Should raise TestCaseNotFoundError
        assert result.exit_code != EXIT_SUCCESS or "não encontrado" in result.output.lower()

    @patch("wally_dev.commands.run._find_norm_for_testcase")
    @patch("wally_dev.commands.run.TestCaseRunner")
    @patch("wally_dev.commands.run.WorkspaceManager")
    @patch("wally_dev.commands.run.LocalConfig")
    def test_run_with_norm_id(
        self, mock_config_cls, mock_workspace_cls, mock_runner_cls, mock_find_norm
    ):
        """Test run with explicit norm ID."""
        mock_config = MagicMock()
        mock_config.is_logged_in = True
        mock_config_cls.return_value = mock_config

        mock_workspace = MagicMock()
        mock_workspace.find_testcase_folder.return_value = "tc-folder"
        mock_workspace_cls.return_value = mock_workspace

        runner = CliRunner()
        _ = runner.invoke(run, ["--testcase", "tc1", "--norm-id", "norm1"])

        # Should not call _find_norm_for_testcase when norm_id provided
        mock_find_norm.assert_not_called()

    @patch("wally_dev.commands.run.TestCaseRunner")
    @patch("wally_dev.commands.run.WorkspaceManager")
    @patch("wally_dev.commands.run.LocalConfig")
    def test_run_verbose_flag(self, mock_config_cls, mock_workspace_cls, mock_runner_cls):
        """Test run with verbose flag."""
        mock_config = MagicMock()
        mock_config.is_logged_in = True
        mock_config_cls.return_value = mock_config

        runner = CliRunner()
        _ = runner.invoke(run, ["--verbose"])

        mock_runner_cls.assert_called_with(verbose=True)

    @patch("wally_dev.commands.run.TestCaseRunner")
    @patch("wally_dev.commands.run.WorkspaceManager")
    @patch("wally_dev.commands.run.LocalConfig")
    def test_run_debug_flag(self, mock_config_cls, mock_workspace_cls, mock_runner_cls):
        """Test run with debug flag."""
        mock_config = MagicMock()
        mock_config.is_logged_in = True
        mock_config_cls.return_value = mock_config

        runner = CliRunner()
        result = runner.invoke(run, ["--debug"])

        # Debug flag should be processed
        assert result.exit_code == EXIT_SUCCESS or result.exception is not None

    @patch("wally_dev.commands.run._run_all_testcases")
    @patch("wally_dev.commands.run.TestCaseRunner")
    @patch("wally_dev.commands.run.WorkspaceManager")
    @patch("wally_dev.commands.run.LocalConfig")
    def test_run_all_flag(self, mock_config_cls, mock_workspace_cls, mock_runner_cls, mock_run_all):
        """Test run with --all flag."""
        mock_config = MagicMock()
        mock_config.is_logged_in = True
        mock_config_cls.return_value = mock_config
        mock_run_all.return_value = EXIT_SUCCESS

        runner = CliRunner()
        _ = runner.invoke(run, ["--all"])

        mock_run_all.assert_called_once()


class TestRunCommandExamplePath:
    """Tests for run command with --example option."""

    @patch("wally_dev.commands.run._find_norm_for_testcase")
    @patch("wally_dev.commands.run.TestCaseRunner")
    @patch("wally_dev.commands.run.WorkspaceManager")
    @patch("wally_dev.commands.run.LocalConfig")
    def test_run_with_example_path_no_testcase(
        self, mock_config_cls, mock_workspace_cls, mock_runner_cls, mock_find_norm
    ):
        """Test run with example path but no testcase ID."""
        mock_config = MagicMock()
        mock_config.is_logged_in = True
        mock_config_cls.return_value = mock_config

        runner = CliRunner()
        result = runner.invoke(run, ["--example", "compliant/test.html"])

        # Should require testcase_id when example_path provided
        assert "caso de teste" in result.output.lower() or result.exit_code != EXIT_SUCCESS

    @patch("wally_dev.commands.run._find_norm_for_testcase")
    @patch("wally_dev.commands.run.TestCaseRunner")
    @patch("wally_dev.commands.run.WorkspaceManager")
    @patch("wally_dev.commands.run.LocalConfig")
    def test_run_with_example_path(
        self, mock_config_cls, mock_workspace_cls, mock_runner_cls, mock_find_norm
    ):
        """Test run with specific example path."""
        mock_config = MagicMock()
        mock_config.is_logged_in = True
        mock_config_cls.return_value = mock_config

        mock_workspace = MagicMock()
        mock_workspace.find_testcase_folder.return_value = "tc-folder"
        mock_workspace_cls.return_value = mock_workspace

        mock_find_norm.return_value = "norm1"

        runner = CliRunner()
        result = runner.invoke(run, ["--testcase", "tc1", "--example", "compliant/test.html"])

        # Should process example path
        assert result.exception is None or isinstance(
            result.exception, (FileNotFoundError, KeyError)
        )


class TestRunCommandShowCode:
    """Tests for run command with --show-code option."""

    @patch("wally_dev.commands.run._find_norm_for_testcase")
    @patch("wally_dev.commands.run.TestCaseRunner")
    @patch("wally_dev.commands.run.WorkspaceManager")
    @patch("wally_dev.commands.run.LocalConfig")
    def test_run_with_show_code(
        self, mock_config_cls, mock_workspace_cls, mock_runner_cls, mock_find_norm
    ):
        """Test run with --show-code flag."""
        mock_config = MagicMock()
        mock_config.is_logged_in = True
        mock_config_cls.return_value = mock_config

        mock_workspace = MagicMock()
        mock_workspace.find_testcase_folder.return_value = "tc-folder"
        mock_workspace_cls.return_value = mock_workspace

        mock_find_norm.return_value = "norm1"

        runner = CliRunner()
        result = runner.invoke(run, ["--testcase", "tc1", "--show-code"])

        # Should process show_code flag
        assert result.exception is None or isinstance(result.exception, Exception)


class TestExampleTestCaseModel:
    """Tests for ExampleTestCase data model."""

    def test_example_testcase_creation(self):
        """Test creating ExampleTestCase instance."""
        example = ExampleTestCase(
            id="ex1",
            name="Example 1",
            description="Description",
            html="<html></html>",
            expected_result="compliant",
            explanation="Explanation",
        )

        assert example.id == "ex1"
        assert example.name == "Example 1"
        assert example.expected_result == "compliant"

    def test_example_testcase_optional_description(self):
        """Test ExampleTestCase with None description."""
        example = ExampleTestCase(
            id="ex1",
            name="Example 1",
            description=None,
            html="<html></html>",
            expected_result="non-compliant",
            explanation="Explanation",
        )

        assert example.description is None


class TestShowResult:
    """Tests for _show_result helper function."""

    def test_show_result_passed(self, capsys):
        """Test showing passed result."""
        from wally_dev.commands.run import _show_result
        from wally_dev.models import TestCaseRunResult

        result = TestCaseRunResult(
            test_case_id="tc1",
            example_id="ex1",
            passed=True,
            expected="compliant",
            actual="compliant",
            execution_time_ms=10.5,
        )

        _show_result(result)
        # Rich console output - verify no exceptions

    def test_show_result_failed(self, capsys):
        """Test showing failed result."""
        from wally_dev.commands.run import _show_result
        from wally_dev.models import TestCaseRunResult

        result = TestCaseRunResult(
            test_case_id="tc1",
            example_id="ex1",
            passed=False,
            expected="compliant",
            actual="non-compliant",
            execution_time_ms=15.2,
        )

        _show_result(result)
        # Rich console output - verify no exceptions

    def test_show_result_failed_with_error(self, capsys):
        """Test showing failed result with error message."""
        from wally_dev.commands.run import _show_result
        from wally_dev.models import TestCaseRunResult

        result = TestCaseRunResult(
            test_case_id="tc1",
            example_id="ex1",
            passed=False,
            expected="compliant",
            actual="error",
            execution_time_ms=5.0,
            error_message="ValidationError: Invalid HTML",
        )

        _show_result(result)
        # Should handle error message gracefully


class TestShowDebugOutput:
    """Tests for _show_debug_output helper function."""

    def test_show_debug_output_success(self, capsys):
        """Test showing debug output for successful execution."""
        from wally_dev.commands.run import _show_debug_output

        debug_info = {
            "execution": {
                "success": True,
                "elements_found": 3,
                "finder_time_ms": 5.2,
                "total_time_ms": 10.8,
                "validation_results": [
                    {
                        "index": 0,
                        "element": {"tag": "img", "line": 10, "snippet": "<img src='test.jpg'>"},
                        "passed": True,
                    },
                    {
                        "index": 1,
                        "element": {"tag": "img", "line": 15, "snippet": "<img src='bad.jpg'>"},
                        "passed": False,
                    },
                ],
            }
        }

        _show_debug_output(debug_info)
        # Should not raise exception

    def test_show_debug_output_with_errors(self, capsys):
        """Test showing debug output with validation errors."""
        from wally_dev.commands.run import _show_debug_output

        debug_info = {
            "execution": {
                "success": True,
                "elements_found": 1,
                "finder_time_ms": 2.0,
                "total_time_ms": 5.0,
                "validation_results": [
                    {
                        "index": 0,
                        "element": {"tag": "div", "line": 5, "snippet": "<div>"},
                        "passed": False,
                        "error": "TypeError: 'NoneType' object is not subscriptable",
                    },
                ],
            }
        }

        _show_debug_output(debug_info)
        # Should handle errors gracefully

    def test_show_debug_output_execution_failed(self, capsys):
        """Test showing debug output when execution failed."""
        from wally_dev.commands.run import _show_debug_output

        debug_info = {
            "execution": {
                "success": False,
                "error_type": "SyntaxError",
                "error": "invalid syntax (finder.py, line 5)",
            },
            "traceback": "Traceback (most recent call last):\n  File 'finder.py', line 5\n    def find(\nSyntaxError: invalid syntax",
        }

        _show_debug_output(debug_info)
        # Should handle failure gracefully

    def test_show_debug_output_no_elements(self, capsys):
        """Test showing debug output with no elements found."""
        from wally_dev.commands.run import _show_debug_output

        debug_info = {
            "execution": {
                "success": True,
                "elements_found": 0,
                "finder_time_ms": 1.0,
                "total_time_ms": 1.5,
                "validation_results": [],
            }
        }

        _show_debug_output(debug_info)
        # Should handle no elements case


class TestRunCommandWithTestcase:
    """Tests for run command with specific testcase."""

    @patch("wally_dev.commands.run._load_examples_from_dir")
    @patch("wally_dev.commands.run._find_norm_for_testcase")
    @patch("wally_dev.commands.run.TestCaseRunner")
    @patch("wally_dev.commands.run.WorkspaceManager")
    @patch("wally_dev.commands.run.LocalConfig")
    def test_run_testcase_code_not_found(
        self,
        mock_config_cls,
        mock_workspace_cls,
        mock_runner_cls,
        mock_find_norm,
        mock_load_examples,
    ):
        """Test run when code directory doesn't exist."""
        mock_config = MagicMock()
        mock_config.is_logged_in = True
        mock_config_cls.return_value = mock_config

        mock_workspace = MagicMock()
        mock_workspace.find_testcase_folder.return_value = "tc-folder"
        mock_workspace.load_testcase.return_value = MagicMock(id="tc1", name="Test")

        # Code directory doesn't exist
        code_dir = MagicMock()
        code_dir.exists.return_value = False
        mock_workspace.get_testcase_code_dir.return_value = code_dir
        mock_workspace_cls.return_value = mock_workspace

        mock_find_norm.return_value = "norm1"

        runner = CliRunner()
        result = runner.invoke(run, ["--testcase", "tc1"])

        assert (
            "código" in result.output.lower()
            or "code" in result.output.lower()
            or result.exit_code != EXIT_SUCCESS
        )

    @patch("wally_dev.commands.run._load_examples_from_dir")
    @patch("wally_dev.commands.run._find_norm_for_testcase")
    @patch("wally_dev.commands.run.TestCaseRunner")
    @patch("wally_dev.commands.run.WorkspaceManager")
    @patch("wally_dev.commands.run.LocalConfig")
    def test_run_with_show_code_displays_finder(
        self,
        mock_config_cls,
        mock_workspace_cls,
        mock_runner_cls,
        mock_find_norm,
        mock_load_examples,
        tmp_path,
    ):
        """Test run with --show-code displays finder and validator code."""
        mock_config = MagicMock()
        mock_config.is_logged_in = True
        mock_config_cls.return_value = mock_config

        # Create actual code files
        code_dir = tmp_path / "code"
        code_dir.mkdir()
        (code_dir / "finder.py").write_text("def find(html): return []")
        (code_dir / "validator.py").write_text("def validate(el): return True")

        examples_dir = tmp_path / "examples"
        examples_dir.mkdir()

        mock_workspace = MagicMock()
        mock_workspace.find_testcase_folder.return_value = "tc-folder"
        mock_workspace.load_testcase.return_value = MagicMock(id="tc1", name="Test")
        mock_workspace.get_testcase_code_dir.return_value = code_dir
        mock_workspace.get_testcase_dir.return_value = tmp_path
        mock_workspace_cls.return_value = mock_workspace

        mock_find_norm.return_value = "norm1"
        mock_load_examples.return_value = []

        runner = CliRunner()
        result = runner.invoke(run, ["--testcase", "tc1", "--show-code"])

        # Should show code
        assert (
            "finder.py" in result.output
            or "def find" in result.output
            or result.exit_code == EXIT_SUCCESS
        )


class TestRunCommandWithExample:
    """Tests for run command with specific example."""

    @patch("wally_dev.commands.run._find_norm_for_testcase")
    @patch("wally_dev.commands.run.TestCaseRunner")
    @patch("wally_dev.commands.run.WorkspaceManager")
    @patch("wally_dev.commands.run.LocalConfig")
    def test_run_example_not_found(
        self,
        mock_config_cls,
        mock_workspace_cls,
        mock_runner_cls,
        mock_find_norm,
        tmp_path,
    ):
        """Test run with non-existent example path."""
        mock_config = MagicMock()
        mock_config.is_logged_in = True
        mock_config_cls.return_value = mock_config

        code_dir = tmp_path / "code"
        code_dir.mkdir()
        (code_dir / "finder.py").write_text("def find(html): return []")

        mock_workspace = MagicMock()
        mock_workspace.find_testcase_folder.return_value = "tc-folder"
        mock_workspace.load_testcase.return_value = MagicMock(id="tc1", name="Test")
        mock_workspace.get_testcase_code_dir.return_value = code_dir
        mock_workspace.get_testcase_dir.return_value = tmp_path
        mock_workspace_cls.return_value = mock_workspace

        mock_find_norm.return_value = "norm1"

        runner = CliRunner()
        result = runner.invoke(
            run, ["--testcase", "tc1", "--example", "compliant/nonexistent.html"]
        )

        assert "não encontrado" in result.output.lower() or result.exit_code != EXIT_SUCCESS

    @patch("wally_dev.commands.run._find_norm_for_testcase")
    @patch("wally_dev.commands.run.TestCaseRunner")
    @patch("wally_dev.commands.run.WorkspaceManager")
    @patch("wally_dev.commands.run.LocalConfig")
    def test_run_example_success(
        self,
        mock_config_cls,
        mock_workspace_cls,
        mock_runner_cls,
        mock_find_norm,
        tmp_path,
    ):
        """Test run with valid example path."""
        from wally_dev.models import TestCaseRunResult

        mock_config = MagicMock()
        mock_config.is_logged_in = True
        mock_config_cls.return_value = mock_config

        # Create code dir
        code_dir = tmp_path / "code"
        code_dir.mkdir()
        (code_dir / "finder.py").write_text("def find(html): return []")

        # Create example
        examples_dir = tmp_path / "examples"
        (examples_dir / "compliant").mkdir(parents=True)
        (examples_dir / "compliant" / "test.html").write_text("<html lang='pt'>Test</html>")

        mock_workspace = MagicMock()
        mock_workspace.find_testcase_folder.return_value = "tc-folder"
        mock_workspace.load_testcase.return_value = MagicMock(id="tc1", name="Test")
        mock_workspace.get_testcase_code_dir.return_value = code_dir
        mock_workspace.get_testcase_dir.return_value = tmp_path
        mock_workspace_cls.return_value = mock_workspace

        mock_find_norm.return_value = "norm1"

        # Mock runner
        mock_runner = MagicMock()
        mock_runner.run_example.return_value = TestCaseRunResult(
            test_case_id="tc1",
            example_id="test",
            passed=True,
            expected="compliant",
            actual="compliant",
            execution_time_ms=5.0,
        )
        mock_runner_cls.return_value = mock_runner

        runner = CliRunner()
        result = runner.invoke(run, ["--testcase", "tc1", "--example", "compliant/test.html"])

        assert result.exit_code == EXIT_SUCCESS or "PASSOU" in result.output.upper()


class TestRunCommandDebugMode:
    """Tests for run command debug mode."""

    @patch("wally_dev.commands.run._load_examples_from_dir")
    @patch("wally_dev.commands.run._find_norm_for_testcase")
    @patch("wally_dev.commands.run.TestCaseRunner")
    @patch("wally_dev.commands.run.WorkspaceManager")
    @patch("wally_dev.commands.run.LocalConfig")
    def test_run_debug_mode_single_example(
        self,
        mock_config_cls,
        mock_workspace_cls,
        mock_runner_cls,
        mock_find_norm,
        mock_load_examples,
        tmp_path,
    ):
        """Test run with --debug for single example."""
        mock_config = MagicMock()
        mock_config.is_logged_in = True
        mock_config_cls.return_value = mock_config

        code_dir = tmp_path / "code"
        code_dir.mkdir()
        (code_dir / "finder.py").write_text("def find(html): return []")

        examples_dir = tmp_path / "examples"
        (examples_dir / "compliant").mkdir(parents=True)
        (examples_dir / "compliant" / "test.html").write_text("<html>Test</html>")

        mock_workspace = MagicMock()
        mock_workspace.find_testcase_folder.return_value = "tc-folder"
        mock_workspace.load_testcase.return_value = MagicMock(id="tc1", name="Test")
        mock_workspace.get_testcase_code_dir.return_value = code_dir
        mock_workspace.get_testcase_dir.return_value = tmp_path
        mock_workspace_cls.return_value = mock_workspace

        mock_find_norm.return_value = "norm1"

        # Mock runner debug output
        mock_runner = MagicMock()
        mock_runner.debug_testcase.return_value = {
            "execution": {
                "success": True,
                "elements_found": 1,
                "finder_time_ms": 2.0,
                "total_time_ms": 4.0,
                "validation_results": [
                    {
                        "index": 0,
                        "element": {"tag": "html", "line": 1, "snippet": "<html>"},
                        "passed": True,
                    }
                ],
            }
        }
        mock_runner_cls.return_value = mock_runner

        runner = CliRunner()
        result = runner.invoke(
            run, ["--testcase", "tc1", "--example", "compliant/test.html", "--debug"]
        )

        # Should show debug output
        assert (
            result.exit_code == EXIT_SUCCESS
            or "debug" in result.output.lower()
            or "elementos" in result.output.lower()
        )

    @patch("wally_dev.commands.run._load_examples_from_dir")
    @patch("wally_dev.commands.run._find_norm_for_testcase")
    @patch("wally_dev.commands.run.TestCaseRunner")
    @patch("wally_dev.commands.run.WorkspaceManager")
    @patch("wally_dev.commands.run.LocalConfig")
    def test_run_debug_mode_all_examples(
        self,
        mock_config_cls,
        mock_workspace_cls,
        mock_runner_cls,
        mock_find_norm,
        mock_load_examples,
        tmp_path,
    ):
        """Test run with --debug for all examples."""
        mock_config = MagicMock()
        mock_config.is_logged_in = True
        mock_config_cls.return_value = mock_config

        code_dir = tmp_path / "code"
        code_dir.mkdir()
        (code_dir / "finder.py").write_text("def find(html): return []")

        mock_workspace = MagicMock()
        mock_workspace.find_testcase_folder.return_value = "tc-folder"
        mock_workspace.load_testcase.return_value = MagicMock(id="tc1", name="Test")
        mock_workspace.get_testcase_code_dir.return_value = code_dir
        mock_workspace.get_testcase_dir.return_value = tmp_path
        mock_workspace_cls.return_value = mock_workspace

        mock_find_norm.return_value = "norm1"

        # Mock examples
        example = ExampleTestCase(
            _id="ex1",
            name="Example 1",
            html="<html></html>",
            expectedResult="compliant",
            explanation="Test",
        )
        mock_load_examples.return_value = [example]

        # Mock runner debug output
        mock_runner = MagicMock()
        mock_runner.debug_testcase.return_value = {
            "execution": {
                "success": True,
                "elements_found": 0,
                "finder_time_ms": 1.0,
                "total_time_ms": 2.0,
                "validation_results": [],
            }
        }
        mock_runner_cls.return_value = mock_runner

        runner = CliRunner()
        result = runner.invoke(run, ["--testcase", "tc1", "--debug"])

        # Should process in debug mode
        assert result.exit_code == EXIT_SUCCESS
