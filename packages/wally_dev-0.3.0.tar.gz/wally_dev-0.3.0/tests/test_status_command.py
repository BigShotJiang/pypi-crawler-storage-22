"""
Comprehensive tests for status command.
"""

from datetime import datetime
from unittest.mock import MagicMock, patch

import pytest
from click.testing import CliRunner

from wally_dev.cli import cli
from wally_dev.commands.status import status


class TestStatusCommand:
    """Tests for status command."""

    @pytest.fixture
    def runner(self):
        return CliRunner()

    def test_status_help(self, runner: CliRunner):
        """Test status help."""
        result = runner.invoke(cli, ["status", "--help"])
        assert result.exit_code == 0
        assert "--verbose" in result.output

    @patch("wally_dev.commands.status.WorkspaceManager")
    @patch("wally_dev.commands.status.LocalConfig")
    def test_status_not_logged_in(self, mock_config_class, mock_workspace_class, runner: CliRunner):
        """Test status when not logged in."""
        mock_config = MagicMock()
        mock_config.is_logged_in = False
        mock_config_class.return_value = mock_config

        mock_workspace = MagicMock()
        mock_workspace.list_norms.return_value = []
        mock_workspace_class.return_value = mock_workspace

        result = runner.invoke(status)
        assert result.exit_code == 0
        assert "não logado" in result.output.lower() or "login" in result.output.lower()

    @patch("wally_dev.commands.status.WorkspaceManager")
    @patch("wally_dev.commands.status.LocalConfig")
    def test_status_logged_in_no_checkouts(
        self, mock_config_class, mock_workspace_class, runner: CliRunner
    ):
        """Test status when logged in but no checkouts."""
        mock_config = MagicMock()
        mock_config.is_logged_in = True
        mock_config.get_locked_norms.return_value = {}
        mock_config_class.return_value = mock_config

        mock_workspace = MagicMock()
        mock_workspace.list_norms.return_value = []
        mock_workspace_class.return_value = mock_workspace

        result = runner.invoke(status)
        assert result.exit_code == 0
        assert "nenhuma norma" in result.output.lower() or "checkout" in result.output.lower()

    @patch("wally_dev.commands.status.WorkspaceManager")
    @patch("wally_dev.commands.status.LocalConfig")
    def test_status_with_locked_norms(
        self, mock_config_class, mock_workspace_class, runner: CliRunner
    ):
        """Test status with locked norms."""
        mock_config = MagicMock()
        mock_config.is_logged_in = True
        mock_config.get_locked_norms.return_value = {
            "norm123": {
                "norm_name": "WCAG 2.1",
                "checkout_at": "2024-01-15T10:30:00",
                "testcase_count": 25,
            }
        }
        mock_config_class.return_value = mock_config

        mock_workspace = MagicMock()
        mock_workspace.list_norms.return_value = ["norm123"]
        mock_workspace.get_workspace_info.return_value = {
            "testcase_count": 25,
            "modified": 3,
        }
        mock_workspace_class.return_value = mock_workspace

        result = runner.invoke(status)
        assert result.exit_code == 0
        assert "norm123" in result.output.lower() or "checkout" in result.output.lower()

    @patch("wally_dev.commands.status.WorkspaceManager")
    @patch("wally_dev.commands.status.LocalConfig")
    def test_status_with_verbose(self, mock_config_class, mock_workspace_class, runner: CliRunner):
        """Test status with verbose flag."""
        mock_config = MagicMock()
        mock_config.is_logged_in = True
        mock_config.get_locked_norms.return_value = {
            "norm123": {
                "norm_name": "WCAG 2.1",
                "checkout_at": datetime.now().isoformat(),
                "testcase_count": 25,
            }
        }
        mock_config_class.return_value = mock_config

        mock_workspace = MagicMock()
        mock_workspace.list_norms.return_value = ["norm123"]
        mock_workspace.get_workspace_info.return_value = {
            "testcase_count": 25,
            "modified": 3,
            "path": "/tmp/wally-dev/norms/norm123",
        }
        mock_workspace_class.return_value = mock_workspace

        result = runner.invoke(status, ["--verbose"])
        assert result.exit_code == 0
        # Verbose should show more details

    @patch("wally_dev.commands.status.WorkspaceManager")
    @patch("wally_dev.commands.status.LocalConfig")
    def test_status_multiple_locked_norms(
        self, mock_config_class, mock_workspace_class, runner: CliRunner
    ):
        """Test status with multiple locked norms."""
        mock_config = MagicMock()
        mock_config.is_logged_in = True
        mock_config.get_locked_norms.return_value = {
            "norm1": {
                "norm_name": "WCAG 2.1",
                "checkout_at": "2024-01-15T10:30:00",
                "testcase_count": 25,
            },
            "norm2": {
                "norm_name": "NBR 17225",
                "checkout_at": "2024-01-16T14:00:00",
                "testcase_count": 10,
            },
        }
        mock_config_class.return_value = mock_config

        mock_workspace = MagicMock()
        mock_workspace.list_norms.return_value = ["norm1", "norm2"]
        mock_workspace.get_workspace_info.return_value = {
            "testcase_count": 25,
        }
        mock_workspace_class.return_value = mock_workspace

        result = runner.invoke(status)
        assert result.exit_code == 0
        assert "checkout" in result.output.lower() or "norma" in result.output.lower()

    @patch("wally_dev.commands.status.WorkspaceManager")
    @patch("wally_dev.commands.status.LocalConfig")
    def test_status_workspace_norm_not_in_config(
        self, mock_config_class, mock_workspace_class, runner: CliRunner
    ):
        """Test status when workspace has norm not in config (sync issue)."""
        mock_config = MagicMock()
        mock_config.is_logged_in = True
        mock_config.get_locked_norms.return_value = {}
        mock_config_class.return_value = mock_config

        mock_workspace = MagicMock()
        mock_workspace.list_norms.return_value = ["orphan_norm"]
        mock_workspace.get_workspace_info.return_value = {
            "testcase_count": 5,
        }
        mock_workspace_class.return_value = mock_workspace

        result = runner.invoke(status)
        assert result.exit_code == 0

    @patch("wally_dev.commands.status.WorkspaceManager")
    @patch("wally_dev.commands.status.LocalConfig")
    def test_status_config_norm_not_in_workspace(
        self, mock_config_class, mock_workspace_class, runner: CliRunner
    ):
        """Test status when config has norm not in workspace (sync issue)."""
        mock_config = MagicMock()
        mock_config.is_logged_in = True
        mock_config.get_locked_norms.return_value = {
            "missing_norm": {
                "norm_name": "Missing Norm",
                "checkout_at": "2024-01-15T10:30:00",
            }
        }
        mock_config_class.return_value = mock_config

        mock_workspace = MagicMock()
        mock_workspace.list_norms.return_value = []
        mock_workspace.get_workspace_info.return_value = {}
        mock_workspace_class.return_value = mock_workspace

        result = runner.invoke(status)
        assert result.exit_code == 0

    @patch("wally_dev.commands.status.WorkspaceManager")
    @patch("wally_dev.commands.status.LocalConfig")
    def test_status_invalid_datetime_handled(
        self, mock_config_class, mock_workspace_class, runner: CliRunner
    ):
        """Test status handles invalid datetime format gracefully."""
        mock_config = MagicMock()
        mock_config.is_logged_in = True
        mock_config.get_locked_norms.return_value = {
            "norm123": {
                "norm_name": "Test Norm",
                "checkout_at": "invalid-date-format",
                "testcase_count": 5,
            }
        }
        mock_config_class.return_value = mock_config

        mock_workspace = MagicMock()
        mock_workspace.list_norms.return_value = ["norm123"]
        mock_workspace.get_workspace_info.return_value = {}
        mock_workspace_class.return_value = mock_workspace

        result = runner.invoke(status)
        # Should handle gracefully without crashing
        assert result.exit_code == 0
