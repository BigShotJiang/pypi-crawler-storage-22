"""
Tests for wally_dev testcases command.

Comprehensive test coverage for testcase management functionality.
"""

from unittest.mock import MagicMock, patch

import pytest
from click.testing import CliRunner

from wally_dev.cli import cli
from wally_dev.commands.testcases import create_testcase, list_testcases, testcases
from wally_dev.constants import EXIT_ERROR_API, EXIT_SUCCESS


class TestTestcasesGroup:
    """Tests for testcases command group."""

    @pytest.fixture
    def runner(self):
        return CliRunner()

    def test_testcases_help(self, runner: CliRunner):
        """Test testcases help."""
        result = runner.invoke(testcases, ["--help"])
        assert result.exit_code == 0
        assert "testcase" in result.output.lower()


class TestCreateTestcase:
    """Tests for testcases create command."""

    @pytest.fixture
    def runner(self):
        return CliRunner()

    def test_create_help(self, runner: CliRunner):
        """Test testcases create help."""
        result = runner.invoke(cli, ["testcases", "create", "--help"])
        assert result.exit_code == 0
        assert "--target" in result.output
        assert "--rule-id" in result.output
        assert "--all" in result.output

    @patch("wally_dev.commands.testcases.Settings")
    @patch("wally_dev.commands.testcases.LocalConfig")
    def test_create_not_logged_in(self, mock_config_cls, mock_settings_cls, runner: CliRunner):
        """Test create testcase when not logged in."""
        mock_config = MagicMock()
        mock_config.is_logged_in = False
        mock_config_cls.return_value = mock_config

        result = runner.invoke(create_testcase, ["--target", "html", "--all"])

        assert result.exit_code != EXIT_SUCCESS

    @patch("wally_dev.commands.testcases.Settings")
    @patch("wally_dev.commands.testcases.LocalConfig")
    def test_create_missing_parameters(self, mock_config_cls, mock_settings_cls, runner: CliRunner):
        """Test create testcase without --all or --rule-id."""
        mock_config = MagicMock()
        mock_config.is_logged_in = True
        mock_config_cls.return_value = mock_config

        result = runner.invoke(create_testcase, ["--target", "html"])

        # Should show error about missing parameters
        assert (
            "--all" in result.output
            or "--rule-id" in result.output
            or "parâmetro" in result.output.lower()
        )

    @patch("wally_dev.commands.testcases.Settings")
    @patch("wally_dev.commands.testcases.LocalConfig")
    def test_create_conflicting_parameters(
        self, mock_config_cls, mock_settings_cls, runner: CliRunner
    ):
        """Test create testcase with both --all and --rule-id."""
        mock_config = MagicMock()
        mock_config.is_logged_in = True
        mock_config_cls.return_value = mock_config

        result = runner.invoke(
            create_testcase, ["--target", "html", "--all", "--rule-id", "rule123"]
        )

        # Should show error about conflicting parameters
        assert (
            "conflitantes" in result.output.lower()
            or "ambos" in result.output.lower()
            or "--all" in result.output
        )

    @patch("wally_dev.commands.testcases.Settings")
    @patch("wally_dev.commands.testcases.LocalConfig")
    def test_create_no_norm_in_checkout(
        self, mock_config_cls, mock_settings_cls, runner: CliRunner
    ):
        """Test create testcase without norm in checkout."""
        mock_config = MagicMock()
        mock_config.is_logged_in = True
        mock_config.get_locked_norms.return_value = {}
        mock_config_cls.return_value = mock_config

        result = runner.invoke(create_testcase, ["--target", "html", "--all"])

        assert "checkout" in result.output.lower()


class TestCreateTestcaseTargets:
    """Tests for testcases create with different targets."""

    @pytest.fixture
    def runner(self):
        return CliRunner()

    def test_create_invalid_target(self, runner: CliRunner):
        """Test create testcase with invalid target."""
        result = runner.invoke(cli, ["testcases", "create", "--target", "invalid", "--all"])

        # Click should reject invalid choice
        assert result.exit_code != 0

    def test_create_valid_targets(self, runner: CliRunner):
        """Test that all valid targets are accepted."""
        valid_targets = ["html", "react", "angular", "vue"]

        for target in valid_targets:
            result = runner.invoke(cli, ["testcases", "create", "--target", target, "--help"])
            assert result.exit_code == 0


class TestCreateTestcaseDryRun:
    """Tests for testcases create --dry-run option."""

    @pytest.fixture
    def runner(self):
        return CliRunner()

    @patch("wally_dev.commands.testcases.Settings")
    @patch("wally_dev.commands.testcases.LocalConfig")
    def test_create_dry_run(self, mock_config_cls, mock_settings_cls, runner: CliRunner):
        """Test create testcase with dry-run flag."""
        mock_config = MagicMock()
        mock_config.is_logged_in = True
        mock_config.get_locked_norms.return_value = {
            "norm1": {"norm_name": "WCAG 2.1", "checkout_at": "2025-01-01"}
        }
        mock_config_cls.return_value = mock_config

        # Note: This test may need more mocking depending on implementation
        result = runner.invoke(create_testcase, ["--target", "html", "--all", "--dry-run"])

        # Dry run should show what would be created
        assert result.exit_code in (EXIT_SUCCESS, EXIT_ERROR_API)


class TestListTestcases:
    """Tests for testcases list command."""

    @pytest.fixture
    def runner(self):
        return CliRunner()

    def test_list_help(self, runner: CliRunner):
        """Test testcases list help."""
        result = runner.invoke(cli, ["testcases", "list", "--help"])
        assert result.exit_code == 0

    @patch("wally_dev.commands.testcases.WorkspaceManager")
    @patch("wally_dev.commands.testcases.Settings")
    @patch("wally_dev.commands.testcases.LocalConfig")
    def test_list_not_logged_in(
        self, mock_config_cls, mock_settings_cls, mock_workspace_cls, runner: CliRunner
    ):
        """Test list testcases when not logged in."""
        mock_config = MagicMock()
        mock_config.is_logged_in = False
        mock_config_cls.return_value = mock_config

        result = runner.invoke(list_testcases)

        assert result.exit_code != EXIT_SUCCESS

    @patch("wally_dev.commands.testcases.WorkspaceManager")
    @patch("wally_dev.commands.testcases.Settings")
    @patch("wally_dev.commands.testcases.LocalConfig")
    def test_list_no_norm_in_checkout(
        self, mock_config_cls, mock_settings_cls, mock_workspace_cls, runner: CliRunner
    ):
        """Test list testcases with no norm in checkout."""
        mock_config = MagicMock()
        mock_config.is_logged_in = True
        mock_config.get_locked_norms.return_value = {}
        mock_config_cls.return_value = mock_config

        result = runner.invoke(list_testcases)

        assert "checkout" in result.output.lower() or result.exit_code == EXIT_SUCCESS

    @patch("wally_dev.commands.testcases.WorkspaceManager")
    @patch("wally_dev.commands.testcases.Settings")
    @patch("wally_dev.commands.testcases.LocalConfig")
    def test_list_with_testcases(
        self, mock_config_cls, mock_settings_cls, mock_workspace_cls, runner: CliRunner
    ):
        """Test list testcases with available testcases."""
        mock_config = MagicMock()
        mock_config.is_logged_in = True
        mock_config.get_locked_norms.return_value = {
            "norm1": {"norm_name": "WCAG 2.1", "checkout_at": "2025-01-01"}
        }
        mock_config_cls.return_value = mock_config

        mock_workspace = MagicMock()
        mock_workspace.list_norms.return_value = ["norm1"]
        mock_workspace.get_workspace_info.return_value = {
            "testcases": ["tc1", "tc2"],
            "testcase_count": 2,
        }
        mock_workspace_cls.return_value = mock_workspace

        result = runner.invoke(list_testcases)

        # Should display testcases info
        assert result.exit_code in (EXIT_SUCCESS, EXIT_ERROR_API)


class TestCreateTestcaseForce:
    """Tests for testcases create --force option."""

    @pytest.fixture
    def runner(self):
        return CliRunner()

    @patch("wally_dev.commands.testcases.Settings")
    @patch("wally_dev.commands.testcases.LocalConfig")
    def test_create_with_force(self, mock_config_cls, mock_settings_cls, runner: CliRunner):
        """Test create testcase with force flag."""
        mock_config = MagicMock()
        mock_config.is_logged_in = True
        mock_config.get_locked_norms.return_value = {
            "norm1": {"norm_name": "WCAG 2.1", "checkout_at": "2025-01-01"}
        }
        mock_config_cls.return_value = mock_config

        result = runner.invoke(
            create_testcase, ["--target", "html", "--rule-id", "rule1", "--force"]
        )

        # Force should be passed through
        assert result.exit_code in (EXIT_SUCCESS, EXIT_ERROR_API)


class TestCreateTestcaseContinueOnError:
    """Tests for testcases create --continue-on-error option."""

    @pytest.fixture
    def runner(self):
        return CliRunner()

    @patch("wally_dev.commands.testcases.Settings")
    @patch("wally_dev.commands.testcases.LocalConfig")
    def test_create_with_continue_on_error(
        self, mock_config_cls, mock_settings_cls, runner: CliRunner
    ):
        """Test create testcase with continue-on-error flag."""
        mock_config = MagicMock()
        mock_config.is_logged_in = True
        mock_config.get_locked_norms.return_value = {
            "norm1": {"norm_name": "WCAG 2.1", "checkout_at": "2025-01-01"}
        }
        mock_config_cls.return_value = mock_config

        result = runner.invoke(
            create_testcase,
            ["--target", "html", "--all", "--continue-on-error"],
        )

        # Should handle continue-on-error flag
        assert result.exit_code in (EXIT_SUCCESS, EXIT_ERROR_API)


class TestCreateTestcaseDelay:
    """Tests for testcases create --delay option."""

    @pytest.fixture
    def runner(self):
        return CliRunner()

    @patch("wally_dev.commands.testcases.Settings")
    @patch("wally_dev.commands.testcases.LocalConfig")
    def test_create_with_custom_delay(self, mock_config_cls, mock_settings_cls, runner: CliRunner):
        """Test create testcase with custom delay."""
        mock_config = MagicMock()
        mock_config.is_logged_in = True
        mock_config.get_locked_norms.return_value = {
            "norm1": {"norm_name": "WCAG 2.1", "checkout_at": "2025-01-01"}
        }
        mock_config_cls.return_value = mock_config

        result = runner.invoke(create_testcase, ["--target", "html", "--all", "--delay", "5.0"])

        # Should accept custom delay
        assert result.exit_code in (EXIT_SUCCESS, EXIT_ERROR_API)


class TestTestcasesIntegration:
    """Integration tests for testcases commands."""

    @pytest.fixture
    def runner(self):
        return CliRunner()

    def test_testcases_create_available_via_cli(self, runner: CliRunner):
        """Test that testcases create is available via CLI."""
        result = runner.invoke(cli, ["testcases", "create", "--help"])
        assert result.exit_code == 0
        assert "create" in result.output.lower()

    def test_testcases_list_available_via_cli(self, runner: CliRunner):
        """Test that testcases list is available via CLI."""
        result = runner.invoke(cli, ["testcases", "list", "--help"])
        assert result.exit_code == 0


class TestListTestcasesWithAPI:
    """Tests for list testcases with actual API calls."""

    @pytest.fixture
    def runner(self):
        return CliRunner()

    @patch("wally_dev.commands.testcases.WorkspaceManager")
    @patch("wally_dev.commands.testcases.Settings")
    @patch("wally_dev.commands.testcases.LocalConfig")
    def test_list_with_api_response(
        self, mock_config_cls, mock_settings_cls, mock_workspace_cls, runner: CliRunner
    ):
        """Test list testcases with successful API response."""
        from wally_dev.models import TestCase

        mock_config = MagicMock()
        mock_config.is_logged_in = True
        mock_config.get_locked_norms.return_value = {
            "norm1": {"norm_name": "WCAG 2.1", "checkout_at": "2025-01-01"}
        }
        mock_config_cls.return_value = mock_config

        # Mock API client
        mock_client = MagicMock()
        mock_client.__enter__ = MagicMock(return_value=mock_client)
        mock_client.__exit__ = MagicMock(return_value=False)
        mock_client.get_testcases_by_norm.return_value = [
            TestCase(
                id="tc1", name="Test 1", rule_id="r1", language="html", enabled=True, examples=[]
            ),
            TestCase(
                id="tc2", name="Test 2", rule_id="r2", language="react", enabled=False, examples=[]
            ),
        ]
        mock_config.create_api_client.return_value = mock_client

        result = runner.invoke(list_testcases)

        assert result.exit_code == EXIT_SUCCESS
        assert "Test 1" in result.output or "tc1" in result.output

    @patch("wally_dev.commands.testcases.WorkspaceManager")
    @patch("wally_dev.commands.testcases.Settings")
    @patch("wally_dev.commands.testcases.LocalConfig")
    def test_list_with_rule_id_filter(
        self, mock_config_cls, mock_settings_cls, mock_workspace_cls, runner: CliRunner
    ):
        """Test list testcases filtered by rule ID."""
        from wally_dev.models import TestCase

        mock_config = MagicMock()
        mock_config.is_logged_in = True
        mock_config.get_locked_norms.return_value = {
            "norm1": {"norm_name": "WCAG 2.1", "checkout_at": "2025-01-01"}
        }
        mock_config_cls.return_value = mock_config

        mock_client = MagicMock()
        mock_client.__enter__ = MagicMock(return_value=mock_client)
        mock_client.__exit__ = MagicMock(return_value=False)
        mock_client.get_testcases_by_norm.return_value = [
            TestCase(id="tc1", name="Test 1", rule_id="rule123", language="html", enabled=True),
            TestCase(id="tc2", name="Test 2", rule_id="other", language="react", enabled=True),
        ]
        mock_config.create_api_client.return_value = mock_client

        result = runner.invoke(list_testcases, ["--rule-id", "rule123"])

        assert result.exit_code == EXIT_SUCCESS

    @patch("wally_dev.commands.testcases.WorkspaceManager")
    @patch("wally_dev.commands.testcases.Settings")
    @patch("wally_dev.commands.testcases.LocalConfig")
    def test_list_empty_testcases(
        self, mock_config_cls, mock_settings_cls, mock_workspace_cls, runner: CliRunner
    ):
        """Test list testcases when none exist."""
        mock_config = MagicMock()
        mock_config.is_logged_in = True
        mock_config.get_locked_norms.return_value = {
            "norm1": {"norm_name": "WCAG 2.1", "checkout_at": "2025-01-01"}
        }
        mock_config_cls.return_value = mock_config

        mock_client = MagicMock()
        mock_client.__enter__ = MagicMock(return_value=mock_client)
        mock_client.__exit__ = MagicMock(return_value=False)
        mock_client.get_testcases_by_norm.return_value = []
        mock_config.create_api_client.return_value = mock_client

        result = runner.invoke(list_testcases)

        assert result.exit_code == EXIT_SUCCESS
        assert "nenhum" in result.output.lower()


class TestSummaryTestcases:
    """Tests for testcases summary command."""

    @pytest.fixture
    def runner(self):
        return CliRunner()

    def test_summary_help(self, runner: CliRunner):
        """Test testcases summary help."""
        result = runner.invoke(cli, ["testcases", "summary", "--help"])
        assert result.exit_code == 0
        assert "--target" in result.output

    @patch("wally_dev.commands.testcases.Settings")
    @patch("wally_dev.commands.testcases.LocalConfig")
    def test_summary_not_logged_in(self, mock_config_cls, mock_settings_cls, runner: CliRunner):
        """Test summary when not logged in."""
        from wally_dev.commands.testcases import summary_testcases

        mock_config = MagicMock()
        mock_config.is_logged_in = False
        mock_config_cls.return_value = mock_config

        result = runner.invoke(summary_testcases)

        assert result.exit_code != EXIT_SUCCESS

    @patch("wally_dev.commands.testcases.Settings")
    @patch("wally_dev.commands.testcases.LocalConfig")
    def test_summary_no_checkout(self, mock_config_cls, mock_settings_cls, runner: CliRunner):
        """Test summary without norm in checkout."""
        from wally_dev.commands.testcases import summary_testcases

        mock_config = MagicMock()
        mock_config.is_logged_in = True
        mock_config.get_locked_norms.return_value = {}
        mock_config_cls.return_value = mock_config

        result = runner.invoke(summary_testcases)

        assert "checkout" in result.output.lower()

    @patch("wally_dev.commands.testcases.Settings")
    @patch("wally_dev.commands.testcases.LocalConfig")
    def test_summary_with_data(self, mock_config_cls, mock_settings_cls, runner: CliRunner):
        """Test summary with rules and testcases."""
        from wally_dev.commands.testcases import summary_testcases
        from wally_dev.models import Rule, TestCase

        mock_config = MagicMock()
        mock_config.is_logged_in = True
        mock_config.get_locked_norms.return_value = {
            "norm1": {"norm_name": "WCAG 2.1", "checkout_at": "2025-01-01"}
        }
        mock_config_cls.return_value = mock_config

        mock_client = MagicMock()
        mock_client.__enter__ = MagicMock(return_value=mock_client)
        mock_client.__exit__ = MagicMock(return_value=False)
        mock_client.get_rules_by_norm.return_value = [
            Rule(id="r1", name="Rule 1", norm_id="norm1", category="A", is_automatable=True),
            Rule(id="r2", name="Rule 2", norm_id="norm1", category="B", is_automatable=False),
        ]
        mock_client.get_testcases_by_norm.return_value = [
            TestCase(id="tc1", name="Test 1", rule_id="r1", language="html", enabled=True),
        ]
        mock_config.create_api_client.return_value = mock_client

        result = runner.invoke(summary_testcases)

        assert result.exit_code == EXIT_SUCCESS
        assert "cobertura" in result.output.lower() or "%" in result.output

    @patch("wally_dev.commands.testcases.Settings")
    @patch("wally_dev.commands.testcases.LocalConfig")
    def test_summary_with_target_filter(
        self, mock_config_cls, mock_settings_cls, runner: CliRunner
    ):
        """Test summary with target filter."""
        from wally_dev.commands.testcases import summary_testcases
        from wally_dev.models import Rule, TestCase

        mock_config = MagicMock()
        mock_config.is_logged_in = True
        mock_config.get_locked_norms.return_value = {
            "norm1": {"norm_name": "WCAG 2.1", "checkout_at": "2025-01-01"}
        }
        mock_config_cls.return_value = mock_config

        mock_client = MagicMock()
        mock_client.__enter__ = MagicMock(return_value=mock_client)
        mock_client.__exit__ = MagicMock(return_value=False)
        mock_client.get_rules_by_norm.return_value = [
            Rule(id="r1", name="Rule 1", norm_id="norm1", category="A", is_automatable=True),
        ]
        mock_client.get_testcases_by_norm.return_value = [
            TestCase(id="tc1", name="Test 1", rule_id="r1", language="html"),
            TestCase(id="tc2", name="Test 2", rule_id="r1", language="react"),
        ]
        mock_config.create_api_client.return_value = mock_client

        result = runner.invoke(summary_testcases, ["--target", "html"])

        assert result.exit_code == EXIT_SUCCESS
        assert "HTML" in result.output.upper()

    @patch("wally_dev.commands.testcases.Settings")
    @patch("wally_dev.commands.testcases.LocalConfig")
    def test_summary_no_rules(self, mock_config_cls, mock_settings_cls, runner: CliRunner):
        """Test summary when no rules exist."""
        from wally_dev.commands.testcases import summary_testcases

        mock_config = MagicMock()
        mock_config.is_logged_in = True
        mock_config.get_locked_norms.return_value = {
            "norm1": {"norm_name": "WCAG 2.1", "checkout_at": "2025-01-01"}
        }
        mock_config_cls.return_value = mock_config

        mock_client = MagicMock()
        mock_client.__enter__ = MagicMock(return_value=mock_client)
        mock_client.__exit__ = MagicMock(return_value=False)
        mock_client.get_rules_by_norm.return_value = []
        mock_config.create_api_client.return_value = mock_client

        result = runner.invoke(summary_testcases)

        assert result.exit_code == EXIT_SUCCESS
        assert "nenhuma regra" in result.output.lower()


class TestCreateTestcaseWithAI:
    """Tests for testcases create with AI generation."""

    @pytest.fixture
    def runner(self):
        return CliRunner()

    @patch.dict("os.environ", {"OPENAI_API_KEY": ""})
    @patch("wally_dev.commands.testcases.Settings")
    @patch("wally_dev.commands.testcases.LocalConfig")
    def test_create_no_openai_key(self, mock_config_cls, mock_settings_cls, runner: CliRunner):
        """Test create without OPENAI_API_KEY."""
        mock_config = MagicMock()
        mock_config.is_logged_in = True
        mock_config.get_locked_norms.return_value = {
            "norm1": {"norm_name": "WCAG 2.1", "checkout_at": "2025-01-01"}
        }
        mock_config_cls.return_value = mock_config

        result = runner.invoke(create_testcase, ["--target", "html", "--all"])

        assert "OPENAI_API_KEY" in result.output or result.exit_code != EXIT_SUCCESS

    @patch.dict("os.environ", {"OPENAI_API_KEY": "test-key"})
    @patch("wally_dev.commands.testcases.Settings")
    @patch("wally_dev.commands.testcases.LocalConfig")
    def test_create_no_rules_found(self, mock_config_cls, mock_settings_cls, runner: CliRunner):
        """Test create when no rules exist."""
        mock_config = MagicMock()
        mock_config.is_logged_in = True
        mock_config.get_locked_norms.return_value = {
            "norm1": {"norm_name": "WCAG 2.1", "checkout_at": "2025-01-01"}
        }
        mock_config_cls.return_value = mock_config

        mock_client = MagicMock()
        mock_client.__enter__ = MagicMock(return_value=mock_client)
        mock_client.__exit__ = MagicMock(return_value=False)
        mock_client.get_rules_by_norm.return_value = []
        mock_config.create_api_client.return_value = mock_client

        result = runner.invoke(create_testcase, ["--target", "html", "--all"])

        assert result.exit_code == EXIT_SUCCESS
        assert "nenhuma regra" in result.output.lower()

    @patch("wally_dev.commands.testcases.Settings")
    @patch("wally_dev.commands.testcases.LocalConfig")
    def test_create_multiple_norms_warning(
        self, mock_config_cls, mock_settings_cls, runner: CliRunner
    ):
        """Test create with multiple norms shows warning."""
        mock_config = MagicMock()
        mock_config.is_logged_in = True
        mock_config.get_locked_norms.return_value = {
            "norm1": {"norm_name": "WCAG 2.1", "checkout_at": "2025-01-01"},
            "norm2": {"norm_name": "NBR 17225", "checkout_at": "2025-01-02"},
        }
        mock_config_cls.return_value = mock_config

        result = runner.invoke(create_testcase, ["--target", "html", "--all"])

        # Should show warning about multiple norms
        assert (
            "múltiplas" in result.output.lower()
            or "primeira" in result.output.lower()
            or result.exit_code != EXIT_SUCCESS
        )


class TestCreateTestcaseAIGeneration:
    """Tests for testcases create with full AI generation flow."""

    @pytest.fixture
    def runner(self):
        return CliRunner()

    @patch.dict("os.environ", {"OPENAI_API_KEY": "test-key"})
    @patch("wally_dev.commands.testcases.TestCaseGenerator")
    @patch("wally_dev.commands.testcases.WorkspaceManager")
    @patch("wally_dev.commands.testcases.Settings")
    @patch("wally_dev.commands.testcases.LocalConfig")
    def test_create_successful_generation(
        self,
        mock_config_cls,
        mock_settings_cls,
        mock_workspace_cls,
        mock_generator_cls,
        runner: CliRunner,
    ):
        """Test successful testcase generation with AI."""
        from wally_dev.models import Rule, TestCase

        mock_config = MagicMock()
        mock_config.is_logged_in = True
        mock_config.get_locked_norms.return_value = {
            "norm1": {"norm_name": "WCAG 2.1", "checkout_at": "2025-01-01"}
        }
        mock_config_cls.return_value = mock_config

        mock_client = MagicMock()
        mock_client.__enter__ = MagicMock(return_value=mock_client)
        mock_client.__exit__ = MagicMock(return_value=False)
        mock_client.get_norm.return_value = MagicMock(name="WCAG 2.1")
        mock_client.get_rules_by_norm.return_value = [
            Rule(id="r1", name="Alt Text Rule", norm_id="norm1", is_automatable=True),
        ]
        mock_client.get_testcases_by_norm.return_value = []
        mock_client.create_testcase.return_value = TestCase(
            id="tc-new", name="TC: Alt Text Rule", rule_id="r1", language="html"
        )
        mock_client.create_example.return_value = {"_id": "ex1"}
        mock_config.create_api_client.return_value = mock_client

        mock_generator = MagicMock()
        mock_generator.generate.return_value = {
            "code": "def main(): pass",
            "finder_py": "def find(html): return []",
            "validator_py": "def validate(el): return True",
            "compliant_html": "<img alt='test'>",
            "non_compliant_html": "<img>",
        }
        mock_generator_cls.return_value = mock_generator

        mock_workspace = MagicMock()
        mock_workspace_cls.return_value = mock_workspace

        result = runner.invoke(create_testcase, ["--target", "html", "--all"])

        assert result.exit_code == EXIT_SUCCESS
        mock_generator.generate.assert_called()
        mock_client.create_testcase.assert_called()

    @patch.dict("os.environ", {"OPENAI_API_KEY": "test-key"})
    @patch("wally_dev.commands.testcases.TestCaseGenerator")
    @patch("wally_dev.commands.testcases.Settings")
    @patch("wally_dev.commands.testcases.LocalConfig")
    def test_create_generation_failure_without_continue(
        self, mock_config_cls, mock_settings_cls, mock_generator_cls, runner: CliRunner
    ):
        """Test creation stops on error without --continue-on-error."""
        from wally_dev.models import Rule

        mock_config = MagicMock()
        mock_config.is_logged_in = True
        mock_config.get_locked_norms.return_value = {
            "norm1": {"norm_name": "WCAG 2.1", "checkout_at": "2025-01-01"}
        }
        mock_config_cls.return_value = mock_config

        mock_client = MagicMock()
        mock_client.__enter__ = MagicMock(return_value=mock_client)
        mock_client.__exit__ = MagicMock(return_value=False)
        mock_client.get_norm.return_value = MagicMock(name="WCAG 2.1")
        mock_client.get_rules_by_norm.return_value = [
            Rule(id="r1", name="Rule 1", norm_id="norm1", is_automatable=True),
        ]
        mock_client.get_testcases_by_norm.return_value = []
        mock_config.create_api_client.return_value = mock_client

        mock_generator = MagicMock()
        mock_generator.generate.side_effect = Exception("AI generation failed")
        mock_generator_cls.return_value = mock_generator

        result = runner.invoke(create_testcase, ["--target", "html", "--all"])

        # Should fail and show error
        assert result.exit_code == EXIT_ERROR_API or "erro" in result.output.lower()

    @patch.dict("os.environ", {"OPENAI_API_KEY": "test-key"})
    @patch("wally_dev.commands.testcases.TestCaseGenerator")
    @patch("wally_dev.commands.testcases.WorkspaceManager")
    @patch("wally_dev.commands.testcases.Settings")
    @patch("wally_dev.commands.testcases.LocalConfig")
    def test_create_generation_failure_with_continue(
        self,
        mock_config_cls,
        mock_settings_cls,
        mock_workspace_cls,
        mock_generator_cls,
        runner: CliRunner,
    ):
        """Test creation continues on error with --continue-on-error."""
        from wally_dev.models import Rule, TestCase

        mock_config = MagicMock()
        mock_config.is_logged_in = True
        mock_config.get_locked_norms.return_value = {
            "norm1": {"norm_name": "WCAG 2.1", "checkout_at": "2025-01-01"}
        }
        mock_config_cls.return_value = mock_config

        mock_client = MagicMock()
        mock_client.__enter__ = MagicMock(return_value=mock_client)
        mock_client.__exit__ = MagicMock(return_value=False)
        mock_client.get_norm.return_value = MagicMock(name="WCAG 2.1")
        mock_client.get_rules_by_norm.return_value = [
            Rule(id="r1", name="Rule 1", norm_id="norm1", is_automatable=True),
            Rule(id="r2", name="Rule 2", norm_id="norm1", is_automatable=True),
        ]
        mock_client.get_testcases_by_norm.return_value = []
        mock_client.create_testcase.return_value = TestCase(
            id="tc-new", name="TC: Rule 2", rule_id="r2", language="html"
        )
        mock_config.create_api_client.return_value = mock_client

        mock_generator = MagicMock()
        # First call fails, second succeeds
        mock_generator.generate.side_effect = [
            Exception("Failed"),
            {"code": "pass", "finder_py": "pass", "validator_py": "pass"},
        ]
        mock_generator_cls.return_value = mock_generator

        mock_workspace = MagicMock()
        mock_workspace_cls.return_value = mock_workspace

        result = runner.invoke(
            create_testcase, ["--target", "html", "--all", "--continue-on-error"]
        )

        # Should complete with 1 success and 1 failure
        assert result.exit_code == EXIT_SUCCESS
        assert "1 testcases" in result.output.lower() or "sucesso" in result.output.lower()

    @patch.dict("os.environ", {"OPENAI_API_KEY": "test-key"})
    @patch("wally_dev.commands.testcases.TestCaseGenerator")
    @patch("wally_dev.commands.testcases.Settings")
    @patch("wally_dev.commands.testcases.LocalConfig")
    def test_create_generation_returns_none(
        self, mock_config_cls, mock_settings_cls, mock_generator_cls, runner: CliRunner
    ):
        """Test creation handles AI returning None."""
        from wally_dev.models import Rule

        mock_config = MagicMock()
        mock_config.is_logged_in = True
        mock_config.get_locked_norms.return_value = {
            "norm1": {"norm_name": "WCAG 2.1", "checkout_at": "2025-01-01"}
        }
        mock_config_cls.return_value = mock_config

        mock_client = MagicMock()
        mock_client.__enter__ = MagicMock(return_value=mock_client)
        mock_client.__exit__ = MagicMock(return_value=False)
        mock_client.get_norm.return_value = MagicMock(name="WCAG 2.1")
        mock_client.get_rules_by_norm.return_value = [
            Rule(id="r1", name="Rule 1", norm_id="norm1", is_automatable=True),
        ]
        mock_client.get_testcases_by_norm.return_value = []
        mock_config.create_api_client.return_value = mock_client

        mock_generator = MagicMock()
        mock_generator.generate.return_value = None  # AI returns None
        mock_generator_cls.return_value = mock_generator

        result = runner.invoke(
            create_testcase, ["--target", "html", "--all", "--continue-on-error"]
        )

        # Should complete but show failures
        assert "falha" in result.output.lower() or result.exit_code == EXIT_SUCCESS

    @patch.dict("os.environ", {"OPENAI_API_KEY": "test-key"})
    @patch("wally_dev.commands.testcases.Settings")
    @patch("wally_dev.commands.testcases.LocalConfig")
    def test_create_all_rules_already_have_testcases(
        self, mock_config_cls, mock_settings_cls, runner: CliRunner
    ):
        """Test create when all rules already have testcases for target."""
        from wally_dev.models import Rule, TestCase

        mock_config = MagicMock()
        mock_config.is_logged_in = True
        mock_config.get_locked_norms.return_value = {
            "norm1": {"norm_name": "WCAG 2.1", "checkout_at": "2025-01-01"}
        }
        mock_config_cls.return_value = mock_config

        mock_client = MagicMock()
        mock_client.__enter__ = MagicMock(return_value=mock_client)
        mock_client.__exit__ = MagicMock(return_value=False)
        mock_client.get_norm.return_value = MagicMock(name="WCAG 2.1")
        mock_client.get_rules_by_norm.return_value = [
            Rule(id="r1", name="Rule 1", norm_id="norm1", is_automatable=True),
        ]
        mock_client.get_testcases_by_norm.return_value = [
            TestCase(id="tc1", name="Test 1", rule_id="r1", language="html"),
        ]
        mock_config.create_api_client.return_value = mock_client

        result = runner.invoke(create_testcase, ["--target", "html", "--all"])

        # All rules have testcases
        assert result.exit_code == EXIT_SUCCESS
        assert "já possuem" in result.output.lower()

    @patch.dict("os.environ", {"OPENAI_API_KEY": "test-key"})
    @patch("wally_dev.commands.testcases.Settings")
    @patch("wally_dev.commands.testcases.LocalConfig")
    def test_create_non_automatable_rules_skipped(
        self, mock_config_cls, mock_settings_cls, runner: CliRunner
    ):
        """Test create skips non-automatable rules."""
        from wally_dev.models import Rule

        mock_config = MagicMock()
        mock_config.is_logged_in = True
        mock_config.get_locked_norms.return_value = {
            "norm1": {"norm_name": "WCAG 2.1", "checkout_at": "2025-01-01"}
        }
        mock_config_cls.return_value = mock_config

        mock_client = MagicMock()
        mock_client.__enter__ = MagicMock(return_value=mock_client)
        mock_client.__exit__ = MagicMock(return_value=False)
        mock_client.get_norm.return_value = MagicMock(name="WCAG 2.1")
        mock_client.get_rules_by_norm.return_value = [
            Rule(id="r1", name="Manual Rule", norm_id="norm1", is_automatable=False),
        ]
        mock_client.get_testcases_by_norm.return_value = []
        mock_config.create_api_client.return_value = mock_client

        result = runner.invoke(create_testcase, ["--target", "html", "--all"])

        # No rules to process (all non-automatable)
        assert result.exit_code == EXIT_SUCCESS


class TestListTestcasesErrorHandling:
    """Tests for list testcases error handling."""

    @pytest.fixture
    def runner(self):
        return CliRunner()

    @patch("wally_dev.commands.testcases.WorkspaceManager")
    @patch("wally_dev.commands.testcases.Settings")
    @patch("wally_dev.commands.testcases.LocalConfig")
    def test_list_api_exception(
        self, mock_config_cls, mock_settings_cls, mock_workspace_cls, runner: CliRunner
    ):
        """Test list testcases handles API exceptions."""
        mock_config = MagicMock()
        mock_config.is_logged_in = True
        mock_config.get_locked_norms.return_value = {
            "norm1": {"norm_name": "WCAG 2.1", "checkout_at": "2025-01-01"}
        }
        mock_config_cls.return_value = mock_config

        mock_client = MagicMock()
        mock_client.__enter__ = MagicMock(return_value=mock_client)
        mock_client.__exit__ = MagicMock(return_value=False)
        mock_client.get_testcases_by_norm.side_effect = Exception("API Error")
        mock_config.create_api_client.return_value = mock_client

        result = runner.invoke(list_testcases)

        # Should fail with error
        assert result.exit_code == EXIT_ERROR_API or "erro" in result.output.lower()


class TestSummaryTestcasesErrorHandling:
    """Tests for summary testcases error handling."""

    @pytest.fixture
    def runner(self):
        return CliRunner()

    @patch("wally_dev.commands.testcases.Settings")
    @patch("wally_dev.commands.testcases.LocalConfig")
    def test_summary_connection_error(self, mock_config_cls, mock_settings_cls, runner: CliRunner):
        """Test summary handles connection errors."""
        from wally_dev.commands.testcases import summary_testcases
        from wally_dev.exceptions import ConnectionFailedError

        mock_config = MagicMock()
        mock_config.is_logged_in = True
        mock_config.get_locked_norms.return_value = {
            "norm1": {"norm_name": "WCAG 2.1", "checkout_at": "2025-01-01"}
        }
        mock_config_cls.return_value = mock_config

        mock_client = MagicMock()
        mock_client.__enter__ = MagicMock(return_value=mock_client)
        mock_client.__exit__ = MagicMock(return_value=False)
        mock_client.get_rules_by_norm.side_effect = ConnectionFailedError("Connection failed")
        mock_config.create_api_client.return_value = mock_client

        result = runner.invoke(summary_testcases)

        # Should handle error
        assert (
            result.exit_code == EXIT_ERROR_API
            or "conexão" in result.output.lower()
            or "erro" in result.output.lower()
        )

    @patch("wally_dev.commands.testcases.Settings")
    @patch("wally_dev.commands.testcases.LocalConfig")
    def test_summary_general_exception(self, mock_config_cls, mock_settings_cls, runner: CliRunner):
        """Test summary handles general exceptions."""
        from wally_dev.commands.testcases import summary_testcases

        mock_config = MagicMock()
        mock_config.is_logged_in = True
        mock_config.get_locked_norms.return_value = {
            "norm1": {"norm_name": "WCAG 2.1", "checkout_at": "2025-01-01"}
        }
        mock_config_cls.return_value = mock_config

        mock_client = MagicMock()
        mock_client.__enter__ = MagicMock(return_value=mock_client)
        mock_client.__exit__ = MagicMock(return_value=False)
        mock_client.get_rules_by_norm.side_effect = Exception("Unexpected error")
        mock_config.create_api_client.return_value = mock_client

        result = runner.invoke(summary_testcases)

        # Should handle error
        assert result.exit_code == EXIT_ERROR_API or "erro" in result.output.lower()
