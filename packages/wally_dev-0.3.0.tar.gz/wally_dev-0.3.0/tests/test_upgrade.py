"""
Tests for upgrade command.
"""

from unittest.mock import Mock, patch

from click.testing import CliRunner

from wally_dev import __version__
from wally_dev.commands.upgrade import (
    InstallMethod,
    UpgradeResult,
    detect_install_method,
    get_latest_version_from_pypi,
    is_upgrade_available,
    upgrade,
)
from wally_dev.constants import (
    EXIT_ERROR_NETWORK,
    EXIT_ERROR_UPGRADE,
    EXIT_SUCCESS,
    EXIT_UPGRADE_AVAILABLE,
)


class TestVersionParsing:
    """Tests for version parsing logic."""

    def test_parse_version_full(self):
        """Test parsing full version string."""
        from wally_dev.commands.upgrade import _parse_version

        assert _parse_version("1.2.3") == (1, 2, 3)

    def test_parse_version_partial(self):
        """Test parsing partial version string."""
        from wally_dev.commands.upgrade import _parse_version

        assert _parse_version("1.2") == (1, 2, 0)
        assert _parse_version("1") == (1, 0, 0)

    def test_parse_version_invalid(self):
        """Test parsing invalid version string."""
        from wally_dev.commands.upgrade import _parse_version

        assert _parse_version("invalid") == (0, 0, 0)
        assert _parse_version("") == (0, 0, 0)


class TestUpgradeAvailable:
    """Tests for upgrade availability check."""

    def test_upgrade_available_major(self):
        """Test upgrade available for major version."""
        assert is_upgrade_available("1.0.0", "2.0.0") is True

    def test_upgrade_available_minor(self):
        """Test upgrade available for minor version."""
        assert is_upgrade_available("1.0.0", "1.1.0") is True

    def test_upgrade_available_patch(self):
        """Test upgrade available for patch version."""
        assert is_upgrade_available("1.0.0", "1.0.1") is True

    def test_no_upgrade_needed(self):
        """Test when no upgrade is needed."""
        assert is_upgrade_available("1.0.0", "1.0.0") is False

    def test_downgrade_not_needed(self):
        """Test downgrade scenario."""
        assert is_upgrade_available("2.0.0", "1.0.0") is False

    def test_none_latest_version(self):
        """Test when latest version is None."""
        assert is_upgrade_available("1.0.0", None) is False


class TestInstallMethodDetection:
    """Tests for installation method detection."""

    @patch("wally_dev.commands.upgrade.shutil.which")
    def test_detect_pip_when_pipx_not_available(self, mock_which):
        """Test detection falls back to pip when pipx is not installed."""
        mock_which.return_value = None
        assert detect_install_method() == InstallMethod.PIP

    @patch("wally_dev.commands.upgrade.subprocess.run")
    @patch("wally_dev.commands.upgrade.shutil.which")
    def test_detect_pipx_when_wally_dev_in_list(self, mock_which, mock_run):
        """Test detection returns pipx when wally-dev is in pipx list."""
        mock_which.return_value = "/usr/bin/pipx"
        mock_run.return_value = Mock(returncode=0, stdout="wally-dev 0.1.1\nother-pkg 1.0.0\n")
        assert detect_install_method() == InstallMethod.PIPX

    @patch("wally_dev.commands.upgrade.subprocess.run")
    @patch("wally_dev.commands.upgrade.shutil.which")
    def test_detect_pip_when_wally_dev_not_in_pipx(self, mock_which, mock_run):
        """Test detection returns pip when wally-dev is not in pipx list."""
        mock_which.return_value = "/usr/bin/pipx"
        mock_run.return_value = Mock(returncode=0, stdout="other-pkg 1.0.0\n")
        assert detect_install_method() == InstallMethod.PIP


class TestGetLatestVersion:
    """Tests for fetching latest version from PyPI."""

    @patch("wally_dev.commands.upgrade.requests.get")
    def test_get_latest_version_success(self, mock_get):
        """Test successfully fetching latest version."""
        mock_response = Mock()
        mock_response.json.return_value = {"info": {"version": "0.2.0"}}
        mock_get.return_value = mock_response

        version = get_latest_version_from_pypi()
        assert version == "0.2.0"

    @patch("wally_dev.commands.upgrade.requests.get")
    def test_get_latest_version_no_tag(self, mock_get):
        """Test when response has no version."""
        mock_response = Mock()
        mock_response.json.return_value = {}
        mock_get.return_value = mock_response

        version = get_latest_version_from_pypi()
        assert version is None

    @patch("wally_dev.commands.upgrade.requests.get")
    def test_get_latest_version_network_error(self, mock_get):
        """Test handling network errors."""
        import requests

        mock_get.side_effect = requests.RequestException("Network error")

        version = get_latest_version_from_pypi()
        assert version is None

    @patch("wally_dev.commands.upgrade.requests.get")
    def test_get_latest_version_timeout(self, mock_get):
        """Test handling timeout."""
        import requests

        mock_get.side_effect = requests.Timeout("Timeout")

        version = get_latest_version_from_pypi()
        assert version is None


class TestUpgradeResult:
    """Tests for UpgradeResult named tuple."""

    def test_upgrade_result_success(self):
        """Test successful upgrade result."""
        result = UpgradeResult(success=True, message="OK", exit_code=EXIT_SUCCESS)
        assert result.success is True
        assert result.exit_code == EXIT_SUCCESS

    def test_upgrade_result_failure(self):
        """Test failed upgrade result."""
        result = UpgradeResult(success=False, message="Error", exit_code=EXIT_ERROR_UPGRADE)
        assert result.success is False
        assert result.exit_code == EXIT_ERROR_UPGRADE


class TestUpgradeCommand:
    """Tests for upgrade CLI command."""

    @patch("wally_dev.commands.upgrade.detect_install_method")
    @patch("wally_dev.commands.upgrade.get_latest_version_from_pypi")
    def test_upgrade_check_flag_no_upgrade_needed(self, mock_get, mock_detect):
        """Test --check flag when no upgrade is needed."""
        runner = CliRunner()
        mock_get.return_value = __version__
        mock_detect.return_value = InstallMethod.PIP

        result = runner.invoke(upgrade, ["--check"])
        assert result.exit_code == EXIT_SUCCESS
        assert "já possui a versão mais recente" in result.output

    @patch("wally_dev.commands.upgrade.detect_install_method")
    @patch("wally_dev.commands.upgrade.get_latest_version_from_pypi")
    def test_upgrade_check_flag_upgrade_available(self, mock_get, mock_detect):
        """Test --check flag when upgrade is available returns exit code 1."""
        runner = CliRunner()
        mock_get.return_value = "99.9.9"
        mock_detect.return_value = InstallMethod.PIP

        result = runner.invoke(upgrade, ["--check"])
        assert result.exit_code == EXIT_UPGRADE_AVAILABLE
        assert "Nova versão disponível" in result.output
        assert "Use 'wally-dev upgrade' para atualizar" in result.output

    @patch("wally_dev.commands.upgrade.detect_install_method")
    @patch("wally_dev.commands.upgrade.get_latest_version_from_pypi")
    def test_upgrade_no_new_version(self, mock_get, mock_detect):
        """Test upgrade when no new version is available."""
        runner = CliRunner()
        mock_get.return_value = __version__
        mock_detect.return_value = InstallMethod.PIP

        result = runner.invoke(upgrade, input="n\n")
        assert result.exit_code == EXIT_SUCCESS
        assert "já possui a versão mais recente" in result.output

    @patch("wally_dev.commands.upgrade.detect_install_method")
    @patch("wally_dev.commands.upgrade.perform_upgrade")
    @patch("wally_dev.commands.upgrade.get_latest_version_from_pypi")
    def test_upgrade_with_confirmation(self, mock_get, mock_perform, mock_detect):
        """Test upgrade with user confirmation."""
        runner = CliRunner()
        mock_get.return_value = "99.9.9"
        mock_detect.return_value = InstallMethod.PIP
        mock_perform.return_value = UpgradeResult(
            success=True, message="Upgrade realizado com sucesso!", exit_code=EXIT_SUCCESS
        )

        result = runner.invoke(upgrade, input="y\n")
        assert result.exit_code == EXIT_SUCCESS
        assert "sucesso" in result.output.lower()

    @patch("wally_dev.commands.upgrade.detect_install_method")
    @patch("wally_dev.commands.upgrade.get_latest_version_from_pypi")
    def test_upgrade_cancelled(self, mock_get, mock_detect):
        """Test upgrade when user cancels."""
        runner = CliRunner()
        mock_get.return_value = "99.9.9"
        mock_detect.return_value = InstallMethod.PIP

        result = runner.invoke(upgrade, input="n\n")
        assert result.exit_code == EXIT_SUCCESS
        assert "cancelado" in result.output

    @patch("wally_dev.commands.upgrade.detect_install_method")
    @patch("wally_dev.commands.upgrade.perform_upgrade")
    @patch("wally_dev.commands.upgrade.get_latest_version_from_pypi")
    def test_upgrade_yes_flag_auto_confirms(self, mock_get, mock_perform, mock_detect):
        """Test --yes flag auto-confirms upgrade without prompting."""
        runner = CliRunner()
        mock_get.return_value = "99.9.9"
        mock_detect.return_value = InstallMethod.PIP
        mock_perform.return_value = UpgradeResult(
            success=True, message="Upgrade realizado com sucesso!", exit_code=EXIT_SUCCESS
        )

        result = runner.invoke(upgrade, ["--yes"])
        assert result.exit_code == EXIT_SUCCESS
        mock_perform.assert_called_once()
        assert "Deseja atualizar agora?" not in result.output

    @patch("wally_dev.commands.upgrade.detect_install_method")
    @patch("wally_dev.commands.upgrade.perform_upgrade")
    def test_upgrade_specific_version(self, mock_perform, mock_detect):
        """Test upgrade to specific version."""
        runner = CliRunner()
        mock_detect.return_value = InstallMethod.PIP
        mock_perform.return_value = UpgradeResult(
            success=True, message="Upgrade realizado com sucesso!", exit_code=EXIT_SUCCESS
        )

        result = runner.invoke(upgrade, ["--version", "0.2.0"])
        assert result.exit_code == EXIT_SUCCESS
        assert "sucesso" in result.output.lower()

    @patch("wally_dev.commands.upgrade.detect_install_method")
    @patch("wally_dev.commands.upgrade.get_latest_version_from_pypi")
    def test_upgrade_network_error(self, mock_get, mock_detect):
        """Test upgrade when network is unavailable returns proper exit code."""
        runner = CliRunner()
        mock_get.return_value = None
        mock_detect.return_value = InstallMethod.PIP

        result = runner.invoke(upgrade, [])
        assert result.exit_code == EXIT_ERROR_NETWORK
        assert "Não foi possível verificar versão" in result.output


class TestUpgradeCommand_Integration:
    """Integration tests for upgrade command."""

    @patch("wally_dev.commands.upgrade.detect_install_method")
    @patch("wally_dev.commands.upgrade.get_latest_version_from_pypi")
    def test_upgrade_shows_current_version(self, mock_get, mock_detect):
        """Test that upgrade shows current version."""
        runner = CliRunner()
        mock_get.return_value = __version__
        mock_detect.return_value = InstallMethod.PIP

        result = runner.invoke(upgrade, ["--check"])
        assert __version__ in result.output

    @patch("wally_dev.commands.upgrade.detect_install_method")
    @patch("wally_dev.commands.upgrade.get_latest_version_from_pypi")
    def test_upgrade_shows_available_version(self, mock_get, mock_detect):
        """Test that upgrade shows available version."""
        runner = CliRunner()
        mock_get.return_value = "99.9.9"
        mock_detect.return_value = InstallMethod.PIP

        result = runner.invoke(upgrade, ["--check"])
        assert "99.9.9" in result.output

    @patch("wally_dev.commands.upgrade.detect_install_method")
    @patch("wally_dev.commands.upgrade.get_latest_version_from_pypi")
    def test_upgrade_shows_install_method(self, mock_get, mock_detect):
        """Test that upgrade shows detected installation method."""
        runner = CliRunner()
        mock_get.return_value = __version__
        mock_detect.return_value = InstallMethod.PIPX

        result = runner.invoke(upgrade, ["--check"])
        assert "pipx" in result.output
