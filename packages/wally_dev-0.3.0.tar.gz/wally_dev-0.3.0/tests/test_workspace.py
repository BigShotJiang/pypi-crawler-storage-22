"""Tests for workspace module."""

import json
from pathlib import Path

import pytest

from wally_dev.exceptions import TestCaseNotFoundError
from wally_dev.models import ExampleTestCase, TestCase
from wally_dev.workspace import WorkspaceManager, sanitize_folder_name


class TestSanitizeFolderName:
    """Tests for sanitize_folder_name function."""

    def test_basic_sanitization(self):
        """Test basic name sanitization."""
        assert sanitize_folder_name("Test Alt Text") == "test-alt-text"
        assert sanitize_folder_name("Images Must Have Alt") == "images-must-have-alt"

    def test_accents_removal(self):
        """Test accent removal."""
        assert sanitize_folder_name("Imágenes con Acentos") == "imagenes-con-acentos"
        assert sanitize_folder_name("Não Compliant") == "nao-compliant"

    def test_special_chars_removal(self):
        """Test special character removal."""
        assert sanitize_folder_name("Test: With (Special) [Chars]") == "test-with-special-chars"
        assert sanitize_folder_name("Test/With\\Slashes") == "test-with-slashes"

    def test_length_limiting(self):
        """Test length limiting to 80 characters."""
        long_name = "A" * 100
        result = sanitize_folder_name(long_name)
        assert len(result) <= 80
        assert result == "a" * 80

    def test_leading_trailing_hyphens_removed(self):
        """Test leading/trailing hyphens are removed."""
        assert sanitize_folder_name("-Test-") == "test"
        assert sanitize_folder_name("___Test___") == "test"


@pytest.fixture
def workspace(tmp_path: Path) -> WorkspaceManager:
    """Create a workspace manager with temp directory."""
    return WorkspaceManager(base_path=tmp_path)


@pytest.fixture
def sample_testcase() -> TestCase:
    """Create a sample test case."""
    return TestCase(
        id="tc123",
        name="Test Alt Text",
        description="Verifies alt text presence",
        rule_id="rule456",
        norm_id="norm789",
        language="HTML",
        enabled=True,
        examples=[
            ExampleTestCase(
                id="ex1",
                name="Image with alt",
                description="Valid image",
                html='<img src="test.jpg" alt="Test">',
                expected_result="pass",
                explanation="Has alt text",
            ),
            ExampleTestCase(
                id="ex2",
                name="Image without alt",
                description="Invalid image",
                html='<img src="test.jpg">',
                expected_result="fail",
                explanation="Missing alt text",
            ),
        ],
    )


def _create_testcase_dir(workspace: WorkspaceManager, norm_id: str, testcase: TestCase) -> Path:
    """Helper to create a testcase directory structure for tests."""
    testcase_dir = workspace.get_testcases_dir(norm_id) / testcase.id
    testcase_dir.mkdir(parents=True, exist_ok=True)

    # Create testcase.json
    json_path = testcase_dir / "testcase.json"
    with open(json_path, "w", encoding="utf-8") as f:
        json.dump(testcase.to_file_dict(), f, indent=2, ensure_ascii=False)

    # Create code directory with finder/validator
    code_dir = testcase_dir / "code"
    code_dir.mkdir(exist_ok=True)

    (code_dir / "finder.py").write_text("""
from bs4 import BeautifulSoup

def find(html_content):
    soup = BeautifulSoup(html_content, "html.parser")
    return soup.find_all("img")
""")

    (code_dir / "validator.py").write_text("""
def validate(element):
    alt = element.get("alt", "")
    return bool(alt and alt.strip())
""")

    # Create examples directories
    examples_dir = testcase_dir / "examples"
    compliant_dir = examples_dir / "compliant"
    non_compliant_dir = examples_dir / "non-compliant"
    compliant_dir.mkdir(parents=True, exist_ok=True)
    non_compliant_dir.mkdir(parents=True, exist_ok=True)

    (compliant_dir / "example.html").write_text('<img src="test.jpg" alt="Test">')
    (non_compliant_dir / "example.html").write_text('<img src="test.jpg">')

    return testcase_dir


class TestWorkspaceManager:
    """Tests for WorkspaceManager class."""

    def test_ensure_norm_dir(self, workspace: WorkspaceManager):
        """Test creating norm directory structure."""
        norm_dir = workspace.ensure_norm_dir("norm123")

        assert norm_dir.exists()
        assert (norm_dir / "testCases").exists()

    def test_save_testcase_legacy_format(
        self, workspace: WorkspaceManager, sample_testcase: TestCase
    ):
        """Test saving a test case (new directory format with sanitized name)."""
        # save_testcase now creates a directory with testcase.json inside
        testcase_dir = workspace.save_testcase("norm789", sample_testcase)

        assert testcase_dir.exists()
        assert testcase_dir.is_dir()

        # Check JSON file inside the directory
        json_path = testcase_dir / "testcase.json"
        assert json_path.exists()

        # Verify JSON content (includes both 'id' and '_id' for compatibility)
        with open(json_path) as f:
            data = json.load(f)
        assert data["id"] == "tc123"
        assert data["_id"] == "tc123"
        assert data["name"] == "Test Alt Text"
        assert len(data["examples"]) == 2

        # Verify folder name is sanitized
        assert testcase_dir.name == "test-alt-text"

    def test_save_testcases(self, workspace: WorkspaceManager, sample_testcase: TestCase):
        """Test saving multiple test cases."""
        tc2 = TestCase(
            id="tc456",
            name="Another Test",
            rule_id="rule789",
            examples=[],
        )

        count = workspace.save_testcases("norm789", [sample_testcase, tc2])

        assert count == 2
        # Folders use sanitized names, not IDs
        assert (workspace.get_testcases_dir("norm789") / "test-alt-text").exists()
        assert (workspace.get_testcases_dir("norm789") / "another-test").exists()
        # Verify JSON files exist inside directories
        assert (workspace.get_testcases_dir("norm789") / "test-alt-text" / "testcase.json").exists()
        assert (workspace.get_testcases_dir("norm789") / "another-test" / "testcase.json").exists()

    def test_load_testcase_new_format(self, workspace: WorkspaceManager, sample_testcase: TestCase):
        """Test loading a test case (new directory format)."""
        # Create testcase in new format
        _create_testcase_dir(workspace, "norm789", sample_testcase)

        loaded = workspace.load_testcase("norm789", "tc123")

        assert loaded.id == "tc123"
        assert loaded.name == "Test Alt Text"
        assert len(loaded.examples) > 0

    def test_load_testcase_not_found(self, workspace: WorkspaceManager):
        """Test loading non-existent test case."""
        workspace.ensure_norm_dir("norm789")

        with pytest.raises(TestCaseNotFoundError):
            workspace.load_testcase("norm789", "nonexistent")

    def test_load_all_testcases(self, workspace: WorkspaceManager, sample_testcase: TestCase):
        """Test loading all test cases for a norm."""
        _create_testcase_dir(workspace, "norm789", sample_testcase)

        testcases = workspace.load_all_testcases("norm789")

        assert len(testcases) == 1
        assert testcases[0].id == "tc123"

    def test_list_norms(self, workspace: WorkspaceManager, sample_testcase: TestCase):
        """Test listing norms in workspace."""
        _create_testcase_dir(workspace, "norm1", sample_testcase)
        _create_testcase_dir(workspace, "norm2", sample_testcase)

        norms = workspace.list_norms()

        assert set(norms) == {"norm1", "norm2"}

    def test_delete_norm(self, workspace: WorkspaceManager, sample_testcase: TestCase):
        """Test deleting a norm's workspace."""
        _create_testcase_dir(workspace, "norm789", sample_testcase)
        assert workspace.get_norm_dir("norm789").exists()

        result = workspace.delete_norm("norm789")

        assert result is True
        assert not workspace.get_norm_dir("norm789").exists()

    def test_get_workspace_info(self, workspace: WorkspaceManager, sample_testcase: TestCase):
        """Test getting workspace info."""
        _create_testcase_dir(workspace, "norm789", sample_testcase)

        info = workspace.get_workspace_info("norm789")

        assert info["norm_id"] == "norm789"
        assert info["exists"] is True
        assert info["testcase_count"] == 1
        assert "tc123" in info["testcases"]

    def test_get_testcase_code_dir(self, workspace: WorkspaceManager, sample_testcase: TestCase):
        """Test getting code directory path."""
        _create_testcase_dir(workspace, "norm789", sample_testcase)

        code_dir = workspace.get_testcase_code_dir("norm789", "tc123")

        assert code_dir.exists()
        assert (code_dir / "finder.py").exists()
        assert (code_dir / "validator.py").exists()

    def test_get_testcase_dir(self, workspace: WorkspaceManager, sample_testcase: TestCase):
        """Test getting testcase directory path."""
        _create_testcase_dir(workspace, "norm789", sample_testcase)

        testcase_dir = workspace.get_testcase_dir("norm789", "tc123")

        assert testcase_dir.exists()
        assert (testcase_dir / "testcase.json").exists()
        assert (testcase_dir / "code").exists()
        assert (testcase_dir / "examples").exists()

    def test_extract_testcases_zip(self, workspace: WorkspaceManager):
        """Test extracting test cases from ZIP."""
        import io
        import zipfile

        # Create a test ZIP file
        zip_buffer = io.BytesIO()
        with zipfile.ZipFile(zip_buffer, "w", zipfile.ZIP_DEFLATED) as zf:
            zf.writestr("tc1/testcase.json", '{"_id": "tc1", "name": "Test 1"}')
            zf.writestr("tc1/code/finder.py", "def find(html): return []")
            zf.writestr("tc1/code/validator.py", "def validate(el): return True")
            zf.writestr("tc2/testcase.json", '{"_id": "tc2", "name": "Test 2"}')

        zip_content = zip_buffer.getvalue()

        count = workspace.extract_testcases_zip("norm123", zip_content)

        assert count == 2
        assert (workspace.get_testcases_dir("norm123") / "tc1" / "testcase.json").exists()
        assert (workspace.get_testcases_dir("norm123") / "tc1" / "code" / "finder.py").exists()
        assert (workspace.get_testcases_dir("norm123") / "tc2" / "testcase.json").exists()

    def test_extract_testcases_zip_invalid(self, workspace: WorkspaceManager):
        """Test extracting from invalid ZIP raises error."""
        from wally_dev.exceptions import WorkspaceError

        with pytest.raises(WorkspaceError):
            workspace.extract_testcases_zip("norm123", b"not a valid zip")

    def test_extract_examples_zip(self, workspace: WorkspaceManager):
        """Test extracting examples from ZIP."""
        import io
        import zipfile

        # First create the testcase directory
        workspace.ensure_norm_dir("norm123")
        testcase_dir = workspace.get_testcases_dir("norm123") / "tc1"
        testcase_dir.mkdir(parents=True, exist_ok=True)

        # Create a test ZIP file with examples
        zip_buffer = io.BytesIO()
        with zipfile.ZipFile(zip_buffer, "w", zipfile.ZIP_DEFLATED) as zf:
            zf.writestr("tc1/examples/compliant/example1.html", "<img alt='test'>")
            zf.writestr("tc1/examples/non-compliant/example1.html", "<img>")

        zip_content = zip_buffer.getvalue()

        count = workspace.extract_examples_zip("norm123", zip_content)

        assert count == 2
        examples_dir = testcase_dir / "examples"
        assert (examples_dir / "compliant" / "example1.html").exists()
        assert (examples_dir / "non-compliant" / "example1.html").exists()

    def test_extract_examples_zip_invalid(self, workspace: WorkspaceManager):
        """Test extracting examples from invalid ZIP raises error."""
        from wally_dev.exceptions import WorkspaceError

        with pytest.raises(WorkspaceError):
            workspace.extract_examples_zip("norm123", b"not a valid zip")

    def test_save_generated_testcase(self, workspace: WorkspaceManager):
        """Test saving a generated testcase."""
        generated = {
            "finder_py": "def find(html): return []",
            "validator_py": "def validate(el): return True",
            "code": "# combined code",
            "compliant_html": "<img alt='test'>",
            "non_compliant_html": "<img>",
        }

        testcase_dir = workspace.save_generated_testcase(
            norm_id="norm456",
            testcase_id="tc_generated_123",
            generated=generated,
        )

        assert testcase_dir.exists()
        assert (testcase_dir / "testcase.json").exists()
        assert (testcase_dir / "code" / "finder.py").exists()
        assert (testcase_dir / "code" / "validator.py").exists()
        assert (testcase_dir / "code" / "main.py").exists()
        assert (testcase_dir / "examples" / "compliant").exists()
        assert (testcase_dir / "examples" / "non-compliant").exists()

    def test_delete_norm_nonexistent(self, workspace: WorkspaceManager):
        """Test deleting a non-existent norm returns False."""
        result = workspace.delete_norm("nonexistent")
        assert result is False

    def test_list_norms_empty(self, workspace: WorkspaceManager):
        """Test listing norms when none exist."""
        norms = workspace.list_norms()
        assert norms == []

    def test_get_workspace_info_nonexistent(self, workspace: WorkspaceManager):
        """Test getting info for non-existent norm."""
        info = workspace.get_workspace_info("nonexistent")
        assert info["exists"] is False
        assert info["testcase_count"] == 0

    def test_load_all_testcases_empty(self, workspace: WorkspaceManager):
        """Test loading testcases when none exist."""
        workspace.ensure_norm_dir("empty_norm")
        testcases = workspace.load_all_testcases("empty_norm")
        assert testcases == []

    def test_load_testcase_with_code_files(
        self, workspace: WorkspaceManager, sample_testcase: TestCase
    ):
        """Test loading testcase reads code from files."""
        _create_testcase_dir(workspace, "norm789", sample_testcase)

        loaded = workspace.load_testcase("norm789", "tc123")

        # Should have loaded the testcase successfully
        assert loaded.id == "tc123"
        assert loaded.name == "Test Alt Text"


class TestWorkspaceChecksums:
    """Tests for checksum-based change detection."""

    def test_save_checksums(self, workspace: WorkspaceManager, sample_testcase: TestCase):
        """Test saving checksums for a norm."""
        _create_testcase_dir(workspace, "norm789", sample_testcase)

        checksums = workspace.save_checksums("norm789")

        assert "tc123" in checksums
        assert len(checksums["tc123"]) > 0
        # Should have checksums for code files
        assert any("finder.py" in path for path in checksums["tc123"])

    def test_save_checksums_excludes_pycache(
        self, workspace: WorkspaceManager, sample_testcase: TestCase
    ):
        """Test that save_checksums excludes __pycache__ and .pyc files."""
        _create_testcase_dir(workspace, "norm789", sample_testcase)

        # Create __pycache__ directory with .pyc file
        pycache_dir = workspace.get_testcase_code_dir("norm789", "tc123") / "__pycache__"
        pycache_dir.mkdir(parents=True, exist_ok=True)
        (pycache_dir / "finder.cpython-312.pyc").write_bytes(b"fake pyc content")

        checksums = workspace.save_checksums("norm789")

        # __pycache__ files should not be included
        for file_path in checksums.get("tc123", {}).keys():
            assert "__pycache__" not in file_path
            assert not file_path.endswith(".pyc")

    def test_load_checksums(self, workspace: WorkspaceManager, sample_testcase: TestCase):
        """Test loading saved checksums."""
        _create_testcase_dir(workspace, "norm789", sample_testcase)

        # Save checksums first
        workspace.save_checksums("norm789")

        # Load checksums
        loaded = workspace.load_checksums("norm789")

        assert "tc123" in loaded
        assert len(loaded["tc123"]) > 0

    def test_load_checksums_no_file(self, workspace: WorkspaceManager):
        """Test loading checksums when file doesn't exist."""
        workspace.ensure_norm_dir("norm789")

        loaded = workspace.load_checksums("norm789")

        assert loaded == {}

    def test_load_checksums_invalid_json(self, workspace: WorkspaceManager):
        """Test loading checksums with invalid JSON."""
        workspace.ensure_norm_dir("norm789")

        checksums_path = workspace._get_checksums_path("norm789")
        checksums_path.write_text("invalid json {{{")

        loaded = workspace.load_checksums("norm789")

        assert loaded == {}

    def test_get_locally_modified_testcases_no_checksums(
        self, workspace: WorkspaceManager, sample_testcase: TestCase
    ):
        """Test get_locally_modified_testcases when no checksums saved."""
        _create_testcase_dir(workspace, "norm789", sample_testcase)

        modified = workspace.get_locally_modified_testcases("norm789")

        assert modified == []

    def test_get_locally_modified_testcases_no_changes(
        self, workspace: WorkspaceManager, sample_testcase: TestCase
    ):
        """Test get_locally_modified_testcases when nothing changed."""
        _create_testcase_dir(workspace, "norm789", sample_testcase)

        # Save initial checksums
        workspace.save_checksums("norm789")

        # Check for modifications (none)
        modified = workspace.get_locally_modified_testcases("norm789")

        assert modified == []

    def test_get_locally_modified_testcases_with_modification(
        self, workspace: WorkspaceManager, sample_testcase: TestCase
    ):
        """Test get_locally_modified_testcases detects file changes."""
        _create_testcase_dir(workspace, "norm789", sample_testcase)

        # Save initial checksums
        workspace.save_checksums("norm789")

        # Modify a file
        code_dir = workspace.get_testcase_code_dir("norm789", "tc123")
        (code_dir / "finder.py").write_text("# Modified content")

        # Check for modifications
        modified = workspace.get_locally_modified_testcases("norm789")

        assert "tc123" in modified

    def test_get_locally_modified_testcases_with_new_file(
        self, workspace: WorkspaceManager, sample_testcase: TestCase
    ):
        """Test get_locally_modified_testcases detects new files."""
        _create_testcase_dir(workspace, "norm789", sample_testcase)

        # Save initial checksums
        workspace.save_checksums("norm789")

        # Add a new file
        code_dir = workspace.get_testcase_code_dir("norm789", "tc123")
        (code_dir / "runner.py").write_text("def run(): pass")

        # Check for modifications
        modified = workspace.get_locally_modified_testcases("norm789")

        assert "tc123" in modified

    def test_get_locally_modified_testcases_with_deleted_file(
        self, workspace: WorkspaceManager, sample_testcase: TestCase
    ):
        """Test get_locally_modified_testcases detects deleted files."""
        _create_testcase_dir(workspace, "norm789", sample_testcase)

        # Save initial checksums
        workspace.save_checksums("norm789")

        # Delete a file
        code_dir = workspace.get_testcase_code_dir("norm789", "tc123")
        (code_dir / "validator.py").unlink()

        # Check for modifications
        modified = workspace.get_locally_modified_testcases("norm789")

        assert "tc123" in modified

    def test_get_locally_modified_testcases_empty_dir(self, workspace: WorkspaceManager):
        """Test get_locally_modified_testcases with non-existent workspace."""
        modified = workspace.get_locally_modified_testcases("nonexistent")

        assert modified == []

    def test_get_testcase_changes_detailed(
        self, workspace: WorkspaceManager, sample_testcase: TestCase
    ):
        """Test get_testcase_changes returns detailed change info."""
        _create_testcase_dir(workspace, "norm789", sample_testcase)

        # Save initial checksums
        workspace.save_checksums("norm789")

        # Add a file, modify a file, delete a file
        code_dir = workspace.get_testcase_code_dir("norm789", "tc123")
        (code_dir / "runner.py").write_text("def run(): pass")  # added
        (code_dir / "finder.py").write_text("# Modified")  # modified
        (code_dir / "validator.py").unlink()  # deleted

        changes = workspace.get_testcase_changes("norm789", "tc123")

        assert "runner.py" in changes["added"][0]
        assert "finder.py" in changes["modified"][0]
        assert "validator.py" in changes["deleted"][0]

    def test_get_testcase_changes_no_changes(
        self, workspace: WorkspaceManager, sample_testcase: TestCase
    ):
        """Test get_testcase_changes with no modifications."""
        _create_testcase_dir(workspace, "norm789", sample_testcase)
        workspace.save_checksums("norm789")

        changes = workspace.get_testcase_changes("norm789", "tc123")

        assert changes["added"] == []
        assert changes["modified"] == []
        assert changes["deleted"] == []

    def test_get_testcase_changes_deleted_testcase(
        self, workspace: WorkspaceManager, sample_testcase: TestCase
    ):
        """Test get_testcase_changes for deleted testcase."""
        _create_testcase_dir(workspace, "norm789", sample_testcase)
        workspace.save_checksums("norm789")

        # Delete the whole testcase directory
        import shutil

        shutil.rmtree(workspace.get_testcase_dir("norm789", "tc123"))

        changes = workspace.get_testcase_changes("norm789", "tc123")

        assert len(changes["deleted"]) > 0

    def test_get_all_local_testcase_ids(
        self, workspace: WorkspaceManager, sample_testcase: TestCase
    ):
        """Test get_all_local_testcase_ids."""
        _create_testcase_dir(workspace, "norm789", sample_testcase)

        ids = workspace.get_all_local_testcase_ids("norm789")

        assert "tc123" in ids

    def test_get_all_local_testcase_ids_excludes_hidden(
        self, workspace: WorkspaceManager, sample_testcase: TestCase
    ):
        """Test get_all_local_testcase_ids excludes hidden directories."""
        _create_testcase_dir(workspace, "norm789", sample_testcase)

        # Create a hidden directory
        hidden_dir = workspace.get_testcases_dir("norm789") / ".hidden"
        hidden_dir.mkdir(parents=True, exist_ok=True)

        ids = workspace.get_all_local_testcase_ids("norm789")

        assert ".hidden" not in ids

    def test_get_all_local_testcase_ids_empty(self, workspace: WorkspaceManager):
        """Test get_all_local_testcase_ids with non-existent workspace."""
        ids = workspace.get_all_local_testcase_ids("nonexistent")

        assert ids == []

    def test_get_all_testcase_files(self, workspace: WorkspaceManager, sample_testcase: TestCase):
        """Test get_all_testcase_files returns all files."""
        _create_testcase_dir(workspace, "norm789", sample_testcase)

        files = workspace.get_all_testcase_files("norm789", "tc123")

        assert len(files) > 0
        # Should include code files
        assert any("finder.py" in f for f in files)

    def test_get_all_testcase_files_excludes_pycache(
        self, workspace: WorkspaceManager, sample_testcase: TestCase
    ):
        """Test get_all_testcase_files excludes __pycache__."""
        _create_testcase_dir(workspace, "norm789", sample_testcase)

        # Create __pycache__
        pycache_dir = workspace.get_testcase_code_dir("norm789", "tc123") / "__pycache__"
        pycache_dir.mkdir(parents=True, exist_ok=True)
        (pycache_dir / "test.pyc").write_bytes(b"fake")

        files = workspace.get_all_testcase_files("norm789", "tc123")

        assert not any("__pycache__" in f for f in files)

    def test_get_all_testcase_files_nonexistent(self, workspace: WorkspaceManager):
        """Test get_all_testcase_files with non-existent testcase."""
        files = workspace.get_all_testcase_files("norm789", "nonexistent")

        assert files == []


class TestWorkspaceFindTestcase:
    """Tests for find_testcase_folder function."""

    def test_find_testcase_folder_by_folder_name(
        self, workspace: WorkspaceManager, sample_testcase: TestCase
    ):
        """Test finding testcase by folder name."""
        _create_testcase_dir(workspace, "norm789", sample_testcase)

        result = workspace.find_testcase_folder("norm789", "tc123")

        assert result == "tc123"

    def test_find_testcase_folder_by_id(
        self, workspace: WorkspaceManager, sample_testcase: TestCase
    ):
        """Test finding testcase by ID in testcase.json."""
        # Create testcase with different folder name but same ID
        testcases_dir = workspace.get_testcases_dir("norm789")
        testcases_dir.mkdir(parents=True, exist_ok=True)

        folder_name = "custom-folder-name"
        testcase_dir = testcases_dir / folder_name
        testcase_dir.mkdir()

        json_path = testcase_dir / "testcase.json"
        json_path.write_text('{"id": "tc-unique-id", "name": "Test"}')

        result = workspace.find_testcase_folder("norm789", "tc-unique-id")

        assert result == folder_name

    def test_find_testcase_folder_not_found(self, workspace: WorkspaceManager):
        """Test finding non-existent testcase."""
        workspace.ensure_norm_dir("norm789")

        result = workspace.find_testcase_folder("norm789", "nonexistent")

        assert result is None

    def test_find_testcase_folder_nonexistent_norm(self, workspace: WorkspaceManager):
        """Test finding testcase in non-existent norm."""
        result = workspace.find_testcase_folder("nonexistent", "tc123")

        assert result is None

    def test_find_testcase_folder_invalid_json(self, workspace: WorkspaceManager):
        """Test finding testcase with invalid JSON."""
        testcases_dir = workspace.get_testcases_dir("norm789")
        testcases_dir.mkdir(parents=True, exist_ok=True)

        testcase_dir = testcases_dir / "bad-json"
        testcase_dir.mkdir()
        (testcase_dir / "testcase.json").write_text("invalid json")

        result = workspace.find_testcase_folder("norm789", "tc123")

        # Should not crash, just return None
        assert result is None


class TestWorkspaceAIGuide:
    """Tests for AI guide creation."""

    def test_create_ai_guide(self, workspace: WorkspaceManager):
        """Test creating AI testcase guide."""
        guide_path = workspace.create_ai_guide("norm123")

        assert guide_path.exists()
        content = guide_path.read_text()
        assert "norm123" in content or "testcase" in content.lower()


class TestWorkspaceHasChanges:
    """Tests for _has_changes method."""

    def test_has_changes_code_changed(self, workspace: WorkspaceManager):
        """Test _has_changes detects code changes."""
        original = TestCase(
            id="tc1",
            name="Test",
            rule_id="rule_test",
            code="original code",
            examples=[],
        )
        local = TestCase(
            id="tc1",
            name="Test",
            rule_id="rule_test",
            code="modified code",
            examples=[],
        )

        assert workspace._has_changes(original, local) is True

    def test_has_changes_no_changes(self, workspace: WorkspaceManager):
        """Test _has_changes returns False when no changes."""
        original = TestCase(
            id="tc1",
            name="Test",
            rule_id="rule_test",
            code="same code",
            examples=[
                ExampleTestCase(
                    id="ex1",
                    name="Example",
                    html="<html></html>",
                    expected_result="pass",
                    explanation="Test",
                )
            ],
        )
        local = TestCase(
            id="tc1",
            name="Test",
            rule_id="rule_test",
            code="same code",
            examples=[
                ExampleTestCase(
                    id="ex1",
                    name="Example",
                    html="<html></html>",
                    expected_result="pass",
                    explanation="Test",
                )
            ],
        )

        assert workspace._has_changes(original, local) is False

    def test_has_changes_example_count_different(self, workspace: WorkspaceManager):
        """Test _has_changes detects example count changes."""
        original = TestCase(
            id="tc1",
            name="Test",
            rule_id="rule_test",
            code="code",
            examples=[
                ExampleTestCase(
                    id="ex1",
                    name="Example",
                    html="<html></html>",
                    expected_result="pass",
                    explanation="Test",
                )
            ],
        )
        local = TestCase(
            id="tc1",
            name="Test",
            rule_id="rule_test",
            code="code",
            examples=[],  # No examples
        )

        assert workspace._has_changes(original, local) is True

    def test_has_changes_example_html_different(self, workspace: WorkspaceManager):
        """Test _has_changes detects example HTML changes."""
        original = TestCase(
            id="tc1",
            name="Test",
            rule_id="rule_test",
            code="code",
            examples=[
                ExampleTestCase(
                    id="ex1",
                    name="Example",
                    html="<html>Original</html>",
                    expected_result="pass",
                    explanation="Test",
                )
            ],
        )
        local = TestCase(
            id="tc1",
            name="Test",
            rule_id="rule_test",
            code="code",
            examples=[
                ExampleTestCase(
                    id="ex1",
                    name="Example",
                    html="<html>Modified</html>",
                    expected_result="pass",
                    explanation="Test",
                )
            ],
        )

        assert workspace._has_changes(original, local) is True

    def test_has_changes_new_example_id(self, workspace: WorkspaceManager):
        """Test _has_changes detects new example ID."""
        original = TestCase(
            id="tc1",
            name="Test",
            rule_id="rule_test",
            code="code",
            examples=[
                ExampleTestCase(
                    id="ex1",
                    name="Example",
                    html="<html></html>",
                    expected_result="pass",
                    explanation="Test",
                )
            ],
        )
        local = TestCase(
            id="tc1",
            name="Test",
            rule_id="rule_test",
            code="code",
            examples=[
                ExampleTestCase(
                    id="ex-new",  # Different ID
                    name="Example",
                    html="<html></html>",
                    expected_result="pass",
                    explanation="Test",
                )
            ],
        )

        assert workspace._has_changes(original, local) is True


class TestWorkspaceGetModifiedTestcases:
    """Tests for get_modified_testcases method."""

    def test_get_modified_testcases_with_new(
        self, workspace: WorkspaceManager, sample_testcase: TestCase
    ):
        """Test get_modified_testcases detects new testcases."""
        _create_testcase_dir(workspace, "norm789", sample_testcase)

        # Compare with empty original list
        modified = workspace.get_modified_testcases("norm789", [])

        assert len(modified) == 1
        assert modified[0].id == "tc123"

    def test_get_modified_testcases_with_changes(
        self, workspace: WorkspaceManager, sample_testcase: TestCase
    ):
        """Test get_modified_testcases detects changes."""
        _create_testcase_dir(workspace, "norm789", sample_testcase)

        # Create original with different code
        original = TestCase(
            id="tc123",
            name="Test Alt Text",
            rule_id="rule456",
            code="different code",
            examples=[],
        )

        modified = workspace.get_modified_testcases("norm789", [original])

        assert len(modified) == 1

    def test_get_modified_testcases_no_changes(
        self, workspace: WorkspaceManager, sample_testcase: TestCase
    ):
        """Test get_modified_testcases returns empty when no changes."""
        # Just ensure directory exists
        workspace.ensure_norm_dir("norm789")

        modified = workspace.get_modified_testcases("norm789", [sample_testcase])

        assert modified == []


class TestWorkspaceLoadWithVariousExtensions:
    """Tests for loading testcases with various file extensions."""

    def test_load_testcase_jsx_examples(self, workspace: WorkspaceManager):
        """Test loading testcase with JSX examples."""
        testcases_dir = workspace.get_testcases_dir("norm789")
        testcase_dir = testcases_dir / "tc-jsx"
        testcase_dir.mkdir(parents=True, exist_ok=True)

        # Create testcase.json
        (testcase_dir / "testcase.json").write_text(
            '{"id": "tc-jsx", "name": "JSX Test", "examples": []}'
        )

        # Create JSX examples
        examples_dir = testcase_dir / "examples"
        (examples_dir / "compliant").mkdir(parents=True, exist_ok=True)
        (examples_dir / "compliant" / "button.jsx").write_text(
            '<button aria-label="Test">Click</button>'
        )

        loaded = workspace.load_testcase("norm789", "tc-jsx")

        assert len(loaded.examples) == 1
        assert "compliant" in loaded.examples[0].expected_result.lower()

    def test_load_testcase_vue_examples(self, workspace: WorkspaceManager):
        """Test loading testcase with Vue examples."""
        testcases_dir = workspace.get_testcases_dir("norm789")
        testcase_dir = testcases_dir / "tc-vue"
        testcase_dir.mkdir(parents=True, exist_ok=True)

        (testcase_dir / "testcase.json").write_text(
            '{"id": "tc-vue", "name": "Vue Test", "examples": []}'
        )

        examples_dir = testcase_dir / "examples"
        (examples_dir / "non-compliant").mkdir(parents=True, exist_ok=True)
        (examples_dir / "non-compliant" / "component.vue").write_text(
            "<template><div></div></template>"
        )

        loaded = workspace.load_testcase("norm789", "tc-vue")

        assert len(loaded.examples) == 1
        assert "non-compliant" in loaded.examples[0].expected_result.lower()

    def test_load_testcase_without_id_uses_folder_name(self, workspace: WorkspaceManager):
        """Test loading testcase without id field uses folder name."""
        testcases_dir = workspace.get_testcases_dir("norm789")
        testcase_dir = testcases_dir / "legacy-folder"
        testcase_dir.mkdir(parents=True, exist_ok=True)

        # Create testcase.json without id
        (testcase_dir / "testcase.json").write_text('{"name": "Legacy Test"}')

        loaded = workspace.load_testcase("norm789", "legacy-folder")

        assert loaded.id == "legacy-folder"

    def test_load_testcase_finds_any_py_file(self, workspace: WorkspaceManager):
        """Test loading testcase finds any .py file if main.py doesn't exist."""
        testcases_dir = workspace.get_testcases_dir("norm789")
        testcase_dir = testcases_dir / "tc-any-py"
        testcase_dir.mkdir(parents=True, exist_ok=True)

        (testcase_dir / "testcase.json").write_text('{"id": "tc-any-py", "name": "Test"}')

        code_dir = testcase_dir / "code"
        code_dir.mkdir(parents=True, exist_ok=True)
        (code_dir / "custom_code.py").write_text("def find(): pass")

        loaded = workspace.load_testcase("norm789", "tc-any-py")

        assert loaded.code is not None
        assert "find" in loaded.code
