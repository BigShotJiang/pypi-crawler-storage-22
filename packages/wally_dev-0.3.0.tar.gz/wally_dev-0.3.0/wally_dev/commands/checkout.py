"""
Checkout command group for Wally Dev CLI.

Manages checkout of norms for local development.
"""

from datetime import datetime
from typing import Any, Optional

import click
from rich.console import Console
from rich.panel import Panel
from rich.progress import Progress, SpinnerColumn, TextColumn
from rich.table import Table

from ..config import LocalConfig, Settings
from ..constants import EXIT_ERROR_API, EXIT_ERROR_AUTH, EXIT_SUCCESS
from ..exceptions import NormLockedError, NormNotFoundError, NotLoggedInError, WallyDevError
from ..workspace import WorkspaceManager

console = Console()


# Valid targets for testcases
VALID_TARGETS = ["html", "react", "angular", "vue"]


@click.group("checkout", invoke_without_command=True)
@click.option(
    "--norm-id",
    "norm_id",
    required=False,
    default=None,
    help="ID da norma para fazer checkout (opcional, se não informado exibe lista)",
)
@click.option(
    "--target",
    "-t",
    type=click.Choice(VALID_TARGETS, case_sensitive=False),
    default=None,
    help="Target dos casos de teste a baixar (html, react, angular, vue)",
)
@click.option(
    "--force",
    "-f",
    is_flag=True,
    help="Força checkout mesmo se já existir localmente",
)
@click.pass_context
def checkout(ctx: click.Context, norm_id: Optional[str], target: str, force: bool) -> int:
    """
    Gerencia checkout de normas para desenvolvimento local.

    Quando executado sem subcomando, faz checkout de uma norma:
    bloqueia a norma no servidor e baixa todos os casos de teste
    para o diretório workspace local.

    Subcomandos disponíveis:
        release - Libera o checkout atual (desbloqueia norma e limpa workspace)

    Exemplos:
        wally-dev checkout                             # Seleção interativa
        wally-dev checkout --norm-id <id>              # Checkout direto
        wally-dev checkout --target html               # Checkout com target específico
        wally-dev checkout release                     # Libera checkout
        wally-dev checkout release --norm-id <id>     # Libera checkout específico
    """
    # If a subcommand was invoked, don't run the default checkout logic
    if ctx.invoked_subcommand is not None:
        return EXIT_SUCCESS

    # Run default checkout logic (get)
    return _do_checkout(norm_id, target, force)


@checkout.command("get")
@click.option(
    "--norm-id",
    "norm_id",
    required=False,
    default=None,
    help="ID da norma para fazer checkout (opcional, se não informado exibe lista)",
)
@click.option(
    "--target",
    "-t",
    type=click.Choice(VALID_TARGETS, case_sensitive=False),
    default=None,
    help="Target dos casos de teste a baixar (html, react, angular, vue)",
)
@click.option(
    "--force",
    "-f",
    is_flag=True,
    help="Força checkout mesmo se já existir localmente",
)
def checkout_get(norm_id: Optional[str], target: str, force: bool) -> int:
    """
    Faz checkout de uma norma para desenvolvimento local.

    Bloqueia a norma no servidor (impede edições via sistema) e
    baixa todos os casos de teste para o diretório workspace local.

    Se --norm-id não for informado, exibe a lista de normas disponíveis
    para seleção interativa.

    Estrutura criada:
        ./workspace/[normId]/testCases/
            [testCaseId]/
                testcase.json  - Dados do caso de teste
                code/          - Código de implementação
                examples/      - Exemplos

    Exemplo:
        wally-dev checkout get
        wally-dev checkout get --norm-id 507f1f77bcf86cd799439011
        wally-dev checkout get --target react
    """
    return _do_checkout(norm_id, target, force)


@checkout.command("release")
@click.option(
    "--norm-id",
    "norm_id",
    required=False,
    default=None,
    help="ID da norma para liberar (opcional, se houver apenas uma usa automaticamente)",
)
@click.option(
    "--force",
    "-f",
    is_flag=True,
    help="Força release sem confirmação",
)
@click.option(
    "--force-unlock",
    is_flag=True,
    help="Força desbloqueio mesmo se bloqueada por outro usuário (requer permissão admin)",
)
def checkout_release(norm_id: Optional[str], force: bool, force_unlock: bool) -> int:
    """
    Libera o checkout atual de uma norma.

    Desbloqueia a norma no servidor e remove o workspace local,
    descartando todas as alterações não enviadas.

    Se --norm-id não for informado e houver apenas uma norma em checkout,
    usa essa norma automaticamente. Se houver múltiplas, exibe lista
    para seleção.

    Também detecta normas bloqueadas no servidor que não estão no config local
    (ex: checkout feito em outra sessão/máquina).

    Exemplo:
        wally-dev checkout release
        wally-dev checkout release --norm-id 507f1f77bcf86cd799439011
        wally-dev checkout release --force
        wally-dev checkout release --force-unlock  # Força desbloqueio (admin)
    """
    config = LocalConfig()
    settings = Settings()
    workspace = WorkspaceManager()

    # Check login
    if not config.is_logged_in:
        raise NotLoggedInError()

    try:
        # Get locked norms from local config
        locked_norms = config.get_locked_norms() or {}

        # Also check API for norms locked by current user (may be out of sync)
        api_locked_norms: dict[str, Any] = {}
        with config.create_api_client(settings) as client:
            try:
                all_norms = client.list_norms()
                for norm in all_norms:
                    if norm.locked_by == config.user_id:
                        api_locked_norms[norm.id] = {
                            "norm_name": norm.name,
                            "checkout_at": "N/A (servidor)",
                            "testcase_count": 0,
                        }
            except WallyDevError:
                pass  # If API fails, proceed with local only

        # Merge: API norms that aren't in local config
        for norm_id_api, info in api_locked_norms.items():
            if norm_id_api not in locked_norms:
                locked_norms[norm_id_api] = info

        if not locked_norms:
            console.print(
                Panel(
                    "[yellow]Nenhuma norma em checkout.[/yellow]\n\n"
                    "[dim]Use 'wally-dev checkout' para fazer checkout de uma norma.[/dim]",
                    title="[bold yellow]Sem Checkout[/bold yellow]",
                    border_style="yellow",
                )
            )
            return EXIT_SUCCESS

        # If norm_id not provided, try to auto-select
        if not norm_id:
            if len(locked_norms) == 1:
                norm_id = list(locked_norms.keys())[0]
            else:
                norm_id = _select_locked_norm_interactive(locked_norms)
                if not norm_id:
                    return EXIT_SUCCESS

        # Check if norm is actually in checkout (local or API)
        if norm_id not in locked_norms:
            console.print(
                Panel(
                    f"[red]Norma '{norm_id}' não está em checkout.[/red]\n\n"
                    "[dim]Use 'wally-dev status' para ver normas em checkout.[/dim]",
                    title="[bold red]Norma Não Encontrada[/bold red]",
                    border_style="red",
                )
            )
            return EXIT_ERROR_API

        norm_info = locked_norms[norm_id]
        norm_name = norm_info.get("norm_name", norm_id)

        # Confirm release
        if not force:
            console.print(
                Panel(
                    f"[yellow]⚠️ Você está prestes a liberar o checkout da norma:[/yellow]\n\n"
                    f"[dim]Norma:[/dim] {norm_name}\n"
                    f"[dim]ID:[/dim] {norm_id}\n"
                    f"[dim]Checkout em:[/dim] {norm_info.get('checkout_at', 'N/A')}\n"
                    f"[dim]Casos de teste:[/dim] {norm_info.get('testcase_count', 0)}\n\n"
                    "[bold red]Todas as alterações locais não enviadas serão perdidas![/bold red]",
                    title="[bold yellow]Confirmar Release[/bold yellow]",
                    border_style="yellow",
                )
            )

            if not click.confirm("Deseja continuar?", default=False):
                console.print("[yellow]Operação cancelada.[/yellow]")
                return EXIT_SUCCESS

        unlock_success = False
        with config.create_api_client(settings) as client:
            with Progress(
                SpinnerColumn(),
                TextColumn("[progress.description]{task.description}"),
                console=console,
            ) as progress:
                task = progress.add_task("Desbloqueando norma no servidor...", total=None)

                # Unlock norm on server
                try:
                    client.unlock_norm(norm_id, force=force_unlock)
                    unlock_success = True
                except WallyDevError as e:
                    progress.stop()
                    # Show error clearly
                    console.print(
                        f"\n[red]✗ Não foi possível desbloquear a norma no servidor:[/red]\n"
                        f"[red]{e.user_message}[/red]\n"
                    )
                    if not force_unlock and "outro usuário" in e.user_message.lower():
                        console.print(
                            "[dim]Dica: Use --force-unlock para forçar o desbloqueio (requer permissão admin)[/dim]\n"
                        )

                    # Release must succeed on server - no local-only cleanup allowed
                    console.print(
                        Panel(
                            "[red]Release abortado para evitar estado inconsistente.[/red]\n\n"
                            "[dim]A norma permanece bloqueada no servidor e o workspace local não foi alterado.[/dim]\n\n"
                            "[bold]Opções:[/bold]\n"
                            "  • Tente novamente mais tarde\n"
                            "  • Use [cyan]--force-unlock[/cyan] se tiver permissão admin\n"
                            "  • Contate o administrador para desbloquear manualmente",
                            title="[bold red]Release Falhou[/bold red]",
                            border_style="red",
                        )
                    )
                    return EXIT_ERROR_API

                # Delete local workspace
                progress.update(task, description="Removendo workspace local...")
                deleted = workspace.delete_norm(norm_id)

                # Remove from local tracking
                progress.update(task, description="Atualizando configuração...")
                config.remove_locked_norm(norm_id)

        # Success output
        console.print()
        if unlock_success:
            console.print(
                Panel(
                    f"[green]✓ Checkout liberado com sucesso![/green]\n\n"
                    f"[dim]Norma:[/dim] {norm_name}\n"
                    f"[dim]ID:[/dim] {norm_id}\n"
                    f"[dim]Workspace removido:[/dim] {'Sim' if deleted else 'Não existia'}",
                    title="[bold green]Release Completo[/bold green]",
                    border_style="green",
                )
            )
            console.print("\n[dim]A norma foi desbloqueada e está disponível para edição.[/dim]\n")
        else:
            console.print(
                Panel(
                    f"[yellow]⚠️ Workspace local removido, mas norma ainda bloqueada no servidor.[/yellow]\n\n"
                    f"[dim]Norma:[/dim] {norm_name}\n"
                    f"[dim]ID:[/dim] {norm_id}\n"
                    f"[dim]Workspace removido:[/dim] {'Sim' if deleted else 'Não existia'}",
                    title="[bold yellow]Release Parcial[/bold yellow]",
                    border_style="yellow",
                )
            )

        return EXIT_SUCCESS

    except NotLoggedInError as e:
        console.print(
            Panel(
                f"[red]✗ {e.user_message}[/red]\n\n[dim]{e.hint}[/dim]",
                title="[bold red]Não Autenticado[/bold red]",
                border_style="red",
            )
        )
        return EXIT_ERROR_AUTH

    except WallyDevError as e:
        console.print(
            Panel(
                f"[red]✗ {e.user_message}[/red]",
                title="[bold red]Erro[/bold red]",
                border_style="red",
            )
        )
        return e.exit_code

    except Exception as e:
        console.print(f"[red]Erro inesperado: {e}[/red]")
        return EXIT_ERROR_API


def _do_checkout(norm_id: Optional[str], target: Optional[str], force: bool) -> int:
    """
    Execute checkout logic.

    Args:
        norm_id: Norm ID to checkout (optional)
        target: Target type for testcases (html, react, angular, vue). If None, prompts interactively.
        force: Force checkout even if already exists locally

    Returns:
        Exit code
    """
    config = LocalConfig()
    settings = Settings()
    workspace = WorkspaceManager()

    # Check login
    if not config.is_logged_in:
        raise NotLoggedInError()

    # If target not provided, show interactive selection
    if not target:
        target = _select_target_interactive()
        if not target:
            return EXIT_ERROR_API
    else:
        # Show banner for explicitly specified target
        console.print(
            Panel(
                f"[bold]Target selecionado:[/bold] [cyan]{target.upper()}[/cyan]\n\n"
                f"[dim]Serão baixados apenas testcases compatíveis com {target.upper()}.[/dim]",
                title="[bold cyan]🎯 Target[/bold cyan]",
                border_style="cyan",
            )
        )

    try:
        with config.create_api_client(settings) as client:
            # If norm_id not provided, show interactive selection
            if not norm_id:
                norm_id = _select_norm_interactive(client, config)
                if not norm_id:
                    return EXIT_ERROR_API

            # Check if already checked out locally
            if config.is_norm_locked_locally(norm_id) and not force:
                info = workspace.get_workspace_info(norm_id)
                console.print(
                    Panel(
                        f"[yellow]Esta norma já está em checkout local.[/yellow]\n\n"
                        f"[dim]Caminho:[/dim] {info['path']}\n"
                        f"[dim]Casos de teste:[/dim] {info['testcase_count']}\n\n"
                        f"[dim]Use --force para baixar novamente, "
                        f"'wally-dev push' para enviar alterações, ou "
                        f"'wally-dev checkout release' para liberar.[/dim]",
                        title="[bold yellow]Norma já em checkout[/bold yellow]",
                        border_style="yellow",
                    )
                )
                return EXIT_SUCCESS

            with Progress(
                SpinnerColumn(),
                TextColumn("[progress.description]{task.description}"),
                console=console,
            ) as progress:
                # Get norm info
                task = progress.add_task("Buscando informações da norma...", total=None)
                norm = client.get_norm(norm_id)
                progress.update(task, completed=True)

                # Check if norm is locked by someone else (not the current user)
                already_locked_by_me = norm.locked_by and norm.locked_by == config.user_id

                if norm.locked_by and not already_locked_by_me:
                    progress.stop()
                    raise NormLockedError(
                        message=f"Norma está bloqueada por outro usuário: {norm.locked_by}"
                    )

                # If locked by me but no local checkout, offer reconnect
                if (
                    already_locked_by_me
                    and not config.is_norm_locked_locally(norm_id)
                    and not force
                ):
                    progress.stop()
                    console.print(
                        Panel(
                            f"[cyan]Esta norma já está bloqueada por você no servidor,[/cyan]\n"
                            f"[cyan]mas não há checkout local.[/cyan]\n\n"
                            f"[dim]Norma:[/dim] {norm.name}\n"
                            f"[dim]ID:[/dim] {norm_id}\n\n"
                            f"[bold]Opções:[/bold]\n"
                            f"  [green]1.[/green] Reconectar (apenas vincular, sem baixar arquivos)\n"
                            f"  [yellow]2.[/yellow] Baixar novamente (download completo)\n"
                            f"  [red]0.[/red] Cancelar",
                            title="[bold cyan]🔗 Reconectar Checkout[/bold cyan]",
                            border_style="cyan",
                        )
                    )

                    while True:
                        try:
                            selection = click.prompt("Selecione uma opção", default="1")
                            selected = int(selection)

                            if selected == 0:
                                console.print("[yellow]Operação cancelada.[/yellow]")
                                return EXIT_SUCCESS
                            elif selected == 1:
                                # Reconnect only - just track locally without download
                                config.add_locked_norm(
                                    norm_id,
                                    {
                                        "norm_name": norm.name,
                                        "checkout_at": datetime.now().isoformat(),
                                        "testcase_count": 0,
                                        "examples_count": 0,
                                        "target": target,
                                        "reconnected": True,
                                    },
                                )
                                workspace.ensure_norm_dir(norm_id)

                                console.print(
                                    Panel(
                                        f"[green]✓ Reconectado com sucesso![/green]\n\n"
                                        f"[dim]Norma:[/dim] {norm.name}\n"
                                        f"[dim]ID:[/dim] {norm_id}\n"
                                        f"[dim]Target:[/dim] {target}\n\n"
                                        f"[yellow]⚠️ Workspace vazio - use --force para baixar arquivos.[/yellow]",
                                        title="[bold green]Checkout Reconectado[/bold green]",
                                        border_style="green",
                                    )
                                )
                                return EXIT_SUCCESS
                            elif selected == 2:
                                # Continue with full download
                                break
                            else:
                                console.print("[red]Opção inválida.[/red]")
                        except ValueError:
                            console.print("[red]Por favor, digite um número válido.[/red]")

                    # Restart progress for download
                    progress = Progress(
                        SpinnerColumn(),
                        TextColumn("[progress.description]{task.description}"),
                        console=console,
                    )
                    progress.start()
                    task = progress.add_task("Preparando download...", total=None)

                # Lock the norm (only if not already locked by me)
                if not already_locked_by_me:
                    progress.update(task, description="Bloqueando norma no servidor...")
                    client.lock_norm(norm_id)
                else:
                    progress.update(task, description="Norma já está bloqueada por você...")

                # Download test cases as ZIP
                progress.update(task, description=f"Baixando casos de teste ({target})...")
                try:
                    zip_content = client.export_testcases_zip(norm_id, target=target)

                    # Extract to workspace
                    progress.update(task, description="Extraindo casos de teste...")
                    count = workspace.extract_testcases_zip(norm_id, zip_content)
                except Exception as e:
                    # If export fails (e.g., no testcases), continue with count=0
                    console.print(f"[dim]Aviso (testcases): {e}[/dim]")
                    count = 0
                    workspace.ensure_norm_dir(norm_id)

                # Download examples as ZIP (filtered by target)
                progress.update(task, description=f"Baixando examples ({target})...")
                examples_count = 0
                try:
                    examples_zip = client.export_examples_zip(norm_id, target=target)

                    # Extract examples to workspace
                    progress.update(task, description="Extraindo examples...")
                    examples_count = workspace.extract_examples_zip(norm_id, examples_zip)
                except Exception as e:
                    # If export fails (e.g., no examples), continue
                    console.print(f"[dim]Aviso (examples): {e}[/dim]")

                # Create AI guide for development assistance
                progress.update(task, description="Criando guia de desenvolvimento...")
                workspace.create_ai_guide(norm_id)

                # Save checksums for change detection
                progress.update(task, description="Salvando checksums...")
                workspace.save_checksums(norm_id)

                # Track locally
                config.add_locked_norm(
                    norm_id,
                    {
                        "norm_name": norm.name,
                        "checkout_at": datetime.now().isoformat(),
                        "testcase_count": count,
                        "examples_count": examples_count,
                        "target": target,
                    },
                )

        # Success output
        console.print()
        console.print(
            Panel(
                f"[green]✓ Checkout realizado com sucesso![/green]\n\n"
                f"[dim]Norma:[/dim] {norm.name}\n"
                f"[dim]ID:[/dim] {norm_id}\n"
                f"[dim]Target:[/dim] {target}\n"
                f"[dim]Casos de teste:[/dim] {count}\n"
                f"[dim]Examples:[/dim] {examples_count}",
                title="[bold green]Checkout Completo[/bold green]",
                border_style="green",
            )
        )

        workspace_info = workspace.get_workspace_info(norm_id)
        console.print(f"\n[dim]Workspace:[/dim] {workspace_info['path']}")

        # List extracted test cases from workspace
        if count > 0:
            testcases_dir = workspace.get_testcases_dir(norm_id)
            testcase_dirs = [d for d in testcases_dir.iterdir() if d.is_dir()]

            console.print("\n[bold]Casos de teste baixados:[/bold]")
            table = Table(show_header=True, header_style="bold cyan")
            table.add_column("ID", style="dim")
            table.add_column("Arquivos", justify="right")

            for tc_dir in sorted(testcase_dirs)[:10]:  # Show first 10
                files = list(tc_dir.iterdir())
                table.add_row(
                    tc_dir.name[:20] + ("..." if len(tc_dir.name) > 20 else ""),
                    str(len(files)),
                )

            if len(testcase_dirs) > 10:
                table.add_row("...", f"+ {len(testcase_dirs) - 10}")

            console.print(table)

        console.print("\n[dim]Próximos passos:[/dim]")
        console.print(f"  • Edite os arquivos em [cyan]./workspace/{norm_id}/testCases/[/cyan]")
        console.print(
            "  • Use [cyan]wally-dev run --testcase <ID> --example <ID>[/cyan] para testar"
        )
        console.print(
            f"  • Use [cyan]wally-dev push --norm-id {norm_id}[/cyan] para enviar alterações"
        )
        console.print("  • Use [cyan]wally-dev checkout release[/cyan] para liberar a norma\n")

        return EXIT_SUCCESS

    except NotLoggedInError as e:
        console.print(
            Panel(
                f"[red]✗ {e.user_message}[/red]\n\n[dim]{e.hint}[/dim]",
                title="[bold red]Não Autenticado[/bold red]",
                border_style="red",
            )
        )
        return EXIT_ERROR_AUTH

    except NormNotFoundError as e:
        console.print(
            Panel(
                f"[red]✗ {e.user_message}[/red]\n\n[dim]{e.hint}[/dim]",
                title="[bold red]Norma Não Encontrada[/bold red]",
                border_style="red",
            )
        )
        return EXIT_ERROR_API

    except NormLockedError as e:
        console.print(
            Panel(
                f"[red]✗ {e.user_message}[/red]\n\n[dim]{e.hint}[/dim]",
                title="[bold red]Norma Bloqueada[/bold red]",
                border_style="red",
            )
        )
        return EXIT_ERROR_API

    except WallyDevError as e:
        console.print(
            Panel(
                f"[red]✗ {e.user_message}[/red]",
                title="[bold red]Erro[/bold red]",
                border_style="red",
            )
        )
        return e.exit_code

    except Exception as e:
        console.print(f"[red]Erro inesperado: {e}[/red]")
        return EXIT_ERROR_API


def _select_norm_interactive(client: Any, config: LocalConfig) -> Optional[str]:
    """
    Display norms list and let user select one interactively.

    Args:
        client: WallyDevApiClient instance
        config: LocalConfig instance

    Returns:
        Selected norm ID or None if cancelled/no norms
    """
    console.print("\n[bold cyan]📋 Selecionar Norma para Checkout[/bold cyan]\n")
    console.print("[dim]Buscando normas disponíveis...[/dim]\n")

    norms = client.list_norms()

    if not norms:
        console.print(
            Panel(
                "[yellow]Nenhuma norma disponível.[/yellow]\n\n"
                "[dim]Verifique se você tem acesso a normas nesta organização.[/dim]",
                title="[bold yellow]Sem Normas[/bold yellow]",
                border_style="yellow",
            )
        )
        return None

    # Get locally locked norms to mark them
    locally_locked = config.get_locked_norms() or {}

    # Display norms table
    table = Table(
        title="📋 Normas Disponíveis",
        show_header=True,
        header_style="bold cyan",
    )
    table.add_column("#", style="dim", width=4, justify="right")
    table.add_column("Nome", style="white")
    table.add_column("ID", style="dim")
    table.add_column("Status", width=12)
    table.add_column("", width=3)  # For markers

    for i, norm in enumerate(norms, start=1):
        is_local = norm.id in locally_locked
        is_locked = bool(norm.locked_by)

        # Status indicator
        if is_locked:
            if norm.locked_by == config.user_id:
                status = "[yellow]🔒 Você[/yellow]"
            else:
                status = "[red]🔒 Outro[/red]"
        else:
            status = "[green]✓ Livre[/green]"

        marker = "[cyan]↓[/cyan]" if is_local else ""

        table.add_row(
            str(i),
            norm.name[:30] + ("..." if len(norm.name) > 30 else ""),
            norm.id[:20] + "..." if len(norm.id) > 20 else norm.id,
            status,
            marker,
        )

    console.print(table)
    console.print("\n[dim]↓ = já em checkout local[/dim]")
    console.print(f"[dim]Total: {len(norms)} norma(s)[/dim]\n")

    # Prompt for selection
    while True:
        try:
            selection = click.prompt("Selecione o número da norma (0 para cancelar)")
            selected_index = int(selection)

            if selected_index == 0:
                console.print("[yellow]Operação cancelada.[/yellow]")
                return None

            if 1 <= selected_index <= len(norms):
                selected_norm = norms[selected_index - 1]
                selected_id: str = selected_norm.id
                return selected_id
            else:
                console.print(
                    f"[red]Número inválido. Digite um número entre 1 e {len(norms)}, "
                    f"ou 0 para cancelar.[/red]"
                )
        except ValueError:
            console.print("[red]Por favor, digite um número válido.[/red]")


def _select_locked_norm_interactive(locked_norms: dict) -> Optional[str]:
    """
    Display locked norms list and let user select one interactively.

    Args:
        locked_norms: Dictionary of locked norms {norm_id: info}

    Returns:
        Selected norm ID or None if cancelled
    """
    console.print("\n[bold cyan]📋 Selecionar Norma para Liberar[/bold cyan]\n")

    # Display norms table
    table = Table(
        title="📋 Normas em Checkout",
        show_header=True,
        header_style="bold cyan",
    )
    table.add_column("#", style="dim", width=4, justify="right")
    table.add_column("Nome", style="white")
    table.add_column("ID", style="dim")
    table.add_column("Checkout em", style="dim")
    table.add_column("TCs", justify="right")

    norm_ids = list(locked_norms.keys())
    for i, norm_id in enumerate(norm_ids, start=1):
        info = locked_norms[norm_id]
        checkout_at = info.get("checkout_at", "N/A")
        if checkout_at != "N/A":
            # Format date
            try:
                from datetime import datetime as dt

                checkout_dt = dt.fromisoformat(checkout_at)
                checkout_at = checkout_dt.strftime("%d/%m/%Y %H:%M")
            except (ValueError, TypeError):
                pass

        table.add_row(
            str(i),
            info.get("norm_name", norm_id)[:30],
            norm_id[:20] + "..." if len(norm_id) > 20 else norm_id,
            checkout_at,
            str(info.get("testcase_count", 0)),
        )

    console.print(table)
    console.print(f"\n[dim]Total: {len(norm_ids)} norma(s) em checkout[/dim]\n")

    # Prompt for selection
    while True:
        try:
            selection = click.prompt("Selecione o número da norma (0 para cancelar)")
            selected_index = int(selection)

            if selected_index == 0:
                console.print("[yellow]Operação cancelada.[/yellow]")
                return None

            if 1 <= selected_index <= len(norm_ids):
                return norm_ids[selected_index - 1]
            else:
                console.print(
                    f"[red]Número inválido. Digite um número entre 1 e {len(norm_ids)}, "
                    f"ou 0 para cancelar.[/red]"
                )
        except ValueError:
            console.print("[red]Por favor, digite um número válido.[/red]")


def _select_target_interactive() -> Optional[str]:
    """
    Display available targets and let user select one interactively.

    Returns:
        Selected target or None if cancelled
    """
    console.print("\n[bold cyan]🎯 Selecionar Target dos Testcases[/bold cyan]\n")

    # Target descriptions
    target_info = {
        "html": ("HTML", "Páginas HTML estáticas/renderizadas"),
        "react": ("React", "Componentes JSX/TSX"),
        "angular": ("Angular", "Templates Angular (HTML + diretivas)"),
        "vue": ("Vue", "Single File Components (.vue)"),
    }

    # Display targets table
    table = Table(
        title="🎯 Targets Disponíveis",
        show_header=True,
        header_style="bold cyan",
    )
    table.add_column("#", style="dim", width=4, justify="right")
    table.add_column("Target", style="bold white")
    table.add_column("Descrição", style="dim")

    for i, (_target_key, (display_name, description)) in enumerate(target_info.items(), start=1):
        table.add_row(str(i), display_name, description)

    console.print(table)
    console.print(
        "\n[dim]Cada target baixa apenas os testcases compatíveis com essa tecnologia.[/dim]\n"
    )

    # Prompt for selection
    targets_list = list(target_info.keys())
    while True:
        try:
            selection = click.prompt(
                "Selecione o número do target (0 para cancelar)",
                default="1",
            )
            selected_index = int(selection)

            if selected_index == 0:
                console.print("[yellow]Operação cancelada.[/yellow]")
                return None

            if 1 <= selected_index <= len(targets_list):
                selected_target = targets_list[selected_index - 1]
                console.print(
                    f"\n[green]✓ Target selecionado:[/green] [bold]{selected_target.upper()}[/bold]\n"
                )
                return selected_target
            else:
                console.print(
                    f"[red]Número inválido. Digite um número entre 1 e {len(targets_list)}, "
                    f"ou 0 para cancelar.[/red]"
                )
        except ValueError:
            console.print("[red]Por favor, digite um número válido.[/red]")
