"""
Push command for Wally Dev CLI.

Uploads modified test cases to the server.
"""

from typing import Optional

import click
from rich.console import Console
from rich.panel import Panel
from rich.progress import Progress, SpinnerColumn, TextColumn
from rich.prompt import Confirm
from rich.table import Table

from ..config import LocalConfig, Settings
from ..constants import EXIT_ERROR_API, EXIT_ERROR_AUTH, EXIT_SUCCESS
from ..exceptions import NotLoggedInError, WallyDevError
from ..workspace import WorkspaceManager

console = Console()


@click.command("push")
@click.option(
    "--norm-id",
    "norm_id",
    required=False,
    default=None,
    help="ID da norma para fazer push (opcional, usa a norma em checkout)",
)
@click.option(
    "--force",
    "-f",
    is_flag=True,
    help="Força push sem confirmação",
)
@click.option(
    "--all",
    "upload_all",
    is_flag=True,
    help="Envia todos os arquivos, não apenas os modificados (útil quando o servidor não tem os arquivos)",
)
def push(norm_id: Optional[str], force: bool, upload_all: bool) -> int:
    """
    Envia alterações dos casos de teste para o servidor.

    Faz upload dos casos de teste modificados localmente.
    A norma permanece bloqueada após o push.

    Para desbloquear a norma, use 'wally-dev checkout release'.

    Se --norm-id não for informado e houver apenas uma norma em checkout,
    usa essa norma automaticamente. Se houver múltiplas, exibe lista
    para seleção.

    Exemplo:
        wally-dev push
        wally-dev push --norm-id 507f1f77bcf86cd799439011
    """
    config = LocalConfig()
    settings = Settings()
    workspace = WorkspaceManager()

    # Check login
    if not config.is_logged_in:
        raise NotLoggedInError()

    # If norm_id not provided, try to detect from local checkout
    if not norm_id:
        norm_id = _get_norm_for_push(config)
        if not norm_id:
            return EXIT_ERROR_API

    # Check if norm is checked out locally
    if not config.is_norm_locked_locally(norm_id):
        console.print(
            Panel(
                f"[yellow]Esta norma não está em checkout local.[/yellow]\n\n"
                f"[dim]Use 'wally-dev checkout --norm-id {norm_id}' primeiro.[/dim]",
                title="[bold yellow]Norma Não Encontrada[/bold yellow]",
                border_style="yellow",
            )
        )
        return EXIT_SUCCESS

    try:
        # Get testcases to process
        if upload_all:
            # With --all flag, get all testcases in workspace
            testcase_ids = workspace.get_all_local_testcase_ids(norm_id)
            if not testcase_ids:
                console.print(
                    Panel(
                        "[yellow]Nenhum caso de teste encontrado no workspace.[/yellow]",
                        title="[bold yellow]Workspace Vazio[/bold yellow]",
                        border_style="yellow",
                    )
                )
                return EXIT_SUCCESS
            console.print(
                f"\n[bold]Enviando todos os arquivos de {len(testcase_ids)} casos de teste...[/bold]\n"
            )
        else:
            # Default: check for locally modified testcases using checksums (fast, no API call)
            testcase_ids = workspace.get_locally_modified_testcases(norm_id)

        if not testcase_ids and not upload_all:
            # No local modifications detected
            console.print(
                Panel(
                    "[yellow]Nenhuma alteração local detectada.[/yellow]\n\n"
                    "[dim]Os arquivos não foram modificados desde o checkout.[/dim]",
                    title="[bold yellow]Sem Alterações[/bold yellow]",
                    border_style="yellow",
                )
            )

            # Still allow to continue without changes
            if not force:
                console.print("[dim]Use 'wally-dev checkout release' para liberar a norma.[/dim]\n")
            return EXIT_SUCCESS

        # Show which testcases have local modifications
        if not upload_all:
            console.print(
                f"\n[bold]Casos de teste modificados localmente ({len(testcase_ids)}):[/bold]"
            )
            for tc_id in testcase_ids[:10]:
                changes = workspace.get_testcase_changes(norm_id, tc_id)
                change_summary = []
                if changes["added"]:
                    change_summary.append(f"+{len(changes['added'])}")
                if changes["modified"]:
                    change_summary.append(f"~{len(changes['modified'])}")
                if changes["deleted"]:
                    change_summary.append(f"-{len(changes['deleted'])}")
                console.print(f"  • {tc_id[:20]}... [{', '.join(change_summary) or 'modificado'}]")
            if len(testcase_ids) > 10:
                console.print(f"  ... e mais {len(testcase_ids) - 10}")
            console.print()

        with config.create_api_client(settings) as client:
            with Progress(
                SpinnerColumn(),
                TextColumn("[progress.description]{task.description}"),
                console=console,
            ) as progress:
                # Load testcases for upload
                task_desc = (
                    "Carregando casos de teste..."
                    if upload_all
                    else "Carregando casos de teste modificados..."
                )
                task = progress.add_task(task_desc, total=None)
                modified = []  # List of (testcase, folder_name) tuples
                for folder_name in testcase_ids:
                    try:
                        tc = workspace.load_testcase(norm_id, folder_name)
                        modified.append((tc, folder_name))
                    except Exception as e:
                        console.print(
                            f"[dim]Aviso: Não foi possível carregar {folder_name}: {e}[/dim]"
                        )
                progress.update(task, completed=True)
                progress.update(task, completed=True)

            # Show changes summary
            console.print()
            if modified:
                console.print(
                    f"[bold]Pronto para enviar ({len(modified)} caso(s) de teste):[/bold]"
                )
                table = Table(show_header=True, header_style="bold cyan")
                table.add_column("ID", style="dim")
                table.add_column("Nome")
                table.add_column("Código", justify="center")
                table.add_column("Exemplos", justify="right")

                for tc, _ in modified:
                    table.add_row(
                        tc.id[:12] + "...",
                        tc.name[:40] + ("..." if len(tc.name) > 40 else ""),
                        "✓" if tc.code else "—",
                        str(len(tc.examples)),
                    )

                console.print(table)
                console.print()

            # Confirm push
            if not force and modified:
                if not Confirm.ask(f"Enviar {len(modified)} caso(s) de teste modificado(s)?"):
                    console.print("[dim]Push cancelado.[/dim]")
                    return EXIT_SUCCESS

            with Progress(
                SpinnerColumn(),
                TextColumn("[progress.description]{task.description}"),
                console=console,
            ) as progress:
                # Sync test case files
                if modified:
                    task = progress.add_task("Sincronizando arquivos...", total=None)

                    for tc, folder_name in modified:
                        # Get existing files from server to map by path
                        try:
                            server_files = client.get_testcase_files(tc.id)
                            # Map by path for accurate matching
                            file_map = {f.get("path"): f for f in server_files if f.get("path")}
                        except Exception:
                            file_map = {}

                        # Get norm and rule IDs for creating new files
                        norm_id_for_file = norm_id
                        rule_id_for_file = tc.rule_id if hasattr(tc, "rule_id") else None
                        # Use folder_name for local paths (e.g., 'tc-5-1-1-indicador-de-foco-visivel')
                        # Use tc.id for API calls (MongoDB ObjectId)

                        # Determine which files to upload
                        if upload_all:
                            # With --all, upload ALL local files
                            all_local_files = workspace.get_all_testcase_files(norm_id, folder_name)
                            files_to_upload = all_local_files
                        else:
                            # Get file changes for this testcase
                            changes = workspace.get_testcase_changes(norm_id, folder_name)
                            # Process added files
                            for rel_path in changes.get("added", []):
                                file_path = (
                                    workspace.get_testcase_dir(norm_id, folder_name) / rel_path
                                )
                                if file_path.exists():
                                    file_name = file_path.name
                                    with open(file_path, "rb") as f:
                                        content = f.read()
                                    try:
                                        client.create_and_upload_file(
                                            name=file_name,
                                            path=rel_path,
                                            content=content,
                                            testcase_id=tc.id,
                                            norm_id=norm_id_for_file,
                                            rule_id=rule_id_for_file,
                                        )
                                        console.print(f"  [green]✓[/green] {rel_path} (novo)")
                                    except Exception as e:
                                        console.print(f"  [red]✗[/red] {rel_path}: {e}")
                            # Use modified files list
                            files_to_upload = changes.get("modified", [])

                        # Upload files (all files for --all, modified files otherwise)
                        for rel_path in files_to_upload:
                            file_path = workspace.get_testcase_dir(norm_id, folder_name) / rel_path
                            if file_path.exists():
                                # Find file by path
                                server_file = file_map.get(rel_path)

                                with open(file_path, "rb") as f:
                                    content = f.read()

                                if server_file:
                                    file_id = server_file.get("_id") or server_file.get("id")
                                    if file_id:
                                        try:
                                            client.update_file_binary(file_id, content)
                                            console.print(f"  [green]✓[/green] {rel_path}")
                                        except Exception as e:
                                            console.print(f"  [red]✗[/red] {rel_path}: {e}")
                                    else:
                                        # File exists but no ID, need to create
                                        file_name = file_path.name
                                        try:
                                            client.create_and_upload_file(
                                                name=file_name,
                                                path=rel_path,
                                                content=content,
                                                testcase_id=tc.id,
                                                norm_id=norm_id_for_file,
                                                rule_id=rule_id_for_file,
                                            )
                                            console.print(f"  [green]✓[/green] {rel_path} (criado)")
                                        except Exception as e:
                                            console.print(f"  [red]✗[/red] {rel_path}: {e}")
                                else:
                                    # File doesn't exist on server, create it
                                    file_name = file_path.name
                                    try:
                                        client.create_and_upload_file(
                                            name=file_name,
                                            path=rel_path,
                                            content=content,
                                            testcase_id=tc.id,
                                            norm_id=norm_id_for_file,
                                            rule_id=rule_id_for_file,
                                        )
                                        console.print(f"  [green]✓[/green] {rel_path} (criado)")
                                    except Exception as e:
                                        console.print(f"  [red]✗[/red] {rel_path}: {e}")

                        # Note: For deleted files, we need to be careful
                        # The server might not allow deleting required files
                        # Only process deletions when not using --all
                        if not upload_all:
                            for rel_path in changes.get("deleted", []):
                                server_file = file_map.get(rel_path)
                                if server_file:
                                    file_id = server_file.get("_id") or server_file.get("id")
                                    if file_id:
                                        try:
                                            client.delete_file(file_id)
                                            console.print(f"  [red]✗[/red] {rel_path} (removido)")
                                        except Exception as e:
                                            console.print(
                                                f"  [yellow]⚠[/yellow] {rel_path}: não foi possível remover: {e}"
                                            )

                        # Upload examples (HTML files in examples/ directories)
                        examples_dir = workspace.get_testcase_dir(norm_id, folder_name) / "examples"
                        if examples_dir.exists():
                            # Get testcase from API to get example IDs
                            try:
                                api_testcase = client.get_testcase(tc.id)
                                # Build a map from example name to example ID
                                example_map = {}
                                for ex in api_testcase.examples:
                                    # Try to match by name or expected result
                                    name = ex.name.lower()
                                    expected = ex.expected_result.lower()
                                    example_map[(name, expected)] = ex.id
                                    # Also map by common patterns
                                    if "compliant" in name:
                                        if expected == "compliant":
                                            example_map[("compliant", "compliant")] = ex.id
                                        else:
                                            example_map[("non-compliant", "non-compliant")] = ex.id

                                # Upload compliant examples
                                compliant_dir = examples_dir / "compliant"
                                if compliant_dir.exists():
                                    for html_file in compliant_dir.glob("*.html"):
                                        # Try to find matching example ID
                                        example_id = example_map.get(("compliant", "compliant"))
                                        if not example_id:
                                            # Try matching by file stem
                                            file_stem = html_file.stem.lower()
                                            for (name, expected), eid in example_map.items():
                                                if expected == "compliant" and (
                                                    file_stem in name or name in file_stem
                                                ):
                                                    example_id = eid
                                                    break

                                        if example_id:
                                            with open(html_file, "rb") as f:
                                                content = f.read()
                                            try:
                                                client.update_example_binary(example_id, content)
                                                console.print(
                                                    f"  [green]✓[/green] examples/compliant/{html_file.name}"
                                                )
                                            except Exception as e:
                                                console.print(
                                                    f"  [red]✗[/red] examples/compliant/{html_file.name}: {e}"
                                                )

                                # Upload non-compliant examples
                                non_compliant_dir = examples_dir / "non-compliant"
                                if non_compliant_dir.exists():
                                    for html_file in non_compliant_dir.glob("*.html"):
                                        # Try to find matching example ID
                                        example_id = example_map.get(
                                            ("non-compliant", "non-compliant")
                                        )
                                        if not example_id:
                                            # Try matching by file stem
                                            file_stem = html_file.stem.lower()
                                            for (name, expected), eid in example_map.items():
                                                if expected == "non-compliant" and (
                                                    file_stem in name or name in file_stem
                                                ):
                                                    example_id = eid
                                                    break

                                        if example_id:
                                            with open(html_file, "rb") as f:
                                                content = f.read()
                                            try:
                                                client.update_example_binary(example_id, content)
                                                console.print(
                                                    f"  [green]✓[/green] examples/non-compliant/{html_file.name}"
                                                )
                                            except Exception as e:
                                                console.print(
                                                    f"  [red]✗[/red] examples/non-compliant/{html_file.name}: {e}"
                                                )

                            except Exception as e:
                                console.print(
                                    f"  [yellow]⚠[/yellow] Não foi possível enviar exemplos: {e}"
                                )

                    progress.update(task, completed=True)

                    # Update checksums after successful push
                    progress.update(task, description="Atualizando checksums...")
                    workspace.save_checksums(norm_id)

        # Success output
        console.print()
        if modified:
            console.print(
                Panel(
                    f"[green]✓ Push realizado com sucesso![/green]\n\n"
                    f"[dim]Casos de teste enviados:[/dim] {len(modified)}\n"
                    f"[dim]Norma:[/dim] permanece bloqueada",
                    title="[bold green]Push Completo[/bold green]",
                    border_style="green",
                )
            )
        else:
            console.print(
                Panel(
                    "[green]✓ Concluído sem alterações.[/green]",
                    title="[bold green]Push Completo[/bold green]",
                    border_style="green",
                )
            )

        console.print(
            "\n[dim]A norma permanece bloqueada. Use 'wally-dev checkout release' "
            "para liberar.[/dim]\n"
        )

        return EXIT_SUCCESS

    except NotLoggedInError as e:
        console.print(
            Panel(
                f"[red]✗ {e.user_message}[/red]\n\n[dim]{e.hint}[/dim]",
                title="[bold red]Não Autenticado[/bold red]",
                border_style="red",
            )
        )
        return EXIT_ERROR_AUTH

    except WallyDevError as e:
        console.print(
            Panel(
                f"[red]✗ {e.user_message}[/red]",
                title="[bold red]Erro[/bold red]",
                border_style="red",
            )
        )
        return e.exit_code

    except Exception as e:
        console.print(f"[red]Erro inesperado: {e}[/red]")
        return EXIT_ERROR_API


def _get_norm_for_push(config: LocalConfig) -> Optional[str]:
    """
    Get norm ID for push based on local checkout state.

    - If no norms in checkout: show error
    - If exactly one norm: use it automatically
    - If multiple norms: show selection list

    Returns:
        Norm ID or None if no selection
    """
    locked_norms = config.get_locked_norms()

    if not locked_norms:
        console.print(
            Panel(
                "[yellow]Nenhuma norma em checkout local.[/yellow]\n\n"
                "[dim]Use 'wally-dev checkout' para fazer checkout de uma norma.[/dim]",
                title="[bold yellow]Sem Checkout[/bold yellow]",
                border_style="yellow",
            )
        )
        return None

    # If only one norm, use it automatically
    if len(locked_norms) == 1:
        norm_id = list(locked_norms.keys())[0]
        norm_info = locked_norms[norm_id]
        norm_name = norm_info.get("norm_name", "Desconhecida")
        console.print(f"\n[dim]Usando norma em checkout:[/dim] {norm_name} ({norm_id[:12]}...)\n")
        return norm_id

    # Multiple norms - show selection
    console.print("\n[bold cyan]📋 Selecionar Norma para Push[/bold cyan]\n")

    table = Table(
        title="📋 Normas em Checkout",
        show_header=True,
        header_style="bold cyan",
    )
    table.add_column("#", style="dim", width=4, justify="right")
    table.add_column("Nome", style="white")
    table.add_column("ID", style="dim")
    table.add_column("Checkout em", style="dim")

    norm_list = list(locked_norms.items())
    for i, (norm_id, info) in enumerate(norm_list, start=1):
        checkout_at = info.get("checkout_at", "")[:10]  # Just date part
        table.add_row(
            str(i),
            info.get("norm_name", "Desconhecida")[:30],
            norm_id[:20] + "...",
            checkout_at,
        )

    console.print(table)
    console.print()

    # Prompt for selection
    while True:
        try:
            selection = click.prompt("Selecione o número da norma (0 para cancelar)")
            selected_index = int(selection)

            if selected_index == 0:
                console.print("[yellow]Operação cancelada.[/yellow]")
                return None

            if 1 <= selected_index <= len(norm_list):
                selected_norm_id: str = norm_list[selected_index - 1][0]
                return selected_norm_id
            else:
                console.print(
                    f"[red]Número inválido. Digite um número entre 1 e {len(norm_list)}, ou 0 para cancelar.[/red]"
                )
        except ValueError:
            console.print("[red]Por favor, digite um número válido.[/red]")
