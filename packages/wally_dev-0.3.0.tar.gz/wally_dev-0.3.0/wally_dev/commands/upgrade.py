"""
Upgrade command for Wally Dev CLI.

Checks for new versions and upgrades the tool.
Enterprise-level implementation with:
- Auto-detection of pipx vs pip installation
- CI/CD friendly --yes flag for non-interactive mode
- Proper exit codes for scripting
"""

import shutil
import subprocess
import sys
from enum import Enum
from typing import NamedTuple

import click
import requests
from rich.console import Console
from rich.panel import Panel
from rich.table import Table

from .. import __version__
from ..constants import EXIT_ERROR_NETWORK, EXIT_ERROR_UPGRADE, EXIT_SUCCESS, EXIT_UPGRADE_AVAILABLE

console = Console()


class InstallMethod(Enum):
    """Installation method detection."""

    PIPX = "pipx"
    PIP = "pip"
    UNKNOWN = "unknown"


class UpgradeResult(NamedTuple):
    """Result of upgrade operation."""

    success: bool
    message: str
    exit_code: int


def detect_install_method() -> InstallMethod:
    """Detect how wally-dev was installed (pipx or pip).

    Returns:
        InstallMethod: The detected installation method
    """
    # Check if pipx is available
    pipx_path = shutil.which("pipx")
    if not pipx_path:
        return InstallMethod.PIP

    # Check if wally-dev is in pipx list
    try:
        result = subprocess.run(
            ["pipx", "list", "--short"],
            capture_output=True,
            text=True,
            timeout=10,
        )
        if result.returncode == 0 and "wally-dev" in result.stdout:
            return InstallMethod.PIPX
    except (subprocess.TimeoutExpired, FileNotFoundError, OSError):
        pass

    return InstallMethod.PIP


def get_latest_version_from_pypi(package_name: str = "wally-dev", timeout: int = 5) -> str | None:
    """Fetch the latest version from PyPI.

    Args:
        package_name: Name of the package on PyPI
        timeout: Request timeout in seconds

    Returns:
        Latest version string or None if unavailable
    """
    try:
        url = f"https://pypi.org/pypi/{package_name}/json"
        response = requests.get(url, timeout=timeout)
        response.raise_for_status()

        data = response.json()
        version = data.get("info", {}).get("version")

        return version if version else None
    except requests.RequestException as e:
        console.print(f"[yellow]⚠️  Não foi possível verificar versão: {e}[/yellow]")
        return None
    except Exception as e:
        console.print(f"[yellow]⚠️  Erro ao processar resposta: {e}[/yellow]")
        return None


def _parse_version(version_str: str) -> tuple[int, int, int]:
    """Parse version string into tuple of integers.

    Examples:
        "0.1.1" -> (0, 1, 1)
        "1.2" -> (1, 2, 0)
    """
    try:
        parts = version_str.split(".")
        major = int(parts[0]) if len(parts) > 0 else 0
        minor = int(parts[1]) if len(parts) > 1 else 0
        patch = int(parts[2]) if len(parts) > 2 else 0
        return (major, minor, patch)
    except (ValueError, IndexError):
        return (0, 0, 0)


def is_upgrade_available(current: str, latest: str | None) -> bool:
    """Check if upgrade is available.

    Args:
        current: Current installed version
        latest: Latest available version (can be None)

    Returns:
        True if upgrade is available, False otherwise
    """
    if not latest:
        return False

    current_tuple = _parse_version(current)
    latest_tuple = _parse_version(latest)

    return latest_tuple > current_tuple


def perform_upgrade(version: str, method: InstallMethod) -> UpgradeResult:
    """Perform the actual upgrade using pipx or pip.

    Args:
        version: Target version to install
        method: Installation method (pipx or pip)

    Returns:
        UpgradeResult with success status, message and exit code
    """
    try:
        method_name = "pipx" if method == InstallMethod.PIPX else "pip"
        console.print(f"\n[bold blue]📦 Iniciando upgrade via {method_name}...[/bold blue]")
        console.print(f"   Versão alvo: {version}\n")

        if method == InstallMethod.PIPX:
            cmd = ["pipx", "upgrade", "wally-dev"]
        else:
            cmd = [
                sys.executable,
                "-m",
                "pip",
                "install",
                "--upgrade",
                f"wally-dev=={version}",
            ]

        result = subprocess.run(
            cmd,
            capture_output=False,
            text=True,
        )

        if result.returncode == 0:
            return UpgradeResult(
                success=True,
                message="Upgrade realizado com sucesso!",
                exit_code=EXIT_SUCCESS,
            )
        else:
            return UpgradeResult(
                success=False,
                message="Erro durante o upgrade. Verifique as permissões.",
                exit_code=EXIT_ERROR_UPGRADE,
            )

    except FileNotFoundError:
        return UpgradeResult(
            success=False,
            message=f"Comando {method_name} não encontrado.",
            exit_code=EXIT_ERROR_UPGRADE,
        )
    except Exception as e:
        return UpgradeResult(
            success=False,
            message=f"Erro inesperado: {e}",
            exit_code=EXIT_ERROR_UPGRADE,
        )


def _show_version_info(current: str, latest: str, method: InstallMethod) -> None:
    """Display version information table."""
    table = Table(show_header=False, box=None, padding=(0, 2))
    table.add_column("Label", style="dim")
    table.add_column("Value")

    table.add_row("Versão instalada:", f"[bold]{current}[/bold]")
    table.add_row("Versão disponível:", f"[bold cyan]{latest}[/bold cyan]")
    table.add_row("Método de instalação:", method.value)

    console.print(table)
    console.print()


@click.command()
@click.option(
    "--check",
    is_flag=True,
    help="Apenas verifica se há nova versão (exit code 1 se houver upgrade)",
)
@click.option(
    "--yes",
    "-y",
    is_flag=True,
    help="Confirma automaticamente o upgrade (útil para CI/CD)",
)
@click.option(
    "--version",
    "target_version",
    type=str,
    help="Atualiza para uma versão específica",
)
@click.pass_context
def upgrade(ctx: click.Context, check: bool, yes: bool, target_version: str | None) -> None:
    """
    Verifica e instala a versão mais recente do wally-dev.

    \b
    Exemplos:
      wally-dev upgrade              # Atualiza interativamente
      wally-dev upgrade --yes        # Atualiza sem confirmação (CI/CD)
      wally-dev upgrade --check      # Verifica se há upgrade (exit 1 = disponível)
      wally-dev upgrade --version 0.2.0  # Atualiza para versão específica

    \b
    Exit Codes:
      0 - Sucesso (upgrade realizado ou já está na última versão)
      1 - Upgrade disponível (quando usado com --check)
      7 - Erro durante o upgrade
    """
    console.print("\n[bold]Wally Dev[/bold] - Upgrade Tool\n")

    # Detect installation method
    install_method = detect_install_method()

    # If specific version is requested
    if target_version:
        console.print(f"[bold blue]→[/bold blue] Atualizando para versão {target_version}...")
        result = perform_upgrade(target_version, install_method)

        if result.success:
            console.print(
                Panel(
                    f"[green]✅ {result.message}[/green]\n"
                    "[dim]Reinicie seu terminal para usar a nova versão[/dim]",
                    title="Sucesso",
                    border_style="green",
                )
            )
        else:
            console.print(f"[red]❌ {result.message}[/red]\n")

        ctx.exit(result.exit_code)

    # Check for latest version
    console.print("[bold blue]→[/bold blue] Verificando última versão disponível...")
    latest_version = get_latest_version_from_pypi()

    if not latest_version:
        console.print(
            "[yellow]⚠️  Não foi possível verificar versão. Tente novamente mais tarde.[/yellow]\n"
        )
        ctx.exit(EXIT_ERROR_NETWORK)

    # Show version info
    _show_version_info(__version__, latest_version, install_method)

    # Check if upgrade is available
    if not is_upgrade_available(__version__, latest_version):
        console.print(
            Panel(
                "[green]✅ Você já possui a versão mais recente![/green]",
                title="Status",
                border_style="green",
            )
        )
        ctx.exit(EXIT_SUCCESS)

    # Upgrade is available
    console.print(
        Panel(
            f"[cyan]Nova versão disponível: {__version__} → {latest_version}[/cyan]",
            title="Upgrade Disponível",
            border_style="cyan",
        )
    )

    # If --check flag is set, exit with code 1 to indicate upgrade is available
    if check:
        console.print("[dim]Use 'wally-dev upgrade' para atualizar[/dim]\n")
        ctx.exit(EXIT_UPGRADE_AVAILABLE)

    # Auto-confirm with --yes flag or ask for confirmation
    should_upgrade = yes or click.confirm("Deseja atualizar agora?", default=True)

    if should_upgrade:
        result = perform_upgrade(latest_version, install_method)

        if result.success:
            console.print(
                Panel(
                    f"[green]✅ {result.message}[/green]\n"
                    "[dim]Reinicie seu terminal para usar a nova versão[/dim]",
                    title="Sucesso",
                    border_style="green",
                )
            )
        else:
            console.print(f"[red]❌ {result.message}[/red]\n")

        ctx.exit(result.exit_code)
    else:
        console.print("[yellow]Upgrade cancelado[/yellow]\n")
        ctx.exit(EXIT_SUCCESS)
