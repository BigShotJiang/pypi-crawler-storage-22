#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Walmart 防爬验证处理器
专门处理 Walmart 网站的各种防爬验证场景

主要处理 PerimeterX 反爬系统的验证：
- Press and Hold 按住验证
- 验证码
- 拼图验证
"""

import time
import random
import logging
from typing import Optional, Callable, Any
from enum import Enum

from app.selectors.walmart_selectors import WalmartSelectors, WalmartTimeouts

logger = logging.getLogger(__name__)


class BotDetectionType(Enum):
    """防爬验证类型"""
    NONE = "none"                    # 无验证
    LOGO_CLICK = "logo_click"        # 需要点击 Logo 按钮
    CAPTCHA = "captcha"              # 验证码
    PRESS_HOLD = "press_hold"        # 按住按钮验证
    PUZZLE = "puzzle"                # 拼图验证
    BLOCKED = "blocked"              # 被封禁
    UNKNOWN = "unknown"              # 未知类型


class WalmartBotHandler:
    """Walmart 防爬验证处理器

    处理 Walmart 网站的各种防爬验证场景：
    1. Logo 点击验证 - 页面只显示 Logo，需要点击进入下一步
    2. 验证码 - 需要手动输入验证码
    3. 按住验证 - 需要按住按钮一段时间
    4. 拼图验证 - 需要拖动拼图

    使用方式：
        handler = WalmartBotHandler(page)
        if handler.detect():
            handler.handle()
    """

    # 验证页面特征选择器
    SELECTORS = {
        # Logo 点击验证
        'logo_click': {
            'indicators': [
                'a.header-logo',
                'css:a[aria-label*="Walmart"][href="/"]',
                'span.elc-icon-spark'
            ],
            'click_targets': [
                'a.header-logo',
                'css:a[aria-label*="Walmart"][href="/"]',
                'css:a[aria-label*="Save Money"]'
            ]
        },
        # 验证码
        'captcha': {
            'indicators': [
                'css:[data-testid="captcha"]',
                'css:#captcha-container',
                'css:input#captchacharacters',
                '.captcha-container'
            ]
        },
        # PerimeterX Press and Hold 验证
        'press_hold': {
            'indicators': WalmartSelectors.PerimeterX.ALL_INDICATORS,
            'container': WalmartSelectors.PerimeterX.CAPTCHA_CONTAINER,
            'hold_targets': [
                WalmartSelectors.PerimeterX.HOLD_BUTTON,
                WalmartSelectors.PerimeterX.HOLD_BUTTON_ALT
            ]
        },
        # 拼图验证
        'puzzle': {
            'indicators': [
                'css:[data-testid="puzzle-captcha"]',
                '.puzzle-container',
                'text:Slide to verify'
            ]
        },
        # 被封禁
        'blocked': {
            'indicators': [
                'text:Access Denied',
                'text:blocked',
                'text:unusual activity'
            ]
        }
    }

    def __init__(self, page, terminal_ui=None, on_captcha_callback: Optional[Callable] = None):
        """初始化防爬处理器

        Args:
            page: DrissionPage 页面对象
            terminal_ui: 终端UI实例（用于更新验证码计数）
            on_captcha_callback: 验证码回调函数
        """
        self.page = page
        self.terminal_ui = terminal_ui
        self.on_captcha_callback = on_captcha_callback

        # 统计数据
        self.stats = {
            'logo_click_count': 0,
            'captcha_count': 0,
            'press_hold_count': 0,
            'puzzle_count': 0,
            'blocked_count': 0,
            'success_count': 0,
            'fail_count': 0
        }

    def detect(self) -> BotDetectionType:
        """检测当前页面的防爬验证类型

        Returns:
            BotDetectionType: 验证类型
        """
        try:
            # 首先检查是否有正常的商品内容
            if self._has_product_content():
                return BotDetectionType.NONE

            # 检查各种验证类型
            if self._check_blocked():
                logger.warning("检测到访问被封禁")
                return BotDetectionType.BLOCKED

            if self._check_captcha():
                logger.info("检测到验证码页面")
                return BotDetectionType.CAPTCHA

            if self._check_press_hold():
                logger.info("检测到按住验证页面")
                return BotDetectionType.PRESS_HOLD

            if self._check_puzzle():
                logger.info("检测到拼图验证页面")
                return BotDetectionType.PUZZLE

            if self._check_logo_click():
                logger.info("检测到 Logo 点击验证页面")
                return BotDetectionType.LOGO_CLICK

            return BotDetectionType.NONE

        except Exception as e:
            logger.error(f"检测防爬验证类型时出错: {e}")
            return BotDetectionType.UNKNOWN

    def handle(self, detection_type: BotDetectionType = None) -> bool:
        """处理防爬验证

        Args:
            detection_type: 验证类型，如果为 None 则自动检测

        Returns:
            bool: 是否成功通过验证
        """
        if detection_type is None:
            detection_type = self.detect()

        if detection_type == BotDetectionType.NONE:
            return True

        logger.info(f"开始处理防爬验证: {detection_type.value}")

        handlers = {
            BotDetectionType.LOGO_CLICK: self._handle_logo_click,
            BotDetectionType.CAPTCHA: self._handle_captcha,
            BotDetectionType.PRESS_HOLD: self._handle_press_hold,
            BotDetectionType.PUZZLE: self._handle_puzzle,
            BotDetectionType.BLOCKED: self._handle_blocked,
            BotDetectionType.UNKNOWN: self._handle_unknown
        }

        handler = handlers.get(detection_type)
        if handler:
            success = handler()
            if success:
                self.stats['success_count'] += 1
            else:
                self.stats['fail_count'] += 1
            return success

        return False

    def _has_product_content(self) -> bool:
        """检查页面是否有商品内容"""
        try:
            # 检查商品标题
            if self.page.ele(WalmartSelectors.PageStatus.PRODUCT_TITLE, timeout=WalmartTimeouts.QUICK):
                return True

            # 检查购买区域
            if self.page.ele(WalmartSelectors.PageStatus.BUY_BOX, timeout=WalmartTimeouts.QUICK):
                return True

            # 检查搜索框（正常页面应该有）
            if self.page.ele(WalmartSelectors.PageStatus.SEARCH_BOX, timeout=WalmartTimeouts.QUICK):
                # 有搜索框但没有商品内容，可能是搜索结果页或其他页面
                # 需要进一步判断
                pass

            return False

        except Exception:
            return False

    def _check_logo_click(self) -> bool:
        """检查是否是 Logo 点击验证页面"""
        try:
            for selector in self.SELECTORS['logo_click']['indicators']:
                if self.page.ele(selector, timeout=WalmartTimeouts.QUICK):
                    # 确认没有商品内容
                    if not self._has_product_content():
                        return True
            return False
        except Exception:
            return False

    def _check_captcha(self) -> bool:
        """检查是否是验证码页面"""
        try:
            for selector in self.SELECTORS['captcha']['indicators']:
                if self.page.ele(selector, timeout=WalmartTimeouts.QUICK):
                    return True
            return False
        except Exception:
            return False

    def _check_press_hold(self) -> bool:
        """检查是否是 PerimeterX Press-Hold 验证页面"""
        try:
            # 检查 PerimeterX 验证指示器
            for selector in WalmartSelectors.PerimeterX.ALL_INDICATORS:
                if self.page.ele(selector, timeout=WalmartTimeouts.QUICK):
                    return True

            # 通过 JS 检查 Shadow DOM 中的内容
            has_px_captcha = self.page.run_js('''
                const container = document.querySelector('#px-captcha');
                if (!container) return false;
                // 检查是否有内容
                return container.innerHTML.length > 0 ||
                       (container.shadowRoot && container.shadowRoot.innerHTML.length > 0);
            ''')
            if has_px_captcha:
                return True

            return False
        except Exception:
            return False

    def _check_puzzle(self) -> bool:
        """检查是否是拼图验证页面"""
        try:
            for selector in self.SELECTORS['puzzle']['indicators']:
                if self.page.ele(selector, timeout=WalmartTimeouts.QUICK):
                    return True
            return False
        except Exception:
            return False

    def _check_blocked(self) -> bool:
        """检查是否被封禁"""
        try:
            for selector in self.SELECTORS['blocked']['indicators']:
                if self.page.ele(selector, timeout=WalmartTimeouts.QUICK):
                    return True
            return False
        except Exception:
            return False

    def _handle_logo_click(self) -> bool:
        """处理 Logo 点击验证

        点击 Logo 按钮进入下一步验证

        Returns:
            bool: 是否成功
        """
        self.stats['logo_click_count'] += 1
        self._update_terminal_ui()

        max_attempts = 3
        for attempt in range(1, max_attempts + 1):
            try:
                # 尝试点击各种 Logo 选择器
                for selector in self.SELECTORS['logo_click']['click_targets']:
                    logo_button = self.page.ele(selector, timeout=WalmartTimeouts.SHORT)
                    if logo_button:
                        logger.info(f"点击 Logo 按钮: {selector} (第 {attempt} 次)")
                        logo_button.click()
                        time.sleep(WalmartTimeouts.MEDIUM)

                        # 检查结果
                        new_type = self.detect()
                        if new_type == BotDetectionType.NONE:
                            logger.info("Logo 点击验证通过")
                            return True
                        elif new_type == BotDetectionType.CAPTCHA:
                            logger.info("进入验证码页面")
                            return self._handle_captcha()
                        elif new_type == BotDetectionType.PRESS_HOLD:
                            logger.info("进入按住验证页面")
                            return self._handle_press_hold()

                        break

                time.sleep(WalmartTimeouts.NORMAL)

            except Exception as e:
                logger.warning(f"Logo 点击处理出错 (第 {attempt} 次): {e}")
                time.sleep(1)

        logger.warning("Logo 点击验证失败")
        return False

    def _handle_captcha(self) -> bool:
        """处理验证码

        等待用户手动输入验证码

        Returns:
            bool: 是否成功
        """
        self.stats['captcha_count'] += 1
        self._update_terminal_ui()

        logger.info("检测到验证码，等待手动输入...")

        max_wait_time = 120  # 最长等待2分钟
        start_time = time.time()

        while time.time() - start_time < max_wait_time:
            try:
                # 检查验证码是否还存在
                if not self._check_captcha():
                    # 验证码消失，检查是否通过
                    time.sleep(1)
                    if self._has_product_content() or self.detect() == BotDetectionType.NONE:
                        logger.info("验证码验证通过")
                        return True

                # 检查验证码输入框
                captcha_input = self.page.ele('input#captchacharacters', timeout=WalmartTimeouts.QUICK)
                if captcha_input:
                    input_value = captcha_input.attr('value') or ''
                    if len(input_value) >= 4:
                        # 尝试提交
                        self._try_submit_captcha()
                        time.sleep(1)

                time.sleep(0.5)

            except Exception as e:
                logger.debug(f"验证码处理过程出错: {e}")
                time.sleep(0.5)

        logger.warning("验证码等待超时")
        return False

    def _try_submit_captcha(self):
        """尝试提交验证码"""
        try:
            # 方式1: 点击 submit 按钮
            submit_btn = self.page.ele('tag:button@@type=submit', timeout=WalmartTimeouts.QUICK)
            if submit_btn:
                submit_btn.click()
                return

            # 方式2: 点击 input submit
            submit_input = self.page.ele('tag:input@@type=submit', timeout=WalmartTimeouts.QUICK)
            if submit_input:
                submit_input.click()
                return

            # 方式3: 按文本查找按钮
            for btn_text in ['Continue shopping', 'Submit', 'Continue', 'Verify']:
                btn = self.page.ele(f'text={btn_text}', timeout=WalmartTimeouts.QUICK)
                if btn:
                    btn.click()
                    return

            # 方式4: 按回车
            captcha_input = self.page.ele('input#captchacharacters', timeout=WalmartTimeouts.QUICK)
            if captcha_input:
                captcha_input.input('\n')

        except Exception as e:
            logger.debug(f"提交验证码出错: {e}")

    def _handle_press_hold(self) -> bool:
        """处理 PerimeterX Press and Hold 验证

        PerimeterX 验证特点：
        1. 使用 Shadow DOM 隐藏按钮
        2. 可能创建 display:none 的假 iframe 诱饵
        3. 需要生成 isTrusted=true 的鼠标事件
        4. 按住时间通常需要 5-8 秒

        Returns:
            bool: 是否成功通过验证
        """
        self.stats['press_hold_count'] += 1
        self._update_terminal_ui()

        logger.info("检测到 PerimeterX Press-Hold 验证，开始处理...")

        max_attempts = 5
        for attempt in range(1, max_attempts + 1):
            logger.info(f"Press-Hold 处理尝试 {attempt}/{max_attempts}")

            try:
                # 方案1：使用 actions API（生成 isTrusted=true 事件）
                if self._perform_press_hold_with_actions():
                    logger.info("Press-Hold 验证通过（actions API）")
                    return True

                # 方案2：通过 Shadow DOM 访问
                if self._perform_press_hold_via_shadow_dom():
                    logger.info("Press-Hold 验证通过（Shadow DOM）")
                    return True

                # 方案3：直接元素交互
                if self._perform_press_hold_direct():
                    logger.info("Press-Hold 验证通过（直接交互）")
                    return True

                # 短暂等待后重试
                time.sleep(2)

            except Exception as e:
                logger.warning(f"Press-Hold 处理出错 (尝试 {attempt}): {e}")
                time.sleep(1)

        # 所有自动方案失败，等待手动处理
        logger.info("自动 Press-Hold 处理失败，等待手动操作...")
        return self._wait_for_manual_verification(timeout=120)

    def _perform_press_hold_with_actions(self) -> bool:
        """使用 actions API 执行 Press-Hold

        actions API 可以生成 isTrusted=true 的鼠标事件，
        这是通过 PerimeterX 验证的关键

        Returns:
            bool: 是否成功
        """
        try:
            # 查找 PerimeterX 容器
            px_container = self.page.ele(
                WalmartSelectors.PerimeterX.CAPTCHA_CONTAINER,
                timeout=WalmartTimeouts.SHORT
            )
            if not px_container:
                px_container = self.page.ele(
                    WalmartSelectors.PerimeterX.CAPTCHA_CONTAINER_ALT,
                    timeout=WalmartTimeouts.SHORT
                )

            if not px_container:
                logger.debug("未找到 PerimeterX 容器")
                return False

            # 获取容器的位置和尺寸
            rect = px_container.rect
            if not rect:
                logger.debug("无法获取容器尺寸")
                return False

            # 计算中心点（按钮通常在容器中心）
            center_x = rect.midpoint[0]
            center_y = rect.midpoint[1]

            logger.info(f"准备在坐标 ({center_x}, {center_y}) 执行 Press-Hold")

            # 使用 actions API 执行按住操作
            # 1. 移动到目标位置
            self.page.actions.move_to((center_x, center_y))
            time.sleep(random.uniform(0.1, 0.3))

            # 2. 按下鼠标左键
            self.page.actions.hold()

            # 3. 按住期间添加微移动（模拟人类手抖）
            hold_duration = random.uniform(
                WalmartTimeouts.HOLD_MIN,
                WalmartTimeouts.HOLD_MAX
            )
            start_time = time.time()

            while time.time() - start_time < hold_duration:
                # 微小移动（±3像素）
                dx = random.randint(-3, 3)
                dy = random.randint(-3, 3)
                self.page.actions.move(dx, dy)
                time.sleep(WalmartTimeouts.HOLD_CHECK_INTERVAL)

            # 4. 释放鼠标
            self.page.actions.release()

            # 等待验证完成
            time.sleep(WalmartTimeouts.MEDIUM)

            # 检查是否通过验证
            return self.detect() == BotDetectionType.NONE

        except Exception as e:
            logger.debug(f"actions API 方式失败: {e}")
            return False

    def _perform_press_hold_via_shadow_dom(self) -> bool:
        """通过 Shadow DOM 访问按钮并执行 Press-Hold

        PerimeterX 通常将按钮放在 closed shadow root 中

        Returns:
            bool: 是否成功
        """
        try:
            # 尝试通过 JS 获取 Shadow DOM 中的按钮信息
            button_info = self.page.run_js('''
                const container = document.querySelector('#px-captcha');
                if (!container) return null;

                // 尝试访问 shadow root
                let sr = container.shadowRoot;
                if (!sr) {
                    // 可能是 closed shadow root，尝试其他方法
                    return null;
                }

                // 查找真实的 iframe（过滤掉 display:none 的假 iframe）
                const iframes = sr.querySelectorAll('iframe');
                let realIframe = null;
                for (const iframe of iframes) {
                    const style = window.getComputedStyle(iframe);
                    if (style.display !== 'none' && style.visibility !== 'hidden') {
                        realIframe = iframe;
                        break;
                    }
                }

                if (realIframe) {
                    const rect = realIframe.getBoundingClientRect();
                    return {
                        x: rect.left + rect.width / 2,
                        y: rect.top + rect.height / 2,
                        width: rect.width,
                        height: rect.height,
                        type: 'iframe'
                    };
                }

                // 直接查找按钮
                const button = sr.querySelector('button, [role="button"]');
                if (button) {
                    const rect = button.getBoundingClientRect();
                    return {
                        x: rect.left + rect.width / 2,
                        y: rect.top + rect.height / 2,
                        width: rect.width,
                        height: rect.height,
                        type: 'button'
                    };
                }

                return null;
            ''')

            if not button_info:
                logger.debug("无法通过 Shadow DOM 获取按钮信息")
                return False

            x, y = button_info['x'], button_info['y']
            logger.info(f"通过 Shadow DOM 找到按钮，坐标: ({x}, {y})")

            # 执行 Press-Hold
            self.page.actions.move_to((x, y))
            time.sleep(0.1)
            self.page.actions.hold()

            hold_duration = random.uniform(
                WalmartTimeouts.HOLD_MIN,
                WalmartTimeouts.HOLD_MAX
            )
            start_time = time.time()

            while time.time() - start_time < hold_duration:
                dx = random.randint(-2, 2)
                dy = random.randint(-2, 2)
                self.page.actions.move(dx, dy)
                time.sleep(0.3)

            self.page.actions.release()
            time.sleep(WalmartTimeouts.MEDIUM)

            return self.detect() == BotDetectionType.NONE

        except Exception as e:
            logger.debug(f"Shadow DOM 方式失败: {e}")
            return False

    def _perform_press_hold_direct(self) -> bool:
        """直接元素交互方式执行 Press-Hold

        作为最后的降级方案，直接查找可点击元素

        Returns:
            bool: 是否成功
        """
        try:
            # 尝试多种选择器
            selectors_to_try = [
                WalmartSelectors.PerimeterX.CAPTCHA_CONTAINER,
                WalmartSelectors.PerimeterX.HOLD_BUTTON,
                WalmartSelectors.PerimeterX.HOLD_BUTTON_ALT,
                'text:Press and hold',
                'text:press & hold'
            ]

            for selector in selectors_to_try:
                element = self.page.ele(selector, timeout=WalmartTimeouts.SHORT)
                if element:
                    logger.info(f"找到可交互元素: {selector}")

                    # 使用 DrissionPage 的 click.hold 方法
                    hold_duration = random.uniform(
                        WalmartTimeouts.HOLD_MIN,
                        WalmartTimeouts.HOLD_MAX
                    )
                    element.click.hold(duration=hold_duration)

                    time.sleep(WalmartTimeouts.MEDIUM)

                    if self.detect() == BotDetectionType.NONE:
                        return True

            return False

        except Exception as e:
            logger.debug(f"直接交互方式失败: {e}")
            return False

    def _handle_puzzle(self) -> bool:
        """处理拼图验证

        拼图验证通常需要手动完成

        Returns:
            bool: 是否成功
        """
        self.stats['puzzle_count'] += 1
        self._update_terminal_ui()

        logger.info("检测到拼图验证，等待手动完成...")
        return self._wait_for_manual_verification(timeout=120)

    def _handle_blocked(self) -> bool:
        """处理被封禁

        Returns:
            bool: 始终返回 False
        """
        self.stats['blocked_count'] += 1
        logger.error("访问被封禁，无法继续")
        return False

    def _handle_unknown(self) -> bool:
        """处理未知验证类型

        Returns:
            bool: 是否成功
        """
        logger.warning("未知的验证类型，等待手动处理...")
        return self._wait_for_manual_verification(timeout=60)

    def _wait_for_manual_verification(self, timeout: int = 60) -> bool:
        """等待手动验证完成

        Args:
            timeout: 超时时间（秒）

        Returns:
            bool: 是否成功
        """
        start_time = time.time()

        while time.time() - start_time < timeout:
            try:
                # 检查是否通过验证
                if self._has_product_content():
                    logger.info("手动验证通过")
                    return True

                if self.detect() == BotDetectionType.NONE:
                    logger.info("验证通过")
                    return True

                time.sleep(1)

            except Exception as e:
                logger.debug(f"等待验证过程出错: {e}")
                time.sleep(1)

        logger.warning("手动验证等待超时")
        return False

    def _update_terminal_ui(self):
        """更新终端UI的验证码计数"""
        if self.terminal_ui:
            try:
                self.terminal_ui.increment_captcha()
            except Exception:
                pass

    def get_stats(self) -> dict:
        """获取统计数据"""
        return self.stats.copy()

    def reset_stats(self):
        """重置统计数据"""
        for key in self.stats:
            self.stats[key] = 0
