#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
人类行为模拟器
模拟真实用户的浏览行为，降低被反爬系统检测的风险
"""

import time
import random
import logging
from typing import Literal

logger = logging.getLogger(__name__)


def human_like_delay(min_sec: float = 2.0, max_sec: float = 5.0) -> float:
    """生成人类风格的随机延迟

    使用正态分布生成更自然的延迟时间，
    大多数延迟会集中在中间值附近

    Args:
        min_sec: 最小延迟（秒）
        max_sec: 最大延迟（秒）

    Returns:
        float: 实际等待的时间（秒）
    """
    # 使用正态分布，中心点在中间
    mean = (min_sec + max_sec) / 2
    std = (max_sec - min_sec) / 4  # 使大部分值落在范围内

    delay = random.gauss(mean, std)
    delay = max(min_sec, min(max_sec, delay))  # 限制在范围内

    logger.debug(f"人类延迟: {delay:.2f}秒")
    time.sleep(delay)
    return delay


def human_like_scroll(
    page,
    scroll_type: Literal['read', 'scan', 'random'] = 'read',
    duration: float = None
) -> None:
    """模拟人类风格的页面滚动

    Args:
        page: DrissionPage 页面对象
        scroll_type: 滚动类型
            - 'read': 慢速阅读滚动
            - 'scan': 快速浏览滚动
            - 'random': 随机滚动
        duration: 滚动持续时间（秒），None 表示自动计算
    """
    try:
        if scroll_type == 'read':
            # 阅读模式：缓慢、小幅滚动
            _reading_scroll(page, duration or random.uniform(3, 6))
        elif scroll_type == 'scan':
            # 浏览模式：快速滚动到感兴趣的位置
            _scanning_scroll(page, duration or random.uniform(1, 2))
        else:
            # 随机模式
            _random_scroll(page, duration or random.uniform(2, 4))
    except Exception as e:
        logger.debug(f"滚动模拟出错: {e}")


def _reading_scroll(page, duration: float) -> None:
    """阅读式滚动 - 模拟认真阅读内容"""
    start_time = time.time()

    while time.time() - start_time < duration:
        # 小幅滚动
        scroll_amount = random.randint(50, 150)
        page.scroll.down(scroll_amount)

        # 阅读暂停（0.5-2秒）
        pause = random.uniform(0.5, 2.0)
        time.sleep(pause)

        # 偶尔向上滚动一点（回顾）
        if random.random() < 0.15:
            page.scroll.up(random.randint(30, 80))
            time.sleep(random.uniform(0.3, 0.8))


def _scanning_scroll(page, duration: float) -> None:
    """扫描式滚动 - 快速浏览"""
    start_time = time.time()

    while time.time() - start_time < duration:
        # 快速大幅滚动
        scroll_amount = random.randint(200, 400)
        page.scroll.down(scroll_amount)

        # 短暂停留
        time.sleep(random.uniform(0.2, 0.5))


def _random_scroll(page, duration: float) -> None:
    """随机滚动 - 模拟不确定的浏览行为"""
    start_time = time.time()

    while time.time() - start_time < duration:
        # 随机选择滚动方向
        if random.random() < 0.7:
            page.scroll.down(random.randint(50, 300))
        else:
            page.scroll.up(random.randint(30, 150))

        time.sleep(random.uniform(0.3, 1.0))


def random_mouse_movement(page, iterations: int = 3) -> None:
    """模拟随机鼠标移动

    在页面上随机移动鼠标，模拟真实用户行为

    Args:
        page: DrissionPage 页面对象
        iterations: 移动次数
    """
    try:
        for _ in range(iterations):
            # 获取视口尺寸
            viewport = page.run_js(
                'return {width: window.innerWidth, height: window.innerHeight}'
            )

            if viewport:
                # 随机生成目标坐标（避开边缘）
                margin = 50
                x = random.randint(margin, viewport['width'] - margin)
                y = random.randint(margin, viewport['height'] - margin)

                # 移动鼠标
                page.actions.move_to((x, y))

                # 随机停留
                time.sleep(random.uniform(0.1, 0.3))

    except Exception as e:
        logger.debug(f"鼠标移动模拟出错: {e}")


def simulate_human_interaction(page) -> None:
    """执行一组人类交互模拟

    包含：鼠标移动、滚动、停顿等

    Args:
        page: DrissionPage 页面对象
    """
    try:
        # 先随机移动鼠标
        random_mouse_movement(page, iterations=2)

        # 短暂停顿
        time.sleep(random.uniform(0.3, 0.8))

        # 滚动页面
        scroll_type = random.choice(['read', 'scan', 'random'])
        human_like_scroll(page, scroll_type=scroll_type, duration=random.uniform(1, 3))

        # 再次移动鼠标
        random_mouse_movement(page, iterations=1)

    except Exception as e:
        logger.debug(f"人类交互模拟出错: {e}")


def add_micro_movements(page, x: int, y: int, duration: float = 0.5) -> None:
    """在按住期间添加微小的鼠标移动

    Args:
        page: DrissionPage 页面对象
        x: 中心点 X 坐标
        y: 中心点 Y 坐标
        duration: 持续时间（秒）
    """
    try:
        start_time = time.time()
        while time.time() - start_time < duration:
            # 微小的随机偏移（±3像素）
            dx = random.randint(-3, 3)
            dy = random.randint(-3, 3)
            page.actions.move(dx, dy)
            time.sleep(random.uniform(0.1, 0.3))
    except Exception as e:
        logger.debug(f"微移动出错: {e}")
