#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Chrome 浏览器辅助工具
处理用户数据目录检测、拷贝等功能
"""

import os
import sys
import shutil
import logging
from pathlib import Path
from typing import Optional

logger = logging.getLogger(__name__)

# 默认的项目用户数据目录
DEFAULT_PROJECT_CHROME_DATA = "data/chrome_user_data"


def get_system_chrome_user_data_path() -> Optional[str]:
    """获取系统 Chrome 默认用户数据目录路径

    Returns:
        Optional[str]: Chrome 用户数据目录路径，未找到返回 None
    """
    if sys.platform == 'win32':
        # Windows
        local_app_data = os.environ.get('LOCALAPPDATA', '')
        if local_app_data:
            chrome_path = Path(local_app_data) / 'Google' / 'Chrome' / 'User Data'
            if chrome_path.exists():
                return str(chrome_path)
    elif sys.platform == 'darwin':
        # macOS
        home = Path.home()
        chrome_path = home / 'Library' / 'Application Support' / 'Google' / 'Chrome'
        if chrome_path.exists():
            return str(chrome_path)
    else:
        # Linux
        home = Path.home()
        chrome_path = home / '.config' / 'google-chrome'
        if chrome_path.exists():
            return str(chrome_path)

    return None


def ensure_project_chrome_data(source_path: str = None, target_dir: str = None) -> str:
    """确保项目有可用的 Chrome 用户数据目录

    如果目标目录不存在，会从系统 Chrome 用户数据目录拷贝。

    Args:
        source_path: 源用户数据目录（可选，默认自动检测系统 Chrome）
        target_dir: 目标目录（可选，默认为 data/chrome_user_data）

    Returns:
        str: 可用的 Chrome 用户数据目录的 **绝对路径**
    """
    # 构建项目目录的绝对路径
    if target_dir:
        # 如果是相对路径，相对于项目根目录解析
        target_path = Path(target_dir)
        if not target_path.is_absolute():
            project_root = Path(__file__).parent.parent.parent
            target_path = (project_root / target_dir).resolve()
        else:
            target_path = target_path.resolve()
    else:
        # 从当前文件位置推算项目根目录
        # chrome_helper.py 位于 app/utils/，向上两级是项目根目录
        project_root = Path(__file__).parent.parent.parent
        target_path = (project_root / DEFAULT_PROJECT_CHROME_DATA).resolve()

    logger.info(f"目标用户数据目录（绝对路径）: {target_path}")

    # 如果目标目录已存在且有内容，直接使用
    if target_path.exists() and any(target_path.iterdir()):
        logger.info(f"使用已存在的用户数据目录: {target_path}")
        return str(target_path)

    # 确定源目录
    if source_path:
        source = Path(source_path)
    else:
        system_path = get_system_chrome_user_data_path()
        if not system_path:
            logger.warning("未找到系统 Chrome 用户数据目录，将使用空目录")
            target_path.mkdir(parents=True, exist_ok=True)
            return str(target_path)
        source = Path(system_path)

    if not source.exists():
        logger.warning(f"源目录不存在: {source}，将使用空目录")
        target_path.mkdir(parents=True, exist_ok=True)
        return str(target_path)

    # 拷贝关键文件（只拷贝 Default 配置文件，不拷贝缓存等大文件）
    logger.info(f"正在从系统 Chrome 拷贝用户数据...")
    logger.info(f"  源目录: {source}")
    logger.info(f"  目标目录: {target_path}")

    try:
        _copy_chrome_profile(source, target_path)
        logger.info("Chrome 用户数据拷贝完成")
        return str(target_path)
    except Exception as e:
        logger.error(f"拷贝用户数据失败: {e}")
        target_path.mkdir(parents=True, exist_ok=True)
        return str(target_path)


def _copy_chrome_profile(source: Path, target: Path):
    """拷贝 Chrome 配置文件（只拷贝关键文件，跳过缓存等大文件）

    支持两种源目录格式：
    1. User Data 目录（包含 Default 子目录）
    2. Default 目录本身（直接包含 Preferences 等文件）

    Args:
        source: 源目录
        target: 目标目录
    """
    # 判断源目录类型：是 User Data 还是 Default 目录
    is_profile_dir = (source / 'Preferences').exists() or source.name == 'Default'

    if is_profile_dir:
        # 源目录是 profile 目录（如 Default），直接拷贝到 target/Default
        _copy_profile_files(source, target / 'Default')
        # 尝试从父目录拷贝 Local State
        local_state = source.parent / 'Local State'
        if local_state.exists():
            try:
                shutil.copy2(local_state, target / 'Local State')
                logger.debug("已拷贝: Local State")
            except Exception as e:
                logger.debug(f"拷贝 Local State 失败: {e}")
    else:
        # 源目录是 User Data 目录，拷贝 Default 子目录
        default_dir = source / 'Default'
        if default_dir.exists():
            _copy_profile_files(default_dir, target / 'Default')
        # 拷贝 Local State
        local_state = source / 'Local State'
        if local_state.exists():
            try:
                shutil.copy2(local_state, target / 'Local State')
                logger.debug("已拷贝: Local State")
            except Exception as e:
                logger.debug(f"拷贝 Local State 失败: {e}")


def _copy_profile_files(source: Path, target: Path):
    """拷贝 profile 目录中的关键文件

    Args:
        source: 源 profile 目录（如 Default）
        target: 目标 profile 目录
    """
    # profile 目录中的关键文件
    important_items = [
        'Preferences',
        'Cookies',
        'Login Data',
        'Web Data',
        'Bookmarks',
        'Favicons',
        'History',
        'Network',
        'Local Storage',
        'Session Storage',
        'IndexedDB',
    ]

    # 需要跳过的目录
    skip_patterns = [
        'Cache', 'Code Cache', 'GPUCache', 'ShaderCache',
        'Service Worker', 'GrShaderCache', 'blob_storage', 'CacheStorage',
    ]

    target.mkdir(parents=True, exist_ok=True)

    for item in important_items:
        src_item = source / item
        dst_item = target / item

        if src_item.exists():
            try:
                if src_item.is_file():
                    shutil.copy2(src_item, dst_item)
                    logger.debug(f"已拷贝: {item}")
                elif src_item.is_dir():
                    if any(skip in item for skip in skip_patterns):
                        continue
                    if dst_item.exists():
                        shutil.rmtree(dst_item)
                    shutil.copytree(src_item, dst_item, ignore=shutil.ignore_patterns(
                        'Cache', 'Code Cache', 'GPUCache', '*.log', '*.tmp'
                    ))
                    logger.debug(f"已拷贝: {item}")
            except Exception as e:
                logger.debug(f"拷贝 {item} 失败: {e}")


def get_chrome_user_data_path(configured_path: str = None) -> str:
    """获取最终使用的 Chrome 用户数据目录

    始终使用项目 data 目录下的用户数据，避免与系统 Chrome 冲突。
    如果配置了源路径，会从该路径拷贝；否则自动检测系统 Chrome 目录。

    Args:
        configured_path: 配置的源用户数据路径（用于拷贝）

    Returns:
        str: 最终使用的用户数据目录路径（在项目 data 目录下）
    """
    logger.info(f"[chrome_helper] 输入源路径: {configured_path}")
    # 始终使用项目目录，从配置的路径或系统路径拷贝
    result = ensure_project_chrome_data(source_path=configured_path)
    logger.info(f"[chrome_helper] 返回项目路径: {result}")
    return result
