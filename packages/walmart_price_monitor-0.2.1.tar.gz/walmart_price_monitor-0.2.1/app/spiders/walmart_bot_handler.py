#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Walmart 防爬验证处理器
专门处理 Walmart 网站的各种防爬验证场景
"""

import time
import logging
from typing import Optional, Callable
from enum import Enum

from app.selectors.walmart_selectors import WalmartSelectors, WalmartTimeouts

logger = logging.getLogger(__name__)


class BotDetectionType(Enum):
    """防爬验证类型"""
    NONE = "none"                    # 无验证
    LOGO_CLICK = "logo_click"        # 需要点击 Logo 按钮
    CAPTCHA = "captcha"              # 验证码
    PRESS_HOLD = "press_hold"        # 按住按钮验证
    PUZZLE = "puzzle"                # 拼图验证
    BLOCKED = "blocked"              # 被封禁
    UNKNOWN = "unknown"              # 未知类型


class WalmartBotHandler:
    """Walmart 防爬验证处理器

    处理 Walmart 网站的各种防爬验证场景：
    1. Logo 点击验证 - 页面只显示 Logo，需要点击进入下一步
    2. 验证码 - 需要手动输入验证码
    3. 按住验证 - 需要按住按钮一段时间
    4. 拼图验证 - 需要拖动拼图
    """

    # 验证页面特征选择器
    SELECTORS = {
        # Logo 点击验证
        'logo_click': {
            'indicators': [
                'a.header-logo',
                'a[aria-label*="Walmart"][href="/"]',
                'span.elc-icon-spark'
            ],
            'click_targets': [
                'a.header-logo',
                'a[aria-label*="Walmart"][href="/"]',
                'a[aria-label*="Save Money"]'
            ]
        },
        # 验证码
        'captcha': {
            'indicators': [
                'css:[data-testid="captcha"]',
                'css:#captcha-container',
                'css:input#captchacharacters',
                'css:.captcha-container'
            ]
        },
        # 按住验证 (PerimeterX)
        'press_hold': {
            'indicators': [
                # 英文界面
                'text:Press and hold',
                'text:Activate and hold',
                'text:press & hold',
                # 中文界面
                'text:按住',
                'text:请稍候',
                'text:再次按下',
                # HTML结构特征
                'css:div.re-captcha',
                'css:#px-captcha',
                'css:p.bot-message',
                'css:[data-testid="press-and-hold"]'
            ],
            'hold_targets': [
                'css:[data-testid="press-and-hold-button"]',
                'text=Press',
                'text:按住'
            ]
        },
        # 拼图验证
        'puzzle': {
            'indicators': [
                'css:[data-testid="puzzle-captcha"]',
                'css:.puzzle-container',
                'text=Slide to verify'
            ]
        },
        # 被封禁
        'blocked': {
            'indicators': [
                'text=Access Denied',
                'text=blocked',
                'text=unusual activity'
            ]
        }
    }

    def __init__(self, page, terminal_ui=None, on_captcha_callback: Optional[Callable] = None):
        """初始化防爬处理器

        Args:
            page: DrissionPage 页面对象
            terminal_ui: 终端UI实例（可选）
            on_captcha_callback: 验证码回调函数（可选）
        """
        self.page = page
        self.terminal_ui = terminal_ui
        self.on_captcha_callback = on_captcha_callback

        # 统计数据
        self.stats = {
            'logo_click_count': 0,
            'captcha_count': 0,
            'press_hold_count': 0,
            'puzzle_count': 0,
            'blocked_count': 0,
            'success_count': 0,
            'fail_count': 0
        }

    def detect(self) -> BotDetectionType:
        """检测当前页面的防爬验证类型

        Returns:
            BotDetectionType: 验证类型
        """
        try:
            # 首先检查是否有正常的商品内容
            if self._has_product_content():
                return BotDetectionType.NONE

            # 检查各种验证类型（按严重程度排序）
            if self._check_blocked():
                logger.warning("检测到访问被封禁")
                return BotDetectionType.BLOCKED

            if self._check_captcha():
                logger.info("检测到验证码页面")
                return BotDetectionType.CAPTCHA

            if self._check_press_hold():
                logger.info("检测到按住验证页面")
                return BotDetectionType.PRESS_HOLD

            if self._check_puzzle():
                logger.info("检测到拼图验证页面")
                return BotDetectionType.PUZZLE

            if self._check_logo_click():
                logger.info("检测到 Logo 点击验证页面")
                return BotDetectionType.LOGO_CLICK

            return BotDetectionType.NONE

        except Exception as e:
            logger.error(f"检测防爬验证类型时出错: {e}")
            return BotDetectionType.UNKNOWN

    def handle(self, detection_type: BotDetectionType = None) -> bool:
        """处理防爬验证

        Args:
            detection_type: 验证类型，如果为 None 则自动检测

        Returns:
            bool: 是否成功通过验证
        """
        if detection_type is None:
            detection_type = self.detect()

        if detection_type == BotDetectionType.NONE:
            return True

        logger.info(f"开始处理防爬验证: {detection_type.value}")

        handlers = {
            BotDetectionType.LOGO_CLICK: self._handle_logo_click,
            BotDetectionType.CAPTCHA: self._handle_captcha,
            BotDetectionType.PRESS_HOLD: self._handle_press_hold,
            BotDetectionType.PUZZLE: self._handle_puzzle,
            BotDetectionType.BLOCKED: self._handle_blocked,
            BotDetectionType.UNKNOWN: self._handle_unknown
        }

        handler = handlers.get(detection_type)
        if handler:
            success = handler()
            if success:
                self.stats['success_count'] += 1
            else:
                self.stats['fail_count'] += 1
            return success

        return False

    def _has_product_content(self) -> bool:
        """检查页面是否有商品内容"""
        try:
            # 检查商品标题
            if self.page.ele(WalmartSelectors.PageStatus.PRODUCT_TITLE, timeout=WalmartTimeouts.QUICK):
                return True

            # 检查购买区域
            if self.page.ele(WalmartSelectors.PageStatus.BUY_BOX, timeout=WalmartTimeouts.QUICK):
                return True

            # 检查搜索框（正常页面应该有）
            if self.page.ele(WalmartSelectors.PageStatus.SEARCH_BOX, timeout=WalmartTimeouts.QUICK):
                # 有搜索框但没有商品内容，可能是其他页面
                pass

            return False

        except Exception:
            return False

    def _check_logo_click(self) -> bool:
        """检查是否是 Logo 点击验证页面"""
        try:
            for selector in self.SELECTORS['logo_click']['indicators']:
                if self.page.ele(selector, timeout=WalmartTimeouts.QUICK):
                    # 确认没有商品内容
                    if not self._has_product_content():
                        return True
            return False
        except Exception:
            return False

    def _check_captcha(self) -> bool:
        """检查是否是验证码页面"""
        try:
            for selector in self.SELECTORS['captcha']['indicators']:
                if self.page.ele(selector, timeout=WalmartTimeouts.QUICK):
                    return True
            return False
        except Exception:
            return False

    def _check_press_hold(self) -> bool:
        """检查是否是按住验证页面"""
        try:
            for selector in self.SELECTORS['press_hold']['indicators']:
                if self.page.ele(selector, timeout=WalmartTimeouts.QUICK):
                    return True
            return False
        except Exception:
            return False

    def _check_puzzle(self) -> bool:
        """检查是否是拼图验证页面"""
        try:
            for selector in self.SELECTORS['puzzle']['indicators']:
                if self.page.ele(selector, timeout=WalmartTimeouts.QUICK):
                    return True
            return False
        except Exception:
            return False

    def _check_blocked(self) -> bool:
        """检查是否被封禁"""
        try:
            for selector in self.SELECTORS['blocked']['indicators']:
                if self.page.ele(selector, timeout=WalmartTimeouts.QUICK):
                    return True
            return False
        except Exception:
            return False

    def _handle_logo_click(self) -> bool:
        """处理 Logo 点击验证

        点击 Logo 按钮进入下一步验证

        Returns:
            bool: 是否成功
        """
        self.stats['logo_click_count'] += 1

        max_attempts = 3
        for attempt in range(1, max_attempts + 1):
            try:
                # 尝试点击各种 Logo 选择器
                for selector in self.SELECTORS['logo_click']['click_targets']:
                    logo_button = self.page.ele(selector, timeout=WalmartTimeouts.SHORT)
                    if logo_button:
                        logger.info(f"点击 Logo 按钮: {selector} (第 {attempt} 次)")
                        logo_button.click()
                        time.sleep(WalmartTimeouts.MEDIUM)

                        # 检查结果
                        new_type = self.detect()
                        if new_type == BotDetectionType.NONE:
                            logger.info("Logo 点击验证通过")
                            return True
                        elif new_type == BotDetectionType.CAPTCHA:
                            logger.info("进入验证码页面")
                            return self._handle_captcha()
                        elif new_type == BotDetectionType.PRESS_HOLD:
                            logger.info("进入按住验证页面")
                            return self._handle_press_hold()

                        break

                time.sleep(WalmartTimeouts.NORMAL)

            except Exception as e:
                logger.warning(f"Logo 点击处理出错 (第 {attempt} 次): {e}")
                time.sleep(1)

        logger.warning("Logo 点击验证失败")
        return False

    def _handle_captcha(self) -> bool:
        """处理验证码

        等待用户手动输入验证码

        Returns:
            bool: 是否成功
        """
        self.stats['captcha_count'] += 1

        logger.warning("检测到验证码，需要手动输入（等待中...）")

        max_wait_time = 120  # 最长等待2分钟
        start_time = time.time()

        while time.time() - start_time < max_wait_time:
            try:
                # 检查验证码是否还存在
                if not self._check_captcha():
                    # 验证码消失，检查是否通过
                    time.sleep(1)
                    if self._has_product_content() or self.detect() == BotDetectionType.NONE:
                        logger.info("验证码验证通过")
                        return True

                # 检查验证码输入框
                captcha_input = self.page.ele('css:input#captchacharacters', timeout=WalmartTimeouts.QUICK)
                if captcha_input:
                    input_value = captcha_input.attr('value') or ''
                    if len(input_value) >= 4:
                        # 尝试提交
                        self._try_submit_captcha()
                        time.sleep(1)

                time.sleep(0.5)

            except Exception as e:
                logger.debug(f"验证码处理过程出错: {e}")
                time.sleep(0.5)

        logger.warning("验证码等待超时")
        return False

    def _try_submit_captcha(self):
        """尝试提交验证码"""
        try:
            # 方式1: 点击 submit 按钮
            submit_btn = self.page.ele('css:button[type="submit"]', timeout=WalmartTimeouts.QUICK)
            if submit_btn:
                submit_btn.click()
                return

            # 方式2: 点击 input submit
            submit_input = self.page.ele('css:input[type="submit"]', timeout=WalmartTimeouts.QUICK)
            if submit_input:
                submit_input.click()
                return

            # 方式3: 按文本查找按钮
            for btn_text in ['Continue shopping', 'Submit', 'Continue', 'Verify']:
                btn = self.page.ele(f'text={btn_text}', timeout=WalmartTimeouts.QUICK)
                if btn:
                    btn.click()
                    return

            # 方式4: 按回车
            captcha_input = self.page.ele('css:input#captchacharacters', timeout=WalmartTimeouts.QUICK)
            if captcha_input:
                captcha_input.input('\n')

        except Exception as e:
            logger.debug(f"提交验证码出错: {e}")

    def _handle_press_hold(self) -> bool:
        """处理按住验证 (PerimeterX)

        PerimeterX 使用 Shadow DOM + iframe 实现验证,无法自动化处理
        验证流程:
        1. 用户按住圆形按钮(左侧小人图标)
        2. 等待加载(3-5秒),左边会显示进度
        3. 出现"再次按下"按钮后点击
        4. 验证通过,页面自动跳转

        Returns:
            bool: 是否成功
        """
        self.stats['press_hold_count'] += 1

        logger.warning("=" * 60)
        logger.warning("检测到 PerimeterX 按住验证 (无法自动化处理)")
        logger.warning("=" * 60)
        logger.warning("请手动完成以下步骤:")
        logger.warning("1. 按住页面上的圆形按钮(左侧小人图标)")
        logger.warning("2. 等待加载完成(约3-5秒)")
        logger.warning("3. 出现'再次按下'按钮后点击")
        logger.warning("4. 等待页面自动跳转...")
        logger.warning("")
        logger.warning("程序将等待最多120秒,完成后会自动继续")
        logger.warning("=" * 60)

        # 尝试自动处理(使用 shadow_root API)
        try:
            logger.debug("尝试自动处理按住验证...")

            # 方法1: 尝试通过普通选择器
            for selector in self.SELECTORS['press_hold'].get('hold_targets', []):
                hold_button = self.page.ele(selector, timeout=WalmartTimeouts.QUICK)
                if hold_button:
                    logger.debug(f"找到按钮: {selector},尝试点击...")
                    try:
                        hold_button.click()
                        time.sleep(5)

                        if self.detect() == BotDetectionType.NONE:
                            logger.info("自动按住验证成功!")
                            return True
                    except Exception as e:
                        logger.debug(f"自动点击失败: {e}")

            # 方法2: 尝试通过 Shadow DOM 访问 (重要!)
            # DrissionPage 支持通过 .sr 或 .shadow_root 访问 closed shadow root
            logger.debug("尝试通过 Shadow DOM 访问验证按钮...")

            # 查找 PerimeterX 容器
            px_container = self.page.ele('css:#px-captcha', timeout=WalmartTimeouts.QUICK)
            if not px_container:
                px_container = self.page.ele('css:div.re-captcha', timeout=WalmartTimeouts.QUICK)

            if px_container:
                logger.debug("找到 PerimeterX 容器")

                try:
                    # 获取 shadow root (DrissionPage 特性)
                    shadow_root = px_container.sr  # 简写形式
                    logger.debug("成功获取 shadow root")

                    # ✅ 关键修复: 找到真实的 iframe (display: block)，过滤掉伪装的 (display: none)
                    iframe = self._find_real_iframe(shadow_root)
                    if iframe:
                        logger.debug("找到真实的 iframe (display: block)")

                        # 在 iframe 内查找按住按钮
                        # 使用更精确的选择器 (用户提供的HTML)
                        button_selectors = [
                            '@role=button',                    # role="button" (最准确)
                            '@aria-label:可访问性',            # aria-label包含"可访问性"
                            '@aria-label:accessibility',       # 英文版
                            'css:a[role="button"]',           # <a role="button">
                            'text:按住',
                            'text:Press',
                            'css:button',
                            'css:div[role="button"]'
                        ]

                        for btn_selector in button_selectors:
                            try:
                                hold_button = iframe.ele(btn_selector, timeout=WalmartTimeouts.QUICK)
                                if hold_button:
                                    logger.info(f"找到按住按钮: {btn_selector}")
                                    logger.debug(f"按钮信息: {hold_button.tag} - aria-label={hold_button.attr('aria-label')}")

                                    # ✅ 使用改进的按住操作方法
                                    logger.info("开始模拟按住操作...")
                                    self._perform_hold_action(hold_button)

                                    # ✅ 关键修复: 处理"再次按下"和"请再试一次"的多轮重试
                                    max_retry_rounds = 3
                                    for retry_round in range(max_retry_rounds):
                                        logger.debug(f"第 {retry_round + 1} 轮检查...")

                                        # 等待页面响应
                                        time.sleep(2)

                                        # 检查是否已通过验证
                                        if self.detect() == BotDetectionType.NONE:
                                            logger.info("通过 Shadow DOM 自动验证成功!")
                                            return True

                                        # 重新获取真实 iframe（页面可能重新渲染）
                                        current_iframe = self._find_real_iframe(shadow_root)
                                        if not current_iframe:
                                            logger.debug("无法找到真实 iframe，重试...")
                                            time.sleep(1)
                                            continue

                                        # 检查是否出现"请再试一次"错误
                                        if self._check_retry_error(shadow_root):
                                            logger.warning(f"检测到'请再试一次'错误，等待后重试 (第 {retry_round + 1} 轮)")
                                            time.sleep(3)  # 等待错误消失

                                            # 重新找到按钮并执行按住操作
                                            new_button = self._find_hold_button_in_iframe(current_iframe)
                                            if new_button:
                                                logger.info("重新执行按住操作...")
                                                self._perform_hold_action(new_button)
                                            continue

                                        # 检查是否需要"再次按下"
                                        retry_button = self._find_retry_button(current_iframe, hold_button)
                                        if retry_button:
                                            logger.info("检测到'再次按下'按钮，点击...")
                                            try:
                                                retry_button.click()
                                                time.sleep(2)
                                            except Exception as e:
                                                logger.debug(f"点击'再次按下'失败: {e}")
                                            continue

                                        # 没有发现需要处理的状态，退出循环
                                        break

                                    # 最终检查是否通过
                                    time.sleep(1)
                                    if self.detect() == BotDetectionType.NONE:
                                        logger.info("通过 Shadow DOM 自动验证成功!")
                                        return True

                                    logger.debug(f"按钮 {btn_selector} 未能通过验证")

                            except Exception as e:
                                logger.debug(f"尝试按钮 {btn_selector} 失败: {e}")
                                continue

                except AttributeError:
                    logger.debug("当前 DrissionPage 版本可能不支持 .sr 属性")
                    logger.debug("尝试使用 .shadow_root 属性...")
                    try:
                        shadow_root = px_container.shadow_root
                        logger.debug("使用 .shadow_root 获取成功")
                        # ... 相同的逻辑
                    except Exception as e2:
                        logger.debug(f"访问 shadow_root 失败: {e2}")

                except Exception as e:
                    logger.debug(f"Shadow DOM 访问失败: {e}")
            else:
                logger.debug("未找到 PerimeterX 容器")

        except Exception as e:
            logger.debug(f"自动处理失败: {e}")

        # 等待用户手动完成验证
        logger.info("等待手动完成按住验证...")
        return self._wait_for_press_hold_completion(timeout=120)

    def _find_real_iframe(self, shadow_root):
        """在 Shadow DOM 中找到真实的 iframe（过滤掉 display: none 的伪装 iframe）

        PerimeterX 会生成多个伪装的 iframe (display: none)，只有一个是真实的 (display: block)

        Args:
            shadow_root: Shadow DOM 根节点

        Returns:
            真实的 iframe 元素，如果找不到返回 None
        """
        try:
            # 获取所有 iframe
            all_iframes = shadow_root.eles('tag:iframe')
            logger.debug(f"找到 {len(all_iframes)} 个 iframe")

            for idx, iframe in enumerate(all_iframes):
                try:
                    # 获取 style 属性
                    style = iframe.attr('style') or ''

                    # 检查是否是 display: block（真实 iframe）
                    # 伪装的 iframe 是 display: none
                    if 'display: block' in style or 'display:block' in style:
                        logger.debug(f"iframe[{idx}] 是真实的 (display: block)")
                        return iframe

                    # 如果没有 display: none，也可能是真实的
                    if 'display: none' not in style and 'display:none' not in style:
                        # 检查是否有实际尺寸
                        if 'width: 100%' in style or 'height: 102px' in style:
                            logger.debug(f"iframe[{idx}] 可能是真实的 (有尺寸且非 none)")
                            return iframe

                except Exception as e:
                    logger.debug(f"检查 iframe[{idx}] 失败: {e}")
                    continue

            # 如果没找到明确的 display: block，返回第一个非 hidden 的
            for idx, iframe in enumerate(all_iframes):
                try:
                    style = iframe.attr('style') or ''
                    if 'display: none' not in style and 'display:none' not in style:
                        logger.debug(f"使用 iframe[{idx}] (第一个非 hidden)")
                        return iframe
                except:
                    continue

            # 兜底：返回第一个
            if all_iframes:
                logger.debug("使用第一个 iframe 作为兜底")
                return all_iframes[0]

            return None

        except Exception as e:
            logger.debug(f"查找真实 iframe 失败: {e}")
            return None

    def _check_retry_error(self, shadow_root) -> bool:
        """检查是否出现"请再试一次"错误

        Args:
            shadow_root: Shadow DOM 根节点

        Returns:
            bool: 是否出现错误
        """
        try:
            # 错误信息选择器
            error_selectors = [
                'text:请再试一次',
                'text:Please try again',
                'text:Try again',
                '@role=alert',  # role="alert" 的元素通常是错误提示
                'css:p[role="alert"]',
            ]

            for selector in error_selectors:
                try:
                    error_elem = shadow_root.ele(selector, timeout=0.5)
                    if error_elem:
                        text = error_elem.text or ''
                        # 确认是错误信息（包含重试相关的文字）
                        if any(kw in text for kw in ['再试', 'try again', 'Try again', '重试']):
                            logger.debug(f"检测到错误提示: {text}")
                            return True
                except:
                    continue

            return False

        except Exception as e:
            logger.debug(f"检查错误状态失败: {e}")
            return False

    def _find_hold_button_in_iframe(self, iframe):
        """在 iframe 中找到按住按钮

        Args:
            iframe: iframe 元素

        Returns:
            按钮元素，如果找不到返回 None
        """
        button_selectors = [
            '@role=button',
            '@aria-label:可访问性',
            '@aria-label:accessibility',
            'css:a[role="button"]',
            'text:按住',
            'text:Press',
            'css:button',
            'css:div[role="button"]'
        ]

        for selector in button_selectors:
            try:
                button = iframe.ele(selector, timeout=1)
                if button:
                    return button
            except:
                continue

        return None

    def _find_retry_button(self, iframe, original_button):
        """找到"再次按下"按钮

        Args:
            iframe: iframe 元素
            original_button: 原始的按住按钮（用于排除）

        Returns:
            "再次按下"按钮元素，如果找不到返回 None
        """
        retry_selectors = [
            'text:再次按下',
            'text:Press again',
            'text:再次',
            '@aria-label:再次',
        ]

        for selector in retry_selectors:
            try:
                button = iframe.ele(selector, timeout=1)
                if button and button != original_button:
                    return button
            except:
                continue

        return None

    def _perform_hold_action(self, button, hold_duration: float = None) -> bool:
        """执行按住操作

        ✅ 关键修复: 使用 DrissionPage 的 actions API 进行真实鼠标操作
        通过 CDP 协议发送事件，isTrusted = true，可以通过 PerimeterX 检测

        Args:
            button: 按钮元素
            hold_duration: 按住时长（秒），默认随机 5-8 秒

        Returns:
            bool: 是否成功执行
        """
        import random

        if hold_duration is None:
            hold_duration = random.uniform(5, 8)  # 增加按住时间

        try:
            logger.info(f"执行真实鼠标按住操作，持续 {hold_duration:.1f} 秒...")

            # 方法1: 尝试使用 DrissionPage 的 actions API（真实鼠标事件，isTrusted=true）
            try:
                # 获取按钮在页面上的坐标
                # 由于按钮在 iframe 的 shadow DOM 中，需要通过 JS 获取相对于视口的坐标
                js_get_coords = '''
                var rect = this.getBoundingClientRect();
                return {
                    x: rect.left + rect.width / 2,
                    y: rect.top + rect.height / 2,
                    width: rect.width,
                    height: rect.height
                };
                '''
                coords = button.run_js(js_get_coords)

                if coords and coords.get('x') and coords.get('y'):
                    x = coords['x']
                    y = coords['y']
                    logger.debug(f"按钮视口坐标: ({x}, {y})")

                    # 获取 iframe 相对于主页面的偏移量
                    # 需要遍历所有父级 iframe 累加偏移
                    iframe_offset = self._get_iframe_offset()
                    if iframe_offset:
                        x += iframe_offset['x']
                        y += iframe_offset['y']
                        logger.debug(f"加上 iframe 偏移后: ({x}, {y})")

                    # 使用 DrissionPage 的 actions API 执行真实鼠标操作
                    logger.info(f"使用 actions API 移动到 ({x:.0f}, {y:.0f}) 并按住...")

                    # 先移动到按钮位置
                    self.page.actions.move_to((x, y))
                    time.sleep(random.uniform(0.1, 0.3))

                    # 按住鼠标
                    self.page.actions.hold()
                    logger.debug("已按住鼠标 (isTrusted=true)")

                    # 保持按住状态，期间轻微移动鼠标（模拟人类抖动）
                    start_time = time.time()
                    while time.time() - start_time < hold_duration:
                        time.sleep(0.3)
                        # 轻微移动（抖动）
                        jitter_x = random.randint(-3, 3)
                        jitter_y = random.randint(-3, 3)
                        try:
                            self.page.actions.move(jitter_x, jitter_y)
                        except:
                            pass

                    # 释放鼠标
                    self.page.actions.release()
                    logger.debug("已释放鼠标")
                    logger.info("真实鼠标按住操作完成")

                    return True

            except Exception as e:
                logger.warning(f"actions API 失败: {e}，尝试备用方案...")

            # 方法2: 备用方案 - 使用 CDP 直接发送 Input 事件
            try:
                logger.debug("尝试使用 CDP Input 事件...")

                # 获取按钮坐标
                js_get_coords = '''
                var rect = this.getBoundingClientRect();
                return {x: rect.left + rect.width / 2, y: rect.top + rect.height / 2};
                '''
                coords = button.run_js(js_get_coords)

                if coords:
                    x, y = coords['x'], coords['y']

                    # 获取 iframe 偏移
                    iframe_offset = self._get_iframe_offset()
                    if iframe_offset:
                        x += iframe_offset['x']
                        y += iframe_offset['y']

                    # 使用 CDP Input.dispatchMouseEvent
                    # DrissionPage 的 page.run_cdp 可以调用 CDP 方法
                    self.page.run_cdp('Input.dispatchMouseEvent', type='mousePressed',
                                      x=x, y=y, button='left', clickCount=1)
                    logger.debug("CDP: mousePressed")

                    time.sleep(hold_duration)

                    self.page.run_cdp('Input.dispatchMouseEvent', type='mouseReleased',
                                      x=x, y=y, button='left', clickCount=1)
                    logger.debug("CDP: mouseReleased")
                    logger.info("CDP 鼠标按住操作完成")

                    return True

            except Exception as e:
                logger.warning(f"CDP 方案也失败: {e}")

            # 方法3: 最后尝试直接点击（可能不会通过验证，但至少尝试）
            logger.debug("尝试直接点击...")
            button.click()
            time.sleep(hold_duration)
            return True

        except Exception as e:
            logger.warning(f"执行按住操作失败: {e}")
            return False

    def _get_iframe_offset(self) -> dict:
        """获取 px-captcha iframe 相对于主页面的偏移量

        Returns:
            dict: {'x': offset_x, 'y': offset_y} 或 None
        """
        try:
            # 查找 px-captcha 容器
            px_container = self.page.ele('css:#px-captcha', timeout=1)
            if px_container:
                # 获取容器在页面上的位置
                js_get_offset = '''
                var rect = this.getBoundingClientRect();
                return {x: rect.left, y: rect.top};
                '''
                offset = px_container.run_js(js_get_offset)
                if offset:
                    logger.debug(f"iframe 偏移量: {offset}")
                    return offset

            return {'x': 0, 'y': 0}

        except Exception as e:
            logger.debug(f"获取 iframe 偏移失败: {e}")
            return {'x': 0, 'y': 0}

    def _wait_for_press_hold_completion(self, timeout: int = 120) -> bool:
        """等待按住验证完成

        监控页面变化,判断验证是否通过

        Args:
            timeout: 超时时间(秒)

        Returns:
            bool: 是否成功
        """
        start_time = time.time()
        last_log_time = start_time

        while time.time() - start_time < timeout:
            try:
                # 每10秒提醒一次
                current_time = time.time()
                if current_time - last_log_time >= 10:
                    elapsed = int(current_time - start_time)
                    remaining = timeout - elapsed
                    logger.info(f"等待手动验证... (已等待 {elapsed}秒, 剩余 {remaining}秒)")
                    last_log_time = current_time

                # 检查是否通过验证(多种方式)

                # 方式1: 检查是否有商品内容
                if self._has_product_content():
                    logger.info("检测到商品内容,按住验证通过!")
                    return True

                # 方式2: 检查按住验证元素是否消失
                if not self._check_press_hold():
                    # 验证页面消失,等待1秒后再次确认
                    time.sleep(1)
                    if self.detect() == BotDetectionType.NONE:
                        logger.info("按住验证页面已消失,验证通过!")
                        return True

                # 方式3: 检查URL是否变化
                current_url = self.page.url
                if '/ip/' in current_url and 'robot_or_human' not in current_url.lower():
                    # URL包含商品ID且不包含验证标识
                    logger.info("URL已跳转,按住验证通过!")
                    return True

                time.sleep(0.5)

            except Exception as e:
                logger.debug(f"等待按住验证过程出错: {e}")
                time.sleep(1)

        logger.warning("按住验证等待超时")
        return False

    def _handle_puzzle(self) -> bool:
        """处理拼图验证

        拼图验证通常需要手动完成

        Returns:
            bool: 是否成功
        """
        self.stats['puzzle_count'] += 1

        logger.warning("检测到拼图验证，需要手动完成（等待中...）")
        return self._wait_for_manual_verification(timeout=120)

    def _handle_blocked(self) -> bool:
        """处理被封禁

        Returns:
            bool: 始终返回 False
        """
        self.stats['blocked_count'] += 1
        logger.error("访问被封禁，无法继续")
        return False

    def _handle_unknown(self) -> bool:
        """处理未知验证类型

        Returns:
            bool: 是否成功
        """
        logger.warning("未知的验证类型，等待手动处理...")
        return self._wait_for_manual_verification(timeout=60)

    def _wait_for_manual_verification(self, timeout: int = 60) -> bool:
        """等待手动验证完成

        Args:
            timeout: 超时时间（秒）

        Returns:
            bool: 是否成功
        """
        start_time = time.time()

        while time.time() - start_time < timeout:
            try:
                # 检查是否通过验证
                if self._has_product_content():
                    logger.info("手动验证通过")
                    return True

                if self.detect() == BotDetectionType.NONE:
                    logger.info("验证通过")
                    return True

                time.sleep(1)

            except Exception as e:
                logger.debug(f"等待验证过程出错: {e}")
                time.sleep(1)

        logger.warning("手动验证等待超时")
        return False

    def get_stats(self) -> dict:
        """获取统计数据"""
        return self.stats.copy()

    def reset_stats(self):
        """重置统计数据"""
        for key in self.stats:
            self.stats[key] = 0
