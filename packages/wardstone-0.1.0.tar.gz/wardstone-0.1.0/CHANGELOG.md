# Changelog

## 0.1.0 (2025-01-01)

- Initial release
- `Wardstone` sync client and `AsyncWardstone` async client
- Pydantic v2 models for all API request/response shapes
- Retry with exponential backoff on 429 and 5xx errors
- Rate limit info parsed from response headers
- Exception hierarchy (AuthenticationError, BadRequestError, RateLimitError, etc.)
- Context manager support (`with` / `async with`)
- PEP 561 compatible (py.typed marker)
- Python >= 3.9
