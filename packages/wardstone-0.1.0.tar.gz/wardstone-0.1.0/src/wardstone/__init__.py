"""Wardstone Python SDK: LLM security, prompt injection detection, and content moderation."""

from ._async_client import AsyncWardstone
from ._client import Wardstone
from ._errors import (
    AuthenticationError,
    BadRequestError,
    ConnectionError,  # noqa: F401 (kept for explicit import, not in __all__)
    InternalServerError,
    PermissionError,  # noqa: F401 (kept for explicit import, not in __all__)
    RateLimitError,
    TimeoutError,  # noqa: F401 (kept for explicit import, not in __all__)
    WardstoneConnectionError,
    WardstoneError,
    WardstonePermissionError,
    WardstoneTimeoutError,
)
from ._types import (
    DetectResponse,
    DetectResult,
    Processing,
    RateLimitInfo,
    RawScores,
    RiskBand,
    RiskBands,
    Subcategories,
    UnknownLinks,
)
from ._version import __version__

__all__ = [
    # Clients
    "Wardstone",
    "AsyncWardstone",
    # Errors (canonical names, no builtin shadowing)
    "WardstoneError",
    "AuthenticationError",
    "BadRequestError",
    "WardstonePermissionError",
    "RateLimitError",
    "InternalServerError",
    "WardstoneConnectionError",
    "WardstoneTimeoutError",
    # Types
    "DetectResponse",
    "DetectResult",
    "RiskBands",
    "RiskBand",
    "Processing",
    "RateLimitInfo",
    "RawScores",
    "Subcategories",
    "UnknownLinks",
    # Meta
    "__version__",
]
