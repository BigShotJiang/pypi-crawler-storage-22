from __future__ import annotations

import asyncio
import json
from typing import Any

import httpx

from ._base_client import (
    DEFAULT_BASE_URL,
    DEFAULT_MAX_RETRIES,
    DEFAULT_TIMEOUT,
    _sanitize_transport_error,
    astream_error_body,
    astream_response_body,
    build_detect_body,
    build_headers,
    build_result,
    check_content_length,
    check_content_type,
    get_auth_header,
    get_retry_delay,
    is_retryable,
    raise_for_status,
    resolve_api_key,
    validate_base_url,
    validate_options,
    validate_scan_strategy,
    validate_text,
)
from ._errors import WardstoneConnectionError, WardstoneError, WardstoneTimeoutError
from ._types import DetectResult, ScanStrategy


class AsyncWardstone:
    """Asynchronous Wardstone API client.

    Usage::

        from wardstone import AsyncWardstone

        client = AsyncWardstone(api_key="wrd_live_...")
        result = await client.detect("text to scan")

        if result.flagged:
            print(result.primary_category)

    Can also be used as an async context manager::

        async with AsyncWardstone() as client:
            result = await client.detect("text")
    """

    __slots__ = ("__api_key", "__dict__")

    def __init__(
        self,
        *,
        api_key: str | None = None,
        base_url: str = DEFAULT_BASE_URL,
        timeout: float = DEFAULT_TIMEOUT,
        max_retries: int = DEFAULT_MAX_RETRIES,
    ) -> None:
        self.__api_key = resolve_api_key(api_key)
        self._base_url = validate_base_url(base_url)
        self._timeout = timeout
        self._max_retries = max_retries
        validate_options(timeout, max_retries)
        self._client = httpx.AsyncClient(
            timeout=timeout,
            headers=build_headers(is_async=True),
            follow_redirects=False,
        )

    def __repr__(self) -> str:
        return f"AsyncWardstone(base_url={self._base_url!r})"

    def __dir__(self) -> list[str]:
        """Exclude the API key attribute from dir() and introspection."""
        mangled = f"_{type(self).__name__}__api_key"
        return [k for k in super().__dir__() if k != mangled]

    def __getstate__(self) -> None:
        """Prevent pickling to avoid leaking internal state."""
        raise TypeError(
            "AsyncWardstone client cannot be pickled. Create a new instance instead."
        )

    def __setstate__(self, state: dict[str, Any]) -> None:
        """Prevent unpickling which would lose the API key."""
        raise TypeError(
            "AsyncWardstone client cannot be unpickled. Create a new instance instead."
        )

    async def __aenter__(self) -> AsyncWardstone:
        return self

    async def __aexit__(self, *_: object) -> None:
        await self.close()

    async def close(self) -> None:
        """Close the underlying HTTP client."""
        await self._client.aclose()

    async def detect(
        self,
        text: str,
        *,
        scan_strategy: ScanStrategy | None = None,
        include_raw_scores: bool | None = None,
    ) -> DetectResult:
        """Analyze text for security threats.

        Args:
            text: The text to analyze (max 8,000,000 characters).
            scan_strategy: How chunked inputs are scanned. One of
                ``"early-exit"`` (default), ``"full-scan"``, or ``"smart-sample"``.
            include_raw_scores: Include raw confidence scores
                (Business and Enterprise plans only).

        Returns:
            A :class:`DetectResult` with detection outcomes and rate limit info.
        """
        validate_text(text)
        validate_scan_strategy(scan_strategy)
        body = build_detect_body(text, scan_strategy, include_raw_scores)
        response_bytes, headers = await self.__request("/api/detect", body)
        return build_result(response_bytes, headers)

    # -----------------------------------------------------------------------
    # Internal
    # -----------------------------------------------------------------------

    async def __request(
        self,
        path: str,
        body: dict[str, object],
    ) -> tuple[bytes, httpx.Headers]:
        """Send a POST request with retry logic.

        Note: Retries only apply to HTTP-level errors (429 and 5xx).
        Connection-level failures (DNS, TCP reset, etc.) raise immediately.
        """
        url = f"{self._base_url}{path}"

        for attempt in range(self._max_retries + 1):
            try:
                request = self._client.build_request(
                    "POST",
                    url,
                    json=body,
                    headers=get_auth_header(self.__api_key),
                )
                response = await self._client.send(request, stream=True)
            except httpx.TimeoutException as exc:
                raise WardstoneTimeoutError(
                    f"Request timed out after {self._timeout}s"
                ) from exc
            except httpx.TransportError as exc:
                raise WardstoneConnectionError(
                    _sanitize_transport_error(exc)
                ) from exc

            try:
                check_content_length(response.headers)

                if response.is_success:
                    check_content_type(response.headers)
                    response_bytes = await astream_response_body(response)
                    return response_bytes, response.headers

                # Read error body with size limit before closing
                error_bytes = await astream_error_body(response)
            finally:
                await response.aclose()

            if is_retryable(response.status_code) and attempt < self._max_retries:
                delay = get_retry_delay(attempt, response.headers)
                await asyncio.sleep(delay)
                continue

            # Parse error body from captured bytes (avoids use-after-close)
            try:
                data = json.loads(error_bytes)
            except Exception:
                data = None
            raise_for_status(response.status_code, data, response.headers)

        # Unreachable: the loop always returns or raises
        raise WardstoneError("Unexpected retry exhaustion")  # pragma: no cover
