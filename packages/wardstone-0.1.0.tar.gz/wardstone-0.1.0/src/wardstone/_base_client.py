from __future__ import annotations

import json
import math
import os
import random
import re
from typing import Any
from urllib.parse import urlparse

from ._errors import (
    AuthenticationError,
    BadRequestError,
    InternalServerError,
    RateLimitError,
    WardstoneError,
    WardstonePermissionError,
)
from ._types import ApiErrorResponse, DetectResponse, DetectResult, RateLimitInfo, ScanStrategy
from ._version import __version__

DEFAULT_BASE_URL = "https://wardstone.ai"
DEFAULT_TIMEOUT = 30.0
DEFAULT_MAX_RETRIES = 2
MAX_MAX_RETRIES = 10
MAX_RETRY_DELAY_S = 60.0
MAX_RESPONSE_BYTES = 10 * 1024 * 1024  # 10 MB
MAX_ERROR_BODY_BYTES = 65_536  # 64 KB for error responses
MAX_TEXT_LENGTH = 8_000_000
MAX_ERROR_MESSAGE_LENGTH = 1000
MIN_API_KEY_LENGTH = 8

VALID_SCAN_STRATEGIES: tuple[ScanStrategy, ...] = ("early-exit", "full-scan", "smart-sample")
LOCALHOST_HOSTS = frozenset({"localhost", "127.0.0.1", "::1", "[::1]"})

# All control characters including \t \n \r to prevent log injection
_CONTROL_CHARS_RE = re.compile(r"[\x00-\x1f\x7f]")


def _sanitize_message(msg: str) -> str:
    """Truncate and strip control characters from server error messages.

    Note: Error messages originate from the API server and may contain
    server-provided content. They are truncated and sanitized but not
    fully validated.
    """
    if len(msg) > MAX_ERROR_MESSAGE_LENGTH:
        truncated = msg[:MAX_ERROR_MESSAGE_LENGTH] + "..."
    else:
        truncated = msg
    return _CONTROL_CHARS_RE.sub("", truncated)


def validate_base_url(url: str) -> str:
    """Validate and normalize the base URL. Enforces HTTPS for remote hosts."""
    trimmed = url.rstrip("/")
    parsed = urlparse(trimmed)

    if parsed.scheme not in ("https", "http"):
        raise WardstoneError(
            f'Invalid base_url scheme "{parsed.scheme}". Only https and http are supported.'
        )

    if parsed.username or parsed.password:
        raise WardstoneError(
            "base_url must not contain credentials (user:pass@host)."
        )

    if parsed.scheme == "http" and parsed.hostname not in LOCALHOST_HOSTS:
        raise WardstoneError(
            "Insecure base_url: HTTP is only allowed for localhost. "
            "Use HTTPS for remote hosts."
        )

    if not parsed.hostname:
        raise WardstoneError(f'Invalid base_url: "{url}" has no hostname.')

    if "\x00" in parsed.hostname or _CONTROL_CHARS_RE.search(parsed.hostname):
        raise WardstoneError("base_url hostname contains invalid characters.")

    if parsed.query or parsed.fragment:
        raise WardstoneError(
            "base_url must not contain query parameters or fragments."
        )

    return trimmed


def validate_options(timeout: float, max_retries: int) -> None:
    """Validate constructor options."""
    if not isinstance(timeout, (int, float)) or math.isnan(timeout) or math.isinf(timeout):
        raise WardstoneError("timeout must be a finite number.")
    if timeout <= 0:
        raise WardstoneError("timeout must be a positive number.")
    if not isinstance(max_retries, int):
        raise WardstoneError("max_retries must be an integer.")
    if max_retries < 0 or max_retries > MAX_MAX_RETRIES:
        raise WardstoneError(f"max_retries must be between 0 and {MAX_MAX_RETRIES}.")


def resolve_api_key(api_key: str | None) -> str:
    """Resolve the API key from the parameter or environment variable."""
    raw = api_key or os.environ.get("WARDSTONE_API_KEY")
    if not raw:
        raise AuthenticationError(
            "API key is required. Pass it via the api_key parameter "
            "or set the WARDSTONE_API_KEY environment variable."
        )
    key = raw.strip()
    if len(key) < MIN_API_KEY_LENGTH:
        raise AuthenticationError(
            f"API key is too short (minimum {MIN_API_KEY_LENGTH} characters). "
            "Check that you are using a valid Wardstone API key."
        )
    return key


def build_headers(*, is_async: bool = False) -> dict[str, str]:
    """Build default headers (Content-Type and User-Agent only, no credentials)."""
    variant = "async" if is_async else "sync"
    return {
        "Content-Type": "application/json",
        "User-Agent": f"wardstone-python/{__version__} ({variant})",
    }


def get_auth_header(api_key: str) -> dict[str, str]:
    """Build the Authorization header. Kept separate so the key is not persisted
    in httpx's default header dict."""
    return {"Authorization": f"Bearer {api_key}"}


def validate_text(text: str) -> None:
    """Validate the text input before sending to the API."""
    if not isinstance(text, str) or len(text) == 0:
        raise BadRequestError(
            "text must be a non-empty string.", code="invalid_input"
        )
    if len(text) > MAX_TEXT_LENGTH:
        raise BadRequestError(
            f"text exceeds maximum length of {MAX_TEXT_LENGTH:,} characters.",
            code="text_too_long",
            max_length=MAX_TEXT_LENGTH,
        )


def validate_scan_strategy(scan_strategy: str | None) -> None:
    """Validate scan_strategy against the allowed literal values."""
    if scan_strategy is not None and scan_strategy not in VALID_SCAN_STRATEGIES:
        raise BadRequestError(
            f"Invalid scan_strategy. "
            f"Must be one of: {', '.join(VALID_SCAN_STRATEGIES)}.",
            code="invalid_input",
        )


def validate_include_raw_scores(include_raw_scores: bool | None) -> None:
    """Validate include_raw_scores is a boolean if provided."""
    if include_raw_scores is not None and not isinstance(include_raw_scores, bool):
        raise BadRequestError(
            "include_raw_scores must be a boolean.", code="invalid_input"
        )


def build_detect_body(
    text: str,
    scan_strategy: str | None = None,
    include_raw_scores: bool | None = None,
) -> dict[str, Any]:
    validate_include_raw_scores(include_raw_scores)
    body: dict[str, Any] = {"text": text}
    if scan_strategy is not None:
        body["scan_strategy"] = scan_strategy
    if include_raw_scores is not None:
        body["include_raw_scores"] = include_raw_scores
    return body


def parse_rate_limit(headers: Any) -> RateLimitInfo:
    """Parse rate limit info from response headers (works with httpx headers)."""

    def _int(key: str) -> int:
        val = headers.get(key)
        if val is None:
            return 0
        try:
            return int(val)
        except (ValueError, TypeError):
            return 0

    return RateLimitInfo(
        limit=_int("X-RateLimit-Limit"),
        remaining=_int("X-RateLimit-Remaining"),
        reset=_int("X-RateLimit-Reset"),
    )


def check_content_length(headers: Any) -> None:
    """Check Content-Length header and reject oversized responses before reading the body."""
    content_length = headers.get("Content-Length")
    if content_length is not None:
        try:
            size = int(content_length)
        except (ValueError, TypeError):
            return
        if size > MAX_RESPONSE_BYTES:
            raise WardstoneError(
                f"Response body too large ({size} bytes). "
                f"Maximum: {MAX_RESPONSE_BYTES} bytes."
            )


def stream_response_body(response: Any) -> bytes:
    """Read response body in chunks with a size limit (sync).

    Uses httpx streaming to abort early if the body exceeds MAX_RESPONSE_BYTES,
    preventing full buffering of oversized responses.
    """
    chunks: list[bytes] = []
    total = 0
    for chunk in response.iter_bytes():
        total += len(chunk)
        if total > MAX_RESPONSE_BYTES:
            raise WardstoneError(
                f"Response body too large (>{MAX_RESPONSE_BYTES} bytes). "
                f"Maximum: {MAX_RESPONSE_BYTES} bytes."
            )
        chunks.append(chunk)
    return b"".join(chunks)


async def astream_response_body(response: Any) -> bytes:
    """Read response body in chunks with a size limit (async).

    Uses httpx async streaming to abort early if the body exceeds MAX_RESPONSE_BYTES,
    preventing full buffering of oversized responses.
    """
    chunks: list[bytes] = []
    total = 0
    async for chunk in response.aiter_bytes():
        total += len(chunk)
        if total > MAX_RESPONSE_BYTES:
            raise WardstoneError(
                f"Response body too large (>{MAX_RESPONSE_BYTES} bytes). "
                f"Maximum: {MAX_RESPONSE_BYTES} bytes."
            )
        chunks.append(chunk)
    return b"".join(chunks)


def stream_error_body(response: Any) -> bytes:
    """Read error response body with a small size limit (sync).

    Truncates after MAX_ERROR_BODY_BYTES to prevent memory exhaustion
    from oversized error responses. The underlying connection may not be
    reusable after truncation (acceptable for error paths).
    """
    chunks: list[bytes] = []
    total = 0
    for chunk in response.iter_bytes():
        remaining = MAX_ERROR_BODY_BYTES - total
        if remaining <= 0:
            break
        if len(chunk) > remaining:
            chunks.append(chunk[:remaining])
            break
        chunks.append(chunk)
        total += len(chunk)
    return b"".join(chunks)


async def astream_error_body(response: Any) -> bytes:
    """Read error response body with a small size limit (async).

    Truncates after MAX_ERROR_BODY_BYTES to prevent memory exhaustion
    from oversized error responses. The underlying connection may not be
    reusable after truncation (acceptable for error paths).
    """
    chunks: list[bytes] = []
    total = 0
    async for chunk in response.aiter_bytes():
        remaining = MAX_ERROR_BODY_BYTES - total
        if remaining <= 0:
            break
        if len(chunk) > remaining:
            chunks.append(chunk[:remaining])
            break
        chunks.append(chunk)
        total += len(chunk)
    return b"".join(chunks)


def check_content_type(headers: Any) -> None:
    """Validate that the response Content-Type is JSON."""
    content_type = headers.get("Content-Type") or ""
    if "application/json" not in content_type.lower():
        safe_ct = content_type[:200] if len(content_type) > 200 else content_type
        raise WardstoneError(
            f"Unexpected Content-Type: {safe_ct!r}. "
            "Expected application/json. This may indicate a proxy, CDN, "
            "or captive portal intercepting the request."
        )


def build_result(data: bytes | dict[str, Any], headers: Any) -> DetectResult:
    """Build a DetectResult from response data (bytes or dict) and headers.

    Note: Content-Type validation is performed by the caller before streaming
    the response body, so it is not repeated here.
    """
    parsed: Any
    if isinstance(data, bytes):
        parsed = json.loads(data)
    else:
        parsed = data
    response = DetectResponse.model_validate(parsed)
    rate_limit = parse_rate_limit(headers)
    return DetectResult(**response.model_dump(), rate_limit=rate_limit)


def raise_for_status(
    status_code: int,
    data: dict[str, Any] | None,
    headers: Any = None,
) -> None:
    """Raise a typed error based on the HTTP status code.

    Note: Error messages originate from the API server. They are sanitized
    (truncated, control characters removed) but may contain server-provided content.
    """
    error_data: ApiErrorResponse | None = None
    if data:
        try:
            error_data = ApiErrorResponse.model_validate(data)
        except Exception:
            pass

    raw_message = error_data.message if error_data else "Request failed"
    message = _sanitize_message(raw_message)

    if status_code == 400:
        raise BadRequestError(
            message,
            code=error_data.error if error_data else None,
            max_length=error_data.max_length if error_data else None,
        )
    elif status_code == 401:
        raise AuthenticationError(message)
    elif status_code == 403:
        raise WardstonePermissionError(message)
    elif status_code == 429:
        retry_after: float | None = None
        if headers is not None:
            try:
                retry_after = float(headers.get("Retry-After", ""))
            except (ValueError, TypeError):
                pass
        raise RateLimitError(message, retry_after=retry_after)
    elif status_code >= 500:
        raise InternalServerError(message)
    else:
        code = error_data.error if error_data else None
        raise WardstoneError(message, status=status_code, code=code)


def get_retry_delay(attempt: int, headers: Any = None) -> float:
    """Calculate retry delay with exponential backoff, capped at MAX_RETRY_DELAY_S.

    Only supports numeric Retry-After values (seconds) for predictability.
    """
    if headers is not None:
        retry_after = headers.get("Retry-After")
        if retry_after is not None:
            try:
                val = float(retry_after)
                if val > 0:
                    return val if val < MAX_RETRY_DELAY_S else MAX_RETRY_DELAY_S
            except (ValueError, TypeError):
                pass
    base_delay = 0.5 * (2**attempt)
    capped = base_delay if base_delay < 8.0 else 8.0
    return capped * (0.5 + random.random() * 0.5)


def is_retryable(status_code: int) -> bool:
    return status_code == 429 or status_code >= 500


_TRANSPORT_ERROR_MAP: dict[str, str] = {
    "connect": "Connection failed",
    "refused": "Connection refused",
    "reset": "Connection reset by peer",
    "dns": "DNS lookup failed",
    "name resolution": "DNS lookup failed",
    "timed out": "Connection timed out",
    "timeout": "Connection timed out",
    "certificate": "TLS certificate error",
    "ssl": "TLS/SSL error",
    "eof": "Connection closed unexpectedly",
}


def _sanitize_transport_error(exc: Exception) -> str:
    """Map transport errors to generic messages to avoid leaking network details."""
    msg = str(exc).lower()
    for pattern, safe_msg in _TRANSPORT_ERROR_MAP.items():
        if pattern in msg:
            return safe_msg
    return "Connection failed"
