from __future__ import annotations


class WardstoneError(Exception):
    """Base exception for all Wardstone SDK errors."""

    status: int | None
    code: str | None

    def __init__(
        self,
        message: str = "An error occurred",
        *,
        status: int | None = None,
        code: str | None = None,
    ) -> None:
        super().__init__(message)
        self.status = status
        self.code = code


class AuthenticationError(WardstoneError):
    """Raised when the API key is missing or invalid (401)."""

    def __init__(self, message: str = "Invalid or missing API key") -> None:
        super().__init__(message, status=401, code="authentication_error")


class BadRequestError(WardstoneError):
    """Raised on 400 responses (invalid JSON, missing text, text too long)."""

    max_length: int | None

    def __init__(
        self,
        message: str = "Bad request",
        *,
        code: str | None = "bad_request",
        max_length: int | None = None,
    ) -> None:
        super().__init__(message, status=400, code=code)
        self.max_length = max_length


class WardstonePermissionError(WardstoneError):
    """Raised when a feature is not available on the current plan (403)."""

    def __init__(self, message: str = "Permission denied") -> None:
        super().__init__(message, status=403, code="permission_error")


class RateLimitError(WardstoneError):
    """Raised when the monthly quota is exceeded (429)."""

    retry_after: float | None

    def __init__(
        self, message: str = "Rate limit exceeded", retry_after: float | None = None
    ) -> None:
        super().__init__(message, status=429, code="rate_limit_error")
        self.retry_after = retry_after


class InternalServerError(WardstoneError):
    """Raised on 5xx server errors."""

    def __init__(self, message: str = "Internal server error") -> None:
        super().__init__(message, status=500, code="internal_server_error")


class WardstoneConnectionError(WardstoneError):
    """Raised when the HTTP connection fails."""

    def __init__(self, message: str = "Connection failed") -> None:
        super().__init__(message, status=None, code="connection_error")


class WardstoneTimeoutError(WardstoneError):
    """Raised when a request exceeds the configured timeout."""

    def __init__(self, message: str = "Request timed out") -> None:
        super().__init__(message, status=None, code="timeout_error")


# Aliases kept for backwards compatibility and convenience.
# These no longer shadow the builtins.
PermissionError = WardstonePermissionError  # noqa: A001
ConnectionError = WardstoneConnectionError  # noqa: A001
TimeoutError = WardstoneTimeoutError  # noqa: A001
