from __future__ import annotations

from typing import Literal

from pydantic import BaseModel, Field

# ---------------------------------------------------------------------------
# Request
# ---------------------------------------------------------------------------

ScanStrategy = Literal["early-exit", "full-scan", "smart-sample"]

RiskLevel = Literal["Low Risk", "Some Risk", "High Risk", "Severe Risk"]

Category = Literal["content_violation", "prompt_attack", "data_leakage", "unknown_links"]

ContentViolationSubtype = Literal[
    "hate", "sexual", "profanity", "violence", "crime", "weapons"
]

DataLeakageSubtype = Literal[
    "address", "credit_card", "email", "iban", "ip_address", "name", "phone_number", "ssn"
]


# ---------------------------------------------------------------------------
# Response models
# ---------------------------------------------------------------------------


class RiskBand(BaseModel):
    level: RiskLevel


class RiskBands(BaseModel):
    content_violation: RiskBand
    prompt_attack: RiskBand
    data_leakage: RiskBand
    unknown_links: RiskBand


class ContentViolationSub(BaseModel):
    triggered: list[ContentViolationSubtype]


class DataLeakageSub(BaseModel):
    triggered: list[DataLeakageSubtype]


class Subcategories(BaseModel):
    content_violation: ContentViolationSub
    data_leakage: DataLeakageSub


class UnknownLinks(BaseModel):
    flagged: bool
    unknown_count: int
    known_count: int
    total_urls: int
    unknown_domains: list[str]


class Processing(BaseModel):
    inference_ms: int
    input_length: int
    scan_strategy: ScanStrategy
    chunks_scanned: int | None = None
    total_chunks: int | None = None


class RawScoreSubcategories(BaseModel):
    content_violation: dict[str, float] | None = None
    data_leakage: dict[str, float] | None = None


class RawScores(BaseModel):
    categories: dict[str, float]
    subcategories: RawScoreSubcategories


class DetectResponse(BaseModel):
    flagged: bool
    risk_bands: RiskBands
    primary_category: Category | None = None
    subcategories: Subcategories
    unknown_links: UnknownLinks
    processing: Processing
    raw_scores: RawScores | None = None


# ---------------------------------------------------------------------------
# Rate limit info (parsed from response headers)
# ---------------------------------------------------------------------------


class RateLimitInfo(BaseModel):
    limit: int
    remaining: int
    reset: int


# ---------------------------------------------------------------------------
# Full result returned by client.detect()
# ---------------------------------------------------------------------------


class DetectResult(DetectResponse):
    """Detection result including rate limit information."""

    rate_limit: RateLimitInfo


# ---------------------------------------------------------------------------
# API error response
# ---------------------------------------------------------------------------


class ApiErrorResponse(BaseModel):
    model_config = {"populate_by_name": True}

    error: str
    message: str
    max_length: int | None = Field(None, alias="maxLength")
