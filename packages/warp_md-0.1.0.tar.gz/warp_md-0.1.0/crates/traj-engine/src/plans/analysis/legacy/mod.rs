pub mod topol;
pub mod param;

pub use topol::{LegacyMolType, LegacyTopology};
pub use param::LegacyParam;
