import contextvars

# Context variable to hold the current transaction
_transaction_context = contextvars.ContextVar("watchup_transaction", default=None)

def set_transaction(tx):
    return _transaction_context.set(tx)

def get_transaction():
    return _transaction_context.get()

def reset_transaction(token):
    _transaction_context.reset(token)
