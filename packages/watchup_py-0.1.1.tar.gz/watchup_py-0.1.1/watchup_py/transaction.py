import time

class Span:
    def __init__(self, name: str):
        self.name = name
        self.start_time = int(time.time() * 1000)  # ms
        self.end_time = None

    def finish(self):
        self.end_time = int(time.time() * 1000)

    @property
    def duration(self):
        end = self.end_time if self.end_time is not None else int(time.time() * 1000)
        return int(end - self.start_time)

class Transaction:
    def __init__(self, name: str):
        self.name = name
        self.start_time = int(time.time() * 1000)  # ms
        self.end_time = None
        self.spans = []

    def finish(self):
        self.end_time = int(time.time() * 1000)

    @property
    def duration(self):
        end = self.end_time if self.end_time is not None else int(time.time() * 1000)
        return int(end - self.start_time)
