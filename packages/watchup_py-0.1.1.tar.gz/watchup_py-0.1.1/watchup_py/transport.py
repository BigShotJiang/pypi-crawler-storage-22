import requests
import threading
import json

def send_payload(config, payload, endpoint="/v1/capture/transaction"):
    def task():
        try:
            url = f"{config['base_url']}{endpoint}"
            headers = {
                "Content-Type": "application/json",
                "X-Watchup-Project": config['project_id'],
                "X-Watchup-Key": config['api_key'],
            }
            
            # Ensure payload has a type
            if 'type' not in payload:
                payload['type'] = 'transaction'
            
            requests.post(url, headers=headers, json=payload, timeout=20)
        except Exception as e:
            # Fail silently
            print(f"[watchup] Failed to send payload to {endpoint}: {e}")

    # Run in background
    threading.Thread(target=task, daemon=True).start()
