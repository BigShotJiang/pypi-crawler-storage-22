from .shape_manager import ShapeManager

__all__ = [
    "ShapeManager",
]
