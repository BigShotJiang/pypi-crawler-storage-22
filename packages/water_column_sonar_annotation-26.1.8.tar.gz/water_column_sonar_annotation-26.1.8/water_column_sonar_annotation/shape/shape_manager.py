class ShapeManager:
    def __init__(
        self,
    ):
        self.DECIMAL_PRECISION = 4

    def point(
        self,
        date_string,
        time_string,
        depth_string,
    ):  # -> returntype # TODO:
        pass

    def polygon(
        self,
        date_string,
        time_string,
        depth_string,
    ):  # -> type # TODO:
        pass

    def bounding_box(
        self,
        date_string,
        time_string,
        depth_string,
    ):  # -> returntype # TODO:
        pass
