from .client import WaterworksClient

__all__ = ["WaterworksClient"]
__version__ = "0.1.0"