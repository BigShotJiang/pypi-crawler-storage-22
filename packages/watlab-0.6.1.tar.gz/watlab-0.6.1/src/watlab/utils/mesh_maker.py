# Watlab - MeshMaker General Conditions
# -----------------------------------------
# Licensed under the BSD 3-Clause License (the "License");
# you may not use this file except in compliance with the License.

# Copyright (c) <2025> <Universite catholique de Louvain (UCLouvain), Belgique>
# All rights reserved.

# Authors (all affiliate to Université catholique de Louvain (UCLouvain), Belgique) : Alexis Girard, Pierre-Yves Gousenbourger, Martin Petitjean

# Redistribution and use in source and binary forms, with or without
# modification, are permitted provided that the following conditions are met:

# * Redistributions of source code must retain the above copyright notice, this
#   list of conditions and the following disclaimer.

# * Redistributions in binary form must reproduce the above copyright notice,
#   this list of conditions and the following disclaimer in the documentation
#   and/or other materials provided with the distribution.

# * Neither the name of the copyright holder nor the names of its
#   contributors may be used to endorse or promote products derived from
#   this software without specific prior written permission.

# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
# AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
# IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
# DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
# FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
# DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
# SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
# CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
# OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
# OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

# *************************************************************************
# This program has dependencies on other libraries and Website depedencies which are or not under BSD license and that are commonly used with this program core libraries.

# Dependencies are as follows:

# Name					    Licence type			Website				
# geopandas (v1.1.0)	    3-clauses BSD 			https://geopandas.org
# shapely (v2.0.7)		    3-clauses BSD 			https://github.com/shapely/shapely
# Watlab-ShapefileParser    3-clause BSD            https://sites.uclouvain.be/hydraulics-group/watlab


# External executables
# ---------------------

# External executables are also needed for a proper execution of this program. These executables are not part of this program and have to be used according to their own license.

# External executables are (license are given for information purpose only) :
# gmsh (v4.13)	 		GNU GPL v2 or later			https://gmsh.info/


# Licences & Credits of dependencies
# ----------------------------------

# #########
# GEOPANDAS
# #########

# Copyright (c) 2013-2022, GeoPandas developers.
# All rights reserved.

# Redistribution and use in source and binary forms, with or without
# modification, are permitted provided that the following conditions are met:

#  * Redistributions of source code must retain the above copyright notice, this
#    list of conditions and the following disclaimer.
#  * Redistributions in binary form must reproduce the above copyright notice,
#    this list of conditions and the following disclaimer in the documentation
#    and/or other materials provided with the distribution.
#  * Neither the name of GeoPandas nor the names of its contributors may
#    be used to endorse or promote products derived from this software without
#    specific prior written permission.

# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
# ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
# WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
# DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR
# ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
# (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
# LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
# ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
# (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
# SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

# #########
# SHAPELY
# #########

# BSD 3-Clause License

# Copyright (c) 2007, Sean C. Gillies. 2019, Casper van der Wel. 2007-2022, Shapely Contributors.
# All rights reserved.

# Redistribution and use in source and binary forms, with or without
# modification, are permitted provided that the following conditions are met:

# 1. Redistributions of source code must retain the above copyright notice, this
#    list of conditions and the following disclaimer.

# 2. Redistributions in binary form must reproduce the above copyright notice,
#    this list of conditions and the following disclaimer in the documentation
#    and/or other materials provided with the distribution.

# 3. Neither the name of the copyright holder nor the names of its
#    contributors may be used to endorse or promote products derived from
#    this software without specific prior written permission.

# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
# AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
# IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
# DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
# FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
# DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
# SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
# CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
# OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
# OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

# #########
# WATLAB - SHAPEFILEPARSER
# #########

# Copyright (c) <2025> <Universite catholique de Louvain (UCLouvain), Belgique>
# All rights reserved.

# Authors (all affiliate to Université catholique de Louvain (UCLouvain), Belgique) : Alexis Girard, Pierre-Yves Gousenbourger, Martin Petitjean

# Redistribution and use in source and binary forms, with or without
# modification, are permitted provided that the following conditions are met:

# * Redistributions of source code must retain the above copyright notice, this
#   list of conditions and the following disclaimer.

# * Redistributions in binary form must reproduce the above copyright notice,
#   this list of conditions and the following disclaimer in the documentation
#   and/or other materials provided with the distribution.

# * Neither the name of the copyright holder nor the names of its
#   contributors may be used to endorse or promote products derived from
#   this software without specific prior written permission.

# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
# AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
# IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
# DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
# FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
# DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
# SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
# CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
# OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
# OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

####################


from geopandas import GeoDataFrame
from shapely.geometry import Polygon, LineString
from .shapefile_parser import ShapeFileParser
import gmsh

class Zone:
    def __init__(self, polygon: Polygon, index: int):
        """
        Tree node for sorting zones that contain other zones.
        """
        self.polygon = polygon 
        self.index = index # index of the sorted zone keys
        self.parent = None
        self.children = []
class MeshMaker:
    """ Based on the gmsh API, the MeshMaker class generate 2D computational meshes 
    from shapefiles, GeoDataFrames or ShapeFileParser object.
    The resulting mesh can then be used to define computational domains and regions 
    for hydrodynamic or sediment transport simulations within the Watlab suite.
    
    :param shapefile: Input geometry data — can be a path to a shapefile, a GeoDataFrame, or a ShapeFileParser object. \n
                      The shapefile 'data.shp' must be placed in the same folder as the associated files 'data.cpg', 'data.dbf', 'data.prj', and 'data.shx'.
    :type shapefile: str | geopandas.GeoDataFrame | watlab.shapefile_parser.ShapeFileParser
    :param type: Type of input file if `shapefile` is a path.
                 `"shp"` for Shapefile (default), or `"csv"` for CSV input.
    :type type: str, optional
    
    **Example**

    .. code-block:: python

        from watlab.utils.mesh_maker import MeshMaker

        # Example 1 — From a shapefile
        mesh = MeshMaker("data/boundaries.shp")
        mesh.make_mesh("output_mesh")

        # Example 2 — From a ShapeFileParser
        from watlab.utils.shapefile_parser import ShapeFileParser
        shp_parser = ShapeFileParser("data/boundaries.shp")
        mesh = MeshMaker(shp_parser)
        mesh.make_mesh("river_mesh.msh")

    **Notes**

    - The shapefile must contain all necessary associated files (`.shp`, `.dbf`, `.prj`, `.shx`, `.cpg`).
    - Each zone should form a valid, closed polygon (or curveloop).
    - Gmsh must be correctly installed and accessible in your environment.
    """

    def __init__(self, shapefile: str|GeoDataFrame|ShapeFileParser, type="shp"):
        """Constructs the MeshMaker object based on a Shapefile, GeoDataFrame or ShapeFileParser object.
        """
        if not isinstance(shapefile,ShapeFileParser):
            self.data = ShapeFileParser(shapefile, type)
        else:
            self.data = shapefile
        # Reindex data to be compatible with gmsh numbering.
        self.data._reindex_lines()

        # Create curveloops
        self.curveloops = {}
        for zone in sorted(self.data.zones.keys()):
            if zone != '':      # LineString with zone == '' are Internal boundaries => do not create a curveloop 
                self.curveloops[zone] = self.make_curveloop_from_zone(self.data.zones[zone], self.data.lines, self.data.points)

        self._model = gmsh.model
    
    # def __del__(self):
    #     """
    #     Finalizes the Gmsh session when the object is deleted.

    #     This method ensures that Gmsh is properly closed when the `MeshMaker` instance
    #     is destroyed, preventing memory leaks or locked resources in Gmsh.
    #     It calls :func:`gmsh.finalize()` only if Gmsh has been previously initialized.

    #     **Example**

    #     .. code-block:: python

    #         mesh = MeshMaker("data/domain.shp")
    #         mesh.make_mesh("domain_mesh")
    #         del mesh  # Automatically finalizes Gmsh if still active

    #     **Notes**

    #     - This method is automatically invoked by Python’s garbage collector.
    #     - It is safe to call multiple times, as Gmsh checks its internal state.
    #     """
    #     if gmsh.is_initialized():
    #         gmsh.finalize()
    
    def _get_zone_orientation(self, zone: list, lines: dict|list, points: list):
        # """Returns the orientation of the normal for a given zone.  
        # The normal is computed using the formula:  
        # n = (x1*y2 - x2*y1) + (x2*y3 - x3*y2) + ... + (xn*y1 - x1*yn)  
        # If n is positive, the orientation is counterclockwise.

        # :param zone: list of line tags defining the zone.
        # :type zone: list
        # :param lines: dictionary or list containing the line definitions indexed by tags.
        # :type lines: dict | list
        # :param points: list of point coordinates used to compute the orientation.
        # :type points: list
        # :return: orientation value n; positive if counterclockwise.
        # :rtype: float
        # """
        n = 0
        for tag in zone:
            line = lines[abs(tag)]
            n += (points[line[0]-1][0]*points[line[1]-1][1] - points[line[0]-1][1]*points[line[1]-1][0])*(-1)**(tag<0)
        return n
    
    def verify_curveloop_closure(self, curveloop: list, lines: dict|list):
        """
        Verifies that a given curveloop is properly closed.

        A curveloop is a list of line tags that form a continuous polygonal boundary.  
        This method checks whether the starting point of the first line 
        and the ending point of the last line are identical, ensuring that
        the loop is closed.

        :param curveloop: List of line tags composing the curveloop.  
                          Each line tag can be positive or negative, indicating its direction.
        :type curveloop: list
        :param lines: Dictionary or list mapping each line tag to a tuple of point indices (start, end).
        :type lines: dict | list
        :return: True if the curveloop is closed, False otherwise.
        :rtype: bool

        **Example**

        .. code-block:: python

            curveloop = [1, 2, 3]
            lines = {
                1: (1, 2),
                2: (2, 3),
                3: (3, 1)
            }

            is_closed = meshmaker.verify_curveloop_closure(curveloop, lines)
            print(is_closed)  # True → the loop is closed

        **Notes**

        - A negative line tag (e.g. -2) means that the line is traversed in reverse order.
        - This method only checks topological closure (connectivity of start and end points),
          not geometric continuity.
        """
        start_point = lines[abs(curveloop[0])][(curveloop[0]<0)]
        end_point = lines[abs(curveloop[-1])][(curveloop[-1]>0)]
        return start_point == end_point

    def make_curveloop_from_zone(self, zone: list, lines: dict|list=None, points: list=None):
        """
        Constructs a curveloop from an unordered set of line tags defining a zone.

        A curveloop is an ordered list of lines that form a closed polygonal boundary.  
        Each line connects two consecutive points, and its sign indicates the traversal direction:
        - A positive tag means the line is traversed from its first point to its second.
        - A negative tag means the line is traversed in reverse order.

        This method ensures that:
        - All lines in the given zone are ordered so that they form a closed loop.
        - The loop orientation is counterclockwise (positive normal).
        - The closure and orientation validity are verified.

        :param zone: List of line indexes defining the zone.
        :type zone: list
        :param lines: Dictionary or list of line definitions where each line is a tuple (start_point, end_point).  
                      Defaults to self.data.lines.
        :type lines: dict | list, optional
        :param points: List of point coordinates used to determine the geometric orientation.  
                       Defaults to self.data.points.
        :type points: list, optional
        :raises Exception: If the curveloop cannot be closed or the shapefile contains inconsistencies.
        :raises ValueError: If the zone has no proper orientation (orientation equals zero).
        :return: Ordered list of signed line tags forming a closed, properly oriented curveloop.
        :rtype: list

        **Example**

        .. code-block:: python

            zone = [1, 2, 3, 4]
            lines = {
                1: (1, 2),
                2: (2, 3),
                3: (3, 4),
                4: (4, 1)
            }
            points = [(0,0), (1,0), (1,1), (0,1)]

            curveloop = meshmaker.make_curveloop_from_zone(zone, lines, points)
            print(curveloop)
            # Output: [1, 2, 3, 4]  → properly ordered and counterclockwise
        """
        # **Algorithm Overview**

        # 1. Starts from an arbitrary line in the zone.
        # 2. Iteratively finds the next connected line sharing a common endpoint.
        # 3. Tracks traversal direction (sign of the line tag).
        # 4. Verifies that the loop is properly closed (first and last points coincide).
        # 5. Ensures the loop orientation is counterclockwise (positive area).
        if lines is None: lines = self.data.lines
        if points is None: points = self.data.points

        # Function to find the tag of the line that contains a point_tag
        # Returns: line_tag: the tag of the line that contains the point_tag
        #          pos: | 0 if the point is a starting point
        #               | 1 if the point is an ending point
        def find_line_with_point(point_tag, lines_tags_in_zone):
            # This should return a list of one element
            found_line_tag = [tag for tag in lines_tags_in_zone if point_tag in lines[tag]]
            # Take only first found (shouldn't be more than two)
            found_line_tag = int(found_line_tag[0])
            pos = lines[found_line_tag].index(point_tag)
            return found_line_tag, pos

        # Copy to enable popping without breaking the object
        lines_tags_in_zone = zone.copy()

        # Starting point
        point_tag = start_point_tag = lines[lines_tags_in_zone[0]][0]
        curveloop = []
        while len(lines_tags_in_zone) > 0:
            # Find the tag of the line that contains the point.
            [line_tag, pos] = find_line_with_point(point_tag, lines_tags_in_zone)
            # Get the ending (resp. starting) point
            point_tag = lines[line_tag][1-pos]
            # Append to curveloop and adapt the sign given the position of the point (negative if ending point)
            sign = (-1)**pos
            curveloop.append(line_tag*sign)
            # Check if start point and last added point are the same (curveloop is closed)
            if (start_point_tag == point_tag): 
                break
            # Remove the current line to avoid adding it twice
            lines_tags_in_zone.pop(lines_tags_in_zone.index(line_tag))
        
        if not(start_point_tag == point_tag): raise Exception("A zone couldn't be closed while transforming to curveloop. Check the shapefile.")

        # check zone orientation (should be positive)
        if self._get_zone_orientation(curveloop, lines, points) < 0:
            # return the entire curveloop
            curveloop.reverse()
            curveloop = [-i for i in curveloop]
        elif self._get_zone_orientation(curveloop, lines, points) == 0:
            raise ValueError("The zone has no proper orientation. Orientation cannot be zero.")
        
        if self.verify_curveloop_closure(curveloop, lines):
            return curveloop
        else: raise Exception("A curveloop is not closed. Check the shapefile.")

    def create_points(self, points: list, resolutions: list) -> None:
        # Create points
        """
        Creates points in the Gmsh model.
        Each point is added with a specific resolution, which controls the local mesh size.

        :param points: List of point coordinates. Each point can be 2D (x, y) or 3D (x, y, z).
        :type points: list of tuples or lists
        :param resolutions: List of resolution values for each point. Must have the same length as points.
        :type resolutions: list of float

        **Notes**
        - The points are added to the Gmsh model with tags starting from 1 and incremented sequentially.
        """
        for tag, point in enumerate(points):
            self._model.geo.addPoint(point[0], point[1], point[2] if len(point)==3 else 0, resolutions[tag], tag+1)

    def create_lines(self, lines: dict) -> None:
        """
        Creates lines in the Gmsh model from a dictionary of lines.

        Each line is defined by its start and end points and assigned a unique tag.
        These lines can then be used to form curves, surfaces, and loops in Gmsh.

        :param lines: Dictionary of lines where the key is the line tag and the value is a list or tuple 
                    containing the start and end point indices.
        :type lines: dict

        **Example**

        .. code-block:: python

            lines = {
                1: [1, 2],
                2: [2, 3],
                3: [3, 1]
            }
            mesh_maker.create_lines(lines)
        """
        # Create associated lines --- Actually not sure that tags of lines must be n_points+1...
        for tag, line in sorted(lines.items()):
            self._model.geo.addLine(line[0], line[1], tag)

    def _curveloop2polygon(self, curveloop:list, lines:dict, points:list) -> Polygon:
        """Converts a curveloop into a polygon formed by its points.

        Each curveloop is a sequence of line indices. The sign of a line index indicates
        the traversal direction along the line (positive: start to end, negative: end to start).

        :param curveloop: List of line tags forming the curveloop.
        :type curveloop: list
        :param lines: Dictionary mapping line tags to their start and end point indices.
        :type lines: dict
        :param points: List of coordinates of all points in the mesh.
        :type points: list
        :return: Polygon object representing the closed curveloop.
        :rtype: shapely.geometry.Polygon

        **Example**

        .. code-block:: python

            polygon = mesh_maker._curveloop2polygon(curveloop, lines, points)
            print(polygon.area)
        """
        coords = []
        cl = curveloop.copy()
        cl.append(cl[0]) # in such a way, the curveloop will start and end at the same point
        for tag in cl:
            pnt_idx = lines[tag][0] if tag >=0 else lines[-tag][1]
            coords.append(points[pnt_idx-1])
        return Polygon(coords)
    
    def _get_nested_curveloops_tree(self, curveloops:dict, lines:list|dict=None, points:list=None) -> dict:
        """
        Detects nested curveloops and builds a parent-child hierarchy of polygons.

        This function converts each curveloop into a Polygon and determines which polygons
        are contained within others. Smaller polygons fully contained within a larger one
        are considered children of the larger polygon.

        :param curveloops: Dictionary of curveloops where the key is the zone name and
                           the value is a list of line indices forming the curveloop.
        :type curveloops: dict
        :param lines: List or dictionary of lines defining the curveloops. Defaults to `self.data.lines`.
        :type lines: list or dict, optional
        :param points: List of point coordinates used to define the lines. Defaults to `self.data.points`.
        :type points: list, optional
        :return: Dictionary mapping curveloop names to `Zone` objects, with parent-child relationships.
        :rtype: dict

        **Example**

        .. code-block:: python

            nested_tree = mesh_maker._get_nested_curveloops_tree(curveloops)
            for zone_name, zone_obj in nested_tree.items():
                print(zone_name, zone_obj.parent, [child.index for child in zone_obj.children])
        """
        # """
        # Detects the nested curveloops within the curveloops already created.
        # Builds a mapping of curveloops containing other curveloops.
        # Returns a list of polygons chained by parents and children
        # """
        if lines is None: lines = self.data.lines
        if points is None: points = self.data.points
        
        # Turn curveloops to Polygons, and store it to nodes
        names = sorted(curveloops.keys())
        polygons = [Zone(self._curveloop2polygon(curveloop, self.data.lines, self.data.points), names.index(name)) for name, curveloop in sorted(curveloops.items())]
        polygons = sorted(polygons, key=lambda p: p.polygon.area)

        for i, child in enumerate(polygons):
            for potential_parent in polygons[i+1:]: # we only take the biggest zones, sorted from the smallest to the biggest
                if child.polygon.within(potential_parent.polygon):
                    child.parent = potential_parent
                    potential_parent.children.append(child)
                    break # stop looking at parents if you find the first smallest container

        # Return the chained list of polygons
        return {names[polygon.index]: polygon for polygon in polygons}

    def create_curveloops(self, curveloops: dict, lines: dict=None, points: list=None) -> None:
        """
        Creates curveloops and corresponding plane surfaces in Gmsh.

        Each curveloop defines a closed boundary using line indices. Nested curveloops
        (holes) are automatically detected and handled, so the resulting plane surfaces
        correctly account for inner voids.

        :param curveloops: Dictionary of curveloops where keys are zone names and values are
                        lists of line indices forming each curveloop.
        :type curveloops: dict
        :param lines: Dictionary of line definitions (key: line tag, value: tuple of point indices). 
                    Defaults to `self.data.lines` if None.
        :type lines: dict, optional
        :param points: List of point coordinates corresponding to the lines. Defaults to `self.data.points` if None.
        :type points: list, optional
        :return: None. Curveloops and plane surfaces are added directly to the Gmsh model.

        **Example**

        .. code-block:: python

            mesh_maker.create_curveloops(curveloops)
        """
        if lines is None: lines = self.data.lines
        if points is None: points = self.data.points

        # Create associated curveloops and plane surfaces
        curveloops_tree = self._get_nested_curveloops_tree(curveloops, lines, points)
        names = sorted(curveloops.keys())
        
        for i, zone in enumerate(names):
            self._model.geo.addCurveLoop(curveloops[zone], i+1)

        # Add associated plane surface (if not nested)
        for i, zone in enumerate(names):
            tags = [i+1]
            holes = curveloops_tree[zone].children
            if holes:
                for h in holes:
                    tags.append(h.index+1)

            if "*" not in zone:
                self._model.geo.addPlaneSurface(tags, i+1)
                
    def create_boundaries(self, boundaries: dict) -> None:
        """
        Creates physical groups for boundaries in Gmsh.

        Each boundary is defined as a set of lines and assigned a name.
        This allows boundary conditions to be applied to specific edges in the mesh.

        :param boundaries: Dictionary where keys are boundary names and values are lists of line tags
                           that define each boundary.
        :type boundaries: dict
        :return: None. Physical groups for boundaries are added directly to the Gmsh model.

        **Example**

        .. code-block:: python

            boundaries = {
                "inlet": [1, 2, 3],
                "outlet": [4, 5]
            }
            mesh_maker.create_boundaries(boundaries)
        """
        # Create boundaries (list of lines)
        for boundary_name, line_tags in sorted(boundaries.items()):
            self._model.addPhysicalGroup(1, line_tags, name=boundary_name)

    def create_zones(self, zone_names: list) -> None:
        """
        Creates physical groups for zones (plane surfaces) in Gmsh.

        Each zone is assigned a name and added as a 2D physical group.
        This allows assigning properties or performing operations on specific zones in the mesh.

        :param zone_names: List of zone names corresponding to plane surfaces.
                           Zones with names ending with '*' are ignored.
        :type zone_names: list
        :return: None. Physical groups for zones are added directly to the Gmsh model.

        **Example**

        .. code-block:: python

            zone_names = ["river", "floodplain"]
            mesh_maker.create_zones(zone_names)
        """
        # Create zones and regions - list of plane surfaces tags
        # To add : how to handle empty zones (key is "*" ?)
        for tag, zone_name in enumerate(zone_names):
            if not zone_name.endswith("*"): self._model.addPhysicalGroup(2, [tag+1], name=zone_name)
        
    def create_regions(self, zone_names: list, regions: dict) -> None:
        """
        Creates physical groups for regions composed of multiple zones in Gmsh.

        Each region is defined as a 2D physical group that may contain multiple zones.
        Zones with names ending with '*' are ignored when assigning them to regions.

        :param zone_names: List of all zone names corresponding to plane surfaces.
        :type zone_names: list
        :param regions: Dictionary mapping region names to lists of zone names included in the region.
        :type regions: dict
        :return: None. Physical groups for regions are added directly to the Gmsh model.

        **Example**

        .. code-block:: python

            zone_names = ["zone1", "zone2", "zone3"]
            regions = {"regionA": ["zone1", "zone2"], "regionB": ["zone3"]}
            mesh_maker.create_regions(zone_names, regions)
        """
        for region_name, zones in sorted(regions.items()):
            zone_tags = [zone_names.index(elem)+1 for elem in zones if not elem.endswith("*")]
            self._model.addPhysicalGroup(2, zone_tags, name=region_name)

    @staticmethod
    def _linetags2linestring(points: list, lines: dict, line_tags: list) -> LineString:
        """
        Converts a sequence of line segments into a shapely.geometry.LineString.

        The method reconstructs the full polyline by concatenating the coordinates
        of the points corresponding to each line tag in line_tags.
        For every segment, only the first point is added, and the final point of the
        last segment is appended at the end to complete the LineString.

        :param points: List of point coordinates. Each element typically represents a tuple
                    (x, y).
        :type points: list
        :param lines: Dictionary mapping line tags to pairs of point indices.  
                    Example: {5: (2, 3)} means line 5 connects points[1] and points[2].
        :type lines: dict
        :param line_tags: Ordered list of line tags forming the polyline.
        :type line_tags: list
        :return: A LineString reconstructed from the ordered line segments.
        :rtype: LineString

        **Example**

        .. code-block:: python

            points = [(0, 0), (1, 0), (1, 1), (0, 1)]
            lines = {1: (1, 2), 2: (2, 3)}
            line_tags = [1, 2]

            ls = Mesh._linetags2linestring(points, lines, line_tags)
        """
        coords = []
        for line_tag in line_tags:
            points_tags = lines[line_tag]
            coords.append(points[points_tags[0]-1])             #Add first of each line composing the boundary
        coords.append(points[lines[line_tags[-1]][1]-1])        #Add last point of last line composing the boundary
        return LineString(coords)

        
    def embed_internal_boundaries(self, points: list, lines: dict, internal_boundaries: dict, curveloops: dict):
        """
        Embeds internal boundaries into their corresponding 2D surfaces in the Gmsh model.

        Each internal boundary is reconstructed as a LineString and tested
        against zone polygons to determine which zone contains it. If the zone covers
        the boundary, the corresponding line tags are embedded into that surface using
        gmsh.model.mesh.embed.

        :param points: List of point coordinates.
        :type points: list
        :param lines: Mapping of line tags to pairs of point indices.
        :type lines: dict
        :param internal_boundaries: Mapping of boundary names to ordered line-tag lists.
        :type internal_boundaries: dict
        :param curveloops: Mapping of zone names to line-tag lists forming each zone boundary.
        :type curveloops: dict
        :return: None
        :rtype: None. Internal Boundaries are embedded directly to the surfaces of Gmsh model.

        :raises Warning: If a boundary does not lie inside any zone.
        """
        # Create a dict zone_name -> polygon
        zone_polygons = {zone_name: self._curveloop2polygon(curveloop, lines, points)
                        for zone_name, curveloop in curveloops.items()}

        for boundary_name, line_tags in internal_boundaries.items():
            line_geom = self._linetags2linestring(points, lines, line_tags) #Create LineString representing the internal boundary
            
            embedded = False
            for zone_name, polygon in zone_polygons.items(): # Look which zone contains our boundary (through shp.Polygon.contains(LineString))
                if polygon.covers(line_geom):                # covers = accepts points on borders of the polygon
                    surface_tag = list(curveloops.keys()).index(zone_name) + 1
                    gmsh.model.mesh.embed(1, line_tags, 2, surface_tag)
                    embedded = True
                    break
            if not embedded:
                raise Warning(f"Line {line_tags} of internal boundary '{boundary_name}' not inside any zone. Mesh will not be constraint.")

    def make_mesh(self, name: str, verbosity=5, display_ui=False):
        """
        Generates a 2D mesh using Gmsh from the provided points, lines, curveloops, and physical groups.

        This method performs the complete mesh creation workflow: \n
        1. Initializes Gmsh if necessary.
        2. Adds points and lines to the geometry.
        3. Creates curveloops and associated plane surfaces.
        4. Synchronizes the geometric model.
        5. Creates boundaries, zones, and regions as physical groups.
        6. Generates and optionally optimizes the mesh.
        7. Exports the mesh to a `.msh` file.
        8. Optionally opens the Gmsh GUI for visualization.

        :param name: Name of the output mesh file. If the extension is not provided, '.msh' will be appended.
        :type name: str
        :param verbosity: Level of messages printed by Gmsh: \n
                          - 0: silent except for fatal errors
                          - 1: errors
                          - 2: warnings
                          - 3: direct messages
                          - 4: information
                          - 5: status (default)
                          - 99: debug
        :type verbosity: int, optional
        :param display_ui: If True, opens the Gmsh GUI for visualization. Defaults to False.
        :type display_ui: bool, optional
        :return: None. The mesh is written to a `.msh` file and added to the Gmsh model.
        
        **Example**

        .. code-block:: python

            mesh_maker = MeshMaker("my_shapefile.shp")
            mesh_maker.make_mesh("output_mesh", verbosity=5, display_ui=False)
        """
        if not gmsh.is_initialized():
            gmsh.initialize()
            
        gmsh.option.setNumber("General.Verbosity", verbosity)
        self._model.add(name)

        # Create geometry
        self.create_points(self.data.points, self.data.resolutions)
        self.create_lines(self.data.lines)
        self.create_curveloops(self.curveloops)

        # Synchronize before creating physical groups
        self._model.geo.synchronize()

        # Create physical groups
        self.create_boundaries(self.data.boundaries)
        zone_names = list(sorted(self.data.zones.keys()))
        self.create_zones(zone_names)
        self.create_regions(zone_names, self.data.regions)
        self.embed_internal_boundaries(self.data.points, self.data.lines, self.data.internal_boundaries, self.curveloops)
        self._model.mesh.generate(2)
        self._model.mesh.optimize('Laplace2D')
        
        # Export
        file_name = name if name.endswith(".msh") else name+".msh"
        gmsh.write(file_name)
        if display_ui:
            gmsh.fltk.run()

        # gmsh.finalize()