# Watlab - ShapefileParser General Conditions
# -----------------------------------------
# Licensed under the BSD 3-Clause License (the "License");
# you may not use this file except in compliance with the License.

# Copyright (c) <2025> <Universite catholique de Louvain (UCLouvain), Belgique>
# All rights reserved.

# Authors (all affiliate to Université catholique de Louvain (UCLouvain), Belgique) : Alexis Girard, Pierre-Yves Gousenbourger, Martin Petitjean

# Redistribution and use in source and binary forms, with or without
# modification, are permitted provided that the following conditions are met:

# * Redistributions of source code must retain the above copyright notice, this
#   list of conditions and the following disclaimer.

# * Redistributions in binary form must reproduce the above copyright notice,
#   this list of conditions and the following disclaimer in the documentation
#   and/or other materials provided with the distribution.

# * Neither the name of the copyright holder nor the names of its
#   contributors may be used to endorse or promote products derived from
#   this software without specific prior written permission.

# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
# AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
# IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
# DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
# FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
# DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
# SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
# CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
# OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
# OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

# *************************************************************************
# This program has dependencies on other libraries and Website depedencies which are or not under BSD license and that are commonly used with this program core libraries.

# Dependencies are as follows:

# Name					Licence type			Website				
# geopandas (v1.1.0)	3-clauses BSD 			https://geopandas.org
# shapely (v2.0.7)		3-clauses BSD 			https://github.com/shapely/shapely

# External executables
# ---------------------

# External executables are also needed for a proper execution of this program. These executables are not part of this program and have to be used according to their own license.

# External executables are (license are given for information purpose only) :
# gmsh (v4.13)	 		GNU GPL v2 or later			https://gmsh.info/


# Licences & Credits of dependencies
# ----------------------------------

# #########
# GEOPANDAS
# #########

# Copyright (c) 2013-2022, GeoPandas developers.
# All rights reserved.

# Redistribution and use in source and binary forms, with or without
# modification, are permitted provided that the following conditions are met:

#  * Redistributions of source code must retain the above copyright notice, this
#    list of conditions and the following disclaimer.
#  * Redistributions in binary form must reproduce the above copyright notice,
#    this list of conditions and the following disclaimer in the documentation
#    and/or other materials provided with the distribution.
#  * Neither the name of GeoPandas nor the names of its contributors may
#    be used to endorse or promote products derived from this software without
#    specific prior written permission.

# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
# ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
# WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
# DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR
# ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
# (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
# LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
# ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
# (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
# SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

# #########
# SHAPELY
# #########

# BSD 3-Clause License

# Copyright (c) 2007, Sean C. Gillies. 2019, Casper van der Wel. 2007-2022, Shapely Contributors.
# All rights reserved.

# Redistribution and use in source and binary forms, with or without
# modification, are permitted provided that the following conditions are met:

# 1. Redistributions of source code must retain the above copyright notice, this
#    list of conditions and the following disclaimer.

# 2. Redistributions in binary form must reproduce the above copyright notice,
#    this list of conditions and the following disclaimer in the documentation
#    and/or other materials provided with the distribution.

# 3. Neither the name of the copyright holder nor the names of its
#    contributors may be used to endorse or promote products derived from
#    this software without specific prior written permission.

# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
# AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
# IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
# DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
# FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
# DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
# SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
# CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
# OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
# OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
####################

from geopandas import read_file, GeoDataFrame
from shapely import LineString
from re import split
from numpy import nan

def read_csv_geodataframe(csv_file):
    """
    Converts a CSV file of geospatial vectored information into a geopandas.GeoDataFrame.

    This function reads a CSV file whose geometry column contains LINESTRING-formatted
    coordinates (as strings using WKT-like LINESTRING (x y, x y, ...) syntax) and transforms 
    them into actual Shapely objects and res column contains resolution of the Linestring.

    :param csv_file: Path to the CSV file to be converted.
    :type csv_file: str

    :returns: A GeoDataFrame where:
              - the geometry column contains Shapely LineString objects,
              - the res column contains floats instead of strings.
    :rtype: geopandas.GeoDataFrame

    **Example**

    .. code-block:: python

        from watlab.utils.shapeFileParser import read_csv_geodataframe

        gdf = read_csv_geodataframe("topology/data.csv")
        print(gdf.head())
    """
    dataFrame = read_file(csv_file)
    # Turn linestring to acutal geometric polyline
    linestring = []
    for elem in dataFrame["geometry"]:
        data_points = elem.replace('LINESTRING ','').replace('(','').replace(')','').split(',')
        points = [pt for pt in (point.strip().split(' ') for point in data_points)]
        linestring.append(LineString(points))
    dataFrame["geometry"] = linestring
    # Turn resolution from string to float
    dataFrame["res"] = dataFrame["res"].astype(float)
        
    return dataFrame

class ShapeFileParser:
    """
    Extracts and structures the elements of geospatial vector informations into an indexed format compatible with MeshMaker.

    This parser reads a shapefile (.shp) or a geopandas.GeoDataFrame and extracts all
    geometric and topological information required for mesh construction.
    It identifies points, resolutions, lines, boundaries, zones, and regions.
    Duplicate geometries are automatically removed.

    :param shapefile: Path to the shapefile, or a GeoDataFrame containing the data.
                      The shapefile 'data.shp' must be placed in the same folder as the associated files 'data.cpg', 'data.dbf', 'data.prj', and 'data.shx'.
    :type shapefile: str | geopandas.GeoDataFrame
    :param type: Defines how the input should be interpreted. Use "shp" for shapefiles or "csv" for CSV geometry files.
                 Defaults to "shp".
    :type type: str

    **Example**

    .. code-block:: python

        from watlab.utils.shapeFileParser import ShapeFileParser

        parser = ShapeFileParser("topology/data.shp")

        print(parser.points)
        print(parser.boundaries)
        print(parser.zones)
        print(parser.regions)
    """
    # constants
    _ZONES_KEY = "zone"
    _BOUNDARIES_KEY = "type"
    _REGIONS_KEY = "region"
    _POINTS_KEY = "geometry"
    _RESOLUTION_KEY = "res"

    def __init__(self, shapefile: str|GeoDataFrame, type:str="shp"):
        """
        Extracts the constitutive elements of a shapefile mesh.
        Returns the list of points, lines, zones, regions and resolutions associated.
        Duplicates are by default removed.

        Args:
            shapefile (str): path to the shapefile. The shapefile data.shp must be placed in the same
                            folder as data.cpg, data.dbf, data.prj and data.shx.
            reduce (bool, default=True): enables the reducing strategy that eliminated duplicated from the
                                        shapefile.

        Returns:
            points (list): the list of xy points of the topology
            resolutions (list): the associated resolutions of each point
            lines (list): the list of points describing a line (list of indexes of points)
            boundaries (dict) : the type of lines describing a boundary (key: name of the boundary, elem: list of indexed lines).
            zones (dict): the list of lines describing a zone (key: name of the zone, elem: list of indexed lines).
            regions (list): list of zones that compose a region (key: name of the region, elem: list of indexed zones)
        """
        if isinstance(shapefile,str): # Shapefile is transformed to geopandas dataset. Then all is done by this
            if type == "csv":
                self._data = read_csv_geodataframe(shapefile)
            elif type == "shp":
                self._data = read_file(shapefile)
            else:
                raise TypeError("Only shp and csv files are handled.")
        else:
            self._data = shapefile


        # Epure group names from None
        self._check_geometry(self.data)
        self._remove_none_from_group(self.data, self._BOUNDARIES_KEY)
        self._remove_none_from_group(self.data, self._ZONES_KEY)
        self._remove_none_from_group(self.data, self._REGIONS_KEY)

        # Extract the structure
        self._points = self._extract_points(self.data)
        self._points_tags = [i for i in range(1,len(self._points)+1)]
        self._polypoints = self._extract_polypoints(self.data, self.points)
        self._resolutions = self._extract_points_resolution(self._data, self.points, self.polypoints)
        self._linestrings = self._extract_linestrings(self.data, self.points, self.polypoints)
        self._lines = self._get_lines(self.linestrings)
        self._polylines = self._get_polylines(self.lines, self.linestrings)
        self._zones = self._extract_zones(self.data, self.polylines) # lines
        self._boundaries = self._extract_boundaries(self.data, self.polylines) # lines
        self._regions = self._extract_regions(self.data) # lines
        self._internal_boundaries = self._extract_internal_boundaries(self.data, self.polylines)

    @property
    def data(self) -> GeoDataFrame: 
        """
        geopandas.GeoDataframe that stores the geospatial vectored data.

        :getter: returns the GeoDataFrame containing the original geospatial vectored data.
        :rtype: geopandas.GeoDataFrame
        """
        return self._data
    
    def _check_geometry(self, data:GeoDataFrame):
        """""
        Validates that all geometries in the GeoDataFrame data are valid
        LineString objects.

        :param data: The GeoDataFrame whose geometries are to be checked. Each
                     row must contain a non-null geometry of type LineString.
        :type data: geopandas.GeoDataFrame

        :returns: None. The function raises an exception if invalid geometries
                  are encountered.
        :rtype: None
        :raises ValueError: If a row contains a None geometry.
        :raises TypeError: If a geometry is not of type LineString.
        """
        for idx, row in data.iterrows():
            if row.geometry is None:
                raise ValueError(f"Error : geometry is None for row index {idx}, \n{row}.")
            if not isinstance(row.geometry, LineString):
                raise TypeError(f"Error : incorrect geometry type ({type(row.geometry).__name__}) for row  index {idx}, \n{row}.\nLineString expected.")

    def _extract_points(self, data:GeoDataFrame, reduce:bool=True) -> list:
        """
        Extracts the points coordinates from the LineStrings contained in the GeoDataFrame data.

        :param data: The GeoDataFrame containing the geometric LineString objects.
        :type data: geopandas.GeoDataFrame
        :param reduce: Optional reduction strategy to remove points that are too
                       close to one another. *Currently not implemented.*
        :type reduce: bool

        :returns: A sorted list of unique coordinate points extracted from the geometry.
        :rtype: list of tuple(float, float)
        """
        # extraction of points coordinates from lines and remove duplicates
        # MPJ : Quid si on a des MultiLineStrings ?
        points = set([coord for linestring in data[self._POINTS_KEY] for coord in linestring.coords])
        # sorting elements and return as a list
        return sorted([point for point in points])

    @property
    def points(self) -> list:
        """
        List of unique point coordinates extracted from the shapefile (sorted by increasing coordinates).

        :getter: A sorted list of unique point coordinates.
        :rtype: list of tuple(float, float)
        """
        return self._points

    @property
    def points_tags(self) -> list: 
        """
        List of sequential identifiers associated with each extracted point.

        Tags are generated after point extraction and correspond to the index
        (starting at 1) of each point in the sorted points list.

        :getter: A list of integer tags for all points.
        :rtype: list of int
        """
        return self._points_tags

    def _extract_points_resolution(self, data:GeoDataFrame, points:list, polypoints:list=None) -> list:
        """
        Extracts the resolutions from the shapefile and associate it to the points.
        If a point belongs to multiple lines, the smallest resolution value is selected.

        :param data: The GeoDataFrame containing the geometric LineString objects and their
                     associated resolution values in the res field.
        :type data: geopandas.GeoDataFrame
        :param points: The list of unique points previously extracted from the geometry.
        :type points: list of tuple(float, float)
        :param polypoints: Optional list mapping each polyline to the indices of its
                           constituent points. If not provided, it is computed internally.
        :type polypoints: list of list[int], optional

        :returns: A list where each entry corresponds to a point in points and
                  contains the smallest resolution value associated with that point.
        :rtype: list of float
        """
        if (polypoints is None):
            polypoints = self._extract_polypoints(data, points)
        
        # Associates the resolutions to the known polylines - Also used in boundaries and zones finidng, but with polylines
        polylines_resolution = tuple(zip(list(data[self._RESOLUTION_KEY]), polypoints))
        # Builds the pairing point-to-resolution
        resolutions = [[] for pt in points]
        for line in polylines_resolution:
            for pt in line[1]:
                resolutions[pt-1].append(line[0])

        # Keeps the smallest resolution for each point
        return [min(res) for res in resolutions]

    @property
    def resolutions(self) -> list: 
        """
        Resolution value associated with each point on the geospatial vectored data.

        :getter: A list of resolution for all points.
        :rtype: list of double
        """
        return self._resolutions

    def _extract_polypoints(self, data:GeoDataFrame, points:list) -> list:
        """
        Extracts the linestrings from the shapefile as a collection of points.

        :param data: The GeoDataFrame containing the LineString geometries to be
                     converted into point-index sequences.
        :type data: geopandas.GeoDataFrame
        :param points: The list of unique points previously extracted from the geometry.
        :type points: list of tuple(float, float)

        :returns: A list of resolution values aligned with the points list.
        :rtype: list of float
        """
        return [[self.points_tags[points.index(coord)] for coord in linestring.coords] for linestring in data[self._POINTS_KEY]]

    @property
    def polypoints(self) -> list: 
        """
        Sequence of point-index lists describing each polyline.
        Each element corresponds to a LineString and contains the ordered point
        identifiers (tags) that compose it.

        :getter: A list where each element is a list of point tags forming a polyline.
        :rtype: list of list[int]
        """
        return self._polypoints

    def _extract_linestrings(self, data:GeoDataFrame, points:list, polypoints:list=None) -> list:
        """
        Extracts the LineStrings from the shapefile as a collection of points.
        Each line is converted into a list of line segment expresses as pairs of point tags.

        param data: The GeoDataFrame containing the LineString geometries.
        :type data: geopandas.GeoDataFrame
        :param points: The list of unique points previously extracted.
        :type points: list
        :param polypoints: Optional list of point-index sequences representing
                           each polyline. If not provided, it is computed internally.
        :type polypoints: list of list[int], optional

        :returns: A list where each element corresponds to a polyline, represented
                  as a list of tuples (i, j), each tuple being a line segment
                  between two consecutive point tags.
        :rtype: list of list[tuple[int, int]]
        """
        # Transform the list of points coordinates into list of points indexes
        if (polypoints is None):
            polypoints = self._extract_polypoints(data, points)
        
        # Turn consecutive points indexes to lists of tuples of points indexes (i.e., lists of lines)
        return [[(elem[i],elem[i+1]) for i in range(len(elem[:-1])) if (elem[i] != elem[i+1])] for elem in polypoints]

    @property
    def linestrings(self) -> list: 
        """
        A list of line segments extracted from the shapefile.

        Each element corresponds to a polyline and is represented
        as a list of tuples (i, j), where each tuple denotes a line segment
        between two consecutive point tags in the geometry.

        :getter: The collection of line segments grouped by their originating polylines.
        :rtype: list of list[tuple[int, int]]
        """
        return self._linestrings

    def _get_lines(self, linestrings: list) -> list:
        """
        Extracts all unique line segments from the collection of linestrings.

        Each linestring is represented as a list of point-tags pairs
        (i, j), corresponding to consecutive points in a polyline. This
        method flattens all linestrings into a single collection of segments,
        removes duplicates, and sorts the result for reproducibility.

        :param linestrings: The list of linestrings, where each linestring is a
                            list of tuples (i, j) representing line segments
                            between two consecutive point indices.
        :type linestrings: list of list[tuple[int, int]]

        :returns: A sorted list of unique line segments extracted from all
                  linestrings.
        :rtype: list[tuple[int, int]]
        """
        return sorted(list(set([line for linestring in linestrings for line in linestring])))

    @property
    def lines(self) -> list: 
        """
        A list of unique line segments extracted from all linestrings.

        Unlike linestrings—which preserves the grouping by polylines—this
        property returns a flat collection of distinct line segments, each
        represented as a tuple (i, j) of point indices. Duplicate segments
        are removed, and the list is sorted to ensure consistent ordering.

        :getter: The sorted list of unique line segments.
        :rtype: list[tuple[int, int]]
        """
        return self._lines
    
    def _get_polylines(self, lines: list, linestrings: list) -> list:
        """
        Converts each linestring into a sequence of line indices.

        This method maps every line segment (i, j) contained in a
        linestring to its corresponding index in the global lines list.
        The result preserves the original grouping of the linestrings, but
        represents each polyline as a list of integer indices rather than
        point pairs.

        :param lines: The sorted list of unique line segments, where each
                      segment is represented as a tuple (i, j) of point
                      tags.
        :type lines: list[tuple[int, int]]
        :param linestrings: The collection of linestrings, where each linestring
                            is a list of line segments represented as tuples
                            (i, j).
        :type linestrings: list[list[tuple[int, int]]]

        :returns: A list of polylines, where each polyline is represented as a
                  list of integers referring to indices in lines.
        :rtype: list[list[int]]
        """
        return [[lines.index(line) for line in ls] for ls in linestrings]

    @property
    def polylines(self) -> list: 
        """
        A sequence of line indices representing the polylines.

        Each polyline corresponds to a linestring from the shapefile and is
        represented as a list of integer indices pointing to the global lines list.
        This allows reconstructing each polyline in terms of its constituent line segments.

        :getter: A list of polylines, where each polyline is a list of indices
                  referring to line segments in lines.
        :rtype: list of list[int]
        """
        return self._polylines
    
    def _remove_none_from_group(self, data: GeoDataFrame, column: str):
        """
        Replaces None values in a specified column of the GeoDataFrame by an empty string.

        :param data: The GeoDataFrame containing the column to process.
        :type data: geopandas.GeoDataFrame
        :param column: The name of the column to check and clean.
        :type column: str
        """
        for i, key in enumerate(data[column]):
            if key is None or key is nan:
                data.loc[i,column] = ""

    def _extract_physical_group_names(self, data:GeoDataFrame, column:str) -> list:
        """
        Extracts all physical group names from a specified column in the GeoDataFrame.

        This method processes each entry in the column by:
        1. Splitting the string on commas (`,`) or semicolons (`;`) to separate multiple group names.
        2. Stripping leading and trailing whitespace from each name.
        3. Flattening the structure to obtain a list of lists of group names.

        :param data: The GeoDataFrame containing the column to extract group names from.
        :type data: geopandas.GeoDataFrame
        :param column: The name of the column containing the physical group names.
        :type column: str

        :returns: A list of lists where each sublist contains the cleaned group names
                  extracted from the corresponding row in the column.
        :rtype: list[list[str]]
        """
        # Extracts
        return [[key.strip() for key in subkey] for subkey in (split(";|,",datakeys) for datakeys in data[column])]

    def _extract_physical_groups(self, group_type:str, data:GeoDataFrame, polylines:list=None) -> dict:
        """
        Extracts physical groups (zones or boundaries) from the shapefile.

        Each polyline can belong to one or multiple physical groups. This method
        maps the names of these groups to the indices of the line segments
        (polylines) that compose them.

        If polylines is not provided, it will be computed automatically from
        the points and lines in the dataset.

        :param group_type: The column name in the GeoDataFrame corresponding to
                           the physical group (e.g., zones or boundaries).
        :type group_type: str
        :param data: The GeoDataFrame containing the shapefile geometries and attributes.
        :type data: geopandas.GeoDataFrame
        :param polylines: Optional precomputed list of polylines, where each
                          polyline is a list of line indices.
        :type polylines: list of list[int], optional

        :returns: A dictionary mapping each physical group name (key) to the list of
                  line indices that belong to that group (value).
        :rtype: dict[str, list[int]]
        """
        if polylines is None:
            points = self._extract_points(data)
            linestrings = self._extract_linestrings(data, points, self._extract_polypoints(data, points))
            polylines = self._get_polylines(self._get_lines(linestrings),linestrings)

        names = self._extract_physical_group_names(data, group_type)
        keys = set([key for subkey in names for key in subkey])

        # Associates the tpes to polylines
        groups_to_polylines = tuple(zip(names, polylines))

        # Builds the pairing point-to-resolution
        group = {key: [] for key in keys}
        for elem in groups_to_polylines:
            for key in elem[0]:
                group[key].extend(elem[1])
        
        if group_type != self._BOUNDARIES_KEY :
            group = {k: v for k, v in group.items() if k != ''} 
        return group

    def _extract_boundaries(self, data:GeoDataFrame, polylines:list=None) -> dict:
        """
        Extracts the boundaries from a shapefile and maps them to line indices.

        Each boundary in the shapefile is identified by a name (from the
        _BOUNDARIES_KEY column) and can consist of one or multiple polylines.
        This method returns a dictionary where each key is a boundary name and
        the corresponding value is a list of line indices that compose that boundary.

        :param data: The GeoDataFrame containing the shapefile geometries and attributes.
        :type data: geopandas.GeoDataFrame
        :param polylines: Optional precomputed list of polylines, where each polyline
                          is a list of line indices. If not provided, it will be
                          computed automatically.
        :type polylines: list of list[int], optional

        :returns: A dictionary mapping boundary names to the list of line indices.
        :rtype: dict[str, list[int]]
        """
        return self._extract_physical_groups(self._BOUNDARIES_KEY, data, polylines)

    @property
    def boundaries(self) -> dict:
        """
        A dictionary of boundaries names and boundary line indices.

        Each key is a boundary name extracted from the shapefile, and each value
        is a list of line indices that compose that boundary. This allows
        referencing the topology according to its physical boundary definitions.

        :getter: Dictionary mapping boundary names to lists of line indices.
        :rtype: dict[str, list[int]]
        """
        return self._boundaries
    
    def _extract_internal_boundaries(self, data: GeoDataFrame, polylines: list=None) -> dict:
        """
        
        Extracts the internal boundaries (boundary in a unique zone) from a shapefile and maps them to line indices.

        Each internal boundary in the shapefile is identified by a name (from the
        _BOUNDARIES_KEY column) and does not belong to any zone or region (_ZONE_KEY and 
        _REGION_KEY are Null) and can consist of one or multiple polylines.
        This method returns a dictionary where each key is an internal boundary name and
        the corresponding value is a list of line indices that compose that boundary.

        :param data: The GeoDataFrame containing the shapefile geometries and attributes.
        :type data: geopandas.GeoDataFrame
        :param polylines: Optional precomputed list of polylines, where each polyline
                          is a list of line indices. If not provided, it will be
                          computed automatically.
        :type polylines: list of list[int], optional

        :returns: A dictionary mapping internal boundary names to the list of line indices.
        :rtype: dict[str, list[int]]
        """

        # Compute polylines if not provided
        if polylines is None:
            points = self._extract_points(data)
            linestrings = self._extract_linestrings(data, points, self._extract_polypoints(data, points))
            polylines = self._get_polylines(self._get_lines(linestrings), linestrings)

        # Filter internal boundaries
        mask_internal = (
            (data[self._BOUNDARIES_KEY] != "") &
            (data[self._ZONES_KEY] == "") &
            (data[self._REGIONS_KEY] == "")
        )

        internal_boundaries = {}
        internal_names = data.loc[mask_internal, self._BOUNDARIES_KEY].tolist()

        # Link the filtered rows to their polylines
        for row_idx, name in zip(data.index[mask_internal], internal_names):
            if name not in internal_boundaries:
                internal_boundaries[name] = []
            internal_boundaries[name].extend(polylines[row_idx])

        return internal_boundaries
    
    @property
    def internal_boundaries(self) -> dict:
        """
        A dictionary of internal boundaries names and internal boundary line indices.

        Each key is an internal boundary name extracted from the shapefile, and each value
        is a list of line indices that compose that internal boundary. This allows
        referencing the topology according to its physical boundary definitions. An internal
        boundary is a line within a unique zone, which does not separate two different zones.

        :getter: Dictionary mapping internal boundary names to lists of line indices.
        :rtype: dict[str, list[int]]
        """
        return self._internal_boundaries

    def _extract_zones(self, data:GeoDataFrame, polylines:list=None) -> dict:
        """
        Extracts the zones defined in a shapefile and maps them to line indices.

        Each zone in the shapefile is identified by a name (from the _ZONES_KEY column)
        and consists of one or multiple polylines forming a closed loop.
        The returned dictionary maps each zone name to a list of line indices that
        delimit that zone. By convention, the first point of the first line is
        identical to the last point of the last line to form a closed loop. This convention
        is checked by the MeshMaker class.

        :param data: The GeoDataFrame containing the shapefile geometries and attributes.
        :type data: geopandas.GeoDataFrame
        :param polylines: Optional precomputed list of polylines, where each polyline
                          is a list of line indices. If not provided, it will be
                          computed automatically.
        :type polylines: list of list[int], optional

        :returns: A dictionary mapping zone names (key) to lists of line indices forming the zone boundaries (value).
        :rtype: dict[str, list[int]]
        """
        return self._extract_physical_groups(self._ZONES_KEY, data, polylines)

    @property
    def zones(self) -> dict: 
        """
        A dictionary of zones and line indices.

        Each key is a zone name extracted from the shapefile, and each value
        is a list of line indices that compose the boundary of that zone.
        By convention, the first point of the first line matches the last point
        of the last line, forming a closed loop.

        :getter: Dictionary mapping zone names to lists of line indices forming the zone boundaries.
        :rtype: dict[str, list[int]]
        """
        return self._zones

    def _extract_regions(self, data:GeoDataFrame, polylines:list=None, zones: dict=None) -> dict:
        """
        Extracts regions from a shapefile by grouping zones.

        Each region is composed of one or more zones. This method identifies
        which zones belong to each region by checking which zones have all
        their lines included in the region's line set.

        :param data: The GeoDataFrame containing the shapefile geometries and attributes.
        :type data: geopandas.GeoDataFrame
        :param polylines: Optional precomputed list of polylines, where each polyline
                          is a list of line indices. If not provided, it will be
                          computed automatically.
        :type polylines: list of list[int], optional
        :param zones: Optional dictionary mapping zone names to line indices. If not
                      provided, it will be computed automatically from the shapefile.
        :type zones: dict[str, list[int]], optional

        :returns: A dictionary mapping each region name to a set of zone names that
                  compose that region.
        :rtype: dict[str, set[str]]
        """        
        # Getting zones if not given
        if zones is None: zones = self.zones

        # Retrieve lines composing the regions
        regions_lines = self._extract_physical_groups(self._REGIONS_KEY, data, polylines)
        regions = {key: set() for key in regions_lines.keys()}

        # Finding zones that share the same lines with the regions.
        # That will happend if all lines from the zone are in the region.
        for region_name in regions.keys():
            for zone_name in zones.keys():
                if all(elem in regions_lines[region_name] for elem in zones[zone_name]): 
                    regions[region_name].add(zone_name)

        return regions
    
    @property
    def regions(self) -> dict: 
        """
        A dictionary of regions and zones names.

        Each key is a region name extracted from the shapefile, and each value
        is a set of zone names that compose that region. Zones are included in
        a region if all their line segments are part of the region's lines.

        :getter: Dictionary mapping region names to sets of zone names.
        :rtype: dict[str, set[str]]
        """
        return self._regions

    def _reindex_lines(self):
        """
        Reindexes all lines, polylines, zones, and boundaries to start after the points.

        In some mesh formats (e.g., GMSH), line indices start after the point indices.
        This method updates all line-related structures so that indexing starts at
        n_points + 1, where n_points is the number of extracted points.

        The following attributes are modified in place:

        - _lines: dictionary mapping new line indices to their point tuples.
        - _polylines: list of polylines updated to use the new line indices.
        - _zones: dictionary mapping zone names to updated line indices.
        - _boundaries: dictionary mapping boundary names to updated line indices.
        """
        # Modify the line indexing such that the lines now start at n_points+1; like in gmsh.
        self._n_points = len(self.points)
        self._lines = {index+self._n_points+1: value for index, value in enumerate(self.lines)}
        self._polylines = [[elem+self._n_points+1 for elem in polyline] for polyline in self.polylines]
        self._zones = {key: [vals+self._n_points+1 for vals in value] for key, value in self.zones.items()}
        self._boundaries = {key: [vals+self._n_points+1 for vals in value] for key, value in self.boundaries.items()}
        self._internal_boundaries = {key: self.boundaries[key] for key in self.internal_boundaries}
