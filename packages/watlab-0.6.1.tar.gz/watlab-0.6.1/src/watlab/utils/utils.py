# # -*- coding: utf-8 -*- 
# """::

#   _    _           _            __ _               
#  | |  | |         | |          / _| |              
#  | |__| |_   _  __| |_ __ ___ | |_| | _____      __
#  |  __  | | | |/ _` | '__/ _ \|  _| |/ _ \ \ /\ / /
#  | |  | | |_| | (_| | | | (_) | | | | (_) \ V  V / 
#  |_|  |_|\__, |\__,_|_|  \___/|_| |_|\___/ \_/\_/  
#           __/ |                                    
#          |___/

# This module includes functions and classes to pilot hydroflow.

# Usage:
# ======

# Insert here the description of the module


# License
# =======

# Copyright (C) <1998 – 2024> <Université catholique de Louvain (UCLouvain), Belgique> 
	
# List of the contributors to the development of Watlab: see AUTHORS file.
# Description and complete License: see LICENSE file.
	
# This program (Watlab) is free software: you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation, either version 3 of the License, or (at your option) any later version.

# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.

# You should have received a copy of the GNU General Public License
# along with this program (see COPYING file).  If not, 
# see <http://www.gnu.org/licenses/>.

# """
import rasterio 
import numpy as np 
from scipy.interpolate import griddata
from pandas import to_datetime
import os
import pandas as pd
from netCDF4 import Dataset

def extract_values_from_tif(tif_file):
    """
    Extracts spatial coordinates and corresponding raster values from a GeoTIFF file.

    This function opens a GeoTIFF using Rasterio, reads the image band, 
    and computes the (x, y) coordinates of each pixel in the raster grid.

    :param tif_file: Path to the input GeoTIFF file.
    :type tif_file: str
    :return: 
        - **tif_points_coordinates** (*numpy.ndarray*): Array of shape (N, 2) containing the (x, y) coordinates of each pixel.  
        - **tif_points_data** (*numpy.ndarray*): Array of shape (N,) containing the raster values for each pixel.
    :rtype: tuple(numpy.ndarray, numpy.ndarray)

    **Example**

    .. code-block:: python

        coords, values = extract_values_from_tif("dem.tif")
        print(coords.shape, values.shape)
    """
    with rasterio.open(tif_file) as dataset:
                image_data = dataset.read()
                transform = dataset.transform
                # Get the x and y coordinates of the top-left corner of the image
                x_origin = transform.c
                y_origin = transform.f
                # Get the x and y coordinates of the bottom-right corner of the image
                x_end = x_origin + (dataset.width * transform.a) + transform.a
                y_end = y_origin + (dataset.height * transform.e) + transform.e
                x_coords, y_coords = np.meshgrid(np.linspace(x_origin, x_end, dataset.width), np.linspace(y_origin, y_end, dataset.height))
                data = image_data[0]
            
    tif_points_coordinates = np.column_stack((x_coords.flatten(), y_coords.flatten()))
    tif_points_data = data.flatten()
    return tif_points_coordinates, tif_points_data

def interpolate_points(known_points_coordinates,known_points_data,desired_points,interpolation_method='nearest'):
    """
    Interpolates values at desired spatial points based on known data points.

    This function performs spatial interpolation (nearest, linear, or cubic)
    using the `scipy.interpolate.griddata` function. It interpolates values at 
    target (x, y) coordinates from a set of known points and associated data.

    :param known_points_coordinates: Coordinates of known data points, of shape (N, 2).
    :type known_points_coordinates: numpy.ndarray
    :param known_points_data: Values corresponding to the known points, of shape (N,).
    :type known_points_data: numpy.ndarray
    :param desired_points: Coordinates where interpolated values should be estimated, of shape (M, 2).
    :type desired_points: numpy.ndarray
    :param interpolation_method: Interpolation method; one of ``'nearest'``, ``'linear'`` or ``'cubic'``. Defaults to ``'nearest'``.
    :type interpolation_method: str, optional
    :return: Interpolated values at the desired points.
    :rtype: numpy.ndarray

    **Example**

    .. code-block:: python

        import numpy as np
        from scipy.interpolate import griddata

        # Known data points
        known_coords = np.array([[0, 0], [1, 0], [0, 1], [1, 1]])
        known_values = np.array([1.0, 2.0, 3.0, 4.0])

        # Points where we want interpolated values
        target_points = np.array([[0.5, 0.5], [0.25, 0.75]])

        interpolated = interpolate_points(known_coords, known_values, target_points, interpolation_method='linear')
        print(interpolated)
    """
    desired_points_x,  desired_points_y  = desired_points[:,0], desired_points[:,1]
    mesh_points = np.column_stack((desired_points_x.flatten(), desired_points_y.flatten()))
    return griddata(known_points_coordinates, known_points_data, mesh_points, method=interpolation_method)

def generate_sourceterm_id():
    """
    Generates a sequential source term identifier each time it is called.

    This function is a generator that yields an incrementing integer value 
    starting from zero. Each iteration provides a unique ID, which can be used 
    to label or index source terms in a model or simulation.

    :return: Generator that yields an incremental integer ID.
    :rtype: generator of int

    **Example**

    .. code-block:: python

        id_generator = generate_sourceterm_id()

        next(id_generator)  # 0
        next(id_generator)  # 1
        next(id_generator)  # 2
    """
    count = 0
    while True:
        yield count
        count += 1

def parse_date(date_string):
    """
    Parses a date string into a pandas ``Timestamp`` object.

    This function attempts to convert a given date string into a datetime object 
    using ``pandas.to_datetime`` with flexible parsing (``format='mixed'``).  
    If the input string cannot be parsed, a ``ValueError`` is raised.

    :param date_string: The date string to parse. It should follow the format ``'YYYY-MM-DD HH:MM'``.
    :type date_string: str
    :return: Parsed date as a pandas ``Timestamp``.
    :rtype: pandas.Timestamp
    :raises ValueError: If the date string is not in a recognized or supported format.

    **Example**

    .. code-block:: python

        from watlab.utils import parse_date

        # Valid date string
        dt = parse_date("2024-07-15 12:30")
        print(dt)  # 2024-07-15 12:30:00

        # Invalid format example
        parse_date("15/07/2024")  
        # Raises: ValueError: The date string is not in the correct format.
    """
    try:
        return to_datetime(date_string, format='mixed')
    except:
        raise ValueError("The date string is not in the correct format. Please provide a date string in the format 'YYYY-MM-DD HH:MM'")


def post_processed_gauge(pic_path_template, time_step, variable_names, node_index, output_file_path):
    """
    Extracts and processes time series (gauge) data from simulation output “picture” files.

    This function reads a sequence of text or CSV files representing simulation
    snapshots over time, extracts one or more variables for a specific mesh node,
    and writes the resulting time series to a CSV file.

    :param pic_path_template: Template string for file paths. It should contain 
        placeholders for the time values (e.g., ``"output_{:05d}_{:02d}.txt"``).
    :type pic_path_template: str
    :param time_step: Time interval (in seconds) between consecutive output files.
    :type time_step: int
    :param variable_names: List of variable names to extract from each file 
        (e.g., ``["h", "V", "zb"]``).
    :type variable_names: list of str
    :param node_index: Index (zero-based) of the mesh node for which to extract data.
    :type node_index: int
    :param output_file_path: Destination path where the extracted gauge data 
        will be saved as a CSV file.
    :type output_file_path: str
    :return: None. The function writes the processed gauge data to a CSV file.
    :rtype: None

    **Example**

    .. code-block:: python

        from watlab.utils import post_processed_gauge

        pic_path_template = "results/pic_{:05d}_{:02d}.txt"
        time_step = 60  # seconds
        variable_names = ["h", "V"]
        node_index = 42
        output_file_path = "output/gauge_node42.csv"

        post_processed_gauge(pic_path_template, time_step, variable_names, node_index, output_file_path)

        # -> Creates a CSV file with columns: time, h, V
    """
    time_second = 0
    time_hundreds = 0
    data = {var: [] for var in variable_names}
    time = []

    while os.path.exists(pic_path_template.format(time_second, time_hundreds)):
        file = pic_path_template.format(time_second, time_hundreds)
        file_data = pd.read_csv(file, sep='\s+')
        for var in variable_names:
            data[var].append(file_data[var][node_index])
        time.append(time_second)
        time_second += time_step

    gauge_data = {"time": time}
    for var in variable_names:
        gauge_data[var] = data[var]

    output_df = pd.DataFrame(gauge_data)
    output_df.to_csv(output_file_path, index=False)
  
def select_postprocessing_variable(data, variable_name, manning_values=None):
    """
    Selects and computes a variable from simulation data for post-processing or plotting.

    Depending on the provided `variable_name`, this function extracts the corresponding
    column from the data or computes derived variables such as velocity, Froude number, 
    or shear stress. Supports both pandas DataFrames and numpy structured arrays.

    :param data: The simulation data from which to extract or compute the variable.
        Must contain columns like "h", "zb", "qx", "qy", etc.
    :type data: pandas.DataFrame or numpy.ndarray
    :param variable_name: Name of the variable to select or compute. 
                            Supported values: \n
                            - `"h"` or `"height"`: water depth
                            - `"zb"`: bed elevation
                            - `"zw"`: water surface elevation (`zb + h`)
                            - `"V"` or `"velocity"`: flow velocity magnitude
                            - `"qx"`, `"qy"`: flow components
                            - `"Fr"` or `"Froude"`: Froude number
                            - `"Shear stress"` or `"tau"`: bed shear stress (requires `manning_values`)
                            - any column present in `data`
    :type variable_name: str
    :param manning_values: Optional array of Manning's coefficient 'n' values, required for `"Shear stress"` calculation.
    :type manning_values: numpy.ndarray or list, optional
    :return: Array of values corresponding to the selected variable.
    :rtype: numpy.ndarray
    :raises ValueError: If `variable_name` is unknown or missing in `data`.

    **Example**

    .. code-block:: python

        import numpy as np
        import pandas as pd
        from watlab.utils import select_postprocessing_variable

        data = pd.DataFrame({
            "h": [1.0, 2.0],
            "zb": [0.0, 0.0],
            "qx": [0.5, 1.0],
            "qy": [0.0, 0.0]
        })
        manning = np.array([0.03, 0.03])

        # Select water depth
        h_values = select_postprocessing_variable(data, "h")

        # Compute velocity
        velocity = select_postprocessing_variable(data, "V")

        # Compute shear stress
        tau = select_postprocessing_variable(data, "Shear stress", manning_values=manning)
    """
    match variable_name:
        case "h" | "height":
            variable = data["h"].values
        case "zb":
            variable = data["zb"].values   
        case "zw":
            variable = data["zb"].values + data["h"].values  # zw = zb + h
        case "V" | "velocity":
            h = data["h"].values
            qx, qy = data["qx"].values, data["qy"].values
            u_velocity, v_velocity = np.zeros_like(h), np.zeros_like(h)
            u_velocity[h>0], v_velocity[h>0] = qx[h>0] / h[h>0], qy[h>0] / h[h>0]
            variable = np.sqrt(u_velocity**2 + v_velocity**2)
        case "qx":
            variable = data["qx"].values
        case "qy":
            variable = data["qy"].values
        case "Fr" | "Froude":
            h = data["h"].values
            qx, qy = data["qx"].values, data["qy"].values
            u_velocity, v_velocity = np.zeros_like(h), np.zeros_like(h)
            u_velocity[h>0], v_velocity[h>0] = qx[h>0] / h[h>0], qy[h>0] / h[h>0]
            velocity = np.sqrt(u_velocity**2 + v_velocity**2)
            froude = np.zeros_like(h)
            froude[h>0] = velocity[h>0]/np.sqrt(9.81 * h[h>0])  # Froude number: Fr = V / sqrt(g * h)
            variable = froude
        case "Shear stress" | "tau":
            h = data["h"].values
            qx, qy = data["qx"].values, data["qy"].values
            u_velocity, v_velocity = np.zeros_like(h), np.zeros_like(h)
            u_velocity[h>0], v_velocity[h>0] = qx[h>0] / h[h>0], qy[h>0] / h[h>0]
            velocity = np.sqrt(u_velocity**2 + v_velocity**2)
            Sf = np.zeros_like(h)
            Sf[h>0] = manning_values[h>0]**2 * velocity[h>0]**2 / (h[h>0]**(4/3))
            variable = 9.81 * data["h"].values * Sf * 1000 # tau = rho * g * h * Sf
        case _:
            if hasattr(data, "columns") and variable_name in data.columns:
                variable = data[variable_name].values
            else:
                raise ValueError(f"Unknown variable_name: {variable_name}")
    return variable

def post_processed_maximal_values(pic_path_template, time_step, output_file_name, variable_names=None,manning_values=None):    
    """
    Process a series of simulation output “picture” files and extract the maximal values 
    of specified variables over time.

    This function iterates over multiple picture/output files generated by a simulation,
    extracts specified variables for all nodes, and computes the maximum value of each 
    variable at each node over the entire time series. The results are saved to a CSV file.

    :param pic_path_template: Template path to the picture files, with placeholders 
        for time formatting (e.g., `"pic_{:05d}_{:02d}.txt"`).
    :type pic_path_template: str
    :param time_step: Time step increment (in seconds) between consecutive files.
    :type time_step: int
    :param output_file_name: Path to save the CSV file containing maximal values.
    :type output_file_name: str
    :param variable_names: List of variable names to extract and process. If None, all available variables are used.
    :type variable_names: list of str, optional
    :param manning_values: Optional array of Manning's coefficient 'n' values, required if shear stress is computed.
    :type manning_values: list or numpy.ndarray, optional
    :return: Dictionary containing the maximal values for each variable at each node.
    :rtype: dict
    :raises FileNotFoundError: If a file matching `pic_path_template` does not exist.

    **Example**

    .. code-block:: python

        pic_template = "results/pic_{:05d}_{:02d}.txt"
        time_step = 60
        output_file = "max_values.csv"
        variables = ["h", "V", "Shear stress"]
        manning = np.array([0.03, 0.03, 0.03])

        max_vals = post_processed_maximal_values(pic_template, time_step, output_file, variable_names=variables, manning_values=manning)

        print(max_vals["h"])  # Maximal water depth over all timesteps
    """
    time_second = 0
    time_hundreds = 00
    data= pd.read_csv(pic_path_template.format(time_second, time_hundreds), sep='\s+')
    
    overall_max = {
        "x": data["x"].values,
        "y": data["y"].values,
        "zb": data["zb"].values
    }
    for var in variable_names:
        overall_max[var] = np.zeros(len(data))
    
    while os.path.exists(pic_path_template.format(time_second, time_hundreds)):
        data = pd.read_csv(pic_path_template.format(time_second, time_hundreds), sep='\s+')
        for var in variable_names:
            variable = select_postprocessing_variable(data,variable_name=var, manning_values=manning_values)
            
            overall_max[var] = np.maximum(overall_max[var], np.nan_to_num(variable, 0))
        time_second += time_step
        print(f"Processed time: {time_second} seconds")

    pd.DataFrame(overall_max).to_csv(output_file_name, index=False, sep='\t')
    return overall_max

def create_netcdf_mesh(output_file, nodes_file, cells_file, EPSG_CODE="31370"):
    """
    Creates a NetCDF file defining a 2D mesh topology from node and cell files.

    This function reads a set of node coordinates and cell connectivity
    from text files, defines the mesh topology, and writes it to a NetCDF file 
    following CF conventions. The mesh includes node coordinates, elevation (zb),
    connectivity of faces, and optional EPSG-based spatial reference.

    :param output_file: Path to the output NetCDF file to be created.
    :type output_file: str
    :param nodes_file: Path to the file containing node coordinates. The file should have at least three columns: x, y, zb, with a header row (number of nodes).
    :type nodes_file: str
    :param cells_file: Path to the file containing cell connectivity. The file should have a header row (number of cells) and at least three columns (node indices).
    :type cells_file: str
    :param EPSG_CODE: EPSG code for the coordinate reference system. Default is `"31370"`.
    :type EPSG_CODE: str, optional
    :return: NetCDF Dataset object representing the created mesh.
    :rtype: netCDF4.Dataset

    **Example**

    .. code-block:: python

        from watlab.utils import create_netcdf_mesh

        ncfile = create_netcdf_mesh(
            output_file="mesh.nc",
            nodes_file="nodes.txt",
            cells_file="cells.txt",
            EPSG_CODE="25831"
        )

        print(ncfile)  # NetCDF Dataset object
        ncfile.close()
    """
    nodes = np.loadtxt(nodes_file, skiprows=1) 
    triangles = np.loadtxt(cells_file, dtype=int, skiprows=1)[:, 1:]  
    
    n_nodes = nodes.shape[0]
    n_faces = triangles.shape[0]
    max_face_nodes = triangles.shape[1]

    ncfile = Dataset(output_file, mode="w", format="NETCDF4")
    ncfile.createDimension("nodes", n_nodes)
    ncfile.createDimension("faces", n_faces)
    ncfile.createDimension("max_face_nodes", max_face_nodes)

    mesh_var = ncfile.createVariable("mesh", "i4")
    mesh_var.setncattr("cf_role", "mesh_topology")
    mesh_var.setncattr("topology_dimension", 2)
    mesh_var.setncattr("node_coordinates", "x y")
    mesh_var.setncattr("face_node_connectivity", "connectivity")
    
    scr = ncfile.createVariable("scr", "i4")
    scr.grid_mapping_name = "latitude_longitude"
    scr.epsg_code = "EPSG:" + EPSG_CODE

    x_var = ncfile.createVariable("x", "f8", ("nodes",))
    y_var = ncfile.createVariable("y", "f8", ("nodes",))
    zb_var = ncfile.createVariable("zb", "f8", ("nodes",))

    x_var.standard_name = "X coordinates"    
    y_var.standard_name = "Y coordinates"
    x_var.grid_mapping = "scr"
    y_var.grid_mapping = "scr"
        
    x_var[:] = nodes[:, 0]
    y_var[:] = nodes[:, 1]
    zb_var[:] = nodes[:, 2]

    connectivity = ncfile.createVariable("connectivity", "i4", ("faces", "max_face_nodes"))
    connectivity.setncattr("long_name", "Face to node connectivity")
    connectivity.setncattr("start_index", 0)  # 0-based indexing
    connectivity[:, :] = triangles
    return ncfile 
    
def generate_netcdf_file_from_picture(nodes_file, cells_file, manning_values, pic_path_template, output_file,max_time, time_step, EPSG_CODE="31370",initial_time=0):
    """
    Generate a NetCDF file from mesh and simulation field data over time.

    This function reads a mesh (nodes and cells) and a series of simulation output
    "picture" files, computes derived fields such as velocity and shear stress, 
    and writes all variables into a NetCDF file structured by time and faces.

    :param nodes_file: Path to the file containing node coordinates (x, y, zb).
    :type nodes_file: str
    :param cells_file: Path to the file containing cell connectivity (node indices).
    :type cells_file: str
    :param manning_values: Array or list of Manning's coefficient 'n' values per node.
    :type manning_values: list or numpy.ndarray
    :param pic_path_template: Template path for the picture file paths, with placeholders for time formatting.
    :type pic_path_template: str
    :param output_file: Path to the output NetCDF file to create.
    :type output_file: str
    :param max_time: Maximum simulation time in seconds.
    :type max_time: int
    :param time_step: Time step interval between simulation outputs, in seconds.
    :type time_step: int
    :param EPSG_CODE: EPSG code for the coordinate reference system (default: "31370").
    :type EPSG_CODE: str, optional
    :param initial_time: Initial time for the simulation in seconds (default: 0).
    :type initial_time: int, optional
    :return: None. The function writes all variables into the NetCDF file specified by `output_file`.
    :rtype: None

    **Example**

    .. code-block:: python

        nodes_file = "nodes.txt"
        cells_file = "cells.txt"
        manning_values = np.loadtxt("manning.txt")
        pic_template = "results/pic_{:05d}_{:02d}.txt"
        output_file = "simulation.nc"
        max_time = 3600
        time_step = 60

        generate_netcdf_file_from_picture(
            nodes_file,
            cells_file,
            manning_values,
            pic_template,
            output_file,
            max_time,
            time_step
        )
    """

    # manning_values = np.loadtxt(friction_values)

    ncfile = create_netcdf_mesh(output_file, nodes_file, cells_file, EPSG_CODE=EPSG_CODE)
    
    n_timesteps = int(max_time/time_step)  # number of files/timesteps
    ncfile.createDimension("time", n_timesteps)
    time_var = ncfile.createVariable("time", "f8", ("time",))
    time_var[:] = np.arange(initial_time, max_time, time_step)  # time in seconds
  
    h_var = ncfile.createVariable("h", "f8", ("time", "faces"))
    h_var.setncattr("location", "face")
    h_var.setncattr("units", "m")
    h_var.setncattr("standard_name", "Water depth")

    u_var = ncfile.createVariable("u_velocity", "f8", ("time", "faces"))
    u_var.setncattr("location", "face")
    u_var.setncattr("units", "m/s")
    u_var.setncattr("mesh", "mesh2d")
    u_var.setncattr("standard_name", "eastward_velocity")

    v_var = ncfile.createVariable("v_velocity", "f8", ("time", "faces"))
    v_var.setncattr("location", "face")
    v_var.setncattr("units", "m/s")
    v_var.setncattr("mesh", "mesh2d")
    v_var.setncattr("standard_name", "northward_velocity")
    
    velocity_var = ncfile.createVariable("velocity", "f8", ("time", "faces"))
    velocity_var.setncattr("location", "face")
    velocity_var.setncattr("units", "m/s")

    shear_stress_var = ncfile.createVariable("shear_stress", "f8", ("time", "faces"))
    shear_stress_var.setncattr("location", "face")
    shear_stress_var.setncattr("units", "Pa")

    zw_var = ncfile.createVariable("zw", "f8", ("time", "faces"))
    zw_var.setncattr("location", "face")
    zw_var.setncattr("units", "m")
    zw_var.setncattr("standard_name", "Water surface elevation")
     
    # Field values
    time_second = 0
    t_index = 0 
    
    while time_second < max_time:
        data = pd.read_csv(pic_path_template.format(time_second, 0), sep=r'\s+')
        
        h = data["h"].values
        qx = data["qx"].values
        qy = data["qy"].values
        zb = data["zb"].values
 
        u_velocity, v_velocity = np.zeros_like(h), np.zeros_like(h)
        u_velocity[h>0], v_velocity[h>0] = qx[h>0] / h[h>0], qy[h>0] / h[h>0]
       
        zw = h + zb

        velocity = np.sqrt(u_velocity**2 + v_velocity**2)

        Sf = np.zeros_like(h)
        Sf[h>0] = manning_values[h>0]**2 * velocity[h>0]**2 / (h[h>0]**(4/3))
        shear_stress = 9.81 * h * Sf * 1000  # in Pascals

        h_var[t_index, :] = h
        u_var[t_index, :] = u_velocity
        v_var[t_index, :] = v_velocity
        zw_var[t_index, :] = zw
        velocity_var[t_index, :] = velocity
        
        shear_stress_var[t_index, :] = shear_stress
        time_second += time_step
        t_index += 1
        print(time_second)
    ncfile.sync()
    ncfile.close()
    print(f"NetCDF file {output_file} created successfully.")