# ============================================================
# ============================================================
#
# Binding file for wavex here all conversion from pointers
# given by WaveX.API.dll are converted in numpy zero-copy
# arrays, the user just reads the callbacks, for now all
# available options are start and stop
#
# ============================================================
# ============================================================

import os
import ctypes
from ctypes import (
    c_int32,
    c_uint32,
    c_uint16,
    c_uint8,
    c_int16,
    c_void_p,
    POINTER,
    Structure,
    WINFUNCTYPE,
)
import numpy as np
from .enums import *
# ============================================================
# WaveX global constants, they must correspond exactly to
# the original otherwise array conversion will fail
# ============================================================
DEVICE_MASTER_MASTERSLAVE_REQ = 0
DEVICE_SLAVE_MASTERSLAVE_REQ = 1
DEVICE_SLAVE_REQ = 2
DEVICE_NONE_REQ = 3
ACC_GYRO_MAG_AXES = 3
IMU_DATA_DIM = 4
EMG_CHANNEL_MAX_VALUE_MICROVOLT = 3300
MAX_FSW_SENSORS_NUM = 2
FSW_TRANSDUCERS_NUM = 4

FSW_THRESHOLDS_NUM = 4
FSW_DEFAULT_THRESHOLD_VALUE = 20
FSW_CHANNEL_MAX_VALUE_VOLT = 4
ANALOG_CHANNEL_MAX_VALUE_VOLT = 3.3
IMU_MAGNETOMETER_CHANNEL_MAX_VALUE_MICROTESLA = 4900
IMU_MAGNETOMETER_3_CHANNELS_OVERFLOW_MICROTESLA = 4912
INSOLE_MAX_VALUE_PERCENT = 100
INSOLE_SENSOR_SAMPLING_RATE = 100
MAX_DEVICE_SENSORS_NUM = 18
MAX_SENSORS_NUM = 36
ANALOG_OUTPUTS_NUM = 40

MAX_REMOTE_CONTROLLERS_NUM = 2
MAX_ANALOG_CHANNELS_NUM = 32
MAX_HDsEMGs_NUM = 4
MAX_HDsEMG_SENSORS_NUM = 32
MAX_INSOLES_NUM = 2
MAX_INSOLE_SENSORS_NUM = 64

# ============================================================
# DLL loading, all the necessary dll must be in the folder _native
# ============================================================

_native_dir = os.path.join(os.path.dirname(__file__), "_native")
os.add_dll_directory(_native_dir)

_lib = ctypes.WinDLL(os.path.join(_native_dir, "WaveX.API.dll"))

# ============================================================
# Capture configuration API
# ============================================================

_lib.WaveX_CaptureConfig_Create.restype = c_void_p
_lib.WaveX_CaptureConfig_Destroy.argtypes = [c_void_p]

_lib.WaveX_CaptureConfig_SetImuAcqPType.argtypes = [c_void_p, c_int32]
_lib.WaveX_CaptureConfig_SetEmgAcqPType.argtypes = [c_void_p, c_int32]
_lib.WaveX_CaptureConfig_SetImuAcqXType.argtypes = [c_void_p, c_int32]
_lib.WaveX_CaptureConfig_SetEmgAcqXType.argtypes = [c_void_p, c_int32]
_lib.WaveX_CaptureConfig_SetEMG_IMU_AcqXType.argtypes= [c_void_p, c_int32]
_lib.WaveX_CaptureConfig_SetIMU_AcqBType.argtypes = [c_void_p, c_int32]
_lib.WaveX_CaptureConfig_SetEMG_AcqBType.argtypes = [c_void_p, c_int32]


_lib.WaveX_CaptureConfig_EnableInsole.argtypes = [
    c_void_p,  # cfg
    c_int32,   # index
    c_uint8,   # enabled
]

_lib.WaveX_CaptureConfig_SetInsoleProtocol.argtypes = [c_void_p, c_int32]
_lib.WaveX_CaptureConfig_SetInsole_BtAcqType.argtypes = [c_void_p, c_int32]
_lib.WaveX_CaptureConfig_SetInsole_RfAcqType.argtypes = [c_void_p, c_int32]
_lib.WaveX_CaptureConfig_SetInsole_AccelerometerFullScale.argtypes = [c_void_p, c_int32]
_lib.WaveX_CaptureConfig_SetInsole_GyroscopeFullScale.argtypes = [c_void_p, c_int32]

_lib.WaveX_CaptureConfig_EnableAnalogChannel.argtypes = [
    c_void_p,  # cfg
    c_int32,   # index
    c_uint8,   # enabled
]


_lib.WaveX_CaptureConfig_SetAnalogConfig.argtypes = [
    c_void_p,   # cfg
    c_int32,    # WaveX_AnalogAcqType
    c_int32,    # WaveX_AnalogTriggerMode
    c_int32,    # WaveX_VoltageFullScale
    c_int32,    # delayMs
]

_lib.WaveX_ConfigureCapture.argtypes = [
    c_void_p,  # handle
    c_void_p,  # cfg
]
_lib.WaveX_ConfigureCapture.restype = c_uint8

_lib.WaveX_SensorConfig_Create.restype = c_void_p
_lib.WaveX_SensorConfig_Destroy.argtypes = [c_void_p]

_lib.WaveX_SensorConfig_Set.argtypes = [
	c_void_p,   # cfg,
    c_int32,    # SensorModel,
    c_int32,    # SensorMode,
    c_int32,    # AccelerometerFullScale,
    c_int32,    # GyroscopeFullScale
]

_lib.WaveX_ConfigureSensor.argtypes = [
    c_void_p,  # handle,
    c_void_p,  # cfg,
    c_int32    # sensorIndex
]

_lib.WaveX_ConfigureSensor.restype = c_uint8


_lib.WaveX_CalibrateImuOffset.argtypes = [
    c_void_p,  # handle
    c_int32    # sensorIndex
]

_lib.WaveX_CalibrateGyroscopeOffset.argtypes = [
    c_void_p,  # handle,
    c_int32    # sensorIndex
]

_lib.WaveX_CalibrateAccelerometerOffset.argtypes = [
    c_void_p,  # handle,
    c_int32    # sensorIndex
]

_lib.WaveX_CalibrateEMGOffset.argtypes = [
    c_void_p,  # handle,
    c_int32    # sensorIndex
]

_lib.WaveX_UpdateDisplay.argtypes = [c_void_p]

_lib.WaveX_SaveCurrentRxConfiguration.argtypes = [c_void_p]
_lib.WaveX_GetDeviceState.argtypes = [c_void_p]
_lib.WaveX_GetDeviceState.restype = c_int32

# ============================================================
# ArrayView definitions
# ============================================================

def _reshape_2d(arr, d0, d1):
    if arr.size == 0:
        return arr.reshape((0, 0))
    return arr.reshape((d0, d1))


def _reshape_3d(arr, d0, d1, d2):
    if arr.size == 0:
        return arr.reshape((0, 0, 0))
    return arr.reshape((d0, d1, d2))

# ============================================================
# ArrayView definitions
# ============================================================

class _ArrayViewF32(Structure):
    _fields_ = [
        ("data", POINTER(ctypes.c_float)),
        ("length", c_uint32),
    ]

    def to_numpy(self):
        if not self.data or self.length == 0:
            return np.empty(0, dtype=np.float32)
        return np.ctypeslib.as_array(self.data, shape=(self.length,))


class _ArrayViewU16(Structure):
    _fields_ = [
        ("data", POINTER(c_uint16)),
        ("length", c_uint32),
    ]

    def to_numpy(self):
        if not self.data or self.length == 0:
            return np.empty(0, dtype=np.uint16)
        return np.ctypeslib.as_array(self.data, shape=(self.length,))


class _ArrayViewI16(Structure):
    _fields_ = [
        ("data", POINTER(c_int16)),
        ("length", c_uint32),
    ]

    def to_numpy(self):
        if not self.data or self.length == 0:
            return np.empty(0, dtype=np.int16)
        return np.ctypeslib.as_array(self.data, shape=(self.length,))



# ============================================================
# ctypes struct mirror (C ABI)
# ============================================================

class _DataAvailableArgs_C(Structure):
    _fields_ = [
        ("ScanNumber", c_int32),

        ("EmgSamples", _ArrayViewF32),
        ("ImuSamples", _ArrayViewF32),
        ("AccelerometerSamples", _ArrayViewF32),
        ("GyroscopeSamples", _ArrayViewF32),
        ("MagnetometerSamples", _ArrayViewF32),
        ("SyncSamples", _ArrayViewF32),
        ("SensorStates", _ArrayViewF32),
        ("FootSwSamples", _ArrayViewF32),
        ("FootSwRawSamples", _ArrayViewF32),
        ("FootSwSensorStates", _ArrayViewF32),

        ("RemoteControlEvents", _ArrayViewU16),
        ("RemoteControlState", c_uint16),

        ("StartTriggerDetected", c_uint8),
        ("StopTriggerDetected", c_uint8),
        ("StartTriggerScan", c_int32),
        ("StopTriggerScan", c_int32),

        ("StartInsoleTriggerDetected", c_uint8),
        ("StopInsoleTriggerDetected", c_uint8),
        ("StartInsoleTriggerScan", c_int32),
        ("StopInsoleTriggerScan", c_int32),

        ("StartInsoleImuTriggerDetected", c_uint8),
        ("StopInsoleImuTriggerDetected", c_uint8),
        ("StartInsoleImuTriggerScan", c_int32),
        ("StopInsoleImuTriggerScan", c_int32),

        ("StartAnalogTriggerDetected", c_uint8),
        ("StopAnalogTriggerDetected", c_uint8),
        ("StartAnalogTriggerScan", c_int32),
        ("StopAnalogTriggerScan", c_int32),

        ("DataTransferRate", c_int32),
        ("UsbLostPackets", c_int32),
        ("UsbLowPerformance", c_uint8),

        ("InsoleScanNumber", c_int32),
        ("InsoleImuScanNumber", c_int32),

        ("InsoleSamples", _ArrayViewF32),
        ("InsoleImuSamples", _ArrayViewF32),
        ("InsoleAccelerometerSamples", _ArrayViewF32),
        ("InsoleGyroscopeSamples", _ArrayViewF32),
        ("InsoleStates", _ArrayViewF32),

        ("AnalogScanNumber", c_int32),
        ("AnalogSamples", _ArrayViewF32),
        ("AnalogStates", _ArrayViewI16),
    ]


class DataAvailableEvent:
    __slots__ = (
        # Device
        "ScanNumber",
        "EmgSamples",
        "AccelerometerSamples",
        "ImuSamples",
        "GyroscopeSamples",
        "MagnetometerSamples",
        "SensorStates",
        "SyncSamples",

        # Footswitch
        "FootSwSamples",
        "FootSwRawSamples",
        "FootSwSensorStates",

        # Remote control
        "RemoteControlEvents",
        "RemoteControlState",

        # Triggers
        "StartTriggerDetected",
        "StopTriggerDetected",
        "StartTriggerScan",
        "StopTriggerScan",

        "StartInsoleTriggerDetected",
        "StopInsoleTriggerDetected",
        "StartInsoleTriggerScan",
        "StopInsoleTriggerScan",

        "StartInsoleImuTriggerDetected",
        "StopInsoleImuTriggerDetected",
        "StartInsoleImuTriggerScan",
        "StopInsoleImuTriggerScan",

        "StartAnalogTriggerDetected",
        "StopAnalogTriggerDetected",
        "StartAnalogTriggerScan",
        "StopAnalogTriggerScan",

        "DataTransferRate",
        "UsbLostPackets",
        "UsbLowPerformance",

        # Insole
        "InsoleScanNumber",
        "InsoleSamples",
        "InsoleImuSamples",
        "InsoleAccelerometerSamples",
        "InsoleGyroscopeSamples",
        "InsoleStates",

        # Analog
        "AnalogScanNumber",
        "AnalogSamples",
        "AnalogStates",

        # HDsEmg (optional)
        "HDsEmgScanNumber",
        "HDsEmgSamples",
        "HDsEmgStates",
    )

    def __init__(self, c):
        # ----------------------------------------------------
        # Device
        # ----------------------------------------------------
        self.ScanNumber = c.ScanNumber
        self.EmgSamples = _reshape_2d(c.EmgSamples.to_numpy(), MAX_SENSORS_NUM, self.ScanNumber)
        self.AccelerometerSamples = _reshape_3d(c.AccelerometerSamples.to_numpy(), MAX_SENSORS_NUM, ACC_GYRO_MAG_AXES, self.ScanNumber)
        self.ImuSamples = _reshape_3d(c.ImuSamples.to_numpy(), MAX_SENSORS_NUM, IMU_DATA_DIM, self.ScanNumber)
        self.GyroscopeSamples = _reshape_3d(c.GyroscopeSamples.to_numpy(), MAX_SENSORS_NUM, ACC_GYRO_MAG_AXES, self.ScanNumber)
        self.MagnetometerSamples = _reshape_3d(c.MagnetometerSamples.to_numpy(), MAX_SENSORS_NUM, ACC_GYRO_MAG_AXES, self.ScanNumber)
        self.SensorStates = c.SensorStates.to_numpy()
        self.SyncSamples = c.SyncSamples.to_numpy()

        # ----------------------------------------------------
        # Footswitch
        # ----------------------------------------------------
        self.FootSwSamples = _reshape_2d(c.FootSwSamples.to_numpy(), MAX_FSW_SENSORS_NUM, self.ScanNumber)
        self.FootSwRawSamples = _reshape_3d(c.FootSwRawSamples.to_numpy(), MAX_FSW_SENSORS_NUM, FSW_TRANSDUCERS_NUM, self.ScanNumber)
        self.FootSwSensorStates = c.FootSwSensorStates.to_numpy()

        # ----------------------------------------------------
        # Remote control
        # ----------------------------------------------------
        self.RemoteControlEvents = c.RemoteControlEvents.to_numpy()
        self.RemoteControlState = int(c.RemoteControlState)

        # ----------------------------------------------------
        # Triggers
        # ----------------------------------------------------
        self.StartTriggerDetected = bool(c.StartTriggerDetected)
        self.StopTriggerDetected = bool(c.StopTriggerDetected)
        self.StartTriggerScan = c.StartTriggerScan
        self.StopTriggerScan = c.StopTriggerScan

        self.StartInsoleTriggerDetected = bool(c.StartInsoleTriggerDetected)
        self.StopInsoleTriggerDetected = bool(c.StopInsoleTriggerDetected)
        self.StartInsoleTriggerScan = c.StartInsoleTriggerScan
        self.StopInsoleTriggerScan = c.StopInsoleTriggerScan

        self.StartInsoleImuTriggerDetected = bool(c.StartInsoleImuTriggerDetected)
        self.StopInsoleImuTriggerDetected = bool(c.StopInsoleImuTriggerDetected)
        self.StartInsoleImuTriggerScan = c.StartInsoleImuTriggerScan
        self.StopInsoleImuTriggerScan = c.StopInsoleImuTriggerScan

        self.StartAnalogTriggerDetected = bool(c.StartAnalogTriggerDetected)
        self.StopAnalogTriggerDetected = bool(c.StopAnalogTriggerDetected)
        self.StartAnalogTriggerScan = c.StartAnalogTriggerScan
        self.StopAnalogTriggerScan = c.StopAnalogTriggerScan

        # ----------------------------------------------------
        # Transport
        # ----------------------------------------------------
        self.DataTransferRate = c.DataTransferRate
        self.UsbLostPackets = c.UsbLostPackets
        self.UsbLowPerformance = bool(c.UsbLowPerformance)

        # ----------------------------------------------------
        # Insole
        # ----------------------------------------------------
        self.InsoleScanNumber = c.InsoleScanNumber
        self.InsoleSamples = _reshape_3d(c.InsoleSamples.to_numpy(), MAX_INSOLES_NUM, MAX_INSOLE_SENSORS_NUM, self.InsoleScanNumber)
        self.InsoleImuSamples = _reshape_3d(c.InsoleImuSamples.to_numpy(), MAX_INSOLES_NUM, IMU_DATA_DIM, self.InsoleScanNumber)
        self.InsoleAccelerometerSamples = _reshape_3d(c.InsoleAccelerometerSamples.to_numpy(), MAX_INSOLES_NUM, ACC_GYRO_MAG_AXES, self.InsoleScanNumber)
        self.InsoleGyroscopeSamples = _reshape_3d(c.InsoleGyroscopeSamples.to_numpy(), MAX_INSOLES_NUM, ACC_GYRO_MAG_AXES, self.InsoleScanNumber)
        self.InsoleStates = c.InsoleStates.to_numpy()

        # ----------------------------------------------------
        # Analog
        # ----------------------------------------------------
        self.AnalogScanNumber = c.AnalogScanNumber
        self.AnalogSamples = _reshape_2d(c.AnalogSamples.to_numpy(), MAX_ANALOG_CHANNELS_NUM, self.AnalogScanNumber)
        self.AnalogStates = c.AnalogStates.to_numpy()

        # ----------------------------------------------------
        # HDsEmg
        # ----------------------------------------------------
        #self.HDsEmgScanNumber = c.HDsEmgScanNumber
        #self.HDsEmgSamples = _reshape_3d(c.HDsEmgSamples.to_numpy(), MAX_HDsEMGs_NUM, MAX_HDsEMG_SENSORS_NUM, self.HDsEmgScanNumber)
        #self.HDsEmgStates = c.HDsEmgStates.to_numpy()



class CaptureConfiguration:
    def __init__(self):
        self._cfg = _lib.WaveX_CaptureConfig_Create()
        if not self._cfg:
            raise RuntimeError("WaveX_CaptureConfig_Create failed")

    def set_imu_acq_p(self, acq_type: int):
        _lib.WaveX_CaptureConfig_SetImuAcqPType(self._cfg, acq_type)

    def set_emg_acq_p(self, acq_type: int):
        _lib.WaveX_CaptureConfig_SetEmgAcqPType(self._cfg, acq_type)

    def set_imu_acq_x(self, acq_type: int):
        _lib.WaveX_CaptureConfig_SetImuAcqXType(self._cfg, acq_type)

    def set_emg_acq_x(self, acq_type: int):
        _lib.WaveX_CaptureConfig_SetEmgAcqXType(self._cfg, acq_type)

    def set_emg_imu_acq_x(self, acq_type: int):
        _lib.WaveX_CaptureConfig_SetEMG_IMU_AcqXType(self._cfg, acq_type)

    def set_imu_acq_b(self, acq_type: int):
        _lib.WaveX_CaptureConfig_SetImuAcqB(self._cfg, acq_type)

    def set_emg_acq_b(self, acq_type: int):
        _lib.WaveX_CaptureConfig_SetEmgAcqB(self._cfg, acq_type)

    def enable_insole(self, index: int, enabled: bool = True):
        _lib.WaveX_CaptureConfig_EnableInsole(
            self._cfg, index, int(enabled)
        )

    def set_insole_protocol(self, insole_protocol: int):
        _lib.WaveX_CaptureConfig_SetInsoleProtocol(
            self._cfg, insole_protocol
        )
    def set_insole_bt_acq(self, insole_bt_acq: int):
        _lib.WaveX_CaptureConfig_SetInsole_BtAcqType(
            self._cfg, insole_bt_acq
        )
    def set_insole_rf_acq(self, insole_rf_acq: int):
        _lib.WaveX_CaptureConfig_SetInsole_RfAcqType(
            self._cfg, insole_rf_acq
        )
    def set_insole_acc_fullscale(self, insole_acc_fullscale: int):
        _lib.WaveX_CaptureConfig_SetInsole_AccFullscale(
            self._cfg, insole_acc_fullscale
        )
    def set_insole_gyro_fullscale(self, insole_gyro_fullscale: int):
        _lib.WaveX_CaptureConfig_SetInsole_GyroFullscale(
            self._cfg, insole_gyro_fullscale
        )

    def enable_analog_channel(self, analog_channel: int, enabled: bool = True):
        _lib.WaveX_CaptureConfig_EnableAnalogChannel(
            self._cfg, analog_channel, int(enabled)
        )

    def set_analog_configuration(self, analogAcqType: int, analogTriggerMode: int, voltageFullScale:int, delayMs: int):
        _lib.WaveX_CaptureConfig_SetAnalogConfiguration(
            self._cfg, analogAcqType, analogTriggerMode, voltageFullScale, delayMs
        )

    def _destroy(self):
        if self._cfg:
            _lib.WaveX_CaptureConfig_Destroy(self._cfg)
            self._cfg = None


class SensorConfiguration:
    def __init__(self):
        self._cfg = _lib.WaveX_SensorConfig_Create()
        if not self._cfg:
            raise RuntimeError("WaveX_CaptureConfig_Create failed")

    def set_sensor_config(self, sensorModel: int, sensorMode: int, accelerometerFullScale: int, gyroscopeFullScale: int):
        _lib.WaveX_SensorConfig_Set(
            self._cfg, sensorModel, sensorMode, accelerometerFullScale, gyroscopeFullScale
        )
    def _destroy(self):
        if self._cfg:
            _lib.WaveX_SensorConfig_Destroy(self._cfg)
            self._cfg = None


# ============================================================
# Native API signatures
# ============================================================

_CALLBACK = WINFUNCTYPE(None, POINTER(_DataAvailableArgs_C), c_void_p)

_lib.WaveX_Create.restype = c_void_p
_lib.WaveX_Destroy.argtypes = [c_void_p]

_lib.WaveX_StartCapturing.argtypes = [c_void_p]
_lib.WaveX_StopCapturing.argtypes = [c_void_p]

_lib.WaveX_RegisterDataAvailableCallback.argtypes = [
    c_void_p,
    _CALLBACK,
    c_void_p,
]

_lib.WaveX_UnregisterDataAvailableCallback.argtypes = [
    c_void_p,
    _CALLBACK,
    c_void_p,
]

# ============================================================
# High-level API
# ============================================================

class WaveX:
    def __init__(self):
        self._handle = _lib.WaveX_Create()
        if not self._handle:
            raise RuntimeError("WaveX_Create failed")

        self._cb_native = None
        self._cb_user = None

    def StartCapturing(self):
        _lib.WaveX_StartCapturing(self._handle)

    def StopCapturing(self):
        _lib.WaveX_StopCapturing(self._handle)

    def close(self):
        if self._cb_native:
            _lib.WaveX_UnregisterDataAvailableCallback(
                self._handle, self._cb_native, None
            )
            self._cb_native = None
        _lib.WaveX_Destroy(self._handle)
        self._handle = None

    def OnDataAvailable(self, callback):
        self._cb_user = callback

        def _thunk(c_args_ptr, _):
            evt = DataAvailableEvent(c_args_ptr.contents)
            callback(evt)

        self._cb_native = _CALLBACK(_thunk)

        _lib.WaveX_RegisterDataAvailableCallback(
            self._handle, self._cb_native, None
        )

    def ConfigureCapture(self, cfg: CaptureConfiguration):
        ok = _lib.WaveX_ConfigureCapture(
            self._handle, cfg._cfg
        )
        if not ok:
            raise RuntimeError("WaveX_ConfigureCapture failed")

    def ConfigureSensor(self, cfg: SensorConfiguration, sensorIndex: int):
        ok = _lib.WaveX_ConfigureSensor(
            self._handle, cfg._cfg, sensorIndex
        )
        if not ok:
            raise RuntimeError("WaveX_ConfigureSensor failed")

    def CalibrateImu(self, sensorIndex: int):
        _lib.WaveX_CalibrateImuOffset(self._handle,sensorIndex )

    def CalibrateGyroscope(self, sensorIndex: int):
        _lib.WaveX_CalibrateGyroscopeOffset(self._handle, sensorIndex )

    def CalibrateAccelerometer(self, sensorIndex: int):
        _lib.WaveX_CalibrateAccelerometerOffset(self._handle, sensorIndex)

    def CalibrateEMG(self, sensorIndex: int):
        _lib.WaveX_CalibrateEMGOffset(self._handle, sensorIndex)

    def UpdateDisplay(self):
        _lib.WaveX_UpdateDisplay(self._handle)

    def SaveCurrentConfiguration(self):
        _lib.WaveX_SaveCurrentRxConfiguration(self._handle)

    def GetDeviceState(self):
        _lib.WaveX_GetDeviceState(self._handle)
