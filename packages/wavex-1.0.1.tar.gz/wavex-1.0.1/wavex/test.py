import time
from enum import EnumDict
from logging import exception

import wavex

from wavex import *

import enums


def on_data(args):
    print(args.ScanNumber, args.EmgSamples.shape, args.StartTriggerDetected)
    print(args.EmgSamples[1,0])

daqSystem = wavex.DaqSystem()

cfg = CaptureConfiguration()
cfg.set_imu_acq_p(enums.ImuAcqPType.RawAccGyroMagData_284Hz)     # RawAccGyroMagData_284Hz
cfg.set_emg_acq_x(enums.EmgAcqXType.Emg_2kHz)     # Emg_2kHz_Acc_142Hz
cfg.enable_insole(enums.ChannelSide.Right, True)
cfg.enable_analog_channel(3)
cfg.set_emg_imu_acq_x(enums.EmgImuAcqXType.Emg_2kHz_RawAccGyroData_200Hz)

s_cfg = SensorConfiguration()
s_cfg.set_sensor_config(enums.SensorModel.Imu, enums.SensorMode.INERTIAL_SENSOR, enums.AccelerometerFullScale.g_16, enums.GyroscopeFullScale.dps_2000)
for i in range(6):
    daqSystem.ConfigureSensor(s_cfg, i+1)

daqSystem.OnDataAvailable(on_data)
daqSystem.ConfigureCapture(cfg)
daqSystem.UpdateDisplay()
daqSystem.SaveCurrentConfiguration()
time.sleep(1)
daqSystem.StartCapturing()
time.sleep(5)
daqSystem.CalibrateImu(1)
time.sleep(5)
daqSystem.StopCapturing()

