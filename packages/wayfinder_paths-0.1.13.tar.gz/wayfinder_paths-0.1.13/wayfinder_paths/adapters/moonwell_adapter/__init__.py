"""
Moonwell Adapter
"""

from wayfinder_paths.adapters.moonwell_adapter.adapter import MoonwellAdapter

__all__ = ["MoonwellAdapter"]
