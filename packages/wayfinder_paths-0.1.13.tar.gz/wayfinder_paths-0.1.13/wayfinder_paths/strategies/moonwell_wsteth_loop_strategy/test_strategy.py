"""Test template for Moonwell wstETH Loop Strategy."""

from pathlib import Path
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from wayfinder_paths.strategies.moonwell_wsteth_loop_strategy.strategy import (
    ETH_TOKEN_ID,
    M_USDC,
    M_WETH,
    M_WSTETH,
    USDC_TOKEN_ID,
    WETH,
    WETH_TOKEN_ID,
    WSTETH_TOKEN_ID,
    MoonwellWstethLoopStrategy,
    SwapOutcomeUnknownError,
)
from wayfinder_paths.tests.test_utils import (
    get_canonical_examples,
    load_strategy_examples,
)


@pytest.fixture
def strategy():
    """Create a strategy instance for testing with minimal config."""
    mock_config = {
        "main_wallet": {"address": "0x1234567890123456789012345678901234567890"},
        "strategy_wallet": {"address": "0xabcdefabcdefabcdefabcdefabcdefabcdefabcd"},
    }

    # Patch the initialization to avoid real adapter/web3 setup
    with patch.object(
        MoonwellWstethLoopStrategy, "__init__", lambda self, **kwargs: None
    ):
        s = MoonwellWstethLoopStrategy(
            config=mock_config,
            main_wallet=mock_config["main_wallet"],
            strategy_wallet=mock_config["strategy_wallet"],
            simulation=True,
        )
        # Manually set attributes that would be set in __init__
        s.config = mock_config
        s.simulation = True
        s._token_info_cache = {}
        s._token_price_cache = {}
        s._token_price_timestamps = {}

        # Mock adapters
        s.balance_adapter = MagicMock()
        s.moonwell_adapter = MagicMock()
        s.brap_adapter = MagicMock()
        s.token_adapter = MagicMock()
        s.ledger_adapter = MagicMock()
        s.ledger_adapter.record_strategy_snapshot = AsyncMock(return_value=None)

        return s


@pytest.fixture
def mock_adapter_responses(strategy):
    """Set up mock responses for adapter calls."""
    # Mock balance adapter
    strategy.balance_adapter.get_balance = AsyncMock(return_value=(True, 1000000))
    strategy.balance_adapter.move_from_main_wallet_to_strategy_wallet = AsyncMock(
        return_value=(True, "success")
    )
    strategy.balance_adapter.move_from_strategy_wallet_to_main_wallet = AsyncMock(
        return_value=(True, "success")
    )

    # Mock token adapter
    strategy.token_adapter.get_token = AsyncMock(
        return_value=(True, {"decimals": 18, "symbol": "TEST"})
    )
    strategy.token_adapter.get_token_price = AsyncMock(
        return_value=(True, {"current_price": 1.0})
    )

    # Mock moonwell adapter
    strategy.moonwell_adapter.get_pos = AsyncMock(
        return_value=(
            True,
            {
                "mtoken_balance": 1000000000000000000,
                "underlying_balance": 1000000000000000000,
                "borrow_balance": 0,
                "exchange_rate": 1000000000000000000,
            },
        )
    )
    strategy.moonwell_adapter.get_collateral_factor = AsyncMock(
        return_value=(True, 0.8)
    )
    strategy.moonwell_adapter.get_apy = AsyncMock(return_value=(True, 0.05))
    strategy.moonwell_adapter.get_borrowable_amount = AsyncMock(
        return_value=(True, 1000.0)
    )
    strategy.moonwell_adapter.max_withdrawable_mtoken = AsyncMock(
        return_value=(True, {"cTokens_raw": 1000000, "underlying_raw": 1000000})
    )
    strategy.moonwell_adapter.lend = AsyncMock(return_value=(True, "success"))
    strategy.moonwell_adapter.unlend = AsyncMock(return_value=(True, "success"))
    strategy.moonwell_adapter.borrow = AsyncMock(return_value=(True, "success"))
    strategy.moonwell_adapter.repay = AsyncMock(return_value=(True, "success"))
    strategy.moonwell_adapter.set_collateral = AsyncMock(return_value=(True, "success"))
    strategy.moonwell_adapter.claim_rewards = AsyncMock(return_value={})

    # Mock brap adapter
    strategy.brap_adapter.swap_from_token_ids = AsyncMock(
        return_value=(True, {"to_amount": 1000000000000000000})
    )

    return strategy


@pytest.mark.asyncio
@pytest.mark.smoke
async def test_smoke(strategy, mock_adapter_responses):
    """REQUIRED: Basic smoke test - verifies strategy lifecycle."""
    examples = load_strategy_examples(Path(__file__))
    smoke_data = examples["smoke"]

    # Mock quote to return positive APY
    with patch.object(strategy, "quote", new_callable=AsyncMock) as mock_quote:
        mock_quote.return_value = {"apy": 0.1, "data": {}}

        # Status test
        with patch.object(strategy, "_status", new_callable=AsyncMock) as mock_status:
            mock_status.return_value = {
                "portfolio_value": 0.0,
                "net_deposit": 0.0,
                "strategy_status": {},
                "gas_available": 0.1,
                "gassed_up": True,
            }
            st = await strategy.status()
            assert isinstance(st, dict)
            assert (
                "portfolio_value" in st
                or "net_deposit" in st
                or "strategy_status" in st
            )

        # Deposit test
        deposit_params = smoke_data.get("deposit", {})
        with patch.object(strategy, "deposit", new_callable=AsyncMock) as mock_deposit:
            mock_deposit.return_value = (True, "success")
            ok, msg = await strategy.deposit(**deposit_params)
            assert isinstance(ok, bool)
            assert isinstance(msg, str)

        # Update test
        with patch.object(strategy, "update", new_callable=AsyncMock) as mock_update:
            mock_update.return_value = (True, "success")
            ok, msg = await strategy.update(**smoke_data.get("update", {}))
            assert isinstance(ok, bool)

        # Withdraw test
        with patch.object(
            strategy, "withdraw", new_callable=AsyncMock
        ) as mock_withdraw:
            mock_withdraw.return_value = (True, "success")
            ok, msg = await strategy.withdraw(**smoke_data.get("withdraw", {}))
            assert isinstance(ok, bool)


@pytest.mark.asyncio
async def test_canonical_usage(strategy, mock_adapter_responses):
    """REQUIRED: Test canonical usage examples from examples.json (minimum)."""
    examples = load_strategy_examples(Path(__file__))
    canonical = get_canonical_examples(examples)

    for example_name, example_data in canonical.items():
        # Mock methods for canonical usage tests
        with patch.object(strategy, "quote", new_callable=AsyncMock) as mock_quote:
            mock_quote.return_value = {"apy": 0.1, "data": {}}

            if "deposit" in example_data:
                deposit_params = example_data.get("deposit", {})
                with patch.object(
                    strategy, "deposit", new_callable=AsyncMock
                ) as mock_deposit:
                    mock_deposit.return_value = (True, "success")
                    ok, _ = await strategy.deposit(**deposit_params)
                    assert ok, f"Canonical example '{example_name}' deposit failed"

            if "update" in example_data:
                with patch.object(
                    strategy, "update", new_callable=AsyncMock
                ) as mock_update:
                    mock_update.return_value = (True, "success")
                    ok, msg = await strategy.update()
                    assert ok, (
                        f"Canonical example '{example_name}' update failed: {msg}"
                    )

            if "status" in example_data:
                with patch.object(
                    strategy, "_status", new_callable=AsyncMock
                ) as mock_status:
                    mock_status.return_value = {
                        "portfolio_value": 0.0,
                        "net_deposit": 0.0,
                        "strategy_status": {},
                        "gas_available": 0.1,
                        "gassed_up": True,
                    }
                    st = await strategy.status()
                    assert isinstance(st, dict), (
                        f"Canonical example '{example_name}' status failed"
                    )


@pytest.mark.asyncio
async def test_status_returns_status_dict(strategy, mock_adapter_responses):
    """Test that _status returns a proper StatusDict."""
    with patch.object(
        strategy, "_aggregate_positions", new_callable=AsyncMock
    ) as mock_pos:
        mock_pos.return_value = ({}, {})
        with patch.object(strategy, "compute_ltv", new_callable=AsyncMock) as mock_ltv:
            mock_ltv.return_value = 0.5
            with patch.object(
                strategy, "_get_gas_balance", new_callable=AsyncMock
            ) as mock_gas:
                mock_gas.return_value = 100000000000000000  # 0.1 ETH
                with patch.object(
                    strategy, "get_peg_diff", new_callable=AsyncMock
                ) as mock_peg:
                    mock_peg.return_value = 0.001
                    with patch.object(
                        strategy, "quote", new_callable=AsyncMock
                    ) as mock_quote:
                        mock_quote.return_value = {"apy": 0.1, "data": {}}

                        status = await strategy._status()

                        assert "portfolio_value" in status
                        assert "net_deposit" in status
                        assert "strategy_status" in status
                        assert "gas_available" in status
                        assert "gassed_up" in status


@pytest.mark.asyncio
async def test_policies_returns_list(strategy):
    """Test that policies returns a non-empty list."""
    # Mock the policy functions to avoid ABI fetching
    with (
        patch(
            "wayfinder_paths.strategies.moonwell_wsteth_loop_strategy.strategy.musdc_mint_or_approve_or_redeem",
            new_callable=AsyncMock,
            return_value="mock_musdc_policy",
        ),
        patch(
            "wayfinder_paths.strategies.moonwell_wsteth_loop_strategy.strategy.mweth_approve_or_borrow_or_repay",
            new_callable=AsyncMock,
            return_value="mock_mweth_policy",
        ),
        patch(
            "wayfinder_paths.strategies.moonwell_wsteth_loop_strategy.strategy.mwsteth_approve_or_mint_or_redeem",
            new_callable=AsyncMock,
            return_value="mock_mwsteth_policy",
        ),
        patch(
            "wayfinder_paths.strategies.moonwell_wsteth_loop_strategy.strategy.moonwell_comptroller_enter_markets_or_claim_rewards",
            new_callable=AsyncMock,
            return_value="mock_comptroller_policy",
        ),
        patch(
            "wayfinder_paths.strategies.moonwell_wsteth_loop_strategy.strategy.weth_deposit",
            new_callable=AsyncMock,
            return_value="mock_weth_deposit_policy",
        ),
        patch(
            "wayfinder_paths.strategies.moonwell_wsteth_loop_strategy.strategy.enso_swap",
            new_callable=AsyncMock,
            return_value="mock_enso_swap_policy",
        ),
    ):
        policies = await strategy.policies()
        assert isinstance(policies, list)
        assert len(policies) > 0


@pytest.mark.asyncio
async def test_quote_returns_apy_info(strategy, mock_adapter_responses):
    """Test that quote returns APY information."""
    with patch("httpx.AsyncClient") as mock_client:
        mock_response = MagicMock()
        mock_response.json.return_value = {"data": {"smaApr": 3.5}}
        mock_client.return_value.__aenter__.return_value.get = AsyncMock(
            return_value=mock_response
        )

        quote = await strategy.quote()

        assert "apy" in quote
        assert "information" in quote or "data" in quote


# Tests for new safety methods


def test_max_safe_f_calculates_correctly(strategy):
    """Test that _max_safe_F calculates the depeg-aware leverage limit correctly."""
    # Set up strategy with MAX_DEPEG = 0.01 (1%)
    strategy.MAX_DEPEG = 0.01

    # With cf_w = 0.8, a = 0.99
    # F_max = 1 / (1 + 0.8 * (1 - 0.99)) = 1 / (1 + 0.8 * 0.01) = 1 / 1.008 ≈ 0.992
    result = strategy._max_safe_F(0.8)
    expected = 1 / (1 + 0.8 * 0.01)
    assert abs(result - expected) < 0.001


def test_max_safe_f_with_zero_collateral_factor(strategy):
    """Test _max_safe_F with zero collateral factor."""
    strategy.MAX_DEPEG = 0.01
    result = strategy._max_safe_F(0.0)
    # F_max = 1 / (1 + 0 * anything) = 1.0
    assert result == 1.0


@pytest.mark.asyncio
async def test_swap_with_retries_succeeds_first_attempt(
    strategy, mock_adapter_responses
):
    """Test that _swap_with_retries succeeds on first attempt."""
    strategy.max_swap_retries = 3
    strategy.swap_slippage_tolerance = 0.005

    result = await strategy._swap_with_retries(
        from_token_id="usd-coin-base",
        to_token_id="l2-standard-bridged-weth-base-base",
        amount=1000000,
    )

    assert result is not None
    assert "to_amount" in result
    strategy.brap_adapter.swap_from_token_ids.assert_called_once()


@pytest.mark.asyncio
async def test_swap_with_retries_succeeds_on_second_attempt(
    strategy, mock_adapter_responses
):
    """Test that _swap_with_retries retries and succeeds."""
    strategy.max_swap_retries = 3
    strategy.swap_slippage_tolerance = 0.005

    # First call fails, second succeeds
    strategy.brap_adapter.swap_from_token_ids = AsyncMock(
        side_effect=[
            Exception("First attempt failed"),
            (True, {"to_amount": 1000000}),
        ]
    )

    with patch("asyncio.sleep", new_callable=AsyncMock):  # Speed up test
        result = await strategy._swap_with_retries(
            from_token_id="usd-coin-base",
            to_token_id="l2-standard-bridged-weth-base-base",
            amount=1000000,
        )

    assert result is not None
    assert result["to_amount"] == 1000000
    assert strategy.brap_adapter.swap_from_token_ids.call_count == 2


@pytest.mark.asyncio
async def test_swap_with_retries_fails_all_attempts(strategy, mock_adapter_responses):
    """Test that _swap_with_retries returns None after all attempts fail."""
    strategy.max_swap_retries = 3
    strategy.swap_slippage_tolerance = 0.005

    strategy.brap_adapter.swap_from_token_ids = AsyncMock(
        side_effect=Exception("Swap failed")
    )

    with patch("asyncio.sleep", new_callable=AsyncMock):
        result = await strategy._swap_with_retries(
            from_token_id="usd-coin-base",
            to_token_id="l2-standard-bridged-weth-base-base",
            amount=1000000,
        )

    assert result is None
    assert strategy.brap_adapter.swap_from_token_ids.call_count == 3


@pytest.mark.asyncio
async def test_swap_with_retries_aborts_on_unknown_outcome(
    strategy, mock_adapter_responses
):
    """Swap retries must abort (no retry) when the transaction outcome is unknown."""
    strategy.max_swap_retries = 3
    strategy.brap_adapter.swap_from_token_ids = AsyncMock(
        return_value=(
            False,
            "Transaction HexBytes('0xdeadbeef') is not in the chain after 120 seconds",
        )
    )

    with pytest.raises(SwapOutcomeUnknownError):
        await strategy._swap_with_retries(
            from_token_id=USDC_TOKEN_ID,
            to_token_id=WETH_TOKEN_ID,
            amount=1000000,
        )

    assert strategy.brap_adapter.swap_from_token_ids.call_count == 1


@pytest.mark.asyncio
async def test_balance_weth_debt_no_action_when_balanced(
    strategy, mock_adapter_responses
):
    """Test that _balance_weth_debt does nothing when debt is balanced."""
    # Mock wstETH position: 2 ETH worth
    strategy.moonwell_adapter.get_pos = AsyncMock(
        side_effect=[
            (True, {"underlying_balance": 2 * 10**18, "borrow_balance": 0}),  # wstETH
            (
                True,
                {"underlying_balance": 0, "borrow_balance": 1 * 10**18},
            ),  # WETH debt
        ]
    )

    # Mock prices: wstETH = $2000, WETH = $2000 (so 2 wstETH > 1 WETH debt)
    strategy.token_adapter.get_token_price = AsyncMock(
        return_value=(True, {"current_price": 2000.0})
    )

    success, msg = await strategy._balance_weth_debt()

    assert success is True
    assert "balanced" in msg.lower()


@pytest.mark.asyncio
async def test_balance_weth_debt_rebalances_when_excess_debt(
    strategy, mock_adapter_responses
):
    """Test that _balance_weth_debt attempts to rebalance when debt exceeds collateral."""
    # Mock positions: wstETH value < WETH debt
    strategy.moonwell_adapter.get_pos = AsyncMock(
        side_effect=[
            (True, {"underlying_balance": 1 * 10**18}),  # 1 wstETH
            (True, {"borrow_balance": 2 * 10**18}),  # 2 WETH debt (excess)
        ]
    )

    # Mock prices
    strategy.token_adapter.get_token_price = AsyncMock(
        return_value=(True, {"current_price": 2000.0})
    )

    # Mock wallet balances (has WETH to repay)
    strategy.balance_adapter.get_balance = AsyncMock(
        side_effect=[
            (True, 1 * 10**18),  # WETH balance
            (True, 0),  # ETH balance
        ]
    )

    strategy.MIN_GAS = 0.005

    success, msg = await strategy._balance_weth_debt()

    # Should have attempted repayment
    strategy.moonwell_adapter.repay.assert_called()


@pytest.mark.asyncio
async def test_balance_weth_debt_rebalances_when_no_wsteth_position(
    strategy, mock_adapter_responses
):
    """Test that _balance_weth_debt still rebalances when wstETH position fetch fails."""
    strategy.moonwell_adapter.get_pos = AsyncMock(
        side_effect=[
            (False, "rpc error"),  # wstETH (treat as 0)
            (True, {"borrow_balance": 2 * 10**18}),  # WETH debt
        ]
    )

    strategy.token_adapter.get_token_price = AsyncMock(
        return_value=(True, {"current_price": 2000.0})
    )

    strategy.balance_adapter.get_balance = AsyncMock(
        side_effect=[
            (True, 2 * 10**18),  # WETH balance (enough to repay)
        ]
    )

    success, msg = await strategy._balance_weth_debt()

    assert success is True
    assert "balanced" in msg.lower()
    strategy.moonwell_adapter.repay.assert_called()


@pytest.mark.asyncio
async def test_atomic_deposit_iteration_swaps_from_eth_when_borrow_surfaces_as_eth(
    strategy, mock_adapter_responses
):
    """Borrowed WETH can surface as native ETH; iteration should wrap ETH→WETH then swap WETH→wstETH."""
    # Ensure gas reserve exists so we don't drain to 0
    strategy.WRAP_GAS_RESERVE = 0.0014

    borrow_amt_wei = 10**18
    safe_borrow = int(borrow_amt_wei * 0.98)

    balances: dict[str, int] = {
        ETH_TOKEN_ID: 2 * 10**18,
        WETH_TOKEN_ID: 0,
        WSTETH_TOKEN_ID: 0,
    }

    async def get_balance_side_effect(*, token_id: str, wallet_address: str, **_):
        return (True, balances.get(token_id, 0))

    strategy.balance_adapter.get_balance = AsyncMock(
        side_effect=get_balance_side_effect
    )

    async def borrow_side_effect(*, mtoken: str, amount: int):
        # Borrow shows up as native ETH (simulates on-chain behavior)
        assert mtoken == M_WETH
        balances[ETH_TOKEN_ID] += int(amount)
        return (True, {"block_number": 12345})

    strategy.moonwell_adapter.borrow = AsyncMock(side_effect=borrow_side_effect)

    async def wrap_eth_side_effect(*, amount: int):
        # Wrap ETH to WETH
        balances[ETH_TOKEN_ID] -= int(amount)
        balances[WETH_TOKEN_ID] += int(amount)
        return (True, {"block_number": 12346})

    strategy.moonwell_adapter.wrap_eth = AsyncMock(side_effect=wrap_eth_side_effect)

    async def swap_side_effect(
        *, from_token_id: str, to_token_id: str, amount: int, **_
    ):
        # After wrapping, the swap should be WETH→wstETH
        assert from_token_id == WETH_TOKEN_ID
        assert to_token_id == WSTETH_TOKEN_ID
        # Simulate receiving wstETH
        balances[WSTETH_TOKEN_ID] += 123
        return {"to_amount": 123}

    strategy._swap_with_retries = AsyncMock(side_effect=swap_side_effect)

    lent = await strategy._atomic_deposit_iteration(borrow_amt_wei)

    assert lent == 123
    strategy.moonwell_adapter.borrow.assert_called_once_with(
        mtoken=M_WETH, amount=safe_borrow
    )
    strategy.moonwell_adapter.wrap_eth.assert_called_once()
    strategy._swap_with_retries.assert_called_once()


@pytest.mark.asyncio
async def test_complete_unpaired_weth_borrow_uses_eth_inventory(
    strategy, mock_adapter_responses
):
    """If debt exists but wstETH collateral is missing, use wallet ETH to complete the loop."""
    # wstETH pos is empty; WETH debt exists
    strategy.moonwell_adapter.get_pos = AsyncMock(
        side_effect=[
            (True, {"underlying_balance": 0}),  # mwstETH
            (True, {"borrow_balance": 5 * 10**18}),  # mWETH debt
        ]
    )

    balances: dict[str, int] = {
        ETH_TOKEN_ID: 10 * 10**18,
        WETH_TOKEN_ID: 0,
        WSTETH_TOKEN_ID: 0,
    }

    async def get_balance_side_effect(*, token_id: str, wallet_address: str):
        return (True, balances.get(token_id, 0))

    strategy.balance_adapter.get_balance = AsyncMock(
        side_effect=get_balance_side_effect
    )

    async def swap_side_effect(
        *, from_token_id: str, to_token_id: str, amount: int, **_
    ):
        assert from_token_id == ETH_TOKEN_ID
        assert to_token_id == WSTETH_TOKEN_ID
        balances[WSTETH_TOKEN_ID] += 7 * 10**18
        return {"to_amount": 7 * 10**18}

    strategy._swap_with_retries = AsyncMock(side_effect=swap_side_effect)

    success, msg = await strategy._complete_unpaired_weth_borrow()

    assert success is True
    assert "completed unpaired borrow" in msg.lower()
    strategy.moonwell_adapter.lend.assert_called()


@pytest.mark.asyncio
async def test_sweep_token_balances_no_tokens(strategy, mock_adapter_responses):
    """Test that _sweep_token_balances handles empty wallet."""
    # All balances are 0
    strategy.balance_adapter.get_balance = AsyncMock(return_value=(True, 0))

    success, msg = await strategy._sweep_token_balances(
        target_token_id="usd-coin-base",
    )

    assert success is True
    assert "no tokens" in msg.lower()


@pytest.mark.asyncio
async def test_sweep_token_balances_sweeps_tokens(strategy, mock_adapter_responses):
    """Test that _sweep_token_balances converts dust tokens."""
    strategy.min_withdraw_usd = 1.0

    # Mock balance returns (has some WETH dust)
    def balance_side_effect(token_id, wallet_address):
        if "weth" in token_id.lower():
            return (True, 100 * 10**18)  # 100 WETH
        return (True, 0)

    strategy.balance_adapter.get_balance = AsyncMock(side_effect=balance_side_effect)

    # Mock price (high enough to trigger sweep)
    strategy.token_adapter.get_token_price = AsyncMock(
        return_value=(True, {"current_price": 2000.0})
    )

    success, msg = await strategy._sweep_token_balances(
        target_token_id="usd-coin-base",
        exclude=set(),
    )

    assert success is True
    # Should have called swap
    strategy.brap_adapter.swap_from_token_ids.assert_called()


# Tests for code review fixes


@pytest.mark.asyncio
async def test_deposit_rejects_zero_amount(strategy):
    """Test that deposit rejects zero or negative amounts."""
    result = await strategy.deposit(main_token_amount=0.0)
    assert result[0] is False
    assert "positive" in result[1].lower()

    result = await strategy.deposit(main_token_amount=-10.0)
    assert result[0] is False
    assert "positive" in result[1].lower()


def test_slippage_capped_at_max(strategy):
    """Test that slippage is capped at MAX_SLIPPAGE_TOLERANCE."""
    strategy.MAX_SLIPPAGE_TOLERANCE = 0.03
    strategy.swap_slippage_tolerance = 0.02

    # With 3 retries at 2% base: 2%, 4%, 6% -> should be capped at 3%
    # The actual slippage calculation happens in the method, we just verify the constant exists
    assert hasattr(strategy, "MAX_SLIPPAGE_TOLERANCE")
    assert strategy.MAX_SLIPPAGE_TOLERANCE == 0.03


def test_price_staleness_threshold_exists(strategy):
    """Test that price staleness threshold is configured."""
    assert hasattr(strategy, "PRICE_STALENESS_THRESHOLD")
    assert strategy.PRICE_STALENESS_THRESHOLD > 0


def test_min_leverage_gain_constant_exists(strategy):
    """Test that minimum leverage gain constant is configured."""
    assert hasattr(strategy, "_MIN_LEVERAGE_GAIN_BPS")
    assert strategy._MIN_LEVERAGE_GAIN_BPS == 50e-4  # 50 bps


@pytest.mark.asyncio
async def test_leverage_calc_handles_high_cf_w(strategy, mock_adapter_responses):
    """Test that leverage calculation handles high collateral factors safely."""
    strategy.MIN_HEALTH_FACTOR = 1.2

    # This should return early without crashing when cf_w >= MIN_HEALTH_FACTOR
    # Pass collateral_factors directly to avoid RPC call ordering issues
    # collateral_factors = (cf_usdc, cf_wsteth)
    result = await strategy._loop_wsteth(
        wsteth_price=2000.0,
        weth_price=2000.0,
        current_borrowed_value=1000.0,
        initial_leverage=1.5,
        usdc_lend_value=1000.0,
        wsteth_lend_value=500.0,
        collateral_factors=(0.8, 1.3),  # cf_u=0.8, cf_w=1.3 (higher than MIN_HF)
    )

    # Should return failure tuple instead of crashing
    assert result[0] is False
    assert result[2] == -1  # Error code


@pytest.mark.asyncio
async def test_price_staleness_triggers_refresh(strategy, mock_adapter_responses):
    """Test that stale prices trigger a refresh."""
    strategy.PRICE_STALENESS_THRESHOLD = 1  # 1 second for test
    strategy._token_price_cache = {"test-token": 100.0}
    strategy._token_price_timestamps = {"test-token": 0}  # Very old timestamp

    # Should refresh because timestamp is stale
    await strategy._get_token_price("test-token")

    # Should have called token adapter because cache was stale
    strategy.token_adapter.get_token_price.assert_called_with("test-token")


@pytest.mark.asyncio
async def test_partial_liquidate_prefers_wsteth_when_excess(strategy):
    """Partial liquidation should redeem wstETH first when collateral exceeds debt."""

    # Token metadata
    async def mock_get_token(token_id: str):
        if token_id == USDC_TOKEN_ID:
            return (True, {"decimals": 6})
        if token_id == WSTETH_TOKEN_ID:
            return (True, {"decimals": 18})
        return (True, {"decimals": 18})

    async def mock_get_price(token_id: str):
        if token_id == WSTETH_TOKEN_ID:
            return (True, {"current_price": 2000.0})
        return (True, {"current_price": 1.0})

    strategy.token_adapter.get_token = AsyncMock(side_effect=mock_get_token)
    strategy.token_adapter.get_token_price = AsyncMock(side_effect=mock_get_price)

    # Wallet balances (raw)
    balances: dict[str, int] = {USDC_TOKEN_ID: 0, WSTETH_TOKEN_ID: 0}

    async def mock_get_balance(*, token_id: str, wallet_address: str):
        return (True, balances.get(token_id, 0))

    strategy.balance_adapter.get_balance = AsyncMock(side_effect=mock_get_balance)

    # Position snapshot: wstETH collateral > WETH debt
    totals_usd = {
        f"Base_{M_WSTETH}": 500.0,
        f"Base_{M_USDC}": 1000.0,
        f"Base_{WETH}": -200.0,
    }
    strategy._aggregate_positions = AsyncMock(return_value=({}, totals_usd))

    # Collateral factors
    strategy.moonwell_adapter.get_collateral_factor = AsyncMock(
        return_value=(True, 0.8)
    )

    # mwstETH redemption metadata (1:1 exchange rate for test)
    async def mock_max_withdrawable(*, mtoken: str):
        return (
            True,
            {
                "cTokens_raw": 10**30,
                "exchangeRate_raw": 10**18,
                "conversion_factor": 1.0,
            },
        )

    strategy.moonwell_adapter.max_withdrawable_mtoken = AsyncMock(
        side_effect=mock_max_withdrawable
    )

    async def mock_unlend(*, mtoken: str, amount: int):
        if mtoken == M_WSTETH:
            balances[WSTETH_TOKEN_ID] += int(amount)
        return (True, "success")

    strategy.moonwell_adapter.unlend = AsyncMock(side_effect=mock_unlend)

    async def mock_swap(
        from_token_id,
        to_token_id,
        from_address,
        amount,
        slippage=0.0,
        strategy_name=None,
        **_,
    ):
        amt = int(amount)
        # wstETH → USDC
        balances[WSTETH_TOKEN_ID] -= amt
        usd_out = (amt / 10**18) * 2000.0
        usdc_out = int(usd_out * 10**6)
        balances[USDC_TOKEN_ID] += usdc_out
        return (True, {"to_amount": usdc_out})

    strategy.brap_adapter.swap_from_token_ids = AsyncMock(side_effect=mock_swap)

    # Also need to mock lend since partial_liquidate may try to re-lend leftover wstETH
    strategy.moonwell_adapter.lend = AsyncMock(return_value=(True, "success"))

    ok, msg = await strategy.partial_liquidate(usd_value=100.0)
    assert ok
    assert "available" in msg.lower()

    # Should have redeemed mwstETH and swapped to USDC
    assert strategy.moonwell_adapter.unlend.call_count == 1
    assert strategy.moonwell_adapter.unlend.call_args.kwargs["mtoken"] == M_WSTETH
    assert strategy.brap_adapter.swap_from_token_ids.call_count >= 1


@pytest.mark.asyncio
async def test_partial_liquidate_uses_usdc_collateral_when_no_wsteth_excess(strategy):
    """If wstETH collateral doesn't exceed debt, partial liquidation should redeem USDC collateral."""
    # Token metadata
    strategy.token_adapter.get_token = AsyncMock(
        side_effect=lambda token_id: (
            True,
            {"decimals": 6} if token_id == USDC_TOKEN_ID else {"decimals": 18},
        )
    )
    strategy.token_adapter.get_token_price = AsyncMock(
        return_value=(True, {"current_price": 1.0})
    )

    balances: dict[str, int] = {USDC_TOKEN_ID: 0}

    async def mock_get_balance(*, token_id: str, wallet_address: str):
        return (True, balances.get(token_id, 0))

    strategy.balance_adapter.get_balance = AsyncMock(side_effect=mock_get_balance)

    totals_usd = {
        f"Base_{M_WSTETH}": 100.0,  # <= debt
        f"Base_{M_USDC}": 500.0,
        f"Base_{WETH}": -200.0,
    }
    strategy._aggregate_positions = AsyncMock(return_value=({}, totals_usd))

    strategy.moonwell_adapter.get_collateral_factor = AsyncMock(
        return_value=(True, 0.8)
    )

    async def mock_max_withdrawable(*, mtoken: str):
        return (
            True,
            {
                "cTokens_raw": 10**30,
                "exchangeRate_raw": 10**18,
                "conversion_factor": 1.0,
            },
        )

    strategy.moonwell_adapter.max_withdrawable_mtoken = AsyncMock(
        side_effect=mock_max_withdrawable
    )

    async def mock_unlend(*, mtoken: str, amount: int):
        if mtoken == M_USDC:
            balances[USDC_TOKEN_ID] += int(amount)
        return (True, "success")

    strategy.moonwell_adapter.unlend = AsyncMock(side_effect=mock_unlend)

    ok, msg = await strategy.partial_liquidate(usd_value=50.0)
    assert ok
    assert "available" in msg.lower()

    # Should redeem mUSDC and not need a swap
    assert strategy.moonwell_adapter.unlend.call_count == 1
    assert strategy.moonwell_adapter.unlend.call_args.kwargs["mtoken"] == M_USDC
    assert not strategy.brap_adapter.swap_from_token_ids.called
