"""Utility helpers for local functionality not tied to external APIs."""
