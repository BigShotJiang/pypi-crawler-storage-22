"""Wayfinder Paths MCP server (FastMCP).

Run locally (via Claude Code .mcp.json):
  poetry run python -m wayfinder_paths.mcp.server
"""

from __future__ import annotations

import asyncio

from mcp.server.fastmcp import FastMCP

from wayfinder_paths.mcp.tools.balances import balances
from wayfinder_paths.mcp.tools.discovery import describe, discover
from wayfinder_paths.mcp.tools.execute import execute
from wayfinder_paths.mcp.tools.hyperliquid import hyperliquid, hyperliquid_execute
from wayfinder_paths.mcp.tools.quotes import quote_swap
from wayfinder_paths.mcp.tools.run_script import run_script
from wayfinder_paths.mcp.tools.strategies import run_strategy
from wayfinder_paths.mcp.tools.tokens import tokens
from wayfinder_paths.mcp.tools.wallets import wallets

mcp = FastMCP("wayfinder")

mcp.tool()(discover)
mcp.tool()(describe)
mcp.tool()(wallets)
mcp.tool()(tokens)
mcp.tool()(balances)
mcp.tool()(quote_swap)
mcp.tool()(hyperliquid)
mcp.tool()(hyperliquid_execute)
mcp.tool()(run_strategy)
mcp.tool()(run_script)
mcp.tool()(execute)


def main() -> None:
    # FastMCP is sync, but our tools are async; the library handles that.
    mcp.run()


if __name__ == "__main__":
    # Some environments complain if an event loop is already running.
    # FastMCP handles stdio and tool execution; we just start it.
    try:
        main()
    except RuntimeError as exc:
        if "asyncio.run()" in str(exc) and asyncio.get_event_loop().is_running():
            main()
        else:
            raise
