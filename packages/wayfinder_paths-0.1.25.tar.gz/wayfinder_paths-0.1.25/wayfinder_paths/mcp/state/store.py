from __future__ import annotations

import json
import os
import sqlite3
import time
from pathlib import Path
from typing import Any

from wayfinder_paths.mcp.utils import repo_root


class _HexBytesEncoder(json.JSONEncoder):
    """JSON encoder that handles HexBytes and other byte-like objects."""

    def default(self, obj: Any) -> Any:
        if hasattr(obj, "hex") and callable(obj.hex):
            return obj.hex()
        if isinstance(obj, bytes):
            return obj.hex()
        return super().default(obj)


class IdempotencyStore:
    def __init__(self, db_path: Path):
        self.db_path = db_path
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        self._init_db()

    @staticmethod
    def default() -> IdempotencyStore:
        candidate = (
            os.getenv("WAYFINDER_MCP_STATE_PATH") or ".cache/wayfinder_mcp.sqlite3"
        )
        path = Path(candidate)
        if not path.is_absolute():
            path = repo_root() / path
        return IdempotencyStore(path)

    def _connect(self) -> sqlite3.Connection:
        conn = sqlite3.connect(str(self.db_path))
        conn.row_factory = sqlite3.Row
        return conn

    def _init_db(self) -> None:
        with self._connect() as conn:
            conn.execute(
                """
                CREATE TABLE IF NOT EXISTS idempotency (
                    idempotency_key TEXT PRIMARY KEY,
                    created_at INTEGER NOT NULL,
                    request_json TEXT NOT NULL,
                    response_json TEXT NOT NULL
                )
                """
            )
            conn.commit()

    def get(self, key: str) -> dict[str, Any] | None:
        with self._connect() as conn:
            row = conn.execute(
                "SELECT response_json FROM idempotency WHERE idempotency_key = ?",
                (key,),
            ).fetchone()
            if row is None:
                return None
            try:
                parsed = json.loads(row["response_json"])
            except Exception:
                return None
            return parsed if isinstance(parsed, dict) else None

    def put(self, key: str, request: Any, response: Any) -> None:
        with self._connect() as conn:
            conn.execute(
                """
                INSERT OR REPLACE INTO idempotency
                    (idempotency_key, created_at, request_json, response_json)
                VALUES
                    (?, ?, ?, ?)
                """,
                (
                    key,
                    int(time.time()),
                    json.dumps(request, sort_keys=True, cls=_HexBytesEncoder),
                    json.dumps(response, sort_keys=True, cls=_HexBytesEncoder),
                ),
            )
            conn.commit()
