from __future__ import annotations

import asyncio
from typing import Any, Literal

import httpx

from wayfinder_paths.core.config import get_api_base_url, get_api_key
from wayfinder_paths.core.constants.base import DEFAULT_HTTP_TIMEOUT
from wayfinder_paths.mcp.utils import err, find_wallet_by_label, normalize_address, ok


class _BalanceClient:
    def __init__(self):
        self.api_base_url = get_api_base_url()
        timeout = httpx.Timeout(DEFAULT_HTTP_TIMEOUT)
        self.client = httpx.AsyncClient(timeout=timeout)
        self._headers = {"Content-Type": "application/json"}
        api_key = get_api_key()
        if api_key:
            self._headers["X-API-KEY"] = api_key

    async def close(self):
        await self.client.aclose()

    async def get_enriched_wallet_balances(
        self,
        *,
        wallet_address: str,
        exclude_spam_tokens: bool = True,
    ) -> dict:
        url = f"{self.api_base_url}/blockchain/balances/enriched/"
        params = {
            "address": wallet_address,
            "exclude_spam_tokens": str(exclude_spam_tokens).lower(),
        }
        response = await self.client.get(url, params=params, headers=self._headers)
        response.raise_for_status()
        return response.json()

    async def get_wallet_activity(
        self,
        *,
        wallet_address: str,
        limit: int = 20,
        offset: str | None = None,
    ) -> dict:
        url = f"{self.api_base_url}/blockchain/balances/activity/"
        params: dict[str, str | int] = {"address": wallet_address, "limit": limit}
        if offset:
            params["offset"] = offset
        response = await self.client.get(url, params=params, headers=self._headers)
        response.raise_for_status()
        return response.json()

    async def get_token_balance(
        self,
        *,
        wallet_address: str,
        token_id: str,
        human_readable: bool = True,
    ) -> dict:
        url = f"{self.api_base_url}/public/balances/token/"
        params = {
            "wallet_address": wallet_address,
            "token_id": token_id,
            "human_readable": str(human_readable).lower(),
        }
        response = await self.client.get(url, params=params, headers=self._headers)
        response.raise_for_status()
        return response.json()

    async def get_pool_balance(
        self,
        *,
        pool_address: str,
        chain_id: int,
        user_address: str,
        human_readable: bool = True,
    ) -> dict:
        url = f"{self.api_base_url}/public/balances/pool/"
        params = {
            "pool_address": pool_address,
            "chain_id": chain_id,
            "user_address": user_address,
            "human_readable": str(human_readable).lower(),
        }
        response = await self.client.get(url, params=params, headers=self._headers)
        response.raise_for_status()
        return response.json()


def _dedupe_ordered(items: list[str]) -> list[str]:
    seen: set[str] = set()
    out: list[str] = []
    for item in items:
        key = item.lower()
        if key in seen:
            continue
        seen.add(key)
        out.append(item)
    return out


def _is_evm_address(addr: str) -> bool:
    a = (addr or "").strip()
    return a.startswith("0x") and len(a) == 42


def _balance_usd(entry: dict[str, Any]) -> float:
    val = entry.get("balanceUSD", 0)
    try:
        return float(val or 0)
    except (TypeError, ValueError):
        return 0.0


async def balances(
    action: Literal["token", "pool", "enriched", "activity"],
    *,
    wallet_label: str | None = None,
    wallet_address: str | None = None,
    human_readable: bool = True,
    include_solana: bool = False,
    exclude_spam_tokens: bool = True,
    limit: int = 20,
    offset: str | None = None,
    token_id: str | None = None,
    token_ids: list[str] | None = None,
    chain_id: int | None = None,
    pool_address: str | None = None,
    pool_addresses: list[str] | None = None,
) -> dict[str, Any]:
    waddr = normalize_address(wallet_address)
    if not waddr:
        want = (wallet_label or "").strip()
        if want:
            w = find_wallet_by_label(want)
            if not w:
                return err("not_found", f"Unknown wallet_label: {want}")
            waddr = normalize_address(w.get("address"))

    if not waddr:
        return err(
            "invalid_request", "wallet_label or wallet_address is required for balances"
        )

    client = _BalanceClient()

    try:
        if action == "enriched":
            try:
                data = await client.get_enriched_wallet_balances(
                    wallet_address=waddr,
                    exclude_spam_tokens=bool(exclude_spam_tokens),
                )
                if (
                    not include_solana
                    and _is_evm_address(waddr)
                    and isinstance(data, dict)
                    and isinstance(data.get("balances"), list)
                ):
                    balances_list = [b for b in data["balances"] if isinstance(b, dict)]
                    filtered = [
                        b
                        for b in balances_list
                        if str(b.get("network", "")).lower() != "solana"
                    ]
                    if len(filtered) != len(balances_list):
                        out = dict(data)
                        out["balances"] = filtered
                        out["total_balance_usd"] = sum(
                            _balance_usd(b) for b in filtered
                        )
                        breakdown: dict[str, float] = {}
                        for b in filtered:
                            net = str(b.get("network") or "").strip()
                            if not net:
                                continue
                            breakdown[net] = breakdown.get(net, 0.0) + _balance_usd(b)
                        out["chain_breakdown"] = breakdown
                        out["filtered"] = {
                            "excluded_networks": ["solana"],
                            "original_count": len(balances_list),
                            "filtered_count": len(filtered),
                        }
                        data = out

                return ok(data)
            except Exception as exc:  # noqa: BLE001
                return err("balance_error", str(exc))

        if action == "activity":
            try:
                data = await client.get_wallet_activity(
                    wallet_address=waddr,
                    limit=int(limit),
                    offset=offset,
                )
                return ok(
                    {
                        "wallet_address": waddr,
                        "activity": data.get("activity", []),
                        "next_offset": data.get("next_offset"),
                    }
                )
            except Exception as exc:  # noqa: BLE001
                return err("activity_error", str(exc))

        if action == "token":
            raw_ids: list[str] = []
            if token_id:
                raw_ids.append(str(token_id).strip())
            if token_ids:
                raw_ids.extend(str(x).strip() for x in token_ids)

            ids = _dedupe_ordered([x for x in raw_ids if x])
            if not ids:
                return err(
                    "invalid_request",
                    "token_id or token_ids is required for balances(action=token)",
                )

            async def _one(tid: str) -> dict[str, Any]:
                try:
                    data = await client.get_token_balance(
                        token_id=tid,
                        wallet_address=waddr,
                        human_readable=bool(human_readable),
                    )
                    return {"ok": True, "token_id": tid, "data": data}
                except Exception as exc:  # noqa: BLE001
                    return {"ok": False, "token_id": tid, "error": str(exc)}

            results = await asyncio.gather(*[_one(tid) for tid in ids])
            return ok({"wallet_address": waddr, "balances": results})

        if action == "pool":
            if chain_id is None:
                return err(
                    "invalid_request", "chain_id is required for balances(action=pool)"
                )

            raw_pools: list[str] = []
            if pool_address:
                raw_pools.append(str(pool_address).strip())
            if pool_addresses:
                raw_pools.extend(str(x).strip() for x in pool_addresses)

            pools = _dedupe_ordered([x for x in raw_pools if x])
            if not pools:
                return err(
                    "invalid_request",
                    "pool_address or pool_addresses is required for balances(action=pool)",
                )

            async def _one_pool(paddr: str) -> dict[str, Any]:
                try:
                    data = await client.get_pool_balance(
                        pool_address=paddr,
                        chain_id=int(chain_id),  # type: ignore[arg-type]
                        user_address=waddr,
                        human_readable=bool(human_readable),
                    )
                    return {
                        "ok": True,
                        "pool_address": paddr,
                        "chain_id": int(chain_id),  # type: ignore[arg-type]
                        "data": data,
                    }
                except Exception as exc:  # noqa: BLE001
                    return {
                        "ok": False,
                        "pool_address": paddr,
                        "chain_id": int(chain_id),  # type: ignore[arg-type]
                        "error": str(exc),
                    }

            results = await asyncio.gather(*[_one_pool(p) for p in pools])
            return ok(
                {"wallet_address": waddr, "chain_id": int(chain_id), "pools": results}
            )

        return err("invalid_request", f"Unknown balances action: {action}")

    finally:
        try:
            await client.close()
        except Exception:  # noqa: BLE001
            pass
