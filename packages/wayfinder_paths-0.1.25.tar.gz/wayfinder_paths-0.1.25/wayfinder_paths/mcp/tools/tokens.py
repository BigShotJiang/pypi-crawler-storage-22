from __future__ import annotations

from typing import Any, Literal

from wayfinder_paths.core.clients.TokenClient import TokenClient
from wayfinder_paths.mcp.utils import err, ok


async def tokens(
    action: Literal["resolve", "gas", "fuzzy"],
    query: str | None = None,
    chain_code: str | None = None,
) -> dict[str, Any]:
    client = TokenClient()
    try:
        if action == "resolve":
            q = (query or "").strip()
            if not q:
                return err(
                    "invalid_request", "query is required for tokens(action=resolve)"
                )
            token = await client.get_token_details(q)
            return ok({"token": token})

        if action == "gas":
            cc = (chain_code or "").strip()
            if not cc:
                return err(
                    "invalid_request", "chain_code is required for tokens(action=gas)"
                )
            token = await client.get_gas_token(cc)
            return ok({"token": token})

        if action == "fuzzy":
            q = (query or "").strip()
            if not q:
                return err(
                    "invalid_request", "query is required for tokens(action=fuzzy)"
                )
            cc = (chain_code or "").strip() or None
            result = await client.fuzzy_search(q, chain=cc)
            return ok(result)

        return err("invalid_request", f"Unknown tokens action: {action}")
    except Exception as exc:  # noqa: BLE001
        return err("token_error", str(exc))
