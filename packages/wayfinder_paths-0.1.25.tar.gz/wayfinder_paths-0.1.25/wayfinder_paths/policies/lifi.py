from wayfinder_paths.policies.util import allow_functions

LIFI_ROUTERS: dict[int:str] = {999: "0x0a0758d937d1059c356D4714e57F5df0239bce1A"}
LIFI_GENERIC = "0x31a9b1835864706Af10103b31Ea2b79bdb995F5F"


async def lifi_swap(chain_id):
    # NOTE: we get the abi from the base contract as it is a generic abi used everywhere
    # and not all chains have this ABI published
    return await allow_functions(
        policy_name="Allow LIFI Swap",
        abi_chain_id=8453,
        address=LIFI_ROUTERS[chain_id],
        function_names=[
            "swapTokensMultipleV3ERC20ToERC20",
        ],
        abi_address_override=LIFI_GENERIC,
    )
