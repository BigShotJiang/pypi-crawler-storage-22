# ─────────────────────────────────────────────────────────────────────────────
# TOKEN IDS (wayfinder token identifiers)
# ─────────────────────────────────────────────────────────────────────────────

# Arbitrum tokens
USDC_ARB = "usd-coin-arbitrum"
USDT_ARB = "usdt0-arbitrum"
ETH_ARB = "ethereum-arbitrum"

# HyperEVM tokens
HYPE_NATIVE = "hype-hyperevm"
WHYPE = "wrapped-hype-hyperevm"  # Wrapped HYPE (1:1 with native HYPE)
KHYPE_LST = "kinetic-staked-hype-hyperevm"
LOOPED_HYPE = "looped-hype-hyperevm"
USDC_HYPE = "usd-coin-hyperevm"


# ─────────────────────────────────────────────────────────────────────────────
# CONTRACT ADDRESSES
# ─────────────────────────────────────────────────────────────────────────────

# HyperEVM token addresses
KHYPE_ADDRESS = "0xfD739d4e423301CE9385c1fb8850539D657C296D"
LOOPED_HYPE_ADDRESS = "0x5748ae796AE46A4F1348a1693de4b50560485562"
WHYPE_ADDRESS = "0x5555555555555555555555555555555555555555"

# Accountant contracts for exchange rate calculations
KHYPE_STAKING_ACCOUNTANT = "0x9209648Ec9D448EF57116B73A2f081835643dc7A"
LHYPE_ACCOUNTANT = "0xcE621a3CA6F72706678cFF0572ae8d15e5F001c3"

# Chain IDs
HYPEREVM_CHAIN_ID = 999
ARBITRUM_CHAIN_ID = 42161

# ABIs for exchange rate reads
KHYPE_STAKING_ACCOUNTANT_ABI = [
    {
        "inputs": [
            {"internalType": "uint256", "name": "kHYPEAmount", "type": "uint256"}
        ],
        "name": "kHYPEToHYPE",
        "outputs": [{"internalType": "uint256", "name": "", "type": "uint256"}],
        "stateMutability": "view",
        "type": "function",
    }
]

LHYPE_ACCOUNTANT_ABI = [
    {
        "inputs": [{"internalType": "address", "name": "quote", "type": "address"}],
        "name": "getRateInQuote",
        "outputs": [{"internalType": "uint256", "name": "", "type": "uint256"}],
        "stateMutability": "view",
        "type": "function",
    }
]

# WHYPE contract ABI for unwrapping (standard WETH-like interface)
WHYPE_ABI = [
    {
        "name": "withdraw",
        "type": "function",
        "stateMutability": "nonpayable",
        "inputs": [{"name": "wad", "type": "uint256"}],
        "outputs": [],
    },
    {
        "name": "balanceOf",
        "type": "function",
        "stateMutability": "view",
        "inputs": [{"name": "owner", "type": "address"}],
        "outputs": [{"type": "uint256"}],
    },
]


# ─────────────────────────────────────────────────────────────────────────────
# STRATEGY THRESHOLDS
# ─────────────────────────────────────────────────────────────────────────────

MIN_NET_DEPOSIT = 150.0  # Minimum deposit to activate strategy
MAX_HL_LEVERAGE = 2.0  # Maximum leverage on Hyperliquid shorts
PARTIAL_TRIM_THRESHOLD = 0.75  # Risk level to trigger partial trim
FULL_REBALANCE_THRESHOLD = 0.90  # Risk level to trigger full rebalance
ALLOCATION_DEVIATION_THRESHOLD = 0.03  # 3% deviation triggers rebalance
HORIZON_DAYS = 7  # Planning horizon in days


# ─────────────────────────────────────────────────────────────────────────────
# BOROS CONFIGURATION
# ─────────────────────────────────────────────────────────────────────────────

# NOTE: Boros migrated the old USDT-collateralized HYPE market. The current
# entry path uses HYPE collateral (via the LayerZero OFT token on Arbitrum).
BOROS_HYPE_MARKET_ID = 51  # HYPERLIQUID-HYPE-27FEB2026 (fallback)
BOROS_HYPE_TOKEN_ID = 5  # HYPE collateral token ID on Boros (current)
BOROS_MIN_DEPOSIT_USD = 10.50  # Minimum collateral value to bother funding
BOROS_MIN_TENOR_DAYS = 3  # Roll to new market if < 3 days to expiry
BOROS_ENABLE_MIN_TOTAL_USD = 80.0  # Skip Boros if capital below this

# LayerZero OFT bridge (HyperEVM native HYPE → Arbitrum OFT HYPE)
HYPE_OFT_ADDRESS = "0x007C26Ed5C33Fe6fEF62223d4c363A01F1b1dDc1"
LZ_EID_ARBITRUM = 30110

# Minimal IOFT ABI for quoting + sending.
HYPE_OFT_ABI = [
    {
        "inputs": [
            {
                "components": [
                    {"internalType": "uint32", "name": "dstEid", "type": "uint32"},
                    {"internalType": "bytes32", "name": "to", "type": "bytes32"},
                    {"internalType": "uint256", "name": "amountLD", "type": "uint256"},
                    {
                        "internalType": "uint256",
                        "name": "minAmountLD",
                        "type": "uint256",
                    },
                    {
                        "internalType": "bytes",
                        "name": "extraOptions",
                        "type": "bytes",
                    },
                    {"internalType": "bytes", "name": "composeMsg", "type": "bytes"},
                    {"internalType": "bytes", "name": "oftCmd", "type": "bytes"},
                ],
                "internalType": "struct SendParam",
                "name": "_sendParam",
                "type": "tuple",
            },
            {"internalType": "bool", "name": "_payInLzToken", "type": "bool"},
        ],
        "name": "quoteSend",
        "outputs": [
            {
                "components": [
                    {"internalType": "uint256", "name": "nativeFee", "type": "uint256"},
                    {
                        "internalType": "uint256",
                        "name": "lzTokenFee",
                        "type": "uint256",
                    },
                ],
                "internalType": "struct MessagingFee",
                "name": "",
                "type": "tuple",
            }
        ],
        "stateMutability": "view",
        "type": "function",
    },
    {
        "inputs": [
            {
                "components": [
                    {"internalType": "uint32", "name": "dstEid", "type": "uint32"},
                    {"internalType": "bytes32", "name": "to", "type": "bytes32"},
                    {"internalType": "uint256", "name": "amountLD", "type": "uint256"},
                    {
                        "internalType": "uint256",
                        "name": "minAmountLD",
                        "type": "uint256",
                    },
                    {
                        "internalType": "bytes",
                        "name": "extraOptions",
                        "type": "bytes",
                    },
                    {"internalType": "bytes", "name": "composeMsg", "type": "bytes"},
                    {"internalType": "bytes", "name": "oftCmd", "type": "bytes"},
                ],
                "internalType": "struct SendParam",
                "name": "_sendParam",
                "type": "tuple",
            },
            {
                "components": [
                    {"internalType": "uint256", "name": "nativeFee", "type": "uint256"},
                    {
                        "internalType": "uint256",
                        "name": "lzTokenFee",
                        "type": "uint256",
                    },
                ],
                "internalType": "struct MessagingFee",
                "name": "_fee",
                "type": "tuple",
            },
            {"internalType": "address", "name": "_refundAddress", "type": "address"},
        ],
        "name": "send",
        "outputs": [
            {
                "components": [
                    {"internalType": "bytes32", "name": "guid", "type": "bytes32"},
                    {"internalType": "uint64", "name": "nonce", "type": "uint64"},
                    {
                        "components": [
                            {
                                "internalType": "uint256",
                                "name": "nativeFee",
                                "type": "uint256",
                            },
                            {
                                "internalType": "uint256",
                                "name": "lzTokenFee",
                                "type": "uint256",
                            },
                        ],
                        "internalType": "struct MessagingFee",
                        "name": "fee",
                        "type": "tuple",
                    },
                ],
                "internalType": "struct MessagingReceipt",
                "name": "",
                "type": "tuple",
            },
            {
                "components": [
                    {
                        "internalType": "uint256",
                        "name": "amountSentLD",
                        "type": "uint256",
                    },
                    {
                        "internalType": "uint256",
                        "name": "amountReceivedLD",
                        "type": "uint256",
                    },
                ],
                "internalType": "struct OFTReceipt",
                "name": "",
                "type": "tuple",
            },
        ],
        "stateMutability": "payable",
        "type": "function",
    },
]

# ─────────────────────────────────────────────────────────────────────────────
# GAS CONFIGURATION
# ─────────────────────────────────────────────────────────────────────────────

MIN_HYPE_GAS = 0.1  # Minimum HYPE for HyperEVM gas
HYPE_DEPOSIT_REQUIREMENT = 0.1  # HYPE to ensure for gas on deposit


# ─────────────────────────────────────────────────────────────────────────────
# EXTERNAL API ENDPOINTS
# ─────────────────────────────────────────────────────────────────────────────

LHYPE_API_URL = "https://app.loopingcollective.org/api/external/asset/lhype"
KHYPE_API_URL = "https://kinetiq.xyz/api/khype"
