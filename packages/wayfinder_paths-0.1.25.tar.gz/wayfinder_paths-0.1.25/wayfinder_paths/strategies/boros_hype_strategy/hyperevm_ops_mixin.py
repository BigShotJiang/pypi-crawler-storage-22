"""
HyperEVM / spot-leg operations for BorosHypeStrategy.

Kept as a mixin so the main strategy file stays readable without changing behavior.
"""

from __future__ import annotations

from typing import Any

from .constants import HYPE_NATIVE, KHYPE_LST, LOOPED_HYPE, MIN_HYPE_GAS
from .types import Inventory


class BorosHypeHyperEvmOpsMixin:
    async def _ensure_gas_on_hyperevm(
        self, params: dict[str, Any], inventory: Inventory
    ) -> tuple[bool, str]:
        min_hype = float(params.get("min_hype") or MIN_HYPE_GAS)
        need = max(0.0, min_hype - inventory.hype_hyperevm_balance)
        if need <= 0.0:
            return True, "HyperEVM gas already sufficient"

        # Best-effort: if HYPE exists on HL spot, bridge it over.
        if inventory.hl_spot_hype > max(0.1, need + 0.001):
            return await self._transfer_hl_spot_to_hyperevm(
                {"hype_amount": max(0.1, need)}, inventory
            )

        # Otherwise, we expect the upcoming BRIDGE_TO_HYPEREVM routine to bring HYPE.
        return True, "HyperEVM gas will be provisioned during routing"

    async def _ensure_gas_on_arbitrum(
        self, params: dict[str, Any], inventory: Inventory
    ) -> tuple[bool, str]:
        # TODO: Implement - bridge ETH or use gas station
        return True, "Arbitrum gas routing not yet implemented"

    async def _swap_hype_to_lst(
        self, params: dict[str, Any], inventory: Inventory
    ) -> tuple[bool, str]:
        hype_amount = params.get("hype_amount", 0.0)

        if hype_amount <= 0:
            return True, "No HYPE to swap"

        if self.simulation:
            return True, f"[SIMULATION] Swapped {hype_amount:.4f} HYPE to LSTs"

        if not self.brap_adapter:
            return False, "BRAP adapter not configured"

        strategy_wallet = self._config.get("strategy_wallet", {})
        wallet_address = strategy_wallet.get("address")
        if not wallet_address:
            return False, "No strategy wallet address configured"

        # Normalize split fractions.
        khype_fraction = max(0.0, float(self.hedge_cfg.khype_fraction))
        looped_fraction = max(0.0, float(self.hedge_cfg.looped_hype_fraction))
        total_fraction = khype_fraction + looped_fraction
        if total_fraction <= 0:
            khype_fraction = 0.5
            looped_fraction = 0.5
            total_fraction = 1.0

        khype_share = khype_fraction / total_fraction

        # HYPE native has 18 decimals.
        hype_amount_wei = int(float(hype_amount) * 1e18)
        khype_amount_wei = int(hype_amount_wei * khype_share)
        looped_amount_wei = max(0, hype_amount_wei - khype_amount_wei)

        # If one side is dust, allocate to the other.
        min_swap_wei = int(0.02 * 1e18)
        if 0 < khype_amount_wei < min_swap_wei:
            looped_amount_wei += khype_amount_wei
            khype_amount_wei = 0
        if 0 < looped_amount_wei < min_swap_wei:
            khype_amount_wei += looped_amount_wei
            looped_amount_wei = 0

        results: list[str] = []

        if khype_amount_wei > 0:
            ok, res = await self.brap_adapter.swap_from_token_ids(
                from_token_id=HYPE_NATIVE,
                to_token_id=KHYPE_LST,
                from_address=wallet_address,
                amount=str(khype_amount_wei),
                slippage=0.01,
                strategy_name="boros_hype_strategy",
            )
            if not ok:
                return False, f"Swap HYPE→kHYPE failed: {res}"
            results.append(f"kHYPE({khype_amount_wei / 1e18:.4f} HYPE)")

        if looped_amount_wei > 0:
            ok, res = await self.brap_adapter.swap_from_token_ids(
                from_token_id=HYPE_NATIVE,
                to_token_id=LOOPED_HYPE,
                from_address=wallet_address,
                amount=str(looped_amount_wei),
                slippage=0.01,
                strategy_name="boros_hype_strategy",
            )
            if not ok:
                return False, f"Swap HYPE→looped HYPE failed: {res}"
            results.append(f"looped({looped_amount_wei / 1e18:.4f} HYPE)")

        if not results:
            return True, "No non-dust HYPE amount to swap"

        return True, f"Swapped HYPE → {', '.join(results)}"
