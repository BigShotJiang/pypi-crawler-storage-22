"""
Hyperliquid operations for BorosHypeStrategy.

Kept as a mixin so the main strategy file stays readable without changing behavior.
"""

from __future__ import annotations

from typing import Any

from loguru import logger

from wayfinder_paths.adapters.hyperliquid_adapter.adapter import (
    HYPERLIQUID_BRIDGE_ADDRESS,
)
from wayfinder_paths.adapters.hyperliquid_adapter.paired_filler import (
    MIN_NOTIONAL_USD,
    PairedFiller,
)

from .constants import MAX_HL_LEVERAGE, USDC_ARB
from .types import Inventory


class BorosHypeHyperliquidOpsMixin:
    async def _get_hype_asset_ids(self) -> tuple[int, int]:
        if not self.hyperliquid_adapter:
            raise RuntimeError("Hyperliquid adapter not configured")

        perp_asset_id = self.hyperliquid_adapter.coin_to_asset.get("HYPE")
        if perp_asset_id is None:
            raise RuntimeError("HYPE perp asset ID not found")

        spot_asset_id = await self.hyperliquid_adapter.get_spot_asset_id("HYPE", "USDC")
        if spot_asset_id is None:
            success, spot_assets = await self.hyperliquid_adapter.get_spot_assets()
            if success and isinstance(spot_assets, dict):
                spot_asset_id = spot_assets.get("HYPE/USDC")

        if spot_asset_id is None:
            raise RuntimeError("HYPE/USDC spot asset ID not found")

        return int(spot_asset_id), int(perp_asset_id)

    async def _ensure_hl_hype_leverage_set(self, address: str) -> tuple[bool, str]:
        if self.simulation:
            self._planner_runtime.leverage_set_for_hype = True
            return True, "[SIMULATION] HYPE leverage set"

        if not self.hyperliquid_adapter:
            return False, "Hyperliquid adapter not configured"
        if not self._sign_callback:
            return False, "No strategy wallet signing callback configured"

        if self._planner_runtime.leverage_set_for_hype:
            return True, "HYPE leverage already set"

        perp_asset_id = self.hyperliquid_adapter.coin_to_asset.get("HYPE")
        if perp_asset_id is None:
            return False, "HYPE perp asset ID not found"

        ok_lev, lev_res = await self.hyperliquid_adapter.update_leverage(
            asset_id=int(perp_asset_id),
            leverage=int(MAX_HL_LEVERAGE),
            is_cross=True,
            address=address,
        )
        if not ok_lev:
            return False, f"Failed to update Hyperliquid leverage: {lev_res}"

        self._planner_runtime.leverage_set_for_hype = True
        logger.info(f"Set Hyperliquid HYPE leverage to {int(MAX_HL_LEVERAGE)}x (cross)")
        return True, f"Set Hyperliquid HYPE leverage to {int(MAX_HL_LEVERAGE)}x (cross)"

    async def _cancel_lingering_orders(
        self, pointers: list[dict[str, Any]], address: str
    ) -> None:
        if not self.hyperliquid_adapter:
            return

        for pointer in pointers:
            metadata = pointer.get("metadata") if isinstance(pointer, dict) else None
            if not isinstance(metadata, dict):
                continue
            asset_id = metadata.get("asset_id")
            cloid = metadata.get("client_id")
            if asset_id is None or not cloid:
                continue
            try:
                await self.hyperliquid_adapter.cancel_order_by_cloid(
                    int(asset_id), str(cloid), address
                )
            except Exception as exc:
                logger.debug(
                    f"Failed to cancel lingering order: asset_id={asset_id}, cloid={cloid}, err={exc}"
                )

    async def _cancel_hl_open_orders_for_hype(self, address: str) -> None:
        if not self.hyperliquid_adapter:
            return

        try:
            spot_asset_id, perp_asset_id = await self._get_hype_asset_ids()
        except Exception as exc:  # noqa: BLE001
            logger.warning(f"Failed to resolve HYPE asset ids for cancel: {exc}")
            return

        spot_coin = f"@{spot_asset_id - 10000}" if spot_asset_id >= 10000 else None

        success, open_orders = await self.hyperliquid_adapter.get_frontend_open_orders(
            address
        )
        if not success or not isinstance(open_orders, list):
            logger.warning("Could not fetch Hyperliquid open orders to cancel")
            return

        canceled = 0
        for order in open_orders:
            if not isinstance(order, dict):
                continue
            order_coin = order.get("coin") or order.get("asset") or ""
            order_id = order.get("oid") or order.get("orderId") or order.get("id")
            if not order_id:
                continue

            try:
                if str(order_coin) == "HYPE":
                    await self.hyperliquid_adapter.cancel_order(
                        asset_id=int(perp_asset_id),
                        order_id=order_id,
                        address=address,
                    )
                    canceled += 1
                elif spot_coin and str(order_coin) == spot_coin:
                    await self.hyperliquid_adapter.cancel_order(
                        asset_id=int(spot_asset_id),
                        order_id=order_id,
                        address=address,
                    )
                    canceled += 1
            except Exception as exc:  # noqa: BLE001
                logger.debug(
                    f"Failed cancel HL order: coin={order_coin} oid={order_id} err={exc}"
                )

        if canceled:
            logger.info(f"Canceled {canceled} Hyperliquid HYPE order(s)")

    async def _deploy_excess_hl_margin(
        self, params: dict[str, Any], inventory: Inventory
    ) -> tuple[bool, str]:
        # Flow: Transfer USDC perp→spot, buy HYPE on spot, bridge to HyperEVM
        excess_margin = params.get("excess_margin_usd", 0)

        if excess_margin < 5:
            return True, "Skipping small excess margin deployment"

        if not self.hyperliquid_adapter:
            return False, "Hyperliquid adapter not configured"

        strategy_wallet = self._config.get("strategy_wallet", {})
        address = strategy_wallet.get("address")
        if not address:
            return False, "No strategy wallet address configured"

        if self.simulation:
            return (
                True,
                f"[SIMULATION] Deployed ${excess_margin:.2f} excess HL margin to spot",
            )

        hype_price = float(inventory.hype_price_usd or 0.0)
        if hype_price <= 0:
            hype_price = 25.0

        success, result = await self.hyperliquid_adapter.transfer_perp_to_spot(
            amount=excess_margin,
            address=address,
        )

        if not success:
            error_msg = result if isinstance(result, str) else str(result)
            return False, f"Perp to spot transfer failed: {error_msg}"

        logger.info(f"Transferred ${excess_margin:.2f} from perp margin to spot")

        if excess_margin < MIN_NOTIONAL_USD:
            return True, f"Excess margin ${excess_margin:.2f} too small for paired fill"

        hype_to_buy = (excess_margin * 0.98) / hype_price  # 2% buffer

        spot_asset_id, perp_asset_id = await self._get_hype_asset_ids()
        paired_filler = PairedFiller(adapter=self.hyperliquid_adapter, address=address)

        ok_lev, lev_msg = await self._ensure_hl_hype_leverage_set(address)
        if not ok_lev:
            return False, lev_msg

        try:
            (
                filled_spot,
                filled_perp,
                spot_notional,
                perp_notional,
                spot_pointers,
                perp_pointers,
            ) = await paired_filler.fill_pair_units(
                coin="HYPE",
                spot_asset_id=spot_asset_id,
                perp_asset_id=perp_asset_id,
                total_units=hype_to_buy,
                direction="long_spot_short_perp",
                builder_fee=self.builder_fee,
            )
            logger.info(
                f"Paired fill from excess margin complete: "
                f"spot={filled_spot:.4f} (${spot_notional:.2f}), "
                f"perp={filled_perp:.4f} (${perp_notional:.2f})"
            )
            await self._cancel_lingering_orders(spot_pointers + perp_pointers, address)
        except Exception as exc:
            logger.error(f"Paired fill from excess margin failed: {exc}")
            return False, f"Paired fill failed: {exc}"

        try:
            success, spot_state = await self.hyperliquid_adapter.get_spot_user_state(
                address
            )
            if not success or not isinstance(spot_state, dict):
                return (
                    True,
                    f"Deployed ${excess_margin:.2f} (bridge pending spot state)",
                )

            balances = spot_state.get("balances", [])
            actual_hype = 0.0
            for bal in balances:
                coin = bal.get("coin") or bal.get("token")
                if coin != "HYPE":
                    continue
                hold = float(bal.get("hold", 0))
                total = float(bal.get("total", 0))
                actual_hype = max(0.0, total - hold)
                break

            amount_to_bridge = actual_hype - 0.001
            if amount_to_bridge < 0.1:
                return True, f"Deployed ${excess_margin:.2f} (no HYPE to bridge)"

            ok, res = await self.hyperliquid_adapter.hypercore_to_hyperevm(
                amount=amount_to_bridge,
                address=address,
            )
            if ok:
                return (
                    True,
                    f"Deployed ${excess_margin:.2f} excess margin → {amount_to_bridge:.4f} HYPE to HyperEVM",
                )

            err = res if isinstance(res, str) else str(res)
            return False, f"Bridge failed: {err}"

        except Exception as exc:
            return False, f"Bridge failed: {exc}"

    async def _transfer_hl_spot_to_hyperevm(
        self, params: dict[str, Any], inventory: Inventory
    ) -> tuple[bool, str]:
        # HL spot HYPE withdrawal goes directly to HyperEVM (native chain) via L1 withdrawal
        hype_amount = params.get("hype_amount", 0)

        if hype_amount < 0.1:
            return True, "Skipping small HYPE transfer"

        if not self.hyperliquid_adapter:
            return False, "Hyperliquid adapter not configured"

        strategy_wallet = self._config.get("strategy_wallet", {})
        address = strategy_wallet.get("address")
        if not address:
            return False, "No strategy wallet address configured"

        if self.simulation:
            return (
                True,
                f"[SIMULATION] Transferred {hype_amount:.4f} HYPE from HL spot to HyperEVM",
            )

        try:
            success, spot_state = await self.hyperliquid_adapter.get_spot_user_state(
                address
            )
            if not success or not isinstance(spot_state, dict):
                return False, "Failed to read HL spot balances"

            balances = spot_state.get("balances", [])
            actual_hype = 0.0
            for bal in balances:
                coin = bal.get("coin") or bal.get("token")
                if coin != "HYPE":
                    continue
                hold = float(bal.get("hold", 0))
                total = float(bal.get("total", 0))
                actual_hype = max(0.0, total - hold)
                break

            transfer_amount = actual_hype - 0.001
            if transfer_amount < 0.1:
                return True, "Insufficient HYPE balance to transfer"

            ok, res = await self.hyperliquid_adapter.hypercore_to_hyperevm(
                amount=transfer_amount,
                address=address,
            )
            if ok:
                return True, f"Transferred {transfer_amount:.4f} HYPE to HyperEVM"

            err = res if isinstance(res, str) else str(res)
            return False, f"Transfer failed: {err}"

        except Exception as exc:
            logger.error(f"HYPE spot transfer failed: {exc}")
            return False, f"HL spot transfer failed: {exc}"

    async def _ensure_hl_short(
        self, params: dict[str, Any], inventory: Inventory
    ) -> tuple[bool, str]:
        # Safety: 2x leverage, venue-valid rounding, check free margin before increasing
        target_size = float(params.get("target_size") or 0.0)
        current_size = float(params.get("current_size") or 0.0)

        # If both target and current are negligible, do nothing.
        # If target is ~0 but we still have a short, fall through so we can close it.
        if target_size < 0.01 and abs(current_size) < 0.01:
            return True, "No HYPE exposure to hedge"

        tol = max(
            self._planner_config.delta_neutral_abs_tol_hype,
            target_size * self._planner_config.delta_neutral_rel_tol,
        )
        delta = target_size - current_size
        diff = abs(delta)
        if diff <= tol:
            return (
                True,
                f"HYPE hedge within tolerance: Δ={diff:.4f} tol={tol:.4f} "
                f"(spot={target_size:.4f}, short={current_size:.4f})",
            )

        if not self.hyperliquid_adapter:
            return False, "Hyperliquid adapter not configured"

        strategy_wallet = self._config.get("strategy_wallet", {})
        address = strategy_wallet.get("address")
        if not address:
            return False, "No strategy wallet address configured"

        perp_asset_id = self.hyperliquid_adapter.coin_to_asset.get("HYPE")
        if perp_asset_id is None:
            return False, "HYPE perp asset ID not found"

        ok_lev, lev_msg = await self._ensure_hl_hype_leverage_set(address)
        if not ok_lev:
            return False, lev_msg

        hype_price = float(inventory.hype_price_usd or 0.0)
        if hype_price <= 0:
            return False, "Cannot hedge: HYPE price unavailable"

        # delta > 0 => need to INCREASE short (sell more)
        if delta > 0:
            min_increase_needed = max(0.0, diff - tol)
            free_margin = float(inventory.hl_withdrawable_usd or 0.0)
            max_increase_by_margin = (
                (free_margin * MAX_HL_LEVERAGE) / hype_price if hype_price > 0 else 0.0
            )
            desired_increase = min(diff, max_increase_by_margin)
            required_margin = (min_increase_needed * hype_price) / MAX_HL_LEVERAGE

            if free_margin < required_margin * 0.9:
                return (
                    False,
                    f"Insufficient free margin (${free_margin:.2f}) to increase short by {diff:.4f} HYPE "
                    f"(need ${required_margin:.2f}, tol={tol:.4f}). Consider trimming spot.",
                )

            rounded_size = self.hyperliquid_adapter.get_valid_order_size(
                int(perp_asset_id), desired_increase
            )
            if rounded_size <= 0:
                return (
                    False,
                    f"Hedge mismatch Δ={diff:.4f} tol={tol:.4f} but order size rounds to 0.",
                )
            if rounded_size + 1e-9 < min_increase_needed:
                return (
                    False,
                    "Insufficient free margin to hedge within tolerance after rounding "
                    f"(need ≥{min_increase_needed:.4f} HYPE, got {rounded_size:.4f}).",
                )

            order_value_usd = rounded_size * hype_price
            if order_value_usd < float(MIN_NOTIONAL_USD):
                return True, (
                    f"Delta {diff:.4f} HYPE below HL ${MIN_NOTIONAL_USD:.0f} minimum, acceptable"
                )

            if self.simulation:
                return True, (
                    f"[SIMULATION] Increased HYPE short by {rounded_size:.4f} "
                    f"(target={target_size:.4f}, current={current_size:.4f})"
                )

            ok, res = await self.hyperliquid_adapter.place_market_order(
                asset_id=int(perp_asset_id),
                is_buy=False,  # sell to increase short
                slippage=0.05,
                size=float(rounded_size),
                address=address,
                builder=self.builder_fee,
            )
            if not ok:
                return False, f"Failed to increase HYPE short: {res}"

            return True, f"Increased HYPE short by {rounded_size:.4f}"

        # delta < 0 => need to REDUCE short (buy back)
        reduce_units = min(diff, current_size)
        rounded_size = self.hyperliquid_adapter.get_valid_order_size(
            int(perp_asset_id), reduce_units
        )
        if rounded_size <= 0:
            return True, "No short position to reduce"

        order_value_usd = rounded_size * hype_price
        if order_value_usd < float(MIN_NOTIONAL_USD):
            return True, (
                f"Delta {diff:.4f} HYPE below HL ${MIN_NOTIONAL_USD:.0f} minimum, acceptable"
            )

        if self.simulation:
            return True, (
                f"[SIMULATION] Reduced HYPE short by {rounded_size:.4f} "
                f"(target={target_size:.4f}, current={current_size:.4f})"
            )

        ok, res = await self.hyperliquid_adapter.place_market_order(
            asset_id=int(perp_asset_id),
            is_buy=True,  # buy to reduce short
            slippage=0.05,
            size=float(rounded_size),
            address=address,
            reduce_only=True,
            builder=self.builder_fee,
        )
        if not ok:
            return False, f"Failed to reduce HYPE short: {res}"

        return True, f"Reduced HYPE short by {rounded_size:.4f}"

    async def _send_usdc_to_hl(
        self, params: dict[str, Any], inventory: Inventory
    ) -> tuple[bool, str]:
        amount_usd = params.get("amount_usd", 0.0)

        if amount_usd < self._planner_config.min_usdc_action:
            return True, f"Skipping small USDC send (${amount_usd:.2f})"

        if not self.balance_adapter:
            return False, "Balance adapter not configured"

        if not self.hyperliquid_adapter:
            return False, "Hyperliquid adapter not configured"

        strategy_wallet = self._config.get("strategy_wallet", {})
        address = strategy_wallet.get("address")
        if not address:
            return False, "No strategy wallet address configured"

        if self.simulation:
            return True, f"[SIMULATION] Sent ${amount_usd:.2f} USDC to Hyperliquid"

        usdc_raw = int(float(amount_usd) * 1e6)
        success, result = await self.balance_adapter.send_to_address(
            token_id=USDC_ARB,
            amount=usdc_raw,
            from_wallet=strategy_wallet,
            to_address=HYPERLIQUID_BRIDGE_ADDRESS,
            signing_callback=self._sign_callback,
        )
        if not success:
            return False, f"Failed to send USDC to HL bridge: {result}"

        confirmed, final_balance = await self.hyperliquid_adapter.wait_for_deposit(
            address=address,
            expected_increase=float(amount_usd),
            timeout_s=240,
            poll_interval_s=10,
        )
        if not confirmed:
            return False, (
                f"USDC sent to bridge but not confirmed on Hyperliquid within timeout. "
                f"Current HL balance: ${final_balance:.2f}"
            )

        return (
            True,
            f"Sent ${amount_usd:.2f} USDC to Hyperliquid (balance=${final_balance:.2f})",
        )

    async def _bridge_to_hyperevm(
        self, params: dict[str, Any], inventory: Inventory
    ) -> tuple[bool, str]:
        # Assumes Arb→HL deposit handled by SEND_USDC_TO_HL. We: 1) xfer perp→spot,
        # 2) paired fill (long spot / short perp), 3) bridge spot HYPE to HyperEVM.
        desired_usd = float(params.get("amount_usd") or 0.0)
        reserve_hl_margin_usd = float(params.get("reserve_hl_margin_usd") or 0.0)

        if desired_usd < max(self._planner_config.min_usdc_action, MIN_NOTIONAL_USD):
            # Return False to not trigger re-observation when nothing changes
            return False, f"Skipping small bridge (${desired_usd:.2f})"

        if not self.hyperliquid_adapter:
            return False, "Hyperliquid adapter not configured"

        strategy_wallet = self._config.get("strategy_wallet", {})
        address = strategy_wallet.get("address")
        if not address:
            return False, "No strategy wallet address configured"

        if self.simulation:
            return True, f"[SIMULATION] Bridged ${desired_usd:.2f} to HyperEVM"

        hype_price = float(inventory.hype_price_usd or 0.0)
        if hype_price <= 0:
            success, prices = await self.hyperliquid_adapter.get_all_mid_prices()
            if success and isinstance(prices, dict):
                hype_price = float(prices.get("HYPE", 0.0))
        if hype_price <= 0:
            return False, "Could not determine HYPE price"

        # Transfer from perp→spot, but never below the reserved perp margin.
        spot_usdc_before = float(inventory.hl_spot_usdc or 0.0)
        perp_margin = float(inventory.hl_perp_margin or 0.0)
        withdrawable = float(inventory.hl_withdrawable_usd or 0.0)

        transferable_from_perp = max(
            0.0,
            min(
                withdrawable,
                perp_margin - reserve_hl_margin_usd,
            ),
        )

        need_from_perp = max(0.0, desired_usd - spot_usdc_before)
        xfer_usd = min(need_from_perp, transferable_from_perp)

        if xfer_usd >= self._planner_config.min_usdc_action:
            xfer_ok, xfer_res = await self.hyperliquid_adapter.transfer_perp_to_spot(
                amount=float(xfer_usd),
                address=address,
            )
            if not xfer_ok:
                return False, f"Perp→spot transfer failed: {xfer_res}"
            logger.info(
                f"Transferred ${xfer_usd:.2f} from HL perp→spot "
                f"(reserve_perp=${reserve_hl_margin_usd:.2f})"
            )

        deployable_usd = min(desired_usd, spot_usdc_before + xfer_usd)
        if deployable_usd < MIN_NOTIONAL_USD:
            return False, (
                "Insufficient deployable HL spot USDC after reserving perp margin "
                f"(${deployable_usd:.2f} < ${MIN_NOTIONAL_USD:.2f}; "
                f"reserve=${reserve_hl_margin_usd:.2f}, perp=${perp_margin:.2f}, "
                f"withdrawable=${withdrawable:.2f}, spot=${spot_usdc_before:.2f})"
            )

        # Atomic Paired Fill: buy spot HYPE, short perp HYPE
        hype_units = (deployable_usd * 0.98) / hype_price  # 2% buffer
        spot_asset_id, perp_asset_id = await self._get_hype_asset_ids()
        paired_filler = PairedFiller(adapter=self.hyperliquid_adapter, address=address)

        ok_lev, lev_msg = await self._ensure_hl_hype_leverage_set(address)
        if not ok_lev:
            return False, lev_msg

        try:
            (
                filled_spot,
                filled_perp,
                spot_notional,
                perp_notional,
                spot_pointers,
                perp_pointers,
            ) = await paired_filler.fill_pair_units(
                coin="HYPE",
                spot_asset_id=spot_asset_id,
                perp_asset_id=perp_asset_id,
                total_units=hype_units,
                direction="long_spot_short_perp",
                builder_fee=self.builder_fee,
            )
            logger.info(
                f"Paired fill complete: spot={filled_spot:.4f} (${spot_notional:.2f}), "
                f"perp={filled_perp:.4f} (${perp_notional:.2f})"
            )
            await self._cancel_lingering_orders(spot_pointers + perp_pointers, address)
        except Exception as exc:
            logger.error(f"Paired fill failed: {exc}")
            return False, f"Paired fill failed: {exc}"

        success, spot_state = await self.hyperliquid_adapter.get_spot_user_state(
            address
        )
        if not success or not isinstance(spot_state, dict):
            return False, "Failed to read HL spot balances after paired fill"

        balances = spot_state.get("balances", [])
        actual_hype = 0.0
        for bal in balances:
            coin = bal.get("coin") or bal.get("token")
            if coin != "HYPE":
                continue
            hold = float(bal.get("hold", 0))
            total = float(bal.get("total", 0))
            actual_hype = max(0.0, total - hold)
            break

        amount_to_bridge = actual_hype - 0.001
        if amount_to_bridge < 0.1:
            return False, "No HYPE available to bridge to HyperEVM"

        ok, res = await self.hyperliquid_adapter.hypercore_to_hyperevm(
            amount=amount_to_bridge,
            address=address,
        )
        if ok:
            return True, f"Bridged {amount_to_bridge:.4f} HYPE to HyperEVM"

        err = res if isinstance(res, str) else str(res)
        return False, f"Bridge failed: {err}"
