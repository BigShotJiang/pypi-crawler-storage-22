"""Tests for BorosHypeStrategy."""

import importlib.util
import sys
from pathlib import Path
from unittest.mock import AsyncMock

# Ensure wayfinder-paths is on path for tests.test_utils import
_wayfinder_path_dir = Path(__file__).parent.parent.parent.resolve()
_wayfinder_path_str = str(_wayfinder_path_dir)
if _wayfinder_path_str not in sys.path:
    sys.path.insert(0, _wayfinder_path_str)
elif sys.path.index(_wayfinder_path_str) > 0:
    sys.path.remove(_wayfinder_path_str)
    sys.path.insert(0, _wayfinder_path_str)

import pytest  # noqa: E402

try:
    from tests.test_utils import get_canonical_examples, load_strategy_examples
except ImportError:
    test_utils_path = Path(_wayfinder_path_dir) / "tests" / "test_utils.py"
    spec = importlib.util.spec_from_file_location("tests.test_utils", test_utils_path)
    test_utils = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(test_utils)
    get_canonical_examples = test_utils.get_canonical_examples
    load_strategy_examples = test_utils.load_strategy_examples

from wayfinder_paths.strategies.boros_hype_strategy.strategy import (  # noqa: E402
    BorosHypeStrategy,
)


@pytest.fixture
def strategy():
    """Create a strategy instance for testing with minimal config."""
    mock_config = {
        "main_wallet": {"address": "0x1234567890123456789012345678901234567890"},
        "strategy_wallet": {"address": "0xabcdefabcdefabcdefabcdefabcdefabcdefabcd"},
    }

    s = BorosHypeStrategy(
        config=mock_config,
        main_wallet=mock_config["main_wallet"],
        strategy_wallet=mock_config["strategy_wallet"],
        simulation=True,
    )

    # Mock the Boros adapter
    if hasattr(s, "boros_adapter") and s.boros_adapter:
        s.boros_adapter.quote_markets_for_underlying = AsyncMock(
            return_value=(True, [])
        )
        s.boros_adapter.get_account_balances = AsyncMock(
            return_value=(True, {"total": 0.0, "cross": 0.0, "isolated": 0.0})
        )
        s.boros_adapter.get_active_positions = AsyncMock(return_value=(True, []))

    return s


@pytest.mark.asyncio
@pytest.mark.smoke
async def test_smoke(strategy):
    """REQUIRED: Basic smoke test - verifies strategy lifecycle."""
    examples = load_strategy_examples(Path(__file__))
    smoke_data = examples["smoke"]

    await strategy.setup()

    st = await strategy.status()
    assert isinstance(st, dict)
    assert "portfolio_value" in st or "net_deposit" in st or "strategy_status" in st

    deposit_params = smoke_data.get("deposit", {})
    ok, msg = await strategy.deposit(**deposit_params)
    assert isinstance(ok, bool)
    assert isinstance(msg, str)

    # update() returns (success, message, rotated) - 3 values
    update_result = await strategy.update(**smoke_data.get("update", {}))
    ok = update_result[0]
    assert isinstance(ok, bool)

    ok, msg = await strategy.withdraw(**smoke_data.get("withdraw", {}))
    assert isinstance(ok, bool)


@pytest.mark.asyncio
async def test_canonical_usage(strategy):
    """REQUIRED: Test canonical usage examples from examples.json."""
    await strategy.setup()

    examples = load_strategy_examples(Path(__file__))
    canonical = get_canonical_examples(examples)

    for example_name, example_data in canonical.items():
        if "deposit" in example_data:
            deposit_params = example_data.get("deposit", {})
            ok, _ = await strategy.deposit(**deposit_params)
            assert ok, f"Canonical example '{example_name}' deposit failed"

        if "update" in example_data:
            update_result = await strategy.update()
            ok = update_result[0]
            msg = update_result[1] if len(update_result) > 1 else ""
            assert ok, f"Canonical example '{example_name}' update failed: {msg}"

        if "status" in example_data:
            st = await strategy.status()
            assert isinstance(st, dict), (
                f"Canonical example '{example_name}' status failed"
            )


@pytest.mark.asyncio
async def test_error_cases(strategy):
    """OPTIONAL: Test error scenarios from examples.json."""
    await strategy.setup()

    examples = load_strategy_examples(Path(__file__))

    for example_name, example_data in examples.items():
        if isinstance(example_data, dict) and "expect" in example_data:
            expect = example_data.get("expect", {})

            if "deposit" in example_data:
                deposit_params = example_data.get("deposit", {})
                ok, _ = await strategy.deposit(**deposit_params)

                if expect.get("success") is False:
                    assert ok is False, (
                        f"Expected {example_name} deposit to fail but it succeeded"
                    )
                elif expect.get("success") is True:
                    assert ok is True, (
                        f"Expected {example_name} deposit to succeed but it failed"
                    )


@pytest.mark.asyncio
async def test_below_minimum_deposit(strategy):
    """Test deposit below minimum threshold fails."""
    await strategy.setup()

    ok, msg = await strategy.deposit(main_token_amount=50.0, gas_token_amount=0.01)
    assert ok is False
    assert "minimum" in msg.lower() or "150" in msg


@pytest.mark.asyncio
async def test_opa_loop_structure(strategy):
    """Test OPA loop components are properly configured."""
    await strategy.setup()

    # Verify OPA config
    config = strategy.opa_config
    assert config.max_iterations_per_tick > 0
    assert config.max_steps_per_iteration > 0
    assert config.max_total_steps_per_tick > 0

    # Verify inventory changing ops
    ops = strategy.get_inventory_changing_ops()
    assert len(ops) > 0


@pytest.mark.asyncio
async def test_observe_returns_inventory(strategy):
    """Test observe() returns valid inventory."""
    await strategy.setup()

    inv = await strategy.observe()
    assert inv is not None
    assert hasattr(inv, "hype_hyperevm_balance")
    assert hasattr(inv, "total_value")
    assert hasattr(inv, "hype_price_usd")


@pytest.mark.asyncio
async def test_plan_returns_plan(strategy):
    """Test plan() returns valid plan."""
    await strategy.setup()

    inv = await strategy.observe()
    plan = strategy.plan(inv)

    assert plan is not None
    assert hasattr(plan, "steps")
    assert hasattr(plan, "desired_state")


@pytest.mark.asyncio
async def test_status_returns_expected_fields(strategy):
    """Test status() returns expected fields."""
    await strategy.setup()

    status = await strategy.status()

    assert "portfolio_value" in status
    assert "strategy_status" in status
    assert "gas_available" in status
    assert "gassed_up" in status
