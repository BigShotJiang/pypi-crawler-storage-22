from __future__ import annotations

from unittest.mock import AsyncMock, patch

import pytest

from wayfinder_paths.mcp.tools.quotes import quote_swap


@pytest.mark.asyncio
async def test_quote_swap_returns_compact_best_quote_by_default():
    fake_wallet = {"address": "0x000000000000000000000000000000000000dEaD"}

    class FakeTokenClient:
        async def get_gas_token(self, chain_code: str):
            assert chain_code == "arbitrum"
            return {
                "token_id": "ethereum-arbitrum",
                "asset_id": "ethereum",
                "symbol": "ETH",
                "decimals": 18,
                "chain_id": 42161,
                "address": "0x0000000000000000000000000000000000000000",
            }

        async def get_token_details(self, query: str):
            assert query == "usd-coin-arbitrum"
            return {
                "token_id": "usd-coin-arbitrum",
                "asset_id": "usd-coin",
                "symbol": "USDC",
                "decimals": 6,
                "chain_id": 42161,
                "address": "0xaf88d065e77c8cc2239327c5edb3a432268e5831",
            }

    class FakeBRAPClient:
        async def get_quote(self, **kwargs):  # noqa: ANN003
            assert kwargs["from_chain_id"] == 42161
            assert kwargs["to_chain_id"] == 42161
            assert kwargs["slippage"] == pytest.approx(0.005)

            calldata = "0x" + ("ab" * 4096)
            return {
                "quotes": {
                    "quote_count": 3,
                    "best_quote": {
                        "provider": "brap_best",
                        "input_amount": kwargs["amount1"],
                        "output_amount": "1234567",
                        "input_amount_usd": 5.0,
                        "output_amount_usd": 4.99,
                        "gas_estimate": 210000,
                        "fee_estimate": {"total_usd": 0.01},
                        "native_input": True,
                        "native_output": False,
                        "calldata": calldata,
                        "wrap_transaction": None,
                        "unwrap_transaction": None,
                    },
                    "all_quotes": [
                        {"provider": "brap_best"},
                        {"provider": "brap_alt"},
                        {"provider": "brap_alt"},
                    ],
                }
            }

    with (
        patch(
            "wayfinder_paths.mcp.tools.quotes.find_wallet_by_label",
            return_value=fake_wallet,
        ),
        patch(
            "wayfinder_paths.mcp.tools.quotes.TokenClient",
            return_value=FakeTokenClient(),
        ),
        patch(
            "wayfinder_paths.mcp.tools.quotes.BRAPClient", return_value=FakeBRAPClient()
        ),
    ):
        out = await quote_swap(
            wallet_label="main",
            from_token="ethereum-arbitrum",
            to_token="usd-coin-arbitrum",
            amount="0.0017",
            slippage_bps=50,
        )

    assert out["ok"] is True
    res = out["result"]
    assert "raw" not in res["quote"]

    best = res["quote"]["best_quote"]
    assert best["provider"] == "brap_best"
    assert best["output_amount"] == "1234567"
    assert best["calldata_len"] > 0
    assert "calldata" not in best
    assert res["quote"]["quote_count"] == 3
    assert res["quote"]["providers"] == ["brap_best", "brap_alt"]


@pytest.mark.asyncio
async def test_quote_swap_can_include_calldata_when_requested():
    fake_wallet = {"address": "0x000000000000000000000000000000000000dEaD"}
    token_client = AsyncMock()
    token_client.get_gas_token = AsyncMock(
        return_value={
            "token_id": "ethereum-arbitrum",
            "asset_id": "ethereum",
            "symbol": "ETH",
            "decimals": 18,
            "chain_id": 42161,
            "address": "0x0000000000000000000000000000000000000000",
        }
    )
    token_client.get_token_details = AsyncMock(
        return_value={
            "token_id": "usd-coin-arbitrum",
            "asset_id": "usd-coin",
            "symbol": "USDC",
            "decimals": 6,
            "chain_id": 42161,
            "address": "0xaf88d065e77c8cc2239327c5edb3a432268e5831",
        }
    )

    calldata = "0x" + ("cd" * 1024)
    brap_client = AsyncMock()
    brap_client.get_quote = AsyncMock(
        return_value={
            "quotes": {
                "quote_count": 1,
                "best_quote": {
                    "provider": "brap_best",
                    "output_amount": "1",
                    "calldata": calldata,
                },
                "all_quotes": [{"provider": "brap_best"}],
            }
        }
    )

    with (
        patch(
            "wayfinder_paths.mcp.tools.quotes.find_wallet_by_label",
            return_value=fake_wallet,
        ),
        patch(
            "wayfinder_paths.mcp.tools.quotes.TokenClient", return_value=token_client
        ),
        patch("wayfinder_paths.mcp.tools.quotes.BRAPClient", return_value=brap_client),
    ):
        out = await quote_swap(
            wallet_label="main",
            from_token="ethereum-arbitrum",
            to_token="usd-coin-arbitrum",
            amount="0.0017",
            slippage_bps=50,
            include_calldata=True,
        )

    assert out["ok"] is True
    best = out["result"]["quote"]["best_quote"]
    assert best["calldata"] == calldata
