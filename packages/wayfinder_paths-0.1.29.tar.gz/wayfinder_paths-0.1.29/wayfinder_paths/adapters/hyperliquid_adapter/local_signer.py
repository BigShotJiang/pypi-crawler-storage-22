from typing import Any

from eth_account import Account

from wayfinder_paths.core.types import HyperliquidSignCallback


def _resolve_private_key(config: dict[str, Any]) -> str | None:
    """Extract private key from config."""
    # Try strategy_wallet first
    strategy_wallet = config.get("strategy_wallet", {})
    if isinstance(strategy_wallet, dict):
        pk = strategy_wallet.get("private_key_hex") or strategy_wallet.get(
            "private_key"
        )
        if pk:
            return pk

    # Try main_wallet as fallback (for single-wallet setups)
    main_wallet = config.get("main_wallet", {})
    if isinstance(main_wallet, dict):
        pk = main_wallet.get("private_key_hex") or main_wallet.get("private_key")
        if pk:
            return pk

    return None


def create_local_signer(config: dict[str, Any]) -> HyperliquidSignCallback:
    """
    Create a Hyperliquid signing callback using private key from config.

    For local signing, the payload is a keccak hash (0x...) of the encoded EIP-712 typed data.
    The callback signs with the private key and returns a signature dict.

    Args:
        config: Configuration dict containing private key in strategy_wallet or main_wallet

    Returns:
        HyperliquidSignCallback that signs payloads with the local private key

    Raises:
        ValueError: If no private key found in config
    """
    # Extract private key from config
    private_key = _resolve_private_key(config)
    if not private_key:
        raise ValueError(
            "No private key found in config. "
            "Provide strategy_wallet.private_key_hex or strategy_wallet.private_key"
        )

    # Create account
    pk = private_key if private_key.startswith("0x") else "0x" + private_key
    account: Account = Account.from_key(pk)

    async def sign(
        action: dict[str, Any], payload: str, address: str
    ) -> dict[str, str] | None:
        """
        Sign a Hyperliquid action with local private key.

        For local signing, payload is keccak hash (0x...) of encoded typed data.
        Sign with account and return signature dict.

        Args:
            action: The action being signed (not used for local signing)
            payload: Keccak hash (0x...) of encoded EIP-712 typed data
            address: The address signing (validation check)

        Returns:
            Signature dict {"r": "0x...", "s": "0x...", "v": 28} or None if validation fails
        """
        # Verify address matches account
        if address.lower() != account.address.lower():
            return None

        # Sign the hash
        signed = account.sign_message(payload)
        return {"r": hex(signed.r), "s": hex(signed.s), "v": signed.v}

    return sign
