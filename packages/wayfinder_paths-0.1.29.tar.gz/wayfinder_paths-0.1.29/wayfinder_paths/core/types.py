from collections.abc import Awaitable, Callable
from typing import Any

# EVM transaction signing callback
# Used for signing EVM-compatible transactions (mainnet, Base, Arbitrum, etc.)
# Parameters: transaction dict with to/from/data/value/etc.
# Returns: signed transaction hex string
TransactionSigningCallback = Callable[[dict], Awaitable[str]]

# Hyperliquid signing callback
# Used for signing Hyperliquid actions (orders, transfers, withdrawals, etc.)
# Parameters:
#   - action: dict - The action being signed (order, transfer, etc.)
#   - payload: str - Either JSON string (EIP-712) or keccak hash (local) of typed data
#   - address: str - The address signing the transaction
# Returns: signature dict {"r": "0x...", "s": "0x...", "v": 28} or None if declined
HyperliquidSignCallback = Callable[
    [dict[str, Any], str, str], Awaitable[dict[str, str] | None]
]
