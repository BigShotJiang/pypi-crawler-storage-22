from __future__ import annotations

from typing import Any, Literal

from wayfinder_paths.mcp.utils import err, ok, read_text_excerpt, read_yaml, repo_root


async def discover(
    kind: Literal["adapter", "strategy"],
    detail: Literal["summary", "full"] = "summary",
) -> dict[str, Any]:
    root = repo_root()
    base = (
        root / "wayfinder_paths" / ("adapters" if kind == "adapter" else "strategies")
    )
    if not base.exists():
        return err("not_found", f"Directory not found: {base}")

    items: list[dict[str, Any]] = []
    for child in sorted(base.iterdir()):
        if not child.is_dir():
            continue
        manifest_path = child / "manifest.yaml"
        if not manifest_path.exists():
            continue
        manifest = read_yaml(manifest_path)
        rel_manifest = str(manifest_path.relative_to(root))

        if kind == "adapter":
            item = {
                "name": child.name,
                "entrypoint": manifest.get("entrypoint"),
                "capabilities": manifest.get("capabilities", []),
                "dependencies": manifest.get("dependencies", []),
                "manifest_path": rel_manifest,
            }
        else:
            adapters = manifest.get("adapters", [])
            item = {
                "name": child.name,
                "entrypoint": manifest.get("entrypoint"),
                "adapters": adapters if isinstance(adapters, list) else [],
                "permissions_policy_present": bool(
                    isinstance(manifest.get("permissions"), dict)
                    and (manifest.get("permissions") or {}).get("policy")
                ),
                "manifest_path": rel_manifest,
            }

        if detail == "full":
            readme = read_text_excerpt(child / "README.md")
            if readme:
                item["readme_excerpt"] = readme
            item["manifest"] = manifest

        items.append(item)

    return ok({"kind": kind, "items": items})


async def describe(
    kind: Literal["adapter", "strategy"],
    name: str,
    include_manifest: bool = True,
    include_readme_excerpt: bool = True,
) -> dict[str, Any]:
    root = repo_root()
    base = (
        root / "wayfinder_paths" / ("adapters" if kind == "adapter" else "strategies")
    )
    target = base / name
    if not target.exists():
        return err("not_found", f"Unknown {kind}: {name}")

    manifest_path = target / "manifest.yaml"
    if not manifest_path.exists():
        return err("not_found", f"Missing manifest.yaml for {kind}: {name}")

    out: dict[str, Any] = {"kind": kind, "name": name}
    if include_manifest:
        out["manifest"] = read_yaml(manifest_path)
        out["manifest_path"] = str(manifest_path.relative_to(root))

    if include_readme_excerpt:
        readme = read_text_excerpt(target / "README.md")
        if readme:
            out["readme_excerpt"] = readme

    return ok(out)
