from __future__ import annotations

import re
from typing import Any

from wayfinder_paths.core.clients.BRAPClient import BRAPClient
from wayfinder_paths.core.clients.TokenClient import TokenClient
from wayfinder_paths.core.constants.chains import CHAIN_CODE_TO_ID
from wayfinder_paths.mcp.utils import (
    err,
    find_wallet_by_label,
    normalize_address,
    ok,
    parse_amount_to_raw,
)


def _chain_id(token: dict[str, Any]) -> int | None:
    # Token payloads often include a database/internal `id` field; do not treat that as a chain id.
    if token.get("chain_id") is not None:
        try:
            return int(token.get("chain_id"))
        except (TypeError, ValueError):
            return None

    chain = token.get("chain") or {}
    if not isinstance(chain, dict):
        return None

    for key in ("chain_id", "chainId", "id"):
        if chain.get(key) is None:
            continue
        try:
            return int(chain.get(key))
        except (TypeError, ValueError):
            return None

    return None


_SIMPLE_CHAIN_SUFFIX_RE = re.compile(r"^[a-z0-9]+\s+[a-z0-9-]+$", re.IGNORECASE)
_ASSET_CHAIN_SPLIT_RE = re.compile(
    r"^(?P<asset>[a-z0-9]+)[- _](?P<chain>[a-z0-9-]+)$", re.IGNORECASE
)


def _normalize_token_query(query: str) -> str:
    q = " ".join(str(query).strip().split())
    if not q or "-" in q or "_" in q:
        return q
    if not _SIMPLE_CHAIN_SUFFIX_RE.match(q):
        return q
    asset, chain_code = q.rsplit(" ", 1)
    if chain_code.lower() in CHAIN_CODE_TO_ID:
        return f"{asset}-{chain_code}"
    return q


def _is_eth_like_token(meta: dict[str, Any]) -> bool:
    asset_id = str(meta.get("asset_id") or "").lower()
    symbol = str(meta.get("symbol") or "").lower()
    return asset_id == "ethereum" or symbol == "eth"


def _split_asset_chain(query: str) -> tuple[str, str] | None:
    q = str(query).strip()
    if not q:
        return None
    m = _ASSET_CHAIN_SPLIT_RE.match(q)
    if not m:
        return None
    return m.group("asset").lower(), m.group("chain").lower()


async def _resolve_token_meta(
    token_client: TokenClient,
    *,
    query: str,
) -> tuple[str, dict[str, Any]]:
    q = _normalize_token_query(query)
    split = _split_asset_chain(q)
    if split:
        asset, chain_code = split
        if asset in {"eth", "ethereum"}:
            try:
                gas_meta = await token_client.get_gas_token(chain_code)
                if isinstance(gas_meta, dict) and _is_eth_like_token(gas_meta):
                    return q, gas_meta
            except Exception:
                pass
    meta = await token_client.get_token_details(q)
    return q, meta


def _infer_chain_code_from_query(query: str, meta: dict[str, Any]) -> str | None:
    q = str(query).strip().lower()
    if not q:
        return None

    candidates: set[str] = {str(k).lower() for k in CHAIN_CODE_TO_ID.keys()}
    addrs = meta.get("addresses") or {}
    if isinstance(addrs, dict):
        candidates.update(str(k).lower() for k in addrs.keys())

    best: str | None = None
    for code in candidates:
        if q.endswith(f"-{code}"):
            if best is None or len(code) > len(best):
                best = code
    return best


def _address_for_chain(meta: dict[str, Any], chain_code: str) -> str | None:
    addrs = meta.get("addresses") or {}
    if not isinstance(addrs, dict):
        return None
    for key, val in addrs.items():
        if str(key).lower() == chain_code and val:
            return str(val)
    return None


def _select_token_chain(
    meta: dict[str, Any], *, query: str
) -> tuple[int | None, str | None]:
    chain_id = _chain_id(meta)
    token_address = meta.get("address")

    desired_chain = _infer_chain_code_from_query(query, meta)
    if desired_chain:
        addr = _address_for_chain(meta, desired_chain)
        if addr:
            token_address = addr
        if desired_chain in CHAIN_CODE_TO_ID:
            chain_id = CHAIN_CODE_TO_ID[desired_chain]

    token_address_out = str(token_address).strip() if token_address else None
    return chain_id, token_address_out


def _slippage_float(slippage_bps: int) -> float:
    return max(0.0, float(int(slippage_bps)) / 10_000.0)


async def quote_swap(
    *,
    wallet_label: str,
    from_token: str,
    to_token: str,
    amount: str,
    slippage_bps: int = 50,
    recipient: str | None = None,
    include_calldata: bool = False,
) -> dict[str, Any]:
    w = find_wallet_by_label(wallet_label)
    if not w:
        return err("not_found", f"Unknown wallet_label: {wallet_label}")
    sender = normalize_address(w.get("address"))
    if not sender:
        return err("invalid_wallet", f"Wallet {wallet_label} missing address")

    token_client = TokenClient()
    brap_client = BRAPClient()

    try:
        from_q, from_meta = await _resolve_token_meta(token_client, query=from_token)
        to_q, to_meta = await _resolve_token_meta(token_client, query=to_token)
    except Exception as exc:  # noqa: BLE001
        return err("token_error", str(exc))

    from_chain_id, from_token_addr = _select_token_chain(from_meta, query=from_q)
    to_chain_id, to_token_addr = _select_token_chain(to_meta, query=to_q)
    if from_chain_id is None or to_chain_id is None:
        return err(
            "invalid_token",
            "Could not resolve chain_id for one or more tokens",
            {"from_chain_id": from_chain_id, "to_chain_id": to_chain_id},
        )
    if not from_token_addr or not to_token_addr:
        return err(
            "invalid_token",
            "Could not resolve token address for one or more tokens",
            {"from_token_address": from_token_addr, "to_token_address": to_token_addr},
        )

    decimals = int(from_meta.get("decimals") or 18)
    try:
        amount_raw = parse_amount_to_raw(amount, decimals)
    except ValueError as exc:
        return err("invalid_amount", str(exc))

    rcpt = normalize_address(recipient) or sender
    slip = _slippage_float(slippage_bps)

    try:
        data = await brap_client.get_quote(
            from_token=from_token_addr,
            to_token=to_token_addr,
            from_chain=from_chain_id,
            to_chain=to_chain_id,
            from_wallet=sender,
            from_amount=str(amount_raw),
            slippage=slip,
        )
    except Exception as exc:  # noqa: BLE001
        return err("quote_error", str(exc))

    # API returns {"quotes": [...], "best_quote": {...}} at top level
    raw_quotes = data.get("quotes", []) if isinstance(data, dict) else []
    if not isinstance(raw_quotes, list):
        raw_quotes = []
    all_quotes = raw_quotes
    best_quote = data.get("best_quote") if isinstance(data, dict) else None
    quote_count = len(all_quotes)

    providers: list[str] = []
    seen: set[str] = set()
    for q in all_quotes:
        if not isinstance(q, dict):
            continue
        p = q.get("provider")
        if not p:
            continue
        p_str = str(p)
        if p_str in seen:
            continue
        seen.add(p_str)
        providers.append(p_str)

    best_out: dict[str, Any] | None = None
    if isinstance(best_quote, dict):
        calldata = best_quote.get("calldata")
        calldata_len = len(calldata) if calldata else 0

        best_out = {
            "provider": best_quote.get("provider"),
            "input_amount": best_quote.get("input_amount"),
            "output_amount": best_quote.get("output_amount"),
            "input_amount_usd": best_quote.get("input_amount_usd"),
            "output_amount_usd": best_quote.get("output_amount_usd"),
            "gas_estimate": best_quote.get("gas_estimate"),
            "fee_estimate": best_quote.get("fee_estimate"),
            "native_input": best_quote.get("native_input"),
            "native_output": best_quote.get("native_output"),
            "error": best_quote.get("error"),
        }

        # Strip data fields from wrap/unwrap transactions to reduce response size
        wrap_tx = best_quote.get("wrap_transaction")
        if isinstance(wrap_tx, dict):
            best_out["wrap_transaction"] = {
                k: v for k, v in wrap_tx.items() if k != "data"
            }
        unwrap_tx = best_quote.get("unwrap_transaction")
        if isinstance(unwrap_tx, dict):
            best_out["unwrap_transaction"] = {
                k: v for k, v in unwrap_tx.items() if k != "data"
            }

        if include_calldata:
            best_out["calldata"] = calldata
        else:
            best_out["calldata_len"] = calldata_len

    preview = (
        f"Swap {amount} {from_meta.get('symbol')} → {to_meta.get('symbol')} "
        f"(chain {from_chain_id} → {to_chain_id}). "
        f"Sender={sender} Recipient={rcpt}. Slippage={slip:.2%}."
    )
    if rcpt.lower() != sender.lower():
        preview = "⚠ RECIPIENT DIFFERS FROM SENDER\n" + preview

    from_token_id = from_meta.get("token_id") or from_q
    to_token_id = to_meta.get("token_id") or to_q

    result = {
        "preview": preview,
        "quote": {
            "best_quote": best_out,
            "quote_count": quote_count,
            "providers": providers,
        },
        "from_token": from_meta.get("symbol"),
        "to_token": to_meta.get("symbol"),
        "amount": str(amount),
        "slippage_bps": int(slippage_bps),
        "suggested_execute_request": {
            "kind": "swap",
            "wallet_label": wallet_label,
            "from_token": from_token_id,
            "to_token": to_token_id,
            "amount": str(amount),
            "slippage_bps": int(slippage_bps),
            "recipient": rcpt,
        },
    }

    return ok(result)
