from django.apps import AppConfig


class WbaccountingConfig(AppConfig):
    name = "wbaccounting"
