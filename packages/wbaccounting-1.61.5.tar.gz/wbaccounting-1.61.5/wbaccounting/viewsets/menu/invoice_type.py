from wbcore.menus import ItemPermission, MenuItem

INVOICETYPE_MENUITEM = MenuItem(
    label="Invoice Types",
    endpoint="wbaccounting:invoicetype-list",
    permission=ItemPermission(
        method=lambda request: request.user.is_internal, permissions=["wbaccounting.view_invoicetype"]
    ),
    add=MenuItem(
        label="Create Invoice Type",
        endpoint="wbaccounting:invoicetype-list",
        permission=ItemPermission(permissions=["wbaccounting.add_invoicetype"]),
    ),
)
