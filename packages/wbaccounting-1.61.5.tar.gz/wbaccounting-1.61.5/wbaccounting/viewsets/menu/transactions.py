from wbcore.menus import ItemPermission, MenuItem

TRANSACTION_MENUITEM = MenuItem(
    label="Transactions",
    endpoint="wbaccounting:transaction-list",
    permission=ItemPermission(
        method=lambda request: request.user.is_internal, permissions=["wbaccounting.view_transaction"]
    ),
    add=MenuItem(
        label="Create Transaction",
        endpoint="wbaccounting:transaction-list",
        permission=ItemPermission(permissions=["wbaccounting.add_transaction"]),
    ),
)
