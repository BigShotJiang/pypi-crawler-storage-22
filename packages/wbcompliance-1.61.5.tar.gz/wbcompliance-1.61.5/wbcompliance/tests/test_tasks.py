import pytest
from wbcore.contrib.notifications.models import Notification

from wbcompliance.tasks import send_reminder_of_unsigned_compliance_form


@pytest.mark.django_db
class TestComplianceForm:
    def test_send_reminder_of_unsigned_compliance_form(
        self, compliance_form_factory, compliance_form_signature_factory
    ):
        cf1 = compliance_form_factory.create()
        cf2 = compliance_form_factory.create()
        cf3 = compliance_form_factory.create()

        compliance_form_signature_factory.create(compliance_form=cf1, signed=None)
        compliance_form_signature_factory.create(compliance_form=cf1, version=1, signed=None)
        compliance_form_signature_factory.create(compliance_form=cf2)
        compliance_form_signature_factory.create(compliance_form=cf3, signed=None)

        assert Notification.objects.count() == 0
        send_reminder_of_unsigned_compliance_form(compliance_form_ids=[cf1.id, cf2.id])
        assert Notification.objects.filter(
            title=f"Unsigned Compliance Form - {cf1.form_type} Reminder : {cf1.title}"
        ).exists()
        assert Notification.objects.filter(
            title=f"Unsigned Compliance Form - {cf2.form_type} Reminder : {cf2.title}"
        ).exists()
