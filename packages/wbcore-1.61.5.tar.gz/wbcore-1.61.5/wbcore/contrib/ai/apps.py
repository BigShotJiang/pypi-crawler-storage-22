from django.apps import AppConfig


class AIAppConfig(AppConfig):
    name = "wbcore.contrib.ai"
