from .user_activities import (
    UserActivityModelEndpointConfig,
    UserActivityTableEndpointConfig,
    UserActivityUserModelEndpointConfig,
)
from .users import UserPermissionsModelEndpointConfig, UserProfileModelEndpointConfig
