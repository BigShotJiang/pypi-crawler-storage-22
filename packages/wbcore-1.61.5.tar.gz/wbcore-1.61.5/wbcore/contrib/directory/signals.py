from django.dispatch import Signal

deactivate_profile = Signal()  # "instance", "substitute_profile"
