from wbcore.menus import ItemPermission, MenuItem

ClassificationMenuItem = MenuItem(
    label="Classification",
    endpoint="wbfdm:classification-list",
    permission=ItemPermission(
        permissions=["wbfdm.view_classification"],
        method=lambda request: request.user.is_internal,
    ),
)
ClassificationGroupMenuItem = MenuItem(
    label="Classification Group",
    endpoint="wbfdm:classificationgroup-list",
    permission=ItemPermission(
        permissions=["wbfdm.view_classificationgroup"],
        method=lambda request: request.user.is_internal,
    ),
)
