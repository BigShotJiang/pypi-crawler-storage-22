from wbcore.menus import ItemPermission, MenuItem

ExchangeMenuItem = MenuItem(
    label="Exchange",
    endpoint="wbfdm:exchange-list",
    permission=ItemPermission(permissions=["wbfdm.view_exchange"], method=lambda request: request.user.is_internal),
)
