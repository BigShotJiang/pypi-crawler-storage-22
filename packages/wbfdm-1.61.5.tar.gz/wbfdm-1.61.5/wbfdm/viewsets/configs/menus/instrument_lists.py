from wbcore.menus import ItemPermission, MenuItem

INSTRUMENT_LIST_MENUITEM = MenuItem(
    label="Instrument Lists",
    endpoint="wbfdm:instrumentlist-list",
    permission=ItemPermission(
        method=lambda request: request.user.is_internal, permissions=["wbfdm.view_instrumentlist"]
    ),
)
