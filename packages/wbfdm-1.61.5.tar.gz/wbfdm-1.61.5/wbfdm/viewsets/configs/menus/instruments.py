from wbcore.menus import ItemPermission, MenuItem

INSTRUMENT_MENUITEM = MenuItem(
    label="Instrument",
    endpoint="wbfdm:instrument-list",
    endpoint_get_parameters={"parent__isnull": True},
    permission=ItemPermission(method=lambda request: request.user.is_internal, permissions=["wbfdm.view_instrument"]),
)

INVESTABLE_UNIVERSE_MENUITEM = MenuItem(
    label="Investable Universe",
    endpoint="wbfdm:instrument-list",
    endpoint_get_parameters={"is_investable_universe": True},
    permission=ItemPermission(method=lambda request: request.user.is_internal, permissions=["wbfdm.view_instrument"]),
)
