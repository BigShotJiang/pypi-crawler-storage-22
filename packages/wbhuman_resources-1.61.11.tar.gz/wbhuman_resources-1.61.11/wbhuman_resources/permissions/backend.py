from django.db.models import Q, QuerySet
from wbcore.contrib.authentication.models.users import User
from wbcore.contrib.permission.internal.backend import UserBackend as BaseUserBackend

from wbhuman_resources.models.employee import EmployeeHumanResource


class UserBackend(BaseUserBackend):
    """
    The UserBackend proposed by the human resources module
    """

    def get_internal_users(self) -> "QuerySet[User]":
        """
        Get internal users defined by the human resources module

        Returns:
            A queryset of users
        """
        internal_employee_profiles = EmployeeHumanResource.active_internal_employees.all()
        base_internal_users = super().get_internal_users()
        return User.objects.filter(
            Q(profile__in=internal_employee_profiles.values("profile")) | Q(id__in=base_internal_users.values("id"))
        )
