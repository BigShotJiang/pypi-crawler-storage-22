from .claim import ClaimModelAdmin
from .dividends import DividendAdmin
from .fees import FeesAdmin
from .trades import TradeAdmin
