from wbcore.menus import ItemPermission, MenuItem

VALUATIONDATAAUM_MENUITEM = MenuItem(
    label="AuM Chart",
    endpoint="wbportfolio:aumchart-list",
    permission=ItemPermission(
        method=lambda request: request.user.is_internal, permissions=["wbportfolio.view_portfolio"]
    ),
)
