from wbcore.menus import ItemPermission, MenuItem

PRODUCTPERFORMANCELIST_MENUITEM = MenuItem(
    label="Performances",
    endpoint="wbportfolio:productperformance-list",
    permission=ItemPermission(
        method=lambda request: request.user.is_internal, permissions=["wbportfolio.view_product"]
    ),
)

PRODUCTPERFORMANCECOMPARISONLIST_MENUITEM = MenuItem(
    label="Performances Summary",
    endpoint="wbportfolio:productperformancecomparison-list",
    permission=ItemPermission(
        method=lambda request: request.user.is_internal, permissions=["wbportfolio.view_product"]
    ),
)
PRODUCTPERFORMANCENNMLIST_MENUITEM = MenuItem(
    label="Net new money",
    endpoint="wbportfolio:productperformancennmlist-list",
    permission=ItemPermission(
        method=lambda request: request.user.is_internal, permissions=["wbportfolio.view_product"]
    ),
)
