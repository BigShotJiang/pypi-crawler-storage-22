from wbcore.menus import ItemPermission, MenuItem

TASK_MENUITEM = MenuItem(
    label="Tasks",
    endpoint="wbtasks:task-list",
    add=MenuItem(label="Create Task", endpoint="wbtasks:task-list"),
    permission=ItemPermission(method=lambda request: request.user.is_internal, permissions=["wbtasks.view_task"]),
)
