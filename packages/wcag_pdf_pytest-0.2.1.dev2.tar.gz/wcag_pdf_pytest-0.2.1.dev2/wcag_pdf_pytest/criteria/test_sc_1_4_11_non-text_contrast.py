import pytest

from wcag_pdf_pytest.pdf_inspector import SCResult, evaluate_sc

SC_NUM = "1.4.11"
SC_TITLE = "Non-text Contrast"
SC_LEVEL = "AA"
SC_APPLICABILITY = "Applies"
SC_NOTES = "UI components and graphical objects (e.g., form controls) must meet 3:1 contrast."


@pytest.mark.wcag21
@pytest.mark.AA
def test_sc_1_4_11_non_text_contrast(wcag_pdf_paths, wcag_context):
    assert wcag_pdf_paths, "No --wcag-pdf provided."
    res = evaluate_sc(SC_NUM, SC_TITLE, SC_LEVEL, wcag_pdf_paths, SC_APPLICABILITY, SC_NOTES)
    assert isinstance(res, SCResult)
    assert res.passed, res.reason
