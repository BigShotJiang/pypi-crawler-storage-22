import pytest

from wcag_pdf_pytest.pdf_inspector import SCResult, evaluate_sc

SC_NUM = "1.4.5"
SC_TITLE = "Images of Text"
SC_LEVEL = "AA"
SC_APPLICABILITY = "Applies"
SC_NOTES = "Avoid images of text in PDFs, except for essential cases (e.g., logos)."


@pytest.mark.wcag21
@pytest.mark.AA
def test_sc_1_4_5___(wcag_pdf_paths, wcag_context):
    """WCAG 2.1 SC 1.4.5: Images of Text (Level AA).
    Automated heuristic for static PDFs:
      - 1.3.x: Tagging presence used to infer structure/sequence; others treated N/A.
      - 1.4.x (≤1.4.9): Media/color ops scanned;
        images-of-text flagged if images exist.
    """
    assert wcag_pdf_paths, "No --wcag-pdf provided."
    res = evaluate_sc(SC_NUM, SC_TITLE, SC_LEVEL, wcag_pdf_paths, SC_APPLICABILITY, SC_NOTES)
    assert isinstance(res, SCResult)
    assert res.passed, res.reason
