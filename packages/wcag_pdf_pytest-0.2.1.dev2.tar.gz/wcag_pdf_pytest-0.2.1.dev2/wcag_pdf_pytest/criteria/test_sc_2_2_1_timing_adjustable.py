import pytest

from wcag_pdf_pytest.pdf_inspector import SCResult, evaluate_sc

SC_NUM = "2.2.1"
SC_TITLE = "Timing Adjustable"
SC_LEVEL = "A"
SC_APPLICABILITY = "Depends"
SC_NOTES = "Applies if the PDF imposes time limits (uncommon for static PDFs)."


@pytest.mark.wcag21
@pytest.mark.A
def test_sc_2_2_1_timing_adjustable(wcag_pdf_paths, wcag_context):
    assert wcag_pdf_paths, "No --wcag-pdf provided."
    res = evaluate_sc(SC_NUM, SC_TITLE, SC_LEVEL, wcag_pdf_paths, SC_APPLICABILITY, SC_NOTES)
    assert isinstance(res, SCResult)
    assert res.passed, res.reason
