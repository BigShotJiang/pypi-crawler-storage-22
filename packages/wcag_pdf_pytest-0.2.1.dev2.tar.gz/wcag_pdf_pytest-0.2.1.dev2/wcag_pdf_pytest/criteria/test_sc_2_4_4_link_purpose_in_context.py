import pytest

from wcag_pdf_pytest.pdf_inspector import SCResult, evaluate_sc

SC_NUM = "2.4.4"
SC_TITLE = "Link Purpose (In Context)"
SC_LEVEL = "A"
SC_APPLICABILITY = "Applies"
SC_NOTES = "Ensure link purpose is clear from link text and its context."


@pytest.mark.wcag21
@pytest.mark.A
def test_sc_2_4_4____(wcag_pdf_paths, wcag_context):
    assert wcag_pdf_paths, "No --wcag-pdf provided."
    res = evaluate_sc(SC_NUM, SC_TITLE, SC_LEVEL, wcag_pdf_paths, SC_APPLICABILITY, SC_NOTES)
    assert isinstance(res, SCResult)
    assert res.passed, res.reason
