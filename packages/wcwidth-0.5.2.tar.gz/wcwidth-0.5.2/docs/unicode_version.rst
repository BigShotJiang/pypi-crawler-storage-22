=====================
Unicode release files
=====================

This library aims to be forward-looking, portable, and most correct.
The most current release of this API is based on the Unicode Standard
release files:


``DerivedGeneralCategory-17.0.0.txt``
  *Date: 2025-07-24, 00:12:50 GMT*

``EastAsianWidth-17.0.0.txt``
  *Date: 2025-07-24, 00:12:54 GMT*

``emoji-variation-sequences-12.0.0.txt``
  *Date: 2019-01-15, 12:10:05 GMT*

``emoji-variation-sequences-17.0.0.txt``
  *Date: 2025-01-30, 21:48:29 GMT*

