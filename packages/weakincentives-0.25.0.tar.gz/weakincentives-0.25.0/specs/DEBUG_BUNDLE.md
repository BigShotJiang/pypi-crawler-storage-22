# Debug Bundle Specification

## Purpose

A debug bundle is a self-contained zip archive capturing everything needed to
understand, reproduce, and debug an AgentLoop execution. Bundles unify session
state, logs, filesystem snapshots, configuration, and metrics into a single
portable artifact.

**Implementation:**

- Bundle core: `src/weakincentives/debug/bundle.py`
- Environment capture: `src/weakincentives/debug/environment.py`
- Public API: `src/weakincentives/debug/__init__.py`
- EvalLoop integration: `src/weakincentives/evals/_loop.py`

## Principles

- **Zero-configuration capture**: Automatic bundling during AgentLoop execution
- **Self-contained**: All context for diagnosis lives in one file
- **Portable**: Readable with standard tools (unzip, text editor, jq)
- **Deterministic layout**: Predictable structure enables tooling
- **Streaming writes**: Incremental capture minimizes memory footprint
- **Atomic creation**: Bundle either fully created or not present
- **Graceful degradation**: Capture failures logged, never fail the request

## Bundle Format

All bundles contain a single `debug_bundle/` root directory. Timestamps use
ISO-8601 UTC throughout.

### Directory Layout

```
debug_bundle/
  manifest.json           # Bundle metadata and integrity
  README.txt              # Human-readable navigation guide
  request/
    input.json            # AgentLoop request
    output.json           # AgentLoop response
  session/
    before.jsonl          # Session state before execution
    after.jsonl           # Session state after execution
  logs/
    app.jsonl             # All structured log records during execution (incl. transcript events when available)
  environment/            # Reproducibility envelope
    system.json           # OS, kernel, arch, CPU, memory
    python.json           # Python version, executable, venv info
    packages.txt          # Installed packages (pip freeze)
    env_vars.json         # Environment variables (filtered/redacted)
    git.json              # Repo root, commit, branch, remotes
    git.diff              # Uncommitted changes (if any)
    command.txt           # argv, working dir, entrypoint
    container.json        # Container runtime info (if applicable)
  config.json             # AgentLoop and adapter configuration
  run_context.json        # Execution context (IDs, tracing)
  metrics.json            # Token usage, timing, budget state
  prompt_overrides.json   # Visibility overrides (if any)
  error.json              # Error details (if failed)
  eval.json               # Eval metadata (EvalLoop only)
  filesystem/             # Workspace snapshot (if captured)
    ...
```

### Artifact Requirements

| Artifact | Required | Description |
|----------|----------|-------------|
| `manifest.json` | Yes | Version, bundle ID, file list, integrity checksums |
| `README.txt` | Yes | Generated navigation guide |
| `request/input.json` | Yes | Canonical AgentLoop input |
| `request/output.json` | Yes | Canonical AgentLoop output |
| `session/before.jsonl` | No | Pre-execution session snapshot |
| `session/after.jsonl` | Yes | Post-execution session snapshot |
| `logs/app.jsonl` | Yes | Structured log records with request correlation (and transcript events when emitted) |
| `environment/` | No | Reproducibility envelope (system, Python, packages, git) |
| `config.json` | Yes | AgentLoop, adapter, prompt configuration |
| `run_context.json` | Yes | Run/request/session IDs, tracing spans |
| `metrics.json` | Yes | Timing phases, token consumption, budget |
| `prompt_overrides.json` | No | Visibility overrides accumulated during execution |
| `error.json` | No | Exception type, phase, traceback, context |
| `eval.json` | No | Sample ID, experiment, score, judge output |
| `filesystem/` | No | Workspace files preserving directory structure |

### Manifest Schema

```json
{
  "format_version": "1.0.0",
  "bundle_id": "uuid",
  "created_at": "2024-01-15T10:30:00+00:00",
  "request": {
    "request_id": "uuid",
    "session_id": "uuid",
    "status": "success|error",
    "started_at": "...",
    "ended_at": "..."
  },
  "capture": {
    "mode": "full",
    "trigger": "config|env|request",
    "limits_applied": { "filesystem_truncated": false }
  },
  "prompt": { "ns": "...", "key": "...", "adapter": "..." },
  "files": ["manifest.json", "..."],
  "integrity": {
    "algorithm": "sha256",
    "checksums": { "request/input.json": "abc123..." }
  },
  "build": { "version": "1.42.0", "commit": "abc123" }
}
```

## API

### BundleConfig

Configuration for bundle creation. See `src/weakincentives/debug/bundle.py`
for the full dataclass definition.

| Field | Type | Default | Description |
|-------|------|---------|-------------|
| `target` | `Path \| None` | `None` | Output directory |
| `max_file_size` | `int` | `10_000_000` | Skip files > 10MB |
| `max_total_size` | `int` | `52_428_800` | Max filesystem capture (50MB) |
| `compression` | `str` | `"deflate"` | Zip compression method |
| `retention` | `BundleRetentionPolicy \| None` | `None` | Local cleanup policy |
| `storage_handler` | `BundleStorageHandler \| None` | `None` | External storage callback |

The `enabled` property returns `True` when `target is not None`. Bundles always
capture full debug information: DEBUG logs, session before+after, and all
filesystem contents within size limits.

### BundleRetentionPolicy

Policy for cleaning up old debug bundles in the target directory.
See `src/weakincentives/debug/bundle.py` for the full dataclass definition.

| Field | Type | Default | Description |
|-------|------|---------|-------------|
| `max_bundles` | `int \| None` | `None` | Keep at most N bundles (oldest deleted first) |
| `max_age_seconds` | `int \| None` | `None` | Delete bundles older than this |
| `max_total_bytes` | `int \| None` | `None` | Keep total size under limit (oldest deleted first) |

Retention is applied **after** each bundle is successfully created. If multiple
limits are configured, all are enforced (most restrictive wins). Bundle age is
determined from the `created_at` field in the manifest. Deletion uses TOCTOU
protection via inode/device verification to prevent race conditions.

```python
from weakincentives.debug import BundleConfig, BundleRetentionPolicy

config = BundleConfig(
    target=Path("./debug/"),
    retention=BundleRetentionPolicy(
        max_bundles=10,           # Keep last 10 bundles
        max_age_seconds=86400,    # Delete bundles older than 24 hours
    ),
)
```

### BundleStorageHandler

Runtime-checkable protocol for copying bundles to external storage after creation.
See `src/weakincentives/debug/bundle.py` for the protocol definition.

The handler receives `(bundle_path: Path, manifest: BundleManifest)` and is called
**after** retention policy is applied, so only bundles that survive cleanup are
passed to the handler. Errors are logged but do not propagate (non-blocking).

Example S3 handler:

```python
@dataclass
class S3StorageHandler:
    bucket: str
    prefix: str = "debug-bundles/"

    def store_bundle(self, bundle_path: Path, manifest: BundleManifest) -> None:
        key = f"{self.prefix}{manifest.bundle_id}.zip"
        s3_client.upload_file(str(bundle_path), self.bucket, key)

config = BundleConfig(
    target=Path("./debug/"),
    storage_handler=S3StorageHandler(bucket="my-bucket"),
)
```

### BundleWriter

Context manager for streaming bundle creation. See
`src/weakincentives/debug/bundle.py` for the full class definition.

Key methods: `write_session_before()`, `write_session_after()`,
`write_request_input()`, `write_request_output()`, `capture_logs()` (context
manager), `write_environment()`, `write_filesystem()`, `write_config()`,
`write_run_context()`, `write_metrics()`, `write_error()`, `write_metadata()`,
`write_prompt_overrides()`, `set_prompt_info()`.

The `write_metadata(name, data)` method provides a generic mechanism for adding
domain-specific metadata (e.g., `eval.json`) without coupling the bundle layer.

```python
with BundleWriter(target="./debug/", bundle_id=run_id) as writer:
    writer.write_session_before(session)
    writer.write_request_input(request)
    with writer.capture_logs():
        response = adapter.evaluate(prompt, session=session)
    writer.write_session_after(session)
    writer.write_request_output(response)
    writer.write_environment()  # Capture reproducibility envelope
    writer.write_filesystem(fs)
    writer.write_config(config)
    writer.write_run_context(run_context)
    writer.write_metrics(metrics)
    if error:
        writer.write_error(error)
# Bundle finalized on exit: README generated, checksums computed, zip created
```

### DebugBundle

Load and inspect existing bundles. See `src/weakincentives/debug/bundle.py`
for the full class definition.

Properties: `manifest`, `path`, `request_input`, `request_output`,
`session_before`, `session_after`, `logs`, `config`, `run_context`, `metrics`,
`prompt_overrides`, `error`, `eval`, `environment`.

Methods: `load()` (classmethod), `read_file()`, `list_files()`, `extract()`,
`verify_integrity()`.

```python
bundle = DebugBundle.load("./debug/bundle.zip")
print(bundle.manifest)
print(bundle.metrics)
print(bundle.session_after)
```

## AgentLoop Integration

### Configuration

`AgentLoopConfig` gains a `debug_bundle` field. When set, AgentLoop automatically
creates a bundle for each execution:

```python
loop = CodeReviewLoop(
    adapter=adapter,
    requests=requests,
    config=AgentLoopConfig(
        debug_bundle=BundleConfig(target=Path("./debug/")),
    ),
)
```

Per-request override via `AgentLoopRequest.debug_bundle`.

### Execution Flow

```
AgentLoop._handle_message()
  ├─ _build_run_context()
  ├─ BundleWriter(target, bundle_id)  # if configured
  │    ├─ write_session_before()
  │    ├─ write_request_input()
  │    ├─ capture_logs() → adapter.evaluate()
  │    ├─ write_session_after()
  │    ├─ write_environment()
  │    ├─ write_filesystem()
  │    ├─ write_config(), write_run_context(), write_metrics()
  │    ├─ write_error()  # if failed
  │    └─ __exit__() finalizes bundle:
  │         ├─ Generate README, compute checksums, create ZIP
  │         ├─ Atomic rename to target directory
  │         ├─ Apply retention policy (delete old bundles)
  │         └─ Call storage_handler.store_bundle() (if configured)
  └─ Return AgentLoopResult(bundle_path=writer.path)
```

### Post-Creation Lifecycle

After the bundle ZIP is finalized and atomically moved to the target directory:

1. **Retention enforcement**: If `BundleConfig.retention` is set, scan the target
   directory and delete bundles that exceed configured limits. Deletion order is
   oldest-first based on manifest `created_at`.

1. **Storage handler invocation**: If `BundleConfig.storage_handler` is set, call
   `store_bundle(bundle_path, manifest)`. Errors are logged at WARNING level but
   do not fail the request or affect the local bundle.

Both steps are non-blocking: failures are logged but do not propagate exceptions.

### Result Extension

`AgentLoopResult` gains `bundle_path: Path | None` for accessing the created
bundle.

## EvalLoop Integration

EvalLoop wraps AgentLoop for evaluation datasets. When `EvalLoopConfig.debug_bundle`
is set to a `BundleConfig` with a `target` directory, EvalLoop uses
`AgentLoop.execute_with_bundle()` to reuse the standard bundle creation logic with
eval-specific metadata:

1. EvalLoop creates bundle target at `{target}/{request_id}/`
1. AgentLoop creates bundle capturing session, logs, request/response
1. EvalLoop injects `eval.json` with score, experiment, latency
1. Bundle path returned in `EvalResult.bundle_path`

### eval.json Schema

```json
{
  "sample_id": "sample-123",
  "experiment_name": "baseline",
  "score": {
    "value": 0.85,
    "passed": true,
    "reason": "Found expected answer"
  },
  "latency_ms": 1500,
  "error": null
}
```

### EvalLoopConfig

| Field | Type | Default | Description |
|-------|------|---------|-------------|
| `lease_extender` | `LeaseExtenderConfig \| None` | `None` | Automatic message visibility extension |
| `debug_bundle` | `BundleConfig \| None` | `None` | Debug bundle creation per sample |

See `src/weakincentives/evals/_loop.py` for the full `EvalLoopConfig` and `EvalLoop`
implementation.

### Example

```python
eval_loop = EvalLoop(
    loop=agent_loop,
    evaluator=exact_match,
    requests=requests_mailbox,
    config=EvalLoopConfig(
        debug_bundle=BundleConfig(target=Path("./eval_bundles/")),
    ),
)

# After evaluation:
# result.bundle_path == Path("./eval_bundles/{request_id}/{bundle_id}_{timestamp}.zip")
```

## CLI

### Commands

```bash
wink debug <bundle.zip>            # Open bundle in web UI
wink debug <directory>             # Open most recent bundle in directory
wink query <bundle.zip> "SELECT * FROM manifest"  # SQL query against bundle
wink query <bundle.zip> --schema   # Show database schema
```

Options:

| Option | Default | Description |
|--------|---------|-------------|
| `--host` | `127.0.0.1` | Host interface to bind |
| `--port` | `8000` | Port to bind |
| `--no-open-browser` | | Disable automatic browser open |

### Web UI Panels

| Panel | Source | Description |
|-------|--------|-------------|
| Overview | `manifest.json` | Bundle summary, navigation |
| Request | `request/*.json` | Input/output inspector |
| Slices | `session/*.jsonl` | Session state browser by slice type |
| Logs | `logs/app.jsonl` | Searchable, filterable log viewer |
| Files | `filesystem/` | File tree with content |
| Config | `config.json` | Configuration inspector |
| Metrics | `metrics.json` | Performance dashboard |
| Error | `error.json` | Error details (if present) |

### API Routes

| Route | Description |
|-------|-------------|
| `/api/meta` | Bundle metadata summary |
| `/api/manifest` | Full bundle manifest |
| `/api/request/input` | Request input data |
| `/api/request/output` | Request output data |
| `/api/slices/{type}` | Slice items (paginated) |
| `/api/logs` | Log entries (paginated, filterable by level) |
| `/api/files` | Filesystem listing |
| `/api/files/{path}` | File content |
| `/api/config` | Configuration |
| `/api/metrics` | Metrics |
| `/api/error` | Error details |
| `/api/bundles` | List bundles in directory |
| `/api/switch` | Switch to different bundle |
| `/api/reload` | Reload current bundle |

## Bundle Naming

Standard: `{bundle_id}_{timestamp}.zip`

EvalLoop: `{request_id}/{bundle_id}_{timestamp}.zip`

## Public API

```python
from weakincentives.debug import (
    # Bundle creation and inspection
    BundleWriter,
    BundleConfig,
    DebugBundle,
    BundleManifest,
    BundleError,
    BundleValidationError,
    # Retention and storage
    BundleRetentionPolicy,
    BundleStorageHandler,
    # Environment capture
    capture_environment,
    EnvironmentCapture,
    SystemInfo,
    PythonInfo,
    GitInfo,
    CommandInfo,
    ContainerInfo,
)
```

## Invariants

1. **Atomic creation**: Bundle either fully created or absent
1. **Immutable**: No modification after creation
1. **Single root**: Zip contains only `debug_bundle/` directory
1. **Valid manifest**: Every bundle has well-formed `manifest.json`
1. **Integrity verification**: Checksums enable artifact verification
1. **Deterministic ordering**: JSONL files ordered by timestamp
1. **Retention before storage**: Retention policy runs before storage handler
1. **Non-blocking lifecycle**: Retention and storage failures never fail the request

## Security Considerations

Bundles may contain sensitive data: API keys in logs, proprietary code in
filesystem snapshots, PII in inputs. Recommendations:

- Review before sharing externally
- Store with appropriate access controls
- Disable filesystem capture via `WEAKINCENTIVES_DEBUG_BUNDLE_NO_FS=1` for sensitive workspaces

## Limitations

- **Filesystem size**: Large workspaces produce large bundles
- **Memory**: Log capture buffers before writing
- **Concurrency**: One bundle per AgentLoop execution
- **No automatic redaction**: Manual review required for sensitive data

## Related Specifications

- `specs/AGENT_LOOP.md` - Execution flow
- `specs/SESSIONS.md` - Session snapshots
- `specs/LOGGING.md` - Log record format
- `specs/RUN_CONTEXT.md` - Execution metadata
- `specs/FILESYSTEM.md` - Workspace abstraction
- `specs/EVALS.md` - Evaluation framework
