# Guardrails Specification

## Purpose

Guardrails ensure agents operate within constraints while preserving reasoning
autonomy. Three complementary mechanisms--tool policies, feedback providers, and
task completion checking--enforce invariants, provide guidance, and verify goals.

**Philosophy:** See `POLICIES_OVER_WORKFLOWS.md` for design rationale.

## Overview

| Mechanism | Role | Enforcement |
|-----------|------|-------------|
| Tool Policies | Gate tool invocations | Hard block (fail-closed) |
| Feedback Providers | Soft guidance over time | Advisory (agent decides) |
| Task Completion | Verify goals before stopping | Block early termination |

______________________________________________________________________

## Tool Policies

**Implementation:** `src/weakincentives/prompt/policy.py`

Policies enforce sequential dependencies between tool invocations. Declares
that tool B requires tool A first--unconditionally or keyed by parameter.

### Principles

- **Prompt-scoped declaration**: Bound to prompts alongside tools
- **Session-scoped state**: Invocation history in session slices
- **Composable**: Multiple policies can govern same tool; all must allow
- **Fail-closed**: Denied calls return error without executing

### ToolPolicy Protocol

| Method/Property | Description |
|-----------------|-------------|
| `name` | Unique identifier |
| `check(tool, params, *, context)` | Returns `PolicyDecision` |
| `on_result(tool, params, result, *, context)` | Update state after success |

### PolicyDecision

| Field | Type | Description |
|-------|------|-------------|
| `allowed` | `bool` | Whether to proceed |
| `reason` | `str \| None` | Denial explanation |

### PolicyState (Session Slice)

| Field | Type | Description |
|-------|------|-------------|
| `policy_name` | `str` | Policy identifier |
| `invoked_tools` | `frozenset[str]` | Successfully invoked tools |
| `invoked_keys` | `frozenset[tuple[str, str]]` | (tool, key) pairs |

### Built-in Policies

#### SequentialDependencyPolicy

Unconditional tool ordering: tool B requires tool A to have succeeded.

```python
policy = SequentialDependencyPolicy(
    dependencies={
        "deploy": frozenset({"test", "build"}),
        "build": frozenset({"lint"}),
    }
)
```

#### ReadBeforeWritePolicy

Parameter-keyed dependency for filesystem tools. Existing files must be read
before overwritten. New files can be created freely.

```python
policy = ReadBeforeWritePolicy()
# write_file("new.txt")      -> OK (doesn't exist)
# write_file("config.yaml")  -> DENIED (exists, not read)
# read_file("config.yaml")   -> OK (records path)
# write_file("config.yaml")  -> OK (was read)
```

### Policy Integration

```python
template = PromptTemplate(
    sections=[
        MarkdownSection(
            tools=[read_file, write_file],
            policies=[ReadBeforeWritePolicy()],
        ),
        MarkdownSection(
            tools=[lint, test, build, deploy],
            policies=[SequentialDependencyPolicy(dependencies={...})],
        ),
    ],
    policies=[...],  # Prompt-level policies
)
```

### Execution Flow

Policy enforcement happens in the adapter's tool execution hooks.
See `TOOLS.md` (Runtime Dispatch section) for the full dispatch sequence.

### Policy State Management

- **Snapshot/restore**: State captured with session snapshots
- **Reset**: `session.reset()` clears policy state
- **Isolation**: Each session has independent state

### Limitations

- **Synchronous**: Policy checks run on tool execution thread
- **Session-scoped**: No cross-session persistence
- **No rollback notification**: Policies not notified on restore

______________________________________________________________________

## Feedback Providers

**Implementation:** `src/weakincentives/prompt/feedback.py`

Deliver ongoing progress feedback to agents during unattended execution. Analyze
patterns over time and inject guidance into context for soft course-correction.

Unlike tool policies that gate calls, feedback providers observe trajectory and
produce contextual feedback delivered immediately after tool execution.

### Characteristics

- **Non-blocking**: Guidance, not gates; agent decides response
- **Trigger-based**: Run when conditions met (every N calls/seconds/file created)
- **Immediate delivery**: Inject via hook response, not next render
- **Concurrent evaluation**: All matching providers run, not just first match
- **Independent trigger state**: Each provider maintains its own trigger cadence

### FeedbackTrigger

At `src/weakincentives/prompt/feedback.py`:

| Field | Type | Description |
|-------|------|-------------|
| `every_n_calls` | `int \| None` | Run after N tool calls since last feedback from this provider |
| `every_n_seconds` | `float \| None` | Run after N seconds since last feedback from this provider |
| `on_file_created` | `FileCreatedTrigger \| None` | Run once when file created |

Conditions are OR'd together. Trigger state is tracked per-provider to ensure
each provider maintains independent trigger cadences.

### FileCreatedTrigger

At `src/weakincentives/prompt/feedback.py`:

Triggers when a specified file is created on the filesystem. Fires exactly once
per session--after initial detection, subsequent tool calls will not re-trigger
even if the file is deleted and recreated.

| Field | Type | Description |
|-------|------|-------------|
| `filename` | `str` | Path to watch for creation |

#### Behavior

1. After tool execution completes, check if `filename` exists
1. If file exists and trigger has not fired -> fire, mark as fired
1. If file does not exist or trigger already fired -> skip
1. Trigger state persists in session via `FileCreatedTriggerState` slice; reset clears it

### StaticFeedbackProvider

At `src/weakincentives/prompt/feedback_providers.py`:

A built-in provider that delivers a fixed feedback message. Useful with
`FileCreatedTrigger` for one-time guidance when specific files are detected.

| Field | Type | Description |
|-------|------|-------------|
| `feedback` | `str` | Feedback content to deliver |

```python
config = FeedbackProviderConfig(
    provider=StaticFeedbackProvider(
        feedback="AGENTS.md detected. Follow the conventions defined within.",
    ),
    trigger=FeedbackTrigger(
        on_file_created=FileCreatedTrigger(filename="AGENTS.md"),
    ),
)
```

### FeedbackProviderConfig

```python
template = PromptTemplate(
    ...,
    feedback_providers=(
        FeedbackProviderConfig(
            provider=DeadlineFeedback(),
            trigger=FeedbackTrigger(every_n_seconds=30),
        ),
    ),
)
```

### FeedbackProvider Protocol

| Method/Property | Description |
|-----------------|-------------|
| `name` | Unique identifier |
| `should_run(context)` | Additional filtering beyond trigger |
| `provide(context)` | Produce feedback |

### Feedback

At `src/weakincentives/prompt/feedback.py`:

| Field | Type | Description |
|-------|------|-------------|
| `provider_name` | `str` | Source provider |
| `summary` | `str` | Main message |
| `observations` | `tuple[Observation, ...]` | Detailed observations |
| `suggestions` | `tuple[str, ...]` | Recommendations |
| `severity` | `Literal["info", "caution", "warning"]` | Urgency level |
| `timestamp` | `datetime` | When produced |
| `call_index` | `int` | Tool call count when produced |
| `prompt_name` | `str` | Prompt that produced this feedback |

### XML-Style Feedback Rendering

`Feedback.render()` produces XML-tagged output for structured context injection:

```xml
<feedback provider='Deadline'>
The work so far took 5 minutes. You have 3 minutes remaining.

-> Prioritize completing critical remaining work.
</feedback>
```

Multiple providers produce separate `<feedback>` blocks, joined by blank lines.

### FeedbackContext

At `src/weakincentives/prompt/feedback.py`:

| Property/Method | Description |
|-----------------|-------------|
| `session` | Session protocol |
| `prompt` | Prompt protocol |
| `deadline` | Optional deadline |
| `last_feedback` | Most recent feedback for prompt |
| `last_feedback_for_provider(name)` | Most recent feedback from specific provider |
| `tool_call_count` | Total calls for prompt |
| `tool_calls_since_last_feedback()` | Calls since last feedback (any provider) |
| `tool_calls_since_last_feedback_for_provider(name)` | Calls since last feedback from specific provider |
| `recent_tool_calls(n)` | Last N tool calls |

### Execution Flow

At `src/weakincentives/prompt/feedback.py` (`run_feedback_providers`):

1. Tool call completes
1. `ToolInvoked` dispatched
1. For each configured provider:
   a. Check trigger conditions (using provider-scoped state)
   b. Call `provider.should_run()`
1. Collect all triggered providers
1. Call `provider.provide()` for each
1. Store all feedback in session
1. Mark file creation triggers as fired
1. Render and combine all feedback blocks
1. Return combined text

**All matching providers are evaluated concurrently** (not first-match-wins).

### Adapter Integration

| Adapter | Delivery Method |
|---------|-----------------|
| Claude Agent SDK | `PostToolUse` hook `additionalContext` |
| OpenAI | Appended to tool result message |

### Built-in Provider: DeadlineFeedback

At `src/weakincentives/prompt/feedback_providers.py`:

Reports remaining time until deadline.

```python
config = FeedbackProviderConfig(
    provider=DeadlineFeedback(warning_threshold_seconds=120),
    trigger=FeedbackTrigger(every_n_seconds=30),
)
```

Output varies by remaining time. Below threshold adds suggestions.

### State Management

| Slice | Purpose |
|-------|---------|
| `ToolInvoked` | Tool invocation log |
| `Feedback` | Feedback history |
| `FileCreatedTriggerState` | Tracks which file creation triggers have fired |

Feedback stored via `session.dispatch(feedback)` with `append_all` reducer.

When sessions reused across prompts, feedback/counts scoped to current prompt
via `prompt_name` field.

### Public API

```python
from weakincentives.prompt import (
    DeadlineFeedback,        # Built-in provider
    Feedback,                # Dataclass
    FeedbackContext,         # Context
    FeedbackProvider,        # Protocol
    FeedbackProviderConfig,  # Config
    FeedbackTrigger,         # Trigger
    FileCreatedTrigger,      # File creation trigger
    StaticFeedbackProvider,  # Built-in provider
    collect_feedback,        # Primary entry point
)
```

### Limitations

- **Synchronous**: Providers block tool completion briefly
- **Text-based**: Agent interprets natural language

______________________________________________________________________

## Task Completion Checking

**Implementation:** `src/weakincentives/adapters/claude_agent_sdk/_task_completion.py`

Verify agents complete all assigned tasks before stopping. Critical for ensuring
agents don't prematurely terminate with work incomplete.

### TaskCompletionResult

| Field | Type | Description |
|-------|------|-------------|
| `complete` | `bool` | Whether tasks are complete |
| `feedback` | `str \| None` | Explanation for incomplete |

Factory methods: `TaskCompletionResult.ok()`, `TaskCompletionResult.incomplete(feedback)`

### TaskCompletionContext

| Field | Type | Description |
|-------|------|-------------|
| `session` | `Session` | Session containing state |
| `tentative_output` | `Any` | Output being produced |
| `filesystem` | `Filesystem \| None` | Optional filesystem |
| `adapter` | `ProviderAdapter \| None` | Optional adapter |
| `stop_reason` | `str \| None` | Why agent is stopping |

### TaskCompletionChecker Protocol

```python
class TaskCompletionChecker(Protocol):
    def check(self, context: TaskCompletionContext) -> TaskCompletionResult: ...
```

### Built-in Implementations

#### PlanBasedChecker

Checks session `Plan` state for incomplete steps.

```python
checker = PlanBasedChecker(plan_type=Plan)
```

Returns incomplete if plan steps exist with `status != "done"`.

#### CompositeChecker

Combines multiple checkers with configurable logic.

```python
# All must pass
checker = CompositeChecker(
    checkers=(PlanBasedChecker(plan_type=Plan), FileExistsChecker(("output.txt",))),
    all_must_pass=True,
)

# Any can pass
checker = CompositeChecker(checkers=(...), all_must_pass=False)
```

### Adapter Integration

Configure via `ClaudeAgentSDKClientConfig`:

```python
adapter = ClaudeAgentSDKAdapter(
    client_config=ClaudeAgentSDKClientConfig(
        task_completion_checker=PlanBasedChecker(plan_type=Plan),
    ),
)
```

#### Hook Integration

- **PostToolUse Hook (StructuredOutput)**: If incomplete, adds feedback context
- **Stop Hook**: Returns `needsMoreTurns: True` if incomplete
- **Final Verification**: Raises `PromptEvaluationError` if incomplete

### Operational Notes

- **Default disabled**: Must configure checker to enable
- **Budget/deadline bypass**: Skipped when exhausted
- **Feedback truncation**: Plan checker limits to 3 task titles

______________________________________________________________________

## Design Rationale

### Immediate Delivery (Feedback)

No outer workflow; hooks inject into current turn.

### Store If Delivered

Need history for trigger state and debugging.

### All Matching Providers

All triggered providers run and their feedback is combined, ensuring no guidance
is silently dropped when multiple conditions are met simultaneously.

### No Escalation

Budget provides backstop; feedback is soft guidance.

### Fail-Closed (Policies)

When uncertain, deny. Agent reasons about why and adjusts.

### Observable and Debuggable

Expose reasoning. Denial feedback enables self-correction.

______________________________________________________________________

## Related Specifications

- `POLICIES_OVER_WORKFLOWS.md` - Design philosophy
- `TOOLS.md` - Tool runtime
- `SESSIONS.md` - Session state, snapshots
- `CLAUDE_AGENT_SDK.md` - SDK adapter integration
