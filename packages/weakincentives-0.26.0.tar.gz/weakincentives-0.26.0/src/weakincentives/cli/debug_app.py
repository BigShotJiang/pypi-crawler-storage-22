# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""FastAPI app for exploring debug bundle zip files.

This module provides a web UI for inspecting debug bundles, powered by
SQLite for fast querying. It reuses the same database caching logic as
the `wink query` command.
"""

from __future__ import annotations

import base64
import json
import threading
import webbrowser
from collections.abc import Awaitable, Callable, Mapping
from importlib.resources import files
from pathlib import Path
from typing import Annotated

import uvicorn
from fastapi import FastAPI, HTTPException, Query, Request, Response
from fastapi.responses import HTMLResponse, JSONResponse
from fastapi.staticfiles import StaticFiles

from ..runtime.logging import StructuredLogger, get_logger
from ..types import JSONValue

# Re-export public symbols that other modules access as ``debug_app.X``.
from ._bundle_store import (
    BundleLoadError as BundleLoadError,
    BundleStore as BundleStore,
    _markdown,
)
from .query import iter_bundle_files as iter_bundle_files

# Module-level logger keeps loader warnings consistent with the debug server.
logger: StructuredLogger = get_logger(__name__)

# pyright: reportUnusedFunction=false
# pyright: reportPrivateUsage=false


class _DebugAppHandlers:
    def __init__(
        self, *, store: BundleStore, logger: StructuredLogger, static_dir: Path
    ) -> None:
        super().__init__()
        self._store = store
        self._logger = logger
        self._static_dir = static_dir

    def index(self) -> HTMLResponse:
        index_path = self._static_dir / "index.html"
        return HTMLResponse(
            content=index_path.read_text(),
            headers={"Cache-Control": "no-cache"},
        )

    def get_meta(self) -> Mapping[str, JSONValue]:
        return self._store.get_meta()

    def get_manifest(self) -> JSONResponse:
        """Return the raw bundle manifest."""
        manifest = self._store.bundle.manifest
        return JSONResponse(json.loads(manifest.to_json()))

    def get_slice(
        self,
        encoded_slice_type: str,
        *,
        offset: Annotated[int, Query(ge=0)] = 0,
        limit: Annotated[int | None, Query(ge=0)] = None,
    ) -> Mapping[str, JSONValue]:
        from urllib.parse import unquote

        slice_type = unquote(encoded_slice_type)
        try:
            return self._store.get_slice_items(slice_type, offset=offset, limit=limit)
        except KeyError as error:
            raise HTTPException(status_code=404, detail=str(error)) from error

    def get_logs(  # noqa: PLR0913
        self,
        *,
        offset: Annotated[int, Query(ge=0)] = 0,
        limit: Annotated[int | None, Query(ge=0)] = None,
        level: Annotated[str | None, Query()] = None,
        logger: Annotated[str | None, Query()] = None,
        event: Annotated[str | None, Query()] = None,
        search: Annotated[str | None, Query()] = None,
        exclude_logger: Annotated[str | None, Query()] = None,
        exclude_event: Annotated[str | None, Query()] = None,
    ) -> Mapping[str, JSONValue]:
        """Return log entries from the bundle."""
        return self._store.get_logs(
            offset=offset,
            limit=limit,
            level=level,
            logger=logger,
            event=event,
            search=search,
            exclude_logger=exclude_logger,
            exclude_event=exclude_event,
        )

    def get_log_facets(self) -> Mapping[str, JSONValue]:
        """Return unique loggers, events, and levels for filter UI."""
        return self._store.get_log_facets()

    def get_transcript(  # noqa: PLR0913
        self,
        *,
        offset: Annotated[int, Query(ge=0)] = 0,
        limit: Annotated[int | None, Query(ge=0)] = None,
        source: Annotated[str | None, Query()] = None,
        entry_type: Annotated[str | None, Query()] = None,
        search: Annotated[str | None, Query()] = None,
        exclude_source: Annotated[str | None, Query()] = None,
        exclude_entry_type: Annotated[str | None, Query()] = None,
    ) -> Mapping[str, JSONValue]:
        """Return transcript entries from the bundle."""
        return self._store.get_transcript(
            offset=offset,
            limit=limit,
            source=source,
            entry_type=entry_type,
            search=search,
            exclude_source=exclude_source,
            exclude_entry_type=exclude_entry_type,
        )

    def get_transcript_facets(self) -> Mapping[str, JSONValue]:
        """Return unique transcript sources and entry types for filter UI."""
        return self._store.get_transcript_facets()

    def get_environment(self) -> Mapping[str, JSONValue]:
        """Return environment data (system, python, git, container, env_vars)."""
        return self._store.get_environment()

    def get_config(self) -> JSONResponse:
        """Return the bundle config."""
        config = self._store.bundle.config
        if config is None:
            raise HTTPException(status_code=404, detail="Config not found in bundle")
        return JSONResponse(config)

    def get_metrics(self) -> JSONResponse:
        """Return the bundle metrics."""
        metrics = self._store.bundle.metrics
        if metrics is None:
            raise HTTPException(status_code=404, detail="Metrics not found in bundle")
        return JSONResponse(metrics)

    def get_error(self) -> JSONResponse:
        """Return error details if present."""
        error = self._store.bundle.error
        if error is None:
            raise HTTPException(status_code=404, detail="No error in bundle")
        return JSONResponse(error)

    def list_files(self) -> list[str]:
        """List files in the bundle."""
        return self._store.bundle.list_files()

    def get_file(self, file_path: str) -> JSONResponse:
        """Get content of a specific file in the bundle."""
        from ..debug.bundle import BundleValidationError

        # Image extension to MIME type mapping
        image_extensions: dict[str, str] = {
            ".png": "image/png",
            ".jpg": "image/jpeg",
            ".jpeg": "image/jpeg",
            ".gif": "image/gif",
            ".webp": "image/webp",
            ".svg": "image/svg+xml",
            ".ico": "image/x-icon",
            ".bmp": "image/bmp",
        }

        try:
            content = self._store.bundle.read_file(file_path)

            # Check for image by extension
            lower_path = file_path.lower()
            for ext, mime_type in image_extensions.items():
                if lower_path.endswith(ext):
                    encoded = base64.b64encode(content).decode("ascii")
                    return JSONResponse(
                        {
                            "content": encoded,
                            "type": "image",
                            "mime_type": mime_type,
                        }
                    )

            # Check for markdown by extension
            if lower_path.endswith(".md"):
                try:
                    text = content.decode("utf-8")
                    html = _markdown.render(text)
                    return JSONResponse(
                        {"content": text, "html": html, "type": "markdown"}
                    )
                except UnicodeDecodeError:
                    return JSONResponse({"content": None, "type": "binary"})

            # Try to parse as JSON
            try:
                parsed = json.loads(content.decode("utf-8"))
                return JSONResponse({"content": parsed, "type": "json"})
            except (json.JSONDecodeError, UnicodeDecodeError):
                # Return as text or indicate binary
                try:
                    text = content.decode("utf-8")
                    return JSONResponse({"content": text, "type": "text"})
                except UnicodeDecodeError:
                    return JSONResponse({"content": None, "type": "binary"})
        except BundleValidationError as error:
            raise HTTPException(status_code=404, detail=str(error)) from error

    def reload(self) -> Mapping[str, JSONValue]:
        try:
            return self._store.reload()
        except BundleLoadError as error:
            self._logger.warning(
                "Bundle reload failed",
                event="debug.server.reload_failed",
                context={
                    "path": str(self._store.path),
                    "error": str(error),
                },
            )
            raise HTTPException(status_code=400, detail=str(error)) from error

    def list_bundles(self) -> list[Mapping[str, JSONValue]]:
        return self._store.list_bundles()

    def switch(self, payload: dict[str, JSONValue]) -> Mapping[str, JSONValue]:
        path = self._parse_switch_payload(payload)
        try:
            return self._store.switch(path)
        except BundleLoadError as error:
            raise HTTPException(status_code=400, detail=str(error)) from error

    @staticmethod
    def _parse_switch_payload(payload: Mapping[str, JSONValue]) -> Path:
        path_value = payload.get("path")
        if not isinstance(path_value, str):
            raise HTTPException(status_code=400, detail="path is required")
        return Path(path_value)


def build_debug_app(store: BundleStore, logger: StructuredLogger) -> FastAPI:
    """Construct the FastAPI application for inspecting debug bundles."""

    static_dir = Path(str(files(__package__).joinpath("static")))
    handlers = _DebugAppHandlers(store=store, logger=logger, static_dir=static_dir)

    app = FastAPI(title="wink debug bundle server")
    app.state.bundle_store = store
    app.state.logger = logger
    app.mount(
        "/static",
        StaticFiles(directory=str(static_dir)),
        name="static",
    )

    @app.middleware("http")
    async def _no_cache_static(
        request: Request, call_next: Callable[[Request], Awaitable[Response]]
    ) -> Response:
        response = await call_next(request)
        if request.url.path.startswith("/static/"):
            response.headers["Cache-Control"] = "no-cache"
        return response

    _ = app.get("/", response_class=HTMLResponse)(handlers.index)
    _ = app.get("/api/meta")(handlers.get_meta)
    _ = app.get("/api/manifest")(handlers.get_manifest)
    _ = app.get("/api/slices/{encoded_slice_type}")(handlers.get_slice)
    _ = app.get("/api/logs")(handlers.get_logs)
    _ = app.get("/api/logs/facets")(handlers.get_log_facets)
    _ = app.get("/api/transcript")(handlers.get_transcript)
    _ = app.get("/api/transcript/facets")(handlers.get_transcript_facets)
    _ = app.get("/api/environment")(handlers.get_environment)
    _ = app.get("/api/config")(handlers.get_config)
    _ = app.get("/api/metrics")(handlers.get_metrics)
    _ = app.get("/api/error")(handlers.get_error)
    _ = app.get("/api/files")(handlers.list_files)
    _ = app.get("/api/files/{file_path:path}")(handlers.get_file)
    _ = app.post("/api/reload")(handlers.reload)
    _ = app.get("/api/bundles")(handlers.list_bundles)
    _ = app.post("/api/switch")(handlers.switch)

    return app


def run_debug_server(
    app: FastAPI,
    *,
    host: str,
    port: int,
    open_browser: bool,
    logger: StructuredLogger,
) -> int:
    """Run the uvicorn server for the supplied FastAPI app."""

    url = f"http://{host}:{port}/"
    if open_browser:
        threading.Timer(0.2, _open_browser, args=(url, logger)).start()

    logger.info(
        "Starting wink debug server",
        event="debug.server.start",
        context={"url": url},
    )

    try:
        config = uvicorn.Config(
            app,
            host=host,
            port=port,
            log_config=None,
        )
        server = uvicorn.Server(config)
        server.run()
    except Exception as error:  # pragma: no cover - exercised in wink tests
        logger.exception(
            "Failed to start wink debug server",
            event="debug.server.error",
            context={"url": url, "error": repr(error)},
        )
        return 3
    return 0


def _open_browser(url: str, logger: StructuredLogger) -> None:
    try:
        _ = webbrowser.open(url)
    except Exception as error:  # pragma: no cover - best effort logging
        logger.warning(
            "Unable to open browser",
            event="debug.server.browser",
            context={"url": url, "error": repr(error)},
        )
