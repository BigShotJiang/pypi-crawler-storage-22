# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Clock control helpers for tests.

The primary test clock is :class:`weakincentives.clock.FakeClock`, which provides
controllable monotonic and wall-clock time. This module provides the ``fake_clock``
pytest fixture and backward-compatible helpers.

**Recommended**: Use the ``fake_clock`` fixture for most tests::

    def test_deadline_remaining(fake_clock: FakeClock) -> None:
        fake_clock.set_wall(datetime(2024, 6, 1, 12, 0, 0, tzinfo=UTC))

        deadline = Deadline(
            expires_at=datetime(2024, 6, 1, 13, 0, 0, tzinfo=UTC),
            clock=fake_clock,
        )

        assert deadline.remaining() == timedelta(hours=1)
        fake_clock.advance(1800)  # 30 minutes
        assert deadline.remaining() == timedelta(minutes=30)

**Alternative**: Import FakeClock directly when you need multiple instances
or for type annotations::

    from tests.helpers.time import FakeClock  # Preferred import location

    def test_multiple_clocks() -> None:
        clock1 = FakeClock()
        clock2 = FakeClock()
        # ...

The fixture is auto-registered via pytest_plugins in the main conftest.py.
"""

from __future__ import annotations

from datetime import datetime

import pytest

# Re-export FakeClock from main module for convenience
from weakincentives.clock import FakeClock


class ControllableClock:
    """Backward-compatible wrapper around FakeClock for monotonic-only usage.

    .. deprecated::
        Use :class:`weakincentives.clock.FakeClock` directly instead.
        This class remains for backward compatibility with tests that
        use ``clock()`` instead of ``clock.monotonic()``.

    Example (legacy)::

        clock = ControllableClock()
        mailbox = InMemoryMailbox(name="test", clock=clock)

    Example (preferred)::

        from weakincentives.clock import FakeClock

        clock = FakeClock()
        mailbox = InMemoryMailbox(name="test", clock=clock)
    """

    def __init__(self, start: float = 0.0) -> None:
        self._clock = FakeClock()
        self._clock.set_monotonic(start)

    def __call__(self) -> float:
        """Return the current monotonic time (legacy callable interface)."""
        return self._clock.monotonic()

    def monotonic(self) -> float:
        """Return the current monotonic time."""
        return self._clock.monotonic()

    def utcnow(self) -> datetime:
        """Return the current wall-clock time."""
        return self._clock.utcnow()

    def sleep(self, seconds: float) -> None:
        """Advance time immediately without blocking."""
        self._clock.sleep(seconds)

    def advance(self, seconds: float) -> float:
        """Advance the clock by the given number of seconds.

        Args:
            seconds: Time to advance in seconds.

        Returns:
            The new monotonic time.
        """
        self._clock.advance(seconds)
        return self._clock.monotonic()

    def set(self, value: float) -> float:
        """Set the monotonic clock to an absolute value.

        Args:
            value: The new clock value.

        Returns:
            The new monotonic time.
        """
        self._clock.set_monotonic(value)
        return self._clock.monotonic()


@pytest.fixture
def fake_clock() -> FakeClock:
    """Provide a fresh FakeClock for deterministic time control.

    This is the preferred fixture for testing time-dependent code.
    Inject the clock into components that accept a clock parameter.

    Example::

        def test_heartbeat_elapsed(fake_clock: FakeClock) -> None:
            hb = Heartbeat(clock=fake_clock)

            hb.beat()
            assert hb.elapsed() == 0.0

            fake_clock.advance(10)
            assert hb.elapsed() == 10.0
    """
    return FakeClock()


__all__ = [
    "ControllableClock",
    "FakeClock",
    "fake_clock",
]
