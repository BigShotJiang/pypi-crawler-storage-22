import logging
import socket
from typing import Any

from confluent_kafka import (
    Consumer as ConfluentKafkaConsumer,
)
from confluent_kafka import (
    Producer as ConfluentKafkaProducer,
)
from confluent_kafka import (
    TopicPartition,
)

from weave.trace_server import trace_server_interface as tsi
from weave.trace_server.datadog import set_root_span_dd_tags
from weave.trace_server.environment import (
    kafka_broker_host,
    kafka_broker_port,
    kafka_client_password,
    kafka_client_user,
    kafka_partition_by_project_id,
    kafka_producer_max_buffer_size,
)

CALL_ENDED_TOPIC = "weave.call_ended"

DEFAULT_MAX_BUFFER_SIZE = 10000

logger = logging.getLogger(__name__)


class KafkaProducer(ConfluentKafkaProducer):
    """Kafka producer for sending messages to the Kafka broker.

    Args:
        config (dict[str, Any]): Kafka producer configuration.
        max_buffer_size (int): Maximum number of messages in the producer buffer.
    """

    def __init__(self, config: dict[str, Any]):
        super().__init__(config)
        self.max_buffer_size = (
            kafka_producer_max_buffer_size() or DEFAULT_MAX_BUFFER_SIZE
        )

    @classmethod
    def from_env(
        cls,
        additional_kafka_config: dict[str, Any] | None = None,
    ) -> "KafkaProducer":
        if additional_kafka_config is None:
            additional_kafka_config = {}

        num_retries = 1
        request_retry_backoff_ms = 100
        # per attempt deadline, this is large to accommodate large call batches,
        # with only 1 retry to prevent continued failures when timeout is due to size
        request_timeout_ms = 5000
        # worst case total request time hardcap
        total_timeout_ms = (
            request_timeout_ms * (num_retries + 1) + request_retry_backoff_ms
        )
        config = {
            "bootstrap.servers": _make_broker_host(),
            "client.id": socket.gethostname(),
            "request.timeout.ms": request_timeout_ms,
            "message.timeout.ms": total_timeout_ms,
            "retries": 1,
            "retry.backoff.ms": request_retry_backoff_ms,
            "partitioner": "murmur2_random",  # Explicit round robin
            **_make_auth_config(),
            **additional_kafka_config,
        }

        return cls(config)

    def produce_call_end(
        self, call_end: tsi.EndedCallSchemaForInsert, flush_immediately: bool = False
    ) -> None:
        """Produce a call_end message to Kafka with buffer size management.

        Drops messages if buffer is full to prevent unbounded memory growth.
        Logs warnings at 50% capacity and errors when dropping messages.
        """
        buffer_size = len(self)

        if buffer_size >= self.max_buffer_size:
            logger.error(
                "Kafka producer buffer full, dropping message",
                extra={
                    "buffer_size": buffer_size,
                    "max_buffer_size": self.max_buffer_size,
                    "project_id": call_end.project_id,
                    "call_id": call_end.id,
                },
            )
            set_root_span_dd_tags({"kafka.producer.buffer_size": buffer_size})

            # Drop the message - do not produce
            return

        # Log warning if buffer is at 50% capacity
        if buffer_size >= self.max_buffer_size * 0.5:
            buffer_percentage = (buffer_size / self.max_buffer_size) * 100
            logger.warning(
                "Kafka producer buffer at 50%% capacity or higher",
                extra={
                    "buffer_size": buffer_size,
                    "max_buffer_size": self.max_buffer_size,
                    "buffer_percentage": buffer_percentage,
                },
            )
            set_root_span_dd_tags(
                {
                    "kafka.producer.buffer_size": buffer_size,
                    "kafka.producer.buffer_percentage": buffer_percentage,
                }
            )

        publish_key = None
        if kafka_partition_by_project_id():
            publish_key = call_end.project_id

        self.produce(
            topic=CALL_ENDED_TOPIC,
            value=call_end.model_dump_json(),
            key=publish_key,
        )

        if flush_immediately:
            self.flush()


class KafkaConsumer(ConfluentKafkaConsumer):
    """Kafka consumer for receiving messages from the Kafka broker.

    Args:
        group_id (str): The group ID for the consumer.
        additional_kafka_config (Optional[dict[str, Any]]): Additional Kafka configuration to pass to the consumer.
    """

    @classmethod
    def from_env(
        cls, group_id: str, additional_kafka_config: dict[str, Any] | None = None
    ) -> "KafkaConsumer":
        if additional_kafka_config is None:
            additional_kafka_config = {}

        config = {
            "bootstrap.servers": _make_broker_host(),
            "client.id": socket.gethostname(),
            "group.id": group_id,
            "auto.offset.reset": "earliest",
            "enable.auto.commit": False,
            # Connection health: detect dead sockets in 10s instead of the
            # 60s default.  Without this, a dropped connection blocks heartbeats
            # for up to a minute, which can exceed the session timeout and
            # trigger an unnecessary consumer-group rebalance.
            "socket.timeout.ms": 10_000,
            # Session / heartbeat: keep session.timeout high enough to ride out
            # transient coordinator slowness (commit backlogs, broker GC pauses)
            # without falsely declaring the consumer dead.  The key invariant is
            #   socket.timeout.ms  <  session.timeout.ms
            # so dead-socket detection fires before the session expires.
            "session.timeout.ms": 45_000,
            "heartbeat.interval.ms": 3_000,
            # Reconnection: back off quickly but cap at 5s so we rejoin the
            # group fast after a transient failure.
            "reconnect.backoff.ms": 100,
            "reconnect.backoff.max.ms": 5_000,
            # TODO: Re-enable once prod Bufstream supports Kafka >= 2.4.0 protocol.
            # "partition.assignment.strategy": "cooperative-sticky",  # KIP-429, requires >= 2.4.0
            # "group.instance.id": socket.gethostname(),  # KIP-345, requires >= 2.3.0
            **_make_auth_config(),
            **additional_kafka_config,
        }

        return cls(config)

    def commit_batch_async(self, messages: list[Any]) -> None:
        """Commit the highest offset per partition in a single async call.

        Replaces N synchronous per-message commits with one non-blocking call,
        which keeps the coordinator connection free for heartbeats.

        Args:
            messages: Raw confluent-kafka Message objects to commit.
        """
        if not messages:
            return

        # Keep only the highest offset per (topic, partition).
        max_offsets: dict[tuple[str, int], int] = {}
        for msg in messages:
            key = (msg.topic(), msg.partition())
            offset = msg.offset()
            if key not in max_offsets or offset > max_offsets[key]:
                max_offsets[key] = offset

        # commit position = next offset the consumer should read
        offsets = [
            TopicPartition(topic, partition, offset + 1)
            for (topic, partition), offset in max_offsets.items()
        ]

        try:
            self.commit(offsets=offsets, asynchronous=True)
        except Exception:
            # Async commit failure is non-fatal: the messages will be
            # redelivered on the next rebalance and reprocessed.
            logger.warning("Async batch commit failed", exc_info=True)


def _make_broker_host() -> str:
    return f"{kafka_broker_host()}:{kafka_broker_port()}"


def _make_auth_config() -> dict[str, str | None]:
    username = kafka_client_user()

    if username is None:
        return {}

    return {
        "sasl.username": username,
        "sasl.password": kafka_client_password(),
        "security.protocol": "SASL_PLAINTEXT",
        "sasl.mechanisms": "PLAIN",
    }
