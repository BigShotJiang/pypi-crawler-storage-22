"""webimg-square: CLI tool to square images for web with smart padding."""

__version__ = "1.0.1"
