
__version__ = "2026.1.31"
__prog__ = "webscout"
