"""WebSense: AI-powered web scraping and structured data extraction."""

from .scraper import Scraper


__all__ = ["Scraper"]
