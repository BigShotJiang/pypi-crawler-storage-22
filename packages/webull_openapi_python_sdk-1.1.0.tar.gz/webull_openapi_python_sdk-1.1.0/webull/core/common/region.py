from enum import Enum


class Region(Enum):
    US = 'us'
    HK = 'hk'
    JP = 'jp'
