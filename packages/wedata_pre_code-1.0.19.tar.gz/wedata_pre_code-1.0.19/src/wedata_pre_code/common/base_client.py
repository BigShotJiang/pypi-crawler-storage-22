__doc__ = """
基础客户端类
"""

from abc import abstractmethod
from pydantic import BaseModel


class BaseClient(BaseModel):
    """
    基础客户端类
    """

    @abstractmethod
    def init(self):
        pass
