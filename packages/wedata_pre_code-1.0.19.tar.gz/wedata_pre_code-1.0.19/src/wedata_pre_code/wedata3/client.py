from typing import Optional

from wedata_pre_code.common.base_client import BaseClient
from wedata_pre_code.wedata3.experiment import (
    create_experiment,
    delete_experiment,
    rename_experiment,
    restore_experiment,
    get_experiment,
    get_experiment_by_name,
    search_experiments,
    set_experiment
)


__doc__ = """
Wedata3预执行代码客户端
"""

PROXY_HEADER_KEY_IP = "X-Target-Service-IP"
PROXY_HEADER_KEY_PORT = "X-Target-Service-PORT"

FEAST_PROXY_ENV_KEY_IP = "FEAST_SERVICE_IP"
FEAST_PROXY_ENV_KEY_PORT = "FEAST_SERVICE_PORT"

MLFLOW_PROXY_ENV_KEY_IP = "MLFLOW_SERVICE_IP"
MLFLOW_PROXY_ENV_KEY_PORT = "MLFLOW_SERVICE_PORT"

KERNEL_WEDATA_PREFIX = "KERNEL_WEDATA_"


def get_kernel_env_key(key):
    """
    设置Wedata特定的变量前缀，避免于系统内置变量冲突。
    例如：key = "REGION" , 最终返回 "KERNEL_WEDATA_REGION"
    :param key:
    :return:
    """
    return KERNEL_WEDATA_PREFIX + key


class Wedata3PreCodeClient(BaseClient):
    """
    Wedata3预执行代码客户端
    必传参数:
        - workspace_id: 工作空间ID
        - mlflow_tracking_uri: mlflow跟踪URI
        - base_url: 基础URL
        - mlflow_gateway_url: mlflow基础serverless网关地址
        - feast_gateway_url: feast基础serverless网关地址
        - mlflow_proxy_ip: mlflow转发地址
        - mlflow_proxy_port: mlflow转发端口
        - feast_proxy_ip: feast转发地址
        - feast_proxy_port: feast转发端口
    可选参数:
        - region: 区域
        - ap_region_id: 区域ID
        - kernel_task_name: Notebook路径名
        - kernel_task_id:  Notebook文件ID
        - kernel_submit_form_workflow: 任务提交表单工作流
        - kernel_is_international: 是否国际站
        - cloud_sdk_secret_id: 云SDK密钥ID
        - cloud_sdk_secret_key: 云SDK密钥KEY
        - cloud_sdk_secret_token: 云SDK密钥TOKEN
        - qcloud_uin: 腾讯云uin
        - qcloud_subuin: 腾讯云subuin
    """

    workspace_id: str
    base_url: str
    region: Optional[str] = ""
    ap_region_id: Optional[int] = 0
    # 基础serverless网关地址
    mlflow_gateway_url: str
    feast_gateway_url: str
    # mlflow转发地址
    mlflow_proxy_ip: str
    mlflow_proxy_port: str
    # feast转发地址
    feast_proxy_ip: str
    feast_proxy_port: str
    # 系统内置变量
    kernel_task_name: Optional[str]
    kernel_task_id: Optional[str]
    kernel_submit_form_workflow: Optional[str] = ""
    # SDK相关
    cloud_sdk_secret_id: Optional[str] = ""
    cloud_sdk_secret_key: Optional[str] = ""
    cloud_sdk_secret_token: Optional[str] = ""
    # 帐号相关
    qcloud_uin: Optional[str] = ""
    qcloud_subuin: Optional[str] = ""

    def init(self):
        import inspect
        import json
        import os
        from functools import wraps

        import feast
        import feast.infra.registry.remote
        import grpc
        import mlflow
        from feast.errors import FeastError
        from feast.protos.feast.registry import RegistryServer_pb2_grpc
        from mlflow.models.model import Model
        from mlflow.tracking import MlflowClient
        from mlflow.tracking._tracking_service.client import TrackingServiceClient

        mlflow_tracking_uri = f"http://{self.mlflow_proxy_ip}:{self.mlflow_proxy_port}"
        mlflow_registry_uri = f"tclake:{self.region}"
        feast_remote_address = f"{self.feast_proxy_ip}:{self.feast_proxy_port}"

        if self.mlflow_gateway_url:
            mlflow_tracking_uri = f"http://{self.mlflow_gateway_url}"
            os.environ[MLFLOW_PROXY_ENV_KEY_IP] = self.mlflow_proxy_ip
            os.environ[MLFLOW_PROXY_ENV_KEY_PORT] = self.mlflow_proxy_port

        if self.feast_gateway_url:
            feast_remote_address = self.feast_gateway_url
            os.environ[FEAST_PROXY_ENV_KEY_IP] = self.feast_proxy_ip
            os.environ[FEAST_PROXY_ENV_KEY_PORT] = self.feast_proxy_port

        # os.environ["MLFLOW_RUN_CONTEXT"] = self.run_context_data
        os.environ["WEDATA_WORKSPACE_ID"] = self.workspace_id
        os.environ["MLFLOW_TRACKING_URI"] = mlflow_tracking_uri
        os.environ["MLFLOW_REGISTRY_URI"] = mlflow_registry_uri
        os.environ[get_kernel_env_key("REGION")] = self.region

        os.environ["KERNEL_FEAST_REMOTE_ADDRESS"] = feast_remote_address

        # 设置系统内置变量
        os.environ[get_kernel_env_key("TASK_NAME")] = self.kernel_task_name
        os.environ[get_kernel_env_key("TASK_ID")] = self.kernel_task_id
        os.environ[get_kernel_env_key("SUBMIT_FORM_WORKFLOW")] = self.kernel_submit_form_workflow
        os.environ[get_kernel_env_key("CLOUD_SDK_SECRET_ID")] = self.cloud_sdk_secret_id
        os.environ[get_kernel_env_key("CLOUD_SDK_SECRET_KEY")] = self.cloud_sdk_secret_key
        os.environ[get_kernel_env_key("CLOUD_SDK_SECRET_TOKEN")] = self.cloud_sdk_secret_token
        os.environ[get_kernel_env_key("QCLOUD_UIN")] = self.qcloud_uin
        os.environ[get_kernel_env_key("QCLOUD_SUBUIN")] = self.qcloud_subuin

        mlflow.set_tracking_uri(mlflow_tracking_uri)
        mlflow.set_registry_uri(mlflow_registry_uri)

        if not os.environ.get("MLFLOW_RUN_CONTEXT"):
            # 避免重复设置
            run_context_data = {
                "mlflow.source.name": self.kernel_task_name,
                "mlflow.user": self.qcloud_uin,
                "wedata.taskId": self.kernel_task_id,
                "wedata.workflowId": self.kernel_submit_form_workflow,
                "wedata.datascience.type": "MACHINE_LEARNING",
                "wedata.workspace": self.workspace_id,
            }
            run_context_value = json.dumps(run_context_data, indent=None)

            os.environ["MLFLOW_RUN_CONTEXT"] = run_context_value

        if self.region:
            # 日志输出装饰器
            base_url = self.base_url
            workspace_id = self.workspace_id
            ap_region_id = self.ap_region_id

            def log_after_terminated(func):
                @wraps(func)
                def wrapper(self, run_id, *args, **kwargs):
                    print("wedata log_after_terminated wrapper")
                    result = func(self, run_id, *args, **kwargs)
                    run_info = self.store.get_run(run_id).info
                    run_name = run_info.run_name
                    experiment_id = run_info.experiment_id
                    experiment_url = f"{base_url}/datascience/experiments/experiments-single/{experiment_id}?o={workspace_id}&r={ap_region_id}"
                    run_url = f"{base_url}/datascience/experiments/task-detail-learn/{run_id}?o={workspace_id}&r={ap_region_id}"
                    print(f"View run {run_name} at :{run_url}")
                    print(f"View experiment at: {experiment_url}")
                    return result

                return wrapper

            TrackingServiceClient.set_terminated = log_after_terminated(TrackingServiceClient.set_terminated)

        # 模型版本标签注入装饰器
        def inject_model_version_tag(func):
            @wraps(func)
            def wrapper(*args, **kwargs):
                print("wedata inject_model_version_tag wrapper")
                registered_model_name = kwargs.get("registered_model_name")
                if registered_model_name is None:
                    sig = inspect.signature(func)
                    params = list(sig.parameters.keys())
                    if "registered_model_name" in params:
                        idx = params.index("registered_model_name") - 1
                        if len(args) > idx:
                            registered_model_name = args[idx]
                result = func(*args, **kwargs)
                model_version = result.registered_model_version
                if registered_model_name and model_version:
                    from mlflow import MlflowClient

                    MlflowClient().set_model_version_tag(registered_model_name, model_version, "mlflow.user", "${uin}")
                    MlflowClient().set_model_version_tag(
                        registered_model_name,
                        model_version,
                        "wedata.workspace",
                        self.workspace_id,
                    )
                    MlflowClient().set_model_version_tag(
                        registered_model_name,
                        model_version,
                        "wedata.datascience.type",
                        "MACHINE_LEARNING",
                    )
                return result

            return wrapper

        Model.log = inject_model_version_tag(Model.log)

        # 项目标签注入装饰器
        def inject_workspace_tag(func):
            @wraps(func)
            def wrapper(self, *args, **kwargs):
                workspace = os.getenv("WEDATA_WORKSPACE_ID")
                args_list = list(args)
                if workspace:
                    if "tags" in kwargs:
                        tags = kwargs["tags"] or {}
                        tags = tags.copy()
                        # 如果传入的参数中有wedata.workspace和wedata.datascience.type，则不进行注入
                        if "wedata.workspace" not in tags:
                            tags["wedata.workspace"] = workspace
                        if "wedata.datascience.type" not in tags:
                            tags["wedata.datascience.type"] = "MACHINE_LEARNING"
                        kwargs["tags"] = tags
                    else:
                        current_tags = None
                        method_name = func.__name__
                        tags_index = -1
                        if method_name in ("create_experiment", "create_run"):
                            tags_index = 2
                            if len(args_list) >= 3:
                                current_tags = args_list[2]
                        elif method_name in ("create_registered_model",):
                            tags_index = 1
                            if len(args_list) >= 2:
                                current_tags = args_list[1]
                        elif method_name in ("create_model_version",):
                            tags_index = 4
                            if len(args_list) >= 5:
                                current_tags = args_list[4]
                        
                        if current_tags is None:
                            current_tags = {}
                        else:
                            current_tags = current_tags.copy() if current_tags else {}
                        
                        current_tags["wedata.workspace"] = workspace
                        current_tags["wedata.datascience.type"] = "MACHINE_LEARNING"
                        current_tags["mlflow.user"] = "${uin}"
                        
                        # 如果 tags 在位置参数中，需要更新 args_list 并移除该位置参数
                        if tags_index >= 0 and len(args_list) > tags_index:
                            args_list[tags_index] = current_tags
                            args = tuple(args_list)
                        else:
                            # 否则通过 kwargs 传递
                            kwargs["tags"] = current_tags
                return func(self, *args, **kwargs)

            return wrapper

        # 标签验证装饰器
        def validate_wedata_tag(func):
            @wraps(func)
            def wrapper(*args, **kwargs):
                workspace = os.getenv("WEDATA_WORKSPACE_ID")
                obj = func(*args, **kwargs)
                if obj is None:
                    return obj
                workspace_tag = None
                datascience_type_tag = None
                method_name = func.__name__
                obj_name = "object"
                if "run" in method_name:
                    workspace_tag = obj.data.tags.get("wedata.workspace")
                    datascience_type_tag = obj.data.tags.get("wedata.datascience.type")
                    obj_name = "run"
                elif "experiment" in method_name:
                    obj_name = "experiment"
                    workspace_tag = obj.tags.get("wedata.workspace")
                    datascience_type_tag = obj.tags.get("wedata.datascience.type")
                elif "model" in method_name:
                    obj_name = "model"
                    workspace_tag = obj.tags.get("wedata.workspace")
                    datascience_type_tag = obj.tags.get("wedata.datascience.type")
                if workspace and workspace_tag != workspace:
                    print(f"this workspace:{workspace},has no {obj_name}")
                    return None
                return obj

            return wrapper

        # 操作前验证装饰器
        def validate_wedata_before_operation(func):
            @wraps(func)
            def wrapper(self, *args, **kwargs):
                workspace = os.getenv("WEDATA_WORKSPACE_ID")
                if not workspace:
                    return func(self, *args, **kwargs)
                method_name = func.__name__
                id_name = None
                res = None
                workspace_tag = None
                data_science_type = None
                if "experiment" in method_name:
                    id_name = kwargs.get("experiment_id") or (args[0] if args else None)
                    res = self.get_experiment(id_name)
                    if not res:
                        print(f"Experiment: '{id_name}' not exist or does not have permission to operate")
                        return
                    workspace_tag = res.tags.get("wedata.workspace")
                    data_science_type = res.tags.get("wedata.datascience.type")
                elif "model" in method_name:
                    id_name = kwargs.get("name") or (args[0] if args else None)
                    res = self.get_registered_model(id_name)
                    if not res:
                        print(f"Model '{id_name}' not exist or does not have permission to operate")
                        return
                    workspace_tag = res.tags.get("wedata.workspace")
                    data_science_type = res.tags.get("wedata.datascience.type")
                else:
                    id_name = kwargs.get("run_id") or (args[0] if args else None)
                    res = self.get_run(id_name)
                    if not res:
                        print(f"run: '{id_name}' not exist or does not have permission to operate")
                        return
                    workspace_tag = res.data.tags.get("wedata.workspace")
                    data_science_type = res.data.tags.get("wedata.datascience.type")
                if workspace_tag != workspace or data_science_type not in (
                    "MACHINE_LEARNING",
                    "DEEP_LEARNING",
                ):
                    print(f"Unauthorized operation:{method_name} ({id_name})")
                    return
                if method_name in (
                    "update_tag",
                    "delete_tags",
                    "set_registered_model_tag",
                    "delete_registered_model_tag",
                    "delete_model_version_tag",
                    "set_experiment_tag",
                ):
                    key_value = kwargs.get("key") or (args[1] if args else None)
                    if key_value == "wedata.workspace":
                        print(f"No permission to operate protected tags: {key_value}")
                        return
                return func(self, *args, **kwargs)

            return wrapper

        # 应用装饰器
        MlflowClient.create_experiment = inject_workspace_tag(create_experiment)
        MlflowClient.get_experiment = validate_wedata_tag(get_experiment)
        MlflowClient.get_experiment_by_name = validate_wedata_tag(get_experiment_by_name)
        MlflowClient.search_experiments = search_experiments
        MlflowClient.get_run = validate_wedata_tag(MlflowClient.get_run)
        MlflowClient.get_parent_run = validate_wedata_tag(MlflowClient.get_parent_run)
        MlflowClient.delete_experiment = delete_experiment
        MlflowClient.restore_experiment = restore_experiment
        MlflowClient.rename_experiment = validate_wedata_before_operation(rename_experiment)
        MlflowClient.set_experiment_tag = validate_wedata_before_operation(MlflowClient.set_experiment_tag)
        MlflowClient.set_tag = validate_wedata_before_operation(MlflowClient.set_tag)
        MlflowClient.delete_tag = validate_wedata_before_operation(MlflowClient.delete_tag)
        MlflowClient.update_run = validate_wedata_before_operation(MlflowClient.update_run)
        MlflowClient.download_artifacts = validate_wedata_before_operation(MlflowClient.download_artifacts)
        MlflowClient.list_artifacts = validate_wedata_before_operation(MlflowClient.list_artifacts)
        MlflowClient.delete_run = validate_wedata_before_operation(MlflowClient.delete_run)
        MlflowClient.restore_run = validate_wedata_before_operation(MlflowClient.restore_run)
        mlflow.set_experiment = set_experiment

        # 2026.01.27. 预执行脚本强制安装tclake插件,取消以下代码
        # MlflowClient.create_registered_model = inject_workspace_tag(MlflowClient.create_registered_model)
        # MlflowClient.create_model_version = inject_workspace_tag(MlflowClient.create_model_version)
        # MlflowClient.get_registered_model = validate_wedata_tag(MlflowClient.get_registered_model)
        # MlflowClient.rename_registered_model = validate_wedata_before_operation(MlflowClient.rename_registered_model)
        # MlflowClient.update_registered_model = validate_wedata_before_operation(MlflowClient.update_registered_model)
        # MlflowClient.delete_registered_model = validate_wedata_before_operation(MlflowClient.delete_registered_model)
        # MlflowClient.update_model_version = validate_wedata_before_operation(MlflowClient.update_model_version)
        # MlflowClient.delete_model_version = validate_wedata_before_operation(MlflowClient.delete_model_version)
        # MlflowClient.set_model_version_tag = validate_wedata_before_operation(MlflowClient.set_model_version_tag)
        # MlflowClient.delete_model_version_tag = validate_wedata_before_operation(MlflowClient.delete_model_version_tag)
        # MlflowClient.set_registered_model_alias = validate_wedata_before_operation(MlflowClient.set_registered_model_alias)
        # MlflowClient.delete_registered_model_alias = validate_wedata_before_operation(MlflowClient.delete_registered_model_alias)
        # MlflowClient.set_registered_model_tag = validate_wedata_before_operation(MlflowClient.set_registered_model_tag)
        # MlflowClient.delete_registered_model_tag = validate_wedata_before_operation(MlflowClient.delete_registered_model_tag)

        _original_remote_registry = feast.infra.registry.remote.RemoteRegistry

        def add_feast_proxy_header():
            def func(*args, **kwargs):
                registry = _original_remote_registry(*args, **kwargs)
                proxy_header_interceptor = GrpcClientProxyHeaderInterceptor()
                registry.channel = grpc.intercept_channel(registry.channel, proxy_header_interceptor)
                registry.stub = RegistryServer_pb2_grpc.RegistryServerStub(registry.channel)
                return registry

            return func

        class GrpcClientProxyHeaderInterceptor(
            grpc.UnaryUnaryClientInterceptor,
            grpc.UnaryStreamClientInterceptor,
            grpc.StreamUnaryClientInterceptor,
            grpc.StreamStreamClientInterceptor,
        ):
            def __init__(self):
                self.proxy_ip = os.environ.get(FEAST_PROXY_ENV_KEY_IP)
                self.proxy_port = os.environ.get(FEAST_PROXY_ENV_KEY_PORT)
                if not self.proxy_ip:
                    raise FeastError(f"Environment variable `{FEAST_PROXY_ENV_KEY_IP}` is not set")
                if not self.proxy_port:
                    raise FeastError(f"Environment variable `{FEAST_PROXY_ENV_KEY_PORT}` is not set")

            def intercept_unary_unary(self, continuation, client_call_details, request_iterator):
                return self._handle_call(continuation, client_call_details, request_iterator)

            def intercept_unary_stream(self, continuation, client_call_details, request_iterator):
                return self._handle_call(continuation, client_call_details, request_iterator)

            def intercept_stream_unary(self, continuation, client_call_details, request_iterator):
                return self._handle_call(continuation, client_call_details, request_iterator)

            def intercept_stream_stream(self, continuation, client_call_details, request_iterator):
                return self._handle_call(continuation, client_call_details, request_iterator)

            def _handle_call(self, continuation, client_call_details, request_iterator):
                client_call_details = self._append_proxy_header_metadata(client_call_details)
                result = continuation(client_call_details, request_iterator)
                if result.exception() is not None:
                    mapped_error = FeastError.from_error_detail(result.exception().details())
                    if mapped_error is not None:
                        raise mapped_error
                return result

            def _append_proxy_header_metadata(self, client_call_details):
                metadata = client_call_details.metadata or []
                metadata.append((PROXY_HEADER_KEY_IP.lower(), self.proxy_ip))
                metadata.append((PROXY_HEADER_KEY_PORT.lower(), self.proxy_port))
                client_call_details = client_call_details._replace(metadata=metadata)
                return client_call_details

        feast.infra.registry.remote.RemoteRegistry = add_feast_proxy_header()
