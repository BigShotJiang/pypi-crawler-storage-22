import http
import os
import hashlib
import hmac
import json
import time
import logging
from datetime import datetime, timezone
from typing import Optional, Dict, Any, List
from http.client import HTTPSConnection

from mlflow import MlflowException, MlflowClient
from mlflow.environment_variables import MLFLOW_EXPERIMENT_ID
from mlflow.exceptions import RestException
from mlflow.protos.databricks_pb2 import ABORTED, BAD_REQUEST, INVALID_PARAMETER_VALUE, RESOURCE_DOES_NOT_EXIST
from mlflow.entities import Experiment, ViewType, ExperimentTag
from mlflow.store.entities import PagedList
from mlflow.store.tracking import SEARCH_MAX_RESULTS_DEFAULT
from mlflow.utils.search_utils import SearchExperimentsUtils
from mlflow.entities.lifecycle_stage import LifecycleStage
from mlflow.tracking import fluent


def log_msg(msg):
    tencent_cloud_debug = os.getenv("TENCENTCLOUD_DEBUG", None)
    if tencent_cloud_debug and tencent_cloud_debug.lower() in ["1", "true"]:
        print(msg)


class DataScienceApiException(Exception):
    def __init__(self, code: str, message: str, request_id: Optional[str] = None):
        self.code = code
        self.message = message
        self.request_id = request_id

    def __str__(self):
        return f"[DataScienceApiException] code:{self.code} message:{self.message} requestId:{self.request_id}"

    def get_code(self) -> str:
        return self.code

    def get_message(self) -> str:
        return self.message

    def get_request_id(self) -> str:
        return self.request_id or ""


class DataScienceApiMethod(object):
    _version = "2025-10-10"
    _service = "wedata"

    def __init__(self, action: str) -> None:
        self.action = action
        self._host = os.getenv("TENCENTCLOUD_ENDPOINT", "wedata.internal.tencentcloudapi.com")
        self._region = os.environ["KERNEL_WEDATA_REGION"]
        self._secret_id = os.environ["KERNEL_WEDATA_CLOUD_SDK_SECRET_ID"]
        self._secret_key = os.environ["KERNEL_WEDATA_CLOUD_SDK_SECRET_KEY"]
        self._token = os.environ.get("KERNEL_WEDATA_CLOUD_SDK_SECRET_TOKEN")

    def _sign(self, body: str, timestamp: int) -> str:
        """http请求签名"""
        algorithm = "TC3-HMAC-SHA256"
        date = datetime.fromtimestamp(timestamp, timezone.utc).strftime("%Y-%m-%d")

        # ************* 步骤 1：拼接规范请求串 *************
        http_request_method = "POST"
        canonical_uri = "/"
        canonical_querystring = ""
        ct = "application/json; charset=utf-8"
        canonical_headers = f"content-type:{ct}\nhost:{self._host}\nx-tc-action:{self.action.lower()}\n"
        signed_headers = "content-type;host;x-tc-action"
        hashed_request_payload = hashlib.sha256(body.encode("utf-8")).hexdigest()
        canonical_request = (f"{http_request_method}\n{canonical_uri}\n{canonical_querystring}\n{canonical_headers}\n"
                             f"{signed_headers}\n{hashed_request_payload}")

        # ************* 步骤 2：拼接待签名字符串 *************
        credential_scope = f"{date}/{self._service}/tc3_request"
        hashed_canonical_request = hashlib.sha256(canonical_request.encode("utf-8")).hexdigest()
        string_to_sign = f"{algorithm}\n{timestamp}\n{credential_scope}\n{hashed_canonical_request}"

        # ************* 步骤 3：计算签名 *************
        secret_date = hmac.new(("TC3" + self._secret_key).encode("utf-8"), date.encode("utf-8"), hashlib.sha256).digest()
        secret_service = hmac.new(secret_date, self._service.encode("utf-8"), hashlib.sha256).digest()
        secret_signing = hmac.new(secret_service, "tc3_request".encode("utf-8"), hashlib.sha256).digest()
        signature = hmac.new(secret_signing, string_to_sign.encode("utf-8"), hashlib.sha256).hexdigest()

        # ************* 步骤 4：拼接 Authorization *************
        authorization = (f"{algorithm} Credential={self._secret_id}/{credential_scope}, SignedHeaders={signed_headers}"
                         f", Signature={signature}")

        return authorization

    def _generate_headers(self, authorization: str, timestamp: int) -> Dict[str, str]:
        headers = {
            "Authorization": authorization,
            "Content-Type": "application/json; charset=utf-8",
            "Host": self._host,
            "X-TC-Action": self.action,
            "X-TC-Timestamp": str(timestamp),
            "X-TC-Version": self._version,
        }

        if self._region:
            headers["X-TC-Region"] = self._region
        if self._token:
            headers["X-TC-Token"] = self._token
        if "IS_WEDATA_TEST" in os.environ.keys():
            headers["X-Qcloud-User-Id"] = os.environ["TEST_USER_ID"]

        return headers

    def _request(self, payload: Dict[str, Any]):
        body = json.dumps(payload)
        timestamp = int(time.time())
        authorization = self._sign(body, timestamp)
        headers = self._generate_headers(authorization, timestamp)

        log_msg(f"host: {self._host}\naction: {self.action}\nbody: {json.dumps(payload, indent=2)}")
        req = HTTPSConnection(self._host, timeout=30)
        try:
            req.request("POST", "/", headers=headers, body=body.encode("utf-8"))
            resp = req.getresponse()
            content = resp.read().decode("utf-8")
        finally:
            req.close()

        log_msg(f"response: {content}")

        # check http status
        if resp.status != http.HTTPStatus.OK:
            raise DataScienceApiException("ServerNetworkError", content)
        try:
            data = json.loads(content)
        except json.JSONDecodeError:
            raise DataScienceApiException("DecodeError", content)

        # check error
        if "Error" in data["Response"]:
            code = data["Response"]["Error"]["Code"]
            message = data["Response"]["Error"]["Message"]
            req_id = data["Response"]["RequestId"]
            raise DataScienceApiException(code, message, req_id)

        return data

    def __call__(self, request: Dict[str, Any]) -> Dict[str, Any]:
        return self._request(request)


class DataScienceApiObject(object):
    def __getattr__(self, action: str) -> DataScienceApiMethod:
        return DataScienceApiMethod(action)

    def __getitem__(self, action: str) -> DataScienceApiMethod:
        return DataScienceApiMethod(action)


def create_experiment(
        self, name: str,
        artifact_location: Optional[str] = None,
        tags: Optional[dict[str, Any]] = None,
) -> str:
    req_body = {
        "WorkspaceId": os.environ["WEDATA_WORKSPACE_ID"],
        "Name": name,
        "Type": "MACHINE_LEARNING",
        "Tags": [{"Key": key, "Value": value} for key, value in (tags or {}).items()]
    }
    resp = DataScienceApiObject().CreateExperiment(req_body)
    return resp["Response"]["Data"]["ExperimentId"]


def rename_experiment(self, experiment_id: str, new_name: str) -> None:
    req_body = {
        "NewName": new_name,
        "ExperimentId": experiment_id,
        "WorkspaceId": os.environ["WEDATA_WORKSPACE_ID"],
    }
    resp = DataScienceApiObject().UpdateExperimentName(req_body)
    if not resp["Response"]["Data"]["Status"]:
        raise MlflowException("Failed to rename the experiment", BAD_REQUEST)


def restore_experiment(self, experiment_id: str) -> None:
    raise MlflowException("Please go to the WeData console to restore the experiment; "
                            "this operation is prohibited in scripts.", ABORTED)


def delete_experiment(self, experiment_id: str) -> None:
    raise MlflowException("Please go to the WeData console to delete the experiment; "
                            "this operation is prohibited in scripts.", ABORTED)


def _convert_to_experiment(resp: Dict[str, Any]) -> Experiment:
    tags: Optional[List[ExperimentTag]] = [
        ExperimentTag(tag["Key"], tag["Value"])
        for tag in resp.get("Tags", [])
    ]
    return Experiment(
        experiment_id=resp["ExperimentId"],
        name=resp["Name"],
        artifact_location=resp.get("ArtifactLocation"),
        lifecycle_stage=resp.get("LifecycleStage"),
        tags=tags,
        creation_time=resp["CreationTime"],
        last_update_time=resp["LastModifiedTime"],
    )


def get_experiment_by_name(self, name: str) -> Optional[Experiment]:
    req_body = {
        "WorkspaceId": os.environ["WEDATA_WORKSPACE_ID"],
        "ExperimentName": name,
    }
    try:
        resp = DataScienceApiObject().GetExperiment(req_body)
    except DataScienceApiException as e:
        if e.get_code() == "ResourceNotFound.MlflowResourceNotFound":
            return None
        raise

    return _convert_to_experiment(resp["Response"]["Data"])


def get_experiment(self, experiment_id: str) -> Experiment:
    req_body = {
        "WorkspaceId": os.environ["WEDATA_WORKSPACE_ID"],
        "ExperimentId": experiment_id,
    }
    resp = DataScienceApiObject().GetExperiment(req_body)
    return _convert_to_experiment(resp["Response"]["Data"])


def _parse_order_by(order_by: Optional[List[str]]) -> List[Dict[str, str]]:
    # 解析排序字符串
    if not order_by:
        return []

    results: List[Dict[str, str]] = []
    key_map: Dict[str, str] = {
        "name": "Name",
        "experiment_id": "ExperimentId",
        "creation_time": "CreationTime",
        "last_update_time": "LastUpdateTime",
    }
    for order_by_string in order_by:
        _, key, is_ascending = SearchExperimentsUtils.parse_order_by_for_search_experiments(order_by_string)
        if key not in key_map:
            raise RestException({
                "error_code": INVALID_PARAMETER_VALUE,
                "message": f"Invalid attribute key '{key}' specified. Valid keys are "
                           f"'{'last_update_time', 'name', 'experiment_id', 'creation_time'}'"
            })
        results.append({"Name": key_map[key], "Order": "ASC" if is_ascending else "DESC"})

    return results


def search_experiments(
        self,
        view_type: int = ViewType.ACTIVE_ONLY,
        max_results: Optional[int] = SEARCH_MAX_RESULTS_DEFAULT,
        filter_string: Optional[str] = None,
        order_by: Optional[List[str]] = None,
        page_token=None,
    ) -> PagedList[Experiment]:
    req_body = {
        "WorkspaceId": os.environ["WEDATA_WORKSPACE_ID"],
        "MaxResults": max_results,
        "OrderBys": _parse_order_by(order_by),
        "FilterString": filter_string or "",
        "ViewType": view_type
    }
    if page_token:
        req_body["PageToken"] = page_token

    resp = DataScienceApiObject().ListExperiments(req_body)
    experiments = [_convert_to_experiment(exp) for exp in resp["Response"]["Data"]["List"]]

    return PagedList(experiments, resp["Response"]["Data"].get("NextPageToken"))


def set_experiment(
    experiment_name: Optional[str] = None, experiment_id: Optional[str] = None
) -> Experiment:
    if (experiment_name is not None and experiment_id is not None) or (
        experiment_name is None and experiment_id is None
    ):
        raise MlflowException(
            message="Must specify exactly one of: `experiment_id` or `experiment_name`.",
            error_code=INVALID_PARAMETER_VALUE,
        )

    client = MlflowClient()

    with getattr(fluent, "_experiment_lock"):
        if experiment_id is None:
            experiment = client.get_experiment_by_name(experiment_name)
            if not experiment:
                logging.info(
                    "Experiment with name '%s' does not exist. Creating a new experiment.",
                    experiment_name,
                )
                try:
                    experiment_id = client.create_experiment(experiment_name)
                except DataScienceApiException as e:
                    if e.get_code() == "InvalidParameter.ExperimentNameAlreadyExists":
                        # NB: If two simultaneous processes attempt to set the same experiment
                        # simultaneously, a race condition may be encountered here wherein
                        # experiment creation fails
                        return client.get_experiment_by_name(experiment_name)
                    raise

                experiment = client.get_experiment(experiment_id)
        else:
            experiment = client.get_experiment(experiment_id)
            if experiment is None:
                raise MlflowException(
                    message=f"Experiment with ID '{experiment_id}' does not exist.",
                    error_code=RESOURCE_DOES_NOT_EXIST,
                )

        if experiment.lifecycle_stage != LifecycleStage.ACTIVE:
            raise MlflowException(
                message=(
                    f"Cannot set a deleted experiment {experiment.name!r} as the active"
                    " experiment. "
                    "You can restore the experiment, or permanently delete the "
                    "experiment to create a new one."
                ),
                error_code=INVALID_PARAMETER_VALUE,
            )

    setattr(fluent, "_active_experiment_id", experiment.experiment_id)

    # Set 'MLFLOW_EXPERIMENT_ID' environment variable
    # so that subprocess can inherit it.
    MLFLOW_EXPERIMENT_ID.set(experiment.experiment_id)

    return experiment


__ALL__ = [
    "create_experiment",
    "rename_experiment",
    "restore_experiment",
    "delete_experiment",
    "get_experiment_by_name",
    "get_experiment",
    "search_experiments",
    "set_experiment"
]
