from weegit.gui.windows import MainWindow
from weegit.gui.panels.eeg_signal_panel import EegSignalPanel


__all__ = [
    "MainWindow",
    "EegSignalPanel",
]
