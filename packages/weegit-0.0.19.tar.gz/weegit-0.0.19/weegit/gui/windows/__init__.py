from weegit.gui.windows.main import MainWindow


__all__ = [
    "MainWindow",
]
