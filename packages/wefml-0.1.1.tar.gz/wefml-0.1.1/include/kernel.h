#pragma once

int k();