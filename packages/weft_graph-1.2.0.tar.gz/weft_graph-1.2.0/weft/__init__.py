"""Weft - A local-first knowledge graph for your browsing."""

__version__ = "1.2.0"
