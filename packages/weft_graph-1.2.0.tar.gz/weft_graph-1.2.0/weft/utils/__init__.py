"""Utility modules for URL and text processing."""
