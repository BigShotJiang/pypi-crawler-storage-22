"""OpenAI provider generators."""
