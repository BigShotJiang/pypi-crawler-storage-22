"""
GraphQL API for Boards backend
"""

from .schema import schema

__all__ = ["schema"]
