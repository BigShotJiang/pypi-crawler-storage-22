from . import batch

def hello() -> str:
    return "Hello from wenbi!"
