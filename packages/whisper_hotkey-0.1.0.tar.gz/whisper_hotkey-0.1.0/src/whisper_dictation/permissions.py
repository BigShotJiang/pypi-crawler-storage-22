"""macOS permission requests for microphone and accessibility."""

import subprocess
import sys
import os


def get_python_path():
    """Return the resolved Python interpreter path."""
    return os.path.realpath(sys.executable)


def request_microphone_access():
    """Trigger the macOS microphone permission dialog."""
    print("Requesting microphone access...")
    print("  If prompted, click 'Allow' in the macOS dialog.\n")
    try:
        import sounddevice as sd
        sd.rec(int(0.1 * 16000), samplerate=16000, channels=1, dtype="float32")
        sd.wait()
        print("  Microphone access granted.\n")
    except Exception as e:
        print(f"  Microphone access may have been denied: {e}")
        print("  Go to System Settings > Privacy & Security > Microphone")
        print(f"  and enable access for: {get_python_path()}\n")


def request_accessibility_access():
    """Trigger the macOS accessibility permission prompt."""
    print("Requesting accessibility access...")
    print("  This is needed to detect the keyboard shortcut and paste text.\n")

    subprocess.run(
        ["osascript", "-e",
         'tell application "System Events" to keystroke ""'],
        capture_output=True,
    )

    terminal = os.environ.get("TERM_PROGRAM", "Terminal")
    print("  If the shortcut doesn't work after install, add BOTH of these")
    print("  in System Settings > Privacy & Security > Accessibility:\n")
    print(f"    1. Your terminal: {terminal}")
    print(f"    2. Python: {get_python_path()}\n")


def request_permissions():
    """Run all permission requests."""
    print("=" * 60)
    print("  whisper-dictation: Permission Setup")
    print("=" * 60)
    print()
    print(f"  Python interpreter: {get_python_path()}")
    print()

    request_microphone_access()
    request_accessibility_access()

    print("=" * 60)
    print("  After granting permissions, restart your terminal")
    print("  for changes to take effect.")
    print("=" * 60)
    print()
