from django.apps import AppConfig


class WhiteboxPluginDeviceInsta360Config(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "whitebox_plugin_device_insta360"
    verbose_name = "Insta360 Camera Support"
