from channels.layers import get_channel_layer

from whitebox.events import EventHandler
from .models import DeviceConnection
from .services import DeviceConnectionService

channel_layer = get_channel_layer()


class DeviceConnectionStatusUpdateHandler(EventHandler):
    """
    Handler for handling the `device.connection_status.update` event.
    """

    @staticmethod
    async def emit_device_connection_status_update(data, ctx):
        data = ctx["data"]

        await channel_layer.group_send(
            "management", {"type": "device.connection_status.update", "data": data}
        )

    default_callbacks = [
        emit_device_connection_status_update,
    ]

    async def handle(self, data):
        return {"data": data}


class BaseDeviceConnectionCommandHandler(EventHandler):
    async def _get_device_connection(self, device_connection_id):
        try:
            dc = await DeviceConnection.objects.aget(id=device_connection_id)
        except DeviceConnection.DoesNotExist:
            raise ValueError(
                f"DeviceConnection with ID: {device_connection_id} not found.",
            )

        return dc


class CommandDeviceConnectionConnectHandler(BaseDeviceConnectionCommandHandler):
    """
    Handler for handling the `command.device.device_connection.connect` event.
    """

    async def handle(self, data) -> dict:
        dc = await self._get_device_connection(
            device_connection_id=data.get("device_connection_id"),
        )
        await DeviceConnectionService.aconnect_device(dc)

        return {
            "device_connection": dc,
        }


class CommandDeviceConnectionDisconnectHandler(BaseDeviceConnectionCommandHandler):
    """
    Handler for handling the `command.device.device_connection.disconnect` event.
    """

    async def handle(self, data) -> dict:
        dc = await self._get_device_connection(
            device_connection_id=data.get("device_connection_id"),
        )
        await DeviceConnectionService.adisconnect_device(dc)

        return {
            "device_connection": dc,
        }
