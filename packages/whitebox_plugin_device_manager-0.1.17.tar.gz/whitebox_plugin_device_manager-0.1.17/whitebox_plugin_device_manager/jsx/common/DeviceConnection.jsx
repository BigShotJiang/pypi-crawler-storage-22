const { importWhiteboxComponent } = Whitebox;
const Button = importWhiteboxComponent("ui.button");
const IconLink = importWhiteboxComponent("icons.link");
const IconEclipse = importWhiteboxComponent("icons.eclipse");

const DeviceStatus = (
    {
        connectionStatus = null,
        connectionInfo = null,
    }
) => {
  let connectionText;
  let badgeColor;

  switch (connectionStatus) {
    case "connecting":
      connectionText = "Connecting...";
      badgeColor = "fill-warning";
      break;
    case "disconnecting":
      connectionText = "Disconnecting...";
      badgeColor = "fill-warning";
      break;
    case "connected":
      connectionText = "Connected";
      badgeColor = "fill-success";
      break;
    case "disconnected":
      connectionText = "Disconnected";
      badgeColor = "fill-error";
      break;
    case "failed":
      connectionText = "Failed to connect";
        badgeColor = "fill-error";
      break;
    default:
      connectionText = "Unknown";
      badgeColor = "fill-secondary";
      break;
  }

  if (connectionInfo) {
    connectionText += ` - ${connectionInfo}`;
  }

  return (
    <span className="inline-flex items-center gap-1">
      <IconEclipse className={"h-1.5 w-1.5 " + badgeColor} />
      {connectionText}
    </span>
  );
};

const DeviceConnection = (
    {
      deviceName,
      connectionStatus,
      connectionInfo = null,
      icon = null,
      action = null,
    }
) => {
  const deviceIcon = icon || <IconLink />;

  return (
    <div
      className="c_device_connection
                      flex p-4 items-center gap-4 self-stretch
                      border border-solid border-borders-default rounded-full"
    >
      <div className="">
        <Button
          typeClass="btn-secondary"
          leftIcon={deviceIcon}
          className="bg-x-low-emphasis"
        />
      </div>

      <div className="flex flex-col items-start gap-1 flex-1">
        <span className="text-full-emphasis font-bold leading-tight">
          {deviceName}
        </span>

        <DeviceStatus connectionStatus={connectionStatus}
                      connectionInfo={connectionInfo} />
      </div>

      {action && <div className="">{action}</div>}
    </div>
  );
};

export { DeviceConnection };
export default DeviceConnection;
