import os
import queue
import asyncio
import signal
import threading
import time
from copy import deepcopy

from django.core.management.base import BaseCommand
from channels.layers import get_channel_layer

from utils.locking import global_lock
from whitebox_plugin_device_manager.models import (
    DeviceConnection,
    ConnectionStatus,
)
from whitebox_plugin_device_manager.networking.wireless_interface_manager import (
    wireless_interface_manager,
)
from whitebox_plugin_device_manager.services import DeviceConnectionService


channel_layer = get_channel_layer()


class DaemonEventMixin:
    events_queue: queue.Queue = None
    events_to_subscribe: list = None

    def get_events_to_subscribe(self):
        if not self.events_to_subscribe:
            return []

        return self.events_to_subscribe

    async def _channel_event_loop_runner(self):
        channel_name = await channel_layer.new_channel()

        events_to_subscribe = self.get_events_to_subscribe()

        for event_type in events_to_subscribe:
            await channel_layer.group_add(event_type, channel_name)

        self.stdout.write("Daemon started and listening for events.")

        while True:
            # Wait for a new message using blocking pop (BZPOPMIN)
            message = await channel_layer.receive(channel_name)
            self.events_queue.put(message)

    def start_channel_event_loop(self):
        self.events_queue = queue.Queue()

        loop_thread = threading.Thread(
            target=asyncio.run,
            args=(self._channel_event_loop_runner(),),
            # This thread uses blocking calls so it cannot be shut down
            # gracefully. It only collects events and puts them into a queue, so
            # it's safe to run as a daemon thread
            daemon=True,
        )
        loop_thread.start()


class BaseDaemonCommand(DaemonEventMixin, BaseCommand):
    register_shutdown_signals = True
    graceful_shutdown_timeout_seconds = 10

    def __init__(self, *args, **kwargs):
        self.daemon_shutdown_event = threading.Event()
        self._graceful_shutdown_initiated = False

        super().__init__(*args, **kwargs)

    def _start_shutdown_timeout_timer(self, timeout_seconds):
        def _timeout_handler():
            self.stdout.write(
                f"Graceful shutdown timeout ({timeout_seconds} seconds). "
                "Forcing exit...",
            )
            os._exit(1)

        timer_thread = threading.Timer(
            timeout_seconds,
            _timeout_handler,
        )
        timer_thread.start()

    def _process_exit_signal_event(self, signum, frame):
        self.daemon_shutdown_event.set()

        if not self._graceful_shutdown_initiated:
            self._graceful_shutdown_initiated = True
            self.stdout.write(
                "Shutdown signal received. Initiating graceful shutdown...",
            )

            if self.graceful_shutdown_timeout_seconds:
                self._start_shutdown_timeout_timer(
                    self.graceful_shutdown_timeout_seconds,
                )
            return

        self.stdout.write(
            "Second shutdown signal received. Forcing exit...",
        )
        os._exit(1)

    def handle(self, *args, **options):
        if self.get_events_to_subscribe():
            self.start_channel_event_loop()

        if self.register_shutdown_signals:
            # Setup signal handlers for graceful shutdown for threads to use
            signal.signal(signal.SIGINT, self._process_exit_signal_event)
            signal.signal(signal.SIGTERM, self._process_exit_signal_event)

        self.run_daemon(*args, **options)

    def run_daemon(self, *args, **options):
        raise NotImplementedError("Subclasses must implement run_daemon method.")


class Command(BaseDaemonCommand):
    help = "Daemon to manage device connections."

    events_to_subscribe = [
        "command.device.device_connection.connect",
        "command.device.device_connection.disconnect",
    ]

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)

        self.device_2_interface_map: dict = None
        self.interface_2_device_map: dict = None

        self.connectivity_check_interval = 10  # seconds
        self.queue_check_interval = 0.2  # seconds

    # region locks
    # Lock objects are not reusable after being released, hence the helpers

    def _get_assignment_lock(self):
        return global_lock("device.connection_manager.assignment")

    def _get_connection_lock(self, iface_name, timeout=None):
        kwargs = {}
        if timeout is not None:
            kwargs["timeout"] = timeout

        return global_lock(
            f"device.connection_manager.connection.{iface_name}",
            **kwargs,
        )

    # endregion locks

    # region command processing

    def process_command_connect(self, message):
        device_connection_id = message.get("device_connection_id")
        if not device_connection_id:
            self.stderr.write(
                "Received connect command without device_connection_id.",
            )
            return

        self.stdout.write(
            f"Received connect command for DeviceConnection ID: "
            f"{device_connection_id}",
        )

        device_connection = DeviceConnection.objects.get(id=device_connection_id)
        with self._get_assignment_lock():
            iface_name = self.device_2_interface_map.get(device_connection.pk)
            if iface_name:
                # In case the device was already assigned an interface (e.g. in
                # cases of connection drops and reconnects), use that one
                self.stdout.write(
                    f"DeviceConnection ID: {device_connection_id} is already "
                    f"assigned to interface: {iface_name}.",
                )

            else:
                # Otherwise, assign the first available interface
                assigned = self._assign_device_connection_to_unused_interface(
                    device_connection,
                )
                if not assigned:
                    self.stderr.write(
                        f"No available interfaces to assign for "
                        f"DeviceConnection ID: {device_connection_id}.",
                    )
                    # Re-emit current status (disconnected) so it's clear the
                    # connection attempt is not happening
                    DeviceConnectionService.emit_device_connection_status_update(
                        device_connection,
                    )
                    return

                iface_name = self.device_2_interface_map[device_connection.pk]

        if self._is_device_connected(device_connection):
            self.stdout.write(
                f"DeviceConnection ID: {device_connection_id} is already "
                f"connected on interface: {iface_name}.",
            )
            device_connection.update_connection_status(ConnectionStatus.CONNECTED)
            DeviceConnectionService.emit_device_connection_status_update(
                device_connection,
            )
            return

        self._attempt_interface_connection_in_thread(
            iface_name,
            device_connection,
        )

    def process_command_disconnect(self, message):
        device_connection_id = message.get("device_connection_id")
        if not device_connection_id:
            self.stderr.write(
                "Received disconnect command without device_connection_id.",
            )
            return

        self.stdout.write(
            f"Received disconnect command for DeviceConnection ID: "
            f"{device_connection_id}",
        )

        if device_connection_id not in self.device_2_interface_map:
            self.stderr.write(
                f"DeviceConnection ID: {device_connection_id} is not "
                "currently assigned to any interface.",
            )
            return

        with self._get_assignment_lock():
            iface_name = self.device_2_interface_map.pop(device_connection_id)
            self.interface_2_device_map.pop(iface_name)

        self.stdout.write(
            f"Removed assignment of DeviceConnection ID: {device_connection_id} "
            f"from interface: {iface_name}",
        )

        device_connection = DeviceConnection.objects.get(id=device_connection_id)

        DeviceConnectionService.update_connection_status(
            device_connection,
            ConnectionStatus.DISCONNECTING,
        )

        with self._get_connection_lock(iface_name):
            success, message = wireless_interface_manager.disconnect_from_wifi(
                iface_name,
            )

        if not success:
            self.stderr.write(
                f"Failed to disconnect interface '{iface_name}': {message}",
            )
            return

        self.stdout.write(
            f"Successfully disconnected interface '{iface_name}'",
        )
        DeviceConnectionService.update_connection_status(
            device_connection,
            ConnectionStatus.DISCONNECTED,
        )

    def process_incoming_message(self, message):
        self.stdout.write(f"Received message: {message}")

        data = deepcopy(message)
        type_ = data.pop("type", None)

        if type_ == "command.device.device_connection.connect":
            handler = self.process_command_connect
        elif type_ == "command.device.device_connection.disconnect":
            handler = self.process_command_disconnect
        else:
            self.stderr.write(f"Unknown message type: {type_}")
            return

        try:
            handler(data)
        except Exception as e:
            self.stderr.write(f"Error processing message: {str(e)}")

    # endregion command processing

    def _get_device_connection_map(self):
        device_connections = DeviceConnection.objects.filter(
            connection_type="wifi",
        )
        device_connection_map = {
            dc.wifi_ssid: dc for dc in device_connections if dc.wifi_ssid
        }

        return device_connection_map

    def _get_interface_report(self, device_connection_map):
        # Filter out those that are already connected
        wifi_interfaces = wireless_interface_manager.get_interface_states()

        unassigned = []
        assigned = []
        mismatched = []

        for interface in wifi_interfaces:
            if interface.state == "disconnected":
                unassigned.append(interface)
                continue

            if interface.connection not in device_connection_map:
                mismatched.append(interface)
                continue

            assigned.append(interface)

        return unassigned, assigned, mismatched

    def _get_states_map(self):
        return {
            iface.device: iface
            for iface in wireless_interface_manager.get_interface_states()
        }

    def _is_device_connected(
        self,
        device_connection,
        states_map=None,
    ):
        # If not assigned, then not connected
        iface_name = self.device_2_interface_map.get(device_connection.pk)
        if not iface_name:
            return False

        if not states_map:
            states_map = self._get_states_map()

        state = states_map.get(iface_name)
        if state and state.state == "connected":
            if state.connection == device_connection.wifi_ssid:
                return True

        return False

    # region daemon initialization

    def _ensure_system_autoconnect_disabled(self):
        modified = wireless_interface_manager.set_autoconnect_off()

        for conn_uuid, conn_name in modified.items():
            self.stdout.write(
                f"Disabled autoconnect for connection: {conn_name} ({conn_uuid})",
            )

    def _initialize_current_situation(self, device_connection_map):
        # When daemon first starts, we'll check for the current state of
        # connections, and any recognized device connection will be assigned
        # to that interface for the duration of the daemon's runtime.
        #
        # Assignment lock is not applied here, as we are still in the
        # initialization phase.
        self.device_2_interface_map = {}
        self.interface_2_device_map = {}

        (
            unused,
            assigned,
            mismatched,
        ) = self._get_interface_report(device_connection_map)

        for iface in assigned:
            ssid = iface.connection
            iface_name = iface.device
            device_connection = device_connection_map.get(ssid)
            if not device_connection:
                continue

            self.device_2_interface_map[device_connection.pk] = iface_name
            self.interface_2_device_map[iface_name] = device_connection.pk
            self.stdout.write(
                f"Initialized assignment: Interface {iface_name} -> "
                f"DeviceConnection '{device_connection.name}' (SSID: {ssid})"
            )

        if mismatched:
            self.stderr.write(
                "Found mismatched interfaces during daemon initialization: "
                + ", ".join(
                    f"{iface.device} ({iface.connection})" for iface in mismatched
                ),
            )

    def _assign_available_interfaces(self, device_connection_map):
        # First, get all available networks
        reachable = wireless_interface_manager.get_networks_in_range()
        reachable_ssids = {net.ssid for net in reachable}

        # Then, check which DeviceConnections are available to connect to
        eligible_to_connect = []
        for ssid, dc in device_connection_map.items():
            if dc.pk in self.device_2_interface_map:
                # Already assigned
                continue

            if ssid not in reachable_ssids:
                # Not in range
                continue

            eligible_to_connect.append(dc)

        # Finally, assign interfaces to those eligible DeviceConnections
        for dc in eligible_to_connect:
            with self._get_assignment_lock():
                assigned = self._assign_device_connection_to_unused_interface(dc)

            if assigned:
                self.stdout.write(
                    f"Assigned interface to eligible DeviceConnection "
                    f"'{dc.name}' (SSID: {dc.wifi_ssid})",
                )

    def _initialize_daemon(self):
        # Upon startup, first, disable system autoconnect on. This ensures that
        # all interface changes are only our own doing going forward
        self._ensure_system_autoconnect_disabled()

        device_connection_map = self._get_device_connection_map()

        # Then, initialize current situation, mapping what Whitebox is currently
        # connected to for state tracking
        self._initialize_current_situation(device_connection_map)

        # Update DB state & emit current assignments to clients
        self._update_db_state()
        self._emit_current_assignments()

        # Upon startup, we also want to make sure Whitebox uses all available
        # interfaces to connect to any unconnected DeviceConnections that are
        # available (Wi-Fi network in range)
        self._assign_available_interfaces(device_connection_map)

        # Finally, attempt connections on all assigned interfaces
        self._attempt_device_connections(device_connection_map)

    def _update_db_state(self):
        states_map = self._get_states_map()

        for dc in DeviceConnection.objects.filter(connection_type="wifi"):
            is_connected = self._is_device_connected(dc, states_map)
            if is_connected and dc.connection_status != ConnectionStatus.CONNECTED:
                DeviceConnectionService.update_connection_status(
                    dc,
                    ConnectionStatus.CONNECTED,
                )
                continue

            if not is_connected and dc.connection_status == ConnectionStatus.CONNECTED:
                DeviceConnectionService.update_connection_status(
                    dc,
                    ConnectionStatus.DISCONNECTED,
                )

    def _emit_current_assignments(self):
        for dc in DeviceConnection.objects.filter(connection_type="wifi"):
            DeviceConnectionService.emit_device_connection_status_update(dc)

    # endregion daemon initialization

    # region interface allocation

    def _remove_deleted_device_connections(self, device_connection_map):
        # Check existing assignments, and remove any that no longer have
        # corresponding DeviceConnection entries.

        assigned_device_pks = list(self.device_2_interface_map.keys())

        for device_pk in assigned_device_pks:
            found = False
            for dc in device_connection_map.values():
                if dc.pk == device_pk:
                    found = True
                    break

            if found:
                continue

            # DeviceConnection entry no longer exists, remove assignment
            iface_name = self.device_2_interface_map.pop(device_pk)
            self.interface_2_device_map.pop(iface_name)

            self.stdout.write(
                f"Removed interface assignment for '{iface_name}' to missing "
                f"DeviceConnection ID: {device_pk}",
            )

    def _assign_device_connection_to_unused_interface(self, device_connection):
        # Make sure this method is run under assignment lock!
        # First check if it's already assigned
        if device_connection.pk in self.device_2_interface_map:
            return False

        interfaces = wireless_interface_manager.get_interface_states()

        # Sort interfaces by those without any connection first. That way,
        # even if some interface has a connection not managed by Whitebox,
        # it'll be used last. Already assigned interfaces will be ignored
        interfaces.sort(
            key=lambda iface: iface.state != "disconnected",
        )

        for interface in interfaces:
            if interface.device in self.interface_2_device_map:
                continue

            # Found an unused interface, assign it
            iface_name = interface.device
            self.device_2_interface_map[device_connection.pk] = iface_name
            self.interface_2_device_map[iface_name] = device_connection.pk

            return True

        # If we reached here, nothing was assigned
        return False

    # endregion interface allocation

    # region connection management

    def _attempt_interface_connection(self, iface_name, device_connection):
        # Ensure only one connection attempt per interface at a time. If a lock
        # already exists for the specific interface, use it, otherwise create a
        # new one.

        # Timeout for connection is 30s, so set a slightly longer one here to
        # ensure we don't attempt to release the lock later when it stops
        # existing (Redis throws an error)
        lock = self._get_connection_lock(iface_name, timeout=32)

        ssid = device_connection.wifi_ssid
        password = device_connection.wifi_password

        self.stdout.write(
            f"Attempting to connect to SSID: '{ssid}' on interface "
            f"'{iface_name}'...",
        )

        with lock:
            DeviceConnectionService.update_connection_status(
                device_connection,
                ConnectionStatus.CONNECTING,
            )

            success, message = wireless_interface_manager.connect_to_wifi(
                ssid,
                password,
                iface_name,
            )

        if not success:
            self.stderr.write(
                f"Failed to connect to SSID: '{ssid}' on interface "
                f"'{iface_name}': {message}",
            )

            DeviceConnectionService.update_connection_status(
                device_connection,
                ConnectionStatus.FAILED,
                message,
            )
            return False

        self.stdout.write(
            f"Successfully connected to SSID: '{ssid}' on interface "
            f"'{iface_name}'.",
        )
        DeviceConnectionService.update_connection_status(
            device_connection,
            ConnectionStatus.CONNECTED,
        )
        return True

    def _attempt_interface_connection_in_thread(
        self,
        iface_name,
        device_connection,
    ):
        thread = threading.Thread(
            target=self._attempt_interface_connection,
            args=(iface_name, device_connection),
        )
        thread.start()
        return thread

    def _attempt_device_connections(
        self,
        interfaces=None,
        device_connection_map=None,
    ):
        if not interfaces:
            interfaces = wireless_interface_manager.get_available_interfaces()

        if not device_connection_map:
            device_connection_map = self._get_device_connection_map()

        states_map = self._get_states_map()

        threads = []

        # Iterate over interfaces, verify if they are already connected where we
        # want them to be. If not, attempt to connect in a separate thread
        for iface_name in interfaces:
            device_pk = self.interface_2_device_map.get(iface_name)
            if not device_pk:
                # Interface not allocated
                continue

            device_connection = None
            for dc in device_connection_map.values():
                if dc.pk == device_pk:
                    device_connection = dc
                    break

            if not device_connection:
                self.stderr.write(
                    f"Could not find DeviceConnection for assigned interface "
                    f"{iface_name} (pk: {device_pk})",
                )
                continue

            if self._is_device_connected(
                device_connection,
                states_map,
            ):
                # Already connected
                continue

            # Verify there isn't already an ongoing connection attempt
            lock = self._get_connection_lock(iface_name)
            if lock.locked():
                continue

            thread = self._attempt_interface_connection_in_thread(
                iface_name,
                device_connection,
            )
            threads.append(thread)

    # endregion connection management

    def periodic_connectivity_checks(self):
        # Every so often, re-evaluate the connection state and act if needed:
        # - Remove deleted DeviceConnections from allocations
        # - Ensure allocated connected

        device_connection_map = self._get_device_connection_map()

        with self._get_assignment_lock():
            self._remove_deleted_device_connections(device_connection_map)

        self._attempt_device_connections(
            device_connection_map=device_connection_map,
        )

    def run_daemon(self, *args, **options):
        self._initialize_daemon()

        last_connectivity_check = time.monotonic()
        self.periodic_connectivity_checks()

        while not self.daemon_shutdown_event.is_set():
            # In case there are incoming messages in the queue, process them
            # immediately until the queue is empty
            try:
                message = self.events_queue.get(block=False)
                self.process_incoming_message(message)
                continue
            except queue.Empty:
                pass

            # If the queue is empty, periodically perform connection checks
            since_last_check = time.monotonic() - last_connectivity_check
            if since_last_check >= self.connectivity_check_interval:
                self.stdout.write("Performing periodic connectivity checks...")
                self.periodic_connectivity_checks()
                last_connectivity_check = time.monotonic()

            # Sleep briefly to avoid high CPU usage. Instead of normal sleep,
            # wait on the shutdown event to make the shutdown more instant if it
            # happens in the middle of the sleep
            self.daemon_shutdown_event.wait(timeout=self.queue_check_interval)
