import re
import subprocess

from enum import Enum
from typing import Dict, List, Optional, Tuple

from whitebox import get_plugin_logger
from . import nmcli


logger = get_plugin_logger(__name__)


class WiFiConnectionStatus(Enum):
    DISCONNECTED = "disconnected"
    CONNECTING = "connecting"
    CONNECTED = "connected"
    FAILED = "failed"


class WirelessInterfaceManager:
    """
    Manager for wireless interface connections to camera devices.
    This service dynamically detects available Wi-Fi interfaces and maps
    one interface per device connection, excluding system interfaces (e.g. used
    for hotspot).
    """

    _RE_MATCH_CONNECT_SUCCESS_CONNECTION_UUID = re.compile(
        r".*Device \'.*\' successfully activated with \'(.*)\'.*",
        flags=re.DOTALL,
    )

    _instance = None
    _initialized = False

    def __new__(cls):
        if cls._instance is None:
            cls._instance = super(WirelessInterfaceManager, cls).__new__(cls)
        return cls._instance

    def __init__(self):
        self.system_interfaces = ["wlan0"]

    # region interfaces

    def get_interface_states(self, include_system=False) -> list:
        """
        Discover all available Wi-Fi interfaces, excluding system_interfaces.
        """
        try:
            devices = nmcli.device_status()

        except (nmcli.NmcliNonZeroExit, nmcli.NmcliTimeout) as e:
            logger.error(
                f"Failed to discover Wi-Fi interfaces: {e.result.stderr.strip()}",
            )
            return []

        except nmcli.NmcliError as e:
            logger.error(f"Error discovering Wi-Fi interfaces: {str(e)}")
            return []

        interfaces = []
        for device in devices:
            # Include only WiFi interfaces
            if not (device.type == "wifi" and device.device.startswith("wlan")):
                continue

            # but exclude system interfaces (e.g. wlan0 - hotspot), unless
            # explicitly included
            if not include_system and device.device in self.system_interfaces:
                continue

            interfaces.append(device)

        interfaces = sorted(interfaces, key=lambda x: x.device)
        return interfaces

    def get_available_interfaces(self, include_system=False) -> List[str]:
        """
        Get list of available Wi-Fi interfaces.
        """
        return [
            iface.device
            for iface in self.get_interface_states(include_system=include_system)
        ]

    def get_interface_state(self, interface: str):
        """
        Get the state of a specific Wi-Fi interface.

        Args:
            interface: The Wi-Fi interface name

        Returns:
            nmcli device namedtuple or None if not found
        """
        interfaces = self.get_interface_states(include_system=True)
        for iface in interfaces:
            if iface.device == interface:
                return iface
        return None

    def get_interface_connected_ssid(self, interface: str) -> Optional[str]:
        """
        Get the SSID of the Wi-Fi network currently connected to the specified interface.

        Args:
            interface: The Wi-Fi interface name

        Returns:
            SSID string if connected, None otherwise
        """
        state = self.get_interface_state(interface)
        if state and state.state == "connected":
            return state.connection
        return None

    # endregion interfaces

    # region networks

    def get_networks_in_range(self):
        """
        Get list of Wi-Fi networks in range using nmcli.

        Multiple networks may have the same SSID, but different BSSID (MAC
        address). Results will be deduplicated based on both SSID and BSSID.

        Returns:
            List of nmcli Wi-Fi network namedtuples
        """

        try:
            networks = nmcli.device_wifi_list()

        except (nmcli.NmcliNonZeroExit, nmcli.NmcliTimeout) as e:
            logger.error(
                f"Failed to list Wi-Fi networks: {e.result.stderr.strip()}",
            )
            return []

        except nmcli.NmcliError as e:
            logger.error(f"Error listing Wi-Fi networks: {str(e)}")
            return []

        # System interfaces' result are excluded from this search
        eligible = [net for net in networks if net.device not in self.system_interfaces]

        # Multiple interfaces seeing the same networks will return duplicates,
        # so we deduplicate based on SSID and BSSID.
        seen = set()
        unique_networks = []

        for net in eligible:
            identifier = (net.ssid, net.bssid)
            if identifier not in seen:
                seen.add(identifier)
                unique_networks.append(net)

        return unique_networks

    # endregion networks

    # region commands

    def _post_connect_handle_autoconnect(self, interface, ssid, nmcli_stdout):
        output = nmcli_stdout.strip()
        match = self._RE_MATCH_CONNECT_SUCCESS_CONNECTION_UUID.match(output)
        if match:
            conn_uuid = match.group(1)
            self._set_autoconnect_off_for_connection(conn_uuid)
            logger.info(
                f"Autoconnect disabled for Wi-Fi connection '{ssid}' "
                f"on interface '{interface}'"
            )
        else:
            logger.error(
                f"Could not find connection UUID for Wi-Fi connection "
                f"'{ssid}' on interface '{interface}' after connection. "
                f"nmcli version: {nmcli.get_nmcli_version_string()}"
            )

    def connect_to_wifi(
        self,
        ssid: str,
        password: str,
        interface: str,
        disable_autoconnect: bool = True,
    ) -> Tuple[bool, str]:
        """
        Connect to a Wi-Fi network using nmcli on the specified interface.

        Args:
            ssid: The Wi-Fi network SSID
            password: The Wi-Fi network password
            interface: The Wi-Fi interface to use

        Returns:
            Tuple of (success, message)
        """
        current_ssid = self.get_interface_connected_ssid(interface)

        log_message = (
            f"Attempting to connect to Wi-Fi SSID '{ssid}' on interface "
            f"'{interface}'"
        )
        if current_ssid:
            log_message += f" (currently connected to '{current_ssid}')"

        logger.info(log_message)

        try:
            result = nmcli.device_wifi_connect(
                ssid,
                password,
                interface,
            )

        except nmcli.NmcliNonZeroExit as e:
            error_msg = e.result.stderr.strip() or "Connection failed"
            logger.error(
                f"Failed to connect to Wi-Fi network '{ssid}' on interface '{interface}': {error_msg}"
            )
            return False, error_msg

        except nmcli.NmcliTimeout:
            error_msg = "Connection attempt timed out"
            logger.error(
                f"Wi-Fi connection to '{ssid}' on interface '{interface}' timed out"
            )
            return False, error_msg

        except nmcli.NmcliError as e:
            error_msg = f"Unexpected error: {str(e)}"
            logger.error(
                f"Unexpected error connecting to Wi-Fi '{ssid}' on interface '{interface}': {error_msg}"
            )
            return False, error_msg

        logger.info(
            f"Successfully connected to Wi-Fi network '{ssid}' on interface '{interface}'"
        )

        if disable_autoconnect:
            self._post_connect_handle_autoconnect(
                interface,
                ssid,
                result.stdout,
            )

        return True, f"Connected to {ssid} on {interface}"

    def disconnect_from_wifi(self, interface: str) -> Tuple[bool, str]:
        """
        Disconnect from a Wi-Fi network on the provided interface.

        Args:
            interface: The Wi-Fi interface to disconnect from

        Returns:
            Tuple of (success, message)
        """

        ssid = self.get_interface_connected_ssid(interface)

        logger.info(f"Disconnecting from Wi-Fi interface '{interface}', SSID '{ssid}'")

        try:
            nmcli.device_disconnect(interface)

        except nmcli.NmcliNonZeroExit as e:
            error_msg = e.result.stderr.strip() or "Disconnection failed"
            logger.error(
                f"Failed to disconnect from Wi-Fi network '{ssid}' on interface "
                f"'{interface}': {error_msg}"
            )
            return False, error_msg

        except nmcli.NmcliError as e:
            error_msg = f"Unexpected error: {str(e)}"
            logger.error(
                f"Unexpected error disconnecting from Wi-Fi '{ssid}' on "
                f"interface '{interface}': {error_msg}"
            )
            return False, error_msg

        logger.info(
            f"Successfully disconnected from Wi-Fi network '{ssid}' on "
            f"interface '{interface}'"
        )
        return True, f"Disconnected from {ssid} on {interface}"

    def _set_autoconnect_off_for_connection(self, connection_uuid):
        nmcli.connection_modify(
            connection_uuid,
            {
                "connection.autoconnect": "no",
            },
        )

    def set_autoconnect_off(self, include_system=False):
        connections = nmcli.connection_show()

        modified = {}

        for conn in connections:
            if not include_system and conn.device in self.system_interfaces:
                # Skip managing the primary WiFi interface
                continue

            # When requested using `-g`, nmcli shows `wifi` as `802-11-wireless`
            if conn.type != "802-11-wireless":
                continue

            if conn.autoconnect != "yes":
                continue

            nmcli.connection_modify(
                conn.uuid,
                {
                    "connection.autoconnect": "no",
                },
            )
            modified[conn.uuid] = conn.name

        if modified:
            conns = ", ".join([f"{name} ({uuid})" for uuid, name in modified.items()])
            logger.info(
                f"Autoconnect disabled for {len(modified)} Wi-Fi connections: "
                f"{conns}"
            )

        return modified

    # endregion commands


wireless_interface_manager = WirelessInterfaceManager()
