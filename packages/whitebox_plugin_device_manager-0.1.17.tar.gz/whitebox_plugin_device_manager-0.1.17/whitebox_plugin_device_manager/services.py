import logging

from asgiref.sync import async_to_sync
from channels.layers import get_channel_layer

from whitebox.events import event_emitter
from .serializers import DeviceConnectionStatusSerializer
from .models import DeviceConnection, ConnectionStatus
from .networking.wireless_interface_manager import wireless_interface_manager


logger = logging.getLogger(__name__)


channel_layer = get_channel_layer()


class DeviceConnectionService:
    """
    Service class for handling device connection-related operations.
    """

    @classmethod
    def emit_device_connection_status_update(
        cls,
        device_connection,
    ) -> None:
        """
        Emit a device connection status update event to all connected clients
        and plugins who are listening for device connection status updates.

        Parameters:
            device_connection: The DeviceConnection instance to emit status for
        """

        device_connection_status_data = DeviceConnectionStatusSerializer(
            instance=device_connection
        ).data
        event_emitter.emit_sync(
            "device.connection_status.update", device_connection_status_data
        )

    @classmethod
    def _emit_connection_status_update(
        cls, device_connection: DeviceConnection
    ) -> None:
        """
        Emit a connection status update via WebSocket using the event system.

        Args:
            device_connection: The DeviceConnection instance to emit status for
        """
        try:
            DeviceConnectionService.emit_device_connection_status_update(
                device_connection
            )

            logger.debug(
                f"Emitted connection status update for device: {device_connection.name}"
            )

        except Exception as e:
            logger.error(f"Failed to emit connection status update: {str(e)}")

    @classmethod
    def connect_to_device_wifi(cls, device_connection_id: int) -> bool:
        """
        Connect to a device's Wi-Fi network.

        Args:
            device_connection_id: The ID of the DeviceConnection to connect to

        Returns:
            bool: True if connection was successful, False otherwise
        """
        try:
            device_connection = DeviceConnection.objects.get(id=device_connection_id)
        except DeviceConnection.DoesNotExist:
            logger.error(f"DeviceConnection with ID {device_connection_id} not found")
            return False

        if not device_connection.is_wifi_connection:
            logger.error(
                f"DeviceConnection {device_connection_id} is not a Wi-Fi connection"
            )
            return False

        logger.info(f"Connecting to Wi-Fi for device: {device_connection.name}")

        # Update status to connecting
        device_connection.update_connection_status(ConnectionStatus.CONNECTING)

        # Emit status update via WebSocket
        cls._emit_connection_status_update(device_connection)

        # Attempt to connect
        success, message = wireless_interface_manager.connect_to_wifi(
            device_connection.id,
            device_connection.wifi_ssid,
            device_connection.wifi_password,
        )

        if success:
            device_connection.update_connection_status(ConnectionStatus.CONNECTED)
            logger.info(
                f"Successfully connected to Wi-Fi for device: {device_connection.name}"
            )
        else:
            device_connection.update_connection_status(ConnectionStatus.FAILED, message)
            logger.error(
                f"Failed to connect to Wi-Fi for device {device_connection.name}: {message}"
            )

        # Emit updated status via WebSocket
        cls._emit_connection_status_update(device_connection)

        return success

    @classmethod
    def disconnect_from_device_wifi(cls, device_connection_id: int) -> bool:
        """
        Disconnect from a device's Wi-Fi network.

        Args:
            device_connection_id: The ID of the DeviceConnection to disconnect from

        Returns:
            bool: True if disconnection was successful, False otherwise
        """
        try:
            device_connection = DeviceConnection.objects.get(id=device_connection_id)
        except DeviceConnection.DoesNotExist:
            logger.error(f"DeviceConnection with ID {device_connection_id} not found")
            return False

        if not device_connection.is_wifi_connection:
            logger.error(
                f"DeviceConnection {device_connection_id} is not a Wi-Fi connection"
            )
            return False

        logger.info(f"Disconnecting from Wi-Fi for device: {device_connection.name}")

        success, message = wireless_interface_manager.disconnect_from_wifi(
            device_connection.id, device_connection.wifi_ssid
        )

        if success:
            device_connection.update_connection_status(ConnectionStatus.DISCONNECTED)
            logger.info(
                f"Successfully disconnected from Wi-Fi for device: {device_connection.name}"
            )
        else:
            logger.error(
                f"Failed to disconnect from Wi-Fi for device {device_connection.name}: {message}"
            )

        # Emit updated status via WebSocket
        cls._emit_connection_status_update(device_connection)

        return success

    @classmethod
    def update_connection_status(
        cls,
        device_connection: DeviceConnection,
        new_status: ConnectionStatus,
        error_message: str = "",
    ) -> None:
        """
        Update the connection status of a device and emit a status update event.

        Args:
            device_connection: The DeviceConnection instance to update
            new_status: The new ConnectionStatus to set
            error_message: Optional error message if the status is FAILED
        """
        device_connection.update_connection_status(new_status, error_message)
        cls._emit_connection_status_update(device_connection)

    @classmethod
    async def _send_command(cls, command: str, **data) -> None:
        """
        Send a command to the daemon via the event system.

        Args:
            command: The command event type to send
            data: The data payload for the command
        """

        payload = {
            "type": command,
            **data,
        }
        await channel_layer.group_send(command, payload)

    @classmethod
    async def aconnect_device(cls, device_connection: DeviceConnection):
        """
        Instruct daemon to connect to the device.

        Args:
            device_connection: The DeviceConnection instance to connect
        """

        await cls._send_command(
            "command.device.device_connection.connect",
            device_connection_id=device_connection.id,
        )

    @classmethod
    async def adisconnect_device(cls, device_connection: DeviceConnection):
        """
        Instruct daemon to disconnect from the device.

        Args:
            device_connection: The DeviceConnection instance to disconnect
        """

        await cls._send_command(
            "command.device.device_connection.disconnect",
            device_connection_id=device_connection.id,
        )

    @classmethod
    def connect_device(cls, device_connection: DeviceConnection):
        """
        Instruct daemon to connect to the device (synchronous wrapper).

        Args:
            device_connection: The DeviceConnection instance to connect
        """

        async_to_sync(cls.aconnect_device)(device_connection)

    @classmethod
    def disconnect_device(cls, device_connection: DeviceConnection):
        """
        Instruct daemon to disconnect from the device (synchronous wrapper).

        Args:
            device_connection: The DeviceConnection instance to disconnect
        """

        async_to_sync(cls.adisconnect_device)(device_connection)
