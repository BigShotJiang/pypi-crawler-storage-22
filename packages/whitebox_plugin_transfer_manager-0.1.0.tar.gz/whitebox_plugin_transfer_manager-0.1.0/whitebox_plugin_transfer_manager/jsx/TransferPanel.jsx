import { useState } from "react";
import useTransferStore, { ACTIVE_STATUSES } from "./stores/transfer";

const { importWhiteboxComponent } = Whitebox;

const IconClose = importWhiteboxComponent("icons.close");
const IconChevronDown = importWhiteboxComponent("icons.chevron-down");
const IconChevronUp = importWhiteboxComponent("icons.chevron-up");

const formatSpeed = (bytesPerSec) => {
  if (!bytesPerSec) return "";
  if (bytesPerSec > 1024 * 1024) {
    return `${(bytesPerSec / (1024 * 1024)).toFixed(1)} MB/s`;
  }
  if (bytesPerSec > 1024) {
    return `${(bytesPerSec / 1024).toFixed(0)} KB/s`;
  }
  return `${bytesPerSec.toFixed(0)} B/s`;
};

const getFilename = (sourcePath) => {
  if (!sourcePath) return "Unknown";
  return sourcePath.split("/").pop();
};

const getProgress = (transfer) => {
  const status = transfer.status_display;
  if (status === "Download Started") return transfer.download_percent || 0;
  if (status === "Processing Started") return transfer.processing_percent || 0;
  if (status === "Download Completed" || status === "Processing Completed") return 100;
  return 0;
};

const getPhaseLabel = (status) => {
  switch (status) {
    case "Pending": return "Queued";
    case "Download Started": return "Downloading";
    case "Download Completed": return "Downloaded";
    case "Processing Started": return "Processing";
    case "Processing Completed": return "Complete";
    case "Failed": return "Failed";
    case "Cancelled": return "Cancelled";
    case "Paused": return "Paused";
    default: return status;
  }
};

const TransferItem = ({ transfer }) => {
  const filename = getFilename(transfer.source_path);
  const status = transfer.status_display;
  const label = getPhaseLabel(status);
  const progress = getProgress(transfer);
  const isActive = ACTIVE_STATUSES.includes(status);
  const isFailed = status === "Failed";
  const isComplete = status === "Processing Completed";
  const showSpeed = status === "Download Started" && transfer.download_speed;

  return (
    <div className="px-5 py-3">
      <div className="flex items-center justify-between">
        <span className="text-sm font-medium truncate flex-1 mr-3" title={filename}>
          {filename}
        </span>
        <span className={`text-xs whitespace-nowrap ${
          isFailed ? "text-error" :
          isComplete ? "text-success" :
          "text-gray-4"
        }`}>
          {label}
          {showSpeed && ` \u00b7 ${formatSpeed(transfer.download_speed)}`}
        </span>
      </div>

      {isActive && (
        <div className="mt-2 w-full bg-gray-6 rounded-full h-1.5">
          <div
            className={`h-1.5 rounded-full transition-all duration-500 ${
              status === "Processing Started" ? "bg-warning" : "bg-surface-primary"
            }`}
            style={{ width: `${progress}%` }}
          />
        </div>
      )}
    </div>
  );
};

const TransferPanel = () => {
  const transfers = useTransferStore((state) => state.transfers);
  const activeCount = useTransferStore((state) => state.activeCount);
  const dismissAll = useTransferStore((state) => state.dismissAll);
  const [minimized, setMinimized] = useState(false);
  const allDone = activeCount === 0;

  const transferList = Object.values(transfers).sort((a, b) => {
    if (!a.queued_at || !b.queued_at) return 0;
    return new Date(b.queued_at) - new Date(a.queued_at);
  });

  if (transferList.length === 0) return null;

  return (
    <div
      className="fixed bottom-6 right-4 z-50 bg-white rounded-2xl overflow-hidden"
      style={{
        width: 360,
        maxHeight: minimized ? "auto" : 320,
        boxShadow: "0 4px 24px rgba(0, 0, 0, 0.08), 0 1px 4px rgba(0, 0, 0, 0.04)",
      }}
    >
      {/* Header */}
      <div
        className="flex items-center justify-between px-5 py-3.5 cursor-pointer select-none"
        onClick={() => setMinimized(!minimized)}
      >
        <span className="text-base font-bold">
          Transfers
          {activeCount > 0 && (
            <span className="font-normal text-gray-3 ml-1.5 text-sm">
              {activeCount} active
            </span>
          )}
        </span>
        <div className="flex items-center gap-1">
          {allDone && (
            <button
              className="text-gray-3 hover:text-gray-1 p-0.5"
              onClick={(e) => { e.stopPropagation(); dismissAll(); }}
              title="Dismiss"
            >
              <IconClose
                width={20}
                height={20}
                className="fill-gray-3"
              />
            </button>
          )}
          <span className="text-gray-3">
            {minimized
              ? <IconChevronUp width={20} height={20} className="fill-gray-3" />
              : <IconChevronDown width={20} height={20} className="fill-gray-3" />
            }
          </span>
        </div>
      </div>

      {/* Transfer list */}
      {!minimized && (
        <div
          className="overflow-y-auto divide-y divide-gray-6 border-t border-gray-5"
          style={{ maxHeight: 260 }}
        >
          {transferList.map((transfer) => (
            <TransferItem key={transfer.id} transfer={transfer} />
          ))}
        </div>
      )}
    </div>
  );
};

export { TransferPanel };
export default TransferPanel;
