import threading
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path
from typing import Callable, Protocol, runtime_checkable


@dataclass
class RemoteFile:
    """Represents a file on a remote device."""

    path: str
    size: int | None = None
    created_at: datetime | None = None
    checksum: str | None = None
    metadata: dict = field(default_factory=dict)


@runtime_checkable
class TransferAdapter(Protocol):
    """
    Protocol for device-specific file transfer implementations.

    Device plugins implement this to handle downloading and processing
    files from their specific device types.
    """

    def list_files(self, device_connection) -> list[RemoteFile]:
        """
        List files available on device.

        Args:
            device_connection: DeviceConnection model instance

        Returns:
            List of RemoteFile objects representing available files
        """
        ...

    def get_file_info(self, device_connection, path: str) -> RemoteFile:
        """
        Get metadata for a specific file on the device.

        Args:
            device_connection: DeviceConnection model instance
            path: Path to file on device

        Returns:
            RemoteFile with metadata
        """
        ...

    def download_file(
        self,
        device_connection,
        source_path: str,
        destination_path: Path,
        progress_callback: Callable[[int, int | None], None],
        cancel_event: threading.Event,
    ) -> bool:
        """
        Download file from device with progress reporting.

        Args:
            device_connection: DeviceConnection model instance
            source_path: Path on device
            destination_path: Local path to save file
            progress_callback: Called with (bytes_so_far, total_bytes)
            cancel_event: Set when download should be aborted

        Returns:
            True on success, False on failure
        """
        ...

    def supports_resume(self) -> bool:
        """
        Whether device supports HTTP range requests for resume.

        Returns:
            True if partial downloads can be resumed
        """
        ...

    def process_file(
        self,
        source_path: Path,
        destination_path: Path,
        progress_callback: Callable[[int, str | None], None],
        cancel_event: threading.Event,
    ) -> bool:
        """
        Process downloaded file (transcode, stitch, etc.).

        Args:
            source_path: Path to downloaded raw file
            destination_path: Path for processed output
            progress_callback: Called with (percent_complete, step_description)
            cancel_event: Set when processing should be aborted

        Returns:
            True on success, False on failure
        """
        ...
