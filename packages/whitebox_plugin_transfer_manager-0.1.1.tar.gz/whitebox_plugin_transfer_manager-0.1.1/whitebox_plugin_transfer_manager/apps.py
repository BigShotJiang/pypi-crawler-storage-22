from django.apps import AppConfig

from plugin.registry import model_registry


class TransferManagerConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "whitebox_plugin_transfer_manager"
    verbose_name = "Transfer Manager"

    def ready(self):
        from .models import Transfer

        model_registry.register("transfer.Transfer", Transfer)
