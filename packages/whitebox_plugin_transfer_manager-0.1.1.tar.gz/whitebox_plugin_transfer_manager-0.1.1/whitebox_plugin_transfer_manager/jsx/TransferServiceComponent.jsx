import { useEffect } from "react";
import useTransferStore from "./stores/transfer";

const { importWhiteboxStateStore, withStateStore } = Whitebox;

const TransferServiceComponentToWrap = () => {
  const upsertTransfer = useTransferStore((state) => state.upsertTransfer);
  const useMissionControlStore = importWhiteboxStateStore("flight.mission-control");
  const fetchFlightSessions = useMissionControlStore(
    (state) => state.fetchFlightSessions
  );

  useEffect(() => {
    const removeListener = Whitebox.sockets.addEventListener(
      "management",
      "message",
      (event) => {
        const data = JSON.parse(event.data);

        if (!data.type?.startsWith("observation.transfer.")) return;

        upsertTransfer(data.data);

        const filename =
          data.data?.source_path?.split("/").pop() || "file";

        if (data.type === "observation.transfer.download.started") {
          Whitebox.toasts.info(`Downloading ${filename}...`);
        } else if (data.type === "observation.transfer.processing.completed") {
          Whitebox.toasts.success(`Transfer complete: ${filename}`);
          fetchFlightSessions();
        } else if (data.type.endsWith(".failed")) {
          Whitebox.toasts.error(`Transfer failed: ${filename}`);
        }
      }
    );

    return removeListener;
  }, []);

  return null;
};

const TransferServiceComponent = withStateStore(
  TransferServiceComponentToWrap,
  ["flight.mission-control"]
);

export { TransferServiceComponent };
export default TransferServiceComponent;
