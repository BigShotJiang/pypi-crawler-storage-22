import { create } from "zustand";

const ACTIVE_STATUSES = [
  "Download Started",
  "Download Completed",
  "Processing Started",
];

const COMPLETED_STATUSES = [
  "Processing Completed",
];

const createTransferSlice = (set, get) => ({
  transfers: {},
  activeCount: 0,

  upsertTransfer: (data) => {
    set((state) => {
      const transfers = { ...state.transfers, [data.id]: data };
      const activeCount = Object.values(transfers).filter((t) =>
        ACTIVE_STATUSES.includes(t.status_display)
      ).length;
      return { transfers, activeCount };
    });
  },

  removeTransfer: (id) => {
    set((state) => {
      const transfers = { ...state.transfers };
      delete transfers[id];
      const activeCount = Object.values(transfers).filter((t) =>
        ACTIVE_STATUSES.includes(t.status_display)
      ).length;
      return { transfers, activeCount };
    });
  },

  clearCompleted: () => {
    set((state) => {
      const transfers = {};
      for (const [id, transfer] of Object.entries(state.transfers)) {
        if (!COMPLETED_STATUSES.includes(transfer.status_display)) {
          transfers[id] = transfer;
        }
      }
      const activeCount = Object.values(transfers).filter((t) =>
        ACTIVE_STATUSES.includes(t.status_display)
      ).length;
      return { transfers, activeCount };
    });
  },

  dismissAll: () => {
    set({ transfers: {}, activeCount: 0 });
  },
});

const useTransferStore = create((...a) => ({
  ...createTransferSlice(...a),
}));

export { ACTIVE_STATUSES, COMPLETED_STATUSES };
export default useTransferStore;
