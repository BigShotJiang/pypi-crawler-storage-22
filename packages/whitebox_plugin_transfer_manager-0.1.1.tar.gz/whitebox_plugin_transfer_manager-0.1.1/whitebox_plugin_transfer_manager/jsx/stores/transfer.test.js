import useTransferStore, { ACTIVE_STATUSES, COMPLETED_STATUSES } from "./transfer";

describe("useTransferStore", () => {
  beforeEach(() => {
    useTransferStore.setState({ transfers: {}, activeCount: 0 });
  });

  describe("Initial State", () => {
    test("should have empty transfers and zero activeCount", () => {
      const state = useTransferStore.getState();

      expect(state.transfers).toEqual({});
      expect(state.activeCount).toBe(0);
    });

    test("should have all required methods", () => {
      const state = useTransferStore.getState();

      expect(typeof state.upsertTransfer).toBe("function");
      expect(typeof state.removeTransfer).toBe("function");
      expect(typeof state.clearCompleted).toBe("function");
      expect(typeof state.dismissAll).toBe("function");
    });
  });

  describe("Constants", () => {
    test("ACTIVE_STATUSES should contain expected values", () => {
      expect(ACTIVE_STATUSES).toContain("Download Started");
      expect(ACTIVE_STATUSES).toContain("Download Completed");
      expect(ACTIVE_STATUSES).toContain("Processing Started");
      expect(ACTIVE_STATUSES).toHaveLength(3);
    });

    test("COMPLETED_STATUSES should contain expected values", () => {
      expect(COMPLETED_STATUSES).toContain("Processing Completed");
      expect(COMPLETED_STATUSES).toHaveLength(1);
    });
  });

  describe("upsertTransfer", () => {
    test("should add a new transfer", () => {
      const { upsertTransfer } = useTransferStore.getState();

      upsertTransfer({
        id: "t1",
        status_display: "Pending",
        source_path: "/DCIM/file.insv",
      });

      const state = useTransferStore.getState();
      expect(Object.keys(state.transfers)).toHaveLength(1);
      expect(state.transfers["t1"].source_path).toBe("/DCIM/file.insv");
    });

    test("should update an existing transfer", () => {
      const { upsertTransfer } = useTransferStore.getState();

      upsertTransfer({ id: "t1", status_display: "Pending" });
      upsertTransfer({ id: "t1", status_display: "Download Started" });

      const state = useTransferStore.getState();
      expect(Object.keys(state.transfers)).toHaveLength(1);
      expect(state.transfers["t1"].status_display).toBe("Download Started");
    });

    test("should preserve other transfers on update", () => {
      const { upsertTransfer } = useTransferStore.getState();

      upsertTransfer({ id: "t1", status_display: "Pending" });
      upsertTransfer({ id: "t2", status_display: "Pending" });
      upsertTransfer({ id: "t1", status_display: "Download Started" });

      const state = useTransferStore.getState();
      expect(Object.keys(state.transfers)).toHaveLength(2);
      expect(state.transfers["t2"].status_display).toBe("Pending");
    });

    test("should recalculate activeCount for active transfer", () => {
      const { upsertTransfer } = useTransferStore.getState();

      upsertTransfer({ id: "t1", status_display: "Download Started" });

      const state = useTransferStore.getState();
      expect(state.activeCount).toBe(1);
    });

    test("should not count completed transfers as active", () => {
      const { upsertTransfer } = useTransferStore.getState();

      upsertTransfer({ id: "t1", status_display: "Processing Completed" });

      const state = useTransferStore.getState();
      expect(state.activeCount).toBe(0);
    });

    test("should count all active statuses correctly", () => {
      const { upsertTransfer } = useTransferStore.getState();

      upsertTransfer({ id: "t1", status_display: "Download Started" });
      upsertTransfer({ id: "t2", status_display: "Download Completed" });
      upsertTransfer({ id: "t3", status_display: "Processing Started" });

      const state = useTransferStore.getState();
      expect(state.activeCount).toBe(3);
    });

    test("should decrement activeCount when status changes to inactive", () => {
      const { upsertTransfer } = useTransferStore.getState();

      upsertTransfer({ id: "t1", status_display: "Download Started" });
      expect(useTransferStore.getState().activeCount).toBe(1);

      upsertTransfer({ id: "t1", status_display: "Processing Completed" });
      expect(useTransferStore.getState().activeCount).toBe(0);
    });
  });

  describe("removeTransfer", () => {
    test("should remove a transfer by id", () => {
      const { upsertTransfer, removeTransfer } = useTransferStore.getState();

      upsertTransfer({ id: "t1", status_display: "Pending" });
      upsertTransfer({ id: "t2", status_display: "Pending" });
      removeTransfer("t1");

      const state = useTransferStore.getState();
      expect(Object.keys(state.transfers)).toHaveLength(1);
      expect(state.transfers["t1"]).toBeUndefined();
      expect(state.transfers["t2"]).toBeDefined();
    });

    test("should be a noop for unknown id", () => {
      const { upsertTransfer, removeTransfer } = useTransferStore.getState();

      upsertTransfer({ id: "t1", status_display: "Pending" });
      removeTransfer("nonexistent");

      const state = useTransferStore.getState();
      expect(Object.keys(state.transfers)).toHaveLength(1);
    });

    test("should recalculate activeCount after removal", () => {
      const { upsertTransfer, removeTransfer } = useTransferStore.getState();

      upsertTransfer({ id: "t1", status_display: "Download Started" });
      upsertTransfer({ id: "t2", status_display: "Processing Started" });
      expect(useTransferStore.getState().activeCount).toBe(2);

      removeTransfer("t1");
      expect(useTransferStore.getState().activeCount).toBe(1);
    });
  });

  describe("clearCompleted", () => {
    test("should remove only completed transfers", () => {
      const { upsertTransfer, clearCompleted } = useTransferStore.getState();

      upsertTransfer({ id: "t1", status_display: "Download Started" });
      upsertTransfer({ id: "t2", status_display: "Processing Completed" });
      upsertTransfer({ id: "t3", status_display: "Failed" });

      clearCompleted();

      const state = useTransferStore.getState();
      expect(Object.keys(state.transfers)).toHaveLength(2);
      expect(state.transfers["t1"]).toBeDefined();
      expect(state.transfers["t2"]).toBeUndefined();
      expect(state.transfers["t3"]).toBeDefined();
    });

    test("should be a noop when no completed transfers", () => {
      const { upsertTransfer, clearCompleted } = useTransferStore.getState();

      upsertTransfer({ id: "t1", status_display: "Download Started" });
      upsertTransfer({ id: "t2", status_display: "Failed" });

      clearCompleted();

      const state = useTransferStore.getState();
      expect(Object.keys(state.transfers)).toHaveLength(2);
    });

    test("should recalculate activeCount correctly", () => {
      const { upsertTransfer, clearCompleted } = useTransferStore.getState();

      upsertTransfer({ id: "t1", status_display: "Download Started" });
      upsertTransfer({ id: "t2", status_display: "Processing Completed" });

      clearCompleted();

      const state = useTransferStore.getState();
      expect(state.activeCount).toBe(1);
    });
  });

  describe("dismissAll", () => {
    test("should clear everything", () => {
      const { upsertTransfer, dismissAll } = useTransferStore.getState();

      upsertTransfer({ id: "t1", status_display: "Download Started" });
      upsertTransfer({ id: "t2", status_display: "Processing Completed" });
      upsertTransfer({ id: "t3", status_display: "Failed" });

      dismissAll();

      const state = useTransferStore.getState();
      expect(state.transfers).toEqual({});
      expect(state.activeCount).toBe(0);
    });
  });
});
