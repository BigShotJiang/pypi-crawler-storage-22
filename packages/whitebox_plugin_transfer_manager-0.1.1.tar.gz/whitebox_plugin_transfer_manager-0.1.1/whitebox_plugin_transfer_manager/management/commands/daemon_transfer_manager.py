import queue
import time
from pathlib import Path

from django.conf import settings
from plugin.manager import plugin_manager
from utils.daemons import BaseDaemonCommand

from whitebox import import_whitebox_model
from whitebox_plugin_transfer_manager.adapter import RemoteFile
from whitebox_plugin_transfer_manager.manager import transfer_manager

DeviceConnection = import_whitebox_model("device.DeviceConnection")
FlightSession = import_whitebox_model("flight.FlightSession")


class Command(BaseDaemonCommand):
    help = "Transfer Manager Daemon - orchestrates file transfers from devices"

    events_to_subscribe = [
        "observation.flight.end",
        "observation.device.connection_status.update",
        "command.transfer.cancel",
        "command.transfer.retry",
        "command.transfer.queue_batch",
    ]

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.manager = transfer_manager
        self.periodic_check_interval = 5  # seconds

    def _initialize(self):
        """Run once on startup."""
        self.stdout.write("Initializing Transfer Manager Daemon...")

        # Discover and register adapters from installed device plugins
        self._discover_adapters()

        # Recover any transfers that were ACTIVE when daemon last stopped
        recovered = self.manager.recover_interrupted_transfers()
        if recovered:
            self.stdout.write(f"Recovered {recovered} interrupted transfers")

        # Check for pending transfers and dispatch
        self.manager.dispatch_pending_sync()

        self.stdout.write("Transfer Manager Daemon initialized.")

    def _discover_adapters(self):
        """
        Discover TransferAdapters from installed device plugins.
        Uses Whitebox's plugin_manager to iterate loaded plugins and calls
        plugin instance method get_transfer_adapters().
        """
        for plugin_name, plugin_info in plugin_manager.plugin_info.items():
            if not plugin_info.is_loaded or not plugin_info.loaded_plugin_instance:
                continue

            plugin_instance = plugin_info.loaded_plugin_instance

            get_adapters_fn = getattr(plugin_instance, "get_transfer_adapters", None)
            if get_adapters_fn is None:
                continue

            try:
                adapters = get_adapters_fn()
                if adapters:
                    for device_codename, adapter in adapters:
                        self.manager.register_adapter(device_codename, adapter)
                        self.stdout.write(
                            f"Registered transfer adapter: {device_codename}"
                        )
            except Exception as e:
                self.stderr.write(f"Failed to load adapters from {plugin_name}: {e}")

    def _process_message_queue(self):
        """Process all pending messages from the event queue."""
        while True:
            try:
                message = self.events_queue.get(block=False)
                self._handle_message(message)
            except queue.Empty:
                break

    def _handle_message(self, message):
        """Handle a single event message."""
        msg_type = message.get("type")

        if msg_type == "observation.flight.end":
            # Flight ended - device plugins should queue their transfers
            # We don't need to do anything here, just dispatch pending
            self.manager.dispatch_pending_sync()

        elif msg_type == "observation.device.connection_status.update":
            data = message.get("data", {})
            if data.get("connection_status") == "connected":
                # Device reconnected - check for pending transfers
                device_connection_id = data.get("id")
                if device_connection_id:
                    self.stdout.write(
                        f"Device {device_connection_id} reconnected, "
                        "dispatching pending transfers..."
                    )
                    self.manager.dispatch_pending_for_device(device_connection_id)

        elif msg_type == "command.transfer.cancel":
            transfer_id = message.get("transfer_id")
            if transfer_id:
                self.stdout.write(f"Cancelling transfer {transfer_id}")
                self.manager.cancel_transfer_sync(transfer_id)

        elif msg_type == "command.transfer.retry":
            transfer_id = message.get("transfer_id")
            if transfer_id:
                self.stdout.write(f"Retrying transfer {transfer_id}")
                self.manager.retry_transfer_sync(transfer_id)

        elif msg_type == "command.transfer.queue_batch":
            self._handle_queue_batch(message)

    def _handle_queue_batch(self, message):
        """
        Handle command.transfer.queue_batch event.

        Emitted by device plugins (e.g. insta360) after post-flight operations
        identify files eligible for transfer.
        """
        data = message.get("data", {})
        device_connection_id = data.get("device_connection_id")
        flight_session_id = data.get("flight_session_id")
        files = data.get("files", [])

        if not device_connection_id or not flight_session_id or not files:
            self.stderr.write("Invalid queue_batch event: missing required fields")
            return

        try:
            device_connection = DeviceConnection.objects.get(id=device_connection_id)
            flight_session = FlightSession.objects.get(id=flight_session_id)
        except (DeviceConnection.DoesNotExist, FlightSession.DoesNotExist) as e:
            self.stderr.write(f"queue_batch lookup failed: {e}")
            return

        base_dir = (
            settings.MEDIA_ROOT
            / "transfers"
            / f"{flight_session.id}_{device_connection.id}"
        )
        download_dir = base_dir / "downloads"
        processed_dir = base_dir / "processed"

        remote_files = [
            RemoteFile(
                path=f["path"],
                size=f.get("size"),
                metadata=f.get("metadata", {}),
            )
            for f in files
        ]

        self.stdout.write(
            f"Queueing {len(remote_files)} files for transfer "
            f"(flight={flight_session_id}, device={device_connection_id})"
        )

        transfers = self.manager.queue_batch_sync(
            device_connection=device_connection,
            files=remote_files,
            download_dir=download_dir,
            processed_dir=processed_dir,
            associate_with=flight_session,
        )

        self.stdout.write(f"Created {len(transfers)} transfer records, dispatching...")
        self.manager.dispatch_pending_sync()

    def _periodic_checks(self):
        """Run periodically to handle timeouts, stale transfers, etc."""
        self.manager.recover_stale_transfers()
        self.manager.dispatch_pending_sync()

    def run_daemon(self, *args, **options):
        """Main daemon loop."""
        self._initialize()

        last_periodic_check = time.monotonic()

        while not self.daemon_shutdown_event.is_set():
            self._process_message_queue()

            if time.monotonic() - last_periodic_check >= self.periodic_check_interval:
                self._periodic_checks()
                last_periodic_check = time.monotonic()

            self.daemon_shutdown_event.wait(timeout=0.5)

        self.stdout.write("Transfer Manager Daemon shutting down...")
