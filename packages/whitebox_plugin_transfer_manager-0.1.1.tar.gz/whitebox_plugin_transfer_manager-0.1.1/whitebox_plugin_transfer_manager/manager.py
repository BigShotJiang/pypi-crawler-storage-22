import time
from datetime import timedelta
from pathlib import Path

import django_rq
from asgiref.sync import async_to_sync, sync_to_async
from channels.layers import get_channel_layer
from django.contrib.contenttypes.models import ContentType
from django.core.cache import cache
from django.db.models import Model
from django.utils import timezone
from plugin.manager import plugin_manager

from whitebox import get_plugin_logger, import_whitebox_model

from .adapter import RemoteFile, TransferAdapter
from .models import Transfer, TransferPriority, TransferStatus


logger = get_plugin_logger(__name__)

DeviceConnection = import_whitebox_model("device.DeviceConnection")


class TransferError(Exception):
    """Exception raised for transfer-related errors."""

    pass


class TransferManager:
    """
    Stateless service class for managing file transfers.

    All state lives in the database (Transfer model) and Redis (locks, cancellation flags).
    This class is just a collection of methods that operate on that state.

    Used by:
    - daemon_transfer_manager (orchestrator - discovers adapters on startup)
    - RQ workers (actual downloads - also discovers adapters on first use)
    - API (user actions - doesn't need adapters)

    IMPORTANT: Since daemon and workers run in separate processes, each must
    discover adapters independently. The adapter registry is populated lazily
    when get_adapter() is first called.
    """

    def __init__(self):
        # Adapter registry: device_type_slug → TransferAdapter instance
        # Populated by _discover_adapters() on first access
        self._adapters: dict[str, TransferAdapter] = {}
        self._adapters_discovered = False

        # Concurrency settings
        self._max_concurrent_per_device = 2
        self._max_concurrent_global = 4

        # Retry settings
        self._max_retry_backoff_seconds = 60  # Cap backoff at 60s
        self._retry_window = timedelta(days=7)  # Give up after 7 days

        # Progress throttling
        self._progress_interval_seconds = 1.0
        self._progress_min_percent_delta = 5

        # Track last progress emission per transfer
        self._last_progress_time: dict[str, float] = {}
        self._last_progress_percent: dict[str, int] = {}

    # region adapter registration

    def register_adapter(self, device_type_slug: str, adapter: TransferAdapter) -> None:
        """
        Called by daemon on startup after discovering adapters from plugins.
        """
        self._adapters[device_type_slug] = adapter
        logger.info(f"Registered transfer adapter: {device_type_slug}")

    def get_adapter(self, device_connection) -> TransferAdapter:
        """
        Get the adapter for a device connection.
        Maps DeviceConnection → codename → TransferAdapter

        Lazy-loads adapters on first call (needed because workers also call this).
        """
        if not self._adapters_discovered:
            self._discover_adapters()
            self._adapters_discovered = True

        # DeviceConnection uses codename to identify device type
        device_type_slug = device_connection.codename
        adapter = self._adapters.get(device_type_slug)
        if not adapter:
            raise TransferError(
                f"No transfer adapter registered for device type: {device_type_slug}"
            )
        return adapter

    def _discover_adapters(self) -> None:
        """
        Discover TransferAdapters from installed Whitebox plugins.
        Called lazily on first get_adapter() call, or explicitly by daemon on startup.

        Plugins provide adapters via:
        - get_transfer_adapters() -> list of (codename, adapter) tuples
        """
        for plugin_name, plugin_info in plugin_manager.plugin_info.items():
            if not plugin_info.is_loaded or not plugin_info.loaded_plugin_instance:
                continue

            plugin_instance = plugin_info.loaded_plugin_instance

            get_adapters_fn = getattr(plugin_instance, "get_transfer_adapters", None)
            if not get_adapters_fn:
                continue

            try:
                adapters = get_adapters_fn()
                if adapters:
                    for device_codename, adapter in adapters:
                        self._adapters[device_codename] = adapter
                        logger.debug(
                            f"Discovered transfer adapter: {device_codename} from {plugin_name}"
                        )
            except Exception as e:
                logger.warning(f"Failed to load adapters from {plugin_name}: {e}")

    # endregion adapter registration

    # region queue management

    async def queue_transfer(
        self,
        device_connection,
        source_path: str,
        download_path: Path | str,
        processed_path: Path | str,
        *,
        source_size: int | None = None,
        expected_checksum: str | None = None,
        associate_with: Model | None = None,
        priority: int = TransferPriority.NORMAL,
        metadata: dict | None = None,
    ) -> Transfer:
        """
        Queue a file for transfer. Returns immediately.
        Actual download + processing happens asynchronously via worker.
        """
        # Check for duplicate (idempotent)
        in_progress_statuses = [
            TransferStatus.PENDING,
            TransferStatus.DOWNLOAD_STARTED,
            TransferStatus.DOWNLOAD_COMPLETED,
            TransferStatus.PROCESSING_STARTED,
        ]
        existing = await Transfer.objects.filter(
            device_connection=device_connection,
            source_path=source_path,
            status__in=in_progress_statuses,
        ).afirst()

        if existing:
            return existing

        # Create transfer record
        transfer = await Transfer.objects.acreate(
            device_connection=device_connection,
            source_path=source_path,
            source_size=source_size,
            download_path=str(download_path),
            processed_path=str(processed_path) if processed_path else None,
            expected_checksum=expected_checksum,
            status=TransferStatus.PENDING,
            priority=priority,
            metadata=metadata or {},
        )

        # Set generic FK if provided
        if associate_with:
            transfer.content_type = await sync_to_async(
                ContentType.objects.get_for_model
            )(associate_with)
            transfer.object_id = associate_with.pk
            await transfer.asave()

        await self._emit_event("observation.transfer.queued", transfer)
        return transfer

    async def queue_batch(
        self,
        device_connection,
        files: list[RemoteFile],
        download_dir: Path | str,
        processed_dir: Path | str,
        *,
        associate_with: Model,
        priority: int = TransferPriority.NORMAL,
    ) -> list[Transfer]:
        """
        Queue multiple files for transfer. Each file becomes one Transfer.
        Filenames are preserved from source.
        """
        download_dir = Path(download_dir)
        processed_dir = Path(processed_dir)
        transfers = []

        for remote_file in files:
            filename = Path(remote_file.path).name
            stem = Path(remote_file.path).stem

            transfer = await self.queue_transfer(
                device_connection=device_connection,
                source_path=remote_file.path,
                download_path=download_dir / filename,
                processed_path=processed_dir / f"{stem}.mp4",
                source_size=remote_file.size,
                expected_checksum=remote_file.checksum,
                associate_with=associate_with,
                priority=priority,
                metadata=remote_file.metadata,
            )
            transfers.append(transfer)

        return transfers

    def queue_transfer_sync(
        self,
        device_connection,
        source_path: str,
        download_path: Path | str,
        processed_path: Path | str,
        *,
        source_size: int | None = None,
        expected_checksum: str | None = None,
        associate_with: Model | None = None,
        priority: int = TransferPriority.NORMAL,
        metadata: dict | None = None,
    ) -> Transfer:
        """Sync version of queue_transfer for use in RQ tasks."""
        return async_to_sync(self.queue_transfer)(
            device_connection=device_connection,
            source_path=source_path,
            download_path=download_path,
            processed_path=processed_path,
            source_size=source_size,
            expected_checksum=expected_checksum,
            associate_with=associate_with,
            priority=priority,
            metadata=metadata,
        )

    def queue_batch_sync(
        self,
        device_connection,
        files: list[RemoteFile],
        download_dir: Path | str,
        processed_dir: Path | str,
        *,
        associate_with: Model,
        priority: int = TransferPriority.NORMAL,
    ) -> list[Transfer]:
        """Sync version of queue_batch for use in RQ tasks."""
        return async_to_sync(self.queue_batch)(
            device_connection=device_connection,
            files=files,
            download_dir=download_dir,
            processed_dir=processed_dir,
            associate_with=associate_with,
            priority=priority,
        )

    # endregion queue management

    # region dispatch

    async def _dispatch_pending(self, device_connection=None) -> None:
        """
        Check for pending transfers and dispatch to workers if capacity allows.

        Args:
            device_connection: If provided, only dispatch transfers for this device.
                              If None, dispatch any pending transfers globally.
        """
        active_statuses = [
            TransferStatus.DOWNLOAD_STARTED,
            TransferStatus.DOWNLOAD_COMPLETED,
            TransferStatus.PROCESSING_STARTED,
        ]

        # Check global concurrency limit
        active_global = await Transfer.objects.filter(
            status__in=active_statuses
        ).acount()
        if active_global >= self._max_concurrent_global:
            return

        available_slots = self._max_concurrent_global - active_global

        # Build pending query, excluding transfers still in retry backoff
        pending_qs = (
            Transfer.objects.filter(status=TransferStatus.PENDING)
            .exclude(retry_after__gt=timezone.now())
            .select_related("device_connection")
            .order_by("-priority", "queued_at")
        )

        if device_connection:
            pending_qs = pending_qs.filter(device_connection=device_connection)

        # Dispatch transfers respecting per-device limits
        dispatched = 0
        async for transfer in pending_qs:
            if dispatched >= available_slots:
                break

            # Check per-device concurrency
            active_for_device = await Transfer.objects.filter(
                device_connection=transfer.device_connection,
                status__in=active_statuses,
            ).acount()

            if active_for_device >= self._max_concurrent_per_device:
                continue

            await self._dispatch_single(transfer)
            dispatched += 1

    async def _dispatch_single(self, transfer: Transfer) -> None:
        """Dispatch a single transfer to RQ worker."""
        transfer.status = TransferStatus.DOWNLOAD_STARTED
        transfer.download_started_at = timezone.now()
        await transfer.asave()

        await self._emit_event("observation.transfer.download.started", transfer)

        # Enqueue to RQ
        django_rq.enqueue(
            "whitebox_plugin_transfer_manager.tasks.execute_transfer",
            transfer_id=str(transfer.id),
            job_timeout="4h",
        )

    def dispatch_pending_sync(self, device_connection=None) -> None:
        """Sync version of _dispatch_pending."""
        async_to_sync(self._dispatch_pending)(device_connection)

    def dispatch_pending_for_device(self, device_connection_id: int) -> None:
        """
        Called when a device reconnects. Dispatches any pending transfers
        for that specific device.
        """
        try:
            device_connection = DeviceConnection.objects.get(id=device_connection_id)
        except DeviceConnection.DoesNotExist:
            return

        self.dispatch_pending_sync(device_connection)

    # endregion dispatch

    # region progress and completion

    def report_download_progress(
        self, transfer_id: str, bytes_transferred: int, total: int | None
    ) -> None:
        """Called by worker during download. Handles throttling."""
        transfer = Transfer.objects.get(id=transfer_id)

        transfer.download_bytes_transferred = bytes_transferred
        if total and not transfer.source_size:
            transfer.source_size = total

        if transfer.download_started_at:
            elapsed = (timezone.now() - transfer.download_started_at).total_seconds()
            if elapsed > 0:
                transfer.download_speed = bytes_transferred / elapsed

        transfer.updated_at = timezone.now()
        transfer.save(
            update_fields=[
                "download_bytes_transferred",
                "source_size",
                "download_speed",
                "updated_at",
            ]
        )

        if self._should_emit_progress(
            transfer_id, transfer.download_percent, "download"
        ):
            self._emit_event_sync(
                "observation.transfer.download.progress", self._serialize(transfer)
            )

    def mark_download_completed(self, transfer_id: str) -> None:
        """Called by worker when download finishes."""
        transfer = Transfer.objects.get(id=transfer_id)
        transfer.status = TransferStatus.DOWNLOAD_COMPLETED
        transfer.download_completed_at = timezone.now()
        transfer.save()

        self._emit_event_sync(
            "observation.transfer.download.completed", self._serialize(transfer)
        )

    def report_processing_progress(
        self, transfer_id: str, percent: int, step: str | None
    ) -> None:
        """Called by worker during processing. Handles throttling."""
        transfer = Transfer.objects.get(id=transfer_id)

        transfer.processing_percent = percent
        transfer.processing_step = step
        transfer.updated_at = timezone.now()
        transfer.save(
            update_fields=["processing_percent", "processing_step", "updated_at"]
        )

        if self._should_emit_progress(transfer_id, percent, "processing"):
            self._emit_event_sync(
                "observation.transfer.processing.progress", self._serialize(transfer)
            )

    def mark_processing_started(self, transfer_id: str) -> None:
        """Called by worker when processing begins."""
        transfer = Transfer.objects.get(id=transfer_id)
        transfer.status = TransferStatus.PROCESSING_STARTED
        transfer.processing_started_at = timezone.now()
        transfer.save()

        self._emit_event_sync(
            "observation.transfer.processing.started", self._serialize(transfer)
        )

    def mark_processing_completed(
        self, transfer_id: str, checksum: str | None = None
    ) -> None:
        """Called by worker when processing finishes."""
        transfer = Transfer.objects.get(id=transfer_id)
        transfer.status = TransferStatus.PROCESSING_COMPLETED
        transfer.processing_completed_at = timezone.now()
        transfer.processing_percent = 100
        if checksum:
            transfer.actual_checksum = checksum
        transfer.save()

        self._emit_event_sync(
            "observation.transfer.processing.completed", self._serialize(transfer)
        )
        self.dispatch_pending_sync(transfer.device_connection)

    def mark_failed(
        self,
        transfer_id: str,
        stage: str,
        error: str,
        should_retry: bool = True,
    ) -> None:
        """Called by worker on failure. Stage is 'download' or 'processing'."""
        transfer = Transfer.objects.get(id=transfer_id)
        transfer.error_message = error
        transfer.failed_at_stage = stage

        # Retry if allowed AND within the retry window (7 days from queued_at)
        # AND under the safety cap on retry count
        within_retry_window = (
            transfer.queued_at
            and timezone.now() - transfer.queued_at < self._retry_window
        )
        under_retry_cap = transfer.retry_count < transfer.max_retries

        if should_retry and within_retry_window and under_retry_cap:
            transfer.retry_count += 1
            transfer.status = TransferStatus.PENDING

            # Exponential backoff: 2, 4, 8, 16, 32, 60, 60, ... capped at 60s
            backoff = min(
                2**transfer.retry_count,
                self._max_retry_backoff_seconds,
            )

            # Set retry_after so dispatch skips this transfer until backoff expires
            transfer.retry_after = timezone.now() + timedelta(seconds=backoff)
            transfer.save()

            logger.info(
                f"Transfer {transfer_id} retry #{transfer.retry_count} "
                f"scheduled in {backoff}s (stage={stage})"
            )
            self._emit_event_sync(
                "observation.transfer.retry_scheduled",
                {
                    **self._serialize(transfer),
                    "stage": stage,
                    "retry_in_seconds": backoff,
                },
            )
        else:
            transfer.status = TransferStatus.FAILED
            transfer.save()

            event_type = f"observation.transfer.{stage}.failed"
            self._emit_event_sync(event_type, self._serialize(transfer))

        self.dispatch_pending_sync(transfer.device_connection)

    # endregion progress and completion

    # region recovery

    def recover_interrupted_transfers(self) -> int:
        """
        Called on daemon startup to handle transfers that were in progress
        when the daemon/worker crashed or was restarted.

        Strategy: Reset any in-progress transfer back to PENDING.
        The worker's download-skip logic detects existing files on disk
        and jumps straight to processing when appropriate.

        Returns count of recovered transfers.
        """
        interrupted_statuses = [
            TransferStatus.DOWNLOAD_STARTED,
            TransferStatus.DOWNLOAD_COMPLETED,
            TransferStatus.PROCESSING_STARTED,
        ]

        recovered_count = Transfer.objects.filter(
            status__in=interrupted_statuses
        ).update(
            status=TransferStatus.PENDING,
            processing_percent=0,
            processing_step=None,
            retry_after=None,
        )

        # Clear retry_after on any PENDING transfers that were waiting
        # for backoff when the daemon crashed — they should be dispatched now.
        Transfer.objects.filter(
            status=TransferStatus.PENDING,
            retry_after__isnull=False,
        ).update(retry_after=None)

        # Emit events for frontend to update state
        for transfer in Transfer.objects.filter(status=TransferStatus.PENDING):
            self._emit_event_sync(
                "observation.transfer.queued", self._serialize(transfer)
            )

        return recovered_count

    def recover_stale_transfers(self) -> int:
        """
        Called periodically by the daemon to detect transfers stuck in active
        states due to worker crashes (OOM, SIGKILL, RQ job timeout).

        If a transfer hasn't had any DB update in 2+ minutes while in an
        active state, the worker is likely dead — reset to PENDING so the
        daemon can re-dispatch it.
        """
        stale_threshold = timezone.now() - timedelta(minutes=2)

        active_statuses = [
            TransferStatus.DOWNLOAD_STARTED,
            TransferStatus.DOWNLOAD_COMPLETED,
            TransferStatus.PROCESSING_STARTED,
        ]

        stale_count = Transfer.objects.filter(
            status__in=active_statuses,
            updated_at__lt=stale_threshold,
        ).update(
            status=TransferStatus.PENDING,
            processing_percent=0,
            processing_step=None,
            retry_after=None,
        )

        if stale_count:
            logger.warning(
                f"Recovered {stale_count} stale transfers (worker likely dead)"
            )
            for transfer in Transfer.objects.filter(status=TransferStatus.PENDING):
                self._emit_event_sync(
                    "observation.transfer.queued", self._serialize(transfer)
                )

        return stale_count

    # endregion recovery

    # region user actions

    async def cancel_transfer(self, transfer_id: str) -> Transfer:
        """Cancel a transfer."""
        transfer = await Transfer.objects.aget(id=transfer_id)

        active_statuses = [
            TransferStatus.DOWNLOAD_STARTED,
            TransferStatus.PROCESSING_STARTED,
        ]
        if transfer.status in active_statuses:
            cache.set(f"transfer_cancel_{transfer_id}", True, timeout=300)

        transfer.status = TransferStatus.CANCELLED
        await transfer.asave()
        await self._emit_event("observation.transfer.cancelled", transfer)
        return transfer

    async def retry_transfer(self, transfer_id: str) -> Transfer:
        """Retry a failed/cancelled transfer."""
        transfer = await Transfer.objects.aget(id=transfer_id)

        if transfer.status not in [TransferStatus.FAILED, TransferStatus.CANCELLED]:
            raise TransferError("Can only retry failed/cancelled transfers")

        transfer.status = TransferStatus.PENDING
        transfer.error_message = None
        transfer.failed_at_stage = None
        transfer.download_bytes_transferred = 0
        transfer.download_speed = None
        transfer.processing_percent = 0
        transfer.processing_step = None
        transfer.retry_count = 0
        transfer.retry_after = None
        await transfer.asave()

        await self._emit_event("observation.transfer.queued", transfer)
        await self._dispatch_pending(transfer.device_connection)
        return transfer

    async def pause_transfer(self, transfer_id: str) -> Transfer:
        """Pause a transfer."""
        transfer = await Transfer.objects.aget(id=transfer_id)

        if transfer.status in [
            TransferStatus.DOWNLOAD_STARTED,
            TransferStatus.PROCESSING_STARTED,
        ]:
            cache.set(f"transfer_cancel_{transfer_id}", True, timeout=300)

        transfer.status = TransferStatus.PAUSED
        await transfer.asave()
        await self._emit_event("observation.transfer.paused", transfer)
        return transfer

    async def resume_transfer(self, transfer_id: str) -> Transfer:
        """Resume a paused transfer."""
        transfer = await Transfer.objects.aget(id=transfer_id)

        if transfer.status != TransferStatus.PAUSED:
            raise TransferError("Can only resume paused transfers")

        cache.delete(f"transfer_cancel_{transfer_id}")
        transfer.status = TransferStatus.PENDING
        transfer.retry_after = None
        await transfer.asave()

        await self._emit_event("observation.transfer.queued", transfer)
        await self._dispatch_pending(transfer.device_connection)
        return transfer

    def cancel_transfer_sync(self, transfer_id: str) -> Transfer:
        """Sync version of cancel_transfer."""
        return async_to_sync(self.cancel_transfer)(transfer_id)

    def retry_transfer_sync(self, transfer_id: str) -> Transfer:
        """Sync version of retry_transfer."""
        return async_to_sync(self.retry_transfer)(transfer_id)

    # endregion user actions

    # region event emission

    async def _emit_event(self, event_type: str, transfer: Transfer) -> None:
        """Async version for use in async contexts."""
        channel_layer = get_channel_layer()
        await channel_layer.group_send(
            "management",
            {
                "type": event_type,
                "data": self._serialize(transfer),
            },
        )

    def _emit_event_sync(self, event_type: str, data: dict) -> None:
        """
        Emit event to WebSocket subscribers (sync version for RQ workers).
        """
        channel_layer = get_channel_layer()
        async_to_sync(channel_layer.group_send)(
            "management",
            {
                "type": event_type,
                "data": data,
            },
        )

    def _serialize(self, transfer: Transfer) -> dict:
        """Serialize transfer for event payload."""
        return {
            "id": str(transfer.id),
            "status": transfer.status,
            "status_display": transfer.get_status_display(),
            "source_path": transfer.source_path,
            "source_size": transfer.source_size,
            "download_bytes_transferred": transfer.download_bytes_transferred,
            "download_percent": transfer.download_percent,
            "download_speed": transfer.download_speed,
            "processing_percent": transfer.processing_percent,
            "processing_step": transfer.processing_step,
            "error_message": transfer.error_message,
            "failed_at_stage": transfer.failed_at_stage,
            "device_connection_id": transfer.device_connection_id,
            "queued_at": transfer.queued_at.isoformat() if transfer.queued_at else None,
            "download_started_at": (
                transfer.download_started_at.isoformat()
                if transfer.download_started_at
                else None
            ),
            "download_completed_at": (
                transfer.download_completed_at.isoformat()
                if transfer.download_completed_at
                else None
            ),
            "processing_started_at": (
                transfer.processing_started_at.isoformat()
                if transfer.processing_started_at
                else None
            ),
            "processing_completed_at": (
                transfer.processing_completed_at.isoformat()
                if transfer.processing_completed_at
                else None
            ),
        }

    # endregion event emission

    # region progress throttling

    def _should_emit_progress(self, transfer_id: str, percent: int, phase: str) -> bool:
        """
        Check if we should emit a progress event (throttled).
        Emit at most every 1 second OR every 5% progress.
        """
        key = f"{transfer_id}_{phase}"
        now = time.monotonic()

        last_time = self._last_progress_time.get(key, 0)
        last_percent = self._last_progress_percent.get(key, 0)

        time_delta = now - last_time
        percent_delta = abs(percent - last_percent)

        if (
            time_delta >= self._progress_interval_seconds
            or percent_delta >= self._progress_min_percent_delta
        ):
            self._last_progress_time[key] = now
            self._last_progress_percent[key] = percent
            return True

        return False

    # endregion progress throttling


# Global instance (stateless, so safe to share)
transfer_manager = TransferManager()
