import uuid

from django.contrib.contenttypes.fields import GenericForeignKey
from django.contrib.contenttypes.models import ContentType
from django.db import models

from utils.models import TimestampedModel


class TransferStatus(models.IntegerChoices):
    """Status values for transfer lifecycle."""

    PENDING = 10, "Pending"
    DOWNLOAD_STARTED = 20, "Download Started"
    DOWNLOAD_COMPLETED = 25, "Download Completed"
    PROCESSING_STARTED = 30, "Processing Started"
    PROCESSING_COMPLETED = 40, "Processing Completed"
    FAILED = 60, "Failed"
    CANCELLED = 70, "Cancelled"
    PAUSED = 80, "Paused"


class TransferPriority(models.IntegerChoices):
    """Priority levels for transfer queue ordering."""

    LOW = 0, "Low"
    NORMAL = 10, "Normal"
    HIGH = 20, "High"
    URGENT = 30, "Urgent"


class Transfer(TimestampedModel):
    """
    Persistent model for tracking file transfers from devices.

    Each transfer goes through two phases:
    1. Download: Fetch file from device to local storage
    2. Processing: Transcode/stitch/convert the downloaded file
    """

    # Identity
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)

    # Source - the file on the device
    device_connection = models.ForeignKey(
        "whitebox_plugin_device_manager.DeviceConnection",
        on_delete=models.CASCADE,
        related_name="transfers",
    )
    source_path = models.CharField(
        max_length=512,
        help_text="Path on device (e.g., /DCIM/Camera01/VID_001.insv)",
    )
    source_size = models.BigIntegerField(
        null=True,
        blank=True,
        help_text="Expected bytes (used for progress %, may be None initially)",
    )

    # Destination - local paths (absolute)
    download_path = models.CharField(
        max_length=512,
        help_text="Absolute path for raw download",
    )
    processed_path = models.CharField(
        max_length=512,
        null=True,
        blank=True,
        help_text="Absolute path for processed output",
    )

    # Association - generic FK to associate with FlightSession or other models
    content_type = models.ForeignKey(
        ContentType,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
    )
    object_id = models.PositiveIntegerField(null=True, blank=True)
    associated_with = GenericForeignKey("content_type", "object_id")

    # Status
    status = models.IntegerField(
        choices=TransferStatus.choices,
        default=TransferStatus.PENDING,
    )
    priority = models.IntegerField(
        choices=TransferPriority.choices,
        default=TransferPriority.NORMAL,
    )

    # Download progress
    download_bytes_transferred = models.BigIntegerField(default=0)
    download_speed = models.FloatField(
        null=True,
        blank=True,
        help_text="bytes/sec",
    )

    # Processing progress
    processing_percent = models.IntegerField(
        default=0,
        help_text="0-100",
    )
    processing_step = models.CharField(
        max_length=128,
        null=True,
        blank=True,
        help_text="e.g., 'stitching', 'transcoding'",
    )

    # Timestamps
    queued_at = models.DateTimeField(auto_now_add=True)
    download_started_at = models.DateTimeField(null=True, blank=True)
    download_completed_at = models.DateTimeField(null=True, blank=True)
    processing_started_at = models.DateTimeField(null=True, blank=True)
    processing_completed_at = models.DateTimeField(null=True, blank=True)

    # Error handling
    error_message = models.TextField(null=True, blank=True)
    failed_at_stage = models.CharField(
        max_length=20,
        null=True,
        blank=True,
        help_text="'download' or 'processing'",
    )
    retry_count = models.IntegerField(default=0)
    max_retries = models.IntegerField(
        default=500,
        help_text="Safety cap on retries. Primary retry limit is time-based (7 days).",
    )
    retry_after = models.DateTimeField(
        null=True,
        blank=True,
        help_text="Earliest time this transfer can be retried (exponential backoff)",
    )

    # Integrity (optional - not all devices provide checksums)
    expected_checksum = models.CharField(
        max_length=64,
        null=True,
        blank=True,
        help_text="From device, if available",
    )
    actual_checksum = models.CharField(
        max_length=64,
        null=True,
        blank=True,
        help_text="Computed after processing",
    )

    # Metadata (device-specific extras)
    metadata = models.JSONField(default=dict, blank=True)

    class Meta:
        ordering = ["-priority", "queued_at"]
        indexes = [
            models.Index(fields=["status"]),
            models.Index(fields=["device_connection", "status"]),
        ]

    def __str__(self):
        return f"Transfer {self.id} - {self.source_path} ({self.get_status_display()})"

    @property
    def download_percent(self) -> int:
        """Calculate download percentage."""
        if not self.source_size or self.source_size == 0:
            return 0
        return min(100, int((self.download_bytes_transferred / self.source_size) * 100))

    @property
    def is_active(self) -> bool:
        """Check if transfer is currently in progress."""
        return self.status in [
            TransferStatus.DOWNLOAD_STARTED,
            TransferStatus.DOWNLOAD_COMPLETED,
            TransferStatus.PROCESSING_STARTED,
        ]

    @property
    def is_complete(self) -> bool:
        """Check if transfer completed successfully."""
        return self.status == TransferStatus.PROCESSING_COMPLETED

    @property
    def can_retry(self) -> bool:
        """Check if transfer can be retried."""
        return self.status in [TransferStatus.FAILED, TransferStatus.CANCELLED]
