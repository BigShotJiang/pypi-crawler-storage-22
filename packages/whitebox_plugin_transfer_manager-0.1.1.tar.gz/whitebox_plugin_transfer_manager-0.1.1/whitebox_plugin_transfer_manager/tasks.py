import hashlib
import shutil
import threading
from pathlib import Path

import requests
from django.conf import settings
from django.core.cache import cache
from django.utils import timezone

from whitebox import get_plugin_logger, import_whitebox_model

from .manager import transfer_manager
from .models import Transfer, TransferStatus


logger = get_plugin_logger(__name__)

FlightSessionRecording = import_whitebox_model("flight.FlightSessionRecording")


def _calculate_sha256(file_path: Path) -> str:
    """Calculate SHA256 checksum of a file."""
    sha256_hash = hashlib.sha256()
    with open(file_path, "rb") as f:
        for chunk in iter(lambda: f.read(8192), b""):
            sha256_hash.update(chunk)
    return sha256_hash.hexdigest()


def _download_already_complete(transfer: Transfer, download_path: Path) -> bool:
    """
    Check if the download file already exists and is complete.

    Used after crash recovery: if a transfer crashed during the processing
    phase, the downloaded file is intact. Instead of re-downloading from the
    device, we skip straight to processing.
    """
    if not download_path.exists():
        return False

    # If we know the expected size, verify the file is complete
    if transfer.source_size:
        return download_path.stat().st_size >= transfer.source_size

    # Without source_size we can't verify completeness, but if the file
    # exists and download was previously marked completed, trust it
    return transfer.download_completed_at is not None


def execute_transfer(transfer_id: str) -> None:
    """
    RQ worker task that performs download + processing.
    Runs as a single job to ensure atomicity.
    """
    manager = transfer_manager
    cancel_event = threading.Event()

    def check_cancelled():
        if cache.get(f"transfer_cancel_{transfer_id}"):
            cancel_event.set()
        return cancel_event.is_set()

    try:
        transfer = Transfer.objects.select_related("device_connection").get(
            id=transfer_id
        )

        # Ensure status is DOWNLOAD_STARTED. Normally _dispatch_single sets
        # this, but on retries the worker may be invoked with status=PENDING.
        if transfer.status in (TransferStatus.PENDING, TransferStatus.DOWNLOAD_STARTED):
            if transfer.status == TransferStatus.PENDING:
                transfer.status = TransferStatus.DOWNLOAD_STARTED
                transfer.download_started_at = timezone.now()
                transfer.retry_after = None
                transfer.save(
                    update_fields=["status", "download_started_at", "retry_after"]
                )
                manager._emit_event_sync(
                    "observation.transfer.download.started",
                    manager._serialize(transfer),
                )

        adapter = manager.get_adapter(transfer.device_connection)

        # Check cancellation before starting
        if check_cancelled():
            logger.info(f"Transfer {transfer_id} cancelled before start")
            return

        download_path = Path(transfer.download_path)
        download_path.parent.mkdir(parents=True, exist_ok=True)

        # ===== DOWNLOAD PHASE =====
        # Skip download if file already exists from a previous run (e.g.
        # crash recovery after processing failed — the download is intact).
        if _download_already_complete(transfer, download_path):
            logger.info(
                f"Download already exists for transfer {transfer_id}, "
                "skipping to processing"
            )
            manager.mark_download_completed(transfer_id)
        else:
            # Disk space check before download
            if transfer.source_size:
                free_space = shutil.disk_usage(download_path.parent).free
                if free_space < transfer.source_size * 1.1:  # 10% buffer
                    manager.mark_failed(
                        transfer_id,
                        "download",
                        "Insufficient disk space",
                        should_retry=False,
                    )
                    return

            logger.info(f"Starting download for transfer {transfer_id}")

            def on_download_progress(bytes_done: int, total: int | None):
                check_cancelled()
                manager.report_download_progress(transfer_id, bytes_done, total)

            download_ok = adapter.download_file(
                device_connection=transfer.device_connection,
                source_path=transfer.source_path,
                destination_path=download_path,
                progress_callback=on_download_progress,
                cancel_event=cancel_event,
            )

            if cancel_event.is_set():
                logger.info(f"Transfer {transfer_id} cancelled during download")
                download_path.unlink(missing_ok=True)
                return

            if not download_ok:
                logger.warning(f"Download failed for transfer {transfer_id}")
                download_path.unlink(missing_ok=True)
                manager.mark_failed(
                    transfer_id, "download", "Download failed", should_retry=True
                )
                return

            manager.mark_download_completed(transfer_id)
            logger.info(f"Download completed for transfer {transfer_id}")

        # ===== PROCESSING PHASE =====
        manager.mark_processing_started(transfer_id)
        transfer.refresh_from_db()

        processed_path = (
            Path(transfer.processed_path) if transfer.processed_path else None
        )

        if processed_path:
            processed_path.parent.mkdir(parents=True, exist_ok=True)

            # Check disk space for processing output
            if transfer.source_size:
                free_space = shutil.disk_usage(processed_path.parent).free
                # Processing output could be larger or smaller, use 2x as buffer
                if free_space < transfer.source_size * 2:
                    manager.mark_failed(
                        transfer_id,
                        "processing",
                        "Insufficient disk space for processing",
                        should_retry=False,
                    )
                    return

            def on_processing_progress(percent: int, step: str | None):
                check_cancelled()
                manager.report_processing_progress(transfer_id, percent, step)

            logger.info(f"Starting processing for transfer {transfer_id}")

            process_ok = adapter.process_file(
                source_path=download_path,
                destination_path=processed_path,
                progress_callback=on_processing_progress,
                cancel_event=cancel_event,
            )

            if cancel_event.is_set():
                logger.info(f"Transfer {transfer_id} cancelled during processing")
                processed_path.unlink(missing_ok=True)
                return

            if not process_ok:
                logger.warning(f"Processing failed for transfer {transfer_id}")
                manager.mark_failed(
                    transfer_id, "processing", "Processing failed", should_retry=True
                )
                return

            # Calculate checksum of final processed file
            checksum = None
            if processed_path.stat().st_size < 1_000_000_000:  # < 1GB
                checksum = _calculate_sha256(processed_path)

            # Create FlightSessionRecording for the processed file
            transfer.refresh_from_db()
            if transfer.associated_with:
                _create_flight_session_recording(transfer, processed_path)

            manager.mark_processing_completed(transfer_id, checksum)
            logger.info(f"Processing completed for transfer {transfer_id}")

            # Optional: clean up raw download to save disk space
            cleanup_raw = getattr(settings, "TRANSFER_CLEANUP_RAW_FILES", False)
            if cleanup_raw:
                download_path.unlink(missing_ok=True)
                logger.info(f"Cleaned up raw file for transfer {transfer_id}")

        else:
            # No processing needed, mark as completed
            manager.mark_processing_completed(transfer_id, None)
            logger.info(f"Transfer {transfer_id} completed (no processing needed)")

    except Transfer.DoesNotExist:
        logger.error(f"Transfer {transfer_id} not found")

    except (ConnectionError, OSError, requests.exceptions.RequestException) as e:
        # Transient network/device errors — should retry when device is back
        logger.warning(f"Transfer {transfer_id} failed with transient error: {e}")
        try:
            transfer = Transfer.objects.get(id=transfer_id)
            stage = (
                "processing"
                if transfer.status == TransferStatus.PROCESSING_STARTED
                else "download"
            )
            manager.mark_failed(transfer_id, stage, str(e), should_retry=True)
        except Transfer.DoesNotExist:
            pass

    except Exception as e:
        logger.exception(f"Transfer {transfer_id} failed with exception")
        try:
            transfer = Transfer.objects.get(id=transfer_id)
            stage = (
                "processing"
                if transfer.status == TransferStatus.PROCESSING_STARTED
                else "download"
            )
            # Download failures are almost always connectivity/device issues
            # (transient) — retry them. Processing failures are more likely
            # permanent (corrupt file, missing tool) — don't retry.
            should_retry = stage == "download"
            manager.mark_failed(transfer_id, stage, str(e), should_retry=should_retry)
        except Transfer.DoesNotExist:
            pass


def _create_flight_session_recording(transfer: Transfer, processed_path: Path) -> None:
    """
    Create a FlightSessionRecording for the processed file.
    """
    # Check if recording already exists
    existing = transfer.metadata.get("recording_id")
    if existing:
        logger.info(f"Recording {existing} already exists for transfer {transfer.id}")
        return

    recording = FlightSessionRecording(
        flight_session=transfer.associated_with,
        provided_by=transfer.device_connection,
    )

    # file.name must be relative to MEDIA_ROOT (Django FileField convention)
    try:
        relative_path = processed_path.relative_to(settings.MEDIA_ROOT)
        recording.file.name = str(relative_path)
    except ValueError:
        # Path is not under MEDIA_ROOT, store as-is
        recording.file.name = str(processed_path)

    # Set status if the model has it
    if hasattr(FlightSessionRecording, "STATUSES"):
        recording.status = FlightSessionRecording.STATUSES.READY

    recording.save()

    # Store reference in transfer metadata for traceability
    transfer.metadata["recording_id"] = recording.pk
    transfer.save(update_fields=["metadata"])

    logger.info(
        f"Created FlightSessionRecording {recording.pk} for transfer {transfer.id}"
    )
