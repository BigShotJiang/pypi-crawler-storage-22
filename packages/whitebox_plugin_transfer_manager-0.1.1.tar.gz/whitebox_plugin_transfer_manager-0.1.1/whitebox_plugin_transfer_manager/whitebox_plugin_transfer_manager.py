from whitebox import Plugin


class WhiteboxPluginTransferManager(Plugin):
    name = "Transfer Manager"

    provides_capabilities = [
        "transfer-manager",
    ]

    requires_capabilities = [
        "device",
    ]

    exposed_component_map = {
        "service-component": {
            "transfer-service": "TransferServiceComponent",
        },
        "transfer-manager": {
            "transfer-panel": "TransferPanel",
        },
    }

    state_store_map = {
        "transfer": "stores/transfer",
    }

    slot_component_map = {
        "transfer.panel": "TransferPanel",
    }

    def get_plugin_classes_map(self):
        """Expose classes for other plugins to use via import_whitebox_plugin_class."""
        from .manager import transfer_manager
        from .adapter import TransferAdapter, RemoteFile

        return {
            "transfer.TransferManager": transfer_manager,
            "transfer.TransferAdapter": TransferAdapter,
            "transfer.RemoteFile": RemoteFile,
        }


plugin_class = WhiteboxPluginTransferManager
