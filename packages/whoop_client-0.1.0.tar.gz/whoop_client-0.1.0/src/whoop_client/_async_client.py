from __future__ import annotations

import inspect
from collections.abc import AsyncIterator
from datetime import datetime
from typing import Any

import httpx

from whoop_client._auth import (
    AsyncOAuthTokenProvider,
    AsyncTokenProvider,
    OAuthTokenProvider,
    StaticTokenProvider,
    TokenProvider,
)
from whoop_client._exceptions import WhoopAuthenticationError
from whoop_client._base_client import BaseClientMixin
from whoop_client._constants import (
    BASE_URL,
    DEFAULT_PAGE_LIMIT,
    DEFAULT_TIMEOUT_SECONDS,
)
from whoop_client._retry import RetryPolicy, execute_with_retry_async
from whoop_client.models._pagination import PaginatedResponse
from whoop_client.models.activity_mapping import ActivityIdMapping
from whoop_client.models.cycle import Cycle
from whoop_client.models.recovery import Recovery
from whoop_client.models.sleep import Sleep
from whoop_client.models.user import UserBasicProfile, UserBodyMeasurement
from whoop_client.models.workout import Workout


class AsyncWhoopClient(BaseClientMixin):
    """Asynchronous WHOOP API client."""

    def __init__(
        self,
        token_provider: TokenProvider | AsyncTokenProvider | str,
        *,
        base_url: str = BASE_URL,
        timeout: float = DEFAULT_TIMEOUT_SECONDS,
        retry_policy: RetryPolicy | None = None,
        httpx_client: httpx.AsyncClient | None = None,
    ) -> None:
        if isinstance(token_provider, str):
            token_provider = StaticTokenProvider(token_provider)
        self._token_provider: TokenProvider | AsyncTokenProvider = token_provider
        self._base_url = base_url
        self._retry_policy = retry_policy or RetryPolicy()
        self._owns_client = httpx_client is None
        self._client = httpx_client or httpx.AsyncClient(timeout=timeout)

    async def __aenter__(self) -> AsyncWhoopClient:
        return self

    async def __aexit__(self, *args: object) -> None:
        await self.close()

    async def close(self) -> None:
        if self._owns_client:
            await self._client.aclose()

    async def _get_token(self) -> str:
        if inspect.iscoroutinefunction(self._token_provider.get_token):
            return await self._token_provider.get_token()
        return self._token_provider.get_token()  # type: ignore[union-attr]

    async def _request(self, method: str, path: str, **kwargs: Any) -> httpx.Response:
        token = await self._get_token()
        headers = self._build_auth_header(token)
        url = self._build_url(path)

        async def _do_request() -> httpx.Response:
            return await self._client.request(method, url, headers=headers, **kwargs)

        try:
            return await execute_with_retry_async(_do_request, self._retry_policy)
        except WhoopAuthenticationError:
            if not isinstance(
                self._token_provider, (OAuthTokenProvider, AsyncOAuthTokenProvider)
            ):
                raise
            self._token_provider.force_refresh()
            token = await self._get_token()
            retry_headers = self._build_auth_header(token)

            async def _do_retry() -> httpx.Response:
                return await self._client.request(
                    method, url, headers=retry_headers, **kwargs
                )

            return await execute_with_retry_async(_do_retry, self._retry_policy)

    # --- Cycle ---

    async def get_cycles(
        self,
        *,
        limit: int | None = None,
        start: datetime | None = None,
        end: datetime | None = None,
        next_token: str | None = None,
    ) -> PaginatedResponse[Cycle]:
        params = self._build_pagination_params(
            limit=limit, start=start, end=end, next_token=next_token
        )
        response = await self._request("GET", "/v2/cycle", params=params)
        return self._parse_paginated_response(response, Cycle)

    async def get_cycle_by_id(self, cycle_id: int) -> Cycle:
        response = await self._request("GET", f"/v2/cycle/{cycle_id}")
        return self._parse_response(response, Cycle)

    async def get_cycle_sleep(self, cycle_id: int) -> Sleep:
        response = await self._request("GET", f"/v2/cycle/{cycle_id}/sleep")
        return self._parse_response(response, Sleep)

    async def get_cycle_recovery(self, cycle_id: int) -> Recovery:
        response = await self._request("GET", f"/v2/cycle/{cycle_id}/recovery")
        return self._parse_response(response, Recovery)

    async def iter_cycles(
        self,
        *,
        limit: int = DEFAULT_PAGE_LIMIT,
        start: datetime | None = None,
        end: datetime | None = None,
    ) -> AsyncIterator[Cycle]:
        next_token: str | None = None
        while True:
            page = await self.get_cycles(
                limit=limit, start=start, end=end, next_token=next_token
            )
            for record in page.records:
                yield record
            if page.next_token is None:
                break
            next_token = page.next_token

    # --- Recovery ---

    async def get_recoveries(
        self,
        *,
        limit: int | None = None,
        start: datetime | None = None,
        end: datetime | None = None,
        next_token: str | None = None,
    ) -> PaginatedResponse[Recovery]:
        params = self._build_pagination_params(
            limit=limit, start=start, end=end, next_token=next_token
        )
        response = await self._request("GET", "/v2/recovery", params=params)
        return self._parse_paginated_response(response, Recovery)

    async def iter_recoveries(
        self,
        *,
        limit: int = DEFAULT_PAGE_LIMIT,
        start: datetime | None = None,
        end: datetime | None = None,
    ) -> AsyncIterator[Recovery]:
        next_token: str | None = None
        while True:
            page = await self.get_recoveries(
                limit=limit, start=start, end=end, next_token=next_token
            )
            for record in page.records:
                yield record
            if page.next_token is None:
                break
            next_token = page.next_token

    # --- Sleep ---

    async def get_sleeps(
        self,
        *,
        limit: int | None = None,
        start: datetime | None = None,
        end: datetime | None = None,
        next_token: str | None = None,
    ) -> PaginatedResponse[Sleep]:
        params = self._build_pagination_params(
            limit=limit, start=start, end=end, next_token=next_token
        )
        response = await self._request("GET", "/v2/activity/sleep", params=params)
        return self._parse_paginated_response(response, Sleep)

    async def get_sleep_by_id(self, sleep_id: str) -> Sleep:
        response = await self._request("GET", f"/v2/activity/sleep/{sleep_id}")
        return self._parse_response(response, Sleep)

    async def iter_sleeps(
        self,
        *,
        limit: int = DEFAULT_PAGE_LIMIT,
        start: datetime | None = None,
        end: datetime | None = None,
    ) -> AsyncIterator[Sleep]:
        next_token: str | None = None
        while True:
            page = await self.get_sleeps(
                limit=limit, start=start, end=end, next_token=next_token
            )
            for record in page.records:
                yield record
            if page.next_token is None:
                break
            next_token = page.next_token

    # --- Workout ---

    async def get_workouts(
        self,
        *,
        limit: int | None = None,
        start: datetime | None = None,
        end: datetime | None = None,
        next_token: str | None = None,
    ) -> PaginatedResponse[Workout]:
        params = self._build_pagination_params(
            limit=limit, start=start, end=end, next_token=next_token
        )
        response = await self._request("GET", "/v2/activity/workout", params=params)
        return self._parse_paginated_response(response, Workout)

    async def get_workout_by_id(self, workout_id: str) -> Workout:
        response = await self._request("GET", f"/v2/activity/workout/{workout_id}")
        return self._parse_response(response, Workout)

    async def iter_workouts(
        self,
        *,
        limit: int = DEFAULT_PAGE_LIMIT,
        start: datetime | None = None,
        end: datetime | None = None,
    ) -> AsyncIterator[Workout]:
        next_token: str | None = None
        while True:
            page = await self.get_workouts(
                limit=limit, start=start, end=end, next_token=next_token
            )
            for record in page.records:
                yield record
            if page.next_token is None:
                break
            next_token = page.next_token

    # --- User ---

    async def get_profile(self) -> UserBasicProfile:
        response = await self._request("GET", "/v2/user/profile/basic")
        return self._parse_response(response, UserBasicProfile)

    async def get_body_measurement(self) -> UserBodyMeasurement:
        response = await self._request("GET", "/v2/user/measurement/body")
        return self._parse_response(response, UserBodyMeasurement)

    async def revoke_access(self) -> None:
        await self._request("DELETE", "/v2/user/access")

    # --- Activity Mapping ---

    async def get_activity_mapping(self, v1_id: int) -> ActivityIdMapping:
        response = await self._request("GET", f"/v1/activity-mapping/{v1_id}")
        return self._parse_response(response, ActivityIdMapping)
