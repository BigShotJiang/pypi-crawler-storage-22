from __future__ import annotations

import asyncio
import threading
import time
from collections.abc import Awaitable, Callable
from typing import Protocol, runtime_checkable

import httpx

from whoop_client._constants import DEFAULT_REFRESH_SCOPE, TOKEN_URL
from whoop_client._exceptions import WhoopAuthTokenError

OnTokenRefresh = Callable[[str, str, float], None]
AsyncOnTokenRefresh = Callable[[str, str, float], Awaitable[None]]


@runtime_checkable
class TokenProvider(Protocol):
    def get_token(self) -> str: ...  # pragma: no branch


@runtime_checkable
class AsyncTokenProvider(Protocol):
    async def get_token(self) -> str: ...  # pragma: no branch


class StaticTokenProvider:
    """Provides a fixed access token. Implements both sync and async protocols."""

    def __init__(self, access_token: str) -> None:
        self._access_token = access_token

    def get_token(self) -> str:
        return self._access_token


class OAuthTokenProvider:
    """Sync OAuth2 token provider with automatic refresh.

    Thread-safe via `threading.Lock`.
    """

    def __init__(
        self,
        client_id: str,
        client_secret: str,
        refresh_token: str,
        access_token: str | None = None,
        token_url: str = TOKEN_URL,
        expires_at: float | None = None,
        on_token_refresh: OnTokenRefresh | None = None,
    ) -> None:
        self._client_id = client_id
        self._client_secret = client_secret
        self._refresh_token = refresh_token
        self._access_token = access_token
        self._token_url = token_url
        if expires_at is not None:
            self._expires_at = expires_at
        elif access_token is not None:
            self._expires_at = time.time() + 3600
        else:
            self._expires_at = 0.0
        self._lock = threading.Lock()
        self._on_token_refresh = on_token_refresh

    def get_token(self) -> str:
        with self._lock:
            if self._access_token and time.time() < self._expires_at:
                return self._access_token
            return self._refresh()

    def force_refresh(self) -> None:
        """Invalidate the cached token so the next `get_token` triggers a refresh."""
        with self._lock:
            self._expires_at = 0.0

    def _refresh(self) -> str:
        try:
            response = httpx.post(
                self._token_url,
                data={
                    "grant_type": "refresh_token",
                    "client_id": self._client_id,
                    "client_secret": self._client_secret,
                    "refresh_token": self._refresh_token,
                    "scope": DEFAULT_REFRESH_SCOPE,
                },
            )
            response.raise_for_status()
        except httpx.HTTPError as exc:
            raise WhoopAuthTokenError(f"Token refresh failed: {exc}") from exc

        data = response.json()
        self._access_token = data["access_token"]
        if "refresh_token" in data:
            self._refresh_token = data["refresh_token"]
        self._expires_at = time.time() + data.get("expires_in", 3600) - 60
        if self._on_token_refresh:
            self._on_token_refresh(
                self._access_token, self._refresh_token, self._expires_at
            )
        return self._access_token


class AsyncOAuthTokenProvider:
    """Async OAuth2 token provider with automatic refresh.

    Concurrency-safe via `asyncio.Lock`.
    """

    def __init__(
        self,
        client_id: str,
        client_secret: str,
        refresh_token: str,
        access_token: str | None = None,
        token_url: str = TOKEN_URL,
        expires_at: float | None = None,
        on_token_refresh: AsyncOnTokenRefresh | OnTokenRefresh | None = None,
    ) -> None:
        self._client_id = client_id
        self._client_secret = client_secret
        self._refresh_token = refresh_token
        self._access_token = access_token
        self._token_url = token_url
        if expires_at is not None:
            self._expires_at = expires_at
        elif access_token is not None:
            self._expires_at = time.time() + 3600
        else:
            self._expires_at = 0.0
        self._lock = asyncio.Lock()
        self._on_token_refresh = on_token_refresh

    async def get_token(self) -> str:
        async with self._lock:
            if self._access_token and time.time() < self._expires_at:
                return self._access_token
            return await self._refresh()

    def force_refresh(self) -> None:
        """Invalidate the cached token so the next `get_token` triggers a refresh."""
        self._expires_at = 0.0

    async def _refresh(self) -> str:
        try:
            async with httpx.AsyncClient() as client:
                response = await client.post(
                    self._token_url,
                    data={
                        "grant_type": "refresh_token",
                        "client_id": self._client_id,
                        "client_secret": self._client_secret,
                        "refresh_token": self._refresh_token,
                        "scope": DEFAULT_REFRESH_SCOPE,
                    },
                )
                response.raise_for_status()
        except httpx.HTTPError as exc:
            raise WhoopAuthTokenError(f"Token refresh failed: {exc}") from exc

        data = response.json()
        self._access_token = data["access_token"]
        if "refresh_token" in data:
            self._refresh_token = data["refresh_token"]
        self._expires_at = time.time() + data.get("expires_in", 3600) - 60
        if self._on_token_refresh:
            result = self._on_token_refresh(
                self._access_token, self._refresh_token, self._expires_at
            )
            if asyncio.iscoroutine(result):
                await result
        return self._access_token
