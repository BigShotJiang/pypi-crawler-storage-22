from __future__ import annotations

from datetime import datetime, timezone
from typing import Any, TypeVar

import httpx

from whoop_client._exceptions import raise_for_status
from whoop_client.models._base import WhoopModel
from whoop_client.models._pagination import PaginatedResponse

T = TypeVar("T", bound=WhoopModel)


class BaseClientMixin:
    _base_url: str

    def _build_url(self, path: str) -> str:
        return f"{self._base_url}{path}"

    def _build_pagination_params(
        self,
        *,
        limit: int | None = None,
        start: datetime | None = None,
        end: datetime | None = None,
        next_token: str | None = None,
    ) -> dict[str, Any]:
        params: dict[str, Any] = {}
        if limit is not None:
            params["limit"] = limit
        if start is not None:
            params["start"] = self._format_datetime(start)
        if end is not None:
            params["end"] = self._format_datetime(end)
        if next_token is not None:
            params["nextToken"] = next_token
        return params

    @staticmethod
    def _format_datetime(dt: datetime) -> str:
        """Format a datetime as ISO 8601 with Z suffix for the WHOOP API."""
        if dt.tzinfo is None:
            dt = dt.replace(tzinfo=timezone.utc)
        return dt.astimezone(timezone.utc).strftime("%Y-%m-%dT%H:%M:%S.000Z")

    def _build_auth_header(self, token: str) -> dict[str, str]:
        return {"Authorization": f"Bearer {token}"}

    def _handle_error_response(self, response: httpx.Response) -> None:
        raise_for_status(response)

    def _parse_response(self, response: httpx.Response, model_type: type[T]) -> T:
        return model_type.model_validate(response.json())

    def _parse_paginated_response(
        self, response: httpx.Response, item_model: type[T]
    ) -> PaginatedResponse[T]:
        data = response.json()
        records = [item_model.model_validate(r) for r in data.get("records", [])]
        return PaginatedResponse[T](
            records=records,
            next_token=data.get("next_token"),
        )
