"""CLI entry point for whoop-client: ``whoop-client auth`` and ``whoop-client mcp``."""

from __future__ import annotations

import argparse
import os
import secrets
import sys
import webbrowser
from http.server import BaseHTTPRequestHandler, HTTPServer
from typing import TextIO
from urllib.parse import parse_qs, urlencode, urlparse

import httpx

from whoop_client._constants import (
    AUTHORIZATION_URL,
    DEFAULT_CALLBACK_PORT,
    DEFAULT_REDIRECT_URI,
    DEFAULT_SCOPES,
    TOKEN_URL,
)
from whoop_client._exceptions import OAuthFlowError
from whoop_client._token_storage import StoredTokens, get_token_path, save_tokens


class _CallbackHandler(BaseHTTPRequestHandler):
    """HTTP handler that captures the OAuth2 callback."""

    auth_code: str | None = None
    error: str | None = None

    def do_GET(self) -> None:
        parsed = urlparse(self.path)
        if parsed.path != "/callback":
            self.send_response(404)
            self.end_headers()
            return

        params = parse_qs(parsed.query)
        if "code" in params:
            _CallbackHandler.auth_code = params["code"][0]
            self.send_response(200)
            self.send_header("Content-Type", "text/html")
            self.end_headers()
            self.wfile.write(b"<h1>Done! You can close this tab.</h1>")
        else:
            _CallbackHandler.error = params.get("error", ["unknown"])[0]
            self.send_response(400)
            self.send_header("Content-Type", "text/html")
            self.end_headers()
            self.wfile.write(f"<h1>Error: {_CallbackHandler.error}</h1>".encode())

    def log_message(self, format: str, *args: object) -> None:  # noqa: A002
        pass


def _build_authorize_url(
    client_id: str,
    redirect_uri: str,
    scopes: list[str],
    state: str,
) -> str:
    params = urlencode(
        {
            "client_id": client_id,
            "redirect_uri": redirect_uri,
            "response_type": "code",
            "scope": " ".join(scopes),
            "state": state,
        }
    )
    return f"{AUTHORIZATION_URL}?{params}"


def _exchange_code_for_tokens(
    code: str,
    client_id: str,
    client_secret: str,
    redirect_uri: str,
) -> dict:
    response = httpx.post(
        TOKEN_URL,
        data={
            "grant_type": "authorization_code",
            "client_id": client_id,
            "client_secret": client_secret,
            "redirect_uri": redirect_uri,
            "code": code,
        },
    )
    response.raise_for_status()
    return response.json()


def run_oauth_flow(
    client_id: str,
    client_secret: str,
    *,
    scopes: list[str] | None = None,
    port: int = DEFAULT_CALLBACK_PORT,
    redirect_uri: str | None = None,
    open_browser: bool = True,
    output: TextIO = sys.stderr,
) -> dict:
    """Run the interactive browser-based OAuth2 Authorization Code flow.

    Opens a browser to the WHOOP authorization page, starts a local HTTP
    callback server, and exchanges the resulting code for tokens.

    Args:
        client_id: OAuth2 client ID.
        client_secret: OAuth2 client secret.
        scopes: OAuth2 scopes to request. Defaults to all read scopes.
        port: Local callback server port.
        redirect_uri: OAuth2 redirect URI. Defaults to ``http://localhost:{port}/callback``.
        open_browser: Whether to auto-open a browser. Falls back to printing the URL.
        output: Where to write status messages (default: stderr).

    Returns:
        Token response dict containing ``access_token``, ``refresh_token``, etc.

    Raises:
        OAuthFlowError: If the OAuth callback returns an error.
    """
    resolved_scopes = scopes or list(DEFAULT_SCOPES)
    resolved_redirect_uri = redirect_uri or f"http://localhost:{port}/callback"
    state = secrets.token_urlsafe(32)

    authorize_url = _build_authorize_url(
        client_id=client_id,
        redirect_uri=resolved_redirect_uri,
        scopes=resolved_scopes,
        state=state,
    )

    if open_browser:
        print("Opening browser for WHOOP authorization...", file=output)
        if not webbrowser.open(authorize_url):
            print(
                f"Could not open browser. Open this URL manually:\n\n{authorize_url}\n",
                file=output,
            )
    else:
        print(f"Open this URL in your browser:\n\n{authorize_url}\n", file=output)

    print(f"Waiting for callback on http://localhost:{port}/callback ...", file=output)

    # Reset handler state
    _CallbackHandler.auth_code = None
    _CallbackHandler.error = None

    server = HTTPServer(("localhost", port), _CallbackHandler)
    while _CallbackHandler.auth_code is None and _CallbackHandler.error is None:
        server.handle_request()
    server.server_close()

    if _CallbackHandler.error:
        raise OAuthFlowError(f"OAuth callback error: {_CallbackHandler.error}")

    code = _CallbackHandler.auth_code
    print("Got authorization code, exchanging for tokens...", file=output)

    tokens = _exchange_code_for_tokens(
        code=code,
        client_id=client_id,
        client_secret=client_secret,
        redirect_uri=resolved_redirect_uri,
    )

    return tokens


# ---------------------------------------------------------------------------
# Subcommand: auth
# ---------------------------------------------------------------------------


def _add_auth_parser(subparsers: argparse._SubParsersAction) -> None:
    auth = subparsers.add_parser(
        "auth",
        help="Obtain WHOOP OAuth2 tokens via the browser.",
    )
    auth.add_argument(
        "--client-id",
        default=os.environ.get("WHOOP_CLIENT_ID"),
        help="OAuth2 client ID (default: $WHOOP_CLIENT_ID)",
    )
    auth.add_argument(
        "--client-secret",
        default=os.environ.get("WHOOP_CLIENT_SECRET"),
        help="OAuth2 client secret (default: $WHOOP_CLIENT_SECRET)",
    )
    auth.add_argument(
        "--scopes",
        nargs="+",
        default=list(DEFAULT_SCOPES),
        help="OAuth2 scopes (default: all read scopes)",
    )
    auth.add_argument(
        "--port",
        type=int,
        default=DEFAULT_CALLBACK_PORT,
        help=f"Local callback server port (default: {DEFAULT_CALLBACK_PORT})",
    )
    auth.add_argument(
        "--redirect-uri",
        default=None,
        help=f"OAuth2 redirect URI (default: {DEFAULT_REDIRECT_URI})",
    )
    auth.add_argument(
        "--token-file",
        default=None,
        help="Output file for tokens (default: ~/.config/whoop-client/tokens.json)",
    )
    auth.add_argument(
        "--no-open",
        action="store_true",
        help="Print the authorization URL instead of opening a browser",
    )
    auth.set_defaults(func=_run_auth)


def _run_auth(args: argparse.Namespace) -> None:
    if not args.client_id:
        print(
            "Error: --client-id or WHOOP_CLIENT_ID environment variable is required.",
            file=sys.stderr,
        )
        sys.exit(1)
    if not args.client_secret:
        print(
            "Error: --client-secret or WHOOP_CLIENT_SECRET environment variable is required.",
            file=sys.stderr,
        )
        sys.exit(1)

    tokens = run_oauth_flow(
        client_id=args.client_id,
        client_secret=args.client_secret,
        scopes=args.scopes,
        port=args.port,
        redirect_uri=args.redirect_uri,
        open_browser=not args.no_open,
        output=sys.stdout,
    )

    token_path = get_token_path(args.token_file)
    save_tokens(
        token_path,
        StoredTokens(
            access_token=tokens["access_token"],
            refresh_token=tokens["refresh_token"],
            expires_at=tokens.get("expires_at", 0),
        ),
    )
    print(f"Tokens saved to {token_path}")


# ---------------------------------------------------------------------------
# Subcommand: mcp
# ---------------------------------------------------------------------------


def _add_mcp_parser(subparsers: argparse._SubParsersAction) -> None:
    mcp_parser = subparsers.add_parser(
        "mcp",
        help="Start the WHOOP MCP server (stdio transport).",
    )
    mcp_parser.set_defaults(func=_run_mcp)


def _run_mcp(args: argparse.Namespace) -> None:
    from whoop_client.mcp.server import mcp

    mcp.run(transport="stdio")


# ---------------------------------------------------------------------------
# Top-level entry point
# ---------------------------------------------------------------------------


def main(argv: list[str] | None = None) -> None:
    try:
        from dotenv import load_dotenv

        load_dotenv()
    except ImportError:
        pass

    parser = argparse.ArgumentParser(
        prog="whoop-client",
        description="WHOOP API client CLI.",
    )
    subparsers = parser.add_subparsers(dest="command")
    _add_auth_parser(subparsers)
    _add_mcp_parser(subparsers)

    args = parser.parse_args(argv)
    if not args.command:
        parser.print_help()
        sys.exit(1)

    args.func(args)
