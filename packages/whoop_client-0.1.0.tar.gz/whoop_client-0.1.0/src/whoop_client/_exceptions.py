from __future__ import annotations

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    import httpx


class WhoopError(Exception):
    """Base exception for all whoop-client errors."""


class WhoopAPIError(WhoopError):
    """Error returned by the WHOOP API."""

    def __init__(
        self, message: str, *, status_code: int, response: httpx.Response
    ) -> None:
        self.status_code = status_code
        self.response = response
        super().__init__(message)


class WhoopBadRequestError(WhoopAPIError):
    """400 Bad Request."""


class WhoopAuthenticationError(WhoopAPIError):
    """401 Unauthorized."""


class WhoopNotFoundError(WhoopAPIError):
    """404 Not Found."""


class WhoopRateLimitError(WhoopAPIError):
    """429 Too Many Requests."""

    def __init__(
        self,
        message: str,
        *,
        status_code: int,
        response: httpx.Response,
        retry_after: float | None = None,
    ) -> None:
        self.retry_after = retry_after
        super().__init__(message, status_code=status_code, response=response)


class WhoopServerError(WhoopAPIError):
    """5xx Server Error."""


class WhoopConnectionError(WhoopError):
    """Network connection failure."""


class WhoopTimeoutError(WhoopError):
    """Request timed out."""


class WhoopAuthTokenError(WhoopError):
    """Token refresh failure."""


class OAuthFlowError(WhoopError):
    """Interactive browser OAuth flow failure."""


_STATUS_CODE_MAP: dict[int, type[WhoopAPIError]] = {
    400: WhoopBadRequestError,
    401: WhoopAuthenticationError,
    404: WhoopNotFoundError,
    429: WhoopRateLimitError,
}


def raise_for_status(response: httpx.Response) -> None:
    """Raise a typed exception for error HTTP status codes."""
    if response.is_success:
        return

    status_code = response.status_code

    # Try to extract error message from JSON body
    message = f"WHOOP API error {status_code}"
    try:
        body = response.json()
        if isinstance(body, dict):
            message = body.get("message", body.get("error", message))
    except Exception:
        text = response.text
        if text:
            message = text

    # 429 special handling for Retry-After
    if status_code == 429:
        retry_after: float | None = None
        raw = response.headers.get("Retry-After")
        if raw is not None:
            try:
                retry_after = float(raw)
            except ValueError:
                pass
        raise WhoopRateLimitError(
            message,
            status_code=status_code,
            response=response,
            retry_after=retry_after,
        )

    exc_class = _STATUS_CODE_MAP.get(status_code)
    if exc_class is not None:
        raise exc_class(message, status_code=status_code, response=response)

    if 500 <= status_code < 600:
        raise WhoopServerError(message, status_code=status_code, response=response)

    raise WhoopAPIError(message, status_code=status_code, response=response)
