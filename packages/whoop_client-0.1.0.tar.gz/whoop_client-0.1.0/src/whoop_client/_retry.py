from __future__ import annotations

import asyncio
import random
import time
from collections.abc import Awaitable, Callable
from dataclasses import dataclass, field
from typing import TypeVar

import httpx

from whoop_client._exceptions import (
    WhoopConnectionError,
    WhoopError,
    WhoopTimeoutError,
    raise_for_status,
)

T = TypeVar("T", bound=httpx.Response)

_DEFAULT_RETRYABLE = frozenset({429, 500, 502, 503, 504})


@dataclass(frozen=True, slots=True)
class RetryPolicy:
    max_retries: int = 3
    backoff_factor: float = 0.5
    retryable_status_codes: frozenset[int] = field(
        default_factory=lambda: _DEFAULT_RETRYABLE
    )
    retry_on_timeout: bool = True
    retry_on_connection_error: bool = True
    max_backoff_seconds: float = 60.0


def _compute_delay(
    policy: RetryPolicy, attempt: int, retry_after: float | None
) -> float:
    if retry_after is not None and retry_after > 0:
        return min(retry_after, policy.max_backoff_seconds)
    delay = policy.backoff_factor * (2**attempt)
    jitter = random.uniform(0, delay * 0.25)  # noqa: S311
    return min(delay + jitter, policy.max_backoff_seconds)


def execute_with_retry_sync(
    fn: Callable[[], httpx.Response],
    policy: RetryPolicy,
) -> httpx.Response:
    last_exception: Exception | None = None

    for attempt in range(policy.max_retries + 1):
        try:
            response = fn()
        except httpx.TimeoutException as exc:
            if not policy.retry_on_timeout or attempt == policy.max_retries:
                raise WhoopTimeoutError(str(exc)) from exc
            last_exception = exc
            time.sleep(_compute_delay(policy, attempt, None))
            continue
        except httpx.ConnectError as exc:
            if not policy.retry_on_connection_error or attempt == policy.max_retries:
                raise WhoopConnectionError(str(exc)) from exc
            last_exception = exc
            time.sleep(_compute_delay(policy, attempt, None))
            continue

        if (
            response.status_code in policy.retryable_status_codes
            and attempt < policy.max_retries
        ):
            retry_after: float | None = None
            if response.status_code == 429:
                raw = response.headers.get("Retry-After")
                if raw is not None:
                    try:
                        retry_after = float(raw)
                    except ValueError:
                        pass
            time.sleep(_compute_delay(policy, attempt, retry_after))
            continue

        raise_for_status(response)
        return response

    # Should not reach here, but satisfy type checker  # pragma: no cover
    if last_exception is not None:  # pragma: no cover
        raise WhoopTimeoutError(
            str(last_exception)
        ) from last_exception  # pragma: no cover
    raise WhoopError("Retry exhausted")  # pragma: no cover


async def execute_with_retry_async(
    fn: Callable[[], Awaitable[httpx.Response]],
    policy: RetryPolicy,
) -> httpx.Response:
    last_exception: Exception | None = None

    for attempt in range(policy.max_retries + 1):
        try:
            response = await fn()
        except httpx.TimeoutException as exc:
            if not policy.retry_on_timeout or attempt == policy.max_retries:
                raise WhoopTimeoutError(str(exc)) from exc
            last_exception = exc
            await asyncio.sleep(_compute_delay(policy, attempt, None))
            continue
        except httpx.ConnectError as exc:
            if not policy.retry_on_connection_error or attempt == policy.max_retries:
                raise WhoopConnectionError(str(exc)) from exc
            last_exception = exc
            await asyncio.sleep(_compute_delay(policy, attempt, None))
            continue

        if (
            response.status_code in policy.retryable_status_codes
            and attempt < policy.max_retries
        ):
            retry_after: float | None = None
            if response.status_code == 429:
                raw = response.headers.get("Retry-After")
                if raw is not None:
                    try:
                        retry_after = float(raw)
                    except ValueError:
                        pass
            await asyncio.sleep(_compute_delay(policy, attempt, retry_after))
            continue

        raise_for_status(response)
        return response

    if last_exception is not None:  # pragma: no cover
        raise WhoopTimeoutError(
            str(last_exception)
        ) from last_exception  # pragma: no cover
    raise WhoopError("Retry exhausted")  # pragma: no cover
