"""Centralized token file I/O for persisting OAuth tokens to disk."""

from __future__ import annotations

import json
import os
from pathlib import Path
from typing import TypedDict

from whoop_client._auth import OnTokenRefresh

DEFAULT_TOKEN_DIR = "~/.config/whoop-client"
DEFAULT_TOKEN_FILENAME = "tokens.json"


class StoredTokens(TypedDict):
    access_token: str
    refresh_token: str
    expires_at: float


def get_token_path(override: str | Path | None = None) -> Path:
    """Resolve the token file path.

    Priority: explicit *override* > ``WHOOP_TOKEN_FILE`` env var > default.
    """
    if override is not None:
        return Path(override).expanduser()

    env = os.environ.get("WHOOP_TOKEN_FILE")
    if env:
        return Path(env).expanduser()

    return Path(DEFAULT_TOKEN_DIR).expanduser() / DEFAULT_TOKEN_FILENAME


def load_tokens(path: Path) -> StoredTokens | None:
    """Load tokens from *path*, returning ``None`` if missing or malformed."""
    try:
        data = json.loads(path.read_text())
    except (FileNotFoundError, json.JSONDecodeError, OSError):
        return None

    if (
        isinstance(data, dict)
        and "access_token" in data
        and "refresh_token" in data
        and "expires_at" in data
    ):
        return StoredTokens(
            access_token=data["access_token"],
            refresh_token=data["refresh_token"],
            expires_at=data["expires_at"],
        )
    return None


def save_tokens(path: Path, tokens: StoredTokens) -> None:
    """Write *tokens* as JSON to *path*, creating parent directories as needed."""
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(dict(tokens), indent=2) + "\n")


def make_token_file_callback(path: Path) -> OnTokenRefresh:
    """Return an ``on_token_refresh`` callback that persists tokens to *path*."""

    def _on_refresh(access_token: str, refresh_token: str, expires_at: float) -> None:
        save_tokens(
            path,
            StoredTokens(
                access_token=access_token,
                refresh_token=refresh_token,
                expires_at=expires_at,
            ),
        )

    return _on_refresh
