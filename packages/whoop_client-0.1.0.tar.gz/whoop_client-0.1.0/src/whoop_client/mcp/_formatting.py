from __future__ import annotations

from whoop_client.models.cycle import Cycle
from whoop_client.models.recovery import Recovery
from whoop_client.models.sleep import Sleep
from whoop_client.models.user import UserBasicProfile, UserBodyMeasurement
from whoop_client.models.workout import Workout
from whoop_client.models._pagination import PaginatedResponse


def _ms_to_hours_minutes(ms: int) -> str:
    total_minutes = ms // 60_000
    hours, minutes = divmod(total_minutes, 60)
    if hours:
        return f"{hours}h {minutes}m"
    return f"{minutes}m"


def format_cycle(cycle: Cycle) -> str:
    lines = [
        f"Cycle {cycle.id}",
        f"  Start: {cycle.start.isoformat()}",
        f"  End: {cycle.end.isoformat() if cycle.end else 'ongoing'}",
        f"  Score state: {cycle.score_state.value}",
    ]
    if cycle.score:
        lines.extend(
            [
                f"  Strain: {cycle.score.strain:.1f}",
                f"  Kilojoules: {cycle.score.kilojoule:.1f}",
                f"  Avg HR: {cycle.score.average_heart_rate} bpm",
                f"  Max HR: {cycle.score.max_heart_rate} bpm",
            ]
        )
    return "\n".join(lines)


def format_cycles(page: PaginatedResponse[Cycle]) -> str:
    if not page.records:
        return "No cycles found."
    parts = [format_cycle(c) for c in page.records]
    text = "\n\n".join(parts)
    if page.next_token:
        text += f"\n\n[More results available. Use next_token: {page.next_token}]"
    return text


def format_recovery(recovery: Recovery) -> str:
    lines = [
        f"Recovery (cycle {recovery.cycle_id})",
        f"  Sleep ID: {recovery.sleep_id}",
        f"  Score state: {recovery.score_state.value}",
    ]
    if recovery.score:
        lines.append(f"  Recovery score: {recovery.score.recovery_score:.0f}%")
        lines.append(f"  Resting HR: {recovery.score.resting_heart_rate:.0f} bpm")
        lines.append(f"  HRV (RMSSD): {recovery.score.hrv_rmssd_milli:.1f} ms")
        if recovery.score.spo2_percentage is not None:
            lines.append(f"  SpO2: {recovery.score.spo2_percentage:.1f}%")
        if recovery.score.skin_temp_celsius is not None:
            lines.append(f"  Skin temp: {recovery.score.skin_temp_celsius:.1f}\u00b0C")
        if recovery.score.user_calibrating:
            lines.append("  (User is calibrating)")
    return "\n".join(lines)


def format_recoveries(page: PaginatedResponse[Recovery]) -> str:
    if not page.records:
        return "No recoveries found."
    parts = [format_recovery(r) for r in page.records]
    text = "\n\n".join(parts)
    if page.next_token:
        text += f"\n\n[More results available. Use next_token: {page.next_token}]"
    return text


def format_sleep(sleep: Sleep) -> str:
    lines = [
        f"Sleep {sleep.id}{' (nap)' if sleep.nap else ''}",
        f"  Start: {sleep.start.isoformat()}",
        f"  End: {sleep.end.isoformat()}",
        f"  Score state: {sleep.score_state.value}",
    ]
    if sleep.score:
        s = sleep.score
        if s.sleep_performance_percentage is not None:
            lines.append(f"  Performance: {s.sleep_performance_percentage:.0f}%")
        if s.sleep_efficiency_percentage is not None:
            lines.append(f"  Efficiency: {s.sleep_efficiency_percentage:.0f}%")
        if s.sleep_consistency_percentage is not None:
            lines.append(f"  Consistency: {s.sleep_consistency_percentage:.0f}%")
        if s.respiratory_rate is not None:
            lines.append(f"  Respiratory rate: {s.respiratory_rate:.1f} rpm")

        ss = s.stage_summary
        lines.append(
            f"  Total in bed: {_ms_to_hours_minutes(ss.total_in_bed_time_milli)}"
        )
        lines.append(f"  Awake: {_ms_to_hours_minutes(ss.total_awake_time_milli)}")
        lines.append(
            f"  Light sleep: {_ms_to_hours_minutes(ss.total_light_sleep_time_milli)}"
        )
        lines.append(
            f"  Deep (SWS): {_ms_to_hours_minutes(ss.total_slow_wave_sleep_time_milli)}"
        )
        lines.append(f"  REM: {_ms_to_hours_minutes(ss.total_rem_sleep_time_milli)}")
        lines.append(f"  Sleep cycles: {ss.sleep_cycle_count}")
        lines.append(f"  Disturbances: {ss.disturbance_count}")

        sn = s.sleep_needed
        lines.append(
            f"  Sleep needed (baseline): {_ms_to_hours_minutes(sn.baseline_milli)}"
        )
        lines.append(
            f"  Sleep needed (debt): {_ms_to_hours_minutes(sn.need_from_sleep_debt_milli)}"
        )
        lines.append(
            f"  Sleep needed (strain): {_ms_to_hours_minutes(sn.need_from_recent_strain_milli)}"
        )
        lines.append(
            f"  Sleep needed (nap adj): {_ms_to_hours_minutes(sn.need_from_recent_nap_milli)}"
        )
    return "\n".join(lines)


def format_sleeps(page: PaginatedResponse[Sleep]) -> str:
    if not page.records:
        return "No sleeps found."
    parts = [format_sleep(s) for s in page.records]
    text = "\n\n".join(parts)
    if page.next_token:
        text += f"\n\n[More results available. Use next_token: {page.next_token}]"
    return text


def format_workout(workout: Workout) -> str:
    lines = [
        f"Workout {workout.id}",
        f"  Sport: {workout.sport_name or 'Unknown'}",
        f"  Start: {workout.start.isoformat()}",
        f"  End: {workout.end.isoformat()}",
        f"  Score state: {workout.score_state.value}",
    ]
    if workout.score:
        ws = workout.score
        lines.extend(
            [
                f"  Strain: {ws.strain:.1f}",
                f"  Avg HR: {ws.average_heart_rate} bpm",
                f"  Max HR: {ws.max_heart_rate} bpm",
                f"  Kilojoules: {ws.kilojoule:.1f}",
                f"  Percent recorded: {ws.percent_recorded:.0f}%",
            ]
        )
        if ws.distance_meter is not None:
            lines.append(f"  Distance: {ws.distance_meter:.0f} m")
        if ws.altitude_gain_meter is not None:
            lines.append(f"  Altitude gain: {ws.altitude_gain_meter:.0f} m")
        if ws.zone_duration:
            zd = ws.zone_duration
            lines.append("  Heart rate zones:")
            lines.append(
                f"    Zone 0 (rest): {_ms_to_hours_minutes(zd.zone_zero_milli)}"
            )
            lines.append(f"    Zone 1: {_ms_to_hours_minutes(zd.zone_one_milli)}")
            lines.append(f"    Zone 2: {_ms_to_hours_minutes(zd.zone_two_milli)}")
            lines.append(f"    Zone 3: {_ms_to_hours_minutes(zd.zone_three_milli)}")
            lines.append(f"    Zone 4: {_ms_to_hours_minutes(zd.zone_four_milli)}")
            lines.append(f"    Zone 5: {_ms_to_hours_minutes(zd.zone_five_milli)}")
    return "\n".join(lines)


def format_workouts(page: PaginatedResponse[Workout]) -> str:
    if not page.records:
        return "No workouts found."
    parts = [format_workout(w) for w in page.records]
    text = "\n\n".join(parts)
    if page.next_token:
        text += f"\n\n[More results available. Use next_token: {page.next_token}]"
    return text


def format_profile(profile: UserBasicProfile) -> str:
    return (
        f"User profile\n"
        f"  User ID: {profile.user_id}\n"
        f"  Name: {profile.first_name} {profile.last_name}\n"
        f"  Email: {profile.email}"
    )


def format_body_measurement(body: UserBodyMeasurement) -> str:
    return (
        f"Body measurements\n"
        f"  Height: {body.height_meter:.2f} m\n"
        f"  Weight: {body.weight_kilogram:.1f} kg\n"
        f"  Max HR: {body.max_heart_rate} bpm"
    )
