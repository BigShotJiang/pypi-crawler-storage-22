from __future__ import annotations

import asyncio
import os
import sys
from collections.abc import AsyncIterator
from contextlib import asynccontextmanager
from dataclasses import dataclass
from datetime import datetime

from mcp.server.fastmcp import Context, FastMCP

from whoop_client._async_client import AsyncWhoopClient
from whoop_client._auth import AsyncOAuthTokenProvider, StaticTokenProvider
from whoop_client._cli import run_oauth_flow
from whoop_client._token_storage import (
    StoredTokens,
    get_token_path,
    load_tokens,
    make_token_file_callback,
    save_tokens,
)

from ._formatting import (
    format_body_measurement,
    format_cycle,
    format_cycles,
    format_profile,
    format_recoveries,
    format_recovery,
    format_sleep,
    format_sleeps,
    format_workout,
    format_workouts,
)

try:
    from dotenv import load_dotenv

    load_dotenv()
except ImportError:
    pass


@dataclass
class WhoopContext:
    client: AsyncWhoopClient


@asynccontextmanager
async def whoop_lifespan(server: FastMCP) -> AsyncIterator[WhoopContext]:
    client_id = os.environ.get("WHOOP_CLIENT_ID")
    client_secret = os.environ.get("WHOOP_CLIENT_SECRET")
    refresh_token = os.environ.get("WHOOP_REFRESH_TOKEN")
    access_token = os.environ.get("WHOOP_ACCESS_TOKEN")

    has_client_credentials = bool(client_id and client_secret)
    token_path = get_token_path()

    # Strategy 1: Env vars with full OAuth credentials
    if has_client_credentials and refresh_token:
        assert client_id is not None
        assert client_secret is not None
        print("Using OAuth credentials from environment variables.", file=sys.stderr)
        on_refresh = make_token_file_callback(token_path)
        token_provider = AsyncOAuthTokenProvider(
            client_id=client_id,
            client_secret=client_secret,
            refresh_token=refresh_token,
            access_token=access_token,
            on_token_refresh=on_refresh,
        )

    # Strategy 2: Static access token only (no client credentials)
    elif access_token and not has_client_credentials:
        print("Using static access token (no auto-refresh).", file=sys.stderr)
        token_provider = StaticTokenProvider(access_token)

    # Strategy 3: Stored tokens file (needs client credentials)
    elif has_client_credentials and (stored := load_tokens(token_path)):
        assert client_id is not None
        assert client_secret is not None
        print(f"Using stored tokens from {token_path}.", file=sys.stderr)
        on_refresh = make_token_file_callback(token_path)
        token_provider = AsyncOAuthTokenProvider(
            client_id=client_id,
            client_secret=client_secret,
            refresh_token=stored["refresh_token"],
            access_token=stored["access_token"],
            expires_at=stored["expires_at"],
            on_token_refresh=on_refresh,
        )

    # Strategy 4: Interactive browser OAuth flow (needs client credentials)
    elif has_client_credentials:
        assert client_id is not None
        assert client_secret is not None
        print("No tokens found. Starting browser OAuth flow...", file=sys.stderr)
        tokens = await asyncio.to_thread(
            run_oauth_flow,
            client_id,
            client_secret,
            output=sys.stderr,
        )
        save_tokens(
            token_path,
            StoredTokens(
                access_token=tokens["access_token"],
                refresh_token=tokens["refresh_token"],
                expires_at=tokens.get("expires_at", 0),
            ),
        )
        print(f"Tokens saved to {token_path}.", file=sys.stderr)

        on_refresh = make_token_file_callback(token_path)
        token_provider = AsyncOAuthTokenProvider(
            client_id=client_id,
            client_secret=client_secret,
            refresh_token=tokens["refresh_token"],
            access_token=tokens["access_token"],
            on_token_refresh=on_refresh,
        )

    # Strategy 5: Nothing available
    else:
        print(
            "Error: set WHOOP_CLIENT_ID + WHOOP_CLIENT_SECRET (tokens will be "
            "acquired automatically via browser), or set WHOOP_ACCESS_TOKEN for "
            "static token mode.",
            file=sys.stderr,
        )
        sys.exit(1)

    client = AsyncWhoopClient(token_provider)
    try:
        yield WhoopContext(client=client)
    finally:
        await client.close()


mcp = FastMCP("whoop", lifespan=whoop_lifespan)


def _parse_date(value: str | None) -> datetime | None:
    if value is None:
        return None
    return datetime.fromisoformat(value)


# --- Cycle tools ---


@mcp.tool()
async def get_cycles(
    ctx: Context,
    start: str | None = None,
    end: str | None = None,
    limit: int | None = None,
    next_token: str | None = None,
) -> str:
    """Get a paginated list of physiological cycles.

    Each cycle represents one day of WHOOP data, including strain and heart rate.

    Args:
        start: Start date filter (ISO 8601 format, e.g. "2024-01-01").
        end: End date filter (ISO 8601 format, e.g. "2024-01-31").
        limit: Maximum number of results per page (max 25).
        next_token: Pagination token from a previous response.
    """
    whoop_ctx: WhoopContext = ctx.request_context.lifespan_context
    page = await whoop_ctx.client.get_cycles(
        start=_parse_date(start),
        end=_parse_date(end),
        limit=limit,
        next_token=next_token,
    )
    return format_cycles(page)


@mcp.tool()
async def get_cycle_by_id(ctx: Context, cycle_id: int) -> str:
    """Get a single physiological cycle by its ID.

    Args:
        cycle_id: The numeric cycle ID.
    """
    whoop_ctx: WhoopContext = ctx.request_context.lifespan_context
    cycle = await whoop_ctx.client.get_cycle_by_id(cycle_id)
    return format_cycle(cycle)


@mcp.tool()
async def get_cycle_sleep(ctx: Context, cycle_id: int) -> str:
    """Get the sleep record associated with a specific cycle.

    Args:
        cycle_id: The numeric cycle ID.
    """
    whoop_ctx: WhoopContext = ctx.request_context.lifespan_context
    sleep = await whoop_ctx.client.get_cycle_sleep(cycle_id)
    return format_sleep(sleep)


@mcp.tool()
async def get_cycle_recovery(ctx: Context, cycle_id: int) -> str:
    """Get the recovery record associated with a specific cycle.

    Args:
        cycle_id: The numeric cycle ID.
    """
    whoop_ctx: WhoopContext = ctx.request_context.lifespan_context
    recovery = await whoop_ctx.client.get_cycle_recovery(cycle_id)
    return format_recovery(recovery)


# --- Recovery tools ---


@mcp.tool()
async def get_recoveries(
    ctx: Context,
    start: str | None = None,
    end: str | None = None,
    limit: int | None = None,
    next_token: str | None = None,
) -> str:
    """Get a paginated list of recovery records.

    Recovery includes recovery score, HRV, resting heart rate, and SpO2.

    Args:
        start: Start date filter (ISO 8601 format, e.g. "2024-01-01").
        end: End date filter (ISO 8601 format, e.g. "2024-01-31").
        limit: Maximum number of results per page (max 25).
        next_token: Pagination token from a previous response.
    """
    whoop_ctx: WhoopContext = ctx.request_context.lifespan_context
    page = await whoop_ctx.client.get_recoveries(
        start=_parse_date(start),
        end=_parse_date(end),
        limit=limit,
        next_token=next_token,
    )
    return format_recoveries(page)


# --- Sleep tools ---


@mcp.tool()
async def get_sleeps(
    ctx: Context,
    start: str | None = None,
    end: str | None = None,
    limit: int | None = None,
    next_token: str | None = None,
) -> str:
    """Get a paginated list of sleep records.

    Includes sleep stages, duration, performance, and sleep needed breakdown.

    Args:
        start: Start date filter (ISO 8601 format, e.g. "2024-01-01").
        end: End date filter (ISO 8601 format, e.g. "2024-01-31").
        limit: Maximum number of results per page (max 25).
        next_token: Pagination token from a previous response.
    """
    whoop_ctx: WhoopContext = ctx.request_context.lifespan_context
    page = await whoop_ctx.client.get_sleeps(
        start=_parse_date(start),
        end=_parse_date(end),
        limit=limit,
        next_token=next_token,
    )
    return format_sleeps(page)


@mcp.tool()
async def get_sleep_by_id(ctx: Context, sleep_id: str) -> str:
    """Get a single sleep record by its ID.

    Args:
        sleep_id: The sleep record ID.
    """
    whoop_ctx: WhoopContext = ctx.request_context.lifespan_context
    sleep = await whoop_ctx.client.get_sleep_by_id(sleep_id)
    return format_sleep(sleep)


# --- Workout tools ---


@mcp.tool()
async def get_workouts(
    ctx: Context,
    start: str | None = None,
    end: str | None = None,
    limit: int | None = None,
    next_token: str | None = None,
) -> str:
    """Get a paginated list of workout records.

    Includes sport type, strain, heart rate, and heart rate zone durations.

    Args:
        start: Start date filter (ISO 8601 format, e.g. "2024-01-01").
        end: End date filter (ISO 8601 format, e.g. "2024-01-31").
        limit: Maximum number of results per page (max 25).
        next_token: Pagination token from a previous response.
    """
    whoop_ctx: WhoopContext = ctx.request_context.lifespan_context
    page = await whoop_ctx.client.get_workouts(
        start=_parse_date(start),
        end=_parse_date(end),
        limit=limit,
        next_token=next_token,
    )
    return format_workouts(page)


@mcp.tool()
async def get_workout_by_id(ctx: Context, workout_id: str) -> str:
    """Get a single workout record by its ID.

    Args:
        workout_id: The workout record ID.
    """
    whoop_ctx: WhoopContext = ctx.request_context.lifespan_context
    workout = await whoop_ctx.client.get_workout_by_id(workout_id)
    return format_workout(workout)


# --- User tools ---


@mcp.tool()
async def get_profile(ctx: Context) -> str:
    """Get the user's basic profile (name, email, user ID)."""
    whoop_ctx: WhoopContext = ctx.request_context.lifespan_context
    profile = await whoop_ctx.client.get_profile()
    return format_profile(profile)


@mcp.tool()
async def get_body_measurement(ctx: Context) -> str:
    """Get the user's body measurements (height, weight, max heart rate)."""
    whoop_ctx: WhoopContext = ctx.request_context.lifespan_context
    body = await whoop_ctx.client.get_body_measurement()
    return format_body_measurement(body)
