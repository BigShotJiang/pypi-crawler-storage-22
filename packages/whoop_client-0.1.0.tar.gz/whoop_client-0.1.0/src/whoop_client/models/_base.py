from __future__ import annotations

from pydantic import BaseModel, ConfigDict


class WhoopModel(BaseModel):
    model_config = ConfigDict(
        frozen=True,
        populate_by_name=True,
        extra="ignore",
    )
