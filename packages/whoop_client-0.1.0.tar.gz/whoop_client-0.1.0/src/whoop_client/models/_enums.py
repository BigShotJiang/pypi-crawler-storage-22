from __future__ import annotations

from enum import Enum


class ScoreState(str, Enum):
    SCORED = "SCORED"
    PENDING_SCORE = "PENDING_SCORE"
    UNSCORABLE = "UNSCORABLE"
