from __future__ import annotations

from whoop_client.models._base import WhoopModel


class ActivityIdMapping(WhoopModel):
    id: str
    type: str
