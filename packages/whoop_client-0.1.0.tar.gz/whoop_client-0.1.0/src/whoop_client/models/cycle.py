from __future__ import annotations

from datetime import datetime

from whoop_client.models._base import WhoopModel
from whoop_client.models._enums import ScoreState


class CycleScore(WhoopModel):
    strain: float
    kilojoule: float
    average_heart_rate: int
    max_heart_rate: int


class Cycle(WhoopModel):
    id: int
    user_id: int
    created_at: datetime
    updated_at: datetime
    start: datetime
    end: datetime | None = None
    timezone_offset: str | None = None
    score_state: ScoreState
    score: CycleScore | None = None
