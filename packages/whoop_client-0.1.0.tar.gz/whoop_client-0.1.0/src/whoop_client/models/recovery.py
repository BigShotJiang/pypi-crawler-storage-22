from __future__ import annotations

from datetime import datetime

from whoop_client.models._base import WhoopModel
from whoop_client.models._enums import ScoreState


class RecoveryScore(WhoopModel):
    user_calibrating: bool
    recovery_score: float
    resting_heart_rate: float
    hrv_rmssd_milli: float
    spo2_percentage: float | None = None
    skin_temp_celsius: float | None = None


class Recovery(WhoopModel):
    cycle_id: int
    sleep_id: str
    user_id: int
    created_at: datetime
    updated_at: datetime
    score_state: ScoreState
    score: RecoveryScore | None = None
