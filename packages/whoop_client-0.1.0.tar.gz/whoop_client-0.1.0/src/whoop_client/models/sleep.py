from __future__ import annotations

from datetime import datetime

from whoop_client.models._base import WhoopModel
from whoop_client.models._enums import ScoreState


class SleepStageSummary(WhoopModel):
    total_in_bed_time_milli: int
    total_awake_time_milli: int
    total_no_data_time_milli: int
    total_light_sleep_time_milli: int
    total_slow_wave_sleep_time_milli: int
    total_rem_sleep_time_milli: int
    sleep_cycle_count: int
    disturbance_count: int


class SleepNeeded(WhoopModel):
    baseline_milli: int
    need_from_sleep_debt_milli: int
    need_from_recent_strain_milli: int
    need_from_recent_nap_milli: int


class SleepScore(WhoopModel):
    stage_summary: SleepStageSummary
    sleep_needed: SleepNeeded
    respiratory_rate: float | None = None
    sleep_performance_percentage: float | None = None
    sleep_consistency_percentage: float | None = None
    sleep_efficiency_percentage: float | None = None


class Sleep(WhoopModel):
    id: str
    user_id: int
    created_at: datetime
    updated_at: datetime
    start: datetime
    end: datetime
    timezone_offset: str | None = None
    nap: bool
    score_state: ScoreState
    score: SleepScore | None = None
