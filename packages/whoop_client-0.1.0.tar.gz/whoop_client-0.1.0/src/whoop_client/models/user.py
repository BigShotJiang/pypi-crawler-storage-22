from __future__ import annotations

from whoop_client.models._base import WhoopModel


class UserBasicProfile(WhoopModel):
    user_id: int
    email: str
    first_name: str
    last_name: str


class UserBodyMeasurement(WhoopModel):
    height_meter: float
    weight_kilogram: float
    max_heart_rate: int
