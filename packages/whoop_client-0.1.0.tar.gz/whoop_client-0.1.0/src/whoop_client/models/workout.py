from __future__ import annotations

from datetime import datetime

from whoop_client.models._base import WhoopModel
from whoop_client.models._enums import ScoreState


class ZoneDurations(WhoopModel):
    zone_zero_milli: int
    zone_one_milli: int
    zone_two_milli: int
    zone_three_milli: int
    zone_four_milli: int
    zone_five_milli: int


class WorkoutScore(WhoopModel):
    strain: float
    average_heart_rate: int
    max_heart_rate: int
    kilojoule: float
    percent_recorded: float
    distance_meter: float | None = None
    altitude_gain_meter: float | None = None
    altitude_change_meter: float | None = None
    zone_duration: ZoneDurations | None = None


class Workout(WhoopModel):
    id: str
    user_id: int
    created_at: datetime
    updated_at: datetime
    start: datetime
    end: datetime
    timezone_offset: str | None = None
    sport_name: str | None = None
    score_state: ScoreState
    score: WorkoutScore | None = None
