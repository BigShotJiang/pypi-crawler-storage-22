# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import List, Optional
from typing_extensions import Literal, Required, TypedDict

from .app_type import AppType
from .shared.app_statuses import AppStatuses

__all__ = ["AppUpdateParams", "Icon"]


class AppUpdateParams(TypedDict, total=False):
    app_store_description: Optional[str]
    """The description of the app for the app store in-depth app view."""

    app_type: Optional[AppType]
    """The type of end-user an app is built for"""

    base_url: Optional[str]
    """The base production url of the app"""

    dashboard_path: Optional[str]
    """The path for the dashboard view of the app"""

    description: Optional[str]
    """The description of the app"""

    discover_path: Optional[str]
    """The path for the discover view of the app"""

    experience_path: Optional[str]
    """The path for the hub view of the app"""

    icon: Optional[Icon]
    """The icon for the app"""

    name: Optional[str]
    """The name of the app"""

    required_scopes: Optional[List[Literal["read_user"]]]
    """The scopes that the app will request off of users when a user installs the app."""

    status: Optional[AppStatuses]
    """The status of an experience interface"""


class Icon(TypedDict, total=False):
    """The icon for the app"""

    id: Required[str]
    """The ID of an existing file object."""
