"""WhOSSpr Flow - Open Source Speech-to-Text for macOS."""

__version__ = "0.1.0"
__app_name__ = "whosspr"
