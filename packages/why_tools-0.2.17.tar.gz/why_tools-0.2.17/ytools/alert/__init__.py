# -*- coding: utf-8 -*-
"""
@File    : __init__.py.py
@Author  : yintian
@Date    : 2026/1/8 15:00
@Software: PyCharm
@Desc    : 
"""

if __name__ == '__main__':
    pass
