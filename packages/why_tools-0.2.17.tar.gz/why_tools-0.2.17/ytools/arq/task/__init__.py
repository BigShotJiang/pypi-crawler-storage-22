# -*- coding: utf-8 -*-
"""
@File    : __init__.py.py
@Author  : yintian
@Date    : 2025/10/21 10:35
@Software: PyCharm
@Desc    : 
"""

if __name__ == '__main__':
    pass
