# flake8: noqa

# import apis into api package
from wildberries_sdk.general.api.default_api import DefaultApi

