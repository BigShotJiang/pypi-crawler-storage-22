# flake8: noqa

# import apis into api package
from wildberries_sdk.in_store_pickup.api.default_api import DefaultApi

