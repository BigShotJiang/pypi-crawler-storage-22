"""
The following things can be done with WILLIAM:
1. Define Graphs (with Node, ValueNode und Graph)
2. Define custom or use existing values and operators contained in those graphs (Value, library operators)
3. Save and load graphs (parse_dot_file)
4. Definite own objective function for optimization, by default compression is maximized,
   i.e. description length is minimized.
5. Run induction (Induction)
"""

try:
    # Version is added only when packaged
    from william._version import __version__
except ImportError:
    try:
        from setuptools_scm import get_version
    except ImportError:
        __version__ = None
    else:
        __version__ = get_version(root="..", relative_to=__file__)
        del get_version
