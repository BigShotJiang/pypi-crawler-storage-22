"""ANSI colors taken from https://github.com/tartley/colorama/blob/master/colorama/ansi.py"""

_ANSI_COLOR_FMT = "\033[1;{:d}m"


class ANSI:
    RESET = "\033[0m"
    BOLD = "\033[1m"

    BLACK, RED, GREEN, YELLOW, BLUE, MAGENTA, CYAN, WHITE = (_ANSI_COLOR_FMT.format(c) for c in range(30, 38))
    (
        LIGHTBLACK,
        LIGHTRED,
        LIGHTGREEN,
        LIGHTYELLOW,
        LIGHTBLUE,
        LIGHTMAGENTA,
        LIGHTCYAN,
        LIGHTWHITE,
    ) = (_ANSI_COLOR_FMT.format(c) for c in range(90, 98))
    B_BLACK, B_RED, B_GREEN, B_YELLOW, B_BLUE, B_MAGENTA, B_CYAN, B_WHITE = (
        _ANSI_COLOR_FMT.format(c) for c in range(40, 48)
    )
    (
        B_LIGHTBLACK,
        B_LIGHTRED,
        B_LIGHTGREEN,
        B_LIGHTYELLOW,
        B_LIGHTBLUE,
        B_LIGHTMAGENTA,
        B_LIGHTCYAN,
        B_LIGHTWHITE,
    ) = (_ANSI_COLOR_FMT.format(c) for c in range(100, 108))
