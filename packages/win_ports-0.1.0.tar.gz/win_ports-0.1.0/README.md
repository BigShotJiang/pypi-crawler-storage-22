# win-ports

TUI tool to view listening ports and kill processes with filtering support.

## Installation

```bash
pip install win-ports
```

## Usage

```bash
win-ports
# or
wp
```

## Keybindings

| Key | Action |
|-----|--------|
| `/` | Filter |
| `Escape` | Clear filter |
| `r` | Refresh |
| `k` / `Enter` | Kill process |
| `q` | Quit |

## License

MIT
