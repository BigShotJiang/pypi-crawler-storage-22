"""win-ports - TUI tool to view listening ports and kill processes with filtering support."""

from datetime import datetime

import psutil
from textual import on
from textual.app import App, ComposeResult
from textual.binding import Binding
from textual.containers import Container, Horizontal, Vertical
from textual.screen import ModalScreen
from textual.widgets import Button, DataTable, Footer, Input, Label, Static


def get_listening_ports() -> list[dict]:
    """Get all listening ports with process information."""
    ports = []

    for conn in psutil.net_connections(kind="inet"):
        if conn.status == "LISTEN":
            try:
                proc = psutil.Process(conn.pid) if conn.pid else None
                proc_name = proc.name() if proc else "Unknown"
            except (psutil.NoSuchProcess, psutil.AccessDenied):
                proc_name = "Unknown"

            ports.append({
                "protocol": "TCP",
                "address": conn.laddr.ip if conn.laddr else "-",
                "port": conn.laddr.port if conn.laddr else 0,
                "pid": conn.pid or 0,
                "process": proc_name,
            })

    for conn in psutil.net_connections(kind="udp"):
        if conn.status == "NONE":
            try:
                proc = psutil.Process(conn.pid) if conn.pid else None
                proc_name = proc.name() if proc else "Unknown"
            except (psutil.NoSuchProcess, psutil.AccessDenied):
                proc_name = "Unknown"

            ports.append({
                "protocol": "UDP",
                "address": conn.laddr.ip if conn.laddr else "-",
                "port": conn.laddr.port if conn.laddr else 0,
                "pid": conn.pid or 0,
                "process": proc_name,
            })

    return sorted(ports, key=lambda x: x["port"])


class ConfirmKillScreen(ModalScreen[bool]):
    """Modal screen to confirm process termination."""

    BINDINGS = [
        Binding("y", "confirm", "Yes"),
        Binding("n", "cancel", "No"),
        Binding("escape", "cancel", "Cancel"),
    ]

    def __init__(self, pid: int, process_name: str, port: int) -> None:
        super().__init__()
        self.pid = pid
        self.process_name = process_name
        self.port = port

    def compose(self) -> ComposeResult:
        with Container(id="confirm-dialog"):
            yield Label("Kill process?", id="confirm-title")
            yield Static(
                f"Process: [bold]{self.process_name}[/bold]\n"
                f"PID: [bold]{self.pid}[/bold]\n"
                f"Port: [bold]{self.port}[/bold]",
                id="confirm-details",
            )
            with Horizontal(id="confirm-buttons"):
                yield Button("Yes (Y)", variant="error", id="btn-yes")
                yield Button("No (N)", variant="primary", id="btn-no")

    def action_confirm(self) -> None:
        self.dismiss(True)

    def action_cancel(self) -> None:
        self.dismiss(False)

    @on(Button.Pressed, "#btn-yes")
    def on_yes(self) -> None:
        self.dismiss(True)

    @on(Button.Pressed, "#btn-no")
    def on_no(self) -> None:
        self.dismiss(False)


class WinPortsApp(App):
    """TUI application for viewing and managing listening ports."""

    CSS = """
    Screen { background: $surface; }
    #main-container { height: 100%; }
    #top-bar { height: 1; background: $boost; }
    #timestamp { width: 1fr; }
    #filter-label { width: auto; padding: 0 1; }
    #filter-input { width: 30; border: none; background: $surface; padding: 0; }
    #filter-input:focus { border: none; background: $surface-lighten-1; }
    DataTable { height: 1fr; }
    DataTable > .datatable--cursor { background: $accent; color: $text; }
    #message-bar { height: 1; background: $boost; }
    #confirm-dialog { width: 50; height: 12; padding: 1 2; background: $surface; border: tall $primary; }
    #confirm-title { text-align: center; text-style: bold; width: 100%; padding-bottom: 1; }
    #confirm-details { padding: 1; background: $boost; margin-bottom: 1; }
    #confirm-buttons { width: 100%; height: 3; align: center middle; }
    #confirm-buttons Button { margin: 0 1; }
    """

    BINDINGS = [
        Binding("q", "quit", "Quit"),
        Binding("r", "refresh", "Refresh"),
        Binding("k", "kill", "Kill"),
        Binding("enter", "kill", "Kill", show=False),
        Binding("delete", "kill", "Kill", show=False),
        Binding("/", "focus_filter", "Filter"),
        Binding("escape", "clear_filter", "Clear", show=False),
    ]

    def __init__(self) -> None:
        super().__init__()
        self.all_ports: list[dict] = []
        self.filtered_ports: list[dict] = []
        self.current_filter = ""

    def compose(self) -> ComposeResult:
        with Vertical(id="main-container"):
            with Horizontal(id="top-bar"):
                yield Label("", id="timestamp")
                yield Label("/", id="filter-label")
                yield Input(placeholder="filter...", id="filter-input")
            yield DataTable(id="port-table")
            yield Static("", id="message-bar")
        yield Footer()

    def on_mount(self) -> None:
        table = self.query_one("#port-table", DataTable)
        table.cursor_type = "row"
        table.zebra_stripes = True
        table.add_column("Protocol", width=10)
        table.add_column("Address", width=20)
        table.add_column("Port", width=10)
        table.add_column("PID", width=10)
        table.add_column("Process", width=30)
        self.load_ports()

    def load_ports(self) -> None:
        self.all_ports = get_listening_ports()
        self.apply_filter()

    def apply_filter(self) -> None:
        table = self.query_one("#port-table", DataTable)
        table.clear()

        filter_text = self.current_filter.lower().strip()

        if filter_text:
            self.filtered_ports = [
                p for p in self.all_ports
                if filter_text in str(p["port"])
                or filter_text in p["process"].lower()
                or filter_text in p["address"].lower()
                or filter_text in p["protocol"].lower()
            ]
        else:
            self.filtered_ports = self.all_ports.copy()

        for idx, port_info in enumerate(self.filtered_ports):
            table.add_row(
                port_info["protocol"],
                port_info["address"],
                str(port_info["port"]),
                str(port_info["pid"]),
                port_info["process"],
                key=str(idx),
            )

        timestamp = self.query_one("#timestamp", Label)
        now = datetime.now().strftime("%H:%M:%S")
        if filter_text:
            timestamp.update(f" [{now}] {len(self.filtered_ports)}/{len(self.all_ports)} ports")
        else:
            timestamp.update(f" [{now}] {len(self.all_ports)} ports")

        if not filter_text:
            self.show_message(f"Loaded {len(self.all_ports)} ports", "success")

    @on(Input.Changed, "#filter-input")
    def on_filter_changed(self, event: Input.Changed) -> None:
        self.current_filter = event.value
        self.apply_filter()

    def action_focus_filter(self) -> None:
        self.query_one("#filter-input", Input).focus()

    def action_clear_filter(self) -> None:
        filter_input = self.query_one("#filter-input", Input)
        filter_input.value = ""
        self.current_filter = ""
        self.apply_filter()
        self.query_one("#port-table", DataTable).focus()

    def show_message(self, message: str, msg_class: str = "") -> None:
        msg_bar = self.query_one("#message-bar", Static)
        if msg_class == "success":
            msg_bar.update(f" [green]{message}[/green]")
        elif msg_class == "error":
            msg_bar.update(f" [red]{message}[/red]")
        else:
            msg_bar.update(f" {message}")

    def action_refresh(self) -> None:
        self.load_ports()

    def action_kill(self) -> None:
        table = self.query_one("#port-table", DataTable)

        if table.row_count == 0:
            self.show_message("No ports to select", "error")
            return

        if self.query_one("#filter-input", Input).has_focus:
            return

        row_key, _ = table.coordinate_to_cell_key(table.cursor_coordinate)
        row_data = table.get_row(row_key)

        pid = int(row_data[3])
        process_name = row_data[4]
        port = int(row_data[2])

        if pid == 0:
            self.show_message("Cannot kill process with PID 0", "error")
            return

        self.push_screen(
            ConfirmKillScreen(pid, process_name, port),
            lambda result: self.kill_process(pid, process_name, port) if result else None,
        )

    def kill_process(self, pid: int, process_name: str, port: int) -> None:
        try:
            proc = psutil.Process(pid)
            proc.terminate()
            try:
                proc.wait(timeout=2)
            except psutil.TimeoutExpired:
                proc.kill()
            self.show_message(f"Killed {process_name} (PID: {pid}, Port: {port})", "success")
            self.load_ports()
        except psutil.NoSuchProcess:
            self.show_message(f"Process {pid} no longer exists", "error")
            self.load_ports()
        except psutil.AccessDenied:
            self.show_message(f"Access denied - run as administrator", "error")
        except Exception as e:
            self.show_message(f"Error: {e}", "error")


def main() -> None:
    WinPortsApp().run()


if __name__ == "__main__":
    main()
