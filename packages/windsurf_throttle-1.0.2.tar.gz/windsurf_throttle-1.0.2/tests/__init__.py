"""Tests for windsurf-throttle."""
