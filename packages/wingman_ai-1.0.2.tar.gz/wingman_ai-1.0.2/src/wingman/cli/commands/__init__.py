"""CLI commands for Wingman."""
