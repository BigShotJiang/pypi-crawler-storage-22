"""Console slash commands."""
