# WINZTOOL - Herramientas Útiles de Windows

Biblioteca de Python con funciones útiles de Windows implementadas en C++ usando pybind11.

## 🚀 Instalación

```bash
python setup.py build
python setup.py install
```

## 📋 Funciones Disponibles

### Sistema
- `obtener_sistema()` - Información del procesador y arquitectura
- `obtener_memoria()` - Información de memoria RAM
- `obtener_espacio_disco(unidad)` - Espacio en disco (ej: "C:\\")
- `obtener_version_windows()` - Versión de Windows
- `obtener_resolucion_pantalla()` - Resolución de pantalla

### Usuario
- `obtener_nombre_usuario()` - Nombre del usuario actual
- `obtener_nombre_equipo()` - Nombre del equipo

### Consola
- `limpiar_consola()` - Limpiar pantalla
- `titulo_consola(titulo)` - Cambiar título de consola
- `cambiar_color_consola(color)` - Cambiar color del texto
  - Colores: 1=Azul, 2=Verde, 4=Rojo, 6=Amarillo, 7=Blanco, 10=Verde brillante, etc.
- `mostrar_consola(bool)` - Mostrar/ocultar ventana de consola
- `establecer_posicion_cursor(x, y)` - Posicionar cursor en consola
- `obtener_tecla()` - Leer tecla sin esperar Enter

### Portapapeles
- `copiar_al_portapapeles(texto)` - Copiar texto
- `obtener_del_portapapeles()` - Obtener texto del portapapeles

### Archivos y Directorios
- `obtener_directorio_actual()` - Directorio de trabajo
- `cambiar_directorio(path)` - Cambiar directorio
- `crear_directorio(path)` - Crear directorio
- `eliminar_archivo(filename)` - Eliminar archivo
- `archivo_existe(filename)` - Verificar si existe
- `abrir_archivo(filepath)` - Abrir con app predeterminada

### Procesos
- `iniciar_proceso(nombre)` - Iniciar proceso
- `fin_proceso(nombre)` - Terminar proceso
- `listar_procesos()` - Lista de procesos activos

### Sistema de Energía
- `apagar_sistema(segundos)` - Apagar en X segundos
- `reiniciar_sistema(segundos)` - Reiniciar en X segundos
- `cancelar_apagado()` - Cancelar apagado programado
- `suspender_sistema()` - Suspender equipo

### Utilidades
- `beep_sistema(frecuencia, duracion)` - Emitir sonido
- `mostrar_mensaje(mensaje, titulo, tipo)` - Cuadro de diálogo
  - tipo: 0=OK, 1=OK/Cancel, 2=Yes/No
- `abrir_url(url)` - Abrir en navegador
- `ejecutar_comando(cmd)` - Ejecutar comando y obtener salida
- `vaciar_papelera()` - Vaciar papelera de reciclaje
- `bloquear_entrada(bool)` - Bloquear teclado/mouse (¡usar con cuidado!)

## 💡 Ejemplos de Uso

### Ejemplo Básico
```python
import WINZTOOL as wt

# Información del sistema
wt.obtener_sistema()
wt.obtener_memoria()

# Usuario
print(f"Usuario: {wt.obtener_nombre_usuario()}")
print(f"Equipo: {wt.obtener_nombre_equipo()}")

# Consola
wt.titulo_consola("Mi Aplicación")
wt.cambiar_color_consola(10)  # Verde brillante
print("¡Texto en color!")
```

### Portapapeles
```python
import WINZTOOL as wt

# Copiar
wt.copiar_al_portapapeles("Hola Mundo")

# Pegar
texto = wt.obtener_del_portapapeles()
print(texto)
```

### Gestión de Archivos
```python
import WINZTOOL as wt

# Verificar si existe
if wt.archivo_existe("archivo.txt"):
    print("El archivo existe")
    
# Crear directorio
wt.crear_directorio("mi_carpeta")

# Cambiar directorio
wt.cambiar_directorio("C:\\Users")
print(wt.obtener_directorio_actual())
```

### Procesos
```python
import WINZTOOL as wt

# Listar procesos
procesos = wt.listar_procesos()
for p in procesos[:10]:
    print(p)

# Abrir aplicación
wt.iniciar_proceso("notepad.exe")

# Cerrar proceso
wt.fin_proceso("notepad.exe")
```

### Cuadros de Diálogo
```python
import WINZTOOL as wt

# Mensaje simple
wt.mostrar_mensaje("Operación completada", "Éxito", 0)

# Pregunta Yes/No
respuesta = wt.mostrar_mensaje("¿Continuar?", "Confirmar", 2)
if respuesta == 6:  # IDYES
    print("Usuario dijo Sí")
```

### Ejecutar Comandos
```python
import WINZTOOL as wt

# Obtener IP
resultado = wt.ejecutar_comando("ipconfig")
print(resultado)

# Listar archivos
archivos = wt.ejecutar_comando("dir")
print(archivos)
```

### Sonidos y Efectos
```python
import WINZTOOL as wt

# Sonido simple
wt.beep_sistema(1000, 500)  # 1000Hz por 500ms

# Melodía
for freq in [262, 294, 330, 349, 392, 440, 494, 523]:
    wt.beep_sistema(freq, 200)
```

### Utilidades Web
```python
import WINZTOOL as wt

# Abrir página web
wt.abrir_url("https://www.google.com")

# Abrir archivo local
wt.abrir_archivo("C:\\Users\\documento.pdf")
```

## 🎯 Programa de Ejemplo Completo

Ejecuta `ejemplo_winztool.py` para ver un menú interactivo con todas las funciones:

```bash
python ejemplo_winztool.py
```

## ⚠️ Advertencias

- **bloquear_entrada()**: Usar con extremo cuidado. Si bloqueas la entrada, necesitarás otra forma de desbloquearla.
- **apagar_sistema()** y **reiniciar_sistema()**: Guardar trabajo antes de usar.
- **vaciar_papelera()**: No se puede deshacer.
- Algunas funciones requieren permisos de administrador.

## 🔧 Requisitos

- Windows 7 o superior
- Python 3.6+
- pybind11
- Visual Studio Build Tools (para compilar)

## 📝 Licencia

Uso libre para proyectos personales y educativos.
