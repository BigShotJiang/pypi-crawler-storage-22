#include <iostream>
#include <windows.h>
#include <pybind11/pybind11.h>
#include <pybind11/stl.h>
#include <string>
#include <vector>
#include <tlhelp32.h>
#include <psapi.h>
#include <PowrProf.h>
#include <shlobj.h>
#include <conio.h>

namespace py = pybind11;
using namespace std;

void cambiar_color_consola(int color) {
    SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), color);
}

void obtener_sistema() {
    SYSTEM_INFO si;
    GetSystemInfo(&si);
    std::cout << "Procesadores: " << si.dwNumberOfProcessors << std::endl;
    std::cout << "Arquitectura: " << si.wProcessorArchitecture << std::endl;  
}

void limpiar_consola() {
    system("cls");
}

void titulo_consola(const char* titulo) {
    SetConsoleTitle(titulo);
}

void iniciar_proceso(char * nombre_proceso) {
    STARTUPINFO si;
    PROCESS_INFORMATION pi;

    ZeroMemory(&si, sizeof(si));
    si.cb = sizeof(si);
    ZeroMemory(&pi, sizeof(pi));

    if (!CreateProcess(NULL,   // No module name (use command line)
        nombre_proceso,        // Command line
        NULL,                  // Process handle not inheritable
        NULL,                  // Thread handle not inheritable
        FALSE,                 // Set handle inheritance to FALSE
        0,                     // No creation flags
        NULL,                  // Use parent's environment block
        NULL,                  // Use parent's starting directory 
        &si,                   // Pointer to STARTUPINFO structure
        &pi)                   // Pointer to PROCESS_INFORMATION structure
        ) 
    {
        std::cerr << "Proceso fallido (" << GetLastError() << ").\n";
        return;
    }

    WaitForSingleObject(pi.hProcess, INFINITE);

    CloseHandle(pi.hProcess);
    CloseHandle(pi.hThread);

}

void fin_proceso(char * nombre_proceso) {
    string comando = "taskkill /IM ";
    comando += nombre_proceso;
    comando += " /F";
    system(comando.c_str());
}

// ===== NUEVAS FUNCIONES =====

// Información de memoria
void obtener_memoria() {
    MEMORYSTATUSEX statex;
    statex.dwLength = sizeof(statex);
    GlobalMemoryStatusEx(&statex);
    
    cout << "Memoria total: " << statex.ullTotalPhys / (1024*1024) << " MB" << endl;
    cout << "Memoria disponible: " << statex.ullAvailPhys / (1024*1024) << " MB" << endl;
    cout << "Uso de memoria: " << statex.dwMemoryLoad << "%" << endl;
    cout << "Memoria virtual total: " << statex.ullTotalVirtual / (1024*1024) << " MB" << endl;
}

// Información de disco
void obtener_espacio_disco(const char* unidad) {
    DWORD sectorsPerCluster, bytesPerSector, freeClusters, totalClusters;
    if (GetDiskFreeSpace(unidad, &sectorsPerCluster, &bytesPerSector, &freeClusters, &totalClusters)) {
        unsigned long long totalBytes = (unsigned long long)totalClusters * sectorsPerCluster * bytesPerSector;
        unsigned long long freeBytes = (unsigned long long)freeClusters * sectorsPerCluster * bytesPerSector;
        
        cout << "Disco " << unidad << endl;
        cout << "Espacio total: " << totalBytes / (1024*1024*1024) << " GB" << endl;
        cout << "Espacio libre: " << freeBytes / (1024*1024*1024) << " GB" << endl;
    } else {
        cerr << "Error al obtener información del disco" << endl;
    }
}

// Emitir sonido del sistema
void beep_sistema(int frecuencia, int duracion) {
    Beep(frecuencia, duracion);
}

// Obtener nombre de usuario
string obtener_nombre_usuario() {
    char username[256];
    DWORD size = sizeof(username);
    if (GetUserName(username, &size)) {
        return string(username);
    }
    return "Desconocido";
}

// Obtener nombre del equipo
string obtener_nombre_equipo() {
    char computerName[256];
    DWORD size = sizeof(computerName);
    if (GetComputerName(computerName, &size)) {
        return string(computerName);
    }
    return "Desconocido";
}

// Copiar texto al portapapeles
void copiar_al_portapapeles(const char* texto) {
    if (OpenClipboard(NULL)) {
        EmptyClipboard();
        size_t len = strlen(texto) + 1;
        HGLOBAL hMem = GlobalAlloc(GMEM_MOVEABLE, len);
        if (hMem) {
            memcpy(GlobalLock(hMem), texto, len);
            GlobalUnlock(hMem);
            SetClipboardData(CF_TEXT, hMem);
        }
        CloseClipboard();
    }
}

// Obtener texto del portapapeles
string obtener_del_portapapeles() {
    string result = "";
    if (OpenClipboard(NULL)) {
        HANDLE hData = GetClipboardData(CF_TEXT);
        if (hData) {
            char* pszText = static_cast<char*>(GlobalLock(hData));
            if (pszText) {
                result = string(pszText);
            }
            GlobalUnlock(hData);
        }
        CloseClipboard();
    }
    return result;
}

// Obtener directorio actual
string obtener_directorio_actual() {
    char buffer[MAX_PATH];
    GetCurrentDirectory(MAX_PATH, buffer);
    return string(buffer);
}

// Cambiar directorio
bool cambiar_directorio(const char* path) {
    return SetCurrentDirectory(path);
}

// Crear directorio
bool crear_directorio(const char* path) {
    return CreateDirectory(path, NULL);
}

// Eliminar archivo
bool eliminar_archivo(const char* filename) {
    return DeleteFile(filename);
}

// Verificar si un archivo existe
bool archivo_existe(const char* filename) {
    DWORD attrib = GetFileAttributes(filename);
    return (attrib != INVALID_FILE_ATTRIBUTES && !(attrib & FILE_ATTRIBUTE_DIRECTORY));
}

// Listar procesos en ejecución
vector<string> listar_procesos() {
    vector<string> procesos;
    HANDLE hSnapshot = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0);
    
    if (hSnapshot != INVALID_HANDLE_VALUE) {
        PROCESSENTRY32 pe32;
        pe32.dwSize = sizeof(PROCESSENTRY32);
        
        if (Process32First(hSnapshot, &pe32)) {
            do {
                procesos.push_back(string(pe32.szExeFile));
            } while (Process32Next(hSnapshot, &pe32));
        }
        CloseHandle(hSnapshot);
    }
    return procesos;
}

// Mostrar/Ocultar ventana de consola
void mostrar_consola(bool mostrar) {
    HWND console = GetConsoleWindow();
    ShowWindow(console, mostrar ? SW_SHOW : SW_HIDE);
}

// Mensaje de alerta
int mostrar_mensaje(const char* mensaje, const char* titulo, int tipo) {
    // tipo: 0 = OK, 1 = OK/Cancel, 2 = Yes/No
    UINT uType = MB_OK;
    if (tipo == 1) uType = MB_OKCANCEL;
    else if (tipo == 2) uType = MB_YESNO;
    
    return MessageBox(NULL, mensaje, titulo, uType | MB_ICONINFORMATION);
}

// Suspender el sistema
void suspender_sistema() {
    SetSuspendState(FALSE, FALSE, FALSE);
}

// Apagar el sistema
void apagar_sistema(int segundos) {
    string comando = "shutdown /s /t " + to_string(segundos);
    system(comando.c_str());
}

// Reiniciar el sistema
void reiniciar_sistema(int segundos) {
    string comando = "shutdown /r /t " + to_string(segundos);
    system(comando.c_str());
}

// Cancelar apagado/reinicio
void cancelar_apagado() {
    system("shutdown /a");
}

// Obtener versión de Windows
string obtener_version_windows() {
    OSVERSIONINFOEX osvi;
    ZeroMemory(&osvi, sizeof(OSVERSIONINFOEX));
    osvi.dwOSVersionInfoSize = sizeof(OSVERSIONINFOEX);
    
    #pragma warning(disable : 4996)
    GetVersionEx((OSVERSIONINFO*)&osvi);
    #pragma warning(default : 4996)
    
    string version = "Windows " + to_string(osvi.dwMajorVersion) + "." + to_string(osvi.dwMinorVersion);
    return version;
}

// Abrir URL en navegador predeterminado
void abrir_url(const char* url) {
    ShellExecute(NULL, "open", url, NULL, NULL, SW_SHOWNORMAL);
}

// Abrir archivo con aplicación predeterminada
void abrir_archivo(const char* filepath) {
    ShellExecute(NULL, "open", filepath, NULL, NULL, SW_SHOWNORMAL);
}

// Obtener resolución de pantalla
void obtener_resolucion_pantalla() {
    int ancho = GetSystemMetrics(SM_CXSCREEN);
    int alto = GetSystemMetrics(SM_CYSCREEN);
    cout << "Resolución: " << ancho << "x" << alto << endl;
}

// Bloquear entrada de mouse y teclado
void bloquear_entrada(bool bloquear) {
    BlockInput(bloquear);
}

// Ejecutar comando y obtener salida
string ejecutar_comando(const char* comando) {
    string result = "";
    FILE* pipe = _popen(comando, "r");
    if (pipe) {
        char buffer[128];
        while (fgets(buffer, sizeof(buffer), pipe) != NULL) {
            result += buffer;
        }
        _pclose(pipe);
    }
    return result;
}

// Vaciar papelera de reciclaje
void vaciar_papelera() {
    SHEmptyRecycleBin(NULL, NULL, SHERB_NOCONFIRMATION | SHERB_NOPROGRESSUI | SHERB_NOSOUND);
}

// Establecer posición del cursor
void establecer_posicion_cursor(int x, int y) {
    COORD coord;
    coord.X = x;
    coord.Y = y;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
}

// Obtener tecla presionada (sin esperar Enter)
int obtener_tecla() {
    if (_kbhit()) {
        return _getch();
    }
    return -1;
}

PYBIND11_MODULE(winzitool, m) {
    m.doc() = "WINZEAPI - Herramientas útiles de Windows";
    
    // Funciones originales
    m.def("cambiar_color_consola", &cambiar_color_consola, "Cambiar el color del texto de la consola");
    m.def("obtener_sistema", &obtener_sistema, "Obtener información del sistema");
    m.def("limpiar_consola", &limpiar_consola, "Limpiar la pantalla de la consola");
    m.def("titulo_consola", &titulo_consola, "Establecer el título de la consola");
    m.def("iniciar_proceso", &iniciar_proceso, "Iniciar un proceso");
    m.def("fin_proceso", &fin_proceso, "Terminar un proceso");
    
    // Funciones nuevas
    m.def("obtener_memoria", &obtener_memoria, "Obtener información de memoria RAM");
    m.def("obtener_espacio_disco", &obtener_espacio_disco, "Obtener información de espacio en disco");
    m.def("beep_sistema", &beep_sistema, "Emitir un sonido del sistema");
    m.def("obtener_nombre_usuario", &obtener_nombre_usuario, "Obtener nombre del usuario actual");
    m.def("obtener_nombre_equipo", &obtener_nombre_equipo, "Obtener nombre del equipo");
    m.def("copiar_al_portapapeles", &copiar_al_portapapeles, "Copiar texto al portapapeles");
    m.def("obtener_del_portapapeles", &obtener_del_portapapeles, "Obtener texto del portapapeles");
    m.def("obtener_directorio_actual", &obtener_directorio_actual, "Obtener directorio de trabajo actual");
    m.def("cambiar_directorio", &cambiar_directorio, "Cambiar directorio de trabajo");
    m.def("crear_directorio", &crear_directorio, "Crear un nuevo directorio");
    m.def("eliminar_archivo", &eliminar_archivo, "Eliminar un archivo");
    m.def("archivo_existe", &archivo_existe, "Verificar si un archivo existe");
    m.def("listar_procesos", &listar_procesos, "Listar todos los procesos en ejecución");
    m.def("mostrar_consola", &mostrar_consola, "Mostrar u ocultar la ventana de consola");
    m.def("mostrar_mensaje", &mostrar_mensaje, "Mostrar un cuadro de mensaje");
    m.def("suspender_sistema", &suspender_sistema, "Suspender el sistema");
    m.def("apagar_sistema", &apagar_sistema, "Apagar el sistema");
    m.def("reiniciar_sistema", &reiniciar_sistema, "Reiniciar el sistema");
    m.def("cancelar_apagado", &cancelar_apagado, "Cancelar apagado o reinicio programado");
    m.def("obtener_version_windows", &obtener_version_windows, "Obtener versión de Windows");
    m.def("abrir_url", &abrir_url, "Abrir URL en navegador predeterminado");
    m.def("abrir_archivo", &abrir_archivo, "Abrir archivo con aplicación predeterminada");
    m.def("obtener_resolucion_pantalla", &obtener_resolucion_pantalla, "Obtener resolución de pantalla");
    m.def("bloquear_entrada", &bloquear_entrada, "Bloquear/desbloquear entrada de mouse y teclado");
    m.def("ejecutar_comando", &ejecutar_comando, "Ejecutar comando y obtener salida");
    m.def("vaciar_papelera", &vaciar_papelera, "Vaciar la papelera de reciclaje");
    m.def("establecer_posicion_cursor", &establecer_posicion_cursor, "Establecer posición del cursor en consola");
    m.def("obtener_tecla", &obtener_tecla, "Obtener tecla presionada sin esperar Enter");
}