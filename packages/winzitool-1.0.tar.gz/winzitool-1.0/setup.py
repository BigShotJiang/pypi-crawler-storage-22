from setuptools import setup, Extension
import pybind11
import sysconfig

python_include = sysconfig.get_paths()["include"]

module = Extension(
    "winzitool",
    sources=["WINZTOOL.cpp"],
    include_dirs=[
        pybind11.get_include(),
        python_include
    ],
    language="c++",
    extra_compile_args=["/std:c++20"],
    libraries=["user32", "kernel32", "shell32", "psapi", "PowrProf", "advapi32"],
)

setup(
    name="winzitool",
    version="1.0",
    ext_modules=[module]
)