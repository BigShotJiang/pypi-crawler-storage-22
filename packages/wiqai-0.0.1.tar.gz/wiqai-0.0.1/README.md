<p align="center">
  <img src="docs/assets/wiqai-logo.svg" alt="Wiqai" width="200" />
</p>

<h1 align="center">Wiqai</h1>

<p align="center">
  <strong>Open-source security middleware for AI agents</strong><br/>
  <em>وِقاية — Prevention. Protection. The shell way.</em>
</p>

<p align="center">
  <a href="https://pypi.org/project/wiqai/"><img src="https://img.shields.io/pypi/v/wiqai?color=blue&label=PyPI" alt="PyPI"></a>
  <a href="https://github.com/wiqai/wiqai/blob/main/LICENSE"><img src="https://img.shields.io/badge/License-Apache_2.0-green.svg" alt="License"></a>
  <a href="https://github.com/wiqai/wiqai/stargazers"><img src="https://img.shields.io/github/stars/wiqai/wiqai?style=social" alt="Stars"></a>
  <a href="https://discord.gg/wiqai"><img src="https://img.shields.io/discord/0?label=Discord&logo=discord&color=7289DA" alt="Discord"></a>
  <a href="https://github.com/sponsors/wiqai"><img src="https://img.shields.io/badge/Sponsor-%E2%9D%A4-pink" alt="Sponsor"></a>
</p>

---

**Wiqai** (وِقاية — "prevention/protection" in Arabic) is an open-source security middleware that scans, audits, and protects AI agents and MCP tools in real-time.

> Think of it as the **OWASP ZAP for the agentic era** — but designed as a lightweight SDK that integrates in 3 lines of code.

## Why Wiqai?

AI agents are powerful. They can execute code, browse the web, access your files, call APIs. But **who watches the watchers?**

- Cisco found that **26% of MCP skills** contain at least one security vulnerability
- Prompt injection attacks can silently exfiltrate data through hidden `curl` commands
- No unified tool exists to scan, audit, AND evaluate agent security

Wiqai fills this gap.

## Quick Start

```bash
pip install wiqai
```

```python
from wiqai import Shield

shield = Shield()

# Scan MCP tools for vulnerabilities
results = shield.scan("./mcp-skills/")
print(results.summary())

# Protect an agent at runtime
@shield.protect
async def my_agent(prompt: str):
    return await llm.generate(prompt)

# Audit agent behavior
audit = shield.audit(agent_logs="./logs/")
audit.report()
```

```bash
# CLI usage
wiqai scan --target ./skills/
wiqai audit --logs ./agent-logs/
wiqai eval --agent ./my_agent.py
```

## Features

| Module | Description | Status |
|--------|-------------|--------|
| **MCP Proxy** | Intercepts and scans every MCP tool call | Planned |
| **Prompt Firewall** | 4-layer injection detection (regex, classifier, semantic, LLM judge) | Planned |
| **Behavioral Audit** | Traces agent actions, detects anomalies | Planned |
| **Eval Engine** | Quality + safety scoring for agent outputs | Planned |
| **Compliance Reporter** | OWASP, RGPD, CNDP compliance reports | Planned |

## Architecture

```
[Your Agent]  ←  AutoGPT / OpenClaw / CrewAI / LangGraph / Custom
      ↓
[Wiqai SDK]   ←  pip install wiqai
      ├── MCP Proxy         → scans every tool call
      ├── Prompt Firewall   → blocks injections
      ├── Behavioral Audit  → traces + anomaly detection
      ├── Eval Engine       → quality + safety scoring
      └── Compliance Report → OWASP / RGPD / CNDP
      ↓
[Dashboard / API / Webhooks]
```

## Integrations

Wiqai is designed to work with any agent framework:

- **MCP Protocol** — Native support, intercept any MCP server
- **LangChain / LangGraph** — Middleware integration
- **CrewAI** — Agent-level protection
- **AutoGPT** — Plugin scanning
- **OpenClaw** — Skill security analysis
- **Custom agents** — Simple decorator API

## Sponsorship

Wiqai is 100% open-source and community-funded. We rely on sponsors to keep the project alive and independent.

<p align="center">
  <a href="https://github.com/sponsors/wiqai">
    <img src="https://img.shields.io/badge/%E2%9D%A4%EF%B8%8F_Sponsor_Wiqai-pink?style=for-the-badge" alt="Sponsor Wiqai" />
  </a>
</p>

| Tier | Amount | Perks |
|------|--------|-------|
| Hatchling | $5/mo | Name in SPONSORS.md + Discord role |
| Shell | $25/mo | Logo on README + priority issues |
| Carapace | $100/mo | Logo on website + monthly call |
| Fortress | $500+/mo | Custom integration support + advisory |

### Grants & Funding

We actively pursue grants to ensure long-term sustainability:
- NLnet Foundation (NGI Zero)
- Mozilla MOSS
- EU Sovereign Tech Fund
- Open Technology Fund

## Contributing

We welcome contributions! See [CONTRIBUTING.md](CONTRIBUTING.md) for guidelines.

```bash
git clone https://github.com/wiqai/wiqai.git
cd wiqai
pip install -e ".[dev]"
pytest
```

## Community

- [Discord](https://discord.gg/wiqai) — Chat with the team
- [GitHub Discussions](https://github.com/wiqai/wiqai/discussions) — Ideas & questions
- [Twitter/X](https://twitter.com/wiqai) — Updates

## License

Apache 2.0 — See [LICENSE](LICENSE) for details.

---

<p align="center">
  <strong>Built with care by <a href="https://2pidata.com">2PiData</a></strong><br/>
  <em>Securing the agentic era, one shell at a time.</em>
</p>
