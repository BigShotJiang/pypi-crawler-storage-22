"""Basic tests for Wiqai package."""


def test_version():
    from wiqai import __version__

    assert __version__ == "0.0.1"


def test_import():
    import wiqai

    assert wiqai.__author__ == "Miloud Belarebia"
    assert wiqai.__license__ == "Apache-2.0"
