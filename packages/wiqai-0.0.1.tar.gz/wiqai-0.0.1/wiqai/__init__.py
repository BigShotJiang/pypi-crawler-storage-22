"""
Wiqai - Open-source security middleware for AI agents.

Scan, audit, and protect your AI agents and MCP tools.
The shell way.
"""

__version__ = "0.0.1"
__author__ = "Miloud Belarebia"
__license__ = "Apache-2.0"
