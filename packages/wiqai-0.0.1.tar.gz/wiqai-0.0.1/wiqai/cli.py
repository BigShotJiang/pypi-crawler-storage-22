"""Wiqai CLI - Security middleware for AI agents."""


def main():
    print("Wiqai v0.0.1 - Coming soon.")
    print("Open-source security middleware for AI agents.")
    print("https://wiqai.dev")


if __name__ == "__main__":
    main()
