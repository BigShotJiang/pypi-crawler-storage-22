from django.apps import AppConfig


class App2(AppConfig):
    name = "app_2"
