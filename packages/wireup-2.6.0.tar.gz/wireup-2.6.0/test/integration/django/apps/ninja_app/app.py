from django.apps import AppConfig


class NinjaApp(AppConfig):
    name = "ninja_app"
