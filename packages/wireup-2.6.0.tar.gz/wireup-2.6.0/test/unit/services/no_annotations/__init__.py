class FooRepository:
    pass
