
from wireup import Injected
import time
import wireup
from typing import Annotated
from wireup import service as injectable, create_sync_container, inject_from_container, Inject

class G:
    pass

class F:
    def __init__(self, g: G):
        self.g = g

class E:
    def __init__(self, f: F):
        self.f = f

class D:
    def __init__(self, e: E):
        self.e = e

class C:
    def __init__(self, d: D):
        self.d = d

class B:
    def __init__(self, c: C):
        self.c = c

class A:
    def __init__(self, b: B):
        self.b = b

def run_bench():
    classes = [G, F, E, D, C, B, A]

    # Test 1: Singleton (Cached)
    print("Benchmarking SINGLETON resolution (Cached)...")
    container = create_sync_container(services=[injectable(c) for c in classes])
    
    # Warmup
    container.get(A)

    start = time.time()
    iterations = 200_000
    for _ in range(iterations):
        container.get(A)
    
    end = time.time()
    print(f"Time for {iterations} singleton hits: {end - start:.4f}s")
    print(f"Ops/sec: {iterations / (end - start):.2f}")

    # Test 2: Singleton (Cached) - Function Injection
    print("\nBenchmarking SINGLETON resolution (Cached) - Function Injection...")
    
    @inject_from_container(container)
    def func_singleton(a: Injected[A]):
        pass

    # Warmup
    func_singleton()

    start = time.time()
    for _ in range(iterations):
        func_singleton()
    
    end = time.time()
    print(f"Time for {iterations} singleton function injections: {end - start:.4f}s")
    print(f"Ops/sec: {iterations / (end - start):.2f}")

    # Test 3: Scoped (Full Graph)
    print("\nBenchmarking SCOPED resolution (Full Graph Creation)...")
    container_scoped = create_sync_container(services=[injectable(c, lifetime="scoped") for c in classes])

    start = time.time()
    iterations_scope = 20_000
    for _ in range(iterations_scope):
        with container_scoped.enter_scope() as scope:
            scope.get(A)
    
    end = time.time()
    print(f"Time for {iterations_scope} scoped resolutions: {end - start:.4f}s")
    print(f"Ops/sec: {iterations_scope / (end - start):.2f}")


    # Test 4: Scoped (Full Graph) - Function Injection
    print("\nBenchmarking SCOPED resolution (Full Graph) - Function Injection...")

    @inject_from_container(container_scoped)
    def func_scoped(a: Injected[A]):
        pass

    start = time.time()
    for _ in range(iterations_scope):
        func_scoped()
    
    end = time.time()
    print(f"Time for {iterations_scope} scoped function injections: {end - start:.4f}s")
    print(f"Ops/sec: {iterations_scope / (end - start):.2f}")

if __name__ == "__main__":
    run_bench()
