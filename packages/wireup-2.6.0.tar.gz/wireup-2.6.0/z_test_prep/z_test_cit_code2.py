"""
Stock prices, list of entries.
You're given a list, each list has transaction object
Following fields: trader name, company name, price bought or sold stock, sperate string, buy or sell, quantity.
calculate total profit for each trader.
"""

from collections import defaultdict
from dataclasses import dataclass
from typing import Literal


@dataclass
class Transaction:
    trader: str
    company: str
    price: float
    side: Literal["buy", "sell"]
    qty: int


def compute_trader_profit(transactions: list[Transaction]) -> dict[str, float]:
    trades: dict[str, dict[str, float]] = defaultdict(lambda: defaultdict(float))

    for txn in transactions:
        balance_delta = txn.price if txn.side == "sell" else -txn.price
        trades[txn.trader][txn.company] += balance_delta * txn.qty

    return {trader: sum(txns_by_company.values()) for trader, txns_by_company in trades.items()}


print(
    compute_trader_profit(
        [
            Transaction(trader="aldo", company="AAPL", price=220, side="buy", qty=1),
            Transaction(trader="alda", company="AAPL", price=220, side="buy", qty=1),
            Transaction(trader="alda", company="AAPL", price=220, side="sell", qty=1),
            Transaction(trader="aldo", company="AAPL", price=200, side="buy", qty=5),
            Transaction(trader="aldo", company="AAPL", price=250, side="sell", qty=6),
        ]
    )
)
