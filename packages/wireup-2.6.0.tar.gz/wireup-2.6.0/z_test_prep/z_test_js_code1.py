"""
Given code with curly brace marked blocks, identify the blocks as a dict for start line to end line
"""

example = """
int main() {
    for (;;) {
        for (;;) {
            return 0;
        }
    }

    int i = 0;
    for (;;) {
        i++;
    }

}

"""


def get_code_block_lines(source: str) -> dict[int, int]:
    positions: list[int] = []
    res: dict[int, int] = {}

    for line_no, line in enumerate(source.split("\n")):
        if "{" in line:
            positions.append(line_no)

        if "}" in line:
            res[positions.pop()] = line_no

    return res


class CollapsibleSource:
    def __init__(self, source: str) -> None:
        self.source = source
        self.src_lines = source.split("\n")
        self.block_map = get_code_block_lines(source)
        self.collapsed_lines = []

    def collapse(self, start: int) -> None:
        if start not in self.block_map:
            raise Exception
        self.collapse_start = start

    def __str__(self) -> str:
        if not self.collapse_start:
            return self.source

        collapse_end = self.block_map[self.collapse_start]

        lines: list[str] = []
        for line_no, line in enumerate(self.src_lines):
            if line_no == self.collapse_start:
                lines.append(f"{line} ... }}")
                continue

            if line_no < self.collapse_start or line_no > collapse_end:
                lines.append(line)

        return "\n".join(lines)


print(get_code_block_lines(example))

src = CollapsibleSource(example)
src.collapse(9)

print(src)
