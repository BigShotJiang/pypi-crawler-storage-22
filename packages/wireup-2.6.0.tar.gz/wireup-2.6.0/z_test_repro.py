import asyncio

import wireup


class FooDep:
    def print(self):
        print("Foo")


@wireup.injectable
async def async_foo_dep() -> FooDep:
    return FooDep()


@wireup.injectable
class BarDep:
    def __init__(self, foo: FooDep):
        self.foo = foo

    def do(self):
        self.foo.print()


class FooOverride:
    def print(self):
        print("FooOverride")


async def main() -> None:
    container = wireup.create_async_container(injectables=[async_foo_dep, BarDep])

    with container.override.injectable(FooDep, FooOverride()):
        bar = await container.get(BarDep)
        bar.do()


if __name__ == "__main__":
    asyncio.run(main())
