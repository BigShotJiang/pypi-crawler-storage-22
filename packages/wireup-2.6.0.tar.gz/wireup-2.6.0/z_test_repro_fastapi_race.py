import asyncio
import uuid
from typing import Annotated, Dict

import uvicorn
from fastapi import Depends, FastAPI, Request
from httpx import AsyncClient

app = FastAPI()

# --- Settings ---
NUM_SINGLETON_REQUESTS = 100
NUM_SCOPED_REQUESTS = 100

class Service:
    def __init__(self, name: str):
        self.name = name
        self.id = uuid.uuid4()

# --- Counters ---
singleton_calls = 0
scoped_calls = 0

# --- Singleton Race Condition Reproduction ---

async def get_singleton(request: Request) -> Service:
    """Lazy singleton on app.state without locking."""
    global singleton_calls
    singleton_calls += 1
    
    if not hasattr(request.app.state, "singleton_instance"):
        # Increase the race window
        await asyncio.sleep(0.1)
        request.app.state.singleton_instance = Service("singleton")
    return request.app.state.singleton_instance

@app.get("/singleton")
async def singleton_endpoint(service: Annotated[Service, Depends(get_singleton)]):
    return {"id": str(service.id)}

# --- Scoped Dependency Reproduction ---

async def get_scoped() -> Service:
    """Plain scoped dependency."""
    global scoped_calls
    scoped_calls += 1
    
    # Simulate work
    await asyncio.sleep(0.1)
    return Service("scoped")

async def sub_dep1(s: Annotated[Service, Depends(get_scoped)]):
    return s

async def sub_dep2(s: Annotated[Service, Depends(get_scoped)]):
    return s

@app.get("/scoped")
async def scoped_endpoint(
    s1: Annotated[Service, Depends(sub_dep1)],
    s2: Annotated[Service, Depends(sub_dep2)]
):
    # Within a single request, s1 and s2 should be the same
    return {"id1": str(s1.id), "id2": str(s2.id), "match": s1.id == s2.id}

@app.get("/counters")
async def get_counters():
    return {"singleton_calls": singleton_calls, "scoped_calls": scoped_calls}

def get_free_port():
    import socket
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.bind(("", 0))
        return s.getsockname()[1]

async def run_repro():
    port = get_free_port()
    # Start server in background
    config = uvicorn.Config(app, port=port, log_level="error")
    server = uvicorn.Server(config)
    loop = asyncio.get_event_loop()
    server_task = loop.create_task(server.serve())
    
    # Wait for server to start
    await asyncio.sleep(1)
    
    async with AsyncClient(base_url=f"http://127.0.0.1:{port}") as client:
        print(f"\n--- Testing Singleton Race Condition ({NUM_SINGLETON_REQUESTS} requests) ---")
        # Send concurrent requests to the singleton endpoint
        responses = await asyncio.gather(*(client.get("/singleton") for _ in range(NUM_SINGLETON_REQUESTS)))
        ids = {r.json()["id"] for r in responses}
        
        print(f"Number of unique singleton instances created: {len(ids)}")
        
        print(f"\n--- Testing Scoped Dependency ({NUM_SCOPED_REQUESTS} requests) ---")
        # Concurrent requests, each having 2 branches depending on same thing
        responses = await asyncio.gather(*(client.get("/scoped") for _ in range(NUM_SCOPED_REQUESTS)))
        matches = [r.json()["match"] for r in responses]
        all_match = all(matches)
        
        print(f"All sub-dependencies matched in all requests: {all_match}")

        # Final Counters
        resp = await client.get("/counters")
        counters = resp.json()
        
        print("\n--- Final Call Counters ---")
        print(f"Singleton calls: {counters['singleton_calls']} (Expected: 1, Actual: {counters['singleton_calls']})")
        print(f"Scoped calls:     {counters['scoped_calls']} (Expected: {NUM_SCOPED_REQUESTS}, Actual: {counters['scoped_calls']})")
        
        if counters['singleton_calls'] > 1:
            print("\nRESULT: Singleton Race Reproduced! (Called multiple times)")
        
        if counters['scoped_calls'] == NUM_SCOPED_REQUESTS:
            print("RESULT: Scoped Dependency Cached Correctly! (Called once per request)")
        elif counters['scoped_calls'] > NUM_SCOPED_REQUESTS:
            print(f"RESULT: Scoped Dependency Over-called! (Called {counters['scoped_calls']} times for {NUM_SCOPED_REQUESTS} requests)")

    server.should_exit = True
    await server_task

if __name__ == "__main__":
    asyncio.run(run_repro())
