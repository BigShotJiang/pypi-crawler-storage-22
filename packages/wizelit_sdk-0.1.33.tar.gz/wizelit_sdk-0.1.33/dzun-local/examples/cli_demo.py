"""Demo: programmatically invoke wizelit-sdk CLI to scaffold and validate an agent."""

from pathlib import Path
import tempfile
import sys

from click.testing import CliRunner

from wizelit_sdk import cli as sdk_cli


def run_demo() -> int:
    runner = CliRunner()

    with tempfile.TemporaryDirectory() as tmp:
        outdir = Path(tmp)
        agent_name = "test-agent"

        print(f"Scaffolding agent '{agent_name}' into: {outdir}")
        r = runner.invoke(sdk_cli.cli, ["init", agent_name, "--template", "fast", "--output-dir", str(outdir)])
        print("--- init output ---")
        print(r.output)
        if r.exit_code != 0:
            print(f"init failed (exit {r.exit_code})")
            return r.exit_code

        project_dir = outdir / "test-agent"
        print(f"Validating project at: {project_dir}")
        r2 = runner.invoke(sdk_cli.cli, ["validate", str(project_dir)])
        print("--- validate output ---")
        print(r2.output)
        if r2.exit_code != 0:
            print(f"validate failed (exit {r2.exit_code})")
            return r2.exit_code

        print("Listing tools...")
        r3 = runner.invoke(sdk_cli.cli, ["list-tools", str(project_dir)])
        print("--- list-tools output ---")
        print(r3.output)

        main_py = project_dir / "main.py"
        if main_py.exists():
            print("--- main.py preview ---")
            text = main_py.read_text(encoding="utf-8")
            for i, line in enumerate(text.splitlines()[:40], start=1):
                print(f"{i:03}: {line}")

    return 0


if __name__ == "__main__":
    # Ensure the SDK package is importable when running this script directly.
    # If running from the repo root, set PYTHONPATH to `src` so imports resolve.
    try:
        sys.exit(run_demo())
    except Exception as e:
        print("Demo failed:", e)
        raise
