#!/usr/bin/env bash
set -euo pipefail

# Determine repo root (script placed in wizelit-sdk/)
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
SRC_DIR="$ROOT/src"
DEMO="$ROOT/examples/cli_demo.py"

# Activate .venv if it exists
if [ -f "$ROOT/.venv/bin/activate" ]; then
  echo "Activating virtualenv at $ROOT/.venv"
  # shellcheck disable=SC1090
  source "$ROOT/.venv/bin/activate"
fi

# Ensure PYTHONPATH includes local src so `from wizelit_sdk import ...` works
# Use safe expansions so `set -u` doesn't error when PYTHONPATH is unset.
export PYTHONPATH="$SRC_DIR${PYTHONPATH:+:}${PYTHONPATH:-}"

# Ensure click is available (install if missing)
if ! python3 -c "import importlib, sys; importlib.import_module('click')" >/dev/null 2>&1; then
  echo "Module 'click' not found. Installing into current environment..."
  pip install click
fi

echo "Running demo: $DEMO"
python3 "$DEMO"