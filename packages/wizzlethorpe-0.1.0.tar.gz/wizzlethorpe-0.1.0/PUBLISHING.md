# Publishing to PyPI

This document describes how to publish the `wizzlethorpe` package to PyPI.

## Quick Start (Using publish.py)

The easiest way to publish is using the `publish.py` script:

```bash
# Check if tools are installed
python publish.py check

# Build only
python publish.py build

# Test on TestPyPI
python publish.py testpypi

# Publish to PyPI
python publish.py pypi

# Full workflow (interactive)
python publish.py all
```

For manual publishing or more control, see the detailed steps below.

## Prerequisites

1. Install build tools:
   ```bash
   pip install build twine
   ```

2. Create accounts:
   - [PyPI account](https://pypi.org/account/register/)
   - [TestPyPI account](https://test.pypi.org/account/register/) (for testing)

3. Configure PyPI credentials:
   - Create a PyPI API token at https://pypi.org/manage/account/token/
   - Save it in `~/.pypirc`:
     ```ini
     [pypi]
     username = __token__
     password = pypi-...your-token-here...

     [testpypi]
     username = __token__
     password = pypi-...your-token-here...
     ```

## Publishing Steps

### 1. Update Version

Edit the version number in `pyproject.toml`:

```toml
[project]
version = "0.1.1"  # Increment appropriately
```

### 2. Build the Package

```bash
# Clean old builds
rm -rf dist/ build/ *.egg-info

# Build source distribution and wheel
python -m build
```

This creates:
- `dist/wizzlethorpe-0.1.1.tar.gz` (source distribution)
- `dist/wizzlethorpe-0.1.1-py3-none-any.whl` (wheel)

### 3. Test on TestPyPI (Optional but Recommended)

```bash
# Upload to TestPyPI
python -m twine upload --repository testpypi dist/*

# Test installation
pip install --index-url https://test.pypi.org/simple/ wizzlethorpe
```

### 4. Publish to PyPI

```bash
# Upload to PyPI
python -m twine upload dist/*
```

### 5. Verify Installation

```bash
# Install from PyPI
pip install wizzlethorpe

# Test it works (both commands should work)
wizzlethorpe --help
wzl --help
python -c "from wizzlethorpe import WizzlethorpeClient; print('OK')"
```

### 6. Tag the Release

```bash
git tag v0.1.1
git push origin v0.1.1
```

## Automated Publishing with GitHub Actions

You can automate publishing using GitHub Actions. Create `.github/workflows/publish.yml`:

```yaml
name: Publish to PyPI

on:
  release:
    types: [published]

jobs:
  publish:
    runs-on: ubuntu-latest
    permissions:
      id-token: write  # for trusted publishing
    steps:
      - uses: actions/checkout@v4

      - uses: actions/setup-python@v5
        with:
          python-version: '3.10'

      - name: Install build tools
        run: pip install build

      - name: Build package
        run: python -m build

      - name: Publish to PyPI
        uses: pypa/gh-action-pypi-publish@release/v1
        with:
          password: ${{ secrets.PYPI_API_TOKEN }}
```

Then set `PYPI_API_TOKEN` as a GitHub secret in your repository settings.

## Versioning Guidelines

Follow [Semantic Versioning](https://semver.org/):

- **MAJOR** (1.0.0): Breaking changes
- **MINOR** (0.1.0): New features, backwards compatible
- **PATCH** (0.0.1): Bug fixes, backwards compatible

## Checklist Before Publishing

- [ ] Update version in `pyproject.toml`
- [ ] Update CHANGELOG or README with changes
- [ ] Run tests if available
- [ ] Build package locally
- [ ] Test on TestPyPI
- [ ] Publish to PyPI
- [ ] Tag release in git
- [ ] Verify installation from PyPI
