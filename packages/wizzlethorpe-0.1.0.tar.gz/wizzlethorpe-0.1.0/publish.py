#!/usr/bin/env python3
"""Build and publish script for the wizzlethorpe package."""

import argparse
import shutil
import subprocess
import sys
from pathlib import Path


def run(cmd, check=True):
    """Run a command and print it."""
    print(f"Running: {' '.join(cmd)}")
    result = subprocess.run(cmd, check=check)
    return result.returncode == 0


def clean():
    """Remove old build artifacts."""
    print("Cleaning old builds...")
    dirs_to_remove = ["dist", "build", "*.egg-info"]

    for pattern in dirs_to_remove:
        if "*" in pattern:
            # Handle glob patterns
            for path in Path(".").glob(pattern):
                if path.is_dir():
                    print(f"  Removing {path}")
                    shutil.rmtree(path)
        else:
            path = Path(pattern)
            if path.exists():
                print(f"  Removing {path}")
                shutil.rmtree(path)

    print("Clean complete!")


def check_tools():
    """Check if required tools are installed."""
    print("Checking for required tools...")

    missing = []

    # Check build (doesn't support --version, so we try to import it)
    result = subprocess.run(
        [sys.executable, "-c", "import build"],
        capture_output=True,
        check=False
    )
    if result.returncode != 0:
        missing.append("build")

    # Check twine (supports --version)
    result = subprocess.run(
        [sys.executable, "-m", "twine", "--version"],
        capture_output=True,
        check=False
    )
    if result.returncode != 0:
        missing.append("twine")

    if missing:
        print(f"Missing required tools: {', '.join(missing)}")
        print(f"Install with: pip install {' '.join(missing)}")
        return False

    print("All required tools installed!")
    return True


def build():
    """Build the package."""
    print("Building package...")
    if not run([sys.executable, "-m", "build"]):
        print("Build failed!")
        return False

    print("\nBuild artifacts:")
    for file in Path("dist").glob("*"):
        print(f"  {file}")

    print("\nBuild complete!")
    return True


def upload(repository="pypi"):
    """Upload to PyPI or TestPyPI."""
    dist_files = list(Path("dist").glob("*"))

    if not dist_files:
        print("No distribution files found! Run build first.")
        return False

    print(f"\nUploading to {repository}...")
    cmd = [sys.executable, "-m", "twine", "upload"]

    if repository == "testpypi":
        cmd.extend(["--repository", "testpypi"])

    cmd.extend([str(f) for f in dist_files])

    if not run(cmd, check=False):
        print(f"\nUpload to {repository} failed!")
        return False

    print(f"\nUpload to {repository} complete!")
    return True


def verify_version():
    """Show the current version from pyproject.toml."""
    import tomllib

    with open("pyproject.toml", "rb") as f:
        config = tomllib.load(f)

    version = config["project"]["version"]
    name = config["project"]["name"]

    print(f"\nPackage: {name}")
    print(f"Version: {version}")
    return version


def main():
    parser = argparse.ArgumentParser(
        description="Build and publish the wizzlethorpe package"
    )
    parser.add_argument(
        "action",
        choices=["clean", "build", "testpypi", "pypi", "check", "all"],
        help="Action to perform"
    )
    parser.add_argument(
        "--skip-clean",
        action="store_true",
        help="Skip cleaning step"
    )

    args = parser.parse_args()

    # Show version info
    if args.action != "clean":
        try:
            verify_version()
        except Exception as e:
            print(f"Warning: Could not read version: {e}")

    # Execute action
    if args.action == "check":
        sys.exit(0 if check_tools() else 1)

    elif args.action == "clean":
        clean()

    elif args.action == "build":
        if not args.skip_clean:
            clean()
        if not check_tools():
            sys.exit(1)
        sys.exit(0 if build() else 1)

    elif args.action == "testpypi":
        if not args.skip_clean:
            clean()
        if not check_tools():
            sys.exit(1)
        if not build():
            sys.exit(1)

        print("\n" + "="*60)
        print("Ready to upload to TestPyPI")
        print("="*60)
        response = input("Continue? [y/N]: ")
        if response.lower() != "y":
            print("Aborted.")
            sys.exit(1)

        sys.exit(0 if upload("testpypi") else 1)

    elif args.action == "pypi":
        if not args.skip_clean:
            clean()
        if not check_tools():
            sys.exit(1)
        if not build():
            sys.exit(1)

        print("\n" + "="*60)
        print("⚠️  Ready to upload to PyPI (PRODUCTION)")
        print("="*60)
        response = input("Are you sure? [y/N]: ")
        if response.lower() != "y":
            print("Aborted.")
            sys.exit(1)

        if upload("pypi"):
            version = verify_version()
            print("\n" + "="*60)
            print("Success! Next steps:")
            print(f"  1. Tag release: git tag v{version}")
            print(f"  2. Push tag: git push origin v{version}")
            print(f"  3. Test install: pip install wizzlethorpe=={version}")
            print("="*60)
            sys.exit(0)
        else:
            sys.exit(1)

    elif args.action == "all":
        # Full workflow: clean, build, testpypi, pypi
        print("Full workflow: clean -> build -> testpypi -> pypi")
        print()

        if not check_tools():
            sys.exit(1)

        clean()

        if not build():
            sys.exit(1)

        print("\n" + "="*60)
        print("Step 1: Upload to TestPyPI")
        print("="*60)
        response = input("Upload to TestPyPI? [y/N]: ")
        if response.lower() == "y":
            if not upload("testpypi"):
                sys.exit(1)

            print("\nTest the package from TestPyPI:")
            print("  pip install --index-url https://test.pypi.org/simple/ wizzlethorpe")
            print("  wzl --help")
            input("\nPress Enter when ready to continue...")

        print("\n" + "="*60)
        print("Step 2: Upload to PyPI (PRODUCTION)")
        print("="*60)
        response = input("Upload to PyPI? [y/N]: ")
        if response.lower() == "y":
            if upload("pypi"):
                version = verify_version()
                print("\n" + "="*60)
                print("Success! Next steps:")
                print(f"  1. Tag release: git tag v{version}")
                print(f"  2. Push tag: git push origin v{version}")
                print(f"  3. Test install: pip install wizzlethorpe=={version}")
                print("="*60)
        else:
            print("Aborted.")


if __name__ == "__main__":
    main()
