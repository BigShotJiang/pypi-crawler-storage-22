# ────────────────────────────────────────────────────────────────────────────────────────
#   wj-termimage
#   ────────────
#
#   Display images in the terminal using ANSI colour and Unicode half-block graphics.
#
#   (c) 2026 WaterJuice — MIT License; see LICENSE in the project root.
#
#   Authors
#   ───────
#   bena (via Claude)
#
#   Version History
#   ───────────────
#   Feb 2026 - Created
# ────────────────────────────────────────────────────────────────────────────────────────

# ────────────────────────────────────────────────────────────────────────────────────────
#   Version
# ────────────────────────────────────────────────────────────────────────────────────────

from .version import VERSION_STR

__version__ = VERSION_STR
__all__ = ["__version__"]
