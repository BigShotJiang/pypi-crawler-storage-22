# ────────────────────────────────────────────────────────────────────────────────────────
#   cli.py
#   ──────
#
#   CLI entry point for wj-termimage. Handles argument parsing and orchestrates
#   image decoding and rendering.
#
#   (c) 2026 WaterJuice — MIT License; see LICENSE in the project root.
#
#   Authors
#   ───────
#   bena (via Claude)
#
#   Version History
#   ───────────────
#   Feb 2026 - Created
# ────────────────────────────────────────────────────────────────────────────────────────

# ────────────────────────────────────────────────────────────────────────────────────────
#   Imports
# ────────────────────────────────────────────────────────────────────────────────────────

import argparse
import sys
import traceback
from pathlib import Path
from .version import VERSION_STR

# ────────────────────────────────────────────────────────────────────────────────────────
#   Main Entry Point
# ────────────────────────────────────────────────────────────────────────────────────────


# ────────────────────────────────────────────────────────────────────────────────────────
def main(argv: list[str] | None = None) -> int:
    """
    Main entry point for wj-termimage CLI.

    Parameters:
        argv: Command line arguments. If None, uses sys.argv[1:].

    Returns:
        Exit code (0 for success, non-zero for error).
    """
    if argv is None:
        argv = sys.argv[1:]

    try:
        return _main_inner(argv)
    except KeyboardInterrupt:
        return 1
    except SystemExit as e:
        return e.code if isinstance(e.code, int) else 0
    except BaseException as e:
        t = "-----------------------------------------------------------------------------\n"
        t += "UNHANDLED EXCEPTION OCCURRED!!\n"
        t += "\n"
        t += traceback.format_exc()
        t += "\n"
        t += f"EXCEPTION: {type(e)} {e}\n"
        t += "-----------------------------------------------------------------------------\n"
        t += "\n"
        print(t, file=sys.stderr)
        return 1


# ────────────────────────────────────────────────────────────────────────────────────────
def _main_inner(argv: list[str]) -> int:
    """Inner main function."""
    parser = argparse.ArgumentParser(
        prog="wj-termimage",
        description=(
            "Display images in the terminal using ANSI colour and Unicode"
            " half-block graphics."
        ),
    )
    parser.add_argument(
        "--version",
        action="version",
        version=f"wj-termimage {VERSION_STR}",
    )
    parser.add_argument(
        "image",
        type=Path,
        help="Path to the image file to display.",
    )
    parser.add_argument(
        "-f",
        "--full-width",
        action="store_true",
        default=False,
        help="Scale to terminal width (may require scrolling).",
    )
    parser.add_argument(
        "-o",
        "--output",
        type=Path,
        default=None,
        metavar="FILE",
        help="Write ANSI output to a text file instead of the terminal.",
    )
    parser.add_argument(
        "-w",
        "--width",
        type=int,
        default=None,
        metavar="COLS",
        help="Render width in columns. Required when using --output.",
    )
    parser.add_argument(
        "-n",
        "--nearest",
        action="store_true",
        default=False,
        help="Use nearest-neighbour instead of area-averaged downscaling.",
    )
    parser.add_argument(
        "-c",
        "--colour",
        choices=["24bit", "256", "8"],
        default="24bit",
        help="Colour mode: 24bit (default), 256, or 8.",
    )

    args = parser.parse_args(argv)
    image_path: Path = args.image
    full_width: bool = args.full_width
    output_path: Path | None = args.output
    explicit_width: int | None = args.width
    antialias: bool = not args.nearest
    colour_mode: str = args.colour

    if output_path is not None and explicit_width is None:
        parser.error("--width is required when using --output")

    if not image_path.exists():
        print(f"Error: file not found: {image_path}", file=sys.stderr)
        return 1

    from .decoders import decode_file
    from .renderer import render

    image = decode_file(image_path)
    result = render(
        image,
        full_width=full_width,
        width=explicit_width,
        antialias=antialias,
        colour_mode=colour_mode,
    )

    if output_path is not None:
        output_path.write_text(result + "\n", encoding="utf-8")
    else:
        print(result)
    return 0
