# ────────────────────────────────────────────────────────────────────────────────────────
#   decoders/__init__.py
#   ────────────────────
#
#   Image format detection and dispatch. Identifies image formats by magic bytes
#   and delegates to the appropriate decoder module.
#
#   (c) 2026 WaterJuice — MIT License; see LICENSE in the project root.
#
#   Authors
#   ───────
#   bena (via Claude)
#
#   Version History
#   ───────────────
#   Feb 2026 - Created
# ────────────────────────────────────────────────────────────────────────────────────────

# ────────────────────────────────────────────────────────────────────────────────────────
#   Imports
# ────────────────────────────────────────────────────────────────────────────────────────

from pathlib import Path
from ..image import Image

# ────────────────────────────────────────────────────────────────────────────────────────
#   Format Detection
# ────────────────────────────────────────────────────────────────────────────────────────


# ────────────────────────────────────────────────────────────────────────────────────────
def decode_file(path: Path) -> Image:
    """
    Decode an image file, auto-detecting the format from magic bytes.

    Parameters:
        path: Path to the image file.

    Returns:
        Decoded Image.

    Raises:
        ValueError: If the format is not supported.
        FileNotFoundError: If the file does not exist.
    """
    data = path.read_bytes()

    if len(data) < 2:
        raise ValueError(f"File too small to be an image: {path}")

    # JPEG: starts with 0xFF 0xD8
    if data[0] == 0xFF and data[1] == 0xD8:
        from .jpeg import decode_jpeg

        return decode_jpeg(data)

    # PNG: 8-byte signature
    if data[:8] == b"\x89PNG\r\n\x1a\n":
        from .png import decode_png

        return decode_png(data)

    # BMP: starts with "BM"
    if data[:2] == b"BM":
        from .bmp import decode_bmp

        return decode_bmp(data)

    raise ValueError(
        f"Unsupported image format: {path}\nCurrently supported formats: JPEG, PNG, BMP"
    )
