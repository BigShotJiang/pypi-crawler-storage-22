# ────────────────────────────────────────────────────────────────────────────────────────
#   bmp.py
#   ──────
#
#   Pure-Python BMP decoder. Supports uncompressed 1-bit, 4-bit, 8-bit indexed,
#   16-bit, 24-bit, and 32-bit images with BITMAPINFOHEADER (v3) and later.
#
#   (c) 2026 WaterJuice — MIT License; see LICENSE in the project root.
#
#   Authors
#   ───────
#   bena (via Claude)
#
#   Version History
#   ───────────────
#   Feb 2026 - Created
# ────────────────────────────────────────────────────────────────────────────────────────

# ────────────────────────────────────────────────────────────────────────────────────────
#   Imports
# ────────────────────────────────────────────────────────────────────────────────────────

import struct
from ..image import Colour
from ..image import Image

# ────────────────────────────────────────────────────────────────────────────────────────
#   Constants
# ────────────────────────────────────────────────────────────────────────────────────────

_BI_RGB = 0
_BI_BITFIELDS = 3

# ────────────────────────────────────────────────────────────────────────────────────────
#   Helpers
# ────────────────────────────────────────────────────────────────────────────────────────


# ────────────────────────────────────────────────────────────────────────────────────────
def _read_colour_table(data: bytes, offset: int, count: int) -> list[Colour]:
    """Read a BMP colour table (array of BGRA quads) into RGB tuples."""
    table: list[Colour] = []
    for i in range(count):
        off = offset + i * 4
        b, g, r = data[off], data[off + 1], data[off + 2]
        # 4th byte is reserved/alpha, ignored for colour table
        table.append((r, g, b))
    return table


# ────────────────────────────────────────────────────────────────────────────────────────
def _mask_shift_and_scale(mask: int) -> tuple[int, int]:
    """
    Compute the right-shift and scale factor for a bitmask.

    Returns:
        (shift, scale) where value = ((raw >> shift) * scale) gives 0–255.
    """
    if mask == 0:
        return (0, 0)
    shift = 0
    m = mask
    while (m & 1) == 0:
        m >>= 1
        shift += 1
    # Count the number of bits in the mask
    bits = 0
    while m & 1:
        m >>= 1
        bits += 1
    # Scale factor to expand to 8 bits
    if bits >= 8:
        scale = 1
    else:
        scale = 255 // ((1 << bits) - 1) if bits > 0 else 0
    return (shift, scale)


# ────────────────────────────────────────────────────────────────────────────────────────
#   Public API
# ────────────────────────────────────────────────────────────────────────────────────────


# ────────────────────────────────────────────────────────────────────────────────────────
def decode_bmp(data: bytes) -> Image:
    """
    Decode a BMP image from raw bytes.

    Parameters:
        data: Complete BMP file contents.

    Returns:
        Decoded Image with RGB pixel data.

    Raises:
        ValueError: If the data is not valid BMP or uses unsupported features.
    """
    if len(data) < 54 or data[0:2] != b"BM":
        raise ValueError("Not a valid BMP file")

    # File header (14 bytes)
    pixel_offset: int = struct.unpack_from("<I", data, 10)[0]

    # Info header
    header_size: int = struct.unpack_from("<I", data, 14)[0]
    if header_size < 40:
        raise ValueError(f"Unsupported BMP header size: {header_size}")

    width: int = struct.unpack_from("<i", data, 18)[0]
    height_raw: int = struct.unpack_from("<i", data, 22)[0]
    bits_per_pixel: int = struct.unpack_from("<H", data, 28)[0]
    compression: int = struct.unpack_from("<I", data, 30)[0]

    # Negative height means top-down row order
    top_down = height_raw < 0
    height = abs(height_raw)

    if width <= 0 or height == 0:
        raise ValueError(f"Invalid BMP dimensions: {width}x{height}")

    if compression not in (_BI_RGB, _BI_BITFIELDS):
        raise ValueError(f"Unsupported BMP compression: {compression}")

    # Colour table follows the info header
    colour_table_offset = 14 + header_size
    colours_used: int = struct.unpack_from("<I", data, 46)[0]

    # Read bitfield masks for 16-bit and BI_BITFIELDS
    r_mask: int
    g_mask: int
    b_mask: int
    if compression == _BI_BITFIELDS and header_size >= 52:
        r_mask = struct.unpack_from("<I", data, 54)[0]
        g_mask = struct.unpack_from("<I", data, 58)[0]
        b_mask = struct.unpack_from("<I", data, 62)[0]
    elif compression == _BI_BITFIELDS:
        # Masks stored after info header
        mask_off = 14 + header_size
        r_mask = struct.unpack_from("<I", data, mask_off)[0]
        g_mask = struct.unpack_from("<I", data, mask_off + 4)[0]
        b_mask = struct.unpack_from("<I", data, mask_off + 8)[0]
    elif bits_per_pixel == 16:
        # Default 16-bit masks (5-5-5)
        r_mask = 0x7C00
        g_mask = 0x03E0
        b_mask = 0x001F
    else:
        r_mask = 0
        g_mask = 0
        b_mask = 0

    # Read colour table for indexed formats
    colour_table: list[Colour] = []
    if bits_per_pixel <= 8:
        num_colours = colours_used if colours_used > 0 else (1 << bits_per_pixel)
        colour_table = _read_colour_table(data, colour_table_offset, num_colours)

    # Row stride is padded to 4-byte boundary
    row_bits = width * bits_per_pixel
    row_bytes = (row_bits + 7) // 8
    stride = (row_bytes + 3) & ~3

    # Decode pixel data
    pixels: list[Colour] = []
    rows: list[list[Colour]] = []

    for y in range(height):
        row_offset = pixel_offset + y * stride
        row: list[Colour] = []

        if bits_per_pixel == 32:
            for x in range(width):
                off: int = row_offset + x * 4
                b_val: int = data[off]
                g_val: int = data[off + 1]
                r_val: int = data[off + 2]
                # 4th byte is alpha, ignored
                row.append((r_val, g_val, b_val))

        elif bits_per_pixel == 24:
            for x in range(width):
                off = row_offset + x * 3
                b_val = data[off]
                g_val = data[off + 1]
                r_val = data[off + 2]
                row.append((r_val, g_val, b_val))

        elif bits_per_pixel == 16:
            r_shift, r_scale = _mask_shift_and_scale(r_mask)
            g_shift, g_scale = _mask_shift_and_scale(g_mask)
            b_shift, b_scale = _mask_shift_and_scale(b_mask)
            for x in range(width):
                off = row_offset + x * 2
                val: int = struct.unpack_from("<H", data, off)[0]
                rv = ((val & r_mask) >> r_shift) * r_scale
                gv = ((val & g_mask) >> g_shift) * g_scale
                bv = ((val & b_mask) >> b_shift) * b_scale
                row.append((rv, gv, bv))

        elif bits_per_pixel == 8:
            for x in range(width):
                idx: int = data[row_offset + x]
                row.append(colour_table[idx])

        elif bits_per_pixel == 4:
            for x in range(width):
                byte_off: int = row_offset + x // 2
                if x % 2 == 0:
                    idx = (data[byte_off] >> 4) & 0x0F
                else:
                    idx = data[byte_off] & 0x0F
                row.append(colour_table[idx])

        elif bits_per_pixel == 1:
            for x in range(width):
                byte_off = row_offset + x // 8
                bit = 7 - (x % 8)
                idx = (data[byte_off] >> bit) & 1
                row.append(colour_table[idx])

        else:
            raise ValueError(f"Unsupported BMP bits per pixel: {bits_per_pixel}")

        rows.append(row)

    # BMP rows are bottom-up by default
    if not top_down:
        rows.reverse()

    for row in rows:
        pixels.extend(row)

    return Image(width, height, pixels)
