# ────────────────────────────────────────────────────────────────────────────────────────
#   jpeg.py
#   ───────
#
#   Pure-Python JPEG decoder supporting both baseline (SOF0) and progressive (SOF2)
#   modes. Decodes JFIF/Exif JPEG files to RGB pixels using only the standard
#   library. Supports 4:4:4, 4:2:2, and 4:2:0 chroma subsampling.
#
#   (c) 2026 WaterJuice — MIT License; see LICENSE in the project root.
#
#   Authors
#   ───────
#   bena (via Claude)
#
#   Version History
#   ───────────────
#   Feb 2026 - Created
# ────────────────────────────────────────────────────────────────────────────────────────

# ────────────────────────────────────────────────────────────────────────────────────────
#   Imports
# ────────────────────────────────────────────────────────────────────────────────────────

import math
import struct
from dataclasses import dataclass
from dataclasses import field
from ..image import Colour
from ..image import Image

# ────────────────────────────────────────────────────────────────────────────────────────
#   Constants
# ────────────────────────────────────────────────────────────────────────────────────────

# JPEG marker bytes (second byte after 0xFF)
_SOF0 = 0xC0  # Baseline DCT
_SOF2 = 0xC2  # Progressive DCT
_DHT = 0xC4  # Define Huffman Table
_SOI = 0xD8  # Start of Image
_EOI = 0xD9  # End of Image
_SOS = 0xDA  # Start of Scan
_DQT = 0xDB  # Define Quantization Table
_DRI = 0xDD  # Define Restart Interval
_RST0 = 0xD0  # Restart marker 0
_RST7 = 0xD7  # Restart marker 7

_INVSQRT2 = 1.0 / math.sqrt(2.0)

# Zigzag scan order: maps coefficient index (0-63) to (row, col) position in 8×8 block
# fmt: off
_ZIGZAG = [
     0,  1,  8, 16,  9,  2,  3, 10,
    17, 24, 32, 25, 18, 11,  4,  5,
    12, 19, 26, 33, 40, 48, 41, 34,
    27, 20, 13,  6,  7, 14, 21, 28,
    35, 42, 49, 56, 57, 50, 43, 36,
    29, 22, 15, 23, 30, 37, 44, 51,
    58, 59, 52, 45, 38, 31, 39, 46,
    53, 60, 61, 54, 47, 55, 62, 63,
]
# fmt: on

# Precomputed cosine table for IDCT: _COS[x * 8 + u] = cos((2x+1) * u * pi / 16)
_COS: list[float] = []
for _x in range(8):
    for _u in range(8):
        _COS.append(math.cos((2 * _x + 1) * _u * math.pi / 16.0))

# ────────────────────────────────────────────────────────────────────────────────────────
#   Types
# ────────────────────────────────────────────────────────────────────────────────────────


# ────────────────────────────────────────────────────────────────────────────────────────
@dataclass
class _Component:
    """A single colour component from the SOF0 frame header."""

    component_id: int
    h_sampling: int  # horizontal sampling factor
    v_sampling: int  # vertical sampling factor
    quant_table_id: int


# ────────────────────────────────────────────────────────────────────────────────────────
@dataclass
class _FrameHeader:
    """Parsed SOF0 frame header."""

    height: int
    width: int
    components: list[_Component]


# ────────────────────────────────────────────────────────────────────────────────────────
@dataclass
class _ScanComponent:
    """A component reference within the SOS scan header."""

    component_id: int
    dc_table_id: int
    ac_table_id: int


# ────────────────────────────────────────────────────────────────────────────────────────
@dataclass
class _JpegContext:
    """Mutable state accumulated while parsing JPEG markers."""

    quant_tables: dict[int, list[int]] = field(default_factory=lambda: {})
    huff_dc: dict[int, _HuffmanTable] = field(default_factory=lambda: {})
    huff_ac: dict[int, _HuffmanTable] = field(default_factory=lambda: {})
    frame: _FrameHeader | None = None
    restart_interval: int = 0


# ────────────────────────────────────────────────────────────────────────────────────────
#   Huffman Table
# ────────────────────────────────────────────────────────────────────────────────────────


# ────────────────────────────────────────────────────────────────────────────────────────
class _HuffmanTable:
    """
    JPEG Huffman decoding table.

    Uses min/max code arrays for efficient decoding as described in the JPEG spec.
    """

    def __init__(self, counts: list[int], symbols: list[int]) -> None:
        self.symbols = symbols
        self.mincode = [0] * 17
        self.maxcode = [-1] * 17
        self.valptr = [0] * 17

        code = 0
        si = 0
        for i in range(1, 17):
            if counts[i - 1] > 0:
                self.valptr[i] = si
                self.mincode[i] = code
                code += counts[i - 1]
                self.maxcode[i] = code - 1
                si += counts[i - 1]
            code <<= 1

    def decode(self, reader: _BitReader) -> int:
        """Decode the next Huffman symbol from the bit stream."""
        code = 0
        for bits in range(1, 17):
            code = (code << 1) | reader.read_bit()
            if self.maxcode[bits] >= 0 and code <= self.maxcode[bits]:
                return self.symbols[self.valptr[bits] + code - self.mincode[bits]]
        raise ValueError("Invalid Huffman code — no matching symbol found")


# ────────────────────────────────────────────────────────────────────────────────────────
#   Bit Reader
# ────────────────────────────────────────────────────────────────────────────────────────


# ────────────────────────────────────────────────────────────────────────────────────────
class _BitReader:
    """
    Reads individual bits from JPEG entropy-coded data.

    Handles 0xFF byte stuffing: 0xFF 0x00 in the stream represents a literal
    0xFF data byte. Restart markers (0xFF 0xD0–0xD7) are silently consumed.
    """

    def __init__(self, data: bytes, pos: int) -> None:
        self.data = data
        self.pos = pos
        self._bits: int = 0
        self._nbits: int = 0
        self.marker_found: bool = False

    def read_bit(self) -> int:
        """Read a single bit from the stream."""
        if self._nbits == 0:
            if self.marker_found:
                return 0
            self._load_byte()
        self._nbits -= 1
        return (self._bits >> self._nbits) & 1

    def read_bits(self, n: int) -> int:
        """Read n bits as an unsigned integer."""
        value = 0
        for _ in range(n):
            value = (value << 1) | self.read_bit()
        return value

    def _load_byte(self) -> None:
        """Load the next byte, handling byte stuffing and end-of-scan markers."""
        if self.pos >= len(self.data):
            self.marker_found = True
            self._bits = 0
            self._nbits = 8
            return

        b = self.data[self.pos]
        self.pos += 1
        if b == 0xFF:
            if self.pos >= len(self.data):
                self.marker_found = True
                self._bits = 0
                self._nbits = 8
                return
            marker = self.data[self.pos]
            self.pos += 1
            if marker == 0x00:
                # Byte stuffing: literal 0xFF
                pass
            elif _RST0 <= marker <= _RST7:
                # Restart marker inside stream — skip and load next byte
                if self.pos >= len(self.data):
                    self.marker_found = True
                    self._bits = 0
                    self._nbits = 8
                    return
                b = self.data[self.pos]
                self.pos += 1
                if b == 0xFF:
                    if self.pos >= len(self.data):
                        self.marker_found = True
                        self._bits = 0
                        self._nbits = 8
                        return
                    marker = self.data[self.pos]
                    self.pos += 1
            else:
                # End-of-scan marker found — back up so the marker can be re-read
                self.pos -= 2
                self.marker_found = True
                self._bits = 0
                self._nbits = 8
                return
        self._bits = b
        self._nbits = 8

    def reset(self) -> None:
        """Reset bit buffer (called at restart marker boundaries)."""
        self._bits = 0
        self._nbits = 0
        self.marker_found = False

    def align_to_byte(self) -> None:
        """Discard any remaining bits in the current byte."""
        self._nbits = 0

    def skip_to_marker(self) -> None:
        """Advance past any remaining entropy data until the next 0xFF marker."""
        self.align_to_byte()
        while self.pos < len(self.data) - 1:
            if self.data[self.pos] == 0xFF and self.data[self.pos + 1] != 0x00:
                marker = self.data[self.pos + 1]
                if not (_RST0 <= marker <= _RST7):
                    break
                self.pos += 2
            else:
                self.pos += 1


# ────────────────────────────────────────────────────────────────────────────────────────
#   IDCT
# ────────────────────────────────────────────────────────────────────────────────────────


# ────────────────────────────────────────────────────────────────────────────────────────
def _idct_1d(data: list[float]) -> list[float]:
    """Compute 1D 8-point IDCT."""
    result = [0.0] * 8
    for x in range(8):
        off = x * 8
        s = data[0] * _INVSQRT2
        for u in range(1, 8):
            s += data[u] * _COS[off + u]
        result[x] = s * 0.5
    return result


# ────────────────────────────────────────────────────────────────────────────────────────
def _idct_2d(block: list[float]) -> list[int]:
    """
    Compute 2D 8×8 IDCT using two passes of 1D IDCT (rows then columns).

    Returns 64 integer pixel values, level-shifted by +128 and clamped to 0–255.
    """
    # Row pass
    temp = [0.0] * 64
    for y in range(8):
        row = block[y * 8 : (y + 1) * 8]
        result = _idct_1d(row)
        off = y * 8
        for x in range(8):
            temp[off + x] = result[x]

    # Column pass
    out = [0] * 64
    for x in range(8):
        col = [temp[y * 8 + x] for y in range(8)]
        result = _idct_1d(col)
        for y in range(8):
            val = int(result[y] + 128.5)
            if val < 0:
                val = 0
            elif val > 255:
                val = 255
            out[y * 8 + x] = val
    return out


# ────────────────────────────────────────────────────────────────────────────────────────
#   Colour Conversion
# ────────────────────────────────────────────────────────────────────────────────────────


# ────────────────────────────────────────────────────────────────────────────────────────
def _ycbcr_to_rgb(y: int, cb: int, cr: int) -> Colour:
    """Convert a single YCbCr pixel to RGB, clamping to 0–255."""
    r = y + 1.402 * (cr - 128)
    g = y - 0.344136 * (cb - 128) - 0.714136 * (cr - 128)
    b = y + 1.772 * (cb - 128)
    return (
        max(0, min(255, int(r + 0.5))),
        max(0, min(255, int(g + 0.5))),
        max(0, min(255, int(b + 0.5))),
    )


# ────────────────────────────────────────────────────────────────────────────────────────
#   Marker Parsing
# ────────────────────────────────────────────────────────────────────────────────────────


# ────────────────────────────────────────────────────────────────────────────────────────
def _parse_dqt(data: bytes, length: int, ctx: _JpegContext) -> None:
    """Parse a DQT (Define Quantization Table) marker segment."""
    off = 0
    while off < length:
        info = data[off]
        off += 1
        precision = (info >> 4) & 0x0F  # 0 = 8-bit, 1 = 16-bit
        table_id = info & 0x0F

        table: list[int] = []
        for _ in range(64):
            if precision == 0:
                table.append(data[off])
                off += 1
            else:
                table.append(struct.unpack(">H", data[off : off + 2])[0])
                off += 2
        ctx.quant_tables[table_id] = table


# ────────────────────────────────────────────────────────────────────────────────────────
def _parse_sof0(data: bytes, ctx: _JpegContext) -> None:
    """Parse a SOF0 (Start of Frame, baseline) marker segment."""
    precision = data[0]
    if precision != 8:
        raise ValueError(f"Unsupported sample precision: {precision} (expected 8)")

    height = struct.unpack(">H", data[1:3])[0]
    width = struct.unpack(">H", data[3:5])[0]
    num_components = data[5]

    components: list[_Component] = []
    off = 6
    for _ in range(num_components):
        comp_id = data[off]
        sampling = data[off + 1]
        h_samp = (sampling >> 4) & 0x0F
        v_samp = sampling & 0x0F
        qt_id = data[off + 2]
        components.append(_Component(comp_id, h_samp, v_samp, qt_id))
        off += 3

    ctx.frame = _FrameHeader(height, width, components)


# ────────────────────────────────────────────────────────────────────────────────────────
def _parse_dht(data: bytes, length: int, ctx: _JpegContext) -> None:
    """Parse a DHT (Define Huffman Table) marker segment."""
    off = 0
    while off < length:
        info = data[off]
        off += 1
        table_class = (info >> 4) & 0x0F  # 0 = DC, 1 = AC
        table_id = info & 0x0F

        counts = list(data[off : off + 16])
        off += 16
        num_symbols = sum(counts)
        symbols = list(data[off : off + num_symbols])
        off += num_symbols

        table = _HuffmanTable(counts, symbols)
        if table_class == 0:
            ctx.huff_dc[table_id] = table
        else:
            ctx.huff_ac[table_id] = table


# ────────────────────────────────────────────────────────────────────────────────────────
def _parse_dri(data: bytes, ctx: _JpegContext) -> None:
    """Parse a DRI (Define Restart Interval) marker segment."""
    ctx.restart_interval = struct.unpack(">H", data[0:2])[0]


# ────────────────────────────────────────────────────────────────────────────────────────
def _parse_sos_header(
    data: bytes,
) -> tuple[list[_ScanComponent], int, int, int, int, int]:
    """
    Parse the SOS (Start of Scan) header.

    Returns:
        (scan_components, ss, se, ah, al, header_length).
        ss/se = spectral selection start/end, ah/al = successive approximation
        high/low bits. header_length is needed to find where entropy data begins.
    """
    num_components = data[0]
    components: list[_ScanComponent] = []
    off = 1
    for _ in range(num_components):
        comp_id = data[off]
        selectors = data[off + 1]
        dc_id = (selectors >> 4) & 0x0F
        ac_id = selectors & 0x0F
        components.append(_ScanComponent(comp_id, dc_id, ac_id))
        off += 2
    ss = data[off]
    se = data[off + 1]
    approx = data[off + 2]
    ah = (approx >> 4) & 0x0F
    al = approx & 0x0F
    off += 3
    return (components, ss, se, ah, al, off)


# ────────────────────────────────────────────────────────────────────────────────────────
#   Block Decoding
# ────────────────────────────────────────────────────────────────────────────────────────


# ────────────────────────────────────────────────────────────────────────────────────────
def _receive_value(reader: _BitReader, size: int) -> int:
    """
    Read a signed coefficient value from the bit stream.

    JPEG encodes signed values using a category/offset scheme: if the leading
    bit is 0 the value is negative.
    """
    if size == 0:
        return 0
    bits = reader.read_bits(size)
    if bits < (1 << (size - 1)):
        # Negative range
        return bits - (1 << size) + 1
    return bits


# ────────────────────────────────────────────────────────────────────────────────────────
def _decode_block(
    reader: _BitReader,
    dc_table: _HuffmanTable,
    ac_table: _HuffmanTable,
    quant: list[int],
    prev_dc: int,
) -> tuple[list[int], int]:
    """
    Decode one 8×8 block from the entropy-coded stream.

    Parameters:
        reader: Bit stream reader.
        dc_table: Huffman table for DC coefficient.
        ac_table: Huffman table for AC coefficients.
        quant: 64-element quantization table.
        prev_dc: Previous DC value for differential coding.

    Returns:
        (pixel_values, new_dc) — 64 pixel values (0–255) and the updated DC predictor.
    """
    # Decode DC coefficient
    dc_size = dc_table.decode(reader)
    dc_diff = _receive_value(reader, dc_size)
    dc_val = prev_dc + dc_diff

    # Build coefficient array in zigzag order
    coeffs = [0.0] * 64
    coeffs[0] = float(dc_val * quant[0])

    # Decode AC coefficients
    k = 1
    while k < 64:
        symbol = ac_table.decode(reader)
        if symbol == 0x00:
            # EOB — remaining coefficients are zero
            break
        run = (symbol >> 4) & 0x0F
        size = symbol & 0x0F
        if size == 0:
            if run == 0x0F:
                # ZRL — skip 16 zeros
                k += 16
                continue
            # Should not happen (EOB is symbol 0x00), but handle gracefully
            break
        k += run
        if k >= 64:
            break
        value = _receive_value(reader, size)
        coeffs[_ZIGZAG[k]] = float(value * quant[k])
        k += 1

    # Inverse DCT
    pixels = _idct_2d(coeffs)
    return (pixels, dc_val)


# ────────────────────────────────────────────────────────────────────────────────────────
#   Scan Decoding
# ────────────────────────────────────────────────────────────────────────────────────────


# ────────────────────────────────────────────────────────────────────────────────────────
def _decode_scan(
    reader: _BitReader,
    ctx: _JpegContext,
    scan_components: list[_ScanComponent],
) -> list[list[list[list[int]]]]:
    """
    Decode the entropy-coded scan data into per-component block grids.

    Returns:
        A list (one per scan component) of 2D grids of 8×8 blocks.
        Each block is a list of 64 pixel values (0–255).
        Grid indexing: blocks[comp_idx][block_row][block_col].
    """
    frame = ctx.frame
    if frame is None:
        raise ValueError("No SOF0 marker found before SOS")

    # Build mapping from component_id to frame component
    comp_map: dict[int, _Component] = {c.component_id: c for c in frame.components}

    # Determine maximum sampling factors
    max_h = max(c.h_sampling for c in frame.components)
    max_v = max(c.v_sampling for c in frame.components)

    # MCU dimensions in pixels
    mcu_w = max_h * 8
    mcu_h = max_v * 8

    # Number of MCUs across and down
    mcus_x = (frame.width + mcu_w - 1) // mcu_w
    mcus_y = (frame.height + mcu_h - 1) // mcu_h

    # Allocate block grids for each scan component
    # blocks_x/y = number of 8×8 blocks in each direction for this component
    block_grids: list[list[list[list[int]]]] = []
    comp_infos: list[_Component] = []
    dc_tables: list[_HuffmanTable] = []
    ac_tables: list[_HuffmanTable] = []
    quant_tables: list[list[int]] = []

    for sc in scan_components:
        comp = comp_map[sc.component_id]
        comp_infos.append(comp)
        blocks_x = mcus_x * comp.h_sampling
        blocks_y = mcus_y * comp.v_sampling
        grid: list[list[list[int]]] = [
            [[0] * 64 for _ in range(blocks_x)] for _ in range(blocks_y)
        ]
        block_grids.append(grid)
        dc_tables.append(ctx.huff_dc[sc.dc_table_id])
        ac_tables.append(ctx.huff_ac[sc.ac_table_id])
        quant_tables.append(ctx.quant_tables[comp.quant_table_id])

    # DC predictors (one per component)
    prev_dc = [0] * len(scan_components)

    # Decode MCUs
    restart_counter = 0
    for mcu_row in range(mcus_y):
        for mcu_col in range(mcus_x):
            # Check for restart interval
            if ctx.restart_interval > 0 and restart_counter == ctx.restart_interval:
                restart_counter = 0
                prev_dc = [0] * len(scan_components)
                reader.align_to_byte()
                # Skip past the restart marker
                while reader.pos < len(reader.data) - 1:
                    if reader.data[reader.pos] == 0xFF:
                        marker = reader.data[reader.pos + 1]
                        if _RST0 <= marker <= _RST7:
                            reader.pos += 2
                            break
                        if marker == 0x00:
                            break
                    reader.pos += 1
                reader.reset()

            # Decode blocks for each component within this MCU
            for ci in range(len(scan_components)):
                comp = comp_infos[ci]
                for v in range(comp.v_sampling):
                    for h in range(comp.h_sampling):
                        block_row = mcu_row * comp.v_sampling + v
                        block_col = mcu_col * comp.h_sampling + h
                        pixels, prev_dc[ci] = _decode_block(
                            reader,
                            dc_tables[ci],
                            ac_tables[ci],
                            quant_tables[ci],
                            prev_dc[ci],
                        )
                        block_grids[ci][block_row][block_col] = pixels

            restart_counter += 1

    return block_grids


# ────────────────────────────────────────────────────────────────────────────────────────
#   Progressive Scan Decoding
# ────────────────────────────────────────────────────────────────────────────────────────


# ────────────────────────────────────────────────────────────────────────────────────────
def _handle_restart(
    reader: _BitReader,
    ctx: _JpegContext,
    restart_counter: int,
    prev_dc: list[int],
) -> int:
    """Handle restart interval boundary. Returns updated restart counter."""
    if ctx.restart_interval > 0 and restart_counter == ctx.restart_interval:
        prev_dc[:] = [0] * len(prev_dc)
        reader.align_to_byte()
        while reader.pos < len(reader.data) - 1:
            if reader.data[reader.pos] == 0xFF:
                marker = reader.data[reader.pos + 1]
                if _RST0 <= marker <= _RST7:
                    reader.pos += 2
                    break
                if marker == 0x00:
                    break
            reader.pos += 1
        reader.reset()
        return 0
    return restart_counter


# ────────────────────────────────────────────────────────────────────────────────────────
def _decode_prog_dc_first(
    reader: _BitReader,
    ctx: _JpegContext,
    scan_components: list[_ScanComponent],
    al: int,
    coeff_grids: list[list[list[list[int]]]],
) -> None:
    """Decode a progressive DC first scan (Ss=0, Se=0, Ah=0)."""
    frame = ctx.frame
    if frame is None:
        raise ValueError("No frame header found before SOS")

    comp_map: dict[int, _Component] = {c.component_id: c for c in frame.components}
    comp_index: dict[int, int] = {
        c.component_id: i for i, c in enumerate(frame.components)
    }
    max_h = max(c.h_sampling for c in frame.components)
    max_v = max(c.v_sampling for c in frame.components)

    interleaved = len(scan_components) > 1
    prev_dc = [0] * len(scan_components)
    restart_counter = 0

    if interleaved:
        mcus_x = (frame.width + max_h * 8 - 1) // (max_h * 8)
        mcus_y = (frame.height + max_v * 8 - 1) // (max_v * 8)

        for mcu_row in range(mcus_y):
            for mcu_col in range(mcus_x):
                restart_counter = _handle_restart(reader, ctx, restart_counter, prev_dc)
                for ci, sc in enumerate(scan_components):
                    comp = comp_map[sc.component_id]
                    gi = comp_index[sc.component_id]
                    dc_table = ctx.huff_dc[sc.dc_table_id]
                    for v in range(comp.v_sampling):
                        for h in range(comp.h_sampling):
                            br = mcu_row * comp.v_sampling + v
                            bc = mcu_col * comp.h_sampling + h
                            dc_size = dc_table.decode(reader)
                            dc_diff = _receive_value(reader, dc_size)
                            prev_dc[ci] += dc_diff
                            coeff_grids[gi][br][bc][0] = prev_dc[ci] << al
                restart_counter += 1
    else:
        sc = scan_components[0]
        comp = comp_map[sc.component_id]
        gi = comp_index[sc.component_id]
        dc_table = ctx.huff_dc[sc.dc_table_id]
        mcus_x = (frame.width + max_h * 8 - 1) // (max_h * 8)
        mcus_y = (frame.height + max_v * 8 - 1) // (max_v * 8)
        blocks_x = mcus_x * comp.h_sampling
        blocks_y = mcus_y * comp.v_sampling

        for br in range(blocks_y):
            for bc in range(blocks_x):
                restart_counter = _handle_restart(reader, ctx, restart_counter, prev_dc)
                dc_size = dc_table.decode(reader)
                dc_diff = _receive_value(reader, dc_size)
                prev_dc[0] += dc_diff
                coeff_grids[gi][br][bc][0] = prev_dc[0] << al
                restart_counter += 1


# ────────────────────────────────────────────────────────────────────────────────────────
def _decode_prog_dc_refine(
    reader: _BitReader,
    ctx: _JpegContext,
    scan_components: list[_ScanComponent],
    al: int,
    coeff_grids: list[list[list[list[int]]]],
) -> None:
    """Decode a progressive DC refining scan (Ss=0, Se=0, Ah>0)."""
    frame = ctx.frame
    if frame is None:
        raise ValueError("No frame header found before SOS")

    comp_map: dict[int, _Component] = {c.component_id: c for c in frame.components}
    comp_index: dict[int, int] = {
        c.component_id: i for i, c in enumerate(frame.components)
    }
    max_h = max(c.h_sampling for c in frame.components)
    max_v = max(c.v_sampling for c in frame.components)

    interleaved = len(scan_components) > 1
    prev_dc: list[int] = [0] * len(scan_components)
    restart_counter = 0
    bit_val = 1 << al

    if interleaved:
        mcus_x = (frame.width + max_h * 8 - 1) // (max_h * 8)
        mcus_y = (frame.height + max_v * 8 - 1) // (max_v * 8)

        for mcu_row in range(mcus_y):
            for mcu_col in range(mcus_x):
                restart_counter = _handle_restart(reader, ctx, restart_counter, prev_dc)
                for sc in scan_components:
                    comp = comp_map[sc.component_id]
                    gi = comp_index[sc.component_id]
                    for v in range(comp.v_sampling):
                        for h in range(comp.h_sampling):
                            br = mcu_row * comp.v_sampling + v
                            bc = mcu_col * comp.h_sampling + h
                            if reader.read_bit():
                                coeff_grids[gi][br][bc][0] |= bit_val
                restart_counter += 1
    else:
        sc = scan_components[0]
        comp = comp_map[sc.component_id]
        gi = comp_index[sc.component_id]
        mcus_x = (frame.width + max_h * 8 - 1) // (max_h * 8)
        mcus_y = (frame.height + max_v * 8 - 1) // (max_v * 8)
        blocks_x = mcus_x * comp.h_sampling
        blocks_y = mcus_y * comp.v_sampling

        for br in range(blocks_y):
            for bc in range(blocks_x):
                restart_counter = _handle_restart(reader, ctx, restart_counter, prev_dc)
                if reader.read_bit():
                    coeff_grids[gi][br][bc][0] |= bit_val
                restart_counter += 1


# ────────────────────────────────────────────────────────────────────────────────────────
def _decode_prog_ac_first(
    reader: _BitReader,
    ctx: _JpegContext,
    scan_components: list[_ScanComponent],
    ss: int,
    se: int,
    al: int,
    coeff_grids: list[list[list[list[int]]]],
) -> None:
    """Decode a progressive AC first scan (Ss>0, Ah=0). Always non-interleaved."""
    frame = ctx.frame
    if frame is None:
        raise ValueError("No frame header found before SOS")

    comp_map: dict[int, _Component] = {c.component_id: c for c in frame.components}
    comp_index: dict[int, int] = {
        c.component_id: i for i, c in enumerate(frame.components)
    }
    max_h = max(c.h_sampling for c in frame.components)
    max_v = max(c.v_sampling for c in frame.components)

    sc = scan_components[0]
    comp = comp_map[sc.component_id]
    gi = comp_index[sc.component_id]
    ac_table = ctx.huff_ac[sc.ac_table_id]

    mcus_x = (frame.width + max_h * 8 - 1) // (max_h * 8)
    mcus_y = (frame.height + max_v * 8 - 1) // (max_v * 8)
    blocks_x = mcus_x * comp.h_sampling
    blocks_y = mcus_y * comp.v_sampling

    prev_dc: list[int] = [0]
    restart_counter = 0
    eob_run = 0

    for br in range(blocks_y):
        for bc in range(blocks_x):
            restart_counter = _handle_restart(reader, ctx, restart_counter, prev_dc)
            if restart_counter == 0 and ctx.restart_interval > 0:
                eob_run = 0

            coeffs = coeff_grids[gi][br][bc]

            if eob_run > 0:
                eob_run -= 1
                restart_counter += 1
                continue

            k = ss
            while k <= se:
                symbol = ac_table.decode(reader)
                run = (symbol >> 4) & 0x0F
                size = symbol & 0x0F

                if size == 0:
                    if run == 0x0F:
                        # ZRL: skip 16 zeros
                        k += 16
                    elif run == 0:
                        # EOB0: end of block for this block only
                        break
                    else:
                        # Extended EOB: 2^run + extra bits
                        eob_run = (1 << run) + reader.read_bits(run) - 1
                        break
                else:
                    k += run
                    if k > se:
                        break
                    value = _receive_value(reader, size)
                    coeffs[_ZIGZAG[k]] = value << al
                    k += 1

            restart_counter += 1


# ────────────────────────────────────────────────────────────────────────────────────────
def _refine_coefficient(coeff: int, bit_val: int, bit: int) -> int:
    """Refine a non-zero coefficient: if bit is set, adjust magnitude."""
    if bit:
        if coeff > 0:
            return coeff + bit_val
        else:
            return coeff - bit_val
    return coeff


# ────────────────────────────────────────────────────────────────────────────────────────
def _decode_prog_ac_refine(
    reader: _BitReader,
    ctx: _JpegContext,
    scan_components: list[_ScanComponent],
    ss: int,
    se: int,
    al: int,
    coeff_grids: list[list[list[list[int]]]],
) -> None:
    """Decode a progressive AC refining scan (Ss>0, Ah>0). Always non-interleaved."""
    frame = ctx.frame
    if frame is None:
        raise ValueError("No frame header found before SOS")

    comp_map: dict[int, _Component] = {c.component_id: c for c in frame.components}
    comp_index: dict[int, int] = {
        c.component_id: i for i, c in enumerate(frame.components)
    }
    max_h = max(c.h_sampling for c in frame.components)
    max_v = max(c.v_sampling for c in frame.components)

    sc = scan_components[0]
    comp = comp_map[sc.component_id]
    gi = comp_index[sc.component_id]
    ac_table = ctx.huff_ac[sc.ac_table_id]

    mcus_x = (frame.width + max_h * 8 - 1) // (max_h * 8)
    mcus_y = (frame.height + max_v * 8 - 1) // (max_v * 8)
    blocks_x = mcus_x * comp.h_sampling
    blocks_y = mcus_y * comp.v_sampling

    prev_dc: list[int] = [0]
    restart_counter = 0
    eob_run = 0
    bit_val = 1 << al

    for br in range(blocks_y):
        for bc in range(blocks_x):
            restart_counter = _handle_restart(reader, ctx, restart_counter, prev_dc)
            if restart_counter == 0 and ctx.restart_interval > 0:
                eob_run = 0

            coeffs = coeff_grids[gi][br][bc]

            if eob_run > 0:
                # Refine all existing non-zero coefficients in [ss, se]
                for k in range(ss, se + 1):
                    zz = _ZIGZAG[k]
                    if coeffs[zz] != 0:
                        coeffs[zz] = _refine_coefficient(
                            coeffs[zz], bit_val, reader.read_bit()
                        )
                eob_run -= 1
                restart_counter += 1
                continue

            k = ss
            while k <= se:
                symbol = ac_table.decode(reader)
                run = (symbol >> 4) & 0x0F
                size = symbol & 0x0F

                if size == 0 and run != 0x0F:
                    # EOBn: end of block
                    if run == 0:
                        eob_run = 0
                    else:
                        eob_run = (1 << run) + reader.read_bits(run) - 1
                    # Refine remaining non-zero coefficients
                    while k <= se:
                        zz = _ZIGZAG[k]
                        if coeffs[zz] != 0:
                            coeffs[zz] = _refine_coefficient(
                                coeffs[zz], bit_val, reader.read_bit()
                            )
                        k += 1
                    break

                # Count zero-valued coefficients to skip, refining non-zero along the way
                zeros_to_skip = 16 if (size == 0 and run == 0x0F) else run
                while k <= se and zeros_to_skip > 0:
                    zz = _ZIGZAG[k]
                    if coeffs[zz] != 0:
                        coeffs[zz] = _refine_coefficient(
                            coeffs[zz], bit_val, reader.read_bit()
                        )
                    else:
                        zeros_to_skip -= 1
                    k += 1

                if size != 0:
                    # New non-zero coefficient
                    if k > se:
                        break
                    # Refine any non-zero at current position
                    while k <= se and coeffs[_ZIGZAG[k]] != 0:
                        coeffs[_ZIGZAG[k]] = _refine_coefficient(
                            coeffs[_ZIGZAG[k]], bit_val, reader.read_bit()
                        )
                        k += 1
                    if k > se:
                        break
                    zz = _ZIGZAG[k]
                    sign_bit = reader.read_bit()
                    coeffs[zz] = bit_val if sign_bit else -bit_val
                    k += 1

            restart_counter += 1


# ────────────────────────────────────────────────────────────────────────────────────────
def _decode_progressive_scan(
    reader: _BitReader,
    ctx: _JpegContext,
    scan_components: list[_ScanComponent],
    ss: int,
    se: int,
    ah: int,
    al: int,
    coeff_grids: list[list[list[list[int]]]],
) -> None:
    """Dispatch a progressive scan to the appropriate decoder."""
    if ss == 0:
        if ah == 0:
            _decode_prog_dc_first(reader, ctx, scan_components, al, coeff_grids)
        else:
            _decode_prog_dc_refine(reader, ctx, scan_components, al, coeff_grids)
    else:
        if ah == 0:
            _decode_prog_ac_first(reader, ctx, scan_components, ss, se, al, coeff_grids)
        else:
            _decode_prog_ac_refine(
                reader, ctx, scan_components, ss, se, al, coeff_grids
            )


# ────────────────────────────────────────────────────────────────────────────────────────
def _assemble_from_coefficients(
    ctx: _JpegContext,
    coeff_grids: list[list[list[list[int]]]],
) -> Image:
    """
    Dequantize and IDCT all coefficient blocks, then assemble into a final Image.

    Used after all progressive scans have been decoded.
    """
    frame = ctx.frame
    if frame is None:
        raise ValueError("No frame header found")

    max_h = max(c.h_sampling for c in frame.components)
    max_v = max(c.v_sampling for c in frame.components)
    mcus_x = (frame.width + max_h * 8 - 1) // (max_h * 8)
    mcus_y = (frame.height + max_v * 8 - 1) // (max_v * 8)

    # Dequantize and IDCT each block, producing pixel block grids
    block_grids: list[list[list[list[int]]]] = []

    for ci, comp in enumerate(frame.components):
        quant = ctx.quant_tables[comp.quant_table_id]
        blocks_y = mcus_y * comp.v_sampling
        blocks_x = mcus_x * comp.h_sampling
        pixel_grid: list[list[list[int]]] = []

        for br in range(blocks_y):
            row: list[list[int]] = []
            for bc in range(blocks_x):
                raw_coeffs = coeff_grids[ci][br][bc]
                # Dequantize: multiply each coefficient by its quantisation value
                dequant = [0.0] * 64
                for i in range(64):
                    dequant[_ZIGZAG[i]] = float(raw_coeffs[_ZIGZAG[i]] * quant[i])
                # IDCT to pixel values
                row.append(_idct_2d(dequant))
            pixel_grid.append(row)

        block_grids.append(pixel_grid)

    # Build scan_components list matching frame component order for _assemble_rgb
    scan_comps = [_ScanComponent(c.component_id, 0, 0) for c in frame.components]
    return _assemble_rgb(block_grids, frame, scan_comps)


# ────────────────────────────────────────────────────────────────────────────────────────
#   Image Assembly
# ────────────────────────────────────────────────────────────────────────────────────────


# ────────────────────────────────────────────────────────────────────────────────────────
def _blocks_to_plane(
    grid: list[list[list[int]]],
    blocks_y: int,
    blocks_x: int,
) -> list[list[int]]:
    """
    Convert a grid of 8×8 blocks into a 2D pixel plane.

    Returns:
        2D list indexed as plane[y][x].
    """
    plane_h = blocks_y * 8
    plane_w = blocks_x * 8
    plane: list[list[int]] = [[0] * plane_w for _ in range(plane_h)]

    for by in range(blocks_y):
        for bx in range(blocks_x):
            block = grid[by][bx]
            base_y = by * 8
            base_x = bx * 8
            for py in range(8):
                row_off = py * 8
                dst_row = plane[base_y + py]
                for px in range(8):
                    dst_row[base_x + px] = block[row_off + px]

    return plane


# ────────────────────────────────────────────────────────────────────────────────────────
def _upsample_plane(
    plane: list[list[int]],
    h_factor: int,
    v_factor: int,
    target_w: int,
    target_h: int,
) -> list[list[int]]:
    """
    Upsample a chroma plane using nearest-neighbour interpolation.

    Parameters:
        plane: Source plane (reduced resolution).
        h_factor: Horizontal ratio (max_h / comp_h).
        v_factor: Vertical ratio (max_v / comp_v).
        target_w: Target width (luma plane width).
        target_h: Target height (luma plane height).

    Returns:
        Upsampled plane at target dimensions.
    """
    if h_factor == 1 and v_factor == 1:
        return plane

    src_h = len(plane)
    src_w = len(plane[0]) if src_h > 0 else 0
    result: list[list[int]] = []

    for y in range(target_h):
        src_y = min(y // v_factor, src_h - 1)
        src_row = plane[src_y]
        row: list[int] = []
        for x in range(target_w):
            src_x = min(x // h_factor, src_w - 1)
            row.append(src_row[src_x])
        result.append(row)

    return result


# ────────────────────────────────────────────────────────────────────────────────────────
def _assemble_rgb(
    block_grids: list[list[list[list[int]]]],
    frame: _FrameHeader,
    scan_components: list[_ScanComponent],
) -> Image:
    """
    Assemble decoded block grids into a final RGB Image.

    Handles chroma upsampling and YCbCr-to-RGB conversion for colour images,
    and direct grayscale output for single-component images.
    """
    width = frame.width
    height = frame.height

    comp_map: dict[int, _Component] = {c.component_id: c for c in frame.components}
    max_h = max(c.h_sampling for c in frame.components)
    max_v = max(c.v_sampling for c in frame.components)

    if len(scan_components) == 1:
        # Grayscale
        comp = comp_map[scan_components[0].component_id]
        blocks_y = len(block_grids[0])
        blocks_x = len(block_grids[0][0]) if blocks_y > 0 else 0
        plane = _blocks_to_plane(block_grids[0], blocks_y, blocks_x)
        pixels: list[Colour] = []
        for y in range(height):
            for x in range(width):
                v = plane[y][x]
                pixels.append((v, v, v))
        return Image(width, height, pixels)

    # Colour image — expect Y, Cb, Cr
    planes: list[list[list[int]]] = []
    comp_list: list[_Component] = []

    for grid_idx, sc in enumerate(scan_components):
        comp = comp_map[sc.component_id]
        comp_list.append(comp)
        blocks_y = len(block_grids[grid_idx])
        blocks_x = len(block_grids[grid_idx][0]) if blocks_y > 0 else 0
        plane = _blocks_to_plane(block_grids[grid_idx], blocks_y, blocks_x)
        planes.append(plane)

    # Upsample chroma planes to match luma
    luma_w = len(planes[0][0]) if len(planes[0]) > 0 else 0
    luma_h = len(planes[0])

    for ci in range(1, len(planes)):
        comp = comp_list[ci]
        h_ratio = max_h // comp.h_sampling
        v_ratio = max_v // comp.v_sampling
        planes[ci] = _upsample_plane(planes[ci], h_ratio, v_ratio, luma_w, luma_h)

    # Convert YCbCr to RGB
    pixels = []
    y_plane = planes[0]
    cb_plane = planes[1]
    cr_plane = planes[2]

    for y in range(height):
        for x in range(width):
            pixels.append(_ycbcr_to_rgb(y_plane[y][x], cb_plane[y][x], cr_plane[y][x]))

    return Image(width, height, pixels)


# ────────────────────────────────────────────────────────────────────────────────────────
#   Public API
# ────────────────────────────────────────────────────────────────────────────────────────


# ────────────────────────────────────────────────────────────────────────────────────────
def decode_jpeg(data: bytes) -> Image:
    """
    Decode a JPEG image (baseline SOF0 or progressive SOF2) from raw bytes.

    Parameters:
        data: Complete JPEG file contents.

    Returns:
        Decoded Image with RGB pixel data.

    Raises:
        ValueError: If the data is not valid JPEG.
    """
    if len(data) < 2 or data[0] != 0xFF or data[1] != _SOI:
        raise ValueError("Not a valid JPEG file (missing SOI marker)")

    ctx = _JpegContext()
    pos = 2
    progressive = False
    coeff_grids: list[list[list[list[int]]]] | None = None

    while pos < len(data) - 1:
        # Find next marker
        if data[pos] != 0xFF:
            pos += 1
            continue

        # Skip padding 0xFF bytes
        while pos < len(data) - 1 and data[pos + 1] == 0xFF:
            pos += 1

        marker = data[pos + 1]
        pos += 2

        if marker == _EOI:
            break

        if marker == 0x00:
            # Byte stuffing outside scan — skip
            continue

        if _RST0 <= marker <= _RST7:
            # Standalone restart marker — skip
            continue

        # Markers with no payload
        if marker == _SOI:
            continue

        # Read segment length
        if pos + 2 > len(data):
            break
        seg_length = struct.unpack(">H", data[pos : pos + 2])[0]
        seg_data = data[pos + 2 : pos + seg_length]
        seg_payload_len = seg_length - 2

        if marker == _DQT:
            _parse_dqt(seg_data, seg_payload_len, ctx)
        elif marker == _SOF0:
            _parse_sof0(seg_data, ctx)
        elif marker == _SOF2:
            _parse_sof0(seg_data, ctx)  # Same header format as SOF0
            progressive = True
        elif marker == _DHT:
            _parse_dht(seg_data, seg_payload_len, ctx)
        elif marker == _DRI:
            _parse_dri(seg_data, ctx)
        elif marker == _SOS:
            scan_comps, ss, se, ah, al, header_len = _parse_sos_header(seg_data)
            entropy_start = pos + 2 + header_len
            reader = _BitReader(data, entropy_start)

            if progressive:
                if ctx.frame is None:
                    raise ValueError("No SOF2 marker found before SOS")
                # Allocate coefficient grids on first scan
                if coeff_grids is None:
                    max_h = max(c.h_sampling for c in ctx.frame.components)
                    max_v = max(c.v_sampling for c in ctx.frame.components)
                    mcus_x = (ctx.frame.width + max_h * 8 - 1) // (max_h * 8)
                    mcus_y = (ctx.frame.height + max_v * 8 - 1) // (max_v * 8)
                    coeff_grids = []
                    for comp in ctx.frame.components:
                        bx = mcus_x * comp.h_sampling
                        by = mcus_y * comp.v_sampling
                        coeff_grids.append(
                            [[[0] * 64 for _ in range(bx)] for _ in range(by)]
                        )

                _decode_progressive_scan(
                    reader, ctx, scan_comps, ss, se, ah, al, coeff_grids
                )
                # Skip past entropy data to continue parsing
                reader.skip_to_marker()
                pos = reader.pos
                continue
            else:
                # Baseline: single scan, decode and return immediately
                block_grids = _decode_scan(reader, ctx, scan_comps)
                if ctx.frame is None:
                    raise ValueError("No SOF0 marker found before SOS")
                return _assemble_rgb(block_grids, ctx.frame, scan_comps)

        pos += seg_length

    # For progressive JPEG, assemble after all scans
    if progressive and coeff_grids is not None:
        return _assemble_from_coefficients(ctx, coeff_grids)

    raise ValueError("No image data found in JPEG file")
