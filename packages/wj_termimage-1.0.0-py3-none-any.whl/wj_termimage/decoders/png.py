# ────────────────────────────────────────────────────────────────────────────────────────
#   png.py
#   ──────
#
#   Pure-Python PNG decoder. Supports 8-bit and 16-bit greyscale, RGB, indexed,
#   greyscale+alpha, and RGBA images. Uses stdlib zlib for IDAT decompression
#   and implements all five PNG filter types.
#
#   (c) 2026 WaterJuice — MIT License; see LICENSE in the project root.
#
#   Authors
#   ───────
#   bena (via Claude)
#
#   Version History
#   ───────────────
#   Feb 2026 - Created
# ────────────────────────────────────────────────────────────────────────────────────────

# ────────────────────────────────────────────────────────────────────────────────────────
#   Imports
# ────────────────────────────────────────────────────────────────────────────────────────

import struct
import zlib
from ..image import Colour
from ..image import Image

# ────────────────────────────────────────────────────────────────────────────────────────
#   Constants
# ────────────────────────────────────────────────────────────────────────────────────────

_PNG_SIGNATURE = b"\x89PNG\r\n\x1a\n"

# Colour type constants
_GREYSCALE = 0
_RGB = 2
_INDEXED = 3
_GREYSCALE_ALPHA = 4
_RGBA = 6

# Filter type constants
_FILTER_NONE = 0
_FILTER_SUB = 1
_FILTER_UP = 2
_FILTER_AVERAGE = 3
_FILTER_PAETH = 4

# ────────────────────────────────────────────────────────────────────────────────────────
#   Helpers
# ────────────────────────────────────────────────────────────────────────────────────────


# ────────────────────────────────────────────────────────────────────────────────────────
def _paeth_predictor(a: int, b: int, c: int) -> int:
    """Paeth predictor function as defined in the PNG specification."""
    p = a + b - c
    pa = abs(p - a)
    pb = abs(p - b)
    pc = abs(p - c)
    if pa <= pb and pa <= pc:
        return a
    if pb <= pc:
        return b
    return c


# ────────────────────────────────────────────────────────────────────────────────────────
def _pixels_from_greyscale(
    pixel_data: bytearray,
    width: int,
    height: int,
    bit_depth: int,
) -> list[Colour]:
    """Convert greyscale pixel data to RGB tuples."""
    pixels: list[Colour] = []
    if bit_depth == 16:
        for y in range(height):
            for x in range(width):
                off = (y * width + x) * 2
                v = pixel_data[off]  # use high byte only
                pixels.append((v, v, v))
    elif bit_depth == 8:
        for y in range(height):
            for x in range(width):
                v = pixel_data[y * width + x]
                pixels.append((v, v, v))
    else:
        # Sub-byte bit depths (1, 2, 4)
        pixels_per_byte = 8 // bit_depth
        max_val = (1 << bit_depth) - 1
        scale = 255 // max_val if max_val > 0 else 0
        for y in range(height):
            row_off = y * ((width * bit_depth + 7) // 8)
            for x in range(width):
                byte_idx = row_off + x // pixels_per_byte
                bit_shift = (pixels_per_byte - 1 - x % pixels_per_byte) * bit_depth
                v = ((pixel_data[byte_idx] >> bit_shift) & max_val) * scale
                pixels.append((v, v, v))
    return pixels


# ────────────────────────────────────────────────────────────────────────────────────────
def _pixels_from_rgb(
    pixel_data: bytearray,
    width: int,
    height: int,
    bit_depth: int,
) -> list[Colour]:
    """Convert RGB pixel data to RGB tuples."""
    pixels: list[Colour] = []
    if bit_depth == 16:
        for y in range(height):
            for x in range(width):
                off = (y * width + x) * 6
                r, g, b = pixel_data[off], pixel_data[off + 2], pixel_data[off + 4]
                pixels.append((r, g, b))
    else:
        for y in range(height):
            for x in range(width):
                off = (y * width + x) * 3
                r, g, b = pixel_data[off], pixel_data[off + 1], pixel_data[off + 2]
                pixels.append((r, g, b))
    return pixels


# ────────────────────────────────────────────────────────────────────────────────────────
def _pixels_from_indexed(
    pixel_data: bytearray,
    width: int,
    height: int,
    bit_depth: int,
    palette: list[Colour],
) -> list[Colour]:
    """Convert indexed pixel data to RGB tuples using the palette."""
    pixels: list[Colour] = []
    if bit_depth == 8:
        for y in range(height):
            for x in range(width):
                idx = pixel_data[y * width + x]
                pixels.append(palette[idx])
    else:
        # Sub-byte bit depths (1, 2, 4)
        pixels_per_byte = 8 // bit_depth
        mask = (1 << bit_depth) - 1
        for y in range(height):
            row_off = y * ((width * bit_depth + 7) // 8)
            for x in range(width):
                byte_idx = row_off + x // pixels_per_byte
                bit_shift = (pixels_per_byte - 1 - x % pixels_per_byte) * bit_depth
                idx = (pixel_data[byte_idx] >> bit_shift) & mask
                pixels.append(palette[idx])
    return pixels


# ────────────────────────────────────────────────────────────────────────────────────────
def _pixels_from_greyscale_alpha(
    pixel_data: bytearray,
    width: int,
    height: int,
    bit_depth: int,
) -> list[Colour]:
    """Convert greyscale+alpha pixel data to RGB tuples (alpha composited on black)."""
    pixels: list[Colour] = []
    bytes_per_sample = 2 if bit_depth == 16 else 1
    step = bytes_per_sample * 2
    for y in range(height):
        for x in range(width):
            off = (y * width + x) * step
            v = pixel_data[off]  # greyscale value (high byte for 16-bit)
            a = pixel_data[off + bytes_per_sample]  # alpha (high byte for 16-bit)
            # Composite onto black background
            c = (v * a) // 255
            pixels.append((c, c, c))
    return pixels


# ────────────────────────────────────────────────────────────────────────────────────────
def _pixels_from_rgba(
    pixel_data: bytearray,
    width: int,
    height: int,
    bit_depth: int,
) -> list[Colour]:
    """Convert RGBA pixel data to RGB tuples (alpha composited on black)."""
    pixels: list[Colour] = []
    if bit_depth == 16:
        for y in range(height):
            for x in range(width):
                off = (y * width + x) * 8
                r, g, b = pixel_data[off], pixel_data[off + 2], pixel_data[off + 4]
                a = pixel_data[off + 6]
                pixels.append(((r * a) // 255, (g * a) // 255, (b * a) // 255))
    else:
        for y in range(height):
            for x in range(width):
                off = (y * width + x) * 4
                r, g, b, a = (
                    pixel_data[off],
                    pixel_data[off + 1],
                    pixel_data[off + 2],
                    pixel_data[off + 3],
                )
                pixels.append(((r * a) // 255, (g * a) // 255, (b * a) // 255))
    return pixels


# ────────────────────────────────────────────────────────────────────────────────────────
#   Chunk Parsing
# ────────────────────────────────────────────────────────────────────────────────────────


# ────────────────────────────────────────────────────────────────────────────────────────
def _iter_chunks(data: bytes) -> list[tuple[bytes, bytes]]:
    """
    Parse PNG chunks after the signature.

    Returns:
        List of (chunk_type, chunk_data) tuples.
    """
    chunks: list[tuple[bytes, bytes]] = []
    pos = 8  # after signature
    while pos + 8 <= len(data):
        length = struct.unpack(">I", data[pos : pos + 4])[0]
        chunk_type = data[pos + 4 : pos + 8]
        chunk_data = data[pos + 8 : pos + 8 + length]
        # Skip CRC (4 bytes)
        pos += 12 + length
        chunks.append((chunk_type, chunk_data))
        if chunk_type == b"IEND":
            break
    return chunks


# ────────────────────────────────────────────────────────────────────────────────────────
#   Public API
# ────────────────────────────────────────────────────────────────────────────────────────


# ────────────────────────────────────────────────────────────────────────────────────────
def decode_png(data: bytes) -> Image:
    """
    Decode a PNG image from raw bytes.

    Parameters:
        data: Complete PNG file contents.

    Returns:
        Decoded Image with RGB pixel data.

    Raises:
        ValueError: If the data is not valid PNG or uses unsupported features.
    """
    if len(data) < 8 or data[:8] != _PNG_SIGNATURE:
        raise ValueError("Not a valid PNG file")

    chunks = _iter_chunks(data)

    # Parse IHDR (must be first chunk)
    if not chunks or chunks[0][0] != b"IHDR":
        raise ValueError("PNG missing IHDR chunk")

    ihdr = chunks[0][1]
    if len(ihdr) < 13:
        raise ValueError("PNG IHDR chunk too short")

    width = struct.unpack(">I", ihdr[0:4])[0]
    height = struct.unpack(">I", ihdr[4:8])[0]
    bit_depth = ihdr[8]
    colour_type = ihdr[9]
    compression_method = ihdr[10]
    filter_method = ihdr[11]
    interlace_method = ihdr[12]

    if compression_method != 0:
        raise ValueError(f"Unsupported PNG compression method: {compression_method}")
    if filter_method != 0:
        raise ValueError(f"Unsupported PNG filter method: {filter_method}")
    if interlace_method != 0:
        raise ValueError("Interlaced PNG is not supported")

    # Collect palette and IDAT data
    palette: list[Colour] = []
    idat_parts: list[bytes] = []

    for chunk_type, chunk_data in chunks:
        if chunk_type == b"PLTE":
            for i in range(0, len(chunk_data), 3):
                r, g, b = chunk_data[i], chunk_data[i + 1], chunk_data[i + 2]
                palette.append((r, g, b))
        elif chunk_type == b"IDAT":
            idat_parts.append(chunk_data)

    if not idat_parts:
        raise ValueError("PNG has no IDAT chunks")

    # Decompress IDAT data
    compressed = b"".join(idat_parts)
    raw = zlib.decompress(compressed)

    # Determine bytes per pixel for filtering
    if colour_type == _GREYSCALE:
        samples_per_pixel = 1
    elif colour_type == _RGB:
        samples_per_pixel = 3
    elif colour_type == _INDEXED:
        samples_per_pixel = 1
    elif colour_type == _GREYSCALE_ALPHA:
        samples_per_pixel = 2
    elif colour_type == _RGBA:
        samples_per_pixel = 4
    else:
        raise ValueError(f"Unsupported PNG colour type: {colour_type}")

    # For sub-byte bit depths, bytes_per_pixel for filtering is 1 (minimum)
    if bit_depth < 8:
        bytes_per_pixel = 1
        # For filtering, stride is based on packed bytes per row
        filter_stride = (width * bit_depth * samples_per_pixel + 7) // 8
    else:
        bytes_per_pixel = samples_per_pixel * (bit_depth // 8)
        filter_stride = width * bytes_per_pixel

    # Unfilter
    pixel_data = _unfilter_raw(raw, filter_stride, height, bytes_per_pixel)

    # Convert to RGB pixels
    if colour_type == _GREYSCALE:
        pixels = _pixels_from_greyscale(pixel_data, width, height, bit_depth)
    elif colour_type == _RGB:
        pixels = _pixels_from_rgb(pixel_data, width, height, bit_depth)
    elif colour_type == _INDEXED:
        if not palette:
            raise ValueError("PNG indexed colour type requires a PLTE chunk")
        pixels = _pixels_from_indexed(pixel_data, width, height, bit_depth, palette)
    elif colour_type == _GREYSCALE_ALPHA:
        pixels = _pixels_from_greyscale_alpha(pixel_data, width, height, bit_depth)
    elif colour_type == _RGBA:
        pixels = _pixels_from_rgba(pixel_data, width, height, bit_depth)
    else:
        raise ValueError(f"Unsupported PNG colour type: {colour_type}")

    return Image(width, height, pixels)


# ────────────────────────────────────────────────────────────────────────────────────────
def _unfilter_raw(
    raw: bytes,
    stride: int,
    height: int,
    bytes_per_pixel: int,
) -> bytearray:
    """
    Reverse PNG row filtering using the actual byte stride (for sub-byte depths).

    Parameters:
        raw: Decompressed IDAT data (with filter bytes).
        stride: Bytes per row (excluding filter byte).
        height: Image height in rows.
        bytes_per_pixel: Minimum filter unit in bytes (>= 1).

    Returns:
        Unfiltered pixel data as a flat bytearray.
    """
    bpp = bytes_per_pixel
    result = bytearray(height * stride)

    for y in range(height):
        src_off = y * (stride + 1)
        filter_type = raw[src_off]
        src_row = src_off + 1
        dst_off = y * stride
        prev_off = (y - 1) * stride

        if filter_type == _FILTER_NONE:
            result[dst_off : dst_off + stride] = raw[src_row : src_row + stride]

        elif filter_type == _FILTER_SUB:
            for i in range(stride):
                left = result[dst_off + i - bpp] if i >= bpp else 0
                result[dst_off + i] = (raw[src_row + i] + left) & 0xFF

        elif filter_type == _FILTER_UP:
            for i in range(stride):
                above = result[prev_off + i] if y > 0 else 0
                result[dst_off + i] = (raw[src_row + i] + above) & 0xFF

        elif filter_type == _FILTER_AVERAGE:
            for i in range(stride):
                left = result[dst_off + i - bpp] if i >= bpp else 0
                above = result[prev_off + i] if y > 0 else 0
                result[dst_off + i] = (raw[src_row + i] + (left + above) // 2) & 0xFF

        elif filter_type == _FILTER_PAETH:
            for i in range(stride):
                left = result[dst_off + i - bpp] if i >= bpp else 0
                above = result[prev_off + i] if y > 0 else 0
                if y > 0 and i >= bpp:
                    upper_left = result[prev_off + i - bpp]
                else:
                    upper_left = 0
                result[dst_off + i] = (
                    raw[src_row + i] + _paeth_predictor(left, above, upper_left)
                ) & 0xFF

        else:
            raise ValueError(f"Unknown PNG filter type: {filter_type}")

    return result
