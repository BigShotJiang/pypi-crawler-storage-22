# ────────────────────────────────────────────────────────────────────────────────────────
#   image.py
#   ────────
#
#   Image data type and scaling utilities. An Image is a simple container for a
#   width × height grid of RGB pixels stored as a flat list.
#
#   (c) 2026 WaterJuice — MIT License; see LICENSE in the project root.
#
#   Authors
#   ───────
#   bena (via Claude)
#
#   Version History
#   ───────────────
#   Feb 2026 - Created
# ────────────────────────────────────────────────────────────────────────────────────────

# ────────────────────────────────────────────────────────────────────────────────────────
#   Imports
# ────────────────────────────────────────────────────────────────────────────────────────

from dataclasses import dataclass

# ────────────────────────────────────────────────────────────────────────────────────────
#   Types
# ────────────────────────────────────────────────────────────────────────────────────────

# RGB colour as (red, green, blue) tuple, each 0-255
type Colour = tuple[int, int, int]

# ────────────────────────────────────────────────────────────────────────────────────────
#   Image
# ────────────────────────────────────────────────────────────────────────────────────────


# ────────────────────────────────────────────────────────────────────────────────────────
@dataclass
class Image:
    """
    A decoded image as a flat grid of RGB pixels.

    Pixels are stored row-major: pixel at (x, y) is pixels[y * width + x].
    """

    width: int
    height: int
    pixels: list[Colour]


# ────────────────────────────────────────────────────────────────────────────────────────
#   Scaling
# ────────────────────────────────────────────────────────────────────────────────────────


# ────────────────────────────────────────────────────────────────────────────────────────
def scale_image(image: Image, new_width: int, new_height: int) -> Image:
    """
    Scale an image to the given dimensions using nearest-neighbour resampling.

    Parameters:
        image: Source image.
        new_width: Target width in pixels.
        new_height: Target height in pixels.

    Returns:
        A new Image at the requested size.
    """
    if new_width == image.width and new_height == image.height:
        return image

    src = image.pixels
    src_w = image.width
    src_h = image.height
    pixels: list[Colour] = []

    for y in range(new_height):
        src_y = y * src_h // new_height
        row_off = src_y * src_w
        for x in range(new_width):
            src_x = x * src_w // new_width
            pixels.append(src[row_off + src_x])

    return Image(new_width, new_height, pixels)


# ────────────────────────────────────────────────────────────────────────────────────────
def scale_image_antialias(image: Image, new_width: int, new_height: int) -> Image:
    """
    Scale an image using area-averaging (box filter) for anti-aliased output.

    Each target pixel is the weighted average of all source pixels whose area
    overlaps it, including fractional edge contributions. Produces much smoother
    results than nearest-neighbour when downscaling.

    Parameters:
        image: Source image.
        new_width: Target width in pixels.
        new_height: Target height in pixels.

    Returns:
        A new Image at the requested size.
    """
    if new_width == image.width and new_height == image.height:
        return image

    src = image.pixels
    src_w = image.width
    src_h = image.height
    pixels: list[Colour] = []

    for ty in range(new_height):
        # Source y range covered by this target row
        sy0 = ty * src_h / new_height
        sy1 = (ty + 1) * src_h / new_height
        iy0 = int(sy0)
        iy1 = min(int(sy1) + 1, src_h)

        for tx in range(new_width):
            # Source x range covered by this target column
            sx0 = tx * src_w / new_width
            sx1 = (tx + 1) * src_w / new_width
            ix0 = int(sx0)
            ix1 = min(int(sx1) + 1, src_w)

            r_acc = 0.0
            g_acc = 0.0
            b_acc = 0.0
            weight = 0.0

            for sy in range(iy0, iy1):
                wy = min(float(sy + 1), sy1) - max(float(sy), sy0)
                if wy <= 0.0:
                    continue
                row_off = sy * src_w
                for sx_i in range(ix0, ix1):
                    wx = min(float(sx_i + 1), sx1) - max(float(sx_i), sx0)
                    if wx <= 0.0:
                        continue
                    w = wx * wy
                    r, g, b = src[row_off + sx_i]
                    r_acc += r * w
                    g_acc += g * w
                    b_acc += b * w
                    weight += w

            if weight > 0.0:
                pixels.append(
                    (
                        int(r_acc / weight + 0.5),
                        int(g_acc / weight + 0.5),
                        int(b_acc / weight + 0.5),
                    )
                )
            else:
                pixels.append((0, 0, 0))

    return Image(new_width, new_height, pixels)
