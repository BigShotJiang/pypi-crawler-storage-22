# ────────────────────────────────────────────────────────────────────────────────────────
#   renderer.py
#   ───────────
#
#   ANSI half-block image renderer. Converts an Image into a string of ANSI-coloured
#   half-block characters suitable for terminal output. Each terminal cell displays
#   two vertical pixels using the lower half-block (▄): background = top pixel,
#   foreground = bottom pixel.
#
#   Rendering approach adapted from wj-spaceinvaders/display.py.
#
#   (c) 2026 WaterJuice — MIT License; see LICENSE in the project root.
#
#   Authors
#   ───────
#   bena (via Claude)
#
#   Version History
#   ───────────────
#   Feb 2026 - Created
# ────────────────────────────────────────────────────────────────────────────────────────

# ────────────────────────────────────────────────────────────────────────────────────────
#   Imports
# ────────────────────────────────────────────────────────────────────────────────────────

import os
from .image import Colour
from .image import Image
from .image import scale_image
from .image import scale_image_antialias

# ────────────────────────────────────────────────────────────────────────────────────────
#   Constants
# ────────────────────────────────────────────────────────────────────────────────────────

_LOWER_HALF = "\u2584"
_RESET = "\033[0m"
_BLACK: Colour = (0, 0, 0)

# Basic 8 ANSI colours (indices 0–7) with their approximate RGB values
_ANSI_8: list[Colour] = [
    (0, 0, 0),  # 0 black
    (128, 0, 0),  # 1 red
    (0, 128, 0),  # 2 green
    (128, 128, 0),  # 3 yellow
    (0, 0, 128),  # 4 blue
    (128, 0, 128),  # 5 magenta
    (0, 128, 128),  # 6 cyan
    (192, 192, 192),  # 7 white
]

# ────────────────────────────────────────────────────────────────────────────────────────
#   Colour Quantisation
# ────────────────────────────────────────────────────────────────────────────────────────


# ────────────────────────────────────────────────────────────────────────────────────────
def _rgb_to_256(r: int, g: int, b: int) -> int:
    """
    Map an RGB colour to the nearest index in the 256-colour ANSI palette.

    Considers the 6x6x6 colour cube (indices 16–231) and the 24-step
    grayscale ramp (indices 232–255), returning whichever is closer.
    """
    # 6x6x6 colour cube
    ci_r = round(r * 5 / 255)
    ci_g = round(g * 5 / 255)
    ci_b = round(b * 5 / 255)
    cube_idx = 16 + 36 * ci_r + 6 * ci_g + ci_b
    # Reconstruct the cube colour for distance comparison
    cr = ci_r * 51
    cg = ci_g * 51
    cb = ci_b * 51
    cube_dist = (r - cr) ** 2 + (g - cg) ** 2 + (b - cb) ** 2

    # 24-step grayscale ramp (8, 18, 28, … 238)
    grey_idx = round((r * 299 + g * 587 + b * 114) / 1000 - 8) // 10
    grey_idx = max(0, min(23, grey_idx))
    grey_val = 8 + 10 * grey_idx
    grey_dist = (r - grey_val) ** 2 + (g - grey_val) ** 2 + (b - grey_val) ** 2

    if grey_dist < cube_dist:
        return 232 + grey_idx
    return cube_idx


# ────────────────────────────────────────────────────────────────────────────────────────
def _rgb_to_8(r: int, g: int, b: int) -> int:
    """
    Map an RGB colour to the nearest of the 8 basic ANSI colours (indices 0–7).
    """
    best = 0
    best_dist = (
        (r - _ANSI_8[0][0]) ** 2 + (g - _ANSI_8[0][1]) ** 2 + (b - _ANSI_8[0][2]) ** 2
    )
    for i in range(1, 8):
        ar, ag, ab = _ANSI_8[i]
        dist = (r - ar) ** 2 + (g - ag) ** 2 + (b - ab) ** 2
        if dist < best_dist:
            best = i
            best_dist = dist
    return best


# ────────────────────────────────────────────────────────────────────────────────────────
#   Terminal Size
# ────────────────────────────────────────────────────────────────────────────────────────


# ────────────────────────────────────────────────────────────────────────────────────────
def get_terminal_size() -> tuple[int, int]:
    """
    Get the current terminal size.

    Returns:
        (columns, rows) tuple.
    """
    try:
        size = os.get_terminal_size()
        return (size.columns, size.lines)
    except OSError:
        return (80, 24)


# ────────────────────────────────────────────────────────────────────────────────────────
#   Fit Calculation
# ────────────────────────────────────────────────────────────────────────────────────────


# ────────────────────────────────────────────────────────────────────────────────────────
def fit_dimensions(
    image_width: int,
    image_height: int,
    term_cols: int,
    term_rows: int,
    full_width: bool = False,
) -> tuple[int, int]:
    """
    Calculate target pixel dimensions to fit an image in the terminal.

    With half-block rendering each terminal row displays 2 pixel rows, so the
    available pixel height is term_rows * 2.

    Parameters:
        image_width: Original image width.
        image_height: Original image height.
        term_cols: Terminal width in columns.
        term_rows: Terminal height in rows.
        full_width: If True, scale to terminal width only (may scroll).

    Returns:
        (target_width, target_height) in pixels. Height is always even.
    """
    avail_w = term_cols
    avail_h = term_rows * 2  # each terminal row = 2 pixel rows

    scale_w = avail_w / image_width

    if full_width:
        scale = scale_w
    else:
        scale_h = avail_h / image_height
        scale = min(scale_w, scale_h)

    target_w = max(1, int(image_width * scale))
    target_h = max(2, int(image_height * scale))

    # Ensure height is even (required for half-block rendering)
    if target_h % 2 != 0:
        target_h += 1

    return (target_w, target_h)


# ────────────────────────────────────────────────────────────────────────────────────────
#   Rendering
# ────────────────────────────────────────────────────────────────────────────────────────


# ────────────────────────────────────────────────────────────────────────────────────────
def render(
    image: Image,
    full_width: bool = False,
    width: int | None = None,
    antialias: bool = False,
    colour_mode: str = "24bit",
) -> str:
    """
    Render an image to ANSI-coloured half-block characters for terminal output.

    Scales the image to fit the terminal, then converts pixel pairs into
    half-block characters with ANSI colour codes.

    Parameters:
        image: The decoded image to render.
        full_width: If True, scale to terminal width (may require scrolling).
        width: Explicit width in columns. Overrides terminal detection and
               implies full_width behaviour (no height constraint).
        antialias: If True, use area-averaging instead of nearest-neighbour
                   for smoother downscaling.
        colour_mode: Colour output mode — "24bit", "256", or "8".

    Returns:
        String ready to write to the terminal.
    """
    if width is not None:
        target_w, target_h = fit_dimensions(
            image.width, image.height, width, 0, full_width=True
        )
    else:
        term_cols, term_rows = get_terminal_size()
        # Reserve one row for the shell prompt that appears after output
        target_w, target_h = fit_dimensions(
            image.width, image.height, term_cols, term_rows - 1, full_width
        )

    scaler = scale_image_antialias if antialias else scale_image
    scaled = scaler(image, target_w, target_h)
    buf = scaled.pixels
    w = scaled.width
    h = scaled.height
    half = _LOWER_HALF

    lines: list[str] = []

    for row in range(0, h, 2):
        top_off = row * w
        bot_off = top_off + w
        parts: list[str] = []
        for col in range(w):
            if top_off + col < len(buf):
                tr, tg, tb = buf[top_off + col]
            else:
                tr, tg, tb = _BLACK
            if bot_off + col < len(buf):
                br, bg, bb = buf[bot_off + col]
            else:
                br, bg, bb = _BLACK
            if colour_mode == "256":
                fi = _rgb_to_256(br, bg, bb)
                bi = _rgb_to_256(tr, tg, tb)
                parts.append(f"\033[38;5;{fi};48;5;{bi}m{half}")
            elif colour_mode == "8":
                fi = _rgb_to_8(br, bg, bb)
                bi = _rgb_to_8(tr, tg, tb)
                parts.append(f"\033[3{fi};4{bi}m{half}")
            else:
                parts.append(f"\033[38;2;{br};{bg};{bb};48;2;{tr};{tg};{tb}m{half}")
        parts.append(_RESET)
        lines.append("".join(parts))

    return "\n".join(lines)
