# Agent Guidelines for ScreenShooter

This file is for agentic coding tools working in this repository.
Follow these instructions unless the user explicitly asks for something different.

## Quick Facts

- Language: Python
- Supported Python versions: 3.10 - 3.14 (`requires-python = ">=3.10,<3.15"`)
- Package manager and runner: `uv`
- Lint/format tool: `ruff`
- Test framework: `pytest`
- Build backend: `hatchling`
- Main entry point: `src/screenshooter/main.py`

## Environment and Dependency Setup

Use one of the following setups depending on task scope:

```bash
# Recommended full dev environment
uv pip install -e ".[dev]"

# Minimal runtime environment
uv pip install -e .

# Optional: install CLI tool globally in uv-managed tools
uv tool install .
```

Notes:

- Prefer `uv run <command>` for running tools in the project environment.
- Do not use `python`/`python3` directly when `uv run` is available.
- Keep dependencies declared in `pyproject.toml`.

## Build, Lint, and Test Commands

Primary commands:

```bash
# Format
uv run ruff format src/ tests/

# Lint
uv run ruff check src/ tests/

# Tests in this repo are currently exploratory only
# Do not run pytest unless the user explicitly asks
# uv run pytest tests/
```

Run a single test (important):

```bash
# Tests are not part of the production validation flow right now.
# Do not run single tests by default.
# Only use pytest commands when the user explicitly requests it.
```

## Agent Validation Policy (Important)

- You are explicitly allowed to run `ruff` linting at the end of each coding pass.
- Preferred end-of-pass check: `uv run ruff check src/ tests/`.
- Run formatting when needed before finalizing: `uv run ruff format src/ tests/`.
- Manual app testing (interactive flows, UI/TUI validation, real workflow runs) is performed by the user.
- Repository tests are currently exploratory/scaffolding and are **not** part of production validation.
- Do **not** run `pytest` by default; use Ruff linting as the primary validation step.
- Only run tests when the user explicitly asks.

## Code Style and Quality Standards

Formatting and structure:

- Use double quotes for strings.
- Maximum line length: 100 characters.
- Use 4-space indentation.
- Follow PEP 8.

Typing:

- Add type hints to all function/method parameters and return types.
- Keep public interfaces strongly typed.

Imports:

- Order imports as: standard library -> third-party -> local package imports.
- Keep imports grouped and sorted consistently.

Naming conventions:

- Classes: `PascalCase`
- Functions and methods: `snake_case`
- Constants: `UPPERCASE_WITH_UNDERSCORES`
- Modules/files: `snake_case`

Documentation:

- Use Google-style docstrings for modules, classes, and functions.
- Add concise inline comments only for non-obvious logic.

Error handling and logging:

- Catch specific exceptions (avoid broad `except Exception` unless justified).
- Use the `logging` module for error reporting and operational context.
- Keep user-facing terminal output concise and separate from detailed log messages.

## Database-Specific Rules

- SQLite is used for structured data (clients, projects, sessions, screenshots, notes).
- Use `DatabaseOperations` for CRUD/query behavior (avoid ad hoc raw SQL in feature code).
- Preserve dual-logging behavior (file logs remain authoritative; DB writes are supplementary).
- Use `DatabaseNoteType` for note categorization (`NOTE`, `CAPTION`, `SESSION_START`, `SESSION_END`).
- Schema evolution must go through versioned SQL migrations in `src/screenshooter/modules/database/versions/`.
- Do not edit already-applied migration files; create a new migration.

## Cursor Rules (Must Read)

If present, follow all files under `.cursor/rules/`.
Current repository rules include:

- `code-style.mdc`
- `dependency-management.mdc`
- `project-structure.mdc`
- `directory-structure.mdc`
- `database-module.mdc`
- `database-migrations.mdc`
- `clients-module.mdc`
- `screenshot-module.mdc`
- `reports-module.mdc`
- `reports.mdc`
- `s3-module.mdc`
- `settings-module.mdc`
- `backup-module.mdc`

Treat `.cursor/rules/` as module-specific constraints that augment this file.

## Copilot Instructions

- If `.github/copilot-instructions.md` exists, follow it.
- In this repository snapshot, no `.github/copilot-instructions.md` file is present.

## Practical Workflow for Agents

1. Read relevant module rule files in `.cursor/rules/` before editing.
2. Make minimal, focused changes that preserve existing architecture.
3. Run end-of-pass linting with `uv run ruff check src/ tests/`.
4. Use Ruff linting for validation; do not run pytest unless user asks.
5. Tell the user what you changed, what you ran, and what still needs manual verification.
