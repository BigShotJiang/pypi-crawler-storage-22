#!/usr/bin/env python3
"""Database migration CLI for ScreenShooter Mac.

Provides command-line interface for migrating existing log file data
to the new SQLite database system.
"""

from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from typing import Any

import click
from rich.console import Console

from screenshooter.modules.database import (
    DatabaseManager,
    DatabaseMigrator,
    DatabaseOperations,
    get_database_manager,
    get_default_database_path,
    get_legacy_database_path,
)
from screenshooter.modules.database.migration_runner import MigrationRunner
from screenshooter.modules.settings.logging_utils import get_database_log_file
from screenshooter.modules.settings.settings_helper import get_screenshots_dir

console = Console()


@dataclass(frozen=True)
class DatabaseContentStats:
    """Aggregated counts for database status output."""

    total_projects: int
    total_sessions: int
    total_screenshots: int
    total_notes: int
    total_captions: int


@dataclass(frozen=True)
class VerificationReportData:
    """Payload for writing screenshot verification reports."""

    report_path: Path
    db_path: Path
    screenshots: list[Any]
    existing_files: list[tuple[Any, int]]
    missing_files: list[Any]
    total_size: int


def _append_database_log(database_log_file: Path, message: str) -> None:
    """Append a timestamped message to the database log file."""
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    entry = f"[{timestamp}] {message}"
    with open(database_log_file, "a") as f:
        f.write(f"{entry}\n")


def _log_and_print_status(
    *,
    database_log_file: Path,
    message: str,
    console_message: str | None = None,
) -> None:
    """Log database status message and print a console-friendly version."""
    _append_database_log(database_log_file, message)
    console.print(console_message or message)


def _write_status_context(
    *,
    database_log_file: Path,
    expected_db_path: Path,
    legacy_db_path: Path,
    db_exists: bool,
) -> None:
    """Write filesystem context details for db status to log file."""
    _append_database_log(database_log_file, f"Expected database location: {expected_db_path}")
    _append_database_log(database_log_file, f"Legacy database location: {legacy_db_path}")
    _append_database_log(database_log_file, f"Database file exists: {db_exists}")
    _append_database_log(database_log_file, f"Legacy database exists: {legacy_db_path.exists()}")


def _handle_missing_database_status(database_log_file: Path) -> bool:
    """Handle missing database flow; return True when caller should exit status command."""
    _log_and_print_status(
        database_log_file=database_log_file,
        message="Database file not found",
        console_message="[yellow]⚠ Database file not found![/yellow]",
    )

    if not _confirm_on_new_line("Database doesn't exist. Do you want to create the database?"):
        _append_database_log(database_log_file, "User chose not to create database - exiting")
        console.print("[yellow]Status check cancelled.[/yellow]")
        return True

    _append_database_log(database_log_file, "User chose to create database - initializing")
    get_database_manager()
    _append_database_log(database_log_file, "Database created and initialized successfully")
    console.print("[green]Database created successfully.[/green]")
    return True


def _gather_database_content_stats(
    db_ops: DatabaseOperations,
    database_log_file: Path,
    clients: list[Any],
) -> DatabaseContentStats:
    """Compute aggregate database content stats across clients/projects/sessions."""
    total_projects = 0
    total_sessions = 0
    total_screenshots = 0
    total_notes = 0
    total_captions = 0

    _append_database_log(database_log_file, "Analyzing projects for each client")
    for client in clients:
        if client.id is None:
            continue
        _append_database_log(database_log_file, f"Querying projects for client {client.id}")
        projects = db_ops.list_projects(client.id)
        total_projects += len(projects)
        _append_database_log(
            database_log_file,
            f"Found {len(projects)} projects for client {client.id}",
        )

        for project in projects:
            if project.id is None:
                continue
            _append_database_log(database_log_file, f"Querying sessions for project {project.id}")
            sessions = db_ops.list_sessions(project.id)
            total_sessions += len(sessions)
            _append_database_log(
                database_log_file,
                f"Found {len(sessions)} sessions for project {project.id}",
            )

            for session in sessions:
                if session.id is None:
                    continue
                _append_database_log(
                    database_log_file,
                    f"Querying screenshots and notes for session {session.id}",
                )
                screenshots = db_ops.list_screenshots(session.id)
                notes = db_ops.list_notes(session.id)
                total_screenshots += len(screenshots)
                total_notes += len(notes)
                captions_count = len([n for n in notes if n.note_type == "caption"])
                total_captions += captions_count
                _append_database_log(
                    database_log_file,
                    f"Found {len(screenshots)} screenshots and {len(notes)} notes "
                    f"for session {session.id}",
                )
                _append_database_log(
                    database_log_file,
                    f"Found {captions_count} captions for session {session.id}",
                )

    return DatabaseContentStats(
        total_projects=total_projects,
        total_sessions=total_sessions,
        total_screenshots=total_screenshots,
        total_notes=total_notes,
        total_captions=total_captions,
    )


def _print_status_stats(clients_count: int, stats: DatabaseContentStats) -> None:
    """Print user-facing status stats summary."""
    console.print("\n[bold]Statistics:[/bold]")
    console.print(f"Clients: {clients_count}")
    console.print(f"Projects: {stats.total_projects}")
    console.print(f"Sessions: {stats.total_sessions}")
    console.print(f"Screenshots: {stats.total_screenshots}")
    console.print(f"Notes: {stats.total_notes}")
    console.print(f"Captions: {stats.total_captions}")


def _resolve_verification_output_dir(output_dir: Path | None) -> Path:
    """Resolve output directory for screenshot verification report."""
    if output_dir is None:
        return Path(get_screenshots_dir())
    return output_dir


def _scan_screenshot_file_presence(
    screenshots: list[Any],
) -> tuple[list[tuple[Any, int]], list[Any], int]:
    """Partition screenshot records into existing/missing and compute total size."""
    existing_files: list[tuple[Any, int]] = []
    missing_files: list[Any] = []
    total_size = 0

    for screenshot in screenshots:
        file_path = Path(screenshot.file_path)
        if not file_path.exists():
            missing_files.append(screenshot)
            continue
        try:
            size = file_path.stat().st_size
            total_size += size
            existing_files.append((screenshot, size))
        except OSError:
            existing_files.append((screenshot, 0))

    return existing_files, missing_files, total_size


def _build_verification_report_path(output_dir: Path) -> Path:
    """Build timestamped screenshot verification report path."""
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    return output_dir / f"screenshot_verification_{timestamp}.txt"


def _write_verification_report(report_data: VerificationReportData) -> None:
    """Write screenshot verification report to disk."""
    with open(report_data.report_path, "w") as f:
        f.write("WorkMaster ScreenShooter - Screenshot Verification Report\n")
        f.write("=" * 60 + "\n\n")
        f.write(f"Generated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n")
        f.write(f"Database: {report_data.db_path}\n")
        f.write(f"Screenshots directory: {get_screenshots_dir()}\n\n")

        f.write("SUMMARY\n")
        f.write("-" * 20 + "\n")
        f.write(f"Total screenshots in database: {len(report_data.screenshots)}\n")
        f.write(f"Existing files: {len(report_data.existing_files)}\n")
        f.write(f"Missing files: {len(report_data.missing_files)}\n")
        f.write(
            f"Total size of existing files: {report_data.total_size / (1024 * 1024):.2f} MB\n\n"
        )

        if report_data.missing_files:
            f.write("MISSING FILES\n")
            f.write("-" * 20 + "\n")
            for screenshot in report_data.missing_files:
                f.write(f"Session {screenshot.session_id}: {screenshot.file_path}\n")
                f.write(f"  Timestamp: {screenshot.timestamp}\n")
                f.write(f"  Set ID: {screenshot.set_id}\n\n")

        f.write("EXISTING FILES\n")
        f.write("-" * 20 + "\n")
        for screenshot, size in report_data.existing_files:
            f.write(f"Session {screenshot.session_id}: {screenshot.file_path}\n")
            f.write(f"  Size: {size / 1024:.1f} KB\n")
            f.write(f"  Timestamp: {screenshot.timestamp}\n")
            f.write(f"  Set ID: {screenshot.set_id}\n\n")


def _print_verification_summary(
    report_path: Path,
    screenshots_count: int,
    existing_count: int,
    missing_count: int,
    total_size: int,
) -> None:
    """Print screenshot verification summary to terminal."""
    console.print(f"\n[green]✓ Report saved to: {report_path}[/green]")
    console.print("\n[bold]Summary:[/bold]")
    console.print(f"Total screenshots: {screenshots_count}")
    console.print(f"Existing files: {existing_count}")
    console.print(f"Missing files: {missing_count}")
    console.print(f"Total size: {total_size / (1024 * 1024):.2f} MB")


def _prompt_ask_on_new_line(prompt_text: str, **kwargs: Any) -> str:
    """Prompt with choices/default on one line, input on a clean `> ` line below."""
    choices = kwargs.get("choices")
    default = kwargs.get("default")

    if choices:
        choices_str = "/".join(str(c) for c in choices)
        extra = f" [{choices_str}]"
        if default is not None:
            extra += f" ({default})"
        console.print(f"{prompt_text}{extra}:")
    else:
        console.print(f"{prompt_text}:")

    while True:
        raw = input("> ").strip()
        if not raw and default is not None:
            raw = str(default)
        if choices:
            if raw in [str(c) for c in choices]:
                return raw
            console.print(
                f"[red]Invalid choice: {raw}. Please enter one of: "
                f"{', '.join(str(c) for c in choices)}[/red]"
            )
            continue
        return raw


def _confirm_on_new_line(prompt_text: str, **kwargs: Any) -> bool:
    """Yes/No confirm with indicator on question line and `> ` for input."""
    default = kwargs.get("default", False)
    indicator = "[Y/n]" if default else "[y/N]"
    console.print(f"{prompt_text} {indicator}:")
    default_choice = "y" if default else "n"

    while True:
        raw = input("> ").strip().lower()
        if not raw:
            raw = default_choice
        if raw in ("y", "n"):
            return raw == "y"
        console.print("[red]Please enter 'y' or 'n'.[/red]")


def interactive_database_menu() -> None:
    """Interactive database management menu."""
    while True:
        console.print("\n[bold]Database Management[/bold]")
        console.print("====================")
        console.print("(Use numbered options to run common database tasks)")

        options = [
            "Show database status",
            "Migrate data from log files to database",
            "Run schema migrations to latest",
            "Show schema migration status",
            "Verify screenshots on disk",
            "Reset database (dangerous - deletes DB data)",
        ]

        console.print("\nOptions:")
        for i, option in enumerate(options, 1):
            console.print(f"{i}. {option}")

        choice = _prompt_ask_on_new_line(
            "\nSelect an option (or 'b' to go back)",
            choices=[str(i) for i in range(1, len(options) + 1)] + ["b"],
            default="1",
        )

        if choice == "b":
            # Return to caller (settings menu or CLI)
            break

        if choice == "1":
            # Use click's main entrypoint but avoid exiting the process
            status.main(args=[], standalone_mode=False)
        elif choice == "2":
            migrate.main(args=[], standalone_mode=False)
        elif choice == "3":
            migrate_schema.main(args=[], standalone_mode=False)
        elif choice == "4":
            migrate_schema.main(["--status"], standalone_mode=False)
        elif choice == "5":
            verify_screenshots.main(args=[], standalone_mode=False)
        elif choice == "6":
            reset.main(args=[], standalone_mode=False)

        input("\nPress Enter to continue...")


@click.command()
@click.option(
    "--base-dir",
    type=click.Path(exists=True, path_type=Path),
    help="Base screenshots directory (defaults to settings value)",
)
@click.option(
    "--dry-run", is_flag=True, help="Show what would be migrated without actually doing it"
)
def migrate(base_dir: Path | None = None, dry_run: bool = False) -> None:
    """Migrate existing log file data to SQLite database."""

    if base_dir is None:
        base_dir = Path(get_screenshots_dir())

    db_path = get_default_database_path()

    # Set up logging to database.log in the central logs directory
    database_log_file = get_database_log_file()

    def write_to_log(message: str) -> None:
        timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        entry = f"[{timestamp}] {message}"
        with open(database_log_file, "a") as f:
            f.write(f"{entry}\n")

    # Log command and context
    write_to_log("Command run: db migrate")
    write_to_log(f"Source directory: {base_dir}")
    write_to_log(f"Database location: {db_path}")
    if dry_run:
        write_to_log("Dry run mode enabled")

    console.print("[bold cyan]ScreenShooter Database Migration[/bold cyan]")
    console.print(f"Source directory: {base_dir}")
    console.print(f"Database location: {db_path}")

    if dry_run:
        console.print("\n[yellow]DRY RUN MODE - No changes will be made[/yellow]")
        # TODO: Add dry run logic to show what would be migrated
        console.print("[yellow]Dry run not implemented yet[/yellow]")
        write_to_log("Dry run mode - no changes were made (not implemented yet)")
        return

    # Confirm migration
    if not _confirm_on_new_line("\nProceed with migration? This will not modify existing files."):
        console.print("Migration cancelled.")
        write_to_log("User cancelled data migration")
        return

    try:
        # Initialize database operations
        db_ops = DatabaseOperations()
        migrator = DatabaseMigrator(db_ops)

        # Run migration
        write_to_log("Starting data migration from log files into database")
        migrator.migrate_all_data(base_dir)

        console.print("\n[green]✓ Migration completed successfully![/green]")
        console.print(f"Database created at: {db_path}")
        write_to_log("Data migration completed successfully")
        write_to_log(f"Database created at: {db_path}")

    except Exception as e:
        console.print(f"\n[bold red]✗ Migration failed:[/bold red] {e}")
        write_to_log(f"Data migration failed: {e}")
        raise click.ClickException(str(e)) from e


@click.command()
@click.option("--force", is_flag=True, help="Force database reset (will delete all existing data)")
def reset(force: bool = False) -> None:
    """Reset the database (delete all data)."""

    db_manager = get_database_manager()
    console.print(f"Database location: {db_manager.db_path}")

    # Set up logging to database.log in the central logs directory
    database_log_file = get_database_log_file()

    def write_to_log(message: str) -> None:
        timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        entry = f"[{timestamp}] {message}"
        with open(database_log_file, "a") as f:
            f.write(f"{entry}\n")

    # Log the command and context
    write_to_log("Command run: db reset")
    write_to_log(f"Database location: {db_manager.db_path}")

    if not force:
        write_to_log("User confirmation required for database reset")
        if not _confirm_on_new_line("Are you sure you want to delete all database data?"):
            console.print("Database reset cancelled.")
            write_to_log("User cancelled database reset")
            return
        write_to_log("User confirmed database reset")
    else:
        write_to_log("Database reset running with --force (no confirmation)")

    try:
        # Close existing connection
        write_to_log("Closing database connection before reset")
        db_manager.close()

        # Delete database file
        if db_manager.db_path.exists():
            db_manager.db_path.unlink()
            console.print("[green]✓ Database deleted[/green]")
            write_to_log("Database file deleted successfully")
        else:
            console.print("[yellow]Database file does not exist[/yellow]")
            write_to_log("Database file did not exist at reset time")

        # Reinitialize database (this will run migrations)
        write_to_log("Reinitializing database after reset")
        db_manager.initialize_database()
        console.print("[green]✓ Database reinitialized[/green]")
        write_to_log("Database reset and reinitialization completed successfully")

    except Exception as e:
        console.print(f"[bold red]✗ Database reset failed:[/bold red] {e}")
        write_to_log(f"Database reset failed: {e}")
        raise click.ClickException(str(e)) from e


@click.command()
@click.option("--version", type=int, help="Migrate to specific version")
@click.option("--status", "show_status", is_flag=True, help="Show migration status")
def migrate_schema(version: int | None = None, show_status: bool = False) -> None:
    """Run database schema migrations."""

    try:
        db_manager = get_database_manager()
        runner = MigrationRunner(db_manager)

        if show_status:
            status_obj = runner.get_migration_status()
            console.print("[bold cyan]Migration Status[/bold cyan]")
            console.print(f"Current version: {status_obj.current_version or 'None'}")
            console.print(f"Latest version: {status_obj.latest_version or 'None'}")
            console.print(f"Pending migrations: {len(status_obj.pending_migrations)}")

            if status_obj.pending_migrations:
                console.print("\n[bold]Pending migrations:[/bold]")
                for migration in status_obj.pending_migrations:
                    console.print(
                        f"  {migration.version:03d}: {migration.description or migration.filename}"
                    )

            if status_obj.is_up_to_date:
                console.print("\n[green]✓ Database is up to date[/green]")
            return

        if version is not None:
            console.print(f"Migrating to version {version}...")
            runner.migrate_to_version(version)
        else:
            console.print("Migrating to latest version...")
            runner.migrate_to_latest()

        console.print("[green]✓ Migration completed successfully[/green]")

    except ImportError as e:
        console.print(f"[bold red]✗ Migration system not available:[/bold red] {e}")
        console.print("[yellow]Falling back to legacy initialization...[/yellow]")

        # Fallback to legacy database initialization
        db_manager = get_database_manager()
        if hasattr(db_manager, "_legacy_initialize_database"):
            db_manager._legacy_initialize_database()
        else:
            console.print("[yellow]Legacy initialization not available[/yellow]")

    except Exception as e:
        console.print(f"[bold red]✗ Migration failed:[/bold red] {e}")
        raise click.ClickException(str(e)) from e


@click.command()
@click.option("--version", type=int, required=True, help="Migration version to rollback")
def rollback_migration(version: int) -> None:
    """Rollback a migration."""

    # Set up logging to database.log in the central logs directory
    database_log_file = get_database_log_file()

    def write_to_log(message: str) -> None:
        timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        entry = f"[{timestamp}] {message}"
        with open(database_log_file, "a") as f:
            f.write(f"{entry}\n")

    write_to_log(f"Command run: db rollback-migration (version={version})")

    try:
        db_manager = get_database_manager()
        runner = MigrationRunner(db_manager)

        if not _confirm_on_new_line(f"Rollback migration {version}? This will undo the changes."):
            console.print("Rollback cancelled.")
            write_to_log(f"User cancelled rollback for migration {version}")
            return

        write_to_log(f"Starting rollback for migration {version}")
        runner.rollback_migration(version)
        console.print(f"[green]✓ Rolled back migration {version}[/green]")
        write_to_log(f"Rollback of migration {version} completed successfully")

    except ImportError as e:
        console.print(f"[bold red]✗ Migration system not available:[/bold red] {e}")
        write_to_log(f"Rollback migration failed (migration system not available): {e}")

    except Exception as e:
        console.print(f"[bold red]✗ Rollback failed:[/bold red] {e}")
        raise click.ClickException(str(e)) from e


@click.command()
@click.option("--name", required=True, help="Migration name (snake_case)")
def create_migration_file(name: str) -> None:
    """Create a new migration file."""

    # Set up logging to database.log in the central logs directory
    database_log_file = get_database_log_file()

    def write_to_log(message: str) -> None:
        timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        entry = f"[{timestamp}] {message}"
        with open(database_log_file, "a") as f:
            f.write(f"{entry}\n")

    write_to_log(f"Command run: db create-migration-file (name={name})")

    try:
        db_manager = get_database_manager()
        runner = MigrationRunner(db_manager)

        # Get next version number
        migrations = runner.load_migrations()
        next_version = max([m.version for m in migrations], default=0) + 1

        # Create migration filename
        filename = f"{next_version:03d}_{name}.sql"
        filepath = runner.migrations_dir / filename

        # Create migration template
        template = f"""-- Migration: {filename}
-- Purpose: [Add migration purpose here]
-- Description: [Add detailed description here]

BEGIN TRANSACTION;

-- Add your migration SQL here

-- Rollback: [Add rollback SQL here]

COMMIT;
"""

        filepath.write_text(template)
        console.print(f"[green]✓ Created migration: {filename}[/green]")
        console.print(f"Location: {filepath}")
        write_to_log(f"Created migration file {filename} at {filepath}")

    except ImportError as e:
        console.print(f"[bold red]✗ Migration system not available:[/bold red] {e}")
        write_to_log(f"create-migration-file failed (migration system not available): {e}")

    except Exception as e:
        console.print(f"[bold red]✗ Failed to create migration:[/bold red] {e}")
        raise click.ClickException(str(e)) from e


@click.command()
@click.option("--version", type=int, required=True, help="Migration version to rollback")
def rollback(version: int) -> None:
    """Rollback a migration."""

    # Set up logging to database.log in the central logs directory
    database_log_file = get_database_log_file()

    def write_to_log(message: str) -> None:
        timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        entry = f"[{timestamp}] {message}"
        with open(database_log_file, "a") as f:
            f.write(f"{entry}\n")

    write_to_log(f"Command run: db rollback (version={version})")

    try:
        db_manager = get_database_manager()
        runner = MigrationRunner(db_manager)

        if not _confirm_on_new_line(f"Rollback migration {version}? This will undo the changes."):
            console.print("Rollback cancelled.")
            write_to_log(f"User cancelled rollback for migration {version}")
            return

        write_to_log(f"Starting rollback for migration {version}")
        runner.rollback_migration(version)
        console.print(f"[green]✓ Rolled back migration {version}[/green]")
        write_to_log(f"Rollback of migration {version} completed successfully")

    except ImportError as e:
        console.print(f"[bold red]✗ Migration system not available:[/bold red] {e}")
        write_to_log(f"Rollback failed (migration system not available): {e}")

    except Exception as e:
        console.print(f"[bold red]✗ Rollback failed:[/bold red] {e}")
        raise click.ClickException(str(e)) from e


@click.command()
@click.option("--name", required=True, help="Migration name (snake_case)")
def create_migration(name: str) -> None:
    """Create a new migration file."""

    try:
        db_manager = get_database_manager()
        runner = MigrationRunner(db_manager)

        # Get next version number
        migrations = runner.load_migrations()
        next_version = max([m.version for m in migrations], default=0) + 1

        # Create migration filename
        filename = f"{next_version:03d}_{name}.sql"
        filepath = runner.migrations_dir / filename

        # Create migration template
        template = f"""-- Migration: {filename}
-- Purpose: [Add migration purpose here]
-- Description: [Add detailed description here]

BEGIN TRANSACTION;

-- Add your migration SQL here

-- Rollback: [Add rollback SQL here]

COMMIT;
"""

        filepath.write_text(template)
        console.print(f"[green]✓ Created migration: {filename}[/green]")
        console.print(f"Location: {filepath}")

    except ImportError as e:
        console.print(f"[bold red]✗ Migration system not available:[/bold red] {e}")

    except Exception as e:
        console.print(f"[bold red]✗ Failed to create migration:[/bold red] {e}")
        raise click.ClickException(str(e)) from e


@click.command()
def status() -> None:
    """Show database status and statistics."""
    provisional_manager = DatabaseManager()
    expected_db_path = provisional_manager.db_path
    legacy_db_path = get_legacy_database_path()
    database_log_file = get_database_log_file()

    try:
        _log_and_print_status(
            database_log_file=database_log_file,
            message="Command run: db status",
            console_message="[bold cyan]Database Status Check[/bold cyan]",
        )

        db_exists = expected_db_path.exists()
        _write_status_context(
            database_log_file=database_log_file,
            expected_db_path=expected_db_path,
            legacy_db_path=legacy_db_path,
            db_exists=db_exists,
        )

        console.print(f"Location: {expected_db_path}")
        console.print(f"File exists: {db_exists}")

        if not db_exists:
            if _handle_missing_database_status(database_log_file):
                return

        db_manager = get_database_manager()
        if not db_manager.db_path.exists():
            return

        _append_database_log(database_log_file, "Database exists - gathering statistics")
        db_ops = DatabaseOperations()
        clients = db_ops.list_clients()
        _append_database_log(database_log_file, f"Found {len(clients)} clients in database")
        stats = _gather_database_content_stats(db_ops, database_log_file, clients)

        _append_database_log(database_log_file, "Statistics gathering complete")
        _append_database_log(
            database_log_file,
            "Final statistics - "
            f"Projects: {stats.total_projects}, "
            f"Sessions: {stats.total_sessions}, "
            f"Screenshots: {stats.total_screenshots}, "
            f"Notes: {stats.total_notes}, "
            f"Captions: {stats.total_captions}",
        )
        _print_status_stats(len(clients), stats)
        _log_and_print_status(
            database_log_file=database_log_file,
            message="Database status check completed successfully",
            console_message="[green]✓ Status check completed successfully[/green]",
        )

    except Exception as e:
        _append_database_log(database_log_file, f"Failed to get database status: {e}")
        console.print(f"[bold red]✗ Failed to get database status:[/bold red] {e}")


@click.command()
@click.option(
    "--output-dir",
    type=click.Path(exists=True, path_type=Path),
    help="Directory to save the verification report (defaults to screenshots directory)",
)
def verify_screenshots(output_dir: Path | None = None) -> None:
    """Verify that screenshots in the database actually exist on the filesystem."""

    output_dir = _resolve_verification_output_dir(output_dir)
    db_for_log = DatabaseOperations()
    database_log_file = get_database_log_file()

    _append_database_log(database_log_file, "Command run: db verify-screenshots")
    _append_database_log(database_log_file, f"Database location: {db_for_log.db.db_path}")
    _append_database_log(database_log_file, f"Report directory: {output_dir}")

    console.print("[bold cyan]Screenshot Verification[/bold cyan]")
    console.print(f"Database location: {db_for_log.db.db_path}")
    console.print(f"Report directory: {output_dir}")

    try:
        db_ops = db_for_log
        screenshots = db_ops.list_all_screenshots()

        if not screenshots:
            console.print("[yellow]No screenshots found in database[/yellow]")
            _append_database_log(
                database_log_file, "No screenshots found in database for verification"
            )
            return

        console.print(f"Checking {len(screenshots)} screenshots...")
        _append_database_log(
            database_log_file,
            f"Starting screenshot verification for {len(screenshots)} records",
        )

        existing_files, missing_files, total_size = _scan_screenshot_file_presence(screenshots)
        report_path = _build_verification_report_path(output_dir)
        _write_verification_report(
            VerificationReportData(
                report_path=report_path,
                db_path=db_for_log.db.db_path,
                screenshots=screenshots,
                existing_files=existing_files,
                missing_files=missing_files,
                total_size=total_size,
            )
        )
        _print_verification_summary(
            report_path,
            len(screenshots),
            len(existing_files),
            len(missing_files),
            total_size,
        )

        _append_database_log(
            database_log_file,
            f"Screenshot verification report saved to: {report_path}",
        )
        _append_database_log(
            database_log_file,
            f"Verification summary - total: {len(screenshots)}, "
            f"existing: {len(existing_files)}, missing: {len(missing_files)}, "
            f"total_size_mb: {total_size / (1024 * 1024):.2f}",
        )

        if missing_files:
            console.print(f"\n[bold red]⚠ {len(missing_files)} files are missing![/bold red]")
            _append_database_log(
                database_log_file,
                f"Verification completed with {len(missing_files)} missing files",
            )
        else:
            console.print("\n[green]✓ All screenshot files are present![/green]")
            _append_database_log(
                database_log_file,
                "Verification completed - all screenshot files present",
            )

    except Exception as e:
        console.print(f"[bold red]✗ Verification failed:[/bold red] {e}")
        _append_database_log(database_log_file, f"Screenshot verification failed: {e}")
        raise click.ClickException(str(e)) from e


@click.group(invoke_without_command=True)
@click.pass_context
def database(ctx) -> None:
    """Database management commands."""
    if ctx.invoked_subcommand is None:
        interactive_database_menu()


# Add subcommands
database.add_command(migrate)
database.add_command(reset)
database.add_command(status)
database.add_command(verify_screenshots)
database.add_command(migrate_schema)
database.add_command(rollback_migration)
database.add_command(create_migration_file)


if __name__ == "__main__":
    database()
