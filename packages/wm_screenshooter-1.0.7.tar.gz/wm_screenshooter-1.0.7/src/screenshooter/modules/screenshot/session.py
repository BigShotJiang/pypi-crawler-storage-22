#!/usr/bin/env python3
"""Session information model for screenshot sessions."""

from datetime import datetime

from pydantic import BaseModel, Field, field_validator


class SessionInfo(BaseModel):
    """Session information model."""

    session_name: str
    session_start_time: str
    session_finish_time: str = ""
    client_name: str
    project_name: str
    timer: str
    archived_at: str = ""
    notes: list[str] = Field(default_factory=list)
    captions: dict[int, str] = Field(default_factory=dict)
    set_captions: dict[int, str] = Field(default_factory=dict)
    last_updated: str = Field(default_factory=lambda: datetime.now().strftime("%Y-%m-%d %H:%M:%S"))

    @field_validator("timer", mode="before")
    @classmethod
    def validate_timer(cls, v) -> str:
        """Convert any timer input to string."""
        return str(v)
