"""wmiexec-ng: Execute commands via WMI without 445 open, with output retrieval over HTTPS."""

__version__ = "1.0.2"