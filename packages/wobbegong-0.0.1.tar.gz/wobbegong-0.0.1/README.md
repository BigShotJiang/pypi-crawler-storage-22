[![PyPI-Server](https://img.shields.io/pypi/v/wobbegong.svg)](https://pypi.org/project/wobbegong/)
![Unit tests](https://github.com/YOUR_ORG_OR_USERNAME/wobbegong/actions/workflows/run-tests.yml/badge.svg)

# wobbegong

> Range-request ready Bioconductor objects

A longer description of your project goes here...

## Install

To get started, install the package from [PyPI](https://pypi.org/project/wobbegong/)

```bash
pip install wobbegong
```

<!-- biocsetup-notes -->

## Note

This project has been set up using [BiocSetup](https://github.com/biocpy/biocsetup)
and [PyScaffold](https://pyscaffold.org/).
