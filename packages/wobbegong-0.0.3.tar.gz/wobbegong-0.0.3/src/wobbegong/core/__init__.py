from .wobbegongify import wobbegongify

from ._frame import wobbegongify_frame
from ._matrix import wobbegongify_matrix
from ._se import wobbegongify_se

__author__ = "Jayaram Kancherla"
__copyright__ = "Jayaram Kancherla"
__license__ = "MIT"
