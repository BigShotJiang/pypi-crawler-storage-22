# Changelog

## Version 0.0.1 - 0.0.4

- Initial implementation.
- Support lz4 compression, in addition to zlib (default)
