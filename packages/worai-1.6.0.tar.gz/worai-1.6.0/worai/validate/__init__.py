"""SHACL validation resources."""
