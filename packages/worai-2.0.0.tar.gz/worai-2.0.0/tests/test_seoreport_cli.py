from __future__ import annotations

from typer.testing import CliRunner

from worai.config import Config
import worai.seoreport.cli as seoreport_cli


class DummyTemplate:
    def render(self, data):
        return ""


class DummyEnv:
    def __init__(self, loader):
        self.loader = loader

    def get_template(self, name):
        return DummyTemplate()


def test_seoreport_uses_config_site(monkeypatch, tmp_path):
    monkeypatch.setattr(seoreport_cli, "Environment", DummyEnv)
    monkeypatch.setattr(seoreport_cli, "generate_report_data", lambda options: {})

    output_path = tmp_path / "report.md"
    runner = CliRunner()
    config = Config(raw={"gsc": {"id": "sc-domain:example.com"}})

    result = runner.invoke(
        seoreport_cli.app,
        ["--output", str(output_path)],
        obj={"config": config},
    )

    assert result.exit_code == 0
    assert "Generating markdown report for sc-domain:example.com" in result.output
