"""CLI wrapper for graph workflows."""

from __future__ import annotations

import typer

from worai.config import resolve_config_path
from worai.core.graph import GraphSyncOptions, run_graph_sync
from worai.errors import UsageError

app = typer.Typer(add_completion=False, no_args_is_help=True)


@app.command("sync", no_args_is_help=True)
def sync(
    ctx: typer.Context,
    profile: str = typer.Option(..., "--profile", help="Profile name in worai.toml."),
    debug: bool = typer.Option(
        False,
        "--debug",
        help="Write generated callback graphs to output/debug_cloud/<profile>/.",
    ),
) -> None:
    try:
        config_path = (ctx.obj or {}).get("config_path") if ctx else None
        run_graph_sync(
            GraphSyncOptions(
                profile=profile,
                config_path=config_path or resolve_config_path(None),
                debug=debug,
            )
        )
    except ValueError as exc:
        raise UsageError(str(exc)) from exc
