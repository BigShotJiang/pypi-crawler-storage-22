"""Shared core logic."""
