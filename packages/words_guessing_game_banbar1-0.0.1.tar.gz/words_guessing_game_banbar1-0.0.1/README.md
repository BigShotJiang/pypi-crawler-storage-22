# Words Guessing Game - Pygame UI Version

A Wordle-style word guessing game with a graphical user interface built using Pygame.

## Features

- **Wordle-inspired visual design** with color-coded feedback
- **Dual input system**: Use physical keyboard or on-screen virtual keyboard
- **Customizable difficulty**: Choose attempts (1-10) and word length (3-11)
- **Color-coded feedback**:
  - 🟩 Green: Letter in correct position
  - 🟨 Yellow: Letter in word but wrong position
  - ⬜ Gray: Letter not in word
- **Virtual keyboard tracking**: See which letters you've tried and their status

## Requirements

- Python 3.7+
- pygame
- nltk (already installed for the console version)

## Installation

If pygame is not installed, run:
```bash
pip install pygame
```

## How to Run

### Pygame UI Version (NEW):
```bash
python game_with_ui.py
```

### Original Console Version:
```bash
python start_game.py
```

## How to Play

1. **Setup Screen**:
   - Select the number of attempts (1-10)
   - Select word length (3-11 characters)
   - Click "START GAME"

2. **Game Screen**:
   - Type your guess using your keyboard OR click letters on the virtual keyboard
   - Press ENTER or click "SUBMIT" to submit your guess
   - Watch the color-coded feedback:
     - Green tiles: Correct letter in correct position
     - Yellow tiles: Correct letter in wrong position
     - Gray tiles: Letter not in the word
   - Press ESC to restart the game

3. **End Screen**:
   - See your final result (Win or Lose)
   - View the correct word
   - Click "PLAY AGAIN" to start a new game
   - Click "EXIT" to quit

## Game Rules

- Words must be exactly the length you selected
- Words must contain only English letters (A-Z)
- Words must be in the English dictionary
- You have a limited number of attempts based on your selection

## Controls

### Physical Keyboard:
- **A-Z**: Type letters
- **BACKSPACE**: Delete last letter
- **ENTER**: Submit guess
- **ESC**: Return to setup screen

### Mouse:
- Click on virtual keyboard letters
- Click "SUBMIT" button to submit guess
- Click "←" button to delete last letter

## File Structure

```
FirstGame/
├── game_with_ui.py          # Main pygame entry point (NEW)
├── start_game.py            # Original console version
├── ui/                      # UI components (NEW)
│   ├── __init__.py
│   ├── constants.py         # Colors, dimensions, fonts
│   ├── ui_components.py     # Reusable UI components
│   ├── setup_screen.py      # Setup screen
│   ├── game_screen.py       # Main game screen
│   └── end_screen.py        # Win/loss screen
└── functions/               # Game logic (unchanged)
    ├── find.py
    ├── print.py
    ├── validation.py
    ├── UserInputIntReader.py
    └── nltk_functions.py
```

## Technical Notes

- The pygame UI reuses all existing game logic from the `functions/` directory
- The original console version (`start_game.py`) remains fully functional
- NLTK word dictionary will download automatically on first run (if not already cached)
- Screen size: 600x800 pixels
- FPS: 60

## Tips

- Start with easier settings (6 attempts, 5-letter words) to get familiar with the game
- Watch the virtual keyboard to track which letters you've already tried
- Common letters like E, A, R, I, O, T are good starting guesses

## Troubleshooting

**Issue**: Game window doesn't open
- Make sure pygame is installed: `pip install pygame`
- Check that your Python version is 3.7 or higher

**Issue**: "Word not in dictionary" error for common words
- The game uses NLTK's English word corpus
- Make sure NLTK data is downloaded (happens automatically on first run)

**Issue**: Slow performance
- Try reducing word length or attempts if on older hardware
- The game runs at 60 FPS on most modern systems

## Credits

Created using:
- **Pygame**: Game framework
- **NLTK**: English word dictionary
- Inspired by Wordle

Enjoy the game!
