"""
Game Screen for Word Guessing Game
Main gameplay interface with grid, input, and virtual keyboard
"""

import pygame
from . import constants
from .constants import COLORS, SCREEN_WIDTH, SCREEN_HEIGHT, GRID_TOP_MARGIN, TILE_SPACING
from .ui_components import Grid, VirtualKeyboard


class GameScreen:
    """Main game screen with word grid and keyboard"""

    def __init__(self):
        """Initialize game screen"""
        self.grid = None
        self.virtual_keyboard = VirtualKeyboard()
        self.error_message = ""
        self.error_timer = 0  # Timer to fade out error message

    def initialize_grid(self, max_attempts, word_length):
        """
        Initialize grid with game parameters

        Args:
            max_attempts: Maximum number of attempts
            word_length: Length of the word
        """
        self.grid = Grid(max_attempts, word_length)
        self.virtual_keyboard.reset()
        self.error_message = ""

    def handle_event(self, event, game_manager):
        """
        Handle events for the game screen

        Args:
            event: Pygame event
            game_manager: GameManager instance
        """
        # Handle physical keyboard input
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_RETURN or event.key == pygame.K_KP_ENTER:
                # Submit guess
                self._submit_guess(game_manager)

            elif event.key == pygame.K_BACKSPACE:
                # Remove last letter
                if game_manager.current_input:
                    game_manager.current_input = game_manager.current_input[:-1]
                    self.error_message = ""  # Clear error on new input

            elif event.key == pygame.K_ESCAPE:
                # Return to setup (optional - could add confirmation dialog)
                
                game_manager.reset_game()

            else:
                # Add letter if it's A-Z
                if event.unicode.isalpha() and len(game_manager.current_input) < game_manager.word_length:
                    game_manager.current_input += event.unicode.upper()
                    self.error_message = ""  # Clear error on new input

        # Handle virtual keyboard clicks
        elif event.type == pygame.MOUSEBUTTONDOWN:
            mouse_pos = pygame.mouse.get_pos()
            mouse_pressed = pygame.mouse.get_pressed()

            action_type, value = self.virtual_keyboard.handle_click(mouse_pos, mouse_pressed)

            if action_type == 'letter':
                # Add letter
                if len(game_manager.current_input) < game_manager.word_length:
                    game_manager.current_input += value
                    self.error_message = ""

            elif action_type == 'backspace':
                # Remove last letter
                if game_manager.current_input:
                    game_manager.current_input = game_manager.current_input[:-1]
                    self.error_message = ""

            elif action_type == 'submit':
                # Submit guess
                self._submit_guess(game_manager)

    def _submit_guess(self, game_manager):
        """
        Submit the current guess and process it

        Args:
            game_manager: GameManager instance
        """
        if not game_manager.current_input:
            return

        # Attempt to submit guess
        success, error = game_manager.submit_guess(game_manager.current_input)

        if not success:
            # Show error message
            self.error_message = error
            self.error_timer = 180  # Show for 3 seconds at 60 FPS
        else:
            # Clear error and input
            self.error_message = ""
            game_manager.current_input = ""

            # Update virtual keyboard states
            self.virtual_keyboard.update_letter_states(game_manager.guesses, game_manager.guess_word)

    def update(self, game_manager):
        """
        Update game screen state

        Args:
            game_manager: GameManager instance
        """
        # Fade out error message
        if self.error_timer > 0:
            self.error_timer -= 1
            if self.error_timer == 0:
                self.error_message = ""

    def render(self, screen, game_manager):
        """
        Render the game screen

        Args:
            screen: Pygame screen surface
            game_manager: GameManager instance
        """
        # Clear screen
        screen.fill(COLORS['background'])

        # Draw title
        title_surface = constants.FONTS['header'].render("WORD GUESSING GAME", True, COLORS['text_white'])
        title_rect = title_surface.get_rect(center=(SCREEN_WIDTH // 2, 40))
        screen.blit(title_surface, title_rect)

        # Draw info bar (attempts remaining)
        info_text = f"Attempts: {game_manager.attempts_remaining}/{game_manager.attempts_total}  |  Length: {game_manager.word_length}"
        info_surface = constants.FONTS['small'].render(info_text, True, COLORS['text_white'])
        info_rect = info_surface.get_rect(center=(SCREEN_WIDTH // 2, 80))
        screen.blit(info_surface, info_rect)

        # Render grid if initialized
        if self.grid:
            self.grid.render(screen, game_manager.guesses, game_manager.current_input)

        # Render current input display (below grid)
        input_y = GRID_TOP_MARGIN + game_manager.attempts_total * (self.grid.tile_size + TILE_SPACING) + 10
        input_text = f"Current: {game_manager.current_input}{'_' * (game_manager.word_length - len(game_manager.current_input))}"
        input_surface = constants.FONTS['normal'].render(input_text, True, COLORS['text_white'])
        input_rect = input_surface.get_rect(center=(SCREEN_WIDTH // 2, input_y))
        screen.blit(input_surface, input_rect)

        # Render error message if present
        if self.error_message:
            error_surface = constants.FONTS['small'].render(self.error_message, True, COLORS['error'])
            error_rect = error_surface.get_rect(center=(SCREEN_WIDTH // 2, input_y + 30))
            screen.blit(error_surface, error_rect)

        # Render virtual keyboard
        self.virtual_keyboard.render(screen)

        # Draw instructions at bottom
        instructions = "Type or click letters | ENTER/SUBMIT to guess | ESC to restart"
        instructions_surface = constants.FONTS['small'].render(instructions, True, COLORS['text_white'])
        instructions_rect = instructions_surface.get_rect(center=(SCREEN_WIDTH // 2, SCREEN_HEIGHT - 20))
        screen.blit(instructions_surface, instructions_rect)
