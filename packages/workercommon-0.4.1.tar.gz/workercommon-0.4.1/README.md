# Requirements

1. Python 3.8
2. A Unix-like OS for `fcntl` support
3. [psycopg2](https://www.psycopg.org/)
4. [Pika](https://pika.readthedocs.io/en/stable/)
