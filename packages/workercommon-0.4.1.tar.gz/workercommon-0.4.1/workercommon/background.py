#!/usr/bin/env python3
import sys

if sys.version_info < (3, 8):
    raise RuntimeError("At least Python 3.8 is required")

import logging, os, asyncio
from typing import Optional, Callable, Union, Dict
from threading import Thread, Lock
from time import sleep
from uuid import uuid1, UUID
from asyncio.events import AbstractEventLoop


class BackgroundThread(Thread):
    def __init__(self, niceness: int = 0):
        super().__init__()
        self.lock = Lock()
        self.loop: Optional[AbstractEventLoop] = None
        self.handles: Dict[UUID, asyncio.Handle] = {}
        self.niceness = niceness

    def submit(self, func: Callable[[], None], delay: Union[int, float]) -> None:
        with self.lock:
            if not self.loop:
                raise RuntimeError("Loop has already been stopped")

            while not self.loop.is_running() and not self.loop.is_closed():
                sleep(0.25)
            if self.loop.is_closed() or not self.loop.is_running():
                raise RuntimeError("Loop has already been stopped")

            self.loop.call_soon_threadsafe(self.submit_inner, func, delay)

    def submit_inner(self, func: Callable[[], None], delay: Union[int, float]) -> UUID:
        with self.lock:
            if not self.loop:
                raise RuntimeError("Loop has already been stopped")

            handle_id = uuid1()

            def task():
                try:
                    func()
                finally:
                    with self.lock:
                        try:
                            del self.handles[handle_id]
                        except KeyError:
                            pass

            logging.debug(f"Submitting task {handle_id} to be run later ({delay})")
            self.handles[handle_id] = self.loop.call_later(delay, task)
            return handle_id

    def stop(self) -> None:
        with self.lock:
            for task in self.handles.values():
                task.cancel()
            if self.loop is not None:
                self.loop.stop()

    def run(self) -> None:
        os.nice(self.niceness)
        with self.lock:
            loop = self.loop = asyncio.new_event_loop()

        try:
            loop.run_forever()
        finally:
            with self.lock:
                self.loop = None
