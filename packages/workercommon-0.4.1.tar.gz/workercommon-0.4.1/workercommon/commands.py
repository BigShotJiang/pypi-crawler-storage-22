#!/usr/bin/env python3
import sys

if sys.version_info < (3, 5):
    raise RuntimeError("At least Python 3.5 is required")

from functools import partial
from typing import Generator, Tuple, Any


class CommandElement(object):
    def __init__(self, name: str, exclusive_lock: bool, function: Any):
        self.name, self.function, self.exclusive_lock = name, function, exclusive_lock

    def __call__(self, *args, **kwargs):
        self.function(*args, **kwargs)


def Command(name: str, exclusive_lock: bool = True):
    return partial(CommandElement, name, exclusive_lock)


class Commands(object):
    @classmethod
    def get_commands(cls) -> Generator[Tuple[str, CommandElement], None, None]:
        for key in dir(cls):
            value = getattr(cls, key)
            if isinstance(value, CommandElement):
                yield value.name, value

    def load_command(self, name: str):
        for cmd_name, value in self.get_commands():
            if name == cmd_name:
                return partial(value, self)
        else:
            raise ValueError("Unknown command: %s" % name)

    def run_command(self, name: str, *args):
        self.load_command(name)(*args)

    def close(self):
        pass
