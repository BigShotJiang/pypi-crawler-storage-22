#!/usr/bin/env python3
import sys

if sys.version_info < (3, 8):
    raise RuntimeError("At least Python 3.8 is required")

from configparser import ConfigParser
import logging
from logging.handlers import WatchedFileHandler
from typing import Tuple, Optional, Callable
from pathlib import Path


class Configuration(object):
    def __init__(self, filename: str):
        self.parser = self.create_parser()
        self.set_base_config(self.parser)
        self.parser.read(filename)
        self.check_all_values(self.parser)

    def create_parser(self) -> ConfigParser:
        return ConfigParser()

    def set_base_config(self, parser: ConfigParser) -> None:
        pass

    def check_all_values(self, parser: ConfigParser) -> None:
        pass

    @staticmethod
    def dir_exists(s: str) -> bool:
        return bool(s and Path(s).is_dir())

    def check_value(
        self, section: str, key: str, validator: Callable[[str], bool]
    ) -> None:
        value: Optional[str] = self[section, key]
        try:
            if value is None or not validator(value):
                raise ValueError
        except:
            raise ValueError(f"Invalid {section}/{key} value: {value}")

    def __getitem__(self, parts: Tuple[str, str]) -> Optional[str]:
        section, key = parts

        try:
            value = self.parser[section][key]
            return value if value else None
        except KeyError:
            return None

    def get_strict(self, section: str, key: str) -> str:
        value = self[section, key]
        if value is None:
            raise ValueError(f"Missing {section}/{key} value")

        return value

    def get(self, section: str, key: str, default: str) -> str:
        value = self[section, key]
        return value if value is not None else default

    def configure_logging(self, *handlers) -> None:
        level = self["Logging", "level"]
        if not level:
            raise RuntimeError("Logging level should have already been validated")

        log_format = self["Logging", "format"]
        if not log_format:
            log_format = "[%(asctime)s] [%(levelname)s] [%(module)s] [%(filename)s:%(lineno)d %(funcName)s] %(message)s"

        if handlers:
            logging.basicConfig(level=level, format=log_format, handlers=handlers)
        else:
            fname = self["Logging", "file"]
            if fname:
                handler = WatchedFileHandler(fname)
                logging.basicConfig(level=level, format=log_format, handlers=[handler])
            else:
                logging.basicConfig(level=level, format=log_format, stream=sys.stderr)
