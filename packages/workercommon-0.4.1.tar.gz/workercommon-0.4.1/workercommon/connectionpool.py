#!/usr/bin/env python3
import sys, os

if sys.version_info < (3, 8):
    raise RuntimeError("At least Python 3.8 is required")

import logging
from typing import Callable, Any, Dict, Optional
from functools import lru_cache
from threading import Lock


class Closeable(object):
    def close(self) -> None:
        raise NotImplementedError


class BaseConnectionPool(object):
    def acquire(self) -> Closeable:
        raise NotImplementedError

    def release(self, connection: Closeable) -> None:
        raise NotImplementedError

    def error(self, connection: Closeable) -> None:
        raise NotImplementedError


class ConnectionHandle(object):
    def __init__(self, pool: BaseConnectionPool):
        self.pool = pool
        self.connection: Optional[Closeable] = None

    def __enter__(self):
        if self.connection is not None:
            raise RuntimeError("Already acquired a connection")

        self.connection = self.pool.acquire()
        return self.connection

    def __exit__(self, type, value, traceback):
        if self.connection is None:
            raise RuntimeError("No connection has been acquired")
        try:
            if value is not None:
                self.pool.error(self.connection)
            else:
                self.pool.release(self.connection)
        finally:
            self.connection = None


class ConnectionPool(BaseConnectionPool):
    def __init__(self, connection_src: Callable[[], Closeable]):
        self.connection_src = connection_src
        self.lock = Lock()
        self.connections: Dict[Closeable, bool] = {}

    def acquire(self) -> Closeable:
        with self.lock:
            for connection, in_use in self.connections.items():
                if not in_use:
                    break
            else:
                connection = self.connection_src()

            self.connections[connection] = True
            return connection

    def release(self, connection: Closeable) -> None:
        with self.lock:
            if connection not in self.connections:
                raise RuntimeError(f"Unknown connection: {connection}")
            self.connections[connection] = False

    def error(self, connection: Closeable) -> None:
        with self.lock:
            if connection not in self.connections:
                raise RuntimeError(f"Unknown connection: {connection}")
            try:
                connection.close()
            except:
                logging.exception(f"Failed to close {connection}")
            del self.connections[connection]

    def close(self) -> None:
        with self.lock:
            for connection in self.connections.keys():
                try:
                    connection.close()
                except:
                    logging.exception(f"Failed to close {connection}")

            self.connections.clear()

    def __call__(self) -> ConnectionHandle:
        return ConnectionHandle(self)
