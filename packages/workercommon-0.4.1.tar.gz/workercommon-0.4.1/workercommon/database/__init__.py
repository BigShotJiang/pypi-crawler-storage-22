#!/usr/bin/env python3
import sys

if sys.version_info < (3, 8):
    raise RuntimeError("At least Python 3.8 is required")

from .base import *

try:
    from .pg import (
        Cursor as PgCursor,
        Connection as PgConnection,
        BaseTable as PgBaseTable,
    )
except ImportError:
    pass
