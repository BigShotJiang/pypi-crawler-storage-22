#!/usr/bin/env python3
import sys

if sys.version_info < (3, 8):
    raise RuntimeError("At least Python 3.8 is required")

from typing import Any, Iterator, Dict, List, Sequence, Optional, Iterable, Union, Tuple
import weakref


class BaseConnection(object):
    def get(self) -> Any:
        raise NotImplementedError

    def commit(self) -> None:
        raise NotImplementedError

    def rollback(self) -> None:
        raise NotImplementedError

    def close(self) -> None:
        raise NotImplementedError


class Cursor(object):
    def get(self) -> Any:
        raise NotImplementedError

    def execute_direct(self, query, *args) -> Any:
        raise NotImplementedError

    def execute(self, query, *args) -> Iterator[Dict[str, Any]]:
        raise NotImplementedError

    def __iter__(self) -> Iterator[Dict[str, Any]]:
        raise NotImplementedError

    @property
    def rowcount(self) -> int:
        raise NotImplementedError

    @property
    def columns(self) -> List[str]:
        raise NotImplementedError

    def __enter__(self) -> Any:
        raise NotImplementedError

    def __exit__(self, type, value, traceback) -> None:
        raise NotImplementedError


class Connection(BaseConnection):
    def cursor(self) -> Cursor:
        raise NotImplementedError


class BaseTable(object):
    ORDERINGS = frozenset(["ASC", "DESC"])

    def __init__(
        self,
        name: str,
        primary_key: str,
        columns: Sequence[str],
        ordering: Optional[str] = "ASC",
    ):
        if not name:
            raise ValueError("Invalid name: {name}")

        if not columns:
            raise ValueError(f"Invalid column list: {columns}")

        if not primary_key:
            raise ValueError(f"Invalid column list: {primary_key}")

        self.columns = frozenset(columns)
        if primary_key not in columns:
            raise ValueError(f"{primary_key} is not in columns: {self.columns}")

        self.name, self.primary_key = name, primary_key

        self.ordering = ordering if ordering in self.ORDERINGS else "ASC"

    def validate(self, columns: Iterable[str]) -> None:
        invalid_columns = {col for col in columns if col not in self.columns}
        if invalid_columns:
            raise ValueError(f"Invalid columns: {invalid_columns}")

    @staticmethod
    def unpack(
        items: Union[Dict[str, Any], List[Tuple[str, Any]]]
    ) -> Tuple[Tuple[str], Tuple[Any]]:
        if isinstance(items, dict):
            columns, values = zip(*items.items())
        else:
            columns, values = zip(*items)
        return columns, values

    def insert(self, base_cursor: Cursor, **input_values: Any) -> Any:
        raise NotImplementedError

    def upsert_on_column(
        self,
        base_cursor: Cursor,
        column_name: str,
        column_value: Any,
        **input_values: Any,
    ) -> Any:
        raise NotImplementedError

    def upsert(self, base_cursor: Cursor, column_value: Any, **input_values: Any) -> Any:
        return self.upsert_on_column(
            base_cursor, self.primary_key, column_value, **input_values
        )

    def select_by_columns(
        self, base_cursor: Cursor, limit: Optional[int] = None, **input_values: Any
    ) -> Iterator[Dict[str, Any]]:
        raise NotImplementedError

    def select_custom_where(
        self, base_cursor: Cursor, where: str, *values
    ) -> Iterator[Dict[str, Any]]:
        raise NotImplementedError

    def select_by_id(self, base_cursor: Cursor, pkey_value: Any) -> Dict[str, Any]:
        raise NotImplementedError

    def delete(self, base_cursor: Cursor, pkey_value: Any) -> bool:
        raise NotImplementedError


class TableCursor(object):
    def __init__(self, cursor: Cursor, table: BaseTable):
        self.cursor, self.table = weakref.ref(cursor), table

    def get_cursor(self) -> Cursor:
        cursor = self.cursor()
        if cursor is None:
            raise RuntimeError("Cursor has gone out of scope")
        return cursor

    def insert(self, **input_values: Any) -> Any:
        return self.table.insert(self.get_cursor(), **input_values)

    def upsert_on_column(
        self, column_name: str, column_value: Any, **input_values: Any
    ) -> Any:
        return self.table.upsert_on_column(
            self.get_cursor(), column_name, column_value, **input_values
        )

    def upsert(self, pkey_value: Any, **input_values: Any) -> Any:
        return self.table.upsert(self.get_cursor(), pkey_value, **input_values)

    def __setitem__(self, key: Any, value: Dict[str, Any]) -> Any:
        self.upsert(key, **value)

    def where(
        self, limit: Optional[int], **input_values: Any
    ) -> Iterator[Dict[str, Any]]:
        return self.table.select_by_columns(self.get_cursor(), limit, **input_values)

    def custom_where(self, where: str, *values) -> Iterator[Dict[str, Any]]:
        return self.table.select_custom_where(self.get_cursor(), where, *values)

    def __getitem__(self, key: Any) -> Dict[str, Any]:
        return self.table.select_by_id(self.get_cursor(), key)

    def __delitem__(self, key: Any) -> None:
        if not self.table.delete(self.get_cursor(), key):
            raise KeyError(key)
