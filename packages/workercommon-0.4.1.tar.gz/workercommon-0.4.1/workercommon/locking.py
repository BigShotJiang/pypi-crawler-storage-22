#!/usr/bin/env python3
import sys

if sys.version_info < (3, 8):
    raise RuntimeError("At least Python 3.8 is required")

from sys import stdout, stderr
from os import fchmod
import fcntl, logging
from time import sleep
from typing import Union
from pathlib import Path


class LockFile(object):
    def __init__(self, location: Union[str, Path], exclusive: bool = True):
        self.location = str(location)
        self.fd = None
        self.exclusive = exclusive

    def __enter__(self):
        if self.fd is not None:
            raise RuntimeError("Cannot lock twice")
        self.fd = open(self.location, "w+b")
        if self.fd is None:
            raise RuntimeError(f"Failed to open {self.location}")
        try:
            fchmod(self.fd.fileno(), 0o666)
        except OSError:
            pass

        for i in range(10):
            try:
                mode = fcntl.LOCK_NB
                if self.exclusive:
                    mode |= fcntl.LOCK_EX
                else:
                    mode |= fcntl.LOCK_SH

                logging.debug(f"Attempting to lock file {self.location}")
                fcntl.lockf(self.fd, mode)
                return
            except IOError:
                logging.warning("Waiting for existing lock...")
                sleep(1)
                continue
        raise RuntimeError("The existing bot did not exit in time; dying")

    def __exit__(self, type, value, traceback):
        fcntl.lockf(self.fd, fcntl.LOCK_UN)
        self.fd.close()
        self.fd = None
