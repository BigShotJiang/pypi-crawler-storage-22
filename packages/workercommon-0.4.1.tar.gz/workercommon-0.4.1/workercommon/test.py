#!/usr/bin/env python3
import sys

if sys.version_info < (3, 8):
    raise RuntimeError("At least Python 3.8 is required")
import unittest

from os import environ
from getpass import getpass
import logging
from database import *
from typing import List


class DBTesting(object):
    DB_PASSWORD: List[str] = []

    @classmethod
    def get_password(cls) -> str:
        if not cls.DB_PASSWORD:
            cls.DB_PASSWORD.append(getpass("Password: "))
        return cls.DB_PASSWORD[0]

    @classmethod
    def build_connection(cls) -> Connection:
        host = environ.get("DB_HOST", None)

        port_number = 5432
        if port := environ.get("DB_PORT", ""):
            port_number = int(port)

        username = environ["DB_USER"]
        password = cls.get_password()
        database = environ["DB_DATABASE"]

        return PgConnection(host, port_number, username, password, database)


class TestConnect(unittest.TestCase, DBTesting):
    def test_connect(self):
        self.build_connection().close()


class TestOperations(unittest.TestCase, DBTesting):
    def setUp(self):
        self.connection = self.build_connection()

    def tearDown(self):
        self.connection.close()
        self.connection = None

    def test_cursor(self):
        cursor = self.connection.cursor()
        self.assertIsNotNone(cursor)
        with self.assertRaises(RuntimeError):
            cursor.get()

        with cursor:
            self.assertIsNotNone(cursor.get())

        with self.assertRaises(RuntimeError):
            cursor.get()

    def test_direct_table(self):
        with self.connection.cursor() as cursor:
            cursor.execute("CREATE TEMPORARY TABLE test(value1 INTEGER, value2 TEXT)")
            cursor.execute("INSERT INTO test(value1, value2) VALUES(%s, %s)", 1, "foo")

            # Basic functionality
            row = cursor.execute_direct(
                "SELECT value1, value2 FROM test LIMIT 1"
            ).fetchone()
            self.assertIsNotNone(row)
            self.assertTrue(cursor.columns)
            self.assertEqual(row[0], 1)
            self.assertEqual(row[1], "foo")

            # Advanced functionality
            rows = list(cursor.execute("SELECT value1, value2 FROM test LIMIT 1"))
            self.assertEqual(len(rows), 1)
            dict_row = rows[0]
            self.assertEqual(dict_row["value1"], 1)
            self.assertEqual(dict_row["value2"], "foo")

    def test_table(self):
        table_type = PgBaseTable("table_test", "key", ["key", "value1", "value2"])
        with self.connection.cursor() as cursor:
            table_cursor = TableCursor(cursor, table_type)

            def verify2():
                row = table_cursor[2]
                self.assertTrue(row)
                self.assertEqual(row["key"], 2)
                self.assertEqual(row["value1"], 30)
                self.assertEqual(row["value2"], "brown")

            cursor.execute(
                "CREATE TEMPORARY TABLE table_test(key SERIAL PRIMARY KEY NOT NULL, value1 INTEGER, value2 TEXT)"
            )
            # Test insert and get
            self.assertEqual(table_type.insert(cursor, value1=100, value2="cow"), 1)

            row = table_type.select_by_id(cursor, 1)
            self.assertTrue(row)
            self.assertEqual(row["key"], 1)
            self.assertEqual(row["value1"], 100)
            self.assertEqual(row["value2"], "cow")

            # Test insert again and get
            self.assertEqual(table_type.insert(cursor, value1=30, value2="brown"), 2)

            verify2()

            # Test selecting by other column values
            rows = list(table_cursor.where(100, value1=100))
            self.assertEqual(len(rows), 1)
            row = rows[0]
            self.assertEqual(row["key"], 1)
            self.assertEqual(row["value1"], 100)
            self.assertEqual(row["value2"], "cow")

            # Test custom selecting
            rows = list(table_cursor.custom_where("value1 > %s", 50))
            self.assertEqual(len(rows), 1)
            row = rows[0]
            self.assertEqual(row["key"], 1)
            self.assertEqual(row["value1"], 100)
            self.assertEqual(row["value2"], "cow")

            # Test selecting by other column values where a None is present
            self.assertEqual(table_type.insert(cursor, value1=None, value2="skittle"), 3)
            rows = list(table_cursor.where(100, value1=None))
            self.assertEqual(len(rows), 1)
            row = rows[0]
            self.assertEqual(row["key"], 3)
            self.assertIsNone(row["value1"])
            self.assertEqual(row["value2"], "skittle")

            # Test upserting on an alternate column
            self.assertEqual(
                table_cursor.upsert_on_column("value1", None, value2="1234"), 3
            )
            rows = list(table_cursor.where(100, value1=None))
            self.assertEqual(len(rows), 1)
            row = rows[0]
            self.assertEqual(row["key"], 3)
            self.assertIsNone(row["value1"])
            self.assertEqual(row["value2"], "1234")

            # Test upserting
            table_cursor[1] = {"value1": 200, "value2": "quack"}
            self.assertEqual(table_type.upsert(cursor, 1, value1=200, value2="quack"), 1)

            row = table_type.select_by_id(cursor, 1)
            self.assertTrue(row)
            self.assertEqual(row["key"], 1)
            self.assertEqual(row["value1"], 200)
            self.assertEqual(row["value2"], "quack")

            verify2()

            # Test deletion
            self.assertTrue(table_type.delete(cursor, 1))
            with self.assertRaises(KeyError):
                table_type.select_by_id(cursor, 1)
            verify2()

            self.assertFalse(table_type.delete(cursor, 1))

            with self.assertRaises(KeyError):
                del table_cursor[1]

            del table_cursor[2]


logging.basicConfig(level=logging.DEBUG, stream=sys.stderr)
unittest.main()
