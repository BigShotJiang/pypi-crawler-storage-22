#!/usr/bin/env python3
import sys

if sys.version_info < (3, 8):
    raise RuntimeError("At least Python 3.8 is required")

from .database import Connection, Cursor
from . import rabbitmqueue
import json, pika.connection, pika.channel, pika.spec, logging
from collections.abc import Mapping
from threading import Thread, Lock
from typing import Iterable, Optional, Any, Callable, List
from multiprocessing import Process
from multiprocessing.managers import SyncManager
from concurrent.futures import ThreadPoolExecutor


class NoDatabase(RuntimeError):
    pass


class BaseWorker(object):
    def start(self) -> None:
        raise NotImplementedError

    def stop(self) -> None:
        raise NotImplementedError

    def join(self, timeout: Optional[float] = None) -> None:
        raise NotImplementedError


class ThreadWorker(BaseWorker, Thread):
    def __init__(self):
        BaseWorker.__init__(self)
        Thread.__init__(self)

    def start(self) -> None:
        Thread.start(self)

    def join(self, timeout: Optional[float] = None) -> None:
        Thread.join(self, timeout)


class ReaderWorker(ThreadWorker):
    def __init__(
        self,
        database_source: Optional[Callable[[], Connection]],
        readq_parameters: rabbitmqueue.Parameters,
        any_exchange: bool = False,
        **readq_arguments: Any,
    ):
        super().__init__()
        self.lock = Lock()
        self.readq_parameters = readq_parameters
        self.readq_arguments = readq_arguments
        self.readq: Optional[rabbitmqueue.ReceiveSendQueue] = None

        self.database_source: Optional[Callable[[], Connection]] = database_source
        self.database: Optional[Connection] = None
        self.restart = True
        self.outbox: List[rabbitmqueue.ToSend] = []
        self.any_exchange = any_exchange

        self.callback_pool_lock = Lock()
        self.callback_pool: Optional[ThreadPoolExecutor] = None

    def get_readq(self) -> rabbitmqueue.ReceiveSendQueue:
        if self.readq is None:
            raise RuntimeError("Read rabbitmqueue is not available")
        return self.readq

    def on_start(self) -> None:
        pass

    def on_stop(self) -> None:
        pass

    def run(self) -> None:
        try:
            with self.callback_pool_lock:
                self.callback_pool = ThreadPoolExecutor(
                    max_workers=1, thread_name_prefix="reader-callback"
                )

            self.on_start()

            while self.restart:
                with self.lock:
                    self.restart = False
                    self.readq = rabbitmqueue.ReceiveSendQueue(
                        self.readq_parameters,
                        self.callback,
                        self.maybe_restart,
                        **self.readq_arguments,
                    )
                if self.outbox:
                    with self.lock:
                        if self.readq is not None:
                            self.readq.add_to_outbox(self.outbox)
                            self.outbox.clear()

                try:
                    self.get_readq().run()
                except BaseException:
                    logging.exception("Lost the queue connection")

                with self.lock:
                    if self.readq is not None:
                        self.outbox.extend(self.readq.get_outbox())

                with self.lock:
                    restart = self.restart

                if restart:
                    logging.info("Trying to start a new one")
                    with self.lock:
                        if self.readq is not None:
                            try:
                                self.readq.close()
                            except BaseException:
                                logging.exception("Failed to close existing readq")
                            finally:
                                self.readq = None

                elif self.outbox:
                    logging.info(f"Trying to send outbox: {self.outbox}")
                    rabbitmqueue.SendQueue.quick_send(self.readq_parameters, self.outbox)

        finally:
            try:
                self.on_stop()
            finally:
                self.close()

    def maybe_restart(self, restart: bool, remaining: List[rabbitmqueue.ToSend]) -> None:
        with self.lock:
            self.restart = restart
            self.outbox.extend(remaining)

    def close(self) -> None:
        with self.callback_pool_lock:
            if self.callback_pool is not None:
                self.callback_pool.shutdown()
                self.callback_pool = None

        if self.database_source is not None:
            self.database_source = None

        if self.database is not None:
            self.database.close()
            self.database = None

    def get_cursor(self) -> Cursor:
        if self.database is None:
            if self.database_source is None:
                raise NoDatabase("Database source is unavailable")
            self.database = self.database_source()

        return self.database.cursor()

    def get_callback_pool(self) -> ThreadPoolExecutor:
        with self.callback_pool_lock:
            if self.callback_pool is None:
                raise RuntimeError("callback_pool is not available")

            return self.callback_pool

    def allow_properties(self, properties: pika.spec.BasicProperties) -> bool:
        return True

    def ack(self, channel: pika.channel.Channel, delivery_tag: int) -> None:
        logging.debug(f"ACKing {delivery_tag} in {channel}")
        channel.basic_ack(delivery_tag)

    def nack(self, channel: pika.channel.Channel, delivery_tag: int) -> None:
        logging.debug(f"NACKing {delivery_tag} in {channel}")
        channel.basic_nack(delivery_tag)

    def callback_job(
        self,
        ch: pika.channel.Channel,
        method: pika.spec.Basic.Deliver,
        properties: pika.spec.BasicProperties,
        body: str,
    ) -> None:
        "Run within a background thread"
        try:
            if not self.allow_properties(properties):
                logging.debug(f"Not handling due to properties: {properties}")
                return

            root = json.loads(body)
            filtered = self.filter_message(root)

            if filtered is not None:
                try:
                    with self.get_cursor() as cursor:
                        self.handle_message(cursor, filtered)
                except NoDatabase:
                    self.handle_message_nodb(filtered)

            logging.debug(f"Successfully handled {method.delivery_tag}")
            self.get_readq().add_callback_threadsafe(
                lambda: self.ack(ch, method.delivery_tag)
            )

        except BaseException as e:
            logging.exception(f"Failed to handle message: {e}")
            try:
                self.get_readq().add_callback_threadsafe(
                    lambda: self.nack(ch, method.delivery_tag)
                )
            except BaseException:
                logging.exception(f"Failed to NACK {method.delivery_tag} in {ch}")

    def callback(
        self,
        ch: pika.channel.Channel,
        method: pika.spec.Basic.Deliver,
        properties: pika.spec.BasicProperties,
        body: str,
    ) -> None:
        if self.readq_parameters.exchange:
            if (
                not self.any_exchange
                and method.exchange != self.readq_parameters.exchange
            ):
                return

        try:
            self.get_callback_pool().submit(
                self.callback_job, ch, method, properties, body
            )

        except BaseException as e:
            logging.exception(f"Failed to submit message to callback pool: {e}")
            try:
                self.nack(ch, method.delivery_tag)
            except BaseException:
                logging.exception(f"Failed to NACK {method.delivery_tag} in {ch}")

    def filter_message(self, message: Any) -> Optional[Any]:
        # Return value will be passed on to handle_message(), but only if isn't None.
        raise NotImplementedError

    def handle_message(self, cursor: Cursor, message: Any) -> None:
        raise NotImplementedError

    def handle_message_nodb(self, message: Any) -> None:
        raise NotImplementedError

    def stop(self) -> None:
        with self.lock:
            if self.readq is not None:
                self.readq.close()
                self.outbox.extend(self.readq.get_outbox())
                self.readq = None


class ReaderWorkerWithRetryLimit(ReaderWorker):
    DEATH_HEADER = "x-death"
    COUNT = "count"
    REASON = "reason"
    EXPIRED = "expired"

    def __init__(
        self,
        database_source: Callable[[], Connection],
        readq_parameters: rabbitmqueue.Parameters,
        retry_limit: int,
        any_exchange: bool = False,
        **readq_arguments: Any,
    ):
        if retry_limit < 1:
            raise ValueError(f"Invalid retry limit: {retry_limit}")

        super().__init__(
            database_source,
            readq_parameters,
            any_exchange,
            **readq_arguments,
        )
        self.retry_limit = retry_limit

    def nack(self, channel: pika.channel.Channel, delivery_tag: int) -> None:
        logging.debug(f"NACKing {delivery_tag} in {channel}")
        channel.basic_nack(delivery_tag, requeue=False)

    @classmethod
    def _get_expiration_count(cls, death: Iterable[Mapping[str, Any]]) -> Optional[int]:
        for entry in death:
            if (
                entry.get(cls.REASON) == cls.EXPIRED and
                (count := entry.get(cls.COUNT)) is not None
            ):
                return count
        return None

    def allow_properties(self, properties: pika.spec.BasicProperties) -> bool:
        if not properties.headers:
            return True

        if (death := properties.headers.get(self.DEATH_HEADER)) and isinstance(death, list):
            if (
                (count := self._get_expiration_count(death)) is not None and
                count > self.retry_limit
            ):
                logging.warning(f"Giving up after {count} attempts")
                return False

        return True


class BaseWorkerManager(Process):
    def stop(self) -> None:
        raise NotImplementedError


class WorkerManager(BaseWorkerManager):
    def __init__(
        self,
        manager: SyncManager,
        worker_source: Callable[[BaseWorkerManager], BaseWorker],
        daemon: bool = True,
    ):
        super().__init__(daemon=daemon)
        self.manager = manager
        self.kill_event = manager.Event()
        self.worker_source = worker_source
        self.worker: Optional[BaseWorker] = None

    def run(self) -> None:
        self.worker = self.worker_source(self)
        if self.worker is None:
            raise RuntimeError("Failed to create worker")

        try:
            self.worker.start()
            while True:
                try:
                    if self.kill_event.wait():
                        break
                except KeyboardInterrupt:
                    continue

        finally:
            try:
                self.worker.stop()
                self.worker.join()
            finally:
                self.worker = None

    def stop(self) -> None:
        self.kill_event.set()
