#!/usr/bin/python

from WorkingWithFiles.WorkingWithFiles import *
from WorkingWithFiles.datasetfuncs import *
