"""worktree-mux — a tmux-based viewer for git worktrees."""

__version__ = "0.2.0"
