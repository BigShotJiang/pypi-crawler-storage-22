"""
Agent Session Logic
===================

Single-shot agent that implements ONE feature per invocation.
External driver calls this repeatedly until all features pass.

Flow:
  1. Find first feature with passes=false
  2. Implement the feature
  3. Test the implementation
  4. Update feature_list.json
  5. Exit

Usage:
  python -m ai_engineer.agent                    # Run one feature session
  python -m ai_engineer.agent claude-opus-4-5    # Use specific model

  # External loop (bash):
  while python -m ai_engineer.agent; do sleep 5; done
"""

import asyncio
import json
from datetime import datetime
from pathlib import Path
from typing import Optional

from claude_agent_sdk import ClaudeSDKClient

from .client import create_client
from .progress import print_session_header, print_progress_summary, count_passing_features


PROJECT_DIR = Path(__file__).parent.parent


async def run_agent_session(
    client: ClaudeSDKClient,
    message: str,
) -> tuple[str, str]:
    """
    Run a single agent session.

    Returns:
        (status, response_text)
    """
    print("Sending prompt to Claude Agent...\n")

    try:
        await client.query(message)

        response_text = ""
        async for msg in client.receive_response():
            msg_type = type(msg).__name__

            if msg_type == "AssistantMessage" and hasattr(msg, "content"):
                for block in msg.content:
                    block_type = type(block).__name__

                    if block_type == "TextBlock" and hasattr(block, "text"):
                        response_text += block.text
                        print(block.text, end="", flush=True)
                    elif block_type == "ToolUseBlock" and hasattr(block, "name"):
                        print(f"\n[Tool: {block.name}]", flush=True)

            elif msg_type == "UserMessage" and hasattr(msg, "content"):
                for block in msg.content:
                    if type(block).__name__ == "ToolResultBlock":
                        is_error = getattr(block, "is_error", False)
                        if is_error:
                            print("   [Error]", flush=True)
                        else:
                            print("   [Done]", flush=True)

        print("\n" + "-" * 70 + "\n")
        return "ok", response_text

    except Exception as e:
        print(f"Error: {e}")
        return "error", str(e)


def get_next_feature() -> Optional[dict]:
    """Find the first feature with passes=false."""
    feature_file = PROJECT_DIR / "ai_engineer" / "feature_list.json"

    if not feature_file.exists():
        return None

    with open(feature_file, "r") as f:
        data = json.load(f)

    for category in data["categories"]:
        for test in category["tests"]:
            if not test.get("passes", False):
                return {
                    "id": test["id"],
                    "description": test["description"],
                    "steps": test["steps"],
                    "category": category["name"],
                }

    return None  # All features pass


def get_feature_prompt(feature: dict) -> str:
    """
    Generate prompt for implementing AND testing a feature.

    The agent will:
    1. Implement the feature
    2. Test the implementation
    3. Update feature_list.json if test passes
    """
    steps_str = "\n".join(f"  {i+1}. {step}" for i, step in enumerate(feature["steps"]))

    return f"""# Implement Feature #{feature['id']}: {feature['description']}

Category: {feature['category']}

## Requirements:
{steps_str}

## Your Task:

### Phase 1: Implement
1. Read the codebase to understand current state
2. Implement the feature following existing patterns
3. Ensure code is clean and well-structured
4. Remember: CLI-first, structured output

### Phase 2: Test
After implementing:
1. Run the CLI command to verify it works
2. Check that output is valid JSON (if applicable)
3. Verify error handling works correctly

### Phase 3: Update Status
If the test PASSES:
- Update ai_engineer/feature_list.json
- Change "passes": false to "passes": true for feature #{feature['id']}

If the test FAILS:
- Fix the issues
- Re-test
- Only mark as passing when fully verified

## Important:
- DO NOT mark feature as passing without testing
- All output should be machine-readable (JSON preferred)
- CLI interface is primary, web GUI is secondary
"""


async def run_one_feature(model: str = "claude-sonnet-4-5") -> int:
    """
    Run one feature implementation session.

    Returns:
        0 if feature completed successfully
        1 if error occurred
        2 if all features already pass
    """
    print("\n" + "=" * 70)
    print("  WORLDBOOK - FEATURE DEVELOPMENT SESSION")
    print("  \"Human uses GUI, We uses CLI.\"")
    print("=" * 70)

    # Check progress
    passing, total = count_passing_features(PROJECT_DIR)
    print(f"\nProgress: {passing}/{total} features passing")

    # Find next feature
    feature = get_next_feature()

    if feature is None:
        print("\n[+] All features pass! Nothing to do.")
        return 2

    print(f"\nNext feature: #{feature['id']} - {feature['description']}")
    print(f"Category: {feature['category']}")
    print(f"Model: {model}")
    print()

    # Create client
    client = create_client(PROJECT_DIR, model)

    # Get prompt
    prompt = get_feature_prompt(feature)

    # Run session
    async with client:
        status, response = await run_agent_session(client, prompt)

    # Check result
    if status == "error":
        print("\nSession failed with error")
        return 1

    # Print final progress
    print("\n" + "=" * 70)
    print("  SESSION COMPLETE")
    print("=" * 70)
    print_progress_summary(PROJECT_DIR)

    return 0


async def run_loop(model: str = "claude-sonnet-4-5", max_iterations: Optional[int] = None) -> None:
    """
    Run features in a loop until all pass or max iterations reached.

    This is an INTERNAL loop for convenience. For production use,
    prefer external loop with single invocations for better isolation.
    """
    iteration = 0

    while True:
        iteration += 1

        if max_iterations and iteration > max_iterations:
            print(f"\nReached max iterations ({max_iterations})")
            break

        print(f"\n{'#' * 70}")
        print(f"  ITERATION {iteration}")
        print(f"{'#' * 70}")

        result = await run_one_feature(model)

        if result == 2:  # All features pass
            print("\n[+] All features complete!")
            break
        elif result == 1:  # Error
            print("\nError occurred. Waiting before retry...")
            await asyncio.sleep(10)
        else:  # Success
            print("\nFeature completed. Continuing...")
            await asyncio.sleep(3)


if __name__ == "__main__":
    import sys

    # Parse arguments
    model = "claude-sonnet-4-5"
    max_iter = None
    loop_mode = False

    args = sys.argv[1:]

    for arg in args:
        if arg == "--loop":
            loop_mode = True
        elif arg.startswith("--max="):
            max_iter = int(arg.split("=")[1])
        elif arg.startswith("claude-"):
            model = arg

    # Run
    if loop_mode:
        # Internal loop mode
        asyncio.run(run_loop(model, max_iter))
    else:
        # Single feature mode (recommended for external drivers)
        result = asyncio.run(run_one_feature(model))
        sys.exit(result)
