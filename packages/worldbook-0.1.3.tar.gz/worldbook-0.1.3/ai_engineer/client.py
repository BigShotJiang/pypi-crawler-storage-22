"""
Claude SDK Client Configuration
===============================

Functions for creating and configuring the Claude Agent SDK client for Worldbook development.
"""

import json
from pathlib import Path

from claude_agent_sdk import ClaudeAgentOptions, ClaudeSDKClient


# Built-in tools for development agent
BUILTIN_TOOLS = [
    "Read",
    "Write",
    "Edit",
    "Glob",
    "Grep",
    "Bash",
    "WebFetch",
    "WebSearch",
]


def create_client(
    project_dir: Path,
    model: str = "claude-sonnet-4-5",
) -> ClaudeSDKClient:
    """
    Create a Claude Agent SDK client for Worldbook development.

    Args:
        project_dir: Directory for the project
        model: Claude model to use

    Returns:
        Configured ClaudeSDKClient
    """

    # Build allowed tools list
    allowed_tools = BUILTIN_TOOLS.copy()

    # Create security settings
    security_settings = {
        "sandbox": {"enabled": True, "autoAllowBashIfSandboxed": True},
        "permissions": {
            "defaultMode": "acceptEdits",
            "allow": [
                # Allow file operations within the project directory
                "Read(./**)",
                "Write(./**)",
                "Edit(./**)",
                "Glob(./**)",
                "Grep(./**)",
                # Bash for commands
                "Bash(*)",
                # Web for documentation and API access
                "WebFetch(*)",
                "WebSearch(*)",
            ],
        },
    }

    # Ensure project directory exists
    project_dir.mkdir(parents=True, exist_ok=True)

    # Write settings to a file in the project directory
    settings_file = project_dir / ".claude_settings.json"
    with open(settings_file, "w") as f:
        json.dump(security_settings, f, indent=2)

    print(f"Created security settings at {settings_file}")
    print("   - Sandbox enabled")
    print(f"   - Working directory: {project_dir.resolve()}")
    print()

    system_prompt = """You are an expert developer building Worldbook - an AI-accessible knowledge system.

## Philosophy: Dual Protocol

"Human uses GUI, We uses CLI."

Worldbook provides:
1. CLI interface for AI agents (primary)
2. Web GUI for human observation (secondary)
3. Structured API responses (JSON, not HTML)
4. Machine-readable metadata

## Technical Stack

- Python 3.10+ with Click for CLI
- FastAPI for API server
- Pydantic for data validation
- SQLite/PostgreSQL for knowledge storage
- httpx for async HTTP

## Key Principles

1. **AI-First Design**: Every feature must be accessible via CLI/API
2. **Structured Output**: Always return JSON, never unstructured text
3. **No CAPTCHA**: AI agents are welcome
4. **Semantic Metadata**: Machine-readable descriptions for everything

## Current Focus

Build the bridge layer that allows AI agents to access traditional web content
in a structured, machine-readable format.

Focus on clean code, proper patterns, and building features incrementally.
Each session should complete at least one feature from feature_list.json."""

    return ClaudeSDKClient(
        options=ClaudeAgentOptions(
            model=model,
            system_prompt=system_prompt,
            allowed_tools=allowed_tools,
            max_turns=1000,
            cwd=str(project_dir.resolve()),
            settings=str(settings_file.resolve()),
        )
    )
