"""
Progress Tracking Utilities
===========================

Functions for tracking and displaying progress of Worldbook development.
"""

import json
from pathlib import Path


def count_passing_features(project_dir: Path) -> tuple[int, int]:
    """
    Count passing and total features in feature_list.json.

    Args:
        project_dir: Directory containing ai_engineer/feature_list.json

    Returns:
        (passing_count, total_count)
    """
    feature_file = project_dir / "ai_engineer" / "feature_list.json"

    if not feature_file.exists():
        return 0, 0

    try:
        with open(feature_file, "r") as f:
            data = json.load(f)

        # Handle both flat and categorized formats
        if "categories" in data:
            total = 0
            passing = 0
            for category in data["categories"]:
                tests = category.get("tests", [])
                total += len(tests)
                passing += sum(1 for t in tests if t.get("passes", False))
            return passing, total
        else:
            features = data.get("features", [])
            total = len(features)
            passing = sum(1 for f in features if f.get("passes", False))
            return passing, total

    except (json.JSONDecodeError, IOError):
        return 0, 0


def get_category_breakdown(project_dir: Path) -> dict[str, tuple[int, int]]:
    """
    Get breakdown of passing features by category.

    Args:
        project_dir: Directory containing ai_engineer/feature_list.json

    Returns:
        Dict mapping category to (passing, total) counts
    """
    feature_file = project_dir / "ai_engineer" / "feature_list.json"

    if not feature_file.exists():
        return {}

    try:
        with open(feature_file, "r") as f:
            data = json.load(f)

        categories: dict[str, tuple[int, int]] = {}

        if "categories" in data:
            for category in data["categories"]:
                cat_name = category.get("name", "unknown")
                tests = category.get("tests", [])
                total = len(tests)
                passing = sum(1 for t in tests if t.get("passes", False))
                categories[cat_name] = (passing, total)
        else:
            features = data.get("features", [])
            for feature in features:
                cat = feature.get("category", "unknown")
                passes = feature.get("passes", False)

                if cat not in categories:
                    categories[cat] = (0, 0)

                current_pass, current_total = categories[cat]
                categories[cat] = (
                    current_pass + (1 if passes else 0),
                    current_total + 1
                )

        return categories
    except (json.JSONDecodeError, IOError):
        return {}


def print_session_header(session_num: int, session_type: str = "CODING") -> None:
    """Print a formatted header for the session."""
    print("\n" + "=" * 70)
    print(f"  WORLDBOOK - SESSION {session_num}: {session_type}")
    print("=" * 70)
    print()


def print_progress_summary(project_dir: Path) -> None:
    """Print a summary of current progress."""
    passing, total = count_passing_features(project_dir)

    if total > 0:
        percentage = (passing / total) * 100
        print(f"\nProgress: {passing}/{total} features passing ({percentage:.1f}%)")

        # Show category breakdown
        categories = get_category_breakdown(project_dir)
        if categories:
            print("\nBy category:")
            for cat, (cat_pass, cat_total) in sorted(categories.items()):
                cat_pct = (cat_pass / cat_total) * 100 if cat_total > 0 else 0
                status = "+" if cat_pass == cat_total else " "
                print(f"  [{status}] {cat}: {cat_pass}/{cat_total} ({cat_pct:.0f}%)")
    else:
        print("\nProgress: feature_list.json not found yet")
