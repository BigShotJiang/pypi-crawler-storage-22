"""
Prompt Loading Utilities
========================

Functions for loading prompt templates from the prompts directory.
"""

from pathlib import Path


PROMPTS_DIR = Path(__file__).parent / "prompts"


def load_prompt(name: str) -> str:
    """Load a prompt template from the prompts directory."""
    prompt_path = PROMPTS_DIR / f"{name}.md"
    return prompt_path.read_text()


def get_system_prompt() -> str:
    """Load the system prompt for Worldbook development."""
    return load_prompt("system_prompt")


def get_coding_prompt() -> str:
    """Load the coding agent prompt."""
    return load_prompt("coding_prompt")
