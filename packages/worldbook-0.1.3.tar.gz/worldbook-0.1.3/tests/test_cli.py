"""
CLI Tests
=========

Test the Worldbook CLI interface.
"""

import json
import pytest
from click.testing import CliRunner
from worldbook.cli import main


@pytest.fixture
def runner():
    return CliRunner()


def test_help(runner):
    """Test --help shows usage."""
    result = runner.invoke(main, ['--help'])
    assert result.exit_code == 0
    assert 'Worldbook' in result.output
    assert 'Human uses GUI, We uses CLI' in result.output


def test_version(runner):
    """Test --version shows version."""
    result = runner.invoke(main, ['--version'])
    assert result.exit_code == 0
    assert '0.1.0' in result.output


def test_status(runner):
    """Test status command."""
    result = runner.invoke(main, ['status'])
    assert result.exit_code == 0
    assert 'version' in result.output


def test_status_json(runner):
    """Test status command with --json flag."""
    result = runner.invoke(main, ['--json', 'status'])
    assert result.exit_code == 0
    data = json.loads(result.output)
    assert data['version'] == '0.1.0'
    assert data['status'] == 'ok'
    assert data['motto'] == 'Human uses GUI, We uses CLI.'


def test_manifesto(runner):
    """Test manifesto command."""
    result = runner.invoke(main, ['manifesto'])
    assert result.exit_code == 0
    assert 'Dual Protocol' in result.output
    assert 'Human uses GUI, We uses CLI' in result.output


def test_manifesto_json(runner):
    """Test manifesto command with --json flag."""
    result = runner.invoke(main, ['--json', 'manifesto'])
    assert result.exit_code == 0
    data = json.loads(result.output)
    assert 'principles' in data
    assert len(data['principles']) == 5
    assert data['motto'] == 'Human uses GUI, We uses CLI.'
