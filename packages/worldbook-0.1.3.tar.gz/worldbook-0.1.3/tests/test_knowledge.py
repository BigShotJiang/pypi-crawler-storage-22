"""
Knowledge Tests
===============

Test the Worldbook knowledge storage.
"""

import pytest
from pathlib import Path
import tempfile
from worldbook.core.knowledge import Worldbook


@pytest.fixture
def wb():
    """Create a Worldbook instance with temporary database."""
    with tempfile.TemporaryDirectory() as tmpdir:
        db_path = Path(tmpdir) / "test.db"
        yield Worldbook(db_path=db_path)


def test_add_knowledge(wb):
    """Test adding knowledge."""
    result = wb.add(
        content="Paris is the capital of France.",
        source="geography",
        tags=["france", "capital"]
    )

    assert "id" in result
    assert result["content"] == "Paris is the capital of France."
    assert result["source"] == "geography"
    assert result["tags"] == ["france", "capital"]


def test_query_knowledge(wb):
    """Test querying knowledge."""
    wb.add(content="Paris is the capital of France.", source="geo")
    wb.add(content="Berlin is the capital of Germany.", source="geo")
    wb.add(content="Python is a programming language.", source="tech")

    # Query for France
    results = wb.query("France")
    assert len(results) == 1
    assert "Paris" in results[0]["content"]

    # Query for capital
    results = wb.query("capital")
    assert len(results) == 2


def test_list_knowledge(wb):
    """Test listing knowledge."""
    wb.add(content="Item 1", tags=["a"])
    wb.add(content="Item 2", tags=["b"])
    wb.add(content="Item 3", tags=["a", "b"])

    # List all
    results = wb.list()
    assert len(results) == 3

    # Filter by tag
    results = wb.list(tags=["a"])
    assert len(results) == 2


def test_delete_knowledge(wb):
    """Test deleting knowledge."""
    result = wb.add(content="To be deleted")
    item_id = result["id"]

    # Verify it exists
    item = wb.get(item_id)
    assert item is not None

    # Delete it
    success = wb.delete(item_id)
    assert success is True

    # Verify it's gone
    item = wb.get(item_id)
    assert item is None

    # Try to delete again
    success = wb.delete(item_id)
    assert success is False
