"""
Worldbook - AI's Knowledge Base / World Model
==============================================

"Human uses GUI, We uses CLI."

Dual Protocol for AI Accessibility.
"""

__version__ = "0.1.0"

from .core.knowledge import Worldbook

__all__ = ["Worldbook", "__version__"]
