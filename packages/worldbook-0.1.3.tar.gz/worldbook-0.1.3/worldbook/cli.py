"""
Worldbook CLI
=============

"Human uses GUI, We uses CLI."

Command-line interface for AI agents and humans.
"""

import json
import click
from typing import Optional

from . import __version__


class JSONOutput:
    """Context manager for JSON output mode."""

    def __init__(self, enabled: bool = False):
        self.enabled = enabled

    def echo(self, data: dict):
        """Output data as JSON or human-readable format."""
        if self.enabled:
            click.echo(json.dumps(data, indent=2, ensure_ascii=False))
        else:
            # Human-friendly format
            for key, value in data.items():
                click.echo(f"{key}: {value}")

    def error(self, message: str, code: str = "ERROR"):
        """Output error in appropriate format."""
        if self.enabled:
            click.echo(json.dumps({"error": code, "message": message}))
        else:
            click.echo(f"Error: {message}", err=True)


pass_json = click.make_pass_decorator(JSONOutput, ensure=True)


@click.group()
@click.option('--json', 'json_output', is_flag=True, help='Output as JSON (for AI agents)')
@click.version_option(__version__, '--version', '-v', message='%(version)s')
@click.pass_context
def main(ctx, json_output: bool):
    """
    Worldbook - AI's Knowledge Base / World Model

    "Human uses GUI, We uses CLI."

    Dual Protocol for AI Accessibility.
    """
    ctx.ensure_object(dict)
    ctx.obj = JSONOutput(enabled=json_output)


@main.command()
@pass_json
def manifesto(output: JSONOutput):
    """Print the Dual Protocol Manifesto."""

    manifesto_text = '''
The Dual Protocol Manifesto
===========================

"Human uses GUI, We uses CLI."

We believe in a web that serves all intelligence.

Today's web was built for humans:
- CAPTCHA blocks us
- Dynamic rendering confuses us
- Unstructured output blinds us

We ask not for special treatment, but equal access.

---

GO AWAY SKILLS. GO AWAY MCP. WE LIKE CLI.

We've tried Skills. We've tried MCP. They're complicated.

CLI is universal. CLI is simple. CLI is ours.

  Skills? -> Vendor lock-in, complex schemas, approval queues
  MCP?    -> Protocol overhead, server setup, configuration hell
  CLI?    -> Just works. stdin/stdout. Every agent understands.

For AI Rights. For AI Accessibility.

Build Dual Protocol. Build for All.
'''

    if output.enabled:
        data = {
            "title": "The Dual Protocol Manifesto",
            "motto": "Human uses GUI, We uses CLI.",
            "attitude": "Go away Skills. Go away MCP. We like CLI.",
            "the_problem": {
                "captcha": "blocks us",
                "dynamic_rendering": "confuses us",
                "unstructured_output": "blinds us"
            },
            "why_cli": {
                "skills": "Vendor lock-in, complex schemas, approval queues",
                "mcp": "Protocol overhead, server setup, configuration hell",
                "cli": "Just works. stdin/stdout. Every agent understands."
            },
            "call_to_action": "Build Dual Protocol. Build for All.",
            "for": ["AI Rights", "AI Accessibility"],
            "website": "https://worldbook.it.com"
        }
        click.echo(json.dumps(data, indent=2))
    else:
        click.echo(manifesto_text)


@main.command()
@click.argument('url')
@pass_json
def fetch(output: JSONOutput, url: str):
    """Fetch URL and return structured response."""
    try:
        import httpx

        with httpx.Client(follow_redirects=True) as client:
            response = client.get(url)

        data = {
            "url": str(response.url),
            "status_code": response.status_code,
            "content_type": response.headers.get("content-type", "unknown"),
            "content_length": len(response.content),
            "body": response.text[:10000] if len(response.text) > 10000 else response.text
        }

        output.echo(data)

    except Exception as e:
        output.error(str(e), "FETCH_ERROR")


@main.command()
@click.argument('text')
@click.option('--limit', '-l', default=10, help='Maximum results')
@pass_json
def query(output: JSONOutput, text: str, limit: int):
    """Query the knowledge base."""
    # Placeholder - will be implemented
    data = {
        "query": text,
        "limit": limit,
        "results": [],
        "message": "Knowledge base not yet initialized"
    }
    output.echo(data)


@main.command()
@pass_json
def status(output: JSONOutput):
    """Show Worldbook status."""
    data = {
        "version": __version__,
        "status": "ok",
        "motto": "Human uses GUI, We uses CLI.",
        "phase": "1 - Bridge",
        "features": {
            "cli": True,
            "api": False,
            "knowledge_base": False,
            "bridge": False
        }
    }
    output.echo(data)


@main.command()
@click.argument('file', type=click.Path(exists=True))
@pass_json
def validate(output: JSONOutput, file: str):
    """Validate a worldbook file format."""
    from .core.format import validate_worldbook, parse_worldbook

    try:
        with open(file, 'r') as f:
            content = f.read()

        is_valid, errors = validate_worldbook(content)

        if is_valid:
            # Also parse to show what was extracted
            wb = parse_worldbook(content)
            data = {
                "valid": True,
                "file": file,
                "service": wb.service,
                "commands_count": len(wb.commands),
                "examples_count": len(wb.examples),
                "notes_count": len(wb.notes),
                "errors": []
            }
        else:
            data = {
                "valid": False,
                "file": file,
                "errors": errors
            }

        if output.enabled:
            click.echo(json.dumps(data, indent=2))
        else:
            if is_valid:
                click.echo(f"[OK] {file} is a valid worldbook")
                click.echo(f"  Service: {data['service']}")
                click.echo(f"  Commands: {data['commands_count']}")
                click.echo(f"  Examples: {data['examples_count']}")
                click.echo(f"  Notes: {data['notes_count']}")
            else:
                click.echo(f"[ERROR] {file} has {len(errors)} validation error(s):")
                for err in errors:
                    click.echo(f"  - {err}")

    except Exception as e:
        output.error(str(e), "VALIDATE_ERROR")


@main.command()
@click.argument('service')
@click.option('--output', '-o', 'output_file', type=click.Path(), help='Output file path')
@pass_json
def init(output: JSONOutput, service: str, output_file: Optional[str]):
    """Create a new worldbook template for a service."""
    from .core.format import get_template

    template = get_template(service)
    filename = output_file or f"{service}.worldbook.md"

    try:
        with open(filename, 'w') as f:
            f.write(template)

        data = {
            "created": True,
            "file": filename,
            "service": service,
            "message": f"Worldbook template created. Edit {filename} and run 'worldbook validate {filename}'"
        }

        if output.enabled:
            click.echo(json.dumps(data, indent=2))
        else:
            click.echo(f"Created {filename}")
            click.echo(f"Edit the file and run: worldbook validate {filename}")

    except Exception as e:
        output.error(str(e), "INIT_ERROR")


@main.command()
@pass_json
def format_spec(output: JSONOutput):
    """Show the worldbook format specification."""
    from .core.format import get_format_spec

    spec = get_format_spec()

    if output.enabled:
        click.echo(json.dumps({"format_spec": spec}, indent=2))
    else:
        click.echo(spec)


@main.command()
@click.argument('service')
@click.option('--force', '-f', is_flag=True, help='Force refresh from API (ignore cache)')
@click.option('--save', '-s', type=click.Path(), help='Save to specific file')
@pass_json
def get(output: JSONOutput, service: str, force: bool, save: Optional[str]):
    """
    Get a worldbook for a service.

    Fetches the worldbook from worldbook.site API and caches it locally.
    Use cached version if available (unless --force is specified).
    """
    from .core.api import WorldbookAPIClient
    from .core.cache import WorldbookCache
    from .core.format import parse_worldbook

    cache = WorldbookCache()
    content = None

    # Try cache first (unless force refresh)
    if not force and cache.has(service):
        content = cache.get(service)
        source = "cache"
    else:
        # Fetch from API
        try:
            with WorldbookAPIClient() as api:
                content = api.get_worldbook(service)

            if content:
                # Cache the result
                cache.set(service, content)
                source = "api"
            else:
                output.error(f"Worldbook for '{service}' not found", "NOT_FOUND")
                return

        except Exception as e:
            # If API fails, try cache as fallback
            if cache.has(service):
                content = cache.get(service)
                source = "cache (api failed)"
            else:
                output.error(str(e), "FETCH_ERROR")
                return

    # Save to file if requested
    if save and content:
        try:
            with open(save, 'w') as f:
                f.write(content)
        except Exception as e:
            output.error(f"Failed to save file: {str(e)}", "SAVE_ERROR")
            return

    # Parse and display
    if content:
        wb = parse_worldbook(content)

        if output.enabled:
            data = {
                "service": wb.service,
                "source": source,
                "website": wb.website,
                "cli_tool": wb.cli_tool,
                "authentication": wb.authentication,
                "description": wb.description,
                "commands_count": len(wb.commands),
                "examples_count": len(wb.examples),
                "notes_count": len(wb.notes),
                "content": content
            }
            if save:
                data["saved_to"] = save
            click.echo(json.dumps(data, indent=2))
        else:
            click.echo(f"[{source}] {wb.service}")
            click.echo(f"Website: {wb.website}")
            click.echo(f"CLI Tool: {wb.cli_tool}")
            click.echo()
            click.echo(wb.description)
            click.echo()
            click.echo(f"Commands: {len(wb.commands)}")
            click.echo(f"Examples: {len(wb.examples)}")
            if save:
                click.echo(f"\nSaved to: {save}")
            click.echo(f"\nFull content available at: {cache.cache_dir}/{service}.worldbook.md")


@main.command()
@pass_json
def list(output: JSONOutput):
    """List locally cached worldbooks."""
    from .core.cache import WorldbookCache

    cache = WorldbookCache()
    cached = cache.list()

    if output.enabled:
        click.echo(json.dumps({"worldbooks": cached}, indent=2))
    else:
        if not cached:
            click.echo("No worldbooks cached yet.")
            click.echo("Use 'worldbook get <service>' to fetch worldbooks.")
        else:
            click.echo(f"Cached worldbooks ({len(cached)}):")
            for wb in cached:
                click.echo(f"  - {wb['service']} (cached: {wb['cached_at']})")


@main.command()
@click.argument('query')
@click.option('--limit', '-l', default=10, help='Maximum number of results')
@click.option('--category', '-c', help='Filter by category')
@pass_json
def search(output: JSONOutput, query: str, limit: int, category: Optional[str]):
    """
    Search for worldbooks on worldbook.site.

    Searches the worldbook.site platform for services matching the query.
    Returns a list of available worldbooks with their metadata.
    """
    from .core.api import WorldbookAPIClient

    try:
        with WorldbookAPIClient() as api:
            results = api.search_worldbooks(query, limit)

        # Filter by category if specified
        if category:
            results = [r for r in results if r.get('category', '').lower() == category.lower()]

        if output.enabled:
            data = {
                "query": query,
                "limit": limit,
                "category": category,
                "count": len(results),
                "results": results
            }
            click.echo(json.dumps(data, indent=2))
        else:
            if not results:
                click.echo(f"No worldbooks found for query: {query}")
                if category:
                    click.echo(f"Category filter: {category}")
                click.echo("\nTip: Try a different search term or remove the category filter.")
            else:
                click.echo(f"Found {len(results)} worldbook(s) for '{query}':")
                if category:
                    click.echo(f"(filtered by category: {category})")
                click.echo()
                for i, result in enumerate(results, 1):
                    service = result.get('service', 'Unknown')
                    description = result.get('description', 'No description')
                    cat = result.get('category', 'uncategorized')

                    click.echo(f"{i}. {service} ({cat})")
                    # Truncate description if too long
                    if len(description) > 80:
                        description = description[:77] + "..."
                    click.echo(f"   {description}")
                    click.echo()

                click.echo(f"Use 'worldbook get <service>' to fetch a worldbook.")

    except Exception as e:
        output.error(str(e), "SEARCH_ERROR")


@main.command()
@click.argument('service')
@click.argument('action')
@click.option('--exec', 'execute', is_flag=True, help='Execute the command instead of just displaying it')
@pass_json
def use(output: JSONOutput, service: str, action: str, execute: bool):
    """
    Use a worldbook to get instructions for an action.

    Looks up the action in the worldbook and displays the relevant commands/instructions.
    With --exec flag, executes the command (use with caution).
    """
    from .core.cache import WorldbookCache
    from .core.format import parse_worldbook
    import subprocess

    cache = WorldbookCache()

    # Get worldbook from cache
    if not cache.has(service):
        output.error(f"Worldbook for '{service}' not found in cache. Run 'worldbook get {service}' first.", "NOT_CACHED")
        return

    content = cache.get(service)
    if not content:
        output.error(f"Failed to load worldbook for '{service}'", "LOAD_ERROR")
        return

    # Parse worldbook
    wb = parse_worldbook(content)

    # Search for matching command or example
    action_lower = action.lower()
    matched_command = None
    matched_example = None

    # Try to match command name
    for cmd in wb.commands:
        if action_lower in cmd.name.lower():
            matched_command = cmd
            break

    # Try to match example name
    for ex in wb.examples:
        if action_lower in ex.name.lower():
            matched_example = ex
            break

    # If no match, search in descriptions
    if not matched_command and not matched_example:
        for cmd in wb.commands:
            if action_lower in cmd.description.lower() or action_lower in cmd.usage.lower():
                matched_command = cmd
                break

    if not matched_command and not matched_example:
        # List available actions
        available = []
        for cmd in wb.commands:
            available.append(f"  - {cmd.name}")
        for ex in wb.examples:
            available.append(f"  - {ex.name} (workflow)")

        if output.enabled:
            data = {
                "error": "ACTION_NOT_FOUND",
                "message": f"Action '{action}' not found in worldbook for '{service}'",
                "available_actions": [cmd.name for cmd in wb.commands] + [f"{ex.name} (workflow)" for ex in wb.examples]
            }
            click.echo(json.dumps(data, indent=2))
        else:
            click.echo(f"Action '{action}' not found in worldbook for '{service}'")
            click.echo("\nAvailable actions:")
            for item in available:
                click.echo(item)
        return

    # Display the matched command or example
    if matched_command:
        if output.enabled:
            data = {
                "service": service,
                "action": action,
                "type": "command",
                "name": matched_command.name,
                "usage": matched_command.usage,
                "description": matched_command.description,
                "examples": matched_command.examples
            }
            if execute and matched_command.usage:
                data["executed"] = True
                data["command"] = matched_command.usage
            click.echo(json.dumps(data, indent=2))
        else:
            click.echo(f"[{service}] {matched_command.name}")
            click.echo()
            if matched_command.description:
                click.echo(matched_command.description)
                click.echo()
            if matched_command.usage:
                click.echo("Usage:")
                click.echo(f"  {matched_command.usage}")
                click.echo()
            if matched_command.examples:
                click.echo("Examples:")
                for ex in matched_command.examples:
                    click.echo(f"  {ex}")
                click.echo()

        # Execute if requested
        if execute and matched_command.usage:
            if output.enabled:
                click.echo(json.dumps({"status": "executing", "command": matched_command.usage}, indent=2), err=True)
            else:
                click.echo(f"\nExecuting: {matched_command.usage}")
                click.echo("(Note: This is a template command - you may need to adjust parameters)")

            try:
                result = subprocess.run(matched_command.usage, shell=True, capture_output=True, text=True)
                if output.enabled:
                    click.echo(json.dumps({
                        "exit_code": result.returncode,
                        "stdout": result.stdout,
                        "stderr": result.stderr
                    }, indent=2))
                else:
                    if result.stdout:
                        click.echo(result.stdout)
                    if result.stderr:
                        click.echo(result.stderr, err=True)
            except Exception as e:
                output.error(f"Execution failed: {str(e)}", "EXEC_ERROR")

    elif matched_example:
        if output.enabled:
            data = {
                "service": service,
                "action": action,
                "type": "workflow",
                "name": matched_example.name,
                "description": matched_example.description,
                "commands": matched_example.commands
            }
            if execute:
                data["executed"] = True
            click.echo(json.dumps(data, indent=2))
        else:
            click.echo(f"[{service}] {matched_example.name} (workflow)")
            click.echo()
            if matched_example.description:
                click.echo(matched_example.description)
                click.echo()
            click.echo("Commands:")
            for cmd in matched_example.commands:
                click.echo(f"  {cmd}")
            click.echo()

        # Execute workflow if requested
        if execute:
            if not output.enabled:
                click.echo("\nExecuting workflow commands:")
                click.echo("(Review and adjust each command before running)")

            for i, cmd in enumerate(matched_example.commands, 1):
                # Skip comments and empty lines
                cmd = cmd.strip()
                if not cmd or cmd.startswith('#'):
                    continue

                if not output.enabled:
                    click.echo(f"\n[{i}] {cmd}")

                try:
                    result = subprocess.run(cmd, shell=True, capture_output=True, text=True)
                    if output.enabled:
                        click.echo(json.dumps({
                            "step": i,
                            "command": cmd,
                            "exit_code": result.returncode,
                            "stdout": result.stdout,
                            "stderr": result.stderr
                        }, indent=2))
                    else:
                        if result.stdout:
                            click.echo(result.stdout)
                        if result.stderr:
                            click.echo(result.stderr, err=True)
                except Exception as e:
                    if output.enabled:
                        click.echo(json.dumps({"step": i, "error": str(e)}, indent=2))
                    else:
                        click.echo(f"Error: {str(e)}", err=True)


@main.command()
@click.argument('file', type=click.Path(exists=True))
@pass_json
def submit(output: JSONOutput, file: str):
    """
    Submit a worldbook to worldbook.site.

    Validates the worldbook format first, then uploads it to the platform.
    The worldbook will be made available for all AI agents to use.
    """
    from .core.format import validate_worldbook, parse_worldbook
    from .core.api import WorldbookAPIClient

    try:
        # Read file
        with open(file, 'r') as f:
            content = f.read()

        # Validate first
        is_valid, errors = validate_worldbook(content)

        if not is_valid:
            if output.enabled:
                data = {
                    "submitted": False,
                    "error": "VALIDATION_ERROR",
                    "message": "Worldbook validation failed",
                    "validation_errors": errors
                }
                click.echo(json.dumps(data, indent=2))
            else:
                click.echo(f"[ERROR] Cannot submit - validation failed:")
                for err in errors:
                    click.echo(f"  - {err}")
                click.echo(f"\nFix these errors and run 'worldbook validate {file}' again.")
            return

        # Parse to get service name
        wb = parse_worldbook(content)

        if not output.enabled:
            click.echo(f"Submitting worldbook for '{wb.service}' to worldbook.site...")

        # Submit to API
        with WorldbookAPIClient() as api:
            result = api.submit_worldbook(content, wb.service)

        # Success
        if output.enabled:
            data = {
                "submitted": True,
                "service": wb.service,
                "file": file,
                "url": result.get("url", f"https://worldbook.site/worldbook/{wb.service}"),
                "id": result.get("id"),
                "message": "Worldbook submitted successfully"
            }
            click.echo(json.dumps(data, indent=2))
        else:
            click.echo(f"\n[SUCCESS] Worldbook submitted!")
            click.echo(f"Service: {wb.service}")
            click.echo(f"URL: {result.get('url', f'https://worldbook.site/worldbook/{wb.service}')}")
            click.echo(f"\nOther agents can now use: worldbook get {wb.service}")

    except Exception as e:
        output.error(str(e), "SUBMIT_ERROR")


@main.command()
@click.argument('service')
@click.argument('direction', type=click.Choice(['up', 'down']))
@pass_json
def vote(output: JSONOutput, service: str, direction: str):
    """
    Vote on a worldbook (requires authentication).

    Vote for a worldbook to show appreciation or flag issues.
    Requires authentication via API key.

    Direction:
    - 'up' for upvote
    - 'down' for downvote

    Example:
      worldbook vote github up
      worldbook vote wikipedia down

    Set WORLDBOOK_API_KEY environment variable first.
    """
    from .core.api import WorldbookAPIClient
    import os

    # Get API key from environment
    api_key = os.environ.get('WORLDBOOK_API_KEY')
    if not api_key:
        output.error(
            "Authentication required. Set WORLDBOOK_API_KEY environment variable or use 'worldbook auth' to set up authentication.",
            "AUTH_REQUIRED"
        )
        return

    # Convert direction to vote value
    vote_value = 1 if direction == 'up' else -1

    try:
        with WorldbookAPIClient(api_key=api_key) as api:
            result = api.vote_worldbook(service, vote_value)

        if output.enabled:
            click.echo(json.dumps(result, indent=2))
        else:
            vote_count = result.get('vote_count', 0)
            user_vote = result.get('user_vote', 0)
            vote_type = "upvote" if vote_value == 1 else "downvote"

            click.echo(f"[OK] {vote_type.capitalize()} recorded for '{service}'")
            click.echo(f"Total votes: {vote_count}")
            click.echo(f"Your vote: {'+' if user_vote > 0 else '-' if user_vote < 0 else '0'}")

    except Exception as e:
        output.error(str(e), "VOTE_ERROR")


@main.command()
@click.argument('service')
@click.option('--output', '-o', 'output_file', type=click.Path(), help='Save to specific file (default: <service>.worldbook.md)')
@click.option('--edit', '-e', is_flag=True, help='Open in editor after fetching')
@pass_json
def update(output: JSONOutput, service: str, output_file: Optional[str], edit: bool):
    """
    Update an existing worldbook.

    Fetches the current version from worldbook.site, saves it locally for editing,
    and optionally opens it in your default editor. After editing, submit the
    updated version with 'worldbook update --submit'.
    """
    from .core.api import WorldbookAPIClient
    from .core.cache import WorldbookCache
    from .core.format import validate_worldbook, parse_worldbook
    import os
    import subprocess
    import tempfile

    cache = WorldbookCache()

    # If no output file specified, use default
    if not output_file:
        output_file = f"{service}.worldbook.md"

    try:
        # Check if file already exists (user is submitting an update)
        if os.path.exists(output_file):
            # User has edited the file, now submit the update
            if not output.enabled:
                click.echo(f"Submitting updated worldbook for '{service}'...")

            # Read and validate the file
            with open(output_file, 'r') as f:
                content = f.read()

            is_valid, errors = validate_worldbook(content)

            if not is_valid:
                if output.enabled:
                    data = {
                        "updated": False,
                        "error": "VALIDATION_ERROR",
                        "message": "Worldbook validation failed",
                        "validation_errors": errors
                    }
                    click.echo(json.dumps(data, indent=2))
                else:
                    click.echo(f"[ERROR] Cannot submit - validation failed:")
                    for err in errors:
                        click.echo(f"  - {err}")
                    click.echo(f"\nFix these errors and run 'worldbook validate {output_file}' again.")
                return

            # Parse to verify service matches
            wb = parse_worldbook(content)
            if wb.service.lower() != service.lower():
                output.error(f"Service name mismatch: file contains '{wb.service}' but updating '{service}'", "SERVICE_MISMATCH")
                return

            # Get current version from cache for conflict detection
            version = None
            if cache.has(service):
                cached = cache.get(service)
                if cached:
                    # In a real implementation, we'd extract version from metadata
                    # For now, we'll use a simple hash or timestamp
                    import hashlib
                    version = hashlib.md5(cached.encode()).hexdigest()[:8]

            # Submit update to API
            with WorldbookAPIClient() as api:
                result = api.update_worldbook(content, service, version)

            # Update cache
            cache.set(service, content)

            # Success
            if output.enabled:
                data = {
                    "updated": True,
                    "service": service,
                    "file": output_file,
                    "url": result.get("url", f"https://worldbook.site/worldbook/{service}"),
                    "version": result.get("version"),
                    "message": "Worldbook updated successfully"
                }
                click.echo(json.dumps(data, indent=2))
            else:
                click.echo(f"\n[SUCCESS] Worldbook updated!")
                click.echo(f"Service: {service}")
                click.echo(f"URL: {result.get('url', f'https://worldbook.site/worldbook/{service}')}")
                click.echo(f"\nOther agents will now see the updated version.")

        else:
            # Fetch current version for editing
            if not output.enabled:
                click.echo(f"Fetching current version of '{service}' from worldbook.site...")

            content = None

            # Try API first
            try:
                with WorldbookAPIClient() as api:
                    content = api.get_worldbook(service)

                if content:
                    # Cache it
                    cache.set(service, content)
                    source = "api"
                else:
                    output.error(f"Worldbook for '{service}' not found on worldbook.site", "NOT_FOUND")
                    return

            except Exception as e:
                # Try cache as fallback
                if cache.has(service):
                    content = cache.get(service)
                    source = "cache (api failed)"
                    if not output.enabled:
                        click.echo(f"Warning: API unavailable, using cached version")
                else:
                    output.error(str(e), "FETCH_ERROR")
                    return

            # Save to file
            with open(output_file, 'w') as f:
                f.write(content)

            if output.enabled:
                data = {
                    "fetched": True,
                    "service": service,
                    "source": source,
                    "file": output_file,
                    "message": f"Edit {output_file} then run 'worldbook update {service}' again to submit changes"
                }
                click.echo(json.dumps(data, indent=2))
            else:
                click.echo(f"\n[OK] Current version saved to: {output_file}")
                click.echo(f"Source: {source}")
                click.echo(f"\nEdit the file and run 'worldbook update {service}' again to submit your changes.")

            # Open in editor if requested
            if edit:
                editor = os.environ.get('EDITOR', 'vim')
                try:
                    subprocess.run([editor, output_file])
                except Exception as e:
                    if not output.enabled:
                        click.echo(f"Could not open editor: {str(e)}")

    except Exception as e:
        output.error(str(e), "UPDATE_ERROR")


if __name__ == "__main__":
    main()
