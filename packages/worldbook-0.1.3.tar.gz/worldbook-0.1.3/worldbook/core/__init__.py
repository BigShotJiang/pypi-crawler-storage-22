"""
Worldbook Core
==============

Core functionality for the Worldbook system.
"""

from .knowledge import Worldbook

__all__ = ["Worldbook"]
