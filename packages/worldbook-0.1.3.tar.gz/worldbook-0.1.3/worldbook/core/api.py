"""
Worldbook API Client

Client for interacting with worldbook.site API.
"""

import httpx
from typing import Optional
from pathlib import Path


class WorldbookAPIClient:
    """Client for worldbook.site API."""

    def __init__(self, base_url: str = "https://worldbook.site/api", api_key: Optional[str] = None):
        self.base_url = base_url
        headers = {"User-Agent": "worldbook-cli/0.1.0"}

        # Add authorization header if API key provided
        if api_key:
            headers["Authorization"] = f"Bearer {api_key}"

        self.client = httpx.Client(
            timeout=30.0,
            follow_redirects=True,
            headers=headers
        )

    def get_worldbook(self, service: str) -> Optional[str]:
        """
        Fetch a worldbook from the API.

        Args:
            service: The service name (e.g., "github", "twitter")

        Returns:
            The worldbook content as markdown string, or None if not found
        """
        try:
            url = f"{self.base_url}/worldbook/{service}"
            response = self.client.get(url, params={"format": "raw"})

            if response.status_code == 200:
                return response.text
            elif response.status_code == 404:
                return None
            else:
                raise Exception(f"API error: {response.status_code}")

        except httpx.ConnectError:
            # API not available, return None
            return None
        except Exception as e:
            raise Exception(f"Failed to fetch worldbook: {str(e)}")

    def search_worldbooks(self, query: str, limit: int = 10) -> list[dict]:
        """
        Search for worldbooks.

        Args:
            query: Search query
            limit: Maximum number of results

        Returns:
            List of worldbook metadata
        """
        try:
            url = f"{self.base_url}/search"
            response = self.client.get(url, params={"q": query, "limit": limit})

            if response.status_code == 200:
                return response.json().get("results", [])
            else:
                return []

        except Exception:
            return []

    def submit_worldbook(self, content: str, service: str) -> dict:
        """
        Submit a worldbook to the API.

        Args:
            content: The worldbook markdown content
            service: The service name

        Returns:
            Dictionary with submission result including status, url, and id
        """
        try:
            url = f"{self.base_url}/worldbook"
            response = self.client.post(
                url,
                json={
                    "service": service,
                    "content": content
                }
            )

            if response.status_code in [200, 201]:
                return response.json()
            elif response.status_code == 400:
                error_detail = response.json().get("message", "Invalid worldbook format")
                raise Exception(f"Validation error: {error_detail}")
            elif response.status_code == 409:
                raise Exception(f"Worldbook for '{service}' already exists. Use 'worldbook update' to modify it.")
            else:
                raise Exception(f"API error: {response.status_code}")

        except httpx.ConnectError:
            raise Exception("Cannot connect to worldbook.site API. Please check your connection.")
        except Exception as e:
            if "Validation error" in str(e) or "already exists" in str(e) or "Cannot connect" in str(e):
                raise
            raise Exception(f"Failed to submit worldbook: {str(e)}")

    def update_worldbook(self, content: str, service: str, version: Optional[str] = None) -> dict:
        """
        Update an existing worldbook on the API.

        Args:
            content: The updated worldbook markdown content
            service: The service name
            version: Optional version for conflict detection

        Returns:
            Dictionary with update result including status, url, and version

        Raises:
            Exception: If update fails, version conflict occurs, or worldbook doesn't exist
        """
        try:
            url = f"{self.base_url}/worldbook/{service}"
            payload = {
                "content": content
            }
            if version:
                payload["version"] = version

            response = self.client.put(url, json=payload)

            if response.status_code == 200:
                return response.json()
            elif response.status_code == 404:
                raise Exception(f"Worldbook for '{service}' not found. Use 'worldbook submit' to create it first.")
            elif response.status_code == 409:
                raise Exception(f"Version conflict: The worldbook has been modified by someone else. Please fetch the latest version and try again.")
            elif response.status_code == 400:
                error_detail = response.json().get("message", "Invalid worldbook format")
                raise Exception(f"Validation error: {error_detail}")
            else:
                raise Exception(f"API error: {response.status_code}")

        except httpx.ConnectError:
            raise Exception("Cannot connect to worldbook.site API. Please check your connection.")
        except Exception as e:
            if "not found" in str(e) or "conflict" in str(e) or "Validation error" in str(e) or "Cannot connect" in str(e):
                raise
            raise Exception(f"Failed to update worldbook: {str(e)}")

    def vote_worldbook(self, service: str, vote: int) -> dict:
        """
        Vote on a worldbook (requires authentication).

        Args:
            service: The service name
            vote: Vote direction (1 for upvote, -1 for downvote)

        Returns:
            Dictionary with vote result including status, vote_count, and user_vote

        Raises:
            Exception: If vote fails or authentication is missing
        """
        try:
            url = f"{self.base_url}/worldbook/{service}/vote"
            response = self.client.post(
                url,
                json={"vote": vote}
            )

            if response.status_code == 200:
                return response.json()
            elif response.status_code == 401:
                raise Exception("Authentication required. Set WORLDBOOK_API_KEY environment variable or use 'worldbook auth' to set up authentication.")
            elif response.status_code == 400:
                error_detail = response.json().get("detail", "Invalid vote")
                raise Exception(f"Vote error: {error_detail}")
            elif response.status_code == 404:
                raise Exception(f"Worldbook for '{service}' not found.")
            else:
                raise Exception(f"API error: {response.status_code}")

        except httpx.ConnectError:
            raise Exception("Cannot connect to worldbook.site API. Please check your connection.")
        except Exception as e:
            if "Authentication required" in str(e) or "Vote error" in str(e) or "not found" in str(e) or "Cannot connect" in str(e):
                raise
            raise Exception(f"Failed to vote: {str(e)}")

    def close(self):
        """Close the HTTP client."""
        self.client.close()

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.close()
