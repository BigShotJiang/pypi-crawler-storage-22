"""
Worldbook Cache

Local caching for worldbooks for offline use.
"""

import json
from pathlib import Path
from datetime import datetime
from typing import Optional


class WorldbookCache:
    """Local cache for worldbooks."""

    def __init__(self, cache_dir: Optional[Path] = None):
        """
        Initialize the cache.

        Args:
            cache_dir: Directory for cache storage. Defaults to ~/.worldbook/cache
        """
        if cache_dir is None:
            cache_dir = Path.home() / ".worldbook" / "cache"

        self.cache_dir = cache_dir
        self.cache_dir.mkdir(parents=True, exist_ok=True)
        self.metadata_file = self.cache_dir / "metadata.json"
        self._load_metadata()

    def _load_metadata(self):
        """Load cache metadata from disk."""
        if self.metadata_file.exists():
            with open(self.metadata_file, 'r') as f:
                self.metadata = json.load(f)
        else:
            self.metadata = {}

    def _save_metadata(self):
        """Save cache metadata to disk."""
        with open(self.metadata_file, 'w') as f:
            json.dump(self.metadata, f, indent=2)

    def get(self, service: str) -> Optional[str]:
        """
        Get a worldbook from cache.

        Args:
            service: The service name

        Returns:
            The worldbook content, or None if not cached
        """
        cache_file = self.cache_dir / f"{service}.worldbook.md"

        if cache_file.exists():
            with open(cache_file, 'r') as f:
                return f.read()

        return None

    def set(self, service: str, content: str):
        """
        Store a worldbook in cache.

        Args:
            service: The service name
            content: The worldbook content
        """
        cache_file = self.cache_dir / f"{service}.worldbook.md"

        with open(cache_file, 'w') as f:
            f.write(content)

        # Update metadata
        self.metadata[service] = {
            "cached_at": datetime.now().isoformat(),
            "file": str(cache_file)
        }
        self._save_metadata()

    def list(self) -> list[dict]:
        """
        List all cached worldbooks.

        Returns:
            List of cached worldbook metadata
        """
        cached = []

        for service, meta in self.metadata.items():
            cache_file = Path(meta["file"])
            if cache_file.exists():
                cached.append({
                    "service": service,
                    "cached_at": meta["cached_at"],
                    "file": str(cache_file)
                })

        return cached

    def has(self, service: str) -> bool:
        """
        Check if a worldbook is cached.

        Args:
            service: The service name

        Returns:
            True if cached, False otherwise
        """
        return service in self.metadata

    def clear(self, service: Optional[str] = None):
        """
        Clear cache.

        Args:
            service: If provided, clear only this service. Otherwise clear all.
        """
        if service:
            cache_file = self.cache_dir / f"{service}.worldbook.md"
            if cache_file.exists():
                cache_file.unlink()
            if service in self.metadata:
                del self.metadata[service]
                self._save_metadata()
        else:
            # Clear all cache files
            for file in self.cache_dir.glob("*.worldbook.md"):
                file.unlink()
            self.metadata = {}
            self._save_metadata()
