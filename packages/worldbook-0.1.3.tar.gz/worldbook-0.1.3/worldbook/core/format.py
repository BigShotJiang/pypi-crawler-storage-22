"""
Worldbook Format Specification and Utilities

A worldbook is a simple Markdown file that tells AI agents how to use a service.
No SDK. No protocol. No ceremony. Just instructions.
"""

from dataclasses import dataclass, field
from typing import Optional  # noqa: F401 - used in type hints
import re


# The format specification
WORLDBOOK_FORMAT_SPEC = """
# Worldbook Format Specification

A worldbook is a simple Markdown file that tells AI agents how to use a service via CLI.

**Philosophy**: CLI is universal. CLI is simple. CLI is ours.

## Required Sections

1. **Service Header** - Name, website, CLI tool, authentication method
2. **Description** - What the service does (1-2 sentences)
3. **Commands** - CLI commands with usage, parameters, examples
4. **Examples** - Complete workflows showing real use cases
5. **Notes** - Rate limits, best practices, gotchas

## File Naming

- `<service>.worldbook.md` - e.g., `github.worldbook.md`
- Lowercase, hyphenated names

## Example Structure

```markdown
# GitHub

**Website**: https://github.com
**CLI Tool**: gh
**Authentication**: gh auth login

## Description
GitHub is a code hosting platform. Use the `gh` CLI for all operations.

## Commands

### Create Repository
```bash
gh repo create <name> [--public|--private] [--description "desc"]
```

### List Issues
```bash
gh issue list [--state open|closed|all] [--label <label>]
```

## Examples

### Clone and Create PR Workflow
```bash
gh repo clone owner/repo
cd repo
git checkout -b feature-branch
# make changes
git add . && git commit -m "feat: add feature"
gh pr create --title "Add feature" --body "Description"
```

## Notes
- Rate limit: 5000 requests/hour for authenticated users
- Use `--json` flag for machine-readable output
```
"""


@dataclass
class WorldbookCommand:
    """A single command in a worldbook."""
    name: str
    usage: str
    description: str = ""
    parameters: list[str] = field(default_factory=list)
    examples: list[str] = field(default_factory=list)


@dataclass
class WorldbookExample:
    """A workflow example in a worldbook."""
    name: str
    description: str = ""
    commands: list[str] = field(default_factory=list)


@dataclass
class Worldbook:
    """Parsed worldbook data structure."""
    service: str
    website: str = ""
    cli_tool: str = ""
    authentication: str = ""
    description: str = ""
    commands: list[WorldbookCommand] = field(default_factory=list)
    examples: list[WorldbookExample] = field(default_factory=list)
    notes: list[str] = field(default_factory=list)
    raw_content: str = ""


def get_format_spec() -> str:
    """Return the worldbook format specification."""
    return WORLDBOOK_FORMAT_SPEC


def get_template(service_name: str = "myservice") -> str:
    """Generate a worldbook template for a service."""
    return f"""# {service_name.title()}

**Website**: https://{service_name}.com
**CLI Tool**: {service_name}
**Authentication**: API key via environment variable

## Description

{service_name.title()} is a service that does X. Use the CLI for all operations.

## Commands

### Command One

```bash
{service_name} command-one [options]
```

**Parameters**:
- `--option`: Description of option

**Example**:
```bash
{service_name} command-one --option value
```

### Command Two

```bash
{service_name} command-two <required-arg> [optional-arg]
```

## Examples

### Common Workflow

```bash
# Step 1: Authenticate
export {service_name.upper()}_API_KEY="your-key"

# Step 2: Do something
{service_name} command-one --option value

# Step 3: Verify
{service_name} command-two result
```

## Notes

- Rate limit: X requests per hour
- Use `--json` flag for machine-readable output
- Best practice: Always check return codes
"""


def parse_worldbook(content: str) -> Worldbook:
    """
    Parse a worldbook markdown file into structured data.

    Args:
        content: The markdown content of the worldbook

    Returns:
        Worldbook object with parsed data
    """
    lines = content.strip().split('\n')

    # Extract service name from title
    service = ""
    for line in lines:
        if line.startswith('# '):
            service = line[2:].strip()
            break

    # Extract metadata
    metadata = _extract_metadata(content)

    # Extract sections
    description = _extract_section(content, "Description")
    commands = _parse_commands(content)
    examples = _parse_examples(content)
    notes = _extract_notes(content)

    return Worldbook(
        service=service,
        website=metadata.get('website', ''),
        cli_tool=metadata.get('cli_tool', ''),
        authentication=metadata.get('authentication', ''),
        description=description,
        commands=commands,
        examples=examples,
        notes=notes,
        raw_content=content
    )


def _extract_metadata(content: str) -> dict:
    """Extract metadata from worldbook header."""
    metadata = {}

    # Website
    match = re.search(r'\*\*Website\*\*:\s*(.+)', content)
    if match:
        metadata['website'] = match.group(1).strip()

    # CLI Tool
    match = re.search(r'\*\*CLI Tool\*\*:\s*(.+)', content)
    if match:
        metadata['cli_tool'] = match.group(1).strip()

    # Authentication
    match = re.search(r'\*\*Authentication\*\*:\s*(.+)', content)
    if match:
        metadata['authentication'] = match.group(1).strip()

    return metadata


def _extract_section(content: str, section_name: str) -> str:
    """Extract content of a section by name."""
    pattern = rf'## {section_name}\s*\n(.*?)(?=\n## |\Z)'
    match = re.search(pattern, content, re.DOTALL)
    if match:
        return match.group(1).strip()
    return ""


def _parse_commands(content: str) -> list[WorldbookCommand]:
    """Parse all commands from the Commands section."""
    commands = []

    commands_section = _extract_section(content, "Commands")
    if not commands_section:
        return commands

    # Split by ### headers - add newline at start to ensure consistent splitting
    if not commands_section.startswith('\n'):
        commands_section = '\n' + commands_section
    cmd_blocks = re.split(r'\n### ', commands_section)

    for block in cmd_blocks[1:]:  # Skip first empty split
        lines = block.strip().split('\n')
        if not lines:
            continue

        name = lines[0].strip()
        usage = ""
        description = ""
        examples = []

        # Find code blocks for usage
        in_code = False
        code_content = []
        for line in lines[1:]:
            # Check if line starts with ``` (with optional language specifier)
            if line.strip().startswith('```'):
                if in_code:
                    if code_content:
                        if not usage:
                            usage = '\n'.join(code_content)
                        else:
                            examples.append('\n'.join(code_content))
                    code_content = []
                in_code = not in_code
            elif in_code:
                code_content.append(line)
            elif not in_code and line.strip() and not line.startswith('**'):
                description += line.strip() + " "

        commands.append(WorldbookCommand(
            name=name,
            usage=usage,
            description=description.strip(),
            examples=examples
        ))

    return commands


def _parse_examples(content: str) -> list[WorldbookExample]:
    """Parse workflow examples from the Examples section."""
    examples = []

    examples_section = _extract_section(content, "Examples")
    if not examples_section:
        return examples

    # Split by ### headers - add newline at start to ensure consistent splitting
    if not examples_section.startswith('\n'):
        examples_section = '\n' + examples_section
    example_blocks = re.split(r'\n### ', examples_section)

    for block in example_blocks[1:]:  # Skip first empty split
        lines = block.strip().split('\n')
        if not lines:
            continue

        name = lines[0].strip()
        commands = []
        description = ""

        # Find code blocks
        in_code = False
        code_content = []
        for line in lines[1:]:
            # Check if line starts with ``` (with optional language specifier)
            if line.strip().startswith('```'):
                if in_code and code_content:
                    commands.extend(code_content)
                    code_content = []
                in_code = not in_code
            elif in_code:
                code_content.append(line)
            elif not in_code and line.strip():
                description += line.strip() + " "

        examples.append(WorldbookExample(
            name=name,
            description=description.strip(),
            commands=commands
        ))

    return examples


def _extract_notes(content: str) -> list[str]:
    """Extract notes from the Notes section."""
    notes_section = _extract_section(content, "Notes")
    if not notes_section:
        return []

    notes = []
    for line in notes_section.split('\n'):
        line = line.strip()
        if line.startswith('- '):
            notes.append(line[2:])
        elif line.startswith('* '):
            notes.append(line[2:])

    return notes


def validate_worldbook(content: str) -> tuple[bool, list[str]]:
    """
    Validate a worldbook format.

    Args:
        content: The markdown content to validate

    Returns:
        (is_valid, errors) tuple
    """
    errors = []

    # Check for title
    if not re.search(r'^# .+', content, re.MULTILINE):
        errors.append("Missing service title (# ServiceName)")

    # Check for required metadata
    if '**Website**:' not in content:
        errors.append("Missing Website metadata")
    if '**CLI Tool**:' not in content:
        errors.append("Missing CLI Tool metadata")

    # Check for required sections
    required_sections = ['Description', 'Commands']
    for section in required_sections:
        if f'## {section}' not in content:
            errors.append(f"Missing required section: {section}")

    # Check for at least one command
    if '### ' not in content:
        errors.append("No commands defined (use ### CommandName)")

    return len(errors) == 0, errors
