"""
Knowledge Storage
=================

Store and retrieve knowledge for AI agents.
"""

from typing import Optional, List
from pathlib import Path
import sqlite3
import json
from datetime import datetime
import uuid


class Worldbook:
    """
    AI's Knowledge Base.

    "Human uses GUI, We uses CLI."
    """

    def __init__(self, db_path: Optional[Path] = None):
        """
        Initialize Worldbook.

        Args:
            db_path: Path to SQLite database. Defaults to ~/.worldbook/knowledge.db
        """
        if db_path is None:
            db_path = Path.home() / ".worldbook" / "knowledge.db"

        self.db_path = db_path
        self.db_path.parent.mkdir(parents=True, exist_ok=True)

        self._init_db()

    def _init_db(self):
        """Initialize database schema."""
        with sqlite3.connect(self.db_path) as conn:
            conn.execute("""
                CREATE TABLE IF NOT EXISTS knowledge (
                    id TEXT PRIMARY KEY,
                    content TEXT NOT NULL,
                    source TEXT,
                    tags TEXT,
                    metadata TEXT,
                    created_at TEXT,
                    updated_at TEXT
                )
            """)
            conn.execute("""
                CREATE INDEX IF NOT EXISTS idx_knowledge_source ON knowledge(source)
            """)
            conn.commit()

    def add(
        self,
        content: str,
        source: Optional[str] = None,
        tags: Optional[List[str]] = None,
        metadata: Optional[dict] = None
    ) -> dict:
        """
        Add a knowledge item.

        Args:
            content: The knowledge content
            source: Where this knowledge came from
            tags: List of tags for categorization
            metadata: Additional metadata

        Returns:
            dict with id and created item details
        """
        item_id = str(uuid.uuid4())
        now = datetime.utcnow().isoformat()

        with sqlite3.connect(self.db_path) as conn:
            conn.execute(
                """
                INSERT INTO knowledge (id, content, source, tags, metadata, created_at, updated_at)
                VALUES (?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    item_id,
                    content,
                    source,
                    json.dumps(tags or []),
                    json.dumps(metadata or {}),
                    now,
                    now
                )
            )
            conn.commit()

        return {
            "id": item_id,
            "content": content,
            "source": source,
            "tags": tags or [],
            "metadata": metadata or {},
            "created_at": now
        }

    def query(
        self,
        text: str,
        limit: int = 10,
        offset: int = 0
    ) -> List[dict]:
        """
        Query knowledge base.

        Args:
            text: Search text
            limit: Maximum results
            offset: Skip first N results

        Returns:
            List of matching knowledge items
        """
        with sqlite3.connect(self.db_path) as conn:
            conn.row_factory = sqlite3.Row
            cursor = conn.execute(
                """
                SELECT * FROM knowledge
                WHERE content LIKE ?
                ORDER BY created_at DESC
                LIMIT ? OFFSET ?
                """,
                (f"%{text}%", limit, offset)
            )

            results = []
            for row in cursor:
                results.append({
                    "id": row["id"],
                    "content": row["content"],
                    "source": row["source"],
                    "tags": json.loads(row["tags"]),
                    "metadata": json.loads(row["metadata"]),
                    "created_at": row["created_at"],
                    "updated_at": row["updated_at"]
                })

            return results

    def list(
        self,
        limit: int = 100,
        offset: int = 0,
        tags: Optional[List[str]] = None
    ) -> List[dict]:
        """
        List all knowledge items.

        Args:
            limit: Maximum results
            offset: Skip first N results
            tags: Filter by tags (any match)

        Returns:
            List of knowledge items
        """
        with sqlite3.connect(self.db_path) as conn:
            conn.row_factory = sqlite3.Row

            if tags:
                # Filter by tags (simple LIKE matching)
                tag_conditions = " OR ".join(["tags LIKE ?" for _ in tags])
                cursor = conn.execute(
                    f"""
                    SELECT * FROM knowledge
                    WHERE {tag_conditions}
                    ORDER BY created_at DESC
                    LIMIT ? OFFSET ?
                    """,
                    [f'%"{tag}"%' for tag in tags] + [limit, offset]
                )
            else:
                cursor = conn.execute(
                    """
                    SELECT * FROM knowledge
                    ORDER BY created_at DESC
                    LIMIT ? OFFSET ?
                    """,
                    (limit, offset)
                )

            results = []
            for row in cursor:
                results.append({
                    "id": row["id"],
                    "content": row["content"],
                    "source": row["source"],
                    "tags": json.loads(row["tags"]),
                    "metadata": json.loads(row["metadata"]),
                    "created_at": row["created_at"],
                    "updated_at": row["updated_at"]
                })

            return results

    def get(self, item_id: str) -> Optional[dict]:
        """
        Get a knowledge item by ID.

        Args:
            item_id: The item ID

        Returns:
            Knowledge item or None if not found
        """
        with sqlite3.connect(self.db_path) as conn:
            conn.row_factory = sqlite3.Row
            cursor = conn.execute(
                "SELECT * FROM knowledge WHERE id = ?",
                (item_id,)
            )
            row = cursor.fetchone()

            if row is None:
                return None

            return {
                "id": row["id"],
                "content": row["content"],
                "source": row["source"],
                "tags": json.loads(row["tags"]),
                "metadata": json.loads(row["metadata"]),
                "created_at": row["created_at"],
                "updated_at": row["updated_at"]
            }

    def delete(self, item_id: str) -> bool:
        """
        Delete a knowledge item.

        Args:
            item_id: The item ID

        Returns:
            True if deleted, False if not found
        """
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.execute(
                "DELETE FROM knowledge WHERE id = ?",
                (item_id,)
            )
            conn.commit()
            return cursor.rowcount > 0
