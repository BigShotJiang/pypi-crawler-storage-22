"""
Data Schemas
============

Pydantic models for Worldbook data structures.
All output should be structured and machine-readable.
"""

from pydantic import BaseModel, Field
from typing import Optional, List, Any
from datetime import datetime


class KnowledgeItem(BaseModel):
    """A piece of knowledge in the Worldbook."""

    id: str = Field(description="Unique identifier (UUID)")
    content: str = Field(description="The knowledge content")
    source: Optional[str] = Field(default=None, description="Where this knowledge came from")
    tags: List[str] = Field(default_factory=list, description="Tags for categorization")
    metadata: dict = Field(default_factory=dict, description="Additional metadata")
    created_at: datetime = Field(description="When this was created")
    updated_at: datetime = Field(description="When this was last updated")

    class Config:
        json_encoders = {
            datetime: lambda v: v.isoformat()
        }


class FetchResponse(BaseModel):
    """Response from fetching a URL."""

    url: str = Field(description="The final URL (after redirects)")
    status_code: int = Field(description="HTTP status code")
    content_type: str = Field(description="Content-Type header")
    content_length: int = Field(description="Content length in bytes")
    body: str = Field(description="Response body (may be truncated)")
    cached: bool = Field(default=False, description="Whether this was served from cache")
    fetched_at: datetime = Field(description="When this was fetched")


class ParseResponse(BaseModel):
    """Response from parsing a web page."""

    url: str = Field(description="The URL that was parsed")
    title: Optional[str] = Field(default=None, description="Page title")
    headings: List[str] = Field(default_factory=list, description="All headings (h1-h6)")
    paragraphs: List[str] = Field(default_factory=list, description="Paragraph text content")
    links: List[dict] = Field(default_factory=list, description="Links with href and text")
    main_content: Optional[str] = Field(default=None, description="Extracted main content")
    metadata: dict = Field(default_factory=dict, description="Page metadata (og:*, etc)")


class ErrorResponse(BaseModel):
    """Standard error response."""

    error: str = Field(description="Error code")
    message: str = Field(description="Human-readable error message")
    details: Optional[Any] = Field(default=None, description="Additional error details")


class QueryRequest(BaseModel):
    """Request for querying knowledge."""

    query: str = Field(description="Search query text")
    limit: int = Field(default=10, ge=1, le=100, description="Maximum results")
    offset: int = Field(default=0, ge=0, description="Skip first N results")
    tags: Optional[List[str]] = Field(default=None, description="Filter by tags")


class AddKnowledgeRequest(BaseModel):
    """Request for adding knowledge."""

    content: str = Field(description="The knowledge content")
    source: Optional[str] = Field(default=None, description="Where this came from")
    tags: Optional[List[str]] = Field(default=None, description="Tags for categorization")
    metadata: Optional[dict] = Field(default=None, description="Additional metadata")


class StatusResponse(BaseModel):
    """Worldbook status response."""

    version: str = Field(description="Worldbook version")
    status: str = Field(description="System status")
    motto: str = Field(default="Human uses GUI, We uses CLI.")
    phase: str = Field(description="Current development phase")
    features: dict = Field(description="Feature availability")
