"""Web platform for worldbook.site"""
