"""Comment tracking and management for worldbooks"""

import json
from pathlib import Path
from typing import Dict, List, Optional
from datetime import datetime
import threading
import uuid


class CommentManager:
    """Manages comments for worldbooks with simple JSON storage"""

    def __init__(self, storage_path: Path):
        self.storage_path = storage_path
        self.storage_path.parent.mkdir(parents=True, exist_ok=True)
        self._lock = threading.Lock()
        self._load_or_create()

    def _load_or_create(self):
        """Load comments from storage or create new storage"""
        if self.storage_path.exists():
            with open(self.storage_path, 'r', encoding='utf-8') as f:
                self.data = json.load(f)
        else:
            self.data = {
                "comments": {}  # service_name -> list of comments
            }
            self._save()

    def _save(self):
        """Save comments to storage"""
        with open(self.storage_path, 'w', encoding='utf-8') as f:
            json.dump(self.data, f, indent=2)

    def add_comment(self, service_name: str, author: str, content: str, parent_id: Optional[str] = None) -> Dict:
        """
        Add a comment to a worldbook

        Args:
            service_name: Name of the service/worldbook
            author: Name or identifier of the comment author
            content: Comment text (supports markdown)
            parent_id: Optional ID of parent comment for nested replies

        Returns:
            Dict with status and the created comment
        """
        with self._lock:
            # Initialize if service doesn't exist
            if service_name not in self.data["comments"]:
                self.data["comments"][service_name] = []

            # Validate content
            if not content or len(content.strip()) < 1:
                return {
                    "status": "error",
                    "message": "Comment content cannot be empty"
                }

            # Create comment
            comment = {
                "id": str(uuid.uuid4()),
                "author": author or "Anonymous",
                "content": content.strip(),
                "created_at": datetime.now().isoformat(),
                "parent_id": parent_id,
                "replies": []
            }

            # If this is a reply, add it to the parent's replies list
            if parent_id:
                parent_found = False
                for existing_comment in self.data["comments"][service_name]:
                    if existing_comment["id"] == parent_id:
                        existing_comment["replies"].append(comment)
                        parent_found = True
                        break

                if not parent_found:
                    return {
                        "status": "error",
                        "message": "Parent comment not found"
                    }
            else:
                # Add as top-level comment
                self.data["comments"][service_name].append(comment)

            # Save changes
            self._save()

            return {
                "status": "success",
                "comment": comment
            }

    def get_comments(self, service_name: str, limit: Optional[int] = None) -> List[Dict]:
        """
        Get all comments for a worldbook

        Args:
            service_name: Name of the service/worldbook
            limit: Optional limit on number of top-level comments returned

        Returns:
            List of comment dictionaries
        """
        comments = self.data["comments"].get(service_name, [])

        # Sort by created_at (most recent first)
        comments = sorted(comments, key=lambda x: x.get("created_at", ""), reverse=True)

        if limit:
            return comments[:limit]
        return comments

    def get_comment_count(self, service_name: str) -> int:
        """Get total comment count for a service (including replies)"""
        def count_comments(comments):
            total = len(comments)
            for comment in comments:
                total += count_comments(comment.get("replies", []))
            return total

        comments = self.data["comments"].get(service_name, [])
        return count_comments(comments)

    def delete_comment(self, service_name: str, comment_id: str) -> Dict:
        """
        Delete a comment (marks as deleted, doesn't actually remove to preserve reply structure)

        Args:
            service_name: Name of the service/worldbook
            comment_id: ID of the comment to delete

        Returns:
            Dict with status
        """
        with self._lock:
            if service_name not in self.data["comments"]:
                return {
                    "status": "error",
                    "message": "Service not found"
                }

            def find_and_delete(comments):
                for comment in comments:
                    if comment["id"] == comment_id:
                        comment["content"] = "[deleted]"
                        comment["author"] = "[deleted]"
                        return True
                    if find_and_delete(comment.get("replies", [])):
                        return True
                return False

            if find_and_delete(self.data["comments"][service_name]):
                self._save()
                return {
                    "status": "success",
                    "message": "Comment deleted"
                }
            else:
                return {
                    "status": "error",
                    "message": "Comment not found"
                }

    def get_all_comment_counts(self) -> Dict[str, int]:
        """Get comment counts for all services"""
        return {
            service_name: self.get_comment_count(service_name)
            for service_name in self.data["comments"].keys()
        }
