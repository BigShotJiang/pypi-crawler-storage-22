"""SQLite database for worldbook web app"""

import sqlite3
from pathlib import Path
from contextlib import contextmanager
from typing import Optional, List, Dict, Any
import json
from datetime import datetime

DB_PATH = Path(__file__).parent / "data" / "worldbook.db"


def get_db_path() -> Path:
    """Get database path, create directory if needed"""
    DB_PATH.parent.mkdir(parents=True, exist_ok=True)
    return DB_PATH


def init_db():
    """Initialize database tables"""
    with get_connection() as conn:
        conn.executescript('''
            CREATE TABLE IF NOT EXISTS votes (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                worldbook_name TEXT NOT NULL,
                user_id TEXT NOT NULL,
                vote INTEGER NOT NULL,  -- 1 or -1
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                UNIQUE(worldbook_name, user_id)
            );
            
            CREATE TABLE IF NOT EXISTS comments (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                worldbook_name TEXT NOT NULL,
                user_id TEXT NOT NULL,
                username TEXT,
                content TEXT NOT NULL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            );
            
            CREATE TABLE IF NOT EXISTS api_keys (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                key TEXT UNIQUE NOT NULL,
                user_id TEXT NOT NULL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            );
            
            CREATE INDEX IF NOT EXISTS idx_votes_worldbook ON votes(worldbook_name);
            CREATE INDEX IF NOT EXISTS idx_comments_worldbook ON comments(worldbook_name);
        ''')


@contextmanager
def get_connection():
    """Get database connection"""
    conn = sqlite3.connect(get_db_path())
    conn.row_factory = sqlite3.Row
    try:
        yield conn
        conn.commit()
    finally:
        conn.close()


# Vote functions
def get_votes(worldbook_name: str) -> Dict[str, int]:
    """Get vote counts for a worldbook"""
    with get_connection() as conn:
        row = conn.execute('''
            SELECT 
                COALESCE(SUM(CASE WHEN vote = 1 THEN 1 ELSE 0 END), 0) as upvotes,
                COALESCE(SUM(CASE WHEN vote = -1 THEN 1 ELSE 0 END), 0) as downvotes
            FROM votes WHERE worldbook_name = ?
        ''', (worldbook_name,)).fetchone()
        return {"upvotes": row["upvotes"], "downvotes": row["downvotes"]}


def get_user_vote(worldbook_name: str, user_id: str) -> Optional[int]:
    """Get user's vote for a worldbook"""
    with get_connection() as conn:
        row = conn.execute(
            'SELECT vote FROM votes WHERE worldbook_name = ? AND user_id = ?',
            (worldbook_name, user_id)
        ).fetchone()
        return row["vote"] if row else None


def set_vote(worldbook_name: str, user_id: str, vote: int) -> Dict[str, int]:
    """Set user's vote (1, -1, or 0 to remove)"""
    with get_connection() as conn:
        if vote == 0:
            conn.execute(
                'DELETE FROM votes WHERE worldbook_name = ? AND user_id = ?',
                (worldbook_name, user_id)
            )
        else:
            conn.execute('''
                INSERT INTO votes (worldbook_name, user_id, vote) VALUES (?, ?, ?)
                ON CONFLICT(worldbook_name, user_id) DO UPDATE SET vote = ?
            ''', (worldbook_name, user_id, vote, vote))
    return get_votes(worldbook_name)


# Comment functions
def get_comments(worldbook_name: str, limit: Optional[int] = None) -> List[Dict[str, Any]]:
    """Get comments for a worldbook"""
    with get_connection() as conn:
        query = '''
            SELECT id, user_id, username, content, created_at
            FROM comments WHERE worldbook_name = ?
            ORDER BY created_at DESC
        '''
        if limit:
            query += f' LIMIT {limit}'
        rows = conn.execute(query, (worldbook_name,)).fetchall()
        return [dict(row) for row in rows]


def add_comment(worldbook_name: str, user_id: str, content: str, username: Optional[str] = None) -> Dict[str, Any]:
    """Add a comment"""
    with get_connection() as conn:
        cursor = conn.execute('''
            INSERT INTO comments (worldbook_name, user_id, username, content)
            VALUES (?, ?, ?, ?)
        ''', (worldbook_name, user_id, username, content))
        return {
            "id": cursor.lastrowid,
            "user_id": user_id,
            "username": username,
            "content": content,
            "created_at": datetime.now().isoformat()
        }


# API key functions
def validate_api_key(key: str) -> Optional[str]:
    """Validate API key, return user_id if valid"""
    with get_connection() as conn:
        row = conn.execute(
            'SELECT user_id FROM api_keys WHERE key = ?', (key,)
        ).fetchone()
        return row["user_id"] if row else None


def create_api_key(user_id: str) -> str:
    """Create new API key for user"""
    import secrets
    key = f"wb_{secrets.token_urlsafe(32)}"
    with get_connection() as conn:
        conn.execute(
            'INSERT INTO api_keys (key, user_id) VALUES (?, ?)',
            (key, user_id)
        )
    return key


# Additional vote functions
def get_all_votes() -> Dict[str, Dict[str, int]]:
    """Get votes for all worldbooks"""
    with get_connection() as conn:
        rows = conn.execute('''
            SELECT worldbook_name,
                COALESCE(SUM(CASE WHEN vote = 1 THEN 1 ELSE 0 END), 0) as upvotes,
                COALESCE(SUM(CASE WHEN vote = -1 THEN 1 ELSE 0 END), 0) as downvotes
            FROM votes GROUP BY worldbook_name
        ''').fetchall()
        return {row["worldbook_name"]: {"upvotes": row["upvotes"], "downvotes": row["downvotes"]} for row in rows}


def get_vote_count(worldbook_name: str) -> int:
    """Get net vote count (upvotes - downvotes)"""
    votes = get_votes(worldbook_name)
    return votes["upvotes"] - votes["downvotes"]


def vote(worldbook_name: str, user_id: str, vote_value: int) -> Dict[str, Any]:
    """Vote on a worldbook, returns result with new counts"""
    set_vote(worldbook_name, user_id, vote_value)
    votes = get_votes(worldbook_name)
    return {
        "success": True,
        "upvotes": votes["upvotes"],
        "downvotes": votes["downvotes"],
        "score": votes["upvotes"] - votes["downvotes"]
    }


# Additional comment functions
def get_comment_count(worldbook_name: str) -> int:
    """Get comment count for a worldbook"""
    with get_connection() as conn:
        row = conn.execute(
            'SELECT COUNT(*) as count FROM comments WHERE worldbook_name = ?',
            (worldbook_name,)
        ).fetchone()
        return row["count"]


def delete_comment(worldbook_name: str, comment_id: int) -> bool:
    """Delete a comment"""
    with get_connection() as conn:
        cursor = conn.execute(
            'DELETE FROM comments WHERE worldbook_name = ? AND id = ?',
            (worldbook_name, comment_id)
        )
        return cursor.rowcount > 0


# Initialize on import
init_db()
