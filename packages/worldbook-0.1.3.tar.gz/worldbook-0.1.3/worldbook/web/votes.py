"""Vote tracking and management for worldbooks"""

import json
from pathlib import Path
from typing import Dict, Optional
from datetime import datetime
import threading


class VoteManager:
    """Manages votes for worldbooks with simple JSON storage"""

    def __init__(self, storage_path: Path):
        self.storage_path = storage_path
        self.storage_path.parent.mkdir(parents=True, exist_ok=True)
        self._lock = threading.Lock()
        self._load_or_create()

    def _load_or_create(self):
        """Load votes from storage or create new storage"""
        if self.storage_path.exists():
            with open(self.storage_path, 'r', encoding='utf-8') as f:
                self.data = json.load(f)
        else:
            self.data = {
                "votes": {},  # service_name -> vote_count
                "user_votes": {}  # user_id -> {service_name -> vote_direction}
            }
            self._save()

    def _save(self):
        """Save votes to storage"""
        with open(self.storage_path, 'w', encoding='utf-8') as f:
            json.dump(self.data, f, indent=2)

    def get_vote_count(self, service_name: str) -> int:
        """Get current vote count for a service"""
        return self.data["votes"].get(service_name, 0)

    def vote(self, service_name: str, user_id: str, direction: int) -> Dict:
        """
        Vote on a worldbook

        Args:
            service_name: Name of the service/worldbook
            user_id: Unique identifier for the user (e.g., session ID, IP hash)
            direction: 1 for upvote, -1 for downvote

        Returns:
            Dict with status, new vote count, and user's vote direction
        """
        with self._lock:
            # Validate direction
            if direction not in [1, -1]:
                return {
                    "status": "error",
                    "message": "Invalid vote direction. Must be 1 (upvote) or -1 (downvote)"
                }

            # Initialize if service doesn't exist
            if service_name not in self.data["votes"]:
                self.data["votes"][service_name] = 0

            # Initialize user votes if doesn't exist
            if user_id not in self.data["user_votes"]:
                self.data["user_votes"][user_id] = {}

            # Get previous vote for this user on this service
            previous_vote = self.data["user_votes"][user_id].get(service_name, 0)

            # Calculate vote change
            if previous_vote == direction:
                # User is removing their vote (clicking same button again)
                vote_change = -direction
                new_user_vote = 0
            elif previous_vote == 0:
                # User is voting for the first time
                vote_change = direction
                new_user_vote = direction
            else:
                # User is changing their vote (e.g., from upvote to downvote)
                vote_change = direction - previous_vote
                new_user_vote = direction

            # Update vote count
            self.data["votes"][service_name] += vote_change

            # Update user's vote record
            if new_user_vote == 0:
                # Remove vote record if user removed their vote
                self.data["user_votes"][user_id].pop(service_name, None)
            else:
                self.data["user_votes"][user_id][service_name] = new_user_vote

            # Save changes
            self._save()

            return {
                "status": "success",
                "vote_count": self.data["votes"][service_name],
                "user_vote": new_user_vote,
                "previous_vote": previous_vote
            }

    def get_user_vote(self, service_name: str, user_id: str) -> int:
        """Get user's current vote for a service (1, -1, or 0)"""
        return self.data["user_votes"].get(user_id, {}).get(service_name, 0)

    def get_top_worldbooks(self, limit: int = 10) -> list:
        """Get top worldbooks by vote count"""
        sorted_worldbooks = sorted(
            self.data["votes"].items(),
            key=lambda x: x[1],
            reverse=True
        )
        return [
            {"service_name": name, "votes": votes}
            for name, votes in sorted_worldbooks[:limit]
        ]

    def get_all_votes(self) -> Dict[str, int]:
        """Get all vote counts as a dictionary"""
        return self.data["votes"].copy()
