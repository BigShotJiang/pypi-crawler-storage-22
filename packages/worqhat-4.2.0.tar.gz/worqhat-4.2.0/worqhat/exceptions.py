"""Exception classes for the Worqhat SDK."""

from typing import Optional, Dict, Any


class WorqhatError(Exception):
    """Base exception for all Worqhat SDK errors."""

    def __init__(self, message: str, code: Optional[int] = None, details: Optional[Dict[str, Any]] = None):
        super().__init__(message)
        self.message = message
        self.code = code
        self.details = details or {}


class APIError(WorqhatError):
    """Raised when the API returns an error response."""

    pass


class AuthenticationError(WorqhatError):
    """Raised when authentication fails."""

    pass


class ValidationError(WorqhatError):
    """Raised when request validation fails."""

    pass


class NotFoundError(WorqhatError):
    """Raised when a resource is not found."""

    pass


class RateLimitError(WorqhatError):
    """Raised when rate limit is exceeded."""

    pass
