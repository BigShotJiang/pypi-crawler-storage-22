"""Storage resource for Worqhat SDK."""

from typing import TYPE_CHECKING, Optional, Dict, Any, BinaryIO, Union

if TYPE_CHECKING:
    from ..http_client import HTTPClient


class StorageResource:
    """Storage operations resource."""

    def __init__(self, client: "HTTPClient"):
        """Initialize the storage resource."""
        self._client = client

    def upload(
        self, file: Union[BinaryIO, bytes], path: Optional[str] = None
    ) -> Dict[str, Any]:
        """
        Upload a file to storage.

        Args:
            file: File object or bytes to upload.
            path: Optional path prefix for the file.

        Returns:
            Upload response with file ID and URL.
        """
        files = {"file": file}
        data: Dict[str, str] = {}

        if path:
            data["path"] = path

        return self._client.post("/api/storage/upload", data=data or None, files=files)

    def fetch(self, file_id: str) -> Dict[str, Any]:
        """
        Fetch a file record by ID and get a download URL.

        Args:
            file_id: File ID.

        Returns:
            File information with download URL.
        """
        return self._client.get(f"/api/storage/fetch/{file_id}")

    def fetch_by_path(self, filepath: str) -> Dict[str, Any]:
        """
        Fetch a file record by filepath and get a download URL.

        Args:
            filepath: File path.

        Returns:
            File information with download URL.
        """
        params = {"filepath": filepath}
        return self._client.get("/api/storage/fetch-by-path", params=params)

    def delete(self, file_id: str) -> Dict[str, Any]:
        """
        Delete a file from storage.

        Args:
            file_id: File ID.

        Returns:
            Delete response.
        """
        return self._client.delete(f"/api/storage/delete/{file_id}")
