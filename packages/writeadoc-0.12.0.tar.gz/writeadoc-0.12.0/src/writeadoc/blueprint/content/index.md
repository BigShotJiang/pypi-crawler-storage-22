---
title: Welcome to WriteADoc
---

Please read the [WriteADoc](https://writeadoc.scaletti.dev) documentation to learn how to use it.

---

This is the front page of your documentation. It's a special page for several reasons:

#. You don't include this file in your `pages` list.
#. This file **must** be named `index.md` and be directly inside the `content` folder, not in a subfolder.
#. Unlike other pages, it uses the `index.jinja` view.
