def test_instantiation(analyzer):
    assert analyzer is not None
