"""
wuji_sdk - Python bindings for Wuji SDK

Communicate with Wuji devices
"""

from typing import Any, Optional, List, Tuple, Generic, TypeVar, Literal, overload, Union, Callable

T = TypeVar("T")

def set_log_level(level: str) -> None:
    """Set SDK log level

    Control the output level of SDK internal logs.

    Note:
        The logging system is initialized when the module is imported.
        This function can only adjust the log level filter, not the format.

    Args:
        level: Log level, available values:
            - "trace": Most verbose, show all logs
            - "debug": Debug information
            - "info": General information (default)
            - "warn": Warnings only
            - "error": Errors only
            - "off": Disable log output

    Example:
        >>> import wuji_sdk
        >>> wuji_sdk.set_log_level("debug")  # Show debug and above
        >>> wuji_sdk.set_log_level("trace")  # Show all logs
        >>> wuji_sdk.set_log_level("info")   # Restore default
        >>> wuji_sdk.set_log_level("off")    # Disable logs
    """
    ...

class WujiException(Exception):
    """SDK unified exception type

    All SDK operation errors throw this exception.

    Common error types (identifiable by exception message):
        - DeviceNotFound: Device not found
        - DeviceMismatch: Device type mismatch
        - AmbiguousPath: Ambiguous path in multi-device scenario
        - InvalidPathFormat: Invalid path format
        - PathNotFound: Resource path does not exist
        - SchemaMismatch: Data type mismatch
        - Disconnected: Device disconnected
        - Timeout: Operation timed out
        - SerializeError: Serialization failed
        - DeserializeError: Deserialization failed
        - NoData: No data available
        - StreamClosed: Stream closed
        - UnsupportedOperation: Unsupported operation
        - Internal: Internal error

    Example:
        >>> try:
        ...     value = device.get("invalid.path")
        ... except WujiException as e:
        ...     print(f"SDK error: {e}")
    """
    ...

class TransportType:
    """Transport type enumeration"""
    Usb: "TransportType"
    Udp: "TransportType"

class ConnectOptions:
    """Connection options

    Attributes:
        timeout_ms: Timeout in milliseconds
        retry_count: Number of retries
    """
    timeout_ms: int
    retry_count: int

    def __init__(self, timeout_ms: int = 1000, retry_count: int = 3) -> None: ...

class Resource:
    """Resource descriptor

    Attributes:
        path: Resource path
        can_get: Supports GET operation
        can_set: Supports SET operation
        can_sub: Supports subscription
        can_pub: Supports publishing
        can_exec: Supports action execution
    """
    path: str
    can_get: bool
    can_set: bool
    can_sub: bool
    can_pub: bool
    can_exec: bool

class DiscoveredDevice:
    """Discovered device information

    Attributes:
        sn: Serial number
        address: Full address
        transport_type: Transport type
    """
    sn: str
    address: str
    transport_type: TransportType

class Topic:
    """Topic descriptor

    Attributes:
        path: Topic path
        can_sub: Supports subscription
        can_pub: Supports publishing
    """
    path: str
    can_sub: bool
    can_pub: bool

class FrameHeader:
    """Frame header information

    Attributes:
        seq: Sequence number
        timestamp_us: Timestamp in microseconds
        frame_id: Coordinate frame ID
    """
    seq: int
    timestamp_us: int
    frame_id: str

class TactileRawFrame:
    """Tactile raw data frame

    Attributes:
        header: Frame header
        data: 768 u16 raw sensor values (resistance)
    """
    header: FrameHeader
    data: List[int]

class TactileFrame:
    """Tactile calibrated data frame

    Attributes:
        header: Frame header
        data: 768 f32 pressure values (0.0 ~ 100.0)
    """
    header: FrameHeader
    data: List[float]

class Quaternion:
    """Quaternion orientation data

    Attributes:
        x: X component
        y: Y component
        z: Z component
        w: W component (scalar)
    """
    x: float
    y: float
    z: float
    w: float

class Pose:
    """Pose data

    Attributes:
        position: 3D position [x, y, z]
        orientation: Rotation quaternion
    """
    position: List[float]
    orientation: Quaternion

    def __init__(self, position: List[float], orientation: Quaternion) -> None: ...

class EmfPose:
    """EMF pose data

    Attributes:
        pose: Pose
        confidence: Solver confidence
    """
    pose: Pose
    confidence: float

class EmfPoseArray:
    """EMF pose array

    Attributes:
        header: Frame header (with coordinate frame ID)
        poses: List of poses
    """
    header: FrameHeader
    poses: List[EmfPose]

class FingertipPose:
    """Fingertip pose with confidence

    Attributes:
        pose: Fingertip pose (position + orientation)
        confidence: Solver confidence (0.0 ~ 1.0)
    """
    pose: Pose
    confidence: float

class FingertipPoses:
    """Fingertip poses for 5 fingers

    Attributes:
        header: Frame header (frame_id = wrist frame)
        poses: List of 5 fingertip poses
    """
    header: FrameHeader
    poses: List[FingertipPose]

class FingerJointAngles:
    """Joint angles for a single finger

    Angles are in radians.
    Thumb (5 DoF): [cmc_rot, cmc_flex, cmc_abd, mcp, ip]
    Other fingers (4 DoF): [mcp_abd, mcp_flex, pip, dip, 0]

    Attributes:
        angles: Joint angles (5 values, radians)
        confidence: IK solver confidence (0.0 ~ 1.0)
    """
    angles: List[float]
    confidence: float

class HandJointAngles:
    """Hand joint angles (20 DoF)

    IK solver output containing joint angles for all 5 fingers.

    Attributes:
        header: Frame header (frame_id = wrist frame)
        fingers: List of 5 FingerJointAngles (thumb, index, middle, ring, pinky)
    """
    header: FrameHeader
    fingers: List[FingerJointAngles]

class SkeletonJoint:
    """Skeleton joint (MediaPipe hand landmark)

    Attributes:
        name: MediaPipe landmark name (e.g. "index_finger_mcp")
        pose: Joint pose in wrist frame
        confidence: Confidence (0.0 ~ 1.0)
    """
    name: str
    pose: Pose
    confidence: float

class HandSkeleton:
    """Hand skeleton (21 MediaPipe hand landmarks)

    Attributes:
        header: Frame header (frame_id = wrist frame)
        joints: List of 21 skeleton joints
    """
    header: FrameHeader
    joints: List[SkeletonJoint]

class TactileZones:
    """Zoned tactile data frame

    Tactile data organized by finger zones.

    Attributes:
        header: Frame header
        palm: Palm zone tactile data
        thumb: Thumb zone tactile data
        index: Index finger zone tactile data
        middle: Middle finger zone tactile data
        ring: Ring finger zone tactile data
        pinky: Pinky finger zone tactile data
    """
    header: FrameHeader
    palm: List[float]
    thumb: List[float]
    index: List[float]
    middle: List[float]
    ring: List[float]
    pinky: List[float]

class Vector3:
    """3D vector (f32)

    Attributes:
        x: X component
        y: Y component
        z: Z component
    """
    x: float
    y: float
    z: float

class Vector3F64:
    """3D vector (f64)

    Attributes:
        x: X component
        y: Y component
        z: Z component
    """
    x: float
    y: float
    z: float

class FrameTransform:
    """Coordinate frame transform

    Attributes:
        timestamp_us: Timestamp in microseconds
        parent_frame_id: Parent frame ID
        child_frame_id: Child frame ID
        translation: Translation [x, y, z]
        rotation: Rotation quaternion
    """
    timestamp_us: int
    parent_frame_id: str
    child_frame_id: str
    translation: List[float]
    rotation: Quaternion

class FrameTransforms:
    """Collection of coordinate frame transforms

    Attributes:
        transforms: List of transforms
    """
    transforms: List[FrameTransform]

class ImuData:
    """IMU data (ROS sensor_msgs/Imu compatible)

    Attributes:
        header: Frame header
        orientation: Orientation quaternion
        orientation_covariance: 3x3 row-major covariance matrix
        angular_velocity: Angular velocity (rad/s)
        angular_velocity_covariance: 3x3 row-major covariance matrix
        linear_acceleration: Linear acceleration (m/s²)
        linear_acceleration_covariance: 3x3 row-major covariance matrix
    """
    header: FrameHeader
    orientation: Quaternion
    orientation_covariance: List[float]
    angular_velocity: Vector3F64
    angular_velocity_covariance: List[float]
    linear_acceleration: Vector3F64
    linear_acceleration_covariance: List[float]

class PointField:
    """Point cloud field descriptor

    Describes a single field in the point cloud binary data layout.

    Attributes:
        name: Field name (e.g. "x", "y", "z", "red")
        offset: Byte offset within each point
        type: Numeric type (1=uint8, 3=uint16, 5=uint32, 7=float32, 8=float64)
    """
    name: str
    offset: int
    type: int

class PointCloud:
    """Point cloud data

    Binary-packed point cloud with field descriptors.
    Default layout: [x: f32, y: f32, z: f32, red: u8, green: u8, blue: u8, alpha: u8], stride=16.

    Attributes:
        header: Frame header
        frame_id: Reference coordinate frame
        point_stride: Bytes per point
        fields: Field descriptors
        data: Raw binary point data
    """
    header: FrameHeader
    frame_id: str
    point_stride: int
    fields: List[PointField]
    data: List[int]

    def point_count(self) -> int:
        """Get number of points in the cloud"""
        ...

class Subscription(Generic[T]):
    """Subscription handle

    Used to receive data streams from the device.

    Attributes:
        dtype: Data type name
    """
    dtype: str

    def recv(self) -> Optional[T]:
        """Receive data (synchronous, non-blocking)

        Returns immediately, returns None if no data available.

        Returns:
            Received data or None

        Raises:
            WujiException: Connection disconnected
        """
        ...

    async def recv_async(self) -> T:
        """Receive data (asynchronous)

        Waits for the next data to arrive. Supports Python async/await syntax.

        Returns:
            Received data, type determined by dtype at creation

        Raises:
            WujiException: Receive failed or connection disconnected
        """
        ...

class CallbackSubscription:
    """Callback subscription handle

    Created via subscribe_with_callback(), automatically receives data
    in background thread and triggers callbacks.

    Attributes:
        dtype: Data type name
        is_active: Whether callback is still running
        received_count: Number of data frames received
        error_count: Number of errors occurred
    """
    dtype: str
    is_active: bool
    received_count: int
    error_count: int

    def close(self) -> None:
        """Stop callback and close subscription

        This method will:
        1. Stop background receiving thread
        2. Wait for current callback to complete
        3. Close underlying subscription
        """
        ...

    def __enter__(self) -> "CallbackSubscription":
        """Context manager entry"""
        ...

    def __exit__(self, *args: Any) -> None:
        """Context manager exit, automatically calls close()"""
        ...

class Publisher:
    """Publisher handle

    Used to send data streams to the device.

    Attributes:
        dtype: Data type name
    """
    dtype: str

    def send(self, data: Any) -> None:
        """Send data (synchronous)

        Considered successful once transport sends the data, does not wait for response.
        Suitable for high-frequency data sending scenarios.

        Args:
            data: Data to send

        Raises:
            WujiException: Data type mismatch or send failed
        """
        ...

    async def send_async(self, data: Any) -> None:
        """Send data (asynchronous)

        Data is serialized before sending, large data is automatically chunked.

        Args:
            data: Data to send

        Raises:
            WujiException: Data type mismatch or send failed
        """
        ...

class WujiDevice:
    """Device handle

    Lightweight handle, safe to clone. Provides resource read/write and subscription.

    Attributes:
        device_name: Device name
        serial_number: Device serial number
        is_connected: Whether connected
    """
    device_name: str
    serial_number: str
    is_connected: bool

    def resources(self) -> List[Resource]:
        """Get resource list

        Returns:
            List of resources supported by the device
        """
        ...

    def params(self) -> List[Resource]:
        """Get Param resource list

        Returns:
            List of Param resources
        """
        ...

    def topics(self) -> List[Topic]:
        """Get Topic resource list

        Returns:
            List of Topic resources
        """
        ...

    def get(self, path: str) -> Any:
        """Get resource value (synchronous)

        Args:
            path: Resource path (without leading slash), e.g., "firmware_version"

        Returns:
            Resource value

        Raises:
            WujiException: Resource does not exist or get failed
        """
        ...

    def set(self, path: str, value: Any) -> None:
        """Set resource value (synchronous)

        Args:
            path: Resource path
            value: Value to set

        Raises:
            WujiException: Invalid path format or set failed
        """
        ...

    def execute(self, path: str) -> None:
        """Execute ACTION (synchronous)

        Args:
            path: ACTION resource path, e.g., "factory_reset"

        Raises:
            WujiException: Resource does not exist, does not support ACTION, or execution failed
        """
        ...

    def subscribe(self, path: str) -> Subscription[Any]:
        """Subscribe to resource stream

        Args:
            path: Resource path

        Returns:
            Subscription handle

        Raises:
            WujiException: Resource does not exist or subscription failed
        """
        ...

    def publish(self, path: str) -> Publisher:
        """Create publish stream

        Args:
            path: Resource path

        Returns:
            Publisher handle

        Raises:
            WujiException: Resource does not exist or creation failed
        """
        ...

    def disconnect(self) -> None:
        """Disconnect

        Raises:
            WujiException: Disconnect failed
        """
        ...

    # ========== Device Log ==========

    def get_device_log_dir(self) -> str:
        """Get device log binary file storage directory

        Returns the path where log files are stored, default is `~/.wuji/logs/`.
        Log files are named in `device_YYYY-MM-DD.bin` format.

        Device logs are automatically output to terminal via log crate, no manual callback needed.
        SDK will automatically download ELF files and decode logs.

        Returns:
            Log file storage directory path
        """
        ...

    def set_device_log_elf(self, elf_path: str) -> None:
        """Manually set firmware ELF file path (optional)

        Set the ELF file path for decoding defmt logs.
        Usually not needed as SDK automatically downloads ELF based on device SN and firmware version.

        Use cases:
        - Local development/debugging (ELF not yet uploaded to server)
        - Offline environment
        - Private/custom firmware

        Args:
            elf_path: Absolute path to ELF file

        Raises:
            WujiException: ELF file read or parse failed
        """
        ...

class SdkManager:
    """SDK Manager

    Singleton pattern, obtain via `SdkManager.instance()`.
    Provides device discovery, connection management, and path routing.
    """

    @staticmethod
    def instance() -> "SdkManager":
        """Get singleton instance

        Returns:
            SDK manager instance
        """
        ...

    def scan(self) -> List[DiscoveredDevice]:
        """Scan all available devices (USB + UDP)

        Returns:
            List of discovered devices

        Raises:
            WujiException: Scan failed
        """
        ...

    def connect(
        self,
        *,
        sn: Optional[str] = None,
        address: Optional[str] = None,
        device_name: str,
        options: Optional[ConnectOptions] = None,
    ) -> Union[WujiDevice, "WujiGlove"]:
        """Connect to device

        Connect via serial number or address. Exactly one of sn or address must be provided.
        device_name is required.

        Automatically returns the appropriate semantic API type based on device type.
        For example, connecting to a Wuji Glove returns a WujiGlove instance.

        Args:
            sn: Device serial number
            address: Device address (IP:port or serial port path)
            device_name: Device name (required)
            options: Connection options (optional)

        Returns:
            WujiDevice or WujiGlove based on device type

        Raises:
            ValueError: device_name not provided, or both sn and address provided
            WujiException: Connection failed
        """
        ...

    def auto_connect(self, device_name: str) -> Union[WujiDevice, "WujiGlove"]:
        """Auto-connect to the first discovered device

        Automatically returns the appropriate semantic API type based on device type.
        For example, connecting to a Wuji Glove returns a WujiGlove instance.

        Args:
            device_name: Device name (required)

        Returns:
            WujiDevice or WujiGlove based on device type

        Raises:
            WujiException: No device found or connection failed
        """
        ...

    def get_device(self, device_name: str) -> Optional[WujiDevice]:
        """Get connected device handle

        Args:
            device_name: Device name

        Returns:
            Device handle, or None if not found
        """
        ...

    def get_connected_devices(self) -> List[Tuple[str, WujiDevice]]:
        """Get all connected devices

        Returns:
            List of (device_name, device_handle) tuples
        """
        ...

    def disconnect(self, device_name: str) -> None:
        """Disconnect specified device

        Args:
            device_name: Device name

        Raises:
            WujiException: Disconnect failed
        """
        ...

    def disconnect_all(self) -> None:
        """Disconnect all devices

        Raises:
            WujiException: Disconnect failed
        """
        ...

    def get(self, path: str) -> Any:
        """Get resource value (via path routing)

        Path format:
        - Root node resource: device_name.param (e.g., left_hand.device_name)
        - Child node resource: device_name/node.param (e.g., left_hand/sensor.gain)

        Separator rules:
        - Root node: Use `.` to connect device name and parameter
        - Child node: Use `/` to access nodes, `.` to separate node levels

        Args:
            path: Resource path

        Returns:
            Resource value

        Raises:
            WujiException: Invalid path format, device does not exist, or get failed
        """
        ...

    def set(self, path: str, value: Any) -> None:
        """Set resource value (via path routing)

        Args:
            path: Resource path
            value: Value to set

        Raises:
            WujiException: Invalid path format, device does not exist, or set failed
        """
        ...

    def execute(self, path: str) -> None:
        """Execute ACTION (via path routing)

        Args:
            path: ACTION resource path

        Raises:
            WujiException: Invalid path format, resource does not exist, or execution failed
        """
        ...

    def subscribe(self, path: str) -> Subscription:
        """Subscribe to resource stream (via path routing)

        Path format: `device_name/node/topic`, e.g., "left_hand/sensor/tactile_matrix"

        Args:
            path: Resource path (must start with device_name)

        Returns:
            Subscription handle

        Raises:
            WujiException: Invalid path format or subscription failed
        """
        ...

    def publish(self, path: str) -> Publisher:
        """Create publish stream (via path routing)

        Path format: `device_name/node/topic`, e.g., "left_hand/test_pub"

        Args:
            path: Resource path (must start with device_name)

        Returns:
            Publisher handle

        Raises:
            WujiException: Invalid path format or creation failed
        """
        ...

    def get_all_topics(self) -> List[Tuple[str, Topic]]:
        """Get topic list for all connected devices

        Returns:
            List of (device_name, Topic) tuples
        """
        ...

# ==================== WujiGlove ====================

class WujiGlove:
    """WujiGlove haptic glove device

    Wraps WujiDevice to provide type-safe semantic API.

    When connecting to a Wuji Glove device, SDK automatically returns this type.

    Attributes:
        serial_number: Device serial number
        device_name: Device name

    Example:
        >>> from wuji_sdk import SdkManager
        >>>
        >>> manager = SdkManager.instance()
        >>> glove = manager.auto_connect(device_name="my_glove")
        >>>
        >>> # Read hand side
        >>> side = glove.hand_side().get()
        >>>
        >>> # Subscribe to tactile data
        >>> sub = glove.tactile().subscribe()
    """

    serial_number: str
    device_name: str

    def __init__(self, device: WujiDevice) -> None:
        """Create WujiGlove semantic API from WujiDevice

        Args:
            device: Connected device handle
        """
        ...

    # ========== Common Device Resources ==========

    def sn(self) -> "SerialNumber":
        """Serial number resource

        Path: serial_number
        Type: str (16 bytes)
        Access: GET

        Returns:
            Serial number resource object
        """
        ...

    def version(self) -> "FirmwareVersion":
        """Firmware version resource

        Path: firmware_version
        Type: str
        Access: GET

        Returns:
            Firmware version resource object
        """
        ...

    def ip(self) -> "IpAddress":
        """IP address resource

        Path: ip_address
        Type: str
        Access: GET, SET

        Returns:
            IP address resource object
        """
        ...

    def port(self) -> "DataPort":
        """Data port resource

        Path: data_port
        Type: u16
        Access: GET, SET

        Returns:
            Data port resource object
        """
        ...

    # ========== WujiGlove Resources ==========

    def hand_side(self) -> "HandSide":
        """Hand side parameter

        Path: hand_side
        Type: str ("left" / "right")
        Access: GET

        Returns:
            Hand side resource object
        """
        ...

    # ========== ACTION Resources ==========

    def factory_reset(self) -> None:
        """Factory reset

        Path: factory_reset
        Type: ACTION

        Raises:
            WujiException: Execution failed
        """
        ...

    def reboot(self) -> None:
        """Reboot device

        Path: reboot
        Type: ACTION

        Raises:
            WujiException: Execution failed
        """
        ...

    # ========== Topic Resources ==========

    def tactile(self) -> "Tactile":
        """Calibrated tactile data topic

        Path: tactile
        Type: TactileFrame
        Access: SUB

        Returns:
            Calibrated tactile data resource object
        """
        ...

    def tactile_zones(self) -> "TactileZonesResource":
        """Zoned tactile data topic

        Path: tactile_zones
        Type: TactileZones
        Access: SUB

        Returns:
            Zoned tactile data resource object
        """
        ...

    def emf_poses(self) -> "EmfPosesResource":
        """EMF pose data topic (virtual resource)

        Path: emf_poses
        Type: EmfPoseArray
        Access: SUB

        Returns:
            EMF pose data resource object
        """
        ...

    def tip_poses(self) -> "TipPosesResource":
        """Fingertip poses topic (virtual resource)

        Path: tip_poses
        Type: FingertipPoses
        Access: SUB

        Returns:
            TipPosesResource: Fingertip poses resource object
        """
        ...

    def hand_joint_angles(self) -> "HandJointAnglesResource":
        """Hand joint angles topic (virtual resource)

        Path: hand_joint_angles
        Type: HandJointAngles
        Access: SUB

        Returns:
            HandJointAnglesResource: Hand joint angles resource object
        """
        ...

    def hand_skeleton(self) -> "HandSkeletonResource":
        """Hand skeleton topic (virtual resource)

        Path: hand_skeleton
        Type: HandSkeleton
        Access: SUB

        Returns:
            HandSkeletonResource: Hand skeleton resource object
        """
        ...

    def tactile_point_cloud(self) -> "PointCloudResource":
        """Tactile point cloud topic (virtual resource)

        Generates 3D point cloud from hand skeleton and tactile data.

        Path: tactile_point_cloud
        Type: PointCloud
        Access: SUB

        Returns:
            PointCloudResource: Tactile point cloud resource object
        """
        ...

    def tf_static(self) -> "TfStaticResource":
        """Static coordinate transforms (virtual resource)

        Publishes fixed frame relationships (e.g. wrist -> emf_tx) at 1 Hz.

        Path: tf_static
        Type: FrameTransforms
        Access: SUB

        Returns:
            TfStaticResource: Static coordinate transforms resource object
        """
        ...

    def tf(self) -> "TfResource":
        """Dynamic coordinate transforms (virtual resource)

        Publishes IMU-driven dynamic transforms (e.g. world -> wrist), data-driven.

        Path: tf
        Type: FrameTransforms
        Access: SUB

        Returns:
            TfResource: Dynamic coordinate transforms resource object
        """
        ...

    def imu_palm(self) -> "ImuResource":
        """Palm IMU data topic

        Type: ImuData (ROS sensor_msgs/Imu compatible)
        Access: SUB

        Returns:
            ImuResource: Palm IMU data resource object
        """
        ...

    def imu_thumb(self) -> "ImuResource":
        """Thumb IMU data topic

        Returns:
            ImuResource: Thumb IMU data resource object
        """
        ...

    def imu_index(self) -> "ImuResource":
        """Index finger IMU data topic

        Returns:
            ImuResource: Index finger IMU data resource object
        """
        ...

    def imu_middle(self) -> "ImuResource":
        """Middle finger IMU data topic

        Returns:
            ImuResource: Middle finger IMU data resource object
        """
        ...

    def imu_ring(self) -> "ImuResource":
        """Ring finger IMU data topic

        Returns:
            ImuResource: Ring finger IMU data resource object
        """
        ...

    def imu_pinky(self) -> "ImuResource":
        """Pinky finger IMU data topic

        Returns:
            ImuResource: Pinky finger IMU data resource object
        """
        ...

    def disconnect(self) -> None:
        """Disconnect device

        Raises:
            WujiException: Disconnect failed
        """
        ...

    def save_params(self) -> None:
        """Save all parameters to disk"""
        ...

    # ========== Device Logging ==========

    def get_device_log_dir(self) -> str:
        """Get device log binary file storage directory

        Returns:
            Log file storage directory path
        """
        ...

    def set_device_log_elf(self, elf_path: str) -> None:
        """Manually set firmware ELF file path

        Args:
            elf_path: Absolute path to ELF file

        Raises:
            WujiException: ELF file read or parse failed
        """
        ...


# ==================== Resource Type Classes ====================

class SerialNumber:
    """Serial number resource

    Path: serial_number
    Type: str (16 bytes)
    Access: GET
    """

    def get(self) -> str:
        """Get serial number

        Returns:
            16-byte serial number string
        """
        ...

class FirmwareVersion:
    """Firmware version resource

    Path: firmware_version
    Type: str
    Access: GET
    """

    def get(self) -> str:
        """Get firmware version

        Returns:
            Firmware version string
        """
        ...

class IpAddress:
    """IP address resource

    Path: ip_address
    Type: str
    Access: GET, SET
    """

    def get(self) -> str:
        """Get IP address

        Returns:
            IP address string
        """
        ...

    def set(self, value: str) -> None:
        """Set IP address

        Args:
            value: New IP address
        """
        ...

class DataPort:
    """Data port resource

    Path: data_port
    Type: u16
    Access: GET, SET
    """

    def get(self) -> int:
        """Get data port

        Returns:
            Port number
        """
        ...

    def set(self, value: int) -> None:
        """Set data port

        Args:
            value: New port number
        """
        ...

class HandSide:
    """Hand side resource

    Path: hand_side
    Type: str ("left" / "right")
    Access: GET
    """

    def get(self) -> str:
        """Get hand side

        Returns:
            "left" or "right"
        """
        ...

class Tactile:
    """Calibrated tactile data resource

    Path: tactile
    Type: TactileFrame
    Access: SUB
    """

    def subscribe(self) -> Subscription[TactileFrame]:
        """Subscribe to calibrated tactile data stream

        Returns:
            Subscription handle
        """
        ...

    def subscribe_with_callback(
        self,
        callback: Callable[[TactileFrame], None],
        on_error: Optional[Callable[[str], None]] = None,
    ) -> CallbackSubscription:
        """Subscribe with callback to calibrated tactile data stream

        Automatically receives data in background thread and triggers callback.

        Args:
            callback: Data callback function, receives TactileFrame parameter
            on_error: Error callback function (optional), receives error message string

        Returns:
            CallbackSubscription handle

        Example:
            >>> def on_data(frame):
            ...     print(f"Max pressure: {max(frame.data)}")
            >>> sub = glove.tactile().subscribe_with_callback(callback=on_data)
            >>> time.sleep(10)
            >>> sub.close()
        """
        ...

class TactileZonesResource:
    """Zoned tactile data resource

    Path: tactile_zones
    Type: TactileZones
    Access: SUB
    """

    def subscribe(self) -> Subscription[TactileZones]:
        """Subscribe to zoned tactile data stream

        Returns:
            Subscription handle
        """
        ...

    def subscribe_with_callback(
        self,
        callback: Callable[[TactileZones], None],
        on_error: Optional[Callable[[str], None]] = None,
    ) -> CallbackSubscription:
        """Subscribe with callback to zoned tactile data stream

        Automatically receives data in background thread and triggers callback.

        Args:
            callback: Data callback function, receives TactileZones parameter
            on_error: Error callback function (optional), receives error message string

        Returns:
            CallbackSubscription handle

        Example:
            >>> def on_data(zones):
            ...     print(f"Palm: {zones.palm}, Thumb: {zones.thumb}")
            >>> sub = glove.tactile_zones().subscribe_with_callback(callback=on_data)
            >>> time.sleep(10)
            >>> sub.close()
        """
        ...

class EmfPosesResource:
    """EMF pose data resource (virtual resource)

    Path: emf_poses
    Type: EmfPoseArray
    Access: SUB
    """

    def subscribe(self) -> Subscription[EmfPoseArray]:
        """Subscribe to EMF pose data stream

        Returns 5-finger pose (position and orientation) data

        Returns:
            Subscription handle
        """
        ...

    def subscribe_with_callback(
        self,
        callback: Callable[[EmfPoseArray], None],
        on_error: Optional[Callable[[str], None]] = None,
    ) -> CallbackSubscription:
        """Subscribe with callback to EMF pose data stream

        Automatically receives data in background thread and triggers callback.

        Args:
            callback: Data callback function, receives EmfPoseArray parameter
            on_error: Error callback function (optional), receives error message string

        Returns:
            CallbackSubscription handle

        Example:
            >>> def on_data(poses):
            ...     for pose in poses.poses:
            ...         print(f"Position: {pose.pose.position}")
            >>> sub = glove.emf_poses().subscribe_with_callback(callback=on_data)
            >>> time.sleep(10)
            >>> sub.close()
        """
        ...

class TipPosesResource:
    """Fingertip poses resource (virtual resource)

    Path: tip_poses
    Type: FingertipPoses
    Access: SUB
    """

    def subscribe(self) -> Subscription[FingertipPoses]:
        """Subscribe to fingertip poses data stream

        Returns:
            Subscription handle
        """
        ...

    def subscribe_with_callback(
        self,
        callback: Callable[[FingertipPoses], None],
        on_error: Optional[Callable[[str], None]] = None,
    ) -> CallbackSubscription:
        """Subscribe with callback to fingertip poses data stream

        Args:
            callback: Data callback function, receives FingertipPoses parameter
            on_error: Error callback function (optional)

        Returns:
            CallbackSubscription handle
        """
        ...

class HandJointAnglesResource:
    """Hand joint angles resource (virtual resource)

    Path: hand_joint_angles
    Type: HandJointAngles
    Access: SUB
    """

    def subscribe(self) -> Subscription[HandJointAngles]:
        """Subscribe to hand joint angles data stream

        Returns:
            Subscription handle
        """
        ...

    def subscribe_with_callback(
        self,
        callback: Callable[[HandJointAngles], None],
        on_error: Optional[Callable[[str], None]] = None,
    ) -> CallbackSubscription:
        """Subscribe with callback to hand joint angles data stream

        Args:
            callback: Data callback function, receives HandJointAngles parameter
            on_error: Error callback function (optional)

        Returns:
            CallbackSubscription handle
        """
        ...

class HandSkeletonResource:
    """Hand skeleton resource (virtual resource)

    Path: hand_skeleton
    Type: HandSkeleton
    Access: SUB
    """

    def subscribe(self) -> Subscription[HandSkeleton]:
        """Subscribe to hand skeleton data stream

        Returns:
            Subscription handle
        """
        ...

    def subscribe_with_callback(
        self,
        callback: Callable[[HandSkeleton], None],
        on_error: Optional[Callable[[str], None]] = None,
    ) -> CallbackSubscription:
        """Subscribe with callback to hand skeleton data stream

        Args:
            callback: Data callback function, receives HandSkeleton parameter
            on_error: Error callback function (optional)

        Returns:
            CallbackSubscription handle
        """
        ...

class PointCloudResource:
    """Tactile point cloud resource (virtual resource)

    Path: tactile_point_cloud
    Type: PointCloud
    Access: SUB
    """

    def subscribe(self) -> Subscription[PointCloud]:
        """Subscribe to tactile point cloud data stream

        Returns:
            Subscription handle
        """
        ...

    def subscribe_with_callback(
        self,
        callback: Callable[[PointCloud], None],
        on_error: Optional[Callable[[str], None]] = None,
    ) -> CallbackSubscription:
        """Subscribe with callback to tactile point cloud data stream

        Args:
            callback: Data callback function, receives PointCloud parameter
            on_error: Error callback function (optional)

        Returns:
            CallbackSubscription handle
        """
        ...

class TfStaticResource:
    """Static coordinate transforms resource (virtual resource)

    Path: tf_static
    Type: FrameTransforms
    Access: SUB

    Publishes fixed frame relationships (e.g. wrist -> emf_tx) at 1 Hz.
    """

    def subscribe(self) -> Subscription[FrameTransforms]:
        """Subscribe to static coordinate transforms

        Returns:
            Subscription handle
        """
        ...

    def subscribe_with_callback(
        self,
        callback: Callable[[FrameTransforms], None],
        on_error: Optional[Callable[[str], None]] = None,
    ) -> CallbackSubscription:
        """Subscribe with callback to static coordinate transforms

        Args:
            callback: Data callback function, receives FrameTransforms parameter
            on_error: Error callback function (optional)

        Returns:
            CallbackSubscription handle
        """
        ...

class TfResource:
    """Dynamic coordinate transforms resource (virtual resource)

    Path: tf
    Type: FrameTransforms
    Access: SUB

    Publishes IMU-driven dynamic transforms (e.g. world -> wrist), data-driven.
    """

    def subscribe(self) -> Subscription[FrameTransforms]:
        """Subscribe to dynamic coordinate transforms

        Returns:
            Subscription handle
        """
        ...

    def subscribe_with_callback(
        self,
        callback: Callable[[FrameTransforms], None],
        on_error: Optional[Callable[[str], None]] = None,
    ) -> CallbackSubscription:
        """Subscribe with callback to dynamic coordinate transforms

        Args:
            callback: Data callback function, receives FrameTransforms parameter
            on_error: Error callback function (optional)

        Returns:
            CallbackSubscription handle
        """
        ...

class ImuResource:
    """IMU data resource

    Path: imu_raw/* (palm/thumb/index/middle/ring/pinky)
    Type: ImuData (ROS sensor_msgs/Imu compatible)
    Access: SUB
    """

    def subscribe(self) -> Subscription[ImuData]:
        """Subscribe to IMU data stream

        Returns:
            Subscription handle
        """
        ...

    def subscribe_with_callback(
        self,
        callback: Callable[[ImuData], None],
        on_error: Optional[Callable[[str], None]] = None,
    ) -> CallbackSubscription:
        """Subscribe with callback to IMU data stream

        Args:
            callback: Data callback function, receives ImuData parameter
            on_error: Error callback function (optional)

        Returns:
            CallbackSubscription handle
        """
        ...
