# -*- coding: utf-8; -*-
################################################################################
#
#  WuttaFarm --Web app to integrate with and extend farmOS
#  Copyright © 2026 Lance Edgar
#
#  This file is part of WuttaFarm.
#
#  WuttaFarm is free software: you can redistribute it and/or modify it under
#  the terms of the GNU General Public License as published by the Free Software
#  Foundation, either version 3 of the License, or (at your option) any later
#  version.
#
#  WuttaFarm is distributed in the hope that it will be useful, but WITHOUT ANY
#  WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR
#  A PARTICULAR PURPOSE.  See the GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License along with
#  WuttaFarm.  If not, see <http://www.gnu.org/licenses/>.
#
################################################################################
"""
Base class for farmOS master views
"""

from wuttaweb.views import MasterView


class FarmOSMasterView(MasterView):
    """
    Base class for farmOS master views
    """

    model_key = "uuid"

    creatable = False
    editable = False
    deletable = False

    filterable = False
    sort_on_backend = False
    paginate_on_backend = False

    farmos_refurl_path = None

    def __init__(self, request, context=None):
        super().__init__(request, context=context)
        self.farmos_client = self.get_farmos_client()

    def get_farmos_client(self):
        token = self.request.session.get("farmos.oauth2.token")
        if not token:
            raise self.forbidden()

        def token_updater(token):
            self.request.session["farmos.oauth2.token"] = token

        # nb. must give a *copy* of the token to farmOS client, since
        # it will mutate it in-place and we don't want that to happen
        # for our original copy in the user session.  (otherwise the
        # auto-refresh will not work correctly for subsequent calls.)
        token = dict(token)

        return self.app.get_farmos_client(token=token, token_updater=token_updater)

    def get_template_context(self, context):

        if self.listing and self.farmos_refurl_path:
            context["farmos_refurl"] = self.app.get_farmos_url(self.farmos_refurl_path)

        return context
