
# Changelog
All notable changes to WuttaFarm will be documented in this file.

The format is based on [Keep a Changelog](http://keepachangelog.com/en/1.0.0/)
and this project adheres to [Semantic Versioning](http://semver.org/spec/v2.0.0.html).

## v0.1.3 (2026-02-06)

### Fix

- fix a couple more edge cases around oauth2 token refresh

## v0.1.2 (2026-02-06)

### Fix

- add support for farmOS/OAuth2 Authorization Code grant/workflow

## v0.1.1 (2026-02-05)

### Fix

- preserve oauth2 token so auto-refresh works correctly
- customize app installer to configure farmos_url
- add some more info when viewing animal
- require minimum version for wuttaweb

## v0.1.0 (2026-02-03)

### Feat

- initial basic app to prove display of API (animal) data
