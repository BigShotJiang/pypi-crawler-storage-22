
# WuttaFarm

This is a Python web app (built with
[WuttaWeb](https://wuttaproject.org)), to integrate with and extend
[farmOS](https://farmos.org).

It is just an experiment so far; the ideas I hope to play with
include:

- display farmOS data directly, via real-time API fetch
- add "mirror" schema and sync data from farmOS to app DB (and display it)
- possibly add more schema / extra features
- possibly sync data back to farmOS


## Quick Start

Make a virtual environment and install the app:

    python3 -m venv .venv
    .venv/bin/pip install -e .
    .venv/bin/wuttafarm install

For more info see
https://docs.wuttaproject.org/wuttjamaican/narr/install/index.html
