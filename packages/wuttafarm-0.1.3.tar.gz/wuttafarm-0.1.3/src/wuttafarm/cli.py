# -*- coding: utf-8; -*-
################################################################################
#
#  WuttaFarm --Web app to integrate with and extend farmOS
#  Copyright © 2026 Lance Edgar
#
#  This file is part of WuttaFarm.
#
#  WuttaFarm is free software: you can redistribute it and/or modify it under
#  the terms of the GNU General Public License as published by the Free Software
#  Foundation, either version 3 of the License, or (at your option) any later
#  version.
#
#  WuttaFarm is distributed in the hope that it will be useful, but WITHOUT ANY
#  WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR
#  A PARTICULAR PURPOSE.  See the GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License along with
#  WuttaFarm.  If not, see <http://www.gnu.org/licenses/>.
#
################################################################################
"""
WuttaFarm CLI
"""

import typer

from wuttjamaican.cli import make_typer


wuttafarm_typer = make_typer(
    name="wuttafarm", help="WuttaFarm -- Web app to integrate with and extend farmOS"
)


@wuttafarm_typer.command()
def install(
    ctx: typer.Context,
):
    """
    Install the WuttaFarm app
    """
    config = ctx.parent.wutta_config
    app = config.get_app()
    install = app.get_install_handler(
        pkg_name="wuttafarm",
        app_title="WuttaFarm",
        pypi_name="WuttaFarm",
        egg_name="WuttaFarm",
    )
    install.run()
