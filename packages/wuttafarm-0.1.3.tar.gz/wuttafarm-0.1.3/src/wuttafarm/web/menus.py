# -*- coding: utf-8; -*-
################################################################################
#
#  WuttaFarm --Web app to integrate with and extend farmOS
#  Copyright © 2026 Lance Edgar
#
#  This file is part of WuttaFarm.
#
#  WuttaFarm is free software: you can redistribute it and/or modify it under
#  the terms of the GNU General Public License as published by the Free Software
#  Foundation, either version 3 of the License, or (at your option) any later
#  version.
#
#  WuttaFarm is distributed in the hope that it will be useful, but WITHOUT ANY
#  WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR
#  A PARTICULAR PURPOSE.  See the GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License along with
#  WuttaFarm.  If not, see <http://www.gnu.org/licenses/>.
#
################################################################################
"""
WuttaFarm Menu
"""

from wuttaweb import menus as base


class WuttaFarmMenuHandler(base.MenuHandler):
    """
    WuttaFarm menu handler
    """

    def make_menus(self, request, **kwargs):
        return [
            self.make_farmos_menu(request),
            self.make_admin_menu(request, include_people=True),
        ]

    def make_farmos_menu(self, request):
        return {
            "title": "farmOS",
            "type": "menu",
            "items": [
                {
                    "title": "Animals",
                    "route": "farmos_animals",
                    "perm": "farmos_animals.list",
                },
            ],
        }
