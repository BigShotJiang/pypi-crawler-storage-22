<%inherit file="wuttaweb:templates/base.mako" />

<%def name="index_title_controls()">
  ${parent.index_title_controls()}

  % if master is not Undefined and master.listing and farmos_refurl is not Undefined:
      <b-button type="is-primary"
                tag="a" target="_blank"
                href="${farmos_refurl}"
                icon-pack="fas"
                icon-left="external-link-alt">
        View in farmOS
      </b-button>
  % endif

</%def>
