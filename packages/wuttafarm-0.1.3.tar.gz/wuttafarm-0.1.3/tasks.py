# -*- coding: utf-8; -*-
"""
Tasks for WuttaFarm
"""

import os
import shutil

from invoke import task


@task
def release(c, skip_tests=False):
    """
    Release a new version of WuttaFarm
    """
    if not skip_tests:
        # TODO
        # c.run("pytest")
        pass

    if os.path.exists("dist"):
        shutil.rmtree("dist")

    c.run("python -m build --sdist")
    c.run("twine upload dist/*")
