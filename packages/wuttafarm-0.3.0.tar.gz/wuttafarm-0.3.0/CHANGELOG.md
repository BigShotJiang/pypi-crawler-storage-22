
# Changelog
All notable changes to WuttaFarm will be documented in this file.

The format is based on [Keep a Changelog](http://keepachangelog.com/en/1.0.0/)
and this project adheres to [Semantic Versioning](http://semver.org/spec/v2.0.0.html).

## v0.3.0 (2026-02-13)

### Feat

- add native table for Activity Logs; import from farmOS API
- add native table for Groups; import from farmOS API
- add native table for Animals; import from farmOS API
- add native table for Structures; import from farmOS API
- add native table for Land Assets; import from farmOS API
- add native table for Log Types; import from farmOS API
- add native table for Structure Types; import from farmOS API
- add native table for Land Types; import from farmOS API
- add native table for Asset Types; import from farmOS API
- add extension table for Users; import from farmOS API
- add native table for Animal Types; import from farmOS API
- add "See raw JSON data" button for farmOS API views

### Fix

- always make 'farmos' system user in app setup
- avoid error for Create User form
- add more perms to Site Admin role in app setup
- rename `drupal_internal_id` => `drupal_id`

## v0.2.3 (2026-02-08)

### Fix

- add custom (built) buefy css to repo

## v0.2.2 (2026-02-08)

### Fix

- update project links for PyPI

## v0.2.1 (2026-02-08)

### Fix

- run web app via uvicorn/ASGI by default

## v0.2.0 (2026-02-08)

### Feat

- add view for farmOS activity logs
- add view for farmOS log types
- add view for farmOS structure types
- add view for farmOS land types
- add view for farmOS land assets
- add view for farmOS groups
- add view for farmOS asset types
- add view for farmOS structures
- add view for farmOS animal types
- add view for farmOS users

### Fix

- add pyramid_exclog dependency
- add menu option, "Go to farmOS"
- ensure Buefy version matches what we use for custom css

## v0.1.5 (2026-02-07)

### Fix

- fix built wheel to include custom buefy css

## v0.1.4 (2026-02-07)

### Fix

- add custom style to better match farmOS color scheme

## v0.1.3 (2026-02-06)

### Fix

- fix a couple more edge cases around oauth2 token refresh

## v0.1.2 (2026-02-06)

### Fix

- add support for farmOS/OAuth2 Authorization Code grant/workflow

## v0.1.1 (2026-02-05)

### Fix

- preserve oauth2 token so auto-refresh works correctly
- customize app installer to configure farmos_url
- add some more info when viewing animal
- require minimum version for wuttaweb

## v0.1.0 (2026-02-03)

### Feat

- initial basic app to prove display of API (animal) data
