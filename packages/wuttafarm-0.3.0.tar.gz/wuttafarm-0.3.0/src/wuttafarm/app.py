# -*- coding: utf-8; -*-
################################################################################
#
#  WuttaFarm --Web app to integrate with and extend farmOS
#  Copyright © 2026 Lance Edgar
#
#  This file is part of WuttaFarm.
#
#  WuttaFarm is free software: you can redistribute it and/or modify it under
#  the terms of the GNU General Public License as published by the Free Software
#  Foundation, either version 3 of the License, or (at your option) any later
#  version.
#
#  WuttaFarm is distributed in the hope that it will be useful, but WITHOUT ANY
#  WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR
#  A PARTICULAR PURPOSE.  See the GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License along with
#  WuttaFarm.  If not, see <http://www.gnu.org/licenses/>.
#
################################################################################
"""
Custom app handler for WuttaFarm
"""

from wuttjamaican import app as base


class WuttaFarmAppHandler(base.AppHandler):
    """
    Custom :term:`app handler` for WuttaFarm.
    """

    default_auth_handler_spec = "wuttafarm.auth:WuttaFarmAuthHandler"
    default_install_handler_spec = "wuttafarm.install:WuttaFarmInstallHandler"

    def get_farmos_handler(self):
        """
        Get the configured farmOS integration handler.

        :rtype: :class:`~wuttafarm.farmos.FarmOSHandler`
        """
        if "farmos" not in self.handlers:
            spec = self.config.get(
                f"{self.appname}.farmos_handler",
                default="wuttafarm.farmos.handler:FarmOSHandler",
            )
            factory = self.load_object(spec)
            self.handlers["farmos"] = factory(self.config)
        return self.handlers["farmos"]

    def get_farmos_url(self, *args, **kwargs):
        """
        Get a farmOS URL.  This is a convenience wrapper around
        :meth:`~wuttafarm.farmos.handler.FarmOSHandler.get_farmos_url()`.
        """
        handler = self.get_farmos_handler()
        return handler.get_farmos_url(*args, **kwargs)

    def get_farmos_client(self, *args, **kwargs):
        """
        Get a farmOS client.  This is a convenience wrapper around
        :meth:`~wuttafarm.farmos.handler.FarmOSHandler.get_farmos_client()`.
        """
        handler = self.get_farmos_handler()
        return handler.get_farmos_client(*args, **kwargs)


class WuttaFarmAppProvider(base.AppProvider):
    """
    The :term:`app provider` for WuttaFarm.
    """

    email_modules = ["wuttafarm.emails"]
