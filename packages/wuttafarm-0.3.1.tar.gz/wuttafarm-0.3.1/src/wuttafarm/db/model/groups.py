# -*- coding: utf-8; -*-
################################################################################
#
#  WuttaFarm --Web app to integrate with and extend farmOS
#  Copyright © 2026 Lance Edgar
#
#  This file is part of WuttaFarm.
#
#  WuttaFarm is free software: you can redistribute it and/or modify it under
#  the terms of the GNU General Public License as published by the Free Software
#  Foundation, either version 3 of the License, or (at your option) any later
#  version.
#
#  WuttaFarm is distributed in the hope that it will be useful, but WITHOUT ANY
#  WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR
#  A PARTICULAR PURPOSE.  See the GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License along with
#  WuttaFarm.  If not, see <http://www.gnu.org/licenses/>.
#
################################################################################
"""
Model definition for Groups
"""

import sqlalchemy as sa
from sqlalchemy import orm

from wuttjamaican.db import model


class Group(model.Base):
    """
    Represents a "group" from farmOS
    """

    __tablename__ = "group"
    __versioned__ = {}
    __wutta_hint__ = {
        "model_title": "Group",
        "model_title_plural": "Groups",
    }

    uuid = model.uuid_column()

    name = sa.Column(
        sa.String(length=100),
        nullable=False,
        unique=True,
        doc="""
        Name for the group.
        """,
    )

    is_location = sa.Column(
        sa.Boolean(),
        nullable=False,
        doc="""
        Whether the group is considered to be a location.
        """,
    )

    is_fixed = sa.Column(
        sa.Boolean(),
        nullable=False,
        doc="""
        Whether the group location is fixed.
        """,
    )

    active = sa.Column(
        sa.Boolean(),
        nullable=False,
        doc="""
        Whether the group is active.
        """,
    )

    notes = sa.Column(
        sa.Text(),
        nullable=True,
        doc="""
        Arbitrary notes for the group.
        """,
    )

    farmos_uuid = sa.Column(
        model.UUID(),
        nullable=True,
        unique=True,
        doc="""
        UUID for the group within farmOS.
        """,
    )

    drupal_id = sa.Column(
        sa.Integer(),
        nullable=True,
        unique=True,
        doc="""
        Drupal internal ID for the group.
        """,
    )

    def __str__(self):
        return self.name or ""
