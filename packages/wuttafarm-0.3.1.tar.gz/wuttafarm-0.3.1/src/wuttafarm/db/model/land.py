# -*- coding: utf-8; -*-
################################################################################
#
#  WuttaFarm --Web app to integrate with and extend farmOS
#  Copyright © 2026 Lance Edgar
#
#  This file is part of WuttaFarm.
#
#  WuttaFarm is free software: you can redistribute it and/or modify it under
#  the terms of the GNU General Public License as published by the Free Software
#  Foundation, either version 3 of the License, or (at your option) any later
#  version.
#
#  WuttaFarm is distributed in the hope that it will be useful, but WITHOUT ANY
#  WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR
#  A PARTICULAR PURPOSE.  See the GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License along with
#  WuttaFarm.  If not, see <http://www.gnu.org/licenses/>.
#
################################################################################
"""
Model definition for Land Types
"""

import sqlalchemy as sa
from sqlalchemy import orm

from wuttjamaican.db import model


class LandType(model.Base):
    """
    Represents a "land type" from farmOS
    """

    __tablename__ = "land_type"
    __versioned__ = {}
    __wutta_hint__ = {
        "model_title": "Land Type",
        "model_title_plural": "Land Types",
    }

    uuid = model.uuid_column()

    name = sa.Column(
        sa.String(length=100),
        nullable=False,
        unique=True,
        doc="""
        Name of the land type.
        """,
    )

    farmos_uuid = sa.Column(
        model.UUID(),
        nullable=True,
        unique=True,
        doc="""
        UUID for the land type within farmOS.
        """,
    )

    drupal_id = sa.Column(
        sa.String(length=50),
        nullable=True,
        unique=True,
        doc="""
        Drupal internal ID for the land type.
        """,
    )

    land_assets = orm.relationship("LandAsset", back_populates="land_type")

    def __str__(self):
        return self.name or ""


class LandAsset(model.Base):
    """
    Represents a "land asset" from farmOS
    """

    __tablename__ = "land_asset"
    __versioned__ = {}
    __wutta_hint__ = {
        "model_title": "Land Asset",
        "model_title_plural": "Land Assets",
    }

    uuid = model.uuid_column()

    name = sa.Column(
        sa.String(length=100),
        nullable=False,
        unique=True,
        doc="""
        Name of the land asset.
        """,
    )

    land_type_uuid = model.uuid_fk_column("land_type.uuid", nullable=False, unique=True)
    land_type = orm.relationship(LandType, back_populates="land_assets")

    is_location = sa.Column(
        sa.Boolean(),
        nullable=False,
        doc="""
        Whether the land asset should be considered a location.
        """,
    )

    is_fixed = sa.Column(
        sa.Boolean(),
        nullable=False,
        doc="""
        Whether the land asset's location is fixed.
        """,
    )

    notes = sa.Column(
        sa.Text(),
        nullable=True,
        doc="""
        Notes for the land asset.
        """,
    )

    active = sa.Column(
        sa.Boolean(),
        nullable=False,
        doc="""
        Whether the land asset is currently active.
        """,
    )

    farmos_uuid = sa.Column(
        model.UUID(),
        nullable=True,
        unique=True,
        doc="""
        UUID for the land asset within farmOS.
        """,
    )

    drupal_id = sa.Column(
        sa.Integer(),
        nullable=True,
        unique=True,
        doc="""
        Drupal internal ID for the land asset.
        """,
    )

    def __str__(self):
        return self.name or ""
