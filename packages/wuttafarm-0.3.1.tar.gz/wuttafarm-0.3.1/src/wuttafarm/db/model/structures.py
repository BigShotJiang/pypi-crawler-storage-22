# -*- coding: utf-8; -*-
################################################################################
#
#  WuttaFarm --Web app to integrate with and extend farmOS
#  Copyright © 2026 Lance Edgar
#
#  This file is part of WuttaFarm.
#
#  WuttaFarm is free software: you can redistribute it and/or modify it under
#  the terms of the GNU General Public License as published by the Free Software
#  Foundation, either version 3 of the License, or (at your option) any later
#  version.
#
#  WuttaFarm is distributed in the hope that it will be useful, but WITHOUT ANY
#  WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR
#  A PARTICULAR PURPOSE.  See the GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License along with
#  WuttaFarm.  If not, see <http://www.gnu.org/licenses/>.
#
################################################################################
"""
Model definition for Structure Types
"""

import sqlalchemy as sa
from sqlalchemy import orm

from wuttjamaican.db import model


class StructureType(model.Base):
    """
    Represents a "structure type" from farmOS
    """

    __tablename__ = "structure_type"
    __versioned__ = {}
    __wutta_hint__ = {
        "model_title": "Structure Type",
        "model_title_plural": "Structure Types",
    }

    uuid = model.uuid_column()

    name = sa.Column(
        sa.String(length=100),
        nullable=False,
        unique=True,
        doc="""
        Name of the structure type.
        """,
    )

    farmos_uuid = sa.Column(
        model.UUID(),
        nullable=True,
        unique=True,
        doc="""
        UUID for the structure type within farmOS.
        """,
    )

    drupal_id = sa.Column(
        sa.String(length=50),
        nullable=True,
        unique=True,
        doc="""
        Drupal internal ID for the structure type.
        """,
    )

    def __str__(self):
        return self.name or ""


class Structure(model.Base):
    """
    Represents a structure from farmOS
    """

    __tablename__ = "structure"
    __versioned__ = {}
    __wutta_hint__ = {
        "model_title": "Structure",
        "model_title_plural": "Structures",
    }

    uuid = model.uuid_column()

    name = sa.Column(
        sa.String(length=100),
        nullable=False,
        unique=True,
        doc="""
        Name for the structure.
        """,
    )

    active = sa.Column(
        sa.Boolean(),
        nullable=False,
        doc="""
        Whether the structure is currently active.
        """,
    )

    structure_type_uuid = model.uuid_fk_column("structure_type.uuid", nullable=False)
    structure_type = orm.relationship(
        "StructureType",
        doc="""
        Reference to the type of structure.
        """,
    )

    is_location = sa.Column(
        sa.Boolean(),
        nullable=False,
        doc="""
        Whether the structure is considered a location.
        """,
    )

    is_fixed = sa.Column(
        sa.Boolean(),
        nullable=False,
        doc="""
        Whether the structure location is fixed.
        """,
    )

    notes = sa.Column(
        sa.Text(),
        nullable=True,
        doc="""
        Arbitrary notes for the structure.
        """,
    )

    image_url = sa.Column(
        sa.String(length=255),
        nullable=True,
        doc="""
        Optional image URL for the structure.
        """,
    )

    farmos_uuid = sa.Column(
        model.UUID(),
        nullable=True,
        unique=True,
        doc="""
        UUID for the structure within farmOS.
        """,
    )

    drupal_id = sa.Column(
        sa.Integer(),
        nullable=True,
        unique=True,
        doc="""
        Drupal internal ID for the structure.
        """,
    )

    def __str__(self):
        return self.name or ""
