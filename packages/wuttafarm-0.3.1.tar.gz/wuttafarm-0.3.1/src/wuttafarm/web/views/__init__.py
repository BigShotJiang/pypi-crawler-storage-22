# -*- coding: utf-8; -*-
################################################################################
#
#  WuttaFarm --Web app to integrate with and extend farmOS
#  Copyright © 2026 Lance Edgar
#
#  This file is part of WuttaFarm.
#
#  WuttaFarm is free software: you can redistribute it and/or modify it under
#  the terms of the GNU General Public License as published by the Free Software
#  Foundation, either version 3 of the License, or (at your option) any later
#  version.
#
#  WuttaFarm is distributed in the hope that it will be useful, but WITHOUT ANY
#  WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR
#  A PARTICULAR PURPOSE.  See the GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License along with
#  WuttaFarm.  If not, see <http://www.gnu.org/licenses/>.
#
################################################################################
"""
WuttaFarm Views
"""

from wuttaweb.views import essential

from .master import WuttaFarmMasterView


def includeme(config):

    # wuttaweb core
    essential.defaults(
        config,
        **{
            "wuttaweb.views.auth": "wuttafarm.web.views.auth",
            "wuttaweb.views.common": "wuttafarm.web.views.common",
            "wuttaweb.views.users": "wuttafarm.web.views.users",
        }
    )

    # native table views
    config.include("wuttafarm.web.views.asset_types")
    config.include("wuttafarm.web.views.land_types")
    config.include("wuttafarm.web.views.structure_types")
    config.include("wuttafarm.web.views.animal_types")
    config.include("wuttafarm.web.views.land_assets")
    config.include("wuttafarm.web.views.structures")
    config.include("wuttafarm.web.views.animals")
    config.include("wuttafarm.web.views.groups")
    config.include("wuttafarm.web.views.log_types")
    config.include("wuttafarm.web.views.logs_activity")

    # views for farmOS
    config.include("wuttafarm.web.views.farmos")
