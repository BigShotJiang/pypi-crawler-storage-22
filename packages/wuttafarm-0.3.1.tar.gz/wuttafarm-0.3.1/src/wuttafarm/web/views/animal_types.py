# -*- coding: utf-8; -*-
################################################################################
#
#  WuttaFarm --Web app to integrate with and extend farmOS
#  Copyright © 2026 Lance Edgar
#
#  This file is part of WuttaFarm.
#
#  WuttaFarm is free software: you can redistribute it and/or modify it under
#  the terms of the GNU General Public License as published by the Free Software
#  Foundation, either version 3 of the License, or (at your option) any later
#  version.
#
#  WuttaFarm is distributed in the hope that it will be useful, but WITHOUT ANY
#  WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR
#  A PARTICULAR PURPOSE.  See the GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License along with
#  WuttaFarm.  If not, see <http://www.gnu.org/licenses/>.
#
################################################################################
"""
Master view for Animal Types
"""

from wuttafarm.db.model.animals import AnimalType, Animal
from wuttafarm.web.views import WuttaFarmMasterView


class AnimalTypeView(WuttaFarmMasterView):
    """
    Master view for Animal Types
    """

    model_class = AnimalType
    route_prefix = "animal_types"
    url_prefix = "/animal-types"

    farmos_refurl_path = "/admin/structure/taxonomy/manage/animal_type/overview"

    grid_columns = [
        "name",
        "description",
        "changed",
    ]

    sort_defaults = "name"

    filter_defaults = {
        "name": {"active": True, "verb": "contains"},
    }

    form_fields = [
        "name",
        "description",
        "changed",
        "farmos_uuid",
        "drupal_id",
    ]

    has_rows = True
    row_model_class = Animal
    rows_viewable = True

    row_grid_columns = [
        "name",
        "sex",
        "is_sterile",
        "birthdate",
        "active",
    ]

    rows_sort_defaults = "name"

    def configure_grid(self, grid):
        g = grid
        super().configure_grid(g)

        # name
        g.set_link("name")

    def get_farmos_url(self, animal_type):
        return self.app.get_farmos_url(f"/taxonomy/term/{animal_type.drupal_id}")

    def get_xref_buttons(self, animal_type):
        buttons = super().get_xref_buttons(animal_type)

        if animal_type.farmos_uuid:
            buttons.append(
                self.make_button(
                    "View farmOS record",
                    primary=True,
                    url=self.request.route_url(
                        "farmos_animal_types.view", uuid=animal_type.farmos_uuid
                    ),
                    icon_left="eye",
                )
            )

        return buttons

    def get_row_grid_data(self, animal_type):
        model = self.app.model
        session = self.Session()
        return session.query(model.Animal).filter(
            model.Animal.animal_type == animal_type
        )

    def configure_row_grid(self, grid):
        g = grid
        super().configure_row_grid(g)

        # name
        g.set_link("name")

    def get_row_action_url_view(self, animal, i):
        return self.request.route_url("animals.view", uuid=animal.uuid)


def defaults(config, **kwargs):
    base = globals()

    AnimalTypeView = kwargs.get("AnimalTypeView", base["AnimalTypeView"])
    AnimalTypeView.defaults(config)


def includeme(config):
    defaults(config)
