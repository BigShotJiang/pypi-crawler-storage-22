# -*- coding: utf-8; -*-
################################################################################
#
#  WuttaFarm --Web app to integrate with and extend farmOS
#  Copyright © 2026 Lance Edgar
#
#  This file is part of WuttaFarm.
#
#  WuttaFarm is free software: you can redistribute it and/or modify it under
#  the terms of the GNU General Public License as published by the Free Software
#  Foundation, either version 3 of the License, or (at your option) any later
#  version.
#
#  WuttaFarm is distributed in the hope that it will be useful, but WITHOUT ANY
#  WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR
#  A PARTICULAR PURPOSE.  See the GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License along with
#  WuttaFarm.  If not, see <http://www.gnu.org/licenses/>.
#
################################################################################
"""
Master view for Animals
"""

from wuttafarm.db.model.animals import Animal
from wuttafarm.web.views import WuttaFarmMasterView
from wuttafarm.web.forms.schema import AnimalTypeRef
from wuttafarm.web.forms.widgets import ImageWidget


class AnimalView(WuttaFarmMasterView):
    """
    Master view for Animals
    """

    model_class = Animal
    route_prefix = "animals"
    url_prefix = "/animals"

    farmos_refurl_path = "/assets/animal"

    grid_columns = [
        "name",
        "animal_type",
        "sex",
        "is_sterile",
        "birthdate",
        "active",
    ]

    sort_defaults = "name"

    filter_defaults = {
        "name": {"active": True, "verb": "contains"},
    }

    form_fields = [
        "name",
        "animal_type",
        "birthdate",
        "sex",
        "is_sterile",
        "active",
        "notes",
        "farmos_uuid",
        "drupal_id",
        "image_url",
        "image",
    ]

    def configure_grid(self, grid):
        g = grid
        super().configure_grid(g)
        model = self.app.model

        # name
        g.set_link("name")

        # animal_type
        g.set_joiner("animal_type", lambda q: q.join(model.AnimalType))
        g.set_sorter("animal_type", model.AnimalType.name)
        g.set_filter("animal_type", model.AnimalType.name, label="Animal Type Name")

    def configure_form(self, form):
        f = form
        super().configure_form(f)
        animal = form.model_instance

        # animal_type
        f.set_node("animal_type", AnimalTypeRef(self.request))

        # notes
        f.set_widget("notes", "notes")

        # image
        if animal.image_url:
            f.set_widget("image", ImageWidget("animal image"))
            f.set_default("image", animal.image_url)

    def get_farmos_url(self, animal):
        return self.app.get_farmos_url(f"/asset/{animal.drupal_id}")

    def get_xref_buttons(self, animal):
        buttons = super().get_xref_buttons(animal)

        if animal.farmos_uuid:
            buttons.append(
                self.make_button(
                    "View farmOS record",
                    primary=True,
                    url=self.request.route_url(
                        "farmos_animals.view", uuid=animal.farmos_uuid
                    ),
                    icon_left="eye",
                )
            )

        return buttons


def defaults(config, **kwargs):
    base = globals()

    AnimalView = kwargs.get("AnimalView", base["AnimalView"])
    AnimalView.defaults(config)


def includeme(config):
    defaults(config)
