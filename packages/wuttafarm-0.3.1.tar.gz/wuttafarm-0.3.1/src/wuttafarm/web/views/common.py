# -*- coding: utf-8; -*-
################################################################################
#
#  WuttaFarm --Web app to integrate with and extend farmOS
#  Copyright © 2026 Lance Edgar
#
#  This file is part of WuttaFarm.
#
#  WuttaFarm is free software: you can redistribute it and/or modify it under
#  the terms of the GNU General Public License as published by the Free Software
#  Foundation, either version 3 of the License, or (at your option) any later
#  version.
#
#  WuttaFarm is distributed in the hope that it will be useful, but WITHOUT ANY
#  WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR
#  A PARTICULAR PURPOSE.  See the GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License along with
#  WuttaFarm.  If not, see <http://www.gnu.org/licenses/>.
#
################################################################################
"""
Common views
"""

from wuttaweb.views import common as base


class CommonView(base.CommonView):
    """
    Common views
    """

    def setup_enhance_admin_user(self, user):
        """ """
        model = self.app.model
        session = self.app.get_session(user)
        auth = self.app.get_auth_handler()

        # initialize built-in roles
        farm_manager = auth.get_role_farm_manager(session)
        farm_manager.notes = "this is meant to mirror the corresponding role in farmOS"
        farm_worker = auth.get_role_farm_worker(session)
        farm_worker.notes = "this is meant to mirror the corresponding role in farmOS"
        farm_viewer = auth.get_role_farm_viewer(session)
        farm_viewer.notes = "this is meant to mirror the corresponding role in farmOS"

        # create system user to represent farmOS
        auth.make_user(session, username="farmos", prevent_edit=True)

        site_admin = session.query(model.Role).filter_by(name="Site Admin").first()
        if site_admin:
            site_admin_perms = [
                "activity_logs.list",
                "activity_logs.view",
                "activity_logs.versions",
                "animal_types.list",
                "animal_types.view",
                "animal_types.versions",
                "animals.list",
                "animals.view",
                "animals.versions",
                "asset_types.list",
                "asset_types.view",
                "asset_types.versions",
                "farmos_animal_types.list",
                "farmos_animal_types.view",
                "farmos_animals.list",
                "farmos_animals.view",
                "farmos_asset_types.list",
                "farmos_asset_types.view",
                "farmos_groups.list",
                "farmos_groups.view",
                "farmos_land_assets.list",
                "farmos_land_assets.view",
                "farmos_land_types.list",
                "farmos_land_types.view",
                "farmos_log_types.list",
                "farmos_log_types.view",
                "farmos_logs_activity.list",
                "farmos_logs_activity.view",
                "farmos_structure_types.list",
                "farmos_structure_types.view",
                "farmos_structures.list",
                "farmos_structures.view",
                "farmos_users.list",
                "farmos_users.view",
                "groups.list",
                "groups.view",
                "groups.versions",
                "land_assets.list",
                "land_assets.view",
                "land_assets.versions",
                "land_types.list",
                "land_types.view",
                "land_types.versions",
                "log_types.list",
                "log_types.view",
                "log_types.versions",
                "structure_types.list",
                "structure_types.view",
                "structure_types.versions",
                "structures.list",
                "structures.view",
                "structures.versions",
            ]
            for perm in site_admin_perms:
                auth.grant_permission(site_admin, perm)


def defaults(config, **kwargs):
    local = globals()
    CommonView = kwargs.get("CommonView", local["CommonView"])
    base.defaults(config, **{"CommonView": CommonView})


def includeme(config):
    defaults(config)
