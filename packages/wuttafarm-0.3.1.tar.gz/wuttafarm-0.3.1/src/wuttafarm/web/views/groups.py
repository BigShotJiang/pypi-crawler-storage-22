# -*- coding: utf-8; -*-
################################################################################
#
#  WuttaFarm --Web app to integrate with and extend farmOS
#  Copyright © 2026 Lance Edgar
#
#  This file is part of WuttaFarm.
#
#  WuttaFarm is free software: you can redistribute it and/or modify it under
#  the terms of the GNU General Public License as published by the Free Software
#  Foundation, either version 3 of the License, or (at your option) any later
#  version.
#
#  WuttaFarm is distributed in the hope that it will be useful, but WITHOUT ANY
#  WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR
#  A PARTICULAR PURPOSE.  See the GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License along with
#  WuttaFarm.  If not, see <http://www.gnu.org/licenses/>.
#
################################################################################
"""
Master view for Groups
"""

from wuttafarm.db.model.groups import Group
from wuttafarm.web.views import WuttaFarmMasterView


class GroupView(WuttaFarmMasterView):
    """
    Master view for Groups
    """

    model_class = Group
    route_prefix = "groups"
    url_prefix = "/groups"

    farmos_refurl_path = "/assets/group"

    grid_columns = [
        "name",
        "is_location",
        "is_fixed",
        "active",
    ]

    sort_defaults = "name"

    filter_defaults = {
        "name": {"active": True, "verb": "contains"},
    }

    form_fields = [
        "name",
        "is_location",
        "is_fixed",
        "active",
        "notes",
        "farmos_uuid",
        "drupal_id",
    ]

    def configure_grid(self, grid):
        g = grid
        super().configure_grid(g)

        # name
        g.set_link("name")

    def configure_form(self, form):
        f = form
        super().configure_form(f)

        # notes
        f.set_widget("notes", "notes")

    def get_farmos_url(self, group):
        return self.app.get_farmos_url(f"/asset/{group.drupal_id}")

    def get_xref_buttons(self, group):
        buttons = super().get_xref_buttons(group)

        if group.farmos_uuid:
            buttons.append(
                self.make_button(
                    "View farmOS record",
                    primary=True,
                    url=self.request.route_url(
                        "farmos_groups.view", uuid=group.farmos_uuid
                    ),
                    icon_left="eye",
                )
            )

        return buttons


def defaults(config, **kwargs):
    base = globals()

    GroupView = kwargs.get("GroupView", base["GroupView"])
    GroupView.defaults(config)


def includeme(config):
    defaults(config)
