# -*- coding: utf-8; -*-
################################################################################
#
#  WuttaFarm --Web app to integrate with and extend farmOS
#  Copyright © 2026 Lance Edgar
#
#  This file is part of WuttaFarm.
#
#  WuttaFarm is free software: you can redistribute it and/or modify it under
#  the terms of the GNU General Public License as published by the Free Software
#  Foundation, either version 3 of the License, or (at your option) any later
#  version.
#
#  WuttaFarm is distributed in the hope that it will be useful, but WITHOUT ANY
#  WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR
#  A PARTICULAR PURPOSE.  See the GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License along with
#  WuttaFarm.  If not, see <http://www.gnu.org/licenses/>.
#
################################################################################
"""
Master view for Land Assets
"""

from wuttafarm.db.model.land import LandAsset
from wuttafarm.web.views import WuttaFarmMasterView
from wuttafarm.web.forms.schema import LandTypeRef


class LandAssetView(WuttaFarmMasterView):
    """
    Master view for Land Assets
    """

    model_class = LandAsset
    route_prefix = "land_assets"
    url_prefix = "/land-assets"

    farmos_refurl_path = "/assets/land"

    grid_columns = [
        "name",
        "land_type",
        "is_location",
        "is_fixed",
        "notes",
        "active",
    ]

    sort_defaults = "name"

    filter_defaults = {
        "name": {"active": True, "verb": "contains"},
    }

    form_fields = [
        "name",
        "land_type",
        "is_location",
        "is_fixed",
        "notes",
        "active",
        "farmos_uuid",
        "drupal_id",
    ]

    def configure_grid(self, grid):
        g = grid
        super().configure_grid(g)
        model = self.app.model

        # name
        g.set_link("name")

        # land_type
        g.set_joiner("land_type", lambda q: q.join(model.LandType))
        g.set_sorter("land_type", model.LandType.name)
        g.set_filter("land_type", model.LandType.name, label="Land Type Name")

    def configure_form(self, form):
        f = form
        super().configure_form(f)

        # land_type
        f.set_node("land_type", LandTypeRef(self.request))

    def get_farmos_url(self, land):
        return self.app.get_farmos_url(f"/asset/{land.drupal_id}")

    def get_xref_buttons(self, land_asset):
        buttons = super().get_xref_buttons(land_asset)

        if land_asset.farmos_uuid:
            buttons.append(
                self.make_button(
                    "View farmOS record",
                    primary=True,
                    url=self.request.route_url(
                        "farmos_land_assets.view", uuid=land_asset.farmos_uuid
                    ),
                    icon_left="eye",
                )
            )

        return buttons


def defaults(config, **kwargs):
    base = globals()

    LandAssetView = kwargs.get("LandAssetView", base["LandAssetView"])
    LandAssetView.defaults(config)


def includeme(config):
    defaults(config)
