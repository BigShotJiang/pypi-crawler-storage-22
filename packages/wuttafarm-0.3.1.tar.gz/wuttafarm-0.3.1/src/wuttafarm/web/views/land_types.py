# -*- coding: utf-8; -*-
################################################################################
#
#  WuttaFarm --Web app to integrate with and extend farmOS
#  Copyright © 2026 Lance Edgar
#
#  This file is part of WuttaFarm.
#
#  WuttaFarm is free software: you can redistribute it and/or modify it under
#  the terms of the GNU General Public License as published by the Free Software
#  Foundation, either version 3 of the License, or (at your option) any later
#  version.
#
#  WuttaFarm is distributed in the hope that it will be useful, but WITHOUT ANY
#  WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR
#  A PARTICULAR PURPOSE.  See the GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License along with
#  WuttaFarm.  If not, see <http://www.gnu.org/licenses/>.
#
################################################################################
"""
Master view for Land Types
"""

from wuttafarm.db.model.land import LandType, LandAsset
from wuttafarm.web.views import WuttaFarmMasterView


class LandTypeView(WuttaFarmMasterView):
    """
    Master view for Land Types
    """

    model_class = LandType
    route_prefix = "land_types"
    url_prefix = "/land-types"

    grid_columns = [
        "name",
    ]

    sort_defaults = "name"

    filter_defaults = {
        "name": {"active": True, "verb": "contains"},
    }

    form_fields = [
        "name",
        "farmos_uuid",
        "drupal_id",
    ]

    has_rows = True
    row_model_class = LandAsset
    rows_viewable = True

    row_grid_columns = [
        "name",
        "is_location",
        "is_fixed",
        "active",
    ]

    rows_sort_defaults = "name"

    def configure_grid(self, grid):
        g = grid
        super().configure_grid(g)

        # name
        g.set_link("name")

    def get_xref_buttons(self, land_type):
        buttons = super().get_xref_buttons(land_type)

        if land_type.farmos_uuid:
            buttons.append(
                self.make_button(
                    "View farmOS record",
                    primary=True,
                    url=self.request.route_url(
                        "farmos_land_types.view", uuid=land_type.farmos_uuid
                    ),
                    icon_left="eye",
                )
            )

        return buttons

    def get_row_grid_data(self, land_type):
        model = self.app.model
        session = self.Session()
        return session.query(model.LandAsset).filter(
            model.LandAsset.land_type == land_type
        )

    def configure_row_grid(self, grid):
        g = grid
        super().configure_row_grid(g)

        # name
        g.set_link("name")

    def get_row_action_url_view(self, land_asset, i):
        return self.request.route_url("land_assets.view", uuid=land_asset.uuid)


def defaults(config, **kwargs):
    base = globals()

    LandTypeView = kwargs.get("LandTypeView", base["LandTypeView"])
    LandTypeView.defaults(config)


def includeme(config):
    defaults(config)
