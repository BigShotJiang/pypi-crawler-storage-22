# -*- coding: utf-8; -*-
################################################################################
#
#  WuttaFarm --Web app to integrate with and extend farmOS
#  Copyright © 2026 Lance Edgar
#
#  This file is part of WuttaFarm.
#
#  WuttaFarm is free software: you can redistribute it and/or modify it under
#  the terms of the GNU General Public License as published by the Free Software
#  Foundation, either version 3 of the License, or (at your option) any later
#  version.
#
#  WuttaFarm is distributed in the hope that it will be useful, but WITHOUT ANY
#  WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR
#  A PARTICULAR PURPOSE.  See the GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License along with
#  WuttaFarm.  If not, see <http://www.gnu.org/licenses/>.
#
################################################################################
"""
Base class for WuttaFarm master views
"""

from wuttaweb.views import MasterView


class WuttaFarmMasterView(MasterView):
    """
    Base class for WuttaFarm master views
    """

    farmos_refurl_path = None

    labels = {
        "farmos_uuid": "farmOS UUID",
        "drupal_id": "Drupal ID",
        "image_url": "Image URL",
    }

    row_labels = {
        "farmos_uuid": "farmOS UUID",
        "drupal_id": "Drupal ID",
        "image_url": "Image URL",
    }

    def get_farmos_url(self, obj):
        return None

    def get_template_context(self, context):

        if self.listing and self.farmos_refurl_path:
            context["farmos_refurl"] = self.app.get_farmos_url(self.farmos_refurl_path)

        return context

    def get_xref_buttons(self, obj):
        url = self.get_farmos_url(obj)
        if url:
            return [
                self.make_button(
                    "View in farmOS",
                    primary=True,
                    url=url,
                    target="_blank",
                    icon_left="external-link-alt",
                )
            ]
        return []
