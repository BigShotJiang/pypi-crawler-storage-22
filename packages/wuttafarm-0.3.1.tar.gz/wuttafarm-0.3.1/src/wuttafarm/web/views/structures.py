# -*- coding: utf-8; -*-
################################################################################
#
#  WuttaFarm --Web app to integrate with and extend farmOS
#  Copyright © 2026 Lance Edgar
#
#  This file is part of WuttaFarm.
#
#  WuttaFarm is free software: you can redistribute it and/or modify it under
#  the terms of the GNU General Public License as published by the Free Software
#  Foundation, either version 3 of the License, or (at your option) any later
#  version.
#
#  WuttaFarm is distributed in the hope that it will be useful, but WITHOUT ANY
#  WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR
#  A PARTICULAR PURPOSE.  See the GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License along with
#  WuttaFarm.  If not, see <http://www.gnu.org/licenses/>.
#
################################################################################
"""
Master view for Structures
"""

from wuttafarm.db.model.structures import Structure
from wuttafarm.web.views import WuttaFarmMasterView
from wuttafarm.web.forms.schema import StructureTypeRef
from wuttafarm.web.forms.widgets import ImageWidget


class StructureView(WuttaFarmMasterView):
    """
    Master view for Structures
    """

    model_class = Structure
    route_prefix = "structures"
    url_prefix = "/structures"

    farmos_refurl_path = "/assets/structure"

    grid_columns = [
        "name",
        "structure_type",
        "is_location",
        "is_fixed",
        "active",
    ]

    sort_defaults = "name"

    filter_defaults = {
        "name": {"active": True, "verb": "contains"},
    }

    form_fields = [
        "name",
        "structure_type",
        "is_location",
        "is_fixed",
        "notes",
        "active",
        "farmos_uuid",
        "drupal_id",
        "image_url",
        "image",
    ]

    def configure_grid(self, grid):
        g = grid
        super().configure_grid(g)
        model = self.app.model

        # name
        g.set_link("name")

        # structure_type
        g.set_joiner("structure_type", lambda q: q.join(model.StructureType))
        g.set_sorter("structure_type", model.StructureType.name)
        g.set_filter(
            "structure_type", model.StructureType.name, label="Structure Type Name"
        )

    def configure_form(self, form):
        f = form
        super().configure_form(f)
        structure = form.model_instance

        # structure_type
        f.set_node("structure_type", StructureTypeRef(self.request))

        # image
        if structure.image_url:
            f.set_widget("image", ImageWidget("structure image"))
            f.set_default("image", structure.image_url)

    def get_farmos_url(self, structure):
        return self.app.get_farmos_url(f"/asset/{structure.drupal_id}")

    def get_xref_buttons(self, structure):
        buttons = super().get_xref_buttons(structure)

        if structure.farmos_uuid:
            buttons.append(
                self.make_button(
                    "View farmOS record",
                    primary=True,
                    url=self.request.route_url(
                        "farmos_structures.view", uuid=structure.farmos_uuid
                    ),
                    icon_left="eye",
                )
            )

        return buttons


def defaults(config, **kwargs):
    base = globals()

    StructureView = kwargs.get("StructureView", base["StructureView"])
    StructureView.defaults(config)


def includeme(config):
    defaults(config)
