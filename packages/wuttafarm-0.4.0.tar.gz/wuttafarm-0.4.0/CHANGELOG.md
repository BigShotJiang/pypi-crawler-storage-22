
# Changelog
All notable changes to WuttaFarm will be documented in this file.

The format is based on [Keep a Changelog](http://keepachangelog.com/en/1.0.0/)
and this project adheres to [Semantic Versioning](http://semver.org/spec/v2.0.0.html).

## v0.4.0 (2026-02-17)

### Feat

- add basic support for WuttaFarm → farmOS export
- convert group assets to use common base/mixin
- convert structure assets to use common base/mixin
- convert land assets to use common base/mixin
- add "generic" assets, new animal assets based on that

### Fix

- misc. field tweaks for asset forms
- show warning when viewing an archived asset
- fix some perms for all assets view
- fix initial admin perms per route renaming
- add parent relationships support for land assets
- cleanup Land views to better match farmOS
- cleanup Structure views to better match farmOS
- cleanup Group views to better match farmOS
- add / display thumbnail image for animals
- improve handling of 'archived' records for grid/form views
- use Male/Female dict enum for animal sex field
- prevent direct edit of `farmos_uuid` and `drupal_id` fields
- use same datetime display format as farmOS
- convert `active` flag to `archived`
- suppress output when user farmos/drupal keys are empty
- customize page footer to mention farmOS

## v0.3.1 (2026-02-14)

### Fix

- update sterile, archived flags per farmOS 4.x

## v0.3.0 (2026-02-13)

### Feat

- add native table for Activity Logs; import from farmOS API
- add native table for Groups; import from farmOS API
- add native table for Animals; import from farmOS API
- add native table for Structures; import from farmOS API
- add native table for Land Assets; import from farmOS API
- add native table for Log Types; import from farmOS API
- add native table for Structure Types; import from farmOS API
- add native table for Land Types; import from farmOS API
- add native table for Asset Types; import from farmOS API
- add extension table for Users; import from farmOS API
- add native table for Animal Types; import from farmOS API
- add "See raw JSON data" button for farmOS API views

### Fix

- always make 'farmos' system user in app setup
- avoid error for Create User form
- add more perms to Site Admin role in app setup
- rename `drupal_internal_id` => `drupal_id`

## v0.2.3 (2026-02-08)

### Fix

- add custom (built) buefy css to repo

## v0.2.2 (2026-02-08)

### Fix

- update project links for PyPI

## v0.2.1 (2026-02-08)

### Fix

- run web app via uvicorn/ASGI by default

## v0.2.0 (2026-02-08)

### Feat

- add view for farmOS activity logs
- add view for farmOS log types
- add view for farmOS structure types
- add view for farmOS land types
- add view for farmOS land assets
- add view for farmOS groups
- add view for farmOS asset types
- add view for farmOS structures
- add view for farmOS animal types
- add view for farmOS users

### Fix

- add pyramid_exclog dependency
- add menu option, "Go to farmOS"
- ensure Buefy version matches what we use for custom css

## v0.1.5 (2026-02-07)

### Fix

- fix built wheel to include custom buefy css

## v0.1.4 (2026-02-07)

### Fix

- add custom style to better match farmOS color scheme

## v0.1.3 (2026-02-06)

### Fix

- fix a couple more edge cases around oauth2 token refresh

## v0.1.2 (2026-02-06)

### Fix

- add support for farmOS/OAuth2 Authorization Code grant/workflow

## v0.1.1 (2026-02-05)

### Fix

- preserve oauth2 token so auto-refresh works correctly
- customize app installer to configure farmos_url
- add some more info when viewing animal
- require minimum version for wuttaweb

## v0.1.0 (2026-02-03)

### Feat

- initial basic app to prove display of API (animal) data
