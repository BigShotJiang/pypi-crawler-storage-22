
``wuttafarm.cli.install``
=========================

.. automodule:: wuttafarm.cli.install
   :members:
