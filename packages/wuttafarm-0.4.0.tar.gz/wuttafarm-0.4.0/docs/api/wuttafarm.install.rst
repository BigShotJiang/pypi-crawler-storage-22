
``wuttafarm.install``
=====================

.. automodule:: wuttafarm.install
   :members:
