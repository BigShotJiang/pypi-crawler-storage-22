
``wuttafarm.web.forms.schema``
==============================

.. automodule:: wuttafarm.web.forms.schema
   :members:
