
``wuttafarm.web``
=================

.. automodule:: wuttafarm.web
   :members:
