
``wuttafarm.web.static``
========================

.. automodule:: wuttafarm.web.static
   :members:
