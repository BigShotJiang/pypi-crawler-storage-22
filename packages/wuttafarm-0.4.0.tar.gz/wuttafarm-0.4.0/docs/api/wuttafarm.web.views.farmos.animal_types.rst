
``wuttafarm.web.views.farmos.animal_types``
===========================================

.. automodule:: wuttafarm.web.views.farmos.animal_types
   :members:
