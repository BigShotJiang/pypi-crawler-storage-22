
``wuttafarm.web.views.farmos.asset_types``
==========================================

.. automodule:: wuttafarm.web.views.farmos.asset_types
   :members:
