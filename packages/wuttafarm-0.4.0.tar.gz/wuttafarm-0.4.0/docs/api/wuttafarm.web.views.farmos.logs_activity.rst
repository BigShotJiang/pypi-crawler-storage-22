
``wuttafarm.web.views.farmos.logs_activity``
============================================

.. automodule:: wuttafarm.web.views.farmos.logs_activity
   :members:
