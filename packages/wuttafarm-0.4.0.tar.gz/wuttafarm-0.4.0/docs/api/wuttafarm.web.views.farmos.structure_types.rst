
``wuttafarm.web.views.farmos.structure_types``
==============================================

.. automodule:: wuttafarm.web.views.farmos.structure_types
   :members:
