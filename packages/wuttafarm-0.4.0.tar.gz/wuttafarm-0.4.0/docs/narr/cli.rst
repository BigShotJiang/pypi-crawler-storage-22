
========================
 Command Line Interface
========================

WuttaFarm ships with the following commands.

For more general info about CLI see
:doc:`wuttjamaican:narr/cli/index`.


.. _wuttafarm-install:

``wuttafarm install``
---------------------

Run the WuttaFarm app installer.

This will create the :term:`app dir` and initial config files, and
create the schema within the :term:`app database`.

Defined in: :mod:`wuttafarm.cli.install`

.. program-output:: wuttafarm install --help


.. _wuttafarm-import-farmos:

``wuttafarm import-farmos``
---------------------------

Import data from the farmOS API into the WuttaFarm :term:`app
database`.

Defined in: :mod:`wuttafarm.cli.import_farmos`

.. program-output:: wuttafarm import-farmos --help


