
========
Features
========

Here is the list of features currently supported:

* login via farmOS / OAuth2 workflows
   * Authorization Code workflow is supported
   * (technically, Password Grant workflow is also supported, for now)

* view some farmOS data directly
   * limited data is fetched via farmOS API for several views
   * performance isn't bad, but data is not very "complete"
   * more data could be fetched, but not sure this is the best way..?

* import some data from farmOS
   * limited data is imported from farmOS API into native app tables
   * this data is exposed in views, similar to direct farmOS views (above)


Screenshots
-----------

.. image:: https://wuttaproject.org/images/screenshot.png
