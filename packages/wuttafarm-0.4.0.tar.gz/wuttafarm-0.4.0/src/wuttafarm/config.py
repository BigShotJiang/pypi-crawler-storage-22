# -*- coding: utf-8; -*-
################################################################################
#
#  WuttaFarm --Web app to integrate with and extend farmOS
#  Copyright © 2026 Lance Edgar
#
#  This file is part of WuttaFarm.
#
#  WuttaFarm is free software: you can redistribute it and/or modify it under
#  the terms of the GNU General Public License as published by the Free Software
#  Foundation, either version 3 of the License, or (at your option) any later
#  version.
#
#  WuttaFarm is distributed in the hope that it will be useful, but WITHOUT ANY
#  WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR
#  A PARTICULAR PURPOSE.  See the GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License along with
#  WuttaFarm.  If not, see <http://www.gnu.org/licenses/>.
#
################################################################################
"""
WuttaFarm config extensions
"""

from wuttjamaican.conf import WuttaConfigExtension


class WuttaFarmConfig(WuttaConfigExtension):
    """
    Config extension for WuttaFarm
    """

    key = "wuttafarm"

    def configure(self, config):

        # app info
        config.setdefault(f"{config.appname}.app_title", "WuttaFarm")
        config.setdefault(f"{config.appname}.app_dist", "WuttaFarm")

        # app model/enum
        config.setdefault(f"{config.appname}.model_spec", "wuttafarm.db.model")
        config.setdefault(f"{config.appname}.enum_spec", "wuttafarm.enum")

        # app handler
        config.setdefault(
            f"{config.appname}.app.handler", "wuttafarm.app:WuttaFarmAppHandler"
        )

        # web app menu
        config.setdefault(
            f"{config.appname}.web.menus.handler.spec",
            "wuttafarm.web.menus:WuttaFarmMenuHandler",
        )

        # web app libcache
        # config.setdefault('wuttaweb.static_libcache.module', 'wuttafarm.web.static')
