"""add animal thumbnail url

Revision ID: 2a49127e974b
Revises: 8898184c5c75
Create Date: 2026-02-14 19:41:22.039343

"""

from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa
import wuttjamaican.db.util


# revision identifiers, used by Alembic.
revision: str = "2a49127e974b"
down_revision: Union[str, None] = "8898184c5c75"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:

    # animal
    op.add_column(
        "animal", sa.Column("thumbnail_url", sa.String(length=255), nullable=True)
    )
    op.add_column(
        "animal_version",
        sa.Column(
            "thumbnail_url", sa.String(length=255), autoincrement=False, nullable=True
        ),
    )


def downgrade() -> None:

    # animal
    op.drop_column("animal_version", "thumbnail_url")
    op.drop_column("animal", "thumbnail_url")
