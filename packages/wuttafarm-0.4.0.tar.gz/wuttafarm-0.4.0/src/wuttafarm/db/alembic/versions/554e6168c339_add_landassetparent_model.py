"""add LandAssetParent model

Revision ID: 554e6168c339
Revises: 8cc1565d38e7
Create Date: 2026-02-14 20:41:24.859064

"""

from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa
import wuttjamaican.db.util


# revision identifiers, used by Alembic.
revision: str = "554e6168c339"
down_revision: Union[str, None] = "8cc1565d38e7"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:

    # land_asset_parent
    op.create_table(
        "land_asset_parent",
        sa.Column("uuid", wuttjamaican.db.util.UUID(), nullable=False),
        sa.Column("land_asset_uuid", wuttjamaican.db.util.UUID(), nullable=False),
        sa.Column("parent_asset_uuid", wuttjamaican.db.util.UUID(), nullable=False),
        sa.ForeignKeyConstraint(
            ["land_asset_uuid"],
            ["land_asset.uuid"],
            name=op.f("fk_land_asset_parent_land_asset_uuid_land_asset"),
        ),
        sa.ForeignKeyConstraint(
            ["parent_asset_uuid"],
            ["land_asset.uuid"],
            name=op.f("fk_land_asset_parent_parent_asset_uuid_land_asset"),
        ),
        sa.PrimaryKeyConstraint("uuid", name=op.f("pk_land_asset_parent")),
    )
    op.create_table(
        "land_asset_parent_version",
        sa.Column(
            "uuid", wuttjamaican.db.util.UUID(), autoincrement=False, nullable=False
        ),
        sa.Column(
            "land_asset_uuid",
            wuttjamaican.db.util.UUID(),
            autoincrement=False,
            nullable=True,
        ),
        sa.Column(
            "parent_asset_uuid",
            wuttjamaican.db.util.UUID(),
            autoincrement=False,
            nullable=True,
        ),
        sa.Column(
            "transaction_id", sa.BigInteger(), autoincrement=False, nullable=False
        ),
        sa.Column("end_transaction_id", sa.BigInteger(), nullable=True),
        sa.Column("operation_type", sa.SmallInteger(), nullable=False),
        sa.PrimaryKeyConstraint(
            "uuid", "transaction_id", name=op.f("pk_land_asset_parent_version")
        ),
    )
    op.create_index(
        op.f("ix_land_asset_parent_version_end_transaction_id"),
        "land_asset_parent_version",
        ["end_transaction_id"],
        unique=False,
    )
    op.create_index(
        op.f("ix_land_asset_parent_version_operation_type"),
        "land_asset_parent_version",
        ["operation_type"],
        unique=False,
    )
    op.create_index(
        "ix_land_asset_parent_version_pk_transaction_id",
        "land_asset_parent_version",
        ["uuid", sa.literal_column("transaction_id DESC")],
        unique=False,
    )
    op.create_index(
        "ix_land_asset_parent_version_pk_validity",
        "land_asset_parent_version",
        ["uuid", "transaction_id", "end_transaction_id"],
        unique=False,
    )
    op.create_index(
        op.f("ix_land_asset_parent_version_transaction_id"),
        "land_asset_parent_version",
        ["transaction_id"],
        unique=False,
    )


def downgrade() -> None:

    # land_asset_parent
    op.drop_index(
        op.f("ix_land_asset_parent_version_transaction_id"),
        table_name="land_asset_parent_version",
    )
    op.drop_index(
        "ix_land_asset_parent_version_pk_validity",
        table_name="land_asset_parent_version",
    )
    op.drop_index(
        "ix_land_asset_parent_version_pk_transaction_id",
        table_name="land_asset_parent_version",
    )
    op.drop_index(
        op.f("ix_land_asset_parent_version_operation_type"),
        table_name="land_asset_parent_version",
    )
    op.drop_index(
        op.f("ix_land_asset_parent_version_end_transaction_id"),
        table_name="land_asset_parent_version",
    )
    op.drop_table("land_asset_parent_version")
    op.drop_table("land_asset_parent")
