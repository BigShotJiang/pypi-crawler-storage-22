"""add structure thumbnail url

Revision ID: 8cc1565d38e7
Revises: 2a49127e974b
Create Date: 2026-02-14 20:07:33.913573

"""

from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa
import wuttjamaican.db.util


# revision identifiers, used by Alembic.
revision: str = "8cc1565d38e7"
down_revision: Union[str, None] = "2a49127e974b"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:

    # structure
    op.add_column(
        "structure", sa.Column("thumbnail_url", sa.String(length=255), nullable=True)
    )
    op.add_column(
        "structure_version",
        sa.Column(
            "thumbnail_url", sa.String(length=255), autoincrement=False, nullable=True
        ),
    )


def downgrade() -> None:

    # structure
    op.drop_column("structure_version", "thumbnail_url")
    op.drop_column("structure", "thumbnail_url")
