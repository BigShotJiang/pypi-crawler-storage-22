# -*- coding: utf-8; -*-
################################################################################
#
#  WuttaFarm --Web app to integrate with and extend farmOS
#  Copyright © 2026 Lance Edgar
#
#  This file is part of WuttaFarm.
#
#  WuttaFarm is free software: you can redistribute it and/or modify it under
#  the terms of the GNU General Public License as published by the Free Software
#  Foundation, either version 3 of the License, or (at your option) any later
#  version.
#
#  WuttaFarm is distributed in the hope that it will be useful, but WITHOUT ANY
#  WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR
#  A PARTICULAR PURPOSE.  See the GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License along with
#  WuttaFarm.  If not, see <http://www.gnu.org/licenses/>.
#
################################################################################
"""
WuttaFarm data models
"""

# bring in all of wutta
from wuttjamaican.db.model import *

# wutta model extensions
from .users import WuttaFarmUser

# wuttafarm proper models
from .assets import AssetType, Asset, AssetParent
from .land import LandType, LandAsset
from .structures import StructureType, StructureAsset
from .animals import AnimalType, AnimalAsset
from .groups import GroupAsset
from .logs import LogType, ActivityLog
