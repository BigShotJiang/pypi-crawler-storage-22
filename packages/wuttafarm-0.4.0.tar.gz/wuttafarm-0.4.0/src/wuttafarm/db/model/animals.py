# -*- coding: utf-8; -*-
################################################################################
#
#  WuttaFarm --Web app to integrate with and extend farmOS
#  Copyright © 2026 Lance Edgar
#
#  This file is part of WuttaFarm.
#
#  WuttaFarm is free software: you can redistribute it and/or modify it under
#  the terms of the GNU General Public License as published by the Free Software
#  Foundation, either version 3 of the License, or (at your option) any later
#  version.
#
#  WuttaFarm is distributed in the hope that it will be useful, but WITHOUT ANY
#  WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR
#  A PARTICULAR PURPOSE.  See the GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License along with
#  WuttaFarm.  If not, see <http://www.gnu.org/licenses/>.
#
################################################################################
"""
Model definition for Animal Types
"""

import sqlalchemy as sa
from sqlalchemy import orm

from wuttjamaican.db import model

from wuttafarm.db.model.assets import AssetMixin, add_asset_proxies


class AnimalType(model.Base):
    """
    Represents an "animal type" (taxonomy term) from farmOS
    """

    __tablename__ = "animal_type"
    __versioned__ = {
        "exclude": [
            "changed",
        ],
    }
    __wutta_hint__ = {
        "model_title": "Animal Type",
        "model_title_plural": "Animal Types",
    }

    uuid = model.uuid_column()

    name = sa.Column(
        sa.String(length=100),
        nullable=False,
        unique=True,
        doc="""
        Name of the animal type.
        """,
    )

    description = sa.Column(
        sa.String(length=255),
        nullable=True,
        doc="""
        Optional description for the animal type.
        """,
    )

    changed = sa.Column(
        sa.DateTime(),
        nullable=True,
        doc="""
        When the animal type was last changed, according to farmOS.
        """,
    )

    farmos_uuid = sa.Column(
        model.UUID(),
        nullable=True,
        unique=True,
        doc="""
        UUID for the animal type within farmOS.
        """,
    )

    drupal_id = sa.Column(
        sa.Integer(),
        nullable=True,
        unique=True,
        doc="""
        Drupal internal ID for the animal type.
        """,
    )

    def __str__(self):
        return self.name or ""


class AnimalAsset(AssetMixin, model.Base):
    """
    Represents an animal asset from farmOS
    """

    __tablename__ = "asset_animal"
    __versioned__ = {}
    __wutta_hint__ = {
        "model_title": "Animal Asset",
        "model_title_plural": "Animal Assets",
        "farmos_asset_type": "animal",
    }

    animal_type_uuid = model.uuid_fk_column("animal_type.uuid", nullable=False)
    animal_type = orm.relationship(
        "AnimalType",
        doc="""
        Reference to the animal type.
        """,
    )

    birthdate = sa.Column(
        sa.DateTime(),
        nullable=True,
        doc="""
        Birth date (and time) for the animal, if known.
        """,
    )

    sex = sa.Column(
        sa.String(length=1),
        nullable=True,
        doc="""
        Sex of the animal.
        """,
    )

    is_sterile = sa.Column(
        sa.Boolean(),
        nullable=True,
        doc="""
        Whether the animal is sterile (e.g. castrated).
        """,
    )


add_asset_proxies(AnimalAsset)
