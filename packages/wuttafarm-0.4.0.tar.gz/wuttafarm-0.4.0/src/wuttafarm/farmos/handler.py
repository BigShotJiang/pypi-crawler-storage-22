# -*- coding: utf-8; -*-
################################################################################
#
#  WuttaFarm --Web app to integrate with and extend farmOS
#  Copyright © 2026 Lance Edgar
#
#  This file is part of WuttaFarm.
#
#  WuttaFarm is free software: you can redistribute it and/or modify it under
#  the terms of the GNU General Public License as published by the Free Software
#  Foundation, either version 3 of the License, or (at your option) any later
#  version.
#
#  WuttaFarm is distributed in the hope that it will be useful, but WITHOUT ANY
#  WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR
#  A PARTICULAR PURPOSE.  See the GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License along with
#  WuttaFarm.  If not, see <http://www.gnu.org/licenses/>.
#
################################################################################
"""
farmOS integration handler
"""

from farmOS import farmOS

from wuttjamaican.app import GenericHandler


class FarmOSHandler(GenericHandler):
    """
    Base class and default implementation for the farmOS integration
    :term:`handler`.
    """

    def get_farmos_client(self, hostname=None, **kwargs):
        """
        Returns a new farmOS API client.
        """
        if not hostname:
            hostname = self.get_farmos_url()
        return farmOS(hostname, **kwargs)

    def get_farmos_version(self, client=None, *args, **kwargs):
        """
        Returns the farmOS version in use.
        """
        if not client:
            client = self.get_farmos_client(*args, **kwargs)
        info = client.info()
        return info["meta"]["farm"]["version"]

    def is_farmos_3x(self, client=None, *args, **kwargs):
        """
        Check if the farmOS version is 3.x.
        """
        if not client:
            client = self.get_farmos_client(*args, **kwargs)

        version = self.get_farmos_version(client)
        return version[0] == "3"

    def is_farmos_4x(self, client=None, *args, **kwargs):
        """
        Check if the farmOS version is 4.x.
        """
        if not client:
            client = self.get_farmos_client(*args, **kwargs)

        version = self.get_farmos_version(client)
        return version[0] == "4"

    def get_farmos_url(self, path=None, require=True):
        """
        Returns the base URL for farmOS, or one with ``path`` appended.

        Note that if no path is provided, the final slash will be
        stripped from the base URL.

        :param path: Optional path to append to the base URL.

        :param require: If true, an error is raised when base URL
           cannot be determined.

        :returns: URL string
        """
        base = self.config.get("farmos.url.base", require=require)
        if base:
            base = base.rstrip("/")

        if path:
            path = path.lstrip("/")
            return f"{base}/{path}"

        return base
