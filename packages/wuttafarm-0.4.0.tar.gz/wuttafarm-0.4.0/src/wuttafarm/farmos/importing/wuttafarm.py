# -*- coding: utf-8; -*-
################################################################################
#
#  WuttaFarm --Web app to integrate with and extend farmOS
#  Copyright © 2026 Lance Edgar
#
#  This file is part of WuttaFarm.
#
#  WuttaFarm is free software: you can redistribute it and/or modify it under
#  the terms of the GNU General Public License as published by the Free Software
#  Foundation, either version 3 of the License, or (at your option) any later
#  version.
#
#  WuttaFarm is distributed in the hope that it will be useful, but WITHOUT ANY
#  WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR
#  A PARTICULAR PURPOSE.  See the GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License along with
#  WuttaFarm.  If not, see <http://www.gnu.org/licenses/>.
#
################################################################################
"""
WuttaFarm → farmOS data export
"""

from oauthlib.oauth2 import BackendApplicationClient
from requests_oauthlib import OAuth2Session

from wuttasync.importing import ImportHandler, FromWuttaHandler, FromWutta, Orientation

from wuttafarm.db import model
from wuttafarm.farmos import importing as farmos_importing


class FromWuttaFarmHandler(FromWuttaHandler):
    """
    Base class for import handler targeting WuttaFarm
    """

    source_key = "wuttafarm"


class ToFarmOSHandler(ImportHandler):
    """
    Base class for export handlers using CSV file(s) as data target.
    """

    target_key = "farmos"
    generic_target_title = "farmOS"

    # TODO: a lot of duplication to cleanup here; see FromFarmOSHandler

    def begin_target_transaction(self):
        """
        Establish the farmOS API client.
        """
        token = self.get_farmos_oauth2_token()
        self.farmos_client = self.app.get_farmos_client(token=token)
        self.farmos_4x = self.app.is_farmos_4x(self.farmos_client)

    def get_farmos_oauth2_token(self):

        client_id = self.config.get(
            "farmos.oauth2.importing.client_id", default="wuttafarm"
        )
        client_secret = self.config.require("farmos.oauth2.importing.client_secret")
        scope = self.config.get("farmos.oauth2.importing.scope", default="farm_manager")

        client = BackendApplicationClient(client_id=client_id)
        oauth = OAuth2Session(client=client)

        return oauth.fetch_token(
            token_url=self.app.get_farmos_url("/oauth/token"),
            include_client_id=True,
            client_secret=client_secret,
            scope=scope,
        )

    def get_importer_kwargs(self, key, **kwargs):
        kwargs = super().get_importer_kwargs(key, **kwargs)
        kwargs["farmos_client"] = self.farmos_client
        kwargs["farmos_4x"] = self.farmos_4x
        return kwargs


class FromWuttaFarmToFarmOS(FromWuttaFarmHandler, ToFarmOSHandler):
    """
    Handler for WuttaFarm → farmOS API export.
    """

    orientation = Orientation.EXPORT

    def define_importers(self):
        """ """
        importers = super().define_importers()
        importers["LandAsset"] = LandAssetImporter
        importers["StructureAsset"] = StructureAssetImporter
        importers["AnimalType"] = AnimalTypeImporter
        importers["AnimalAsset"] = AnimalAssetImporter
        importers["GroupAsset"] = GroupAssetImporter
        return importers


class FromWuttaFarm(FromWutta):

    drupal_internal_id_field = "drupal_internal__id"

    def create_target_object(self, key, source_data):
        obj = super().create_target_object(key, source_data)
        if obj is None:
            return None

        if not self.dry_run:

            # set farmOS, Drupal key fields in WuttaFarm
            api_object = obj["_new_object"]
            wf_object = source_data["_src_object"]
            wf_object.farmos_uuid = obj["uuid"]
            wf_object.drupal_id = api_object["attributes"][
                self.drupal_internal_id_field
            ]

        return obj


class AnimalAssetImporter(FromWuttaFarm, farmos_importing.model.AnimalAssetImporter):
    """
    WuttaFarm → farmOS API exporter for Animal Assets
    """

    source_model_class = model.AnimalAsset

    supported_fields = [
        "uuid",
        "asset_name",
        "animal_type_uuid",
        "sex",
        "is_sterile",
        "birthdate",
        "notes",
        "archived",
    ]

    def normalize_source_object(self, animal):
        return {
            "uuid": animal.farmos_uuid or self.app.make_true_uuid(),
            "asset_name": animal.asset_name,
            "animal_type_uuid": animal.animal_type.farmos_uuid,
            "sex": animal.sex,
            "is_sterile": animal.is_sterile,
            "birthdate": animal.birthdate,
            "notes": animal.notes,
            "archived": animal.archived,
            "_src_object": animal,
        }


class AnimalTypeImporter(FromWuttaFarm, farmos_importing.model.AnimalTypeImporter):
    """
    WuttaFarm → farmOS API exporter for Animal Types
    """

    source_model_class = model.AnimalType

    supported_fields = [
        "uuid",
        "name",
    ]

    drupal_internal_id_field = "drupal_internal__tid"

    def normalize_source_object(self, animal_type):
        return {
            "uuid": animal_type.farmos_uuid or self.app.make_true_uuid(),
            "name": animal_type.name,
            "_src_object": animal_type,
        }


class GroupAssetImporter(FromWuttaFarm, farmos_importing.model.GroupAssetImporter):
    """
    WuttaFarm → farmOS API exporter for Group Assets
    """

    source_model_class = model.GroupAsset

    supported_fields = [
        "uuid",
        "asset_name",
        "notes",
        "archived",
    ]

    def normalize_source_object(self, group):
        return {
            "uuid": group.farmos_uuid or self.app.make_true_uuid(),
            "asset_name": group.asset_name,
            "notes": group.notes,
            "archived": group.archived,
            "_src_object": group,
        }


class LandAssetImporter(FromWuttaFarm, farmos_importing.model.LandAssetImporter):
    """
    WuttaFarm → farmOS API exporter for Land Assets
    """

    source_model_class = model.LandAsset

    supported_fields = [
        "uuid",
        "asset_name",
        "land_type_id",
        "is_location",
        "is_fixed",
        "notes",
        "archived",
    ]

    def normalize_source_object(self, land):
        return {
            "uuid": land.farmos_uuid or self.app.make_true_uuid(),
            "asset_name": land.asset_name,
            "land_type_id": land.land_type.drupal_id,
            "is_location": land.is_location,
            "is_fixed": land.is_fixed,
            "notes": land.notes,
            "archived": land.archived,
            "_src_object": land,
        }


class StructureAssetImporter(
    FromWuttaFarm, farmos_importing.model.StructureAssetImporter
):
    """
    WuttaFarm → farmOS API exporter for Structure Assets
    """

    source_model_class = model.StructureAsset

    supported_fields = [
        "uuid",
        "asset_name",
        "structure_type_id",
        "is_location",
        "is_fixed",
        "notes",
        "archived",
    ]

    def normalize_source_object(self, structure):
        return {
            "uuid": structure.farmos_uuid or self.app.make_true_uuid(),
            "asset_name": structure.asset_name,
            "structure_type_id": structure.structure_type.drupal_id,
            "is_location": structure.is_location,
            "is_fixed": structure.is_fixed,
            "notes": structure.notes,
            "archived": structure.archived,
            "_src_object": structure,
        }
