# -*- coding: utf-8; -*-
################################################################################
#
#  WuttaFarm --Web app to integrate with and extend farmOS
#  Copyright © 2026 Lance Edgar
#
#  This file is part of WuttaFarm.
#
#  WuttaFarm is free software: you can redistribute it and/or modify it under
#  the terms of the GNU General Public License as published by the Free Software
#  Foundation, either version 3 of the License, or (at your option) any later
#  version.
#
#  WuttaFarm is distributed in the hope that it will be useful, but WITHOUT ANY
#  WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR
#  A PARTICULAR PURPOSE.  See the GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License along with
#  WuttaFarm.  If not, see <http://www.gnu.org/licenses/>.
#
################################################################################
"""
WuttaFarm web app
"""

import os

from wuttaweb import app as base


def main(global_config, **settings):
    """
    Make and return the WSGI app (Paste entry point).
    """
    # prefer WuttaFarm templates over wuttaweb
    settings.setdefault(
        "mako.directories",
        [
            "wuttafarm.web:templates",
            "wuttaweb:templates",
        ],
    )

    # make config objects
    wutta_config = base.make_wutta_config(settings)
    pyramid_config = base.make_pyramid_config(settings)
    app = wutta_config.get_app()

    # custom buefy css
    # TODO: this is not robust enough, probably..but works for me/now
    wutta_config.setdefault(
        "wuttaweb.liburl.buefy_css", "/wuttafarm/css/wuttafarm-buefy.css"
    )
    # nb. ensure buefy version matches what we use for custom css
    wutta_config.setdefault("wuttaweb.libver.buefy", "0.9.29")
    wutta_config.setdefault("wuttaweb.libver.buefy_css", "0.9.29")

    # bring in the rest of WuttaFarm
    pyramid_config.include("wuttafarm.web.static")
    pyramid_config.include("wuttafarm.web.subscribers")
    pyramid_config.include("wuttafarm.web.views")

    return pyramid_config.make_wsgi_app()


def make_wsgi_app():
    """
    Make and return the WSGI app (generic entry point).
    """
    return base.make_wsgi_app(main)


def make_asgi_app():
    """
    Make and return the ASGI app (generic entry point).
    """
    return base.make_asgi_app(main)
