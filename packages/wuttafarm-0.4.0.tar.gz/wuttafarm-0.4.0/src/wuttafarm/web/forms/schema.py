# -*- coding: utf-8; -*-
################################################################################
#
#  WuttaFarm --Web app to integrate with and extend farmOS
#  Copyright © 2026 Lance Edgar
#
#  This file is part of WuttaFarm.
#
#  WuttaFarm is free software: you can redistribute it and/or modify it under
#  the terms of the GNU General Public License as published by the Free Software
#  Foundation, either version 3 of the License, or (at your option) any later
#  version.
#
#  WuttaFarm is distributed in the hope that it will be useful, but WITHOUT ANY
#  WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR
#  A PARTICULAR PURPOSE.  See the GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License along with
#  WuttaFarm.  If not, see <http://www.gnu.org/licenses/>.
#
################################################################################
"""
Custom form widgets for WuttaFarm
"""

import json

import colander

from wuttaweb.forms.schema import ObjectRef, WuttaSet


class AnimalTypeRef(ObjectRef):
    """
    Custom schema type for a
    :class:`~wuttafarm.db.model.animals.AnimalType` reference field.

    This is a subclass of
    :class:`~wuttaweb:wuttaweb.forms.schema.ObjectRef`.
    """

    @property
    def model_class(self):  # pylint: disable=empty-docstring
        """ """
        model = self.app.model
        return model.AnimalType

    def sort_query(self, query):  # pylint: disable=empty-docstring
        """ """
        return query.order_by(self.model_class.name)

    def get_object_url(self, obj):  # pylint: disable=empty-docstring
        """ """
        animal_type = obj
        return self.request.route_url("animal_types.view", uuid=animal_type.uuid)


class AnimalTypeType(colander.SchemaType):

    def __init__(self, request, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.request = request

    def serialize(self, node, appstruct):
        if appstruct is colander.null:
            return colander.null

        return json.dumps(appstruct)

    def widget_maker(self, **kwargs):  # pylint: disable=empty-docstring
        """ """
        from wuttafarm.web.forms.widgets import AnimalTypeWidget

        return AnimalTypeWidget(self.request, **kwargs)


class LandTypeRef(ObjectRef):
    """
    Custom schema type for a
    :class:`~wuttafarm.db.model.land.LandType` reference field.

    This is a subclass of
    :class:`~wuttaweb:wuttaweb.forms.schema.ObjectRef`.
    """

    @property
    def model_class(self):  # pylint: disable=empty-docstring
        """ """
        model = self.app.model
        return model.LandType

    def sort_query(self, query):  # pylint: disable=empty-docstring
        """ """
        return query.order_by(self.model_class.name)

    def get_object_url(self, obj):  # pylint: disable=empty-docstring
        """ """
        land_type = obj
        return self.request.route_url("land_types.view", uuid=land_type.uuid)


class StructureType(colander.SchemaType):

    def __init__(self, request, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.request = request

    def serialize(self, node, appstruct):
        if appstruct is colander.null:
            return colander.null

        return json.dumps(appstruct)

    def widget_maker(self, **kwargs):  # pylint: disable=empty-docstring
        """ """
        from wuttafarm.web.forms.widgets import StructureWidget

        return StructureWidget(self.request, **kwargs)


class StructureTypeRef(ObjectRef):
    """
    Custom schema type for a
    :class:`~wuttafarm.db.model.structures.Structure` reference field.

    This is a subclass of
    :class:`~wuttaweb:wuttaweb.forms.schema.ObjectRef`.
    """

    @property
    def model_class(self):  # pylint: disable=empty-docstring
        """ """
        model = self.app.model
        return model.StructureType

    def sort_query(self, query):  # pylint: disable=empty-docstring
        """ """
        return query.order_by(self.model_class.name)

    def get_object_url(self, obj):  # pylint: disable=empty-docstring
        """ """
        structure_type = obj
        return self.request.route_url("structure_types.view", uuid=structure_type.uuid)


class UsersType(colander.SchemaType):

    def __init__(self, request, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.request = request

    def serialize(self, node, appstruct):
        if appstruct is colander.null:
            return colander.null

        return json.dumps(appstruct)

    def widget_maker(self, **kwargs):  # pylint: disable=empty-docstring
        """ """
        from wuttafarm.web.forms.widgets import UsersWidget

        return UsersWidget(self.request, **kwargs)


class AssetParentRefs(WuttaSet):
    """
    Schema type for Parents field which references assets.
    """

    def serialize(self, node, appstruct):
        if not appstruct:
            appstruct = []
        uuids = [u.hex for u in appstruct]
        return json.dumps(uuids)

    def widget_maker(self, **kwargs):
        from wuttafarm.web.forms.widgets import AssetParentRefsWidget

        return AssetParentRefsWidget(self.request, **kwargs)
