# -*- coding: utf-8; -*-
################################################################################
#
#  WuttaFarm --Web app to integrate with and extend farmOS
#  Copyright © 2026 Lance Edgar
#
#  This file is part of WuttaFarm.
#
#  WuttaFarm is free software: you can redistribute it and/or modify it under
#  the terms of the GNU General Public License as published by the Free Software
#  Foundation, either version 3 of the License, or (at your option) any later
#  version.
#
#  WuttaFarm is distributed in the hope that it will be useful, but WITHOUT ANY
#  WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR
#  A PARTICULAR PURPOSE.  See the GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License along with
#  WuttaFarm.  If not, see <http://www.gnu.org/licenses/>.
#
################################################################################
"""
WuttaFarm Menu
"""

from wuttaweb import menus as base


class WuttaFarmMenuHandler(base.MenuHandler):
    """
    WuttaFarm menu handler
    """

    def make_menus(self, request, **kwargs):
        return [
            self.make_asset_menu(request),
            self.make_log_menu(request),
            self.make_farmos_menu(request),
            self.make_admin_menu(request, include_people=True),
        ]

    def make_asset_menu(self, request):
        return {
            "title": "Assets",
            "type": "menu",
            "items": [
                {
                    "title": "All Assets",
                    "route": "assets",
                    "perm": "assets.list",
                },
                {
                    "title": "Animal",
                    "route": "animal_assets",
                    "perm": "animal_assets.list",
                },
                {
                    "title": "Group",
                    "route": "group_assets",
                    "perm": "group_assets.list",
                },
                {
                    "title": "Land",
                    "route": "land_assets",
                    "perm": "land_assets.list",
                },
                {
                    "title": "Structure",
                    "route": "structure_assets",
                    "perm": "structure_assets.list",
                },
                {"type": "sep"},
                {
                    "title": "Animal Types",
                    "route": "animal_types",
                    "perm": "animal_types.list",
                },
                {
                    "title": "Land Types",
                    "route": "land_types",
                    "perm": "land_types.list",
                },
                {
                    "title": "Structure Types",
                    "route": "structure_types",
                    "perm": "structure_types.list",
                },
                {
                    "title": "Asset Types",
                    "route": "asset_types",
                    "perm": "asset_types.list",
                },
            ],
        }

    def make_log_menu(self, request):
        return {
            "title": "Logs",
            "type": "menu",
            "items": [
                {
                    "title": "Activity Logs",
                    "route": "activity_logs",
                    "perm": "activity_logs.list",
                },
                {"type": "sep"},
                {
                    "title": "Log Types",
                    "route": "log_types",
                    "perm": "log_types.list",
                },
            ],
        }

    def make_farmos_menu(self, request):
        config = request.wutta_config
        app = config.get_app()
        return {
            "title": "farmOS",
            "type": "menu",
            "items": [
                {
                    "title": "Go to farmOS",
                    "url": app.get_farmos_url(),
                    "target": "_blank",
                },
                {"type": "sep"},
                {
                    "title": "Animals",
                    "route": "farmos_animals",
                    "perm": "farmos_animals.list",
                },
                {
                    "title": "Groups",
                    "route": "farmos_groups",
                    "perm": "farmos_groups.list",
                },
                {
                    "title": "Structures",
                    "route": "farmos_structures",
                    "perm": "farmos_structures.list",
                },
                {
                    "title": "Land",
                    "route": "farmos_land_assets",
                    "perm": "farmos_land_assets.list",
                },
                {"type": "sep"},
                {
                    "title": "Activity Logs",
                    "route": "farmos_logs_activity",
                    "perm": "farmos_logs_activity.list",
                },
                {"type": "sep"},
                {
                    "title": "Animal Types",
                    "route": "farmos_animal_types",
                    "perm": "farmos_animal_types.list",
                },
                {
                    "title": "Structure Types",
                    "route": "farmos_structure_types",
                    "perm": "farmos_structure_types.list",
                },
                {
                    "title": "Land Types",
                    "route": "farmos_land_types",
                    "perm": "farmos_land_types.list",
                },
                {
                    "title": "Asset Types",
                    "route": "farmos_asset_types",
                    "perm": "farmos_asset_types.list",
                },
                {
                    "title": "Log Types",
                    "route": "farmos_log_types",
                    "perm": "farmos_log_types.list",
                },
                {"type": "sep"},
                {
                    "title": "Users",
                    "route": "farmos_users",
                    "perm": "farmos_users.list",
                },
            ],
        }
