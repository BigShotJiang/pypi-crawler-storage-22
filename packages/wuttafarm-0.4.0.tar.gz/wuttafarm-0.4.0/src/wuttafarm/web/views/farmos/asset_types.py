# -*- coding: utf-8; -*-
################################################################################
#
#  WuttaFarm --Web app to integrate with and extend farmOS
#  Copyright © 2026 Lance Edgar
#
#  This file is part of WuttaFarm.
#
#  WuttaFarm is free software: you can redistribute it and/or modify it under
#  the terms of the GNU General Public License as published by the Free Software
#  Foundation, either version 3 of the License, or (at your option) any later
#  version.
#
#  WuttaFarm is distributed in the hope that it will be useful, but WITHOUT ANY
#  WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR
#  A PARTICULAR PURPOSE.  See the GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License along with
#  WuttaFarm.  If not, see <http://www.gnu.org/licenses/>.
#
################################################################################
"""
View for farmOS asset types
"""

from wuttafarm.web.views.farmos import FarmOSMasterView


class AssetTypeView(FarmOSMasterView):
    """
    View for farmOS asset types
    """

    model_name = "farmos_asset_type"
    model_title = "farmOS Asset Type"
    model_title_plural = "farmOS Asset Types"

    route_prefix = "farmos_asset_types"
    url_prefix = "/farmOS/asset-types"

    grid_columns = [
        "label",
        "description",
    ]

    sort_defaults = "label"

    form_fields = [
        "label",
        "description",
    ]

    def get_grid_data(self, columns=None, session=None):
        asset_types = self.farmos_client.resource.get("asset_type", "asset_type")
        return [self.normalize_asset_type(t) for t in asset_types["data"]]

    def configure_grid(self, grid):
        g = grid
        super().configure_grid(g)

        # label
        g.set_link("label")
        g.set_searchable("label")

        # description
        g.set_searchable("description")

    def get_instance(self):
        asset_type = self.farmos_client.resource.get_id(
            "asset_type", "asset_type", self.request.matchdict["uuid"]
        )
        self.raw_json = asset_type
        return self.normalize_asset_type(asset_type["data"])

    def get_instance_title(self, asset_type):
        return asset_type["label"]

    def normalize_asset_type(self, asset_type):
        return {
            "uuid": asset_type["id"],
            "drupal_id": asset_type["attributes"]["drupal_internal__id"],
            "label": asset_type["attributes"]["label"],
            "description": asset_type["attributes"]["description"],
        }

    def configure_form(self, form):
        f = form
        super().configure_form(f)

        # description
        f.set_widget("description", "notes")

    def get_xref_buttons(self, asset_type):
        model = self.app.model
        session = self.Session()
        buttons = []

        if wf_asset_type := (
            session.query(model.AssetType)
            .filter(model.AssetType.farmos_uuid == asset_type["uuid"])
            .first()
        ):
            buttons.append(
                self.make_button(
                    f"View {self.app.get_title()} record",
                    primary=True,
                    url=self.request.route_url(
                        "asset_types.view", uuid=wf_asset_type.uuid
                    ),
                    icon_left="eye",
                )
            )

        return buttons


def defaults(config, **kwargs):
    base = globals()

    AssetTypeView = kwargs.get("AssetTypeView", base["AssetTypeView"])
    AssetTypeView.defaults(config)


def includeme(config):
    defaults(config)
