# -*- coding: utf-8; -*-
################################################################################
#
#  WuttaFarm --Web app to integrate with and extend farmOS
#  Copyright © 2026 Lance Edgar
#
#  This file is part of WuttaFarm.
#
#  WuttaFarm is free software: you can redistribute it and/or modify it under
#  the terms of the GNU General Public License as published by the Free Software
#  Foundation, either version 3 of the License, or (at your option) any later
#  version.
#
#  WuttaFarm is distributed in the hope that it will be useful, but WITHOUT ANY
#  WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR
#  A PARTICULAR PURPOSE.  See the GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License along with
#  WuttaFarm.  If not, see <http://www.gnu.org/licenses/>.
#
################################################################################
"""
View for farmOS log types
"""

from wuttafarm.web.views.farmos import FarmOSMasterView


class LogTypeView(FarmOSMasterView):
    """
    Master view for Log Types in farmOS.
    """

    model_name = "farmos_log_type"
    model_title = "farmOS Log Type"
    model_title_plural = "farmOS Log Types"

    route_prefix = "farmos_log_types"
    url_prefix = "/farmOS/log-types"

    grid_columns = [
        "label",
        "description",
    ]

    sort_defaults = "label"

    form_fields = [
        "label",
        "description",
    ]

    def get_grid_data(self, columns=None, session=None):
        log_types = self.farmos_client.resource.get("log_type", "log_type")
        return [self.normalize_log_type(t) for t in log_types["data"]]

    def configure_grid(self, grid):
        g = grid
        super().configure_grid(g)

        # label
        g.set_link("label")
        g.set_searchable("label")

    def get_instance(self):
        log_type = self.farmos_client.resource.get_id(
            "log_type", "log_type", self.request.matchdict["uuid"]
        )
        self.raw_json = log_type
        return self.normalize_log_type(log_type["data"])

    def get_instance_title(self, log_type):
        return log_type["label"]

    def normalize_log_type(self, log_type):
        return {
            "uuid": log_type["id"],
            "drupal_id": log_type["attributes"]["drupal_internal__id"],
            "label": log_type["attributes"]["label"],
            "description": log_type["attributes"]["description"],
        }

    def configure_form(self, form):
        f = form
        super().configure_form(f)

        # description
        f.set_widget("description", "notes")

    def get_xref_buttons(self, log_type):
        model = self.app.model
        session = self.Session()
        buttons = []

        if wf_log_type := (
            session.query(model.LogType)
            .filter(model.LogType.farmos_uuid == log_type["uuid"])
            .first()
        ):
            buttons.append(
                self.make_button(
                    f"View {self.app.get_title()} record",
                    primary=True,
                    url=self.request.route_url("log_types.view", uuid=wf_log_type.uuid),
                    icon_left="eye",
                )
            )

        return buttons


def defaults(config, **kwargs):
    base = globals()

    LogTypeView = kwargs.get("LogTypeView", base["LogTypeView"])
    LogTypeView.defaults(config)


def includeme(config):
    defaults(config)
