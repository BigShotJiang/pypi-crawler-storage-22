# -*- coding: utf-8; -*-
################################################################################
#
#  WuttaFarm --Web app to integrate with and extend farmOS
#  Copyright © 2026 Lance Edgar
#
#  This file is part of WuttaFarm.
#
#  WuttaFarm is free software: you can redistribute it and/or modify it under
#  the terms of the GNU General Public License as published by the Free Software
#  Foundation, either version 3 of the License, or (at your option) any later
#  version.
#
#  WuttaFarm is distributed in the hope that it will be useful, but WITHOUT ANY
#  WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR
#  A PARTICULAR PURPOSE.  See the GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License along with
#  WuttaFarm.  If not, see <http://www.gnu.org/licenses/>.
#
################################################################################
"""
View for farmOS structure types
"""

from wuttafarm.web.views.farmos import FarmOSMasterView


class StructureTypeView(FarmOSMasterView):
    """
    Master view for Structure Types in farmOS.
    """

    model_name = "farmos_structure_type"
    model_title = "farmOS Structure Type"
    model_title_plural = "farmOS Structure Types"

    route_prefix = "farmos_structure_types"
    url_prefix = "/farmOS/structure-types"

    grid_columns = [
        "label",
    ]

    sort_defaults = "label"

    form_fields = [
        "label",
    ]

    def get_grid_data(self, columns=None, session=None):
        structure_types = self.farmos_client.resource.get(
            "structure_type", "structure_type"
        )
        return [self.normalize_structure_type(t) for t in structure_types["data"]]

    def configure_grid(self, grid):
        g = grid
        super().configure_grid(g)

        # label
        g.set_link("label")
        g.set_searchable("label")

    def get_instance(self):
        structure_type = self.farmos_client.resource.get_id(
            "structure_type", "structure_type", self.request.matchdict["uuid"]
        )
        self.raw_json = structure_type
        return self.normalize_structure_type(structure_type["data"])

    def get_instance_title(self, structure_type):
        return structure_type["label"]

    def normalize_structure_type(self, structure_type):
        return {
            "uuid": structure_type["id"],
            "drupal_id": structure_type["attributes"]["drupal_internal__id"],
            "label": structure_type["attributes"]["label"],
        }

    def get_xref_buttons(self, structure_type):
        model = self.app.model
        session = self.Session()
        buttons = []

        if wf_structure_type := (
            session.query(model.StructureType)
            .filter(model.StructureType.farmos_uuid == structure_type["uuid"])
            .first()
        ):
            buttons.append(
                self.make_button(
                    f"View {self.app.get_title()} record",
                    primary=True,
                    url=self.request.route_url(
                        "structure_types.view", uuid=wf_structure_type.uuid
                    ),
                    icon_left="eye",
                )
            )

        return buttons


def defaults(config, **kwargs):
    base = globals()

    StructureTypeView = kwargs.get("StructureTypeView", base["StructureTypeView"])
    StructureTypeView.defaults(config)


def includeme(config):
    defaults(config)
