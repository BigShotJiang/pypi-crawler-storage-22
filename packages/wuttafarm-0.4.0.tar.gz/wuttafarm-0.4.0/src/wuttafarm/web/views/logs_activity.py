# -*- coding: utf-8; -*-
################################################################################
#
#  WuttaFarm --Web app to integrate with and extend farmOS
#  Copyright © 2026 Lance Edgar
#
#  This file is part of WuttaFarm.
#
#  WuttaFarm is free software: you can redistribute it and/or modify it under
#  the terms of the GNU General Public License as published by the Free Software
#  Foundation, either version 3 of the License, or (at your option) any later
#  version.
#
#  WuttaFarm is distributed in the hope that it will be useful, but WITHOUT ANY
#  WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR
#  A PARTICULAR PURPOSE.  See the GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License along with
#  WuttaFarm.  If not, see <http://www.gnu.org/licenses/>.
#
################################################################################
"""
Master view for Activity Logs
"""

from wuttafarm.db.model.logs import ActivityLog
from wuttafarm.web.views import WuttaFarmMasterView


class ActivityLogView(WuttaFarmMasterView):
    """
    Master view for Activity Logs
    """

    model_class = ActivityLog
    route_prefix = "activity_logs"
    url_prefix = "/logs/activity"

    farmos_refurl_path = "/logs/activity"

    grid_columns = [
        "message",
        "timestamp",
        "status",
    ]

    sort_defaults = ("timestamp", "desc")

    filter_defaults = {
        "message": {"active": True, "verb": "contains"},
    }

    form_fields = [
        "message",
        "timestamp",
        "status",
        "notes",
        "farmos_uuid",
        "drupal_id",
    ]

    def configure_grid(self, grid):
        g = grid
        super().configure_grid(g)

        # message
        g.set_link("message")

    def configure_form(self, form):
        f = form
        super().configure_form(f)

        # notes
        f.set_widget("notes", "notes")

    def get_farmos_url(self, log):
        return self.app.get_farmos_url(f"/log/{log.drupal_id}")

    def get_xref_buttons(self, log):
        buttons = super().get_xref_buttons(log)

        if log.farmos_uuid:
            buttons.append(
                self.make_button(
                    "View farmOS record",
                    primary=True,
                    url=self.request.route_url(
                        "farmos_logs_activity.view", uuid=log.farmos_uuid
                    ),
                    icon_left="eye",
                )
            )

        return buttons


def defaults(config, **kwargs):
    base = globals()

    ActivityLogView = kwargs.get("ActivityLogView", base["ActivityLogView"])
    ActivityLogView.defaults(config)


def includeme(config):
    defaults(config)
