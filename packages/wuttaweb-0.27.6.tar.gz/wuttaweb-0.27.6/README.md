
# WuttaWeb

Web app for Wutta Framework

See docs at https://docs.wuttaproject.org/wuttaweb/
