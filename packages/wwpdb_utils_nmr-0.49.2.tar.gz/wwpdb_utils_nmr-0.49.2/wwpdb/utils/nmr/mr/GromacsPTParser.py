# Generated from GromacsPTParser.g4 by ANTLR 4.13.0
# encoding: utf-8
from antlr4 import *
from io import StringIO
import sys
if sys.version_info[1] > 5:
	from typing import TextIO
else:
	from typing.io import TextIO

def serializedATN():
    return [
        4,1,45,636,2,0,7,0,2,1,7,1,2,2,7,2,2,3,7,3,2,4,7,4,2,5,7,5,2,6,7,
        6,2,7,7,7,2,8,7,8,2,9,7,9,2,10,7,10,2,11,7,11,2,12,7,12,2,13,7,13,
        2,14,7,14,2,15,7,15,2,16,7,16,2,17,7,17,2,18,7,18,2,19,7,19,2,20,
        7,20,2,21,7,21,2,22,7,22,2,23,7,23,2,24,7,24,2,25,7,25,2,26,7,26,
        2,27,7,27,2,28,7,28,2,29,7,29,2,30,7,30,2,31,7,31,2,32,7,32,2,33,
        7,33,2,34,7,34,2,35,7,35,2,36,7,36,2,37,7,37,2,38,7,38,2,39,7,39,
        2,40,7,40,2,41,7,41,2,42,7,42,2,43,7,43,2,44,7,44,2,45,7,45,2,46,
        7,46,2,47,7,47,2,48,7,48,2,49,7,49,2,50,7,50,2,51,7,51,1,0,1,0,1,
        0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,
        0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,5,0,134,8,0,10,0,12,0,
        137,9,0,1,0,1,0,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,3,1,150,8,1,
        1,2,1,2,1,2,1,2,4,2,156,8,2,11,2,12,2,157,1,3,1,3,1,3,1,4,1,4,1,
        4,1,4,5,4,167,8,4,10,4,12,4,170,9,4,1,5,1,5,1,5,1,5,1,5,1,5,1,5,
        1,5,1,6,1,6,1,6,1,6,5,6,184,8,6,10,6,12,6,187,9,6,1,7,1,7,1,7,1,
        7,1,7,1,7,1,8,1,8,1,8,1,8,5,8,199,8,8,10,8,12,8,202,9,8,1,9,1,9,
        1,9,1,9,1,9,1,9,1,10,1,10,1,10,1,10,5,10,214,8,10,10,10,12,10,217,
        9,10,1,11,1,11,1,11,1,11,1,11,1,11,1,11,1,12,1,12,1,12,1,12,5,12,
        230,8,12,10,12,12,12,233,9,12,1,13,1,13,1,13,1,13,1,13,1,13,1,13,
        1,13,1,13,1,13,3,13,245,8,13,1,14,1,14,1,14,1,14,5,14,251,8,14,10,
        14,12,14,254,9,14,1,15,1,15,1,15,1,15,1,15,1,15,1,16,1,16,1,16,1,
        16,5,16,266,8,16,10,16,12,16,269,9,16,1,17,1,17,1,17,1,17,1,17,1,
        17,3,17,277,8,17,1,18,1,18,1,18,1,18,4,18,283,8,18,11,18,12,18,284,
        1,19,1,19,1,19,1,19,1,19,1,19,1,19,1,19,1,19,1,19,1,19,1,19,3,19,
        299,8,19,3,19,301,8,19,1,19,3,19,304,8,19,1,20,1,20,1,20,1,20,5,
        20,310,8,20,10,20,12,20,313,9,20,1,21,1,21,1,21,1,21,1,21,1,21,3,
        21,321,8,21,3,21,323,8,21,1,21,3,21,326,8,21,1,22,1,22,1,22,1,22,
        5,22,332,8,22,10,22,12,22,335,9,22,1,23,1,23,1,23,1,23,1,23,1,23,
        1,23,1,23,1,23,3,23,346,8,23,3,23,348,8,23,1,23,3,23,351,8,23,1,
        24,1,24,1,24,1,24,5,24,357,8,24,10,24,12,24,360,9,24,1,25,1,25,1,
        25,1,25,1,25,1,25,1,25,1,25,3,25,370,8,25,1,25,3,25,373,8,25,1,26,
        1,26,1,26,1,26,5,26,379,8,26,10,26,12,26,382,9,26,1,27,1,27,1,27,
        1,27,1,27,1,27,1,27,1,27,1,27,1,27,1,27,3,27,395,8,27,3,27,397,8,
        27,3,27,399,8,27,3,27,401,8,27,1,27,3,27,404,8,27,1,28,1,28,1,28,
        1,28,5,28,410,8,28,10,28,12,28,413,9,28,1,29,1,29,1,29,1,29,1,29,
        1,29,1,29,1,29,1,29,1,29,1,29,3,29,426,8,29,3,29,428,8,29,3,29,430,
        8,29,3,29,432,8,29,1,29,3,29,435,8,29,1,30,1,30,1,30,1,30,5,30,441,
        8,30,10,30,12,30,444,9,30,1,31,1,31,4,31,448,8,31,11,31,12,31,449,
        1,31,3,31,453,8,31,1,32,1,32,1,32,1,32,5,32,459,8,32,10,32,12,32,
        462,9,32,1,33,1,33,1,33,1,33,3,33,468,8,33,1,33,3,33,471,8,33,1,
        34,1,34,1,34,1,34,5,34,477,8,34,10,34,12,34,480,9,34,1,35,1,35,1,
        35,1,35,1,35,3,35,487,8,35,1,35,3,35,490,8,35,1,36,1,36,1,36,1,36,
        5,36,496,8,36,10,36,12,36,499,9,36,1,37,1,37,1,37,1,37,3,37,505,
        8,37,1,38,1,38,1,38,1,38,5,38,511,8,38,10,38,12,38,514,9,38,1,39,
        1,39,1,39,1,39,1,39,3,39,521,8,39,1,39,3,39,524,8,39,1,40,1,40,1,
        40,1,40,5,40,530,8,40,10,40,12,40,533,9,40,1,41,1,41,1,41,1,41,1,
        41,1,41,1,41,1,41,3,41,543,8,41,3,41,545,8,41,1,41,3,41,548,8,41,
        1,42,1,42,1,42,1,42,5,42,554,8,42,10,42,12,42,557,9,42,1,43,1,43,
        1,43,1,43,1,43,1,43,1,43,1,43,1,43,1,43,3,43,569,8,43,1,43,3,43,
        572,8,43,1,44,1,44,1,44,1,44,5,44,578,8,44,10,44,12,44,581,9,44,
        1,45,1,45,1,45,4,45,586,8,45,11,45,12,45,587,1,45,3,45,591,8,45,
        1,45,3,45,594,8,45,1,46,1,46,1,46,1,46,5,46,600,8,46,10,46,12,46,
        603,9,46,1,46,1,46,1,47,1,47,1,47,1,47,4,47,611,8,47,11,47,12,47,
        612,1,48,1,48,1,48,1,49,1,49,1,50,1,50,1,50,1,50,4,50,624,8,50,11,
        50,12,50,625,1,51,1,51,1,51,1,51,1,51,1,51,3,51,634,8,51,1,51,0,
        0,52,0,2,4,6,8,10,12,14,16,18,20,22,24,26,28,30,32,34,36,38,40,42,
        44,46,48,50,52,54,56,58,60,62,64,66,68,70,72,74,76,78,80,82,84,86,
        88,90,92,94,96,98,100,102,0,1,1,0,30,31,677,0,135,1,0,0,0,2,140,
        1,0,0,0,4,151,1,0,0,0,6,159,1,0,0,0,8,162,1,0,0,0,10,171,1,0,0,0,
        12,179,1,0,0,0,14,188,1,0,0,0,16,194,1,0,0,0,18,203,1,0,0,0,20,209,
        1,0,0,0,22,218,1,0,0,0,24,225,1,0,0,0,26,234,1,0,0,0,28,246,1,0,
        0,0,30,255,1,0,0,0,32,261,1,0,0,0,34,270,1,0,0,0,36,278,1,0,0,0,
        38,286,1,0,0,0,40,305,1,0,0,0,42,314,1,0,0,0,44,327,1,0,0,0,46,336,
        1,0,0,0,48,352,1,0,0,0,50,361,1,0,0,0,52,374,1,0,0,0,54,383,1,0,
        0,0,56,405,1,0,0,0,58,414,1,0,0,0,60,436,1,0,0,0,62,445,1,0,0,0,
        64,454,1,0,0,0,66,463,1,0,0,0,68,472,1,0,0,0,70,481,1,0,0,0,72,491,
        1,0,0,0,74,500,1,0,0,0,76,506,1,0,0,0,78,515,1,0,0,0,80,525,1,0,
        0,0,82,534,1,0,0,0,84,549,1,0,0,0,86,558,1,0,0,0,88,573,1,0,0,0,
        90,582,1,0,0,0,92,595,1,0,0,0,94,606,1,0,0,0,96,614,1,0,0,0,98,617,
        1,0,0,0,100,619,1,0,0,0,102,627,1,0,0,0,104,134,3,2,1,0,105,134,
        3,4,2,0,106,134,3,8,4,0,107,134,3,12,6,0,108,134,3,16,8,0,109,134,
        3,20,10,0,110,134,3,24,12,0,111,134,3,28,14,0,112,134,3,32,16,0,
        113,134,3,36,18,0,114,134,3,40,20,0,115,134,3,44,22,0,116,134,3,
        48,24,0,117,134,3,52,26,0,118,134,3,56,28,0,119,134,3,60,30,0,120,
        134,3,64,32,0,121,134,3,68,34,0,122,134,3,72,36,0,123,134,3,76,38,
        0,124,134,3,80,40,0,125,134,3,84,42,0,126,134,3,88,44,0,127,134,
        3,92,46,0,128,134,3,94,47,0,129,134,3,100,50,0,130,131,5,1,0,0,131,
        132,5,29,0,0,132,134,5,2,0,0,133,104,1,0,0,0,133,105,1,0,0,0,133,
        106,1,0,0,0,133,107,1,0,0,0,133,108,1,0,0,0,133,109,1,0,0,0,133,
        110,1,0,0,0,133,111,1,0,0,0,133,112,1,0,0,0,133,113,1,0,0,0,133,
        114,1,0,0,0,133,115,1,0,0,0,133,116,1,0,0,0,133,117,1,0,0,0,133,
        118,1,0,0,0,133,119,1,0,0,0,133,120,1,0,0,0,133,121,1,0,0,0,133,
        122,1,0,0,0,133,123,1,0,0,0,133,124,1,0,0,0,133,125,1,0,0,0,133,
        126,1,0,0,0,133,127,1,0,0,0,133,128,1,0,0,0,133,129,1,0,0,0,133,
        130,1,0,0,0,134,137,1,0,0,0,135,133,1,0,0,0,135,136,1,0,0,0,136,
        138,1,0,0,0,137,135,1,0,0,0,138,139,5,0,0,1,139,1,1,0,0,0,140,141,
        5,1,0,0,141,142,5,3,0,0,142,143,5,2,0,0,143,144,5,30,0,0,144,145,
        5,30,0,0,145,146,5,35,0,0,146,147,5,31,0,0,147,149,5,31,0,0,148,
        150,5,35,0,0,149,148,1,0,0,0,149,150,1,0,0,0,150,3,1,0,0,0,151,152,
        5,1,0,0,152,153,5,4,0,0,153,155,5,2,0,0,154,156,3,6,3,0,155,154,
        1,0,0,0,156,157,1,0,0,0,157,155,1,0,0,0,157,158,1,0,0,0,158,5,1,
        0,0,0,159,160,5,35,0,0,160,161,5,30,0,0,161,7,1,0,0,0,162,163,5,
        1,0,0,163,164,5,5,0,0,164,168,5,2,0,0,165,167,3,10,5,0,166,165,1,
        0,0,0,167,170,1,0,0,0,168,166,1,0,0,0,168,169,1,0,0,0,169,9,1,0,
        0,0,170,168,1,0,0,0,171,172,5,35,0,0,172,173,5,30,0,0,173,174,5,
        31,0,0,174,175,5,31,0,0,175,176,5,30,0,0,176,177,5,31,0,0,177,178,
        5,31,0,0,178,11,1,0,0,0,179,180,5,1,0,0,180,181,5,6,0,0,181,185,
        5,2,0,0,182,184,3,14,7,0,183,182,1,0,0,0,184,187,1,0,0,0,185,183,
        1,0,0,0,185,186,1,0,0,0,186,13,1,0,0,0,187,185,1,0,0,0,188,189,5,
        35,0,0,189,190,5,35,0,0,190,191,5,30,0,0,191,192,5,31,0,0,192,193,
        5,31,0,0,193,15,1,0,0,0,194,195,5,1,0,0,195,196,5,7,0,0,196,200,
        5,2,0,0,197,199,3,18,9,0,198,197,1,0,0,0,199,202,1,0,0,0,200,198,
        1,0,0,0,200,201,1,0,0,0,201,17,1,0,0,0,202,200,1,0,0,0,203,204,5,
        35,0,0,204,205,5,35,0,0,205,206,5,30,0,0,206,207,5,31,0,0,207,208,
        5,31,0,0,208,19,1,0,0,0,209,210,5,1,0,0,210,211,5,8,0,0,211,215,
        5,2,0,0,212,214,3,22,11,0,213,212,1,0,0,0,214,217,1,0,0,0,215,213,
        1,0,0,0,215,216,1,0,0,0,216,21,1,0,0,0,217,215,1,0,0,0,218,219,5,
        35,0,0,219,220,5,35,0,0,220,221,5,35,0,0,221,222,5,30,0,0,222,223,
        5,31,0,0,223,224,5,31,0,0,224,23,1,0,0,0,225,226,5,1,0,0,226,227,
        5,9,0,0,227,231,5,2,0,0,228,230,3,26,13,0,229,228,1,0,0,0,230,233,
        1,0,0,0,231,229,1,0,0,0,231,232,1,0,0,0,232,25,1,0,0,0,233,231,1,
        0,0,0,234,235,5,35,0,0,235,236,5,35,0,0,236,237,5,30,0,0,237,238,
        5,31,0,0,238,244,5,31,0,0,239,245,5,30,0,0,240,241,5,31,0,0,241,
        242,5,31,0,0,242,243,5,31,0,0,243,245,5,31,0,0,244,239,1,0,0,0,244,
        240,1,0,0,0,245,27,1,0,0,0,246,247,5,1,0,0,247,248,5,10,0,0,248,
        252,5,2,0,0,249,251,3,30,15,0,250,249,1,0,0,0,251,254,1,0,0,0,252,
        250,1,0,0,0,252,253,1,0,0,0,253,29,1,0,0,0,254,252,1,0,0,0,255,256,
        5,35,0,0,256,257,5,35,0,0,257,258,5,30,0,0,258,259,5,31,0,0,259,
        260,5,31,0,0,260,31,1,0,0,0,261,262,5,1,0,0,262,263,5,11,0,0,263,
        267,5,2,0,0,264,266,3,34,17,0,265,264,1,0,0,0,266,269,1,0,0,0,267,
        265,1,0,0,0,267,268,1,0,0,0,268,33,1,0,0,0,269,267,1,0,0,0,270,271,
        5,35,0,0,271,272,5,35,0,0,272,273,5,30,0,0,273,274,5,31,0,0,274,
        276,5,31,0,0,275,277,5,31,0,0,276,275,1,0,0,0,276,277,1,0,0,0,277,
        35,1,0,0,0,278,279,5,1,0,0,279,280,5,12,0,0,280,282,5,2,0,0,281,
        283,3,38,19,0,282,281,1,0,0,0,283,284,1,0,0,0,284,282,1,0,0,0,284,
        285,1,0,0,0,285,37,1,0,0,0,286,287,5,30,0,0,287,288,5,35,0,0,288,
        289,5,30,0,0,289,290,5,35,0,0,290,291,5,35,0,0,291,292,5,30,0,0,
        292,300,3,98,49,0,293,298,3,98,49,0,294,295,5,35,0,0,295,296,3,98,
        49,0,296,297,3,98,49,0,297,299,1,0,0,0,298,294,1,0,0,0,298,299,1,
        0,0,0,299,301,1,0,0,0,300,293,1,0,0,0,300,301,1,0,0,0,301,303,1,
        0,0,0,302,304,5,35,0,0,303,302,1,0,0,0,303,304,1,0,0,0,304,39,1,
        0,0,0,305,306,5,1,0,0,306,307,5,13,0,0,307,311,5,2,0,0,308,310,3,
        42,21,0,309,308,1,0,0,0,310,313,1,0,0,0,311,309,1,0,0,0,311,312,
        1,0,0,0,312,41,1,0,0,0,313,311,1,0,0,0,314,315,5,30,0,0,315,316,
        5,30,0,0,316,322,5,30,0,0,317,318,3,98,49,0,318,320,3,98,49,0,319,
        321,3,98,49,0,320,319,1,0,0,0,320,321,1,0,0,0,321,323,1,0,0,0,322,
        317,1,0,0,0,322,323,1,0,0,0,323,325,1,0,0,0,324,326,5,35,0,0,325,
        324,1,0,0,0,325,326,1,0,0,0,326,43,1,0,0,0,327,328,5,1,0,0,328,329,
        5,14,0,0,329,333,5,2,0,0,330,332,3,46,23,0,331,330,1,0,0,0,332,335,
        1,0,0,0,333,331,1,0,0,0,333,334,1,0,0,0,334,45,1,0,0,0,335,333,1,
        0,0,0,336,337,5,30,0,0,337,338,5,30,0,0,338,347,5,30,0,0,339,340,
        3,98,49,0,340,345,3,98,49,0,341,342,3,98,49,0,342,343,3,98,49,0,
        343,344,3,98,49,0,344,346,1,0,0,0,345,341,1,0,0,0,345,346,1,0,0,
        0,346,348,1,0,0,0,347,339,1,0,0,0,347,348,1,0,0,0,348,350,1,0,0,
        0,349,351,5,35,0,0,350,349,1,0,0,0,350,351,1,0,0,0,351,47,1,0,0,
        0,352,353,5,1,0,0,353,354,5,15,0,0,354,358,5,2,0,0,355,357,3,50,
        25,0,356,355,1,0,0,0,357,360,1,0,0,0,358,356,1,0,0,0,358,359,1,0,
        0,0,359,49,1,0,0,0,360,358,1,0,0,0,361,362,5,30,0,0,362,363,5,30,
        0,0,363,369,5,30,0,0,364,365,3,98,49,0,365,366,3,98,49,0,366,367,
        3,98,49,0,367,368,3,98,49,0,368,370,1,0,0,0,369,364,1,0,0,0,369,
        370,1,0,0,0,370,372,1,0,0,0,371,373,5,35,0,0,372,371,1,0,0,0,372,
        373,1,0,0,0,373,51,1,0,0,0,374,375,5,1,0,0,375,376,5,16,0,0,376,
        380,5,2,0,0,377,379,3,54,27,0,378,377,1,0,0,0,379,382,1,0,0,0,380,
        378,1,0,0,0,380,381,1,0,0,0,381,53,1,0,0,0,382,380,1,0,0,0,383,384,
        5,30,0,0,384,385,5,30,0,0,385,386,5,30,0,0,386,400,5,30,0,0,387,
        388,3,98,49,0,388,398,3,98,49,0,389,396,3,98,49,0,390,394,3,98,49,
        0,391,392,3,98,49,0,392,393,3,98,49,0,393,395,1,0,0,0,394,391,1,
        0,0,0,394,395,1,0,0,0,395,397,1,0,0,0,396,390,1,0,0,0,396,397,1,
        0,0,0,397,399,1,0,0,0,398,389,1,0,0,0,398,399,1,0,0,0,399,401,1,
        0,0,0,400,387,1,0,0,0,400,401,1,0,0,0,401,403,1,0,0,0,402,404,5,
        35,0,0,403,402,1,0,0,0,403,404,1,0,0,0,404,55,1,0,0,0,405,406,5,
        1,0,0,406,407,5,17,0,0,407,411,5,2,0,0,408,410,3,58,29,0,409,408,
        1,0,0,0,410,413,1,0,0,0,411,409,1,0,0,0,411,412,1,0,0,0,412,57,1,
        0,0,0,413,411,1,0,0,0,414,415,5,30,0,0,415,416,5,30,0,0,416,417,
        5,30,0,0,417,418,5,30,0,0,418,431,5,30,0,0,419,420,3,98,49,0,420,
        429,3,98,49,0,421,427,3,98,49,0,422,423,3,98,49,0,423,425,3,98,49,
        0,424,426,3,98,49,0,425,424,1,0,0,0,425,426,1,0,0,0,426,428,1,0,
        0,0,427,422,1,0,0,0,427,428,1,0,0,0,428,430,1,0,0,0,429,421,1,0,
        0,0,429,430,1,0,0,0,430,432,1,0,0,0,431,419,1,0,0,0,431,432,1,0,
        0,0,432,434,1,0,0,0,433,435,5,35,0,0,434,433,1,0,0,0,434,435,1,0,
        0,0,435,59,1,0,0,0,436,437,5,1,0,0,437,438,5,18,0,0,438,442,5,2,
        0,0,439,441,3,62,31,0,440,439,1,0,0,0,441,444,1,0,0,0,442,440,1,
        0,0,0,442,443,1,0,0,0,443,61,1,0,0,0,444,442,1,0,0,0,445,447,5,30,
        0,0,446,448,5,30,0,0,447,446,1,0,0,0,448,449,1,0,0,0,449,447,1,0,
        0,0,449,450,1,0,0,0,450,452,1,0,0,0,451,453,5,35,0,0,452,451,1,0,
        0,0,452,453,1,0,0,0,453,63,1,0,0,0,454,455,5,1,0,0,455,456,5,19,
        0,0,456,460,5,2,0,0,457,459,3,66,33,0,458,457,1,0,0,0,459,462,1,
        0,0,0,460,458,1,0,0,0,460,461,1,0,0,0,461,65,1,0,0,0,462,460,1,0,
        0,0,463,464,5,30,0,0,464,465,5,30,0,0,465,467,5,30,0,0,466,468,3,
        98,49,0,467,466,1,0,0,0,467,468,1,0,0,0,468,470,1,0,0,0,469,471,
        5,35,0,0,470,469,1,0,0,0,470,471,1,0,0,0,471,67,1,0,0,0,472,473,
        5,1,0,0,473,474,5,20,0,0,474,478,5,2,0,0,475,477,3,70,35,0,476,475,
        1,0,0,0,477,480,1,0,0,0,478,476,1,0,0,0,478,479,1,0,0,0,479,69,1,
        0,0,0,480,478,1,0,0,0,481,482,5,30,0,0,482,486,5,30,0,0,483,484,
        3,98,49,0,484,485,3,98,49,0,485,487,1,0,0,0,486,483,1,0,0,0,486,
        487,1,0,0,0,487,489,1,0,0,0,488,490,5,35,0,0,489,488,1,0,0,0,489,
        490,1,0,0,0,490,71,1,0,0,0,491,492,5,1,0,0,492,493,5,21,0,0,493,
        497,5,2,0,0,494,496,3,74,37,0,495,494,1,0,0,0,496,499,1,0,0,0,497,
        495,1,0,0,0,497,498,1,0,0,0,498,73,1,0,0,0,499,497,1,0,0,0,500,501,
        5,30,0,0,501,502,5,30,0,0,502,504,5,30,0,0,503,505,5,35,0,0,504,
        503,1,0,0,0,504,505,1,0,0,0,505,75,1,0,0,0,506,507,5,1,0,0,507,508,
        5,22,0,0,508,512,5,2,0,0,509,511,3,78,39,0,510,509,1,0,0,0,511,514,
        1,0,0,0,512,510,1,0,0,0,512,513,1,0,0,0,513,77,1,0,0,0,514,512,1,
        0,0,0,515,516,5,30,0,0,516,517,5,30,0,0,517,518,5,30,0,0,518,520,
        5,30,0,0,519,521,3,98,49,0,520,519,1,0,0,0,520,521,1,0,0,0,521,523,
        1,0,0,0,522,524,5,35,0,0,523,522,1,0,0,0,523,524,1,0,0,0,524,79,
        1,0,0,0,525,526,5,1,0,0,526,527,5,23,0,0,527,531,5,2,0,0,528,530,
        3,82,41,0,529,528,1,0,0,0,530,533,1,0,0,0,531,529,1,0,0,0,531,532,
        1,0,0,0,532,81,1,0,0,0,533,531,1,0,0,0,534,535,5,30,0,0,535,536,
        5,30,0,0,536,537,5,30,0,0,537,538,5,30,0,0,538,544,5,30,0,0,539,
        540,3,98,49,0,540,542,3,98,49,0,541,543,3,98,49,0,542,541,1,0,0,
        0,542,543,1,0,0,0,543,545,1,0,0,0,544,539,1,0,0,0,544,545,1,0,0,
        0,545,547,1,0,0,0,546,548,5,35,0,0,547,546,1,0,0,0,547,548,1,0,0,
        0,548,83,1,0,0,0,549,550,5,1,0,0,550,551,5,24,0,0,551,555,5,2,0,
        0,552,554,3,86,43,0,553,552,1,0,0,0,554,557,1,0,0,0,555,553,1,0,
        0,0,555,556,1,0,0,0,556,85,1,0,0,0,557,555,1,0,0,0,558,559,5,30,
        0,0,559,560,5,30,0,0,560,561,5,30,0,0,561,562,5,30,0,0,562,563,5,
        30,0,0,563,568,5,30,0,0,564,565,3,98,49,0,565,566,3,98,49,0,566,
        567,3,98,49,0,567,569,1,0,0,0,568,564,1,0,0,0,568,569,1,0,0,0,569,
        571,1,0,0,0,570,572,5,35,0,0,571,570,1,0,0,0,571,572,1,0,0,0,572,
        87,1,0,0,0,573,574,5,1,0,0,574,575,5,25,0,0,575,579,5,2,0,0,576,
        578,3,90,45,0,577,576,1,0,0,0,578,581,1,0,0,0,579,577,1,0,0,0,579,
        580,1,0,0,0,580,89,1,0,0,0,581,579,1,0,0,0,582,583,5,30,0,0,583,
        585,5,30,0,0,584,586,5,30,0,0,585,584,1,0,0,0,586,587,1,0,0,0,587,
        585,1,0,0,0,587,588,1,0,0,0,588,590,1,0,0,0,589,591,3,98,49,0,590,
        589,1,0,0,0,590,591,1,0,0,0,591,593,1,0,0,0,592,594,5,35,0,0,593,
        592,1,0,0,0,593,594,1,0,0,0,594,91,1,0,0,0,595,596,5,1,0,0,596,597,
        5,26,0,0,597,601,5,40,0,0,598,600,5,43,0,0,599,598,1,0,0,0,600,603,
        1,0,0,0,601,599,1,0,0,0,601,602,1,0,0,0,602,604,1,0,0,0,603,601,
        1,0,0,0,604,605,5,45,0,0,605,93,1,0,0,0,606,607,5,1,0,0,607,608,
        5,27,0,0,608,610,5,2,0,0,609,611,3,96,48,0,610,609,1,0,0,0,611,612,
        1,0,0,0,612,610,1,0,0,0,612,613,1,0,0,0,613,95,1,0,0,0,614,615,5,
        35,0,0,615,616,5,30,0,0,616,97,1,0,0,0,617,618,7,0,0,0,618,99,1,
        0,0,0,619,620,5,1,0,0,620,621,5,28,0,0,621,623,5,2,0,0,622,624,3,
        102,51,0,623,622,1,0,0,0,624,625,1,0,0,0,625,623,1,0,0,0,625,626,
        1,0,0,0,626,101,1,0,0,0,627,628,5,30,0,0,628,629,5,30,0,0,629,630,
        3,98,49,0,630,631,3,98,49,0,631,633,3,98,49,0,632,634,5,35,0,0,633,
        632,1,0,0,0,633,634,1,0,0,0,634,103,1,0,0,0,69,133,135,149,157,168,
        185,200,215,231,244,252,267,276,284,298,300,303,311,320,322,325,
        333,345,347,350,358,369,372,380,394,396,398,400,403,411,425,427,
        429,431,434,442,449,452,460,467,470,478,486,489,497,504,512,520,
        523,531,542,544,547,555,568,571,579,587,590,593,601,612,625,633
    ]

class GromacsPTParser ( Parser ):

    grammarFileName = "GromacsPTParser.g4"

    atn = ATNDeserializer().deserialize(serializedATN())

    decisionsToDFA = [ DFA(ds, i) for i, ds in enumerate(atn.decisionToState) ]

    sharedContextCache = PredictionContextCache()

    literalNames = [ "<INVALID>", "'['", "']'", "'default'", "'moleculetype'", 
                     "'atomtypes'", "'pairtypes'", "'bondtypes'", "'angletypes'", 
                     "'dihedraltypes'", "'constrainttypes'", "'nonbond_params'", 
                     "'atoms'", "'bonds'", "'pairs'", "'pairs_nb'", "'angles'", 
                     "'dihedrals'", "'exclusions'", "'constraints'", "'settles'", 
                     "'virtual_sites1'", "'virtual_sites2'", "'virtual_sites3'", 
                     "'virtual_sites4'", "'virtual_sitesn'", "'system'", 
                     "'molecules'", "'position_restraints'" ]

    symbolicNames = [ "<INVALID>", "L_brkt", "R_brkt", "Default", "Moleculetype", 
                      "Atomtypes", "Pairtypes", "Bondtypes", "Angletypes", 
                      "Dihedraltypes", "Constrainttypes", "Nonbond_params", 
                      "Atoms", "Bonds", "Pairs", "Pairs_nb", "Angles", "Dihedrals", 
                      "Exclusions", "Constraints", "Settles", "Virtual_sites1", 
                      "Virtual_sites2", "Virtual_sites3", "Virtual_sites4", 
                      "Virtual_sitesn", "System", "Molecules", "Position_restraints", 
                      "Intermolecular_interactions", "Integer", "Real", 
                      "SHARP_COMMENT", "EXCLM_COMMENT", "SMCLN_COMMENT", 
                      "Simple_name", "SPACE", "ENCLOSE_COMMENT", "SECTION_COMMENT", 
                      "LINE_COMMENT", "R_brkt_AA", "SECTION_COMMENT_AA", 
                      "LINE_COMMENT_AA", "Simple_name_AA", "SPACE_AA", "RETURN_AA" ]

    RULE_gromacs_pt = 0
    RULE_default_statement = 1
    RULE_moleculetype_statement = 2
    RULE_moleculetype = 3
    RULE_atomtypes_statement = 4
    RULE_atomtypes = 5
    RULE_pairtypes_statement = 6
    RULE_pairtypes = 7
    RULE_bondtypes_statement = 8
    RULE_bondtypes = 9
    RULE_angletypes_statement = 10
    RULE_angletypes = 11
    RULE_dihedraltypes_statement = 12
    RULE_dihedraltypes = 13
    RULE_constrainttypes_statement = 14
    RULE_constrainttypes = 15
    RULE_nonbonded_params_statement = 16
    RULE_nonbonded_params = 17
    RULE_atoms_statement = 18
    RULE_atoms = 19
    RULE_bonds_statement = 20
    RULE_bonds = 21
    RULE_pairs_statement = 22
    RULE_pairs = 23
    RULE_pairs_nb_statement = 24
    RULE_pairs_nb = 25
    RULE_angles_statement = 26
    RULE_angles = 27
    RULE_dihedrals_statement = 28
    RULE_dihedrals = 29
    RULE_exclusions_statement = 30
    RULE_exclusions = 31
    RULE_constraints_statement = 32
    RULE_constraints = 33
    RULE_settles_statement = 34
    RULE_settles = 35
    RULE_virtual_sites1_statement = 36
    RULE_virtual_sites1 = 37
    RULE_virtual_sites2_statement = 38
    RULE_virtual_sites2 = 39
    RULE_virtual_sites3_statement = 40
    RULE_virtual_sites3 = 41
    RULE_virtual_sites4_statement = 42
    RULE_virtual_sites4 = 43
    RULE_virtual_sitesn_statement = 44
    RULE_virtual_sitesn = 45
    RULE_system_statement = 46
    RULE_molecules_statement = 47
    RULE_molecules = 48
    RULE_number = 49
    RULE_position_restraints = 50
    RULE_position_restraint = 51

    ruleNames =  [ "gromacs_pt", "default_statement", "moleculetype_statement", 
                   "moleculetype", "atomtypes_statement", "atomtypes", "pairtypes_statement", 
                   "pairtypes", "bondtypes_statement", "bondtypes", "angletypes_statement", 
                   "angletypes", "dihedraltypes_statement", "dihedraltypes", 
                   "constrainttypes_statement", "constrainttypes", "nonbonded_params_statement", 
                   "nonbonded_params", "atoms_statement", "atoms", "bonds_statement", 
                   "bonds", "pairs_statement", "pairs", "pairs_nb_statement", 
                   "pairs_nb", "angles_statement", "angles", "dihedrals_statement", 
                   "dihedrals", "exclusions_statement", "exclusions", "constraints_statement", 
                   "constraints", "settles_statement", "settles", "virtual_sites1_statement", 
                   "virtual_sites1", "virtual_sites2_statement", "virtual_sites2", 
                   "virtual_sites3_statement", "virtual_sites3", "virtual_sites4_statement", 
                   "virtual_sites4", "virtual_sitesn_statement", "virtual_sitesn", 
                   "system_statement", "molecules_statement", "molecules", 
                   "number", "position_restraints", "position_restraint" ]

    EOF = Token.EOF
    L_brkt=1
    R_brkt=2
    Default=3
    Moleculetype=4
    Atomtypes=5
    Pairtypes=6
    Bondtypes=7
    Angletypes=8
    Dihedraltypes=9
    Constrainttypes=10
    Nonbond_params=11
    Atoms=12
    Bonds=13
    Pairs=14
    Pairs_nb=15
    Angles=16
    Dihedrals=17
    Exclusions=18
    Constraints=19
    Settles=20
    Virtual_sites1=21
    Virtual_sites2=22
    Virtual_sites3=23
    Virtual_sites4=24
    Virtual_sitesn=25
    System=26
    Molecules=27
    Position_restraints=28
    Intermolecular_interactions=29
    Integer=30
    Real=31
    SHARP_COMMENT=32
    EXCLM_COMMENT=33
    SMCLN_COMMENT=34
    Simple_name=35
    SPACE=36
    ENCLOSE_COMMENT=37
    SECTION_COMMENT=38
    LINE_COMMENT=39
    R_brkt_AA=40
    SECTION_COMMENT_AA=41
    LINE_COMMENT_AA=42
    Simple_name_AA=43
    SPACE_AA=44
    RETURN_AA=45

    def __init__(self, input:TokenStream, output:TextIO = sys.stdout):
        super().__init__(input, output)
        self.checkVersion("4.13.0")
        self._interp = ParserATNSimulator(self, self.atn, self.decisionsToDFA, self.sharedContextCache)
        self._predicates = None




    class Gromacs_ptContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def EOF(self):
            return self.getToken(GromacsPTParser.EOF, 0)

        def default_statement(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(GromacsPTParser.Default_statementContext)
            else:
                return self.getTypedRuleContext(GromacsPTParser.Default_statementContext,i)


        def moleculetype_statement(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(GromacsPTParser.Moleculetype_statementContext)
            else:
                return self.getTypedRuleContext(GromacsPTParser.Moleculetype_statementContext,i)


        def atomtypes_statement(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(GromacsPTParser.Atomtypes_statementContext)
            else:
                return self.getTypedRuleContext(GromacsPTParser.Atomtypes_statementContext,i)


        def pairtypes_statement(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(GromacsPTParser.Pairtypes_statementContext)
            else:
                return self.getTypedRuleContext(GromacsPTParser.Pairtypes_statementContext,i)


        def bondtypes_statement(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(GromacsPTParser.Bondtypes_statementContext)
            else:
                return self.getTypedRuleContext(GromacsPTParser.Bondtypes_statementContext,i)


        def angletypes_statement(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(GromacsPTParser.Angletypes_statementContext)
            else:
                return self.getTypedRuleContext(GromacsPTParser.Angletypes_statementContext,i)


        def dihedraltypes_statement(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(GromacsPTParser.Dihedraltypes_statementContext)
            else:
                return self.getTypedRuleContext(GromacsPTParser.Dihedraltypes_statementContext,i)


        def constrainttypes_statement(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(GromacsPTParser.Constrainttypes_statementContext)
            else:
                return self.getTypedRuleContext(GromacsPTParser.Constrainttypes_statementContext,i)


        def nonbonded_params_statement(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(GromacsPTParser.Nonbonded_params_statementContext)
            else:
                return self.getTypedRuleContext(GromacsPTParser.Nonbonded_params_statementContext,i)


        def atoms_statement(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(GromacsPTParser.Atoms_statementContext)
            else:
                return self.getTypedRuleContext(GromacsPTParser.Atoms_statementContext,i)


        def bonds_statement(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(GromacsPTParser.Bonds_statementContext)
            else:
                return self.getTypedRuleContext(GromacsPTParser.Bonds_statementContext,i)


        def pairs_statement(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(GromacsPTParser.Pairs_statementContext)
            else:
                return self.getTypedRuleContext(GromacsPTParser.Pairs_statementContext,i)


        def pairs_nb_statement(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(GromacsPTParser.Pairs_nb_statementContext)
            else:
                return self.getTypedRuleContext(GromacsPTParser.Pairs_nb_statementContext,i)


        def angles_statement(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(GromacsPTParser.Angles_statementContext)
            else:
                return self.getTypedRuleContext(GromacsPTParser.Angles_statementContext,i)


        def dihedrals_statement(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(GromacsPTParser.Dihedrals_statementContext)
            else:
                return self.getTypedRuleContext(GromacsPTParser.Dihedrals_statementContext,i)


        def exclusions_statement(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(GromacsPTParser.Exclusions_statementContext)
            else:
                return self.getTypedRuleContext(GromacsPTParser.Exclusions_statementContext,i)


        def constraints_statement(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(GromacsPTParser.Constraints_statementContext)
            else:
                return self.getTypedRuleContext(GromacsPTParser.Constraints_statementContext,i)


        def settles_statement(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(GromacsPTParser.Settles_statementContext)
            else:
                return self.getTypedRuleContext(GromacsPTParser.Settles_statementContext,i)


        def virtual_sites1_statement(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(GromacsPTParser.Virtual_sites1_statementContext)
            else:
                return self.getTypedRuleContext(GromacsPTParser.Virtual_sites1_statementContext,i)


        def virtual_sites2_statement(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(GromacsPTParser.Virtual_sites2_statementContext)
            else:
                return self.getTypedRuleContext(GromacsPTParser.Virtual_sites2_statementContext,i)


        def virtual_sites3_statement(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(GromacsPTParser.Virtual_sites3_statementContext)
            else:
                return self.getTypedRuleContext(GromacsPTParser.Virtual_sites3_statementContext,i)


        def virtual_sites4_statement(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(GromacsPTParser.Virtual_sites4_statementContext)
            else:
                return self.getTypedRuleContext(GromacsPTParser.Virtual_sites4_statementContext,i)


        def virtual_sitesn_statement(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(GromacsPTParser.Virtual_sitesn_statementContext)
            else:
                return self.getTypedRuleContext(GromacsPTParser.Virtual_sitesn_statementContext,i)


        def system_statement(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(GromacsPTParser.System_statementContext)
            else:
                return self.getTypedRuleContext(GromacsPTParser.System_statementContext,i)


        def molecules_statement(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(GromacsPTParser.Molecules_statementContext)
            else:
                return self.getTypedRuleContext(GromacsPTParser.Molecules_statementContext,i)


        def position_restraints(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(GromacsPTParser.Position_restraintsContext)
            else:
                return self.getTypedRuleContext(GromacsPTParser.Position_restraintsContext,i)


        def L_brkt(self, i:int=None):
            if i is None:
                return self.getTokens(GromacsPTParser.L_brkt)
            else:
                return self.getToken(GromacsPTParser.L_brkt, i)

        def Intermolecular_interactions(self, i:int=None):
            if i is None:
                return self.getTokens(GromacsPTParser.Intermolecular_interactions)
            else:
                return self.getToken(GromacsPTParser.Intermolecular_interactions, i)

        def R_brkt(self, i:int=None):
            if i is None:
                return self.getTokens(GromacsPTParser.R_brkt)
            else:
                return self.getToken(GromacsPTParser.R_brkt, i)

        def getRuleIndex(self):
            return GromacsPTParser.RULE_gromacs_pt

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterGromacs_pt" ):
                listener.enterGromacs_pt(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitGromacs_pt" ):
                listener.exitGromacs_pt(self)




    def gromacs_pt(self):

        localctx = GromacsPTParser.Gromacs_ptContext(self, self._ctx, self.state)
        self.enterRule(localctx, 0, self.RULE_gromacs_pt)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 135
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==1:
                self.state = 133
                self._errHandler.sync(self)
                la_ = self._interp.adaptivePredict(self._input,0,self._ctx)
                if la_ == 1:
                    self.state = 104
                    self.default_statement()
                    pass

                elif la_ == 2:
                    self.state = 105
                    self.moleculetype_statement()
                    pass

                elif la_ == 3:
                    self.state = 106
                    self.atomtypes_statement()
                    pass

                elif la_ == 4:
                    self.state = 107
                    self.pairtypes_statement()
                    pass

                elif la_ == 5:
                    self.state = 108
                    self.bondtypes_statement()
                    pass

                elif la_ == 6:
                    self.state = 109
                    self.angletypes_statement()
                    pass

                elif la_ == 7:
                    self.state = 110
                    self.dihedraltypes_statement()
                    pass

                elif la_ == 8:
                    self.state = 111
                    self.constrainttypes_statement()
                    pass

                elif la_ == 9:
                    self.state = 112
                    self.nonbonded_params_statement()
                    pass

                elif la_ == 10:
                    self.state = 113
                    self.atoms_statement()
                    pass

                elif la_ == 11:
                    self.state = 114
                    self.bonds_statement()
                    pass

                elif la_ == 12:
                    self.state = 115
                    self.pairs_statement()
                    pass

                elif la_ == 13:
                    self.state = 116
                    self.pairs_nb_statement()
                    pass

                elif la_ == 14:
                    self.state = 117
                    self.angles_statement()
                    pass

                elif la_ == 15:
                    self.state = 118
                    self.dihedrals_statement()
                    pass

                elif la_ == 16:
                    self.state = 119
                    self.exclusions_statement()
                    pass

                elif la_ == 17:
                    self.state = 120
                    self.constraints_statement()
                    pass

                elif la_ == 18:
                    self.state = 121
                    self.settles_statement()
                    pass

                elif la_ == 19:
                    self.state = 122
                    self.virtual_sites1_statement()
                    pass

                elif la_ == 20:
                    self.state = 123
                    self.virtual_sites2_statement()
                    pass

                elif la_ == 21:
                    self.state = 124
                    self.virtual_sites3_statement()
                    pass

                elif la_ == 22:
                    self.state = 125
                    self.virtual_sites4_statement()
                    pass

                elif la_ == 23:
                    self.state = 126
                    self.virtual_sitesn_statement()
                    pass

                elif la_ == 24:
                    self.state = 127
                    self.system_statement()
                    pass

                elif la_ == 25:
                    self.state = 128
                    self.molecules_statement()
                    pass

                elif la_ == 26:
                    self.state = 129
                    self.position_restraints()
                    pass

                elif la_ == 27:
                    self.state = 130
                    self.match(GromacsPTParser.L_brkt)
                    self.state = 131
                    self.match(GromacsPTParser.Intermolecular_interactions)
                    self.state = 132
                    self.match(GromacsPTParser.R_brkt)
                    pass


                self.state = 137
                self._errHandler.sync(self)
                _la = self._input.LA(1)

            self.state = 138
            self.match(GromacsPTParser.EOF)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Default_statementContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def L_brkt(self):
            return self.getToken(GromacsPTParser.L_brkt, 0)

        def Default(self):
            return self.getToken(GromacsPTParser.Default, 0)

        def R_brkt(self):
            return self.getToken(GromacsPTParser.R_brkt, 0)

        def Integer(self, i:int=None):
            if i is None:
                return self.getTokens(GromacsPTParser.Integer)
            else:
                return self.getToken(GromacsPTParser.Integer, i)

        def Simple_name(self, i:int=None):
            if i is None:
                return self.getTokens(GromacsPTParser.Simple_name)
            else:
                return self.getToken(GromacsPTParser.Simple_name, i)

        def Real(self, i:int=None):
            if i is None:
                return self.getTokens(GromacsPTParser.Real)
            else:
                return self.getToken(GromacsPTParser.Real, i)

        def getRuleIndex(self):
            return GromacsPTParser.RULE_default_statement

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterDefault_statement" ):
                listener.enterDefault_statement(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitDefault_statement" ):
                listener.exitDefault_statement(self)




    def default_statement(self):

        localctx = GromacsPTParser.Default_statementContext(self, self._ctx, self.state)
        self.enterRule(localctx, 2, self.RULE_default_statement)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 140
            self.match(GromacsPTParser.L_brkt)
            self.state = 141
            self.match(GromacsPTParser.Default)
            self.state = 142
            self.match(GromacsPTParser.R_brkt)
            self.state = 143
            self.match(GromacsPTParser.Integer)
            self.state = 144
            self.match(GromacsPTParser.Integer)
            self.state = 145
            self.match(GromacsPTParser.Simple_name)
            self.state = 146
            self.match(GromacsPTParser.Real)
            self.state = 147
            self.match(GromacsPTParser.Real)
            self.state = 149
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==35:
                self.state = 148
                self.match(GromacsPTParser.Simple_name)


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Moleculetype_statementContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def L_brkt(self):
            return self.getToken(GromacsPTParser.L_brkt, 0)

        def Moleculetype(self):
            return self.getToken(GromacsPTParser.Moleculetype, 0)

        def R_brkt(self):
            return self.getToken(GromacsPTParser.R_brkt, 0)

        def moleculetype(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(GromacsPTParser.MoleculetypeContext)
            else:
                return self.getTypedRuleContext(GromacsPTParser.MoleculetypeContext,i)


        def getRuleIndex(self):
            return GromacsPTParser.RULE_moleculetype_statement

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterMoleculetype_statement" ):
                listener.enterMoleculetype_statement(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitMoleculetype_statement" ):
                listener.exitMoleculetype_statement(self)




    def moleculetype_statement(self):

        localctx = GromacsPTParser.Moleculetype_statementContext(self, self._ctx, self.state)
        self.enterRule(localctx, 4, self.RULE_moleculetype_statement)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 151
            self.match(GromacsPTParser.L_brkt)
            self.state = 152
            self.match(GromacsPTParser.Moleculetype)
            self.state = 153
            self.match(GromacsPTParser.R_brkt)
            self.state = 155 
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while True:
                self.state = 154
                self.moleculetype()
                self.state = 157 
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if not (_la==35):
                    break

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class MoleculetypeContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def Simple_name(self):
            return self.getToken(GromacsPTParser.Simple_name, 0)

        def Integer(self):
            return self.getToken(GromacsPTParser.Integer, 0)

        def getRuleIndex(self):
            return GromacsPTParser.RULE_moleculetype

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterMoleculetype" ):
                listener.enterMoleculetype(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitMoleculetype" ):
                listener.exitMoleculetype(self)




    def moleculetype(self):

        localctx = GromacsPTParser.MoleculetypeContext(self, self._ctx, self.state)
        self.enterRule(localctx, 6, self.RULE_moleculetype)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 159
            self.match(GromacsPTParser.Simple_name)
            self.state = 160
            self.match(GromacsPTParser.Integer)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Atomtypes_statementContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def L_brkt(self):
            return self.getToken(GromacsPTParser.L_brkt, 0)

        def Atomtypes(self):
            return self.getToken(GromacsPTParser.Atomtypes, 0)

        def R_brkt(self):
            return self.getToken(GromacsPTParser.R_brkt, 0)

        def atomtypes(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(GromacsPTParser.AtomtypesContext)
            else:
                return self.getTypedRuleContext(GromacsPTParser.AtomtypesContext,i)


        def getRuleIndex(self):
            return GromacsPTParser.RULE_atomtypes_statement

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterAtomtypes_statement" ):
                listener.enterAtomtypes_statement(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitAtomtypes_statement" ):
                listener.exitAtomtypes_statement(self)




    def atomtypes_statement(self):

        localctx = GromacsPTParser.Atomtypes_statementContext(self, self._ctx, self.state)
        self.enterRule(localctx, 8, self.RULE_atomtypes_statement)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 162
            self.match(GromacsPTParser.L_brkt)
            self.state = 163
            self.match(GromacsPTParser.Atomtypes)
            self.state = 164
            self.match(GromacsPTParser.R_brkt)
            self.state = 168
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==35:
                self.state = 165
                self.atomtypes()
                self.state = 170
                self._errHandler.sync(self)
                _la = self._input.LA(1)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class AtomtypesContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def Simple_name(self):
            return self.getToken(GromacsPTParser.Simple_name, 0)

        def Integer(self, i:int=None):
            if i is None:
                return self.getTokens(GromacsPTParser.Integer)
            else:
                return self.getToken(GromacsPTParser.Integer, i)

        def Real(self, i:int=None):
            if i is None:
                return self.getTokens(GromacsPTParser.Real)
            else:
                return self.getToken(GromacsPTParser.Real, i)

        def getRuleIndex(self):
            return GromacsPTParser.RULE_atomtypes

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterAtomtypes" ):
                listener.enterAtomtypes(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitAtomtypes" ):
                listener.exitAtomtypes(self)




    def atomtypes(self):

        localctx = GromacsPTParser.AtomtypesContext(self, self._ctx, self.state)
        self.enterRule(localctx, 10, self.RULE_atomtypes)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 171
            self.match(GromacsPTParser.Simple_name)
            self.state = 172
            self.match(GromacsPTParser.Integer)
            self.state = 173
            self.match(GromacsPTParser.Real)
            self.state = 174
            self.match(GromacsPTParser.Real)
            self.state = 175
            self.match(GromacsPTParser.Integer)
            self.state = 176
            self.match(GromacsPTParser.Real)
            self.state = 177
            self.match(GromacsPTParser.Real)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Pairtypes_statementContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def L_brkt(self):
            return self.getToken(GromacsPTParser.L_brkt, 0)

        def Pairtypes(self):
            return self.getToken(GromacsPTParser.Pairtypes, 0)

        def R_brkt(self):
            return self.getToken(GromacsPTParser.R_brkt, 0)

        def pairtypes(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(GromacsPTParser.PairtypesContext)
            else:
                return self.getTypedRuleContext(GromacsPTParser.PairtypesContext,i)


        def getRuleIndex(self):
            return GromacsPTParser.RULE_pairtypes_statement

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterPairtypes_statement" ):
                listener.enterPairtypes_statement(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitPairtypes_statement" ):
                listener.exitPairtypes_statement(self)




    def pairtypes_statement(self):

        localctx = GromacsPTParser.Pairtypes_statementContext(self, self._ctx, self.state)
        self.enterRule(localctx, 12, self.RULE_pairtypes_statement)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 179
            self.match(GromacsPTParser.L_brkt)
            self.state = 180
            self.match(GromacsPTParser.Pairtypes)
            self.state = 181
            self.match(GromacsPTParser.R_brkt)
            self.state = 185
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==35:
                self.state = 182
                self.pairtypes()
                self.state = 187
                self._errHandler.sync(self)
                _la = self._input.LA(1)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class PairtypesContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def Simple_name(self, i:int=None):
            if i is None:
                return self.getTokens(GromacsPTParser.Simple_name)
            else:
                return self.getToken(GromacsPTParser.Simple_name, i)

        def Integer(self):
            return self.getToken(GromacsPTParser.Integer, 0)

        def Real(self, i:int=None):
            if i is None:
                return self.getTokens(GromacsPTParser.Real)
            else:
                return self.getToken(GromacsPTParser.Real, i)

        def getRuleIndex(self):
            return GromacsPTParser.RULE_pairtypes

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterPairtypes" ):
                listener.enterPairtypes(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitPairtypes" ):
                listener.exitPairtypes(self)




    def pairtypes(self):

        localctx = GromacsPTParser.PairtypesContext(self, self._ctx, self.state)
        self.enterRule(localctx, 14, self.RULE_pairtypes)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 188
            self.match(GromacsPTParser.Simple_name)
            self.state = 189
            self.match(GromacsPTParser.Simple_name)
            self.state = 190
            self.match(GromacsPTParser.Integer)
            self.state = 191
            self.match(GromacsPTParser.Real)
            self.state = 192
            self.match(GromacsPTParser.Real)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Bondtypes_statementContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def L_brkt(self):
            return self.getToken(GromacsPTParser.L_brkt, 0)

        def Bondtypes(self):
            return self.getToken(GromacsPTParser.Bondtypes, 0)

        def R_brkt(self):
            return self.getToken(GromacsPTParser.R_brkt, 0)

        def bondtypes(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(GromacsPTParser.BondtypesContext)
            else:
                return self.getTypedRuleContext(GromacsPTParser.BondtypesContext,i)


        def getRuleIndex(self):
            return GromacsPTParser.RULE_bondtypes_statement

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterBondtypes_statement" ):
                listener.enterBondtypes_statement(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitBondtypes_statement" ):
                listener.exitBondtypes_statement(self)




    def bondtypes_statement(self):

        localctx = GromacsPTParser.Bondtypes_statementContext(self, self._ctx, self.state)
        self.enterRule(localctx, 16, self.RULE_bondtypes_statement)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 194
            self.match(GromacsPTParser.L_brkt)
            self.state = 195
            self.match(GromacsPTParser.Bondtypes)
            self.state = 196
            self.match(GromacsPTParser.R_brkt)
            self.state = 200
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==35:
                self.state = 197
                self.bondtypes()
                self.state = 202
                self._errHandler.sync(self)
                _la = self._input.LA(1)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class BondtypesContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def Simple_name(self, i:int=None):
            if i is None:
                return self.getTokens(GromacsPTParser.Simple_name)
            else:
                return self.getToken(GromacsPTParser.Simple_name, i)

        def Integer(self):
            return self.getToken(GromacsPTParser.Integer, 0)

        def Real(self, i:int=None):
            if i is None:
                return self.getTokens(GromacsPTParser.Real)
            else:
                return self.getToken(GromacsPTParser.Real, i)

        def getRuleIndex(self):
            return GromacsPTParser.RULE_bondtypes

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterBondtypes" ):
                listener.enterBondtypes(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitBondtypes" ):
                listener.exitBondtypes(self)




    def bondtypes(self):

        localctx = GromacsPTParser.BondtypesContext(self, self._ctx, self.state)
        self.enterRule(localctx, 18, self.RULE_bondtypes)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 203
            self.match(GromacsPTParser.Simple_name)
            self.state = 204
            self.match(GromacsPTParser.Simple_name)
            self.state = 205
            self.match(GromacsPTParser.Integer)
            self.state = 206
            self.match(GromacsPTParser.Real)
            self.state = 207
            self.match(GromacsPTParser.Real)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Angletypes_statementContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def L_brkt(self):
            return self.getToken(GromacsPTParser.L_brkt, 0)

        def Angletypes(self):
            return self.getToken(GromacsPTParser.Angletypes, 0)

        def R_brkt(self):
            return self.getToken(GromacsPTParser.R_brkt, 0)

        def angletypes(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(GromacsPTParser.AngletypesContext)
            else:
                return self.getTypedRuleContext(GromacsPTParser.AngletypesContext,i)


        def getRuleIndex(self):
            return GromacsPTParser.RULE_angletypes_statement

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterAngletypes_statement" ):
                listener.enterAngletypes_statement(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitAngletypes_statement" ):
                listener.exitAngletypes_statement(self)




    def angletypes_statement(self):

        localctx = GromacsPTParser.Angletypes_statementContext(self, self._ctx, self.state)
        self.enterRule(localctx, 20, self.RULE_angletypes_statement)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 209
            self.match(GromacsPTParser.L_brkt)
            self.state = 210
            self.match(GromacsPTParser.Angletypes)
            self.state = 211
            self.match(GromacsPTParser.R_brkt)
            self.state = 215
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==35:
                self.state = 212
                self.angletypes()
                self.state = 217
                self._errHandler.sync(self)
                _la = self._input.LA(1)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class AngletypesContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def Simple_name(self, i:int=None):
            if i is None:
                return self.getTokens(GromacsPTParser.Simple_name)
            else:
                return self.getToken(GromacsPTParser.Simple_name, i)

        def Integer(self):
            return self.getToken(GromacsPTParser.Integer, 0)

        def Real(self, i:int=None):
            if i is None:
                return self.getTokens(GromacsPTParser.Real)
            else:
                return self.getToken(GromacsPTParser.Real, i)

        def getRuleIndex(self):
            return GromacsPTParser.RULE_angletypes

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterAngletypes" ):
                listener.enterAngletypes(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitAngletypes" ):
                listener.exitAngletypes(self)




    def angletypes(self):

        localctx = GromacsPTParser.AngletypesContext(self, self._ctx, self.state)
        self.enterRule(localctx, 22, self.RULE_angletypes)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 218
            self.match(GromacsPTParser.Simple_name)
            self.state = 219
            self.match(GromacsPTParser.Simple_name)
            self.state = 220
            self.match(GromacsPTParser.Simple_name)
            self.state = 221
            self.match(GromacsPTParser.Integer)
            self.state = 222
            self.match(GromacsPTParser.Real)
            self.state = 223
            self.match(GromacsPTParser.Real)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Dihedraltypes_statementContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def L_brkt(self):
            return self.getToken(GromacsPTParser.L_brkt, 0)

        def Dihedraltypes(self):
            return self.getToken(GromacsPTParser.Dihedraltypes, 0)

        def R_brkt(self):
            return self.getToken(GromacsPTParser.R_brkt, 0)

        def dihedraltypes(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(GromacsPTParser.DihedraltypesContext)
            else:
                return self.getTypedRuleContext(GromacsPTParser.DihedraltypesContext,i)


        def getRuleIndex(self):
            return GromacsPTParser.RULE_dihedraltypes_statement

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterDihedraltypes_statement" ):
                listener.enterDihedraltypes_statement(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitDihedraltypes_statement" ):
                listener.exitDihedraltypes_statement(self)




    def dihedraltypes_statement(self):

        localctx = GromacsPTParser.Dihedraltypes_statementContext(self, self._ctx, self.state)
        self.enterRule(localctx, 24, self.RULE_dihedraltypes_statement)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 225
            self.match(GromacsPTParser.L_brkt)
            self.state = 226
            self.match(GromacsPTParser.Dihedraltypes)
            self.state = 227
            self.match(GromacsPTParser.R_brkt)
            self.state = 231
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==35:
                self.state = 228
                self.dihedraltypes()
                self.state = 233
                self._errHandler.sync(self)
                _la = self._input.LA(1)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class DihedraltypesContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def Simple_name(self, i:int=None):
            if i is None:
                return self.getTokens(GromacsPTParser.Simple_name)
            else:
                return self.getToken(GromacsPTParser.Simple_name, i)

        def Integer(self, i:int=None):
            if i is None:
                return self.getTokens(GromacsPTParser.Integer)
            else:
                return self.getToken(GromacsPTParser.Integer, i)

        def Real(self, i:int=None):
            if i is None:
                return self.getTokens(GromacsPTParser.Real)
            else:
                return self.getToken(GromacsPTParser.Real, i)

        def getRuleIndex(self):
            return GromacsPTParser.RULE_dihedraltypes

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterDihedraltypes" ):
                listener.enterDihedraltypes(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitDihedraltypes" ):
                listener.exitDihedraltypes(self)




    def dihedraltypes(self):

        localctx = GromacsPTParser.DihedraltypesContext(self, self._ctx, self.state)
        self.enterRule(localctx, 26, self.RULE_dihedraltypes)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 234
            self.match(GromacsPTParser.Simple_name)
            self.state = 235
            self.match(GromacsPTParser.Simple_name)
            self.state = 236
            self.match(GromacsPTParser.Integer)
            self.state = 237
            self.match(GromacsPTParser.Real)
            self.state = 238
            self.match(GromacsPTParser.Real)
            self.state = 244
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [30]:
                self.state = 239
                self.match(GromacsPTParser.Integer)
                pass
            elif token in [31]:
                self.state = 240
                self.match(GromacsPTParser.Real)
                self.state = 241
                self.match(GromacsPTParser.Real)
                self.state = 242
                self.match(GromacsPTParser.Real)
                self.state = 243
                self.match(GromacsPTParser.Real)
                pass
            else:
                raise NoViableAltException(self)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Constrainttypes_statementContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def L_brkt(self):
            return self.getToken(GromacsPTParser.L_brkt, 0)

        def Constrainttypes(self):
            return self.getToken(GromacsPTParser.Constrainttypes, 0)

        def R_brkt(self):
            return self.getToken(GromacsPTParser.R_brkt, 0)

        def constrainttypes(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(GromacsPTParser.ConstrainttypesContext)
            else:
                return self.getTypedRuleContext(GromacsPTParser.ConstrainttypesContext,i)


        def getRuleIndex(self):
            return GromacsPTParser.RULE_constrainttypes_statement

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterConstrainttypes_statement" ):
                listener.enterConstrainttypes_statement(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitConstrainttypes_statement" ):
                listener.exitConstrainttypes_statement(self)




    def constrainttypes_statement(self):

        localctx = GromacsPTParser.Constrainttypes_statementContext(self, self._ctx, self.state)
        self.enterRule(localctx, 28, self.RULE_constrainttypes_statement)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 246
            self.match(GromacsPTParser.L_brkt)
            self.state = 247
            self.match(GromacsPTParser.Constrainttypes)
            self.state = 248
            self.match(GromacsPTParser.R_brkt)
            self.state = 252
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==35:
                self.state = 249
                self.constrainttypes()
                self.state = 254
                self._errHandler.sync(self)
                _la = self._input.LA(1)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ConstrainttypesContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def Simple_name(self, i:int=None):
            if i is None:
                return self.getTokens(GromacsPTParser.Simple_name)
            else:
                return self.getToken(GromacsPTParser.Simple_name, i)

        def Integer(self):
            return self.getToken(GromacsPTParser.Integer, 0)

        def Real(self, i:int=None):
            if i is None:
                return self.getTokens(GromacsPTParser.Real)
            else:
                return self.getToken(GromacsPTParser.Real, i)

        def getRuleIndex(self):
            return GromacsPTParser.RULE_constrainttypes

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterConstrainttypes" ):
                listener.enterConstrainttypes(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitConstrainttypes" ):
                listener.exitConstrainttypes(self)




    def constrainttypes(self):

        localctx = GromacsPTParser.ConstrainttypesContext(self, self._ctx, self.state)
        self.enterRule(localctx, 30, self.RULE_constrainttypes)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 255
            self.match(GromacsPTParser.Simple_name)
            self.state = 256
            self.match(GromacsPTParser.Simple_name)
            self.state = 257
            self.match(GromacsPTParser.Integer)
            self.state = 258
            self.match(GromacsPTParser.Real)
            self.state = 259
            self.match(GromacsPTParser.Real)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Nonbonded_params_statementContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def L_brkt(self):
            return self.getToken(GromacsPTParser.L_brkt, 0)

        def Nonbond_params(self):
            return self.getToken(GromacsPTParser.Nonbond_params, 0)

        def R_brkt(self):
            return self.getToken(GromacsPTParser.R_brkt, 0)

        def nonbonded_params(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(GromacsPTParser.Nonbonded_paramsContext)
            else:
                return self.getTypedRuleContext(GromacsPTParser.Nonbonded_paramsContext,i)


        def getRuleIndex(self):
            return GromacsPTParser.RULE_nonbonded_params_statement

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterNonbonded_params_statement" ):
                listener.enterNonbonded_params_statement(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitNonbonded_params_statement" ):
                listener.exitNonbonded_params_statement(self)




    def nonbonded_params_statement(self):

        localctx = GromacsPTParser.Nonbonded_params_statementContext(self, self._ctx, self.state)
        self.enterRule(localctx, 32, self.RULE_nonbonded_params_statement)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 261
            self.match(GromacsPTParser.L_brkt)
            self.state = 262
            self.match(GromacsPTParser.Nonbond_params)
            self.state = 263
            self.match(GromacsPTParser.R_brkt)
            self.state = 267
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==35:
                self.state = 264
                self.nonbonded_params()
                self.state = 269
                self._errHandler.sync(self)
                _la = self._input.LA(1)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Nonbonded_paramsContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def Simple_name(self, i:int=None):
            if i is None:
                return self.getTokens(GromacsPTParser.Simple_name)
            else:
                return self.getToken(GromacsPTParser.Simple_name, i)

        def Integer(self):
            return self.getToken(GromacsPTParser.Integer, 0)

        def Real(self, i:int=None):
            if i is None:
                return self.getTokens(GromacsPTParser.Real)
            else:
                return self.getToken(GromacsPTParser.Real, i)

        def getRuleIndex(self):
            return GromacsPTParser.RULE_nonbonded_params

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterNonbonded_params" ):
                listener.enterNonbonded_params(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitNonbonded_params" ):
                listener.exitNonbonded_params(self)




    def nonbonded_params(self):

        localctx = GromacsPTParser.Nonbonded_paramsContext(self, self._ctx, self.state)
        self.enterRule(localctx, 34, self.RULE_nonbonded_params)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 270
            self.match(GromacsPTParser.Simple_name)
            self.state = 271
            self.match(GromacsPTParser.Simple_name)
            self.state = 272
            self.match(GromacsPTParser.Integer)
            self.state = 273
            self.match(GromacsPTParser.Real)
            self.state = 274
            self.match(GromacsPTParser.Real)
            self.state = 276
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==31:
                self.state = 275
                self.match(GromacsPTParser.Real)


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Atoms_statementContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def L_brkt(self):
            return self.getToken(GromacsPTParser.L_brkt, 0)

        def Atoms(self):
            return self.getToken(GromacsPTParser.Atoms, 0)

        def R_brkt(self):
            return self.getToken(GromacsPTParser.R_brkt, 0)

        def atoms(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(GromacsPTParser.AtomsContext)
            else:
                return self.getTypedRuleContext(GromacsPTParser.AtomsContext,i)


        def getRuleIndex(self):
            return GromacsPTParser.RULE_atoms_statement

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterAtoms_statement" ):
                listener.enterAtoms_statement(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitAtoms_statement" ):
                listener.exitAtoms_statement(self)




    def atoms_statement(self):

        localctx = GromacsPTParser.Atoms_statementContext(self, self._ctx, self.state)
        self.enterRule(localctx, 36, self.RULE_atoms_statement)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 278
            self.match(GromacsPTParser.L_brkt)
            self.state = 279
            self.match(GromacsPTParser.Atoms)
            self.state = 280
            self.match(GromacsPTParser.R_brkt)
            self.state = 282 
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while True:
                self.state = 281
                self.atoms()
                self.state = 284 
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if not (_la==30):
                    break

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class AtomsContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def Integer(self, i:int=None):
            if i is None:
                return self.getTokens(GromacsPTParser.Integer)
            else:
                return self.getToken(GromacsPTParser.Integer, i)

        def Simple_name(self, i:int=None):
            if i is None:
                return self.getTokens(GromacsPTParser.Simple_name)
            else:
                return self.getToken(GromacsPTParser.Simple_name, i)

        def number(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(GromacsPTParser.NumberContext)
            else:
                return self.getTypedRuleContext(GromacsPTParser.NumberContext,i)


        def getRuleIndex(self):
            return GromacsPTParser.RULE_atoms

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterAtoms" ):
                listener.enterAtoms(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitAtoms" ):
                listener.exitAtoms(self)




    def atoms(self):

        localctx = GromacsPTParser.AtomsContext(self, self._ctx, self.state)
        self.enterRule(localctx, 38, self.RULE_atoms)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 286
            self.match(GromacsPTParser.Integer)
            self.state = 287
            self.match(GromacsPTParser.Simple_name)
            self.state = 288
            self.match(GromacsPTParser.Integer)
            self.state = 289
            self.match(GromacsPTParser.Simple_name)
            self.state = 290
            self.match(GromacsPTParser.Simple_name)
            self.state = 291
            self.match(GromacsPTParser.Integer)
            self.state = 292
            self.number()
            self.state = 300
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,15,self._ctx)
            if la_ == 1:
                self.state = 293
                self.number()
                self.state = 298
                self._errHandler.sync(self)
                la_ = self._interp.adaptivePredict(self._input,14,self._ctx)
                if la_ == 1:
                    self.state = 294
                    self.match(GromacsPTParser.Simple_name)
                    self.state = 295
                    self.number()
                    self.state = 296
                    self.number()




            self.state = 303
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==35:
                self.state = 302
                self.match(GromacsPTParser.Simple_name)


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Bonds_statementContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def L_brkt(self):
            return self.getToken(GromacsPTParser.L_brkt, 0)

        def Bonds(self):
            return self.getToken(GromacsPTParser.Bonds, 0)

        def R_brkt(self):
            return self.getToken(GromacsPTParser.R_brkt, 0)

        def bonds(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(GromacsPTParser.BondsContext)
            else:
                return self.getTypedRuleContext(GromacsPTParser.BondsContext,i)


        def getRuleIndex(self):
            return GromacsPTParser.RULE_bonds_statement

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterBonds_statement" ):
                listener.enterBonds_statement(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitBonds_statement" ):
                listener.exitBonds_statement(self)




    def bonds_statement(self):

        localctx = GromacsPTParser.Bonds_statementContext(self, self._ctx, self.state)
        self.enterRule(localctx, 40, self.RULE_bonds_statement)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 305
            self.match(GromacsPTParser.L_brkt)
            self.state = 306
            self.match(GromacsPTParser.Bonds)
            self.state = 307
            self.match(GromacsPTParser.R_brkt)
            self.state = 311
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==30:
                self.state = 308
                self.bonds()
                self.state = 313
                self._errHandler.sync(self)
                _la = self._input.LA(1)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class BondsContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def Integer(self, i:int=None):
            if i is None:
                return self.getTokens(GromacsPTParser.Integer)
            else:
                return self.getToken(GromacsPTParser.Integer, i)

        def number(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(GromacsPTParser.NumberContext)
            else:
                return self.getTypedRuleContext(GromacsPTParser.NumberContext,i)


        def Simple_name(self):
            return self.getToken(GromacsPTParser.Simple_name, 0)

        def getRuleIndex(self):
            return GromacsPTParser.RULE_bonds

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterBonds" ):
                listener.enterBonds(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitBonds" ):
                listener.exitBonds(self)




    def bonds(self):

        localctx = GromacsPTParser.BondsContext(self, self._ctx, self.state)
        self.enterRule(localctx, 42, self.RULE_bonds)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 314
            self.match(GromacsPTParser.Integer)
            self.state = 315
            self.match(GromacsPTParser.Integer)
            self.state = 316
            self.match(GromacsPTParser.Integer)
            self.state = 322
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,19,self._ctx)
            if la_ == 1:
                self.state = 317
                self.number()
                self.state = 318
                self.number()
                self.state = 320
                self._errHandler.sync(self)
                la_ = self._interp.adaptivePredict(self._input,18,self._ctx)
                if la_ == 1:
                    self.state = 319
                    self.number()




            self.state = 325
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==35:
                self.state = 324
                self.match(GromacsPTParser.Simple_name)


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Pairs_statementContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def L_brkt(self):
            return self.getToken(GromacsPTParser.L_brkt, 0)

        def Pairs(self):
            return self.getToken(GromacsPTParser.Pairs, 0)

        def R_brkt(self):
            return self.getToken(GromacsPTParser.R_brkt, 0)

        def pairs(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(GromacsPTParser.PairsContext)
            else:
                return self.getTypedRuleContext(GromacsPTParser.PairsContext,i)


        def getRuleIndex(self):
            return GromacsPTParser.RULE_pairs_statement

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterPairs_statement" ):
                listener.enterPairs_statement(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitPairs_statement" ):
                listener.exitPairs_statement(self)




    def pairs_statement(self):

        localctx = GromacsPTParser.Pairs_statementContext(self, self._ctx, self.state)
        self.enterRule(localctx, 44, self.RULE_pairs_statement)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 327
            self.match(GromacsPTParser.L_brkt)
            self.state = 328
            self.match(GromacsPTParser.Pairs)
            self.state = 329
            self.match(GromacsPTParser.R_brkt)
            self.state = 333
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==30:
                self.state = 330
                self.pairs()
                self.state = 335
                self._errHandler.sync(self)
                _la = self._input.LA(1)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class PairsContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def Integer(self, i:int=None):
            if i is None:
                return self.getTokens(GromacsPTParser.Integer)
            else:
                return self.getToken(GromacsPTParser.Integer, i)

        def number(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(GromacsPTParser.NumberContext)
            else:
                return self.getTypedRuleContext(GromacsPTParser.NumberContext,i)


        def Simple_name(self):
            return self.getToken(GromacsPTParser.Simple_name, 0)

        def getRuleIndex(self):
            return GromacsPTParser.RULE_pairs

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterPairs" ):
                listener.enterPairs(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitPairs" ):
                listener.exitPairs(self)




    def pairs(self):

        localctx = GromacsPTParser.PairsContext(self, self._ctx, self.state)
        self.enterRule(localctx, 46, self.RULE_pairs)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 336
            self.match(GromacsPTParser.Integer)
            self.state = 337
            self.match(GromacsPTParser.Integer)
            self.state = 338
            self.match(GromacsPTParser.Integer)
            self.state = 347
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,23,self._ctx)
            if la_ == 1:
                self.state = 339
                self.number()
                self.state = 340
                self.number()
                self.state = 345
                self._errHandler.sync(self)
                la_ = self._interp.adaptivePredict(self._input,22,self._ctx)
                if la_ == 1:
                    self.state = 341
                    self.number()
                    self.state = 342
                    self.number()
                    self.state = 343
                    self.number()




            self.state = 350
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==35:
                self.state = 349
                self.match(GromacsPTParser.Simple_name)


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Pairs_nb_statementContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def L_brkt(self):
            return self.getToken(GromacsPTParser.L_brkt, 0)

        def Pairs_nb(self):
            return self.getToken(GromacsPTParser.Pairs_nb, 0)

        def R_brkt(self):
            return self.getToken(GromacsPTParser.R_brkt, 0)

        def pairs_nb(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(GromacsPTParser.Pairs_nbContext)
            else:
                return self.getTypedRuleContext(GromacsPTParser.Pairs_nbContext,i)


        def getRuleIndex(self):
            return GromacsPTParser.RULE_pairs_nb_statement

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterPairs_nb_statement" ):
                listener.enterPairs_nb_statement(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitPairs_nb_statement" ):
                listener.exitPairs_nb_statement(self)




    def pairs_nb_statement(self):

        localctx = GromacsPTParser.Pairs_nb_statementContext(self, self._ctx, self.state)
        self.enterRule(localctx, 48, self.RULE_pairs_nb_statement)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 352
            self.match(GromacsPTParser.L_brkt)
            self.state = 353
            self.match(GromacsPTParser.Pairs_nb)
            self.state = 354
            self.match(GromacsPTParser.R_brkt)
            self.state = 358
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==30:
                self.state = 355
                self.pairs_nb()
                self.state = 360
                self._errHandler.sync(self)
                _la = self._input.LA(1)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Pairs_nbContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def Integer(self, i:int=None):
            if i is None:
                return self.getTokens(GromacsPTParser.Integer)
            else:
                return self.getToken(GromacsPTParser.Integer, i)

        def number(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(GromacsPTParser.NumberContext)
            else:
                return self.getTypedRuleContext(GromacsPTParser.NumberContext,i)


        def Simple_name(self):
            return self.getToken(GromacsPTParser.Simple_name, 0)

        def getRuleIndex(self):
            return GromacsPTParser.RULE_pairs_nb

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterPairs_nb" ):
                listener.enterPairs_nb(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitPairs_nb" ):
                listener.exitPairs_nb(self)




    def pairs_nb(self):

        localctx = GromacsPTParser.Pairs_nbContext(self, self._ctx, self.state)
        self.enterRule(localctx, 50, self.RULE_pairs_nb)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 361
            self.match(GromacsPTParser.Integer)
            self.state = 362
            self.match(GromacsPTParser.Integer)
            self.state = 363
            self.match(GromacsPTParser.Integer)
            self.state = 369
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,26,self._ctx)
            if la_ == 1:
                self.state = 364
                self.number()
                self.state = 365
                self.number()
                self.state = 366
                self.number()
                self.state = 367
                self.number()


            self.state = 372
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==35:
                self.state = 371
                self.match(GromacsPTParser.Simple_name)


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Angles_statementContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def L_brkt(self):
            return self.getToken(GromacsPTParser.L_brkt, 0)

        def Angles(self):
            return self.getToken(GromacsPTParser.Angles, 0)

        def R_brkt(self):
            return self.getToken(GromacsPTParser.R_brkt, 0)

        def angles(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(GromacsPTParser.AnglesContext)
            else:
                return self.getTypedRuleContext(GromacsPTParser.AnglesContext,i)


        def getRuleIndex(self):
            return GromacsPTParser.RULE_angles_statement

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterAngles_statement" ):
                listener.enterAngles_statement(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitAngles_statement" ):
                listener.exitAngles_statement(self)




    def angles_statement(self):

        localctx = GromacsPTParser.Angles_statementContext(self, self._ctx, self.state)
        self.enterRule(localctx, 52, self.RULE_angles_statement)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 374
            self.match(GromacsPTParser.L_brkt)
            self.state = 375
            self.match(GromacsPTParser.Angles)
            self.state = 376
            self.match(GromacsPTParser.R_brkt)
            self.state = 380
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==30:
                self.state = 377
                self.angles()
                self.state = 382
                self._errHandler.sync(self)
                _la = self._input.LA(1)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class AnglesContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def Integer(self, i:int=None):
            if i is None:
                return self.getTokens(GromacsPTParser.Integer)
            else:
                return self.getToken(GromacsPTParser.Integer, i)

        def number(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(GromacsPTParser.NumberContext)
            else:
                return self.getTypedRuleContext(GromacsPTParser.NumberContext,i)


        def Simple_name(self):
            return self.getToken(GromacsPTParser.Simple_name, 0)

        def getRuleIndex(self):
            return GromacsPTParser.RULE_angles

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterAngles" ):
                listener.enterAngles(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitAngles" ):
                listener.exitAngles(self)




    def angles(self):

        localctx = GromacsPTParser.AnglesContext(self, self._ctx, self.state)
        self.enterRule(localctx, 54, self.RULE_angles)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 383
            self.match(GromacsPTParser.Integer)
            self.state = 384
            self.match(GromacsPTParser.Integer)
            self.state = 385
            self.match(GromacsPTParser.Integer)
            self.state = 386
            self.match(GromacsPTParser.Integer)
            self.state = 400
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,32,self._ctx)
            if la_ == 1:
                self.state = 387
                self.number()
                self.state = 388
                self.number()
                self.state = 398
                self._errHandler.sync(self)
                la_ = self._interp.adaptivePredict(self._input,31,self._ctx)
                if la_ == 1:
                    self.state = 389
                    self.number()
                    self.state = 396
                    self._errHandler.sync(self)
                    la_ = self._interp.adaptivePredict(self._input,30,self._ctx)
                    if la_ == 1:
                        self.state = 390
                        self.number()
                        self.state = 394
                        self._errHandler.sync(self)
                        la_ = self._interp.adaptivePredict(self._input,29,self._ctx)
                        if la_ == 1:
                            self.state = 391
                            self.number()
                            self.state = 392
                            self.number()








            self.state = 403
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==35:
                self.state = 402
                self.match(GromacsPTParser.Simple_name)


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Dihedrals_statementContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def L_brkt(self):
            return self.getToken(GromacsPTParser.L_brkt, 0)

        def Dihedrals(self):
            return self.getToken(GromacsPTParser.Dihedrals, 0)

        def R_brkt(self):
            return self.getToken(GromacsPTParser.R_brkt, 0)

        def dihedrals(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(GromacsPTParser.DihedralsContext)
            else:
                return self.getTypedRuleContext(GromacsPTParser.DihedralsContext,i)


        def getRuleIndex(self):
            return GromacsPTParser.RULE_dihedrals_statement

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterDihedrals_statement" ):
                listener.enterDihedrals_statement(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitDihedrals_statement" ):
                listener.exitDihedrals_statement(self)




    def dihedrals_statement(self):

        localctx = GromacsPTParser.Dihedrals_statementContext(self, self._ctx, self.state)
        self.enterRule(localctx, 56, self.RULE_dihedrals_statement)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 405
            self.match(GromacsPTParser.L_brkt)
            self.state = 406
            self.match(GromacsPTParser.Dihedrals)
            self.state = 407
            self.match(GromacsPTParser.R_brkt)
            self.state = 411
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==30:
                self.state = 408
                self.dihedrals()
                self.state = 413
                self._errHandler.sync(self)
                _la = self._input.LA(1)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class DihedralsContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def Integer(self, i:int=None):
            if i is None:
                return self.getTokens(GromacsPTParser.Integer)
            else:
                return self.getToken(GromacsPTParser.Integer, i)

        def number(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(GromacsPTParser.NumberContext)
            else:
                return self.getTypedRuleContext(GromacsPTParser.NumberContext,i)


        def Simple_name(self):
            return self.getToken(GromacsPTParser.Simple_name, 0)

        def getRuleIndex(self):
            return GromacsPTParser.RULE_dihedrals

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterDihedrals" ):
                listener.enterDihedrals(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitDihedrals" ):
                listener.exitDihedrals(self)




    def dihedrals(self):

        localctx = GromacsPTParser.DihedralsContext(self, self._ctx, self.state)
        self.enterRule(localctx, 58, self.RULE_dihedrals)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 414
            self.match(GromacsPTParser.Integer)
            self.state = 415
            self.match(GromacsPTParser.Integer)
            self.state = 416
            self.match(GromacsPTParser.Integer)
            self.state = 417
            self.match(GromacsPTParser.Integer)
            self.state = 418
            self.match(GromacsPTParser.Integer)
            self.state = 431
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,38,self._ctx)
            if la_ == 1:
                self.state = 419
                self.number()
                self.state = 420
                self.number()
                self.state = 429
                self._errHandler.sync(self)
                la_ = self._interp.adaptivePredict(self._input,37,self._ctx)
                if la_ == 1:
                    self.state = 421
                    self.number()
                    self.state = 427
                    self._errHandler.sync(self)
                    la_ = self._interp.adaptivePredict(self._input,36,self._ctx)
                    if la_ == 1:
                        self.state = 422
                        self.number()
                        self.state = 423
                        self.number()
                        self.state = 425
                        self._errHandler.sync(self)
                        la_ = self._interp.adaptivePredict(self._input,35,self._ctx)
                        if la_ == 1:
                            self.state = 424
                            self.number()








            self.state = 434
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==35:
                self.state = 433
                self.match(GromacsPTParser.Simple_name)


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Exclusions_statementContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def L_brkt(self):
            return self.getToken(GromacsPTParser.L_brkt, 0)

        def Exclusions(self):
            return self.getToken(GromacsPTParser.Exclusions, 0)

        def R_brkt(self):
            return self.getToken(GromacsPTParser.R_brkt, 0)

        def exclusions(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(GromacsPTParser.ExclusionsContext)
            else:
                return self.getTypedRuleContext(GromacsPTParser.ExclusionsContext,i)


        def getRuleIndex(self):
            return GromacsPTParser.RULE_exclusions_statement

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterExclusions_statement" ):
                listener.enterExclusions_statement(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitExclusions_statement" ):
                listener.exitExclusions_statement(self)




    def exclusions_statement(self):

        localctx = GromacsPTParser.Exclusions_statementContext(self, self._ctx, self.state)
        self.enterRule(localctx, 60, self.RULE_exclusions_statement)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 436
            self.match(GromacsPTParser.L_brkt)
            self.state = 437
            self.match(GromacsPTParser.Exclusions)
            self.state = 438
            self.match(GromacsPTParser.R_brkt)
            self.state = 442
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==30:
                self.state = 439
                self.exclusions()
                self.state = 444
                self._errHandler.sync(self)
                _la = self._input.LA(1)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ExclusionsContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def Integer(self, i:int=None):
            if i is None:
                return self.getTokens(GromacsPTParser.Integer)
            else:
                return self.getToken(GromacsPTParser.Integer, i)

        def Simple_name(self):
            return self.getToken(GromacsPTParser.Simple_name, 0)

        def getRuleIndex(self):
            return GromacsPTParser.RULE_exclusions

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterExclusions" ):
                listener.enterExclusions(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitExclusions" ):
                listener.exitExclusions(self)




    def exclusions(self):

        localctx = GromacsPTParser.ExclusionsContext(self, self._ctx, self.state)
        self.enterRule(localctx, 62, self.RULE_exclusions)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 445
            self.match(GromacsPTParser.Integer)
            self.state = 447 
            self._errHandler.sync(self)
            _alt = 1
            while _alt!=2 and _alt!=ATN.INVALID_ALT_NUMBER:
                if _alt == 1:
                    self.state = 446
                    self.match(GromacsPTParser.Integer)

                else:
                    raise NoViableAltException(self)
                self.state = 449 
                self._errHandler.sync(self)
                _alt = self._interp.adaptivePredict(self._input,41,self._ctx)

            self.state = 452
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==35:
                self.state = 451
                self.match(GromacsPTParser.Simple_name)


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Constraints_statementContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def L_brkt(self):
            return self.getToken(GromacsPTParser.L_brkt, 0)

        def Constraints(self):
            return self.getToken(GromacsPTParser.Constraints, 0)

        def R_brkt(self):
            return self.getToken(GromacsPTParser.R_brkt, 0)

        def constraints(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(GromacsPTParser.ConstraintsContext)
            else:
                return self.getTypedRuleContext(GromacsPTParser.ConstraintsContext,i)


        def getRuleIndex(self):
            return GromacsPTParser.RULE_constraints_statement

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterConstraints_statement" ):
                listener.enterConstraints_statement(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitConstraints_statement" ):
                listener.exitConstraints_statement(self)




    def constraints_statement(self):

        localctx = GromacsPTParser.Constraints_statementContext(self, self._ctx, self.state)
        self.enterRule(localctx, 64, self.RULE_constraints_statement)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 454
            self.match(GromacsPTParser.L_brkt)
            self.state = 455
            self.match(GromacsPTParser.Constraints)
            self.state = 456
            self.match(GromacsPTParser.R_brkt)
            self.state = 460
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==30:
                self.state = 457
                self.constraints()
                self.state = 462
                self._errHandler.sync(self)
                _la = self._input.LA(1)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ConstraintsContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def Integer(self, i:int=None):
            if i is None:
                return self.getTokens(GromacsPTParser.Integer)
            else:
                return self.getToken(GromacsPTParser.Integer, i)

        def number(self):
            return self.getTypedRuleContext(GromacsPTParser.NumberContext,0)


        def Simple_name(self):
            return self.getToken(GromacsPTParser.Simple_name, 0)

        def getRuleIndex(self):
            return GromacsPTParser.RULE_constraints

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterConstraints" ):
                listener.enterConstraints(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitConstraints" ):
                listener.exitConstraints(self)




    def constraints(self):

        localctx = GromacsPTParser.ConstraintsContext(self, self._ctx, self.state)
        self.enterRule(localctx, 66, self.RULE_constraints)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 463
            self.match(GromacsPTParser.Integer)
            self.state = 464
            self.match(GromacsPTParser.Integer)
            self.state = 465
            self.match(GromacsPTParser.Integer)
            self.state = 467
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,44,self._ctx)
            if la_ == 1:
                self.state = 466
                self.number()


            self.state = 470
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==35:
                self.state = 469
                self.match(GromacsPTParser.Simple_name)


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Settles_statementContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def L_brkt(self):
            return self.getToken(GromacsPTParser.L_brkt, 0)

        def Settles(self):
            return self.getToken(GromacsPTParser.Settles, 0)

        def R_brkt(self):
            return self.getToken(GromacsPTParser.R_brkt, 0)

        def settles(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(GromacsPTParser.SettlesContext)
            else:
                return self.getTypedRuleContext(GromacsPTParser.SettlesContext,i)


        def getRuleIndex(self):
            return GromacsPTParser.RULE_settles_statement

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterSettles_statement" ):
                listener.enterSettles_statement(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitSettles_statement" ):
                listener.exitSettles_statement(self)




    def settles_statement(self):

        localctx = GromacsPTParser.Settles_statementContext(self, self._ctx, self.state)
        self.enterRule(localctx, 68, self.RULE_settles_statement)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 472
            self.match(GromacsPTParser.L_brkt)
            self.state = 473
            self.match(GromacsPTParser.Settles)
            self.state = 474
            self.match(GromacsPTParser.R_brkt)
            self.state = 478
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==30:
                self.state = 475
                self.settles()
                self.state = 480
                self._errHandler.sync(self)
                _la = self._input.LA(1)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class SettlesContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def Integer(self, i:int=None):
            if i is None:
                return self.getTokens(GromacsPTParser.Integer)
            else:
                return self.getToken(GromacsPTParser.Integer, i)

        def number(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(GromacsPTParser.NumberContext)
            else:
                return self.getTypedRuleContext(GromacsPTParser.NumberContext,i)


        def Simple_name(self):
            return self.getToken(GromacsPTParser.Simple_name, 0)

        def getRuleIndex(self):
            return GromacsPTParser.RULE_settles

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterSettles" ):
                listener.enterSettles(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitSettles" ):
                listener.exitSettles(self)




    def settles(self):

        localctx = GromacsPTParser.SettlesContext(self, self._ctx, self.state)
        self.enterRule(localctx, 70, self.RULE_settles)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 481
            self.match(GromacsPTParser.Integer)
            self.state = 482
            self.match(GromacsPTParser.Integer)
            self.state = 486
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,47,self._ctx)
            if la_ == 1:
                self.state = 483
                self.number()
                self.state = 484
                self.number()


            self.state = 489
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==35:
                self.state = 488
                self.match(GromacsPTParser.Simple_name)


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Virtual_sites1_statementContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def L_brkt(self):
            return self.getToken(GromacsPTParser.L_brkt, 0)

        def Virtual_sites1(self):
            return self.getToken(GromacsPTParser.Virtual_sites1, 0)

        def R_brkt(self):
            return self.getToken(GromacsPTParser.R_brkt, 0)

        def virtual_sites1(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(GromacsPTParser.Virtual_sites1Context)
            else:
                return self.getTypedRuleContext(GromacsPTParser.Virtual_sites1Context,i)


        def getRuleIndex(self):
            return GromacsPTParser.RULE_virtual_sites1_statement

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterVirtual_sites1_statement" ):
                listener.enterVirtual_sites1_statement(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitVirtual_sites1_statement" ):
                listener.exitVirtual_sites1_statement(self)




    def virtual_sites1_statement(self):

        localctx = GromacsPTParser.Virtual_sites1_statementContext(self, self._ctx, self.state)
        self.enterRule(localctx, 72, self.RULE_virtual_sites1_statement)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 491
            self.match(GromacsPTParser.L_brkt)
            self.state = 492
            self.match(GromacsPTParser.Virtual_sites1)
            self.state = 493
            self.match(GromacsPTParser.R_brkt)
            self.state = 497
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==30:
                self.state = 494
                self.virtual_sites1()
                self.state = 499
                self._errHandler.sync(self)
                _la = self._input.LA(1)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Virtual_sites1Context(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def Integer(self, i:int=None):
            if i is None:
                return self.getTokens(GromacsPTParser.Integer)
            else:
                return self.getToken(GromacsPTParser.Integer, i)

        def Simple_name(self):
            return self.getToken(GromacsPTParser.Simple_name, 0)

        def getRuleIndex(self):
            return GromacsPTParser.RULE_virtual_sites1

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterVirtual_sites1" ):
                listener.enterVirtual_sites1(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitVirtual_sites1" ):
                listener.exitVirtual_sites1(self)




    def virtual_sites1(self):

        localctx = GromacsPTParser.Virtual_sites1Context(self, self._ctx, self.state)
        self.enterRule(localctx, 74, self.RULE_virtual_sites1)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 500
            self.match(GromacsPTParser.Integer)
            self.state = 501
            self.match(GromacsPTParser.Integer)
            self.state = 502
            self.match(GromacsPTParser.Integer)
            self.state = 504
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==35:
                self.state = 503
                self.match(GromacsPTParser.Simple_name)


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Virtual_sites2_statementContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def L_brkt(self):
            return self.getToken(GromacsPTParser.L_brkt, 0)

        def Virtual_sites2(self):
            return self.getToken(GromacsPTParser.Virtual_sites2, 0)

        def R_brkt(self):
            return self.getToken(GromacsPTParser.R_brkt, 0)

        def virtual_sites2(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(GromacsPTParser.Virtual_sites2Context)
            else:
                return self.getTypedRuleContext(GromacsPTParser.Virtual_sites2Context,i)


        def getRuleIndex(self):
            return GromacsPTParser.RULE_virtual_sites2_statement

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterVirtual_sites2_statement" ):
                listener.enterVirtual_sites2_statement(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitVirtual_sites2_statement" ):
                listener.exitVirtual_sites2_statement(self)




    def virtual_sites2_statement(self):

        localctx = GromacsPTParser.Virtual_sites2_statementContext(self, self._ctx, self.state)
        self.enterRule(localctx, 76, self.RULE_virtual_sites2_statement)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 506
            self.match(GromacsPTParser.L_brkt)
            self.state = 507
            self.match(GromacsPTParser.Virtual_sites2)
            self.state = 508
            self.match(GromacsPTParser.R_brkt)
            self.state = 512
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==30:
                self.state = 509
                self.virtual_sites2()
                self.state = 514
                self._errHandler.sync(self)
                _la = self._input.LA(1)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Virtual_sites2Context(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def Integer(self, i:int=None):
            if i is None:
                return self.getTokens(GromacsPTParser.Integer)
            else:
                return self.getToken(GromacsPTParser.Integer, i)

        def number(self):
            return self.getTypedRuleContext(GromacsPTParser.NumberContext,0)


        def Simple_name(self):
            return self.getToken(GromacsPTParser.Simple_name, 0)

        def getRuleIndex(self):
            return GromacsPTParser.RULE_virtual_sites2

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterVirtual_sites2" ):
                listener.enterVirtual_sites2(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitVirtual_sites2" ):
                listener.exitVirtual_sites2(self)




    def virtual_sites2(self):

        localctx = GromacsPTParser.Virtual_sites2Context(self, self._ctx, self.state)
        self.enterRule(localctx, 78, self.RULE_virtual_sites2)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 515
            self.match(GromacsPTParser.Integer)
            self.state = 516
            self.match(GromacsPTParser.Integer)
            self.state = 517
            self.match(GromacsPTParser.Integer)
            self.state = 518
            self.match(GromacsPTParser.Integer)
            self.state = 520
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,52,self._ctx)
            if la_ == 1:
                self.state = 519
                self.number()


            self.state = 523
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==35:
                self.state = 522
                self.match(GromacsPTParser.Simple_name)


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Virtual_sites3_statementContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def L_brkt(self):
            return self.getToken(GromacsPTParser.L_brkt, 0)

        def Virtual_sites3(self):
            return self.getToken(GromacsPTParser.Virtual_sites3, 0)

        def R_brkt(self):
            return self.getToken(GromacsPTParser.R_brkt, 0)

        def virtual_sites3(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(GromacsPTParser.Virtual_sites3Context)
            else:
                return self.getTypedRuleContext(GromacsPTParser.Virtual_sites3Context,i)


        def getRuleIndex(self):
            return GromacsPTParser.RULE_virtual_sites3_statement

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterVirtual_sites3_statement" ):
                listener.enterVirtual_sites3_statement(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitVirtual_sites3_statement" ):
                listener.exitVirtual_sites3_statement(self)




    def virtual_sites3_statement(self):

        localctx = GromacsPTParser.Virtual_sites3_statementContext(self, self._ctx, self.state)
        self.enterRule(localctx, 80, self.RULE_virtual_sites3_statement)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 525
            self.match(GromacsPTParser.L_brkt)
            self.state = 526
            self.match(GromacsPTParser.Virtual_sites3)
            self.state = 527
            self.match(GromacsPTParser.R_brkt)
            self.state = 531
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==30:
                self.state = 528
                self.virtual_sites3()
                self.state = 533
                self._errHandler.sync(self)
                _la = self._input.LA(1)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Virtual_sites3Context(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def Integer(self, i:int=None):
            if i is None:
                return self.getTokens(GromacsPTParser.Integer)
            else:
                return self.getToken(GromacsPTParser.Integer, i)

        def number(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(GromacsPTParser.NumberContext)
            else:
                return self.getTypedRuleContext(GromacsPTParser.NumberContext,i)


        def Simple_name(self):
            return self.getToken(GromacsPTParser.Simple_name, 0)

        def getRuleIndex(self):
            return GromacsPTParser.RULE_virtual_sites3

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterVirtual_sites3" ):
                listener.enterVirtual_sites3(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitVirtual_sites3" ):
                listener.exitVirtual_sites3(self)




    def virtual_sites3(self):

        localctx = GromacsPTParser.Virtual_sites3Context(self, self._ctx, self.state)
        self.enterRule(localctx, 82, self.RULE_virtual_sites3)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 534
            self.match(GromacsPTParser.Integer)
            self.state = 535
            self.match(GromacsPTParser.Integer)
            self.state = 536
            self.match(GromacsPTParser.Integer)
            self.state = 537
            self.match(GromacsPTParser.Integer)
            self.state = 538
            self.match(GromacsPTParser.Integer)
            self.state = 544
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,56,self._ctx)
            if la_ == 1:
                self.state = 539
                self.number()
                self.state = 540
                self.number()
                self.state = 542
                self._errHandler.sync(self)
                la_ = self._interp.adaptivePredict(self._input,55,self._ctx)
                if la_ == 1:
                    self.state = 541
                    self.number()




            self.state = 547
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==35:
                self.state = 546
                self.match(GromacsPTParser.Simple_name)


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Virtual_sites4_statementContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def L_brkt(self):
            return self.getToken(GromacsPTParser.L_brkt, 0)

        def Virtual_sites4(self):
            return self.getToken(GromacsPTParser.Virtual_sites4, 0)

        def R_brkt(self):
            return self.getToken(GromacsPTParser.R_brkt, 0)

        def virtual_sites4(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(GromacsPTParser.Virtual_sites4Context)
            else:
                return self.getTypedRuleContext(GromacsPTParser.Virtual_sites4Context,i)


        def getRuleIndex(self):
            return GromacsPTParser.RULE_virtual_sites4_statement

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterVirtual_sites4_statement" ):
                listener.enterVirtual_sites4_statement(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitVirtual_sites4_statement" ):
                listener.exitVirtual_sites4_statement(self)




    def virtual_sites4_statement(self):

        localctx = GromacsPTParser.Virtual_sites4_statementContext(self, self._ctx, self.state)
        self.enterRule(localctx, 84, self.RULE_virtual_sites4_statement)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 549
            self.match(GromacsPTParser.L_brkt)
            self.state = 550
            self.match(GromacsPTParser.Virtual_sites4)
            self.state = 551
            self.match(GromacsPTParser.R_brkt)
            self.state = 555
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==30:
                self.state = 552
                self.virtual_sites4()
                self.state = 557
                self._errHandler.sync(self)
                _la = self._input.LA(1)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Virtual_sites4Context(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def Integer(self, i:int=None):
            if i is None:
                return self.getTokens(GromacsPTParser.Integer)
            else:
                return self.getToken(GromacsPTParser.Integer, i)

        def number(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(GromacsPTParser.NumberContext)
            else:
                return self.getTypedRuleContext(GromacsPTParser.NumberContext,i)


        def Simple_name(self):
            return self.getToken(GromacsPTParser.Simple_name, 0)

        def getRuleIndex(self):
            return GromacsPTParser.RULE_virtual_sites4

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterVirtual_sites4" ):
                listener.enterVirtual_sites4(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitVirtual_sites4" ):
                listener.exitVirtual_sites4(self)




    def virtual_sites4(self):

        localctx = GromacsPTParser.Virtual_sites4Context(self, self._ctx, self.state)
        self.enterRule(localctx, 86, self.RULE_virtual_sites4)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 558
            self.match(GromacsPTParser.Integer)
            self.state = 559
            self.match(GromacsPTParser.Integer)
            self.state = 560
            self.match(GromacsPTParser.Integer)
            self.state = 561
            self.match(GromacsPTParser.Integer)
            self.state = 562
            self.match(GromacsPTParser.Integer)
            self.state = 563
            self.match(GromacsPTParser.Integer)
            self.state = 568
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,59,self._ctx)
            if la_ == 1:
                self.state = 564
                self.number()
                self.state = 565
                self.number()
                self.state = 566
                self.number()


            self.state = 571
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==35:
                self.state = 570
                self.match(GromacsPTParser.Simple_name)


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Virtual_sitesn_statementContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def L_brkt(self):
            return self.getToken(GromacsPTParser.L_brkt, 0)

        def Virtual_sitesn(self):
            return self.getToken(GromacsPTParser.Virtual_sitesn, 0)

        def R_brkt(self):
            return self.getToken(GromacsPTParser.R_brkt, 0)

        def virtual_sitesn(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(GromacsPTParser.Virtual_sitesnContext)
            else:
                return self.getTypedRuleContext(GromacsPTParser.Virtual_sitesnContext,i)


        def getRuleIndex(self):
            return GromacsPTParser.RULE_virtual_sitesn_statement

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterVirtual_sitesn_statement" ):
                listener.enterVirtual_sitesn_statement(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitVirtual_sitesn_statement" ):
                listener.exitVirtual_sitesn_statement(self)




    def virtual_sitesn_statement(self):

        localctx = GromacsPTParser.Virtual_sitesn_statementContext(self, self._ctx, self.state)
        self.enterRule(localctx, 88, self.RULE_virtual_sitesn_statement)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 573
            self.match(GromacsPTParser.L_brkt)
            self.state = 574
            self.match(GromacsPTParser.Virtual_sitesn)
            self.state = 575
            self.match(GromacsPTParser.R_brkt)
            self.state = 579
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==30:
                self.state = 576
                self.virtual_sitesn()
                self.state = 581
                self._errHandler.sync(self)
                _la = self._input.LA(1)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Virtual_sitesnContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def Integer(self, i:int=None):
            if i is None:
                return self.getTokens(GromacsPTParser.Integer)
            else:
                return self.getToken(GromacsPTParser.Integer, i)

        def number(self):
            return self.getTypedRuleContext(GromacsPTParser.NumberContext,0)


        def Simple_name(self):
            return self.getToken(GromacsPTParser.Simple_name, 0)

        def getRuleIndex(self):
            return GromacsPTParser.RULE_virtual_sitesn

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterVirtual_sitesn" ):
                listener.enterVirtual_sitesn(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitVirtual_sitesn" ):
                listener.exitVirtual_sitesn(self)




    def virtual_sitesn(self):

        localctx = GromacsPTParser.Virtual_sitesnContext(self, self._ctx, self.state)
        self.enterRule(localctx, 90, self.RULE_virtual_sitesn)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 582
            self.match(GromacsPTParser.Integer)
            self.state = 583
            self.match(GromacsPTParser.Integer)
            self.state = 585 
            self._errHandler.sync(self)
            _alt = 1
            while _alt!=2 and _alt!=ATN.INVALID_ALT_NUMBER:
                if _alt == 1:
                    self.state = 584
                    self.match(GromacsPTParser.Integer)

                else:
                    raise NoViableAltException(self)
                self.state = 587 
                self._errHandler.sync(self)
                _alt = self._interp.adaptivePredict(self._input,62,self._ctx)

            self.state = 590
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,63,self._ctx)
            if la_ == 1:
                self.state = 589
                self.number()


            self.state = 593
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==35:
                self.state = 592
                self.match(GromacsPTParser.Simple_name)


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class System_statementContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def L_brkt(self):
            return self.getToken(GromacsPTParser.L_brkt, 0)

        def System(self):
            return self.getToken(GromacsPTParser.System, 0)

        def R_brkt_AA(self):
            return self.getToken(GromacsPTParser.R_brkt_AA, 0)

        def RETURN_AA(self):
            return self.getToken(GromacsPTParser.RETURN_AA, 0)

        def Simple_name_AA(self, i:int=None):
            if i is None:
                return self.getTokens(GromacsPTParser.Simple_name_AA)
            else:
                return self.getToken(GromacsPTParser.Simple_name_AA, i)

        def getRuleIndex(self):
            return GromacsPTParser.RULE_system_statement

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterSystem_statement" ):
                listener.enterSystem_statement(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitSystem_statement" ):
                listener.exitSystem_statement(self)




    def system_statement(self):

        localctx = GromacsPTParser.System_statementContext(self, self._ctx, self.state)
        self.enterRule(localctx, 92, self.RULE_system_statement)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 595
            self.match(GromacsPTParser.L_brkt)
            self.state = 596
            self.match(GromacsPTParser.System)
            self.state = 597
            self.match(GromacsPTParser.R_brkt_AA)
            self.state = 601
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==43:
                self.state = 598
                self.match(GromacsPTParser.Simple_name_AA)
                self.state = 603
                self._errHandler.sync(self)
                _la = self._input.LA(1)

            self.state = 604
            self.match(GromacsPTParser.RETURN_AA)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Molecules_statementContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def L_brkt(self):
            return self.getToken(GromacsPTParser.L_brkt, 0)

        def Molecules(self):
            return self.getToken(GromacsPTParser.Molecules, 0)

        def R_brkt(self):
            return self.getToken(GromacsPTParser.R_brkt, 0)

        def molecules(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(GromacsPTParser.MoleculesContext)
            else:
                return self.getTypedRuleContext(GromacsPTParser.MoleculesContext,i)


        def getRuleIndex(self):
            return GromacsPTParser.RULE_molecules_statement

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterMolecules_statement" ):
                listener.enterMolecules_statement(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitMolecules_statement" ):
                listener.exitMolecules_statement(self)




    def molecules_statement(self):

        localctx = GromacsPTParser.Molecules_statementContext(self, self._ctx, self.state)
        self.enterRule(localctx, 94, self.RULE_molecules_statement)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 606
            self.match(GromacsPTParser.L_brkt)
            self.state = 607
            self.match(GromacsPTParser.Molecules)
            self.state = 608
            self.match(GromacsPTParser.R_brkt)
            self.state = 610 
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while True:
                self.state = 609
                self.molecules()
                self.state = 612 
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if not (_la==35):
                    break

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class MoleculesContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def Simple_name(self):
            return self.getToken(GromacsPTParser.Simple_name, 0)

        def Integer(self):
            return self.getToken(GromacsPTParser.Integer, 0)

        def getRuleIndex(self):
            return GromacsPTParser.RULE_molecules

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterMolecules" ):
                listener.enterMolecules(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitMolecules" ):
                listener.exitMolecules(self)




    def molecules(self):

        localctx = GromacsPTParser.MoleculesContext(self, self._ctx, self.state)
        self.enterRule(localctx, 96, self.RULE_molecules)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 614
            self.match(GromacsPTParser.Simple_name)
            self.state = 615
            self.match(GromacsPTParser.Integer)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class NumberContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def Real(self):
            return self.getToken(GromacsPTParser.Real, 0)

        def Integer(self):
            return self.getToken(GromacsPTParser.Integer, 0)

        def getRuleIndex(self):
            return GromacsPTParser.RULE_number

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterNumber" ):
                listener.enterNumber(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitNumber" ):
                listener.exitNumber(self)




    def number(self):

        localctx = GromacsPTParser.NumberContext(self, self._ctx, self.state)
        self.enterRule(localctx, 98, self.RULE_number)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 617
            _la = self._input.LA(1)
            if not(_la==30 or _la==31):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Position_restraintsContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def L_brkt(self):
            return self.getToken(GromacsPTParser.L_brkt, 0)

        def Position_restraints(self):
            return self.getToken(GromacsPTParser.Position_restraints, 0)

        def R_brkt(self):
            return self.getToken(GromacsPTParser.R_brkt, 0)

        def position_restraint(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(GromacsPTParser.Position_restraintContext)
            else:
                return self.getTypedRuleContext(GromacsPTParser.Position_restraintContext,i)


        def getRuleIndex(self):
            return GromacsPTParser.RULE_position_restraints

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterPosition_restraints" ):
                listener.enterPosition_restraints(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitPosition_restraints" ):
                listener.exitPosition_restraints(self)




    def position_restraints(self):

        localctx = GromacsPTParser.Position_restraintsContext(self, self._ctx, self.state)
        self.enterRule(localctx, 100, self.RULE_position_restraints)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 619
            self.match(GromacsPTParser.L_brkt)
            self.state = 620
            self.match(GromacsPTParser.Position_restraints)
            self.state = 621
            self.match(GromacsPTParser.R_brkt)
            self.state = 623 
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while True:
                self.state = 622
                self.position_restraint()
                self.state = 625 
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if not (_la==30):
                    break

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Position_restraintContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def Integer(self, i:int=None):
            if i is None:
                return self.getTokens(GromacsPTParser.Integer)
            else:
                return self.getToken(GromacsPTParser.Integer, i)

        def number(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(GromacsPTParser.NumberContext)
            else:
                return self.getTypedRuleContext(GromacsPTParser.NumberContext,i)


        def Simple_name(self):
            return self.getToken(GromacsPTParser.Simple_name, 0)

        def getRuleIndex(self):
            return GromacsPTParser.RULE_position_restraint

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterPosition_restraint" ):
                listener.enterPosition_restraint(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitPosition_restraint" ):
                listener.exitPosition_restraint(self)




    def position_restraint(self):

        localctx = GromacsPTParser.Position_restraintContext(self, self._ctx, self.state)
        self.enterRule(localctx, 102, self.RULE_position_restraint)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 627
            self.match(GromacsPTParser.Integer)
            self.state = 628
            self.match(GromacsPTParser.Integer)
            self.state = 629
            self.number()
            self.state = 630
            self.number()
            self.state = 631
            self.number()
            self.state = 633
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==35:
                self.state = 632
                self.match(GromacsPTParser.Simple_name)


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx





