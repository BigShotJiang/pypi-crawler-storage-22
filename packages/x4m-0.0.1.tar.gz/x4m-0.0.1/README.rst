x4m
###

Validate, convert, transform


**Installation**

::

    pip install x4m


For developers
**************

* Use regular virtualenv or any other (no pre-defined preparations provided)

* Running tests::

    tox

* Building package::

    tox -e build

* Contributing: contact me through `Issues <https://gitlab.com/pyctrl/x4m/issues>`__


Versioning
**********

`SemVer <http://semver.org/>`__ used for versioning.
For available versions see the repository
`tags <https://gitlab.com/pyctrl/x4m/tags>`__.


Authors
*******

-  **Dima Burmistrov** - *Initial work* -
   `pyctrl <https://github.com/pyctrl>`__


License
*******

This project is licensed under the X11 License (extended MIT) - see the
`LICENSE <https://github.com/pyctrl/x4m/blob/main/LICENSE>`__ file for details
