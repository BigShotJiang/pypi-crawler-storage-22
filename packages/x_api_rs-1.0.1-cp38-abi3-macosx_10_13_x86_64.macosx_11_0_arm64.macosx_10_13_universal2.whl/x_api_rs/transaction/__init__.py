"""
Transaction (客户端事务 ID) 模块

提供 X-Client-Transaction-Id 头部生成功能。

Example:
    ```python
    from x_api_rs import transaction

    # 异步创建 ClientTransaction 实例
    client_tx = await transaction.ClientTransaction.create()

    # 生成 transaction_id
    tx_id = client_tx.generate_transaction_id("POST", "/1.1/dm/new2.json")
    print(f"Transaction ID: {tx_id}")

    # 使用代理创建
    client_tx = await transaction.ClientTransaction.create(
        proxy_url="http://proxy:8080"
    )

    # 查看内部状态
    print(f"Key: {client_tx.key}")
    print(f"Animation Key: {client_tx.animation_key}")
    ```
"""

from ..x_api_rs import transaction as _transaction

ClientTransaction = _transaction.ClientTransaction

__all__ = [
    "ClientTransaction",
]
