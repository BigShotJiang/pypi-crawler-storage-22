#!/bin/bash
apt-get update && apt-get install -y libegl1 libgl1-mesa-glx libosmesa6-dev xvfb
