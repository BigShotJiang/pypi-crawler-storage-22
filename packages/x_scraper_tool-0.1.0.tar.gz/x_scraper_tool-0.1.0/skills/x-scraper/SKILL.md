---
name: x-scraper
description: Use when scraping X (Twitter) data - user profiles, tweets, followers, following lists, tweet replies, retweeters. Triggers on "scrape twitter", "scrape X", "get tweets", "fetch followers", "twitter data", "X API", "twscrape".
---

# X (Twitter) Scraper

## Overview

CLI tool for scraping X user data via twscrape with cookie-based auth and multi-account rotation.

## Quick Start

```bash
cp config.example.toml config.toml  # fill in ct0 + auth_token
x-scraper scrape --user TARGET --all
```

## Cookie Setup

Browser login -> DevTools -> Application -> Cookies -> copy `ct0` and `auth_token`.

```toml
[[accounts]]
username = "throwaway_account"
cookies = "ct0=xxx; auth_token=yyy"
```

## Commands

```bash
# User data
x-scraper scrape --user USERNAME --all              # profile + tweets + followers + following
x-scraper scrape --user USERNAME --tweets --limit 50 # specific data type
x-scraper scrape --user USERNAME --all --format csv  # CSV output

# Tweet interactions
x-scraper scrape --tweet TWEET_ID --replies --retweeters

# Account management
x-scraper accounts
```

## Output

Files written to `output/{username}/` or `output/tweet_{id}/`:
- `profile.json` - user profile
- `tweets.json` - tweet timeline
- `followers.json` / `following.json` - social graph
- `replies.json` / `retweeters.json` - tweet interactions

## Architecture

| Module | Purpose |
|--------|---------|
| `cli.py` | Click CLI entry point |
| `config.py` | TOML config loading |
| `auth.py` | Cookie import + twscrape xclid monkey-patch |
| `scraper.py` | Async scraping via twscrape API |
| `models.py` | Dataclass models with `from_twscrape()` converters |
| `export.py` | JSON/CSV export |

## Known Issues

- twscrape `xclid.py` breaks when X changes JS bundle format -- `auth.py` includes a monkey-patch for unquoted JSON keys ([twscrape#284](https://github.com/vladkens/twscrape/issues/284))
- X anti-scraping changes every 2-4 weeks; twscrape or the patch may need updates
- Accounts can get locked/suspended; never use primary accounts

## Extending

All scraper methods are async on `XScraper` class:

```python
scraper = XScraper(config)
await scraper.setup()

profile = await scraper.scrape_user_profile("username")
tweets = await scraper.scrape_user_tweets(user_id, limit=100)
followers = await scraper.scrape_user_followers(user_id, limit=500)
replies = await scraper.scrape_tweet_replies(tweet_id)
```
