from __future__ import annotations

import json
import logging
import re

from twscrape import API, AccountsPool

from x_scraper.config import Config

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Monkey-patch: X changed their JS bundles to emit unquoted JSON keys,
# which breaks twscrape's script URL parser.
# See: https://github.com/vladkens/twscrape/issues/284
# ---------------------------------------------------------------------------

def _script_url(k: str, v: str) -> str:
    return f"https://abs.twimg.com/responsive-web/client-web/{k}.{v}.js"


def _patched_get_scripts_list(text: str):
    scripts = text.split('e=>e+"."+')[1].split('[e]+"a.js"')[0]
    try:
        for k, v in json.loads(scripts).items():
            yield _script_url(k, f"{v}a")
    except json.decoder.JSONDecodeError:
        # Fix unquoted keys like: node_modules_pnpm_ws_8_18_0_...
        fixed = re.sub(
            r'([,\{])(\s*)([\w]+_[\w_]+)(\s*):',
            r'\1\2"\3"\4:',
            scripts,
        )
        for k, v in json.loads(fixed).items():
            yield _script_url(k, f"{v}a")


from twscrape import xclid  # noqa: E402

xclid.get_scripts_list = _patched_get_scripts_list
logger.debug("Applied monkey-patch for twscrape xclid script parser")


async def setup_pool(config: Config) -> API:
    """Create twscrape API with accounts from config using cookie-based auth.

    Returns a ready-to-use API instance with all accounts added and activated.
    """
    pool = AccountsPool()

    for account in config.accounts:
        await pool.add_account(
            username=account.username,
            password="placeholder",
            email="placeholder@example.com",
            email_password="placeholder",
            proxy=account.proxy,
            cookies=account.cookies,
        )
        logger.info("Added account: %s", account.username)

    # Do NOT pass proxy to API() -- let per-account proxy take effect
    api = API(pool=pool)
    return api
