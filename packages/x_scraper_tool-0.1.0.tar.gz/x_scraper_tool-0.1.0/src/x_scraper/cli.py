from __future__ import annotations

import asyncio
import logging
import sys
from pathlib import Path

import click

from x_scraper.config import load_config
from x_scraper.export import export_data
from x_scraper.scraper import XScraper

logger = logging.getLogger("x_scraper")


def _setup_logging(verbose: bool) -> None:
    level = logging.DEBUG if verbose else logging.INFO
    logging.basicConfig(
        level=level,
        format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S",
    )


@click.group()
@click.option("-v", "--verbose", is_flag=True, help="Enable debug logging.")
def main(verbose: bool) -> None:
    """X (Twitter) scraper - fetch user data via twscrape."""
    _setup_logging(verbose)


# ---------------------------------------------------------------------------
# scrape command
# ---------------------------------------------------------------------------


@main.command()
@click.option(
    "-c", "--config", "config_path",
    default="config.toml",
    show_default=True,
    help="Path to TOML config file.",
)
@click.option("-u", "--user", "username", help="Target username to scrape.")
@click.option("-t", "--tweet", "tweet_id", type=int, help="Target tweet ID.")
@click.option("--tweets", is_flag=True, help="Scrape user tweets.")
@click.option("--followers", is_flag=True, help="Scrape user followers.")
@click.option("--following", is_flag=True, help="Scrape user following.")
@click.option("--replies", is_flag=True, help="Scrape tweet replies.")
@click.option("--retweeters", is_flag=True, help="Scrape tweet retweeters.")
@click.option("--all", "scrape_all", is_flag=True, help="Scrape all available data.")
@click.option(
    "--format", "fmt",
    type=click.Choice(["json", "csv"]),
    default="json",
    show_default=True,
    help="Output format.",
)
@click.option("--limit", type=int, default=None, help="Max items to fetch per category.")
def scrape(
    config_path: str,
    username: str | None,
    tweet_id: int | None,
    tweets: bool,
    followers: bool,
    following: bool,
    replies: bool,
    retweeters: bool,
    scrape_all: bool,
    fmt: str,
    limit: int | None,
) -> None:
    """Scrape user data or tweet interactions from X."""
    if not username and not tweet_id:
        click.echo("Error: provide --user or --tweet", err=True)
        sys.exit(1)

    try:
        config = load_config(config_path)
    except (FileNotFoundError, ValueError) as exc:
        click.echo(f"Config error: {exc}", err=True)
        sys.exit(1)

    asyncio.run(_run_scrape(
        config=config,
        username=username,
        tweet_id=tweet_id,
        tweets=tweets or scrape_all,
        followers=followers or scrape_all,
        following=following or scrape_all,
        replies=replies or scrape_all,
        retweeters=retweeters or scrape_all,
        fmt=fmt,
        limit=limit,
    ))


async def _run_scrape(
    *,
    config,
    username: str | None,
    tweet_id: int | None,
    tweets: bool,
    followers: bool,
    following: bool,
    replies: bool,
    retweeters: bool,
    fmt: str,
    limit: int | None,
) -> None:
    scraper = XScraper(config)
    await scraper.setup()

    # --- User-level scraping ---
    if username:
        user_dir = config.output_dir / username
        click.echo(f"Scraping user: {username}")

        profile = await scraper.scrape_user_profile(username)
        path = export_data([profile], user_dir, "profile", fmt)
        click.echo(f"  profile -> {path}")

        user_id = int(profile.id)

        if tweets:
            data = await scraper.scrape_user_tweets(user_id, limit=limit)
            path = export_data(data, user_dir, "tweets", fmt)
            click.echo(f"  tweets ({len(data)}) -> {path}")

        if followers:
            data = await scraper.scrape_user_followers(
                user_id, limit=limit or 1000,
            )
            path = export_data(data, user_dir, "followers", fmt)
            click.echo(f"  followers ({len(data)}) -> {path}")

        if following:
            data = await scraper.scrape_user_following(
                user_id, limit=limit or 1000,
            )
            path = export_data(data, user_dir, "following", fmt)
            click.echo(f"  following ({len(data)}) -> {path}")

    # --- Tweet-level scraping ---
    if tweet_id:
        tweet_dir = config.output_dir / f"tweet_{tweet_id}"
        click.echo(f"Scraping tweet: {tweet_id}")

        if replies:
            data = await scraper.scrape_tweet_replies(
                tweet_id, limit=limit or 500,
            )
            path = export_data(data, tweet_dir, "replies", fmt)
            click.echo(f"  replies ({len(data)}) -> {path}")

        if retweeters:
            data = await scraper.scrape_tweet_retweeters(
                tweet_id, limit=limit or 500,
            )
            path = export_data(data, tweet_dir, "retweeters", fmt)
            click.echo(f"  retweeters ({len(data)}) -> {path}")

    click.echo("Done.")


# ---------------------------------------------------------------------------
# accounts command
# ---------------------------------------------------------------------------


@main.command()
@click.option(
    "-c", "--config", "config_path",
    default="config.toml",
    show_default=True,
    help="Path to TOML config file.",
)
def accounts(config_path: str) -> None:
    """List configured accounts and their status."""
    try:
        config = load_config(config_path)
    except (FileNotFoundError, ValueError) as exc:
        click.echo(f"Config error: {exc}", err=True)
        sys.exit(1)

    click.echo(f"Configured accounts ({len(config.accounts)}):")
    for acc in config.accounts:
        proxy_info = f" [proxy: {acc.proxy}]" if acc.proxy else ""
        click.echo(f"  - {acc.username}{proxy_info}")
