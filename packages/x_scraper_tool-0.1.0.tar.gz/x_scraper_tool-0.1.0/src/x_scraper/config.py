from __future__ import annotations

import tomllib
from dataclasses import dataclass, field
from pathlib import Path


@dataclass
class AccountConfig:
    username: str
    cookies: str
    proxy: str | None = None


@dataclass
class Config:
    output_dir: Path = field(default_factory=lambda: Path("./output"))
    request_delay: float = 1.5
    max_tweets: int = 3200
    accounts: list[AccountConfig] = field(default_factory=list)


def load_config(path: str | Path) -> Config:
    """Load and validate configuration from a TOML file."""
    path = Path(path)
    if not path.exists():
        raise FileNotFoundError(f"Config file not found: {path}")

    with path.open("rb") as f:
        raw = tomllib.load(f)

    scraper = raw.get("scraper", {})
    accounts_raw = raw.get("accounts", [])

    if not accounts_raw:
        raise ValueError("At least one account must be configured in [[accounts]]")

    accounts = []
    for acc in accounts_raw:
        if "username" not in acc or "cookies" not in acc:
            raise ValueError("Each account must have 'username' and 'cookies' fields")
        accounts.append(
            AccountConfig(
                username=acc["username"],
                cookies=acc["cookies"],
                proxy=acc.get("proxy"),
            )
        )

    return Config(
        output_dir=Path(scraper.get("output_dir", "./output")),
        request_delay=float(scraper.get("request_delay", 1.5)),
        max_tweets=int(scraper.get("max_tweets", 3200)),
        accounts=accounts,
    )
