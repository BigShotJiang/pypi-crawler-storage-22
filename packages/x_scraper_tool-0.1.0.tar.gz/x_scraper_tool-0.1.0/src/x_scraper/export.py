from __future__ import annotations

import csv
import dataclasses
import json
from pathlib import Path
from typing import Any


def _to_dicts(data: list[Any]) -> list[dict[str, Any]]:
    """Convert a list of dataclass instances to a list of dicts."""
    return [dataclasses.asdict(item) for item in data]


def export_json(data: list[Any], output_path: Path) -> None:
    """Export dataclass instances as a JSON file."""
    output_path.parent.mkdir(parents=True, exist_ok=True)
    records = _to_dicts(data)
    with output_path.open("w", encoding="utf-8") as f:
        json.dump(records, f, ensure_ascii=False, indent=2)


def export_csv(data: list[Any], output_path: Path) -> None:
    """Export dataclass instances as a CSV file."""
    if not data:
        return
    output_path.parent.mkdir(parents=True, exist_ok=True)
    records = _to_dicts(data)
    fieldnames = list(records[0].keys())
    with output_path.open("w", encoding="utf-8", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(records)


def export_data(
    data: list[Any],
    output_dir: Path,
    name: str,
    fmt: str = "json",
) -> Path:
    """Export data to the given directory with the specified format.

    Returns the path of the written file.
    """
    ext = fmt if fmt in ("json", "csv") else "json"
    output_path = output_dir / f"{name}.{ext}"
    if ext == "csv":
        export_csv(data, output_path)
    else:
        export_json(data, output_path)
    return output_path
