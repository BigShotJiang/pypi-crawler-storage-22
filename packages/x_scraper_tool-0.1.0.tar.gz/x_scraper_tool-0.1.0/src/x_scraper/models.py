from __future__ import annotations

from dataclasses import dataclass, field
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    import twscrape


@dataclass
class UserProfile:
    id: str
    username: str
    display_name: str
    bio: str
    followers_count: int
    following_count: int
    tweets_count: int
    created_at: str
    verified: bool
    blue: bool
    profile_image_url: str

    @classmethod
    def from_twscrape(cls, user: twscrape.models.User) -> UserProfile:
        return cls(
            id=str(user.id),
            username=user.username,
            display_name=user.displayname,
            bio=user.rawDescription,
            followers_count=user.followersCount,
            following_count=user.friendsCount,
            tweets_count=user.statusesCount,
            created_at=user.created.isoformat(),
            verified=user.verified or False,
            blue=user.blue or False,
            profile_image_url=user.profileImageUrl,
        )


@dataclass
class Tweet:
    id: str
    user_id: str
    username: str
    text: str
    created_at: str
    retweet_count: int
    like_count: int
    reply_count: int
    quote_count: int
    lang: str
    media_urls: list[str] = field(default_factory=list)
    is_retweet: bool = False
    is_reply: bool = False
    reply_to_tweet_id: str | None = None
    reply_to_user: str | None = None

    @classmethod
    def from_twscrape(cls, tweet: twscrape.models.Tweet) -> Tweet:
        media_urls: list[str] = []
        if tweet.media:
            media_urls.extend(p.url for p in tweet.media.photos)
            media_urls.extend(v.thumbnailUrl for v in tweet.media.videos)

        return cls(
            id=str(tweet.id),
            user_id=str(tweet.user.id),
            username=tweet.user.username,
            text=tweet.rawContent,
            created_at=tweet.date.isoformat(),
            retweet_count=tweet.retweetCount,
            like_count=tweet.likeCount,
            reply_count=tweet.replyCount,
            quote_count=tweet.quoteCount,
            lang=tweet.lang,
            media_urls=media_urls,
            is_retweet=tweet.retweetedTweet is not None,
            is_reply=tweet.inReplyToTweetId is not None,
            reply_to_tweet_id=(
                str(tweet.inReplyToTweetId)
                if tweet.inReplyToTweetId is not None
                else None
            ),
            reply_to_user=(
                tweet.inReplyToUser.username
                if tweet.inReplyToUser is not None
                else None
            ),
        )


@dataclass
class Follower:
    id: str
    username: str
    display_name: str
    bio: str
    followers_count: int
    following_count: int

    @classmethod
    def from_twscrape(cls, user: twscrape.models.User) -> Follower:
        return cls(
            id=str(user.id),
            username=user.username,
            display_name=user.displayname,
            bio=user.rawDescription,
            followers_count=user.followersCount,
            following_count=user.friendsCount,
        )


@dataclass
class Reply:
    id: str
    user_id: str
    username: str
    text: str
    created_at: str
    like_count: int
    reply_to_tweet_id: str

    @classmethod
    def from_twscrape(cls, tweet: twscrape.models.Tweet) -> Reply:
        return cls(
            id=str(tweet.id),
            user_id=str(tweet.user.id),
            username=tweet.user.username,
            text=tweet.rawContent,
            created_at=tweet.date.isoformat(),
            like_count=tweet.likeCount,
            reply_to_tweet_id=str(tweet.inReplyToTweetId or tweet.conversationId),
        )
