from __future__ import annotations

import asyncio
import logging

import twscrape

from x_scraper.auth import setup_pool
from x_scraper.config import Config
from x_scraper.models import Follower, Reply, Tweet, UserProfile

logger = logging.getLogger(__name__)


class XScraper:
    def __init__(self, config: Config) -> None:
        self.config = config
        self.api: twscrape.API | None = None

    async def setup(self) -> None:
        """Initialize twscrape API with configured accounts."""
        self.api = await setup_pool(self.config)

    def _ensure_api(self) -> twscrape.API:
        if self.api is None:
            raise RuntimeError("Call setup() before scraping")
        return self.api

    async def _delay(self) -> None:
        await asyncio.sleep(self.config.request_delay)

    # --- User Profile ---

    async def scrape_user_profile(self, username: str) -> UserProfile:
        """Fetch a user's profile by username."""
        api = self._ensure_api()
        user = await api.user_by_login(username)
        if user is None:
            raise ValueError(f"User not found: {username}")
        return UserProfile.from_twscrape(user)

    async def _resolve_user_id(self, username: str) -> int:
        """Resolve a username to a numeric user ID."""
        api = self._ensure_api()
        user = await api.user_by_login(username)
        if user is None:
            raise ValueError(f"User not found: {username}")
        return user.id

    # --- Tweets ---

    async def scrape_user_tweets(
        self, user_id: int, limit: int | None = None
    ) -> list[Tweet]:
        """Fetch a user's tweets."""
        api = self._ensure_api()
        effective_limit = limit or self.config.max_tweets
        tweets: list[Tweet] = []
        async for raw in api.user_tweets(user_id, limit=effective_limit):
            tweets.append(Tweet.from_twscrape(raw))
        await self._delay()
        logger.info("Fetched %d tweets for user %d", len(tweets), user_id)
        return tweets

    # --- Followers / Following ---

    async def scrape_user_followers(
        self, user_id: int, limit: int = 1000
    ) -> list[Follower]:
        """Fetch a user's followers."""
        api = self._ensure_api()
        followers: list[Follower] = []
        async for raw in api.followers(user_id, limit=limit):
            followers.append(Follower.from_twscrape(raw))
        await self._delay()
        logger.info("Fetched %d followers for user %d", len(followers), user_id)
        return followers

    async def scrape_user_following(
        self, user_id: int, limit: int = 1000
    ) -> list[Follower]:
        """Fetch accounts a user follows."""
        api = self._ensure_api()
        following: list[Follower] = []
        async for raw in api.following(user_id, limit=limit):
            following.append(Follower.from_twscrape(raw))
        await self._delay()
        logger.info("Fetched %d following for user %d", len(following), user_id)
        return following

    # --- Tweet interactions ---

    async def scrape_tweet_replies(
        self, tweet_id: int, limit: int = 500
    ) -> list[Reply]:
        """Fetch replies to a specific tweet."""
        api = self._ensure_api()
        replies: list[Reply] = []
        async for raw in api.tweet_replies(tweet_id, limit=limit):
            replies.append(Reply.from_twscrape(raw))
        await self._delay()
        logger.info("Fetched %d replies for tweet %d", len(replies), tweet_id)
        return replies

    async def scrape_tweet_retweeters(
        self, tweet_id: int, limit: int = 500
    ) -> list[Follower]:
        """Fetch users who retweeted a tweet."""
        api = self._ensure_api()
        retweeters: list[Follower] = []
        async for raw in api.retweeters(tweet_id, limit=limit):
            retweeters.append(Follower.from_twscrape(raw))
        await self._delay()
        logger.info("Fetched %d retweeters for tweet %d", len(retweeters), tweet_id)
        return retweeters
