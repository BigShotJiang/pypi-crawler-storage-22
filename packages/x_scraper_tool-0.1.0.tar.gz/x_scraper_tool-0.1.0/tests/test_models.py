"""Unit tests for data model conversion logic."""

from __future__ import annotations

import dataclasses
from datetime import datetime, timezone
from types import SimpleNamespace
from unittest.mock import MagicMock

from x_scraper.models import Follower, Reply, Tweet, UserProfile


def _make_mock_user(**overrides):
    """Create a mock twscrape User object."""
    defaults = dict(
        id=123456789,
        username="testuser",
        displayname="Test User",
        rawDescription="A test bio",
        followersCount=100,
        friendsCount=50,
        statusesCount=500,
        created=datetime(2020, 1, 15, 12, 0, 0, tzinfo=timezone.utc),
        verified=True,
        blue=False,
        profileImageUrl="https://pbs.twimg.com/profile_images/test.jpg",
    )
    defaults.update(overrides)
    return SimpleNamespace(**defaults)


def _make_mock_media(photo_urls=None, video_urls=None):
    """Create a mock twscrape Media object."""
    photos = [SimpleNamespace(url=u) for u in (photo_urls or [])]
    videos = [SimpleNamespace(thumbnailUrl=u, variants=[], duration=0, views=0)
              for u in (video_urls or [])]
    return SimpleNamespace(photos=photos, videos=videos, animated=[])


def _make_mock_tweet(**overrides):
    """Create a mock twscrape Tweet object."""
    user = _make_mock_user()
    defaults = dict(
        id=999888777,
        user=user,
        rawContent="Hello world!",
        date=datetime(2024, 6, 1, 10, 30, 0, tzinfo=timezone.utc),
        retweetCount=10,
        likeCount=42,
        replyCount=5,
        quoteCount=2,
        lang="en",
        media=_make_mock_media(),
        retweetedTweet=None,
        inReplyToTweetId=None,
        inReplyToUser=None,
        conversationId=999888777,
    )
    defaults.update(overrides)
    return SimpleNamespace(**defaults)


# --- UserProfile ---


class TestUserProfile:
    def test_from_twscrape_basic(self):
        mock = _make_mock_user()
        profile = UserProfile.from_twscrape(mock)

        assert profile.id == "123456789"
        assert profile.username == "testuser"
        assert profile.display_name == "Test User"
        assert profile.bio == "A test bio"
        assert profile.followers_count == 100
        assert profile.following_count == 50
        assert profile.tweets_count == 500
        assert profile.created_at == "2020-01-15T12:00:00+00:00"
        assert profile.verified is True
        assert profile.blue is False

    def test_from_twscrape_none_verified(self):
        mock = _make_mock_user(verified=None, blue=None)
        profile = UserProfile.from_twscrape(mock)
        assert profile.verified is False
        assert profile.blue is False

    def test_serialization_roundtrip(self):
        mock = _make_mock_user()
        profile = UserProfile.from_twscrape(mock)
        d = dataclasses.asdict(profile)
        assert d["id"] == "123456789"
        assert isinstance(d["followers_count"], int)


# --- Tweet ---


class TestTweet:
    def test_from_twscrape_basic(self):
        mock = _make_mock_tweet()
        tweet = Tweet.from_twscrape(mock)

        assert tweet.id == "999888777"
        assert tweet.user_id == "123456789"
        assert tweet.username == "testuser"
        assert tweet.text == "Hello world!"
        assert tweet.retweet_count == 10
        assert tweet.like_count == 42
        assert tweet.lang == "en"
        assert tweet.is_retweet is False
        assert tweet.is_reply is False
        assert tweet.reply_to_tweet_id is None
        assert tweet.reply_to_user is None
        assert tweet.media_urls == []

    def test_from_twscrape_with_media(self):
        media = _make_mock_media(
            photo_urls=["https://img1.jpg", "https://img2.jpg"],
            video_urls=["https://vid1.jpg"],
        )
        mock = _make_mock_tweet(media=media)
        tweet = Tweet.from_twscrape(mock)

        assert tweet.media_urls == [
            "https://img1.jpg",
            "https://img2.jpg",
            "https://vid1.jpg",
        ]

    def test_from_twscrape_retweet(self):
        mock = _make_mock_tweet(retweetedTweet=SimpleNamespace(id=111))
        tweet = Tweet.from_twscrape(mock)
        assert tweet.is_retweet is True

    def test_from_twscrape_reply(self):
        reply_user = SimpleNamespace(
            id=999, id_str="999", username="otheruser", displayname="Other",
        )
        mock = _make_mock_tweet(
            inReplyToTweetId=555666,
            inReplyToUser=reply_user,
        )
        tweet = Tweet.from_twscrape(mock)

        assert tweet.is_reply is True
        assert tweet.reply_to_tweet_id == "555666"
        assert tweet.reply_to_user == "otheruser"


# --- Follower ---


class TestFollower:
    def test_from_twscrape(self):
        mock = _make_mock_user()
        follower = Follower.from_twscrape(mock)

        assert follower.id == "123456789"
        assert follower.username == "testuser"
        assert follower.display_name == "Test User"
        assert follower.bio == "A test bio"
        assert follower.followers_count == 100
        assert follower.following_count == 50


# --- Reply ---


class TestReply:
    def test_from_twscrape(self):
        mock = _make_mock_tweet(inReplyToTweetId=888)
        reply = Reply.from_twscrape(mock)

        assert reply.id == "999888777"
        assert reply.user_id == "123456789"
        assert reply.text == "Hello world!"
        assert reply.like_count == 42
        assert reply.reply_to_tweet_id == "888"

    def test_from_twscrape_fallback_conversation_id(self):
        mock = _make_mock_tweet(inReplyToTweetId=None, conversationId=777)
        reply = Reply.from_twscrape(mock)
        assert reply.reply_to_tweet_id == "777"
