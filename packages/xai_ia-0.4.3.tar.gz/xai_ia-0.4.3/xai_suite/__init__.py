"""
XAI Suite - Explainable AI toolkit for cybersecurity applications.

This package provides implementations of SHAP and LIME explainability methods
for machine learning models, with optional Intelligence Amplification (IA)
for narrative generation.
"""

from xai_suite.orchestrator import XAIOrchestrator
from xai_suite.explainers import BaseExplainer, ShapExplainer, LimeExplainer
from xai_suite.utils import (
    ModelWrapper,
    plot_local_explanation,
    save_local_explanation,
    export_to_markdown,
)

__version__ = "0.4.3"
__all__ = [
    "XAIOrchestrator",
    "BaseExplainer",
    "ShapExplainer",
    "LimeExplainer",
    "ModelWrapper",
    "plot_local_explanation",
    "save_local_explanation",
    "export_to_markdown",
]
