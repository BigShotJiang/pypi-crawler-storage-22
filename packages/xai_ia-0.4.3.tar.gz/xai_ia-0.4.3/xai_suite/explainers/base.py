"""Base explainer abstract class."""

from abc import ABC, abstractmethod


class BaseExplainer(ABC):
    """
    Abstract base class for all XAI explainers.
    """

    def __init__(self, model, data, **kwargs):
        """
        Initializes the explainer.

        Args:
            model: The machine learning model to be explained.
            data: The training data.
            **kwargs: Additional parameters for the explainer.
        """
        self.model = model
        self.data = data
        self.explainer = self._initialize_explainer(**kwargs)

    @abstractmethod
    def _initialize_explainer(self, **kwargs):
        """
        A private method to set up the specific explainer library object.
        Must be implemented by subclasses.
        """
        pass

    @abstractmethod
    def explain_local(self, instance):
        """
        Generates a local, instance-level explanation.

        Args:
            instance: A single data point to explain.

        Returns:
            dict: A standardized dictionary containing the explanation.
        """
        pass

    def explain_global(self):
        """
        Generates a global explanation for the model.
        This is optional and may not be supported by all techniques.
        """
        raise NotImplementedError(
            f"{self.__class__.__name__} does not support global explanations."
        )
