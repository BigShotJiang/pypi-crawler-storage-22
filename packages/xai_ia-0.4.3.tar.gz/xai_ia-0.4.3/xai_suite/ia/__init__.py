"""Intelligence Amplification (IA) client module."""

from xai_suite.ia.client import IAClient
from xai_suite.ia.models import ExplanationRequest, NarrativeResponse

__all__ = ["IAClient", "ExplanationRequest", "NarrativeResponse"]
