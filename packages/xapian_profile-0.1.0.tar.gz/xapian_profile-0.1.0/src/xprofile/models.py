"""XProfile model for Xapian-based profile storage."""
from __future__ import annotations

from xapian_model.base import BaseXapianModel

from .schemas import get_profile_schema


class XProfile(BaseXapianModel):
    """User profile model stored in Xapian index.

    This model extends BaseXapianModel to provide profile management
    with automatic index routing based on entity_id and profile_admin_api_id.

    SECURITY NOTE:
        For security reasons, INDEX_TEMPLATE must be defined in your application code,
        not in this base class. Define it in your subclass or application:

        class MyProfile(XProfile):
            INDEX_TEMPLATE = '{entity_id}/{profile_admin_api_id}'

    Attributes:
        SCHEMA: The complete schema definition for profile fields (without _schema field).
    """

    SCHEMA = get_profile_schema()
