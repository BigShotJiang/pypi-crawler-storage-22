"""Utility functions for slug generation and UUID encoding.

This module provides helpers for creating URL-friendly slugs
and deterministic UUIDs from string inputs.
"""
from __future__ import annotations

import hashlib
import re
import unicodedata
import uuid as _uuid

__all__ = ['get_encoded_uuid', 'get_slug', 'xor_fold']


def xor_fold(data: bytes, length: int) -> bytes:
    """XOR-fold a byte string to a specified length.

    Folds the input bytes from right to left, XORing overlapping
    chunks into the result buffer.

    Args:
        data: The input bytes to fold.
        length: The desired output length in bytes.

    Returns:
        The folded bytes of the specified length.
    """
    remaining = bytearray(data)
    result = bytearray(length)
    while remaining:
        chunk = remaining[-length:]
        for i, byte in enumerate(chunk, -len(chunk)):
            result[length + i] ^= byte
        remaining = remaining[:-length]
    return bytes(result)


def get_slug(name: str) -> str:
    """Generate a URL-friendly slug from a name.

    Transliterates unicode to ASCII, strips non-alphanumeric characters,
    and joins words with hyphens.

    Args:
        name: The name to slugify.

    Returns:
        A lowercased, hyphen-separated slug string.
    """
    value = unicodedata.normalize('NFKD', name).encode('ascii', 'ignore').decode('ascii')
    value = re.sub(r'[^\w\s-]', '', value).strip().lower()
    return re.sub(r'[-\s]+', '-', value)


def get_encoded_uuid(slug: str) -> str:
    """Generate a deterministic UUID from a slug string.

    Computes a SHA-1 hash of the slug, XOR-folds it to 16 bytes,
    and returns the resulting UUID as a hex string.

    Args:
        slug: The slug string to derive a UUID from.

    Returns:
        The hex-encoded UUID string.
    """
    folded = xor_fold(hashlib.sha1(slug).digest(), 10)
    return _uuid.UUID(bytes=folded).encode()
