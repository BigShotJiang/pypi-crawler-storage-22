# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [0.1.1] - 2026-02-16

### Fixed
- Corrected import from `pyxapiand` to `xapiand` (the actual module name installed by the pyxapiand package)

## [0.1.0] - 2026-02-16

### Added
- Initial release of xapian-store package
- XStore model class based on BaseXapianModel
- Comprehensive store schema with field definitions
- Support for multiple store types (affiliate, affinity, franchise, supplier, mashup)
- Store fields for identification, metadata, visual customization, and status
- Soft delete support with is_deleted and deleted_at fields
- Timestamp tracking (created_at, updated_at)
- Type hints and Google-style docstrings
- Python 3.12+ support with modern syntax

[0.1.0]: https://github.com/dubalu/xstore/releases/tag/v0.1.0
