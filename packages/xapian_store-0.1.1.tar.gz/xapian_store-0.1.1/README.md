# xapian-store

A Python package providing the `XStore` model class for managing store data using Xapian as the underlying storage engine.

## Features

- Built on top of `xapian_model.base.BaseXapianModel`
- Comprehensive store schema with support for multiple store types
- Type-safe field definitions with validation
- Support for soft deletes and timestamps
- Configurable store attributes (slug, domain, name, owner, type, etc.)
- Visual customization fields (photo, header, color)

## Requirements

- Python 3.12 or higher
- xapian-model
- pyxapiand

## Installation

```bash
pip install xapian-store
```

## Quick Start

```python
from xstore import XStore, STORE_TYPE_AFFILIATE, get_store_schema

# The XStore class requires INDEX_TEMPLATE to be defined in your application
class MyStore(XStore):
    INDEX_TEMPLATE = "stores/{slug}"  # Define your index template

# Create a store instance
store = MyStore()

# Access the schema
schema = get_store_schema()
```

## Store Types

The package supports the following store types:

- `STORE_TYPE_NONE` - No specific type
- `STORE_TYPE_AFFILIATE` - Affiliate store
- `STORE_TYPE_AFFINITY` - Affinity store
- `STORE_TYPE_FRANCHISE` - Franchise store
- `STORE_TYPE_SUPPLIER` - Supplier store
- `STORE_TYPE_MASHUP` - Mashup store

## Schema Configuration

The store schema includes the following main fields:

- **Identification**: `id`, `slug`, `domain`, `canonical_url`
- **Metadata**: `name`, `owner`, `supplier`, `store_type`
- **Visual**: `photo`, `header`, `color`, `base_color`
- **Status**: `is_published`, `hidden`, `is_deleted`, `is_root_affinity_store`
- **Timestamps**: `created_at`, `updated_at`, `deleted_at`
- **Contact**: `from_email`, `address`

### Security Note

For security reasons, the following values are **NOT** included in this package and must be defined in your application:

- `INDEX_TEMPLATE` in the `XStore` class
- `_schema._foreign` field value in the schema
- Any application-specific constants or identifiers

See the configuration examples below for how to properly set these values.

## Configuration Example

```python
from xstore import XStore, get_store_schema

# Define your store class with required configuration
class MyStore(XStore):
    INDEX_TEMPLATE = "stores/{slug}"

    # Override schema to add application-specific configuration
    @classmethod
    def get_schema(cls):
        schema = get_store_schema()
        schema['_schema']['_foreign'] = 'https://myapp.com/schemas/store'
        schema['_schema']['_meta']['description'] = 'My application store'
        return schema

# Use your store
store = MyStore()
```

## Development

### Setup

The project uses `direnv` to automatically create and activate a virtual environment:

```bash
# With direnv installed, simply cd into the project
cd xstore

# Or manually create the environment
python3 -m venv .venv
source .venv/bin/activate
```

### Project Structure

```
xstore/
├── src/
│   └── xstore/
│       ├── __init__.py     # Public API exports
│       ├── models.py       # XStore model class
│       └── schemas.py      # Schema definitions
├── pyproject.toml          # Project configuration
└── README.md              # This file
```

## License

MIT License - see LICENSE file for details.

## Links

- **Homepage**: https://github.com/dubalu/xstore
- **Repository**: https://github.com/dubalu/xstore
- **Bug Reports**: https://github.com/dubalu/xstore/issues

## Contributing

Contributions are welcome! Please feel free to submit a Pull Request.

## Authors

- Dubalu <info@dubalu.com>
