"""XStore - Store management model built on Xapian.

This package provides the XStore model class for managing store data
using Xapian as the underlying storage engine. It includes schema definitions
for various store types and field configurations.
"""
from __future__ import annotations

from .models import XStore
from .schemas import (
    STORE_TYPE_AFFILIATE,
    STORE_TYPE_AFFINITY,
    STORE_TYPE_FRANCHISE,
    STORE_TYPE_MASHUP,
    STORE_TYPE_NONE,
    STORE_TYPE_SUPPLIER,
    get_store_schema,
)

__all__ = [
    'XStore',
    'get_store_schema',
    'STORE_TYPE_NONE',
    'STORE_TYPE_AFFILIATE',
    'STORE_TYPE_AFFINITY',
    'STORE_TYPE_FRANCHISE',
    'STORE_TYPE_SUPPLIER',
    'STORE_TYPE_MASHUP',
]

__version__ = '0.1.1'
