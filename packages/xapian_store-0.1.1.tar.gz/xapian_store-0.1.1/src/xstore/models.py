from __future__ import annotations

from xapian_model.base import BaseXapianModel

from .schemas import get_store_schema


class XStore(BaseXapianModel):
    """XStore model class for managing store data in Xapian.

    This class extends BaseXapianModel to provide store-specific functionality
    with a predefined schema for store attributes like slug, domain, name, owner,
    store type, and publication status.

    Attributes:
        SCHEMA: Dictionary containing the store field definitions and their types.
    """

    SCHEMA = get_store_schema()
