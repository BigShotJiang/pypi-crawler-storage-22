"""Store schema definitions and type constants.

This module provides the schema definition for store models and constants
for different store types supported by the system.
"""
from __future__ import annotations

from typing import Any

from xapiand import constants as xconst

__all__ = [
    'get_store_schema',
    'STORE_TYPE_NONE',
    'STORE_TYPE_AFFILIATE',
    'STORE_TYPE_AFFINITY',
    'STORE_TYPE_FRANCHISE',
    'STORE_TYPE_SUPPLIER',
    'STORE_TYPE_MASHUP',
]

# Store type constants
STORE_TYPE_NONE = 'none'
STORE_TYPE_AFFILIATE = 'affiliate'
STORE_TYPE_AFFINITY = 'affinity'
STORE_TYPE_FRANCHISE = 'franchise'
STORE_TYPE_SUPPLIER = 'supplier'
STORE_TYPE_MASHUP = 'mashup'


def get_store_schema() -> dict[str, dict[str, Any]]:
    """Get the complete schema definition for store models.

    Returns a dictionary defining all store fields with their types, indexing
    configuration, validation rules, and default values. The schema includes
    fields for store identification (slug, domain), metadata (name, type, owner),
    visual customization (photo, header, color), and configuration flags
    (is_published, hidden).

    The schema also includes common fields for all models like id, visibility,
    timestamps (created_at, updated_at, deleted_at), and soft delete flag.

    Returns:
        Schema definition with field names as keys and configuration
        dictionaries as values. Each field configuration can include:
        - _type: Field data type (term, string, uuid, boolean, date, etc.)
        - _index: Indexing strategy (field_terms, none)
        - _required: Whether the field is mandatory (default: True)
        - _null: Whether null values are allowed (default: False)
        - _default: Default value for the field
        - _choices: Tuple of allowed values for the field
        - _write_only: Whether field is write-only
        - _accuracy: Date field accuracy configuration

    Example:
        >>> schema = get_store_schema()
        >>> schema['slug']['_type']
        'term'
        >>> schema['store_type']['_choices']
        ('affiliate', 'affinity', 'franchise', 'supplier', 'mashup')
    """
    return {
        '_schema': {
            '_type': 'foreign/object',
            # NOTE: '_foreign' must be defined in your application code
            '_meta': {
                # NOTE: 'description' must be defined in your application code
            },
        },
        'id': {
            '_type': 'uuid',
        },
        'visibility': {
            '_type': 'array/term',
            '_required': False,
            '_write_only': True,
        },
        'created_at': {
            '_type': 'date',
            '_required': False,
            '_null': True,
        },
        'updated_at': {
            '_type': 'date',
            '_required': False,
            '_null': True,
            '_accuracy': xconst.DAY_TO_YEAR_ACCURACY,
        },
        'deleted_at': {
            '_type': 'date',
            '_required': False,
            '_null': True,
            '_accuracy': xconst.DAY_TO_YEAR_ACCURACY,
        },
        'is_deleted': {
            '_type': 'boolean',
            '_required': False,
            '_default': False,
        },
        'slug': {
            '_type': 'term',
            '_index': 'field_terms',
        },
        'domain': {
            '_type': 'term',
            '_index': 'field_terms',
            '_required': False,
            '_null': True,
        },
        'canonical_url': {
            '_type': 'term',
            '_index': 'field_terms',
            '_required': False,
            '_null': True,
        },
        'store_type': {
            '_type': 'term',
            '_index': 'field_terms',
            '_choices': (
                STORE_TYPE_AFFILIATE,
                STORE_TYPE_AFFINITY,
                STORE_TYPE_FRANCHISE,
                STORE_TYPE_SUPPLIER,
                STORE_TYPE_MASHUP,
            ),
        },
        'name': {
            '_type': 'string',
            '_index': 'field_terms',
        },
        'owner': {
            '_type': 'uuid',
            '_index': 'field_terms',
        },
        'supplier': {
            '_type': 'uuid',
            '_index': 'field_terms',
            '_required': False,
        },
        'photo': {
            '_type': 'term',
            '_index': 'field_terms',
        },
        'header': {
            '_type': 'term',
            '_index': 'field_terms',
            '_required': False,
        },
        'color': {
            '_type': 'term',
            '_index': 'field_terms',
            '_required': False,
        },
        'is_published': {
            '_type': 'boolean',
            '_index': 'field_terms',
            '_default': False,
        },
        'hidden': {
            '_type': 'boolean',
            '_index': 'field_terms',
            '_default': False,
        },
        'from_email': {
            '_type': 'term',
            '_index': 'none',
            '_required': False,
            '_null': True,
        },
        'base_color': {
            '_type': 'term',
            '_index': 'none',
            '_required': False,
            '_null': True,
        },
        'address': {
            '_type': 'string',
            '_index': 'none',
            '_required': False,
            '_null': True,
        },
        'is_root_affinity_store': {
            '_type': 'boolean',
            '_index': 'field_terms',
            '_default': False,
        },
    }
