# 🔥 XRSUPER XApp Token Tool — Protected Edition

**EXTREME Protection Level** • **Full Token Management Suite** • **Web-Based Interface**

A **fully protected**, cross-platform, web-based token management system for authentication workflows, featuring:

* EAT token extraction
* Access token conversion
* JWT generation
* OAuth login processing

All core logic is compiled into **protected Python bytecode (.pyc)** to secure proprietary systems and algorithms.

---

## 🛡️ Protection Layer (XApp Core)

Your application logic is secured using advanced Python bytecode protection.

### ✅ What This Means

✔ Source code hidden in compiled `.pyc` files<br>
✔ Works on **Termux, Linux, Windows, macOS, Raspberry Pi**<br>
✔ No executable or APK required<br>
✔ Web interface fully embedded in protected module<br>
✔ Sensitive logic and encryption routines cannot be easily extracted<br>

### 🔒 What Users CANNOT Access

* AES encryption keys
* API logic & request structure
* Protocol buffer definitions
* Token processing internals
* Embedded HTML templates
* Proprietary authentication flows

### 🧠 Why It’s Hard to Reverse

1. Source compiled → Python bytecode
2. Optimization Level 2 applied
3. No original `.py` files distributed
4. Dynamic imports prevent static analysis
5. Decompilers produce broken / unreadable output

> ⚠️ Only distribute the `xapp_protected/` package. Never share your original core source files.

---

# 🌟 Token Tool Features

A powerful browser-based interface for managing authentication tokens.

---

## 🔗 Token Extraction

* Extract **EAT tokens** from authentication redirect URLs
* Supports multiple login providers:

  * Facebook
  * Gmail
  * Apple
  * VK
  * Twitter
* Automatic token detection & parsing

---

## 🔄 Token Conversion

Convert **EAT → Access Token** and retrieve:

* Account ID / UID
* Player nickname
* Region & language
* Token validity status

---

## 🔐 JWT Token Generation

Generate JWT tokens using:

### Option 1 — OAuth Login

* Username / User ID
* Password authentication

### Option 2 — Existing Access Token

* Direct JWT generation
* Token decoding & validation

---

# 🚀 Installation

## 📦 Install via pip

```bash
pip install xapp-protected
```

### Dependencies Installed Automatically

* Flask — Web interface
* pycryptodome — AES encryption
* requests — API communication
* PyJWT — JWT processing
* protobuf — Protocol buffers

---

# ▶️ Running the Tool

### Linux / macOS

```bash
python3 run.py
```

### Windows

```cmd
python run.py
```

### Termux (Android)

```bash
pkg update && pkg upgrade
pkg install python
pip install -r requirements.txt
python run.py
```

---

# 🌐 Accessing the Web Interface

After starting:

### Local

```
http://localhost:10170
```

### Network (Termux / LAN)

```
http://YOUR_IP:10170
```

Find IP:

```bash
ifconfig
```

---

# 🎯 How to Use

### 1️⃣ Extract a Token

1. Click a login provider
2. Complete authentication
3. Copy redirected URL
4. Paste into extractor
5. Get your **EAT token**

---

### 2️⃣ Convert EAT → Access Token

1. Open `/convert`
2. Paste EAT token
3. Click **Get Access Token**
4. View account & token details

---

### 3️⃣ Generate JWT

Go to `/token-maker`

Choose:

✔ OAuth Login → Enter credentials<br>
✔ Access Token → Enter token directly

Receive decoded JWT payload + token string.

---

# 🔧 API Endpoints

### Public Pages

| Endpoint       | Purpose         |
| -------------- | --------------- |
| `/`            | Home interface  |
| `/convert`     | Token converter |
| `/token-maker` | JWT generator   |

### API Routes

| Endpoint              | Method | Description            |
| --------------------- | ------ | ---------------------- |
| `/extract`            | POST   | Extract token from URL |
| `/get-access`         | POST   | Convert EAT → Access   |
| `/get-access/<token>` | GET    | Convert via URL        |
| `/access-jwt`         | GET    | JWT from access token  |
| `/token`              | GET    | JWT via OAuth login    |

---

# 🐛 Troubleshooting

### ❌ Invalid Token

* Token may be expired
* Check formatting

### 🌐 API Errors

* Confirm internet connection
* External services must be reachable

### 📦 Import Errors

* Ensure Python 3.7+
* Reinstall dependencies

### 🔌 Port Already in Use

```bash
lsof -ti:10170 | xargs kill -9
```

---

# 🌍 Cross-Platform Support

| Platform     | Supported |
| ------------ | --------- |
| Windows      | ✅         |
| Linux        | ✅         |
| macOS        | ✅         |
| Termux       | ✅         |
| Raspberry Pi | ✅         |

---

# 👨‍💻 Author & Community

**Developer:** **Mr. Void**<br>
GitHub: [@IbrahimKhan](https://github.com/ibrahimkhan008)<br>
Repo: [Xapp](https://github.com/ibrahimkhan008/Xapp)

Community:

* Telegram: @xrbotupdates
* Instagram: @0xbanecipher

---

# ⚖️ License

Your original license here.

---

# ⚠️ Legal & Security Notice

* This software is protected intellectual property
* Do not redistribute core source files
* For educational and research use only
* Not affiliated with or endorsed by any game publisher or platform
* Users are responsible for complying with all laws and service terms

---

**🔐 Protected by XApp Bytecode Security**<br>
**🌟 Powered by XRSUPER Token System**
