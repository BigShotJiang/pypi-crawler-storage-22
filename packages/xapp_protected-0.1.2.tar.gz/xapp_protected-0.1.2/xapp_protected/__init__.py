"""
XApp Protected Module
This module loads precompiled bytecode for maximum protection
"""

import sys
import importlib.util
from pathlib import Path

# Get the bytecode file path
_module_dir = Path(__file__).parent
_cache_dir = _module_dir / '__pycache__'
_bytecode_file = _cache_dir / 'xapp_core.cpython-{}{}.pyc'.format(
    sys.version_info.major,
    sys.version_info.minor
)

if not _bytecode_file.exists():
    raise ImportError("Protected bytecode module not found. Please run setup.py first.")

# Load the bytecode module
spec = importlib.util.spec_from_file_location("xapp_core", _bytecode_file)
_core_module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(_core_module)

# Export the create_app function
create_app = _core_module.create_app

__all__ = ['create_app']
