.. currentmodule:: xarray

Exponential rolling objects
===========================

.. currentmodule:: xarray.computation.rolling_exp

.. autosummary::
   :toctree: ../generated/

   RollingExp
   RollingExp.mean
   RollingExp.sum
