ERDDAPy engine for xarray.

pip (or conda) install xarray-erddap and check if you load the erddapy engine:


```python
import xarray as xr

xr.backends.list_engines()
```

If successful any ERDDAP URL should, that has a netcdf-like response, should work.
Here are a few examples:

1. OPeNDAP
    ```python
    import xarray as xr

    url = "https://gliders.ioos.us/erddap/tabledap/amelia-20200825T1929"
    ds = xr.open_dataset(url, engine="erddapy")
    ```

1. Full NetCDF file (also works with the `ncCF` and `ncCFMA` responses).
    ```python
    url = "https://gliders.ioos.us/erddap/tabledap/amelia-20200825T1929.nc"
    ds = xr.open_dataset(url, engine="erddapy")
    ```

1. Sliced/Filtered URLs obatined from the ERDDAP web interface.

    ```python
    url = "https://gliders.ioos.us/erddap/tabledap/amelia-20200825T1929.nc?trajectory%2Cwmo_id%2Cprofile_id%2Ctime%2Clatitude%2Clongitude%2Cdepth%2Cconductivity&time%3E=2020-09-18T00%3A00%3A00Z&time%3C=2020-09-25T14%3A32%3A48Z"
    ds = xr.open_dataset(url, engine="erddapy")
    ```


    Also works on griddap URLs.

1. OPeNDAP-griddap

    ```python
    url = "https://pae-paha.pacioos.hawaii.edu/erddap/griddap/etopo1_bedrock"
    ds = xr.open_dataset(url, engine="erddapy")
    ```


    Note that griddap supports lazy loading! However, you can do it the ERDDAP way and pass a server-side sliced URL:

1. Sliced/Filtered griddap

    ```python
    url = "https://pae-paha.pacioos.hawaii.edu/erddap/griddap/etopo1_bedrock.nc?z%5B(-42.0):1:(-44.0)%5D%5B(-42.0):1:(-44.0)%5D"
    ds = xr.open_dataset(url, engine="erddapy")
    ```

NB: All URLs should be quoted, like the ones returned from ERDDAP's web-interface. If you are looking for human readable URLs, other non-netCDF responses, and/or programmatically building them, then erddapy is better suited for the task.
