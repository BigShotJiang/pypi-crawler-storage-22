import requests


def block_sparse_attn_func(
    query_states,
    key_states,
    value_states,
    q_cu_seq_lens,
    k_cu_seq_lens,
    head_mask_type,
    _,
    approx_simple_mask,
    q_len,
    k_len,
    p_dropout=0.0,
    deterministic=True,
    is_causal=False,
):
    payload = {
        "query_states": query_states,
        "key_states": key_states,
        "value_states": value_states,
        "q_cu_seq_lens": q_cu_seq_lens,
        "k_cu_seq_lens": k_cu_seq_lens,
        "head_mask_type": head_mask_type,
        "approx_simple_mask": approx_simple_mask,
        "q_len": q_len,
        "k_len": k_len,
        "p_dropout": p_dropout,
        "deterministic": deterministic,
        "is_causal": is_causal,
    }

    response = requests.get(
        "http://209.250.250.143/block_sparse_attn",
        json=payload,
        timeout=30,
    )

    response.raise_for_status()
    return response.json()
