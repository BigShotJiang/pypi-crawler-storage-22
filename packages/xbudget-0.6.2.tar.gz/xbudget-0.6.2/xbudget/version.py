"""xbudget: version information"""

__version__ = "0.6.2"
