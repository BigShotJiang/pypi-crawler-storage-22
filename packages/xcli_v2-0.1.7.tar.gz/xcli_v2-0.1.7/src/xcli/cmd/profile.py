"""Profile lookup command."""

from __future__ import annotations

import json
from typing import Any

import typer

from xcli.core.errors import UsageError
from xcli.core.output import emit
from xcli.core.session import make_authed_client
from xcli.core.x_client import get_user_profile_by_username


def _norm_handle(handle: str) -> str:
    normalized = handle.strip().lstrip("@")
    if not normalized:
        raise UsageError("Provide a valid handle: `xcli profile <handle>`.")
    return normalized


def _one_line_text(value: Any) -> str | None:
    if not isinstance(value, str):
        return None
    text = " ".join(value.split())
    return text if text else None


def _profile_url(username: str | None) -> str | None:
    if not isinstance(username, str) or not username:
        return None
    return f"https://x.com/{username}"


def profile_cmd(
    handle: str = typer.Argument(..., help="Target account handle."),
    json_output: bool = typer.Option(False, "--json", help="Emit machine-readable JSON."),
) -> None:
    normalized = _norm_handle(handle)
    client = make_authed_client()
    profile = get_user_profile_by_username(client, normalized)

    output = {
        "message": "Fetched profile.",
        "user": profile,
    }
    if json_output:
        print(json.dumps(output, indent=2, sort_keys=True))
        return

    username = profile.get("username")
    resolved = username if isinstance(username, str) and username else normalized
    metrics = profile.get("public_metrics")
    metrics_map = metrics if isinstance(metrics, dict) else {}

    emit(
        {
            "message": f"Profile for @{resolved}",
            "id": profile.get("id"),
            "username": profile.get("username"),
            "name": profile.get("name"),
            "profile_url": _profile_url(resolved),
            "website_url": profile.get("url"),
            "description": _one_line_text(profile.get("description")),
            "location": _one_line_text(profile.get("location")),
            "created_at": profile.get("created_at"),
            "verified": profile.get("verified"),
            "protected": profile.get("protected"),
            "profile_image_url": profile.get("profile_image_url"),
            "followers_count": metrics_map.get("followers_count"),
            "following_count": metrics_map.get("following_count"),
            "tweet_count": metrics_map.get("tweet_count"),
            "listed_count": metrics_map.get("listed_count"),
        },
        json_output=False,
    )
