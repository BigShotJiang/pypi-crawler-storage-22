"""Core helpers for xcli."""
