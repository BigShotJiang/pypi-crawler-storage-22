import json

import pytest
from pytest import MonkeyPatch

from xcli.cmd.profile import _norm_handle, profile_cmd
from xcli.core.errors import UsageError


def test_norm_handle_accepts_at_prefix() -> None:
    assert _norm_handle("@XDevelopers") == "XDevelopers"


def test_norm_handle_rejects_empty_input() -> None:
    with pytest.raises(UsageError):
        _norm_handle("   ")


def test_profile_cmd_json_output(
    monkeypatch: MonkeyPatch,
    capsys: pytest.CaptureFixture[str],
) -> None:
    fake_client = object()

    def fake_make_authed_client() -> object:
        return fake_client

    def fake_get_user_profile_by_username(client: object, username: str) -> dict[str, object]:
        assert client is fake_client
        assert username == "XDevelopers"
        return {
            "id": "2244994945",
            "username": "XDevelopers",
            "name": "X Developers",
            "description": "The voice of the X developer community",
            "location": "Internet",
            "url": "https://developer.x.com",
            "created_at": "2013-12-14T04:35:55.000Z",
            "verified": True,
            "protected": False,
            "profile_image_url": "https://pbs.twimg.com/profile_images/example.jpg",
            "public_metrics": {
                "followers_count": 583423,
                "following_count": 2048,
                "tweet_count": 14052,
                "listed_count": 1672,
            },
            "raw": {"data": {"id": "2244994945"}},
        }

    monkeypatch.setattr("xcli.cmd.profile.make_authed_client", fake_make_authed_client)
    monkeypatch.setattr(
        "xcli.cmd.profile.get_user_profile_by_username",
        fake_get_user_profile_by_username,
    )

    profile_cmd(handle="@XDevelopers", json_output=True)
    out = capsys.readouterr().out
    parsed = json.loads(out)

    assert parsed["message"] == "Fetched profile."
    assert parsed["user"]["username"] == "XDevelopers"
    assert parsed["user"]["public_metrics"]["followers_count"] == 583423


def test_profile_cmd_human_output(
    monkeypatch: MonkeyPatch,
    capsys: pytest.CaptureFixture[str],
) -> None:
    def fake_make_authed_client() -> object:
        return object()

    def fake_get_user_profile_by_username(client: object, username: str) -> dict[str, object]:
        del client
        assert username == "XDevelopers"
        return {
            "id": "2244994945",
            "username": "XDevelopers",
            "name": "X Developers",
            "description": "Voice of\nX developers",
            "location": "Internet",
            "url": "https://developer.x.com",
            "created_at": "2013-12-14T04:35:55.000Z",
            "verified": True,
            "protected": False,
            "profile_image_url": "https://pbs.twimg.com/profile_images/example.jpg",
            "public_metrics": {
                "followers_count": 583423,
                "following_count": 2048,
                "tweet_count": 14052,
                "listed_count": 1672,
            },
            "raw": {"data": {"id": "2244994945"}},
        }

    monkeypatch.setattr("xcli.cmd.profile.make_authed_client", fake_make_authed_client)
    monkeypatch.setattr(
        "xcli.cmd.profile.get_user_profile_by_username",
        fake_get_user_profile_by_username,
    )

    profile_cmd(handle="XDevelopers", json_output=False)
    out = capsys.readouterr().out

    assert "Profile for @XDevelopers" in out
    assert "profile_url: https://x.com/XDevelopers" in out
    assert "website_url: https://developer.x.com" in out
    assert "description: Voice of X developers" in out
    assert "followers_count: 583423" in out
