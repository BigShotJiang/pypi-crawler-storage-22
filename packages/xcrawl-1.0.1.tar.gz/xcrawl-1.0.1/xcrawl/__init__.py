"""
XCrawl Python SDK - Official Python SDK for XCrawl API

A powerful web scraping SDK that provides easy-to-use methods for
extracting content, metadata, and structured data from websites.
"""

__version__ = '1.0.1'

# Export main client
from .client import XcrawlClient

# Export all types
from .types import (
    BalanceResponse,
    JobStatusResponse,
    JsonConfig,
    JsRenderConfig,
    Metadata,
    OrderResponse,
    OutputConfig,
    OutputFormat,
    ProxyConfig,
    RequestConfig,
    ScrapeAsyncResponse,
    ScrapeData,
    ScrapeOptions,
    ScrapeResponse,
    ViewportConfig,
    WebhookConfig,
    WebhookEvent,
    CreditsDetail,
    # Search API types
    SerpOptions,
    SearchOptions,
    SearchResponse,
    SearchData,
    # Map API types
    MapOptions,
    MapResponse,
    MapData,
    # Crawl API types
    CrawlerConfig,
    CrawlOptions,
    CrawlResponse,
    CrawlPageData,
    CrawlStatusResponse,
)

# Export error classes
from .errors import JobTimeoutError, XcrawlError

# Define public API
__all__ = [
    # Client
    'XcrawlClient',
    # Common types
    'ProxyConfig',
    'RequestConfig',
    'ViewportConfig',
    'JsRenderConfig',
    'JsonConfig',
    'OutputFormat',
    'OutputConfig',
    'WebhookEvent',
    'WebhookConfig',
    'CreditsDetail',
    # Scrape API types
    'ScrapeOptions',
    'Metadata',
    'ScrapeData',
    'ScrapeResponse',
    'ScrapeAsyncResponse',
    'JobStatusResponse',
    # Search API types
    'SerpOptions',
    'SearchOptions',
    'SearchResponse',
    'SearchData',
    # Map API types
    'MapOptions',
    'MapResponse',
    'MapData',
    # Crawl API types
    'CrawlerConfig',
    'CrawlOptions',
    'CrawlResponse',
    'CrawlPageData',
    'CrawlStatusResponse',
    # Legacy types
    'BalanceResponse',
    'OrderResponse',
    # Errors
    'XcrawlError',
    'JobTimeoutError',
]
