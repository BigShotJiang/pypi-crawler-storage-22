"""
XCrawl SDK client implementation.
"""

import os
from typing import Optional, Union

from .errors import XcrawlError
from .http_client import HttpClient
from .methods import get_job_result as get_job_result_method
from .methods import scrape as scrape_method
from .methods import wait_for_job as wait_for_job_method
from .methods import search as search_method
from .methods import map_site as map_method
from .methods import crawl as crawl_method
from .methods import get_crawl_status as get_crawl_status_method
from .types import (
    JobStatusResponse,
    ScrapeAsyncResponse,
    ScrapeOptions,
    ScrapeResponse,
    SearchOptions,
    SearchResponse,
    MapResponse,
    CrawlResponse,
    CrawlStatusResponse
)
from .validation import validate_url


class XcrawlClient:
    """
    XCrawl SDK client for web scraping.

    This client provides methods to scrape websites, check job status,
    and wait for async jobs to complete.

    Example:
        >>> from xcrawl import XcrawlClient
        >>>
        >>> client = XcrawlClient(api_key='your-api-key')
        >>> result = client.scrape('https://example.com')
        >>> print(result['data']['markdown'])
    """

    def __init__(
        self,
        api_key: Optional[str] = None,
        api_url: Optional[str] = None,
        timeout: float = 60,
        max_retries: int = 3,
        backoff_factor: float = 0.5
    ):
        """
        Initialize XCrawl client.

        Args:
            api_key: API authentication key (defaults to XCRAWL_API_KEY env var)
            api_url: Base API URL (defaults to XCRAWL_API_URL env var or https://run.xcrawl.com)
            timeout: Request timeout in seconds (default: 60)
            max_retries: Maximum retry attempts (default: 3)
            backoff_factor: Backoff multiplier for retries (default: 0.5)

        Raises:
            XcrawlError: If API key is not provided
        """
        # Get API key from parameter or environment
        resolved_api_key = api_key or os.getenv('XCRAWL_API_KEY', '')
        if not resolved_api_key:
            raise XcrawlError(
                'INVALID_CONFIG',
                'API key is required. Set XCRAWL_API_KEY env or pass api_key parameter.'
            )

        # Get API URL from parameter or environment
        resolved_api_url = (
            api_url or
            os.getenv('XCRAWL_API_URL', 'https://run.xcrawl.com')
        ).rstrip('/')

        # Initialize HTTP client
        self._http = HttpClient(
            api_key=resolved_api_key,
            api_url=resolved_api_url,
            timeout=timeout,
            max_retries=max_retries,
            backoff_factor=backoff_factor
        )

    def scrape(
        self,
        url: str,
        options: Optional[ScrapeOptions] = None
    ) -> Union[ScrapeResponse, ScrapeAsyncResponse]:
        """
        Scrape a URL.

        Args:
            url: Target URL to scrape
            options: Scrape configuration options (optional)

        Returns:
            Sync mode: ScrapeResponse with scraped data
            Async mode: ScrapeAsyncResponse with job ID

        Raises:
            XcrawlError: If the request fails or parameters are invalid

        Example:
            >>> # Specify formats to get content
            >>> result = client.scrape('https://example.com', {
            ...     'output': {'formats': ['markdown']}
            ... })
            >>> print(result['data']['markdown'])
            >>>
            >>> # Multiple formats
            >>> result = client.scrape('https://example.com', {
            ...     'mode': 'sync',
            ...     'output': {'formats': ['markdown', 'html', 'links']}
            ... })
            >>> print(result['data']['markdown'])
            >>>
            >>> # Async mode
            >>> job = client.scrape('https://example.com', {'mode': 'async'})
            >>> result = client.wait_for_job(job['scrape_id'])
        """
        # Validate URL
        validate_url(url)

        # Call scrape method
        return scrape_method(self._http, url, options)

    def get_job_result(self, job_id: str) -> JobStatusResponse:
        """
        Get the status and result of an async job.

        Args:
            job_id: Job/scrape ID from async scrape

        Returns:
            Job status response with current status and data (if completed)

        Raises:
            XcrawlError: If the request fails

        Example:
            >>> status = client.get_job_result('job-id-123')
            >>> if status['status'] == 'completed':
            ...     print(status['data']['markdown'])
            >>> elif status['status'] == 'failed':
            ...     print(f"Job failed: {status.get('message')}")
        """
        return get_job_result_method(self._http, job_id)

    def wait_for_job(
        self,
        job_id: str,
        interval: Optional[int] = None,
        max_attempts: Optional[int] = None,
        timeout: Optional[float] = None
    ) -> JobStatusResponse:
        """
        Poll and wait for an async job to complete.

        Smart parameter handling:
        - If only timeout provided: calculates max_attempts from timeout/interval
        - If timeout + max_attempts provided: calculates interval
        - If all three provided: timeout is ignored, uses interval + max_attempts
        - If only max_attempts provided: uses max_attempts without timeout

        Args:
            job_id: Job/scrape ID from async scrape
            interval: Polling interval in milliseconds (default: 2000)
            max_attempts: Maximum polling attempts (default: 30)
            timeout: Total timeout in seconds (optional)

        Returns:
            Job status response when completed (completed or failed)

        Raises:
            JobTimeoutError: If the job doesn't complete within timeout
            XcrawlError: If the request fails

        Example:
            >>> # Only timeout - auto-calculates max_attempts
            >>> result = client.wait_for_job(job['scrape_id'], timeout=60)
            >>>
            >>> # Timeout + max_attempts - auto-calculates interval
            >>> result = client.wait_for_job(
            ...     job['scrape_id'],
            ...     max_attempts=30,
            ...     timeout=60
            ... )
            >>>
            >>> # All parameters - timeout is ignored
            >>> result = client.wait_for_job(
            ...     job['scrape_id'],
            ...     interval=2000,
            ...     max_attempts=30,
            ...     timeout=120  # This will be ignored
            ... )
            >>>
            >>> print(result['status'])  # 'completed' or 'failed'
            >>> print(result['data']['markdown'])
        """
        return wait_for_job_method(
            self._http,
            job_id,
            interval=interval,
            max_attempts=max_attempts,
            timeout=timeout
        )

    def search(self, options: SearchOptions) -> SearchResponse:
        """
        Execute a Google search.

        Args:
            options: Search configuration options

        Returns:
            Search response with SERP results

        Raises:
            XcrawlError: If the request fails or parameters are invalid

        Example:
            >>> # Basic search
            >>> result = client.search({'query': 'web scraping', 'limit': 10})
            >>> print(result['data']['organic_results'])
            >>>
            >>> # Search with location and language
            >>> result = client.search({
            ...     'query': 'python tutorials',
            ...     'location': 'United States',
            ...     'language': 'en',
            ...     'limit': 20
            ... })
            >>> print(f"Found {len(result['data']['organic_results'])} results")
            >>>
            >>> # Advanced search with SERP options
            >>> result = client.search({
            ...     'query': 'machine learning',
            ...     'serp_options': {
            ...         'gl': 'us',
            ...         'hl': 'en',
            ...         'safe': 1,
            ...         'tbs': 'qdr:w'  # Last week
            ...     }
            ... })
            >>> for item in result['data']['organic_results']:
            ...     print(item['title'], item['link'])
        """
        return search_method(self._http, options)

    def map(self, url: str, options: Optional[dict] = None) -> MapResponse:
        """
        Get all URLs from a website (sitemap extraction).

        Args:
            url: Site URL
            options: Optional map configuration (filter, limit, etc.)

        Returns:
            Map response with list of URLs

        Raises:
            XcrawlError: If the request fails or parameters are invalid

        Example:
            >>> # Basic usage
            >>> result = client.map('https://example.com')
            >>> print(result['data']['links'])
            >>>
            >>> # With filtering
            >>> result = client.map('https://example.com', {
            ...     'filter': r'.*\\.html$',  # Only .html URLs
            ...     'limit': 5000,
            ...     'include_subdomains': True
            ... })
        """
        validate_url(url)
        return map_method(self._http, url, options)

    def crawl(self, url: str, options: Optional[dict] = None) -> CrawlResponse:
        """
        Start a batch crawl job (async).

        Args:
            url: Entry URL for the crawl
            options: Optional crawl configuration

        Returns:
            Crawl response with crawl_id

        Raises:
            XcrawlError: If the request fails or parameters are invalid

        Example:
            >>> # Start crawl job
            >>> job = client.crawl('https://example.com', {
            ...     'crawler': {
            ...         'limit': 100,
            ...         'max_depth': 3,
            ...         'include': [r'.*\\.html$'],
            ...         'exclude': [r'.*/admin/.*']
            ...     },
            ...     'output': {'formats': ['markdown', 'links']}
            ... })
            >>> print(job['crawl_id'])
            >>>
            >>> # Check status
            >>> status = client.get_crawl_status(job['crawl_id'])
        """
        validate_url(url)
        return crawl_method(self._http, url, options)

    def get_crawl_status(self, crawl_id: str) -> CrawlStatusResponse:
        """
        Get crawl job status and results.

        Args:
            crawl_id: Crawl job ID

        Returns:
            Crawl status response

        Raises:
            XcrawlError: If the request fails

        Example:
            >>> status = client.get_crawl_status('crawl-id-123')
            >>> if status['status'] == 'completed':
            ...     for page in status['data']:
            ...         print(f"URL: {page['url']}")
            ...         print(f"Content: {page['data']['markdown']}")
        """
        return get_crawl_status_method(self._http, crawl_id)

    def close(self) -> None:
        """
        Close the HTTP client session.

        It's recommended to call this when you're done with the client,
        or use the client as a context manager.

        Example:
            >>> client = XcrawlClient(api_key='your-api-key')
            >>> try:
            ...     result = client.scrape('https://example.com')
            ... finally:
            ...     client.close()
        """
        self._http.close()

    def __enter__(self):
        """Context manager entry."""
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        """Context manager exit."""
        self.close()

    def __repr__(self) -> str:
        """Return string representation of the client."""
        return f"XcrawlClient(api_url='{self._http.get_api_url()}')"
