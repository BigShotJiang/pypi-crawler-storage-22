"""
XCrawl SDK error classes.
"""

from typing import Any, Optional


class XcrawlError(Exception):
    """
    Base exception class for XCrawl SDK errors.

    Attributes:
        code: Error code (e.g., 'INVALID_PARAMS', 'REQUEST_FAILED')
        message: Detailed error message
        status: HTTP status code (if applicable)
        request_id: Server request ID for debugging and support
        details: Additional error details (if available)
    """

    def __init__(
        self,
        code: str,
        message: str,
        status: Optional[int] = None,
        request_id: Optional[str] = None,
        details: Optional[Any] = None
    ):
        """
        Initialize XcrawlError.

        Args:
            code: Error code
            message: Error message
            status: HTTP status code (optional)
            request_id: Request ID for debugging (optional)
            details: Additional error details (optional)
        """
        super().__init__(message)
        self.code = code
        self.message = message
        self.status = status
        self.request_id = request_id
        self.details = details

    def __str__(self) -> str:
        """Return string representation of the error."""
        parts = [f"[{self.code}] {self.message}"]
        if self.status:
            parts.append(f"(HTTP {self.status})")
        if self.request_id:
            parts.append(f"Request ID: {self.request_id}")
        return " ".join(parts)

    def __repr__(self) -> str:
        """Return detailed representation of the error."""
        return (
            f"XcrawlError(code={self.code!r}, message={self.message!r}, "
            f"status={self.status}, request_id={self.request_id!r})"
        )


class JobTimeoutError(XcrawlError):
    """
    Exception raised when a job polling operation times out.

    Attributes:
        job_id: The scrape ID that timed out
        timeout_seconds: The timeout duration in seconds
    """

    def __init__(self, job_id: str, timeout_seconds: float):
        """
        Initialize JobTimeoutError.

        Args:
            job_id: The job/scrape ID that timed out
            timeout_seconds: Timeout duration in seconds
        """
        message = f"Job {job_id} did not complete within {timeout_seconds} seconds"
        super().__init__(
            code='JOB_TIMEOUT',
            message=message
        )
        self.job_id = job_id
        self.timeout_seconds = timeout_seconds

    def __repr__(self) -> str:
        """Return detailed representation of the error."""
        return (
            f"JobTimeoutError(job_id={self.job_id!r}, "
            f"timeout_seconds={self.timeout_seconds})"
        )


def throw_for_bad_response(response, action: str):
    """
    Throw an XcrawlError for a bad HTTP response.

    Args:
        response: HTTP response object from requests library
        action: Action being performed (for error message)

    Raises:
        XcrawlError: Always raises with details from response
    """
    status = response.status_code
    try:
        body = response.json() if response.text else {}
    except Exception:
        body = {}

    message = body.get('message') or body.get('error') or f"Request failed ({status}) while trying to {action}"
    code = body.get('code', 'REQUEST_FAILED')
    request_id = body.get('request_id')

    raise XcrawlError(code, message, status, request_id)


def normalize_requests_error(error, action: str):
    """
    Normalize a requests library error into an XcrawlError.

    Args:
        error: Exception from requests library
        action: Action being performed (for error message)

    Raises:
        XcrawlError: Always raises with normalized error details
    """
    status = None
    body = {}
    message = str(error)

    # Try to extract response details
    if hasattr(error, 'response') and error.response is not None:
        status = error.response.status_code
        try:
            body = error.response.json() if error.response.text else {}
        except Exception:
            body = {}
        message = body.get('message') or body.get('error') or message

    # Build final message
    if not message or message == str(error):
        message = f"Request failed{f' ({status})' if status else ''} while trying to {action}"

    code = body.get('code', 'REQUEST_FAILED')
    request_id = body.get('request_id')

    raise XcrawlError(code, message, status, request_id)