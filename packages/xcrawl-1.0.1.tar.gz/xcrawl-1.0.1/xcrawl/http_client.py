"""
HTTP client with automatic retry logic for XCrawl API.
"""

import time
from typing import Any, Dict, Optional

import requests
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry

from .errors import XcrawlError


def get_version() -> str:
    """
    Get the SDK version from package metadata.

    Returns:
        Version string (defaults to '1.0.1' if not found)
    """
    try:
        import importlib.metadata
        return importlib.metadata.version('xcrawl')
    except Exception:
        return '1.0.1'


class HttpClient:
    """
    HTTP client with automatic retry logic and proper error handling.
    """

    def __init__(
        self,
        api_key: str,
        api_url: str,
        timeout: float = 60,
        max_retries: int = 3,
        backoff_factor: float = 0.5
    ):
        """
        Initialize HTTP client.

        Args:
            api_key: API authentication key
            api_url: Base API URL
            timeout: Request timeout in seconds (default: 60)
            max_retries: Maximum retry attempts (default: 3)
            backoff_factor: Backoff multiplier for retries (default: 0.5)
        """
        self.api_key = api_key
        self.api_url = api_url.rstrip('/')
        self.timeout = timeout
        self.max_retries = max_retries
        self.backoff_factor = backoff_factor

        # Create session with retry logic
        self.session = requests.Session()

        # Configure retry strategy
        # Retry on 5xx errors and connection errors
        retry_strategy = Retry(
            total=max_retries,
            backoff_factor=backoff_factor,
            status_forcelist=[500, 502, 503, 504],
            allowed_methods=['GET', 'POST', 'DELETE'],
            raise_on_status=False  # We'll handle status codes manually
        )

        adapter = HTTPAdapter(max_retries=retry_strategy)
        self.session.mount('http://', adapter)
        self.session.mount('https://', adapter)

        # Set default headers
        version = get_version()
        self.session.headers.update({
            'Content-Type': 'application/json',
            'Authorization': f'Bearer {api_key}',
            'User-Agent': f'xcrawl-sdk-py/{version}'
        })

    def get_api_url(self) -> str:
        """Get the API base URL."""
        return self.api_url

    def get_api_key(self) -> str:
        """Get the API key."""
        return self.api_key

    def _make_request(
        self,
        method: str,
        endpoint: str,
        json: Optional[Dict[str, Any]] = None,
        headers: Optional[Dict[str, str]] = None
    ) -> requests.Response:
        """
        Make an HTTP request with retry logic.

        Args:
            method: HTTP method (GET, POST, DELETE)
            endpoint: API endpoint path
            json: JSON request body (optional)
            headers: Additional headers (optional)

        Returns:
            Response object

        Raises:
            XcrawlError: For API errors or network failures
        """
        url = f"{self.api_url}{endpoint}"
        request_headers = dict(self.session.headers)
        if headers:
            request_headers.update(headers)

        # Adjust timeout if request body contains a timeout parameter
        timeout = self.timeout
        if json and 'timeout' in json and isinstance(json['timeout'], (int, float)):
            timeout = json['timeout'] + 5  # Add 5 seconds buffer

        # Manual retry loop for better control
        attempts = max(1, self.max_retries)
        last_error = None
        for attempt in range(attempts):
            try:
                response = self.session.request(
                    method=method,
                    url=url,
                    json=json,
                    headers=request_headers,
                    timeout=timeout
                )

                # Check if we should retry based on status code
                if response.status_code == 502 and attempt < attempts - 1:
                    time.sleep(self.backoff_factor * (2 ** attempt))
                    continue

                # For 5xx errors, retry if we have attempts left
                if 500 <= response.status_code < 600 and attempt < attempts - 1:
                    time.sleep(self.backoff_factor * (2 ** attempt))
                    continue

                return response

            except requests.exceptions.RequestException as e:
                last_error = e
                # Retry on network errors
                if attempt < attempts - 1:
                    time.sleep(self.backoff_factor * (2 ** attempt))
                    continue
                # Last attempt failed
                raise XcrawlError(
                    code='NETWORK_ERROR',
                    message=f'Network error after {attempts} attempts: {str(e)}'
                )

        # Should not reach here, but handle just in case
        if last_error:
            raise XcrawlError(
                code='REQUEST_FAILED',
                message=f'Request failed after {attempts} attempts: {str(last_error)}'
            )

        raise XcrawlError(
            code='REQUEST_FAILED',
            message='Unexpected HTTP client error'
        )

    def post(
        self,
        endpoint: str,
        body: Dict[str, Any],
        headers: Optional[Dict[str, str]] = None
    ) -> requests.Response:
        """
        Make a POST request.

        Args:
            endpoint: API endpoint path
            body: JSON request body
            headers: Additional headers (optional)

        Returns:
            Response object
        """
        return self._make_request('POST', endpoint, json=body, headers=headers)

    def get(
        self,
        endpoint: str,
        headers: Optional[Dict[str, str]] = None
    ) -> requests.Response:
        """
        Make a GET request.

        Args:
            endpoint: API endpoint path
            headers: Additional headers (optional)

        Returns:
            Response object
        """
        return self._make_request('GET', endpoint, headers=headers)

    def delete(
        self,
        endpoint: str,
        headers: Optional[Dict[str, str]] = None
    ) -> requests.Response:
        """
        Make a DELETE request.

        Args:
            endpoint: API endpoint path
            headers: Additional headers (optional)

        Returns:
            Response object
        """
        return self._make_request('DELETE', endpoint, headers=headers)

    def prepare_headers(self, idempotency_key: Optional[str] = None) -> Dict[str, str]:
        """
        Prepare headers with optional idempotency key.

        Args:
            idempotency_key: Idempotency key for request deduplication (optional)

        Returns:
            Headers dictionary
        """
        headers: Dict[str, str] = {}
        if idempotency_key:
            headers['x-idempotency-key'] = idempotency_key
        return headers

    def close(self) -> None:
        """Close the HTTP session."""
        self.session.close()

    def __enter__(self):
        """Context manager entry."""
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        """Context manager exit."""
        self.close()
