"""
XCrawl SDK methods.
"""

from .job import get_job_result, wait_for_job
from .scrape import scrape
from .search import search
from .map import map_site
from .crawl import crawl, get_crawl_status

__all__ = [
    'scrape',
    'get_job_result',
    'wait_for_job',
    'search',
    'map_site',
    'crawl',
    'get_crawl_status'
]