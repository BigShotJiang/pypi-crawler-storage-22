"""
Crawl API method implementation.
"""

from typing import TYPE_CHECKING, Optional

from ..types import CrawlOptions, CrawlResponse, CrawlStatusResponse
from ..validation import validate_crawl_options, validate_crawl_id
from ..errors import XcrawlError, throw_for_bad_response, normalize_requests_error

if TYPE_CHECKING:
    from ..http_client import HttpClient


def crawl(http: 'HttpClient', url: str, options: Optional[dict] = None) -> CrawlResponse:
    """
    Start a batch crawl job (async).

    Args:
        http: HTTP client instance
        url: Entry URL
        options: Optional crawl options (excluding url)

    Returns:
        Crawl response with crawl_id

    Raises:
        XcrawlError: If validation fails or request fails
    """
    if options is not None and not isinstance(options, dict):
        raise XcrawlError('INVALID_PARAMS', 'options must be a dictionary')

    crawl_options: CrawlOptions = {'url': url, **(options or {})}
    validate_crawl_options(crawl_options)

    try:
        res = http.post('/v1/crawl', crawl_options)
        if res.status_code != 200:
            throw_for_bad_response(res, 'crawl')
        return res.json()
    except Exception as err:
        if hasattr(err, 'response'):
            return normalize_requests_error(err, 'crawl')
        raise


def get_crawl_status(http: 'HttpClient', crawl_id: str) -> CrawlStatusResponse:
    """
    Get crawl job status.

    Args:
        http: HTTP client instance
        crawl_id: Crawl job ID

    Returns:
        Crawl status response

    Raises:
        XcrawlError: If validation fails or request fails
    """
    validate_crawl_id(crawl_id)

    try:
        res = http.get(f'/v1/crawl/{crawl_id}')
        if res.status_code != 200:
            throw_for_bad_response(res, 'get_crawl_status')
        return res.json()
    except Exception as err:
        if hasattr(err, 'response'):
            return normalize_requests_error(err, 'get_crawl_status')
        raise
