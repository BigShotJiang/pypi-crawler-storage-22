"""
Job status and wait methods implementation.
"""

import time
from typing import Optional
from urllib.parse import quote

from ..errors import JobTimeoutError, XcrawlError
from ..http_client import HttpClient
from ..types import JobStatusResponse
from ..validation import validate_job_id


def _is_retryable_error(error: XcrawlError) -> bool:
    """
    Determine if an error should trigger another polling attempt.
    """
    if isinstance(error, JobTimeoutError):
        return False

    status = getattr(error, 'status', None)
    if status is None:
        return True  # network errors have no status -> retry

    if 500 <= status < 600:
        return True

    return False


def _handle_response_error(response, action: str) -> None:
    """
    Handle error responses from the API.

    Args:
        response: HTTP response object
        action: Action being performed (for error message)

    Raises:
        XcrawlError: With details from the response
    """
    try:
        body = response.json()
    except Exception:
        body = {}

    status = response.status_code
    message = body.get('message') or body.get('error') or f'Request failed ({status}) while trying to {action}'
    code = body.get('code', 'REQUEST_FAILED')
    request_id = body.get('request_id')

    raise XcrawlError(code=code, message=message, status=status, request_id=request_id)


def get_job_result(http: HttpClient, job_id: str) -> JobStatusResponse:
    """
    Get the status and result of an async job.

    Args:
        http: HTTP client instance
        job_id: Job/scrape ID

    Returns:
        Job status response with current status and data (if completed)

    Raises:
        XcrawlError: If the request fails
    """
    validate_job_id(job_id)

    safe_job_id = quote(job_id, safe='')
    response = http.get(f'/v1/scrape/{safe_job_id}')

    if response.status_code != 200:
        _handle_response_error(response, 'get job result')

    try:
        return response.json()
    except Exception as e:
        raise XcrawlError(
            code='INVALID_RESPONSE',
            message=f'Failed to parse API response: {str(e)}'
        )


def wait_for_job(
    http: HttpClient,
    job_id: str,
    interval: Optional[int] = None,
    max_attempts: Optional[int] = None,
    timeout: Optional[float] = None
) -> JobStatusResponse:
    """
    Poll and wait for an async job to complete.

    Smart parameter handling:
    - If only timeout provided: calculates max_attempts from timeout/interval
    - If timeout + max_attempts provided: calculates interval
    - If all three provided: timeout is ignored, uses interval + max_attempts
    - If only max_attempts provided: uses max_attempts without timeout

    Args:
        http: HTTP client instance
        job_id: Job/scrape ID
        interval: Polling interval in milliseconds (default: 2000)
        max_attempts: Maximum number of polling attempts (default: 30)
        timeout: Total timeout in seconds (optional)

    Returns:
        Job status response when completed (completed or failed)

    Raises:
        JobTimeoutError: If the job doesn't complete within timeout
        XcrawlError: If the request fails
    """
    validate_job_id(job_id)

    # Smart parameter handling
    timeout_seconds: Optional[float] = None

    if interval is not None and max_attempts is not None and timeout is not None:
        # Priority 1: All three provided → timeout is ignored
        timeout_seconds = None
    elif timeout is not None and max_attempts is None and interval is None:
        # Priority 2: Only timeout → calculate max_attempts with default interval
        interval = 2000
        max_attempts = int((timeout * 1000) / interval + 0.5)  # ceil
        timeout_seconds = timeout
    elif timeout is not None and max_attempts is None and interval is not None:
        # Priority 2b: timeout + interval → calculate max_attempts
        max_attempts = int((timeout * 1000) / interval + 0.5)  # ceil
        timeout_seconds = timeout
    elif timeout is not None and max_attempts is not None and interval is None:
        # Priority 3: timeout + max_attempts → calculate interval
        interval = int((timeout * 1000) / max_attempts)
        timeout_seconds = timeout
    else:
        # Priority 4: Use defaults or provided values
        interval = interval if interval is not None else 2000
        max_attempts = max_attempts if max_attempts is not None else 30
        timeout_seconds = timeout

    interval_seconds = interval / 1000
    start_time = time.time()

    for attempt in range(1, max_attempts + 1):
        # Check total timeout
        if timeout_seconds and (time.time() - start_time) > timeout_seconds:
            raise JobTimeoutError(job_id, timeout_seconds)

        try:
            result = get_job_result(http, job_id)

            # Job completed (completed or failed)
            if result['status'] in ('completed', 'failed'):
                return result

            # Continue waiting
            if attempt < max_attempts:
                time.sleep(interval_seconds)

        except XcrawlError as error:
            # Re-raise immediately for non-retryable errors
            if not _is_retryable_error(error) or attempt == max_attempts:
                raise

            time.sleep(interval_seconds)

    # Exceeded max attempts
    total_time = max_attempts * interval_seconds
    raise JobTimeoutError(job_id, total_time)
