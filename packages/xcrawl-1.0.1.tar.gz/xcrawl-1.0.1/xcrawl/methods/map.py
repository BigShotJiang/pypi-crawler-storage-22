"""
Map API method implementation.
"""

from typing import TYPE_CHECKING, Optional

from ..types import MapOptions, MapResponse
from ..validation import validate_map_options
from ..errors import XcrawlError, throw_for_bad_response, normalize_requests_error

if TYPE_CHECKING:
    from ..http_client import HttpClient


def map_site(http: 'HttpClient', url: str, options: Optional[dict] = None) -> MapResponse:
    """
    Get all URLs from a website (sitemap extraction).

    Args:
        http: HTTP client instance
        url: Site URL
        options: Optional map options (excluding url)

    Returns:
        Map response with list of URLs

    Raises:
        XcrawlError: If validation fails or request fails
    """
    if options is not None and not isinstance(options, dict):
        raise XcrawlError('INVALID_PARAMS', 'options must be a dictionary')

    map_options: MapOptions = {'url': url, **(options or {})}
    validate_map_options(map_options)

    try:
        res = http.post('/v1/map', map_options)
        if res.status_code != 200:
            throw_for_bad_response(res, 'map')
        return res.json()
    except Exception as err:
        if hasattr(err, 'response'):
            return normalize_requests_error(err, 'map')
        raise
