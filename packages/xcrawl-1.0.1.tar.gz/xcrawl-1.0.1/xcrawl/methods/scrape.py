"""
Scrape method implementation.
"""

from typing import Union

from ..errors import XcrawlError
from ..http_client import HttpClient
from ..types import ScrapeAsyncResponse, ScrapeOptions, ScrapeResponse
from ..validation import validate_scrape_options


def _handle_response_error(response, action: str) -> None:
    """
    Handle error responses from the API.

    Args:
        response: HTTP response object
        action: Action being performed (for error message)

    Raises:
        XcrawlError: With details from the response
    """
    try:
        body = response.json()
    except Exception:
        body = {}

    status = response.status_code
    message = body.get('message') or body.get('error') or f'Request failed ({status}) while trying to {action}'
    code = body.get('code', 'REQUEST_FAILED')
    request_id = body.get('request_id')

    raise XcrawlError(code=code, message=message, status=status, request_id=request_id)


def scrape(
    http: HttpClient,
    url: str,
    options: ScrapeOptions = None
) -> Union[ScrapeResponse, ScrapeAsyncResponse]:
    """
    Scrape a URL.

    Args:
        http: HTTP client instance
        url: URL to scrape
        options: Scrape options (optional)

    Returns:
        Sync mode: ScrapeResponse with data
        Async mode: ScrapeAsyncResponse with job ID

    Raises:
        XcrawlError: If the request fails
    """
    # Validate options
    validate_scrape_options(options)

    # Merge url and options into request body
    request_body = {'url': url}
    if options:
        request_body.update(options)

    # Make request
    response = http.post('/v1/scrape', request_body)

    # Check response status
    if response.status_code != 200:
        _handle_response_error(response, 'scrape')

    # Parse and return response
    try:
        return response.json()
    except Exception as e:
        raise XcrawlError(
            code='INVALID_RESPONSE',
            message=f'Failed to parse API response: {str(e)}'
        )
