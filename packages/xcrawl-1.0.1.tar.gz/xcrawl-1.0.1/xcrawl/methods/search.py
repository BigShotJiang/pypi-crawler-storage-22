"""
Search API method implementation.
"""

from typing import TYPE_CHECKING

from ..types import SearchOptions, SearchResponse
from ..validation import validate_search_options
from ..errors import throw_for_bad_response, normalize_requests_error

if TYPE_CHECKING:
    from ..http_client import HttpClient


def search(http: 'HttpClient', options: SearchOptions) -> SearchResponse:
    """
    Execute a Google search.

    Args:
        http: HTTP client instance
        options: Search options

    Returns:
        Search response with SERP results

    Raises:
        XcrawlError: If validation fails or request fails
    """
    validate_search_options(options)

    try:
        res = http.post('/v1/search', options)
        if res.status_code != 200:
            throw_for_bad_response(res, 'search')
        return res.json()
    except Exception as err:
        if hasattr(err, 'response'):
            return normalize_requests_error(err, 'search')
        raise