"""
Type definitions for XCrawl SDK.
"""

from typing import Any, Dict, List, Literal, Optional, TypedDict


# ==================== Request Types ====================

class ProxyConfig(TypedDict, total=False):
    """
    Proxy configuration.

    Attributes:
        location: ISO-3166-1 alpha-2 country code (e.g., 'US', 'JP')
        sticky_session: Session identifier for IP reuse
    """
    location: str
    sticky_session: str


class RequestConfig(TypedDict, total=False):
    """
    Request configuration options.

    Attributes:
        locale: Accept-Language header value
        device: Device type ('desktop' or 'mobile')
        cookies: Custom cookies as key-value pairs
        headers: Custom HTTP headers
        only_main_content: Extract only main content
        block_ads: Block advertisements
        skip_tls_verification: Skip TLS certificate verification
    """
    locale: str
    device: Literal['desktop', 'mobile']
    cookies: Dict[str, str]
    headers: Dict[str, str]
    only_main_content: bool
    block_ads: bool
    skip_tls_verification: bool


class ViewportConfig(TypedDict, total=False):
    """
    Viewport configuration for JavaScript rendering.

    Attributes:
        width: Viewport width in pixels
        height: Viewport height in pixels
    """
    width: int
    height: int


class JsRenderConfig(TypedDict, total=False):
    """
    JavaScript rendering configuration.

    Attributes:
        enabled: Enable JavaScript rendering
        wait_until: Wait condition ('load', 'domcontentloaded', 'networkidle')
        viewport: Viewport size configuration
    """
    enabled: bool
    wait_until: Literal['load', 'domcontentloaded', 'networkidle']
    viewport: ViewportConfig


class JsonConfig(TypedDict, total=False):
    """
    JSON extraction configuration.

    Attributes:
        prompt: AI prompt for data extraction
        json_schema: JSON schema for structured output
    """
    prompt: str
    json_schema: Dict[str, Any]


OutputFormat = Literal['html', 'raw_html', 'markdown', 'links', 'summary', 'screenshot', 'json']


class OutputConfig(TypedDict, total=False):
    """
    Output format configuration.

    Attributes:
        formats: List of output formats to return
        screenshot: Screenshot mode ('full_page' or 'viewport')
        json: JSON extraction configuration
    """
    formats: List[OutputFormat]
    screenshot: Literal['full_page', 'viewport']
    json: JsonConfig


WebhookEvent = Literal['started', 'completed', 'failed']


class WebhookConfig(TypedDict, total=False):
    """
    Webhook configuration for async scrapes.

    Attributes:
        url: Webhook URL
        headers: Custom headers for webhook requests
        events: Events to trigger webhook ('started', 'completed', 'failed')
    """
    url: str
    headers: Dict[str, str]
    events: List[WebhookEvent]


class ScrapeOptions(TypedDict, total=False):
    """
    Options for scraping a URL.

    Attributes:
        mode: Scrape mode ('sync' or 'async')
        proxy: Proxy configuration
        request: Request options
        js_render: JavaScript rendering options
        output: Output format configuration
        webhook: Webhook configuration for async mode
    """
    mode: Literal['sync', 'async']
    proxy: ProxyConfig
    request: RequestConfig
    js_render: JsRenderConfig
    output: OutputConfig
    webhook: WebhookConfig


# ==================== Response Types ====================

class CreditsDetail(TypedDict, total=False):
    """
    Credits usage detail breakdown.

    Attributes:
        base_cost: Base cost for scraping
        traffic_cost: Cost for traffic usage
        json_extract_cost: Cost for JSON extraction
    """
    base_cost: int
    traffic_cost: int
    json_extract_cost: int


class Metadata(TypedDict, total=False):
    """
    Page metadata from scraping.

    Attributes:
        title: Page title
        favicon: Favicon URL
        status_code: HTTP status code
        content_type: Content-Type header
        requested_url: Original requested URL
        final_url: Final URL after redirects
        proxy_location: Proxy location used
        proxy_sticky_session: Sticky session ID used
        description: Meta description
        keywords: Meta keywords
        author: Meta author
        viewport: Viewport meta tag
    """
    title: str
    favicon: str
    status_code: int
    content_type: str
    requested_url: str
    final_url: str
    proxy_location: str
    proxy_sticky_session: str
    description: str
    keywords: str
    author: str
    viewport: str


class ScrapeData(TypedDict, total=False):
    """
    Scraped data in various formats.

    Attributes:
        html: Cleaned HTML content
        raw_html: Original unprocessed HTML
        markdown: Markdown formatted content
        links: List of links found on the page
        metadata: Page metadata
        screenshot: Screenshot download URL
        summary: AI-generated summary
        json: Structured JSON data
        traffic_bytes: Traffic consumed in bytes
        credits_used: Credits consumed for this scrape
        credits_detail: Credits usage breakdown
    """
    html: str
    raw_html: str
    markdown: str
    links: List[str]
    metadata: Metadata
    screenshot: str
    summary: str
    json: Any
    traffic_bytes: int
    credits_used: int
    credits_detail: CreditsDetail


class ScrapeResponse(TypedDict):
    """
    Response from successful synchronous scrape.

    Attributes:
        scrape_id: Unique scrape identifier
        endpoint: API endpoint used
        version: API version
        status: Scrape status ('completed' or 'failed')
        url: Scraped URL
        data: Scraped data
        started_at: Start timestamp (ISO 8601)
        ended_at: End timestamp (ISO 8601)
        total_credits_used: Total credits consumed
    """
    scrape_id: str
    endpoint: str
    version: str
    status: Literal['completed', 'failed']
    url: str
    data: ScrapeData
    started_at: str
    ended_at: str
    total_credits_used: int


class ScrapeAsyncResponse(TypedDict):
    """
    Response from asynchronous scrape initiation.

    Attributes:
        scrape_id: Unique scrape identifier
        endpoint: API endpoint used
        version: API version
        status: Initial status ('pending')
    """
    scrape_id: str
    endpoint: str
    version: str
    status: Literal['pending']


class JobStatusResponse(TypedDict, total=False):
    """
    Response from job status check.

    Attributes:
        scrape_id: Unique scrape identifier
        endpoint: API endpoint used
        version: API version
        status: Job status
        url: Scraped URL (when available)
        data: Scraped data (when completed)
        started_at: Start timestamp (ISO 8601)
        ended_at: End timestamp (ISO 8601)
        message: Status message (for errors)
    """
    scrape_id: str
    endpoint: str
    version: str
    status: Literal['pending', 'crawling', 'completed', 'failed']
    url: str
    data: ScrapeData
    started_at: str
    ended_at: str
    message: str


# ==================== Search API Types ====================

class SerpOptions(TypedDict, total=False):
    """
    Google SERP advanced search options.

    Attributes:
        q: Search query (overrides top-level query)
        location: Region parameter (overrides top-level location)
        uule: Encoded location (takes precedence over location)
        google_domain: Google domain to use
        gl: Country code
        hl: Language code (overrides top-level language)
        cr: Multi-country restriction
        lr: Multi-language restriction
        safe: Adult content filter (1=Active, 2=Off)
        nfpr: Disable spelling correction
        filter: Enable/disable result filtering
        tbs: Advanced search parameters
        start: Result offset
        num: Number of results (overrides top-level limit)
        ludocid: Google CID
        lsig: Additional Google Place ID
        kgmid: Google Knowledge Graph ID
        si: Cached Search Parameters ID
        ibp: Element rendering parameter
        uds: Filter parameter string
        no_cache: Disable caching
    """
    q: str
    location: str
    uule: str
    google_domain: str
    gl: str
    hl: str
    cr: str
    lr: str
    safe: int
    nfpr: bool
    filter: bool
    tbs: str
    start: int
    num: int
    ludocid: str
    lsig: str
    kgmid: str
    si: str
    ibp: str
    uds: str
    no_cache: bool


class SearchOptions(TypedDict, total=False):
    """
    Search API options.

    Attributes:
        query: Search query (required)
        location: Region (country/city/area name or ISO code)
        language: Search language (ISO 639-1)
        limit: Maximum number of results (1-100)
        serp_options: Advanced Google SERP parameters
    """
    query: str  # Required, but TypedDict doesn't support required in total=False
    location: str
    language: str
    limit: int
    serp_options: SerpOptions


class SearchData(TypedDict, total=False):
    """
    Search results data.

    Attributes:
        ads: Ads section
        immersive_products: Shopping/immersive products section
        knowledge_graph: Knowledge graph block
        local_map: Local map block
        organic_results: Main organic results
        pagination: Pagination information
        related_questions: Related questions list
        search_information: Search info block
        search_metadata: Metadata about the SERP
        search_parameters: Parameters used for the search
        refine_this_search: Refine-this-search suggestions
        credits_used: Credits consumed for this search
        credits_detail: Credits usage breakdown
    """
    ads: List[Dict[str, Any]]
    immersive_products: List[Dict[str, Any]]
    knowledge_graph: Dict[str, Any]
    local_map: Dict[str, Any]
    organic_results: List[Dict[str, Any]]
    pagination: Dict[str, Any]
    related_questions: List[Dict[str, Any]]
    search_information: Dict[str, Any]
    search_metadata: Dict[str, Any]
    search_parameters: Dict[str, Any]
    refine_this_search: List[Dict[str, Any]]
    credits_used: int
    credits_detail: CreditsDetail


class SearchResponse(TypedDict):
    """
    Response from search API.

    Attributes:
        search_id: Unique search identifier
        endpoint: API endpoint used
        version: API version
        status: Search status ('completed')
        query: Search query
        data: Search results data
        started_at: Start timestamp (ISO 8601)
        ended_at: End timestamp (ISO 8601)
        total_credits_used: Total credits consumed
    """
    search_id: str
    endpoint: str
    version: str
    status: Literal['completed']
    query: str
    data: SearchData
    started_at: str
    ended_at: str
    total_credits_used: int


# ==================== Map API Types ====================

class MapOptions(TypedDict, total=False):
    """
    Map API options.

    Attributes:
        url: Site URL (required)
        filter: Regex pattern to filter URLs
        limit: Maximum number of URLs (1-100000)
        include_subdomains: Include subdomain URLs
        ignore_query_parameters: Ignore URLs with query parameters
    """
    url: str  # Required
    filter: str
    limit: int
    include_subdomains: bool
    ignore_query_parameters: bool


class MapData(TypedDict, total=False):
    """
    Map results data.

    Attributes:
        links: List of URLs found
        total_links: Total number of links
        credits_used: Credits consumed for this map
        credits_detail: Credits usage breakdown
    """
    links: List[str]
    total_links: int
    credits_used: int
    credits_detail: CreditsDetail


class MapResponse(TypedDict):
    """
    Response from map API.

    Attributes:
        map_id: Unique map identifier
        endpoint: API endpoint used
        version: API version
        status: Map status ('completed')
        url: Site URL
        data: Map data with links
        started_at: Start timestamp (ISO 8601)
        ended_at: End timestamp (ISO 8601)
        total_credits_used: Total credits consumed
    """
    map_id: str
    endpoint: str
    version: str
    status: Literal['completed']
    url: str
    data: MapData
    started_at: str
    ended_at: str
    total_credits_used: int


# ==================== Crawl API Types ====================

class CrawlerConfig(TypedDict, total=False):
    """
    Crawler configuration.

    Attributes:
        limit: Maximum pages to crawl
        include: URL patterns to include (regex)
        exclude: URL patterns to exclude (regex)
        max_depth: Maximum crawl depth
        include_entire_domain: Crawl entire domain (not just subpaths)
        include_subdomains: Include subdomain links
        include_external_links: Include external domain links
        sitemaps: Use site sitemap
    """
    limit: int
    include: List[str]
    exclude: List[str]
    max_depth: int
    include_entire_domain: bool
    include_subdomains: bool
    include_external_links: bool
    sitemaps: bool


class CrawlOptions(TypedDict, total=False):
    """
    Crawl API options.

    Attributes:
        url: Entry URL (required)
        crawler: Crawler configuration
        proxy: Proxy configuration
        request: Request configuration
        js_render: JavaScript rendering configuration
        output: Output format configuration
        webhook: Webhook configuration
    """
    url: str  # Required
    crawler: CrawlerConfig
    proxy: ProxyConfig
    request: RequestConfig
    js_render: JsRenderConfig
    output: OutputConfig
    webhook: WebhookConfig


class CrawlResponse(TypedDict):
    """
    Response from crawl API initiation.

    Attributes:
        crawl_id: Unique crawl identifier
        endpoint: API endpoint used
        version: API version
        status: Initial status ('pending')
    """
    crawl_id: str
    endpoint: str
    version: str
    status: Literal['pending']


class CrawlPageData(TypedDict, total=False):
    """
    Data for a single crawled page.

    Attributes:
        url: Page URL
        data: Scraped data for this page
    """
    url: str
    data: ScrapeData


class CrawlStatusResponse(TypedDict, total=False):
    """
    Response from crawl status check.

    Attributes:
        crawl_id: Unique crawl identifier
        endpoint: API endpoint used
        version: API version
        status: Crawl status
        url: Entry URL (when available)
        data: Crawled pages data (when completed)
        started_at: Start timestamp (ISO 8601)
        ended_at: End timestamp (ISO 8601)
        total_credits_used: Total credits consumed
        message: Status message (for errors)
    """
    crawl_id: str
    endpoint: str
    version: str
    status: Literal['pending', 'crawling', 'completed', 'failed']
    url: str
    data: List[CrawlPageData]
    started_at: str
    ended_at: str
    total_credits_used: int
    message: str


# ==================== Legacy/Compatibility Types ====================

class BalanceResponse(TypedDict):
    """
    Account balance response (legacy).

    Attributes:
        balance: Account balance
        currency: Currency code
    """
    balance: float
    currency: str


class OrderResponse(TypedDict):
    """
    Order response (legacy).

    Attributes:
        orderId: Order identifier
        status: Order status
    """
    orderId: str
    status: str
