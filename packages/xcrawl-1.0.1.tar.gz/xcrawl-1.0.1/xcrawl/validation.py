"""
Parameter validation functions for XCrawl SDK.
"""

import re
from typing import Any, Dict, Optional
from urllib.parse import urlparse

from .errors import XcrawlError
from .types import ScrapeOptions, SearchOptions, MapOptions, CrawlOptions


def validate_url(url: str) -> None:
    """
    Validate URL format.

    Args:
        url: URL to validate

    Raises:
        XcrawlError: If URL is invalid or uses unsupported protocol
    """
    if not url or not isinstance(url, str) or not url.strip():
        raise XcrawlError('INVALID_PARAMS', 'url is required and must be a non-empty string')

    try:
        parsed = urlparse(url)
        if parsed.scheme not in ('http', 'https'):
            raise XcrawlError(
                'INVALID_PARAMS',
                f'url must use http or https protocol, got: {parsed.scheme}:'
            )
        if not parsed.netloc:
            raise XcrawlError(
                'INVALID_PARAMS',
                f'Invalid URL format: "{url}". URL must be a complete HTTP/HTTPS address (e.g., "https://example.com")'
            )
    except ValueError as e:
        raise XcrawlError(
            'INVALID_PARAMS',
            f'Invalid URL format: "{url}". URL must be a complete HTTP/HTTPS address (e.g., "https://example.com")'
        )


def _validate_proxy_config(proxy: Any) -> None:
    if not isinstance(proxy, dict):
        raise XcrawlError('INVALID_PARAMS', 'proxy must be a dictionary')

    if 'location' in proxy:
        if not isinstance(proxy['location'], str):
            raise XcrawlError('INVALID_PARAMS', 'proxy.location must be a string')
        if len(proxy['location']) != 2:
            raise XcrawlError(
                'INVALID_PARAMS',
                f'proxy.location must be a 2-letter ISO-3166-1 alpha-2 country code (e.g., "US", "JP"), got: "{proxy["location"]}"'
            )

    if 'sticky_session' in proxy and not isinstance(proxy['sticky_session'], str):
        raise XcrawlError('INVALID_PARAMS', 'proxy.sticky_session must be a string')


def _validate_request_config(request: Any) -> None:
    if not isinstance(request, dict):
        raise XcrawlError('INVALID_PARAMS', 'request must be a dictionary')

    if 'device' in request and request['device'] not in ('desktop', 'mobile'):
        raise XcrawlError('INVALID_PARAMS', f'request.device must be "desktop" or "mobile", got: "{request["device"]}"')

    if 'locale' in request and not isinstance(request['locale'], str):
        raise XcrawlError('INVALID_PARAMS', 'request.locale must be a string')

    if 'cookies' in request and not isinstance(request['cookies'], dict):
        raise XcrawlError('INVALID_PARAMS', 'request.cookies must be a dictionary')

    if 'headers' in request and not isinstance(request['headers'], dict):
        raise XcrawlError('INVALID_PARAMS', 'request.headers must be a dictionary')

    boolean_fields = ['only_main_content', 'block_ads', 'skip_tls_verification']
    for field in boolean_fields:
        if field in request and not isinstance(request[field], bool):
            raise XcrawlError('INVALID_PARAMS', f'request.{field} must be a boolean, got: {type(request[field]).__name__}')


def _validate_js_render_config(js_render: Any) -> None:
    if not isinstance(js_render, dict):
        raise XcrawlError('INVALID_PARAMS', 'js_render must be a dictionary')

    if 'enabled' in js_render and not isinstance(js_render['enabled'], bool):
        raise XcrawlError('INVALID_PARAMS', f'js_render.enabled must be a boolean, got: {type(js_render["enabled"]).__name__}')

    if 'wait_until' in js_render:
        valid_values = ['load', 'domcontentloaded', 'networkidle']
        if js_render['wait_until'] not in valid_values:
            raise XcrawlError(
                'INVALID_PARAMS',
                f'js_render.wait_until must be one of: {", ".join(valid_values)}, got: "{js_render["wait_until"]}"'
            )

    if 'viewport' in js_render:
        viewport = js_render['viewport']
        if not isinstance(viewport, dict):
            raise XcrawlError('INVALID_PARAMS', 'js_render.viewport must be a dictionary')
        if 'width' in viewport:
            if not isinstance(viewport['width'], int) or viewport['width'] <= 0:
                raise XcrawlError('INVALID_PARAMS', f'js_render.viewport.width must be a positive integer, got: {viewport["width"]}')
        if 'height' in viewport:
            if not isinstance(viewport['height'], int) or viewport['height'] <= 0:
                raise XcrawlError('INVALID_PARAMS', f'js_render.viewport.height must be a positive integer, got: {viewport["height"]}')


def _validate_output_config(output: Any) -> None:
    if not isinstance(output, dict):
        raise XcrawlError('INVALID_PARAMS', 'output must be a dictionary')

    if 'formats' in output:
        if not isinstance(output['formats'], list):
            raise XcrawlError('INVALID_PARAMS', 'output.formats must be a list')

        valid_formats = ['html', 'raw_html', 'markdown', 'links', 'summary', 'screenshot', 'json']
        for fmt in output['formats']:
            if fmt not in valid_formats:
                raise XcrawlError(
                    'INVALID_PARAMS',
                    f'Invalid output format: "{fmt}". Valid formats are: {", ".join(valid_formats)}'
                )

    if 'screenshot' in output and output['screenshot'] not in ('full_page', 'viewport'):
        raise XcrawlError('INVALID_PARAMS', f'output.screenshot must be "full_page" or "viewport", got: "{output["screenshot"]}"')

    if 'json' in output:
        json_config = output['json']
        if not isinstance(json_config, dict):
            raise XcrawlError('INVALID_PARAMS', 'output.json must be a dictionary')
        if 'prompt' in json_config and not isinstance(json_config['prompt'], str):
            raise XcrawlError('INVALID_PARAMS', 'output.json.prompt must be a string')
        if 'json_schema' in json_config and not isinstance(json_config['json_schema'], dict):
            raise XcrawlError('INVALID_PARAMS', 'output.json.json_schema must be a dictionary')


def _validate_webhook_config(webhook: Any) -> None:
    if not isinstance(webhook, dict):
        raise XcrawlError('INVALID_PARAMS', 'webhook must be a dictionary')

    if 'url' in webhook:
        if not isinstance(webhook['url'], str):
            raise XcrawlError('INVALID_PARAMS', 'webhook.url must be a string')

        try:
            parsed = urlparse(webhook['url'])
            if parsed.scheme not in ('http', 'https'):
                raise XcrawlError('INVALID_PARAMS', f'webhook.url must use http or https protocol, got: {parsed.scheme}:')
        except ValueError:
            raise XcrawlError('INVALID_PARAMS', f'Invalid webhook.url format: "{webhook["url"]}"')

    if 'headers' in webhook and not isinstance(webhook['headers'], dict):
        raise XcrawlError('INVALID_PARAMS', 'webhook.headers must be a dictionary')

    if 'events' in webhook:
        events = webhook['events']
        if not isinstance(events, list):
            raise XcrawlError('INVALID_PARAMS', 'webhook.events must be a list')

        valid_events = ['started', 'completed', 'failed']
        for event in events:
            if event not in valid_events:
                raise XcrawlError(
                    'INVALID_PARAMS',
                    f'Invalid webhook event: "{event}". Valid events are: {", ".join(valid_events)}'
                )


def validate_scrape_options(options: Optional[ScrapeOptions]) -> None:
    """
    Validate scrape options.

    Args:
        options: Scrape options to validate

    Raises:
        XcrawlError: If any option is invalid
    """
    # If no options, skip validation
    if not options:
        return

    if not isinstance(options, dict):
        raise XcrawlError('INVALID_PARAMS', 'options must be a dictionary')

    # Validate mode
    if 'mode' in options and options['mode'] not in ('sync', 'async'):
        raise XcrawlError('INVALID_PARAMS', f'mode must be "sync" or "async", got: "{options["mode"]}"')

    proxy = options.get('proxy')
    if proxy is not None:
        _validate_proxy_config(proxy)

    # Validate request
    request = options.get('request')
    if request is not None:
        _validate_request_config(request)

    # Validate js_render
    js_render = options.get('js_render')
    if js_render is not None:
        _validate_js_render_config(js_render)

    # Validate output
    output = options.get('output')
    if output is not None:
        _validate_output_config(output)

    # Validate webhook
    webhook = options.get('webhook')
    if webhook is not None:
        _validate_webhook_config(webhook)


JOB_ID_PATTERN = re.compile(r'^[A-Za-z0-9_-]{1,128}$')


def validate_job_id(job_id: str) -> None:
    """
    Validate job ID format.

    Args:
        job_id: Job ID to validate

    Raises:
        XcrawlError: If job ID is invalid
    """
    if not job_id or not isinstance(job_id, str) or not job_id.strip():
        raise XcrawlError('INVALID_PARAMS', 'job_id is required and must be a non-empty string')

    if not JOB_ID_PATTERN.match(job_id):
        raise XcrawlError(
            'INVALID_PARAMS',
            'job_id must only contain letters, numbers, underscores, or hyphens (e.g., "f9f2c9d3-d00c-47ff-a280-f4fa5bf796fd")'
        )


def validate_crawl_id(crawl_id: str) -> None:
    """
    Validate crawl ID format.

    Args:
        crawl_id: Crawl ID to validate

    Raises:
        XcrawlError: If crawl ID is invalid
    """
    if not crawl_id or not isinstance(crawl_id, str) or not crawl_id.strip():
        raise XcrawlError('INVALID_PARAMS', 'crawl_id is required and must be a non-empty string')


def validate_search_options(options: SearchOptions) -> None:
    """
    Validate search options.

    Args:
        options: Search options to validate

    Raises:
        XcrawlError: If any option is invalid
    """
    if not options or not isinstance(options, dict):
        raise XcrawlError('INVALID_PARAMS', 'options must be a dictionary')

    # query is required
    if 'query' not in options or not isinstance(options['query'], str) or not options['query'].strip():
        raise XcrawlError('INVALID_PARAMS', 'query is required and must be a non-empty string')

    # Validate location
    if 'location' in options and not isinstance(options['location'], str):
        raise XcrawlError('INVALID_PARAMS', 'location must be a string')

    # Validate language
    if 'language' in options and not isinstance(options['language'], str):
        raise XcrawlError('INVALID_PARAMS', 'language must be a string')

    # Validate limit
    if 'limit' in options:
        if not isinstance(options['limit'], int) or options['limit'] < 1 or options['limit'] > 100:
            raise XcrawlError('INVALID_PARAMS', 'limit must be an integer between 1 and 100')

    # Validate serp_options
    if 'serp_options' in options:
        serp_opts = options['serp_options']
        if not isinstance(serp_opts, dict):
            raise XcrawlError('INVALID_PARAMS', 'serp_options must be a dictionary')

        # Validate integer fields
        if 'safe' in serp_opts:
            if not isinstance(serp_opts['safe'], int) or serp_opts['safe'] not in (1, 2):
                raise XcrawlError('INVALID_PARAMS', 'serp_options.safe must be 1 or 2')

        if 'start' in serp_opts:
            if not isinstance(serp_opts['start'], int) or serp_opts['start'] < 0:
                raise XcrawlError('INVALID_PARAMS', 'serp_options.start must be a non-negative integer')

        if 'num' in serp_opts:
            if not isinstance(serp_opts['num'], int) or serp_opts['num'] < 1 or serp_opts['num'] > 100:
                raise XcrawlError('INVALID_PARAMS', 'serp_options.num must be an integer between 1 and 100')

        # Validate boolean fields
        boolean_fields = ['nfpr', 'filter', 'no_cache']
        for field in boolean_fields:
            if field in serp_opts and not isinstance(serp_opts[field], bool):
                raise XcrawlError('INVALID_PARAMS', f'serp_options.{field} must be a boolean')


def validate_map_options(options: MapOptions) -> None:
    """
    Validate map options.

    Args:
        options: Map options to validate

    Raises:
        XcrawlError: If any option is invalid
    """
    if not options or not isinstance(options, dict):
        raise XcrawlError('INVALID_PARAMS', 'options must be a dictionary')

    # url is required
    if 'url' not in options:
        raise XcrawlError('INVALID_PARAMS', 'url is required')
    validate_url(options['url'])

    # Validate filter (regex pattern)
    if 'filter' in options:
        if not isinstance(options['filter'], str):
            raise XcrawlError('INVALID_PARAMS', 'filter must be a string (regex pattern)')
        try:
            re.compile(options['filter'])
        except re.error as e:
            raise XcrawlError('INVALID_PARAMS', f'filter must be a valid regex pattern: {e}')

    # Validate limit
    if 'limit' in options:
        if not isinstance(options['limit'], int) or options['limit'] < 1 or options['limit'] > 100000:
            raise XcrawlError('INVALID_PARAMS', 'limit must be an integer between 1 and 100000')

    # Validate boolean fields
    boolean_fields = ['include_subdomains', 'ignore_query_parameters']
    for field in boolean_fields:
        if field in options and not isinstance(options[field], bool):
            raise XcrawlError('INVALID_PARAMS', f'{field} must be a boolean')


def validate_crawl_options(options: CrawlOptions) -> None:
    """
    Validate crawl options.

    Args:
        options: Crawl options to validate

    Raises:
        XcrawlError: If any option is invalid
    """
    if not options or not isinstance(options, dict):
        raise XcrawlError('INVALID_PARAMS', 'options must be a dictionary')

    # url is required
    if 'url' not in options:
        raise XcrawlError('INVALID_PARAMS', 'url is required')
    validate_url(options['url'])

    # Validate crawler config
    if 'crawler' in options:
        crawler = options['crawler']

        if not isinstance(crawler, dict):
            raise XcrawlError('INVALID_PARAMS', 'crawler must be a dictionary')

        # Validate limit
        if 'limit' in crawler:
            if not isinstance(crawler['limit'], int) or crawler['limit'] < 1:
                raise XcrawlError('INVALID_PARAMS', 'crawler.limit must be a positive integer')

        # Validate include/exclude arrays
        array_fields = ['include', 'exclude']
        for field in array_fields:
            if field in crawler:
                if not isinstance(crawler[field], list):
                    raise XcrawlError('INVALID_PARAMS', f'crawler.{field} must be a list')
                for pattern in crawler[field]:
                    if not isinstance(pattern, str):
                        raise XcrawlError('INVALID_PARAMS', f'crawler.{field} must be a list of strings')

        # Validate max_depth
        if 'max_depth' in crawler:
            if not isinstance(crawler['max_depth'], int) or crawler['max_depth'] < 1:
                raise XcrawlError('INVALID_PARAMS', 'crawler.max_depth must be a positive integer')

        # Validate boolean fields
        boolean_fields = [
            'include_entire_domain',
            'include_subdomains',
            'include_external_links',
            'sitemaps'
        ]
        for field in boolean_fields:
            if field in crawler and not isinstance(crawler[field], bool):
                raise XcrawlError('INVALID_PARAMS', f'crawler.{field} must be a boolean')

    proxy = options.get('proxy')
    if proxy is not None:
        _validate_proxy_config(proxy)

    request = options.get('request')
    if request is not None:
        _validate_request_config(request)

    js_render = options.get('js_render')
    if js_render is not None:
        _validate_js_render_config(js_render)

    output = options.get('output')
    if output is not None:
        _validate_output_config(output)

    webhook = options.get('webhook')
    if webhook is not None:
        _validate_webhook_config(webhook)
