class DecoderError(Exception):
    pass
