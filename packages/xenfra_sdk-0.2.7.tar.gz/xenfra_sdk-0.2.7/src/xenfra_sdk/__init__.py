# This file makes src/xenfra_sdk a Python package.

from .client import XenfraClient
from .engine import InfraEngine
from .events import BuildEvent, DeploymentPhase, EventEmitter, EventStatus
from .exceptions import AuthenticationError, DeploymentError, XenfraAPIError, XenfraError
from .protocol import ProtocolRegistry
from .models import (
    BalanceRead,
    CodebaseAnalysisResponse,
    DiagnosisResponse,
    DropletCostRead,
    PatchObject,
    ProjectRead,
)

# Microservices & Config support
from .manifest import (
    XenfraConfig,
    load_xenfra_config,
    ServiceDefinition,
    load_services_from_xenfra_yaml,
    is_microservices_project,
    get_deployment_mode,
    add_services_to_xenfra_yaml,
    create_services_from_detected,
)
from .detection import (
    auto_detect_services,
    detect_docker_compose_services,
    detect_pyproject_services,
)
from .orchestrator import (
    ServiceOrchestrator,
    get_orchestrator_for_project,
)

# Security
from .security_scanner import (
    scan_directory,
    scan_file_list,
    ScanResult,
    SecurityIssue,
    Severity,
)

# Railpack Integration
from .railpack_detector import (
    RailpackDetector,
    RailpackDetectionResult,
    EnvVariable,
    get_railpack_detector,
)
from .railpack_manager import (
    RailpackManager,
    get_railpack_manager,
)
from .railpack_adapter import (
    RailpackAdapter,
    RailpackPlan,
)

__all__ = [
    "XenfraClient",
    "XenfraError",
    "AuthenticationError",
    "XenfraAPIError",
    "DiagnosisResponse",
    "CodebaseAnalysisResponse",
    "PatchObject",
    "ProjectRead",
    "BalanceRead",
    "DropletCostRead",
    # Config
    "XenfraConfig",
    "load_xenfra_config",
    # Microservices
    "ServiceDefinition",
    "load_services_from_xenfra_yaml",
    "is_microservices_project",
    "get_deployment_mode",
    "add_services_to_xenfra_yaml",
    "create_services_from_detected",
    "auto_detect_services",
    "detect_docker_compose_services",
    "detect_pyproject_services",
    "ServiceOrchestrator",
    "get_orchestrator_for_project",
    "InfraEngine",
    "DeploymentError",
    "ProtocolRegistry",
    "EventEmitter",
    "BuildEvent",
    "DeploymentPhase",
    "EventStatus",
    # Railpack Integration
    "RailpackDetector",
    "RailpackDetectionResult",
    "EnvVariable",
    "get_railpack_detector",
    "RailpackManager",
    "get_railpack_manager",
    "RailpackAdapter",
    "RailpackPlan",
]
