import yaml
from abc import ABC, abstractmethod
from typing import Dict, List, Optional
from pathlib import Path

from xenfra_sdk.blueprints.schema import (
    DeploymentBlueprintManifest, DockerfileModel, ComposeModel, ServiceDetail,
    DeployModel, DeployResourcesModel, ResourceLimitsModel, ResourceReservationsModel
)

from xenfra_sdk.constants import DEFAULT_PORT_RANGE_START

class BaseBlueprint(ABC):
    """
    Abstract base class for all Xenfra Blueprints (Build Packs).
    
    A Blueprint is responsible for:
    1. Analyzing code to detect requirements.
    2. Building a valid Pydantic manifest.
    3. Rendering that manifest to files (Dockerfile, compose, env).
    """

    def __init__(self, context: dict):
        self.context = context
        self.framework = context.get("framework")
        self.port = context.get("port") or DEFAULT_PORT_RANGE_START
        self.file_manifest = context.get("file_manifest", [])
        self.resource_limits = context.get("resource_limits", {})

    def _generate_deploy_model(self) -> DeployModel:
        """Centralized helper for resource governance."""
        return DeployModel(
            resources=DeployResourcesModel(
                limits=ResourceLimitsModel(
                    memory=self.resource_limits.get("memory", "512m"),
                    cpus=self.resource_limits.get("cpus", "0.5"),
                ),
                reservations=ResourceReservationsModel(
                    memory=self.resource_limits.get("memory_reserved", "128m"),
                    cpus=self.resource_limits.get("cpus_reserved", "0.25"),
                ),
            )
        )

    @abstractmethod
    def generate_manifest(self) -> DeploymentBlueprintManifest:
        """Analyze context and files to build the Pydantic manifest."""
        pass

    def render(self) -> Dict[str, str]:
        """Renders the generated manifest into final deployment strings."""
        manifest = self.generate_manifest()
        result = {}

        # 1. Render Dockerfile
        result["Dockerfile"] = self._render_dockerfile(manifest.dockerfile)

        # 2. Render docker-compose.yml
        result["docker-compose.yml"] = self._render_compose(manifest.compose)

        # 3. Render .env
        if manifest.env_file:
            result[".env"] = "\n".join([f'{k}="{v}"' for k, v in manifest.env_file.items()])

        # 4. Render Caddyfile (if provided)
        if manifest.caddyfile:
            result["Caddyfile"] = manifest.caddyfile

        # 5. Render Railpack Plan (if provided)
        if hasattr(manifest, "railpack_plan") and manifest.railpack_plan:
            result["railpack-plan.json"] = manifest.railpack_plan

        return result

    def _render_dockerfile(self, model: DockerfileModel) -> str:
        """Converts DockerfileModel to a string."""
        lines = [f"FROM {model.base_image}"]
        
        # Inject ARG instructions (Build-time variables)
        # Must come after FROM (usually) or before depending on if they affect FROM
        # Standard practice: FROM -> ARG -> WORKDIR -> COPY -> RUN
        if model.args:
            for arg in model.args:
                lines.append(f"ARG {arg}")

        # APT packages
        if model.system_packages:
            packages = " ".join(model.system_packages)
            lines.append("RUN apt-get update && apt-get install -y " + packages + " && rm -rf /var/lib/apt/lists/*")

        lines.append(f"WORKDIR {model.workdir}")

        # Env vars (Non-secret defaults only)
        # We rely on .env + docker-compose for actual deployment values.
        # ARGs are already available during build.
        arg_keys = set(model.args)
        for k, v in model.env_vars.items():
            if k in arg_keys:
                # Skip ENV if it's already an ARG, to keep secrets out of Dockerfile and fix syntax errors
                continue
            # Quote values for safety
            lines.append(f'ENV {k}="{v}"')

        # Copy commands
        if model.copy_dirs:
            for d in model.copy_dirs:
                lines.append(f"COPY {d} .")
        else:
            lines.append("COPY . .")

        # Custom RUN commands
        for cmd in model.run_commands:
            lines.append(f"RUN {cmd}")

        if model.expose_port:
            lines.append(f"EXPOSE {model.expose_port}")

        if model.entrypoint:
            if isinstance(model.entrypoint, list):
                ep = ", ".join([f'"{x}"' for x in model.entrypoint])
                lines.append(f"ENTRYPOINT [{ep}]")
            else:
                lines.append(f"ENTRYPOINT {model.entrypoint}")

        if model.command:
            if isinstance(model.command, list):
                cmd = ", ".join([f'"{x}"' for x in model.command])
                lines.append(f"CMD [{cmd}]")
            else:
                lines.append(f"CMD {model.command}")

        return "\n".join(lines)

    def _render_compose(self, model: ComposeModel) -> str:
        """Converts ComposeModel to a YAML string."""
        # We use a custom dumper to ensure services come first etc if needed
        # But standard yaml works for start
        data = model.model_dump(by_alias=True, exclude_none=True)
        return yaml.dump(data, sort_keys=False, default_flow_style=False)

    def has_file(self, filename: str) -> bool:
        """Helper to check if a file exists in the manifest."""
        return any(f.get("path") == filename for f in self.file_manifest)

    def get_file_content(self, filename: str) -> Optional[str]:
        """Helper to get file content from manifest."""
        for f in self.file_manifest:
            if f.get("path") == filename:
                return f.get("content")
        return None
