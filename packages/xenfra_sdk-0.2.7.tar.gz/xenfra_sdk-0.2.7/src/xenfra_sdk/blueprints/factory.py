from typing import Type, Dict, List
from xenfra_sdk.blueprints.base import BaseBlueprint
from xenfra_sdk.blueprints.python import PythonBlueprint
from xenfra_sdk.blueprints.node import NodeBlueprint
from xenfra_sdk.blueprints.railpack import RailpackBlueprint
from xenfra_sdk.governance import get_resource_limits, ResourceLimits


def resolve_blueprint_class(context: dict) -> Type[BaseBlueprint]:
    """
    The 'Check-In Desk' for manifest generation.
    Decides between Sovereign (Lean) and Specialist (Railpack) paths.
    
    Priority:
    1. Explicit framework selection (user-specified)
    2. File-based detection fallback
    """
    framework = str(context.get("framework", "")).lower().strip()
    file_manifest = context.get("file_manifest", [])
    file_names = {f.get("path") for f in file_manifest}

    # 1. EXPLICIT FRAMEWORK SELECTION (takes priority)
    # If user explicitly selected a framework, respect that choice
    SOVEREIGN_PYTHON = ("python", "fastapi", "flask", "django")
    
    # Modern Node.js frameworks that need railpack (auto-detect + build)
    # These have complex build pipelines that railpack/nixpacks handles better
    RAILPACK_NODE = ("next", "nextjs", "nuxt", "vite", "nestjs", "nest")
    
    # Simple Node.js that can use our lean NodeBlueprint
    # Only for Express-style apps without complex build steps
    SOVEREIGN_NODE = ("express",)
    
    if framework in SOVEREIGN_PYTHON:
        # Check for complex package managers (uv, poetry, pipenv) -> Use Railpack
        if any(f in file_names for f in ("uv.lock", "poetry.lock", "Pipfile.lock")):
            return RailpackBlueprint
        return PythonBlueprint
    
    # Route modern frameworks to RailpackBlueprint
    if framework in RAILPACK_NODE:
        return RailpackBlueprint
    
    # Generic "node" or "nodejs" → check file_manifest for framework hints
    if framework in ("node", "nodejs"):
        # Check for Next.js, Nuxt, etc. config files
        nextjs_configs = {"next.config.js", "next.config.ts", "next.config.mjs"}
        nuxt_configs = {"nuxt.config.js", "nuxt.config.ts"}
        vite_configs = {"vite.config.js", "vite.config.ts"}
        
        if nextjs_configs & file_names or nuxt_configs & file_names or vite_configs & file_names:
            return RailpackBlueprint
        
        # Default to RailpackBlueprint for generic Node.js (safer, handles more cases)
        return RailpackBlueprint
    
    if framework in SOVEREIGN_NODE:
        return NodeBlueprint
        
    # 2. FILE-BASED DETECTION FALLBACK (only if no explicit framework)
    # Check for Python Sovereign Path (Strict Golden Path)
    if "requirements.txt" in file_names and "pyproject.toml" not in file_names:
        return PythonBlueprint
        
    # Check for Node Sovereign Path (Strict Golden Path) 
    # Only for simple Express apps with package-lock.json
    if "package-lock.json" in file_names and "package.json" in file_names:
        # If has modern framework config files, use Railpack
        nextjs_configs = {"next.config.js", "next.config.ts", "next.config.mjs"}
        if nextjs_configs & file_names:
            return RailpackBlueprint
        # Otherwise, still prefer RailpackBlueprint for safety
        return RailpackBlueprint

    # 3. Specialist Path (The Delegate)
    # Handles EVERYTHING else: Rust, Go, Bun, UV, Poetry, etc.
    return RailpackBlueprint


def render_blueprint(context: dict) -> Dict[str, str]:
    """
    Main entry point for manifest generation.
    Resolves the blueprint and renders it to strings.

    ZEN GAP FIX: Automatically injects tier-based resource limits.
    """
    # Inject resource limits if tier is provided but resource_limits isn't
    if "resource_limits" not in context and "tier" in context:
        limits = get_resource_limits(context["tier"])
        context["resource_limits"] = {
            "memory": limits.memory,
            "cpus": limits.cpus,
            "memory_reserved": limits.memory_reserved,
            "cpus_reserved": limits.cpus_reserved,
        }

    blueprint_class = resolve_blueprint_class(context)
    blueprint = blueprint_class(context)
    return blueprint.render()
