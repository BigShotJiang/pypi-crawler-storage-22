import subprocess
import json
from typing import Dict, Any, List
from xenfra_sdk.blueprints.base import BaseBlueprint
from xenfra_sdk.blueprints.schema import DeploymentBlueprintManifest, DockerfileModel, ComposeModel, ServiceDetail


class NodeBlueprint(BaseBlueprint):
    """
    Sovereign Lean Build-Pack for Node.js with Smart Detection.
    
    Detects sub-frameworks: Next.js, Vite, Express, Nest, etc.
    Detects package managers: npm, pnpm, yarn, bun.
    """

    # === PROTOCOL COMPLIANT: Static Recipe Pattern ===
    # No if-else chains - use dictionary-based detection
    PACKAGE_MANAGER_RECIPES = {
        "bun.lockb": {"install": "bun install", "run": "bun run", "binary": "bun"},
        "pnpm-lock.yaml": {"install": "pnpm install", "run": "pnpm run", "binary": "pnpm"},
        "yarn.lock": {"install": "yarn install", "run": "yarn", "binary": "yarn"},
        "package-lock.json": {"install": "npm install", "run": "npm run", "binary": "npm"},
    }

    FRAMEWORK_RECIPES = {
        "next": {
            "build": "{run} build",
            "start": "{run} start",
            "base_image": "node:18-slim",
        },
        "vite": {
            "build": "{run} build",
            "start": "{run} preview",
            "base_image": "node:18-slim",
        },
        "nuxt": {
            "build": "{run} build",
            "start": "node .output/server/index.mjs",
            "base_image": "node:18-slim",
        },
        "express": {
            "build": None,  # Express usually doesn't need build
            "start": "node {entrypoint}",
            "base_image": "node:18-slim",
        },
        "nestjs": {
            "build": "{run} build",
            "start": "node dist/main.js",
            "base_image": "node:18-slim",
        },
    }

    def generate_manifest(self) -> DeploymentBlueprintManifest:
        # Smart Detection: Try nixpacks -> Static Recipes -> Default
        detection = self._detect_node_environment()
        
        # 1. Build Dockerfile
        dockerfile = DockerfileModel(
            base_image=detection["base_image"],
            expose_port=self.port,
            run_commands=detection["run_commands"],
            command=detection["command"],
            env_vars={"PORT": str(self.port)}
        )

        # 2. Build Compose with Resource Governance
        service = ServiceDetail(
            build=".",
            ports=[f"{self.port}:{self.port}"],
            environment={
                **self.context.get("env_vars", {}),
                "PORT": str(self.port),
                "NODE_ENV": "production"
            },
            command=detection["command"],
            deploy=self._generate_deploy_model()
        )

        return DeploymentBlueprintManifest(
            dockerfile=dockerfile,
            compose=ComposeModel(services={"app": service}),
            env_file=self.context.get("env_vars", {})
        )

    def _detect_node_environment(self) -> Dict[str, Any]:
        """
        Multi-stage detection for Node.js projects.
        Stage A: Try nixpacks CLI (most accurate)
        Stage B: Parse package.json for framework/package manager
        Stage C: Default npm start fallback
        """
        file_names = {f.get("path", "") for f in self.file_manifest}
        pkg_json = self._get_package_json()

        # Stage A: Try Railpack CLI (Railway's latest buildpack)
        try:
            result = subprocess.run(
                ["railpack", "plan", ".", "--json"],
                capture_output=True,
                text=True,
                check=True,
                timeout=30
            )
            plan = json.loads(result.stdout)
            phases = plan.get("phases", {})
            
            # Extract nixpacks detection
            build_cmds = phases.get("build", {}).get("cmds", [])
            start_cmd = phases.get("start", {}).get("cmd", "npm start")
            
            return {
                "base_image": "node:18-slim",
                "run_commands": self._build_run_commands(build_cmds),
                "command": start_cmd,
                "detection": "nixpacks"
            }
        except (subprocess.CalledProcessError, FileNotFoundError, 
                subprocess.TimeoutExpired, json.JSONDecodeError):
            pass  # Fall through to Stage B

        # Stage B: Static Recipe Detection
        pkg_manager = self._detect_package_manager(file_names)
        framework = self._detect_node_framework(pkg_json)
        entrypoint = self._detect_entrypoint(pkg_json, file_names)

        # Build commands based on detected framework
        run_prefix = pkg_manager["run"]
        recipe = self.FRAMEWORK_RECIPES.get(framework, {})
        
        build_cmd = recipe.get("build")
        start_cmd = recipe.get("start", "{run} start")
        
        # Format commands with detected values
        if build_cmd:
            build_cmd = build_cmd.format(run=run_prefix)
        start_cmd = start_cmd.format(run=run_prefix, entrypoint=entrypoint)

        run_commands = [
            pkg_manager['install'],  # e.g., "npm install" - renderer adds RUN
        ]
        if build_cmd:
            run_commands.append(build_cmd)  # e.g., "npm run build" - renderer adds RUN

        return {
            "base_image": recipe.get("base_image", "node:18-slim"),
            "run_commands": run_commands,
            "command": start_cmd,
            "detection": f"static:{framework}:{pkg_manager['binary']}"
        }

    def _detect_package_manager(self, file_names: set) -> Dict[str, str]:
        """Detect package manager from lockfile."""
        for lockfile, recipe in self.PACKAGE_MANAGER_RECIPES.items():
            if lockfile in file_names:
                return {**recipe, "lockfile": lockfile}
        # Default to npm
        return {**self.PACKAGE_MANAGER_RECIPES["package-lock.json"], "lockfile": "package*.json"}

    def _detect_node_framework(self, pkg_json: Dict) -> str:
        """Detect Node.js framework from package.json dependencies."""
        deps = {
            **pkg_json.get("dependencies", {}),
            **pkg_json.get("devDependencies", {})
        }
        
        # Priority order for framework detection
        framework_deps = [
            ("next", "next"),
            ("@nestjs/core", "nestjs"),
            ("nuxt", "nuxt"),
            ("vite", "vite"),
            ("express", "express"),
        ]
        
        for dep_name, framework in framework_deps:
            if dep_name in deps:
                return framework
        
        return "express"  # Default assumption for Node.js

    def _detect_entrypoint(self, pkg_json: Dict, file_names: set) -> str:
        """Detect main entrypoint file."""
        # Check package.json main field
        main = pkg_json.get("main")
        if main:
            return main
        
        # Check common entrypoint patterns
        common_entrypoints = ["index.js", "server.js", "app.js", "src/index.js", "src/server.js"]
        for entry in common_entrypoints:
            if entry in file_names:
                return entry
        
        return "index.js"

    def _get_package_json(self) -> Dict:
        """Extract package.json content from file manifest."""
        for f in self.file_manifest:
            if f.get("path") == "package.json":
                content = f.get("content", "{}")
                try:
                    return json.loads(content)
                except json.JSONDecodeError:
                    return {}
        return {}

    def _build_run_commands(self, build_cmds: List[str]) -> List[str]:
        """Format build commands for Dockerfile (without RUN prefix - renderer adds it)."""
        commands = [
            "npm install",  # Renderer adds RUN prefix
        ]
        for cmd in build_cmds:
            if cmd and not cmd.startswith("npm install"):
                commands.append(cmd)  # Renderer adds RUN prefix
        return commands

    def _get_default_command(self) -> str:
        """Return default command for this blueprint."""
        return "npm start"
