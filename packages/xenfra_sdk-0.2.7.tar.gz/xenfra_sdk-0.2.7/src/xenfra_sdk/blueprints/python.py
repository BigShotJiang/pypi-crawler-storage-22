from xenfra_sdk.blueprints.base import BaseBlueprint
from xenfra_sdk.blueprints.schema import DeploymentBlueprintManifest, DockerfileModel, ComposeModel, ServiceDetail
from xenfra_sdk.dockerizer import detect_entrypoint

class PythonBlueprint(BaseBlueprint):
    """
    Sovereign Lean Build-Pack for Python.
    Only handles the 'Golden Path' (requirements.txt).
    """

    def generate_manifest(self) -> DeploymentBlueprintManifest:
        # 1. Deterministic Defaults (with proactive detection)
        base_image = "python:3.11-slim"
        entrypoint = self.context.get("entrypoint")
        if not entrypoint:
            entrypoint = detect_entrypoint(self.file_manifest, framework=self.framework)
        
        command = self.context.get("command")
        if not command:
            if self.framework == "fastapi":
                command = f"uvicorn {entrypoint} --host 0.0.0.0 --port {self.port}"
            elif self.framework == "django":
                # Django typically needs migrations and runs with gunicorn
                app_name = entrypoint.split(":")[0]
                command = f"python manage.py migrate && gunicorn {app_name}.wsgi:application --bind 0.0.0.0:{self.port}"
            elif self.framework == "flask":
                # Flask also runs well with gunicorn
                command = f"gunicorn --bind 0.0.0.0:{self.port} {entrypoint}"
            else:
                py_file = entrypoint.split(":")[0].replace(".", "/") + ".py"
                command = f"python -u {py_file}"
        
        # 2. Build Dockerfile
        dockerfile = DockerfileModel(
            base_image="python:3.11", # Using non-slim for build tools
            expose_port=self.port,
            run_commands=[
                "pip install --upgrade pip",
                "pip install --no-cache-dir -r requirements.txt"
            ],
            command=command.split()
        )

        # 3. Build Compose with Resource Governance
        service = ServiceDetail(
            build=".",
            ports=[f"{self.port}:{self.port}"],
            environment=self.context.get("env_vars", {}),
            command=command,
            deploy=self._generate_deploy_model()
        )

        return DeploymentBlueprintManifest(
            dockerfile=dockerfile,
            compose=ComposeModel(services={"app": service}),
            env_file=self.context.get("env_vars", {})
        )
