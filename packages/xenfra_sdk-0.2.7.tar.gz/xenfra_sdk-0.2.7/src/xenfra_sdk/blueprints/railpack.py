"""
Railpack Blueprint - Auto-detects and builds any language using Railpack.

Railpack is Railway's open-source buildpack that replaces manual Dockerfile
templates with intelligent language detection.
"""

import os
import tempfile
from typing import Optional

from xenfra_sdk.blueprints.base import BaseBlueprint
from xenfra_sdk.blueprints.schema import DeploymentBlueprintManifest
from xenfra_sdk.railpack_manager import get_railpack_manager
from xenfra_sdk.railpack_adapter import RailpackAdapter


class RailpackBlueprint(BaseBlueprint):
    """
    The Universal Blueprint: Uses Railpack for language-agnostic builds.
    
    Railpack auto-detects the project type (Python, Node, Go, Rust, etc.)
    and generates optimized container configurations.
    """

    def generate_manifest(self) -> DeploymentBlueprintManifest:
        """
        Generate deployment manifest using Railpack.
        
        1. Run Railpack prepare on source code
        2. Convert Railpack plan to Xenfra manifest
        3. Return standardized assets
        
        Raises:
            RuntimeError: If Railpack fails to generate valid plan
        """
        source_path = self._get_source_path()
        
        # Get Railpack manager (auto-downloads if needed)
        railpack = get_railpack_manager()
        
        # Create temporary plan file
        with tempfile.NamedTemporaryFile(mode='w', suffix='.json', delete=False) as f:
            plan_path = f.name
        
        try:
            # Run Railpack prepare
            result = railpack.run(
                'prepare', source_path,
                '--plan-out', plan_path,
                cwd=source_path, # CRITICAL: Railpack needs CWD to be project root for proper detection
                capture_output=True,
                text=True,
                check=True
            )
            
            # Load the plan
            import json
            with open(plan_path) as f:
                plan = json.load(f)
            
            # DEBUG: Log the full plan for transparency
            print(f"[RailpackBlueprint] Full JSON Plan:\n{json.dumps(plan, indent=2)}")
            
            # Convert to Xenfra manifest
            adapter = RailpackAdapter(plan, context=self.context)
            manifest = adapter.convert()
            
            # Store detected language in context for later use
            detected_lang = adapter.get_detected_language()
            if detected_lang:
                self.context['detected_language'] = detected_lang
            
            return manifest
            
        except Exception as e:
            raise RuntimeError(f"Railpack failed to generate manifest: {e}")
        finally:
            # Cleanup temp file
            if os.path.exists(plan_path):
                os.unlink(plan_path)
    
    def _get_source_path(self) -> str:
        """Get source code path from context."""
        # Try explicit source path or repo path
        source_path = self.context.get('source_path') or self.context.get('repo_path')
        if source_path:
            return source_path
        
        # Try file manifest to infer path
        file_manifest = self.context.get('file_manifest', [])
        if file_manifest:
            # Assume first file's directory is project root
            first_file = file_manifest[0].get('path', '')
            if first_file:
                return os.path.dirname(first_file) or '.'
        
        # Default to current directory
        return '.'
