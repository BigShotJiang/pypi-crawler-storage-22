import click
import yaml
from rich.console import Console
from rich.table import Table
from rich.panel import Panel
from rich.tree import Tree
from xenfra_sdk import dockerizer
from xenfra_sdk.db.session import create_db_and_tables
from xenfra_sdk.engine import DeploymentError, InfraEngine
from xenfra_sdk.manifest import XenfraConfig, InfrastructureService, load_xenfra_config

console = Console()


@click.group()
@click.pass_context
def main(ctx):
    """
    Xenfra CLI: A 'Zen Mode' infrastructure engine for Python developers.
    """
    try:
        create_db_and_tables()
        ctx.obj = {"engine": InfraEngine()}
        user_info = ctx.obj["engine"].get_user_info()
        console.print(
            f"[bold underline]Xenfra CLI[/bold underline] - Logged in as [green]{user_info.email}[/green]"
        )
    except Exception as e:
        console.print(f"[bold red]CRITICAL ERROR:[/bold red] Failed to initialize engine: {e}")
        exit(1)


@main.command()
@click.pass_context
def init(ctx):
    """Initializes a project by creating a xenfra.yaml configuration file."""
    console.print("\n[bold blue]🔎 INITIALIZING PROJECT (UNIFIED BRAIN)[/bold blue]")

    from xenfra_sdk.detection import auto_detect_services
    
    with console.status("[bold green]Analyzing project with Unified Brain...[/bold green]"):
        detected = auto_detect_services(".")
    
    if not detected:
        console.print("[yellow]   Warning: No services detected in this repository.[/yellow]")
        if not click.confirm("   Do you want to continue with a blank configuration?"):
            return
        services = []
        infrastructure = []
    else:
        # Construct config from detected services
        from xenfra_sdk.manifest import create_services_from_detected
        services = create_services_from_detected(detected)
        
        # Simple infrastructure inference (Migrated from discovery.py logic)
        infrastructure = []
        found_infra = set()
        for svc in detected:
            if svc.get("is_infrastructure"):
                found_infra.add(svc["framework"]) # Basic mapping
        
        # Display detected services
        table = Table(title="Detected Services", show_header=True, header_style="bold cyan")
        table.add_column("Service Name", style="bold")
        table.add_column("Tier", style="dim")
        table.add_column("Framework", style="green")
        table.add_column("Port", style="magenta")
        
        for svc in services:
            table.add_row(svc.name, svc.tier, svc.framework, str(svc.port))
        
        console.print(table)

    # Project Name
    config_name = Path(".").resolve().name
    project_name = click.prompt("\n   Project Name", default=config_name)
    
    config = XenfraConfig(
        name=project_name,
        services=services,
        infrastructure=infrastructure
    )

    # Commit to file
    config.to_yaml(Path("xenfra.yaml"))

    console.print("\n[bold green]✅ SUCCESS![/bold green]")
    console.print("   - Created [cyan]xenfra.yaml[/cyan] with Unified Brain discovery.")
    console.print("\n   Next step: Review the configuration and run 'xenfra deploy'!")


@main.command()
@click.option("--json", "output_json", is_flag=True, help="Output as JSON for scripting.")
def detect(output_json):
    """Detects the framework and configuration of the current project."""
    console.print("\n[bold blue]🔍 ANALYZING PROJECT[/bold blue]")
    
    detector = get_railpack_detector()
    
    with console.status("[bold green]Running Railpack detection...[/bold green]"):
        result = detector.detect_from_path(".")
    
    if output_json:
        import json
        click.echo(json.dumps({
            "framework": result.framework,
            "confidence": result.confidence,
            "detected_from": result.detected_from,
            "package_manager": result.package_manager,
            "runtime_version": result.runtime_version,
            "start_command": result.start_command,
            "detected_port": result.detected_port,
            "runtime_name": result.runtime_name,
            "build_commands": result.build_commands
        }, indent=2))
    else:
        if result.framework == "unknown":
            console.print("[yellow]⚠️  Could not detect framework.[/yellow]")
            console.print("[dim]   Try running from a project root with recognizable files.[/dim]")
        else:
            tree = Tree(f"[bold green]{result.framework.upper()}[/bold green]")
            
            if result.runtime_name:
                tree.add(f"[blue]Runtime:[/blue] {result.runtime_name}")
            if result.runtime_version:
                tree.add(f"[blue]Version:[/blue] {result.runtime_version}")
            if result.package_manager:
                tree.add(f"[magenta]Package Manager:[/magenta] {result.package_manager}")
            if result.detected_port:
                tree.add(f"[yellow]Port:[/yellow] {result.detected_port}")
            if result.start_command:
                tree.add(f"[cyan]Start Command:[/cyan] {result.start_command}")
            if result.build_commands:
                build_tree = tree.add("[dim]Build Steps:[/dim]")
                for cmd in result.build_commands:
                    build_tree.add(f"[dim]→ {cmd}[/dim]")
            
            tree.add(f"[dim]Confidence:[/dim] {result.confidence}")
            tree.add(f"[dim]Detected From:[/dim] {result.detected_from}")
            
            console.print(tree)
            
            console.print("\n[dim]Tip: Run 'xenfra init --railpack' to create config from this detection.[/dim]")


@main.command()
@click.option("--skip-local", is_flag=True, help="Skip the mandatory local mirroring check (Not recommended for Free Tier).")
@click.option("--dry-run", is_flag=True, help="Generate assets without deploying.")
@click.option("--env-file", type=click.Path(exists=True), help="Path to .env file to load environment variables.")
@click.pass_context
def deploy(ctx, skip_local, dry_run, env_file):
    """Deploys the project based on the xenfra.yaml configuration."""
    console.print("\n[bold green]🚀 INITIATING DEPLOYMENT FROM CONFIGURATION[/bold green]")

    config = load_xenfra_config(".")
    if not config:
        raise click.ClickException(
            "No 'xenfra.yaml' found. Run 'xenfra init' to create a configuration file."
        )

    engine = ctx.obj["engine"]

    # Extract config values from Pydantic model
    name = config.name
    do_config = config.digitalocean
    region = do_config.region
    size = do_config.size
    image = do_config.image

    # Load environment variables from file if provided
    env_vars = {}
    if env_file:
        from xenfra_sdk.railpack_detector import RailpackDetector
        detector = RailpackDetector()
        with open(env_file) as f:
            content = f.read()
        parsed = detector.parse_env_content(content)
        env_vars = {v.key: v.value for v in parsed}
        console.print(f"   - Loaded [cyan]{len(env_vars)}[/cyan] variables from [cyan]{env_file}[/cyan]")

    # Build context for templates (handle infrastructure)
    # Note: Modern engine uses InfrastructureService models
    template_context = {
        "email": ctx.obj["engine"].get_user_info().email,
        "mode": config.mode,
        "env_vars": env_vars
    }
    
    # Map infrastructure for templates
    for infra in config.infrastructure:
        template_context[f"include_{infra.type}"] = True
        # For backwards compatibility with original simple logic
        if infra.type == "postgres":
            template_context["database"] = "postgres"
            template_context["db_user"] = infra.env_vars.get("user", "db_user")
            template_context["db_password"] = infra.env_vars.get("password", "db_password")
            template_context["db_name"] = infra.env_vars.get("name", "app_db")

    # Handle services (microservices or single)
    if config.services:
        template_context["services"] = config.services
        # Use first service framework as primary
        primary_service = config.services[0]
        template_context["framework"] = primary_service.framework
        template_context["port"] = primary_service.port
        console.print(f"   - Framework: [cyan]{primary_service.framework}[/cyan]")

    console.print(f"   - App Name: [cyan]{name}[/cyan]")
    console.print(f"   - Region: [cyan]{region}[/cyan], Size: [cyan]{size}[/cyan]")
    if config.infrastructure:
        infra_names = [i.type for i in config.infrastructure]
        console.print(f"   - Including Infrastructure: [cyan]{', '.join(infra_names)}[/cyan]")

    if dry_run:
        console.print("\n[bold yellow]🧪 DRY RUN MODE - Generating assets only[/bold yellow]")
    
    if not click.confirm(f"\n   Ready to deploy '{name}' from 'xenfra.yaml'?"):
        return

    with console.status("[bold green]Deployment in progress...[/bold green]"):
        result = engine.deploy_server(
            name=name, 
            region=region, 
            size=size, 
            image=image, 
            logger=console.log, 
            verify_local=not skip_local,
            dry_run=dry_run,
            **template_context
        )

    if dry_run:
        console.print("\n[bold yellow]🧪 DRY RUN COMPLETE[/bold yellow]")
        if isinstance(result, dict) and "assets" in result:
            console.print("\n[bold cyan]Generated Assets:[/bold cyan]")
            for filename, content in result["assets"].items():
                console.print(f"\n[bold]{filename}:[/bold]")
                console.print(f"[dim]{content[:500]}{'...' if len(content) > 500 else ''}[/dim]")
    else:
        console.print("\n[bold green]✅ DEPLOYMENT COMPLETE![/bold green]")
        console.print(result)


@main.command(name="list")
@click.option("--refresh", is_flag=True, help="Sync with the cloud provider before listing.")
@click.pass_context
def list_projects(ctx, refresh):
    """Lists all active Xenfra projects from the local database."""
    engine = ctx.obj["engine"]

    if refresh:
        console.print("\n[bold]📡 SYNCING WITH CLOUD PROVIDER...[/bold]")
        with console.status("Calling DigitalOcean API and reconciling state..."):
            projects = engine.sync_with_provider()
    else:
        console.print("\n[bold]⚡️ LISTING PROJECTS FROM LOCAL DATABASE[/bold]")
        projects = engine.list_projects_from_db()

    if not projects:
        console.print(
            "[yellow]   No active projects found. Run 'xenfra deploy' to create one.[/yellow]"
        )
    else:
        table = Table(show_header=True, header_style="bold magenta")
        table.add_column("Droplet ID", style="dim", width=12)
        table.add_column("Name", style="cyan")
        table.add_column("IP Address", style="green")
        table.add_column("Status")
        table.add_column("Region")
        table.add_column("Size")
        for p in projects:
            table.add_row(str(p.droplet_id), p.name, p.ip_address, p.status, p.region, p.size)
        console.print(table)


@main.command(name="logs")
@click.pass_context
def logs(ctx):
    """Streams real-time logs from a deployed project."""
    engine = ctx.obj["engine"]

    console.print("\n[bold yellow]📡 SELECT A PROJECT TO STREAM LOGS[/bold yellow]")
    projects = engine.list_projects_from_db()

    if not projects:
        console.print("[yellow]   No active projects to stream logs from.[/yellow]")
        return

    project_map = {str(i + 1): p for i, p in enumerate(projects)}
    for k, p in project_map.items():
        console.print(f"   [{k}] {p.name} ({p.ip_address})")

    choice_key = click.prompt(
        "\n   Select Project (0 to cancel)",
        type=click.Choice(["0"] + list(project_map.keys())),
        show_choices=False,
    )
    if choice_key == "0":
        return

    target = project_map[choice_key]

    try:
        console.print(
            f"\n[bold green]-- Attaching to logs for {target.name} (Press Ctrl+C to stop) --[/bold green]"
        )
        engine.stream_logs(target.droplet_id)
    except DeploymentError as e:
        console.print(f"[bold red]ERROR:[/bold red] {e.message}")
    except KeyboardInterrupt:
        console.print("\n[bold yellow]-- Log streaming stopped by user. --[/bold yellow]")
    except Exception as e:
        console.print(f"[bold red]An unexpected error occurred:[/bold red] {e}")


@main.command()
@click.pass_context
def destroy(ctx):
    """Destroys a deployed project."""
    engine = ctx.obj["engine"]

    console.print("\n[bold red]🧨 SELECT A PROJECT TO DESTROY[/bold red]")
    projects = engine.list_projects_from_db()

    if not projects:
        console.print("[yellow]   No active projects to destroy.[/yellow]")
        return

    project_map = {str(i + 1): p for i, p in enumerate(projects)}
    for k, p in project_map.items():
        console.print(f"   [{k}] {p.name} ({p.ip_address})")

    choice_key = click.prompt(
        "\n   Select Project to DESTROY (0 to cancel)",
        type=click.Choice(["0"] + list(project_map.keys())),
        show_choices=False,
    )
    if choice_key == "0":
        return

    target = project_map[choice_key]

    if click.confirm(
        f"   Are you SURE you want to permanently delete [red]{target.name}[/red] (Droplet ID: {target.droplet_id})? This action cannot be undone."
    ):
        with console.status(f"💥 Destroying {target.name}..."):
            engine.destroy_server(target.droplet_id)
        console.print(f"[green]   Project '{target.name}' has been destroyed.[/green]")


if __name__ == "__main__":
    main()
