"""
Centralized registry for Xenfra SDK defaults and constants.
Follows XENFRA_PROTOCOL.md by eliminating hardcoded strings in logic.
"""

from typing import Final

# Infrastructure Defaults
DEFAULT_REGION: Final[str] = "nyc3"
DEFAULT_SIZE: Final[str] = "s-1vcpu-1gb"
DEFAULT_OS: Final[str] = "ubuntu-22-04-x64"
DEFAULT_SSH_KEY_PATH: Final[str] = "~/.ssh/id_rsa"
DEFAULT_SSH_PUB_KEY_PATH: Final[str] = "~/.ssh/id_rsa.pub"

# Tiered Droplet Sizing (Microservice Orchestration)
SIZE_LIGHT: Final[str] = "s-1vcpu-2gb"      # 1-2 services
SIZE_MEDIUM: Final[str] = "s-2vcpu-4gb"     # 3-5 services
SIZE_HEAVY: Final[str] = "s-4vcpu-8gb"      # 6+ services

# Framework Defaults
DEFAULT_PYTHON_VERSION: Final[str] = "3.11-slim"
DEFAULT_NODE_VERSION: Final[str] = "18-slim"

# Protocol Limits
MAX_SERVICES_PER_PROJECT: Final[int] = 20
DEFAULT_PORT_RANGE_START: Final[int] = 8000
