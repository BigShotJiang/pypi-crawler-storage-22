# src/xenfra/db/session.py

import os
from pathlib import Path

import click
from sqlmodel import Session, SQLModel, create_engine

# Get the app directory for the current user
app_dir = Path(click.get_app_dir("xenfra"))
app_dir.mkdir(parents=True, exist_ok=True)
db_path = app_dir / "xenfra.db"

# For now, we will use a simple SQLite database for ease of setup.
# In production, this should be a PostgreSQL database URL from environment variables.
DATABASE_URL = os.getenv("DATABASE_URL", f"sqlite:///{db_path}")

# Only echo SQL in development (set SQL_ECHO=1 to enable)
SQL_ECHO = os.getenv("SQL_ECHO", "0") == "1"

engine = create_engine(
    DATABASE_URL,
    echo=SQL_ECHO,
    pool_pre_ping=True,
    pool_recycle=300
)


def create_db_and_tables():
    SQLModel.metadata.create_all(engine)


def get_session():
    with Session(engine) as session:
        yield session
