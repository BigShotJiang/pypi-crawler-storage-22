import json
import re
from abc import ABC, abstractmethod
from pathlib import Path
from typing import Dict, List, Optional, Any

import yaml


class DetectionResult:
    """Standardized result for service detection."""
    def __init__(
        self, 
        name: str, 
        path: str, 
        tier: str, # "backend", "frontend", "agent"
        framework: str, 
        entrypoint: Optional[str] = None,
        command: Optional[str] = None,
        port: int = 8000,
        package_manager: str = "pip",
        dependency_file: str = "requirements.txt",
        missing_deps: List[str] = None,
        required_secrets: List[str] = None,
        is_infrastructure: bool = False
    ):
        self.name = name
        self.path = path
        self.tier = tier
        self.framework = framework
        self.entrypoint = entrypoint
        self.command = command
        self.port = port
        self.package_manager = package_manager
        self.dependency_file = dependency_file
        self.missing_deps = missing_deps or []
        self.required_secrets = required_secrets or []
        self.is_infrastructure = is_infrastructure

    def to_dict(self) -> dict:
        return {
            "name": self.name,
            "path": self.path,
            "tier": self.tier,
            "framework": self.framework,
            "entrypoint": self.entrypoint,
            "command": self.command,
            "port": self.port,
            "package_manager": self.package_manager,
            "dependency_file": self.dependency_file,
            "missing_deps": self.missing_deps,
            "required_secrets": self.required_secrets,
            "is_infrastructure": self.is_infrastructure,
        }


class DetectionRegistry:
    """Registry of prioritized probes for service detection."""
    _service_probes: List[tuple] = []
    
    # Infrastructure indicators (Ported from discovery.py)
    INFRA_INDICATORS = {
        "kafka": [r"kafka-python", r"confluent-kafka", r"aiokafka"],
        "redis": [r"redis", r"aioredis"],
        "postgres": [r"psycopg2", r"asyncpg", r"sqlalchemy", r"sqlmodel"],
        "mongodb": [r"pymongo", r"motor"],
    }
    
    @classmethod
    def infer_infrastructure_from_services(cls, services: List[DetectionResult]) -> List[DetectionResult]:
        """Scans service dependencies to suggest infrastructure components."""
        found_infra_types = set()
        for svc in services:
            svc_path = Path(svc.path)
            for dep_file in ["requirements.txt", "package.json", "go.mod", "Cargo.toml", "pyproject.toml"]:
                fpath = svc_path / dep_file
                if not fpath.exists(): continue
                content = fpath.read_text(errors="ignore")
                for infra_type, patterns in cls.INFRA_INDICATORS.items():
                    for pattern in patterns:
                        if re.search(pattern, content, re.IGNORECASE):
                            found_infra_types.add(infra_type)
        
        infra_results = []
        for itype in found_infra_types:
            infra_results.append(DetectionResult(
                name=f"{itype}-cluster",
                path="",
                tier="infrastructure",
                framework=itype,
                is_infrastructure=True
            ))
        return infra_results

    @classmethod
    def register_service_probe(cls, priority: int):
        """Decorator to register a detail probe (e.g. Python, Railpack)."""
        def decorator(probe_cls):
            cls._service_probes.append((priority, probe_cls()))
            cls._service_probes.sort(key=lambda x: x[0])
            return probe_cls
        return decorator

    @classmethod
    def detect_service_details(cls, service_dir: Path, name: str) -> Optional[DetectionResult]:
        """Run all registered service detail probes in priority order."""
        for priority, probe in cls._service_probes:
            result = probe.detect(service_dir, name)
            if result:
                return result
        return None


@DetectionRegistry.register_service_probe(priority=0)
class RailpackProbe:
    """Uses Railway's Railpack for high-fidelity service detection."""
    def detect(self, service_dir: Path, name: str) -> Optional[DetectionResult]:
        try:
            from xenfra_sdk.railpack_detector import get_railpack_detector
            detector = get_railpack_detector()
            # Railpack's fallback logic is already decent, but we use it here
            rp_result = detector.detect_from_path(str(service_dir))
            
            if not rp_result or rp_result.framework == "unknown":
                return None
                
            return DetectionResult(
                name=name,
                path=str(service_dir),
                tier="frontend" if rp_result.runtime_name == "node" and rp_result.framework in ["nextjs", "react"] else "backend",
                framework=rp_result.framework,
                command=rp_result.start_command,
                port=rp_result.detected_port or 8000,
                package_manager=rp_result.package_manager or "pip",
                dependency_file=rp_result.detected_from,
                missing_deps=_scan_proactive_dependencies(service_dir)
            )
        except Exception:
            return None


@DetectionRegistry.register_service_probe(priority=1)
class FrameworkProbe:
    """Static file-based detection for common frameworks."""
    def detect(self, service_dir: Path, name: str) -> Optional[DetectionResult]:
        # Python Check
        has_pyproject = (service_dir / "pyproject.toml").exists()
        has_requirements = (service_dir / "requirements.txt").exists()
        if has_pyproject or has_requirements:
            return self._detect_python(service_dir, name, has_pyproject)

        # Node Check
        if (service_dir / "package.json").exists():
            return self._detect_node(service_dir, name)

        # Go Check
        if (service_dir / "go.mod").exists():
            return self._detect_go(service_dir, name)

        return None

    def _detect_python(self, service_dir, name, has_pyproject):
        content = ""
        if has_pyproject:
            content = (service_dir / "pyproject.toml").read_text(errors="ignore").lower()
        else:
            content = (service_dir / "requirements.txt").read_text(errors="ignore").lower()

        tier = "backend"
        framework = "fastapi"
        if any(lib in content for lib in ["mcp", "langgraph", "crewai", "langchain"]):
            tier = "agent"
            framework = "mcp" if "mcp" in content else "langgraph"
        elif "django" in content: framework = "django"
        elif "flask" in content: framework = "flask"

        return DetectionResult(
            name=name,
            path=str(service_dir),
            tier=tier,
            framework=framework,
            entrypoint=_detect_python_entrypoint(service_dir, name),
            package_manager="uv" if has_pyproject else "pip",
            dependency_file="pyproject.toml" if has_pyproject else "requirements.txt",
            missing_deps=_scan_proactive_dependencies(service_dir)
        )

    def _detect_node(self, service_dir, name):
        try:
            config = json.loads((service_dir / "package.json").read_text())
            deps = {**config.get("dependencies", {}), **config.get("devDependencies", {})}
            tier = "frontend" if any(l in deps for l in ["next", "react", "vue"]) else "backend"
            framework = "nextjs" if "next" in deps else ("express" if "express" in deps else "node")
            return DetectionResult(
                name=name, path=str(service_dir), tier=tier, framework=framework,
                package_manager="npm", dependency_file="package.json",
                port=3000 if tier == "frontend" else 8000
            )
        except Exception: return None

    def _detect_go(self, service_dir, name):
        content = (service_dir / "go.mod").read_text(errors="ignore").lower()
        framework = "gin" if "gin-gonic" in content else ("echo" if "echo" in content else "go-std")
        return DetectionResult(
            name=name, path=str(service_dir), tier="backend", framework=framework,
            package_manager="go", dependency_file="go.mod"
        )


class TopLevelRegistry:
    """Registry of high-level probes (e.g. Docker Compose, Recursive Search)."""
    _top_probes: List[tuple] = []
    
    @classmethod
    def register(cls, priority: int):
        def decorator(probe_cls):
            cls._top_probes.append((priority, probe_cls()))
            cls._top_probes.sort(key=lambda x: x[0])
            return probe_cls
        return decorator

    @classmethod
    def auto_detect(cls, project_path: Path) -> List[DetectionResult]:
        """Execute top-level probes in order and return results from the first one that succeeds."""
        for priority, probe in cls._top_probes:
            results = probe.scan(project_path)
            if results:
                return results
        return []


@TopLevelRegistry.register(priority=0)
class DockerComposeProbe:
    """Detects services from docker-compose.yml files."""
    def scan(self, project_path: Path) -> List[DetectionResult]:
        candidates = ["docker-compose.prod.yml", "docker-compose.prod.yaml", "docker-compose.yml", "docker-compose.yaml"]
        compose_path = next((project_path / c for c in candidates if (project_path / c).exists()), None)
        if not compose_path: return []
        
        try:
            with open(compose_path, "r", encoding="utf-8") as f:
                compose = yaml.safe_load(f)
            if not compose or "services" not in compose: return []
        except Exception: return []
        
        results = []
        for name, config in compose.get("services", {}).items():
            if _is_infrastructure_service(name, config): continue
            
            build_config = config.get("build", ".")
            build_path = build_config.get("context", ".") if isinstance(build_config, dict) else str(build_config)
            src_path = (project_path / build_path).resolve()
            
            # Use detail probes to identify what's inside the build context
            res = DetectionRegistry.detect_service_details(src_path, name)
            if res:
                res.path = build_path # Keep relative path from compose
                res.port = _extract_port(config.get("ports", []), config.get("expose", []), res.port)
                results.append(res)
            else:
                # Fallback for unrecognized services
                results.append(DetectionResult(
                    name=name, path=build_path, tier="backend", framework="other",
                    port=_extract_port(config.get("ports", []), config.get("expose", []), 8000)
                ))
        return results


@TopLevelRegistry.register(priority=1)
class RecursiveScannerProbe:
    """Consolidated recursive scanner (ports logic from discovery.py)."""
    def scan(self, project_path: Path) -> List[DetectionResult]:
        results = []
        project_root = project_path.resolve()
        
        # Scan standard directories first
        for dir_name in ["services", "apps"]:
            s_dir = project_root / dir_name
            if not s_dir.exists(): continue
            for subdir in [d for d in s_dir.iterdir() if d.is_dir()]:
                if subdir.name.startswith((".", "_")) or subdir.name in {"common", "lib", "assets"}:
                    continue
                res = DetectionRegistry.detect_service_details(subdir, subdir.name)
                if res:
                    res.path = f"./{dir_name}/{subdir.name}"
                    results.append(res)

        # If still nothing, do a deeper recursive scan (Option: discovery.py logic)
        if not results:
            results = self._deep_scan(project_root, project_root)
            
        return results

    def _deep_scan(self, path: Path, root: Path) -> List[DetectionResult]:
        # Implementation similar to discovery.py but using Detail Probes
        if path.name.startswith(".") or path.name in ["venv", "node_modules", "target", "build", "dist"]:
            return []
            
        res = DetectionRegistry.detect_service_details(path, path.name)
        if res and path != root:
            res.path = str(path.relative_to(root))
            return [res]
            
        results = []
        if path.is_dir():
            for item in path.iterdir():
                if item.is_dir():
                    results.extend(self._deep_scan(item, root))
        return results


def auto_detect_services(project_path: str = ".") -> Optional[List[dict]]:
    """Try all detection methods in priority order using the Unified Brain."""
    path = Path(project_path)
    results = TopLevelRegistry.auto_detect(path)
    if results:
        infra = DetectionRegistry.infer_infrastructure_from_services(results)
        results.extend(infra)
        return [r.to_dict() for r in results]
    return None


# --- Legacy Wrappers (Backward Compatibility) ---

def detect_docker_compose_services(project_path: str = ".") -> List[dict]:
    """Wrapper for DockerComposeProbe."""
    probe = DockerComposeProbe()
    results = probe.scan(Path(project_path))
    return [r.to_dict() for r in results]


def detect_pyproject_services(project_path: str = ".") -> List[dict]:
    """Wrapper for RecursiveScannerProbe."""
    probe = RecursiveScannerProbe()
    results = probe.scan(Path(project_path))
    return [r.to_dict() for r in results]


# --- Helper Functions (Internal) ---

def _is_infrastructure_service(name: str, config: dict) -> bool:
    infra_names = {"db", "database", "postgres", "mysql", "redis", "mongo", "mongodb", 
                   "elasticsearch", "rabbitmq", "kafka", "zookeeper", "memcached", "nginx"}
    if name.lower() in infra_names: return True
    image = config.get("image", "")
    return any(infra in image.lower() for infra in infra_names)


def _extract_port(ports: list, expose: list, default: int) -> int:
    # 1. Check 'ports' (published ports)
    if ports:
        port_str = str(ports[0])
        if isinstance(ports[0], dict): return int(ports[0].get("published", default))
        match = re.match(r"(\d+):", port_str)
        if match: return int(match.group(1))
        if port_str.isdigit(): return int(port_str)
    
    # 2. Check 'expose' (internal only)
    if expose:
        port_str = str(expose[0])
        if port_str.isdigit(): return int(port_str)
        
    return default


def _detect_python_entrypoint(service_dir: Path, service_name: str = None) -> Optional[str]:
    """Internal helper for PythonProbe."""
    candidates = [
        ("main.py", "main:app"),
        ("app.py", "app:app"),
        ("api.py", "api:app"),
        ("wsgi.py", "wsgi:application"),
        ("asgi.py", "asgi:application"),
    ]
    
    for filename, entrypoint in candidates:
        if (service_dir / filename).exists(): return entrypoint
    
    for container_name in ["src", "app", "services"]:
        container_dir = service_dir / container_name
        if container_dir.exists() and container_dir.is_dir():
            if service_name:
                svc_subdir = container_dir / service_name
                if svc_subdir.exists():
                    for f, s in candidates:
                        if (svc_subdir / f).exists(): return f"{container_name}.{service_name}.{s}"

            for subdir in container_dir.iterdir():
                if subdir.is_dir() and not subdir.name.startswith((".", "__")):
                    for f, s in candidates:
                        if (subdir / f).exists(): return f"{container_name}.{subdir.name}.{s}"
    
    for subdir in service_dir.iterdir():
        if subdir.is_dir() and not subdir.name.startswith((".", "__", "src", "app", "services", "venv", ".venv")):
            for f, s in candidates:
                if (subdir / f).exists(): return f"{subdir.name}.{s}"

    return _discover_entrypoint_by_content(service_dir)


def _scan_proactive_dependencies(service_dir: Path) -> List[str]:
    """
    Scan source code for framework-specific requirements that are often missed.
    Example: FastAPI Form/File/OAuth2 requirements.
    """
    missing = []
    patterns = [
        (r"\b(?:Form|File|OAuth2PasswordRequestForm)\b", "python-multipart"),
    ]
    
    excludes = {".venv", "venv", "tests", "__pycache__", "node_modules", ".git"}
    
    # Speed check: Read main files first
    for py_file in service_dir.rglob("*.py"):
        if any(ex in py_file.parts for ex in excludes):
            continue
            
        try:
            content = py_file.read_text(encoding="utf-8", errors="ignore")
            for pattern, dep in patterns:
                if dep not in missing and re.search(pattern, content):
                    # Check if it's already in the project's dependency files
                    if not _is_dep_already_present(service_dir, dep):
                        missing.append(dep)
        except Exception:
            continue
            
    return missing


def _is_dep_already_present(service_dir: Path, dep: str) -> bool:
    """Check if a dependency is already listed in pyproject.toml or requirements.txt."""
    for filename in ["pyproject.toml", "requirements.txt"]:
        fpath = service_dir / filename
        if fpath.exists():
            try:
                if dep.lower() in fpath.read_text().lower():
                    return True
            except Exception:
                pass
    return False


def _discover_entrypoint_by_content(service_dir: Path) -> Optional[str]:
    patterns = [
        (r"(\w+)\s*=\s*(?:fastapi\.)?FastAPI\(", "{module}:{var}"),
        (r"(\w+)\s*=\s*(?:flask\.)?Flask\(", "{module}:{var}"),
        (r"application\s*=\s*get_wsgi_application\(", "{module}:application"),
        (r"application\s*=\s*get_asgi_application\(", "{module}:application"),
    ]
    excludes = {".venv", "venv", "tests", "__pycache__", "node_modules", ".git", ".xenfra"}
    
    for py_file in service_dir.rglob("*.py"):
        if any(ex in py_file.parts for ex in excludes): continue
        try:
            content = py_file.read_text(encoding="utf-8", errors="ignore")
            for pattern, template in patterns:
                match = re.search(pattern, content)
                if match:
                    try:
                        rel_path = py_file.relative_to(service_dir)
                        module_path = ".".join(rel_path.with_suffix("").parts)
                        var_name = match.group(1) if match.groups() else "application"
                        return template.format(module=module_path, var=var_name)
                    except ValueError: continue
        except Exception: continue
    return None
