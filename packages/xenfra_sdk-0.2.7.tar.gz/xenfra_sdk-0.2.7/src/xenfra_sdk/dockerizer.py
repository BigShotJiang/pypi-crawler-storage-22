"""
Xenfra Dockerizer - Generates deployment assets as strings.

This module renders Dockerfile and docker-compose.yml templates
to strings (in-memory) so they can be written to the target droplet via SSH.
"""

from pathlib import Path
from typing import Dict, Optional
import re


def detect_python_version(file_manifest: list = None) -> str:
    """
    Detect Python version from project files.
    
    Checks in order:
    1. .python-version file (e.g., "3.13")
    2. pyproject.toml requires-python field (e.g., ">=3.13")
    
    Args:
        file_manifest: List of file info dicts with 'path' and optionally 'content'
                       If None, uses 3.11 as default.
    
    Returns:
        Docker image version string (e.g., "python:3.13-slim")
    """
    default_version = "python:3.11-slim"
    
    if not file_manifest:
        return default_version
    
    # Build a lookup dict for quick access
    file_lookup = {f.get('path', ''): f for f in file_manifest}
    
    # Option 1: Check .python-version file
    if '.python-version' in file_lookup:
        file_info = file_lookup['.python-version']
        content = file_info.get('content', '')
        if content:
            # Parse version like "3.13" or "3.13.1"
            version = content.strip().split('\n')[0].strip()
            if version:
                # Extract major.minor (e.g., "3.13" from "3.13.1")
                match = re.match(r'(\d+\.\d+)', version)
                if match:
                    return f"python:{match.group(1)}-slim"
    
    # Option 2: Check pyproject.toml requires-python
    if 'pyproject.toml' in file_lookup:
        file_info = file_lookup['pyproject.toml']
        content = file_info.get('content', '')
        if content:
            # Parse requires-python = ">=3.13" or "^3.13"
            match = re.search(r'requires-python\s*=\s*["\']([^"\']+)["\']', content)
            if match:
                version_spec = match.group(1)
                # Extract version number (e.g., "3.13" from ">=3.13")
                version_match = re.search(r'(\d+\.\d+)', version_spec)
                if version_match:
                    return f"python:{version_match.group(1)}-slim"
    
    return default_version


def detect_entrypoint(file_manifest: list = None, framework: str = "fastapi") -> str:
    """
    Detect the correct uvicorn/gunicorn entrypoint from project structure.

    Checks common patterns:
    - main.py in root → main:app
    - app.py in root → app:app
    - src/main.py → src.main:app
    - app/main.py → app.main:app

    Args:
        file_manifest: List of file info dicts with 'path' key
        framework: The framework being used (fastapi, flask, django)

    Returns:
        Entrypoint string (e.g., "main:app", "src.main:app")
    """
    if not file_manifest:
        return "main:app"  # Default fallback

    # Build set of paths for fast lookup
    paths = {f.get('path', '') for f in file_manifest}

    # Check common entrypoint patterns in priority order
    entrypoint_patterns = [
        ("main.py", "main:app"),
        ("app.py", "app:app"),
        ("src/main.py", "src.main:app"),
        ("src/app.py", "src.app:app"),
        ("app/main.py", "app.main:app"),
        ("api/main.py", "api.main:app"),
    ]

    for file_path, entrypoint in entrypoint_patterns:
        if file_path in paths:
            return entrypoint

    # === PROTOCOL COMPLIANT: Framework Recipe Pattern ===
    # Instead of if-else chains, use a dictionary of patterns
    FRAMEWORK_PATTERNS = {
        "django": {
            "file_suffix": "wsgi.py",
            "instance": "application",
            "class_pattern": None,  # Django uses wsgi discovery
        },
        "fastapi": {
            "file_suffix": None,
            "instance": "app",
            "class_pattern": r'([a-zA-Z0-9_]+)\s*=\s*FastAPI\(',
        },
        "flask": {
            "file_suffix": None,
            "instance": "app",
            "class_pattern": r'([a-zA-Z0-9_]+)\s*=\s*Flask\(',
        },
    }

    # Django special case: Look for wsgi.py
    recipe = FRAMEWORK_PATTERNS.get(framework, {})
    if recipe.get("file_suffix"):
        for path in paths:
            if path.endswith(recipe["file_suffix"]):
                module = path.replace("/", ".").replace(".py", "")
                return f"{module}:{recipe['instance']}"

    # === SEARCH & RESCUE: Deep Content Scan ===
    # If filename scan fails, look inside .py files for instantiation
    class_pattern = recipe.get("class_pattern")
    if class_pattern:
        for file_info in file_manifest:
            path = file_info.get('path', '')
            if not path.endswith(".py") or path.startswith("tests/"):
                continue
                
            content = file_info.get('content', '')
            if not content:
                continue

            match = re.search(class_pattern, content)
            if match:
                instance = match.group(1)
                module = path.replace("/", ".").replace(".py", "").replace("src.", "").replace("app.", "")
                return f"{module}:{instance}"

    return "main:app"  # Default fallback

