"""
Xenfra Governance - Tier-Based Resource Limits.

This module defines deterministic resource limits based on user tier.
No AI, no guessing - just tier → limits mapping.
"""

from enum import Enum
from typing import Dict
from pydantic import BaseModel


class UserTier(str, Enum):
    """User subscription tiers."""
    FREE = "FREE"
    JUNIOR_SRE = "JUNIOR_SRE"
    SENIOR_SRE = "SENIOR_SRE"
    PRO = "PRO"  # Alias for JUNIOR_SRE
    ENTERPRISE = "ENTERPRISE"  # Alias for SENIOR_SRE


class ResourceLimits(BaseModel):
    """Docker cgroups resource limits."""
    memory: str = "512m"  # Docker memory limit format
    cpus: float = 0.5  # CPU cores (can be fractional)
    memory_reserved: str = "128m"  # Minimum guaranteed memory
    cpus_reserved: float = 0.25  # Minimum guaranteed CPU


# Tier-based resource limits - deterministic mapping
TIER_RESOURCE_LIMITS: Dict[UserTier, ResourceLimits] = {
    UserTier.FREE: ResourceLimits(
        memory="512m",
        cpus=0.5,
        memory_reserved="128m",
        cpus_reserved=0.25,
    ),
    UserTier.JUNIOR_SRE: ResourceLimits(
        memory="2g",
        cpus=1.0,
        memory_reserved="512m",
        cpus_reserved=0.5,
    ),
    UserTier.SENIOR_SRE: ResourceLimits(
        memory="4g",
        cpus=2.0,
        memory_reserved="1g",
        cpus_reserved=1.0,
    ),
}

# Add aliases for tiers
TIER_RESOURCE_LIMITS[UserTier.PRO] = TIER_RESOURCE_LIMITS[UserTier.JUNIOR_SRE]
TIER_RESOURCE_LIMITS[UserTier.ENTERPRISE] = TIER_RESOURCE_LIMITS[UserTier.SENIOR_SRE]

# Tier-based polling intervals (seconds)
TIER_POLLING_INTERVALS: Dict[UserTier, int] = {
    UserTier.FREE: 150,
    UserTier.JUNIOR_SRE: 60,
    UserTier.SENIOR_SRE: 15,
}
TIER_POLLING_INTERVALS[UserTier.PRO] = TIER_POLLING_INTERVALS[UserTier.JUNIOR_SRE]
TIER_POLLING_INTERVALS[UserTier.ENTERPRISE] = TIER_POLLING_INTERVALS[UserTier.SENIOR_SRE]

# Tier-based node limits
TIER_NODE_LIMITS: Dict[UserTier, int] = {
    UserTier.FREE: 1,
    UserTier.JUNIOR_SRE: 10,
    UserTier.SENIOR_SRE: 25,
}

# Tier-based auto-heal limits (concurrent fixes)
TIER_AUTO_HEAL_LIMITS: Dict[UserTier, int] = {
    UserTier.FREE: 0,  # Manual fixes only
    UserTier.JUNIOR_SRE: 3,  # 3 auto-heal loops
    UserTier.SENIOR_SRE: 10,  # Twin isolation/sandboxing
}


def get_resource_limits(tier: str) -> ResourceLimits:
    """
    Get resource limits for a user tier.

    Args:
        tier: User tier string (FREE, JUNIOR_SRE, SENIOR_SRE)

    Returns:
        ResourceLimits object with cgroups configuration
    """
    try:
        user_tier = UserTier(tier.upper())
    except ValueError:
        # Unknown tier defaults to FREE
        user_tier = UserTier.FREE

    return TIER_RESOURCE_LIMITS[user_tier]


def get_polling_interval(tier: str) -> int:
    """
    Get polling interval for a user tier.

    Args:
        tier: User tier string

    Returns:
        Polling interval in seconds
    """
    try:
        user_tier = UserTier(tier.upper())
    except ValueError:
        user_tier = UserTier.FREE

    return TIER_POLLING_INTERVALS[user_tier]


def get_node_limit(tier: str) -> int:
    """
    Get maximum nodes allowed for a user tier.

    Args:
        tier: User tier string

    Returns:
        Maximum number of nodes
    """
    try:
        user_tier = UserTier(tier.upper())
    except ValueError:
        user_tier = UserTier.FREE

    return TIER_NODE_LIMITS[user_tier]


def get_auto_heal_limit(tier: str) -> int:
    """
    Get auto-heal limit for a user tier.

    Args:
        tier: User tier string

    Returns:
        Maximum concurrent auto-heal operations
    """
    try:
        user_tier = UserTier(tier.upper())
    except ValueError:
        user_tier = UserTier.FREE

    return TIER_AUTO_HEAL_LIMITS[user_tier]
