from pathlib import Path
from typing import List, Literal, Optional, Dict, Any

import yaml
from pydantic import BaseModel, Field, field_validator, ConfigDict

from xenfra_sdk.constants import DEFAULT_REGION, DEFAULT_SIZE, DEFAULT_OS


class ProviderConfig(BaseModel):
    """Configuration for cloud providers (currently DigitalOcean)."""
    region: str = Field(default=DEFAULT_REGION)
    size: str = Field(default=DEFAULT_SIZE)
    image: str = Field(default=DEFAULT_OS)


class InfrastructureService(BaseModel):
    """Managed infrastructure dependency (e.g., PostgreSQL, Kafka)."""
    type: Literal["postgres", "kafka", "redis", "mongodb"]
    name: str
    version: Optional[str] = None
    env_vars: Dict[str, str] = Field(default_factory=dict)


class ServiceDefinition(BaseModel):
    """
    Single service definition in a microservices project.
    """
    model_config = ConfigDict(extra="ignore")
    
    name: str = Field(..., min_length=1, max_length=50, description="Service name (unique)")
    path: str = Field(default=".", description="Relative path to service directory")
    port: int = Field(..., ge=1, le=65535, description="Service port")
    framework: Literal[
        # Python
        "fastapi", "flask", "django", "python",
        # Node.js
        "nodejs", "nextjs", "react", "express", "nestjs",
        # Go
        "go", "gin", "echo",
        # AI Agents
        "langgraph", "crewai", "mcp",
        # Other languages
        "rust", "ruby", "rails", "php", "java",
        # Alternative runtimes
        "bun", "deno",
        # Custom
        "static", "docker", "other"
    ] = Field(
        default="fastapi", description="Web framework"
    )
    entrypoint: Optional[str] = Field(
        default=None, description="Application entrypoint (e.g., 'users_api.main:app')"
    )
    command: Optional[str] = Field(
        default=None, description="Custom start command"
    )
    env: Dict[str, str] = Field(
        default_factory=dict, description="Environment variables"
    )
    package_manager: Optional[str] = Field(
        default="pip", description="Package manager (pip, uv, poetry, pipenv, npm, yarn, pnpm, bun, cargo, go, bundler, composer, maven, gradle)"
    )
    dependency_file: Optional[str] = Field(
        default=None, description="Dependency file"
    )
    
    @field_validator("name")
    @classmethod
    def validate_name(cls, v: str) -> str:
        """Ensure name is URL-safe (alphanumeric + hyphens)."""
        import re
        if not re.match(r'^[a-z][a-z0-9-]*$', v.lower()):
            raise ValueError(
                f"Service name '{v}' must start with a letter and contain only "
                "lowercase letters, numbers, and hyphens"
            )
        return v.lower()


class XenfraConfig(BaseModel):
    """The root configuration model for xenfra.yaml."""
    model_config = ConfigDict(extra="ignore")

    name: str = Field(..., min_length=1, description="Project identity")
    digitalocean: ProviderConfig = Field(default_factory=ProviderConfig)
    infrastructure: List[InfrastructureService] = Field(default_factory=list)
    services: List[ServiceDefinition] = Field(default_factory=list)
    mode: Literal["single-droplet", "multi-droplet"] = Field(default="single-droplet")

    @field_validator("services")
    @classmethod
    def validate_unique_services(cls, services: List[ServiceDefinition]) -> List[ServiceDefinition]:
        """Ensure all service names and ports are unique."""
        names = [s.name for s in services]
        if len(names) != len(set(names)):
            raise ValueError(f"Duplicate service names detected: {set([n for n in names if names.count(n) > 1])}")
        
        ports = [s.port for s in services]
        if len(ports) != len(set(ports)):
            raise ValueError(f"Duplicate service ports detected: {set([p for p in ports if ports.count(p) > 1])}")
            
        return services

    def to_yaml(self, path: Path):
        """Write the config to a YAML file."""
        data = self.model_dump(exclude_none=True)
        with open(path, "w", encoding="utf-8") as f:
            yaml.dump(data, f, default_flow_style=False, sort_keys=False)


def load_xenfra_config(project_path: str = ".") -> Optional[XenfraConfig]:
    """Load and validate the entire xenfra.yaml config."""
    yaml_path = Path(project_path) / "xenfra.yaml"
    if not yaml_path.exists():
        return None
    
    with open(yaml_path, "r", encoding="utf-8") as f:
        try:
            data = yaml.safe_load(f)
            if not data:
                return None
            return XenfraConfig(**data)
        except (yaml.YAMLError, Exception) as e:
            raise ValueError(f"Invalid xenfra.yaml: {e}")


# Legacy helper for backwards compatibility
def load_services_from_xenfra_yaml(project_path: str = ".") -> Optional[List[ServiceDefinition]]:
    config = load_xenfra_config(project_path)
    return config.services if config else None


def is_microservices_project(project_path: str = ".") -> bool:
    """Check if project has multiple services defined in xenfra.yaml."""
    config = load_xenfra_config(project_path)
    return config is not None and len(config.services) > 1


def get_deployment_mode(project_path: str = ".") -> Optional[str]:
    """Get deployment mode from xenfra.yaml."""
    config = load_xenfra_config(project_path)
    return config.mode if config else None


def add_services_to_xenfra_yaml(
    project_path: str,
    services: List[dict],
    mode: str = "single-droplet"
) -> Path:
    """Add or update services array in existing xenfra.yaml."""
    config = load_xenfra_config(project_path)
    if not config:
        # Create new config if missing
        config = XenfraConfig(name=Path(project_path).name, mode=mode)
    
    config.services = [ServiceDefinition(**svc) for svc in services]
    config.mode = mode
    
    yaml_path = Path(project_path) / "xenfra.yaml"
    config.to_yaml(yaml_path)
    return yaml_path


def create_services_from_detected(services: List[dict]) -> List[ServiceDefinition]:
    """Create ServiceDefinition list from detected services."""
    return [ServiceDefinition(**svc) for svc in services]
