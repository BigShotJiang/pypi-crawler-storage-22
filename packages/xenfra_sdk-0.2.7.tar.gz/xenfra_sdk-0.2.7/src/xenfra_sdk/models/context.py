"""
Deployment Context Models - Type-safe configuration for the Xenfra Engine.
Follows XENFRA_PROTOCOL.md by ensuring all data structures are Pydantic models.
"""

from typing import Dict, List, Optional, Any
from pydantic import BaseModel, Field, ConfigDict
from xenfra_sdk.constants import DEFAULT_PORT_RANGE_START, DEFAULT_REGION, DEFAULT_SIZE, DEFAULT_OS


class DeploymentContext(BaseModel):
    """
    Unified context for a single project or service deployment.
    This model serves as the source of truth for all template rendering and 
    infrastructure provisioning.
    """
    model_config = ConfigDict(extra="ignore")

    # Project Identity
    project_name: str = Field(..., description="Name of the project")
    email: str = Field(..., description="User email for SSL/Caddy")
    
    # Infrastructure (Single Droplet Defaults)
    region: str = Field(default=DEFAULT_REGION)
    size: str = Field(default=DEFAULT_SIZE)
    image: str = Field(default=DEFAULT_OS)
    
    # Application Specification
    framework: str = Field(..., description="Web framework (fastapi, flask, django, etc.)")
    port: int = Field(default=DEFAULT_PORT_RANGE_START)
    entrypoint: Optional[str] = Field(None, description="App entrypoint (e.g. main:app)")
    python_version: str = Field(default="3.11-slim")
    
    # Deployment Strategy
    is_dockerized: bool = Field(default=True)
    branch: str = Field(default="main")
    source_type: str = Field(default="local") # local or git
    
    # Environment & Secrets (Scrubbed by default)
    env_vars: Dict[str, str] = Field(default_factory=dict)
    
    # Infrastructure Flags
    include_postgres: bool = Field(default=False)
    include_redis: bool = Field(default=False)
    include_kafka: bool = Field(default=False)
    
    # Resource Governance
    tier: str = Field(default="FREE")
    cpu_limit: Optional[float] = None
    memory_limit: Optional[str] = None
    
    # Internal Metadata
    phase_logs: List[str] = Field(default_factory=list)
    file_manifest: List[Dict[str, Any]] = Field(default_factory=list)
    source_path: Optional[str] = None
    repo_path: Optional[str] = None
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "DeploymentContext":
        """Backwards compatibility helper to convert legacy dicts."""
        return cls(**data)
