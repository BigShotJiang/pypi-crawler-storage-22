"""
Xenfra Protocol Registry - Centralized constants for compliance with XENFRA_PROTOCOL.md.
Eliminates hardcoded strings across SDK and Services.
"""

from typing import Final


class ProtocolRegistry:
    """
    Structured registry for all strings and constants used in the Xenfra stack.
    Satisfies Anti-Pattern #4 (No Hardcoded Constants).
    """
    
    # Log Prefixes
    LOG_PREFIX_INFRA_ENGINE: Final[str] = "[InfraEngine]"
    LOG_PREFIX_ZEN_MODE: Final[str] = "[ZenMode]"
    LOG_PREFIX_AUTO_MIGRATION: Final[str] = "[AutoMigration]"
    
    # Rate Limiting
    RATE_LIMIT_USER_KEY: Final[str] = "user:{}"  # f-string template
    
    # Error Messages
    MIGRATION_FAILED_MSG: Final[str] = "Auto-migration failed"
    IDENTITY_SYNC_FAILED_MSG: Final[str] = "User identity cannot be synced"
    
    # Header Names
    HEADER_USER_ID: Final[str] = "X-User-ID"
    HEADER_USER_EMAIL: Final[str] = "X-User-Email"
    HEADER_REQUEST_ID: Final[str] = "X-Request-ID"

    # JWT Claims
    JWT_ISSUER: Final[str] = "xenfra-sso"
    JWT_AUDIENCE: Final[str] = "xenfra-api"

    # Default Deployment Values
    DEFAULT_DOCKER_IMAGE: Final[str] = "ubuntu-22-04-x64"
    DEFAULT_PORT: Final[int] = 8000
