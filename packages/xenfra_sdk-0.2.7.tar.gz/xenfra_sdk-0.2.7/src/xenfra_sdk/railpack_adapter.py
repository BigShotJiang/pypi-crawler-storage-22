"""Railpack Adapter - Converts Railpack build plans to Xenfra deployment assets."""

import json
import shlex
from dataclasses import dataclass
from typing import Dict, List, Optional, Any

from xenfra_sdk.blueprints.schema import (
    DeploymentBlueprintManifest,
    DockerfileModel,
    ComposeModel,
    ServiceDetail,
    DeployModel,
    DeployResourcesModel,
    ResourceLimitsModel,
    ResourceReservationsModel,
)


@dataclass
class RailpackPlan:
    version: str
    runtime: Dict[str, Any]
    phases: Dict[str, Dict[str, Any]]
    packages: Dict[str, List[str]]
    copy: List[str]
    secrets: List[str]
    caches: Dict[str, Any]
    deploy: Dict[str, Any]
    
    @classmethod
    def from_dict(cls, data: dict):
        return cls(
            version=data.get('version', '1.0'),
            runtime=data.get('runtime', {}),
            phases=data.get('phases', {}),
            packages=data.get('packages', {}),
            copy=data.get('copy', ['.']),
            secrets=data.get('secrets', []),
            caches=data.get('caches', {}),
            deploy=data.get('deploy', {})
        )


class RailpackAdapter:
    def __init__(self, plan: dict, context: Optional[dict] = None):
        self.plan = RailpackPlan.from_dict(plan)
        self.context = context or {}
        self.port = self.context.get('port', 8000)
        self.tier = self.context.get('tier', 'FREE')
    
    def convert(self):
        dockerfile = self._build_dockerfile()
        compose = self._build_compose()
        caddyfile = self._generate_caddyfile()
        return DeploymentBlueprintManifest(
            dockerfile=dockerfile,
            compose=compose,
            env_file=self.context.get('env_vars', {}),
            caddyfile=caddyfile
        )
    
    def _build_dockerfile(self):
        runtime = self.plan.runtime
        phases = self.plan.phases
        
        # 1. Base Image Logic
        # Railpack usually provides a specific base image (e.g. nixpacks).
        # If not, we MUST fallback to a language-specific image, not plain Ubuntu,
        # because the plan might rely on language tools (npm, pip) being present.
        detected_lang = self.get_detected_language()
        default_base = 'ubuntu:22.04'
        
        # Smart Map for Base Images
        BASE_IMAGE_MAP = {
            'node': 'node:20-bullseye', # Bumped to 20 for modern stack (React Email/Resend)
            'python': 'python:3.11-slim', # Includes pip
            'go': 'golang:1.21-bullseye', # Includes go
            'rust': 'rust:1.75-bullseye', # Includes cargo
            'java': 'openjdk:17-slim', # Includes java/javac
            'php': 'php:8.2-apache', # Includes composer (usually)
            'ruby': 'ruby:3.2', # Includes bundle
            'deno': 'denoland/deno:latest',
        }
        
        if detected_lang and detected_lang in BASE_IMAGE_MAP:
            default_base = BASE_IMAGE_MAP[detected_lang]
            
        base_image = runtime.get('image') or default_base
        
        # 2. System Packages (APT)
        # Railpack plans often list required system libs in 'packages' or 'apt'
        system_packages = []
        if self.plan.packages:
            # Handle list format ["libpq-dev"] or dict format {"apt": [...]}
            if isinstance(self.plan.packages, dict):
                system_packages.extend(self.plan.packages.get('apt', []))
                system_packages.extend(self.plan.packages.get('system', []))
            elif isinstance(self.plan.packages, list):
                system_packages.extend(self.plan.packages)
                
        env_vars = {'PORT': str(self.port)}
        
        # Inject Runtime Envs from Plan
        for env in runtime.get('env', []):
            if '=' in env:
                key, value = env.split('=', 1)
                env_vars[key] = value

        # User-Defined Envs from Context
        # We NO LONGER inject these directly into the Dockerfile as ENV/ARG lines
        # to prevent secrets from leaking into image layers and to avoid shell quoting issues.
        # Instead, they are passed via the 'env_file' manifest property and written as a .env file.
        user_envs = self.context.get('env_vars', {})
        if user_envs:
            print(f"[RailpackAdapter] Found {len(user_envs)} user environment variables. These will be written to .env asset.")
        
        run_commands = []
        
        for phase_name in ['setup', 'install', 'build']:
            phase = phases.get(phase_name, {})
            # Handle plural 'cmds' (standard)
            for cmd in phase.get('cmds', []):
                run_commands.append(cmd)
            # Handle singular 'cmd' (potential variance)
            if phase.get('cmd'):
                 run_commands.append(phase.get('cmd'))
        
        # 3. Safety Net: Ensure Dependencies are Installed
        # If Railpack plan was empty (common with some detection edge cases),
        # we must manually ensure dependencies are installed.
        if detected_lang == 'node':
            # Check if we have any install commands
            has_install = any('npm install' in cmd or 'npm ci' in cmd or 'yarn' in cmd or 'pnpm' in cmd for cmd in run_commands)
            
            if not has_install:
                print(f"[RailpackAdapter] ⚠️ Warning: No install command detected for Node. Injecting 'npm install'.")
                run_commands.append("npm install")
                
            # Check for build command if Next.js
            framework = self.context.get('framework', '').lower()
            if "next" in framework:
                has_build = any('build' in cmd for cmd in run_commands)
                if not has_build:
                    print(f"[RailpackAdapter] ⚠️ Warning: No build command detected for Next.js. Injecting 'npm run build'.")
                    run_commands.append("npm run build")
                    
        elif detected_lang == 'python':
            # Check if we have any install commands
            has_install = any('pip install' in cmd or 'poetry install' in cmd or 'uv sync' in cmd or 'pipenv install' in cmd for cmd in run_commands)
            
            if not has_install:
                cache_keys = self.plan.caches.keys()
                print(f"[RailpackAdapter] ⚠️ Warning: No install command detected for Python. Checking caches: {list(cache_keys)}")
                
                if "uv" in cache_keys:
                    # UV requires installation first since we use slim-python image
                    run_commands.append("pip install uv")
                    run_commands.append("uv sync --frozen")
                    print("[RailpackAdapter] Injected 'uv sync'")
                elif "poetry" in cache_keys:
                    run_commands.append("pip install poetry")
                    run_commands.append("poetry config virtualenvs.create false")
                    run_commands.append("poetry install --no-interaction --no-ansi")
                    print("[RailpackAdapter] Injected 'poetry install'")
                elif "pipenv" in cache_keys:
                    run_commands.append("pip install pipenv")
                    run_commands.append("pipenv install --deploy --system")
                    print("[RailpackAdapter] Injected 'pipenv install'")
                else:
                    # Default to pip / requirements.txt
                    run_commands.append("pip install -r requirements.txt")
                    print("[RailpackAdapter] Injected 'pip install -r requirements.txt'")

        start = phases.get('start', {})
        start_cmd = start.get('cmd', '')
        
        if start_cmd:
            # Check if command needs port injection
            if "$PORT" not in start_cmd and "PORT" not in start_cmd:
                # If command doesn't use PORT var, we might need to inject it
                pass
            command = shlex.split(start_cmd)
        else:
            # Smart fallback based on detected language
            lang = detected_lang
            
            # Check for binary output paths (Go/Rust)
            # Railpack 0.17.x puts binaries in specific paths
            deploy_paths = self.plan.deploy.get("paths", {})
            bin_path = deploy_paths.get("bin") or deploy_paths.get("main")
            
            if lang == "node":
                # Check for Next.js specifically
                framework = self.context.get('framework', '').lower()
                if "next" in framework:
                    command = ["npm", "run", "start"]
                else:
                    command = ["npm", "start"]
            elif lang == "python":
                # Check for specific frameworks in context
                framework = self.context.get('framework', '').lower()
                if "django" in framework:
                    app_name = self.context.get('project_name', 'project').split('-')[-1]
                    command = ["sh", "-c", f"python manage.py migrate && gunicorn {app_name}.wsgi:application --bind 0.0.0.0:$PORT"]
                elif "flask" in framework:
                    command = ["sh", "-c", "gunicorn --bind 0.0.0.0:$PORT main:app"]
                elif "fastapi" in framework:
                    command = ["sh", "-c", "uvicorn main:app --host 0.0.0.0 --port $PORT"]
                else:
                    command = ["python", "main.py"]
            elif lang == "go":
                if bin_path:
                    command = [f"./{bin_path}"]
                else:
                    command = ["./main"]
            elif lang == "rust":
                if bin_path:
                    command = [f"./{bin_path}"]
                else:
                    command = ["./target/release/app"]
            elif lang == "bun":
                command = ["bun", "run", "start"]
            else:
                # Fail loudly so the user knows detection failed (vs silent success and immediate exit)
                command = ["sh", "-c", "echo '❌ Error: No start command detected. Please provide an explicit command.' && exit 1"]
        
        # DEBUG: Trace start command decision
        print(f"[RailpackAdapter] Detected lang: {detected_lang}")
        print(f"[RailpackAdapter] Selected start command: {command}")
        
        
        return DockerfileModel(
            base_image=base_image,
            workdir=runtime.get('workdir', '/app'),
            copy_dirs=self.plan.copy,
            run_commands=run_commands,
            env_vars=env_vars,
            args=[],
            expose_port=self.port,
            command=command,
            system_packages=system_packages # Injected system packages
        )
    
    def get_detected_language(self) -> Optional[str]:
        """
        Extract detected language from plan metadata.
        
        Priority:
        1. Runtime Name (The source of truth)
        2. Cache Keys (Reliable indicators)
        3. Variables (Deployment hints)
        """
        # 1. Trust Runtime Name (Primary Source of Truth)
        runtime_name = self.plan.runtime.get('name', '').lower()
        if runtime_name and runtime_name != "unknown":
            print(f"[RailpackAdapter] Runtime name: {runtime_name}")
            return runtime_name
        
        # 2. Check Caches (Reliable Source)
        # Railpack 0.17.x uses specific cache keys for each provider
        caches = self.plan.caches
        cache_keys = set(caches.keys())
        print(f"[RailpackAdapter] Cache keys: {cache_keys}")
        
        if any(k in cache_keys for k in ("next", "node-modules", "npm-install", "yarn", "pnpm", "bun")):
             return 'node'
        if any(k in cache_keys for k in ("python", "pip", "uv", "poetry", "pipenv")):
             return 'python'
        if "go-build" in cache_keys or "go-mod" in cache_keys:
            return 'go'
        if any(k in cache_keys for k in ("cargo", "cargo-cache", "rust")):
            return 'rust'
        if "bundle" in cache_keys or "ruby" in cache_keys:
            return 'ruby'
        if "composer" in cache_keys:
            return 'php'
        if any(k in cache_keys for k in ("maven", "gradle", "java")):
            return 'java'
        if "deno" in cache_keys:
            return 'deno'
        if "static" in cache_keys or "html" in cache_keys:
            return 'static'
            
        # 3. Fallback: Check variables (Deployment hints)
        variables = str(self.plan.deploy.get("variables", {})).lower()
        if "python" in variables:
            return 'python'
        if "node" in variables or "npm" in variables:
            return 'node'
        
        return None
    
    def _build_compose(self):
        from xenfra_sdk.governance import get_resource_limits
        limits = get_resource_limits(self.tier)
        
        env_vars = self.context.get('env_vars', {})
        
        service = ServiceDetail(
            build_context={
                "context": ".",
                "args": list(env_vars.keys())
            },
            ports=[f'{self.port}:{self.port}'],
            # environment=env_vars, # Replaced by env_file for security and syntax safety
            env_file=[".env"],
            deploy=DeployModel(
                resources=DeployResourcesModel(
                    limits=ResourceLimitsModel(
                        memory=limits.memory,
                        cpus=limits.cpus
                    ),
                    reservations=ResourceReservationsModel(
                        memory=limits.memory_reserved,
                        cpus=limits.cpus_reserved
                    )
                )
            )
        )
        
        return ComposeModel(services={'app': service})
    
    def _generate_caddyfile(self) -> str:
        """
        Generate Caddyfile for single-service deployments.
        
        Routes all traffic from port 80 to the application port.
        """
        domain = self.context.get('domain')
        email = self.context.get('email', 'admin@xenfra.tech')
        
        if domain:
            # Production mode with custom domain and TLS
            caddyfile = f"""{domain}:80, {domain}:443 {{
                reverse_proxy app:{self.port}
                tls {email}
            }}

            # Health check endpoint
            :80/health {{
                respond "OK" 200
            }}
            """
        else:
            # Development mode without domain - expose on port 80
            caddyfile = f""":80 {{
                reverse_proxy app:{self.port}
                
                # Health check endpoint
                handle /health {{
                    respond "OK" 200
                }}
            }}
            """
        
        return caddyfile
