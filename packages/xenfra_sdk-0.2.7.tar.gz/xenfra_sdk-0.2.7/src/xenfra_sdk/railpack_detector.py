"""
Railpack Detector Module

Provides intelligent framework detection using Railway's Railpack buildpack.
Railpack analyzes project structure and dependencies to detect language, 
framework, and build configuration.
"""

import json
import os
import re
import subprocess
import tempfile
from pathlib import Path
from typing import Optional, Dict, Any, List
from dataclasses import dataclass
import logging

logger = logging.getLogger(__name__)

@dataclass
class RailpackDetectionResult:
    """Result from Railpack framework detection."""
    framework: str
    confidence: str  # "high", "medium", "low"
    detected_from: str
    package_manager: Optional[str] = None
    runtime_version: Optional[str] = None
    start_command: Optional[str] = None
    detected_port: Optional[int] = None
    build_commands: List[str] = None
    runtime_name: Optional[str] = None
    
    def __post_init__(self):
        if self.build_commands is None:
            self.build_commands = []

@dataclass
class EnvVariable:
    """Environment variable representation."""
    id: str
    key: str
    value: str
    is_secret: bool = False

class RailpackDetector:
    """
    Detects project framework and configuration using Railpack.
    
    Railpack is Railway's open-source buildpack that auto-detects
    languages and generates optimized container configurations.
    """
    
    
    def __init__(self, version: Optional[str] = None):
        """
        Initialize Railpack detector.
        
        Args:
            version: Specific Railpack version.
        """
        from xenfra_sdk.railpack_manager import get_railpack_manager
        self.manager = get_railpack_manager(version)
    
    def detect_from_path(self, project_path: str) -> RailpackDetectionResult:
        """
        Detect framework from a local project path.
        
        Args:
            project_path: Path to project directory.
            
        Returns:
            RailpackDetectionResult with detected framework info.
            
        Raises:
            RuntimeError: If Railpack fails to run.
        """
        # Ensure installed via manager
        binary = self.manager.ensure_installed()
        
        # Create temp file for plan output
        with tempfile.NamedTemporaryFile(mode='w', suffix='.json', delete=False) as f:
            plan_path = f.name
        
        try:
            # Run railpack prepare with absolute path to be safe
            proc_result = subprocess.run(
                [binary, "prepare", project_path, "--plan-out", plan_path],
                cwd=project_path,
                capture_output=True,
                text=True,
                timeout=60
            )
            
            if proc_result.returncode != 0:
                logger.error(f"Railpack prepare failed: {proc_result.stderr}")
                return self._fallback_detection(project_path)
            
            # Parse the plan
            with open(plan_path) as f:
                plan_content = f.read()
                plan = json.loads(plan_content)
            
            result = self._parse_plan(plan)
            
            # If Railpack returns unknown, try our static fallback
            if result.framework == "unknown":
                logger.warning(
                    f"Railpack returned 'unknown' for {project_path}.\n"
                    f"Plan content: {plan_content[:1000]}...\n"
                    f"Stdout: {proc_result.stdout}\n"
                    f"Stderr: {proc_result.stderr}"
                )
                logger.info("Triggering static fallback...")
                return self._fallback_detection(project_path)
                
            return result
            
        except subprocess.TimeoutExpired:
            logger.warning("Railpack prepare timed out")
            return self._fallback_detection(project_path)
        except json.JSONDecodeError as e:
            logger.warning(f"Failed to parse Railpack plan: {e}")
            return self._fallback_detection(project_path)
        except Exception as e:
            logger.warning(f"Railpack detection error: {e}")
            return self._fallback_detection(project_path)
        finally:
            if os.path.exists(plan_path):
                os.unlink(plan_path)
    
    def detect_from_manifest(self, file_manifest: List[Dict[str, Any]]) -> RailpackDetectionResult:
        """
        Quick detection from file manifest (without full Railpack run).
        
        Uses static file detection but returns Railpack-compatible result format.
        
        Args:
            file_manifest: List of file info dicts with 'path' key.
            
        Returns:
            RailpackDetectionResult with detected framework info.
        """
        file_names = {f.get("path", "").lstrip("./") for f in file_manifest}
        
        # === Node.js Detection ===
        if "package.json" in file_names:
            framework = "nodejs"
            package_manager = "npm"
            start_command = "npm start"
            build_commands = []
            
            if "pnpm-lock.yaml" in file_names:
                package_manager = "pnpm"
            elif "yarn.lock" in file_names:
                package_manager = "yarn"
            elif "bun.lockb" in file_names:
                package_manager = "bun"
            
            # Check for specific frameworks in content if available
            for f in file_manifest:
                if f.get("path") == "package.json" and f.get("content"):
                    content = f["content"].lower()
                    if "next" in content:
                        framework = "nextjs"
                        start_command = "npm run start" if package_manager == "npm" else f"{package_manager} start"
                        build_commands = ["npm run build" if package_manager == "npm" else f"{package_manager} build"]
                    elif "express" in content:
                        framework = "express"
                        start_command = "node server.js" # Common default
                    elif "nestjs" in content or "@nestjs/core" in content:
                        framework = "nestjs"
                        start_command = "npm run start:prod"
                        build_commands = ["npm run build"]
                    break
            
            return RailpackDetectionResult(
                framework=framework,
                confidence="high",
                detected_from="package.json",
                package_manager=package_manager,
                runtime_name="node",
                start_command=start_command,
                build_commands=build_commands
            )
        
        # === Python Detection ===
        if "requirements.txt" in file_names or "pyproject.toml" in file_names:
            framework = "python"
            package_manager = "pip"
            start_command = "python main.py"
            detected_from = "requirements.txt" if "requirements.txt" in file_names else "pyproject.toml"
            
            if "pyproject.toml" in file_names and "uv.lock" in file_names:
                package_manager = "uv"
            elif "Pipfile" in file_names:
                package_manager = "pipenv"
            elif "poetry.lock" in file_names:
                package_manager = "poetry"
            
            # Check for specific frameworks
            for f in file_manifest:
                path = f.get("path", "")
                if path in ("requirements.txt", "pyproject.toml") and f.get("content"):
                    content = f["content"].lower()
                    if "fastapi" in content:
                        framework = "fastapi"
                        start_command = "uvicorn main:app --host 0.0.0.0 --port 8000"
                    elif "django" in content:
                        framework = "django"
                        start_command = "python manage.py runserver 0.0.0.0:8000"
                    elif "flask" in content:
                        framework = "flask"
                        start_command = "python app.py"
                    break
            
            return RailpackDetectionResult(
                framework=framework,
                confidence="high",
                detected_from=detected_from,
                package_manager=package_manager,
                runtime_name="python",
                start_command=start_command
            )
        
        # === Go Detection ===
        if "go.mod" in file_names:
            framework = "go"
            
            # Check for specific frameworks
            for f in file_manifest:
                if f.get("path") == "go.mod" and f.get("content"):
                    content = f["content"].lower()
                    if "gin-gonic" in content:
                        framework = "gin"
                    elif "labstack/echo" in content:
                        framework = "echo"
                    break
            
            return RailpackDetectionResult(
                framework=framework,
                confidence="high",
                detected_from="go.mod",
                package_manager="go",
                runtime_name="go"
            )
        
        # === Rust Detection ===
        if "Cargo.toml" in file_names:
            return RailpackDetectionResult(
                framework="rust",
                confidence="high",
                detected_from="Cargo.toml",
                package_manager="cargo",
                runtime_name="rust"
            )
        
        # === Ruby Detection ===
        if "Gemfile" in file_names:
            framework = "ruby"
            if "config.ru" in file_names:
                framework = "rails"
            
            return RailpackDetectionResult(
                framework=framework,
                confidence="high",
                detected_from="Gemfile",
                package_manager="bundler",
                runtime_name="ruby"
            )
        
        # === PHP Detection ===
        if "composer.json" in file_names:
            return RailpackDetectionResult(
                framework="php",
                confidence="high",
                detected_from="composer.json",
                package_manager="composer",
                runtime_name="php"
            )
        
        # === Java Detection ===
        if "pom.xml" in file_names or "build.gradle" in file_names:
            return RailpackDetectionResult(
                framework="java",
                confidence="high",
                detected_from="pom.xml" if "pom.xml" in file_names else "build.gradle",
                package_manager="maven" if "pom.xml" in file_names else "gradle",
                runtime_name="java"
            )
        
        # === Docker Detection ===
        if "Dockerfile" in file_names:
            return RailpackDetectionResult(
                framework="docker",
                confidence="medium",
                detected_from="Dockerfile",
                runtime_name="docker"
            )
        
        # === Static Site ===
        if "index.html" in file_names:
            return RailpackDetectionResult(
                framework="static",
                confidence="medium",
                detected_from="index.html",
                runtime_name="static"
            )
        
        # Default fallback
        return RailpackDetectionResult(
            framework="unknown",
            confidence="low",
            detected_from="default",
            runtime_name="unknown"
        )
    
    def _parse_plan(self, plan: Dict[str, Any]) -> RailpackDetectionResult:
        """Parse Railpack plan JSON into detection result."""
        runtime = plan.get("runtime", {})
        phases = plan.get("phases", {})
        caches = plan.get("caches", {})
        
        runtime_name = runtime.get("name")
        
        # Fuzzy detection for newer Railpack (0.17.x) where runtime field might be different
        if not runtime_name or runtime_name == "unknown":
            if any(k in caches for k in ("next", "node-modules", "npm-install", "yarn", "pnpm")):
                runtime_name = "node"
            elif any(k in caches for k in ("python", "pip", "uv", "poetry", "pipenv")):
                runtime_name = "python"
            elif "go-build" in caches:
                runtime_name = "go"
            elif any(k in caches for k in ("cargo", "cargo-cache", "rust")):
                runtime_name = "rust"
            elif "bundle" in caches or "ruby" in caches:
                runtime_name = "ruby"
            elif "composer" in caches:
                runtime_name = "php"
            
            # Fallback: Check deploy variables if cache scan failed
            if runtime_name == "unknown":
                variables = str(plan.get("deploy", {}).get("variables", {})).lower()
                if "python" in variables:
                    runtime_name = "python"
                elif "node" in variables or "npm" in variables:
                    runtime_name = "node"
                elif "cargo" in variables or "rust" in variables:
                    runtime_name = "rust"
                elif "go" in variables:
                    runtime_name = "go"
        
        runtime_version = runtime.get("version")
        
        # Get start command
        start_phase = phases.get("start", {})
        start_cmd = start_phase.get("cmd", "")
        
        # Extract port from start command
        detected_port = self._extract_port(start_cmd)
        
        # Get build commands
        build_commands = []
        for phase_name in ["setup", "install", "build"]:
            phase = phases.get(phase_name, {})
            for cmd in phase.get("cmds", []):
                build_commands.append(cmd)
        
        # Map runtime to framework
        framework = self._map_runtime_to_framework(runtime_name, plan)
        
        # Detect package manager from packages
        packages = plan.get("packages", {})
        package_manager = self._detect_package_manager(runtime_name, packages)
        
        return RailpackDetectionResult(
            framework=framework,
            confidence="high",
            detected_from="railpack",
            package_manager=package_manager,
            runtime_version=runtime_version,
            start_command=start_cmd,
            detected_port=detected_port,
            build_commands=build_commands,
            runtime_name=runtime_name
        )
    
    def _extract_port(self, cmd: str) -> Optional[int]:
        """Extract port from start command."""
        import re
        
        patterns = [
            r'--port[=\s]*(\d+)',
            r'-p[=\s]*(\d+)',
            r'PORT[=\s]*(\d+)',
            r':(\d+)',  # URL-style :port
            r'\s(\d{2,4})\s',  # Standalone port number
        ]
        
        for pattern in patterns:
            match = re.search(pattern, cmd)
            if match:
                port = int(match.group(1))
                if 1000 <= port <= 65535:
                    return port
        
        return None
    
    def _map_runtime_to_framework(self, runtime_name: str, plan: Dict) -> str:
        """Map Railpack runtime name to Xenfra framework name."""
        runtime_mapping = {
            "python": "python",
            "node": "nodejs",
            "go": "go",
            "rust": "rust",
            "ruby": "ruby",
            "php": "php",
            "java": "java",
            "deno": "deno",
            "bun": "bun",
        }
        
        base_framework = runtime_mapping.get(runtime_name, runtime_name)
        
        # Try to detect specific framework from packages, commands, or caches
        packages = str(plan.get("packages", {})).lower()
        cmds = str(plan.get("phases", {})).lower()
        caches = str(plan.get("caches", {})).lower()
        
        if runtime_name == "python":
            if "fastapi" in packages or "fastapi" in cmds or "fastapi" in caches:
                return "fastapi"
            elif "django" in packages or "django" in cmds or "django" in caches:
                return "django"
            elif "flask" in packages or "flask" in cmds or "flask" in caches:
                return "flask"
        
        elif runtime_name == "node":
            if "next" in packages or "next" in cmds or "next" in caches:
                return "nextjs"
            elif "express" in packages or "express" in cmds or "express" in caches:
                return "express"
            elif "nestjs" in packages or "nest" in cmds or "nest" in caches:
                return "nestjs"
        
        elif runtime_name == "go":
            if "gin" in packages or "gin-gonic" in cmds or "gin" in caches:
                return "gin"
            elif "echo" in packages or "labstack" in cmds or "echo" in caches:
                return "echo"
        
        elif runtime_name == "ruby":
            if "rails" in packages or "rails" in caches:
                return "rails"
        
        return base_framework
    
    def _detect_package_manager(self, runtime_name: str, packages: Dict) -> Optional[str]:
        """Detect package manager from Railpack packages."""
        pkg_str = str(packages).lower()
        
        if runtime_name == "node":
            if "pnpm" in pkg_str:
                return "pnpm"
            elif "yarn" in pkg_str:
                return "yarn"
            elif "bun" in pkg_str:
                return "bun"
            return "npm"
        
        elif runtime_name == "python":
            if "uv" in pkg_str:
                return "uv"
            elif "poetry" in pkg_str:
                return "poetry"
            elif "pipenv" in pkg_str:
                return "pipenv"
            return "pip"
        
        elif runtime_name == "go":
            return "go"
        
        elif runtime_name == "rust":
            return "cargo"
        
        elif runtime_name == "ruby":
            return "bundler"
        
        elif runtime_name == "php":
            return "composer"
        
        elif runtime_name == "java":
            if "gradle" in pkg_str:
                return "gradle"
            return "maven"
        
        return None
    
    def parse_env_content(self, content: str) -> List[EnvVariable]:
        """
        Parse .env file content into EnvVariable objects.
        
        Args:
            content: The content of a .env file
            
        Returns:
            List of EnvVariable objects
        """
        lines = content.split('\n')
        variables = []
        
        for line in lines:
            trimmed = line.strip()
            
            # Skip empty lines and comments
            if not trimmed or trimmed.startswith("#"):
                continue
            
            # Use partition for robust handling of '=' in values
            key, sep, value = trimmed.partition('=')
            
            if sep:
                key = key.strip()
                value = value.strip()
                
                # Validate key
                if not re.match(r'^[a-zA-Z_][a-zA-Z0-9_]*$', key):
                    continue
                
                # Remove surrounding quotes if present
                if ((value.startswith('"') and value.endswith('"')) or
                    (value.startswith("'") and value.endswith("'"))):
                    value = value[1:-1]
                
                # Unescape escaped quotes
                value = value.replace('\\"', '"').replace("\\'", "'")
                
                # Detect if it looks like a secret
                is_secret = bool(re.search(r'secret|key|token|password|private|api.?key|auth', key, re.IGNORECASE))
                
                variables.append(EnvVariable(
                    id=f"env_{len(variables)}",
                    key=key,
                    value=value,
                    is_secret=is_secret
                ))
        
        return variables

    def _fallback_detection(self, project_path: str) -> RailpackDetectionResult:
        """Fallback to static file detection if Railpack fails."""
        # Build file manifest from directory
        file_manifest = []
        for root, dirs, files in os.walk(project_path):
            # Skip common non-project directories
            dirs[:] = [d for d in dirs if d not in ('node_modules', '.git', '__pycache__', 'target', 'vendor')]
            for file in files:
                file_path = os.path.join(root, file)
                rel_path = os.path.relpath(file_path, project_path)
                file_manifest.append({"path": rel_path})
        
        return self.detect_from_manifest(file_manifest)


# Global detector instance
_railpack_detector: Optional[RailpackDetector] = None


def get_railpack_detector(version: Optional[str] = None) -> RailpackDetector:
    """
    Get or create global RailpackDetector instance.
    
    Args:
        version: Specific version to use. If None, uses default.
        
    Returns:
        RailpackDetector singleton
    """
    global _railpack_detector
    
    if _railpack_detector is None:
        _railpack_detector = RailpackDetector(version=version)
    elif version is not None and _railpack_detector.version != version:
        # Requested different version, create new instance
        _railpack_detector = RailpackDetector(version=version)
    
    return _railpack_detector
