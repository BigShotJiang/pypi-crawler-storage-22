"""
Railpack Manager - Auto-downloads and manages Railpack CLI binary.

Railpack is Railway's open-source buildpack that auto-detects languages
and generates optimized container configurations.
"""

import os
import platform
import shutil
import stat
import subprocess
import tarfile
import urllib.request
import zipfile
from pathlib import Path
from typing import Optional
import logging

logger = logging.getLogger(__name__)


class RailpackManager:
    """
    Manages Railpack CLI binary lifecycle.
    
    Auto-downloads Railpack from GitHub releases if not present.
    Stores binary in ~/.xenfra/bin/ for persistence across sessions.
    """
    
    RAILPACK_VERSION = "0.17.1"
    
    # GitHub release URLs for different platforms
    DOWNLOAD_URLS = {
        ("Linux", "x86_64"): "https://github.com/railwayapp/railpack/releases/download/v{version}/railpack-v{version}-x86_64-unknown-linux-musl.tar.gz",
        ("Linux", "aarch64"): "https://github.com/railwayapp/railpack/releases/download/v{version}/railpack-v{version}-arm64-unknown-linux-musl.tar.gz",
        ("Darwin", "x86_64"): "https://github.com/railwayapp/railpack/releases/download/v{version}/railpack-v{version}-x86_64-apple-darwin.tar.gz",
        ("Darwin", "arm64"): "https://github.com/railwayapp/railpack/releases/download/v{version}/railpack-v{version}-arm64-apple-darwin.tar.gz",
        ("Windows", "AMD64"): "https://github.com/railwayapp/railpack/releases/download/v{version}/railpack-v{version}-x86_64-pc-windows-msvc.zip",
    }
    
    def __init__(self, version: Optional[str] = None):
        """
        Initialize Railpack manager.
        
        Args:
            version: Specific Railpack version to use. Defaults to RAILPACK_VERSION.
        """
        self.version = version or self.RAILPACK_VERSION
        self.bin_dir = Path.home() / ".xenfra" / "bin"
        self.bin_dir.mkdir(parents=True, exist_ok=True)
        
        # Determine binary name based on platform
        system = platform.system()
        self.binary_name = "railpack.exe" if system == "Windows" else "railpack"
        self.binary_path = self.bin_dir / self.binary_name
        
        # Cache availability check
        self._is_available: Optional[bool] = None
    
    def is_installed(self) -> bool:
        """Check if Railpack binary exists and is executable."""
        if self._is_available is not None:
            return self._is_available
            
        if not self.binary_path.exists():
            self._is_available = False
            return False
        
        # Verify it's actually runnable
        try:
            result = subprocess.run(
                [str(self.binary_path), "--version"],
                capture_output=True,
                timeout=5
            )
            self._is_available = result.returncode == 0
            return self._is_available
        except (subprocess.TimeoutExpired, OSError):
            self._is_available = False
            return False
    
    def ensure_installed(self) -> str:
        """
        Ensure Railpack is installed. Download if needed.
        
        Returns:
            Absolute path to railpack binary.
            
        Raises:
            RuntimeError: If installation fails or platform unsupported.
        """
        if self.is_installed():
            return str(self.binary_path)
        
        return self._download_and_install()
    
    def _get_download_url(self) -> str:
        """Get download URL for current platform."""
        system = platform.system()
        machine = platform.machine()
        
        # Normalize machine names
        if machine in ("amd64", "x86_64"):
            machine = "x86_64"
        elif machine in ("arm64", "aarch64"):
            machine = "arm64" if system == "Darwin" else "aarch64"
        
        key = (system, machine)
        
        if key not in self.DOWNLOAD_URLS:
            # Try x86_64 as fallback for Linux
            if system == "Linux":
                key = ("Linux", "x86_64")
            else:
                raise RuntimeError(
                    f"Unsupported platform: {system} {machine}. "
                    f"Railpack supports: Linux (x86_64, arm64), macOS (x86_64, arm64), Windows (x86_64)"
                )
        
        return self.DOWNLOAD_URLS[key].format(version=self.version)
    
    def _download_and_install(self) -> str:
        """Download and install Railpack binary."""
        import tempfile
        
        url = self._get_download_url()
        system = platform.system()
        
        print(f"📦 Downloading Railpack {self.version}...")
        
        with tempfile.TemporaryDirectory() as tmpdir:
            tmp_path = Path(tmpdir)
            
            # Determine archive type
            is_zip = url.endswith(".zip")
            archive_name = "railpack.zip" if is_zip else "railpack.tar.gz"
            download_path = tmp_path / archive_name
            
            # Download with progress
            try:
                self._download_with_progress(url, download_path)
            except urllib.error.HTTPError as e:
                raise RuntimeError(f"Failed to download Railpack: {e}")
            
            print(f"📂 Extracting {archive_name}...")
            
            # Extract
            if is_zip:
                self._extract_zip(download_path, tmp_path)
            else:
                self._extract_tar(download_path, tmp_path)
            
            # Find extracted binary recursively
            extracted_binary = None
            for root, dirs, files in os.walk(tmp_path):
                if self.binary_name in files:
                    extracted_binary = Path(root) / self.binary_name
                    break
            
            if not extracted_binary:
                raise RuntimeError(f"Railpack binary '{self.binary_name}' not found in extracted archive")
            
            # Move to bin directory (Robust cross-device move)
            try:
                shutil.copy2(str(extracted_binary), str(self.binary_path))
                os.remove(str(extracted_binary))
            except Exception as e:
                # If copy/delete fails, try move as fallback but it might fail on cross-device
                logger.warning(f"Copy/remove failed: {e}. Trying shutil.move...")
                shutil.move(str(extracted_binary), str(self.binary_path))
            
            # Make executable (Unix)
            if system != "Windows":
                self.binary_path.chmod(
                    self.binary_path.stat().st_mode | stat.S_IXUSR | stat.S_IXGRP | stat.S_IXOTH
                )
        
        # Reset availability cache so verification actually runs the new binary
        self._is_available = None
        
        # Verify installation
        if not self.is_installed():
            raise RuntimeError("Railpack installation verification failed")
        
        print(f"✅ Railpack {self.version} installed at {self.binary_path}")
        return str(self.binary_path)
    
    def _download_with_progress(self, url: str, dest: Path):
        """Download file with simple progress indication."""
        def report_progress(block_num, block_size, total_size):
            downloaded = block_num * block_size
            percent = min(downloaded * 100 // total_size, 100) if total_size > 0 else 0
            if block_num % 10 == 0:  # Update every 10 blocks
                print(f"   Downloading... {percent}%", end="\r")
        
        urllib.request.urlretrieve(url, dest, reporthook=report_progress)
        print()  # Newline after progress
    
    def _extract_zip(self, zip_path: Path, dest_dir: Path):
        """Extract zip archive."""
        with zipfile.ZipFile(zip_path, 'r') as zf:
            zf.extractall(dest_dir)
    
    def _extract_tar(self, tar_path: Path, dest_dir: Path):
        """Extract tar.gz archive."""
        with tarfile.open(tar_path, 'r:gz') as tf:
            tf.extractall(dest_dir)
    
    def run(self, *args, cwd: Optional[str] = None, 
            capture_output: bool = True, text: bool = True,
            timeout: int = 60, **kwargs) -> subprocess.CompletedProcess:
        """
        Run Railpack command.
        
        Args:
            *args: Command arguments (e.g., "prepare", ".", "--plan-out", "plan.json")
            cwd: Working directory
            capture_output: Capture stdout/stderr
            text: Return text instead of bytes
            timeout: Command timeout in seconds
            **kwargs: Additional subprocess arguments
            
        Returns:
            CompletedProcess with returncode, stdout, stderr
            
        Raises:
            subprocess.CalledProcessError: If command fails and check=True
            subprocess.TimeoutExpired: If timeout reached
        """
        binary = self.ensure_installed()
        cmd = [binary] + list(args)
        
        return subprocess.run(
            cmd,
            cwd=cwd,
            capture_output=capture_output,
            text=text,
            timeout=timeout,
            **kwargs
        )
    
    def prepare(self, source_path: str, plan_out: Optional[str] = None,
                info_out: Optional[str] = None, env: Optional[dict] = None) -> dict:
        """
        Run 'railpack prepare' to generate build plan.
        
        Args:
            source_path: Path to source code directory
            plan_out: Output path for plan JSON (default: source_path/.railpack-plan.json)
            info_out: Output path for build info JSON
            env: Environment variables for Railpack
            
        Returns:
            Parsed plan JSON as dict
            
        Raises:
            RuntimeError: If Railpack fails
        """
        import json
        
        if plan_out is None:
            plan_out = os.path.join(source_path, ".railpack-plan.json")
        
        args = ["prepare", source_path, "--plan-out", plan_out]
        
        if info_out:
            args.extend(["--info-out", info_out])
        
        # Add env vars
        env_vars = os.environ.copy()
        if env:
            env_vars.update(env)
        
        result = self.run(*args, env=env_vars, check=True)
        
        # Read and return plan
        with open(plan_out) as f:
            return json.load(f)
    
    def get_version(self) -> str:
        """Get installed Railpack version."""
        if not self.is_installed():
            return "not installed"
        
        result = self.run("--version", check=True)
        return result.stdout.strip()


# Global singleton instance
_railpack_manager: Optional[RailpackManager] = None


def get_railpack_manager(version: Optional[str] = None) -> RailpackManager:
    """
    Get or create global RailpackManager instance.
    
    Args:
        version: Specific version to use. If None, uses default.
        
    Returns:
        RailpackManager singleton
    """
    global _railpack_manager
    
    if _railpack_manager is None:
        _railpack_manager = RailpackManager(version=version)
    elif version is not None and _railpack_manager.version != version:
        # Requested different version, create new instance
        _railpack_manager = RailpackManager(version=version)
    
    return _railpack_manager
