from typing import Dict, Any
import os

def generate_stack(context: Dict[str, Any], is_dockerized: bool = True) -> str:
    """
    Generates the cloud-init startup script programmatically.
    Effectively replaces the old 'cloud-init.sh.j2' template.
    """
    domain = context.get("domain")
    email = context.get("email")
    port = context.get("port", 8000)
    install_caddy = context.get("install_caddy", False)
    xenfra_api_url = os.getenv("XENFRA_API_URL", "https://api.xenfra.tech")
    
    # Base Script Header
    script = [
        "#!/bin/bash",
        "export DEBIAN_FRONTEND=noninteractive",
        'LOG="/root/setup.log"',
        "touch $LOG",
        "",
        'echo "--------------------------------" >> $LOG',
        'echo "🧘 XENFRA: Context-Aware Boot" >> $LOG',
        'echo "--------------------------------" >> $LOG',
        "",
        "# Create App Directory",
        "mkdir -p /root/app",
        "cd /root/app",
        "",
        "# --- MERCILESS FIX: TERMINATE BACKGROUND PROCESSES ---",
        'echo "⚔️  [0/6] Mercilessly Terminating Background Processes..." >> $LOG',
        "",
        "kill_apt_processes() {",
        '  echo "🎯 Killing processes holding apt/dpkg locks..." >> $LOG',
        "  fuser -k /var/lib/dpkg/lock >/dev/null 2>&1",
        "  fuser -k /var/lib/apt/lists/lock >/dev/null 2>&1",
        "  fuser -k /var/lib/dpkg/lock-frontends >/dev/null 2>&1",
        "}",
        "",
        "# Explicitly stop and disable services that cause locks",
        "systemctl stop unattended-upgrades.service || true",
        "systemctl disable unattended-upgrades.service || true",
        "systemctl stop apt-daily.service || true",
        "systemctl disable apt-daily.service || true",
        "systemctl stop apt-daily-upgrade.service || true",
        "systemctl disable apt-daily-upgrade.service || true",
        "",
        "# Forcefully kill any remaining lock holders",
        "kill_apt_processes",
        "",
        "# Force remove locks if they still exist (The Nuclear Option)",
        "rm -f /var/lib/dpkg/lock*",
        "rm -f /var/lib/apt/lists/lock*",
        "rm -f /var/cache/apt/archives/lock",
        "dpkg --configure -a || true",
        "# -----------------------------------------------",
        "",
        "# 1. System Updates",
        'echo "🔄 [1/5] Refreshing Package Lists..." >> $LOG',
        "apt-get update",
        "apt-get install -y python3-pip git curl",
        ""
    ]

    # 2. Setup Environment
    if is_dockerized:
        script.extend([
            'echo "🐳 [2/5] Installing Docker..." >> $LOG',
            "apt-get install -y docker.io || (curl -fsSL https://get.docker.com | sh)",
            'echo "🎶 [3/5] Installing Docker Compose..." >> $LOG',
            "apt-get install -y docker-compose-v2",
            "",
            "# Install Railpack (Railway's zero-config builder)",
            'echo "🚂 [3.5/5] Installing Railpack..." >> $LOG',
            "curl -sSL https://railpack.com/install.sh | sh || echo 'Railpack install failed (non-critical)' >> $LOG",
        ])
    else:
        script.extend([
            'echo "🐍 [2/5] Setting up host-based Python environment..." >> $LOG',
            "apt-get install -y python3-venv python3-dev build-essential"
        ])
    
    script.append("")

    # 3. Setup Reverse Proxy
    if is_dockerized or install_caddy:
        script.extend([
            'echo "📦 [3/5] Installing Caddy..." >> $LOG',
            "apt-get install -y debian-keyring debian-archive-keyring apt-transport-https",
            "curl -LsSf 'https://dl.cloudsmith.io/public/caddy/stable/gpg.key' | gpg --dearmor -o /usr/share/keyrings/caddy-stable-archive-keyring.gpg",
            "curl -LsSf 'https://dl.cloudsmith.io/public/caddy/stable/debian.deb.txt' | tee /etc/apt/sources.list.d/caddy-stable.list",
            "apt-get update",
            "apt-get install -y caddy"
        ])
    else:
        script.append('echo "🛡️ [3/5] Skipping Caddy for host deployment (setup manual reverse proxy if needed)." >> $LOG')
    
    script.append("")

    # Caddyfile Config (if domain provided)
    if domain:
        script.extend([
            f'echo "🔒 Writing Caddyfile for {domain}..." >> $LOG',
            "cat << EOF > /etc/caddy/Caddyfile",
            f"{domain}:80, {domain}:443 {{",
            f"    reverse_proxy localhost:{port}",
            f"    tls {email}",
            "}",
            "EOF",
            "",
            'echo "🚀 [5/5] Starting Caddy..." >> $LOG',
            "systemctl restart caddy"
        ])
    else:
        script.append('echo "✅ [5/5] Skipping Caddy start (no domain specified)." >> $LOG')
    
    script.append("")

    # Heartbeat Logic
    script.append("# --- ZEN GAP FIX: HEARTBEAT CALLBACK ---")
    script.append('echo "📡 [HEARTBEAT] Sending network_ready signal to Xenfra..." >> $LOG')
    
    if xenfra_api_url:
        script.extend([
            'DROPLET_ID=$(curl -sf http://169.254.169.254/metadata/v1/id 2>/dev/null || echo "")',
            'DROPLET_IP=$(curl -sf http://169.254.169.254/metadata/v1/interfaces/public/0/ipv4/address 2>/dev/null || echo "")',
            'if [ -n "$DROPLET_ID" ]; then',
            f'  curl -sf -X POST "{xenfra_api_url}/internal/heartbeat" \\',
            '    -H "Content-Type: application/json" \\',
            '    -d "{\\"droplet_id\\": $DROPLET_ID, \\"status\\": \\"network_ready\\", \\"ip_address\\": \\"$DROPLET_IP\\"}" \\',
            '    --connect-timeout 5 --max-time 10 >> $LOG 2>&1 || echo "⚠️  Heartbeat failed (non-critical)" >> $LOG',
            'else',
            '  echo "⚠️  [HEARTBEAT] Could not fetch droplet ID from metadata" >> $LOG',
            'fi'
        ])
    else:
        script.append('echo "⚠️  [HEARTBEAT] Skipped - no API URL configured" >> $LOG')

    # Footer
    script.extend([
        "",
        "# Finish",
        'echo "✅ SETUP SCRIPT COMPLETE" >> $LOG',
        "touch /root/setup_complete",
        "",
        "# Final heartbeat: cloud-init complete"
    ])

    if xenfra_api_url:
        script.extend([
            'if [ -n "$DROPLET_ID" ]; then',
            f'  curl -sf -X POST "{xenfra_api_url}/internal/heartbeat" \\',
            '    -H "Content-Type: application/json" \\',
            '    -d "{\\"droplet_id\\": $DROPLET_ID, \\"status\\": \\"cloud_init_complete\\", \\"ip_address\\": \\"$DROPLET_IP\\"}" \\',
            '    --connect-timeout 5 --max-time 10 >> $LOG 2>&1 || true',
            'fi'
        ])

    return "\n".join(script)
