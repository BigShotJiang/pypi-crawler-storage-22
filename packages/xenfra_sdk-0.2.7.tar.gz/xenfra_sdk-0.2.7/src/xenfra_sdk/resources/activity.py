import logging
from typing import List

from ..exceptions import XenfraAPIError, XenfraError
from ..models import ActivityLog
from ..utils import safe_get_json_field, safe_json_parse
from .base import BaseManager

logger = logging.getLogger(__name__)


class ActivityManager(BaseManager):
    def list(self) -> List[ActivityLog]:
        """Retrieves user activity logs."""
        try:
            response = self._client._request("GET", "/users/activity")
            logger.debug(f"ActivityManager.list response: {response.status_code}")
            
            data = safe_json_parse(response)
            # Most listing endpoints return a list directly or wrapped in a dict
            if isinstance(data, list):
                logs = data
            else:
                logs = safe_get_json_field(data, "activity", [])
                
            if not isinstance(logs, list):
                raise XenfraError(f"Expected list of logs, got {type(logs).__name__}")
                
            return [ActivityLog(**log) for log in logs]
        except XenfraAPIError:
            raise
        except Exception as e:
            raise XenfraError(f"Failed to fetch activity logs: {e}")

    def create(self, action: str, details: str) -> ActivityLog:
        """Internal helper to log activity via the SDK."""
        try:
            payload = {"action": action, "details": details}
            response = self._client._request("POST", "/users/activity", json=payload)
            data = safe_json_parse(response)
            return ActivityLog(**data)
        except XenfraAPIError:
            raise
        except Exception as e:
            raise XenfraError(f"Failed to log activity: {e}")
