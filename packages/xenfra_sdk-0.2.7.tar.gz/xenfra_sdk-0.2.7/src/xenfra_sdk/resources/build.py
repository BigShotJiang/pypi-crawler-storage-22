"""
Build resource manager for 3-tier dry-run validation.

Provides methods for:
- Tier 2: Build plan detection (Railpack)
- Tier 3: Sandbox validation (E2B via Xenfra API)
"""

from typing import Dict, List, Optional


class BuildManager:
    """Manager for build operations and dry-run validation."""
    
    def __init__(self, client):
        """
        Initialize the BuildManager.
        
        Args:
            client: The XenfraClient instance.
        """
        self._client = client
    
    def detect(self, file_manifest: List[Dict]) -> Dict:
        """
        Tier 2: Detect build plan from project files.
        
        Runs Railpack detection on the backend to determine
        framework, language, and build configuration.
        
        Args:
            file_manifest: List of file info dicts with keys: path, sha, size
            
        Returns:
            Dict with build plan:
                - framework: str (fastapi, flask, nextjs, etc.)
                - language: str (python, node, go, rust)
                - package_manager: str (pip, npm, go mod, etc.)
                - dependency_file: str (requirements.txt, package.json)
                - port: int
                - build_command: Optional[str]
                - start_command: Optional[str]
                - dockerfile: Optional[str] (generated if applicable)
        """
        payload = {"files": file_manifest}
        
        response = self._client._request("POST", "/build/detect", json=payload)
        return response.json()
    
    def validate(
        self,
        file_manifest: List[Dict],
        build_plan: Dict,
        timeout: int = 300
    ) -> Dict:
        """
        Tier 3: Validate build in E2B sandbox.
        
        Runs full build validation in an isolated sandbox environment.
        This ensures the project actually builds and runs before deployment.
        
        Args:
            file_manifest: List of file info dicts with keys: path, sha, size
            build_plan: Build plan dict from detect()
            timeout: Maximum time to wait for validation (seconds)
            
        Returns:
            Dict with validation result:
                - success: bool
                - output: str (build output logs)
                - error: Optional[str] (error message if failed)
                - build_time: float (seconds)
                - verification_proof: str (SHA256 hash for compliance)
        """
        payload = {
            "files": file_manifest,
            "build_plan": build_plan,
            "timeout": timeout
        }
        
        response = self._client._request("POST", "/build/validate", json=payload)
        return response.json()
    
    def validate_stream(
        self,
        file_manifest: List[Dict],
        build_plan: Dict,
        timeout: int = 300
    ):
        """
        Tier 3: Validate build with streaming logs.
        
        Same as validate() but yields log lines in real-time.
        
        Args:
            file_manifest: List of file info dicts
            build_plan: Build plan dict from detect()
            timeout: Maximum time to wait
            
        Yields:
            Dict with:
                - type: "log" | "complete" | "error"
                - data: str (log line) or dict (result)
        """
        payload = {
            "files": file_manifest,
            "build_plan": build_plan,
            "timeout": timeout,
            "stream": True
        }
        
        with self._client._request(
            "POST",
            "/build/validate",
            json=payload,
            stream=True
        ) as response:
            for line in response.iter_lines():
                if line:
                    import json
                    yield json.loads(line)
    
    def dry_run(
        self,
        file_manifest: List[Dict],
        skip_sandbox: bool = False,
        force_sandbox: bool = False
    ) -> Dict:
        """
        Run full 3-tier dry-run validation.
        
        This is a convenience method that runs all three tiers:
        - Tier 1: Local validation (client-side)
        - Tier 2: Build detection (API call)
        - Tier 3: Sandbox validation (API call, if needed)
        
        Args:
            file_manifest: List of file info dicts
            skip_sandbox: Skip Tier 3 validation
            force_sandbox: Force Tier 3 even if not needed
            
        Returns:
            Dict with full validation results:
                - tier1: Dict (local validation result)
                - tier2: Dict (build plan)
                - tier3: Optional[Dict] (sandbox result)
                - tier3_ran: bool
                - success: bool
        """
        payload = {
            "files": file_manifest,
            "skip_sandbox": skip_sandbox,
            "force_sandbox": force_sandbox
        }
        
        response = self._client._request("POST", "/build/dry-run", json=payload)
        return response.json()
