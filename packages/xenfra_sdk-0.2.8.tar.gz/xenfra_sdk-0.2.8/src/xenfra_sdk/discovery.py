"""
Xenfra Discovery Engine - Recursive Scanner and Infrastructure Inferrer.
Follows XENFRA_PROTOCOL.md Stage 2 (The Harness/Discovery).
"""

import os
from pathlib import Path
from typing import List, Dict, Any, Optional
import re

from xenfra_sdk.manifest import ServiceDefinition, InfrastructureService, XenfraConfig
from xenfra_sdk.constants import DEFAULT_PORT_RANGE_START
from xenfra_sdk.railpack_detector import get_railpack_detector


class RecursiveScanner:
    """
    Scans a directory tree to find microservices and infrastructure dependencies.
    Uses RailpackDetector for framework identification.
    """

    def __init__(self, root_path: str):
        self.root_path = Path(root_path).resolve()
        self.services: List[ServiceDefinition] = []
        self.infrastructure: List[InfrastructureService] = []
        self._port_counter = DEFAULT_PORT_RANGE_START
        self.detector = get_railpack_detector()

    def scan(self) -> XenfraConfig:
        """
        Recursively scans the root path for projects.
        """
        for root, dirs, files in os.walk(self.root_path):
            # Skip hidden directories and virtual envs
            dirs[:] = [d for d in dirs if not d.startswith(".") and d not in ["venv", "node_modules", "__pycache__"]]
            
            root_p = Path(root)
            
            # Create manifest for Railpack detection
            manifest = []
            for f in files:
                f_path = root_p / f
                # Only read content of relevant files to speed up scanning
                content = ""
                if f in ["package.json", "requirements.txt", "pyproject.toml", "go.mod", "Cargo.toml", "Gemfile", "composer.json", "pom.xml", "build.gradle"]:
                    content = f_path.read_text(errors="ignore")
                
                manifest.append({
                    "path": f,
                    "content": content
                })
            
            # 1. Detect Framework via Railpack Logic
            result = self.detector.detect_from_manifest(manifest)
            
            if result.framework != "unknown":
                # Sanitize Name
                rel_path = root_p.relative_to(self.root_path)
                name = rel_path.name.lower().replace("_", "-").replace(" ", "-")
                if name == "." or not name:
                    name = self.root_path.name.lower().replace("_", "-")
                
                # Assign Port
                port = self._port_counter
                self._port_counter += 1
                
                # Register Service
                service = ServiceDefinition(
                    name=name,
                    path=str(rel_path),
                    port=port,
                    framework=result.framework,
                    # Railpack gives us extra details we can optionally use
                )
                self.services.append(service)
                
                # 2. Infer Infrastructure (Post-Process)
                # Railpack doesn't explicitly output "needs redis", so we keep our robust heuristic
                infra_deps = set()
                
                # Check known files for db drivers
                for item in manifest:
                    content = item.get("content", "").lower()
                    if not content: continue
                    
                    if "redis" in content: infra_deps.add("redis")
                    if "kafka" in content or "confluent-kafka" in content: infra_deps.add("kafka")
                    
                    # Postgres
                    if any(x in content for x in ["psycopg2", "asyncpg", "pg", "postgres"]):
                        infra_deps.add("postgres")
                        
                    # MongoDB
                    if any(x in content for x in ["pymongo", "mongoose", "mongodb"]):
                        infra_deps.add("mongodb")

                # Add infrastructure
                for inf in infra_deps:
                    if not any(i.type == inf for i in self.infrastructure):
                        self.infrastructure.append(InfrastructureService(
                            name=f"shared-{inf}",
                            type=inf,
                            port=6379 if inf == "redis" else 5432 if inf == "postgres" else 27017
                        ))

        return XenfraConfig(
            name=self.root_path.name.lower().replace("_", "-"),
            services=self.services,
            infrastructure=self.infrastructure
        )
