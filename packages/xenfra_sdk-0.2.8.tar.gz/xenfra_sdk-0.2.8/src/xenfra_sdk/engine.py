# src/xenfra/engine.py

import os
import time
import subprocess
import json
import shlex
import tempfile
import shutil
from datetime import datetime
from pathlib import Path
from typing import Optional, Dict, Any, Union

import digitalocean
import fabric
from dotenv import load_dotenv
from sqlmodel import Session, select

# Xenfra modules
from . import dockerizer, privacy, constants
from xenfra_sdk.patching import PatchManager
from .db.models import Project
from .db.session import get_session
from .events import EventEmitter, DeploymentPhase, EventStatus
from .exceptions import DeploymentError
from .governance import get_polling_interval, get_resource_limits
from .models.context import DeploymentContext
from .blueprints.factory import render_blueprint
from .client import XenfraClient

class InfraEngine:
    """
    The InfraEngine is the core of Xenfra. It handles all interactions
    with the cloud provider and orchestrates the deployment lifecycle.
    """

    def __init__(self, token: str = None, db_session: Session = None, context: dict = None):
        """
        Initializes the engine and validates the API token.
        """
        load_dotenv()
        self.context = context or {}
        self.token = token or os.getenv("DIGITAL_OCEAN_TOKEN")
        self.db_session = db_session or next(get_session())

        if not self.token:
            raise ValueError(
                "DigitalOcean API token not found. Please set the DIGITAL_OCEAN_TOKEN environment variable."
            )
        try:
            self.manager = digitalocean.Manager(token=self.token)
            self.get_user_info()
        except Exception as e:
            raise ConnectionError(f"Failed to connect to DigitalOcean: {e}")

        # ZEN GAP FIX: Structured Observability
        # Initialize Event Emitter to stream Zen/Biological events
        self.emitter = EventEmitter(
            logger=self.context.get("logger"),
            event_callback=self.context.get("event_callback")
        )
        # Initialize internal client for API access (Intelligence/Sandbox)
        self.client = XenfraClient(token=self.token)

    def _get_connection(self, ip_address: str):
        """Establishes a Fabric connection to the server."""
        private_key_path = str(Path(os.path.expanduser(constants.DEFAULT_SSH_KEY_PATH)).resolve())
        if not Path(private_key_path).exists():
            raise DeploymentError(f"No private SSH key found at {private_key_path}.", stage="Setup")

        return fabric.Connection(
            host=ip_address,
            user="root",
            connect_kwargs={"key_filename": [private_key_path]},
        )

    def get_user_info(self):
        """Retrieves user account information."""
        return self.manager.get_account()

    def list_servers(self):
        """Retrieves a list of all Droplets."""
        return self.manager.get_all_droplets()

    def list_domains(self):
        """Retrieves a list of all domains associated with the account."""
        return self.manager.get_all_domains()

    def destroy_server(
        self,
        droplet_id: int,
        db_session: Session = None,
        preserve_data: bool = False,
        snapshot_callback: callable = None,
    ):
        """
        Idempotent droplet destruction with optional data stewardship.

        ZEN GAP FIX: Stewardship - Snapshot volumes before destruction.

        Args:
            droplet_id: The DigitalOcean droplet ID
            db_session: SQLModel session
            preserve_data: If True, snapshot Docker volumes before destruction
            snapshot_callback: Async callback to upload snapshots (e.g., to S3/R2)

        Destroys the droplet and removes DB records. Handles 404 errors gracefully
        (if droplet already destroyed, continues to DB cleanup).
        """
        session = db_session or self.db_session

        # Find the project in the local DB
        statement = select(Project).where(Project.droplet_id == droplet_id)
        project_to_delete = session.exec(statement).first()

        # ZEN GAP FIX: Stewardship - Snapshot volumes before destruction
        if preserve_data and project_to_delete:
            try:
                droplet = self.manager.get_droplet(droplet_id)
                ip_address = droplet.ip_address
                if ip_address:
                    self._snapshot_volumes(
                        ip_address=ip_address,
                        project_name=project_to_delete.name,
                        callback=snapshot_callback,
                    )
            except Exception as e:
                # Non-fatal: log but continue with destruction
                privacy.scrubbed_print(f"[Stewardship] Volume snapshot failed (non-fatal): {e}")

        # Destroy the droplet on DigitalOcean (handle 404 gracefully)
        try:
            droplet = digitalocean.Droplet(token=self.token, id=droplet_id)
            droplet.destroy()
        except Exception as e:
            # If 404, droplet already gone - that's OK
            error_str = str(e).lower()
            if "404" in error_str or "not found" in error_str:
                pass  # Continue to DB cleanup
            else:
                raise  # Unexpected error

        # If it was in our DB, delete it
        if project_to_delete:
            session.delete(project_to_delete)
            session.commit()

    def _snapshot_volumes(
        self,
        ip_address: str,
        project_name: str,
        callback: callable = None,
    ):
        """
        ZEN GAP FIX: Stewardship - Snapshot Docker volumes before destruction.

        Creates tar.gz archives of named Docker volumes on the droplet.
        100% deterministic: tar + docker volume are Unix primitives.

        Args:
            ip_address: Droplet IP address
            project_name: Project name for snapshot naming
            callback: Optional callback to upload snapshots
        """
        try:
            with self._get_connection(ip_address) as conn:
                # 1. List named volumes
                result = conn.run("docker volume ls -q", warn=True, hide=True)
                if result.failed or not result.stdout.strip():
                    return  # No volumes to snapshot

                volumes = result.stdout.strip().split("\n")

                # 2. Create backup directory
                backup_dir = f"/tmp/xenfra_snapshots/{project_name}"
                conn.run(f"mkdir -p {backup_dir}", warn=True, hide=True)

                # 3. Snapshot each volume
                for vol in volumes:
                    vol = vol.strip()
                    if not vol:
                        continue
                    # Use Alpine container to tar the volume
                    snapshot_file = f"{backup_dir}/{vol}.tar.gz"
                    tar_cmd = (
                        f"docker run --rm "
                        f"-v {vol}:/data:ro "
                        f"-v {backup_dir}:/backup "
                        f"alpine tar czf /backup/{vol}.tar.gz -C /data ."
                    )
                    conn.run(tar_cmd, warn=True, hide=True)

                # 4. If callback provided, upload snapshots
                if callback:
                    # List snapshot files and pass to callback
                    ls_result = conn.run(f"ls {backup_dir}/*.tar.gz", warn=True, hide=True)
                    if ls_result.ok:
                        snapshot_files = ls_result.stdout.strip().split("\n")
                        for snap_file in snapshot_files:
                            callback(snap_file, project_name)

        except Exception as e:
            # Non-fatal error - log and continue
            privacy.scrubbed_print(f"[Stewardship] Snapshot failed: {e}")

    def list_projects_from_db(self, db_session: Session = None, user_id: int = None):
        """Lists all projects from the local database."""
        session = db_session or self.db_session
        statement = select(Project)
        if user_id:
            statement = statement.where(Project.user_id == user_id)
        return session.exec(statement).all()

    def sync_with_provider(
        self,
        user_id: int,
        db_session: Session = None,
        auto_destroy_orphans: bool = False,
    ):
        """
        ZEN GAP FIX: Idempotent Reconciliation with orphan detection.

        Reconciles the local database with the live state from DigitalOcean.
        100% deterministic: Set difference is math.

        Args:
            user_id: User ID to sync for
            db_session: SQLModel session
            auto_destroy_orphans: If True, destroy orphan droplets (in DO but not in DB)

        Returns:
            Tuple of (projects_list, reconciliation_report)
        """
        session = db_session or self.db_session

        # 1. Get live and local states
        live_droplets = self.manager.get_all_droplets(tag_name="xenfra")
        local_projects = self.list_projects_from_db(session, user_id=user_id)

        live_map = {d.id: d for d in live_droplets}
        local_map = {p.droplet_id: p for p in local_projects}

        live_ids = set(live_map.keys())
        local_ids = set(local_map.keys())

        # 2. Calculate differences (pure math, no guessing)
        orphans = live_ids - local_ids  # In DO but not in DB
        ghosts = local_ids - live_ids   # In DB but not in DO
        synced = live_ids & local_ids   # In both

        reconciliation_report = {
            "orphans": list(orphans),  # Droplets without DB records
            "ghosts": list(ghosts),    # DB records without droplets
            "synced": list(synced),    # Properly tracked
            "actions_taken": [],
        }

        # 3. Handle orphans (in DO but not in DB)
        for droplet_id in orphans:
            droplet = live_map[droplet_id]
            if auto_destroy_orphans:
                # Option A: Destroy orphan droplets (cost savings)
                try:
                    orphan_droplet = digitalocean.Droplet(token=self.token, id=droplet_id)
                    orphan_droplet.destroy()
                    reconciliation_report["actions_taken"].append(
                        f"DESTROYED orphan droplet {droplet_id} ({droplet.name})"
                    )
                except Exception as e:
                    reconciliation_report["actions_taken"].append(
                        f"FAILED to destroy orphan {droplet_id}: {e}"
                    )
            else:
                # Option B: Create DB record for recovery
                new_project = Project(
                    droplet_id=droplet.id,
                    name=droplet.name,
                    ip_address=droplet.ip_address,
                    status=droplet.status,
                    region=droplet.region["slug"],
                    size=droplet.size_slug,
                    user_id=user_id,
                )
                session.add(new_project)
                reconciliation_report["actions_taken"].append(
                    f"RECOVERED orphan droplet {droplet_id} ({droplet.name})"
                )

        # 4. Handle ghosts (in DB but not in DO)
        for project_id in ghosts:
            project = local_map[project_id]
            if project.status != "destroyed":
                project.status = "destroyed"
                project.ip_address = None
                session.add(project)
                reconciliation_report["actions_taken"].append(
                    f"MARKED ghost record {project_id} ({project.name}) as destroyed"
                )

        # 5. Update status for synced projects
        for droplet_id in synced:
            droplet = live_map[droplet_id]
            project = local_map[droplet_id]
            if project.status != droplet.status or project.ip_address != droplet.ip_address:
                project.status = droplet.status
                project.ip_address = droplet.ip_address
                session.add(project)
                reconciliation_report["actions_taken"].append(
                    f"UPDATED status for {droplet_id} ({project.name})"
                )

        session.commit()
        return self.list_projects_from_db(session), reconciliation_report

    def get_orphan_droplets(self, user_id: int, db_session: Session = None) -> list:
        """
        ZEN GAP FIX: Detect orphan droplets (in DO but not in DB).

        Returns list of droplet IDs that exist on DigitalOcean but have no
        corresponding database record. These cost money!

        Args:
            user_id: User ID to check for
            db_session: SQLModel session

        Returns:
            List of orphan droplet IDs
        """
        session = db_session or self.db_session

        live_droplets = self.manager.get_all_droplets(tag_name="xenfra")
        local_projects = self.list_projects_from_db(session, user_id=user_id)

        live_ids = {d.id for d in live_droplets}
        local_ids = {p.droplet_id for p in local_projects}

        return list(live_ids - local_ids)

    def destroy_orphans(self, user_id: int, db_session: Session = None) -> list:
        """
        ZEN GAP FIX: Destroy all orphan droplets for cost savings.

        Args:
            user_id: User ID
            db_session: SQLModel session

        Returns:
            List of destroyed droplet IDs
        """
        orphans = self.get_orphan_droplets(user_id, db_session)
        destroyed = []

        for droplet_id in orphans:
            try:
                droplet = digitalocean.Droplet(token=self.token, id=droplet_id)
                droplet.destroy()
                destroyed.append(droplet_id)
            except Exception:
                pass  # Skip if already destroyed

        return destroyed

    def stream_logs(self, droplet_id: int, db_session: Session = None):
        """
        Verifies a server exists and streams its logs in real-time.
        """
        session = db_session or self.db_session

        # 1. Find project in local DB
        statement = select(Project).where(Project.droplet_id == droplet_id)
        project = session.exec(statement).first()
        if not project:
            raise DeploymentError(
                f"Project with Droplet ID {droplet_id} not found in local database.",
                stage="Log Streaming",
            )

        # 2. Just-in-Time Verification
        try:
            droplet = self.manager.get_droplet(droplet_id)
        except digitalocean.baseapi.DataReadError as e:
            if e.response.status_code == 404:
                # The droplet doesn't exist, so remove it from our DB
                session.delete(project)
                session.commit()
                raise DeploymentError(
                    f"Server '{project.name}' (ID: {droplet_id}) no longer exists on DigitalOcean. It has been removed from your local list.",
                    stage="Log Streaming",
                )
            else:
                raise e

        # 3. Stream logs
        ip_address = droplet.ip_address
        with self._get_connection(ip_address) as conn:
            conn.run("cd /root/app && docker compose logs -f app", pty=True)


    def _ensure_ssh_key(self, logger):
        """Ensures a local public SSH key is on DigitalOcean. Generates one if missing (Zen Mode)."""
        pub_key_path = Path(os.path.expanduser(constants.DEFAULT_SSH_PUB_KEY_PATH))
        priv_key_path = Path(os.path.expanduser(constants.DEFAULT_SSH_KEY_PATH))
        
        if not pub_key_path.exists():
            logger("   - [Zen Mode] No SSH key found at ~/.ssh/id_rsa.pub. Generating a new one...")
            try:
                # Ensure .ssh directory exists
                pub_key_path.parent.mkdir(parents=True, exist_ok=True)
                
                # Generate RSA keypair without passphrase
                subprocess.run(
                    ["ssh-keygen", "-t", "rsa", "-b", "4096", "-N", "", "-f", str(priv_key_path)],
                    check=True,
                    capture_output=True
                )
                logger("   - [Zen Mode] Successfully generated SSH keypair.")
            except Exception as e:
                logger(f"   - [ERROR] Failed to generate SSH key: {e}")
                raise DeploymentError(
                    f"Could not find or generate SSH key: {e}", stage="Setup"
                )

        with open(pub_key_path) as f:
            pub_key_content = f.read()

        # Check if the key is already on DigitalOcean
        existing_keys = self.manager.get_all_sshkeys()
        for key in existing_keys:
            if key.public_key.strip() == pub_key_content.strip():
                logger("   - Found existing SSH key on DigitalOcean.")
                return key

        logger("   - No matching SSH key found on provider. Registering new key...")
        # Use a descriptive name including hostname if possible
        import socket
        key_name = f"xenfra-key-{socket.gethostname()}"
        key = digitalocean.SSHKey(
            token=self.token, name=key_name, public_key=pub_key_content
        )
        key.create()
        return key
        
    def deploy_server(
        self,
        name: str,
        region: str = "nyc3",
        size: str = "s-1vcpu-1gb",
        image: str = "ubuntu-22-04-x64",
        logger: Optional[callable] = None,
        user_id: Optional[int] = None,
        email: Optional[str] = None,
        domain: Optional[str] = None,
        repo_url: Optional[str] = None,
        is_dockerized: bool = True,
        db_session: Session = None,
        port: int = 8000,
        command: str = None,
        entrypoint: str = None,  # e.g., "todo.main:app"
        database: str = None,
        package_manager: str = None,
        dependency_file: str = None,
        file_manifest: list = None,  # Delta upload: [{path, sha, size}, ...]
        get_file_content: callable = None,  # Function to get file content by SHA
        cleanup_on_failure: bool = False,  # Auto-cleanup resources on failure
        extra_assets: Dict[str, str] = None,  # Additional files to write (e.g. Dockerfiles)
        # Multi-service deployment (from ServiceOrchestrator)
        multi_service_compose: str = None,  # Pre-generated docker-compose.yml for multi-service
        multi_service_caddy: str = None,  # Pre-generated Caddyfile for multi-service routing
        services: list = None,  # List of ServiceDefinition for multi-service deployments
        env_vars: Dict[str, str] = None,  # Generic environment variables
        dry_run: bool = False, # ZEN MODE: Return assets without deploying
        verify_local: bool = True, # LOCAL MODE: Mirror production locally before cloud push
        **kwargs,
    ):
        """A stateful, blocking orchestrator for deploying a new server."""
        
        # Protocol Compliance: Wrap logger with privacy scrubber
        # Use the scrubbed logger for the rest of the method
        logger_orig = logger or print
        
        def scrubbed_logger(msg):
            if isinstance(msg, str):
                logger_orig(privacy.scrub_pii(msg))
            else:
                logger_orig(msg)
        
        logger = scrubbed_logger
        
        self.emitter.start()
        # Synchronize emitter logger with provided logger
        self.emitter.logger = logger
        # ZEN GAP FIX: Observability - Reset events for fresh deployment telemetry
        self.emitter.events = []
        
        droplet = None
        session = db_session or self.db_session
        framework = kwargs.get("framework")
        mode = kwargs.get("mode", "monolithic")
        tier = kwargs.get("tier", "FREE")  # Default to FREE tier
        
        # ZEN GAP FIX: Resource Governance - Set tier-based polling interval
        polling_interval = kwargs.get("polling_interval") or get_polling_interval(tier)
        
        github_token = kwargs.get("github_token")
        branch = kwargs.get("branch", "main")
        devbox = kwargs.get("devbox", False)
        
        # Backward compatibility for logger
        logger = logger or (lambda msg: None)
        
        try:
            # === 0a. DEEP DISCOVERY ===
            # If no services explicitly provided, scan the project structure
            if not services:
                if file_manifest:
                    # UI DEPLOYMENT: Detect framework from file_manifest (not local files!)
                    # The container's local directory is the deployment service, not user's project
                    from .manifest import ServiceDefinition
                    
                    file_names = {f.get("path", "").lstrip("./") for f in file_manifest}
                    detected_framework = None
                    
                    # Check for Node.js first (package.json is more specific)
                    if "package.json" in file_names:
                        detected_framework = "nodejs"
                    # Then check for Python
                    elif "requirements.txt" in file_names or "pyproject.toml" in file_names:
                        detected_framework = "python"
                        # Refine to specific framework if possible
                        for f in file_manifest:
                            content = f.get("content", "")
                            if content:
                                if "fastapi" in content.lower():
                                    detected_framework = "fastapi"
                                    break
                                elif "django" in content.lower():
                                    detected_framework = "django"
                                    break
                                elif "flask" in content.lower():
                                    detected_framework = "flask"
                                    break
                    elif "go.mod" in file_names:
                        detected_framework = "go"
                    elif "Cargo.toml" in file_names:
                        detected_framework = "rust"
                    
                    # Use explicit framework param if provided and not auto-detect
                    if framework and framework not in ("auto-detect", "other", "unknown", None):
                        detected_framework = framework
                        logger(f"   - [Manifest] Using user-selected framework: {framework}")
                    elif detected_framework:
                        logger(f"\n[bold magenta]🔍 MANIFEST DISCOVERY: Detected framework={detected_framework}[/bold magenta]")
                    
                    if detected_framework:
                        # Create a single service from the manifest
                        services = [ServiceDefinition(
                            name=f"{name}-api" if name else "app-api",
                            path=".",
                            port=port or 8000,
                            framework=detected_framework,
                            entrypoint=entrypoint
                        )]
                        logger(f"   - Created service: {services[0].name} (port {services[0].port})")
                else:
                    # NO FILE_MANIFEST PROVIDED
                    # Check if this is a SERVICE MODE deployment with repo_url
                    # If so, DO NOT scan local directory (it's the deployment service, not user's project!)
                    if os.getenv("XENFRA_SERVICE_MODE") == "true" and repo_url:
                        # Service mode with repo_url but no file_manifest
                        # Use explicit framework if provided, otherwise default to auto-detect
                        # The actual framework will be detected later when repo is cloned
                        from .manifest import ServiceDefinition
                        
                        explicit_framework = framework if framework and framework not in ("auto-detect", "other", "unknown", None) else None
                        
                        if explicit_framework:
                            logger(f"\n[bold magenta]🔍 SERVICE MODE: Using explicit framework={explicit_framework}[/bold magenta]")
                            services = [ServiceDefinition(
                                name=f"{name}-api" if name else "app-api",
                                path=".",
                                port=port or 8000,
                                framework=explicit_framework,
                                entrypoint=entrypoint
                            )]
                            logger(f"   - Created service: {services[0].name} (port {services[0].port})")
                        else:
                            # No explicit framework - we'll need to clone the repo first to detect
                            # This is handled in the GENOME_TRANSFER stage
                            logger(f"\n[dim]No file_manifest or explicit framework - detection will occur after repo clone[/dim]")
                    else:
                        # CLI DEPLOYMENT: Scan local project files
                        from .discovery import RecursiveScanner
                        if os.getcwd():
                            scanner = RecursiveScanner(root_path=os.getcwd())
                            scan_config = scanner.scan()
                            found_services = scan_config.services
                            if found_services:
                                logger(f"\n[bold magenta]🔍 DEEP DISCOVERY: Discovered {len(found_services)} services[/bold magenta]")
                                services = found_services

            
            # === 0b. MICROSERVICES DELEGATION ===
            # If services are provided but no pre-generated assets, delegate to Orchestrator
            if services and mode != "monolithic" and not (multi_service_compose or multi_service_caddy):
                logger("\n[bold magenta]MICROSERVICES DETECTED - Delegating to ServiceOrchestrator[/bold magenta]")
                from .orchestrator import ServiceOrchestrator, load_services_from_xenfra_yaml
                from .manifest import create_services_from_detected
                
                # ZEN MODE: Discovery Clone for Multi-service
                # If we have a repo_url but no file_manifest, we must clone to detect frameworks
                temp_discovery_path = None
                if repo_url and not file_manifest:
                    import tempfile
                    import shutil
                    import subprocess
                    temp_discovery_path = tempfile.mkdtemp(prefix="xenfra-discovery-")
                    logger(f"\n[bold yellow]🔍 DISCOVERY CLONE: Cloning for microservice analysis...[/bold yellow]")
                    try:
                        subprocess.run(
                            ["git", "clone", "--depth", "1", repo_url, temp_discovery_path],
                            check=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL
                        )
                        # Hydrate file_manifest for Orchestrator
                        new_manifest = []
                        for root, dirs, files in os.walk(temp_discovery_path):
                            if ".git" in dirs: 
                                dirs.remove(".git")
                            for f in files:
                                fpath = os.path.join(root, f)
                                rel_path = os.path.relpath(fpath, temp_discovery_path)
                                file_entry = {"path": rel_path}
                                # Read critical configs for hydration
                                if f in ["package.json", "requirements.txt", "pyproject.toml"]:
                                    try:
                                        with open(fpath, "r", encoding="utf-8") as f_in:
                                            file_entry["content"] = f_in.read()
                                    except: pass
                                new_manifest.append(file_entry)
                        file_manifest = new_manifest
                        logger(f"   - Discovery successful: {len(file_manifest)} files mapped")
                    except Exception as e:
                        logger(f"   - [yellow]Warning: Discovery clone failed: {e}[/yellow]")
                    finally:
                        if temp_discovery_path:
                            shutil.rmtree(temp_discovery_path, ignore_errors=True)

                # Convert dicts to ServiceDefinition objects if needed
                service_objs = []
                if services and isinstance(services[0], dict):
                    service_objs = create_services_from_detected(services)
                else:
                    service_objs = services

                # Determine mode (can be passed in kwargs or default to single-droplet)
                mode = kwargs.get("mode", "single-droplet")
                
                orchestrator = ServiceOrchestrator(
                    engine=self,
                    services=service_objs,
                    project_name=name,
                    mode=mode,
                    file_manifest=file_manifest,
                    tier=tier
                )
                
                return orchestrator.deploy(
                    logger=logger,
                    # Pass all original arguments (including dry_run and devbox)
                    dry_run=dry_run,
                    devbox=devbox,
                    region=region,
                    size=size,
                    image=image,
                    user_id=user_id,
                    email=email,
                    domain=domain,
                    repo_url=repo_url,
                    is_dockerized=is_dockerized,
                    db_session=db_session,
                    port=port,
                    command=command,
                    entrypoint=entrypoint,
                    database=database,
                    package_manager=package_manager,
                    dependency_file=dependency_file,
                    file_manifest=file_manifest,
                    get_file_content=get_file_content,
                    cleanup_on_failure=cleanup_on_failure,
                    extra_assets=extra_assets,
                    env_vars=env_vars,
                    **kwargs
                )

            # === 0. EARLY VALIDATION ===
            # Check code source BEFORE creating droplet
            has_code_source = repo_url or (file_manifest and get_file_content)
            if os.getenv("XENFRA_SERVICE_MODE") == "true" and not has_code_source:
                raise DeploymentError(
                    "No code source provided. Use git_repo URL or upload files first. "
                    "Local folder deployment is not supported via the cloud API.",
                    stage="Validation",
                )
            
            # === 1. SETUP STAGE ===
            self.emitter.start_phase(DeploymentPhase.DNA_ENCODING, "Encoding project setup and SSH keys")
            if not dry_run:
                ssh_key = self._ensure_ssh_key(logger)
            else:
                 logger("   - [Dry Run] Skipping SSH key check")
            self.emitter.complete_phase(DeploymentPhase.DNA_ENCODING)

            # === 2. ASSET GENERATION STAGE (THE BLUEPRINT) ===
            self.emitter.start_phase(DeploymentPhase.CELL_BLUEPRINT, "Synthesizing Server DNA (Asset Generation)")
            
            # Detect Python version/Entrypoint from project files if using delta upload
            python_version = "python:3.11-slim"  # Default
            enhanced_manifest = []
            if file_manifest and get_file_content:
                # Build file info with content for version/entrypoint detection
                for finfo in file_manifest:
                    path = finfo.get('path', '')
                    # Load content for version files AND potential entrypoint files (limit depth for performance)
                    is_version_file = path in ['.python-version', 'pyproject.toml']
                    is_candidate_py = path.endswith('.py') and path.count('/') <= 1
                    
                    if is_version_file or is_candidate_py:
                        try:
                            content = get_file_content(finfo.get('sha', ''))
                            if content:
                                enhanced_manifest.append({
                                    'path': path,
                                    'content': content.decode('utf-8', errors='ignore')
                                })
                        except Exception:
                            continue
                
                if enhanced_manifest:
                    python_version = dockerizer.detect_python_version(enhanced_manifest)
                    logger(f"   - Detected Python version: {python_version}")
                    
                    # Update file_manifest in context with loaded contents for blueprints
                    file_manifest = enhanced_manifest
            
            
            # Protocol Compliance: Build Type-Safe DeploymentContext
            # Protocol Compliance: Build Type-Safe DeploymentContext
            ctx = DeploymentContext(
                project_name=name,
                email=email or "admin@xenfra.tech", # Use passed email or default
                region=region,
                size=size,
                image=image,
                framework=framework or "python",
                port=port or 8000,
                entrypoint=entrypoint,
                python_version=python_version or "3.11-slim",
                is_dockerized=is_dockerized,
                branch=branch,
                source_type="git" if repo_url else "local",
                env_vars=env_vars or {},
                tier=tier,
                include_postgres=bool(database == "postgres")
            )
            
            # Pre-inject resource limits if tier is managed
            limits = get_resource_limits(tier)
            ctx.cpu_limit = limits.cpus
            ctx.memory_limit = limits.memory

            # Log scrubbed context for debugging (SAFE)
            logger(f"   - Initializing deployment for {name} ({tier} tier)")

            # Check if this is a multi-service deployment
            if multi_service_compose:
                logger("   - Using multi-service configuration")
                rendered_assets = {
                    "docker-compose.yml": multi_service_compose,
                }
                
                if multi_service_caddy:
                    rendered_assets["Caddyfile"] = multi_service_caddy
            else:
                # Protocol Compliance: Use Blueprint Factory, NOT legacy dockerizer
                ctx_dict = ctx.model_dump()
                temp_repo_path = None
                
                # Server Mode: Clone repo locally to allow Railpack plan generation
                # This ensures we have a build plan even if the droplet doesn't have railpack installed
                if os.getenv("XENFRA_SERVICE_MODE") == "true" and repo_url:
                    try:
                        temp_repo_path = tempfile.mkdtemp()
                        logger(f"   - Cloning {repo_url} for detection...")
                        # Shallow clone to save time
                        subprocess.run(
                            ["git", "clone", "--depth", "1", repo_url, temp_repo_path],
                            check=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL
                        )
                        ctx_dict["repo_path"] = temp_repo_path
                        
                        # Populate file_manifest for fallback detection (Crucial for Railpack Blueprint fallback)
                        manifest_files = []
                        for root, dirs, files in os.walk(temp_repo_path):
                            if ".git" in dirs:
                                dirs.remove(".git")  # Don't traverse .git
                            
                            for f in files:
                                rel_path = os.path.relpath(os.path.join(root, f), temp_repo_path)
                                file_entry = {"path": rel_path}
                                
                                # Read content for critical files (for detection logic)
                                if f in ["package.json", "next.config.js", "next.config.ts", "next.config.mjs", "nuxt.config.ts", "vite.config.ts"]:
                                    try:
                                        with open(os.path.join(root, f), "r", encoding="utf-8") as meta_f:
                                            file_entry["content"] = meta_f.read()
                                    except Exception:
                                        pass
                                        
                                manifest_files.append(file_entry)
                        
                        ctx_dict["file_manifest"] = manifest_files
                        logger(f"   - Hydrated file_manifest with {len(manifest_files)} files for detection")

                    except Exception as e:
                        logger(f"   - Clone for detection failed (proceeding without plan): {e}")

                try:
                    rendered_assets = render_blueprint(ctx_dict)
                finally:
                    if temp_repo_path:
                        shutil.rmtree(temp_repo_path, ignore_errors=True)
                
                if not rendered_assets:
                    raise DeploymentError("Failed to render deployment assets via Blueprint Factory.", stage="Asset Generation")
            
            # Merge extra assets (like service-specific Dockerfiles)
            if extra_assets:
                rendered_assets.update(extra_assets)
                logger(f"   - Included {len(extra_assets)} extra assets")
            
            for filename in rendered_assets:
                self.emitter.progress(DeploymentPhase.CELL_BLUEPRINT, 50, f"Encoded {filename}")
            
            self.emitter.complete_phase(DeploymentPhase.CELL_BLUEPRINT)

            # === 3. CLOUD-INIT STAGE ===
            self.emitter.start_phase(DeploymentPhase.GENESIS_SCRIPT, "Writing the Genesis Script (Server Provisioning)")
            from . import recipes
            cloud_init_script = recipes.generate_stack(ctx.model_dump(), is_dockerized=is_dockerized)
            self.emitter.complete_phase(DeploymentPhase.GENESIS_SCRIPT)
            
            # === ZEN MODE: DRY RUN EXIT ===
            if dry_run:
                logger("\n[bold cyan]🧪 DRY RUN COMPLETE: Returning generated assets[/bold cyan]")
                return {
                    "status": "DRY_RUN",
                    "cloud_init": cloud_init_script,
                    "assets": rendered_assets,
                    "context": ctx.model_dump(),
                    "droplet_request": {
                         "name": name,
                         "region": region,
                         "size": size,
                         "image": image
                    }
                }

            # === ZEN MODE: PRE-MITOSIS (THE RALPH LOOP) ===
            # Replaces the static E2B gate with an autonomous repair loop
            if not dry_run:
                max_retries = 2
                attempt = 0
                
                while attempt <= max_retries:
                    attempt += 1
                    logger(f"\n[bold yellow]🛡️ E2B GATE (Attempt {attempt}/{max_retries + 1}): Verifying build...[/bold yellow]")
                    
                    try:
                         # 1. Verify
                         result = self.client.intelligence.verify(
                            logs="PRE-DEPLOYMENT AUDIT", 
                            code_snippets=[{"path": k, "content": v} for k, v in ctx_dict.get("file_manifest", [])]
                         )
                         
                         if result.get("status") == "failed":
                             raise Exception(f"Sandbox verification failed: {result.get('error')}")
                             
                         logger("   - [Verified] E2B Sandbox check passed.")
                         break # Success! Exit loop.
                         
                    except Exception as e:
                        if attempt > max_retries:
                            raise DeploymentError(f"E2B Verification Failed after {attempt} attempts: {e}", stage="Pre-Mitosis")
                        
                        logger(f"   - [Diagnostics] Verification failed. Asking Ralph for a fix...")
                        
                        # 2. Diagnose & Fix
                        try:
                            # Diagnose using the error logs/message
                            diagnosis = self.client.intelligence.diagnose(
                                logs=str(e),
                                services=services 
                            )
                            
                            # Check if diagnosis suggested a patch
                            # Note: DiagnosisResponse model structure assumed based on intelligence.py
                            if hasattr(diagnosis, "patch") and diagnosis.patch and diagnosis.patch.target_file:
                                logger(f"   - [Ralph] Found fix: {diagnosis.suggestion}")
                                logger(f"   - [Patching] Applying fix to {diagnosis.patch.target_file}...")
                                
                                # Apply patch to local temp clone or CWD (if CLI mode)
                                base_dir = Path(temp_repo_path) if temp_repo_path else Path(os.getcwd())
                                
                                # Use PatchManager
                                patcher = PatchManager(base_dir)
                                filename = getattr(diagnosis.patch, "target_file", None) or diagnosis.patch.file
                                
                                if not filename:
                                     logger("   [red]Patch missing filename. Skipping.[/red]")
                                     continue

                                # Extract params from Pydantic or Dict
                                operation = getattr(diagnosis.patch, "operation", "append")
                                search_content = getattr(diagnosis.patch, "search_content", None)
                                replacement_content = getattr(diagnosis.patch, "content", None) or diagnosis.patch.value
                                json_path = getattr(diagnosis.patch, "path", None)

                                if not replacement_content and operation != "create": 
                                     # create might imply empty file? Usually needs content.
                                     logger("   [red]Patch missing content. Skipping.[/red]")
                                     continue
                                
                                # Apply
                                p_result = patcher.apply_patch(
                                    filename=filename,
                                    operation=operation,
                                    content=replacement_content,
                                    search_content=search_content,
                                    value=replacement_content, # Pass as value too for json/yaml
                                    path=json_path
                                )
                                
                                if p_result.success:
                                     logger(f"   [green]- [Ralph] {p_result.message}[/green]")
                                else:
                                     logger(f"   [red]- [Patch Failed] {p_result.message}[/red]")

                                    
                                # Refresh context manifest for the next verification attempt
                                for f_entry in ctx_dict.get("file_manifest", []):
                                     if f_entry["path"] == diagnosis.patch.target_file:
                                          with open(target_path, "r", encoding="utf-8") as f:
                                              f_entry["content"] = f.read()
                                
                                # Re-render assets with new content
                                logger("   - [Regenerating] Re-rendering deployment assets...")
                                rendered_assets = render_blueprint(ctx_dict)
                                
                            else:
                                logger("   - [Ralph] No auto-fix available.")
                                raise e
                                
                        except Exception as diagnosis_error:
                             logger(f"   - [Ralph] Auto-fix failed: {diagnosis_error}")
                             raise e

            # === 4. DROPLET CREATION STAGE ===
            self.emitter.start_phase(DeploymentPhase.CELL_BIRTH, "Submitting DNA to provider (Creating Droplet)")
            
            # Machine Reuse: Look for existing droplet with same name and 'xenfra' tag
            existing_droplets = digitalocean.Manager(token=self.token).get_all_droplets(tag_name="xenfra")
            droplet = next((d for d in existing_droplets if d.name == name), None)
            
            if droplet and droplet.status == "active":
                logger(f"   - Found existing active droplet '{name}' (ID: {droplet.id}). Reusing machine...")
            else:
                if droplet:
                    logger(f"   - Found existing droplet '{name}' but it's not active ({droplet.status}). Creating new one...")
                
                droplet = digitalocean.Droplet(
                    token=self.token,
                    name=name,
                    region=region,
                    image=image,
                    size_slug=size,
                    ssh_keys=[ssh_key.id],
                    user_data=cloud_init_script,
                    tags=["xenfra"],
                    private_networking=True,
                )
                droplet.create()
                self.emitter.complete_phase(DeploymentPhase.CELL_BIRTH, f"Cell born (ID: {droplet.id})")

            # === 5. POLLING STAGE ===
            self.emitter.start_phase(DeploymentPhase.NEURAL_SYNC, "Establishing neural connection to provider")
            while True:
                droplet.load()
                if droplet.status == "active":
                    self.emitter.progress(DeploymentPhase.NEURAL_SYNC, 50, "Droplet active. Harmonizing SSH...")
                    break
                
                self.emitter.progress(DeploymentPhase.NEURAL_SYNC, 25, f"Syncing with cloud provider... (Wait: {polling_interval}s)")
                time.sleep(polling_interval)

            ip_address = droplet.ip_address

            # Retry SSH connection
            conn = None
            max_retries = 12  # 2-minute timeout for SSH
            for i in range(max_retries):
                try:
                    self.emitter.progress(DeploymentPhase.NEURAL_SYNC, 75, f"Syncing neural pathways ({i + 1}/{max_retries})...")
                    conn = self._get_connection(ip_address)
                    conn.open()
                    self.emitter.progress(DeploymentPhase.NEURAL_SYNC, 90, "Neural link established. Synapsing...")
                    break
                except Exception as e:
                    if i < max_retries - 1:
                        logger("   - SSH connection failed. Retrying in 10s...")
                        time.sleep(10)
                    else:
                        raise DeploymentError(
                            f"Failed to establish SSH connection: {e}", stage="Polling"
                        )

            if not conn or not conn.is_connected:
                raise DeploymentError("Could not establish SSH connection.", stage="Polling")

            logger("   - [DEBUG] Entering SSH context for Phase 5 polling...")
            with conn:
                last_log_line = 0
                logger("   - Polling server setup log (/root/setup.log)...")
                for i in range(120):  # 20-minute timeout
                    # Heartbeat
                    if i % 3 == 0:  # Every 30 seconds
                        logger(f"   - Phase 5 Heartbeat: Waiting for setup completion ({i+1}/120)...")

                    # Check for completion with timeout
                    try:
                        check_result = conn.run("test -f /root/setup_complete", warn=True, hide=True, timeout=10)
                        if check_result.ok:
                            logger("   - Cloud-init setup complete.")
                            break
                    except Exception as e:
                        logger(f"   - [Warning] Status check failed: {e}. Retrying...")
                    
                    # Tail the setup log for visibility
                    try:
                        log_result = conn.run(f"tail -n +{last_log_line + 1} /root/setup.log 2>/dev/null", warn=True, hide=True, timeout=10)
                        if log_result.ok and log_result.stdout.strip():
                            new_lines = log_result.stdout.strip().split("\n")
                            for line in new_lines:
                                if line.strip():
                                    logger(f"     [Server Setup] {line.strip()}")
                            last_log_line += len(new_lines)
                    except Exception as e:
                        # Log doesn't exist yet or tail failed
                        pass

                    time.sleep(10)
                else:
                    raise DeploymentError(
                        "Server setup script failed to complete in time.", stage="Polling"
                    )

            # === 6. CODE UPLOAD STAGE ===
            self.emitter.start_phase(DeploymentPhase.GENOME_TRANSFER, "Transferring project genome (Code Upload)")
            with self._get_connection(ip_address) as conn:
                # Option 1: Git clone (if repo_url provided)
                if repo_url:
                    # Authenticate if token provided (Zen Mode: Private Repo Support)
                    authenticated_url = repo_url
                    if github_token and "github.com" in repo_url:
                        self.emitter.progress(DeploymentPhase.GENOME_TRANSFER, 25, "Injecting authentication for private genome")
                        if repo_url.startswith("https://"):
                            authenticated_url = repo_url.replace("https://", f"https://x-access-token:{github_token}@")
                        elif repo_url.startswith("http://"):
                            authenticated_url = repo_url.replace("http://", f"http://x-access-token:{github_token}@")
                    
                    # Sanitize log (don't show token)
                    log_url = repo_url
                    logger(f"   - Cloning repository from {log_url} (branch: {branch})...")
                    
                    # Use --branch to checkout specific branch, --single-branch for efficiency
                    # Sanitize inputs to prevent command injection
                    safe_branch = shlex.quote(branch)
                    safe_url = shlex.quote(authenticated_url)
                    clone_cmd = f"git clone --branch {safe_branch} --single-branch {safe_url} /root/app"
                    result = conn.run(clone_cmd, warn=True, hide=True)
                    if result.failed:
                        # Try without --single-branch in case branch doesn't exist
                        # Clean up any partial clone first
                        logger(f"   - Branch '{branch}' clone failed, trying default branch...")
                        conn.run("rm -rf /root/app", warn=True, hide=True)
                        conn.run(f"git clone {safe_url} /root/app")
                
                # Option 2: Delta upload (if file_manifest provided)
                elif file_manifest and get_file_content:
                    logger(f"   - Syncing {len(file_manifest)} files via delta upload...")
                    
                    # Ensure /root/app exists
                    conn.run("mkdir -p /root/app", hide=True)
                    
                    for i, file_info in enumerate(file_manifest):
                        path = file_info['path']
                        sha = file_info['sha']
                        size = file_info.get('size', 0)

                        # Security: Validate path to prevent directory traversal attacks
                        if '..' in path or path.startswith('/') or path.startswith('~'):
                            logger(f"   - [Security] Skipping suspicious path: {path}")
                            continue

                        # Build Safety: Placeholder for 0-byte critical files
                        # (Hatchling/Pip fail if README.md or __init__.py are mentioned but empty)
                        is_critical_empty = (
                            size == 0 and
                            (path.lower() == 'readme.md' or path.endswith('__init__.py'))
                        )

                        # Smart Incremental Sync: Check if file exists and has same SHA
                        # Sanitize path to prevent command injection
                        safe_remote_path = shlex.quote(f"/root/app/{path}")
                        check_sha_cmd = f"sha256sum {safe_remote_path}"
                        result = conn.run(check_sha_cmd, warn=True, hide=True)
                        
                        if result.ok:
                            remote_sha = result.stdout.split()[0]
                            if remote_sha == sha and not is_critical_empty:
                                # File already exists and matches, skip upload
                                continue

                        # Get file content from storage
                        content = get_file_content(sha)
                        if content is None:
                            raise DeploymentError(f"File not found in storage: {path} (sha: {sha})", stage="Code Upload")
                        
                        # Apply placeholder if critical and empty
                        if is_critical_empty:
                            content = b"# xenfra placeholder\n"
                            logger(f"   - [Zen Mode] Injected placeholder into empty {path}")

                        # Create directory if needed
                        dir_path = os.path.dirname(path)
                        if dir_path:
                            safe_dir_path = shlex.quote(f"/root/app/{dir_path}")
                            conn.run(f"mkdir -p {safe_dir_path}", warn=True, hide=True)

                        # Use SFTP for file transfer (handles large files)
                        # Note: SFTP doesn't use shell, so path doesn't need quoting here
                        from io import BytesIO
                        remote_path = f"/root/app/{path}"
                        conn.put(BytesIO(content), remote_path)
                        
                        # Progress update every 10 files
                        if (i + 1) % 10 == 0 or i == len(file_manifest) - 1:
                            logger(f"   - Synced {i + 1}/{len(file_manifest)} files...")
                    
                    logger(f"   - All {len(file_manifest)} files synced.")
                
                # Option 3: Local rsync (only works locally, not in service mode)
                else:
                    # Note: Early validation in Phase 0 should have caught this for service mode
                    private_key_path = str(Path.home() / ".ssh" / "id_rsa")
                    # Use subprocess with list args instead of shell=True for security
                    rsync_args = [
                        "rsync", "-avz",
                        "--exclude=.git", "--exclude=.venv", "--exclude=__pycache__",
                        "-e", f"ssh -i {shlex.quote(private_key_path)} -o StrictHostKeyChecking=no",
                        ".", f"root@{ip_address}:/root/app/"
                    ]
                    logger(f"   - Uploading local code via rsync...")
                    result = subprocess.run(rsync_args, capture_output=True, text=True)
                    if result.returncode != 0:
                        raise DeploymentError(f"rsync failed: {result.stderr}", stage="Code Upload")
            logger("   - Code upload complete.")

            
            # === 6.5. WRITE DEPLOYMENT ASSETS TO DROPLET ===
            self.emitter.start_phase(DeploymentPhase.MEMBRANE_FORMATION, "Forming the biological membrane (Writing Assets)")
            # Whitelist of allowed deployment asset filenames (exact match or prefix patterns)
            ALLOWED_ASSET_FILENAMES = {"docker-compose.yml", ".env", "Caddyfile", "railpack-plan.json"}
            ALLOWED_ASSET_PREFIXES = ("Dockerfile",)  # Allows Dockerfile, Dockerfile.service-name, etc.
            
            def is_allowed_asset(filename: str) -> bool:
                """Check if a filename is in the allowlist (exact match or prefix match)."""
                if filename in ALLOWED_ASSET_FILENAMES:
                    return True
                for prefix in ALLOWED_ASSET_PREFIXES:
                    if filename == prefix or filename.startswith(f"{prefix}."):
                        return True
                return False
            
            with self._get_connection(ip_address) as conn:
                for filename, content in rendered_assets.items():
                    # Security: Only allow whitelisted filenames to prevent path injection
                    if not is_allowed_asset(filename):
                        logger(f"   - [Security] Skipping unknown asset: {filename}")
                        continue

                    # Use heredoc with unique delimiter to write file content
                    # Single-quoted delimiter prevents shell variable expansion
                    logger(f"   - Writing {filename}...")
                    try:
                        # Use base64 encoding to safely transfer file content
                        # Use printf to avoid issues with special characters
                        import base64
                        encoded_content = base64.b64encode(content.encode()).decode()
                        # Use printf with %s to handle any special characters in base64
                        # Filename is whitelisted so safe to use directly
                        conn.run(f"printf '%s' '{encoded_content}' | base64 -d > /root/app/{filename}")
                    except Exception as e:
                        raise DeploymentError(f"Failed to write {filename}: {e}", stage="Asset Write")
            self.emitter.complete_phase(DeploymentPhase.MEMBRANE_FORMATION)

            # === 7. FINAL DEPLOY STAGE ===
            if is_dockerized:
                self.emitter.start_phase(DeploymentPhase.CELL_REIFY, "Reifying the cell (Building Containers)")
                with self._get_connection(ip_address) as conn:
                    # Step 7a: Build containers (capture output for debugging)
                    logger("   - Building Docker image (this may take a few minutes)...")
                    
                    # Check if we have a generated railpack plan
                    # If railpack-plan.json exists, we use it for a zero-config build
                    use_railpack_plan = "railpack-plan.json" in rendered_assets
                    
                    if use_railpack_plan:
                        logger("   - Using Railpack Plan for zero-config build...")
                        # Build with Docker buildx using Railpack frontend and the uploaded plan
                        build_result = conn.run(
                            'cd /root/app && docker buildx build '
                            '--build-arg BUILDKIT_SYNTAX="ghcr.io/railwayapp/railpack-frontend" '
                            '-f railpack-plan.json -t app:latest --load . 2>&1',
                            warn=True, hide=False
                        )
                    else:
                        # Fallback: Use docker compose build
                        # We now rely on docker-compose.yml 'build.args' mapping (set by RailpackAdapter)
                        # to pick up variables from the .env file automatically.
                        # This avoids shell quoting issues with complex values (like email headers).
                        build_result = conn.run(
                            "cd /root/app && docker compose build --no-cache 2>&1",
                            warn=True,
                            hide=False
                        )
                    
                    if build_result.failed or build_result.return_code != 0:
                        # Capture build logs for error message
                        build_output = build_result.stdout or build_result.stderr or "No output captured"
                        raise DeploymentError(
                            f"Docker build failed (exit code {build_result.return_code}):\n{build_output[-2000:]}",
                            stage="Build"
                        )
                    logger("   - Docker build complete.")

                    # Step 7b: Start containers
                    logger("   - Starting containers...")
                    
                    if use_railpack_plan:
                        # Railpack built image, run with docker directly
                        # Stop any existing container first
                        conn.run("docker stop xenfra-app 2>/dev/null || true", warn=True, hide=True)
                        conn.run("docker rm xenfra-app 2>/dev/null || true", warn=True, hide=True)
                        
                        # Run the container with port mapping
                        app_port = ctx.port or 8000
                        up_result = conn.run(
                            f"docker run -d --name xenfra-app -p {app_port}:{app_port} "
                            f"--restart unless-stopped --env-file /root/app/.env app:latest 2>&1 || "
                            f"docker run -d --name xenfra-app -p {app_port}:{app_port} --restart unless-stopped app:latest 2>&1",
                            warn=True, hide=True
                        )
                    else:
                        # Docker compose
                        up_result = conn.run(
                            "cd /root/app && docker compose up -d 2>&1",
                            warn=True,
                            hide=True
                        )
                    
                    if up_result.failed or up_result.return_code != 0:
                        # Capture logs if startup failed
                        if use_railpack_plan:
                            logs_result = conn.run(
                                "docker logs xenfra-app --tail 50 2>&1",
                                warn=True, hide=True
                            )
                        else:
                            logs_result = conn.run(
                                "cd /root/app && docker compose logs --tail 50 2>&1",
                                warn=True,
                                hide=True
                            )
                        container_logs = logs_result.stdout or "No logs available"
                        raise DeploymentError(
                            f"Container startup failed:\n{up_result.stdout or up_result.stderr or 'No output'}\n\nContainer logs:\n{container_logs[-2000:]}",
                            stage="Deploy"
                        )
                self.emitter.complete_phase(DeploymentPhase.CELL_REIFY)
            else:
                logger("\n[bold blue]PHASE 7: STARTING HOST-BASED APPLICATION[/bold blue]")
                start_command = context.get("command", f"uvicorn main:app --port {context.get('port', 8000)}")

                # Security: Validate start_command to prevent command injection
                # Only allow safe characters: alphanumeric, dots, colons, hyphens, underscores, spaces, equals, slashes
                import re
                if not re.match(r'^[a-zA-Z0-9._:=\-\s/]+$', start_command):
                    raise DeploymentError(
                        f"Invalid start command - contains unsafe characters: {start_command}",
                        stage="Deploy"
                    )

                with self._get_connection(ip_address) as conn:
                    result = conn.run(f"cd /root/app && python3 -m venv .venv && .venv/bin/pip install -r requirements.txt && nohup .venv/bin/{start_command} > app.log 2>&1 &", hide=True)
                    if result.failed:
                        raise DeploymentError(f"Host-based start failed: {result.stderr}", stage="Deploy")
                logger(f"   - Application started via: {start_command}")

            # Multi-service: Configure Caddy for path-based routing (Gateway or Single-Droplet)
            if multi_service_caddy:
                logger("   - Configuring Caddy for multi-service routing...")
                with self._get_connection(ip_address) as conn:
                    # Write Caddyfile to Caddy's config directory
                    import base64
                    encoded_caddy = base64.b64encode(multi_service_caddy.encode()).decode()
                    conn.run(f"printf '%s' '{encoded_caddy}' | base64 -d > /etc/caddy/Caddyfile", warn=True)
                    # Reload Caddy to pick up new config
                    conn.run("systemctl reload caddy || systemctl restart caddy", warn=True)
                logger("   - Caddy configured for path-based routing")

            # === 8. VERIFICATION STAGE ===
            self.emitter.start_phase(DeploymentPhase.VITALS_CHECK, "Checking vitals (Health Check)")
            
            # Give container a moment to initialize before first health check
            time.sleep(5)
            
            app_port = ctx.port or 8000
            for i in range(24):  # 2-minute timeout for health checks
                logger(f"   - Health check attempt {i + 1}/24...")
                with self._get_connection(ip_address) as conn:
                    # Check if running
                    if is_dockerized:
                        # Check for railpack container first, then docker-compose
                        ps_result = conn.run("docker ps --filter name=xenfra-app --format '{{.Status}}'", hide=True, warn=True)
                        if ps_result.ok and ps_result.stdout.strip():
                            # Railpack container exists
                            ps_output = ps_result.stdout.lower()
                            running = "up" in ps_output
                            if "restarting" in ps_output:
                                logs = conn.run("docker logs xenfra-app --tail 20", hide=True).stdout
                                raise DeploymentError(f"Application is crash-looping (restarting). Logs:\n{logs}", stage="Verification")
                        else:
                            # Try docker-compose
                            ps_result = conn.run("cd /root/app && docker compose ps", hide=True, warn=True)
                            ps_output = ps_result.stdout.lower() if ps_result.stdout else ""
                            # Docker Compose V1 shows "running", V2 shows "Up" in status
                            running = "running" in ps_output or " up " in ps_output
                            if "restarting" in ps_output:
                                logs = conn.run("cd /root/app && docker compose logs --tail 20", hide=True).stdout
                                raise DeploymentError(f"Application is crash-looping (restarting). Logs:\n{logs}", stage="Verification")
                    else:
                        ps_result = conn.run("ps aux | grep -v grep | grep python", hide=True)
                        running = ps_result.ok and len(ps_result.stdout.strip()) > 0

                    if not running:
                        time.sleep(5)
                        continue

                    # Check if application is responsive (port is listening)
                    # Accept ANY HTTP response (including 404) - it means the app is running
                    # Use curl with -w to get HTTP code, accept any response >= 100
                    port_check = conn.run(
                        f"curl -s -o /dev/null -w '%{{http_code}}' --connect-timeout 3 http://localhost:{app_port}/",
                        warn=True, hide=True
                    )
                    # curl may exit non-zero for 404, but still outputs HTTP code
                    http_code = port_check.stdout.strip()
                    
                    # Any HTTP response (200, 404, 500, etc.) means app is running
                    if http_code.isdigit() and int(http_code) >= 100:
                        self.emitter.complete_phase(DeploymentPhase.VITALS_CHECK, "Vitals healthy. Organism is alive.")

                        # === 9. PERSISTENCE STAGE ===
                        self.emitter.start_phase(DeploymentPhase.MEMORY_COMMIT, "Committing to long-term memory")
                        project = Project(
                            droplet_id=droplet.id,
                            name=droplet.name,
                            ip_address=ip_address,
                            status=droplet.status,
                            region=droplet.region["slug"],
                            size=droplet.size_slug,
                            user_id=user_id,  # Save the user_id
                        )
                        session.add(project)
                        session.commit()
                        self.emitter.complete_phase(DeploymentPhase.MEMORY_COMMIT)

                        return droplet  # Return the full droplet object
                time.sleep(5)
            else:
                # Capture logs on timeout failure
                with self._get_connection(ip_address) as conn:
                    logs = conn.run("cd /root/app && docker compose logs --tail 50", hide=True, warn=True).stdout if is_dockerized else ""
                raise DeploymentError(f"Application failed to become healthy in time. Logs:\n{logs}", stage="Verification")

        except Exception as e:
            # ZEN GAP FIX: Observability - Mark failure state
            self.emitter.fail_phase(self.emitter.current_phase or DeploymentPhase.NECROSIS, str(e))
            
            if droplet:
                if cleanup_on_failure:
                    self.emitter.start_phase(DeploymentPhase.APOPTOSIS, "Triggering apoptosis (Resource Cleanup)")
                    try:
                        # 1. Destroy droplet (DigitalOcean API)
                        logger(f"   - Destroying droplet '{droplet.name}'...")
                        droplet.destroy()
                        logger("   - Droplet destroyed.")

                        # 2. Remove from database
                        if session:
                            statement = select(Project).where(Project.droplet_id == droplet.id)
                            project_to_delete = session.exec(statement).first()
                            if project_to_delete:
                                session.delete(project_to_delete)
                                session.commit()
                                logger("   - Database record removed.")

                        self.emitter.complete_phase(DeploymentPhase.APOPTOSIS, "Organism recycled.")
                    except Exception as cleanup_error:
                        self.emitter.fail_phase(DeploymentPhase.APOPTOSIS, f"Recycling failed: {cleanup_error}")
                else:
                    self.emitter.emit(DeploymentPhase.NECROSIS, EventStatus.FAILED, f"Deployment failed. Server '{droplet.name}' preserved for diagnostics.")
            raise e
