
import json
import logging
import os
import re
from pathlib import Path
from typing import Any, Dict, Optional, Union
import yaml

# Try importing tomllib (Python 3.11+)
try:
    import tomllib
except ImportError:
    # Fallback/Mock for older python if needed, but project is >=3.13
    tomllib = None

from pydantic import BaseModel

logger = logging.getLogger(__name__)

class PatchResult(BaseModel):
    success: bool
    message: str
    diff: Optional[str] = None

class PatchManager:
    """
    Handles safe, structured patching of files based on their type.
    Prevents corruption of JSON/YAML/TOML by using parsers instead of text appending.
    """

    def __init__(self, base_dir: Path):
        self.base_dir = base_dir.resolve()

    def apply_patch(self, 
                    filename: str, 
                    operation: str, 
                    content: Optional[str] = None, 
                    search_content: Optional[str] = None, 
                    value: Optional[str] = None,
                    path: Optional[str] = None) -> PatchResult:
        """
        Dispatches the patch to the correct strategy based on file extension.
        """
        target_path = self.base_dir / filename
        
        # Security check: prevent directory traversal
        try:
            target_path.resolve().relative_to(self.base_dir)
        except ValueError:
            return PatchResult(success=False, message=f"Access denied: {filename} is outside project root.")

        if not target_path.exists() and operation != "create":
             # If operation is overwrite, we might allow creating
             if operation == "overwrite":
                 pass
             else:
                 return PatchResult(success=False, message=f"File not found: {filename}")

        # Determine Strategy
        ext = target_path.suffix.lower()
        
        try:
            if ext == ".json":
                return self._patch_json(target_path, operation, path, value or content)
            elif ext in [".yaml", ".yml"]:
                return self._patch_yaml(target_path, operation, path, value or content)
            elif ext == ".toml":
                # TOML Strategy: We lack a writer, so we use Smart Block Replacement but Validate syntax
                return self._patch_toml_smart(target_path, operation, content, search_content)
            else:
                return self._patch_text_smart(target_path, operation, content, search_content)
        except Exception as e:
            return PatchResult(success=False, message=f"Patching failed: {str(e)}")

    def _patch_json(self, file_path: Path, operation: str, json_path: Optional[str], value: Any) -> PatchResult:
        """Safe JSON Manipulation."""
        try:
            # Load
            if file_path.exists():
                text = file_path.read_text(encoding="utf-8")
                data = json.loads(text)
            else:
                data = {}

            # Parse input value if it looks like JSON/Dict
            new_val = value
            if isinstance(value, str):
                try:
                    new_val = json.loads(value)
                except json.JSONDecodeError:
                    pass # Keep as string

            # Apply
            if operation == "merge_key" and json_path:
                # Simple logic for top-level keys for now (e.g. "dependencies")
                # A full JSONPath impl would be complex.
                # Supporting "dependencies.requests" -> nested set
                keys = json_path.split(".")
                current = data
                for k in keys[:-1]:
                    current = current.setdefault(k, {})
                
                # Merge logic
                last_key = keys[-1]
                if isinstance(current.get(last_key), dict) and isinstance(new_val, dict):
                    current[last_key].update(new_val)
                else:
                    current[last_key] = new_val

            elif operation == "overwrite":
                 data = new_val

            else:
                # Default for JSON: "Add/Update root key" if path missing?
                # Or if operation="replace_block", we can't do that easily in JSON.
                # Fallback to Text strategy if operation is unknown for JSON?
                pass

            # Dump
            with open(file_path, "w", encoding="utf-8") as f:
                json.dump(data, f, indent=2)
            
            return PatchResult(success=True, message=f"Updated JSON {file_path.name}")

        except json.JSONDecodeError:
            return PatchResult(success=False, message=f"Invalid JSON in file {file_path.name}")

    def _patch_yaml(self, file_path: Path, operation: str, yaml_path: Optional[str], value: Any) -> PatchResult:
        """Safe YAML Manipulation."""
        try:
            if file_path.exists():
                data = yaml.safe_load(file_path.read_text(encoding="utf-8")) or {}
            else:
                data = {}

             # Parse value
            new_val = value
            if isinstance(value, str):
                try: 
                    new_val = yaml.safe_load(value)
                except:
                    pass

            if operation == "merge_key" and yaml_path:
                keys = yaml_path.split(".")
                current = data
                for k in keys[:-1]:
                    current = current.setdefault(k, {})
                
                last_key = keys[-1]
                if isinstance(current.get(last_key), dict) and isinstance(new_val, dict):
                    current[last_key].update(new_val)
                else:
                    current[last_key] = new_val

            elif operation == "overwrite":
                data = new_val
            
            with open(file_path, "w", encoding="utf-8") as f:
                yaml.dump(data, f, default_flow_style=False)
            
            return PatchResult(success=True, message=f"Updated YAML {file_path.name}")

        except yaml.YAMLError as e:
            return PatchResult(success=False, message=f"YAML Error: {e}")

    def _patch_toml_smart(self, file_path: Path, operation: str, content: str, search_content: Optional[str]) -> PatchResult:
        """
        Smart Text Patching for TOML, but validates the result is valid TOML.
        """
        # 1. Apply Text Patch
        res = self._patch_text_smart(file_path, operation, content, search_content)
        if not res.success:
            return res

        # 2. Verify Syntax (Safety Check)
        if tomllib:
            try:
                new_text = file_path.read_text(encoding="utf-8")
                tomllib.loads(new_text)
            except tomllib.TOMLDecodeError as e:
                # Revert!
                # Note: A real robust implementation needs a backup step.
                # For now, we warn.
                return PatchResult(success=False, message=f"Patch applied but resulted in INVALID TOML: {e}. (Recommend Revert)")
        return res

    def _patch_text_smart(self, file_path: Path, operation: str, content: str, search_content: Optional[str]) -> PatchResult:
        """
        Robust Text/Code Patching.
        Supports:
        - overwrite: Replaces entire file.
        - replace_block: Replaces exact block (safe).
        - replace_fuzzy: (TODO) Normalized whitespace replacement.
        - append_safe: Appends to end (legacy).
        """
        if not content:
            return PatchResult(success=False, message="No content provided for patch.")

        current_text = ""
        if file_path.exists():
            current_text = file_path.read_text(encoding="utf-8")

        if operation == "overwrite":
            file_path.write_text(content, encoding="utf-8")
            return PatchResult(success=True, message="File overwritten")

        elif operation == "replace_block":
            if not search_content:
                return PatchResult(success=False, message="Missing 'search_content' for block replacement.")
            
            if search_content in current_text:
                new_text = current_text.replace(search_content, content)
                file_path.write_text(new_text, encoding="utf-8")
                return PatchResult(success=True, message="Block replaced successfully")
            else:
                 # TODO: Try Fuzzy Match here?
                 return PatchResult(success=False, message="Search block not found exactly in file.")

        elif operation == "append":
             # Safe Append check: Ensure newline
             with open(file_path, "a", encoding="utf-8") as f:
                 if current_text and not current_text.endswith("\n"):
                     f.write("\n")
                 f.write(content)
             return PatchResult(success=True, message="Content appended")

        else:
             return PatchResult(success=False, message=f"Unknown operation: {operation}")
