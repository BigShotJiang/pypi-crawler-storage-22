from .base import BaseManager

class SandboxManager(BaseManager):
    """
    Manager for E2B Sandbox operations.
    """
    pass
