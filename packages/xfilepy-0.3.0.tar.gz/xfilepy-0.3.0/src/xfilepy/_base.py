import io
from abc import ABC, abstractmethod
from collections.abc import Sequence
from typing import Literal, Self, TextIO, TypeGuard, overload

BinReadMode = Literal["rb"]
BinWriteMode = Literal["wb", "ab"]
BinMode = BinReadMode | BinWriteMode
TextReadMode = Literal["r", "rt"]
TextWriteMode = Literal["w", "wt", "a", "at"]
TextMode = TextReadMode | TextWriteMode


def _is_bin_mode(mode: str) -> TypeGuard[BinMode]:
    return mode in ("rb", "wb", "ab")


class _BaseFileHandler(ABC):
    """Cross-platform, file handler using native pickers and security models.

    This class has overloads for creating file handlers via native file pickers
    and saving/loading persistent access grants. Supported platforms are
    Android, iOS, and Desktop (Windows, macOS, Linux). On all platforms you
    can choose files outside your app's sandbox using the native file picker
    without asking the user for broad filesystem permissions. Access to the
    chosen files is mediated by platform-specific security models (e.g., SAF on
    Android, security-scoped bookmarks on iOS). This allows your app to write
    to the files later without re-prompting the user, even across app restarts.

    Notes:
        - Methods that invoke the picker (and hence require user interaction)
          are **asynchronous** to not freeze the UI while waiting for the user.
          You must ``await`` them in an async context or wrap them with
          ``asyncio.run()`` in a sync context.
        - The concrete class exported as ``xfile.FileHandler`` is selected at
          import time based on the runtime platform.
    """

    @classmethod
    @abstractmethod
    def from_uri_string(cls, uri_string: str, require_write: bool = False) -> Self:
        """Create an instance from a previously persisted URI/bookmark string.

        The string is the value returned by :meth:`to_uri_string` on a prior run.
        Implementations should validate that the underlying grant/bookmark is
        still valid and (optionally) writable.

        Args:
            uri_string: Opaque string that identifies and authorizes access to
                a previously chosen file (e.g. Android content URI, iOS
                security-scoped bookmark, or desktop file path).
            require_write: If ``True``, the instance must have write access; if
                not possible, an exception should be raised.

        Returns:
            A platform-specific :class:`_BaseFileHandler` instance.

        Raises:
            ValueError: If ``uri_string`` is empty or malformed.
            RuntimeError: If the persisted grant/bookmark does not exist or
                does not meet the requested access level.
        """

    @classmethod
    @abstractmethod
    async def create_via_picker(cls, start_at: str | None = None) -> Self:
        """Open a native “Open File” picker and return a handler for the choice.

        This presents the system file chooser.

        Args:
            start_at: Optional platform-specific starting location (directory
                path or URI). Implementations may ignore this if unsupported.

        Returns:
            The handler.
        """

    @classmethod
    @abstractmethod
    async def create_via_multi_picker(
        cls, start_at: str | None = None
    ) -> Sequence[Self]:
        """Open a native picker allowing multiple file selections.

        Args:
            start_at: Optional hint for the initial directory/URI.

        Returns:
            The handler.
        """

    @classmethod
    @abstractmethod
    async def create_via_save_dialog(
        cls,
        default_name: str = "untitled.bin",
        start_at: str | None = None,
    ) -> Self:
        """Open a native “Save As” dialog and return a handler to the new file.

        The created file is empty unless the caller writes to it.

        Args:
            default_name: Suggested filename shown in the dialog. May be ignored
                by some platforms.
            start_at: Optional hint for initial directory/URI.

        Returns:
            The handler.
        """

    @abstractmethod
    def to_uri_string(self) -> str | None:
        """Return a persistable identifier for this file, if available.

        The returned string can be stored (e.g., in app settings) and later
        passed to :meth:`from_uri_string` to rehydrate the handler with the same
        permissions.

        Returns:
            Opaque string suitable for persistence, or ``None`` if the handler
            cannot produce one (e.g., no file selected yet).
        """

    @abstractmethod
    def has_access(self, require_write: bool = False) -> bool:
        """Report whether the current handler has valid access to the file.

        Args:
            require_write: If ``True``, also require write permission.

        Returns:
            ``True`` if access (and optionally write) is currently available,
            ``False`` otherwise.
        """

    @overload
    def open(self, mode: BinReadMode) -> io.BufferedReader: ...
    @overload
    def open(self, mode: BinWriteMode) -> io.BufferedWriter: ...
    @overload
    def open(
        self,
        mode: TextMode = "r",
        *,
        encoding: str | None = None,
        errors: str | None = None,
        newline: str | None = None,
        write_through: bool = False,
    ) -> TextIO: ...

    def open(
        self,
        mode: BinMode | TextMode = "r",
        *,
        encoding: str | None = None,
        errors: str | None = None,
        newline: str | None = None,
        write_through: bool = False,
    ) -> io.IOBase | TextIO:
        """Open the underlying file and return a file-like object.

        Args:
            mode:
                File open mode. Supported: ``"rb"``, ``"wb"``, ``"ab"`` for
                binary modes; ``"r"``, ``"rt"``, ``"w"``, ``"wt"``, ``"a"``,
                ``"at"`` for text modes. ``"+"`` (read/write) modes are not
                supported.
            encoding:
                Text encoding (for text modes). Defaults to ``"utf-8"``.
            errors:
                Error handling scheme for text modes. Defaults to ``"strict"``.
            newline:
                Newline handling for text modes. See ``io.TextIOWrapper``
                documentation for details.
        Returns:
            A file-like object supporting standard read/write operations.
        """
        bin_mode = _normalize_to_bin_mode(mode)

        if "b" in mode:  # binary mode does not take encoding/errors/newline
            if encoding is not None:
                raise ValueError("binary mode doesn't take an encoding argument")
            if errors is not None:
                raise ValueError("binary mode doesn't take an errors argument")
            if newline is not None:
                raise ValueError("binary mode doesn't take a newline argument")
            # permission checks + platform open
            return self._open_impl(bin_mode)

        # --- text mode ---
        if encoding is None:
            encoding = "utf-8"

        return io.TextIOWrapper(
            self._open_impl(bin_mode),
            encoding=encoding,
            errors=errors or "strict",
            newline=newline,
            write_through=write_through,
        )

    @overload
    @abstractmethod
    def _open_impl(self, mode: BinReadMode) -> io.BufferedReader: ...

    @overload
    @abstractmethod
    def _open_impl(self, mode: BinWriteMode) -> io.BufferedWriter: ...

    @abstractmethod
    def _open_impl(self, mode: BinMode) -> io.BufferedIOBase: ...

    def __init_subclass__(cls, **kwargs):
        """Ensure subclasses inherit a docstring if they don't define one.

        Copies the first available base-class docstring into ``cls.__doc__``
        if the subclass does not set its own, keeping documentation consistent
        across platform-specific implementations.
        """
        super().__init_subclass__(**kwargs)
        if cls.__doc__ in (None, ""):
            for b in cls.__mro__[1:]:
                if getattr(b, "__doc__", None):
                    cls.__doc__ = b.__doc__
                    break


def _normalize_to_bin_mode(mode: BinMode | TextMode) -> BinMode:
    """Normalize: treat "r"/"w"/"a" as text unless user says "b".

    map text modes to underlying binary modes
    """
    if "b" in mode and "t" in mode:
        raise ValueError("can't have text and binary mode at once")
    if "+" in mode:
        raise ValueError("read/write modes (with '+') are not supported")

    base_mode = mode.replace("t", "")
    if base_mode in ("r", "w", "a"):
        bin_mode = base_mode + "b"
    elif base_mode in ("rb", "wb", "ab"):
        bin_mode = base_mode
    else:
        raise ValueError(f"Unsupported mode: {mode!r}")

    if not _is_bin_mode(bin_mode):
        raise ValueError(f"Unsupported mode: {mode!r}")
    return bin_mode
