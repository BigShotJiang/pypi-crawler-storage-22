import asyncio
import io
from collections.abc import Sequence
from typing import Self, TypeVar, cast, overload

# -------------------- ANDROID (Kivy + pyjnius, SAF) --------------------
from android import activity  # type: ignore[unresolved-import]
from jnius import autoclass  # type: ignore[unresolved-import]

from . import exception
from ._base import BinMode, BinReadMode, BinWriteMode, _BaseFileHandler
from .saf_stream import SAFStream

T = TypeVar("T", bound="FileHandler")

INITIAL_URI_MIN_SDK = 26  # Android 8.0 (O)

PythonActivity = autoclass("org.kivy.android.PythonActivity")
Intent = autoclass("android.content.Intent")
Activity = autoclass("android.app.Activity")
UriCls = autoclass("android.net.Uri")
DocumentsContract = autoclass("android.provider.DocumentsContract")
BuildVERSION = autoclass("android.os.Build$VERSION")


class FileHandler(_BaseFileHandler):
    _router_bound = False
    _next_req = 14000
    _instances: dict[int, "FileHandler"] = {}

    @classmethod
    def _bind_router_once(cls) -> None:
        if not cls._router_bound:
            activity.bind(on_activity_result=cls._router)
            cls._router_bound = True

    @classmethod
    def _router(cls, request_code, result_code, data):  # Android callback signature
        inst = cls._instances.get(int(request_code))
        if inst:
            inst._on_activity_result(request_code, result_code, data)

    def __init__(self, _register: bool = True) -> None:
        self._uri = None
        self._picking: bool = False
        self._multi_fut: asyncio.Future[list[Self]] | None = None
        self._ready_loop: asyncio.AbstractEventLoop | None = None
        self._ready_fut: asyncio.Future[T] | None = None
        self._req: int | None = None

        if _register:
            self._req = FileHandler._next_req
            FileHandler._next_req += 1
            FileHandler._instances[self._req] = self
            FileHandler._bind_router_once()

    def _ensure_future(self) -> asyncio.Future[T]:
        # Must be called from within an active event loop context.
        loop = asyncio.get_running_loop()
        if self._ready_fut is None or self._ready_fut.done():
            self._ready_loop = loop
            self._ready_fut = cast(asyncio.Future, loop.create_future())
        return cast(asyncio.Future[T], self._ready_fut)

    # ---- constructors ----
    @classmethod
    def from_uri_string(cls, uri_string: str, require_write: bool = False) -> Self:
        inst = cls()
        ok, msg = inst._set_existing_persisted_uri(
            uri_string, require_write=require_write
        )
        if not ok:
            raise RuntimeError(f"URI not usable: {msg}")
        return inst

    @classmethod
    async def create_via_picker(cls, start_at: str | None = None) -> Self:
        inst = cls()
        fut = inst._ensure_future()  # create fut before starting picker (avoid race)
        inst._start_picker_open(start_at=start_at, multiple=False)
        return await fut

    @classmethod
    async def create_via_save_dialog(
        cls, default_name: str = "untitled.bin", start_at: str | None = None
    ) -> Self:
        inst = cls()
        fut = inst._ensure_future()
        inst._start_picker_create(default_name, "application/octet-stream", start_at)
        return await fut

    @classmethod
    async def create_via_multi_picker(
        cls, start_at: str | None = None
    ) -> Sequence[Self]:
        inst = cls()
        loop = asyncio.get_running_loop()
        inst._ready_loop = loop
        inst._multi_fut = loop.create_future()
        inst._start_picker_open(start_at=start_at, multiple=True)
        return await inst._multi_fut

    # ---- public API ----
    @overload
    def _open_impl(self, mode: BinReadMode) -> io.BufferedReader: ...
    @overload
    def _open_impl(self, mode: BinWriteMode) -> io.BufferedWriter: ...

    def _open_impl(self, mode: BinMode = "rb") -> io.BufferedIOBase:
        if self._uri is None:
            raise RuntimeError("No URI set. Use picker or from_uri_string().")
        raw = SAFStream(self._uri, mode)
        # Wrap in buffered layer for nicer performance + .read()/.readline()
        return io.BufferedReader(raw) if "r" in mode else io.BufferedWriter(raw)

    def to_uri_string(self) -> str | None:
        return self._uri.toString() if self._uri else None

    def has_access(self, require_write: bool = False) -> bool:
        if not self._uri:
            return False
        has, _can_r, can_w = self._has_persisted_grant(self._uri)
        return has and (not require_write or can_w)

    # --- internal picker helpers ----
    def _maybe_set_initial_uri(self, intent, start_at: str | None) -> None:
        try:
            if start_at and BuildVERSION.SDK_INT >= INITIAL_URI_MIN_SDK:
                uri = UriCls.parse(start_at)
                if uri is not None and "content" == uri.getScheme():
                    intent.putExtra(DocumentsContract.EXTRA_INITIAL_URI, uri)
        except Exception as e:  # pragma: no cover
            print("Ignored start_at:", e)

    def _start_picker_open(
        self, start_at: str | None = None, *, multiple: bool = False
    ) -> None:
        if self._picking:
            return
        self._picking = True
        intent = Intent(Intent.ACTION_OPEN_DOCUMENT)
        intent.addCategory(Intent.CATEGORY_OPENABLE)
        intent.setType("*/*")
        intent.addFlags(
            Intent.FLAG_GRANT_READ_URI_PERMISSION
            | Intent.FLAG_GRANT_WRITE_URI_PERMISSION
            | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION
        )
        if multiple:
            intent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, True)
        self._maybe_set_initial_uri(intent, start_at)
        PythonActivity.mActivity.startActivityForResult(intent, self._req)

    def _start_picker_create(
        self, default_name: str, mime_type: str, start_at: str | None = None
    ) -> None:
        if self._picking:
            return
        self._picking = True
        intent = Intent(Intent.ACTION_CREATE_DOCUMENT)
        intent.addCategory(Intent.CATEGORY_OPENABLE)
        intent.setType(mime_type)
        intent.putExtra(Intent.EXTRA_TITLE, default_name)
        intent.addFlags(
            Intent.FLAG_GRANT_READ_URI_PERMISSION
            | Intent.FLAG_GRANT_WRITE_URI_PERMISSION
            | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION
        )
        self._maybe_set_initial_uri(intent, start_at)
        PythonActivity.mActivity.startActivityForResult(intent, self._req)

    def _on_activity_result(  # noqa: PLR0912
        self, request_code, result_code, data
    ) -> None:
        try:
            loop = self._ready_loop

            if result_code == Activity.RESULT_OK and data is not None:
                clip = data.getClipData()

                # MULTI mode
                if self._multi_fut is not None:
                    handlers: list[FileHandler] = []

                    if clip is not None:
                        for i in range(clip.getItemCount()):
                            uri = clip.getItemAt(i).getUri()
                            self._take_persistable_grant(uri)
                            h = FileHandler(_register=False)
                            h._uri = uri
                            handlers.append(h)
                    else:
                        uri = data.getData()
                        if uri is not None:
                            self._take_persistable_grant(uri)
                            h = FileHandler(_register=False)
                            h._uri = uri
                            handlers.append(h)

                    if loop and not self._multi_fut.done():
                        loop.call_soon_threadsafe(self._multi_fut.set_result, handlers)
                    return

                # SINGLE mode
                uri = data.getData()
                if uri is None:
                    exc = RuntimeError("Picker returned OK but no Uri")
                    if loop and self._ready_fut and not self._ready_fut.done():
                        loop.call_soon_threadsafe(self._ready_fut.set_exception, exc)
                    return

                self._take_persistable_grant(uri)
                self._uri = uri
                if loop and self._ready_fut and not self._ready_fut.done():
                    loop.call_soon_threadsafe(self._ready_fut.set_result, self)
                return

            # cancelled
            exc = exception.UserCancelledError("Picker cancelled")
            if self._multi_fut is not None:
                if loop and not self._multi_fut.done():
                    loop.call_soon_threadsafe(self._multi_fut.set_exception, exc)
            elif loop and self._ready_fut and not self._ready_fut.done():
                loop.call_soon_threadsafe(self._ready_fut.set_exception, exc)

        finally:
            self._picking = False
            if self._req is not None:
                FileHandler._instances.pop(self._req, None)

    # ---- permission helpers ----
    def _take_persistable_grant(self, uri) -> None:
        cr = PythonActivity.mActivity.getContentResolver()
        flags = (
            Intent.FLAG_GRANT_READ_URI_PERMISSION
            | Intent.FLAG_GRANT_WRITE_URI_PERMISSION
        )
        cr.takePersistableUriPermission(uri, flags)

    def _has_persisted_grant(self, uri):
        cr = PythonActivity.mActivity.getContentResolver()
        perms = cr.getPersistedUriPermissions()
        for i in range(perms.size()):
            p = perms.get(i)
            if uri == p.getUri():
                return True, p.isReadPermission(), p.isWritePermission()
        return False, False, False

    def _set_existing_persisted_uri(self, uri_string: str, require_write: bool = False):
        try:
            uri = UriCls.parse(uri_string)
        except Exception as e:
            return False, f"Invalid URI: {e}"
        if uri is None or uri.getScheme() != "content":
            return False, "URI must be content://"
        has, _can_r, can_w = self._has_persisted_grant(uri)
        if not has:
            return False, "No persisted grant for this URI."
        if require_write and not can_w:
            return False, "Persisted grant is read-only."
        self._uri = uri
        return True, "OK"
