from __future__ import annotations

import asyncio
import io
import os
from collections.abc import Sequence
from pathlib import Path
from typing import Self, cast, overload

import crossfiledialog

from . import exception
from ._base import BinMode, BinReadMode, BinWriteMode, _BaseFileHandler


def _norm_dir(s: str | None) -> str | None:
    if not s:
        return None
    abs_path = Path(s).absolute()
    abs_dir = abs_path if abs_path.is_dir() else abs_path.parent
    return str(abs_dir) if abs_dir.is_dir() else None


class FileHandler(_BaseFileHandler):
    def __init__(self, path: str):
        self._path = Path(path).absolute()

    # ---- constructors ----
    @classmethod
    def from_uri_string(cls, uri_string: str, require_write: bool = False) -> Self:
        if not uri_string:
            raise ValueError("uri_string is empty or None.")
        inst = cls(uri_string)
        if not inst.has_access(require_write=require_write):
            raise RuntimeError("Path not accessible with requested permissions.")
        return inst

    @classmethod
    async def create_via_picker(cls, start_at: str | None = None) -> Self:
        path = await asyncio.to_thread(
            crossfiledialog.open_file,
            start_dir=_norm_dir(start_at),
        )
        # path = crossfiledialog.open_file(start_dir=_norm_dir(start_at))
        if not path:
            raise exception.UserCancelledError("Picker cancelled")
        return cls(path)

    @classmethod
    async def create_via_multi_picker(
        cls, start_at: str | None = None
    ) -> Sequence[Self]:
        paths = await asyncio.to_thread(
            crossfiledialog.open_multiple,
            start_dir=_norm_dir(start_at),
        )
        # paths = crossfiledialog.open_multiple(start_dir=_norm_dir(start_at))
        if not paths:
            raise exception.UserCancelledError("Picker cancelled")
        return [cls(p) for p in paths]

    @classmethod
    async def create_via_save_dialog(
        cls,
        default_name: str = "untitled.bin",
        start_at=None,
    ) -> Self:
        path = await asyncio.to_thread(
            crossfiledialog.save_file,
            start_dir=_norm_dir(start_at),
        )
        # path = crossfiledialog.save_file(start_dir=_norm_dir(start_at))
        if not path:
            raise exception.UserCancelledError("Picker cancelled")
        inst = cls(path)
        if not inst._path.exists():
            inst._path.open("wb").close()
        return inst

    # ---- public API ----
    def to_uri_string(self) -> str:
        return str(self._path)

    def has_access(self, require_write: bool = False) -> bool:
        p: Path = self._path
        if p.is_dir():
            return False

        if require_write:
            if p.exists():  # Existing file must be writable
                return p.is_file() and os.access(p, os.W_OK)
            # New file: parent directory must be writable
            return p.parent.is_dir() and os.access(p.parent, os.W_OK)

        return p.is_file() and os.access(p, os.R_OK)  # Read access

    @overload
    def _open_impl(self, mode: BinReadMode) -> io.BufferedReader: ...
    @overload
    def _open_impl(self, mode: BinWriteMode) -> io.BufferedWriter: ...

    def _open_impl(self, mode: BinMode = "rb") -> io.BufferedIOBase:
        f = self._path.open(mode)
        assert isinstance(f, io.BufferedIOBase)
        return cast(io.BufferedIOBase, f)
