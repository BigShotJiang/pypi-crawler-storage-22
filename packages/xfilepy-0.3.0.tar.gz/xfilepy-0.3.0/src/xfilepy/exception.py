class UserCancelledError(Exception):
    pass
