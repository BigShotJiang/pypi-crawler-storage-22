import io

from jnius import autoclass  # type: ignore[unresolved-import]

BufferedInputStream = autoclass("java.io.BufferedInputStream")
ByteArrayOutputStream = autoclass("java.io.ByteArrayOutputStream")
BufferedOutputStream = autoclass("java.io.BufferedOutputStream")
PythonActivity = autoclass("org.kivy.android.PythonActivity")


class SAFStream(io.RawIOBase):
    """
    File-like wrapper around Android SAF content:// Uri streams.
    This is *streaming* I/O: no reliable random access (seek) in general.
    """

    def __init__(self, uri, mode: str):
        super().__init__()
        self._uri = uri
        self._mode = mode
        self._cr = PythonActivity.mActivity.getContentResolver()
        self._inp = None
        self._out = None
        self._closed = False

        if "r" in mode:
            self._inp = self._cr.openInputStream(self._uri)
            self._bis = BufferedInputStream(self._inp)
        if any(m in mode for m in ("w", "a", "+")) and "r" not in mode:
            # SAF supports "w" and sometimes "wa". We'll map:
            # - "wb" -> "w"
            # - "ab" -> "wa" (fallback handled by your FileHandler if needed)
            android_mode = "wa" if "a" in mode else "w"
            self._out = self._cr.openOutputStream(self._uri, android_mode)
            self._bos = BufferedOutputStream(self._out)

    def readable(self) -> bool:
        return self._inp is not None

    def writable(self) -> bool:
        return self._out is not None

    def seekable(self) -> bool:
        return False

    def readinto(self, b) -> int:
        if not self.readable():
            raise io.UnsupportedOperation("not readable")
        # b is a writable buffer (bytearray/memoryview)
        mv = memoryview(b).cast("B")
        n = self._bis.read(mv)
        if n == -1:
            return 0
        return int(n)

    def write(self, b) -> int:
        if not self.writable():
            raise io.UnsupportedOperation("not writable")
        if isinstance(b, str):
            raise TypeError("a bytes-like object is required, not 'str'")
        self._bos.write(b)
        return len(b)

    def flush(self) -> None:
        if self._out is not None:
            self._bos.flush()

    def close(self) -> None:
        if self._closed:
            return
        try:
            try:
                if self._out is not None:
                    self._bos.flush()
            except Exception:
                pass

            # close streams
            if self._out is not None:
                try:
                    self._bos.close()
                except Exception:
                    pass
                try:
                    self._out.close()
                except Exception:
                    pass

            if self._inp is not None:
                try:
                    self._bis.close()
                except Exception:
                    pass
                try:
                    self._inp.close()
                except Exception:
                    pass
        finally:
            self._closed = True
            super().close()
