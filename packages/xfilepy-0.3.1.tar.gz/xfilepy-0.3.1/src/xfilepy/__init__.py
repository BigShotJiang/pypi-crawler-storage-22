"""
Cross‑platform (Android / iOS / Desktop) file handling library.

Design goals:
    typed public surface, explicit platform modules, zero side effects at
    import, late binding to the active platform, and no runtime deps for
    platforms you don’t use.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

from ._platform import current_platform
from .exception import UserCancelledError

__all__ = ["FileHandler", "UserCancelledError"]
__version__ = "0.1.0"
__docformat__ = "google"

if TYPE_CHECKING:
    from .desktop import FileHandler
else:
    _platform = current_platform()
    if _platform == "android":
        from .android import FileHandler
    elif _platform == "ios":
        from .ios import FileHandler
    else:
        from .desktop import FileHandler
