## [0.1.1] - 2026-1-30
### Modified
- Fix Fault: When skill script is not exists, execution will be fail
### Added
- Skill result file will download from sandbox to local workspace 'results' directory


## [0.1.0] - 2026-1-21
### Initial Version
- Support E2B Sandbox