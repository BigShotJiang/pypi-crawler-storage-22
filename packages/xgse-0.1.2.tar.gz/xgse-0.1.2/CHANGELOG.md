## [0.1.2] - 2026-2-2
### Modified
- Fix Fault: Skill task result return 'results' directory files name 
- Fix Bug: Generated code file save to 'results' directory


## [0.1.1] - 2026-1-30
### Modified
- Fix Fault: When skill script is not exists, execution will be fail
### Added
- Skill result file will download from sandbox to local workspace 'results' directory


## [0.1.0] - 2026-1-21
### Initial Version
- Support E2B Sandbox