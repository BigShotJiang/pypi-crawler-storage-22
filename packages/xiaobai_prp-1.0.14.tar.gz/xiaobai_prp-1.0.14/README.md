# PRP - Python Registry Provider (Python包索引提供商)

[![Downloads](https://pepy.tech/badge/xiaobai-prp)](https://pepy.tech/project/xiaobai-prp)

## 目录 (Table of Contents)
- [简介](#prp---python-registry-provider-python包索引提供商)
- [功能](#功能)
- [安装](#安装)
- [使用方法](#使用方法)
- [可用索引源](#可用索引源)
- [贡献](#贡献)
- [许可证](#许可证)

PRP (Python Registry Provider) 是一个用于管理Python包索引源的命令行工具，类似于npm的nrm。它允许您轻松切换不同的Python包索引，如PyPI、TUNA、阿里云等。

PRP (Python Registry Provider) is a command-line tool for managing Python package index sources, similar to `nrm` for npm. It allows you to easily switch between different Python package indexes such as PyPI, TUNA, Aliyun, and more.

## 功能 (Features)

- 列出所有可用包索引源 (List all available package index sources)
- 一键切换包索引源 (Switch between package index sources with a single command)
- 支持多源切换 (Support switching to multiple sources simultaneously)
- 添加自定义包索引源 (Add custom package index sources)
- 支持批量添加多个包索引源 (Support adding multiple package index sources at once)
- 删除包索引源 (Remove package index sources)
- 支持批量删除多个包索引源 (Support removing multiple package index sources at once)
- 恢复默认配置 (Restore to default configuration)
- 测试包索引源速度 (Test package index source speeds)
- 查看当前包索引源 (View current package index source)

## 安装 (Installation)

```bash
pip install xiaobai-prp
```

## 使用方法 (Usage)

### 列出所有包索引源 (List all package index sources)
```bash
prp ls
```

### 切换单个包索引源 (Switch to a single package index source)
```bash
prp use tuna
```

### 切换多个包索引源 (Switch to multiple package index sources)
```bash
# 第一个作为主源，后续作为额外源
prp use aliyun tuna pypi
```

### 添加自定义包索引源 (Add a custom package index source)
```bash
prp add myregistry https://myregistry.example.com/simple/
```

### 批量添加多个包索引源 (Add multiple package index sources at once)
```bash
# 支持添加多个源，格式为: name1 url1 [home1] name2 url2 [home2]
prp add myregistry1 https://myregistry1.example.com/simple/ myregistry2 https://myregistry2.example.com/simple/
```

### 添加带主页的包索引源 (Add package index source with homepage)
```bash
prp add myregistry https://myregistry.example.com/simple/ https://myregistry.example.com
```

### 批量添加带主页的多个包索引源 (Add multiple package index sources with homepages)
```bash
prp add myregistry1 https://myregistry1.example.com/simple/ https://myregistry1.example.com myregistry2 https://myregistry2.example.com/simple/ https://myregistry2.example.com
```

### 删除包索引源 (Delete a package index source)
```bash
prp del myregistry
```

### 批量删除多个包索引源 (Delete multiple package index sources at once)
```bash
prp del myregistry1 myregistry2
```

### 恢复默认配置 (Restore to default configuration)
```bash
prp reset
```

### 测试包索引源速度 (Test package index source speeds)
```bash
# 测试所有源的速度
prp test

# 测试特定源的速度
prp test tuna
```

### 显示当前包索引源 (Show current package index source)
```bash
prp current
```

### 显示版本信息 (Show version information)
```bash
prp version
```

## 可用索引源 (Available Registries)

- pypi - 官方PyPI仓库 (Official PyPI repository)
- pypi-test - PyPI测试仓库 (PyPI test repository)
- tuna - 清华大学镜像 (Tsinghua University mirror)
- aliyun - 阿里云镜像 (Alibaba Cloud mirror)
- douban - 豆瓣镜像 (Douban mirror)
- huawei - 华为云镜像 (Huawei Cloud mirror)
- ustc - 中国科学技术大学镜像 (University of Science and Technology of China mirror)

## 贡献 (Contributing)

欢迎贡献！请随时提交Pull Request。
Contributions are welcome! Please feel free to submit a Pull Request.

## 许可证 (License)

本项目采用GPLv3许可证 - 详见LICENSE文件。
This project is licensed under the GNU General Public License v3 (GPLv3) License - see the LICENSE file for details.