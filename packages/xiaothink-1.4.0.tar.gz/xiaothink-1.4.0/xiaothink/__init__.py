# xiaothink 模块初始化

# 不自动导入子模块，避免导入错误
# 用户需要根据使用的模型类型手动导入：
#
# T7.5 及以上模型（PaddlePaddle）：
#   from xiaothink.llm.inference_paddle import QianyanModel, TextGenerator
#
# T7 及以下模型（TensorFlow）：
#   from xiaothink.llm.inference.test_formal import Model

__version__ = '1.4.0'

__all__ = ['llm']
