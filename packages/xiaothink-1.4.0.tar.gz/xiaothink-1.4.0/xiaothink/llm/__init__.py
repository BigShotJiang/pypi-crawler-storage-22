# xiaothink.llm - 语言模型模块

# 不自动导入子模块，避免导入错误
# 用户需要手动导入：
# from xiaothink.llm.inference_paddle import QianyanModel  # PaddlePaddle
# from xiaothink.llm.inference.test_formal import Model   # TensorFlow

__all__ = ['inference', 'inference_paddle', 'img_zip', 'tools']
