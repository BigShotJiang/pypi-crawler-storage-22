# -*- coding: utf-8 -*-
"""
xiaothink.llm.inference_paddle - PaddlePaddle 推理模块

基于 PaddlePaddle 框架的语言模型推理接口，提供：
- TextGenerator: 文本生成器类
- QianyanModel: 千言模型封装类
- TOTModel: Train-On-Time 动态学习模型
- 模型创建和加载函数
- 分词器工具
"""

from .test import TextGenerator
from .test_formal import QianyanModel
from .models import create_model, get_mt_config
from .tokenizer import WordTokenizer, CharTokenizer, load_tokenizer

# 尝试导入 TOTModel（可选功能）
try:
    from .tot import TOTModel, DynamicLearningSystem
    TOT_AVAILABLE = True
except Exception as e:
    TOTModel = None
    DynamicLearningSystem = None
    TOT_AVAILABLE = False

__all__ = [
    'TextGenerator',
    'QianyanModel',
    'TOTModel',
    'DynamicLearningSystem',
    'create_model',
    'get_mt_config',
    'WordTokenizer',
    'CharTokenizer',
    'load_tokenizer',
    'TOT_AVAILABLE',
]
