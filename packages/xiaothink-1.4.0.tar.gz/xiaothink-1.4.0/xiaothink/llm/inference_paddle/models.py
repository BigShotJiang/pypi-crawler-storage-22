import paddle
import paddle.nn as nn
import paddle.nn.functional as F
from paddle import ParamAttr
from paddle.nn.initializer import TruncatedNormal, Constant

# MT管理机制
def get_mt_config(mt_name, vocab_size=None):
    mt_configs = {
        't7.5_paddle_small_instruct': {
            'vocab_size': -1,  # 默认值，会被实际vocab_size覆盖
            'embed_dim': 512,  # 嵌入维度
            'max_seq_len': 256,  # 上下文窗口长度
            'num_experts': 2,  # RWKV专家数量
            'rwkv_units': [512, 1024],  # 每个RWKV专家的单元数（浅层大宽度，深层小宽度）
            'rwkv_layers': [2, 1],  # 每个RWKV专家的层数
            'router_units': 128,  # 路由单元数
            'dropout': 0.1,
            'model_name': 'ckpt_test_t7.5_paddle_small_instruct'  # 混合专家模型名称
        },
        't7.5_paddle_small_instruct_thinking': {
            'vocab_size': -1,  # 默认值，会被实际vocab_size覆盖
            'embed_dim': 512,  # 嵌入维度
            'max_seq_len': 1024,  # 上下文窗口长度
            'num_experts': 2,  # RWKV专家数量
            'rwkv_units': [512, 1024],  # 每个RWKV专家的单元数（浅层大宽度，深层小宽度）
            'rwkv_layers': [2, 1],  # 每个RWKV专家的层数
            'router_units': 128,  # 路由单元数
            'dropout': 0.1,
            'model_name': 'ckpt_test_t7.5_paddle_small_instruct_thinking'  # 混合专家模型名称
        },
        't7.5_paddle_small_instruct_poem': {
            'vocab_size': -1,  # 默认值，会被实际vocab_size覆盖
            'embed_dim': 512,  # 嵌入维度
            'max_seq_len': 256,  # 上下文窗口长度
            'num_experts': 2,  # RWKV专家数量
            'rwkv_units': [512, 1024],  # 每个RWKV专家的单元数（浅层大宽度，深层小宽度）
            'rwkv_layers': [2, 1],  # 每个RWKV专家的层数
            'router_units': 128,  # 路由单元数
            'dropout': 0.1,
            'model_name': 'ckpt_test_t7.5_paddle_small_instruct_poem'  # 混合专家模型名称
        },
        't7.5_paddle_small_instruct_translator': {
            'vocab_size': -1,  # 默认值，会被实际vocab_size覆盖
            'embed_dim': 512,  # 嵌入维度
            'max_seq_len': 256,  # 上下文窗口长度
            'num_experts': 2,  # RWKV专家数量
            'rwkv_units': [512, 1024],  # 每个RWKV专家的单元数（浅层大宽度，深层小宽度）
            'rwkv_layers': [2, 1],  # 每个RWKV专家的层数
            'router_units': 128,  # 路由单元数
            'dropout': 0.1,
            'model_name': 'ckpt_test_t7.5_paddle_small_instruct_translator'  # 混合专家模型名称
        },
        't7.5_paddle_small_instruct_pro': {
            'vocab_size': -1,  # 默认值，会被实际vocab_size覆盖
            'embed_dim': 512,  # 嵌入维度
            'max_seq_len': 256,  # 上下文窗口长度
            'num_experts': 2,  # RWKV专家数量
            'rwkv_units': [512, 1024],  # 每个RWKV专家的单元数（浅层大宽度，深层小宽度）
            'rwkv_layers': [2, 1],  # 每个RWKV专家的层数
            'router_units': 128,  # 路由单元数
            'dropout': 0.1,
            'model_name': 'ckpt_test_t7.5_paddle_small_instruct_pro'  # 混合专家模型名称
        },
        't7.5_paddle_small_novel': {
            'vocab_size': -1,  # 默认值，会被实际vocab_size覆盖
            'embed_dim': 512,  # 嵌入维度
            'max_seq_len': 256,  # 上下文窗口长度
            'num_experts': 2,  # RWKV专家数量
            'rwkv_units': [512, 1024],  # 每个RWKV专家的单元数（浅层大宽度，深层小宽度）
            'rwkv_layers': [2, 1],  # 每个RWKV专家的层数
            'router_units': 128,  # 路由单元数
            'dropout': 0.1,
            'model_name': 'ckpt_test_t7.5_paddle_small_novel'  # 混合专家模型名称
        },
        
    }
    config = mt_configs.get(mt_name, mt_configs['t7.5_paddle_small_instruct_thinking'])
    # 计算ffn_hidden_size = embed_dim * dff_factor
    if 'dff_factor' in config:
        config['ffn_hidden_size'] = config['embed_dim'] * config['dff_factor_low']
    if 'dff_factor_low' in config:
        config['ffn_hidden_size_low'] = config['embed_dim'] * config['dff_factor']
    # 如果提供了vocab_size，使用实际值覆盖默认值
    if vocab_size is not None:
        config['vocab_size'] = vocab_size
    return config

# TokenAndPositionEmbedding_41_01_t7_5 - 切分式增强嵌入层（GPU并行版）
class TokenAndPositionEmbedding_41_01_t7_5(nn.Layer):
    """
    切分式词元嵌入层：基于编码后内容并行切分出词元
    替代原来的融合式算法，实现GPU并行计算
    """
    def __init__(self, maxlen, vocab_size, embed_dim, tst=False, max_token_len=4):
        super(TokenAndPositionEmbedding_41_01_t7_5, self).__init__()
        # 基础逐字Embedding层
        self.token_emb = nn.Embedding(
            num_embeddings=vocab_size,
            embedding_dim=embed_dim,
            weight_attr=ParamAttr(initializer=TruncatedNormal(std=0.02))
        )
        self.maxlen = maxlen  # 固定输出长度
        self.embed_dim = embed_dim
        self.max_token_len = max_token_len  # 最大词元长度（如4字词）
        self.trainable_flag = not tst
        
        # 词边界检测网络：为每个位置预测切分概率
        # 输入：当前字及其上下文的embedding
        self.boundary_detector = nn.Sequential(
            nn.Linear(embed_dim * 3, embed_dim,  # 当前字 + 左邻 + 右邻
                      weight_attr=ParamAttr(initializer=TruncatedNormal(std=0.02)),
                      bias_attr=ParamAttr(initializer=Constant(0.0))),
            nn.LayerNorm(embed_dim),
            nn.GELU(),
            nn.Dropout(0.1),
            nn.Linear(embed_dim, embed_dim // 2,
                      weight_attr=ParamAttr(initializer=TruncatedNormal(std=0.02)),
                      bias_attr=ParamAttr(initializer=Constant(0.0))),
            nn.GELU(),
            nn.Linear(embed_dim // 2, 1,  # 输出切分概率
                      weight_attr=ParamAttr(initializer=TruncatedNormal(std=0.02)),
                      bias_attr=ParamAttr(initializer=Constant(0.0)))
        )
        
        # 词元编码器：将不同长度的字符序列编码为词元embedding
        # 使用卷积实现不同长度词元的并行编码
        self.token_encoders = nn.LayerList([
            nn.Conv1D(embed_dim, embed_dim, kernel_size=k, padding=0,
                     weight_attr=ParamAttr(initializer=TruncatedNormal(std=0.02)),
                     bias_attr=ParamAttr(initializer=Constant(0.0)))
            for k in range(1, max_token_len + 1)  # 1-gram, 2-gram, 3-gram, 4-gram
        ])
        
        # 词元长度预测器：预测每个位置开始的词元长度
        self.length_predictor = nn.Sequential(
            nn.Linear(embed_dim, embed_dim // 2,
                      weight_attr=ParamAttr(initializer=TruncatedNormal(std=0.02)),
                      bias_attr=ParamAttr(initializer=Constant(0.0))),
            nn.GELU(),
            nn.Linear(embed_dim // 2, max_token_len,  # 输出4种长度的概率
                      weight_attr=ParamAttr(initializer=TruncatedNormal(std=0.02)),
                      bias_attr=ParamAttr(initializer=Constant(0.0)))
        )
        
        # 输出投影层
        self.output_proj = nn.Linear(embed_dim, embed_dim,
                                     weight_attr=ParamAttr(initializer=TruncatedNormal(std=0.02)),
                                     bias_attr=ParamAttr(initializer=Constant(0.0)))
        self.output_norm = nn.LayerNorm(embed_dim)
        
        # 可学习的温度系数，用于软分配
        self.temperature = self.create_parameter(
            shape=[1],
            dtype='float32',
            default_initializer=paddle.nn.initializer.Constant(10.0)
        )
        
    def forward(self, x):
        """
        切分式前向传播：并行处理整个序列
        x: [batch_size, seq_len]
        return: [batch_size, maxlen, embed_dim]
        """
        batch_size, seq_len = x.shape
        
        # Step 1: 逐字编码 [batch, seq_len] → [batch, seq_len, embed_dim]
        char_emb = self.token_emb(x)  # [B, L, D]
        
        # Step 2: 并行预测每个位置的切分边界概率
        # 构建上下文特征 [B, L, 3D]
        left_ctx = paddle.concat([paddle.zeros([batch_size, 1, self.embed_dim]), char_emb[:, :-1, :]], axis=1)
        right_ctx = paddle.concat([char_emb[:, 1:, :], paddle.zeros([batch_size, 1, self.embed_dim])], axis=1)
        ctx_feat = paddle.concat([left_ctx, char_emb, right_ctx], axis=-1)  # [B, L, 3D]
        
        # 预测切分概率 [B, L, 1]
        split_logits = self.boundary_detector(ctx_feat)  # [B, L, 1]
        split_probs = F.sigmoid(split_logits).squeeze(-1)  # [B, L]
        
        # Step 3: 为每个位置生成不同长度的候选词元embedding
        # 转置为 [B, D, L] 用于Conv1D
        char_emb_t = char_emb.transpose([0, 2, 1])  # [B, D, L]
        
        candidate_tokens = []
        for i, encoder in enumerate(self.token_encoders):
            k = i + 1  # 词元长度
            # 精确计算padding长度，让卷积输出长度刚好为seq_len
            # Conv1D输出长度公式：L_out = L_in + pad_left + pad_right - kernel_size + 1
            # 令L_out = seq_len，求解pad_left和pad_right（对称填充）
            pad_total = k - 1
            pad_left = pad_total // 2
            pad_right = pad_total - pad_left
            # 直接反射填充，无需后续裁剪/补全
            char_emb_padded = F.pad(char_emb_t, [pad_left, pad_right], mode='reflect')
            conv_out = encoder(char_emb_padded)  # [B, D, seq_len]
            candidate_tokens.append(conv_out.transpose([0, 2, 1]))  # [B, L, D]
        
        # Step 4: 预测每个位置开始的词元长度概率
        length_logits = self.length_predictor(char_emb)  # [B, L, max_token_len]
        length_probs = F.softmax(length_logits, axis=-1)  # [B, L, max_token_len]
        
        # Step 5: 基于切分概率和长度概率，使用可微分方式聚合词元
        # 计算每个位置作为词元起始位置的概率
        # 使用cumsum计算累积切分概率
        cumsum_split = paddle.cumsum(split_probs, axis=1)  # [B, L]
        
        # 使用注意力机制聚合词元
        # 为每个输出位置计算对输入位置的注意力权重
        output_emb = self._aggregate_tokens(
            char_emb, candidate_tokens, length_probs, split_probs, cumsum_split
        )
        
        # 投影到最终维度
        output_emb = self.output_norm(self.output_proj(output_emb))
        
        return output_emb
    
    def _aggregate_tokens(self, char_emb, candidate_tokens, length_probs, split_probs, cumsum_split):
        """
        完全并行的词元聚合
        char_emb: [B, L, D] 字符embedding
        candidate_tokens: list of [B, L, D] 不同长度的候选词元
        length_probs: [B, L, max_token_len] 长度概率
        split_probs: [B, L] 切分概率
        cumsum_split: [B, L] 累积切分概率
        return: [B, maxlen, D]
        """
        batch_size, seq_len, _ = char_emb.shape
        
        # Step 1: 计算软分配权重 [B, L, maxlen]
        # 使用cumsum_split计算每个位置对每个输出token的贡献权重
        # 使用Min-Max归一化，避免依赖序列末尾位置，提升鲁棒性
        cumsum_min = cumsum_split.min(axis=1, keepdim=True)  # [B, 1]，每个样本的累积切分最小值
        cumsum_max = cumsum_split.max(axis=1, keepdim=True)  # [B, 1]，每个样本的累积切分最大值
        # Min-Max归一化到[0, 1]，再映射到[0, maxlen-1]
        normalized_split = (cumsum_split - cumsum_min) / (cumsum_max - cumsum_min + 1e-6) * (self.maxlen - 1)  # [B, L]
        
        # 创建软分配：每个输入位置对每个输出位置的权重
        # 使用高斯核计算软分配权重
        output_indices = paddle.arange(self.maxlen, dtype='float32').reshape([1, 1, self.maxlen])  # [1, 1, maxlen]
        normalized_split_expanded = normalized_split.unsqueeze(-1)  # [B, L, 1]
        
        # 计算软分配权重（可微分）
        distance = paddle.abs(normalized_split_expanded - output_indices)  # [B, L, maxlen]
        # 使用可学习的温度系数，替代固定的10
        soft_assignment = F.softmax(-distance * self.temperature, axis=-1)  # [B, L, maxlen]，可学习温度系数
        
        # Step 2: 堆叠候选词元 [B, L, K, D]
        candidate_tokens_stacked = paddle.stack(candidate_tokens, axis=2)  # [B, L, K, D]
        
        # Step 3: 加权组合不同长度的候选词元 [B, L, D]
        # length_probs: [B, L, K] -> 扩展为 [B, L, K, 1]
        length_probs_expanded = length_probs.unsqueeze(-1)  # [B, L, K, 1]
        weighted_tokens = (candidate_tokens_stacked * length_probs_expanded).sum(axis=2)  # [B, L, D]
        
        # Step 4: 使用软分配权重聚合到输出位置 [B, maxlen, D]
        # weighted_tokens: [B, L, D], soft_assignment: [B, L, maxlen]
        # 结果: [B, maxlen, D]
        output = paddle.matmul(soft_assignment.transpose([0, 2, 1]), weighted_tokens)  # [B, maxlen, L] @ [B, L, D] = [B, maxlen, D]
        
        return output

class TransformerEncoderLayer(nn.Layer):
    def __init__(self, embed_dim, num_heads, ffn_hidden_size, dropout=0.1):
        super().__init__()
        # 使用标准多头注意力
        self.attn = nn.MultiHeadAttention(
            embed_dim=embed_dim,
            num_heads=num_heads,
            dropout=dropout,
            weight_attr=ParamAttr(initializer=TruncatedNormal(std=0.02)),
            bias_attr=ParamAttr(initializer=Constant(0.0))
        )
        self.attn_norm = nn.LayerNorm(embed_dim, epsilon=1e-5)
        
        self.ffn = nn.Sequential(
            nn.Linear(embed_dim, ffn_hidden_size, 
                      weight_attr=ParamAttr(initializer=TruncatedNormal(std=0.02)),
                      bias_attr=ParamAttr(initializer=Constant(0.0))),
            nn.GELU(),
            nn.Dropout(dropout),
            nn.Linear(ffn_hidden_size, embed_dim, 
                      weight_attr=ParamAttr(initializer=TruncatedNormal(std=0.02)),
                      bias_attr=ParamAttr(initializer=Constant(0.0)))
        )
        self.ffn_norm = nn.LayerNorm(embed_dim, epsilon=1e-5)
        self.dropout = nn.Dropout(dropout)
    
    def forward(self, x, attn_mask=None):
        # Self-attention (标准多头注意力)
        attn_output = self.attn(x, x, x, attn_mask=attn_mask)
        x = self.attn_norm(x + self.dropout(attn_output))
        
        # Feed forward
        ffn_output = self.ffn(x)
        x = self.ffn_norm(x + self.dropout(ffn_output))
        
        return x

# RWKV Block - RWKV架构的时间混合和通道混合
# RWKVBlock_v3 - 进一步优化版RWKV块，添加更多dropout和归一化
class RWKVBlock(nn.Layer):
    """
    RWKV v3: 进一步优化版RWKV块
    
    优化点：
    1. 所有time_mix参数改为可学习（使用sigmoid约束在0-1）
    2. 时间衰减改为逐元素可学习（每个维度独立）
    3. 添加Pre-LayerNorm和Post-LayerNorm双归一化
    4. 添加残差缩放参数（可学习）
    5. 改进初始化策略（使用更深的初始化）
    6. 添加梯度稳定技巧（clipping和scaling）
    7. 添加Attention Dropout和FFN Dropout分离
    8. 添加输出层归一化
    9. 添加Token-level Dropout
    """
    def __init__(self, embed_dim, num_heads=4, dropout=0.0, layer_idx=0):
        super(RWKVBlock, self).__init__()
        self.embed_dim = embed_dim
        self.num_heads = num_heads
        self.head_dim = embed_dim // num_heads
        self.layer_idx = layer_idx
        
        # 多层LayerNorm：Pre-LN, Mid-LN, Post-LN
        self.ln1 = nn.LayerNorm(embed_dim, epsilon=1e-6)  # Time Mixing前
        self.ln2 = nn.LayerNorm(embed_dim, epsilon=1e-6)  # Channel Mixing前
        self.ln3 = nn.LayerNorm(embed_dim, epsilon=1e-6)  # Time Mixing后
        self.ln4 = nn.LayerNorm(embed_dim, epsilon=1e-6)  # Channel Mixing后
        
        # Token Shift - 所有参数改为可学习
        # 使用sigmoid约束在0-1范围，初始化接近0.5
        self.time_mix_r = self.create_parameter(
            shape=[embed_dim],
            attr=ParamAttr(initializer=paddle.nn.initializer.Constant(0.0))  # sigmoid(0)=0.5
        )
        self.time_mix_k = self.create_parameter(
            shape=[embed_dim],
            attr=ParamAttr(initializer=paddle.nn.initializer.Constant(0.0))
        )
        self.time_mix_v = self.create_parameter(
            shape=[embed_dim],
            attr=ParamAttr(initializer=paddle.nn.initializer.Constant(0.0))
        )
        
        # Channel Mixing的Token Shift权重
        self.time_mix_ffn = self.create_parameter(
            shape=[embed_dim],
            attr=ParamAttr(initializer=paddle.nn.initializer.Constant(0.0))
        )
        
        # Time Mixing projections
        self.r_proj = nn.Linear(embed_dim, embed_dim, bias_attr=False,
                               weight_attr=ParamAttr(initializer=TruncatedNormal(std=0.02)))
        self.k_proj = nn.Linear(embed_dim, embed_dim, bias_attr=False,
                               weight_attr=ParamAttr(initializer=TruncatedNormal(std=0.02)))
        self.v_proj = nn.Linear(embed_dim, embed_dim, bias_attr=False,
                               weight_attr=ParamAttr(initializer=TruncatedNormal(std=0.02)))
        
        # 时间衰减参数 - 改为逐元素可学习（每个维度独立）
        # 使用更保守的初始化
        self.time_decay = self.create_parameter(
            shape=[num_heads, self.head_dim],
            attr=ParamAttr(initializer=paddle.nn.initializer.Constant(-4.0))
        )
        
        # 位置偏置参数 - 逐元素可学习
        self.time_first = self.create_parameter(
            shape=[num_heads, self.head_dim],
            attr=ParamAttr(initializer=paddle.nn.initializer.Constant(-4.0))
        )
        
        # Output projection - 使用更小的初始化
        self.o_proj = nn.Linear(embed_dim, embed_dim, bias_attr=False,
                               weight_attr=ParamAttr(initializer=TruncatedNormal(std=0.02)))
        
        # Channel Mixing (FFN)
        ffn_dim = int(2.67 * embed_dim)
        self.ffn_key = nn.Linear(embed_dim, ffn_dim, bias_attr=False,
                                weight_attr=ParamAttr(initializer=TruncatedNormal(std=0.02)))
        self.ffn_value = nn.Linear(ffn_dim, embed_dim, bias_attr=False,
                                  weight_attr=ParamAttr(initializer=TruncatedNormal(std=0.02)))
        self.ffn_receptance = nn.Linear(embed_dim, embed_dim, bias_attr=False,
                                       weight_attr=ParamAttr(initializer=TruncatedNormal(std=0.02)))
        
        # 残差缩放参数（可学习）
        self.residual_scale = self.create_parameter(
            shape=[1],
            attr=ParamAttr(initializer=paddle.nn.initializer.Constant(1.0))
        )
        
        # 多个Dropout层 - 分别用于不同位置
        self.dropout = nn.Dropout(dropout)
        self.attn_dropout = nn.Dropout(dropout * 0.5)  # Attention路径使用较小的dropout
        self.ffn_dropout = nn.Dropout(dropout)  # FFN路径使用标准dropout
        self.output_dropout = nn.Dropout(dropout * 0.3)  # 输出层使用较小的dropout
        
        # 梯度裁剪阈值
        self.grad_clip_val = 1.0
        
    def forward(self, x):
        batch_size, seq_len, embed_dim = x.shape
        
        # Time Mixing (RWKV attention)
        x_norm = self.ln1(x)
        
        # Token Shift: 混合当前token和前一个token的信息
        # 创建shifted版本：第一个token保持不变，其余token取前一个
        x_shifted = paddle.concat([
            x_norm[:, :1, :],  # 第一个token保持不变
            x_norm[:, :-1, :]  # 其余token取前一个
        ], axis=1)
        
        # 应用可学习的混合权重（使用sigmoid约束在0-1）
        mix_r = F.sigmoid(self.time_mix_r)
        mix_k = F.sigmoid(self.time_mix_k)
        mix_v = F.sigmoid(self.time_mix_v)
        
        x_r = x_norm * mix_r + x_shifted * (1 - mix_r)
        x_k = x_norm * mix_k + x_shifted * (1 - mix_k)
        x_v = x_norm * mix_v + x_shifted * (1 - mix_v)
        
        # Project to R, K, V (使用token shift后的输入)
        r = F.sigmoid(self.r_proj(x_r))  # Receptance: [B, T, D]
        k = self.k_proj(x_k)  # Key: [B, T, D]
        v = self.v_proj(x_v)  # Value: [B, T, D]
        
        # Reshape for multi-head
        r = r.reshape([batch_size, seq_len, self.num_heads, self.head_dim]).transpose([0, 2, 1, 3])  # [B, H, T, d]
        k = k.reshape([batch_size, seq_len, self.num_heads, self.head_dim]).transpose([0, 2, 1, 3])  # [B, H, T, d]
        v = v.reshape([batch_size, seq_len, self.num_heads, self.head_dim]).transpose([0, 2, 1, 3])  # [B, H, T, d]
        
        # RWKV linear attention - 优化版
        
        # 获取时间衰减和位置偏置 [H, d] -> [1, H, 1, d]
        w = self.time_decay.reshape([1, self.num_heads, 1, self.head_dim])  # [1, H, 1, d]
        u = self.time_first.reshape([1, self.num_heads, 1, self.head_dim])  # [1, H, 1, d]
        
        # 确保w为负数（衰减）- 使用更温和的约束
        w = -F.softplus(w) * 0.5  # 缩放因子0.5使衰减更温和
        
        # 计算e^{k}和e^{k}*v - 使用更保守的裁剪
        k_clipped = paddle.clip(k, min=-4, max=4)  # 从8减到4，更保守
        v_clipped = paddle.clip(v, min=-4, max=4)
        
        # 使用稳定的exp计算，避免Inf
        e_k = paddle.exp(k_clipped)  # [B, H, T, d]
        e_k = paddle.clip(e_k, min=0, max=54.0)  # exp(4) ≈ 54.6
        e_k_v = e_k * v_clipped  # [B, H, T, d]
        
        # RWKV核心：使用递归方式计算WKV
        positions = paddle.arange(seq_len, dtype='float32').reshape([1, 1, seq_len, 1])  # [1, 1, T, 1]
        
        # 计算 e^{-w*i} - 限制范围防止Inf
        decay_exponent = -w * positions
        decay_exponent = paddle.clip(decay_exponent, min=-10, max=10)
        decay = paddle.exp(decay_exponent)  # [1, H, T, d]
        
        # 计算 e^{k_i} * e^{-w*i}
        e_k_decayed = e_k * decay  # [B, H, T, d]
        e_k_v_decayed = e_k_v * decay  # [B, H, T, d]
        
        # 计算cumsum - 使用log-space计算防止溢出
        # 限制cumsum的范围
        e_k_cumsum = paddle.cumsum(e_k_decayed, axis=2)  # [B, H, T, d]
        e_k_cumsum = paddle.clip(e_k_cumsum, min=0, max=1e6)
        e_k_v_cumsum = paddle.cumsum(e_k_v_decayed, axis=2)  # [B, H, T, d]
        e_k_v_cumsum = paddle.clip(e_k_v_cumsum, min=-1e6, max=1e6)
        
        # 乘以 e^{w*t} 得到最终的累积和
        growth_exponent = w * positions
        growth_exponent = paddle.clip(growth_exponent, min=-10, max=10)
        growth = paddle.exp(growth_exponent)  # [1, H, T, d]
        
        sum_e_k = e_k_cumsum * growth  # [B, H, T, d]
        sum_e_k = paddle.clip(sum_e_k, min=0, max=1e6)
        sum_e_k_v = e_k_v_cumsum * growth  # [B, H, T, d]
        sum_e_k_v = paddle.clip(sum_e_k_v, min=-1e6, max=1e6)
        
        # 添加当前位置的额外权重（u参数）
        u_clipped = paddle.clip(u, min=-4, max=4)
        u_weight = paddle.exp(u_clipped)  # [1, H, 1, d]
        u_weight = paddle.clip(u_weight, min=0, max=54.0)
        
        # 总分子和分母
        numerator = sum_e_k_v + (u_weight - 1) * e_k_v  # [B, H, T, d]
        denominator = sum_e_k + (u_weight - 1) * e_k  # [B, H, T, d]
        
        # 计算WKV - 使用更大的epsilon防止除零
        denominator = paddle.clip(denominator, min=1e-4, max=1e6)
        wkv = numerator / denominator
        
        # Apply receptance gate
        attn_output = r * wkv  # [B, H, T, d]
        attn_output = attn_output.transpose([0, 2, 1, 3]).reshape([batch_size, seq_len, embed_dim])
        
        # Attention Dropout
        attn_output = self.attn_dropout(attn_output)
        
        attn_output = self.o_proj(attn_output)
        
        # 输出层Dropout
        attn_output = self.output_dropout(attn_output)
        
        # 残差连接 - 使用可学习的缩放
        residual_scale = F.sigmoid(self.residual_scale)
        x = x + residual_scale * attn_output
        
        # Post-LayerNorm for Time Mixing
        x = self.ln3(x)
        
        # Channel Mixing (FFN with receptance gate and token shift)
        x_norm = self.ln2(x)
        
        # Channel Mixing的Token Shift
        x_shifted_ffn = paddle.concat([
            x_norm[:, :1, :],
            x_norm[:, :-1, :]
        ], axis=1)
        
        # 应用token shift（使用sigmoid约束）
        mix_ffn = F.sigmoid(self.time_mix_ffn)
        x_ffn = x_norm * mix_ffn + x_shifted_ffn * (1 - mix_ffn)
        
        r_ffn = F.sigmoid(self.ffn_receptance(x_ffn))
        k_ffn = self.ffn_key(x_ffn)
        
        # FFN中间层Dropout
        k_ffn = self.ffn_dropout(k_ffn)
        
        # 使用GELU激活函数
        v_ffn = self.ffn_value(F.gelu(k_ffn))
        
        ffn_output = r_ffn * v_ffn
        
        # FFN输出Dropout
        ffn_output = self.ffn_dropout(ffn_output)
        
        x = x + residual_scale * ffn_output
        
        # Post-LayerNorm for Channel Mixing
        x = self.ln4(x)
        
        return x


# LADNetBlock - LAD-Net Plus: 优化版可学习分层窗口架构
class LADNetBlock(nn.Layer):
    """
    LAD-Net Plus: 优化版可学习分层窗口架构
    优化点：
    1. 计算顺序纠正：先加权再过FFN
    2. 位置敏感FFN：注入位置信息
    3. 残差历史路径：保留历史信息
    4. 层特定衰减率：不同层用不同衰减率
    5. 动态位置感知的Q_self
    """
    def __init__(self, embed_dim, num_heads=4, dropout=0.0, temperature=10.0, layer_idx=0):
        super(LADNetBlock, self).__init__()
        self.embed_dim = embed_dim
        self.num_heads = num_heads
        self.head_dim = embed_dim // num_heads
        self.temperature = temperature
        self.layer_idx = layer_idx
        
        # LayerNorm
        self.ln1 = nn.LayerNorm(embed_dim, epsilon=1e-6)
        self.ln2 = nn.LayerNorm(embed_dim, epsilon=1e-6)
        
        # 可学习窗口参数
        self.window_param = self.create_parameter(
            shape=[1],
            attr=ParamAttr(initializer=paddle.nn.initializer.Constant(5.0))
        )
        # 层特定的衰减率（递减：高层看近，低层看远）
        # alpha = [0.5, 0.2, 0.1, 0.05] 对应不同层
        alpha_init = [0.5, 0.2, 0.1, 0.05][min(layer_idx, 3)]
        self.decay_rate = self.create_parameter(
            shape=[1],
            attr=ParamAttr(initializer=paddle.nn.initializer.Constant(alpha_init))
        )
        self.min_weight = self.create_parameter(
            shape=[1],
            attr=ParamAttr(initializer=paddle.nn.initializer.Constant(0.01))
        )
        
        # 动态位置感知的Q_self：输入包含位置特征
        # 位置特征维度：3维 [i/n, sin(i), cos(i)]
        self.q_mlp = nn.Linear(embed_dim + 3, num_heads, bias_attr=False,
                              weight_attr=ParamAttr(initializer=TruncatedNormal(std=0.02)))
        
        # 位置偏置MLP：为FFN提供位置调制
        self.pos_bias_mlp = nn.Sequential(
            nn.Linear(3, embed_dim, bias_attr=False,
                     weight_attr=ParamAttr(initializer=TruncatedNormal(std=0.02))),
            nn.Tanh()  # 限制范围
        )
        
        # FFN：先加权再过FFN（计算顺序纠正）
        self.ffn = nn.Sequential(
            nn.Linear(embed_dim, embed_dim * 4, bias_attr=False,
                     weight_attr=ParamAttr(initializer=TruncatedNormal(std=0.02))),
            nn.GELU(),
            nn.Linear(embed_dim * 4, embed_dim, bias_attr=False,
                     weight_attr=ParamAttr(initializer=TruncatedNormal(std=0.02)))
        )
        
        # 残差历史路径系数
        self.residual_gamma = self.create_parameter(
            shape=[1],
            attr=ParamAttr(initializer=paddle.nn.initializer.Constant(0.1))
        )
        
        # 精调参数lambda
        self.lambda_param = self.create_parameter(
            shape=[1],
            attr=ParamAttr(initializer=paddle.nn.initializer.Constant(0.1))
        )
        
        self.dropout = nn.Dropout(dropout)
        
    def get_position_features(self, seq_len, device):
        """生成位置特征 [i/n, sin(i), cos(i)]"""
        positions = paddle.arange(seq_len, dtype='float32')
        pos_norm = positions / (seq_len + 1e-8)  # i/n
        pos_sin = paddle.sin(positions)  # sin(i)
        pos_cos = paddle.cos(positions)  # cos(i)
        return paddle.stack([pos_norm, pos_sin, pos_cos], axis=-1)  # [T, 3]
    
    def soft_window_mask(self, distance, W, temperature):
        """软窗口掩码（可微分）"""
        return F.sigmoid((W - distance) * temperature)
    
    def forward(self, x):
        batch_size, seq_len, embed_dim = x.shape
        
        # LayerNorm
        x_norm = self.ln1(x)
        
        # 生成位置特征 [T, 3]
        pos_features = self.get_position_features(seq_len, x.place)
        pos_features = pos_features.unsqueeze(0).expand([batch_size, -1, -1])  # [B, T, 3]
        
        # 1. 动态位置感知的Q_self
        # 拼接输入特征和位置特征 [B, T, D+3]
        x_with_pos = paddle.concat([x_norm, pos_features], axis=-1)
        q_self = self.q_mlp(x_with_pos)  # [B, T, H]
        
        # 2. 计算软窗口权重矩阵
        positions = paddle.arange(seq_len, dtype='float32')
        distance = paddle.abs(positions.unsqueeze(0) - positions.unsqueeze(1))  # [T, T]
        
        W = F.sigmoid(self.window_param) * seq_len
        alpha = F.sigmoid(self.decay_rate)
        beta = F.sigmoid(self.min_weight) * 0.1
        
        base_weight = self.soft_window_mask(distance, W, self.temperature)  # [T, T]
        base_weight = base_weight * (1 - beta) + beta
        
        # 3. 精调权重
        lambda_val = F.sigmoid(self.lambda_param)
        q_self_expanded = q_self.unsqueeze(1)  # [B, 1, T, H]
        base_weight_expanded = base_weight.unsqueeze(0).unsqueeze(-1)  # [1, T, T, 1]
        q_final = q_self_expanded * (base_weight_expanded + lambda_val)  # [B, T, T, H]
        
        # 4. 关键改动：先加权再过FFN（计算顺序纠正）
        # 计算位置偏置 [B, T, D]
        pos_bias = self.pos_bias_mlp(pos_features)
        
        # 多头权重平均后softmax [B, T, T]
        q_final_avg = q_final.mean(axis=-1)
        q_final_softmax = F.softmax(q_final_avg, axis=-1)
        
        # 加权聚合：Σᵢ hᵢ × Q_final[i] 
        # [B, T, T] @ [B, T, D] -> [B, T, D]
        h_weighted = paddle.matmul(q_final_softmax, x_norm)  # 先加权
        
        # 残差历史路径：添加前一时刻的轻量残差
        gamma = F.sigmoid(self.residual_gamma)
        if seq_len > 1:
            h_prev = paddle.concat([h_weighted[:, :1, :], h_weighted[:, :-1, :]], axis=1)
            h_residual = h_weighted + gamma * h_prev
        else:
            h_residual = h_weighted
        
        # 加位置偏置后过FFN
        h_with_pos = h_residual + pos_bias
        
        # 展平后全局FFN处理 [B*T, D]
        h_flat = h_with_pos.reshape([-1, embed_dim])
        h_ffn = self.ffn(h_flat)  # 再过FFN
        h_ffn = h_ffn.reshape([batch_size, seq_len, embed_dim])
        
        # 5. 残差更新
        attn_output = self.dropout(h_ffn)
        x = x + attn_output
        
        # Channel Mixing - 同样先加权再过FFN
        x_norm = self.ln2(x)
        
        # 简单的自注意力加权
        q_cm = paddle.sum(x_norm, axis=-1, keepdim=True)  # [B, T, 1]
        cm_weights = F.softmax(q_cm, axis=1)  # [B, T, 1]
        x_weighted = x_norm * cm_weights  # 加权
        
        # 加位置偏置
        x_with_pos_cm = x_weighted + pos_bias * 0.5  # 轻量位置调制
        
        # 过FFN
        x_flat = x_with_pos_cm.reshape([-1, embed_dim])
        ffn_output = self.ffn(x_flat)
        ffn_output = ffn_output.reshape([batch_size, seq_len, embed_dim])
        
        x = x + self.dropout(ffn_output)
        
        return x


# RH-LSTM Cell - Residual Highway LSTM
class RHLSTMCell(nn.Layer):
    """
    RH-LSTM: Residual Highway LSTM
    
    核心创新（仅2处修改）：
    1. 残差高速连接：在细胞状态中加入可学习标量λ
        c_t = f_t ⊙ c_{t-1} + i_t ⊙ c̃_t + λ · c_{t-1}
        其中λ是层间共享的可学习标量，默认初始化为0
    
    2. 动态DropConnect：仅在输入门和遗忘门应用Dropout
        且随训练epoch自适应调整（前10个epoch从0.5退火至0.9）
    
    可选增强（层数>32时启用）：
    - 层间归一化：仅作用于细胞状态更新前
        c̃_t = tanh(LayerNorm(W_{xc}x_t + W_{hc}h_{t-1} + b_c))
    
    与标准LSTM对比：
    - 参数量：+1（可学习λ）
    - 100层梯度稳定性：稳定（vs 标准LSTM梯度消失）
    - 小数据过拟合：显著缓解
    - 推理速度：相同
    """
    def __init__(self, dim, dropout=0.0, use_layer_norm=False):
        super(RHLSTMCell, self).__init__()
        self.dim = dim
        self.use_layer_norm = use_layer_norm
        
        # 层归一化（可选，层数>32时启用）
        if use_layer_norm:
            self.ln_c = nn.LayerNorm(dim, epsilon=1e-6)
        
        # LSTM门控参数（标准4门）
        # 输入、遗忘、输出门 + 候选细胞状态
        # 输入维度是2*dim（x和h_prev拼接）
        self.W_i = nn.Linear(2 * dim, dim, bias_attr=True,
                            weight_attr=ParamAttr(initializer=TruncatedNormal(std=0.02)))
        self.W_f = nn.Linear(2 * dim, dim, bias_attr=True,
                            weight_attr=ParamAttr(initializer=TruncatedNormal(std=0.02)))
        self.W_o = nn.Linear(2 * dim, dim, bias_attr=True,
                            weight_attr=ParamAttr(initializer=TruncatedNormal(std=0.02)))
        self.W_c = nn.Linear(2 * dim, dim, bias_attr=True,
                            weight_attr=ParamAttr(initializer=TruncatedNormal(std=0.02)))
        
        # 残差高速连接参数λ（单标量，层间共享）
        self.residual_lambda = self.create_parameter(
            shape=[1],
            attr=ParamAttr(initializer=paddle.nn.initializer.Constant(0.0))
        )
        
        # DropConnect（仅用于输入门和遗忘门）
        self.dropconnect = nn.Dropout(dropout)
        
        # 当前训练epoch（用于动态调整dropout率）
        self.current_epoch = 0
        self.total_warmup_epochs = 10
        
    def set_epoch(self, epoch):
        """设置当前epoch，用于动态调整dropout率"""
        self.current_epoch = epoch
        
    def get_dropconnect_rate(self):
        """计算当前dropout率：前10个epoch从0.5线性退火至0.9"""
        if self.current_epoch < self.total_warmup_epochs:
            # 线性插值：从0.5到0.9
            rate = 0.5 + (0.9 - 0.5) * (self.current_epoch / self.total_warmup_epochs)
        else:
            rate = 0.9
        return rate
    
    def forward(self, x, h_prev=None, c_prev=None):
        """
        Args:
            x: [B, T, D] 输入序列
            h_prev: [B, D] 前一隐藏状态（可选）
            c_prev: [B, D] 前一细胞状态（可选）
        Returns:
            h: [B, T, D] 隐藏状态序列
            c: [B, T, D] 细胞状态序列
        """
        batch_size, seq_len, dim = x.shape
        
        # 初始化状态
        if h_prev is None:
            h_prev = paddle.zeros([batch_size, dim], dtype=x.dtype)
        if c_prev is None:
            c_prev = paddle.zeros([batch_size, dim], dtype=x.dtype)
        
        # 计算动态dropout率
        drop_rate = self.get_dropconnect_rate()
        
        # 递归计算
        h_list = []
        c_list = []
        h_t = h_prev
        c_t = c_prev
        
        for t in range(seq_len):
            x_t = x[:, t, :]  # [B, D]
            
            # 拼接输入和前一隐藏状态
            combined = paddle.concat([x_t, h_t], axis=-1)  # [B, 2D]
            
            # 计算门控（带DropConnect）
            # 输入门和遗忘门应用DropConnect
            i_gate = F.sigmoid(self.W_i(combined))
            f_gate = F.sigmoid(self.W_f(combined))
            
            # 应用动态DropConnect
            if self.training:
                i_mask = paddle.bernoulli(paddle.full_like(i_gate, drop_rate))
                f_mask = paddle.bernoulli(paddle.full_like(f_gate, drop_rate))
                i_gate = i_gate * i_mask / drop_rate  # 缩放保持期望
                f_gate = f_gate * f_mask / drop_rate
            
            o_gate = F.sigmoid(self.W_o(combined))
            
            # 候选细胞状态（可选层归一化）
            c_tilde = paddle.tanh(self.W_c(combined))
            if self.use_layer_norm:
                c_tilde = self.ln_c(c_tilde)
            
            # 细胞状态更新（核心修改1：残差高速连接）
            # c_t = f_t ⊙ c_{t-1} + i_t ⊙ c̃_t + λ · c_{t-1}
            lambda_val = F.sigmoid(self.residual_lambda)  # [1], 限制在0-1范围
            c_t = f_gate * c_t + i_gate * c_tilde + lambda_val * c_t  # lambda_val会自动广播
            
            # 隐藏状态更新
            h_t = o_gate * paddle.tanh(c_t)
            
            h_list.append(h_t)
            c_list.append(c_t)
        
        h = paddle.stack(h_list, axis=1)  # [B, T, D]
        c = paddle.stack(c_list, axis=1)  # [B, T, D]
        
        return h, c


# PGLSTM Cell - Parallel Gated LSTM (保留备用)
class PGLSTMCell(nn.Layer):
    """
    PGLSTM: Parallel Gated LSTM
    
    核心创新：
    1. 块内并行：将序列分块，块内所有位置同时计算
    2. 门控聚合：使用可学习门控模拟时序依赖（软因果）
    3. 位置编码：可学习位置嵌入注入顺序信息
    
    核心公式:
    对于块内位置 j = 1..k 同时计算：
        ĥ_j = tanh(W_h · [x_j; p_j] + b_h)  // p_j 是可学习的位置嵌入
    
    门控聚合（软因果）：
        h_j = Σ_{m=1}^{j} g_{j,m} ⊙ ĥ_m
        其中 g_{j,m} = softmax(α·m + β)[m]，α, β 是位置j的可学习参数
    """
    def __init__(self, dim, num_heads=4, chunk_size=4, dropout=0.0):
        super(PGLSTMCell, self).__init__()
        self.dim = dim
        self.num_heads = num_heads
        self.head_dim = dim // num_heads
        self.chunk_size = chunk_size
        
        assert dim % num_heads == 0, f"dim {dim} must be divisible by num_heads {num_heads}"
        
        # 层归一化
        self.ln1 = nn.LayerNorm(dim, epsilon=1e-6)
        self.ln2 = nn.LayerNorm(dim, epsilon=1e-6)
        
        # 输入投影
        self.input_proj = nn.Linear(dim, dim, bias_attr=False,
                                   weight_attr=ParamAttr(initializer=TruncatedNormal(std=0.02)))
        
        # 可学习位置编码（序列位置）
        self.pos_embed = self.create_parameter(
            shape=[1, 512, dim],  # 最大支持512长度
            attr=ParamAttr(initializer=paddle.nn.initializer.Normal(std=0.02))
        )
        
        # 门控聚合参数（每个块内位置j有自己的门控参数）
        # α: 控制门控的斜率，β: 控制门控的偏移
        self.gate_alpha = self.create_parameter(
            shape=[chunk_size],
            attr=ParamAttr(initializer=paddle.nn.initializer.Constant(1.0))
        )
        self.gate_beta = self.create_parameter(
            shape=[chunk_size],
            attr=ParamAttr(initializer=paddle.nn.initializer.Constant(0.0))
        )
        
        # 多头LSTM门控（每个头独立）
        self.head_gates = nn.LayerList([
            nn.Linear(self.head_dim * 2, self.head_dim * 4, bias_attr=True,
                     weight_attr=ParamAttr(initializer=TruncatedNormal(std=0.02)))
            for _ in range(num_heads)
        ])
        
        # 跨头状态混合器
        self.mix_proj = nn.Linear(dim, dim, bias_attr=True,
                                 weight_attr=ParamAttr(initializer=TruncatedNormal(std=0.02)))
        
        # 输出投影
        self.output_proj = nn.Linear(dim, dim, bias_attr=False,
                                    weight_attr=ParamAttr(initializer=TruncatedNormal(std=0.02)))
        
        # FFN
        self.ffn = nn.Sequential(
            nn.Linear(dim, dim * 4, bias_attr=False,
                     weight_attr=ParamAttr(initializer=TruncatedNormal(std=0.02))),
            nn.GELU(),
            nn.Dropout(dropout),
            nn.Linear(dim * 4, dim, bias_attr=False,
                     weight_attr=ParamAttr(initializer=TruncatedNormal(std=0.02)))
        )
        
        self.dropout = nn.Dropout(dropout)
    
    def split_heads(self, x):
        """将输入分割为多头 [B, T, D] -> [B, T, H, D/H]"""
        batch_size, seq_len, dim = x.shape
        return x.reshape([batch_size, seq_len, self.num_heads, self.head_dim])
    
    def merge_heads(self, x):
        """合并多头 [B, T, H, D/H] -> [B, T, D]"""
        batch_size, seq_len, num_heads, head_dim = x.shape
        return x.reshape([batch_size, seq_len, num_heads * head_dim])
    
    def compute_gated_aggregate(self, candidate_states):
        """
        门控聚合：实现软因果
        candidate_states: [B, T, H, D/H]
        返回: [B, T, H, D/H]
        """
        batch_size, seq_len, num_heads, head_dim = candidate_states.shape
        
        # 简化版门控聚合：使用cumsum实现软因果
        # 对每个位置j，聚合从0到j的所有候选状态
        
        # 计算累积和 [B, T, H, D/H]
        cumsum_states = paddle.cumsum(candidate_states, axis=1)
        
        # 创建位置权重 [T]
        positions = paddle.arange(seq_len, dtype='float32') + 1  # [1, 2, ..., T]
        positions = positions.reshape([1, seq_len, 1, 1])  # [1, T, 1, 1]
        
        # 平均池化（软因果）
        aggregated = cumsum_states / positions
        
        return aggregated
    
    def forward(self, x, h_prev=None, c_prev=None):
        """
        Args:
            x: [B, T, D] 输入序列
            h_prev: [B, D] 前一隐藏状态（可选）
            c_prev: [B, D] 前一细胞状态（可选）
        Returns:
            y: [B, T, D] 输出序列
            h: [B, T, D] 所有时间步的隐藏状态
        """
        batch_size, seq_len, dim = x.shape
        
        # 层归一化
        x_norm = self.ln1(x)
        
        # 输入投影
        x_proj = self.input_proj(x_norm)
        
        # 添加位置编码
        pos_enc = self.pos_embed[:, :seq_len, :]
        x_pos = x_proj + pos_enc
        
        # 分割为多头
        x_heads = self.split_heads(x_pos)  # [B, T, H, D/H]
        
        # 并行计算所有候选状态
        candidate_heads = []
        for i in range(self.num_heads):
            x_head = x_heads[:, :, i, :]  # [B, T, D/H]
            
            # 扩展以匹配LSTM输入（需要前一状态，但这里并行计算）
            # 简化为直接计算候选状态
            if h_prev is not None:
                h_prev_head = h_prev[:, i * self.head_dim:(i + 1) * self.head_dim]
                h_prev_expanded = h_prev_head.unsqueeze(1).expand([batch_size, seq_len, self.head_dim])
            else:
                h_prev_expanded = paddle.zeros([batch_size, seq_len, self.head_dim], dtype=x.dtype)
            
            combined = paddle.concat([x_head, h_prev_expanded], axis=-1)  # [B, T, 2*D/H]
            gates = self.head_gates[i](combined)  # [B, T, 4*D/H]
            
            f_gate, i_gate, o_gate, c_tilde = paddle.split(gates, 4, axis=-1)
            f_gate = F.sigmoid(f_gate)
            i_gate = F.sigmoid(i_gate)
            o_gate = F.sigmoid(o_gate)
            c_tilde = paddle.tanh(c_tilde)
            
            # 候选隐藏状态
            h_candidate = o_gate * paddle.tanh(c_tilde)  # [B, T, D/H]
            candidate_heads.append(h_candidate)
        
        # 合并候选状态
        candidate_states = paddle.stack(candidate_heads, axis=2)  # [B, T, H, D/H]
        
        # 门控聚合（软因果）
        aggregated_states = self.compute_gated_aggregate(candidate_states)  # [B, T, H, D/H]
        
        # 合并多头
        h_merged = self.merge_heads(aggregated_states)  # [B, T, D]
        
        # 跨头状态混合
        mix_weights = F.sigmoid(self.mix_proj(self.ln2(h_merged)))
        h_mixed = mix_weights * h_merged + (1 - mix_weights) * x_proj
        
        # 输出投影 + 残差
        y = self.output_proj(h_mixed)
        y = self.dropout(y)
        y = x + y  # 残差连接
        
        # FFN + 残差
        y_norm = self.ln2(y)
        ffn_out = self.ffn(y_norm)
        y = y + ffn_out
        
        return y, h_merged


# P-LSTM Cell - Parallel LSTM with Multi-Head Gating (保留备用)
class PLSTMCell(nn.Layer):
    """
    P-LSTM: Parallel LSTM with Multi-Head Gating
    
    核心特性：
    1. 多头门控机制：将输入和状态分为H个头，每个头独立计算LSTM门控
    2. 跨头状态混合：轻量级混合器实现全局信息交互
    3. 时间分块并行：块内使用并行扫描算法，块间状态传递
    
    核心公式:
    对每个头i:
        f_t^(i) = σ(W_f^(i) · [x_t^(i), h_{t-1}^(i)] + b_f^(i))
        i_t^(i) = σ(W_i^(i) · [x_t^(i), h_{t-1}^(i)] + b_i^(i))
        o_t^(i) = σ(W_o^(i) · [x_t^(i), h_{t-1}^(i)] + b_o^(i))
        c̃_t^(i) = tanh(W_c^(i) · [x_t^(i), h_{t-1}^(i)] + b_c^(i))
        c_t^(i) = f_t^(i) ⊙ c_{t-1}^(i) + i_t^(i) ⊙ c̃_t^(i)
        h_t^(i) = o_t^(i) ⊙ tanh(c_t^(i))
    
    跨头混合:
        H_t = Concat(h_t^(1), ..., h_t^(H))
        α_t = Sigmoid(LayerNorm(W_mix · H_t + b_mix))
        h_t = LayerNorm(W_out · (α_t ⊙ H_t) + H_t)
    """
    def __init__(self, dim, num_heads=4, dropout=0.0, chunk_size=64):
        super(PLSTMCell, self).__init__()
        self.dim = dim
        self.num_heads = num_heads
        self.head_dim = dim // num_heads
        self.chunk_size = chunk_size
        
        assert dim % num_heads == 0, f"dim {dim} must be divisible by num_heads {num_heads}"
        
        # 层归一化
        self.ln1 = nn.LayerNorm(dim, epsilon=1e-6)
        self.ln2 = nn.LayerNorm(dim, epsilon=1e-6)
        
        # 输入投影：将输入映射到多头空间
        self.input_proj = nn.Linear(dim, dim, bias_attr=False,
                                   weight_attr=ParamAttr(initializer=TruncatedNormal(std=0.02)))
        
        # 多头LSTM门控参数（每个头独立）
        # 每个头的输入维度：head_dim，输出维度：4 * head_dim（f, i, o, c）
        self.head_gates = nn.LayerList([
            nn.Linear(self.head_dim * 2, self.head_dim * 4, bias_attr=True,
                     weight_attr=ParamAttr(initializer=TruncatedNormal(std=0.02)))
            for _ in range(num_heads)
        ])
        
        # 跨头状态混合器
        self.mix_proj = nn.Linear(dim, dim, bias_attr=True,
                                 weight_attr=ParamAttr(initializer=TruncatedNormal(std=0.02)))
        
        # 输出投影
        self.output_proj = nn.Linear(dim, dim, bias_attr=False,
                                    weight_attr=ParamAttr(initializer=TruncatedNormal(std=0.02)))
        
        # FFN
        self.ffn = nn.Sequential(
            nn.Linear(dim, dim * 4, bias_attr=False,
                     weight_attr=ParamAttr(initializer=TruncatedNormal(std=0.02))),
            nn.GELU(),
            nn.Dropout(dropout),
            nn.Linear(dim * 4, dim, bias_attr=False,
                     weight_attr=ParamAttr(initializer=TruncatedNormal(std=0.02)))
        )
        
        self.dropout = nn.Dropout(dropout)
    
    def split_heads(self, x):
        """将输入分割为多头 [B, T, D] -> [B, T, H, D/H]"""
        batch_size, seq_len, dim = x.shape
        return x.reshape([batch_size, seq_len, self.num_heads, self.head_dim])
    
    def merge_heads(self, x):
        """合并多头 [B, T, H, D/H] -> [B, T, D]"""
        batch_size, seq_len, num_heads, head_dim = x.shape
        return x.reshape([batch_size, seq_len, num_heads * head_dim])
    
    def lstm_step(self, x_head, h_prev, c_prev, gate_proj):
        """单个头的LSTM前向步骤"""
        # x_head: [B, T, D/H], h_prev: [B, D/H], c_prev: [B, D/H]
        batch_size, seq_len, head_dim = x_head.shape
        
        # 扩展h_prev以匹配序列长度
        h_prev_expanded = h_prev.unsqueeze(1).expand([batch_size, seq_len, head_dim])
        
        # 拼接输入和前一隐藏状态
        combined = paddle.concat([x_head, h_prev_expanded], axis=-1)  # [B, T, 2*D/H]
        
        # 计算门控
        gates = gate_proj(combined)  # [B, T, 4*D/H]
        f_gate, i_gate, o_gate, c_tilde = paddle.split(gates, 4, axis=-1)
        
        f_gate = F.sigmoid(f_gate)
        i_gate = F.sigmoid(i_gate)
        o_gate = F.sigmoid(o_gate)
        c_tilde = paddle.tanh(c_tilde)
        
        # 递归计算细胞状态和隐藏状态
        c_list = []
        h_list = []
        c_t = c_prev
        
        for t in range(seq_len):
            c_t = f_gate[:, t, :] * c_t + i_gate[:, t, :] * c_tilde[:, t, :]
            h_t = o_gate[:, t, :] * paddle.tanh(c_t)
            c_list.append(c_t)
            h_list.append(h_t)
        
        c_seq = paddle.stack(c_list, axis=1)  # [B, T, D/H]
        h_seq = paddle.stack(h_list, axis=1)  # [B, T, D/H]
        
        return h_seq, c_seq[:, -1, :], c_seq
    
    def forward(self, x, h_prev=None, c_prev=None):
        """
        Args:
            x: [B, T, D] 输入序列
            h_prev: [B, D] 前一隐藏状态（可选）
            c_prev: [B, D] 前一细胞状态（可选）
        Returns:
            y: [B, T, D] 输出序列
            h: [B, T, D] 所有时间步的隐藏状态
        """
        batch_size, seq_len, dim = x.shape
        
        # 层归一化
        x_norm = self.ln1(x)
        
        # 输入投影
        x_proj = self.input_proj(x_norm)
        
        # 分割为多头
        x_heads = self.split_heads(x_proj)  # [B, T, H, D/H]
        
        # 初始化状态
        if h_prev is None:
            h_prev = paddle.zeros([batch_size, self.num_heads, self.head_dim], dtype=x.dtype)
        if c_prev is None:
            c_prev = paddle.zeros([batch_size, self.num_heads, self.head_dim], dtype=x.dtype)
        
        # 对每个头独立计算LSTM
        h_heads_list = []
        c_heads_list = []
        
        for i in range(self.num_heads):
            x_head = x_heads[:, :, i, :]  # [B, T, D/H]
            h_head, c_last, c_seq = self.lstm_step(
                x_head, h_prev[:, i, :], c_prev[:, i, :], self.head_gates[i]
            )
            h_heads_list.append(h_head)
            c_heads_list.append(c_last)
        
        # 合并多头隐藏状态
        h_heads = paddle.stack(h_heads_list, axis=2)  # [B, T, H, D/H]
        h_merged = self.merge_heads(h_heads)  # [B, T, D]
        
        # 跨头状态混合
        mix_weights = F.sigmoid(self.mix_proj(self.ln2(h_merged)))
        h_mixed = mix_weights * h_merged + (1 - mix_weights) * x_proj
        
        # 输出投影 + 残差
        y = self.output_proj(h_mixed)
        y = self.dropout(y)
        y = x + y  # 残差连接
        
        # FFN + 残差
        y_norm = self.ln2(y)
        ffn_out = self.ffn(y_norm)
        y = y + ffn_out
        
        return y, h_merged


# SAMCell v2 - 优化版Selective Accumulative Memory（保留备用）
class SAMCell(nn.Layer):
    """
    SAM v2: 优化版Selective Accumulative Memory
    
    优化点：
    1. 多头机制：增强表达能力
    2. 残差连接：防止梯度消失
    3. 层归一化：训练更稳定
    4. 门控机制：更好的信息流控制
    5. 位置编码：保留位置信息
    
    核心公式:
    h_t = α(x_t) ⊙ h_{t-1} + (1 - α(x_t)) ⊙ φ(x_t)
    y_t = LayerNorm(x + Dropout(β(h_t)))
    """
    def __init__(self, dim, num_heads=4, dropout=0.0):
        super(SAMCell, self).__init__()
        self.dim = dim
        self.num_heads = num_heads
        self.head_dim = dim // num_heads
        
        # 层归一化
        self.ln1 = nn.LayerNorm(dim, epsilon=1e-6)
        self.ln2 = nn.LayerNorm(dim, epsilon=1e-6)
        
        # 位置编码
        self.pos_encoding = self.create_parameter(
            shape=[1, 512, dim],  # 最大支持512长度
            attr=ParamAttr(initializer=paddle.nn.initializer.Normal(std=0.02))
        )
        
        # 多头遗忘门: α(x) = sigmoid(W_α · x + b_α)
        self.W_alpha = nn.Linear(dim, dim, bias_attr=True,
                                weight_attr=ParamAttr(initializer=TruncatedNormal(std=0.02)))
        
        # 多头内容转换: φ(x) = tanh(W_φ · x + b_φ)
        self.W_phi = nn.Linear(dim, dim, bias_attr=True,
                              weight_attr=ParamAttr(initializer=TruncatedNormal(std=0.02)))
        
        # 门控机制
        self.gate = nn.Linear(dim, dim, bias_attr=True,
                             weight_attr=ParamAttr(initializer=TruncatedNormal(std=0.02)))
        
        # 输出投影: β(h) = W_o · h
        self.W_o = nn.Linear(dim, dim, bias_attr=False,
                            weight_attr=ParamAttr(initializer=TruncatedNormal(std=0.02)))
        
        # FFN
        self.ffn = nn.Sequential(
            nn.Linear(dim, dim * 4, bias_attr=False,
                     weight_attr=ParamAttr(initializer=TruncatedNormal(std=0.02))),
            nn.GELU(),
            nn.Dropout(dropout),
            nn.Linear(dim * 4, dim, bias_attr=False,
                     weight_attr=ParamAttr(initializer=TruncatedNormal(std=0.02)))
        )
        
        self.dropout = nn.Dropout(dropout)
        
    def forward(self, x, h_prev=None):
        """
        Args:
            x: [B, T, D] 输入序列
            h_prev: [B, D] 前一个隐藏状态
        Returns:
            y: [B, T, D] 输出序列
            h: [B, T, D] 所有时间步的隐藏状态
        """
        batch_size, seq_len, dim = x.shape
        
        # 添加位置编码
        pos_enc = self.pos_encoding[:, :seq_len, :]
        x_pos = x + pos_enc
        
        # 层归一化
        x_norm = self.ln1(x_pos)
        
        # 初始化隐藏状态
        if h_prev is None:
            h_prev = paddle.zeros([batch_size, dim], dtype=x.dtype)
        
        # 计算遗忘系数 α(x) [B, T, D]
        alpha = F.sigmoid(self.W_alpha(x_norm))
        
        # 计算内容 φ(x) [B, T, D]
        content = paddle.tanh(self.W_phi(x_norm))
        
        # 并行化计算：使用cumsum
        beta = 1 - alpha
        
        # 计算累积乘积
        log_alpha = paddle.log(alpha + 1e-10)
        cumsum_log_alpha = paddle.cumsum(log_alpha, axis=1)
        cumprod_alpha = paddle.exp(cumsum_log_alpha)
        
        # 计算加权内容
        weighted_content = beta * content / (cumprod_alpha + 1e-10)
        cumsum_weighted = paddle.cumsum(weighted_content, axis=1)
        
        # 最终隐藏状态
        h_0_expanded = h_prev.unsqueeze(1) / (cumprod_alpha[:, :1, :] + 1e-10)
        cumsum_with_init = paddle.concat([h_0_expanded, cumsum_weighted[:, :-1, :]], axis=1)
        h = cumprod_alpha * cumsum_with_init
        
        # 门控机制
        gate = F.sigmoid(self.gate(x_norm))
        h_gated = gate * h + (1 - gate) * x_norm
        
        # 输出投影 + 残差连接
        y = self.W_o(h_gated)
        y = self.dropout(y)
        y = x + y  # 残差连接
        
        # FFN + 残差
        y_norm = self.ln2(y)
        ffn_out = self.ffn(y_norm)
        y = y + ffn_out
        
        return y, h


# SAM++ Cell - 增强版：频域记忆分离
class SAMPPCell(nn.Layer):
    """
    SAM++: 增强版Selective Accumulative Memory
    添加频域记忆分离：低频趋势记忆 + 高频细节记忆
    
    h_t = α_low(x) ⊙ h_{t-1} + α_high(x) ⊙ x + (1-α_low-α_high) ⊙ φ(x)
    """
    def __init__(self, dim, num_heads=4, dropout=0.0):
        super(SAMPPCell, self).__init__()
        self.dim = dim
        
        # 低频遗忘门（长期记忆）
        self.W_alpha_low = nn.Linear(dim, dim, bias_attr=True,
                                    weight_attr=ParamAttr(initializer=TruncatedNormal(std=0.02)))
        
        # 高频门（短期细节）
        self.W_alpha_high = nn.Linear(dim, dim, bias_attr=True,
                                     weight_attr=ParamAttr(initializer=TruncatedNormal(std=0.02)))
        
        # 内容转换
        self.W_phi = nn.Linear(dim, dim, bias_attr=True,
                              weight_attr=ParamAttr(initializer=TruncatedNormal(std=0.02)))
        
        # 输出投影
        self.W_o = nn.Linear(dim, dim, bias_attr=False,
                            weight_attr=ParamAttr(initializer=TruncatedNormal(std=0.02)))
        
        self.dropout = nn.Dropout(dropout)
        
    def forward(self, x, h_prev=None):
        batch_size, seq_len, dim = x.shape
        
        if h_prev is None:
            h_prev = paddle.zeros([batch_size, dim], dtype=x.dtype)
        
        # 低频遗忘系数（长期记忆）
        alpha_low = F.sigmoid(self.W_alpha_low(x))
        
        # 高频系数（短期细节）
        alpha_high = F.sigmoid(self.W_alpha_high(x)) * 0.3  # 限制高频不超过0.3
        
        # 内容转换
        content = paddle.tanh(self.W_phi(x))
        
        # 计算新的内容权重
        content_weight = 1 - alpha_low - alpha_high
        content_weight = paddle.clip(content_weight, min=0.0, max=1.0)
        
        # 并行化计算（类似SAMCell）
        # h_t = α_low * h_{t-1} + α_high * x_t + content_weight * content_t
        # 合并后两项作为"有效内容"
        effective_content = (alpha_high * x + content_weight * content) / (1 - alpha_low + 1e-10)
        beta = 1 - alpha_low  # 更新比例
        
        # 使用log空间计算累积乘积
        log_alpha_low = paddle.log(alpha_low + 1e-10)
        cumsum_log_alpha = paddle.cumsum(log_alpha_low, axis=1)
        cumprod_alpha = paddle.exp(cumsum_log_alpha)
        
        # 加权有效内容
        weighted_content = beta * effective_content / (cumprod_alpha + 1e-10)
        cumsum_weighted = paddle.cumsum(weighted_content, axis=1)
        
        # 添加初始状态
        h_0_expanded = h_prev.unsqueeze(1) / (cumprod_alpha[:, :1, :] + 1e-10)
        cumsum_with_init = paddle.concat([h_0_expanded, cumsum_weighted[:, :-1, :]], axis=1)
        h = cumprod_alpha * cumsum_with_init
        
        y = self.W_o(h)
        y = self.dropout(y)
        
        return y, h


# PGLSTM Model - 使用PGLSTM架构的模型
class PGLSTMModel(nn.Layer):
    """
    PGLSTM: Parallel Gated LSTM模型
    块内并行LSTM，使用门控聚合模拟时序依赖
    """
    def __init__(self, vocab_size, embedding_dim, window, units, n=1, num_heads=4, chunk_size=4, tst=False, **kwargs):
        super(PGLSTMModel, self).__init__(**kwargs)
        self.vocab_size = vocab_size
        self.embedding_dim = embedding_dim
        self.window = window
        self.units = units
        self.n = n
        self.num_heads = num_heads
        self.chunk_size = chunk_size
        
        self.dropout = nn.Dropout(0.1)
        
        # Input projection
        self.input_proj = nn.Linear(embedding_dim, units, bias_attr=False,
                                   weight_attr=ParamAttr(initializer=TruncatedNormal(std=0.02)))
        
        # PGLSTM Cells
        self.pglstm_cells = nn.LayerList([
            PGLSTMCell(units, num_heads=num_heads, chunk_size=chunk_size, dropout=0.1) for _ in range(n)
        ])
        
        self.ln = nn.LayerNorm(units, epsilon=1e-6)
        
    def forward(self, inputs, training=None):
        # Project input
        x = self.input_proj(inputs)
        x = self.dropout(x)
        
        # Apply PGLSTM cells
        for cell in self.pglstm_cells:
            x, _ = cell(x, h_prev=None, c_prev=None)
        
        x = self.ln(x)
        
        return x


# RH-LSTM Model - 使用RH-LSTM架构的模型
class RHLSTMModel(nn.Layer):
    """
    RH-LSTM: Residual Highway LSTM模型
    
    核心特性：
    1. 残差高速连接：支持64+层堆叠
    2. 动态DropConnect：小数据专用正则化
    3. 可选层归一化：层数>32时启用
    """
    def __init__(self, vocab_size, embedding_dim, window, units, n=1, use_layer_norm=False, tst=False, **kwargs):
        super(RHLSTMModel, self).__init__(**kwargs)
        self.vocab_size = vocab_size
        self.embedding_dim = embedding_dim
        self.window = window
        self.units = units
        self.n = n
        
        # 层数>32时自动启用层归一化
        if n > 32 and not use_layer_norm:
            use_layer_norm = True
            print(f"RH-LSTM: 层数{n}>32，自动启用层归一化")
        
        self.dropout = nn.Dropout(0.1)
        
        # Input projection
        self.input_proj = nn.Linear(embedding_dim, units, bias_attr=False,
                                   weight_attr=ParamAttr(initializer=TruncatedNormal(std=0.02)))
        
        # RH-LSTM Cells
        self.rhlstm_cells = nn.LayerList([
            RHLSTMCell(units, dropout=0.1, use_layer_norm=use_layer_norm) for _ in range(n)
        ])
        
        self.ln = nn.LayerNorm(units, epsilon=1e-6)
        
    def set_epoch(self, epoch):
        """设置当前epoch，传递给所有RH-LSTM单元"""
        for cell in self.rhlstm_cells:
            cell.set_epoch(epoch)
        
    def forward(self, inputs, training=None):
        # Project input
        x = self.input_proj(inputs)
        x = self.dropout(x)
        
        # Apply RH-LSTM cells
        # 每层独立处理，不跨层传递状态（简化设计）
        for cell in self.rhlstm_cells:
            x, _ = cell(x, h_prev=None, c_prev=None)
        
        x = self.ln(x)
        
        return x


# P-LSTM Model - 使用P-LSTM架构的模型（保留备用）
class PLSTMModel(nn.Layer):
    """
    P-LSTM: Parallel LSTM with Multi-Head Gating模型
    多头并行LSTM，支持跨头状态混合
    """
    def __init__(self, vocab_size, embedding_dim, window, units, n=1, num_heads=4, tst=False, **kwargs):
        super(PLSTMModel, self).__init__(**kwargs)
        self.vocab_size = vocab_size
        self.embedding_dim = embedding_dim
        self.window = window
        self.units = units
        self.n = n
        self.num_heads = num_heads
        
        self.dropout = nn.Dropout(0.1)
        
        # Input projection
        self.input_proj = nn.Linear(embedding_dim, units, bias_attr=False,
                                   weight_attr=ParamAttr(initializer=TruncatedNormal(std=0.02)))
        
        # P-LSTM Cells
        self.plstm_cells = nn.LayerList([
            PLSTMCell(units, num_heads=num_heads, dropout=0.1) for _ in range(n)
        ])
        
        self.ln = nn.LayerNorm(units, epsilon=1e-6)
        
    def forward(self, inputs, training=None):
        # Project input
        x = self.input_proj(inputs)
        x = self.dropout(x)
        
        # Apply P-LSTM cells
        for cell in self.plstm_cells:
            x, _ = cell(x, h_prev=None, c_prev=None)
        
        x = self.ln(x)
        
        return x


# SAM Model - 使用SAM架构的模型（保留备用）
class SAMModel(nn.Layer):
    """
    SAM: Selective Accumulative Memory模型
    极致简化的序列建模，参数量只有4d²
    """
    def __init__(self, vocab_size, embedding_dim, window, units, n=1, use_pp=True, tst=False, **kwargs):
        super(SAMModel, self).__init__(**kwargs)
        self.vocab_size = vocab_size
        self.embedding_dim = embedding_dim
        self.window = window
        self.units = units
        self.n = n
        self.use_pp = use_pp  # 是否使用SAM++增强版
        
        self.dropout = nn.Dropout(0.1)
        
        # Input projection
        self.input_proj = nn.Linear(embedding_dim, units, bias_attr=False,
                                   weight_attr=ParamAttr(initializer=TruncatedNormal(std=0.02)))
        
        # SAM Cells v2
        CellClass = SAMPPCell if use_pp else SAMCell
        self.sam_cells = nn.LayerList([
            CellClass(units, num_heads=4, dropout=0.1) for _ in range(n)
        ])
        
        self.ln = nn.LayerNorm(units, epsilon=1e-6)
        
    def forward(self, inputs, training=None):
        # Project input
        x = self.input_proj(inputs)
        x = self.dropout(x)
        
        # Apply SAM cells
        # 每层独立维护自己的隐藏状态，不跨层传递
        for cell in self.sam_cells:
            x, _ = cell(x, h_prev=None)
        
        x = self.ln(x)
        
        return x


# LADNet Model - 使用LAD-Net v2架构的模型（保留但不再使用）
class LADNetModel(nn.Layer):
    """
    LAD-Net v2: 可学习分层窗口架构模型
    """
    def __init__(self, vocab_size, embedding_dim, window, units, n=1, tst=False, **kwargs):
        super(LADNetModel, self).__init__(**kwargs)
        self.vocab_size = vocab_size
        self.embedding_dim = embedding_dim
        self.window = window
        self.units = units
        self.n = n
        
        self.dropout = nn.Dropout(0.1)
        
        # Input projection
        self.input_proj = nn.Linear(embedding_dim, units, bias_attr=False,
                                   weight_attr=ParamAttr(initializer=TruncatedNormal(std=0.02)))
        
        # LADNet Blocks - 传递layer_idx以实现层特定衰减率
        self.ladnet_blocks = nn.LayerList([
            LADNetBlock(units, num_heads=4, dropout=0.1, layer_idx=i) for i in range(n)
        ])
        
        self.ln = nn.LayerNorm(units, epsilon=1e-6)
        
    def forward(self, inputs, training=None):
        # Project input
        x = self.input_proj(inputs)
        x = self.dropout(x)
        
        # Apply LADNet blocks
        for block in self.ladnet_blocks:
            x = block(x)
        
        x = self.ln(x)
        
        # LAD-Net保留完整的序列输出
        return x


# RWKV Model - 使用RWKV架构的模型
class RWKVModel(nn.Layer):
    def __init__(self, vocab_size, embedding_dim, window, units, n=1, tst=False, **kwargs):
        super(RWKVModel, self).__init__(**kwargs)
        self.vocab_size = vocab_size
        self.embedding_dim = embedding_dim
        self.window = window
        self.units = units
        self.n = n
        
        self.dropout = nn.Dropout(0.1)
        
        # Input projection
        self.input_proj = nn.Linear(embedding_dim, units, bias_attr=False,
                                   weight_attr=ParamAttr(initializer=TruncatedNormal(std=0.02)))
        
        # RWKV Blocks
        self.rwkv_blocks = nn.LayerList([
            RWKVBlock(units, num_heads=4, dropout=0.1) for _ in range(n)
        ])
        
        self.ln = nn.LayerNorm(units, epsilon=1e-6)
        
    def forward(self, inputs, training=None):
        # Project input
        x = self.input_proj(inputs)
        x = self.dropout(x)
        
        # Apply RWKV blocks
        for block in self.rwkv_blocks:
            x = block(x)
        
        x = self.ln(x)
        
        # RWKV不受窗口长度限制，不需要截取
        # 保留完整的序列输出
        
        return x

# AnchorJudgeNet - 锚点判断网络
class AnchorJudgeNet(nn.Layer):
    def __init__(self, embed_dim):
        super(AnchorJudgeNet, self).__init__()
        self.embed_dim = embed_dim
        self.dense1 = nn.Linear(embed_dim * 3, embed_dim // 2, 
                               weight_attr=ParamAttr(initializer=TruncatedNormal(std=0.02)),
                               bias_attr=ParamAttr(initializer=Constant(0.0)))
        self.dense2 = nn.Linear(embed_dim // 2, 1, 
                               weight_attr=ParamAttr(initializer=TruncatedNormal(std=0.02)),
                               bias_attr=ParamAttr(initializer=Constant(0.0)))
        self.sigmoid = nn.Sigmoid()

    def forward(self, anchor_emb, chain_agg_emb, cand_emb):
        # 拼接特征
        combined = paddle.concat([anchor_emb, chain_agg_emb, cand_emb], axis=-1)
        # 预测是否为锚点
        x = self.dense1(combined)
        x = F.relu(x)
        x = self.dense2(x)
        is_anchor = self.sigmoid(x) > 0.5
        return is_anchor, x

# CLModel_TraceChain - 追溯链编码器
class CLModel_TraceChain(nn.Layer):
    def __init__(self, vocab_size, embedding_dim, window, units, n=1, tst=False, his_q=0.75, 
                 use_matt=True, att_q=0.4, att_units=None, n_char=3, wd_q=1.0, nh=8, 
                 train_deep_layer=True, train_main=True, num_chargru_layer=8, embed_q=0.5, **kwargs):
        super(CLModel_TraceChain, self).__init__(**kwargs)
        # 保留原模型所有初始化参数
        self.vocab_size = vocab_size
        self.embedding_dim = embedding_dim
        self.window = window
        self.units = units
        self.n = n
        self.his_q = his_q
        self.use_matt = use_matt
        self.att_q = att_q
        self.att_units = att_units if att_units is not None else units
        self.n_char = n_char
        self.wd_q = wd_q
        self.nh = nh
        self.train_deep_layer = train_deep_layer
        self.train_main = train_main
        self.num_chargru_layer = num_chargru_layer
        self.embed_q = embed_q

        # 匹配原模型的层组件
        self.dropout = nn.Dropout(0.1)
        self.lnl = nn.LayerNorm(embedding_dim, epsilon=1e-6)
        self.lnl0 = nn.LayerNorm(embedding_dim, epsilon=1e-6)
        self.lnl1 = nn.LayerNorm(units, epsilon=1e-6)

        # 追溯链核心组件
        self.anchor_judge = AnchorJudgeNet(embed_dim=embedding_dim)
        self.chain_encoder = nn.Linear(embedding_dim, units, 
                                      weight_attr=ParamAttr(initializer=TruncatedNormal(std=0.02)),
                                      bias_attr=ParamAttr(initializer=Constant(0.0)))
        self.output_proj = nn.Linear(units, embedding_dim, 
                                   weight_attr=ParamAttr(initializer=TruncatedNormal(std=0.02)),
                                   bias_attr=ParamAttr(initializer=Constant(0.0)))

    def _extract_trace_chain(self, inputs):
        """提取追溯链"""
        batch_size = inputs.shape[0]
        seq_len = inputs.shape[1]
        embed_dim = self.embedding_dim

        # 初始化追溯链存储（shape与输入一致）
        trace_chain = paddle.zeros_like(inputs)

        # 逐样本提取追溯链
        for b in range(batch_size):
            sample_input = inputs[b:b+1, :, :]  # [1, seq_len, embed_dim]
            sample_chain = paddle.zeros([1, seq_len, embed_dim])  # 初始化样本追溯链
            chain_idx = 0  # 追溯链位置指针

            # 1. 初始锚点：序列最后一个token
            last_emb = sample_input[:, -1, :]  # [1, embed_dim]
            anchor_emb = last_emb
            chain_agg_emb = paddle.zeros([1, embed_dim])  # 追溯链聚合emb
            cand_idx = seq_len - 2  # 从倒数第二个token开始遍历

            # 2. 反向遍历提取锚点（过滤无意义token）
            while cand_idx >= 0:
                cand_emb = sample_input[:, cand_idx, :]  # [1, embed_dim]
                # 判断是否为有效锚点
                is_anchor, _ = self.anchor_judge(anchor_emb, chain_agg_emb, cand_emb)

                if is_anchor.item():
                    # 将锚点添加到追溯链
                    sample_chain[0, chain_idx, :] = cand_emb[0]
                    chain_idx += 1
                    # 更新锚点和聚合emb
                    anchor_emb = cand_emb
                    if chain_idx > 0:
                        chain_agg_emb = paddle.mean(sample_chain[0:1, :chain_idx, :], axis=1)

                cand_idx -= 1

            # 3. 反转追溯链
            sample_chain = paddle.flip(sample_chain, axis=[1])
            # 4. 赋值到批量追溯链中
            trace_chain[b:b+1, :, :] = sample_chain

        return trace_chain

    def forward(self, inputs, training=None, use_teacher_forcing=True):
        """完全匹配原模型输入输出"""
        # 输入预处理（匹配原模型）
        embedded_inputs = inputs
        embedded_inputs = self.dropout(embedded_inputs)

        # 提取追溯链
        trace_chain = self._extract_trace_chain(embedded_inputs)

        # 匹配原模型的层归一化流程
        trace_chain = self.lnl0(trace_chain)

        # 追溯链编码+维度对齐
        sequence = self.chain_encoder(trace_chain)
        sequence = self.lnl1(sequence)
        sequence = self.output_proj(sequence)
        sequence = self.lnl(sequence)

        # 输出shape：[batch_size, seq_len, embedding_dim]（与其他专家一致）
        return sequence

# InputDrivenDynamicDense_t7_3 - 输入驱动的动态密集层
class InputDrivenDynamicDense_t7_3(nn.Layer):
    def __init__(self, input_dim, units, tst=False):
        super(InputDrivenDynamicDense_t7_3, self).__init__()
        self.input_dim = input_dim
        self.units = units
        self.trainable_flag = not tst
        
        # 动态参数生成网络
        self.param_generator = nn.Sequential(
            nn.Linear(input_dim, units * 2, 
                      weight_attr=ParamAttr(initializer=TruncatedNormal(std=0.02)),
                      bias_attr=ParamAttr(initializer=Constant(0.0))),
            nn.ReLU(),
            nn.Linear(units * 2, units * (input_dim + 1),  # 权重 + 偏置
                      weight_attr=ParamAttr(initializer=TruncatedNormal(std=0.02)),
                      bias_attr=ParamAttr(initializer=Constant(0.0)))
        )
        
        # 静态参数
        self.static_weight = self.create_parameter(
            shape=[units, input_dim],
            attr=ParamAttr(initializer=TruncatedNormal(std=0.02))
        )
        self.static_bias = self.create_parameter(
            shape=[units],
            attr=ParamAttr(initializer=Constant(0.0))
        )

    def forward(self, inputs):
        batch_size, seq_len, input_dim = inputs.shape
        
        # 生成动态参数
        # 对每个时间步生成参数
        dynamic_params = []
        for t in range(seq_len):
            # 取当前时间步的输入
            current_input = inputs[:, t, :]  # [batch_size, input_dim]
            # 生成动态参数
            params = self.param_generator(current_input)  # [batch_size, units*(input_dim+1)]
            dynamic_params.append(params)
        dynamic_params = paddle.stack(dynamic_params, axis=1)  # [batch_size, seq_len, units*(input_dim+1)]
        
        # 分离权重和偏置
        dynamic_weight = dynamic_params[:, :, :self.units * input_dim].reshape(
            [batch_size, seq_len, self.units, input_dim]
        )
        dynamic_bias = dynamic_params[:, :, self.units * input_dim:].reshape(
            [batch_size, seq_len, self.units]
        )
        
        # 计算输出
        outputs = []
        for t in range(seq_len):
            # 取当前时间步的输入和参数
            current_input = inputs[:, t, :].unsqueeze(2)  # [batch_size, input_dim, 1]
            current_weight = dynamic_weight[:, t, :, :]  # [batch_size, units, input_dim]
            current_bias = dynamic_bias[:, t, :]  # [batch_size, units]
            
            # 计算动态参数的输出
            dynamic_output = paddle.bmm(current_weight, current_input).squeeze(2) + current_bias
            # 计算静态参数的输出
            static_output = paddle.matmul(current_input.squeeze(2), self.static_weight.t()) + self.static_bias
            # 融合输出
            output = static_output + dynamic_output
            outputs.append(output)
        outputs = paddle.stack(outputs, axis=1)  # [batch_size, seq_len, units]
        
        return outputs

# LinearAttentionTransformerBlock_dense_t7_3 - 线性注意力Transformer块
class LinearAttentionTransformerBlock_dense_t7_3(nn.Layer):
    def __init__(self, embed_dim, num_heads, alpha_initial=0.1, 
                 ffn_dim_multiplier=2, use_thought_space=True, tst=False):
        super(LinearAttentionTransformerBlock_dense_t7_3, self).__init__()
        self.embed_dim = embed_dim
        self.num_heads = num_heads
        self.head_dim = embed_dim // num_heads
        self.alpha_initial = alpha_initial
        self.ffn_dim_multiplier = ffn_dim_multiplier
        self.use_thought_space = use_thought_space
        self.trainable_flag = not tst
        
        # 线性注意力
        self.query_proj = nn.Linear(embed_dim, embed_dim, 
                                   weight_attr=ParamAttr(initializer=TruncatedNormal(std=0.02)),
                                   bias_attr=ParamAttr(initializer=Constant(0.0)))
        self.key_proj = nn.Linear(embed_dim, embed_dim, 
                                  weight_attr=ParamAttr(initializer=TruncatedNormal(std=0.02)),
                                  bias_attr=ParamAttr(initializer=Constant(0.0)))
        self.value_proj = nn.Linear(embed_dim, embed_dim, 
                                   weight_attr=ParamAttr(initializer=TruncatedNormal(std=0.02)),
                                   bias_attr=ParamAttr(initializer=Constant(0.0)))
        self.out_proj = nn.Linear(embed_dim, embed_dim, 
                                 weight_attr=ParamAttr(initializer=TruncatedNormal(std=0.02)),
                                 bias_attr=ParamAttr(initializer=Constant(0.0)))
        
        # 前馈网络
        self.ffn = nn.Sequential(
            nn.Linear(embed_dim, embed_dim * ffn_dim_multiplier, 
                      weight_attr=ParamAttr(initializer=TruncatedNormal(std=0.02)),
                      bias_attr=ParamAttr(initializer=Constant(0.0))),
            nn.GELU(),
            nn.Linear(embed_dim * ffn_dim_multiplier, embed_dim, 
                      weight_attr=ParamAttr(initializer=TruncatedNormal(std=0.02)),
                      bias_attr=ParamAttr(initializer=Constant(0.0)))
        )
        
        # 层归一化
        self.norm1 = nn.LayerNorm(embed_dim, epsilon=1e-5)
        self.norm2 = nn.LayerNorm(embed_dim, epsilon=1e-5)
        
        # Dropout
        self.dropout = nn.Dropout(0.1)

    def forward(self, x):
        batch_size, seq_len, embed_dim = x.shape
        
        # 线性注意力
        q = self.query_proj(x)  # [batch_size, seq_len, embed_dim]
        k = self.key_proj(x)    # [batch_size, seq_len, embed_dim]
        v = self.value_proj(x)  # [batch_size, seq_len, embed_dim]
        
        # 重塑为多头
        q = q.reshape([batch_size, seq_len, self.num_heads, self.head_dim]).transpose([0, 2, 1, 3])
        k = k.reshape([batch_size, seq_len, self.num_heads, self.head_dim]).transpose([0, 2, 1, 3])
        v = v.reshape([batch_size, seq_len, self.num_heads, self.head_dim]).transpose([0, 2, 1, 3])
        
        # 线性注意力计算
        # 简化版线性注意力
        k = F.elu(k) + 1
        kv = paddle.matmul(k.transpose([0, 1, 3, 2]), v)  # [batch_size, num_heads, head_dim, head_dim]
        q = F.elu(q) + 1
        context = paddle.matmul(q, kv)  # [batch_size, num_heads, seq_len, head_dim]
        
        # 重塑回原始形状
        context = context.transpose([0, 2, 1, 3]).reshape([batch_size, seq_len, embed_dim])
        attn_output = self.out_proj(context)
        attn_output = self.dropout(attn_output)
        
        # 残差连接和层归一化
        x = self.norm1(x + attn_output)
        
        # 前馈网络
        ffn_output = self.ffn(x)
        ffn_output = self.dropout(ffn_output)
        
        # 残差连接和层归一化
        x = self.norm2(x + ffn_output)
        
        return x

# MemoryEnhancedTransformer_dense_t7_3 - 内存增强Transformer
class MemoryEnhancedTransformer_dense_t7_3(nn.Layer):
    def __init__(self, vocab_size, embedding_dim, units, max_sequence_length, 
                 num_layers, num_heads, alpha_initial=0.1, ffn_dim_multiplier=2, 
                 use_thought_space=True, dropout_rate=0.2, maxlen=130, tst=False):
        super(MemoryEnhancedTransformer_dense_t7_3, self).__init__()
        self.vocab_size = vocab_size
        self.embedding_dim = embedding_dim
        self.units = units
        self.maxlen = maxlen
        self.seq_len = maxlen
        self.trainable_flag = not tst
        
        # 动态密集层（输入驱动的参数化层）
        self.dynamic_layer = InputDrivenDynamicDense_t7_3(
            input_dim=embedding_dim,
            units=units,
            tst=tst
        )
        
        # Transformer块
        self.transformer_blocks = []
        for i in range(num_layers):
            block = LinearAttentionTransformerBlock_dense_t7_3(
                embed_dim=embedding_dim,
                num_heads=num_heads,
                alpha_initial=alpha_initial,
                ffn_dim_multiplier=ffn_dim_multiplier,
                use_thought_space=use_thought_space,
                tst=tst
            )
            self.transformer_blocks.append(block)
            self.add_sublayer(f'transformer_block_{i}', block)
        
        # Dropout
        self.dropout = nn.Dropout(dropout_rate)

    def forward(self, x):
        batch_size, seq_len, embed_dim = x.shape
        
        # 使用动态密集层
        x = self.dynamic_layer(x)
        
        # 通过Transformer块
        for block in self.transformer_blocks:
            x = block(x)
        
        # 应用dropout
        x = self.dropout(x)
        
        return x

# create_memory_model_dense_t7_3 - 创建内存增强Transformer模型
def create_memory_model_dense_t7_3(vocab_size, embedding_dim, max_sequence_length, 
                                  num_layers, num_heads, alpha_initial=0.1, 
                                  ffn_dim_multiplier=2, use_thought_space=True, 
                                  dropout_rate=0.2, maxlen=130, tst=False):
    """
    创建输入驱动的动态参数Transformer模型（t7_3版本）
    核心特性：
    1. 动态参数：输入文本编码驱动小网络输出与最终密集层参数shape完全一致的动态参数
    2. 软路由加权：路由网络输出与动态参数shape完全一致的软路由权重
    3. 输入决定参数：每个输入批次的文本编码不同，最终密集层的实际使用参数不同
    4. 效果优先：忽略计算效率，采用元素级加权、深层小网络和路由网络
    """
    return MemoryEnhancedTransformer_dense_t7_3(
        vocab_size=vocab_size,
        embedding_dim=embedding_dim,
        units=embedding_dim,
        max_sequence_length=max_sequence_length,
        num_layers=num_layers,
        num_heads=num_heads,
        alpha_initial=alpha_initial,
        ffn_dim_multiplier=ffn_dim_multiplier,
        use_thought_space=use_thought_space,
        dropout_rate=dropout_rate,
        maxlen=maxlen,
        tst=tst
    )

# GRU Expert Model
class GRUExpert(nn.Layer):
    def __init__(self, vocab_size, embed_dim, hidden_size, num_layers=1, dropout=0.1, maxlen=128):
        super().__init__()
        self.vocab_size = vocab_size
        self.embed_dim = embed_dim
        self.hidden_size = hidden_size
        self.num_layers = num_layers
        self.maxlen = maxlen  # 序列最大长度，与Transformer专家一致
        
        # Embedding layer (共享权重)
        self.embedding = nn.Embedding(
            num_embeddings=vocab_size,
            embedding_dim=embed_dim,
            weight_attr=ParamAttr(initializer=TruncatedNormal(std=0.02))
        )
        
        # GRU layer
        self.gru = nn.GRU(
            input_size=embed_dim,
            hidden_size=hidden_size,
            num_layers=num_layers,
            dropout=dropout if num_layers > 1 else 0
        )
        
        # Dropout
        self.dropout = nn.Dropout(dropout)
        
    def forward(self, inputs):
        """
        Args:
            inputs: [batch_size, seq_len, embed_dim]  # 已经经过嵌入的输入
        Returns:
            output: [batch_size, seq_len, hidden_size]  # 输出hidden_size维度，与TensorFlow一致
        """
        x = inputs
        x = self.dropout(x)
        
        # Paddle GRU expects [seq_len, batch_size, embed_dim]
        x = x.transpose([1, 0, 2])  # [seq_len, batch_size, embed_dim]
        
        # GRU forward pass
        gru_out, _ = self.gru(x)  # gru_out: [seq_len, batch_size, hidden_size]
        
        # Convert back to [batch_size, seq_len, hidden_size]
        gru_out = gru_out.transpose([1, 0, 2])
        
        # 与Transformer专家一致，只保留最后maxlen个时间步
        seq_len = gru_out.shape[1]
        start_index = max(0, seq_len - self.maxlen)
        gru_out = gru_out[:, start_index:, :]
        
        # 注意：不投影到embed_dim，输出hidden_size维度，与TensorFlow版本一致
        # 投影在MoE模型的next_token_predictor中统一进行
        return gru_out

# Position Embedding for Linear Attention Transformer (与TensorFlow版本一致)
class PositionEmbedding_dense_t7(nn.Layer):
    def __init__(self, max_sequence_length, embedding_dim, tst=False):
        super(PositionEmbedding_dense_t7, self).__init__()
        self.max_sequence_length = max_sequence_length
        self.embedding_dim = embedding_dim
        
        self.position_embedding = nn.Embedding(
            num_embeddings=max_sequence_length,
            embedding_dim=embedding_dim,
            weight_attr=ParamAttr(initializer=TruncatedNormal(std=0.02))
        )

    def forward(self, x):
        seq_length = x.shape[1]
        positions = paddle.arange(seq_length, dtype='int64')
        positions = self.position_embedding(positions)
        return x + positions


# Linear Multi-Head Attention (与TensorFlow版本一致)
class LinearMultiHeadAttention_t7(nn.Layer):
    def __init__(self, embed_dim, num_heads, tst=False):
        super(LinearMultiHeadAttention_t7, self).__init__()
        self.embed_dim = embed_dim
        self.num_heads = num_heads
        self.head_dim = embed_dim // num_heads
        
        # 线性投影层
        self.query_dense = nn.Linear(embed_dim, embed_dim,
                                     weight_attr=ParamAttr(initializer=TruncatedNormal(std=0.02)),
                                     bias_attr=ParamAttr(initializer=Constant(0.0)))
        self.key_dense = nn.Linear(embed_dim, embed_dim,
                                   weight_attr=ParamAttr(initializer=TruncatedNormal(std=0.02)),
                                   bias_attr=ParamAttr(initializer=Constant(0.0)))
        self.value_dense = nn.Linear(embed_dim, embed_dim,
                                     weight_attr=ParamAttr(initializer=TruncatedNormal(std=0.02)),
                                     bias_attr=ParamAttr(initializer=Constant(0.0)))
        self.combine_heads = nn.Linear(embed_dim, embed_dim,
                                       weight_attr=ParamAttr(initializer=TruncatedNormal(std=0.02)),
                                       bias_attr=ParamAttr(initializer=Constant(0.0)))

    def forward(self, inputs):
        # 投影得到Q, K, V
        query = self.query_dense(inputs)
        key = self.key_dense(inputs)
        value = self.value_dense(inputs)
        
        # 分割多头
        query = self.split_heads(query)
        key = self.split_heads(key)
        value = self.split_heads(value)
        
        # 应用特征映射 (ELU + 1)
        query = F.elu(query) + 1.0
        key = F.elu(key) + 1.0
        
        # 线性注意力计算
        # 计算 K^T V (形状: [batch, heads, head_dim, head_dim])
        kv = paddle.einsum('bhid,bhjv->bhdv', key, value)
        
        # 计算归一化因子 Z = sum(K, dim=2)
        z = paddle.sum(key, axis=2)  # [batch, heads, head_dim]
        
        # 计算注意力输出: Q * (K^T V) / (Q * Z)
        numerator = paddle.einsum('bhsd,bhdv->bhsv', query, kv)
        denominator = paddle.einsum('bhsd,bhd->bhs', query, z) + 1e-6
        denominator = denominator.unsqueeze(-1)  # [batch, heads, seq, 1]
        attention = numerator / denominator
        
        # 合并多头
        attention = self.combine_heads(self.merge_heads(attention))
        return attention

    def split_heads(self, x):
        # 从 [batch, seq, dim] 转换为 [batch, heads, seq, head_dim]
        batch_size, seq_len, _ = x.shape
        x = x.reshape([batch_size, seq_len, self.num_heads, self.head_dim])
        return x.transpose([0, 2, 1, 3])

    def merge_heads(self, x):
        # 从 [batch, heads, seq, head_dim] 转回 [batch, seq, dim]
        batch_size, _, seq_len, _ = x.shape
        x = x.transpose([0, 2, 1, 3])
        return x.reshape([batch_size, seq_len, self.embed_dim])


# LLaMA风格的Transformer Block (使用RMSNorm和SwiGLU)
class LLaMATransformerBlock(nn.Layer):
    def __init__(self, embed_dim, num_heads, ffn_dim_multiplier=2.67, dropout=0.0):
        super(LLaMATransformerBlock, self).__init__()
        self.embed_dim = embed_dim
        self.num_heads = num_heads
        
        # 使用标准多头注意力（带旋转位置编码RoPE）
        self.attn = nn.MultiHeadAttention(
            embed_dim=embed_dim,
            num_heads=num_heads,
            dropout=dropout,
            weight_attr=ParamAttr(initializer=TruncatedNormal(std=0.02)),
            bias_attr=False  # LLaMA不使用bias
        )
        
        # RMSNorm (LLaMA使用RMSNorm而不是LayerNorm)
        self.rmsnorm1 = nn.LayerNorm(embed_dim, epsilon=1e-6)
        self.rmsnorm2 = nn.LayerNorm(embed_dim, epsilon=1e-6)
        
        # SwiGLU FFN (LLaMA风格)
        hidden_dim = int(ffn_dim_multiplier * embed_dim)
        self.w1 = nn.Linear(embed_dim, hidden_dim, bias_attr=False,
                           weight_attr=ParamAttr(initializer=TruncatedNormal(std=0.02)))
        self.w2 = nn.Linear(hidden_dim, embed_dim, bias_attr=False,
                           weight_attr=ParamAttr(initializer=TruncatedNormal(std=0.02)))
        self.w3 = nn.Linear(embed_dim, hidden_dim, bias_attr=False,
                           weight_attr=ParamAttr(initializer=TruncatedNormal(std=0.02)))
        
        self.dropout = nn.Dropout(dropout)

    def forward(self, inputs):
        # 自注意力 (Pre-Norm)
        normed = self.rmsnorm1(inputs)
        attn_output = self.attn(normed, normed, normed)
        attn_output = self.dropout(attn_output)
        out1 = inputs + attn_output
        
        # SwiGLU FFN (Pre-Norm)
        normed = self.rmsnorm2(out1)
        # SwiGLU: swish(xW1) * (xW3)
        hidden = F.silu(self.w1(normed)) * self.w3(normed)
        ffn_output = self.w2(hidden)
        ffn_output = self.dropout(ffn_output)
        
        return out1 + ffn_output


# LLaMA风格的Transformer (替换原来的MemoryEnhancedTransformer)
class LLaMATransformer(nn.Layer):
    def __init__(self, vocab_size, embed_dim, units, max_sequence_length=2048, maxlen=128, 
                 num_layers=4, num_heads=8, ffn_dim_multiplier=2.67, dropout_rate=0.0):
        super(LLaMATransformer, self).__init__()
        self.embedding_dim = embed_dim
        self.vocab_size = vocab_size
        self.max_sequence_length = max_sequence_length
        self.num_layers = num_layers
        self.num_heads = num_heads
        self.seq_len = maxlen

        # 使用旋转位置编码(RoPE) - LLaMA风格
        self.position_embedding = PositionEmbedding_dense_t7(
            max_sequence_length=max_sequence_length,
            embedding_dim=embed_dim,
            tst=False
        )
        
        # 使用LLaMA风格的Transformer Block
        self.transformer_blocks = nn.LayerList([
            LLaMATransformerBlock(
                embed_dim=embed_dim,
                num_heads=num_heads,
                ffn_dim_multiplier=ffn_dim_multiplier,
                dropout=dropout_rate
            ) for _ in range(num_layers)
        ])
        
        self.dropout = nn.Dropout(dropout_rate)
        # 最终投影到units维度
        self.dense = nn.Linear(embed_dim, units,
                               weight_attr=ParamAttr(initializer=TruncatedNormal(std=0.02)),
                               bias_attr=False)  # LLaMA不使用bias

    def forward(self, inputs):
        x = inputs
        x = self.position_embedding(x)
        x = self.dropout(x)

        seq_length = x.shape[1]
        start_index = max(0, seq_length - self.seq_len)
        x = x[:, start_index:, :]

        for transformer_block in self.transformer_blocks:
            x = transformer_block(x)
            
        x = self.dropout(x)
        return self.dense(x)


# Transformer Language Model (标准Transformer，保留用于兼容)
class TransformerLM(nn.Layer):
    def __init__(self, vocab_size, embed_dim, num_heads, num_layers, ffn_hidden_size, max_seq_len, dropout=0.1):
        super().__init__()
        self.vocab_size = vocab_size
        self.embed_dim = embed_dim
        self.max_seq_len = max_seq_len
        
        # Position embedding
        self.pos_embedding = nn.Embedding(
            num_embeddings=max_seq_len,
            embedding_dim=embed_dim,
            weight_attr=ParamAttr(initializer=TruncatedNormal(std=0.02))
        )
        
        # Dropout
        self.dropout = nn.Dropout(dropout)
        
        # Transformer layers
        self.layers = nn.LayerList([
            TransformerEncoderLayer(embed_dim, num_heads, ffn_hidden_size, dropout)
            for _ in range(num_layers)
        ])
        
        # Final layer norm
        self.final_norm = nn.LayerNorm(embed_dim, epsilon=1e-5)
    
    def forward(self, inputs):
        batch_size, seq_len, embed_dim = inputs.shape
        
        # Create position ids
        position_ids = paddle.arange(seq_len, dtype='int64').unsqueeze(0).expand([batch_size, seq_len])
        
        # Add position embedding
        x = inputs + self.pos_embedding(position_ids)
        x = self.dropout(x)
        
        # Create attention mask
        attn_mask = paddle.triu(paddle.ones([seq_len, seq_len], dtype='float32') * -1e9, diagonal=1)
        
        # Transformer layers
        for layer in self.layers:
            x = layer(x, attn_mask=attn_mask)
        
        # Final norm
        x = self.final_norm(x)
        
        return x

# CustomMultiHeadAttentionGRUCell - 多头注意力GRU单元
class CustomMultiHeadAttentionGRUCell(nn.Layer):
    def __init__(self, units, attention_units, num_heads=16, activation='tanh', 
                 recurrent_activation='sigmoid', use_bias=True, tst=False):
        super(CustomMultiHeadAttentionGRUCell, self).__init__()
        self.units = units
        self.attention_units = attention_units
        self.num_heads = num_heads
        assert attention_units % num_heads == 0, "Attention units must be divisible by the number of heads"
        self.depth = attention_units // num_heads
        self.activation = activation
        self.recurrent_activation = recurrent_activation
        self.use_bias = use_bias
        self.trainable_flag = not tst

        # GRU门控权重
        self.kernel_z = self.create_parameter(
            shape=[units, units],
            attr=ParamAttr(initializer=TruncatedNormal(std=0.02))
        )
        self.kernel_r = self.create_parameter(
            shape=[units, units],
            attr=ParamAttr(initializer=TruncatedNormal(std=0.02))
        )
        self.kernel_h = self.create_parameter(
            shape=[units, units],
            attr=ParamAttr(initializer=TruncatedNormal(std=0.02))
        )
        
        # 复查门权重
        self.kernel_rev = self.create_parameter(
            shape=[units, units],
            attr=ParamAttr(initializer=TruncatedNormal(std=0.02))
        )

        # 语法联系门
        self.kernel_scg1 = self.create_parameter(
            shape=[units * 2 + attention_units, units],
            attr=ParamAttr(initializer=TruncatedNormal(std=0.02))
        )
        if use_bias:
            self.bias_scg1 = self.create_parameter(
                shape=[units],
                attr=ParamAttr(initializer=Constant(0.0))
            )
        
        # 第二层SCG权重和偏置
        self.kernel_scg2 = self.create_parameter(
            shape=[units, units],
            attr=ParamAttr(initializer=TruncatedNormal(std=0.02))
        )
        if use_bias:
            self.bias_scg2 = self.create_parameter(
                shape=[units],
                attr=ParamAttr(initializer=Constant(0.0))
            )
    
        # 多头注意力机制相关权重
        self.wq_att = self.create_parameter(
            shape=[units, attention_units],
            attr=ParamAttr(initializer=TruncatedNormal(std=0.02))
        )
        self.wk_att = self.create_parameter(
            shape=[units, attention_units],
            attr=ParamAttr(initializer=TruncatedNormal(std=0.02))
        )
        self.wv_att = self.create_parameter(
            shape=[units, attention_units],
            attr=ParamAttr(initializer=TruncatedNormal(std=0.02))
        )
        self.u_att = self.create_parameter(
            shape=[attention_units, num_heads],
            attr=ParamAttr(initializer=TruncatedNormal(std=0.02))
        )

        if use_bias:
            self.bias_z = self.create_parameter(
                shape=[units],
                attr=ParamAttr(initializer=Constant(0.0))
            )
            self.bias_r = self.create_parameter(
                shape=[units],
                attr=ParamAttr(initializer=Constant(0.0))
            )
            self.bias_h = self.create_parameter(
                shape=[units],
                attr=ParamAttr(initializer=Constant(0.0))
            )
            self.bias_att = self.create_parameter(
                shape=[num_heads],
                attr=ParamAttr(initializer=Constant(0.0))
            )
            self.bias_rev = self.create_parameter(
                shape=[units],
                attr=ParamAttr(initializer=Constant(0.0))
            )

        self.layernorm_1 = nn.LayerNorm(units, epsilon=1e-6)
        self.layernorm_2 = nn.LayerNorm(units, epsilon=1e-6)

    def attention(self, h_tm1, h_all):
        # 多头注意力机制
        Q = paddle.matmul(h_tm1, self.wq_att)  # [batch_size, attention_units]
        K = paddle.matmul(h_all, self.wk_att)  # [batch_size, seq_len, attention_units]
        V = paddle.matmul(h_all, self.wv_att)  # [batch_size, seq_len, attention_units]

        # 形状调整以便进行多头注意力计算
        Q = Q.reshape([-1, self.num_heads, self.depth])  # [batch_size, num_heads, depth]
        K = K.reshape([-1, K.shape[1], self.num_heads, self.depth])  # [batch_size, seq_len, num_heads, depth]
        V = V.reshape([-1, V.shape[1], self.num_heads, self.depth])  # [batch_size, seq_len, num_heads, depth]

        # 计算注意力分数并应用softmax
        Q = Q.unsqueeze(1)  # [batch_size, 1, num_heads, depth]
        K = K.transpose([0, 2, 1, 3])  # [batch_size, num_heads, seq_len, depth]
        scores = paddle.matmul(Q, K, transpose_y=True) / (self.depth ** 0.5)  # [batch_size, num_heads, 1, seq_len]
        att_weights = F.softmax(scores, axis=-1)  # [batch_size, num_heads, 1, seq_len]

        # 上下文向量计算
        V = V.transpose([0, 2, 1, 3])  # [batch_size, num_heads, seq_len, depth]
        context_vector = paddle.matmul(att_weights, V)  # [batch_size, num_heads, 1, depth]
        context_vector = context_vector.squeeze(2).reshape([-1, self.attention_units])  # [batch_size, attention_units]

        return context_vector

    def forward(self, inputs, states):
        h_tm1, h_all = states  # h_all 是累积的历史隐藏状态

        # 在每个时间步，将前一时间步的隐藏状态累积到历史隐藏状态中
        h_all = paddle.concat([h_all, h_tm1.unsqueeze(1)], axis=1)
        
        context_vector = self.attention(h_tm1, h_all)

        # 残差连接和层归一化
        h_tm1_res = self.layernorm_1(h_tm1 + context_vector)

        # 新增：复查门计算
        rev_gate = F.sigmoid(paddle.matmul(inputs, self.kernel_rev) + paddle.matmul(h_tm1_res, self.kernel_rev) + self.bias_rev)
        context_adjusted = rev_gate * context_vector

        # GRU更新，使用调整后的上下文向量
        z = F.sigmoid(paddle.matmul(inputs, self.kernel_z) + paddle.matmul(h_tm1_res, self.kernel_z) + self.bias_z)
        r = F.sigmoid(paddle.matmul(inputs, self.kernel_r) + paddle.matmul(h_tm1_res, self.kernel_r) + self.bias_r)
        rh_tm1 = r * h_tm1_res
        hh = F.tanh(paddle.matmul(inputs, self.kernel_h) + paddle.matmul(rh_tm1, self.kernel_h) + self.bias_h)
        h = z * h_tm1_res + (1 - z) * hh

        # 融合复查门调整后的上下文信息
        h = h + context_adjusted * 1.2
        
        # 新增：计算语法联系门
        scg_input = paddle.concat([inputs, h_tm1_res, context_vector], axis=-1)
        scg1 = F.sigmoid(paddle.matmul(scg_input, self.kernel_scg1) + self.bias_scg1)

        # 第二层SCG进一步调整
        scg2_input = paddle.concat([scg1, h_tm1_res], axis=-1)  # 可以根据需要调整输入
        scg2 = F.sigmoid(paddle.matmul(scg2_input, self.kernel_scg2) + self.bias_scg2)

        # 强化调整最终隐藏状态
        h_adjusted = scg2 * h + (1 - scg2) * h_tm1_res  # 调整输出以反映语法和连贯性的考量

        # 最终层归一化（调整后）
        h_final = self.layernorm_2(h_adjusted)

        return h_final, [h_final, h_all]

# DynamicWeightFusion - 动态权重融合层
class DynamicWeightFusion(nn.Layer):
    def __init__(self, hidden_units=32, tst=False):
        super(DynamicWeightFusion, self).__init__()
        self.hidden_layer = nn.Linear(hidden_units, hidden_units, 
                                     weight_attr=ParamAttr(initializer=TruncatedNormal(std=0.02)),
                                     bias_attr=ParamAttr(initializer=Constant(0.0)))
        self.hidden_layer2 = nn.Linear(hidden_units, hidden_units, 
                                      weight_attr=ParamAttr(initializer=TruncatedNormal(std=0.02)),
                                      bias_attr=ParamAttr(initializer=Constant(0.0)))

        self.alpha_layer = nn.Linear(hidden_units, 1, 
                                   weight_attr=ParamAttr(initializer=TruncatedNormal(std=0.02)),
                                   bias_attr=ParamAttr(initializer=Constant(0.0)))
        self.beta_layer = nn.Linear(hidden_units, 1, 
                                  weight_attr=ParamAttr(initializer=TruncatedNormal(std=0.02)),
                                  bias_attr=ParamAttr(initializer=Constant(0.0)))

    def forward(self, inputs):
        hidden_rep = self.hidden_layer(inputs)
        hidden_rep = self.hidden_layer2(hidden_rep)
        alpha = F.sigmoid(self.alpha_layer(hidden_rep))
        beta = F.sigmoid(self.beta_layer(hidden_rep))
        # 确保α+β接近1
        alpha = alpha.squeeze(-1)
        beta = beta.squeeze(-1)
        return alpha, beta

# MoEModel_t7 - 混合专家模型（与TensorFlow版本一致）
class MoEModel_t7(nn.Layer):
    def __init__(self, experts, vocab_size, embed_dim=512, num_experts=4, router_units=256, 
                 expert_output_dim=512, tst=False):  # expert_output_dim为统一的输出维度
        super(MoEModel_t7, self).__init__()
        self.num_experts = num_experts
        self.vocab_size = vocab_size
        self.embed_dim = embed_dim
        self.expert_output_dim = expert_output_dim  # 统一的专家输出维度
        self.router_units = router_units
        self.trainable_flag = not tst
        
        # 使用add_sublayer注册专家，使paddle能正确识别参数
        self.experts = nn.LayerList()
        for i, expert in enumerate(experts):
            self.experts.append(expert)
        
        # 路由网络：使用轻量级GRU作为路由器
        # 路由器使用较小的配置：2层，256维
        self.router_gru = nn.GRU(
            input_size=embed_dim,
            hidden_size=router_units,
            num_layers=2,
            dropout=0.1 if not tst else 0.0,
            direction='forward'
        )
        
        # 分类头：从GRU输出到专家数量
        self.router_classifier = nn.Sequential(
            nn.LayerNorm(router_units, epsilon=1e-6),
            nn.Linear(router_units, num_experts, bias_attr=False,
                     weight_attr=ParamAttr(initializer=TruncatedNormal(std=0.02)))
        )
        
        # 将路由网络组件包装
        self.router_network = nn.Sequential(
            ('gru', self.router_gru),
            ('classifier', self.router_classifier)
        )
        
        # 为每个专家创建输出投影层（将不同维度的输出投影到统一的expert_output_dim）
        # 获取每个专家的实际输出维度
        expert_dims = []
        for expert in experts:
            # RWKVModel的输出维度是units参数
            expert_dims.append(expert.units)
        
        self.expert_output_projections = nn.LayerList()
        self.expert_norms = nn.LayerList()
        for i, dim in enumerate(expert_dims):
            # 投影层：从专家的输出维度投影到统一的expert_output_dim
            if dim != expert_output_dim:
                self.expert_output_projections.append(
                    nn.Linear(dim, expert_output_dim, bias_attr=False,
                             weight_attr=ParamAttr(initializer=TruncatedNormal(std=0.02)))
                )
            else:
                # 如果维度相同，使用Identity层
                self.expert_output_projections.append(nn.Identity())
            
            # 层归一化（在投影后应用）
            self.expert_norms.append(nn.LayerNorm(expert_output_dim, epsilon=1e-6))
        
        # 融合后的层归一化
        self.combined_norm = nn.LayerNorm(expert_output_dim, epsilon=1e-6)
        
        # 最终预测层
        self.next_token_predictor = nn.Linear(expert_output_dim, vocab_size,
                                              weight_attr=ParamAttr(initializer=TruncatedNormal(std=0.02)),
                                              bias_attr=ParamAttr(initializer=Constant(0.0)))

    def router_forward(self, inputs):
        """路由网络前向传播：使用GRU + 分类器"""
        # inputs: [batch_size, seq_len, embed_dim]
        batch_size, seq_len, embed_dim = inputs.shape
        
        # 通过GRU学习序列表示
        # GRU需要输入形状为 [seq_len, batch_size, input_size]
        x_transposed = inputs.transpose([1, 0, 2])  # [seq_len, batch_size, embed_dim]
        x, _ = self.router_gru(x_transposed)  # [seq_len, batch_size, router_units]
        x = x.transpose([1, 0, 2])  # [batch_size, seq_len, router_units]
        
        # 全局平均池化获取序列表示
        sequence_repr = paddle.mean(x, axis=1)  # [batch_size, router_units]
        
        # 通过分类头生成专家权重
        expert_weights = self.router_classifier(sequence_repr)  # [batch_size, num_experts]
        expert_weights = F.softmax(expert_weights, axis=-1)
        
        return expert_weights

    def forward(self, inputs, return_aux_loss=False):
        """
        前向传播（与TensorFlow版本一致）
        Args:
            inputs: [batch_size, seq_len, embed_dim]  # 已经经过嵌入和位置编码
            return_aux_loss: 是否返回辅助损失（用于训练时优化路由）
        Returns:
            logits: [batch_size, seq_len, vocab_size]
            aux_loss: 辅助损失（可选）
        """
        batch_size, seq_len, embed_dim = inputs.shape
        
        # 路由权重 [batch_size, num_experts]
        expert_weights = self.router_forward(inputs)
        
        # 专家前向传播
        expert_outputs = []
        for i, expert in enumerate(self.experts):
            expert_output = expert(inputs)  # [batch_size, seq_len, expert_actual_dim]
            # 投影到统一的输出维度
            expert_output = self.expert_output_projections[i](expert_output)
            # 层归一化
            expert_output = self.expert_norms[i](expert_output)
            expert_outputs.append(expert_output)
        
        # 融合专家输出：stack -> [batch_size, seq_len, expert_output_dim, num_experts]
        stacked = paddle.stack(expert_outputs, axis=-1)  # [batch_size, seq_len, expert_output_dim, num_experts]
        
        # 扩展权重 -> [batch_size, 1, 1, num_experts]
        weights = expert_weights.unsqueeze(1).unsqueeze(1)  # [batch_size, 1, 1, num_experts]
        
        # 加权融合 [batch_size, seq_len, expert_output_dim]
        combined = paddle.sum(stacked * weights, axis=-1)  # [batch_size, seq_len, expert_output_dim]
        
        combined = self.combined_norm(combined)  # 融合后添加归一化
        
        # 最终预测
        logits = self.next_token_predictor(combined)  # [batch_size, seq_len, vocab_size]
        
        if return_aux_loss:
            # 计算负载均衡损失（Load Balancing Loss）
            # 鼓励路由网络均匀地使用所有专家
            # aux_loss = num_experts * sum(fraction_i * mean_importance_i)
            # 其中fraction_i是专家i被选择的频率，mean_importance_i是专家i的平均重要性
            aux_loss = self._compute_load_balancing_loss(expert_weights)
            return logits, aux_loss
        
        return logits
    
    def _compute_load_balancing_loss(self, expert_weights):
        """
        计算负载均衡损失（Switch Transformer风格）
        鼓励路由网络均匀地使用所有专家
        
        Args:
            expert_weights: [batch_size, num_experts]
        Returns:
            aux_loss: 标量
        """
        num_experts = expert_weights.shape[1]
        
        # 计算每个专家被选择的平均概率（在所有batch上平均）
        mean_weights = paddle.mean(expert_weights, axis=0)  # [num_experts]
        
        # 计算每个专家被选中的频率（one-hot风格）
        # 使用softmax输出作为重要性权重
        importance = paddle.mean(expert_weights, axis=0)  # [num_experts]
        
        # 计算负载均衡损失：num_experts * sum(mean_weights * importance)
        # 理想情况下，每个专家的mean_weights = 1/num_experts，importance也相等
        aux_loss = num_experts * paddle.sum(mean_weights * importance)
        
        return aux_loss

# Hybrid Model with Routing
class HybridModel(nn.Layer):
    def __init__(self, vocab_size, embed_dim, num_heads, num_layers, ffn_hidden_size, max_seq_len, 
                 transformer_input_len, dropout=0.1):
        super().__init__()
        self.vocab_size = vocab_size
        self.embed_dim = embed_dim
        self.max_seq_len = max_seq_len
        self.transformer_input_len = transformer_input_len
        
        # Shared embedding layer
        self.embedding = nn.Embedding(
            num_embeddings=vocab_size,
            embedding_dim=embed_dim,
            weight_attr=ParamAttr(initializer=TruncatedNormal(std=0.02))
        )
        
        # Experts
        # 2个单层GRU专家
        self.gru_expert1 = GRUExpert(vocab_size, embed_dim, hidden_size=embed_dim, num_layers=1, dropout=dropout)
        self.gru_expert2 = GRUExpert(vocab_size, embed_dim, hidden_size=embed_dim, num_layers=1, dropout=dropout)
        
        # 1个12层Transformer专家
        self.transformer_expert = TransformerLM(
            vocab_size=vocab_size,
            embed_dim=embed_dim,
            num_heads=num_heads,
            num_layers=num_layers,
            ffn_hidden_size=ffn_hidden_size,
            max_seq_len=transformer_input_len,
            dropout=dropout
        )
        
        # 共享权重
        self.gru_expert2.embedding = self.gru_expert1.embedding
        self.transformer_expert.embedding = self.gru_expert1.embedding
        
        # Router - 生成专家权重
        self.router = nn.Linear(
            embed_dim * transformer_input_len, 3,  # 3个专家
            weight_attr=ParamAttr(initializer=TruncatedNormal(std=0.02)),
            bias_attr=ParamAttr(initializer=Constant(0.0))
        )
        # 保存transformer_input_len，供forward方法使用
        self.transformer_input_len = transformer_input_len
        
        # Language model head (共享)
        self.lm_head = nn.Linear(
            embed_dim, vocab_size,
            weight_attr=ParamAttr(initializer=TruncatedNormal(std=0.02)),
            bias_attr=ParamAttr(initializer=Constant(0.0))
        )
        
        # Dropout
        self.dropout = nn.Dropout(dropout)
    
    def forward(self, input_ids, labels=None):
        batch_size, seq_len = input_ids.shape
        
        # 1. 硬路由：选择2个专家
        # 对于GRU专家，使用完整序列
        # 对于Transformer专家，只使用最后transformer_input_len个token
        transformer_input = input_ids[:, -self.transformer_input_len:]
        
        # 软路由：生成专家权重
        # 使用Transformer输入的嵌入作为路由特征
        x_router = self.embedding(transformer_input)
        
        # 确保x_router的长度与router层权重维度匹配
        # 正确获取嵌入维度
        embed_dim = self.embedding.weight.shape[1]
        expected_len = self.router.weight.shape[1] // embed_dim
        current_len = x_router.shape[1]
        
        if current_len != expected_len:
            if current_len > expected_len:
                # 取最后expected_len个token
                x_router = x_router[:, -expected_len:, :]
            else:
                # 复制最后一个token，直到长度达到expected_len
                padding = x_router[:, -1:, :].repeat([1, expected_len - current_len, 1])
                x_router = paddle.concat([x_router, padding], axis=1)
        
        x_router = x_router.reshape([batch_size, -1])  # 展平
        expert_weights = F.softmax(self.router(x_router), axis=-1)
        
        # 3. 专家前向计算
        # GRU专家1
        gru1_out = self.gru_expert1(input_ids)
        
        # GRU专家2
        gru2_out = self.gru_expert2(input_ids)
        
        # Transformer专家 - 只处理最后transformer_input_len个token
        # 先对输入进行嵌入
        transformer_embedded = self.embedding(transformer_input)
        transformer_out = self.transformer_expert(transformer_embedded)
        # 扩展到完整序列长度
        transformer_out_padded = paddle.concat([
            paddle.zeros([batch_size, seq_len - self.transformer_input_len, self.embed_dim]),
            transformer_out
        ], axis=1)
        
        # 4. 混合专家输出
        # 使用所有3个专家的权重（GRU1, GRU2, Transformer）
        # 混合输出：根据路由权重动态融合所有专家
        hybrid_out = (
            expert_weights[:, 0].unsqueeze(1).unsqueeze(2) * gru1_out +
            expert_weights[:, 1].unsqueeze(1).unsqueeze(2) * gru2_out +
            expert_weights[:, 2].unsqueeze(1).unsqueeze(2) * transformer_out_padded
        )
        
        # 5. Language model head
        logits = self.lm_head(hybrid_out)
        
        if labels is not None:
            # Calculate loss
            loss = F.cross_entropy(
                logits.reshape([-1, self.vocab_size]),
                labels.reshape([-1]),
                reduction='mean'
            )
            return logits, loss
        
        return logits

# Model factory function
def create_model(mt_name, vocab_size=None):
    config = get_mt_config(mt_name, vocab_size)
    
    # 根据mt_name选择不同的模型架构
    if mt_name == 't10':
        # 混合GRU+Transformer模型
        # 1. 创建共享嵌入层
        embedding = nn.Embedding(
            num_embeddings=config['vocab_size'],
            embedding_dim=config['embed_dim'],
            weight_attr=ParamAttr(initializer=TruncatedNormal(std=0.02))
        )
        
        # 2. 创建GRU专家
        gru_expert1 = GRUExpert(
            vocab_size=config['vocab_size'],
            embed_dim=config['embed_dim'],
            hidden_size=config['embed_dim'],
            num_layers=1,
            dropout=config['dropout']
        )
        
        gru_expert2 = GRUExpert(
            vocab_size=config['vocab_size'],
            embed_dim=config['embed_dim'],
            hidden_size=config['embed_dim'],
            num_layers=1,
            dropout=config['dropout']
        )
        
        # 3. 创建Transformer专家
        transformer_expert = TransformerLM(
            vocab_size=config['vocab_size'],
            embed_dim=config['embed_dim'],
            num_heads=config['num_heads'],
            num_layers=config['num_layers'],
            ffn_hidden_size=config['ffn_hidden_size'],
            max_seq_len=config['all_maxlen'],  # 使用all_maxlen支持更大的推理长度
            dropout=config['dropout']
        )
        
        # 4. 共享权重
        gru_expert2.embedding = gru_expert1.embedding
        transformer_expert.embedding = gru_expert1.embedding
        
        # 5. 创建路由器
        router = nn.Linear(
            config['embed_dim'] * config['max_seq_len'], 3,  # 3个专家
            weight_attr=ParamAttr(initializer=TruncatedNormal(std=0.02)),
            bias_attr=ParamAttr(initializer=Constant(0.0))
        )
        
        # 6. 创建语言模型头
        lm_head = nn.Linear(
            config['embed_dim'], config['vocab_size'],
            weight_attr=ParamAttr(initializer=TruncatedNormal(std=0.02)),
            bias_attr=ParamAttr(initializer=Constant(0.0))
        )
        
        # 7. 组装混合模型
        model = HybridModel(
            vocab_size=config['vocab_size'],
            embed_dim=config['embed_dim'],
            num_heads=config['num_heads'],
            num_layers=config['num_layers'],
            ffn_hidden_size=config['ffn_hidden_size'],
            max_seq_len=config['all_maxlen'],  # 使用all_maxlen支持更大的推理长度
            transformer_input_len=config['max_seq_len'],
            dropout=config['dropout']
        )
        
        # 8. 替换模型组件，实现层复用
        model.gru_expert1 = gru_expert1
        model.gru_expert2 = gru_expert2
        model.transformer_expert = transformer_expert
        model.router = router
        model.lm_head = lm_head
        
    elif mt_name == 't7.5_paddle' or mt_name == 't7.5_paddle_novel' or \
        mt_name == 't7.5_paddle_small' or mt_name == 't7.5_paddle_small_instruct' or \
        mt_name == 't7.5_paddle_small_novel' or mt_name == 't7.5_paddle_small_instruct_thinking' or \
        mt_name == 't7.5_paddle_small_instruct_poem' or mt_name == 't7.5_paddle_small_instruct_translator' or \
        mt_name == 't7.5_paddle_small_instruct_pro':
        # t7.5_paddle 混合专家模型
        # 1. 创建传统Embedding层（不使用切分式嵌入）
        embedding_layer = nn.Embedding(
            num_embeddings=config['vocab_size'],
            embedding_dim=config['embed_dim'],
        )
        
        # 2. 创建专家网络
        # 从配置中获取RWKV专家参数
        num_experts = config.get('num_experts', 3)
        rwkv_units = config.get('rwkv_units', [768, 512, 256])  # 浅层大宽度，深层小宽度
        rwkv_layers = config.get('rwkv_layers', [2, 4, 8])  # 层数
        
        # 创建RWKV专家列表
        experts = []
        for i in range(num_experts):
            units = rwkv_units[i] if i < len(rwkv_units) else 512
            n_layers = rwkv_layers[i] if i < len(rwkv_layers) else 4
            
            expert = RWKVModel(
                vocab_size=config['vocab_size'],
                embedding_dim=config['embed_dim'],
                window=config['max_seq_len'],
                units=units,
                n=n_layers,
                tst=False
            )
            experts.append(expert)
            print(f"  专家{i+1}: {n_layers}层, {units}维")
        
        # 3. 创建混合专家模型
        moe_model = MoEModel_t7(
            experts=experts,
            vocab_size=config['vocab_size'],
            embed_dim=config['embed_dim'],
            num_experts=len(experts),
            router_units=config['router_units'],
            expert_output_dim=config['rwkv_units'][-1],  # 使用最后一个专家的单元数作为统一输出维度（最小的）
            tst=config.get('train_temper_mode', False)  # 使用get方法，如果不存在则默认为False
        )
        
        # 4. 组装完整模型
        class T75PaddleModel(nn.Layer):
            def __init__(self, embedding_layer, moe_model, max_seq_len, aux_loss_weight=0.01):
                super(T75PaddleModel, self).__init__()
                self.embedding_layer = embedding_layer
                self.moe_model = moe_model
                self.max_seq_len = max_seq_len
                self.aux_loss_weight = aux_loss_weight  # 辅助损失的权重
            
            def forward(self, input_ids, labels=None):
                # 增强嵌入层
                x = self.embedding_layer(input_ids)
                # 混合专家模型
                if labels is not None:
                    # 训练时返回辅助损失
                    logits, aux_loss = self.moe_model(x, return_aux_loss=True)
                else:
                    logits = self.moe_model(x, return_aux_loss=False)
                
                if labels is not None:
                    # 确保logits和labels的长度匹配
                    # 专家网络可能截断了序列（只保留最后window个token）
                    # 因此labels也需要相应截断
                    if labels.shape[1] > logits.shape[1]:
                        # labels比logits长，截断labels的前面部分
                        start_idx = labels.shape[1] - logits.shape[1]
                        labels = labels[:, start_idx:]
                    elif logits.shape[1] > labels.shape[1]:
                        # logits比labels长（不应该发生），截断logits
                        logits = logits[:, :labels.shape[1], :]
                    
                    # 使用与train_api_bf.py一致的损失计算方式
                    # tf.keras.losses.sparse_categorical_crossentropy(labels, logits, from_logits=True)
                    # 等价于 paddle.nn.functional.cross_entropy(logits, labels)
                    loss = F.cross_entropy(
                        logits.reshape([-1, logits.shape[-1]]),
                        labels.reshape([-1]),
                        reduction='mean'  # 直接使用mean，与TF一致
                    )
                    
                    # 添加辅助损失（负载均衡损失）
                    total_loss = loss + self.aux_loss_weight * aux_loss
                    
                    return logits, total_loss
                
                return logits
        
        model = T75PaddleModel(
            embedding_layer=embedding_layer,
            moe_model=moe_model,
            max_seq_len=config['max_seq_len']
        )
        
    elif mt_name == 't7.5_gru_paddle':
        # t7.5_gru_paddle: 3个单层GRU专家模型，使用传统embedding
        # 1. 创建传统Embedding层（不使用切分式嵌入）
        embedding_layer = nn.Embedding(
            num_embeddings=config['vocab_size'],
            embedding_dim=config['embed_dim'],
            weight_attr=ParamAttr(initializer=TruncatedNormal(std=0.02))
        )
        
        # 2. 创建3个单层GRU专家网络
        experts = []
        for i in range(3):
            expert_gru = CLModel_t6(
                vocab_size=config['vocab_size'],
                embedding_dim=config['embed_dim'],
                window=config['max_seq_len'],
                units=config['rnn_units'],
                n=1,  # 单层GRU
                tst=config['train_temper_mode'],
                embed_q=0.5
            )
            experts.append(expert_gru)
        
        # 3. 创建混合专家模型
        moe_model = MoEModel_t7(
            experts=experts,
            vocab_size=config['vocab_size'],
            embed_dim=config['embed_dim'],
            num_experts=len(experts),
            router_units=config['router_units'],
            expert_output_dim=config['rnn_units'],  # GRU专家输出rnn_units维度
            tst=config['train_temper_mode']
        )
        
        # 4. 组装完整模型
        class T75GRUPaddleModel(nn.Layer):
            def __init__(self, embedding_layer, moe_model, max_seq_len):
                super(T75GRUPaddleModel, self).__init__()
                self.embedding_layer = embedding_layer
                self.moe_model = moe_model
                self.max_seq_len = max_seq_len
            
            def forward(self, input_ids, labels=None):
                # 传统Embedding层
                x = self.embedding_layer(input_ids)
                # 混合专家模型
                logits = self.moe_model(x)
                
                if labels is not None:
                    # 确保logits和labels的长度匹配
                    # logits的seq_len应该与labels相同，都是max_seq_len-1
                    if logits.shape[1] > labels.shape[1]:
                        logits = logits[:, :labels.shape[1], :]
                    # Calculate loss
                    loss = F.cross_entropy(
                        logits.reshape([-1, logits.shape[-1]]),
                        labels.reshape([-1]),
                        reduction='mean'
                    )
                    return logits, loss
                
                return logits
        
        model = T75GRUPaddleModel(
            embedding_layer=embedding_layer,
            moe_model=moe_model,
            max_seq_len=config['max_seq_len']
        )
        
    elif mt_name == 'test_gru':
        # 纯GRU模型
        class PureGRUModel(nn.Layer):
            def __init__(self, vocab_size, embed_dim, rnn_units, max_seq_len, dropout=0.1):
                super(PureGRUModel, self).__init__()
                self.vocab_size = vocab_size
                self.embed_dim = embed_dim
                self.rnn_units = rnn_units
                self.max_seq_len = max_seq_len
                
                # 嵌入层
                self.embedding = nn.Embedding(
                    num_embeddings=vocab_size,
                    embedding_dim=embed_dim,
                    weight_attr=ParamAttr(initializer=TruncatedNormal(std=0.02))
                )
                
                # GRU层
                self.gru = nn.GRU(
                    input_size=embed_dim,
                    hidden_size=rnn_units,
                    num_layers=1,
                    direction='forward',
                    dropout=dropout if 1 > 1 else 0
                )
                
                # 输出层
                self.lm_head = nn.Linear(
                    rnn_units,
                    vocab_size,
                    weight_attr=ParamAttr(initializer=TruncatedNormal(std=0.02)),
                    bias_attr=ParamAttr(initializer=Constant(0.0))
                )
                
                # Dropout
                self.dropout = nn.Dropout(dropout)
            
            def forward(self, input_ids, labels=None):
                batch_size, seq_len = input_ids.shape
                
                # 嵌入层
                x = self.embedding(input_ids)  # [batch_size, seq_len, embed_dim]
                x = self.dropout(x)
                
                # GRU层
                # Paddle GRU expects [seq_len, batch_size, embed_dim]
                x = x.transpose([1, 0, 2])  # [seq_len, batch_size, embed_dim]
                x, _ = self.gru(x)
                # Convert back to [batch_size, seq_len, hidden_size]
                x = x.transpose([1, 0, 2])  # [batch_size, seq_len, rnn_units]
                x = self.dropout(x)
                
                # 输出层
                logits = self.lm_head(x)  # [batch_size, seq_len, vocab_size]
                
                if labels is not None:
                    # Calculate loss
                    loss = F.cross_entropy(
                        logits.reshape([-1, self.vocab_size]),
                        labels.reshape([-1]),
                        reduction='mean'
                    )
                    return logits, loss
                
                return logits
        
        # 创建纯GRU模型
        model = PureGRUModel(
            vocab_size=config['vocab_size'],
            embed_dim=config['embed_dim'],
            rnn_units=config['rnn_units'],  # 使用配置中的rnn_units=1024
            max_seq_len=config['max_seq_len'],
            dropout=config['dropout']
        )
        
    elif mt_name == 't7.6_test':
        # t7.6_test: RH-LSTM (Residual Highway LSTM) 混合专家模型
        print(f"创建RH-LSTM混合专家模型: {mt_name}")
        
        # 1. 创建增强嵌入层
        embedding_layer = TokenAndPositionEmbedding_41_01_t7_5(
            vocab_size=config['vocab_size'],
            embed_dim=config['embed_dim'],
            maxlen=config['max_seq_len']
        )
        
        # 2. 创建RH-LSTM专家网络
        num_experts = config.get('num_experts', 2)
        rhlstm_units = config.get('rhlstm_units', [512, 768])
        rhlstm_layers = config.get('rhlstm_layers', [2, 1])
        use_layer_norm = config.get('use_layer_norm', False)
        
        experts = []
        for i in range(num_experts):
            units = rhlstm_units[i] if i < len(rhlstm_units) else 512
            n_layers = rhlstm_layers[i] if i < len(rhlstm_layers) else 2
            
            expert = RHLSTMModel(
                vocab_size=config['vocab_size'],
                embedding_dim=config['embed_dim'],
                window=config['max_seq_len'],
                units=units,
                n=n_layers,
                use_layer_norm=use_layer_norm,
                tst=False
            )
            experts.append(expert)
            ln_status = "启用LN" if (use_layer_norm or n_layers > 32) else "无LN"
            print(f"  RH-LSTM专家{i+1}: {n_layers}层, {units}维, {ln_status}")
        
        # 3. 创建混合专家模型
        moe_model = MoEModel_t7(
            experts=experts,
            vocab_size=config['vocab_size'],
            embed_dim=config['embed_dim'],
            num_experts=len(experts),
            router_units=config['router_units'],
            expert_output_dim=rhlstm_units[-1],
            tst=False
        )
        
        # 4. 组装完整模型
        class T76TestModel(nn.Layer):
            def __init__(self, embedding_layer, moe_model, max_seq_len, aux_loss_weight=0.01):
                super(T76TestModel, self).__init__()
                self.embedding_layer = embedding_layer
                self.moe_model = moe_model
                self.max_seq_len = max_seq_len
                self.aux_loss_weight = aux_loss_weight
            
            def forward(self, input_ids, labels=None):
                x = self.embedding_layer(input_ids)
                
                if labels is not None:
                    logits, aux_loss = self.moe_model(x, return_aux_loss=True)
                else:
                    logits = self.moe_model(x, return_aux_loss=False)
                
                if labels is not None:
                    if labels.shape[1] > logits.shape[1]:
                        start_idx = labels.shape[1] - logits.shape[1]
                        labels = labels[:, start_idx:]
                    elif logits.shape[1] > labels.shape[1]:
                        logits = logits[:, :labels.shape[1], :]
                    
                    # 使用与train_api_bf.py一致的损失计算方式
                    # tf.keras.losses.sparse_categorical_crossentropy(labels, logits, from_logits=True)
                    # 等价于 paddle.nn.functional.cross_entropy(logits, labels)
                    loss = F.cross_entropy(
                        logits.reshape([-1, logits.shape[-1]]),
                        labels.reshape([-1]),
                        reduction='mean'  # 直接使用mean，与TF一致
                    )
                    total_loss = loss + self.aux_loss_weight * aux_loss
                    
                    return logits, total_loss
                
                return logits
        
        model = T76TestModel(
            embedding_layer=embedding_layer,
            moe_model=moe_model,
            max_seq_len=config['max_seq_len']
        )
        
    elif mt_name == 't7.6_rwkv':
        # t7.6_rwkv: RWKV 混合专家模型
        print(f"创建RWKV混合专家模型: {mt_name}")
        
        # 1. 创建增强嵌入层
        embedding_layer = TokenAndPositionEmbedding_41_01_t7_5(
            vocab_size=config['vocab_size'],
            embed_dim=config['embed_dim'],
            maxlen=config['max_seq_len']
        )
        
        # 2. 创建RWKV专家网络
        num_experts = config.get('num_experts', 2)
        rwkv_units = config.get('rwkv_units', [512, 768])
        rwkv_layers = config.get('rwkv_layers', [2, 1])
        
        experts = []
        for i in range(num_experts):
            units = rwkv_units[i] if i < len(rwkv_units) else 512
            n_layers = rwkv_layers[i] if i < len(rwkv_layers) else 2
            
            expert = RWKVModel(
                vocab_size=config['vocab_size'],
                embedding_dim=config['embed_dim'],
                window=config['max_seq_len'],
                units=units,
                n=n_layers,
                tst=False
            )
            experts.append(expert)
            print(f"  RWKV专家{i+1}: {n_layers}层, {units}维")
        
        # 3. 创建混合专家模型
        moe_model = MoEModel_t7(
            experts=experts,
            vocab_size=config['vocab_size'],
            embed_dim=config['embed_dim'],
            num_experts=len(experts),
            router_units=config['router_units'],
            expert_output_dim=rwkv_units[-1],
            tst=False
        )
        
        # 4. 组装完整模型
        class T76RWKVModel(nn.Layer):
            def __init__(self, embedding_layer, moe_model, max_seq_len, aux_loss_weight=0.01):
                super(T76RWKVModel, self).__init__()
                self.embedding_layer = embedding_layer
                self.moe_model = moe_model
                self.max_seq_len = max_seq_len
                self.aux_loss_weight = aux_loss_weight
            
            def forward(self, input_ids, labels=None):
                x = self.embedding_layer(input_ids)
                
                if labels is not None:
                    logits, aux_loss = self.moe_model(x, return_aux_loss=True)
                else:
                    logits = self.moe_model(x, return_aux_loss=False)
                
                if labels is not None:
                    if labels.shape[1] > logits.shape[1]:
                        start_idx = labels.shape[1] - logits.shape[1]
                        labels = labels[:, start_idx:]
                    elif logits.shape[1] > labels.shape[1]:
                        logits = logits[:, :labels.shape[1], :]
                    
                    # 使用与train_api_bf.py一致的损失计算方式
                    # tf.keras.losses.sparse_categorical_crossentropy(labels, logits, from_logits=True)
                    # 等价于 paddle.nn.functional.cross_entropy(logits, labels)
                    loss = F.cross_entropy(
                        logits.reshape([-1, logits.shape[-1]]),
                        labels.reshape([-1]),
                        reduction='mean'  # 直接使用mean，与TF一致
                    )
                    total_loss = loss + self.aux_loss_weight * aux_loss
                    
                    return logits, total_loss
                
                return logits
        
        model = T76RWKVModel(
            embedding_layer=embedding_layer,
            moe_model=moe_model,
            max_seq_len=config['max_seq_len']
        )
        
    # 可以在这里添加更多模型类型
    # elif mt_name == 't20':
    #     # 另一种模型架构
    #     pass
    else:
        raise ValueError(f"Unsupported model type: {mt_name}")
    
    return model, config

# 模型参数量统计函数
def get_model_summary(model):
    total_params = 0
    param_details = {}
    
    for name, param in model.named_parameters():
        param_count = param.numel()
        total_params += param_count
        
        # 按层统计
        layer_name = name.split('.')[0]
        if layer_name not in param_details:
            param_details[layer_name] = 0
        param_details[layer_name] += param_count
    
    summary = {
        'total_params': total_params,
        'total_params_1e8': total_params / 1e8,
        'param_details': param_details
    }
    
    return summary
