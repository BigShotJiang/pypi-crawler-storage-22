# -*- coding: utf-8 -*-
# test.py - 加载模型续写文本

import os

# 尝试导入 PaddlePaddle（T7.5 及以上模型需要）
try:
    import paddle
    PADDLE_AVAILABLE = True
except Exception as e:
    PADDLE_AVAILABLE = False
    print(f"[警告] PaddlePaddle 导入失败: {e}")
    print("[提示] T7.5 及以上模型使用 PaddlePaddle，此报错无需关注")
    print("[提示] 如果您使用 T7 及以下模型（TensorFlow），请忽略此警告")

# 尝试导入 TensorFlow（T7 及以下模型需要）
try:
    import tensorflow as tf
    TF_AVAILABLE = True
except Exception as e:
    TF_AVAILABLE = False
    print(f"[警告] TensorFlow 导入失败: {e}")
    print("[提示] T7 及以下模型使用 TensorFlow，此报错无需关注")
    print("[提示] 如果您使用 T7.5 及以上模型（PaddlePaddle），请忽略此警告")

import json
import time
from .models import create_model
from .tokenizer import WordTokenizer, CharTokenizer, load_tokenizer

# 配置
# 可选模型: 't7.6_test' (RH-LSTM), 't7.6_rwkv' (RWKV)
MT_NAME = 't7.5_paddle_small_instruct_pro'  # 默认使用RH-LSTM模型
MODEL_DIR = r'D:\xiaothink\models\ckpt_test_t7.5_paddle_small_instruct_pro'
CHECKPOINT_DIR = os.path.join(MODEL_DIR, 'checkpoints')
# 默认使用词语tokenizer
USE_WORD_TOKENIZER = True

# 空格替换开关：将空格替换为[s]以避免分词器丢失空格
# True: 推理时将用户输入的空格替换为[s]，模型输出后将[s]还原为空格
# False: 保持原始空格处理
REPLACE_SPACE = True

# 空格替换标记
SPACE_TOKEN = "[s]"        # 空格替换标记

def replace_spaces_to_token(text):
    """
    将文本中的空格替换为[s]标记（用于输入处理）
    
    Args:
        text: 原始文本
    
    Returns:
        替换后的文本
    """
    if not REPLACE_SPACE:
        return text
    return text.replace(' ', SPACE_TOKEN)


def replace_token_to_spaces(text):
    """
    将文本中的[s]标记还原为空格（用于输出处理）
    
    Args:
        text: 包含[s]标记的文本
    
    Returns:
        还原后的文本
    """
    if not REPLACE_SPACE:
        return text
    return text.replace(SPACE_TOKEN, ' ')


class TextGenerator:
    def __init__(self, checkpoint_path=None, MT=None):
        self.checkpoint_path = checkpoint_path
        self.model = None
        self.tokenizer = None
        self.config = None
        self.MT = MT
        
    def load_model(self):
        """加载模型和tokenizer"""
        print("正在加载模型...")
        
        # 设置推理设备
        if PADDLE_AVAILABLE:
            try:
                paddle.set_device('gpu:0')
                print("[设备配置] 使用GPU推理")
            except:
                paddle.set_device('cpu')
                print("[设备配置] 使用CPU推理")
        
        # 加载tokenizer
        tokenizer_path = os.path.join(self.checkpoint_path, 'tokenizer.json')
        if os.path.exists(tokenizer_path):
            self.tokenizer = load_tokenizer(tokenizer_path)
            print(f"Tokenizer加载成功，词汇表大小: {self.tokenizer.vocab_size}")
        else:
            raise FileNotFoundError(f"未找到tokenizer文件: {tokenizer_path}")
        
        # 加载模型
        from .models import create_model
        # 使用tokenizer的vocab_size创建模型
        self.model, self.config = create_model(self.MT, self.tokenizer.vocab_size)
        
        # 加载权重
        if 0:#self.checkpoint_path:
            print(f"尝试加载检查点: {self.checkpoint_path}")
            checkpoint = paddle.load(self.checkpoint_path)
            self.model.set_state_dict(checkpoint)
            print(f"已加载检查点: {self.checkpoint_path}")
            print(f"权重文件名: {os.path.basename(self.checkpoint_path)}")
        else:
            # 尝试加载最终模型
            final_model_path = os.path.join(self.checkpoint_path, 'final_model.pdparams')
            if os.path.exists(final_model_path):
                checkpoint = paddle.load(final_model_path)
                self.model.set_state_dict(checkpoint)
                print(f"已加载最终模型: {final_model_path}")
                print(f"权重文件名: final_model.pdparams")
            else:
                # 尝试加载最新的检查点
                checkpoints = sorted([f for f in os.listdir(os.path.join(self.checkpoint_path, 'checkpoints')) if f.startswith('checkpoint_')], 
                                    key=lambda x: int(x.split('_')[1].split('.')[0]))
                if checkpoints:
                    latest_checkpoint = os.path.join(self.checkpoint_path, 'checkpoints', checkpoints[-1])
                    checkpoint = paddle.load(latest_checkpoint)
                    self.model.set_state_dict(checkpoint)
                    print(f"已加载最新检查点: {latest_checkpoint}")
                    print(f"权重文件名: {os.path.basename(latest_checkpoint)}")
                else:
                    raise FileNotFoundError("未找到任何模型文件")
        
        # 确保模型的vocab_size与tokenizer一致
        self.config['vocab_size'] = self.tokenizer.vocab_size
        print(f"模型vocab_size设置为: {self.config['vocab_size']}")
        
        # 设置为评估模式
        self.model.eval()
        print("模型加载完成！")
    
    def generate_text(self, prompt, max_length=200, temperature=0.8, top_p=0.9, repetition_penalty=1.0,
                       stop_conditions=None, banned_tokens=None, ontime_func=None):
        """
        续写文本
        Args:
            prompt: 输入的提示文本
            max_length: 生成的最大长度
            temperature: 采样温度，控制生成的多样性
            top_p: 累积概率阈值，控制采样范围
            repetition_penalty: 重复惩罚，防止重复生成
            stop_conditions: 停止条件列表，遇到这些字符串时停止生成
            banned_tokens: 禁止生成的token ID列表，这些token的概率会被设为-inf
            ontime_func: 回调函数，每生成一个token调用一次，参数为(token_id, generated_text)
        Returns:
            生成的文本
        """
        if self.model is None or self.tokenizer is None:
            self.load_model()
        
        # 处理输入：将空格替换为[s]标记
        original_prompt = prompt
        prompt = replace_spaces_to_token(prompt)
        if REPLACE_SPACE and ' ' in original_prompt:
            print(f"[空格替换] 输入中的空格已替换为{SPACE_TOKEN}")
            print(f"[替换后] {prompt[:100]}...")
        
        # 处理禁用词：将字符转换为token ID
        default_banned_chars = list(set(list(' ')))
        banned_token_ids = []
        
        # 添加默认禁用字符的token ID
        for char in default_banned_chars:
            if hasattr(self.tokenizer, 'char2id') and char in self.tokenizer.char2id:
                token_id = self.tokenizer.char2id[char]
                if token_id not in banned_token_ids:
                    banned_token_ids.append(token_id)
            elif hasattr(self.tokenizer, 'word2id') and char in self.tokenizer.word2id:
                token_id = self.tokenizer.word2id[char]
                if token_id not in banned_token_ids:
                    banned_token_ids.append(token_id)
        
        # 添加用户传入的禁用token ID
        if banned_tokens:
            for token_id in banned_tokens:
                if token_id not in banned_token_ids:
                    banned_token_ids.append(token_id)
        
        # 添加'▩'字符的token ID
        if hasattr(self.tokenizer, 'char2id') and '▩' in self.tokenizer.char2id:
            pad_token_id = self.tokenizer.char2id['▩']
            if pad_token_id not in banned_token_ids:
                banned_token_ids.append(pad_token_id)
        elif hasattr(self.tokenizer, 'word2id') and '▩' in self.tokenizer.word2id:
            pad_token_id = self.tokenizer.word2id['▩']
            if pad_token_id not in banned_token_ids:
                banned_token_ids.append(pad_token_id)
        
        print(f"\n输入提示: {prompt}")
        print(f"生成参数: max_length={max_length}, temperature={temperature}, top_p={top_p}, repetition_penalty={repetition_penalty}")
        
        start_time = time.time()
        
        # 编码提示文本
        input_ids = self.tokenizer.encode(prompt)
        
        # 获取模型的vocab_size，确保id不超出范围
        model_vocab_size = self.config.get('vocab_size', self.tokenizer.vocab_size)
        
        # 检查并替换超出模型词汇表范围的id
        original_input_ids = input_ids.copy()
        input_ids = []
        for i, id in enumerate(original_input_ids):
            if id >= model_vocab_size:
                print(f"\033[91m警告: 输入token ID {id} 超出模型词汇表范围 (0-{model_vocab_size-1})，已替换为 0\033[0m")
                input_ids.append(0)
            else:
                input_ids.append(id)
        
        # 在前端使用空格作为padding（如果需要）
        # 注意：这里不做长度限制，因为生成过程会动态处理
        
        input_ids = paddle.to_tensor([input_ids], dtype='int64')
        
        # 生成文本
        generated = list(input_ids.numpy()[0])
        generated_out = []
        #print(generated)
        # 获取模型的max_seq_len
        model_max_seq_len = self.config.get('max_seq_len', 256)
        
        # 使用no_grad上下文加速推理
        with paddle.no_grad():
            for _ in range(max_length):
                # 获取当前输入
                #print(generated)
                # 确保所有id都在有效范围内
                generated = [min(id, model_vocab_size - 1) for id in generated]
                
                # RWKV支持任意长度序列，但为了内存效率，仍然限制最大长度
                # 但可以将限制放宽到更大的值（如4096）
                max_rwkv_len = 4096  # RWKV可以处理更长的序列
                if len(generated) > max_rwkv_len:
                    generated = generated[-max_rwkv_len:]
                
                current_input = paddle.to_tensor([generated], dtype='int64')
                
                # 前向传播
                logits = self.model(current_input)
                #print(logits)
                # 获取最后一个token的logits
                next_token_logits = logits[0, -1, :]
                # 应用重复惩罚
                if repetition_penalty > 1.0:
                    for token in set(generated):
                        # 确保token在有效范围内
                        if token < model_vocab_size:
                            if next_token_logits[token] > 0:
                                next_token_logits[token] /= repetition_penalty
                            else:
                                next_token_logits[token] *= repetition_penalty
                
                # 应用禁止token（pass逻辑）：将禁止token的概率设为-inf
                # 包括默认禁用字符和用户传入的禁用token
                if banned_token_ids:
                    for banned_token in banned_token_ids:
                        if banned_token < model_vocab_size:
                            next_token_logits[banned_token] = -float('inf')
                
                # 应用温度缩放
                next_token_logits = next_token_logits / temperature
                
                # 应用top_p采样
                if top_p < 1.0:
                    # 按概率从高到低排序
                    sorted_indices = paddle.argsort(next_token_logits, descending=True)
                    sorted_logits = paddle.index_select(next_token_logits, sorted_indices, axis=-1)
                    # 计算累积概率
                    cumulative_probs = paddle.cumsum(paddle.nn.functional.softmax(sorted_logits, axis=-1), axis=-1)
                    # 找到累积概率大于top_p的位置
                    sorted_indices_to_remove = cumulative_probs > top_p
                    # 确保至少保留一个token
                    sorted_indices_to_remove[0] = False
                    # 创建掩码
                    indices_to_remove = paddle.zeros_like(next_token_logits, dtype='bool')
                    indices_to_remove[sorted_indices] = sorted_indices_to_remove
                    # 将需要移除的token的概率设置为很小的值
                    next_token_logits = next_token_logits.masked_fill(indices_to_remove, -float('inf'))
                
                # 采样
                next_token = paddle.multinomial(paddle.nn.functional.softmax(next_token_logits, axis=-1), num_samples=1).item()
                
                # 确保生成的token不超出模型词汇表范围
                if next_token >= model_vocab_size:
                    print(f"\033[91m警告: 生成的token ID {next_token} 超出模型词汇表范围 (0-{model_vocab_size-1})，已替换为 0\033[0m")
                    next_token = 0
                else:
                    next_token = min(next_token, model_vocab_size - 1)
                
                # 添加到生成结果
                generated.append(next_token)
                generated_out.append(next_token)
                
                # 实时解码当前生成的文本
                current_text = self.tokenizer.decode(generated_out)
                
                # 检查停止条件
                if stop_conditions:
                    should_stop = False
                    for stop_str in stop_conditions:
                        if stop_str in current_text:
                            # 找到停止位置，截断文本
                            stop_pos = current_text.find(stop_str)
                            current_text = current_text[:stop_pos]
                            should_stop = True
                            break
                    if should_stop:
                        # 重新编码截断后的文本
                        generated_out = self.tokenizer.encode(current_text)
                        break
                
                # 调用ontime回调函数
                if ontime_func:
                    try:
                        ontime_func(next_token, current_text)
                    except Exception as e:
                        print(f"ontime回调函数错误: {e}")
            
        # 解码最终生成的文本
        generated_text = self.tokenizer.decode(generated_out)
        
        # 过滤掉结束标记<|E|>（大小写都处理）
        generated_text = generated_text.replace('<|E|>', '').replace('<|e|>', '')
        
        # 处理输出：将[s]标记还原为空格
        generated_text_original = generated_text
        generated_text = replace_token_to_spaces(generated_text)
        if REPLACE_SPACE and SPACE_TOKEN in generated_text_original:
            print(f"[空格还原] 输出中的{SPACE_TOKEN}已还原为空格")
        
        end_time = time.time()
        print(f"生成耗时: {end_time - start_time:.2f}s")
        print(f"生成结果: {generated_text}")
        
        return generated_text

# 命令行界面
if __name__ == "__main__":
    import argparse
    import time
    
    # 多轮对话模式 - 支持input输入
    if 1 and 0:  # 设置为 and 1 启用对话模式，and 0 禁用

        print("=" * 60)
        
        # 获取用户输入的对话内容
        print("\n请输入对话内容（每轮对话输入一句，输入'END'结束）：\n")
        
        # 第一轮对话
        user_input1 = input("顾言: ")
        if not user_input1.strip():
            user_input1 = "好久不见，你还好吗？"
        
        # 爱情小说场景 - 久别重逢
        inp_love = f'''
咖啡馆的门被推开，风铃发出清脆的响声。顾言穿着深灰色大衣，比三年前更加成熟稳重。他的目光在店内扫视，最终定格在林晚星身上。

四目相对的瞬间，时间仿佛静止了。

顾言问道：\\"{user_input1}\\"

林晚星轻声说道：\\"'''.replace('\n','\\n')
        
        # 使用爱情小说版本作为默认
        inp = inp_love
        
        parser = argparse.ArgumentParser(description='使用训练好的模型续写文本')
        parser.add_argument('--prompt', type=str, default=inp, help='输入的提示文本')
        parser.add_argument('--max_length', type=int, default=40, help='生成的最大长度')
        parser.add_argument('--temperature', type=float, default=0.8, help='采样温度')#0.75
        parser.add_argument('--top_p', type=float, default=0.6, help='top_p采样参数')#0.5
        parser.add_argument('--repetition_penalty', type=float, default=1.1, help='重复惩罚参数')#1.1
        parser.add_argument('--checkpoint', type=str, default=MODEL_DIR, help='模型检查点路径')
        
        args = parser.parse_args()
        
        # 创建生成器
        generator = TextGenerator(args.checkpoint, MT_NAME)
        
        # 加载模型
        generator.load_model()
        
        # 第一轮生成
        print(f"\n输入提示: {args.prompt[:100]}...")
        generated_text = generator.generate_text(
            prompt=args.prompt.replace('\n','\\n'),
            max_length=args.max_length,
            temperature=args.temperature,
            top_p=args.top_p,
            repetition_penalty=args.repetition_penalty
        )
        
        # 多轮对话循环
        conversation_history = args.prompt + generated_text
        print(f"\n{'='*60}")
        print("林晚星: " + generated_text.split('"')[0] if '"' in generated_text else generated_text[:50])
        print(f"{'='*60}")
        
        # 继续多轮对话
        round_num = 2
        while True:
            user_input = input(f"\n顾言 (输入'END'结束): ")
            if user_input.strip().upper() == 'END':
                print("\n对话结束。")
                break
            
            if not user_input.strip():
                continue
            
            # 构建新的prompt，包含对话历史
            conversation_history += f'\\"\n\n顾言又说道：\\"{user_input}\\"\n\n林晚星抬起头，轻声回应道：\\"'
            
            print(f"\n[第{round_num}轮对话生成中...]")
            
            # 生成回复
            response = generator.generate_text(
                prompt=conversation_history.replace('\n','\\n'),
                max_length=args.max_length,
                temperature=args.temperature,
                top_p=args.top_p,
                repetition_penalty=args.repetition_penalty
            )
            
            # 提取回复内容
            reply = response.split('"')[0].replace('\\n','\n') if '"' in response else response[:50].replace('\\n','\n')
            
            print(f"\n{'='*60}")
            print(f"林晚星: {reply}")
            print(f"{'='*60}")
            
            # 更新对话历史
            conversation_history += reply
            round_num += 1
    elif 0:
        import argparse
        import time
        
        while True:
            inp1 = input("\n请输入内容（输入'END'结束）：")
            if inp1.strip().upper() == 'END':
                print("\n对话结束。")
                break

            parser = argparse.ArgumentParser(description='使用训练好的模型续写文本')
            parser.add_argument('--prompt', type=str, default=inp1, help='输入的提示文本')
            parser.add_argument('--max_length', type=int, default=1024, help='生成的最大长度')
            parser.add_argument('--temperature', type=float, default=0.44, help='采样温度')
            parser.add_argument('--top_p', type=float, default=0.6, help='top_p采样参数')
            parser.add_argument('--repetition_penalty', type=float, default=1.2, help='重复惩罚参数')
            parser.add_argument('--checkpoint', type=str, default=MODEL_DIR, help='模型检查点路径')
            
            args = parser.parse_args()
            
            # 创建生成器
            generator = TextGenerator(args.checkpoint, MT_NAME)
            
            # 加载模型
            generator.load_model()
            
            # 生成文本
            print(f"\n输入提示: {args.prompt[:100]}...")
            generated_text = generator.generate_text(
                prompt=args.prompt,
                max_length=args.max_length,
                temperature=args.temperature,
                top_p=args.top_p,
                repetition_penalty=args.repetition_penalty
            )
            
            print(f"\n{'='*60}")
            print("生成结果:")
            print(f"{'='*60}")
            print(generated_text)
            print(f"{'='*60}")

    # 只续写小说模式（原来的代码）
    else:  # 设置为 and 1 启用续写模式
        import argparse
        import time
        

        inp1 = '''<|U|>中国的首都是哪里？<|A|>'''
        inp2 = '''<|U|>计算3+2<|A|>'''
        inp3 = '''<|U|>根据给定的文本，生成一个简短的摘要：国内互联网头部玩家营销战役再度升级。借助春节这一时间节点，各玩家已开启对用户入口与心智的全面争夺。<|A|>'''
        inp4 = '''<|U|>上联:风云三尺剑 下联:<|A|>'''
        inp5 = '''咖啡馆的门被推开，风铃发出清脆的响声。顾言穿着深灰色大衣，比三年前更加成熟稳重。他的目光在店内扫视，最终定格在林晚星身上。四目相对的瞬间，时间仿佛'''
        inp6 = '''<|U|>针对健身房的新手，设计一套适合他们的健身器械使用指南，包括安全应用、正确姿势等方面。<|A|>'''
        inp7 = '''<|U|>下列哪个是可再生能源？A. 风能B. 石油C. 太阳能D. 天然气<|A|>答案是：选项'''
        parser = argparse.ArgumentParser(description='使用训练好的模型续写文本')
        parser.add_argument('--prompt', type=str, default=inp7.replace('\n','\\n'), help='输入的提示文本')
        parser.add_argument('--max_length', type=int, default=128, help='生成的最大长度')
        parser.add_argument('--temperature', type=float, default=0.01, help='采样温度')#0.54
        parser.add_argument('--top_p', type=float, default=0.8, help='top_p采样参数')
        parser.add_argument('--repetition_penalty', type=float, default=1., help='重复惩罚参数')
        parser.add_argument('--checkpoint', type=str, default=MODEL_DIR, help='模型检查点路径')
        
        args = parser.parse_args()
        
        # 创建生成器
        generator = TextGenerator(args.checkpoint, MT_NAME)
        
        # 加载模型
        generator.load_model()
        
        # 生成文本
        print(f"\n输入提示: {args.prompt[:100]}...")
        
        # 记录生成开始时间
        gen_start_time = time.time()
        
        generated_text = generator.generate_text(
            prompt=args.prompt,
            max_length=args.max_length,
            temperature=args.temperature,
            top_p=args.top_p,
            repetition_penalty=args.repetition_penalty
        )
        
        # 计算生成速度和token数
        gen_end_time = time.time()
        gen_duration = gen_end_time - gen_start_time
        # 使用tokenizer计算实际token数（jieba分词）
        actual_tokens = len(generator.tokenizer.encode(generated_text))
        tps = actual_tokens / gen_duration if gen_duration > 0 else 0
        
        # 获取CPU信息
        cpu_info = ""
        if _use_cpu:
            try:
                import psutil
                cpu_percent = psutil.cpu_percent(interval=0.1)
                cpu_freq = psutil.cpu_freq()
                if cpu_freq:
                    cpu_info = f", CPU: {cpu_percent:.1f}%, {cpu_freq.current:.0f}MHz"
                else:
                    cpu_info = f", CPU: {cpu_percent:.1f}%"
            except:
                pass
        
        print(f"\n{'='*60}")
        print("生成结果:")
        print(f"{'='*60}")
        print(generated_text.replace('\\n','\n'))
        print(f"{'='*60}")
        print(f"[推理速度] Token数: {actual_tokens}, 耗时: {gen_duration:.2f}s, TPS: {tps:.2f}{cpu_info}")
        '''
        # 保存生成结果
        output_path = os.path.join(MODEL_DIR, f'generated_{int(time.time())}.txt')
        with open(output_path, 'w', encoding='utf-8') as f:
            f.write(f"输入提示: {args.prompt}\n")
            f.write(f"生成参数: max_length={args.max_length}, temperature={args.temperature}, top_p={args.top_p}, repetition_penalty={args.repetition_penalty}\n")
            f.write(f"生成时间: {time.strftime('%Y-%m-%d %H:%M:%S')}\n")
            f.write(f"生成结果: \n{generated_text}\n")
        
        print(f"\n生成结果已保存到: {output_path}")


    # 保存生成结果
    output_path = os.path.join(MODEL_DIR, f'generated_{int(time.time())}.txt')
    with open(output_path, 'w', encoding='utf-8') as f:
        f.write(f"输入提示: {args.prompt}\n")
        f.write(f"生成参数: max_length={args.max_length}, temperature={args.temperature}, top_p={args.top_p}, repetition_penalty={args.repetition_penalty}\n")
        f.write(f"生成时间: {time.strftime('%Y-%m-%d %H:%M:%S')}\n")
        f.write(f"生成结果: \n{generated_text}\n")
    
    print(f"\n生成结果已保存到: {output_path}")
'''