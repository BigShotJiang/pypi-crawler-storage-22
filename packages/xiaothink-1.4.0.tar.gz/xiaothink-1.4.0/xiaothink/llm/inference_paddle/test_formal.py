# -*- coding: utf-8 -*-
# test_formal.py - 基于test.py接口的正式模型封装

import paddle
import os

import time
import re
import tempfile
from .test import TextGenerator
from PIL import Image
import numpy as np



class QianyanModel:
    """
    基于Paddle的千言语义模型封装类
    提供与test_formal.py中QianyanModel相同的接口
    """
    
    def __init__(self, ckpt_dir='', MT='t7.5_paddle_small_instruct_thinking', 
                 vocab=None, use_patch=0, imgzip_model_path=None):
        """
        初始化模型
        
        Args:
            ckpt_dir: 模型检查点目录
            MT: 模型类型
            vocab: 词汇表路径（paddle版本暂不使用）
            use_patch: 是否使用patch（paddle版本暂不使用）
            imgzip_model_path: 图像压缩模型路径（paddle版本暂不使用）
        """
        self.ckpt_dir = ckpt_dir
        self.MT = MT
        self.v_path = vocab
        self.use_patch = use_patch
        self.imgzip_model_path = imgzip_model_path
        self.his = ''
        
        # 创建TextGenerator实例
        self.generator = TextGenerator(checkpoint_path=self.ckpt_dir, MT=self.MT)
        self.model = None
        self.d = None  # 用于兼容test_formal接口
        
    def load(self):
        """加载模型"""
        if self.generator.model is None:
            self.generator.load_model()
        self.model = self.generator
        self.d = self.generator.tokenizer
        return self.model, self.d
    
    def _format_input(self, text, form=1):
        """
        格式化输入文本
        
        Args:
            text: 输入文本
            form: 格式类型 (0=instruction格式, 1=conversation格式, 2=简化格式)
        
        Returns:
            (formatted_input, stop_conditions)
        """
        if form == 0:
            # Instruction格式（旧格式，保留兼容）
            inp = f'{{"instruction": "{text}", "input": "", "output": "'
            stopc = ['"}\r\n', '"}\n\r', '"}\n', '", "input"', '", "i', '"}', '\\nHuman:']
        elif form == 1:
            # Conversation格式（旧格式，保留兼容）
            inp = '{"conversations": [{"role": "user", "content": "' + (text).replace('\n', '\\n') + '"}, {"role": "assistant", "content": "'
            stopc = ['"}]}', '"}']
        elif form == 2:
            # 简化格式（新格式）: <|U|>用户输入<|A|>
            inp = f'<|U|>{text}<|A|>'
            # 停止条件（同时支持大写和小写，因为模型可能输出小写）
            stopc = ['<|E|>', '<|U|>', '<|e|>', '<|u|>']
        elif form == 'pretrain':
            # Pretrain格式
            inp = '{"text": "<s>' + text
            stopc = ['</s>', '"}']
        elif form is None:
            # 无格式
            inp = text
            stopc = []
        else:
            raise ValueError(f'不支持的form类型: {form}')
        
        return inp, stopc
    
    def _update_history(self, text, response, form=1):
        """更新对话历史"""
        if form == 0:
            # Instruction格式历史
            if self.his != '':
                self.his += '\\nHuman: ' + text + '\\nAssistant:'
            else:
                self.his = 'Human: ' + text + '\\nAssistant:'
            self.his += response
        elif form == 1:
            # Conversation格式历史（旧格式）
            if self.his != '':
                self.his += ', {"role": "user", "content": "' + (text).replace('\n', '\\n') + '"}'
            else:
                self.his = '{"role": "user", "content": "' + (text).replace('\n', '\\n') + '"}'
            self.his += ', {"role": "assistant", "content": "' + (response).replace('\n', '\\n') + '"}'
        elif form == 2:
            # 简化格式历史（新格式）- 添加回复和结束标记
            self.his += f'{response}'

        elif form == 'pretrain':
            # Pretrain格式历史
            if self.his != '':
                self.his += text
            else:
                self.his = text
            self.his += response
    
    def _generate_until_stop(self, prompt, max_len, temp, stop_c, 
                             ontime=True, repetition_penalty=1.0, 
                             pass_start_char=None, pass_char=None, top_p=1.0):
        """
        生成文本直到遇到停止条件
        
        Args:
            prompt: 输入提示
            max_len: 最大生成长度
            temp: 温度参数
            stop_c: 停止条件列表
            ontime: 是否实时输出
            repetition_penalty: 重复惩罚
            pass_start_char: 禁止作为开头的字符列表（这些token的概率设为-inf）
            pass_char: 禁止生成的字符列表（这些token的概率设为-inf）
            top_p: top-p采样参数
        
        Returns:
            生成的文本
        """
        if self.generator.model is None:
            self.load()
        
        # 构建禁止token列表（pass逻辑：禁止生成这些token）
        banned_tokens = []
        if pass_start_char:
            for char in pass_start_char:
                if hasattr(self.generator.tokenizer, 'char2id') and char in self.generator.tokenizer.char2id:
                    banned_tokens.append(self.generator.tokenizer.char2id[char])
                elif hasattr(self.generator.tokenizer, 'word2id') and char in self.generator.tokenizer.word2id:
                    banned_tokens.append(self.generator.tokenizer.word2id[char])
        if pass_char:
            for char in pass_char:
                if hasattr(self.generator.tokenizer, 'char2id') and char in self.generator.tokenizer.char2id:
                    banned_tokens.append(self.generator.tokenizer.char2id[char])
                elif hasattr(self.generator.tokenizer, 'word2id') and char in self.generator.tokenizer.word2id:
                    banned_tokens.append(self.generator.tokenizer.word2id[char])
        
        # 构建ontime回调函数
        generated_so_far = ""
        def ontime_callback(token_id, current_text):
            nonlocal generated_so_far
            # 只输出新增的部分
            new_part = current_text[len(generated_so_far):]
            if new_part and ontime:
                print(new_part, end='', flush=True)
            generated_so_far = current_text
        
        # 使用generate_text生成文本，传入停止条件和禁止token
        generated_text = self.generator.generate_text(
            prompt=prompt,
            max_length=max_len,
            temperature=temp,
            top_p=top_p,
            repetition_penalty=repetition_penalty,
            stop_conditions=stop_c,  # 传入停止条件，底层会提前停止
            banned_tokens=banned_tokens,  # 传入禁止token，底层不会生成这些token
            ontime_func=ontime_callback if ontime else None  # 传入实时回调
        )
        
        # 提取生成的部分（去掉prompt）
        result = generated_text[len(prompt):] if generated_text.startswith(prompt) else generated_text
        
        return result
    
    def chat_SingleTurn(self, t, temp=0.8, maxlen=1200, form=1, ontime=True, 
                        loop=True, stop=None):
        """
        单轮对话
        
        Args:
            t: 输入文本
            temp: 温度参数
            maxlen: 最大生成长度
            form: 格式类型
            ontime: 是否实时输出
            loop: 是否使用循环生成（paddle版本暂忽略）
            stop: 额外的停止条件
        
        Returns:
            生成的回复
        """
        # 重置模型状态
        self.his = ''
        
        # 格式化输入
        inp, stopc = self._format_input(t, form)
        
        if stop:
            stopc.append(stop)
        
        # 生成回复
        ret = self._generate_until_stop(
            prompt=inp,
            max_len=maxlen,
            temp=temp,
            stop_c=stopc,
            ontime=ontime
        )
        
        return ret
    
    def add_his(self, q, a, form=1):
        """
        添加历史记录
        
        Args:
            q: 用户问题
            a: 助手回答
            form: 格式类型
        
        Returns:
            添加的回答
        """
        q = q.replace('\n', '\\n')
        a = a.replace('\n', '\\n')
        
        self._update_history(q, a, form)
        return a
    
    def chat(self, text, temp=0.68, max_len=2048, form=1, ontime=True,
             loop=True, pre_text='', repetition_penalty=1.0, 
             pass_start_char=None, pass_char=None, top_p=1.0):
        """
        多轮对话
        
        Args:
            text: 输入文本
            temp: 温度参数
            max_len: 最大生成长度
            form: 格式类型
            ontime: 是否实时输出
            loop: 是否使用循环生成
            pre_text: 前置文本
            repetition_penalty: 重复惩罚
            pass_start_char: 跳过的起始字符列表
            pass_char: 跳过的字符列表
            top_p: top-p采样参数
        
        Returns:
            生成的回复
        """
        text = text.replace('\n', '\\n')
        
        # 更新历史
        if form == 0:
            if self.his != '':
                self.his += '\\nHuman: ' + text + '\\nAssistant:'
            else:
                self.his = 'Human: ' + text + '\\nAssistant:'
            t = self.his
            inp, stopc = self._format_input(t, form)
            stopc.append('\\nHuman:')
        elif form == 1:
            # Conversation格式（旧格式）
            if self.his != '':
                self.his += ', {"role": "user", "content": "' + (text).replace('\n', '\\n') + '"}'
            else:
                self.his = '{"role": "user", "content": "' + (text).replace('\n', '\\n') + '"}'
            inp = '{"conversations": [' + self.his + ', {"role": "assistant", "content": "'
            stopc = ['"}]}', '"}']
        elif form == 2:
            # 简化格式（新格式）- 支持多轮对话
            if self.his != '':
                # 继续多轮对话，添加结束标记后开始新一轮
                self.his += f'<|e|><|u|>{text}<|a|>'
            else:
                # 第一轮对话
                self.his = f'<|u|>{text}<|a|>'
            inp = self.his
            stopc = ['<|e|>', '<|u|>', '<|a|>', '<|E|>', '<|U|>', '<|A|>']
        elif form == 'pretrain':
            if self.his != '':
                self.his += text
            else:
                self.his = text
            inp = '{"text": "<s>' + self.his
            stopc = ['</s>', '"}']
        elif form is None:
            self.his = ''
            inp = text
            stopc = []
        else:
            raise ValueError(f'不支持的form类型: {form}')
        
        # 生成回复
        if ontime:
            print('\n【实时输出】')
        
        ret = pre_text + self._generate_until_stop(
            prompt=inp + pre_text,
            max_len=max_len,
            temp=temp,
            stop_c=stopc,
            ontime=ontime,
            repetition_penalty=repetition_penalty,
            pass_start_char=pass_start_char,
            pass_char=pass_char,
            top_p=top_p
        ).replace('<|e|>','')
        
        # 更新历史
        self._update_history(text, ret.replace('<|e|>',''), form)
        
        return ret
    
    def chat_(self, text, temp=0.68, max_len=2048, form=1, ontime=True,
              loop=True, pre_text='', repetition_penalty=1.2):
        """
        多轮对话（简化版）
        
        Args:
            text: 输入文本
            temp: 温度参数
            max_len: 最大生成长度
            form: 格式类型
            ontime: 是否实时输出
            loop: 是否使用循环生成
            pre_text: 前置文本
            repetition_penalty: 重复惩罚
        
        Returns:
            生成的回复
        """
        text = text.replace('\n', '\\n')
        
        # 更新历史
        if form == 0:
            if self.his != '':
                self.his += '\\nHuman: ' + text + '\\nAssistant:'
            else:
                self.his = 'Human: ' + text + '\\nAssistant:'
            t = self.his
            inp, stopc = self._format_input(t, form)
        elif form == 1:
            # Conversation格式（旧格式）
            if self.his != '':
                self.his += ', {"role": "user", "content": "' + (text).replace('\n', '\\n') + '"}'
            else:
                self.his = '{"role": "user", "content": "' + (text).replace('\n', '\\n') + '"}'
            inp = '{"conversations": [' + self.his + ', {"role": "assistant", "content": "'
            stopc = ['"}]}', '"}']
        elif form == 2:
            # 简化格式（新格式）
            self.his = f'<|u|>{text}<|a|>'
            inp = self.his
            stopc = ['<|e|>', '<|u|>', '<|a|>', '<|E|>', '<|U|>', '<|A|>']
        elif form == 'pretrain':
            if self.his != '':
                self.his += text
            else:
                self.his = text
            inp = '{"text": "<s>' + self.his
            stopc = ['</s>', '"}']
        else:
            raise ValueError(f'不支持的form类型: {form}')
        
        # 生成回复
        if ontime:
            print('\n【实时输出】')
        
        ret = pre_text + self._generate_until_stop(
            prompt=inp + pre_text,
            max_len=max_len,
            temp=temp,
            stop_c=stopc,
            ontime=ontime,
            repetition_penalty=repetition_penalty
        )
        
        # 更新历史
        self._update_history(text, ret, form)
        
        return ret
    
    def clean_his(self):
        """清空对话历史"""
        self.his = ''
    
    def write(self, t, temp=0.85, max_len=150, form=0, ontime=True, onfunc=None):
        """
        自由文本生成
        
        Args:
            t: 输入文本
            temp: 温度参数
            max_len: 最大生成长度
            form: 格式类型
            ontime: 是否实时输出
            onfunc: 自定义输出函数
        
        Returns:
            生成的文本
        """
        if self.generator.model is None:
            self.load()
        
        # 生成文本
        generated_text = self.generator.generate_text(
            prompt=t,
            max_length=max_len,
            temperature=temp,
            top_p=1.0,
            repetition_penalty=1.0
        )
        
        # 提取生成的部分（去掉输入）
        ret = generated_text[len(t):] if generated_text.startswith(t) else generated_text
        
        # 应用自定义输出函数
        if ontime and onfunc:
            onfunc(ret)
        
        return ret
    
    def img2ms(self, img_path, temp=0.28, top_p=1.0, pre_text='', 
               pass_start_char=None, ontime=False, max_len=128):
        """
        图片转描述（paddle版本暂不支持图片输入，使用占位符）
        
        Args:
            img_path: 图片路径
            temp: 温度参数
            top_p: top-p采样参数
            pre_text: 前置文本
            pass_start_char: 跳过的起始字符列表
            ontime: 是否实时输出
            max_len: 最大生成长度
        
        Returns:
            生成的图片描述
        """
        self.clean_his()
        prompt = f'<img>{img_path}</img>请你描述图片内容'
        ret = self.chat(prompt, repetition_penalty=1.0, temp=temp, top_p=top_p, 
                       pre_text=pre_text, pass_start_char=pass_start_char, 
                       ontime=ontime, max_len=max_len)
        self.clean_his()
        return ret
    
    def chat_vision(self, text, temp=0.68, max_len=2048, form=1, ontime=True,
                    loop=True, pre_text='', repetition_penalty=1.2, 
                    pass_start_char=None, max_shape=224):
        """
        视觉对话（paddle版本暂不支持图片输入）
        
        Args:
            text: 输入文本
            temp: 温度参数
            max_len: 最大生成长度
            form: 格式类型
            ontime: 是否实时输出
            loop: 是否使用循环生成
            pre_text: 前置文本
            repetition_penalty: 重复惩罚
            pass_start_char: 跳过的起始字符列表
            max_shape: 最大图片尺寸
        
        Returns:
            生成的回复
        """
        # paddle版本暂不支持图片输入，直接调用chat
        return self.chat(text, temp=temp, max_len=max_len, form=form, 
                        ontime=ontime, loop=loop, pre_text=pre_text,
                        repetition_penalty=repetition_penalty, 
                        pass_start_char=pass_start_char)
    
    def img2ms_vision(self, img_path, max_shape=256, temp=0.24, 
                      pre_text='', pass_start_char=None, ontime=True):
        """
        视觉图片描述（paddle版本暂不支持图片输入）
        
        Args:
            img_path: 图片路径
            max_shape: 最大图片尺寸
            temp: 温度参数
            pre_text: 前置文本
            pass_start_char: 跳过的起始字符列表
            ontime: 是否实时输出
        
        Returns:
            生成的图片描述
        """
        self.clean_his()
        ret = self.chat_vision(f'<img>{img_path}</img>请你描述图片内容', 
                              max_shape=max_shape, temp=temp, pre_text=pre_text, 
                              pass_start_char=pass_start_char, ontime=ontime)
        self.clean_his()
        return ret


# 图片处理相关函数（paddle版本保留接口但功能受限）
def replace_img(text, v_path=None, use_patch=1, imgzip_model_path=None):
    """替换图片标签（paddle版本暂不支持）"""
    # 检查文本中是否包含完整的<img>标签
    if '<img>' not in text or '</img>' not in text:
        return text
    
    # paddle版本暂不支持图片处理，直接返回原文本
    # 或者可以添加警告信息
    print("警告: paddle版本暂不支持图片处理功能")
    return text


def replace_vec(text, v_path=None, use_patch=1, imgzip_model_path=None):
    """替换向量标签（paddle版本暂不支持）"""
    if '<img>' not in text or '</img>' not in text:
        return text
    
    print("警告: paddle版本暂不支持图片向量处理功能")
    return text


def replace_img_vision(text, v_path=None, use_patch=1, max_shape=128, imgzip_model_path=None):
    """视觉图片替换（paddle版本暂不支持）"""
    if '<img>' not in text or '</img>' not in text:
        return text, np.zeros((max_shape, max_shape, 3), dtype=np.float32)
    
    print("警告: paddle版本暂不支持视觉图片处理功能")
    return text, np.zeros((max_shape, max_shape, 3), dtype=np.float32)


def create_black_image(max_shape):
    """创建全黑图片"""
    return np.zeros((max_shape, max_shape, 3), dtype=np.float32)


# 全局变量（用于兼容）
Img_path = None
Img_shape = (80, 80)


def set_size(size):
    """设置图片尺寸"""
    global Img_shape
    Img_shape = size


def gen_tempfn():
    """生成临时文件名"""
    with tempfile.NamedTemporaryFile(suffix='.png', delete=False) as temp_file:
        temp_filename = temp_file.name
        print(f"临时图片文件名: {temp_filename}")
    return temp_filename


def compress_image_to_160(img_path):
    """压缩图片至160x160以内"""
    with Image.open(img_path) as img:
        if img.mode in ('RGBA', 'LA') or (img.mode == 'P' and 'transparency' in img.info):
            background = Image.new(img.mode[:-1], img.size, (255, 255, 255))
            background.paste(img, img.split()[-1])
            img = background.convert("RGB")
        elif img.mode != 'RGB':
            img = img.convert("RGB")
        
        original_width, original_height = img.size
        max_size = 160
        if original_width > max_size or original_height > max_size:
            width_ratio = max_size / original_width
            height_ratio = max_size / original_height
            scale_ratio = min(width_ratio, height_ratio)
            new_width = int(original_width * scale_ratio)
            new_height = int(original_height * scale_ratio)
            img = img.resize((new_width, new_height), Image.Resampling.LANCZOS)
        
        temp_file = tempfile.NamedTemporaryFile(delete=False, suffix='.jpg')
        temp_path = temp_file.name
        temp_file.close()
        img.save(temp_path, 'JPEG', quality=90)
        
        return temp_path


# 命令行测试
if __name__ == "__main__" and 0:
    # 测试代码
    print("正在初始化Paddle模型...")
    model = QianyanModel()
    
    # 测试单轮对话
    print("\n=== 测试单轮对话 ===")
    response = model.chat_SingleTurn("你好，请介绍一下自己。", temp=0.8, maxlen=100)
    print(f"\n回复: {response}")
    
    # 测试多轮对话
    print("\n=== 测试多轮对话 ===")
    model.clean_his()
    response1 = model.chat("今天天气怎么样？", temp=0.8, max_len=100)
    print(f"\n回复1: {response1}")
    
    response2 = model.chat("那明天呢？", temp=0.8, max_len=100)
    print(f"\n回复2: {response2}")
    
    print("\n测试完成！")
# 将给定英文文本翻译成中文\n文本：“Hi.”

if __name__=='__main__' and 1:
    # 配置
    MT_NAME = 't7.5_paddle_small_instruct_pro'
    MODEL_DIR = r'D:\xiaothink\models\ckpt_test_t7.5_paddle_small_instruct_pro'
    CHECKPOINT_DIR = os.path.join(MODEL_DIR, 'checkpoints')


    model=QianyanModel(ckpt_dir=MODEL_DIR,#r'G:\大模型\models\ckpt_test_t6_standard_cloud_3epoch',
               MT=MT_NAME,
                 use_patch=0,
                imgzip_model_path='E:/小思框架/o第十四代/draw_v2/best_pro2.2_100c.keras')
    #model.add_his('你叫什么名字？','我的名字是“李明”，很高兴认识你！')
    #model.add_his('你好，李明','你也好呀！')
    #model.add_his('生成一首古诗，关于“烟雨锁重楼”','<think>首先，我需要理解这个主题的意境。“烟雨锁重楼”给人一种朦胧、湿润的感觉，可能是在描绘江南的雨景，重楼被烟雾和细雨笼罩，显得若隐若现。这种画面通常带有一种淡淡的哀愁或者孤寂感，所以诗歌的情感基调应该是比较婉约的。\n接下来是意象的选择。江南的烟雨常与杨柳、孤舟、远山等元素相关。比如“杨柳垂丝”、“孤舟蓑笠翁”这些意象能增强画面感。同时，可以加入一些动态的元素，如雁影、笛声，来增加诗的层次感。\n\n然后要考虑情感的表达。锁重楼可能暗示着被困住的感觉，所以情感上可能有离别、孤独、思念等。比如“别绪长”或者“归期渺”，这些词语能传达出深沉的愁思。同时，结尾处可能需要一种超脱或希望，比如“且把浮名换钓纶”，表现出放下世俗，追求宁静的心态。\n</think><ans>《重楼烟雨》\\n烟雨空濛锁画楼，一帘幽梦几时收。\\n杨柳垂丝牵别绪，孤舟蓑笠钓清秋。\\n寒山雁影穿云岫，玉笛梅花落浦鸥。\\n莫问归期春水逝，且将浮世作虚舟。</ans>')
    #model.add_his('你是谁？','你好，我是一个AI助手，我可以帮助你解决问题，请问有什么需要我帮助的吗？')#[0.14, 0.24, 0.3, 0.34, 0.4, 0.48]
    temp=0.34#0.4#0.36#model.find_base_temp(r'E:\小思框架\o第十四代\text2img2\images_sjk_zhms', n=3, temp_range=[0.2, 0.25, 0.3], plot=True)
    #0.24
    pret=''
    maxl=80
    rp=1.
    top_p=0.9
    while True:
        inp=input('【问】：')
        if inp =='[CLEAN]':
            print('【清空上下文】\n\n')
            model.clean_his()
            continue#0.42 0.52
        elif '[TEMP]' in inp:
            temp=float(inp[6:])
            print(f'【修改temperature至{temp}】\n\n')
            continue
        elif '[MAXL]' in inp:
            maxl=int(inp[6:])
            print(f'【修改max_len至{maxl}】\n\n')
            continue

        elif '[PRET]' in inp:
            pret=(inp[6:])
            print(f'【修改pre_text至"{pret}"】\n\n')
            continue
        elif '[RP]' in inp:
            rp=float(inp[4:])
            print(f'【修改rp至{rp}】\n\n')
            continue
        elif '[TOPP]' in inp:
            top_p=float(inp[6:])
            print(f'【修改TOP-P至{top_p}】\n\n')
            continue
        if 1:
        
            try:

                ret=model.chat(inp,temp=temp, form=2,
                               pre_text=pret,pass_char=['▩'],
                               repetition_penalty=rp,max_len=maxl,
                               top_p=top_p)
            except KeyboardInterrupt as ee:
                print('键盘打断')
            
                
        
        else:
            ret=model.img2ms(inp,temp=temp,max_len=maxl, top_p=top_p)
        #pret=''
        print('\n【答】：',ret,'\n')


 
