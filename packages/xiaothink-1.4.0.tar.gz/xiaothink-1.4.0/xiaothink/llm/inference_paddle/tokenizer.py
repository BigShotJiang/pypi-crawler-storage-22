#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Xiaothink Tokenizer
增强的分词器实现，包含WordTokenizer和CharTokenizer
添加了更复杂的未知内容处理机制，尽可能减少未知量
"""
import json
import jieba

# 字符类型判断函数
def is_chinese_char(char):
    """检查字符是否为中文字符"""
    return '\u4e00' <= char <= '\u9fff'

def is_digit(char):
    """检查字符是否为数字"""
    return char.isdigit()

def is_english_char(char):
    """检查字符是否为英文字符"""
    return char.isalpha() and char.isascii()

def is_punctuation(char):
    """检查字符是否为标点符号"""
    import string
    return char in string.punctuation or char in "，。！？；：\"''（）【】[]()"

def is_special_char(char):
    """检查字符是否为特殊符号"""
    return not (is_chinese_char(char) or is_digit(char) or is_english_char(char) or char.isspace())

# 英文单词拆分函数
def split_english_word(word):
    """
    尝试拆分英文单词为更小的单位
    简单的启发式方法，实际应用中可能需要更复杂的算法
    """
    # 常见的英文前缀
    prefixes = ['un', 're', 'in', 'im', 'il', 'ir', 'dis', 'en', 'em', 'non', 'over', 'mis', 'sub', 'pre', 'inter', 'super', 'intra', 'extra', 'semi', 'anti', 'auto', 'bi', 'co', 'de', 'ex', 'fore', 'in', 'mid', 'post', 'pro', 'tele', 'trans', 'under', 'up']
    
    # 常见的英文后缀
    suffixes = ['s', 'es', 'ed', 'ing', 'ly', 'er', 'est', 'ment', 'ness', 'ity', 'ty', 'al', 'ial', 'ic', 'ical', 'ful', 'less', 'ous', 'eous', 'ious', 'ive', 'ative', 'itive', 'able', 'ible', 'y', 'ly', 'en', 'er', 'est']
    
    # 尝试拆分
    for prefix in prefixes:
        if word.startswith(prefix) and len(word) > len(prefix):
            return [prefix, word[len(prefix):]]
    
    for suffix in suffixes:
        if word.endswith(suffix) and len(word) > len(suffix):
            return [word[:-len(suffix)], suffix]
    
    # 尝试按元音字母拆分
    vowels = 'aeiou'
    for i, char in enumerate(word):
        if char in vowels and i > 0 and i < len(word) - 1:
            return [word[:i+1], word[i+1:]]
    
    # 无法拆分，返回原单词
    return [word]

# 词语Tokenizer类
class WordTokenizer:
    def __init__(self, vocab_path=None):
        self.word2id = {}
        self.id2word = {}
        self.vocab_size = 0
        if vocab_path:
            self._load_vocab(vocab_path)
        else:
            self._build_vocab()
    
    def _build_vocab(self):
        # 只保留▩作为特殊字符（未知字符标记）
        self.word2id['▩'] = 0
        self.id2word[0] = '▩'
        self.vocab_size = 1
    
    def _load_vocab(self, vocab_path):
        """加载词汇表"""
        # 支持两种格式：
        # 1. vocab.json格式（直接的词汇表列表）
        # 2. tokenizer.json格式（包含word2id和id2word）
        with open(vocab_path, 'r', encoding='utf-8') as f:
            try:
                vocab_data = json.load(f)
            except json.JSONDecodeError:
                raise ValueError("Invalid JSON file")
        
        if isinstance(vocab_data, list):
            # vocab.json格式（词汇表列表）
            for i, word in enumerate(vocab_data):
                self.word2id[word] = i
                self.id2word[i] = word
        elif isinstance(vocab_data, dict) and 'word2id' in vocab_data:
            # tokenizer.json格式
            self.word2id = vocab_data['word2id']
            self.id2word = {int(k): v for k, v in vocab_data['id2word'].items()}
        else:
            raise ValueError("Invalid vocab file format")
        
        # 更新词汇表大小
        self.vocab_size = len(self.word2id)
    
    def tokenize(self, text):
        """
        将文本分词为词语列表
        增强的分词逻辑：
        1. 数字必须逐个切分
        2. 汉字基于jieba分词，遇到未知中文词组时拆分为单个汉字
        3. 英文基于空格和标点切分，遇到未知英文单词时尝试拆分为小单词
        4. 标点符号单独作为token
        5. 遇到未知内容先尝试按特殊符号切分
        """
        tokens = []
        i = 0
        n = len(text)
        
        while i < n:
            char = text[i]
            
            # 跳过空白字符
            if char.isspace():
                i += 1
                continue
            
            # 1. 数字 - 逐个切分
            if is_digit(char):
                tokens.append(char)
                i += 1
                continue
            
            # 2. 中文字符 - 使用jieba分词
            if is_chinese_char(char):
                # 找到连续的中文字符段
                j = i
                while j < n and (is_chinese_char(text[j]) or is_punctuation(text[j])):
                    j += 1
                chinese_segment = text[i:j]
                
                # 使用jieba分词
                jieba_tokens = list(jieba.cut(chinese_segment))
                
                # 处理未知中文词组 - 拆分为单个汉字
                for token in jieba_tokens:
                    # 检查token是否全部由中文字符组成且不在词汇表中
                    if all(is_chinese_char(c) for c in token) and token not in self.word2id:
                        # 拆分为单个汉字
                        for char in token:
                            tokens.append(char)
                    else:
                        # 保留原token
                        tokens.append(token)
                
                i = j
                continue
            
            # 3. 英文单词 - 基于空格和标点切分
            if is_english_char(char):
                # 找到连续的英文字符段（包括字母、连字符和可能的特殊符号）
                j = i
                while j < n and (is_english_char(text[j]) or text[j] == '-' or text[j] in ':;"\'<,>.?/~`+/*'):
                    j += 1
                english_segment = text[i:j]
                
                # 先按特殊符号切分
                special_chars = ':;"\'<,>.?/~`+/*'
                segments = []
                current_segment = ''
                
                for c in english_segment:
                    if c in special_chars:
                        if current_segment:
                            segments.append(current_segment)
                            current_segment = ''
                        segments.append(c)
                    else:
                        current_segment += c
                
                if current_segment:
                    segments.append(current_segment)
                
                # 处理每个切分后的段
                for segment in segments:
                    if segment in special_chars:
                        # 特殊符号单独作为token
                        tokens.append(segment)
                    else:
                        # 英文单词部分
                        english_word = segment.lower()
                        
                        # 尝试从大到小拼接已有token
                        if english_word in self.word2id:
                            # 完整单词在词汇表中
                            tokens.append(english_word)
                        else:
                            # 尝试从大到小拆分
                            processed = False
                            remaining = english_word
                            
                            while remaining:
                                # 从当前长度开始尝试
                                max_len = len(remaining)
                                found = False
                                
                                for length in range(max_len, 0, -1):
                                    if length == 1:
                                        # 单个字符，直接添加
                                        tokens.append(remaining[0])
                                        remaining = remaining[1:]
                                        found = True
                                        break
                                    
                                    candidate = remaining[:length]
                                    if candidate in self.word2id:
                                        # 找到匹配的token
                                        tokens.append(candidate)
                                        remaining = remaining[length:]
                                        found = True
                                        break
                                
                                if not found:
                                    # 无法匹配，添加整个剩余部分
                                    tokens.append(remaining)
                                    break
                
                i = j
                continue
            
            # 4. 标点符号 - 单独作为token
            if is_punctuation(char):
                tokens.append(char)
                i += 1
                continue
            
            # 5. 特殊符号 - 单独作为token
            if is_special_char(char):
                tokens.append(char)
                i += 1
                continue
            
            # 6. 其他字符 - 单独作为token
            tokens.append(char)
            i += 1
        
        return tokens
    
    def encode(self, text, max_len=None):
        """
        将文本编码为id列表
        使用词汇表中0项的未知字符标记（▩）
        """
        tokens = self.tokenize(text)
        ids = []
        for token in tokens:
            ids.append(self.word2id.get(token, 0))  # 直接使用0作为未知字符的id
        
        if max_len:
            if len(ids) > max_len:
                ids = ids[:max_len]
            else:
                # 不使用<pad>，直接截断或保持原样
                pass
        
        return ids
    
    def decode(self, ids):
        """
        将id列表解码为文本
        使用词汇表中0项的未知字符标记（▩）
        """
        words = []
        for id in ids:
            # 直接使用id2word.get获取词语，如果找不到则使用0项的未知字符标记
            word = self.id2word.get(id, self.id2word.get(0, '▩'))
            words.append(word)
        return ''.join(words)
    
    def save(self, path):
        """
        保存tokenizer
        """
        with open(path, 'w', encoding='utf-8') as f:
            json.dump({'word2id': self.word2id, 'id2word': self.id2word}, f, ensure_ascii=False, indent=2)
    
    @classmethod
    def load(cls, path):
        """
        加载tokenizer
        """
        tokenizer = cls()
        with open(path, 'r', encoding='utf-8') as f:
            data = json.load(f)
        tokenizer.word2id = data['word2id']
        tokenizer.id2word = {int(k): v for k, v in data['id2word'].items()}
        tokenizer.vocab_size = len(tokenizer.word2id)
        return tokenizer

# 逐字Tokenizer类
class CharTokenizer:
    def __init__(self, vocab_path=None):
        self.char2id = {}
        self.id2char = {}
        self.vocab_size = 0
        if vocab_path:
            self._load_vocab(vocab_path)
        else:
            self._build_vocab()
    
    def _build_vocab(self):
        # 只保留▩作为特殊字符（未知字符标记）
        self.char2id['▩'] = 0
        self.id2char[0] = '▩'
        self.vocab_size = 1
    
    def _load_vocab(self, vocab_path):
        """加载词汇表"""
        # 支持两种格式：
        # 1. vocab_lx3.txt格式（Python列表格式）
        # 2. tokenizer.json格式（包含char2id和id2char）
        with open(vocab_path, 'r', encoding='utf-8') as f:
            try:
                content = f.read()
                # 尝试解析为JSON
                try:
                    vocab_data = json.loads(content)
                    if isinstance(vocab_data, dict) and 'char2id' in vocab_data:
                        # tokenizer.json格式
                        self.char2id = vocab_data['char2id']
                        self.id2char = {int(k): v for k, v in vocab_data['id2char'].items()}
                    else:
                        # 直接的字符列表
                        vocab_list = vocab_data
                        for i, char in enumerate(vocab_list):
                            self.char2id[char] = i
                            self.id2char[i] = char
                except json.JSONDecodeError:
                    # 尝试解析为Python列表
                    vocab_list = eval(content)
                    for i, char in enumerate(vocab_list):
                        self.char2id[char] = i
                        self.id2char[i] = char
            except Exception as e:
                raise ValueError(f"Failed to load vocab: {e}")
        
        # 更新词汇表大小
        self.vocab_size = len(self.char2id)
    
    def tokenize(self, text):
        """
        字符级分词，每个字符作为一个token
        """
        return list(text)
    
    def encode(self, text, max_len=None):
        """
        将文本编码为id列表
        使用词汇表中0项的未知字符标记（▩）
        """
        tokens = self.tokenize(text)
        ids = []
        for token in tokens:
            ids.append(self.char2id.get(token, 0))  # 直接使用0作为未知字符的id
        
        if max_len:
            if len(ids) > max_len:
                ids = ids[:max_len]
            else:
                # 不使用<pad>，直接截断或保持原样
                pass
        
        return ids
    
    def decode(self, ids):
        """
        将id列表解码为文本
        使用词汇表中0项的未知字符标记（▩）
        """
        chars = []
        for id in ids:
            # 直接使用id2char.get获取字符，如果找不到则使用0项的未知字符标记
            char = self.id2char.get(id, self.id2char.get(0, '▩'))
            chars.append(char)
        return ''.join(chars)
    
    def save(self, path):
        """
        保存tokenizer
        """
        with open(path, 'w', encoding='utf-8') as f:
            json.dump({'char2id': self.char2id, 'id2char': self.id2char}, f, ensure_ascii=False, indent=2)
    
    @classmethod
    def load(cls, path):
        """
        加载tokenizer
        """
        tokenizer = cls()
        with open(path, 'r', encoding='utf-8') as f:
            data = json.load(f)
        tokenizer.char2id = data['char2id']
        tokenizer.id2char = {int(k): v for k, v in data['id2char'].items()}
        tokenizer.vocab_size = len(tokenizer.char2id)
        return tokenizer

# 加载tokenizer的辅助函数
def load_tokenizer(tokenizer_path):
    """
    加载tokenizer
    根据文件内容自动判断tokenizer类型
    
    Args:
        tokenizer_path: tokenizer文件路径
        
    Returns:
        WordTokenizer或CharTokenizer实例
    """
    with open(tokenizer_path, 'r', encoding='utf-8') as f:
        try:
            tokenizer_data = json.load(f)
        except json.JSONDecodeError:
            # 尝试作为字符列表加载
            return CharTokenizer(tokenizer_path)
    
    if isinstance(tokenizer_data, list):
        # 直接的词汇表列表，默认为WordTokenizer
        return WordTokenizer(tokenizer_path)
    elif 'word2id' in tokenizer_data:
        # 词语tokenizer
        return WordTokenizer(tokenizer_path)
    elif 'char2id' in tokenizer_data:
        # 字符tokenizer
        return CharTokenizer(tokenizer_path)
    else:
        # 尝试作为字符列表加载
        return CharTokenizer(tokenizer_path)

# 初始化jieba
jieba.initialize()

if __name__ == "__main__":
    """测试tokenizer"""
    # 测试WordTokenizer - 使用实际的词汇表
    print("Testing WordTokenizer...")
    word_tokenizer = WordTokenizer(r'D:/xiaothink/models/tokenizer_lx3/vocab.json')
    print(f"词汇表大小: {word_tokenizer.vocab_size}")
    test_text = "这是一个测试文本，包含123数字和English单词，以及一些可能不在词汇表中的未知中文词组和unknownenglishwords。"
    tokens = word_tokenizer.tokenize(test_text)
    print(f"Original text: {test_text}")
    print(f"Tokens: {tokens}")
    encoded = word_tokenizer.encode(test_text)
    print(f"Encoded: {encoded}")
    print(f"Decoded: {word_tokenizer.decode(encoded)}")
    
    # 测试CharTokenizer - 使用实际的词汇表
    print("\nTesting CharTokenizer...")
    char_tokenizer = CharTokenizer(r'D:/xiaothink/models/vocab_lx3.txt')
    print(f"词汇表大小: {char_tokenizer.vocab_size}")
    tokens = char_tokenizer.tokenize(test_text)
    print(f"Original text: {test_text}")
    print(f"Tokens: {tokens[:20]}..." if len(tokens) > 20 else f"Tokens: {tokens}")
    encoded = char_tokenizer.encode(test_text)
    print(f"Encoded: {encoded[:20]}..." if len(encoded) > 20 else f"Encoded: {encoded}")
    print(f"Decoded: {char_tokenizer.decode(encoded)}")
