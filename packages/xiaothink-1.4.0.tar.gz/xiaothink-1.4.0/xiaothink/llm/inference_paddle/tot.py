# -*- coding: utf-8 -*-
"""
tot.py - Train-On-Time 动态学习系统

工作流程：
1. 用户提问
2. 从训练数据中匹配相似指令
3. 使用相似指令数据微调模型
4. 回答问题

特点：
- 每次对话都会进行微调，实现实时学习
- 基于相似度匹配相关训练数据
- 支持多轮对话历史管理
"""

import os
import sys
import json
import time
import shutil
import numpy as np
from pathlib import Path

# 尝试导入 PaddlePaddle（T7.5 及以上模型需要）
try:
    import paddle
    PADDLE_AVAILABLE = True
except Exception as e:
    PADDLE_AVAILABLE = False
    print(f"[警告] PaddlePaddle 导入失败: {e}")
    print("[提示] TOT 功能需要 PaddlePaddle 支持")

# 导入 QianyanModel
try:
    from .test_formal import QianyanModel
except Exception as e:
    QianyanModel = None
    print(f"[警告] QianyanModel 导入失败: {e}")

# 默认配置
STANDARD_MODEL_DIR = r'E:\server_models\t7.5\ckpt_test_t7.5_paddle_small_instruct_pro'
DEFAULT_TRAIN_DATA_PATHS = [
    r'd:\xiaothink\models\train_data\minimind\large_instruct\belle_train_3.5M_CN_minimindtype.jsonl',
    r'd:\xiaothink\models\train_data\minimind\large_instruct\coig_minimind.jsonl',
    r'd:\xiaothink\models\train_data\minimind\large_instruct\minimindtype_firefly_1_1M.jsonl',
    r'd:\xiaothink\models\train_data\minimind\instruct\hqqa_minisft_t1_geng_dsnet.txt',
    r'd:\xiaothink\models\train_data\minimind\instruct\longtext_m_minisft_hqsft_sft512some_geng_infoprocess_poem_appreciation.txt',
    r'd:\xiaothink\models\train_data\minimind\instruct\ministf512_belle.txt',
    r'd:\xiaothink\models\train_data\minimind\poem.txt',
    r'd:\xiaothink\models\train_data\minimind\fanyi_mixed_mini_big.txt',
]

# 全局变量，可在运行时修改
train_data_paths = DEFAULT_TRAIN_DATA_PATHS

# 训练配置
MAX_INSTRUCT_SAMPLES = 128   # 最大指令微调样本数
TRAIN_EPOCHS = 4
TRAIN_BATCH_SIZE = 32
TRAIN_LEARNING_RATE = 8e-5
TRAIN_MAX_SEQ_LEN = 256
TRAIN_DATA_DUPLICATE = 1  # 训练样本复制倍数（默认为1，不复制）

# 全局函数：计算相似度（必须在类外部，以便多进程序列化）
def _calc_similarity_worker(args):
    """计算单个样本的相似度（全局函数，用于多进程）"""
    import difflib
    text, question, data_path, line_num = args
    try:
        similarity = difflib.SequenceMatcher(None, question, text).ratio()
        return (similarity, data_path, line_num)
    except:
        return (0.0, data_path, line_num)


class DynamicLearningSystem:
    """动态学习系统 - 每次对话都进行微调"""
    
    def __init__(self):
        self.model = None
        self.tokenizer = None
        self.config = None
        self.current_model_dir = None
        self.qianyan_model = None
        
    def load_standard_model(self):
        """加载标准模型"""
        print("[系统] 加载标准模型...")
        from .models import create_model
        from .tokenizer import load_tokenizer
        
        # 加载tokenizer
        tokenizer_path = os.path.join(STANDARD_MODEL_DIR, 'tokenizer.json')
        self.tokenizer = load_tokenizer(tokenizer_path)
        
        # 创建模型
        self.model, self.config = create_model('t7.5_paddle_small_instruct_pro', self.tokenizer.vocab_size)
        
        # 加载权重（尝试多种格式）
        checkpoint_loaded = False
        
        # 1. 尝试加载 final_model.pdparams
        final_model_path = os.path.join(STANDARD_MODEL_DIR, 'final_model.pdparams')
        if os.path.exists(final_model_path):
            checkpoint = paddle.load(final_model_path)
            self.model.set_state_dict(checkpoint)
            print(f"[系统] 已加载标准模型: final_model.pdparams")
            checkpoint_loaded = True
        
        # 2. 尝试加载检查点目录中的最新检查点
        if not checkpoint_loaded:
            checkpoints_dir = os.path.join(STANDARD_MODEL_DIR, 'checkpoints')
            if os.path.exists(checkpoints_dir):
                checkpoints = sorted([f for f in os.listdir(checkpoints_dir) if f.startswith('checkpoint_') and f.endswith('.pdparams')], 
                                    key=lambda x: int(x.split('_')[1].split('.')[0]))
                if checkpoints:
                    latest_checkpoint = os.path.join(checkpoints_dir, checkpoints[-1])
                    checkpoint = paddle.load(latest_checkpoint)
                    self.model.set_state_dict(checkpoint)
                    print(f"[系统] 已加载标准模型: {checkpoints[-1]}")
                    checkpoint_loaded = True
        
        if not checkpoint_loaded:
            raise FileNotFoundError(f"未找到标准模型，请检查目录: {STANDARD_MODEL_DIR}")
        
        self.model.eval()
        self.current_model_dir = STANDARD_MODEL_DIR
        
        # 初始化 QianyanModel 用于聊天
        self._init_qianyan_model()
        
    def _init_qianyan_model(self):
        """初始化 QianyanModel 用于聊天"""
        print("[系统] 初始化 QianyanModel 用于聊天...")
        self.qianyan_model = QianyanModel(
            ckpt_dir=STANDARD_MODEL_DIR,
            MT='t7.5_paddle_small_instruct_pro'
        )
        self.qianyan_model.load()
        print("[系统] QianyanModel 初始化完成")
        
    def find_similar_instruct_data(self, question, top_k=100, random_pool_size=10000):
        """基于difflib找到相似的指令微调数据
        
        Args:
            question: 用户问题
            top_k: 返回的相似指令数量
            random_pool_size: 随机候选池大小
        """
        import heapq
        from multiprocessing import Pool, cpu_count
        from tqdm import tqdm
        
        print(f"[匹配] 寻找相似指令数据（使用{cpu_count()}核并行处理）...")
        
        # 收集所有数据（使用生成器节省内存）
        def data_generator():
            for data_path in train_data_paths:
                if not os.path.exists(data_path):
                    continue
                try:
                    with open(data_path, 'r', encoding='utf-8') as f:
                        for line_num, line in enumerate(f, 1):
                            try:
                                data = json.loads(line.strip())
                                if 'conversations' in data:
                                    conversations = data['conversations']
                                    if conversations and len(conversations) > 0:
                                        user_msg = conversations[0].get('content', '')
                                        yield (user_msg, question, data_path, line_num)
                                elif 'instruction' in data:
                                    instruction = data['instruction']
                                    yield (instruction, question, data_path, line_num)
                            except json.JSONDecodeError:
                                continue
                except Exception as e:
                    print(f"[匹配] 读取文件失败 {data_path}: {e}")
                    continue
        
        top_k_heap = []
        random_pool_refs = []
        
        data_refs = list(data_generator())
        total_samples = len(data_refs)
        
        if total_samples == 0:
            print("[匹配] 未找到任何指令数据")
            return [], []
        
        print(f"[匹配] 共 {total_samples} 条候选数据，开始并行计算相似度...")
        
        with Pool(processes=min(cpu_count(), 8)) as pool:
            for idx, result in enumerate(tqdm(pool.imap(_calc_similarity_worker, data_refs, chunksize=100), 
                              total=total_samples, 
                              desc="[匹配] 计算相似度",
                              ncols=80)):
                similarity, data_path, line_num = result
                
                if len(top_k_heap) < top_k:
                    heapq.heappush(top_k_heap, (similarity, data_path, line_num))
                elif similarity > top_k_heap[0][0]:
                    heapq.heapreplace(top_k_heap, (similarity, data_path, line_num))
                
                if 0.1 < similarity < 0.5 and len(random_pool_refs) < random_pool_size:
                    random_pool_refs.append((data_path, line_num))
        
        print("[匹配] 加载最相似的指令数据...")
        similar_data = []
        
        refs_by_file = {}
        for similarity, data_path, line_num in top_k_heap:
            if data_path not in refs_by_file:
                refs_by_file[data_path] = []
            refs_by_file[data_path].append(line_num)
        
        for data_path, line_nums in refs_by_file.items():
            line_nums_set = set(line_nums)
            try:
                with open(data_path, 'r', encoding='utf-8') as f:
                    for line_num, line in enumerate(f, 1):
                        if line_num in line_nums_set:
                            try:
                                data = json.loads(line.strip())
                                similar_data.append(data)
                            except:
                                pass
            except:
                pass
        
        random_data = []
        if random_pool_refs:
            print(f"[匹配] 加载随机候选池数据...")
            refs_by_file = {}
            for data_path, line_num in random_pool_refs:
                if data_path not in refs_by_file:
                    refs_by_file[data_path] = []
                refs_by_file[data_path].append(line_num)
            
            for data_path, line_nums in refs_by_file.items():
                line_nums_set = set(line_nums)
                try:
                    with open(data_path, 'r', encoding='utf-8') as f:
                        for line_num, line in enumerate(f, 1):
                            if line_num in line_nums_set:
                                try:
                                    data = json.loads(line.strip())
                                    random_data.append(data)
                                except:
                                    pass
                except:
                    pass
        
        print(f"[匹配] 完成: {len(similar_data)} 条相似指令, {len(random_data)} 条随机候选")
        return similar_data, random_data
    
    def prepare_training_data(self, similar_instruct_data, random_instruct_data=None):
        """准备训练数据"""
        print(f"[准备] 准备训练数据...")
        
        training_samples = []
        
        # 添加相似指令数据
        for data in similar_instruct_data[:MAX_INSTRUCT_SAMPLES]:
            if 'conversations' in data:
                conversations = data['conversations']
                for i in range(0, len(conversations)-1, 2):
                    if i+1 < len(conversations):
                        user_msg = conversations[i].get('content', '')
                        assistant_msg = conversations[i+1].get('content', '')
                        if user_msg and assistant_msg:
                            sample = f'<|u|>{user_msg}<|a|>{assistant_msg}<|e|>'
                            training_samples.append(sample)
            elif 'instruction' in data and 'output' in data:
                instruction = data['instruction']
                output = data['output']
                if instruction and output:
                    sample = f'<|u|>{instruction}<|a|>{output}<|e|>'
                    training_samples.append(sample)
        
        # 复制样本
        if TRAIN_DATA_DUPLICATE > 1:
            training_samples = training_samples * TRAIN_DATA_DUPLICATE
        
        print(f"[准备] 共准备 {len(training_samples)} 条训练样本")
        return training_samples
    
    def train_model_in_memory(self, training_samples):
        """在内存中训练模型"""
        print(f"[训练] 开始训练（{len(training_samples)} 样本, {TRAIN_EPOCHS} 轮）...")
        
        # 保存原始权重
        original_state = {k: v.clone() for k, v in self.model.state_dict().items()}
        
        # 设置为训练模式
        self.model.train()
        
        # 优化器
        optimizer = paddle.optimizer.Adam(
            learning_rate=TRAIN_LEARNING_RATE,
            parameters=self.model.parameters()
        )
        
        # 训练循环
        for epoch in range(TRAIN_EPOCHS):
            total_loss = 0
            num_batches = 0
            
            # 打乱数据
            np.random.shuffle(training_samples)
            
            for i in range(0, len(training_samples), TRAIN_BATCH_SIZE):
                batch_samples = training_samples[i:i+TRAIN_BATCH_SIZE]
                
                batch_loss = 0
                for sample in batch_samples:
                    # 编码
                    input_ids = self.tokenizer.encode(sample)
                    if len(input_ids) < 2:
                        continue
                    
                    # 截断
                    if len(input_ids) > TRAIN_MAX_SEQ_LEN:
                        input_ids = input_ids[:TRAIN_MAX_SEQ_LEN]
                    
                    # 转换为tensor
                    input_tensor = paddle.to_tensor([input_ids], dtype='int64')
                    
                    # 前向传播
                    logits = self.model(input_tensor)
                    
                    # 计算loss
                    shift_logits = logits[:, :-1, :]
                    shift_labels = input_tensor[:, 1:]
                    
                    loss_fct = paddle.nn.CrossEntropyLoss()
                    loss = loss_fct(shift_logits.reshape([-1, shift_logits.shape[-1]]), shift_labels.reshape([-1]))
                    
                    batch_loss += loss.item()
                
                if batch_loss > 0:
                    avg_loss = batch_loss / len(batch_samples)
                    total_loss += avg_loss
                    num_batches += 1
                    
                    # 反向传播
                    avg_loss_tensor = paddle.to_tensor(batch_loss / len(batch_samples))
                    avg_loss_tensor.backward()
                    optimizer.step()
                    optimizer.clear_grad()
            
            avg_epoch_loss = total_loss / num_batches if num_batches > 0 else 0
            print(f"[训练] Epoch {epoch+1}/{TRAIN_EPOCHS}, Loss: {avg_epoch_loss:.4f}")
        
        # 设置回评估模式
        self.model.eval()
        
        print("[训练] 训练完成")
        return original_state
    
    def generate_answer(self, question, max_length=256, temperature=0.68, 
                       repetition_penalty=1.2, top_p=1.0):
        """生成答案"""
        # 使用 QianyanModel 生成
        prompt = f'<|u|>{question}<|a|>'
        
        # 调用 QianyanModel 的生成方法
        answer = self.qianyan_model.chat(
            text=question,
            temp=temperature,
            max_len=max_length,
            form=2,
            ontime=False,
            repetition_penalty=repetition_penalty
        )
        
        return answer
    
    def restore_model(self, original_state):
        """恢复模型到原始状态"""
        if original_state:
            self.model.set_state_dict(original_state)
            print("[系统] 模型已恢复到原始状态")
    
    def run(self, question, temp=0.68, max_len=256, pre_text='', repetition_penalty=1.2, top_p=1.0):
        """运行完整流程：匹配相似数据 -> 微调模型 -> 生成答案
        
        Args:
            question: 用户问题
            temp: 温度参数
            max_len: 最大生成长度
            pre_text: 前置文本
            repetition_penalty: 重复惩罚
            top_p: top-p采样参数
        """
        import gc
        
        print("=" * 60)
        print("Train-On-Time 动态学习系统")
        print("=" * 60)
        print(f"问题: {question}")
        print("-" * 60)
        
        # 步骤1: 加载模型
        if not self.model:
            self.load_standard_model()
        
        original_state = None
        
        # 步骤2: 找到相似的指令微调数据
        similar_instruct_data, _ = self.find_similar_instruct_data(question, random_pool_size=0)
        
        # 步骤3: 准备训练数据并训练
        if similar_instruct_data:
            training_data = self.prepare_training_data(similar_instruct_data)
            
            if training_data:
                original_state = self.train_model_in_memory(training_data)
            else:
                print("[系统] 没有可用的训练数据")
        else:
            print("[系统] 未找到相似指令数据")
        
        # 步骤4: 生成答案
        print("[系统] 生成答案...")
        answer = self.generate_answer(
            question, 
            max_length=max_len, 
            temperature=temp, 
            repetition_penalty=repetition_penalty,
            top_p=top_p
        )
        
        # 步骤5: 恢复模型（可选，如果希望保留学习效果可以注释掉）
        # self.restore_model(original_state)
        
        # 清理GPU缓存
        if paddle.is_compiled_with_cuda():
            paddle.device.cuda.empty_cache()
        gc.collect()
        
        # 添加前置文本
        if pre_text:
            answer = pre_text + answer
        
        print("=" * 60)
        print("答案:")
        print(answer)
        print("=" * 60)
        
        return answer


class TOTModel:
    """TOT 模型封装类 - 提供与 QianyanModel 兼容的接口"""
    
    def __init__(self, ckpt_dir=None, MT='t7.5_paddle_small_instruct_pro', data_paths=None):
        """初始化 TOT 模型
        
        Args:
            ckpt_dir: 模型检查点目录（可选，使用默认路径）
            MT: 模型类型
            data_paths: 训练数据路径列表（可选，使用默认路径）
        """
        global STANDARD_MODEL_DIR
        if ckpt_dir:
            STANDARD_MODEL_DIR = ckpt_dir
        
        # 更新全局训练数据路径
        global train_data_paths
        if data_paths:
            train_data_paths = data_paths
        else:
            train_data_paths = DEFAULT_TRAIN_DATA_PATHS
        
        self.MT = MT
        self.system = DynamicLearningSystem()
        self.his = ''
        
    def load(self):
        """加载模型"""
        self.system.load_standard_model()
        
    def clean_his(self):
        """清空对话历史"""
        self.his = ''
        if self.system.qianyan_model:
            self.system.qianyan_model.clean_his()
        print("[系统] 对话历史已清空")
    
    def _update_history(self, q, a, form):
        """更新对话历史"""
        if form == 0:
            if self.his != '':
                self.his += '\\nHuman: ' + q + '\\nAssistant: ' + a
            else:
                self.his = 'Human: ' + q + '\\nAssistant: ' + a
        elif form == 1:
            if self.his != '':
                self.his += ', {"role": "user", "content": "' + q + '"}, {"role": "assistant", "content": "' + a + '"}'
            else:
                self.his = '{"role": "user", "content": "' + q + '"}, {"role": "assistant", "content": "' + a + '"}'
        elif form == 2:
            if self.his != '':
                self.his += f'<|u|>{q}<|a|>{a}<|e|>'
            else:
                self.his = f'<|u|>{q}<|a|>{a}<|e|>'
    
    def chat_SingleTurn(self, t, temp=0.68, maxlen=256, form=2, ontime=False, repetition_penalty=1.2):
        """单轮对话"""
        t = t.replace('\n', '\\n')
        
        # 运行 TOT 流程获取答案
        ret = self.system.run(
            t, 
            temp=temp, 
            max_len=maxlen, 
            repetition_penalty=repetition_penalty
        )
        
        # 提取答案部分
        if '<|a|>' in ret:
            a = ret.split('<|a|>')[-1].replace('<|e|>', '').strip()
        else:
            a = ret
        
        a = a.replace('\n', '\\n')
        return a
    
    def chat(self, text, temp=0.68, max_len=256, form=1, ontime=True,
             loop=True, pre_text='', repetition_penalty=1.0,
             pass_start_char=None, pass_char=None, top_p=1.0):
        """多轮对话
        
        Args:
            text: 输入文本
            temp: 温度参数
            max_len: 最大生成长度
            form: 格式类型
            ontime: 是否实时输出
            loop: 是否使用循环生成
            pre_text: 前置文本
            repetition_penalty: 重复惩罚
            pass_start_char: 跳过的起始字符列表
            pass_char: 跳过的字符列表
            top_p: top-p采样参数
        
        Returns:
            生成的回复
        """
        text = text.replace('\n', '\\n')
        
        # 更新历史
        if form == 2:
            if self.his != '':
                self.his += f'<|e|><|u|>{text}<|a|>'
            else:
                self.his = f'<|u|>{text}<|a|>'
        
        # 运行 TOT 流程获取答案
        if ontime:
            print('\n【实时输出】')
        
        ret = self.system.run(
            text, 
            temp=temp, 
            max_len=max_len, 
            pre_text=pre_text, 
            repetition_penalty=repetition_penalty, 
            top_p=top_p
        )
        
        # 更新历史
        self._update_history(text, ret.replace('<|e|>', ''), form)
        
        return ret
    
    def chat_(self, text, temp=0.68, max_len=256, form=1, ontime=True,
              loop=True, pre_text='', repetition_penalty=1.2):
        """多轮对话（简化版）"""
        return self.chat(text, temp, max_len, form, ontime, loop, pre_text, repetition_penalty)
