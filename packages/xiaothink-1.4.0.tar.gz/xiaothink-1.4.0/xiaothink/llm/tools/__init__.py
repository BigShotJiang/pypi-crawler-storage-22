# xiaothink.llm.tools 模块

# 尝试导入工具模块
try:
    from .ai_possibility import AIDetector
    AI_DETECTOR_AVAILABLE = True
except Exception as e:
    AI_DETECTOR_AVAILABLE = False
    AIDetector = None

try:
    from .classify import ClassifyModel, create_classify_model
    CLASSIFY_AVAILABLE = True
except Exception as e:
    CLASSIFY_AVAILABLE = False
    ClassifyModel = None
    create_classify_model = None

__all__ = [
    'AIDetector',
    'ClassifyModel', 
    'create_classify_model',
    'AI_DETECTOR_AVAILABLE',
    'CLASSIFY_AVAILABLE',
]
