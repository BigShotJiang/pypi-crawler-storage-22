# 尝试导入 TensorFlow（T7 及以下模型需要）
try:
    import tensorflow as tf
    TF_AVAILABLE = True
except Exception as e:
    TF_AVAILABLE = False
    tf = None

# 尝试导入 PaddlePaddle（T7.5 及以上模型需要）
try:
    import paddle
    PADDLE_AVAILABLE = True
except Exception as e:
    PADDLE_AVAILABLE = False
    paddle = None

import numpy as np
import gc

# 尝试导入 TensorFlow 推理模块
try:
    import xiaothink.llm.inference.test as model_infer_tf
    TF_INFERENCE_AVAILABLE = True
except Exception as e:
    model_infer_tf = None
    TF_INFERENCE_AVAILABLE = False

# 尝试导入 PaddlePaddle 推理模块
try:
    from xiaothink.llm.inference_paddle import QianyanModel, TextGenerator
    PADDLE_INFERENCE_AVAILABLE = True
except Exception as e:
    PADDLE_INFERENCE_AVAILABLE = False


class AIDetector:
    """
    AI文本检测类（极简版）
    核心逻辑：完整前文预测字符概率 → 概率的算术平均值 = AI率
    支持 TensorFlow（T7及以下）和 PaddlePaddle（T7.5及以上）两种后端
    """
    def __init__(self,
                 ckpt_dir=r'E:\小思框架\论文\ganskchat\ckpt_test_t7_cloud_pro',
                 vocab_path=r'E:\小思框架\论文\ganskchat\vocab_lx3.txt',
                 model_type='t7',
                 batch_size=1,
                 print_load_info=False,
                 backend='auto'):
        """
        初始化检测器
        
        Args:
            ckpt_dir: 模型检查点目录
            vocab_path: 词汇表路径
            model_type: 模型类型
            batch_size: 批次大小
            print_load_info: 是否打印加载信息
            backend: 后端类型 'auto'/'tensorflow'/'paddle'
        """
        self.ckpt_dir = ckpt_dir
        self.vocab_path = vocab_path
        self.model_type = model_type
        self.batch_size = batch_size
        self.backend = backend
        
        # 自动选择后端
        if backend == 'auto':
            if 't7.5' in model_type.lower() or 'paddle' in model_type.lower():
                self.backend = 'paddle'
            else:
                self.backend = 'tensorflow'
        
        # 检查后端可用性
        if self.backend == 'tensorflow' and not TF_INFERENCE_AVAILABLE:
            raise RuntimeError("TensorFlow 后端不可用，请检查 TensorFlow 安装")
        if self.backend == 'paddle' and not PADDLE_INFERENCE_AVAILABLE:
            raise RuntimeError("PaddlePaddle 后端不可用，请检查 PaddlePaddle 安装")
        
        # 加载模型和词表
        self.model, self.vocab_data = self._load_model(print_load_info)
        self.char2idx, self.idx2char = self.vocab_data
        self.unknown_char_id = self.char2idx.get('▩', 0)
        self.temperature = 1.0

    def _load_model(self, print_load_info):
        """内部方法：加载模型和词表"""
        try:
            if self.backend == 'tensorflow':
                model, vocab_data = model_infer_tf.load(
                    ckpt_dir=self.ckpt_dir,
                    vocab=self.vocab_path,
                    BATCH_SIZE=self.batch_size,
                    model_type=self.model_type,
                    print_out=print_load_info
                )
            else:
                raise NotImplementedError("PaddlePaddle 后端的 AI 检测功能尚未实现")
            
            if print_load_info:
                print(f"✅ 模型加载成功（类型：{self.model_type}，后端：{self.backend}）")
            return model, vocab_data
        except Exception as e:
            raise RuntimeError(f"❌ 模型加载失败：{str(e)}")

    def _get_char_prob(self, full_context, target_char):
        """
        传入完整前文，计算目标字符的预测概率
        :param full_context: 完整前文（如"12"）
        :param target_char: 待预测字符（如"3"）
        :return: 预测概率（0~1）
        """
        # 完整前文转ID序列
        input_ids = [self.char2idx.get(c, self.unknown_char_id) for c in full_context]
        
        if self.backend == 'tensorflow':
            input_eval = tf.expand_dims(input_ids, 0)
            
            # 获取模型预测logits
            predictions = self.model(input_eval, training=False)
            if len(predictions.shape) == 3:
                last_logits = predictions[:, -1, :]
            else:
                last_logits = predictions
            
            # 转换为概率分布
            last_logits = last_logits / self.temperature
            probs = tf.nn.softmax(last_logits, axis=-1).numpy()[0]
        else:
            raise NotImplementedError("PaddlePaddle 后端的 AI 检测功能尚未实现")
        
        # 获取目标字符概率
        target_id = self.char2idx.get(target_char, self.unknown_char_id)
        target_prob = probs[target_id] if 0 <= target_id < len(probs) else 1e-10
        
        return max(target_prob, 1e-10)

    def detect_ai_rate(self, text):
        """
        核心方法：直接返回字符预测概率的算术平均值作为AI率
        :param text: 待检测文本
        :return: 检测结果字典
        """
        # 预处理文本
        chars = [c for c in text if c.strip()]
        if len(chars) < 2:
            return {
                "检测文本": text,
                "字符级详情": [],
                "AI率（概率平均值）": 0.0,
                "检测结论": "无法检测（文本过短/无效）"
            }
        
        # 逐字符计算预测概率（完整前文）
        char_details = []
        char_probs = []
        
        for i in range(1, len(chars)):
            full_context = chars[:i]
            target_char = chars[i]
            context_str = ''.join(full_context)
            
            prob = self._get_char_prob(context_str, target_char)
            char_probs.append(prob)
            
            char_details.append({
                "字符位置": i+1,
                "完整前文": context_str,
                "目标字符": target_char,
                "预测概率": round(prob, 6)
            })
        
        ai_rate = np.mean(char_probs) if char_probs else 0.0
        
        if ai_rate >= 0.01:
            conclusion = "高概率AI生成（概率均值≥0.01）"
        elif ai_rate >= 0.005:
            conclusion = "疑似AI生成（概率均值0.005~0.01）"
        else:
            conclusion = "低概率AI生成（概率均值<0.005）"
        
        return {
            "检测文本": text,
            "字符级详情": char_details,
            "AI率（概率平均值）": round(ai_rate, 6),
            "概率统计信息": {
                "最小概率": round(np.min(char_probs), 6),
                "最大概率": round(np.max(char_probs), 6),
                "标准差": round(np.std(char_probs), 6)
            },
            "检测结论": conclusion
        }

    def close(self):
        """释放模型资源"""
        del self.model
        gc.collect()
        if self.backend == 'tensorflow' and tf:
            tf.keras.backend.clear_session()
        print("✅ 模型资源已释放")
