# 尝试导入 TensorFlow 推理模块（T7 及以下模型需要）
try:
    from xiaothink.llm.inference.test_formal import Model as TFModel
    TF_INFERENCE_AVAILABLE = True
except Exception as e:
    TF_INFERENCE_AVAILABLE = False
    TFModel = None

# 尝试导入 PaddlePaddle 推理模块（T7.5 及以上模型需要）
try:
    from xiaothink.llm.inference_paddle import QianyanModel as PaddleModel
    PADDLE_INFERENCE_AVAILABLE = True
except Exception as e:
    PADDLE_INFERENCE_AVAILABLE = False
    PaddleModel = None


class ClassifyModel:
    """
    文本分类模型
    支持 TensorFlow（T7及以下）和 PaddlePaddle（T7.5及以上）两种后端
    """
    def __init__(self, model):
        """
        初始化分类模型
        
        Args:
            model: 已加载的模型实例（TF Model 或 PaddlePaddle QianyanModel）
        """
        self.model = model
        # 检测模型后端类型
        self.backend = 'unknown'
        if TFModel and isinstance(model, TFModel):
            self.backend = 'tensorflow'
        elif PaddleModel and hasattr(model, 'MT'):
            self.backend = 'paddle'

    def _class_mood(self, text):
        res=[]
        if '正面' in text or '积极' in text:
            res.append(1)

        if '消极' in text or '负面' in text:
            res.append(-1)
        
        if '中性' in text or '无法' in text:
            res.append(0)

        if len(res)==1:
            return res[0]
        elif len(res)>1:
            return tuple(res)

    
        if '好' in text or '正' in text and not '不好' in text:
            res.append(1)

        if '坏' in text or '负' in text or '不好' in text or '反' in text:
            res.append(-1)

        if '未知' in text or '不知道' in text or '中' in text or '平' in text:
            res.append(0)
            
        if len(res)==1:
            return res[0]
        elif len(res)>1:
            return tuple(res)
            

    def calculate_emotion_probability(self, data):
        """
        计算整段文本的积极、消极、中性情感概率
        
        参数：
            data: 元组或列表，包含每句话的情感结果（如(1, (1, 0), -1)）
                  单个元素为1（积极）、-1（消极）、0（中性）；
                  元组元素表示该句的多种可能结果（如(1,0)表示可能积极或中性）
        
        返回：
            字典，包含"积极"、"消极"、"中性"的概率（保留4位小数）
        """
        positive_total = 0.0
        negative_total = 0.0
        neutral_total = 0.0
        total_sentences = len(data)
        
        if total_sentences == 0:
            return {"积极": 0.0, "消极": 0.0, "中性": 0.0}
        
        for sentence in data:
            if isinstance(sentence, tuple):
                count_pos = sentence.count(1)
                count_neg = sentence.count(-1)
                count_neu = sentence.count(0)
                num_results = len(sentence)
                
                if num_results > 0:
                    positive_total += count_pos / num_results
                    negative_total += count_neg / num_results
                    neutral_total += count_neu / num_results
            else:
                if sentence == 1:
                    positive_total += 1.0
                elif sentence == -1:
                    negative_total += 1.0
                elif sentence == 0:
                    neutral_total += 1.0
        
        positive_prob = round(positive_total / total_sentences, 4)
        negative_prob = round(negative_total / total_sentences, 4)
        neutral_prob = round(neutral_total / total_sentences, 4)
        
        return {
            "积极": positive_prob,
            "消极": negative_prob,
            "中性": neutral_prob
        }

    
    def _with_emotion_st(self, text, max_len=8, form=1):
        self.model.clean_his()
        prompt=f'判断情感倾向："{text}"'
        pret='这段文本的情感倾向是'
        ret=self.model.chat(prompt, temp=0.001, ontime=False, pre_text=pret, max_len=max_len, form=form)
        return self._class_mood(ret)

    def emotion(self, text, max_len=8, form=1):
        text=text.replace('，','|split|').replace('\\n','|split|').replace('\n','|split|')\
              .replace('。','|split|').replace('？','|split|').replace('！','|split|')\
              .replace('...','|split|').replace('.','|split|').replace('!','|split|')\
              .replace('?','|split|').split('|split|')
        
        nums=[]
        for i in text:
            num=self._with_emotion_st(i, max_len=max_len, form=form)
            nums.append(num)

        result=self.calculate_emotion_probability(tuple(nums))
        return result


def create_classify_model(ckpt_dir, MT, vocab=None, use_patch=0, backend='auto'):
    """
    创建分类模型的便捷函数
    
    Args:
        ckpt_dir: 模型检查点目录
        MT: 模型类型
        vocab: 词汇表路径（TensorFlow 后端需要）
        use_patch: 补丁版本
        backend: 后端类型 'auto'/'tensorflow'/'paddle'
    
    Returns:
        ClassifyModel 实例
    """
    # 自动选择后端
    if backend == 'auto':
        if 't7.5' in MT.lower() or 'paddle' in MT.lower():
            backend = 'paddle'
        else:
            backend = 'tensorflow'
    
    # 创建模型
    if backend == 'tensorflow':
        if not TF_INFERENCE_AVAILABLE:
            raise RuntimeError("TensorFlow 后端不可用，请检查 TensorFlow 安装")
        model = TFModel(
            ckpt_dir=ckpt_dir,
            MT=MT,
            vocab=vocab,
            use_patch=use_patch,
        )
    elif backend == 'paddle':
        if not PADDLE_INFERENCE_AVAILABLE:
            raise RuntimeError("PaddlePaddle 后端不可用，请检查 PaddlePaddle 安装")
        model = PaddleModel(
            ckpt_dir=ckpt_dir,
            MT=MT,
        )
    else:
        raise ValueError(f"不支持的后端类型: {backend}")
    
    return ClassifyModel(model)


# 测试
if __name__=='__main__':
    # TensorFlow 示例
    if TF_INFERENCE_AVAILABLE:
        model = TFModel(
            ckpt_dir=r'G:\大模型\models\ckpt_test_t6_standard_cloud_belle',
            MT='t6_standard',
            vocab=r'E:\小思框架\论文\ganskchat\vocab_lx3.txt',
            use_patch=0,
        )
        cmodel = ClassifyModel(model)
        while True:
            inp = input('输入文本：')
            res = cmodel.emotion(inp)
            print(res)
    
    # PaddlePaddle 示例
    # if PADDLE_INFERENCE_AVAILABLE:
    #     model = PaddleModel(
    #         ckpt_dir=r'E:\server_models\t7.5\ckpt_test_t7.5_paddle_small_instruct_pro',
    #         MT='t7.5_paddle_small_instruct_pro',
    #     )
    #     cmodel = ClassifyModel(model)
    #     while True:
    #         inp = input('输入文本：')
    #         res = cmodel.emotion(inp)
    #         print(res)
