__version__ = "0.4.10"

from xiaozhi_sdk.core import XiaoZhiWebsocket  # noqa
