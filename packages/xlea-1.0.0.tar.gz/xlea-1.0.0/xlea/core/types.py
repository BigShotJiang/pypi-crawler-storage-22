from typing import TypeVar

from xlea.core.schema import Schema


TSchema = TypeVar("TSchema", bound=Schema)
