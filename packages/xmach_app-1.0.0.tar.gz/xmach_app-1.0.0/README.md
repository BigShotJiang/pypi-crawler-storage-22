
# Table of Contents

1.  [About](#org2252949)
2.  [Features](#org4195ecb)
3.  [Installation](#org3f0235c)
    1.  [Pip under user](#orgbb87e78)
4.  [Usage](#org8dba906)
    1.  [Basic Commands](#org9fdf1dc)
    2.  [Configuration and extension](#orgc666088)
        1.  [Configuration File Format](#orgdfce305)
        2.  [Custom Actions](#org5a2a21c)
5.  [License](#org6484ae6)
    1.  [Code](#org578baf0)

XMach - X(.O) (make) mach(inery).

Cross-platform task runner with current implementation in Python.


<a id="org2252949"></a>

# About

XMach is a minimalist, cross-platform task runner that allows to
define and execute custom actions through a plugin-like system.

It provides a command-line interface for running tasks, managing
configuration, and extending functionality through Python scripts.


<a id="org4195ecb"></a>

# Features

-   cross-platform task execution
-   extensible action system through python scripts
-   built-in actions (ie for listing tasks and configuration management)
-   environment variable support
-   parallel job execution support
-   plugin-like architecture with \`xmach.d\` directory


<a id="org3f0235c"></a>

# Installation


<a id="orgbb87e78"></a>

## Pip under user

    pip install --break-system-packages --user xmach-app


<a id="org8dba906"></a>

# Usage


<a id="org9fdf1dc"></a>

## Basic Commands

    # List available actions
    xmach list
    
    # Write default configuration file
    xmach write-default-config
    
    # Run custom actions
    xmach my-action arg1 arg2
    
    # Run multiple actions
    xmach action1,action2 arg1 arg2
    
    # Run with multiple jobs
    xmach my-action --jobs 4


<a id="orgc666088"></a>

## Configuration and extension

XMach looks for configuration in the \`xmach.d\` directory:

-   `xmach-config.json` - main configuration file
-   `xmach-config.example.json` - example configuration template
-   `xmach_*.py` - python files containing custom action definitions


<a id="orgdfce305"></a>

### Configuration File Format

    {
      "environment": {
        "CUSTOM_VAR": "value"
      },
      "scons_args": {
        "parameter": "value"
      }
    }


<a id="org5a2a21c"></a>

### Custom Actions

Create Python files in the `xmach.d` directory with names like `xmach_myactions.py`:

    #!/usr/bin/env python
    
    class ActionScripts(ActionScriptsBase):
        def action__my_custom_action(self, action_args: list[str] = []) -> None:
            """Action: my-custom-action"""
    
            # Run shell commands
            RunCmd.run_cmd(cmd=["echo", "Hello World"])


<a id="org6484ae6"></a>

# License


<a id="org578baf0"></a>

## Code

Code in this project is licensed under the MPL, version 2.0.

> This Source Code Form is subject to the terms of the Mozilla Public
> License, v. 2.0. If a copy of the MPL was not distributed with this
> file, You can obtain one at <http://mozilla.org/MPL/2.0/>.

