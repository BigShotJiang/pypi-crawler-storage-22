#!/usr/bin/env python3
"""
PyTorch Async Usage Example for MTier Framework

This script demonstrates various async patterns supported by the XMemBackendMTier
and XMemTensorMTier classes, including:
1. Synchronous offload/prefetch (baseline)
2. Non-blocking offload with blocking prefetch
3. Non-blocking offload with non-blocking prefetch
4. Using callbacks for async completion
5. Overlapping multiple transfers for performance
"""

import torch
import time
from xmem.xmem_backend_mtier import XMemBackendMTier


def demo_async_offload_sync_prefetch(bank_id: int):
    """
    Demo 1: Non-blocking offload with blocking prefetch.
    Useful when you want to overlap offload with other computation.
    """
    print("\n" + "="*70)
    print("DEMO 1: Async Offload + Sync Prefetch")
    print("="*70)

    backend = XMemBackendMTier()

    tensor = torch.randn(1000, 1000).cuda()
    print(f"Created tensor: shape={tensor.shape}, dtype={tensor.dtype}")

    # Non-blocking offload - returns immediately
    print("Offloading tensor (non-blocking)...")
    xt = backend.offload(tensor, bank_id=bank_id, non_blocking=True)
    print(f"  Handle status: {xt}")

    # Simulate other work while DMA is in flight
    print("Doing other work while offload is in flight...")
    time.sleep(0.01)  # Simulate computation
    print(f"  Handle ready? {xt.is_ready()}")

    # Prefetch implicitly waits for offload to complete
    print("Prefetching tensor (blocking, will wait for offload)...")
    result = xt.prefetch()

    assert torch.equal(tensor, result), "Data mismatch!"
    print(f"✓ Data integrity verified")


def demo_fully_async(bank_id: int):
    """
    Demo 2: Non-blocking offload and non-blocking prefetch.
    Maximum overlap - useful for pipelining multiple operations.
    """
    print("\n" + "="*70)
    print("DEMO 2: Fully Async (Non-blocking Offload + Prefetch)")
    print("="*70)

    backend = XMemBackendMTier()

    tensor = torch.randn(1000, 1000).cuda()
    print(f"Created tensor: shape={tensor.shape}, dtype={tensor.dtype}")

    # Non-blocking offload
    print("Offloading tensor (non-blocking)...")
    xt = backend.offload(tensor, bank_id=bank_id, non_blocking=True)
    print(f"  ✓ Offload launched (in flight...)")

    # Non-blocking prefetch, implicit wait on offload to be finished
    print("Prefetching tensor (non-blocking)...")
    xt.prefetch(non_blocking=True)
    print(f"  ✓ Prefetch launched (DMA in flight...)")

    # Simulate other work while prefetch is in flight
    print("Doing other work while prefetch is in flight...")
    time.sleep(0.01)  # Simulate computation

    # Wait for prefetch to complete and get the result
    print("Waiting for prefetch to complete...")
    result = xt.wait()
    print(f"  ✓ Prefetch completed")

    assert torch.equal(tensor, result), "Data mismatch!"
    print(f"✓ Data integrity verified")

def main():
    """
    Run all demonstrations.
    """
    print("\n" + "="*70)
    print("MTier PyTorch Async API Usage Examples")
    print("="*70)
    bank_id = 0 

    try:
        demo_async_offload_sync_prefetch(bank_id)
        demo_fully_async(bank_id)

        print("\n" + "="*70)
        print("✓ ALL DEMOS COMPLETED SUCCESSFULLY")
        print("="*70)

    except Exception as e:
        print(f"\n❌ Error: {e}")
        import traceback
        traceback.print_exc()


if __name__ == "__main__":
    main()
