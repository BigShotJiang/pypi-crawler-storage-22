import torch
import xmem

if __name__ == "__main__":
    """
    Example usage of the XMemBackendMTier class with automatic memory management.
    Note: This requires actual QDMA hardware to run successfully.
    """
    try:
        
        # Create an example torch.Tensor
        original_tensor = torch.randn(100, 100).cuda()
        print(f"Original tensor shape: {original_tensor.shape}")
        print(f"Original tensor dtype: {original_tensor.dtype}")
        print(f"Original tensor device: {original_tensor.device}")
        
        # offload the tensor to the remote device and get an XMemTensor handle
        remote_tensor = xmem.offload(original_tensor, bank_id=0)
        print(f"Tensor offloaded to remote device: {remote_tensor}")
        print(f"Remote tensor shape: {remote_tensor.shape}")
        print(f"Remote tensor dtype: {remote_tensor.dtype}")
        print(f"Remote tensor size: {remote_tensor.size} bytes")
        print(f"Remote tensor address: 0x{remote_tensor.remote_addr:x}")
        
        # From now, you can free the GPU memory with `del tensor`
        #   as it is already offloaded to the remote memory
        # In this example, we will keep it to verify the result.
        
        # prefetch the tensor back using the XMemTensor handle
        reconstructed_tensor = remote_tensor.prefetch()
        print(f"Reconstructed tensor shape: {reconstructed_tensor.shape}")
        print(f"Reconstructed tensor dtype: {reconstructed_tensor.dtype}")
        print(f"Reconstructed tensor device: {reconstructed_tensor.device}")
        
        # Verify data integrity using torch.equal()
        if torch.equal(original_tensor, reconstructed_tensor):
            print(f"SUCCESS: Original and reconstructed tensors are identical!")
        else:
            print(f"FAILURE: Data mismatch detected!")
            print(f"Original: {original_tensor}")
            print(f"Reconstructed: {reconstructed_tensor}")
            
    except Exception as e:
        print(f"Error: {e}")