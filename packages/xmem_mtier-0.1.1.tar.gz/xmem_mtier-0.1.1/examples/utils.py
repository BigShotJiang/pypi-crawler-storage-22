import xmem

print (xmem.is_available())

# Use the utility functions
if xmem.is_available():
    num_banks = xmem.mbank_count()
    for bank_id in range(num_banks):
        allocated = xmem.memory_allocated(bank_id)
        available = xmem.memory_available(bank_id)
        print(f"Bank {bank_id}: {allocated} bytes allocated, {available} bytes available")
