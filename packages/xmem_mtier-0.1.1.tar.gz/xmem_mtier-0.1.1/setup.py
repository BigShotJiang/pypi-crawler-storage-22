#!/usr/bin/env python3
"""
Setup script for xmem-mtier package.

This is a compatibility shim for older versions of pip.
Modern installations should use pyproject.toml via PEP 621.
"""

from setuptools import setup, find_packages

# All configuration is in pyproject.toml, but we explicitly specify
# critical fields here to avoid metadata reading issues
setup(
    name="xmem",
    version="0.1.0",
    packages=find_packages(where="."),
)
