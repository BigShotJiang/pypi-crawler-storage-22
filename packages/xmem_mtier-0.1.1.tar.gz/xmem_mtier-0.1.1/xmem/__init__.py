"""
xmem: High-level Python wrapper for MTier memory management with PyTorch integration

This package provides a Python interface to the MTier SDK, enabling seamless
tensor offloading to remote memory tiers with CUDA integration.
"""

from .mtier_sdk import (
    MTierError,
    MTierNotInitializedError,
    MTierOutOfMemoryError,
    MTierInvalidArgumentError,
    MTierServiceUnavailableError,
    MTierEmptyCudaContextError,
    MTierServerError,
    MTierMallocError,
    MTierStatus,
    MTierBankStatus,
)

from .xmem_backend_mtier import XMemBackendMTier
from .xmem_tensor_mtier import XMemTensorMTier
from .utils import (
    mbank_count,
    is_available,
    memory_allocated,
    memory_available,
)

# Create default backend instance for module-level convenience functions
# This internally inits mtier_sdk
_default_backend = XMemBackendMTier()


def offload(tensor, bank_id, non_blocking=False, stream=None) -> XMemTensorMTier:
    """Offload a PyTorch tensor to remote memory.
        This function doesn't free the GPU memory backed by tensor.
        `del tensor` is necessary to free it after `offload()` finishes.
        
    `xmem.offload()` requires a contiguous memory layout. 
    If you pass a non-contiguous tensor (e.g., a sliced or transposed view), 
    `xmem` automatically calls `.contiguous()` internally, 
    which allocates a temporary GPU copy of the entire tensor. 
    This can cause unexpected GPU out-of-memory errors during the offload call.
        
    Args:
        tensor (torch.Tensor): The PyTorch tensor to offload. Must be on a CUDA device.
        bank_id (int): Memory bank identifier (0 to N-1 where N is the number of banks).
        non_blocking (bool): If `True`, launches data transfer asynchronously and returns immediately.
            If `False` (default), blocks until transfer completes.
        stream (cudaStream_t): Optional CUDA stream for async transfers.
            If `None`, a new stream is created.
            Ignored when `non_blocking=False`.

    Returns:
        XMemTensorMTier: A handle to the offloaded tensor. Use this handle to
            [prefetch][xmem.XMemTensorMTier.prefetch] the tensor back.

    Raises:
        ValueError: If tensor is not a `torch.Tensor` or not on a CUDA device.
        MTierOutOfMemoryError: If remote memory allocation fails.
        MTierError: For other MTier-related errors.

    Examples:
        Synchronous offload (default):

        ```python
        import torch
        import xmem

        tensor = torch.randn(1000, 1000, device='cuda')

        # Blocks until offload completes
        remote_tensor = xmem.offload(tensor, bank_id=1)
        print("Offload complete!")

        # From now, you can free the GPU memory with `del tensor`
        #   as it is already offloaded to the remote memory
        ```

        Asynchronous offload:

        ```python
        import torch
        import xmem

        tensor = torch.randn(1000, 1000, device='cuda')

        # Returns immediately, offload happens in background
        remote_tensor = xmem.offload(tensor, bank_id=1, non_blocking=True)

        # Do other work...
        # compute_something_else()

        # Wait for offload to complete
        remote_tensor.wait()
        print("Offload complete!")
        # From now, you can free the GPU memory with `del tensor`
        #   as it is already offloaded to the remote memory
        ```

        Distributing tensors across multiple banks:

        ```python
        import torch
        import xmem

        tensors = [torch.randn(1000, 1000, device='cuda') for _ in range(4)]
        num_banks = xmem.mbank_count()

        remote_tensors = []
        for i, tensor in enumerate(tensors):
            bank_id = i % num_banks  # Round-robin across banks
            remote_tensor = xmem.offload(tensor, bank_id=bank_id)
            remote_tensors.append(remote_tensor)
        ```
    """
    return _default_backend.offload(tensor, bank_id, non_blocking, stream)


def get_default_backend():
    """
    Get the default XMemBackendMTier instance.

    Returns:
        The default XMemBackendMTier instance used by module-level functions.
    """
    return _default_backend

__version__ = "0.1.0"
__all__ = [
    # Main classes
    "XMemBackendMTier",
    "XMemTensorMTier",

    # Exceptions
    "MTierError",
    "MTierNotInitializedError",
    "MTierOutOfMemoryError",
    "MTierInvalidArgumentError",
    "MTierServiceUnavailableError",
    "MTierEmptyCudaContextError",
    "MTierServerError",
    "MTierMallocError",

    # to hide XMemBackendMTier from a user
    "offload",
    "get_default_backend",

    # Utility functions
    "mbank_count",
    "is_available",
    "memory_allocated",
    "memory_available",
]
