"""
Python interface for the MTier SDK.

This module provides a Python wrapper for the MTier C API, which manages
memory tiers with CUDA integration.
"""

import ctypes
import os
from typing import Optional, Tuple
from pathlib import Path


# Return code constants
MTIER_SUCCESS = 0
MTIER_FAILURE = -1
MTIER_NOT_INITIALIZED = -2
MTIER_OUT_OF_MEMORY = -3
MTIER_INVALID_ARGUMENT = -4
MTIER_SERVICE_UNAVAILABLE = -5
MTIER_EMPTY_CUDA_CONTEXT = -6
MTIER_SERVER_ERROR = -7
MTIER_MALLOC_ERROR = -8


class MTierError(Exception):
    """Base exception for all MTier errors.

    All MTier exceptions inherit from this class, making it easy to
    catch all MTier-related errors with a single `except MTierError` clause.
    """
    pass


class MTierNotInitializedError(MTierError):
    """MTier SDK is not initialized.

    Raised when an MTier operation is attempted before the SDK has been
    initialized.
    """
    pass


class MTierOutOfMemoryError(MTierError):
    """Remote memory allocation failed (out of memory).

    Raised when there is not enough memory available in the requested
    memory bank to fulfill the allocation.
    """
    pass


class MTierInvalidArgumentError(MTierError):
    """Invalid argument passed to an MTier function.

    Raised when an argument value is outside the valid range, such as
    an invalid `bank_id`.
    """
    pass


class MTierServiceUnavailableError(MTierError):
    """MTier service is not available or not running.

    Raised when the MTier service cannot be reached. Use
    [xmem.is_available()][xmem.is_available] to check availability
    before operations.
    """
    pass


class MTierEmptyCudaContextError(MTierError):
    """CUDA context is not properly initialized.

    Raised when a CUDA context is required but has not been set up.
    Ensure a CUDA device is selected before calling MTier functions.
    """
    pass


class MTierServerError(MTierError):
    """Error occurred on the MTier server side.

    Raised when the MTier server encounters an internal error while
    processing a request.
    """
    pass


class MTierMallocError(MTierError):
    """Memory allocation failed on remote device.

    Raised when the low-level memory allocation on the remote device fails.
    """
    pass


# Map return codes to exceptions
_ERROR_MAP = {
    MTIER_FAILURE: MTierError,
    MTIER_NOT_INITIALIZED: MTierNotInitializedError,
    MTIER_OUT_OF_MEMORY: MTierOutOfMemoryError,
    MTIER_INVALID_ARGUMENT: MTierInvalidArgumentError,
    MTIER_SERVICE_UNAVAILABLE: MTierServiceUnavailableError,
    MTIER_EMPTY_CUDA_CONTEXT: MTierEmptyCudaContextError,
    MTIER_SERVER_ERROR: MTierServerError,
    MTIER_MALLOC_ERROR: MTierMallocError,
}


# C structures
class MTierStatus(ctypes.Structure):
    """Pool status information."""
    _fields_ = [
        ("status", ctypes.c_int),          # 0=running, non-zero=error
        ("num_banks", ctypes.c_int),
        ("bank_size", ctypes.c_uint64),    # in bytes
    ]


class MTierBankStatus(ctypes.Structure):
    """Per-bank status information."""
    _fields_ = [
        ("bank_id", ctypes.c_int),
        ("total_memory", ctypes.c_uint64),      # in bytes
        ("available_memory", ctypes.c_uint64),  # in bytes
    ]


class MTierSDK:
    """
    Python wrapper for the MTier SDK.

    This class provides a Pythonic interface to the MTier C API for managing
    memory tiers with CUDA integration.

    Example:
        >>> sdk = MTierSDK()
        >>> sdk.init()
        >>> status = sdk.get_status()
        >>> print(f"Number of banks: {status.num_banks}")
        >>> ptr = sdk.malloc(bank_id=0, size=1024*1024)
        >>> sdk.free(ptr)
    """

    def __init__(self, lib_path: Optional[str] = None):
        """
        Initialize the MTier SDK wrapper.

        Args:
            lib_path: Path to the libmtier_sdk.so library. If None, searches
                     in standard locations and the current directory.
        """
        if lib_path is None:
            # Try to find the library in common locations
            search_paths = [
                # Current directory
                "./libmtier.so",
                # Same directory as this Python file
                str(Path(__file__).parent / "libmtier.so"),
                # Build directory
                str(Path(__file__).parent / "build" / "libmtier.so"),
                # System library paths (LD_LIBRARY_PATH will be searched)
                "libmtier.so",
            ]

            for path in search_paths:
                try:
                    self._lib = ctypes.CDLL(path)
                    break
                except OSError:
                    continue
            else:
                raise FileNotFoundError(
                    "Could not find libmtier.so. Please specify lib_path "
                    "or ensure the library is in your LD_LIBRARY_PATH."
                )
        else:
            self._lib = ctypes.CDLL(lib_path)

        self._setup_functions()

    def _setup_functions(self):
        """Configure the ctypes function signatures."""
        # mTierInit
        self._lib.mTierInit.argtypes = []
        self._lib.mTierInit.restype = ctypes.c_int

        # mTierGetStatus
        self._lib.mTierGetStatus.argtypes = [ctypes.POINTER(MTierStatus)]
        self._lib.mTierGetStatus.restype = ctypes.c_int

        # mTierGetBankStatus
        self._lib.mTierGetBankStatus.argtypes = [
            ctypes.c_int,
            ctypes.POINTER(MTierBankStatus)
        ]
        self._lib.mTierGetBankStatus.restype = ctypes.c_int

        # mTierMalloc
        self._lib.mTierMalloc.argtypes = [
            ctypes.c_int,
            ctypes.c_size_t,
            ctypes.POINTER(ctypes.c_void_p)
        ]
        self._lib.mTierMalloc.restype = ctypes.c_int

        # mTierFree
        self._lib.mTierFree.argtypes = [ctypes.c_void_p]
        self._lib.mTierFree.restype = ctypes.c_int

        # mTierGetLogs
        self._lib.mTierGetLogs.argtypes = [
            ctypes.c_char_p,
            ctypes.c_size_t,
            ctypes.POINTER(ctypes.c_size_t)
        ]
        self._lib.mTierGetLogs.restype = ctypes.c_int

        # mTierResetAll
        self._lib.mTierResetAll.argtypes = []
        self._lib.mTierResetAll.restype = ctypes.c_int

        # mTierGetLastError
        self._lib.mTierGetLastError.argtypes = []
        self._lib.mTierGetLastError.restype = ctypes.c_char_p

    def _check_error(self, return_code: int):
        """
        Check return code and raise appropriate exception if needed.

        Args:
            return_code: The return code from a C function call.

        Raises:
            MTierError or a subclass if return_code indicates an error.
        """
        if return_code == MTIER_SUCCESS:
            return

        # Get the last error message
        error_msg = self.get_last_error()

        # Raise the appropriate exception
        exception_class = _ERROR_MAP.get(return_code, MTierError)
        raise exception_class(f"MTier error (code {return_code}): {error_msg}")

    def init(self):
        """
        Initialize the MTier SDK.

        Must be called before using any other SDK functions.

        Raises:
            MTierError: If initialization fails.
        """
        ret = self._lib.mTierInit()
        self._check_error(ret)

    def get_status(self) -> MTierStatus:
        """
        Get overall pool status.

        Returns:
            MTierStatus object containing:
                - status: 0 if running, non-zero if error
                - num_banks: Number of memory banks
                - bank_size: Size of each bank in bytes

        Raises:
            MTierError: If the operation fails.
        """
        status = MTierStatus()
        ret = self._lib.mTierGetStatus(ctypes.byref(status))
        self._check_error(ret)
        return status

    def get_bank_status(self, bank_id: int) -> MTierBankStatus:
        """
        Get status for a specific memory bank.

        Args:
            bank_id: The ID of the bank to query.

        Returns:
            MTierBankStatus object containing:
                - bank_id: The bank ID
                - total_memory: Total memory in bytes
                - available_memory: Available memory in bytes

        Raises:
            MTierError: If the operation fails.
        """
        status = MTierBankStatus()
        ret = self._lib.mTierGetBankStatus(bank_id, ctypes.byref(status))
        self._check_error(ret)
        return status

    def malloc(self, bank_id: int, size: int) -> int:
        """
        Allocate memory from a specific bank.

        This function allocates memory in the current CUDA context. Make sure
        to set the appropriate CUDA device before calling this function using
        cudaSetDevice().

        Note: This function is NOT thread-safe.

        Args:
            bank_id: The ID of the bank to allocate from.
            size: Number of bytes to allocate (will be rounded up to GPU
                 allocation granularity).

        Returns:
            Device pointer (as Python int) to the allocated memory.

        Raises:
            MTierError: If allocation fails.
        """
        d_ptr = ctypes.c_void_p()
        ret = self._lib.mTierMalloc(bank_id, size, ctypes.byref(d_ptr))
        self._check_error(ret)
        return d_ptr.value

    def free(self, d_ptr: int):
        """
        Free a previously allocated memory region.

        Note: This function is NOT thread-safe.

        Args:
            d_ptr: Device pointer (as Python int) returned by malloc().

        Raises:
            MTierError: If freeing fails.
        """
        ret = self._lib.mTierFree(ctypes.c_void_p(d_ptr))
        self._check_error(ret)

    def get_logs(self, max_size: int = 65536) -> str:
        """
        Get server logs.

        Args:
            max_size: Maximum number of bytes to retrieve (default 64KB).

        Returns:
            Log string. If the full log is larger than max_size, the output
            will be truncated.

        Raises:
            MTierError: If the operation fails.
        """
        buf = ctypes.create_string_buffer(max_size)
        log_size = ctypes.c_size_t()
        ret = self._lib.mTierGetLogs(buf, max_size, ctypes.byref(log_size))
        self._check_error(ret)

        # Return the log as a string (decode from bytes)
        return buf.value.decode('utf-8', errors='replace')

    def reset_all(self):
        """
        Reset all server-side allocations.

        WARNING: This releases ALL physical memory on the server. Connected
        clients will NOT be notified and their device pointers become invalid.

        USE WITH EXTREME CAUTION: If you have more than one process using the
        server, no memory safety is guaranteed after this call until they are
        restarted.

        Raises:
            MTierError: If the operation fails.
        """
        ret = self._lib.mTierResetAll()
        self._check_error(ret)

    def get_last_error(self) -> str:
        """
        Get the last error message.

        Returns:
            Error message string.
        """
        error_ptr = self._lib.mTierGetLastError()
        if error_ptr:
            return error_ptr.decode('utf-8', errors='replace')
        return "No error message available"


# Convenience functions for a simpler API
_global_sdk: Optional[MTierSDK] = None


def get_sdk(lib_path: Optional[str] = None) -> MTierSDK:
    """
    Get or create the global MTierSDK instance.

    Args:
        lib_path: Path to the library (only used on first call).

    Returns:
        The global MTierSDK instance.
    """
    global _global_sdk
    if _global_sdk is None:
        _global_sdk = MTierSDK(lib_path)
    return _global_sdk


def init(lib_path: Optional[str] = None):
    """Initialize the MTier SDK using the global instance."""
    sdk = get_sdk(lib_path)
    sdk.init()


def get_status() -> MTierStatus:
    """Get overall pool status using the global instance."""
    return get_sdk().get_status()


def get_bank_status(bank_id: int) -> MTierBankStatus:
    """Get bank status using the global instance."""
    return get_sdk().get_bank_status(bank_id)


def malloc(bank_id: int, size: int) -> int:
    """Allocate memory using the global instance."""
    return get_sdk().malloc(bank_id, size)


def free(d_ptr: int):
    """Free memory using the global instance."""
    get_sdk().free(d_ptr)


def get_logs(max_size: int = 65536) -> str:
    """Get server logs using the global instance."""
    return get_sdk().get_logs(max_size)


def reset_all():
    """Reset all allocations using the global instance."""
    get_sdk().reset_all()


def get_last_error() -> str:
    """Get last error message using the global instance."""
    return get_sdk().get_last_error()
