"""
Utility functions for xmem package.

Provides high-level convenience functions for common MTier operations.
"""

from .mtier_sdk import (
    get_status,
    get_bank_status,
    MTierError,
    MTierNotInitializedError,
)


def mbank_count() -> int:
    """Get the number of available memory banks.

    Returns:
        int: Number of memory banks available.

    Raises:
        MTierError: If the SDK is not initialized or the operation fails.

    Examples:
        ```python
        import xmem
        import torch

        num_banks = xmem.mbank_count()
        print(f"Available memory banks: {num_banks}")

        # Initialize tensors
        tensors = []
        device = "cuda:0"
        for i in range(10):
            # Create random tensors 
            tensor = torch.randn(1000, 1000, device=device)  
            tensors.append(tensor)

        # Use banks in round-robin fashion
        for i in range(10):
            bank_id = i % num_banks
            remote_tensor = xmem.offload(tensors[i], bank_id=bank_id)
        ```
    """
    status = get_status()
    return status.num_banks


def is_available() -> bool:
    """Check if MTier is available and initialized.

    Returns:
        bool: `True` if MTier is available and running, `False` otherwise.

    Examples:
        ```python
        import xmem

        if xmem.is_available():
            print("MTier is ready to use")
            # Proceed with offloading
        else:
            print("MTier is not available")
            # Fall back to alternative memory management
        ```
    """
    try:
        status = get_status()
        return status.status == 0  # 0 means running
    except (MTierError, MTierNotInitializedError):
        return False


def memory_allocated(bank_id: int) -> int:
    """Get the amount of allocated memory in a specific bank.

    Args:
        bank_id (int): The ID of the memory bank to query.

    Returns:
        int: Amount of allocated memory in bytes.

    Raises:
        MTierError: If the operation fails or bank_id is invalid.

    Examples:
        ```python
        import xmem

        allocated = xmem.memory_allocated(bank_id=0)
        print(f"Bank 0 allocated memory: {allocated / (1024**3):.2f} GB")

        # Monitor memory usage across all banks
        for bank_id in range(xmem.mbank_count()):
            allocated = xmem.memory_allocated(bank_id)
            print(f"Bank {bank_id}: {allocated / (1024**3):.2f} GB allocated")
        ```
    """
    bank_status = get_bank_status(bank_id)
    return bank_status.total_memory - bank_status.available_memory


def memory_available(bank_id: int) -> int:
    """Get the amount of available memory in a specific bank.

    Args:
        bank_id (int): The ID of the memory bank to query.

    Returns:
        int: Amount of available memory in bytes.

    Raises:
        MTierError: If the operation fails or bank_id is invalid.

    Examples:
        ```python
        import xmem
        import torch

        available = xmem.memory_available(bank_id=0)
        print(f"Bank 0 available memory: {available / (1024**3):.2f} GB")
        tensor = torch.randn(10000, 10000, device="cuda:0")

        # Check if there's enough space before offloading
        tensor_size = tensor.element_size() * tensor.nelement()
        if xmem.memory_available(bank_id=0) >= tensor_size:
            remote_tensor = xmem.offload(tensor, bank_id=0)
        else:
            print("Not enough memory in bank 0")
        ```
    """
    bank_status = get_bank_status(bank_id)
    return bank_status.available_memory
