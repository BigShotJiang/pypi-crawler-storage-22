#!/usr/bin/env python3
"""
A module that implements offload/prefetch PyTorch tensors to/from Netpreme XMem

A user manages the offloaded tensor through a remote memory handle,
XMemTensorMTier which is implemented in xmem_tensor_mtier.py.
"""
import torch
import ctypes
import io
from ctypes import c_int, c_void_p, c_uint64, c_size_t, c_bool
from ctypes.util import find_library
from typing import Optional, Dict, Any, List
from .xmem_tensor_mtier import XMemTensorMTier
import time
import json
import os
from . import mtier_sdk
from pathlib import Path
from cuda.bindings import runtime as cudart
from concurrent.futures import ThreadPoolExecutor,Future
import threading


# Configure library path with environment variable support
SHARED_LIB_PATH = os.getenv('MTIER_LIB_PATH', '/usr/local/lib/libmtier.so')
if not Path(SHARED_LIB_PATH).exists():
    raise OSError(
        f"MTier shared library not found at {SHARED_LIB_PATH}.\n"
        f"Please ensure libmtier.so is installed or set the MTIER_LIB_PATH environment variable."
    )

class XMemBackendMTier:
    """
    A class that implementes data transfer between Netpreme XMem and GPUs.
    
    This class leverages mtier_sdk, a Python wrapper for C++ mtier_sdk API,
    to execute control plane operations on the Netpreme XMem.
    The MTier server must be configured before initialization.
    """
    
    def __init__(self, max_async_workers=4):
        """
        Args:
            max_async_workers: A number of threads to handle async data transfer
            
        Raises:
            FileNotFoundError: If the shared library file is not found
            OSError: If the shared library file cannot be loaded
            MTierError: If the MTier server is not available
            
        """        
        mtier_sdk.init(SHARED_LIB_PATH)
        self._executor = ThreadPoolExecutor(
            max_workers=max_async_workers,
            thread_name_prefix="xmem-async",
        )
        
    
    def __del__(self) -> None:
        """
        Destructor to ensure proper cleanup
        """
        self._executor.shutdown(wait=True)
          
    def offload(self, tensor: torch.Tensor, bank_id: int,
                non_blocking: bool = False, stream=None) -> XMemTensorMTier:
        """
        Transfer a tensor to a specified XMem memory bank (bank_id)

        It allocates memory on the specified memory bank and
        performs data transfer. It returns a remote memory handle XMemTensorMTier,
        which a user can prefetch a tensor from the handle or wait on the data transfer completion
        (see examples for the usage).
        
        `xmem.offload()` requires a contiguous memory layout. 
        If you pass a non-contiguous tensor (e.g., a sliced or transposed view), 
        `xmem` automatically calls `.contiguous()` internally, 
        which allocates a temporary GPU copy of the entire tensor. 
        This can cause unexpected GPU out-of-memory errors during the offload call.

        Args:
            tensor: torch.Tensor to write to the remote device. Must be on a GPU (cuda).
            bank_id: XMem memory bank identifier for allocation.
            non_blocking: If True, launches the data transfer asynchronously
                            and returns a remote memory handle (XMemTensorMTier).
                            Call .wait() on the handle to block until completion.
                          If False (default), blocks until the data transfer finishes.
            stream: Optional CUDA stream for async transfers. Ignored when
                    non_blocking=False. If None, a new CUDA stream is created.

        Returns:
            XMemTensorMTier handle. If non_blocking=True the handle starts in a
            "pending" state; call wait() before issuing prefetch().

        Raises:
            ValueError: If tensor is not a torch.Tensor or not on a GPU (cuda).
            RuntimeError: If the data transfer fails.
            MTierError: If memory allocation fails on the specified memory bank.

        Example (blocking — default):
            >>> xt = backend.offload(tensor, bank_id=1)
            >>> tensor = xt.prefetch()

        Example (non-blocking):
            >>> xt = backend.offload(tensor, bank_id=1, non_blocking=True)
            >>> # ... overlap with other work ...
            >>> xt.wait() # this can be skipped as prefetch will call it internally
            >>> tensor = xt.prefetch()
        """
        if not isinstance(tensor, torch.Tensor):
            raise ValueError("Data must be a torch.Tensor")
        
        

        # Check if tensor is on a GPU (cuda)
        if not tensor.is_cuda:
            raise ValueError(f"Tensor must be on a GPU (cuda device), but got device: {tensor.device}")

        # Ensure contiguous memory layout for correct cudaMemcpy semantics
        if not tensor.is_contiguous():
            print(f"Warning: a tensor is not contiguous. Making a contiguous copy "
                  f"consumes extra GPU memory equal to the tensor size.")
            tensor = tensor.contiguous()

        tensor_shape = tensor.shape
        tensor_dtype = tensor.dtype
        tensor_device = tensor.device
        size = tensor.element_size() * tensor.nelement()

        print(f"Offloading tensor of shape {tensor_shape}, dtype {tensor_dtype}, "
              f"size {size} bytes to MTier bank {bank_id} (non_blocking={non_blocking})")

        remote_ptr = mtier_sdk.malloc(bank_id, size)

        if not non_blocking:
            # ---- Synchronous path ----
            err, = cudart.cudaMemcpy(
                remote_ptr,
                tensor.data_ptr(),
                size,
                cudart.cudaMemcpyKind.cudaMemcpyDeviceToDevice,
            )
            if err != cudart.cudaError_t.cudaSuccess:
                raise RuntimeError(
                    f"cudaMemcpy failed: {cudart.cudaGetErrorString(err)}"
                )

            return XMemTensorMTier(
                backend=self,
                remote_addr=remote_ptr,
                size=size,
                shape=tensor_shape,
                dtype=tensor_dtype,
                device=tensor_device,
            )

        # ---- Async path ----
        owns_stream = False
        if stream is None:
            err, stream = cudart.cudaStreamCreate()
            if err != cudart.cudaError_t.cudaSuccess:
                raise RuntimeError(
                    f"cudaStreamCreate failed: {cudart.cudaGetErrorString(err)}"
                )
            owns_stream = True

        err, = cudart.cudaMemcpyAsync(
            remote_ptr,
            tensor.data_ptr(),
            size,
            cudart.cudaMemcpyKind.cudaMemcpyDeviceToDevice,
            stream,
        )
        if err != cudart.cudaError_t.cudaSuccess:
            if owns_stream:
                cudart.cudaStreamDestroy(stream)
            raise RuntimeError(
                f"cudaMemcpyAsync failed: {cudart.cudaGetErrorString(err)}"
            )

        def _sync_stream():
            """Submitted to the thread pool; blocks on stream completion."""
            try:
                err, = cudart.cudaStreamSynchronize(stream)
                if err != cudart.cudaError_t.cudaSuccess:
                    raise RuntimeError(
                        f"cudaStreamSynchronize failed: "
                        f"{cudart.cudaGetErrorString(err)}"
                    )
            finally:
                if owns_stream:
                    cudart.cudaStreamDestroy(stream)

        # Submit to the shared thread pool instead of spawning a thread
        future = self._executor.submit(_sync_stream)

        return XMemTensorMTier(
            backend=self,
            remote_addr=remote_ptr,
            size=size,
            shape=tensor_shape,
            dtype=tensor_dtype,
            device=tensor_device,
            future=future,
        ) 
            
    def _prefetch_by_addr_tensor(self, remote_addr: int, size: int, dst_tensor: torch.Tensor):
        """
        Transfer data from a specified remote_addr to dst_tensor.
        
        This method supposed to be used in the XMemTensorMTier class.
        remote_addr should belong to one of XMem memory banks, and dst_tensor
        must be on a GPU. 
        
        Args:
            remote_addr: Remote memory address to read from
            size: Size of data to read in bytes
            dst_tensor: A tensor 
            
        Returns:
            torch.Tensor reconstructed from the remote device data
            
        Raises:
            RuntimeError: If the data transfer fails.
        """
        # if not self.dev_h:
        #     raise RuntimeError("Device not initialized")

        # Perform the DMA read operation
        err, = cudart.cudaMemcpy(
            dst_tensor.data_ptr(), 
            remote_addr, 
            size, 
            cudart.cudaMemcpyKind.cudaMemcpyDeviceToDevice
        )
        if err != cudart.cudaError_t.cudaSuccess:
            raise RuntimeError(f"prefetch failed with error code {err}")
        
        return dst_tensor

    def _prefetch_by_addr_tensor_async(
        self, remote_addr: int, size: int, 
        dst_tensor: torch.Tensor, stream=None
    ) -> Future:
        """
        Asynchronous version of _prefetch_by_addr_tensor.
        
        remote_addr should belong to one of XMem memory banks, and dst_tensor
        must be on a GPU. 
        Args:
            remote_addr: Remote memory address to read from
            size: Size of data to read in bytes
            dst_tensor: Destination tensor to copy data into
            stream: Optional CUDA stream to use. If None, creates a new stream.

        Returns:
            Future[torch.Tensor]: Future that will contain the reconstructed tensor

        Raises:
            RuntimeError: If data transfer fails.
        """
        owns_stream = False
        if stream is None:
            err, stream = cudart.cudaStreamCreate()
            if err != cudart.cudaError_t.cudaSuccess:
                raise RuntimeError(f"cudaStreamCreate failed: {cudart.cudaGetErrorString(err)}")
            owns_stream = True

        err, = cudart.cudaMemcpyAsync(
            dst_tensor.data_ptr(),
            remote_addr,
            size,
            cudart.cudaMemcpyKind.cudaMemcpyDeviceToDevice,
            stream,
        )
        if err != cudart.cudaError_t.cudaSuccess:
            if owns_stream:
                cudart.cudaStreamDestroy(stream)
            raise RuntimeError(f"cudaMemcpyAsync failed: {cudart.cudaGetErrorString(err)}")

        def _sync_and_return():
            """Submitted to the thread pool; blocks on stream completion."""
            try:
                err, = cudart.cudaStreamSynchronize(stream)
                if err != cudart.cudaError_t.cudaSuccess:
                    raise RuntimeError(
                        f"cudaStreamSynchronize failed: "
                        f"{cudart.cudaGetErrorString(err)}"
                    )
                return dst_tensor
            finally:
                if owns_stream:
                    cudart.cudaStreamDestroy(stream)

        return self._executor.submit(_sync_and_return)

# Example usage and testing
if __name__ == "__main__":
    """
    Example usage of the XMemBackendMTier class with automatic memory management.
    """
    try:
        
        # Initialize the backend with the current mode
        backend = XMemBackendMTier()
        
        # Create an example torch.Tensor
        original_tensor = torch.randn(100, 100).cuda()
        print(f"Original tensor shape: {original_tensor.shape}")
        print(f"Original tensor dtype: {original_tensor.dtype}")
        print(f"Original tensor device: {original_tensor.device}")
        
        # offload the tensor to the remote device and get an XMemTensor handle
        remote_tensor = backend.offload(original_tensor, bank_id=1)
        print(f"Tensor offloaded to remote device: {remote_tensor}")
        print(f"Remote tensor shape: {remote_tensor.shape}")
        print(f"Remote tensor dtype: {remote_tensor.dtype}")
        print(f"Remote tensor size: {remote_tensor.size} bytes")
        print(f"Remote tensor address: 0x{remote_tensor.remote_addr:x}")
        
        # prefetch the tensor back using the XMemTensor handle
        reconstructed_tensor = remote_tensor.prefetch()
        print(f"Reconstructed tensor shape: {reconstructed_tensor.shape}")
        print(f"Reconstructed tensor dtype: {reconstructed_tensor.dtype}")
        print(f"Reconstructed tensor device: {reconstructed_tensor.device}")
        
        # Verify data integrity using torch.equal()
        if torch.equal(original_tensor, reconstructed_tensor):
            print(f"SUCCESS: Original and reconstructed tensors are identical!")
        else:
            print(f"FAILURE: Data mismatch detected!")
            print(f"Original: {original_tensor}")
            print(f"Reconstructed: {reconstructed_tensor}")
            
    except Exception as e:
        print(f"Error: {e}")
