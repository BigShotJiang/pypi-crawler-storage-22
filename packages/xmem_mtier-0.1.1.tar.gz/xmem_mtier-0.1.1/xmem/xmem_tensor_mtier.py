import torch
from typing import TYPE_CHECKING, Union
from concurrent.futures import Future
from . import mtier_sdk

# Use TYPE_CHECKING to avoid circular imports
if TYPE_CHECKING:
    from xmem_backend_mtier import XMemBackendMTier

class XMemTensorMTier:
    """A handle to a tensor stored in remote memory.

    Returned by [xmem.offload()][xmem.offload]. This class encapsulates metadata
    about a tensor that has been offloaded to remote memory and provides methods
    to retrieve it.
    """

    def __init__(self, 
                 backend: 'XMemBackendMTier', 
                 remote_addr: int, 
                 size: int,
                 shape: torch.Size, 
                 dtype: torch.dtype, 
                 device: torch.device,
                 future: Future = None,
        ):
        """
        Args:
            backend: Reference to the XMemBackendMTier instance
            remote_addr: Remote memory address where the tensor is stored
            size: Size of the tensor data in bytes
            shape: Original tensor shape
            dtype: Original tensor dtype
            device: Original tensor device (where it was located before offloading)
            future: Optional Future for async operations. If None, the handle
                    is considered immediately ready.
        """
        self._backend = backend
        self._remote_addr = remote_addr
        self._size = size
        self._shape = shape
        self._dtype = dtype
        self._device = device # where the tensor was located before offloading
        self._future = future
        self._result = None  # Stores the prefetch result for non-blocking prefetch
    
    def __del__(self):
        # Wait for any pending async operation to complete first
        if self._future is not None and not self._future.done():
            try:
                self._future.result(timeout=30)
            except Exception:
                pass  # Ignore errors during cleanup
        if self._remote_addr:
            self._free()

    # ------------------------------------------------------------------
    # Async methods
    # ------------------------------------------------------------------

    def wait(self, timeout: float | None = None):
        """Block until the pending async operation completes.

        For synchronously-created handles or handles whose async operation
        has already completed, this is a no-op.

        Args:
            timeout (float | None): Maximum seconds to wait. `None` means wait indefinitely.

        Returns:
            torch.Tensor: If waiting on a non-blocking prefetch.
            XMemTensorMTier: (self) if waiting on a non-blocking offload.

        Raises:
            TimeoutError: If the operation does not complete within the timeout.

        Examples:
            Wait for async offload:

            ```python
            remote_tensor = xmem.offload(tensor, bank_id=1, non_blocking=True)
            remote_tensor.wait()  # Blocks until offload completes
            ```

            Wait for async prefetch with timeout:

            ```python
            remote_tensor.prefetch(non_blocking=True)
            try:
                tensor = remote_tensor.wait(timeout=5.0)  # Wait up to 5 seconds
            except TimeoutError:
                print("Prefetch took too long!")
            ```
        """

        # no-op if there's no pending async transfer
        if self._future is None:
            return self._result if self._result is not None else self

        try:
            result = self._future.result(timeout=timeout)
        except TimeoutError:
            raise TimeoutError(
                f"Async operation did not complete within {timeout}s"
            )

        self._future = None

        # If the future resolved with a tensor (non-blocking prefetch),
        # store and return it.
        if isinstance(result, torch.Tensor):
            self._result = result
            return result

        return self

    def is_ready(self) -> bool:
        """Check if any async operation is complete and the handle is ready.

        Returns:
            bool: `True` if no async operation is in flight, `False` if an
                async operation is still pending.

        Examples:
            ```python
            remote_tensor = xmem.offload(tensor, bank_id=1, non_blocking=True)

            if remote_tensor.is_ready():
                print("Offload is complete!")
            else:
                print("Offload is still in progress...")
            ```
        """
        if self._future is None:
            return True

        # Check if the async op is done
        if self._future.done():
            self.wait()
            return True
        return False

    def add_done_callback(self, fn):
        """Register a callback to be invoked when the async operation completes.

        For already-ready handles, the callback fires immediately.

        Args:
            fn (callable): Callback function that receives the `XMemTensorMTier`
                handle as its argument.

        Examples:
            ```python
            def on_offload_complete(remote_tensor):
                print(f"Offload completed: {remote_tensor}")

            remote_tensor = xmem.offload(tensor, bank_id=1, non_blocking=True)
            remote_tensor.add_done_callback(on_offload_complete)
            ```
        """
        if self._future is None:
            fn(self)
        else:
            self._future.add_done_callback(lambda _: fn(self))

    def _ensure_ready(self):
        """Internal guard — blocks until any pending operation is done."""
        if self._future is not None:
            self.wait()

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        if self._future is not None and not self._future.done():
            try:
                self._future.result(timeout=30)
            except Exception:
                pass
        return False

    # ------------------------------------------------------------------
    # Properties
    # ------------------------------------------------------------------

    @property
    def shape(self) -> torch.Size:
        """Shape of the original tensor."""
        return self._shape

    @property
    def dtype(self) -> torch.dtype:
        """Data type of the original tensor."""
        return self._dtype

    @property
    def size(self) -> int:
        """Size of the tensor in bytes."""
        return self._size

    @property
    def remote_addr(self) -> int:
        """Remote memory address where tensor is stored."""
        return self._remote_addr

    @property
    def device(self) -> torch.device:
        """Original device of the tensor before offloading."""
        return self._device

    # ------------------------------------------------------------------
    # Prefetch
    # ------------------------------------------------------------------

    def prefetch(self, dst_tensor=None, device=None,
                 reuse=False, non_blocking=False, stream=None) -> Union[torch.Tensor, 'XMemTensorMTier']:
        """Retrieve the offloaded tensor from remote memory back to GPU.

        If this handle has a pending async offload, prefetch will implicitly
        wait for it to complete before starting the read.

        Args:
            dst_tensor (torch.Tensor | None): Optional pre-allocated destination tensor.
                If `None`, a new tensor is allocated.
            device (str | torch.device | None): Device for the destination tensor. If `None`,
                uses the original device.
            reuse (bool): If `False` (default), frees remote memory after prefetch.
                If `True`, keeps the remote memory allocated for reuse.
            non_blocking (bool): If `True`, launches DMA asynchronously. If `False`
                (default), blocks until transfer completes.
            stream (cudaStream_t | None): Optional CUDA stream for async transfers.
                Ignored when `non_blocking=False`.

        Returns:
            Returns `torch.Tensor` when `non_blocking=False` (synchronous mode).   
                Returns `XMemTensorMTier` (self) when `non_blocking=True` (asynchronous mode)
                — call [wait()][xmem.XMemTensorMTier.wait] to get the tensor.

        Raises:
            RuntimeError: If data transfer fails.

        Examples:
            Synchronous prefetch (blocks until complete):

            ```python
            tensor = remote_tensor.prefetch()
            ```

            Asynchronous prefetch (returns immediately):

            ```python
            remote_tensor.prefetch(non_blocking=True)
            tensor = remote_tensor.wait()  # Wait for prefetch to complete
            ```

            Reuse remote memory (don't free after prefetch):

            ```python
            tensor = remote_tensor.prefetch(reuse=True)
            ```

            Prefetch to a different device:

            ```python
            tensor = remote_tensor.prefetch(device='cuda:1')
            ```
        """
        self._ensure_ready()

        # Use the original device if not specified
        if device is None:
            device = self._device

        if dst_tensor is None:
            dst_tensor = torch.empty(self._shape, dtype=self._dtype, device=device)

        if not non_blocking:
            # ---- Synchronous path ----
            ret = self._backend._prefetch_by_addr_tensor(
                self._remote_addr,
                self._size,
                dst_tensor,
            )
            if not reuse:
                torch.cuda.synchronize()
                self._free()
            return ret

        # ---- Async path ----
        future = self._backend._prefetch_by_addr_tensor_async(
            self._remote_addr,
            self._size,
            dst_tensor,
            stream,
        )

        if not reuse:
            def _free_on_complete(f):
                try:
                    f.result()
                    self._free()
                except Exception:
                    pass  # Transfer failed — nothing to free, error already on the future

            future.add_done_callback(_free_on_complete)

        self._future = future
        return self
    
    def _free(self):
        """
        Private helper method to free memory on the remote device.

        Args:
            remote_addr: Remote memory address to free

        Raises:
            RuntimeError: If the device is not properly initialized
            IOError: If the free operation fails
        """
        mtier_sdk.free(self._remote_addr)
        self._remote_addr = None

    # ------------------------------------------------------------------
    # Display
    # ------------------------------------------------------------------

    def __repr__(self) -> str:
        status = "pending" if self._future is not None else "ready"
        return (f"XMemTensorMTier(shape={self._shape}, dtype={self._dtype}, "
                f"offloaded_from={self._device}, size={self._size} bytes, "
                f"addr=0x{self._remote_addr:x}, status={status})")

    def __str__(self) -> str:
        status = " [pending]" if self._future is not None else ""
        return (f"XMemTensorMTier: {self._shape} {self._dtype} tensor offloaded from {self._device} "
                f"({self._size} bytes) at remote address 0x{self._remote_addr:x}{status}")