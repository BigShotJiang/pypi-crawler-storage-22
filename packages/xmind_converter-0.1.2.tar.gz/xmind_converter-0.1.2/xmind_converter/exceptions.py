"""Exception definitions"""


class XMindConverterError(Exception):
    """XMind converter base exception"""

    pass


class ParserError(XMindConverterError):
    """XMind parsing exception"""

    pass


class ConverterError(XMindConverterError):
    """Conversion exception"""

    pass


class FileFormatError(XMindConverterError):
    """File format exception"""

    pass


class FileNotFound(XMindConverterError):
    """File not found exception"""

    pass
