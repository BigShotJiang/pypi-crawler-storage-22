# coding: utf-8

__version__ = "1.0.6"

# 1.0.6: 使用click替换argparse

