# coding: utf-8

__version__ = "1.0.7"

# 1.0.7: 添加rich_console
# 1.0.6: 使用click替换argparse

