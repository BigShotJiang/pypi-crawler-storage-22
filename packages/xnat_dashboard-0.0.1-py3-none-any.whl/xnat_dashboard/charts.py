import math

from nicegui import ui
from nicegui.elements.echart import EChart

from xnat_dashboard.data_types import DashboardData


def create_heatmap() -> EChart:
    return ui.echart({
        # 'tooltip': {'formatter': '{c}'},
        'visualMap': {
            'min': 0,
            'max': 0,
            'type': 'piecewise',
            'orient': 'horizontal',
            'left': 'center',
            'top': 65
        },
        'calendar': {
            'top': 120,
            'left': 30,
            'right': 100,
            'cellSize': [16, 16],
            'itemStyle': {
                'borderWidth': 0.5
            },
            'yearLabel': {
                'show': True,
                'position': 'right',
            }
        },
    }).classes('w-full')


def create_chart() -> EChart:
    return ui.echart({
        'legend': {
            'data': [],
            'orient': 'vertical',
            'right': 'right',
            'top': 'auto',
        },
        'tooltip': {
            'show': True,
            'trigger': 'axis',
            'position': 'top',
        },
        'grid': {
            'top': 50,
            'left': 10,
            'right': 100,
            'bottom': 75,
        },
        'xAxis': {
            'type': 'time',
            'name': 'Date',
            'nameLocation': 'middle',
            'nameGap': 35,
            'boundaryGap': False,
        },
        'yAxis': [
            {
                'type': 'value',
                'name': 'Experiments',
                'nameLocation': 'middle',
                'nameGap': 35,
                'boundaryGap': False,
                'alignTicks': True,
            }
        ],
        'dataZoom': [
            {
              'type': 'slider',
              'show': True,
              'xAxisIndex': [0],
              'start': 0,
              'end': 100
            },
        ],
        'toolbox': {
            'show': True,
            'feature': {
                'dataZoom': {'yAxisIndex': "none"},
                'restore': {},
            }
        },
        'series': [
            {'type': 'line', 'step': 'start', 'name': '', 'showSymbol': False},
        ],
    }).classes('w-full h-[32rem]')


async def subjects_chart(data: DashboardData) -> ui.echart:
    df = data.subjects[['project', 'insert_date']].sort_values(by='insert_date').drop_duplicates()

    projects = sorted(data.projects.keys(), key=lambda x: x.casefold())

    series = []
    max_value = 0
    for project in projects:
        try:
            proj_df = df[df['project'] == project]
            proj_df = proj_df[['insert_date']]
            proj_df[project] = range(1, len(proj_df) + 1)
            proj_df['insert_date'] = proj_df['insert_date'].dt.strftime('%Y-%m-%d %H:%M:%S')

            series.append({
                'type': 'line',
                'step': 'start',
                'name': project,
                'showSymbol': False,
                'data': [proj_df.columns.tolist()] + proj_df.values.tolist(),
                'endLabel': {'show': True},
            })
            max_value = max(max_value, len(proj_df))
        except KeyError:  # noqa: PERF203
            pass

    max_value = 10 ** math.ceil(math.log10(max_value))

    return ui.echart({
        'legend': {
            'right': 'auto',
            'top': 'bottom',
            'orient': 'horizontal',
            'data': [x['name'] for x in series]
        },
        'tooltip': {
            'show': True,
            'trigger': 'axis',
            'position': 'top',
        },
        'grid': {
            'top': 50,
            'left': 10,
            'right': 100,
            'bottom': 105,
        },
        'xAxis': {
            'type': 'time',
            'name': 'Date',
            'nameLocation': 'middle',
            'nameGap': 35,
            'boundaryGap': False,
        },
        'yAxis': [
            {
                'type': 'log',
                'min': 1,
                'max': max_value,
                'name': 'Subjects',
                'nameLocation': 'middle',
                'nameGap': 35,
                'boundaryGap': False,
                'alignTicks': True,
            }
        ],
        'dataZoom': [
            {
                'type': 'slider',
                'show': True,
                'xAxisIndex': [0],
                'start': 0,
                'end': 100
            },
        ],
        'toolbox': {
            'show': True,
            'feature': {
                'dataZoom': {'yAxisIndex': "none"},
                'restore': {},
            }
        },
        'series': series,
    }).classes('w-full h-[calc(100vh-250px)]')


async def experiments_chart(data: DashboardData) -> ui.echart:
    series = []
    for modality, df in data.experiments.items():
        proj_df = df[['insert_date']].sort_values(by='insert_date').drop_duplicates().reset_index(drop=True)
        proj_df[modality.name] = range(1, len(proj_df) + 1)
        proj_df['insert_date'] = proj_df['insert_date'].dt.strftime('%Y-%m-%d %H:%M:%S')

        series.append({
            'type': 'line',
            'step': 'start',
            'name': modality.name,
            'showSymbol': False,
            'data': [proj_df.columns.tolist()] + proj_df.values.tolist(),
            'endLabel': {'show': True},
        })

    max_value = max(len(x) for x in data.experiments.values())
    max_value = 10 ** math.ceil(math.log10(max_value))

    return ui.echart({
        'legend': {
            'orient': 'vertical',
            'right': 'right',
            'top': 'center',
            'data': [x['name'] for x in series]
        },
        'tooltip': {
            'show': True,
            'trigger': 'axis',
            'position': 'top',
        },
        'xAxis': {
            'type': 'time',
            'name': 'Date',
            'nameLocation': 'middle',
            'nameGap': 35,
            'boundaryGap': False,
        },
        'yAxis': [
            {
                'type': 'log',
                'min': 1,
                'max': max_value,
                'name': 'Experiments',
                'nameLocation': 'middle',
                'nameGap': 35,
                'boundaryGap': False,
                'alignTicks': True,
            }
        ],
        'grid': {
            'top': 50,
            'left': 10,
            'right': 100,
            'bottom': 75,
        },
        'dataZoom': [
            {
                'type': 'slider',
                'show': True,
                'xAxisIndex': [0],
                'start': 0,
                'end': 100
            },
        ],
        'toolbox': {
            'show': True,
            'feature': {
                'dataZoom': {'yAxisIndex': "none"},
                'restore': {},
            }
        },
        'series': series,
    }).classes('w-full h-[calc(100vh-250px)]')
