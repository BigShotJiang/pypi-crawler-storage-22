""" Several data types/classes and pydantic models. """
import datetime
import enum
import re
from dataclasses import dataclass, field
from typing import Any

import pandas as pd
from nicegui import binding, ui
from pydantic import BaseModel, Field, field_validator


class Modalities(enum.Enum):
    MR = 'mr'
    CT = 'ct'
    US = 'us'
    XA = 'xa'
    NM = 'nm'


class XnatRole(str, enum.Enum):
    """ XNAT roles. """
    OWNER = 'Owners'
    MEMBER = 'Members'
    COLLABORATOR = 'Collaborators'


class XnatUser(BaseModel):
    """ XNAT user info. """
    login: str
    firstname: str
    lastname: str
    email: str
    role: XnatRole | None = Field(default=None, validation_alias='displayname')


# noinspection PyDataclass
class XnatProject(BaseModel):
    """ Project info. """
    id: str = Field(validation_alias='ID')
    description: str | None = None
    name: str
    secondary_ID: str
    experiments_count: int | None = None
    subject_count: int | None = None
    created: datetime.datetime | None = None
    keywords: list[str] = Field(default_factory=list)
    users: list[XnatUser] = Field(default_factory=list)

    @field_validator('keywords', mode='before')
    @classmethod
    def _keywords(cls, value: Any) -> list[str]:
        if len(str(value).strip()) == 0:
            return []

        keyword_list = [kw.strip() for kw in re.split(r'[.,;: ]', str(value))]

        # Filter out all empty strings, then return list
        return list(filter(None, keyword_list))


@dataclass
class DashboardData:
    experiments: dict[Modalities, pd.DataFrame] = field(default_factory=dict)
    subjects: pd.DataFrame = field(default_factory=pd.DataFrame)
    projects: dict[str, XnatProject] = field(default_factory=dict)
    users: list[XnatUser] = field(default_factory=list)
    update_timestamp: datetime.datetime = datetime.datetime(1970, 1, 1, 0, 0, 0)


class ActiveProject:
    name = binding.BindableProperty()

    def __init__(self) -> None:
        self.name = ''


@dataclass
class Charts:
    subjects: ui.echart
    subjects_heatmap: ui.echart
    experiments: ui.echart
    experiments_heatmap: ui.echart

    async def loading(self, value: bool) -> None:
        try:
            await self.experiments.run_chart_method('showLoading' if value else 'hideLoading')
        except TimeoutError:
            pass
        try:
            await self.experiments_heatmap.run_chart_method('showLoading' if value else 'hideLoading')
        except TimeoutError:
            pass
        try:
            await self.subjects.run_chart_method('showLoading' if value else 'hideLoading')
        except TimeoutError:
            pass
        try:
            await self.subjects_heatmap.run_chart_method('showLoading' if value else 'hideLoading')
        except TimeoutError:
            pass
