import asyncio
from datetime import datetime, timezone

import humanize
import pandas as pd
from humanize import naturaldate, naturaltime
from loguru import logger
from nicegui import ui

from xnat_dashboard.data_types import ActiveProject, Charts, DashboardData, Modalities


async def update_charts(charts: Charts, data: DashboardData, selected_project: ActiveProject) -> None:
    logger.debug(f'Updating project "{selected_project.name}" charts')

    await asyncio.gather(
        update_project_subjects_chart(charts.subjects, data, selected_project),
        update_project_subjects_insert_chart(charts.subjects_heatmap, data, selected_project),
        update_project_experiments_chart(charts.experiments, data, selected_project),
        update_project_experiments_insert_chart(charts.experiments_heatmap, data, selected_project)
    )


async def update_project_subjects_chart(chart: ui.echart, data: DashboardData, selected_project: ActiveProject) -> None:
    df = data.subjects
    df = df[df['project'] == selected_project.name]

    df = df[['project', 'insert_date']].sort_values(by='insert_date').drop_duplicates()
    df_onehot = pd.get_dummies(df, columns=['project'], prefix='PROJECT').drop(columns=['insert_date'])
    df = pd.concat([df[['insert_date']], df_onehot.cumsum()], axis=1, join='inner')
    df['insert_date'] = df['insert_date'].dt.strftime('%Y-%m-%d %H:%M:%S')

    chart.options['legend']['data'] = [selected_project.name]
    chart.options['series'][0]['name'] = selected_project.name

    subjects_data = [df.columns.tolist()] + df.values.tolist()

    chart.options['series'][0]['data'] = subjects_data
    chart.options['series'][0]['endLabel'] = {'show': True}

    chart.update()


async def update_project_subjects_insert_chart(chart: ui.echart, data: DashboardData, selected_project: ActiveProject) -> None:
    df = data.subjects
    df = df[df['project'] == selected_project.name]
    df = df[['project', 'insert_date']].sort_values(by='insert_date').drop_duplicates()
    # noinspection PyTypeChecker
    df['insert_date'] = df['insert_date'].dt.date

    begin = df['insert_date'].min().strftime('%Y-%m-%d')
    end = df['insert_date'].max().strftime('%Y-%m-%d')

    frequency = df.groupby(['insert_date']).size().reset_index(name='frequency')
    heatmap_data = []
    for _, row in frequency.iterrows():
        heatmap_data.append((row['insert_date'].strftime('%Y-%m-%d'), row['frequency']))

    max_frequency = frequency['frequency'].max()

    chart.options['visualMap']['max'] = max_frequency
    chart.options['calendar']['range'] = [begin, end]
    chart.options['series'] = [{
        'type': 'heatmap',
        'coordinateSystem': 'calendar',
        'data': heatmap_data,
    }]


async def update_project_experiments_chart(chart: ui.echart, data: DashboardData, selected_project: ActiveProject) -> None:
    exp_df = pd.DataFrame()
    for modality in Modalities:
        df = data.experiments[modality]
        df = df[df['project'] == selected_project.name]
        df = df[['insert_date']]
        df['modality'] = modality.name
        exp_df = pd.concat([exp_df, df])

    exp_df = exp_df.sort_values(by='insert_date')
    exp_df.reset_index(inplace=True, drop=True)

    modalities = exp_df['modality'].unique()
    if len(modalities) == 0:
        return

    try:
        df_onehot = pd.get_dummies(exp_df, columns=['modality'], prefix='MODALITY').drop(columns=['insert_date'])
        df = pd.concat([exp_df[['insert_date']], df_onehot.cumsum()], axis=1, join='inner')
    except pd.errors.InvalidIndexError as e:
        logger.error(f'{selected_project=}: {e}')
    df['insert_date'] = df['insert_date'].dt.strftime('%Y-%m-%d %H:%M:%S')

    series = []
    for modality in modalities:
        mod_df = df[['insert_date', f'MODALITY_{modality}']]

        series_data = [mod_df.columns.tolist()] + mod_df.values.tolist()

        series.append({
            'type': 'line',
            'step': 'start',
            'name': modality,
            'showSymbol': False,
            'data': series_data,
            'endLabel': {'show': True},
        })

    chart.options['series'] = series
    chart.options['legend']['data'] = modalities
    chart.update()


async def update_project_experiments_insert_chart(chart: ui.echart, data: DashboardData, selected_project: ActiveProject) -> None:
    exp_df = pd.DataFrame()
    for modality in Modalities:
        mod_df = data.experiments[modality]
        mod_df = mod_df[mod_df['project'] == selected_project.name]
        mod_df = mod_df[['project', 'insert_date']].sort_values(by='insert_date').drop_duplicates()
        mod_df['modality'] = modality.name
        # noinspection PyTypeChecker
        mod_df['insert_date'] = mod_df['insert_date'].dt.date
        exp_df = pd.concat([exp_df, mod_df])

    exp_df = exp_df.sort_values(by='insert_date')
    exp_df.reset_index(inplace=True, drop=True)

    begin = exp_df['insert_date'].min().strftime('%Y-%m-%d')
    end = exp_df['insert_date'].max().strftime('%Y-%m-%d')

    frequency = exp_df.groupby(['insert_date']).size().reset_index(name='frequency')
    heatmap_data = []
    for _, row in frequency.iterrows():
        heatmap_data.append((row['insert_date'].strftime('%Y-%m-%d'), row['frequency']))

    max_frequency = frequency['frequency'].max()

    chart.options['visualMap']['max'] = max_frequency
    chart.options['calendar']['range'] = [begin, end]
    chart.options['series'] = [{
        'type': 'heatmap',
        'coordinateSystem': 'calendar',
        'data': heatmap_data,
    }]


async def update_project_users_table(table: ui.table, data: DashboardData, selected_project: ActiveProject) -> None:
    table.clear()

    project = data.projects[selected_project.name]

    rows = []
    for val in sorted(project.users, key=lambda x: x.login):
        if val.role is None:
            continue
        rows.append({'login': val.login, 'first_name': val.firstname, 'last_name': val.lastname, 'role': val.role})

    table.rows = rows


async def update_project_info(table: ui.table, data: DashboardData, selected_project: ActiveProject) -> None:
    table.clear()

    project = data.projects[selected_project.name]

    table.rows = [
        {'key': 'Description', 'value': project.description},
        {'key': 'Subjects', 'value': humanize.intcomma(project.subject_count)},
        {'key': 'Experiments', 'value': humanize.intcomma(project.experiments_count)},
        {'key': 'Creation', 'value':
            f'{naturaltime(datetime.now(timezone.utc) - project.created)} ({naturaldate(project.created)})'},
        {'key': 'Keywords', 'value': ', '.join(x for x in project.keywords)},
    ]
