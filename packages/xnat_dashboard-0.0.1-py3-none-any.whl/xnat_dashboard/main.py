import datetime
import functools
import os
import pickle
from collections.abc import Container
from pathlib import Path
from typing import Final

import humanize
from loguru import logger
from nicegui import app, ui
from dotenv import load_dotenv

import xnat_dashboard.queries
from xnat_dashboard.data_types import ActiveProject, Charts, DashboardData, XnatProject, XnatRole, XnatUser
from xnat_dashboard.charts import (
    create_chart,
    create_heatmap,
    experiments_chart, subjects_chart
)
from xnat_dashboard.data_update import update_charts, update_project_info, update_project_users_table

load_dotenv()

UPDATE_INTERVAL: Final[datetime.timedelta] = datetime.timedelta(hours=int(os.environ.get('UPDATE_INTERVAL', '4')))
DB_PATH: Final[Path] = Path('dashboard_data.pkl')

data: DashboardData | None = None


def update_footer(update_time_label: ui.label) -> None:
    now = datetime.datetime.now(tz=datetime.timezone.utc)
    data_age = humanize.naturaldelta(data.update_timestamp - now, minimum_unit="seconds")
    update_time_label.set_text(f'Data is {data_age} old.')


def get_data(*, refresh: bool = False) -> None:
    global data  # noqa: PLW0603

    if data is None and DB_PATH.exists():
        logger.debug(f'Loading cached data ({DB_PATH.absolute()})')
        with DB_PATH.open('rb') as f:
            data = pickle.load(f)  # noqa: S301

    if (refresh is True or
            data is None or
            (datetime.datetime.now(tz=datetime.timezone.utc) - data.update_timestamp) > UPDATE_INTERVAL):
        logger.debug(f'{"Stale" if data is not None else "No cached data"}, reload')
        data = xnat_dashboard.queries.search()
        with DB_PATH.open('wb') as f:
            logger.debug(f'Saving data to cache ({DB_PATH.absolute()})')
            # noinspection PyTypeChecker
            pickle.dump(data, f)


@ui.page('/projects')
async def page_projects() -> None:  # noqa: PLR0915
    get_data()
    await ui.context.client.connected(timeout=30)

    try:
        project_ids = sorted(data.subjects['project'].unique())
    except KeyError:
        project_ids = []

    if 'selected_project' not in app.storage.tab:
        selected_project = ActiveProject()
        default_project = os.getenv('DEFAULT_PROJECT', None)
        if default_project is not None:
            selected_project.name = default_project
        else:
            selected_project.name = project_ids[0] if len(project_ids) > 0 else None
        app.storage.tab['selected_project'] = selected_project
    else:
        selected_project = app.storage.tab['selected_project']

    with ui.header(elevated=True).style('background-color: #3874c8').classes('items-center justify-between'):
        ui.link('Users', '/users').classes(replace='text-lg')
        ui.link('Subjects', '/subjects').classes(replace='text-lg')
        ui.link('Experiments', '/experiments').classes(replace='text-lg')
        ui.space()
        ui.label('XNAT Projects').classes('text-2xl font-bold')
        ui.space()
        ui.label('XNAT Dashboard')

    with ui.footer().style('background-color: #3874c8'):
        ui.label('© LKEB / LUMC 2025')
        ui.space()
        update_time_label = ui.label('Data is ... old.')

    select = ui.select(
        options=project_ids,
        label='Projects',
        value=selected_project.name
    ).classes('w-64').bind_value(selected_project, 'name')

    ui.separator()

    with ui.tabs().classes('w-full') as tabs:
        info_tab = ui.tab('information')
        exp_tab = ui.tab('experiments')
        sub_tab = ui.tab('subjects')

    with ui.tab_panels(tabs, value=info_tab).classes('w-full'):
        with ui.tab_panel(info_tab), ui.grid(columns='1fr 1fr').classes('w-full'):
            project_info = ui.table(columns=[
                {'name': 'key', 'label': 'Key', 'field': 'key', 'required': True, 'align': 'right'},
                {'name': 'value', 'label': 'Value', 'field': 'value', 'required': True, 'align': 'left'}],
                rows=[],
                row_key='key',
                title='General info',
                selection=None,
                column_defaults={'align': 'left', 'headerClasses': 'uppercase text-primary'}
            )

            table_columns = [
                {'name': 'login', 'label': 'Login', 'field': 'login', 'align': 'right', 'sortable': True},
                {'name': 'first_name', 'label': 'First Name', 'field': 'first_name', 'align': 'center',
                 'sortable': True},
                {'name': 'last_name', 'label': 'Last Name', 'field': 'last_name', 'align': 'center', 'sortable': True},
                {'name': 'role', 'label': 'Role', 'field': 'role', 'align': 'center', 'sortable': True}
            ]

            users_table = ui.table(
                columns=table_columns,
                rows=[],
                row_key='login',
                title='Users',
                selection=None,
                column_defaults={'align': 'left', 'headerClasses': 'uppercase text-primary'}
            )

            users_table.add_slot('body', r"""
                    <q-tr :props="props">
                        <q-td
                            v-for="col in props.cols"
                            :key="col.name"
                            :props="props"
                            @click="$parent.$emit('user_selected', {row: props.row, col: col.name})"
                        >
                            {{ col.value }}
                        </q-td>
                    </q-tr>
                """)
            users_table.on('user_selected', lambda x: ui.navigate.to(f'/user/{x.args["row"]["login"]}'))

        with ui.tab_panel(sub_tab):
            sub_hm = create_heatmap()
            sub_chart = create_chart()
        with ui.tab_panel(exp_tab):
            exp_hm = create_heatmap()
            exp_chart = create_chart()

    charts = Charts(sub_chart, sub_hm, exp_chart, exp_hm)

    select.on_value_change(
        functools.partial(update_project_info, project_info, data, selected_project))
    select.on_value_change(
        functools.partial(update_project_users_table, users_table, data, selected_project))
    select.on_value_change(
        functools.partial(update_charts, charts, data, selected_project))

    if selected_project.name is not None:
        await update_project_info(project_info, data, selected_project)
        await update_project_users_table(users_table, data, selected_project)
        await update_charts(charts, data, selected_project)

    ui.timer(5, functools.partial(update_footer, update_time_label=update_time_label))


@ui.page('/users')
async def page_users() -> None:
    with ui.header(elevated=True).style('background-color: #3874c8').classes('items-center justify-between'):
        ui.link('Projects', '/projects').classes(replace='text-lg')
        ui.link('Subjects', '/subjects').classes(replace='text-lg')
        ui.link('Experiments', '/experiments').classes(replace='text-lg')
        ui.space()
        ui.label('XNAT Users').classes('text-2xl font-bold')
        ui.space()
        ui.label('XNAT Dashboard')
    with ui.footer().style('background-color: #3874c8'):
        ui.label('© LKEB / LUMC 2025')

    columns = [
        {'name': 'login', 'label': 'Login', 'field': 'login', 'required': True, 'align': 'right', 'sortable': True},
        {'name': 'firstname', 'label': 'First Name', 'field': 'firstname', 'required': True, 'align': 'center',
         'sortable': True},
        {'name': 'lastname', 'label': 'Last Name', 'field': 'lastname', 'required': True, 'align': 'center',
         'sortable': True},
    ]

    rows = [x.model_dump() for x in sorted(data.users, key=lambda x: x.login.casefold())]

    table = ui.table(columns=columns, rows=rows, row_key='login')
    table.add_slot('body', r"""
        <q-tr :props="props">
            <q-td
                v-for="col in props.cols"
                :key="col.name"
                :props="props"
                @click="$parent.$emit('user_selected', {row: props.row, col: col.name})"
            >
                {{ col.value }}
            </q-td>
        </q-tr>
    """)
    table.on('user_selected', lambda x: ui.navigate.to(f'/user/{x.args["row"]["login"]}'))


@ui.page('/user/{user_id}')
async def page_user(user_id: str) -> None:
    def _user() -> XnatUser | None:
        return next((x for x in data.users if x.login == user_id), None)

    def _user_role(proj: XnatProject) -> XnatRole | None:
        """ User role in the project. """
        return next((usr.role for usr in proj.users if usr.login == user_id), None)

    def _projects_for_user(_projects: Container[XnatProject]) -> list[XnatProject]:
        """ All projects that 'user_id' is a member of. """
        return sorted((proj for proj in data.projects.values() if user_id in (x.login for x in proj.users)),
                      key=lambda x: x.name.casefold())

    user = _user()

    with ui.header(elevated=True).style('background-color: #3874c8').classes('items-center justify-between'):
        ui.link('Users', '/users').classes(replace='text-lg')
        ui.link('Projects', '/projects').classes(replace='text-lg')
        ui.link('Subjects', '/subjects').classes(replace='text-lg')
        ui.link('Experiments', '/experiments').classes(replace='text-lg')
        ui.space()
        ui.label(f'{user.firstname} {user.lastname}').classes('text-2xl font-bold')
        ui.space()
        ui.label('XNAT Dashboard')
    with ui.footer().style('background-color: #3874c8'):
        ui.label('© LKEB / LUMC 2025')

    projects = _projects_for_user(data.projects.values())

    ui.table(columns=[
        {'name': 'name', 'label': 'Project Name', 'field': 'name', 'required': True, 'align': 'right', 'sortable': True},
        {'name': 'role', 'label': 'Role', 'field': 'role', 'sortable': True},
        {'name': 'description', 'label': 'Description', 'field': 'description', 'sortable': True},
    ],
        rows=[
            {'name': proj.name,
             'description': proj.description,
             'role': _user_role(proj)} for proj in projects],
        row_key='key',
        title='Projects',
        selection=None,
        column_defaults={'align': 'left', 'headerClasses': 'uppercase text-primary'})


@ui.page('/subjects')
async def page_subjects() -> None:
    with ui.header(elevated=True).style('background-color: #3874c8').classes('items-center justify-between'):
        ui.link('Users', '/users').classes(replace='text-lg')
        ui.link('Projects', '/projects').classes(replace='text-lg')
        ui.link('Experiments', '/experiments').classes(replace='text-lg')
        ui.space()
        ui.label('XNAT Subjects').classes('text-2xl font-bold')
        ui.space()
        ui.label('XNAT Dashboard')
    with ui.footer().style('background-color: #3874c8'):
        ui.label('© LKEB / LUMC 2025')

    await subjects_chart(data)


@ui.page('/experiments')
async def page_experiments() -> None:
    with ui.header(elevated=True).style('background-color: #3874c8').classes('items-center justify-between'):
        ui.link('Users', '/users').classes(replace='text-lg')
        ui.link('Projects', '/projects').classes(replace='text-lg')
        ui.link('Subjects', '/subjects').classes(replace='text-lg')
        ui.space()
        ui.label('XNAT Experiments').classes('text-2xl font-bold')
        ui.space()
        ui.label('XNAT Dashboard')
    with ui.footer().style('background-color: #3874c8'):
        ui.label('© LKEB / LUMC 2025')

    await experiments_chart(data)


@ui.page('/refresh')
async def data_refresh() -> None:
    get_data(refresh=True)


@ui.page('/')
async def main_page() -> None:
    ui.navigate.to('/users')


async def on_startup() -> None:
    get_data()
    logger.info('Dashboard started')


if __name__ == '__main__':
    app.on_startup(on_startup)
    ui.run(host='localhost', port=8088, show=False, reload=False)
