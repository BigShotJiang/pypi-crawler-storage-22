""" Run queries on a XNAT server and provide functions to access the results. """
import datetime
import io
import os
import string
from collections import defaultdict
from multiprocessing import Pool

import pandas as pd
import xnat
from dotenv import load_dotenv
from loguru import logger
from xnat.mixin import ProjectData

from xnat_dashboard.searches import SUBJECTS_QUERY, MODALITIES_QUERY
from xnat_dashboard.data_types import XnatUser, XnatProject, Modalities, DashboardData

load_dotenv()
SERVER = os.environ.get('SERVER')


def _query_modality(modality: Modalities) -> pd.DataFrame:
    """ Replace the modality keyword in the search document and run the query. """
    return _query(string.Template(MODALITIES_QUERY).substitute({'modality': modality.value}))


def _query(query_xml: str) -> pd.DataFrame:
    """ Run the query on XNAT. """
    with xnat.connect(SERVER) as session:
        result = session.post(path='/data/search?format=csv', data=query_xml)
    return pd.read_csv(io.StringIO(result.text), sep=',', dtype=pd.StringDtype(), parse_dates=['insert_date'])


def search() -> DashboardData:
    """ Query all experiments and subjects within XNAT. """
    data = DashboardData()

    logger.debug('Collecting projects data.')
    with xnat.connect(SERVER) as session:
        data.projects = {xnat_project.id: _convert(xnat_project) for xnat_project in session.projects.values()}
        data.users = [XnatUser(**user.data) for user in session.users.values()]
        result = session.post(path='/data/search?format=csv', data=SUBJECTS_QUERY)
        data.subjects = pd.read_csv(io.StringIO(result.text), sep=',', dtype=pd.StringDtype(), parse_dates=['insert_date'])

    logger.debug('Collecting experiments data.')
    with Pool() as pool:
        results = pool.map(_query_modality, Modalities)
        pool.close()
        pool.join()

    data.experiments = dict(zip(Modalities, results, strict=False))
    data.update_timestamp = datetime.datetime.now(tz=datetime.timezone.utc)

    return data


def get_users() -> list[XnatUser]:
    """ Get all users. """
    with xnat.connect(SERVER) as session:
        return [XnatUser(**user.data) for user in session.users.values()]


def _convert(_xnat: ProjectData) -> XnatProject:
    """ Convert from XNAT ProjectData object to (local) Project object. """
    proj = XnatProject(**_xnat.data)
    proj.experiments_count = len(_xnat.experiments)
    proj.subject_count = len(_xnat.subjects)
    proj.created = _xnat.insert_date  # type: ignore
    for user in _xnat.users.values():
        proj.users.append(XnatUser(**user.data))
    return proj


def main() -> None:
    """ Dummy """
    projects = search().projects

    user_projects = defaultdict(list)
    for project in projects.values():
        for user in project.users:
            user_projects[user.login].append(project)

    print(user_projects)


if __name__ == '__main__':
    main()
