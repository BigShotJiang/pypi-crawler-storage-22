from xnoted.app import XNotedApp

if __name__ == "__main__":
    app = XNotedApp()
    app.run()
