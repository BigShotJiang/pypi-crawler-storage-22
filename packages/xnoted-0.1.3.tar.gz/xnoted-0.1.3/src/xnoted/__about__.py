# SPDX-FileCopyrightText: 2024-present
#
# SPDX-License-Identifier: MIT

__version__ = "0.1.3"
