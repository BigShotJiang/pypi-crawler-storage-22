"""XNoted - A terminal-based todo application built with Textual."""

from xnoted.__about__ import __version__

__all__ = ["__version__"]