"""xnv — Python virtual environment doctor."""

__version__ = "0.1.0"
