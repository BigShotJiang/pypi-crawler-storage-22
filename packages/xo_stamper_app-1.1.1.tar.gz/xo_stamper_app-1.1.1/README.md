# X.O Stamper, version 1.1.1

Build stamp file writer

## Repository

Upstream repository is <https://gitlab.com/xgqt/xgqt-python-app-xo-stamper/>.

## Package

Download from PYPI: <https://pypi.org/project/xo-stamper-app/>.

## License

### Code

Code in this project is licensed under the MPL, version 2.0.

    This Source Code Form is subject to the terms of the Mozilla Public
    License, v. 2.0. If a copy of the MPL was not distributed with this
    file, You can obtain one at http://mozilla.org/MPL/2.0/.
