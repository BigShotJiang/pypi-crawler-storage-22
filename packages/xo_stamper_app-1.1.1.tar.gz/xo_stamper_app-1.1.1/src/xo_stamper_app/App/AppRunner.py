#!/usr/bin/env python


# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at http://mozilla.org/MPL/2.0/.
#
# Copyright (c) 2025-2026, Maciej Barć <xgqt@xgqt.org>


"""
App runner.
"""


from pathlib import Path

from ..Builder.CliBuilder import CliBuilder
from ..Stamper.Stamper import Stamper
from ..Stamper.StamperConfig import StamperConfig


class AppRunner:

    def __init__(self) -> None:
        self._args = CliBuilder().add_arguments().parse().get_args()

    def run(self) -> None:
        file_path = Path(self._args.output_stamp_file_path)
        file_path_str = str(file_path.absolute())

        stamper_config: StamperConfig = StamperConfig(
            env_variables=self._args.env,
            metadata_include_git_commit=self._args.mgc,
            metadata_include_project_version=self._args.mpv,
        )

        file_path.parent.mkdir(parents=True, exist_ok=True)

        stamper = Stamper(stamper_config=stamper_config)

        stamper.write_stamp(file_path_str=file_path_str)
