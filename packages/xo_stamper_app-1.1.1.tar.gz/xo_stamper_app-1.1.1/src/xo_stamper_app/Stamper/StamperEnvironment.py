#!/usr/bin/env python


# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at http://mozilla.org/MPL/2.0/.
#
# Copyright (c) 2025-2026, Maciej Barć <xgqt@xgqt.org>


import os


class StamperEnvironment:

    @staticmethod
    def get_environment(env_variables: list[str]) -> dict[str, str]:
        environment: dict[str, str] = {}

        for env_variable in env_variables:
            environment[env_variable] = os.environ.get(env_variable) or ""

        return environment
