#!/usr/bin/env python


# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at http://mozilla.org/MPL/2.0/.
#
# Copyright (c) 2025-2026, Maciej Barć <xgqt@xgqt.org>


import os


class LocateDominatingFile:

    @staticmethod
    def get_file(file_name: str, start_path: str) -> None | str:
        current_dir = os.path.abspath(start_path)
        target_path = None

        while True:
            target_path = os.path.join(current_dir, file_name)

            if os.path.exists(target_path):
                break

            parent_dir = os.path.dirname(current_dir)

            if parent_dir == current_dir:
                target_path = None
                break

            current_dir = parent_dir

        return target_path
