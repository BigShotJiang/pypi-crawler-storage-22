# Bedmap module tests
