"""Test suite for STAC functionality."""
