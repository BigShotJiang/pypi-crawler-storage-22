import pandas as pd

def clean_employee_data(input_csv, output_csv="cleaned_sample_data.csv"):
    """
    Cleans employee data and saves it to a CSV file.

    Parameters:
        input_csv (str): Path to input CSV file
        output_csv (str): Path to output cleaned CSV file
    """

    df = pd.read_csv(input_csv)

    # Strip column names
    df.columns = df.columns.str.strip()

    # Strip string values
    df = df.apply(lambda x: x.str.strip() if x.dtype == "object" else x)

    # Fill missing values
    if 'age' in df.columns:
        df['age'].fillna(df['age'].mean(), inplace=True)

    if 'salary' in df.columns:
        df['salary'].fillna(df['salary'].median(), inplace=True)

    # Convert date
    if 'date_of_joining' in df.columns:
        df['date_of_joining'] = pd.to_datetime(df['date_of_joining'], errors='coerce')

    # Remove duplicates
    df.drop_duplicates(inplace=True)

    # Normalize performance
    if 'performance' in df.columns:
        df['performance'] = df['performance'].str.capitalize()

    # Drop rows without name
    if 'name' in df.columns:
        df.dropna(subset=['name'], inplace=True)

    df.to_csv(output_csv, index=False)
    return df


''' 
Use of open-source intelligence and passive reconnaissance

Whois hsplot.com

nslookup google.com

Ping google.com

traceroute google.com

Curl -I google.com


---------------------------------------------------------------------

Practical on enumerating host, port, and service scanning.

Ifconfig

Nmap <ip address >

Nmap <host name>

Nmap -h

Nmap -sS ip address

Nmap -sV ip address

---------------------------------------------------------------------------


Practical on vulnerability scanning and assessment.


nslookup amazon.com

ping 192.168.22.253

sudo nmap -vv -O 192.168.22.253

sudo apt-get install nikto

Sudo nikto -h

sudo nikto -h https://www.instagram.com/

Sudo apt-get install uniscan

sudo uniscan -u https://www.facebook.com/




------Practical on use of social engineering tool.----------

Practical on use of social engineering tool.

ngrok http http://localhost:8080


#sudo setoolkit
set>1


Use 1







------------------------------------------------------------------




Practical on using Metasploit Framework for exploitation.

msfconsole

Search option


Use any number 1 -7
Use > 5

Set rhost <ip address>
Set rhost 192.168.101.15

Set port 1 -65000
Set threads 100

Run

Exploit

Show payloads

#Hack FTP Server Using Metasploit

serch vsftp

use 1

Show option

Set rhost 192.1.10.7
Set port 26

Show option

---------------------------------------------------------------------------------------------

'''

'''
#------- this is for wifi ----------------------

# 1. Update system
sudo apt update && sudo apt upgrade -y

# 2. Install required Wi-Fi tools
sudo apt install -y wireless-tools net-tools iw aircrack-ng rfkill

# 3. Check USB Wi-Fi adapter
lsusb

# 4. Check wireless interface
ip a
iwconfig

# 5. Unblock Wi-Fi (common issue)
sudo rfkill list
sudo rfkill unblock wifi

# 6. Bring interface UP (replace wlan0 if different)
sudo ip link set wlan0 up

# 7. Check supported modes (monitor mode support)
iw list

# 8. Kill conflicting processes
sudo airmon-ng check kill

# 9. Enable monitor mode
sudo airmon-ng start wlan0

# 10. Verify monitor mode
iwconfig

# 11. Scan nearby Wi-Fi networks
sudo airodump-ng wlan0mon



----------------------------------------

Sniff Wifi Hotspots in Wireless Network

# iw dev

#sudo airmon-ng check kill

Enable monitor mode (manual method)
#sudo ip link set wlan0 down
#sudo iw dev wlan0 set type monitor
#sudo ip link set wlan0 up

Sniff Wi-Fi hotspots
#sudo airodump-ng wlan0



Stop monitor mode and restore Wi-Fi
#sudo ip link set wlan0 down
#sudo iw dev wlan0 set type managed
#sudo ip link set wlan0 up
#sudo service NetworkManager restart


--------------------------------------------------

Analyse strength Wifi Network Strength

# iw dev

If Wi-Fi Still Does NOT Scan
#sudo ip link set wlan0 down
#sudo iw dev wlan0 set type managed
#sudo ip link set wlan0 up
#sudo service NetworkManager restart


#ifconfig

List Wi-Fi Networks with Signal Strength
#nmcli dev wifi list

----------------------------------------------------------------------

Discover wireless access points in Wireless Networks.

Check Wireless Interface
#iw dev


Bring Interface UP
#sudo ip link set wlan0 up


Discover APs
#sudo iw dev wlan0 scan| grep SSID


To view full details
#sudo iw dev wlan0 scan


'''