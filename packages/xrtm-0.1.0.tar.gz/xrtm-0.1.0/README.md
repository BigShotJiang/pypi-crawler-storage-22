# xRtm: The Generative Forecasting Framework

[![PyPI](https://img.shields.io/pypi/v/xrtm?style=flat-square)](https://pypi.org/project/xrtm/)
[![License](https://img.shields.io/badge/license-Apache%202.0-blue?style=flat-square)](LICENSE)

**xRtm** is an open-source framework for institutional-grade generative forecasting and agentic reasoning.

## Installation

```bash
pip install xrtm
```

This installs the complete framework, including all components below.

---

## Ecosystem

| Component | Badge | Description |
| :--- | :--- | :--- |
| **xrtm-forecast** | [![PyPI](https://img.shields.io/pypi/v/xrtm-forecast?style=flat-square)](https://pypi.org/project/xrtm-forecast/) | The Inference Engine |
| **xrtm-data** | [![PyPI](https://img.shields.io/pypi/v/xrtm-data?style=flat-square)](https://pypi.org/project/xrtm-data/) | The Snapshot Vault |
| **xrtm-eval** | [![PyPI](https://img.shields.io/pypi/v/xrtm-eval?style=flat-square)](https://pypi.org/project/xrtm-eval/) | The Judge |
| **xrtm-train** | [![PyPI](https://img.shields.io/pypi/v/xrtm-train?style=flat-square)](https://pypi.org/project/xrtm-train/) | The Training Pipeline |

---

## Documentation

Full documentation is available at **[xrtm.org](https://xrtm.org)**.

---

## License

Apache 2.0 — see [LICENSE](LICENSE) for details.
