from tests.fixtures.books import BookForm, Books
from tests.integration.benchmarks.conftest import context, xsdata_temp_dir
from xsdata.formats.dataclass.parsers import JsonParser, XmlParser
from xsdata.formats.dataclass.serializers import JsonSerializer, XmlSerializer
from xsdata.models.datatype import XmlDate


def make_books(how_many: int) -> Books:
    return Books(
        book=[
            BookForm(
                author="Arne Dahl",
                title="Misterioso: A Crime Novel",
                genre="Thrillers & Suspense",
                price=15.95,
                pub_date=XmlDate(1999, 10, 5),
                review=(
                    "Lorem ipsum dolor sit amet, consectetur adipiscing elit. "
                    "Integer at erat sagittis, accumsan mauris eu, egestas "
                    "quam. Name tristique felis justo, vel iaculis ipsum cursus "
                    "at. Praesent various enim ac nunc interdum placerat. "
                    "Integer porttitor, nibh at viverra vehicula, leo dui "
                    "suscipit nisi, ornare laoreet eros neque nec mi. Proin."
                ),
                id="9788831796781",
            )
            for _ in range(how_many)
        ]
    )


def parse(source, handler) -> None:
    parser = XmlParser(context=context, handler=handler)
    parser.from_bytes(source, Books)


def parse_json(source) -> None:
    parser = JsonParser(context=context)
    parser.from_bytes(source, Books)


def write(size, obj, writer) -> None:
    with xsdata_temp_dir.joinpath(f"benchmark_{size}.xml").open("w") as f:
        serializer = XmlSerializer(writer=writer, context=context)
        serializer.write(f, obj)


def write_json(size, obj) -> None:
    with xsdata_temp_dir.joinpath(f"benchmark_{size}.json").open("w") as f:
        serializer = JsonSerializer(context=context)
        serializer.write(f, obj)
