"""Services package for xsmeteo."""
