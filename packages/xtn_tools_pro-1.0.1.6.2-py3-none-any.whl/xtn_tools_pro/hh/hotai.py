#!/usr/bin/env python
# -*- coding: utf-8 -*-

# 说明：
#    维护后台相关
# History:
# Date          Author    Version       Modification
# --------------------------------------------------------------------------------------------------
# 2026/2/1    xiatn     V00.01.000    新建
# --------------------------------------------------------------------------------------------------
import json
import time

import requests
from xtn_tools_pro.utils.time_utils import get_time_timestamp_to_datestr


class A818:
    def __init__(self, x_api_key, host):
        self.__x_api_key = x_api_key
        self.__host = host
        self.__headers = {
            "accept": "application/json, text/plain, */*",
            "accept-language": "zh-CN,zh;q=0.9,en-US;q=0.8,en;q=0.7",
            "content-type": "application/json",
            "priority": "u=1, i",
            "sec-ch-ua": "\"Chromium\";v=\"142\", \"Google Chrome\";v=\"142\", \"Not_A Brand\";v=\"99\"",
            "sec-ch-ua-mobile": "?0",
            "sec-ch-ua-platform": "\"Windows\"",
            "sec-fetch-dest": "empty",
            "sec-fetch-mode": "cors",
            "sec-fetch-site": "same-site",
            "x-api-key": x_api_key
        }

    def get_task_list(self, taskType=None, taskStatus=None, countryCode=None, priority=None, pageNo=1, pageSize=500):
        """
            获取任务列表
        :param taskType:任务类型[单选],不指定获取全部
        :param taskStatus: 任务状态[多选],不指定获取全部,-1失败;0排队;1已完成;2进行中;3关闭 列表类型
        :param countryCode: 国家[单选],不指定获取全部
        :param priority: 任务权重[单选],0插队;1加急;2平台;3一般
        :return: 
        """
        data = {
            "pageNo": pageNo,
            "pageSize": pageSize,
        }
        if taskType:
            data["taskType"] = taskType
        if isinstance(taskStatus, list):
            data["taskStatus"] = taskStatus
        if countryCode:
            # 国家 自动转大写
            data["countryCode"] = str(countryCode).upper()
        if priority:
            data["priority"] = str(priority)

        url = f"{self.__host}/filter/task/list"
        data = json.dumps(data, separators=(',', ':'))
        for _ in range(3):
            try:
                response = requests.post(url, headers=self.__headers, data=data)
                return response.json()
            except Exception as e:
                print("f[get_task_list]报错:{e}")

    def to_ji_su_du(self, total_time=60, taskType=None, taskStatus=None, countryCode=None, priority=None):
        """
            统计速度
        :param total_time:下次统计时间
        :param taskType:任务类型[单选],不指定获取全部
        :param taskStatus: 任务状态[多选],不指定获取全部,-1失败;0排队;1已完成;2进行中;3关闭 列表类型
        :param countryCode: 国家[单选],不指定获取全部
        :param priority: 任务权重[单选],0插队;1加急;2平台;3一般
        :return:
        """
        index = 0
        total_cnt_history = 0
        while True:
            json_data = self.get_task_list(taskType=taskType, taskStatus=taskStatus,
                                           countryCode=countryCode, priority=priority)
            try:
                total_cnt = 0
                for item in json_data["result"]["records"]:
                    taskProgress = item["taskProgress"]
                    total_cnt += taskProgress
                index += 1
                print(f"第{index}次", get_time_timestamp_to_datestr(), total_cnt - total_cnt_history)
                total_cnt_history = total_cnt
                time.sleep(total_time)
            except Exception as e:
                print(f"[to_ji_su_du]报错:{e}")


if __name__ == '__main__':
    pass
