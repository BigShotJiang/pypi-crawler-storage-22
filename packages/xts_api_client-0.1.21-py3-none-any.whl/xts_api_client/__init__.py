# X   X  TTTTT  SSSSS     AAAAA  PPPPP   III
#  X X     T    S        A     A P    P   I
#   X      T    SSSSS    AAAAAAA PPPPP    I
#  X X     T        S    A     A P        I
# X   X    T    SSSSS    A     A P        III

