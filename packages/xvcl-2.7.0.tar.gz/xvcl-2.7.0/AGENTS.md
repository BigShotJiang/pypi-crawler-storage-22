# Repository Guidelines

## Project Structure & Module Organization
- `src/xvcl/compiler.py` holds the full compiler (intentional single-file design). Package metadata lives in `src/xvcl/__init__.py` and `src/xvcl/py.typed`.
- `tests/` is pytest-based. Inputs live in `tests/xvcl/`, expected VCL in `tests/expected/`, Falco validation inputs in `tests/xvcl/falco/`.
- `examples/` contains larger, integration-style `.xvcl` examples.
- `docs/` is the static site assets; `dist/` may hold build artifacts.
- Tooling and metadata are in `pyproject.toml` (Python >=3.9); `uv.lock` pins dev deps.

## Build, Test, and Development Commands
- Install dev deps: `uv pip install -e ".[dev]"`
- Run compiler: `xvcl input.xvcl -o output.vcl` (add include paths with `-I ./includes`)
- Lint/format/type-check: `ruff check .`, `ruff format .`, `mypy src/xvcl`
- Run tests: `pytest tests/ -v` (or `uv run pytest tests/ -v`)
- Validate generated VCL: `falco lint output.vcl` and `falco test output.vcl` (optional if Falco is installed)

## Coding Style & Naming Conventions
- Formatting is enforced by Ruff: 4-space indent, 100-char lines, double quotes.
- Keep compiler logic centralized in `src/xvcl/compiler.py` unless there’s a clear reason to split.
- XVCL source files use `.xvcl`; generated output is `.vcl`.
- Error test files use `tests/xvcl/error_*.xvcl` with a first line like `// ERROR: <substring>`.

## Testing Guidelines
- Feature tests: add `tests/xvcl/<name>.xvcl` plus matching `tests/expected/<name>.vcl`.
- Error tests: add `tests/xvcl/error_<name>.xvcl` and include the `// ERROR:` line.
- Falco tests: add full VCL scenarios in `tests/xvcl/falco/` (pytest skips if `falco` is missing).

## Commit & Pull Request Guidelines
- Git history uses short, descriptive subjects (e.g., “Add more tests”, “Nits”, “Bump”) plus occasional merge commits; keep messages concise.
- PRs should include a brief summary, testing commands run (e.g., `pytest tests/ -v`, `falco lint`), and example input/output when changing compiler behavior.

## Architecture Notes
- The compiler is multi-pass (constants/includes/macros/functions/directives) and uses only the Python standard library at runtime. Keep changes aligned with this design to preserve zero runtime dependencies.
