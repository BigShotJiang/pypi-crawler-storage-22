# Changelog

All notable changes to xvcl will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [2.7.0] - 2026-02-02

### Added

- Multiline support for arrays and function calls - expressions can now span multiple lines for better readability
- Comprehensive test suite with 39 tests covering features, error handling, and Falco validation
- Example: ipcrypt-nd implementation demonstrating advanced xvcl usage

### Changed

- Improved quick reference documentation with better descriptions and multiline tip
- Updated command-line option descriptions for clarity

### Fixed

- String-aware parenthesis matching in macro expansion - parentheses inside string literals are now correctly ignored
- Iterator consumption bug in for loop debug logging
- Word boundary checking in block matching to prevent `#ifdef` matching `#if`

## [2.6.0] - 2026-01-06

### Added

- Tuple unpacking in for loops: `#for name, port in BACKENDS`
- Support for `enumerate()` in for loops: `#for idx, item in enumerate(LIST)`

### Fixed

- String-aware argument parsing in macros - commas and parentheses inside strings no longer break parsing

## [2.5.0] - 2025-11-26

### Added

- Inline macros with `#inline`/`#endinline` for zero-overhead text substitution
- Functions with single and tuple return values using `#def`/`#enddef`
- `#let` directive for combined variable declaration and initialization
- Debug mode (`--debug`) with expansion traces
- Source maps (`--source-maps`) for tracking generated code origin

### Changed

- Multi-pass compilation for proper forward references and scoping

## [2.4.0] - 2025-11-01

### Added

- File includes with `#include` directive
- Include-once semantics and circular dependency detection
- Include path configuration with `-I` flag

## [2.3.0] - 2025-10-15

### Added

- Conditional compilation with `#if`/`#else`/`#endif`
- Boolean constants and expressions

## [2.2.0] - 2025-10-01

### Added

- For loops with `#for`/`#endfor`
- `range()` function for numeric iteration
- List iteration support

## [2.1.0] - 2025-09-15

### Added

- Template expressions with `{{expression}}` syntax
- Built-in functions: `len()`, `str()`, `int()`, `hex()`, `format()`, `min()`, `max()`, `abs()`

## [2.0.0] - 2025-09-01

### Added

- Constants with `#const` directive
- Type checking for INTEGER, STRING, FLOAT, BOOL
- Type inference when type is omitted

### Changed

- Complete rewrite as single-file compiler
- Zero external dependencies (Python standard library only)

## [1.0.0] - 2025-08-01

### Added

- Initial release
- Basic VCL preprocessing
