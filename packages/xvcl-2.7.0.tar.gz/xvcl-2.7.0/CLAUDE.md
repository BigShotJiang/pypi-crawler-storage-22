# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## Project Overview

xvcl is a VCL transpiler that extends Fastly VCL with programming constructs like loops, functions, constants, and macros. It's a Python-based compiler that processes `.xvcl` files into standard `.vcl` files compatible with Fastly.

**Core concept:** xvcl adds compile-time metaprogramming to VCL without runtime overhead. Features include constants, template expressions, for loops, conditionals, file includes, inline macros, and functions with return values.

## Build & Development Commands

### Installation and Setup
```bash
# Install dependencies and package (development mode)
uv pip install -e ".[dev]"

# Run xvcl directly without installation
uvx xvcl input.xvcl -o output.vcl

# Install for production use
uv pip install .
```

### Running the Compiler
```bash
# Basic compilation
xvcl input.xvcl -o output.vcl

# With include paths
xvcl main.xvcl -o main.vcl -I ./includes

# Debug mode (shows expansion traces)
xvcl main.xvcl --debug

# With source maps
xvcl main.xvcl --source-maps
```

### Linting and Formatting
```bash
# Lint Python code
ruff check .

# Format Python code
ruff format .

# Type check
mypy src/xvcl
```

### Testing Generated VCL
```bash
# Compile and validate with Falco (VCL linter/tester)
xvcl examples/ipcrypt_deterministic.xvcl -o output.vcl
falco lint output.vcl
falco test output.vcl
```

## Architecture

### Single-File Compiler Design
The entire compiler is implemented in `src/xvcl/compiler.py` (~1500 lines). This is intentional - xvcl has **zero external dependencies** beyond Python standard library.

### Multi-Pass Compilation Process

The compiler processes xvcl files in **6 sequential passes**:

1. **Pass 1: Extract constants** - Parse `#const` directives and build constant symbol table
2. **Pass 2: Process includes** - Recursively expand `#include` directives with cycle detection
3. **Pass 3: Extract inline macros** - Parse `#inline` blocks (zero-overhead text substitution)
4. **Pass 4: Extract functions** - Parse `#def` blocks (functions with single/tuple returns)
5. **Pass 5: Process directives** - Expand `#for`, `#if`, `#let`, template expressions `{{}}`, macro calls
6. **Pass 6: Generate function subroutines** - Emit VCL subroutines for all defined functions

**Key insight:** Each pass operates on the full text, building up state (constants, macros, functions) before final code generation. This multi-pass design allows forward references and proper scoping.

### Core Classes

- **`XVCLCompiler`** - Main compiler class, orchestrates all passes
- **`Macro`** - Represents `#inline` macros (simple parameter substitution)
- **`Function`** - Represents `#def` functions (generates VCL subroutines with global headers for param passing)
- **`PreprocessorError`** - Exception with source location and context for error reporting
- **`SourceLocation`** - Tracks file and line number for error messages

### Function Compilation Strategy

Functions are compiled into VCL subroutines using **global request headers** for parameter passing:

```vcl
# xvcl code:
set var.result = add(5, 10);

# Generated VCL:
set req.http.X-Func-add-a = "5";
set req.http.X-Func-add-b = "10";
call add;
set var.result = std.atoi(req.http.X-Func-add-Return);
```

The compiler automatically handles type conversions (INTEGER/FLOAT/BOOL ↔ STRING) and supports tuple returns using indexed headers (`X-Func-{name}-Return0`, `X-Func-{name}-Return1`, etc.).

### Macro vs Function Design Trade-offs

- **Macros** (`#inline`): Direct text substitution, zero overhead, single expression only
- **Functions** (`#def`): VCL subroutine calls, overhead from globals, supports complex logic/multiple statements

Use macros for simple expressions; use functions for complex logic with conditionals or multiple statements.

### Include System

The `#include` directive uses **include-once semantics** with cycle detection:
- Tracks absolute paths in `included_files` set
- Uses `include_stack` for circular dependency detection
- Searches in current directory first, then `-I` include paths
- Constants and macros from included files are available to parent

### Error Reporting

Error messages include:
- Source file and line number
- Error context (surrounding lines with arrow pointing to error)
- Suggestions for typos (using `difflib.get_close_matches()`)
- ANSI color codes for terminal output (automatically detected)

## Development Practices

### Code Style
- Uses dataclasses for structured data
- Single-file design: keep all compiler logic in `compiler.py`

### Testing
- Examples in `examples/` directory serve as integration tests
- Test by compiling examples and validating output with Falco
- No unit test framework currently (pytest is in dev dependencies but no tests exist)

### Making Changes to Directives

When adding or modifying directives:
1. Update the appropriate pass in `_process_lines()` method
2. Add regex pattern matching for the directive
3. Update error handling with proper `SourceLocation`
4. Add debug logging calls (`self.log_debug()`)
5. Update README.md and xvcl-quick-reference.md with syntax and examples

Output is accumulated in `self.output` list and joined at the end. Use `self.emit()` to add lines.

## Important Notes

- **No backwards compatibility concerns** - Feel free to make breaking changes to syntax
- **Zero runtime overhead goal** - Generated VCL should be clean and efficient
- **Standard library only** - Do not add external dependencies
- **Falco integration** - Generated VCL must validate with Falco linter
- xvcl files use `.xvcl` extension by convention (but not enforced)
- Generated function subroutines have special annotations for VCL scope compatibility

## Falco Integration

Generated VCL must validate with [Falco](https://github.com/ysugimoto/falco). Falco source code is at `/Users/j/src/falco`.