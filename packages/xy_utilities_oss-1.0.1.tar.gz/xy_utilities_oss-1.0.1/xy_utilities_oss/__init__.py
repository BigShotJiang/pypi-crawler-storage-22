"""
xy_utilities_oss - 阿里云OSS工具库

提供对阿里云对象存储服务的便捷操作封装。
"""
from xy_utilities_oss.OssHelper import OssHelper

__version__ = "1.0.1"
__all__ = ["OssHelper"]
