import logging
from typing import Literal

from aiogram import Router, F
from aiogram.exceptions import TelegramBadRequest
from aiogram.filters import Command
from aiogram.filters.callback_data import CallbackData
from aiogram.types import Message, CallbackQuery, InlineKeyboardButton

from xync_bot.shared import BoolCd
from xync_schema import models

hot = Router(name="hot")


class HotCd(CallbackData, prefix="hot"):
    typ: Literal["sell", "buy"]
    cex: int = 4


@hot.message(Command("hot"))
async def start(msg: Message, xbt: "XyncBot"):  # noqa: F821
    me = msg.from_user
    user, _ = await models.User.tg_upsert(me, False)
    await xbt.go_hot(user, [4])


@hot.callback_query(BoolCd.filter(F.req.__eq__("is_you")))
async def is_you(query: CallbackQuery, callback_data: BoolCd, xbt: "XyncBot"):  # noqa: F821
    if not callback_data.res:
        try:
            await query.message.delete()
        except TelegramBadRequest as e:
            logging.error(e)
        return await query.answer("ok, sorry")

    order = await models.Order.get(id=callback_data.xtr).prefetch_related(
        "ad__pair_side__pair", "ad__my_ad", "ad__maker", "taker"
    )
    if not (
        user_persons := await models.Person.filter(user__username_id=query.from_user.id).prefetch_related(
            "user", "creds", "actors"
        )
    ):
        raise ValueError(f"Не найдено персонов tg юзера:{query.from_user.id}, это как бле??")
    user: models.User = user_persons[0].user
    actor_person_query = models.Person.filter(actors=order.taker_id, user_id__isnull=True)
    # проверка на всякий
    if (cnt := await actor_person_query.count()) != 1:
        if cnt:
            raise ValueError(f"{cnt} persons у актора:{order.taker_id}! А должна быть ОДНА!")
        logging.error(f"у актора:{order.taker_id} уже нет персон, уже не актуальный запрос")
        return await query.message.delete()

    # переназначаем персоне тейкера, текущего тг юзера, если у него
    actor_person = await actor_person_query.first()
    actor_person.user_id = user.id
    await actor_person.save(update_fields=["user_id"])

    txt = f"Юзер{user.id} {user.username_id}:{user.first_name} прожал что {order.taker_id} его!"
    logging.info(txt)
    btns = [[InlineKeyboardButton(text=f"👀{order.exid}", url=f"https://www.bybit.com/p2p/orderList/{order.exid}")]]
    await xbt.send(193017646, txt, btns)

    # и если старая персона юзера осталась сиротой без кредов и акторов, то удаляем ее
    if not len(user_persons[0].creds) and not len(user_persons[0].actors):
        await user_persons[0].delete()

    await xbt.hot_result(user, order)

    try:
        await query.message.delete()
    except TelegramBadRequest as e:
        logging.error(e)
    return await query.answer("ok")
