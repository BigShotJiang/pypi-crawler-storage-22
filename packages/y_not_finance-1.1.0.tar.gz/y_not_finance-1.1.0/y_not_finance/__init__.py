"""
Y-Not-Finance: A comprehensive Python library for financial data.

This package provides three main modules:
1. prices - Fetch historical and intraday price data from Yahoo Finance
2. constituents - Fetch stock index constituents from various sources
3. events - Fetch corporate events data (dividends, splits, earnings)

Examples:
    >>> from y_not_finance import YahooFinanceClient, EventsClient, get_constituents
    >>> 
    >>> # Fetch price data
    >>> client = YahooFinanceClient()
    >>> prices = client.get_prices(["AAPL", "MSFT"], range_str="1mo")
    >>> 
    >>> # Fetch events data
    >>> events_client = EventsClient()
    >>> events = events_client.get_events("AAPL", range_str="5y")
    >>> 
    >>> # Get index constituents
    >>> tickers, description = get_constituents("^SPX", info=True)
"""

__version__ = "1.0.0"

# Import main classes and functions for convenience
from .yahoo_finance import YahooFinanceClient, EventsClient
from .constituents import get_constituents, STOCK_LISTS

__all__ = [
    'YahooFinanceClient',
    'EventsClient',
    'get_constituents',
    'STOCK_LISTS',
    '__version__',
]
