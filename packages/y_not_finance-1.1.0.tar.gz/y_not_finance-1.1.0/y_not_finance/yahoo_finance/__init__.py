"""
Yahoo Finance provider module.

This module provides access to Yahoo Finance data including:
- Prices: Historical and intraday price data
- Events: Corporate events (dividends, splits, earnings)
"""

from .prices import YahooFinanceClient
from .events import EventsClient

__all__ = ['YahooFinanceClient', 'EventsClient']
