"""
Events module - Yahoo Finance events data (dividends, splits, earnings).

This module provides functionality to fetch corporate events data
from Yahoo Finance, including dividends, stock splits, and earnings.
"""

from .client import EventsClient

__all__ = ['EventsClient']
