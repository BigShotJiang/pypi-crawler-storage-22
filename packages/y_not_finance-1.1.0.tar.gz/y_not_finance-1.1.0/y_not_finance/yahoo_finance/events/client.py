"""
Main client for fetching events data from Yahoo Finance.
"""

import logging
from typing import Union, List, Optional
import pandas as pd

from ..core import YahooFinanceHTTPClient, utils
from .parser import extract_events
from ..prices.constants import LONG_INTERVALS

logger = logging.getLogger(__name__)


class EventsClient:
    """
    A client for fetching corporate events data from Yahoo Finance API.
    
    Features:
    - Multi-ticker concurrent fetching
    - Support for dividends, splits, earnings, and capital gains
    - Automatic retry with exponential backoff
    - Flexible date range filtering
    """
    
    def __init__(
        self,
        max_workers: int = 10,
        rate_limit_delay: float = 0.1,
        timeout: int = 10,
        max_retries: int = 5
    ):
        """
        Initialize the Events client.
        
        Args:
            max_workers: Maximum number of concurrent API requests
            rate_limit_delay: Delay between requests in seconds
            timeout: Request timeout in seconds
            max_retries: Maximum number of retry attempts for failed requests
        """
        self.fetcher = YahooFinanceHTTPClient(
            max_workers=max_workers,
            rate_limit_delay=rate_limit_delay,
            timeout=timeout,
            max_retries=max_retries
        )
    
    def get_events(
        self,
        tickers: Union[str, List[str]],
        range_str: str = "10y",
        event_type: str = "dividends"
    ) -> pd.DataFrame:
        """
        Fetch corporate events data for one or more tickers.
        
        Args:
            tickers: Single ticker string or list of ticker symbols
            range_str: Date range to fetch (e.g., '1y', '5y', '10y', 'max')
                      Default: '10y'
            event_type: Type of event to extract (string only).
                       Available: 'dividends', 'splits'
                       Default: 'dividends'
                        
        Returns:
            DataFrame with date as index and ticker symbols as columns.
            For single ticker, column is the ticker name.
            For multiple tickers, each ticker is a separate column.
            
        Examples:
            >>> client = EventsClient()
            >>> 
            >>> # Get dividends
            >>> dividends_df = client.get_events("AAPL", range_str="5y", event_type="dividends")
            >>> 
            >>> # Get splits for multiple tickers
            >>> splits_df = client.get_events(["AAPL", "MSFT"], range_str="5y", event_type="splits")
        """
        # Normalize tickers to list
        if isinstance(tickers, str):
            tickers = [tickers]
        
        # Events are only available with daily data
        interval = "1d"
        
        # Fetch data concurrently
        raw_json_data = self.fetcher.fetch_concurrent(tickers, range_str, interval)
        
        if not raw_json_data:
            logger.warning("No data fetched for any ticker")
            return pd.DataFrame()

        # Extract events from raw data
        ticker_frames = {}
        for ticker, raw_json in raw_json_data.items():
            try:
                df = extract_events(raw_json, event_type)
                if not df.empty:
                    ticker_frames[ticker] = df
            except Exception as e:
                logger.error(f"Error processing events for {ticker}: {e}")

        if not ticker_frames:
            logger.warning("No valid events data extracted")
            return pd.DataFrame()

        # Concatenate with date as index, tickers as columns
        result = pd.concat(ticker_frames, axis=1, sort=True)
        
        # Flatten MultiIndex columns - keep only ticker names
        if isinstance(result.columns, pd.MultiIndex):
            result.columns = result.columns.get_level_values(0)
        
        # Fill missing values with 0 for dividends, NaN for splits
        if event_type.lower() == 'dividends':
            result = result.fillna(0.0)
        
        return utils.format_as_daily(result.sort_index())
