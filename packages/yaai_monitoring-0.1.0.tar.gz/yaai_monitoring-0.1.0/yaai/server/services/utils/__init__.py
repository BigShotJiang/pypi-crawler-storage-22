"""Utility functions for services."""
