"""Utilities and executable documentation assets for yads."""
