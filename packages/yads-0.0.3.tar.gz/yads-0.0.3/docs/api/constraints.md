---
icon: "lucide/shield-check"
---
# Constraints

## Column Constraints

::: yads.constraints.ColumnConstraint
    options:
      heading_level: 3

::: yads.constraints.NotNullConstraint
    options:
      heading_level: 3

::: yads.constraints.PrimaryKeyConstraint
    options:
      heading_level: 3

::: yads.constraints.DefaultConstraint
    options:
      heading_level: 3

::: yads.constraints.ForeignKeyConstraint
    options:
      heading_level: 3

::: yads.constraints.IdentityConstraint
    options:
      heading_level: 3

## Table Constraints

::: yads.constraints.TableConstraint
    options:
      heading_level: 3

::: yads.constraints.PrimaryKeyTableConstraint
    options:
      heading_level: 3

::: yads.constraints.ForeignKeyTableConstraint
    options:
      heading_level: 3

::: yads.constraints.ForeignKeyReference