# Polars Loader

::: yads.loaders.polars_loader.PolarsLoader

::: yads.loaders.polars_loader.PolarsLoaderConfig