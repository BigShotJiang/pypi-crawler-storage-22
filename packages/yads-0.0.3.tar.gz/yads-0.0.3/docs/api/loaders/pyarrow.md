# PyArrow Loader

::: yads.loaders.pyarrow_loader.PyArrowLoader

::: yads.loaders.pyarrow_loader.PyArrowLoaderConfig