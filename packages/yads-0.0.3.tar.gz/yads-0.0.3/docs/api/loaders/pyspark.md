# PySpark Loader

::: yads.loaders.pyspark_loader.PySparkLoader

::: yads.loaders.pyspark_loader.PySparkLoaderConfig