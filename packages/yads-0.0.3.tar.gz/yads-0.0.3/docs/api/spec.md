---
icon: "lucide/file-text"
---
# YadsSpec

::: yads.spec.YadsSpec

::: yads.spec.Field

::: yads.spec.Column

::: yads.spec.TransformedColumnReference

::: yads.spec.Storage

::: yads.spec.from_dict
