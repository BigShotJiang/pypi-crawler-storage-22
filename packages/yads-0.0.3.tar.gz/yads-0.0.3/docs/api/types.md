---
icon: "lucide/type"
---

# Types

::: yads.types.YadsType

::: yads.types.String

::: yads.types.Integer

::: yads.types.Float

::: yads.types.Decimal

::: yads.types.Boolean

::: yads.types.Binary

::: yads.types.Date

::: yads.types.TimeUnit

::: yads.types.Time

::: yads.types.Timestamp

::: yads.types.TimestampTZ

::: yads.types.TimestampLTZ

::: yads.types.TimestampNTZ

::: yads.types.Duration

::: yads.types.IntervalTimeUnit

::: yads.types.Interval

::: yads.types.Array

::: yads.types.Struct

::: yads.types.Map

::: yads.types.JSON

::: yads.types.Geometry

::: yads.types.Geography

::: yads.types.UUID

::: yads.types.Void

::: yads.types.Variant

::: yads.types.Tensor
