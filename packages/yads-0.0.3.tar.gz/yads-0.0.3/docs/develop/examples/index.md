---
icon: "lucide/flask-conical"
---
# Example use-cases for yads