"""Command-line helpers for docs automation."""
