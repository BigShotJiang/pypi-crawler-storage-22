# `yads` Spec

| Version | Spec File                               |
| ------- | --------------------------------------- |
| latest  | [yads_spec_latest.json](./yads_spec_latest.json) |
| v0.0.2  | [yads_spec_v0.0.2.json](./yads_spec_v0.0.2.json) |
| v0.0.1  | [yads_spec_v0.0.1.json](./yads_spec_v0.0.1.json) |