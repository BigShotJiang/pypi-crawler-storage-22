CREATE TABLE catalog.db.test_spec (
  id INT NOT NULL,
  name TEXT
); 