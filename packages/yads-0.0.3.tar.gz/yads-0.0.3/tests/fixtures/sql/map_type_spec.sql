CREATE TABLE catalog.db.map_spec (
  metadata MAP<TEXT(50), INT>
); 