# yafg: Yet Another Figure Generator
#
# Copyright (c) 2019-2020 Philipp Trommler
#
# SPDX-License-Identifier: GPL-3.0-or-later
from .yafg import makeExtension, YafgExtension
