"""Examples package - sample projects demonstrating framework features."""
