"""Tests for yamlgraph-generator."""
