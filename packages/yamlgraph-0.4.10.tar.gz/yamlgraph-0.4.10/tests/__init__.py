"""Test suite for yamlgraph."""
