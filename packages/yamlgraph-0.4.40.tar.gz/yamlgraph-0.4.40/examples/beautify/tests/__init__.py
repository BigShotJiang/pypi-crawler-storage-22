# Beautify example tests
