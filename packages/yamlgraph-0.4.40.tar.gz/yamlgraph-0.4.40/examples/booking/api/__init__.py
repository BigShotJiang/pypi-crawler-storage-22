"""Booking API package."""
