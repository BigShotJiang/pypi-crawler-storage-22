# NPC example
