# NPC example tests
