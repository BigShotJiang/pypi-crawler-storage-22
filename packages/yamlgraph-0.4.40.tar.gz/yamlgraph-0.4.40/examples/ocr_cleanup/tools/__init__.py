"""OCR cleanup tools."""
