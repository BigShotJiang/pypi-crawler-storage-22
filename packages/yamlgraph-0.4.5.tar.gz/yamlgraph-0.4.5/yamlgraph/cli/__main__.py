"""Allow running yamlgraph.cli as a module: python -m yamlgraph.cli"""

from yamlgraph.cli import main

if __name__ == "__main__":
    main()
