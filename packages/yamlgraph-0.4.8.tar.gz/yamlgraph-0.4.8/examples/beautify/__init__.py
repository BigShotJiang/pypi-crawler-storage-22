"""Beautify example - Transform graph.yaml into HTML infographics."""
