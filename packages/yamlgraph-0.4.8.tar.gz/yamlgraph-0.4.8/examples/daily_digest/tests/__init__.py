"""Tests for daily_digest example."""
