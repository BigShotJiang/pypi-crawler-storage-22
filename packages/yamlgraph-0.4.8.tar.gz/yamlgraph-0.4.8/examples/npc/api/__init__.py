"""NPC Encounter Web API."""
