"""API routes for NPC encounters."""

from .encounter import router as encounter_router

__all__ = ["encounter_router"]
