# Book Translator Example
"""Book translation pipeline using YAMLGraph."""
