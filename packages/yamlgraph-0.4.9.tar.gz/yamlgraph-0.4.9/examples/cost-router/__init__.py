"""Cost Router example - Route queries to cost-appropriate LLM providers."""
