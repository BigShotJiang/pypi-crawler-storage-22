"""Storyboard example - demonstrates Python node for image generation."""
