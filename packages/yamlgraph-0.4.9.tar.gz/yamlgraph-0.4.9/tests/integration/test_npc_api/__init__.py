"""Integration tests for NPC Web API."""
