# -*- coding: utf-8 -*-
__version__ = '0.3.2'
__author__ = 'Maxim Mosin && Miskler'
