from sqlalchemy import create_engine
import pandas as pd
class yangth:
    def __init__(self,token=''):
        self.token=token
        self.username='yangthpypi'
        self.passwd='2B6682876669d3b46635ed65dfe7ef89'
        self.host='rm-uf6frg8f8628ip3fieo.mysql.rds.aliyuncs.com'
        self.engine=create_engine(f'mysql+pymysql://{self.username}:{self.passwd}@{self.host}:3306/stk?charset=utf8')
    def get_new_news(self):
        df=pd.read_sql(f"select * from  major_news order by crt_time desc limit 1", con=self.engine)
        return df