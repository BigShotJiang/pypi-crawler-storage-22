from sqlalchemy import create_engine
import pandas as pd
class yangth:
    def __init__(self,token=''):
        self.token=token
        self.username='yangthpypi'
        self.passwd='2B6682876669d3b46635ed65dfe7ef89'
        self.host='rm-uf6frg8f8628ip3fieo.mysql.rds.aliyuncs.com'
        self.engine=create_engine(f'mysql+pymysql://{self.username}:{self.passwd}@{self.host}:3306/stk?charset=utf8')
    def get_lst_news(self,limit=1):
            # 参数类型和值检查
        if not isinstance(limit, int):
            raise TypeError(f"limit参数必须是整数类型，当前传入的是{type(limit).__name__}类型")
        if limit <= 0:
            raise ValueError(f"limit参数必须是正整数，当前传入的值是{limit}")
        df=pd.read_sql(f"select * from  major_news order by crt_time desc limit {limit}", con=self.engine)
        return df