from sqlalchemy import create_engine
import pandas as pd
import time
import threading
from functools import wraps

def rate_limit(period=30):
    def decorator(func):
        last_called = [0.0]  # 使用列表实现可变对象
        lock = threading.Lock()
        
        @wraps(func)
        def wrapper(*args, **kwargs):
            with lock:
                elapsed = time.time() - last_called[0]
                if elapsed < period:
                    raise RuntimeError(
                        f"操作过于频繁，请等待 {period - elapsed:.1f} 秒后再试。"
                        f"距离下次可调用还有 {period - elapsed:.1f} 秒"
                    )
                last_called[0] = time.time()
            return func(*args, **kwargs)
        return wrapper
    return decorator

class yangth:
    def __init__(self, token=''):
        self.token = token
        self.username = 'yangthpypi'
        self.passwd = '2B6682876669d3b46635ed65dfe7ef89'
        self.host = 'rm-uf6frg8f8628ip3fieo.mysql.rds.aliyuncs.com'
        self.engine = create_engine(f'mysql+pymysql://{self.username}:{self.passwd}@{self.host}:3306/stk?charset=utf8')
        
    @rate_limit(period=30)  # 30秒内只能调用1次
    def get_lst_news(self, limit=1): 
        # 参数类型和值检查
        if not isinstance(limit, int):
            raise TypeError(f"limit参数必须是整数类型，当前传入的是{type(limit).__name__}类型")
        if limit <= 0:
            raise ValueError(f"limit参数必须是正整数，当前传入的值是{limit}")
        elif limit >1000:
            raise ValueError(f"limit参数必须小于1000条")
        
        df = pd.read_sql(
            f"SELECT * FROM major_news ORDER BY crt_time DESC LIMIT {limit}", 
            con=self.engine
        )
        return df