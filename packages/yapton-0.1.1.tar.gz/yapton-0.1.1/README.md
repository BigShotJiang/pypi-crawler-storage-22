# Yapton

Yapton is a basic language that transpiles to Python. It keeps most of Python’s power but adds slang keywords for kids in these generations to know common operations and basics before actually going to Python.

## Prerequisites

- Python 3.10 or higher installed
- Git installed (to clone the repository)
- A terminal (PowerShell, Command Prompt, Git Bash, or any IDE terminal)

## Installation and setup

1. **Clone the repository**
   - Use `git clone` to download this project and then change into the project directory.

2. **Create a virtual environment**
   - From the project directory, create a virtual environment named `.venv`:
     - `python -m venv .venv`

3. **Activate the virtual environment**
   - Activate `.venv` so the `yap` command installs into it:
     - PowerShell or Command Prompt: `./.venv/Scripts/activate` (or `./.venv/Scripts/Activate.ps1`)
     - Git Bash: `source .venv/Scripts/activate`

4. **Install Yapton in editable mode**
   - Run `python -m pip install -e .` from the project directory while the virtual environment is active. This installs the `yapton` package and exposes the `yap` command.

## Running Yapton programs

- Use the `yap` command to run a Yapton source file.
- Yapton source files should use the `.yap` extension.

## Viewing the Yapton slang dictionary

- Run `yap --slang-help` to print a list of Yapton slang keywords and a short description of what each one does.

## Things to keep in mind when coding in Yapton

- Indentation and block structure follow Python rules.
- Colons are required at the end of control-flow and function-definition lines.
- Boolean operators are the Python words (`and`, `or`, `not`).
- `W` and `L` represent the boolean values for true and false, respectively.
- Slang keywords for conditions and branches map directly onto Python’s `if` / `elif` / `else`.
- Slang for defining functions maps directly onto Python’s function definition keyword.
- Slang for importing modules maps directly onto Python’s import mechanism.
- Slang for printing maps directly onto Python’s standard output function.
- The input helper automatically converts numeric-looking input into numbers when possible; otherwise it returns text.
- Core Python data types (numbers, text, lists, dictionaries, etc.) and operations behave exactly as in Python.
- Loops, comparisons, arithmetic, slicing, and built-in functions follow normal Python semantics.
- Comments use the same character as Python and are ignored by the interpreter.
- Runtime errors are reported with a custom prefix but otherwise show the underlying Python error type and message.
- Plain Python syntax continues to work alongside the Yapton slang; the slang is additional sugar, not a replacement for Python’s features.
