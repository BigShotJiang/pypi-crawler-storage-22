# Allowing coloring in windows.
if  __import__('sys').platform == 'win32':
    __import__('os').system("")


# Colors!
class Colors:
    """More colors! A lot more colors!
    Red, orange, yellow,
    Green, blue, skyblue,
    Purple, magenta, pink,
    White, black, gray,
    And more!"""

    # Reset
    RESET = "\x1b[0m"

    # Classic
    BLACK = "\x1b[30m"
    BLUE = "\x1b[34m"
    CYAN = "\x1b[36m"
    GREEN = "\x1b[32m"
    GREY = "\x1b[90m"
    MAGENTA = "\x1b[35m"
    RED = "\x1b[31m"
    WHITE = "\x1b[37m"
    YELLOW = "\x1b[33m"

    # Bolds
    BOLD = "\x1b[1m"
    BOLD_BLACK = "\x1b[1;30m"
    BOLD_BLUE = "\x1b[1;34m"
    BOLD_CYAN = "\x1b[1;36m"
    BOLD_GREEN = "\x1b[1;32m"
    BOLD_MAGENTA = "\x1b[1;35m"
    BOLD_RED = "\x1b[1;31m"
    BOLD_WHITE = "\x1b[1;37m"
    BOLD_YELLOW = "\x1b[1;33m"

    # Intenses
    INTENSE_BLACK = "\x1b[90m"
    INTENSE_BLUE = "\x1b[94m"
    INTENSE_CYAN = "\x1b[96m"
    INTENSE_GREEN = "\x1b[92m"
    INTENSE_MAGENTA = "\x1b[95m"
    INTENSE_RED = "\x1b[91m"
    INTENSE_WHITE = "\x1b[97m"
    INTENSE_YELLOW = "\x1b[93m"

    # Backgrounds
    BACKGROUND_BLACK = "\x1b[40m"
    BACKGROUND_BLUE = "\x1b[44m"
    BACKGROUND_CYAN = "\x1b[46m"
    BACKGROUND_GREEN = "\x1b[42m"
    BACKGROUND_MAGENTA = "\x1b[45m"
    BACKGROUND_RED = "\x1b[41m"
    BACKGROUND_WHITE = "\x1b[47m"
    BACKGROUND_YELLOW = "\x1b[43m"

    # Intense backgrounds
    INTENSE_BACKGROUND_BLACK = "\x1b[100m"
    INTENSE_BACKGROUND_BLUE = "\x1b[104m"
    INTENSE_BACKGROUND_CYAN = "\x1b[106m"
    INTENSE_BACKGROUND_GREEN = "\x1b[102m"
    INTENSE_BACKGROUND_MAGENTA = "\x1b[105m"
    INTENSE_BACKGROUND_RED = "\x1b[101m"
    INTENSE_BACKGROUND_WHITE = "\x1b[107m"
    INTENSE_BACKGROUND_YELLOW = "\x1b[103m"

# Creating meta classes
class _MetaColor(type):
    def __instancecheck__(cls, other):
        return hasattr(other, 'color')
class Color(metaclass=_MetaColor):
    """Color!
    Red, orange, yellow,
    Green, blue, skyblue,
    Purple, magenta, pink,
    White, black, gray,
    And more!"""
    def __init__(self, color: str):
        if hasattr(Colors, color):
            self.color = color
        else:
            raise ValueError(f"please, enter a valid color, not \"{color}\".")

# Deleting meta classes
del _MetaColor

# Color text, you can do it myself, if you want
def color(text: str, color: Color, reset: bool = True):
    reset = Colors.RESET if reset else ''
    if not isinstance(color, Color):
        raise TypeError(f"color must be Color, not \"{type(color).__name__}\"")
    return f'{color.color}{text}{reset}'
