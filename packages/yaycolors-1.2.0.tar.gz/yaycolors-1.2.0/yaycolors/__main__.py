from yaycolors import rainbow

print("--- YayColors CLI ---")
print("Enter text, and it will turn into rainbow!")

while True:
    try:
        print(rainbow(input("Enter text: ")))
    except KeyboardInterrupt:
        print("\nBye!")
        break
