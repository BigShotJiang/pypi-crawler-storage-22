after you finish work, commit with a conventional message. only commit the files you edited.
always run `just check` before code commits.
if you fix anything from `just check`, rerun it and confirm it passes before committing.
when using gh to edit or create PR descriptions, prefer `--body-file` to preserve newlines.
always include a "Manual testing" checklist section in PRs.
