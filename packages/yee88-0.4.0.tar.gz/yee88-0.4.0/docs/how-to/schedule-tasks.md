# Schedule tasks

Telegram’s native message scheduling works with Takopi.

In Telegram, long-press the send button and choose **Schedule Message** to run tasks at a specific time.
You can also set up recurring schedules (daily/weekly) for automated workflows.

