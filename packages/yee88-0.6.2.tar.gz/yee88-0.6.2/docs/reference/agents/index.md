# For agents

These pages are **high-signal reference** for LLM agents (and humans acting like one).

- [Repo map](repo-map.md)
- [Invariants](invariants.md)

