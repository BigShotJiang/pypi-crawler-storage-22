# Yera

## Installation

```bash
pip install yera
```

## Quick Start

Run a development environment in your current directory:

```bash
yera dev
```

This will:

- Discover agents in your current directory
- Start the execution server
- Open the UI in your browser

Run a specific agent:

```bash
yera run path/to/agent.py
```
