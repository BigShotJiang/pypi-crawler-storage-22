from abc import ABC, abstractmethod
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from .base_server import BaseServer


class BaseClient(ABC):
    def __init__(self, url_base: str):
        self.url_base = url_base

    def _make_url(self, *parts: str) -> str:
        return "/".join([self.url_base.rstrip("/"), *list(parts)])

    @classmethod
    @abstractmethod
    def from_server(cls, server: "BaseServer") -> "BaseClient":
        """Create client from server instance.

        Must be implemented by each subclass with appropriate server type.

        Args:
            server: BaseServer instance to connect to

        Returns:
            BaseClient configured to connect to the server

        """
        raise NotImplementedError
