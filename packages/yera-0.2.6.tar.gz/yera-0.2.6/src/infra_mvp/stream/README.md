# Yera Stream Test Server

A minimal FastAPI-based server that streams predefined conversations over Server-Sent Events (SSE) for the Yera UI.

## Running the Server

### Simple start (no auto-reload)

```bash
uv run python -m infra_mvp.stream --host 127.0.0.1 --port 8991
```

### Development mode (with auto-reload)

```bash
uv run uvicorn infra_mvp.stream.app:app --host 0.0.0.0 --port 8991 --reload
```

The development command is recommended while working on the UI or stream conversations, as it automatically restarts when code changes.

## Key Endpoints

- `POST /api/session` – create a new streaming session for a given `conversation_id`
- `GET /api/stream?session_id=...` – stream conversation messages via SSE
- `POST /api/interaction?session_id=...` – send user interactions (buttons, input prompts, etc.)
- `GET /health` – simple health check

## Conversations

By default, the server loads conversation JSON files from:

```text
src/infra_mvp/stream/conversations/
```

The integration tests use separate, test-only conversations under:

```text
tests/integration/infra_mvp/stream/conversations/
```

## Testing

```bash
uv run pytest tests/integration/infra_mvp/stream -q
```

This runs fast, focused integration tests against the stream server.

For lower-level checks of data loading and helpers, you can also run the unit tests:

```bash
uv run pytest tests/unit/infra_mvp/stream -q
```


