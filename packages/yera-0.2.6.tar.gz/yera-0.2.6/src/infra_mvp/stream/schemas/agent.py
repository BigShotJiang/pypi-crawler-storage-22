"""Agent metadata schemas for API responses."""

from pydantic import BaseModel, Field


class AgentMetadata(BaseModel):
    """Minimal agent metadata for list endpoints.

    Contains only the fields needed for displaying agents in lists,
    cards, and hierarchical navigation.
    """

    id: str = Field(description="Agent identifier (dotted module.function name)")
    name: str = Field(description="Agent display name")
    description: str | None = Field(default=None, description="Agent description")
    path: list[str] = Field(
        description="Folder hierarchy path (empty for single-agent CLI mode)"
    )


class ListAgentsResponse(BaseModel):
    """Response schema for listing agents."""

    agents: list[AgentMetadata] = Field(description="List of agents")
