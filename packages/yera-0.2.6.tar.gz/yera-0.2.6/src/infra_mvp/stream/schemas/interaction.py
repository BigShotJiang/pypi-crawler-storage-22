"""Interaction request and response schemas."""

from typing import Any

from pydantic import BaseModel


class LayoutSubBlock(BaseModel):
    """Schema for a layout sub-block in an interaction."""

    sub_block_id: str
    sub_block_type: str
    value: Any


class UserInteraction(BaseModel):
    """Schema for a user interaction."""

    blockId: str
    value: Any
    blockType: str


class AddInteractionResponse(BaseModel):
    """Response schema for interaction handling."""

    status: str
    session_id: str
