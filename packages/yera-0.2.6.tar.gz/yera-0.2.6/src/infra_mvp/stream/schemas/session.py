"""Session request and response schemas."""

from dataclasses import dataclass, field

from pydantic import BaseModel

from yera.agents.decorator import AgentFunctionWrapper
from yera.events.runtime import PyRuntimeExecutor


@dataclass
class SessionState:
    """Session state for Python agent sessions."""

    agent: AgentFunctionWrapper
    executor: PyRuntimeExecutor
    session_id: str
    interactions: list[dict] = field(default_factory=list)


class SessionCreateRequest(BaseModel):
    """Request schema for creating a session."""

    agent_id: str


class CreateSessionResponse(BaseModel):
    """Response schema for session creation."""

    session_id: str
