from dataclasses import dataclass
from inspect import Parameter
from typing import Any


@dataclass
class AgentInput:
    name: str
    type: str
    kind: str
    has_default: bool
    default_value: Any

    @staticmethod
    def from_parameter(p: Parameter) -> "AgentInput":
        return AgentInput(
            name=p.name,
            type=str(p.annotation),
            kind=str(p.kind),
            has_default=p.default is not Parameter.empty,
            default_value=None if p.default is Parameter.empty else p.default,
        )


@dataclass
class AgentInstance:
    agent_id: str
    instance_id: int


@dataclass
class AgentMetadata:
    name: str
    module: str
    identifier: str
    params: list[AgentInput]
    return_type: str
    docs: str | None = None
    description: str | None = None

    def make_instance_id(self, ix: int) -> AgentInstance:
        return AgentInstance(
            agent_id=f"{self.module}.{self.identifier}", instance_id=ix
        )

    def pretty_print(self) -> str:
        lines = [
            f"Agent: {self.name}",
            f"Module: {self.module}",
            f"Identifier: {self.identifier}",
        ]

        if self.description:
            lines.append(f"Description: {self.description}")

        if self.docs:
            lines.append(f"Docs: {self.docs}")

        lines.append(f"\nParameters ({len(self.params)}):")
        if self.params:
            for param in self.params:
                default = f" = {param.default_value}" if param.has_default else ""
                lines.append(f"  - {param.name}: {param.type}{default}")
        else:
            lines.append("  (none)")

        lines.append(f"\nReturn Type: {self.return_type}")

        return "\n".join(lines)
