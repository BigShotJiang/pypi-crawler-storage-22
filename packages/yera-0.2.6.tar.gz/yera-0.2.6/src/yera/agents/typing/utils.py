from typing import get_args, get_origin


def get_type_name(type_hint):
    if type_hint is None or type_hint is type(None):
        return "None"

    origin = get_origin(type_hint)
    if origin is not None:
        args = get_args(type_hint)
        if args:
            arg_names = ", ".join(get_type_name(arg) for arg in args)
            return f"{origin.__name__}[{arg_names}]"
        return origin.__name__

    if hasattr(type_hint, "__name__"):
        return type_hint.__name__

    return str(type_hint)
