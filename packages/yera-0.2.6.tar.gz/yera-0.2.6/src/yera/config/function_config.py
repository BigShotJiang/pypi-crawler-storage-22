import warnings
from enum import Enum
from typing import Any

from pydantic import BaseModel, field_validator


class ParameterKind(str, Enum):
    POSITIONAL_OR_KEYWORD = "POSITIONAL_OR_KEYWORD"
    VAR_POSITIONAL = "VAR_POSITIONAL"  # *args
    KEYWORD_ONLY = "KEYWORD_ONLY"  # keyword-only parameters
    VAR_KEYWORD = "VAR_KEYWORD"  # **kwargs


class ParameterInfo(BaseModel):
    name: str
    type_annotation: str
    kind: ParameterKind
    default: Any | None = None

    @field_validator("default")
    @classmethod
    def validate_default_for_kind(cls, v, info):
        """Validate parameter defaults and warn about mutable defaults."""
        if "kind" in info.data:
            kind = info.data["kind"]
            name = info.data.get("name", "unknown")

            # Validate that VAR_POSITIONAL and VAR_KEYWORD cannot have non-None defaults
            if (
                kind in (ParameterKind.VAR_POSITIONAL, ParameterKind.VAR_KEYWORD)
                and v is not None
            ):
                raise ValueError(
                    f"Parameter kind '{kind}' cannot have a default value (got {v})"
                )

            # Warn about mutable defaults (Python best practice violation)
            if v is not None and isinstance(v, list | dict | set):
                warnings.warn(
                    f"Parameter '{name}' has a mutable default value ({type(v).__name__}). "
                    f"This can lead to unexpected behavior as the same object is reused across calls. "
                    f"Consider using 'None' as default and creating a new object inside the function.",
                    UserWarning,
                    stacklevel=3,
                )
        return v


class FunctionConfig(BaseModel):
    content: str
    name: str
    parameters: list[ParameterInfo]  # Replaces input_signature and parameter_defaults
    output_signature: str
    module_path: str | None = None
