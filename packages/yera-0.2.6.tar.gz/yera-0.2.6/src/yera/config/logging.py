from copy import deepcopy
from logging.config import dictConfig

from uvicorn.config import LOGGING_CONFIG

# Make a copy to avoid mutating the original
LOG_CONFIG = deepcopy(LOGGING_CONFIG)

# Add root logger configuration for your application logs
LOG_CONFIG["root"] = {
    "level": "INFO",
    "handlers": ["default"],
}


def setup_logging():
    """Configure logging for the application."""
    dictConfig(LOG_CONFIG)
