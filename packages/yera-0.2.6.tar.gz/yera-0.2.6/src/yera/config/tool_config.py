from pydantic import BaseModel

from yera.config.function_config import FunctionConfig


class ToolConfig(BaseModel):
    function_config: FunctionConfig
    security_rank: int
