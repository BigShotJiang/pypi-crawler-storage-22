"""Configuration management for Yera.

This module handles configuration file management, credential storage,
and application settings.

"""

__all__ = []
