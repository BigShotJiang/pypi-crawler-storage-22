"""Helper functions for paths."""

from pathlib import Path


def has_local_yera_toml() -> bool:
    """Check whether there is a local yera toml file.

    Local tomls are under current working directory

    Returns:
        true if present otherwise false
    """
    toml_path = Path.cwd() / "yera.toml"
    return toml_path.exists()


def has_global_yera_toml() -> bool:
    """Check whether there is a global yera toml file.

    global tomls are under the user home/.config/yera directory

    Returns:
        true if present otherwise false

    """
    toml_path = Path.home() / ".config" / "yera" / "yera.toml"
    return toml_path.exists()
