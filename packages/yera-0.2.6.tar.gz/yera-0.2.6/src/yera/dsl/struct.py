from typing import Self, TypeVar

from pydantic import BaseModel as PydanticBaseModel
from pydantic import ConfigDict


class Struct(PydanticBaseModel):
    model_config = ConfigDict(extra="forbid")

    @classmethod
    def fill(cls, prompt: str, **kwargs) -> Self:
        from .functions import struct

        return struct(prompt, cls, **kwargs)

    def __hash__(self) -> int:
        return hash(repr(self))


TBaseModel = TypeVar("TBaseModel", bound=Struct)
