"""Chat-related helpers for the Yera library.

The block construction helpers defined here are also re-exported at the top
level of the `yera` package so that they can be used either as:

    import yera

    yera.events.markdown(...)

or:

    import yera as yr

    yr.markdown(...)
"""

from __future__ import annotations

from yera.events.blocks import (
    action,
    bar_chart,
    columns,
    container,
    exit_event,
    form,
    input_echo,
    line_chart,
    markdown,
    quit_event,
    request_input_buttons,
    request_input_date_picker,
    request_input_slider,
    request_input_text,
    spinner,
    system_prompt,
    table,
)

__all__ = [
    "action",
    "bar_chart",
    "columns",
    "container",
    "exit_event",
    "form",
    "input_echo",
    "line_chart",
    "markdown",
    "quit_event",
    "request_input_buttons",
    "request_input_date_picker",
    "request_input_slider",
    "request_input_text",
    "spinner",
    "system_prompt",
    "table",
]
