"""Chat-specific block construction helpers for the Yera library.

This package provides block construction functions that can be used either via
the events namespace:

    import yera

    yera.events.markdown(...)
    yera.events.buttons(...)
    ...

or via the top-level re-exports:

    import yera as yr

    yr.markdown(...)
    yr.buttons(...)
    ...
"""

from __future__ import annotations

from yera.events.blocks.action import action
from yera.events.blocks.bar_chart import bar_chart
from yera.events.blocks.base.base import _BlockFactory
from yera.events.blocks.buttons import request_input_buttons as request_input_buttons
from yera.events.blocks.columns import columns
from yera.events.blocks.container import container
from yera.events.blocks.date_picker import (
    request_input_date_picker as request_input_date_picker,
)
from yera.events.blocks.exit import exit_event, quit_event
from yera.events.blocks.form import form
from yera.events.blocks.input_echo import input_echo as input_echo
from yera.events.blocks.input_request import request_input_text as request_input_text
from yera.events.blocks.line_chart import line_chart
from yera.events.blocks.markdown import markdown
from yera.events.blocks.slider import request_input_slider as request_input_slider
from yera.events.blocks.spinner import spinner
from yera.events.blocks.system_prompt import system_prompt as system_prompt
from yera.events.blocks.table import table


def reset_all_factories() -> None:
    """Reset all block factory counters to 0."""
    _BlockFactory.reset_all()


__all__ = [
    "action",
    "bar_chart",
    "columns",
    "container",
    "exit_event",
    "form",
    "input_echo",
    "line_chart",
    "markdown",
    "quit_event",
    "request_input_buttons",
    "request_input_date_picker",
    "request_input_slider",
    "request_input_text",
    "reset_all_factories",
    "spinner",
    "system_prompt",
    "table",
]
