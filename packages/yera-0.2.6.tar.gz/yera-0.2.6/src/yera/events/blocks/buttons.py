"""Buttons block implementation."""

from __future__ import annotations

from yera.events.blocks.base import _BlockFactory
from yera.events.models import ButtonsData
from yera.events.stream import push_output


class _ButtonsBlockFactory(_BlockFactory):
    """Factory for creating button blocks."""

    def __init__(self):
        super().__init__("buttons")

    def __call__(
        self,
        options: list[str],
        label: str | None = None,
    ):
        event = self._create_block_output_event(
            data=ButtonsData(options=options, label=label),
            message_type="await_user",
        )
        push_output(event)


# Create a single shared factory instance
_buttons_factory = _ButtonsBlockFactory()


def request_input_buttons(options: list[str], label: str | None = None):
    """Request buttons input from the user."""
    return _buttons_factory(options, label)


__all__ = ["request_input_buttons"]
