"""Columns block implementation."""

from __future__ import annotations

from yera.events.blocks.base import LayoutHandle, _BlockFactory
from yera.events.models import ColumnsData


class _ColumnsBlockFactory(_BlockFactory):
    """Factory for columns blocks."""

    def __init__(self):
        super().__init__("columns")

    def __call__(self, n: int, border: bool = False) -> LayoutHandle:
        """Return a context manager for creating column layouts with n columns."""
        block_id = self._generate_block_id()
        return LayoutHandle(
            block_id, "columns", ColumnsData(showBorder=border, column_count=n)
        )


# Create the columns callable/context manager
columns = _ColumnsBlockFactory()

__all__ = ["columns"]
