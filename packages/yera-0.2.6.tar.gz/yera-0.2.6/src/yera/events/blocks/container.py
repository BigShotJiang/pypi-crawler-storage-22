"""Container block implementation."""

from __future__ import annotations

from yera.events.blocks.base import LayoutHandle, _BlockFactory
from yera.events.models import ContainerData


class _ContainerBlockFactory(_BlockFactory):
    """Factory for container blocks."""

    def __init__(self):
        super().__init__("container")

    def __call__(self, border: bool = False) -> LayoutHandle:
        """Return a context manager for creating container layouts."""
        block_id = self._generate_block_id()
        return LayoutHandle(block_id, "container", ContainerData(showBorder=border))


# Create the container callable/context manager
container = _ContainerBlockFactory()

__all__ = ["container"]
