"""Date picker block implementation."""

from __future__ import annotations

from datetime import date

from yera.events.blocks.base import _BlockFactory
from yera.events.models import DatePickerData
from yera.events.stream import push_output


class _DatePickerBlockFactory(_BlockFactory):
    """Factory for creating date picker blocks."""

    def __init__(self):
        super().__init__("date")

    def __call__(
        self,
        label: str,
        default_date: date | str | None = None,
    ):
        """Create a date picker block."""
        # Default to today's date if not provided
        if default_date is None:
            default_date = date.today()
        elif isinstance(default_date, str):
            # Parse string to date if provided as string
            default_date = date.fromisoformat(default_date)

        data = DatePickerData(value=default_date, label=label)

        # Use shared method with await_user message_type
        event = self._create_block_output_event(data, message_type="await_user")
        push_output(event)


# Create a single shared factory instance
_date_picker_factory = _DatePickerBlockFactory()


def request_input_date_picker(
    label: str,
    default_date: date | str | None = None,
):
    """Request date picker input from the user."""
    return _date_picker_factory(label, default_date)


__all__ = ["request_input_date_picker"]
