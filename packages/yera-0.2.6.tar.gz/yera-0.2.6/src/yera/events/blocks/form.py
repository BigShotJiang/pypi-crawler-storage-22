"""Form block implementation."""

from __future__ import annotations

from yera.events.blocks.base import LayoutHandle, _BlockFactory
from yera.events.models import ContainerData


class _FormBlockFactory(_BlockFactory):
    """Factory for form blocks (layout with await_user children and submit)."""

    def __init__(self):
        super().__init__("form")

    def __call__(self, border: bool = False) -> LayoutHandle:
        """Return a context manager for creating form layouts."""
        block_id = self._generate_block_id()
        return LayoutHandle(block_id, "form", ContainerData(showBorder=border))


# Create the form callable/context manager
form = _FormBlockFactory()

__all__ = ["form"]
