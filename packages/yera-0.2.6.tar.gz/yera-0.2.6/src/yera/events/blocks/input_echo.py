from __future__ import annotations

from yera.events.blocks.base import _BlockFactory
from yera.events.models import MarkdownData
from yera.events.stream import push_output


class _InputEchoBlockFactory(_BlockFactory):
    def __init__(self):
        super().__init__("input_echo")

    def __call__(self, content):
        event = self._create_block_output_event(
            data=MarkdownData(content=content),
            message_type="informational",
        )
        push_output(event)


input_echo = _InputEchoBlockFactory()

__all__ = ["input_echo"]
