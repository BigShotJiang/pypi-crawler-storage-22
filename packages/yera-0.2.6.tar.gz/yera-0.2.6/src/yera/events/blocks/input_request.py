from __future__ import annotations

from typing import Literal

from yera.events.blocks.base import _BlockFactory
from yera.events.models import InputRequestData
from yera.events.stream import push_output


class _InputRequestBlockFactory(_BlockFactory):
    def __init__(self):
        super().__init__("input_request")

    def __call__(self, message: str | None, input_type: Literal["text"]):
        event = self._create_block_output_event(
            data=InputRequestData(message=message, type=input_type),
            message_type="await_user",
        )
        push_output(event)


# Create a single shared factory instance
_input_request_factory = _InputRequestBlockFactory()


def request_input_text(message: str | None = None):
    """Request text input from the user."""
    return _input_request_factory(message or "", "text")


__all__ = ["request_input_text"]
