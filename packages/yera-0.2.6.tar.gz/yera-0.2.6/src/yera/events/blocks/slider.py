"""Slider block implementation."""

from __future__ import annotations

from yera.events.blocks.base import _BlockFactory
from yera.events.models import SliderData
from yera.events.stream import push_output


class _SliderBlockFactory(_BlockFactory):
    """Factory for creating slider blocks."""

    def __init__(self):
        super().__init__("slider")

    def __call__(
        self,
        min_value: float,
        max_value: float,
        label: str,
        default_value: float | None = None,
    ):
        """Create a slider block."""
        # Default to midpoint if not provided
        if default_value is None:
            default_value = (min_value + max_value) / 2

        data = SliderData(
            min_value=min_value,
            max_value=max_value,
            initial_value=default_value,
            label=label,
        )

        # Use shared method with await_user message_type
        event = self._create_block_output_event(data, message_type="await_user")
        push_output(event)


# Create a single shared factory instance
_slider_factory = _SliderBlockFactory()


def request_input_slider(
    min_value: float,
    max_value: float,
    label: str,
    default_value: float | None = None,
):
    """Request slider input from the user."""
    return _slider_factory(min_value, max_value, label, default_value)


__all__ = ["request_input_slider"]
