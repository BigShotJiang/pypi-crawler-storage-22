"""Spinner block implementation."""

from __future__ import annotations

from yera.events.blocks.base import _BlockFactory, _StreamHandle
from yera.events.models import SpinnerData
from yera.events.stream import push_output


class SpinnerStream(_StreamHandle):
    """Stream handle for creating multiple chunks of the same spinner block."""

    def __init__(self, block_id: str, initial_message: str):
        super().__init__(block_id, "spinner")
        self.initial_message = initial_message

    def __enter__(self):
        event = self._create_chunk_event(
            data=SpinnerData(status="active", message=self.initial_message),
        )
        push_output(event)
        return self

    def __exit__(self, exc_type, exc_value, traceback):
        event = self._create_chunk_event(
            data=SpinnerData(status="complete"),
        )
        push_output(event)
        return False

    def update(self, message: str) -> None:
        """Create an update chunk with status 'active'."""
        event = self._create_chunk_event(
            data=SpinnerData(status="active", message=message),
        )
        push_output(event)


class _SpinnerBlockFactory(_BlockFactory):
    """Factory for spinner blocks. Returns a context manager when called with message."""

    def __init__(self):
        super().__init__("spinner")

    def __call__(self, message: str) -> SpinnerStream:
        """Return a context manager for creating multiple spinner chunks."""
        block_id = self._generate_block_id()
        return SpinnerStream(block_id, message)


# Create the spinner callable/context manager
spinner = _SpinnerBlockFactory()


__all__ = ["spinner"]
