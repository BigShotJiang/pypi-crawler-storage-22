from __future__ import annotations

from yera.events.blocks.base import _BlockFactory
from yera.events.models import MarkdownData
from yera.events.stream import push_output


class _SystemPromptBlockFactory(_BlockFactory):
    def __init__(self):
        super().__init__("system_prompt")

    def __call__(self, content):
        event = self._create_block_output_event(
            data=MarkdownData(content=content),
            message_type="informational",
        )
        push_output(event)


system_prompt = _SystemPromptBlockFactory()

__all__ = ["system_prompt"]
