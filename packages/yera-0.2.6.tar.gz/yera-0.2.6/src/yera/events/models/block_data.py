"""Block data models for events blocks."""

from __future__ import annotations

from datetime import date
from typing import Literal

from pydantic import BaseModel


class MarkdownData(BaseModel):
    content: str


class ButtonsData(BaseModel):
    options: list[str]
    label: str | None = None


class ActionData(BaseModel):
    status: Literal["active", "complete"]
    message: str | None = None


class SpinnerData(BaseModel):
    status: Literal["active", "complete"]
    message: str | None = None


class DatePickerData(BaseModel):
    value: date  # Pydantic will serialize to YYYY-MM-DD string automatically
    label: str


class SliderData(BaseModel):
    min_value: float
    max_value: float
    initial_value: float
    label: str


class TableData(BaseModel):
    columns: list[str]
    rows: list[list[str | int | float]]
    border: Literal["all", "none", "horizontal"] = "all"


class ContainerData(BaseModel):
    showBorder: bool


class ColumnsData(BaseModel):
    showBorder: bool
    column_count: int


class LayoutEndData(BaseModel):
    """Empty data for layout_end control event; layout identified by block_id."""

    pass


class BarChartData(BaseModel):
    x_label: str | None
    x_categories: list[str]
    y_label: str | None
    y_values: list[list[int | float | None]]
    colour_label: str | None
    colour_categories: list[str]
    colour_values: list[str]
    horizontal: bool
    stack: bool


class LineChartData(BaseModel):
    x_label: str | None = None
    x_ticks: list[str] | None = None
    y_label: str | None = None
    y_values: list[list[float | None]]
    colour_label: str | None = None
    colour_series: list[str]
    colour_values: list[str]


class InputRequestData(BaseModel):
    type: Literal["text"]
    message: str | None = None


class ExitEventData(BaseModel):
    exit_code: int
    reason: str | None
    return_type: str
    return_value: str | None


__all__ = [
    "ActionData",
    "BarChartData",
    "ButtonsData",
    "ColumnsData",
    "ContainerData",
    "DatePickerData",
    "ExitEventData",
    "InputRequestData",
    "LayoutEndData",
    "LineChartData",
    "MarkdownData",
    "SliderData",
    "SpinnerData",
    "TableData",
]
