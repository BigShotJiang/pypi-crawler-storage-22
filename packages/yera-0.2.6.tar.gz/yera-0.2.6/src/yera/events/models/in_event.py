from pydantic import BaseModel


class InputEvent(BaseModel):
    identifier: str
    type: str
    data: str
