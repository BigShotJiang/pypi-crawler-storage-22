"""Event model for events block events."""

from __future__ import annotations

from datetime import datetime
from typing import Literal

from pydantic import BaseModel, Field

from yera.agents.dataclasses import AgentInstance
from yera.events.models import InputRequestData
from yera.events.models.block_data import (
    ActionData,
    BarChartData,
    ButtonsData,
    ColumnsData,
    ContainerData,
    DatePickerData,
    ExitEventData,
    LayoutEndData,
    LineChartData,
    MarkdownData,
    SliderData,
    SpinnerData,
    TableData,
)


class OutputEvent(BaseModel):
    message_type: Literal["informational", "await_user", "await_agent", "layout"]
    block_type: Literal[
        "markdown",
        "buttons",
        "action",
        "table",
        "slider",
        "date_picker",
        "date",
        "spinner",
        "layout",
        "container",
        "columns",
        "form",
        "input_echo",
        "input_request",
        "system_prompt",
        "bar_chart",
        "line_chart",
        "exit",
        "layout_end",
    ]
    block_id: str
    data: (
        MarkdownData
        | ButtonsData
        | ActionData
        | SpinnerData
        | DatePickerData
        | SliderData
        | TableData
        | ContainerData
        | ColumnsData
        | BarChartData
        | LineChartData
        | InputRequestData
        | ExitEventData
        | LayoutEndData
    )
    chunk_id: int
    agent_instance: AgentInstance
    parent_block_id: str | None = None
    timestamp: datetime = Field(default_factory=datetime.now)


__all__ = ["OutputEvent"]
