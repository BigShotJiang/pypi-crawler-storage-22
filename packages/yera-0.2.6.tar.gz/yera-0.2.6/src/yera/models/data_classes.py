from typing import Literal

from pydantic import BaseModel


class Message(BaseModel):
    role: Literal["user", "system", "assistant"]
    content: dict | str

    @staticmethod
    def user(content: str) -> "Message":
        return Message(role="user", content=content)

    @staticmethod
    def system(content: str) -> "Message":
        return Message(role="system", content=content)

    @staticmethod
    def assistant(content: str) -> "Message":
        return Message(role="assistant", content=content)
