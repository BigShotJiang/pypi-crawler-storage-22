from yera.config2.paths import has_global_yera_toml, has_local_yera_toml
from yera.models.model_atlas import ModelAtlas


class _ModelsProxy:
    _atlas: ModelAtlas | None = None

    def __init__(self):
        self._atlas = None

    def _ensure_atlas(self) -> ModelAtlas:
        from ..config2.read import read_config

        if has_global_yera_toml() or has_local_yera_toml():
            yera_config = read_config()
            self._atlas = ModelAtlas.from_yera_config(yera_config)
        else:
            self._atlas = ModelAtlas()
        return self._atlas

    def __getattr__(self, name):
        return getattr(self._ensure_atlas(), name)

    def __getitem__(self, key):
        return self._ensure_atlas()[key]

    def __dir__(self):
        """Forward to atlas for tab completion"""
        return dir(self._ensure_atlas())

    def _ipython_key_completions_(self):
        """Forward to atlas for IPython/Jupyter completion"""
        return self._ensure_atlas()._ipython_key_completions_()

    def list_models(self):
        """Forward the list_models method"""
        return self._ensure_atlas().list_models()

    def _repr_html_(self):
        """Forward HTML representation for Jupyter notebooks"""
        return self._ensure_atlas()._repr_html_()


llm: ModelAtlas = _ModelsProxy()
