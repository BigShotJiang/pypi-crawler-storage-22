from collections.abc import Iterator

from yera.models.data_classes import Message
from yera.models.llm_interfaces.base import BaseLLMInterface, TBaseModel


class AwsBedrockLLM(BaseLLMInterface):
    def chat(self, messages: list[Message], **kwargs) -> Iterator[str]:
        pass

    def make_struct(
        self, prompt: str, cls: type[TBaseModel], **kwargs
    ) -> Iterator[str]:
        pass
