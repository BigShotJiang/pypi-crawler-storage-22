from openai import AzureOpenAI

from yera.config2.keyring import DevKeyring
from yera.models.llm_interfaces.open_ai import OpenAILLM


class AzureOpenAILLM(OpenAILLM):
    def __init__(self, config, overrides, creds_map):
        super().__init__(config, overrides, creds_map)
        self._endpoint_path = f"providers.{creds_map['endpoint']}"
        self._api_key_path = f"providers.{creds_map['api_key']}"

    def start(self):
        endpoint = DevKeyring.get(self._endpoint_path)
        api_key = DevKeyring.get(self._api_key_path)
        self.client = AzureOpenAI(
            api_version="2024-12-01-preview",
            azure_endpoint=endpoint,
            api_key=api_key,
        )
