from abc import ABC, abstractmethod
from collections.abc import Iterator

from yera.dsl.struct import TBaseModel
from yera.models.data_classes import Message


class BaseLLMInterface(ABC):
    def __init__(self, **kwargs):
        self.kwargs = dict(kwargs)

    @abstractmethod
    def chat(self, messages: list[Message], **kwargs) -> Iterator[str]:
        pass

    @abstractmethod
    def make_struct(
        self, messages: list[Message], cls: type[TBaseModel], **kwargs
    ) -> Iterator[str]:
        pass

    def start(self):
        return

    def stop(self):
        return
