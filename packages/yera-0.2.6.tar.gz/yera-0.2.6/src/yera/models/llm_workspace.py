from yera.models.data_classes import Message


class LLMWorkspace:
    def __init__(self):
        self.messages: list[Message] = []
        self.variables: dict = {}

    def add_user_message(self, content: str | dict):
        message = Message.user(content)
        self.messages.append(message)

    def add_sys_message(self, content: str | dict):
        message = Message.system(content)
        self.messages.append(message)

    def add_assistant_message(self, content: str | dict):
        message = Message.assistant(content)
        self.messages.append(message)
