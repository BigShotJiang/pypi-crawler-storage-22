from .base import OpaqueCallable as OpaqueCallable
from .decorator import opaque as opaque
from .opaque_function import OpaqueFunction as OpaqueFunction

__all__ = [
    "OpaqueCallable",
    "OpaqueFunction",
    "opaque",
]
