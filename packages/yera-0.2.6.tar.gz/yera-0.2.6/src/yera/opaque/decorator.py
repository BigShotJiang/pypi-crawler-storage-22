from collections.abc import Callable

from yera.opaque.opaque_function import OpaqueFunction


def opaque(func: Callable) -> OpaqueFunction:
    """Decorator to mark a function as opaque to the tracer."""
    return OpaqueFunction(func)
