from __future__ import annotations

import functools
from collections.abc import Callable
from typing import Any

from yera.config.config_utils import extract_function_config
from yera.opaque.base import OpaqueCallable


class OpaqueFunction(OpaqueCallable):
    """Wrapper for functions marked with @yk.opaque decorator."""

    def __init__(self, func: Callable):
        self._func = func
        self._function_config = extract_function_config(func)
        functools.update_wrapper(self, func)

    def __call__(self, *args: Any, **kwargs: Any) -> Any:
        return self._func(*args, **kwargs)

    @property
    def name(self) -> str:
        """Get the name of the opaque function."""
        return self._function_config.name
