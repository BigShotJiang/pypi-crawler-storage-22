from __future__ import annotations

from collections.abc import Callable
from typing import Any

from yera.config.tool_config import ToolConfig
from yera.tools.base import Tool
from yera.tools.tool_utils import reconstruct_tool_function


class AtlasTool(Tool):
    def __init__(self, tool_config: ToolConfig):
        super().__init__(tool_config)
        self._callable: Callable | None = None

    def __call__(self, *args, **kwargs) -> Any:
        # Tool is reconstructed lazily from tool_config the first time it is called, and cached for subsequent calls
        if self._callable is None:
            self._callable = reconstruct_tool_function(self.tool_config)
        return self._callable(*args, **kwargs)
