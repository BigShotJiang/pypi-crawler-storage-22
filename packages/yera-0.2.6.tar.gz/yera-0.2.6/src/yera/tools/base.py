from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Any

from yera.config.tool_config import ToolConfig
from yera.opaque import OpaqueCallable


class Tool(OpaqueCallable, ABC):
    """Abstract base class for all Yera tools. Tools are a specialisation of opaque callables."""

    def __init__(self, tool_config: ToolConfig):
        self.tool_config = tool_config

    @abstractmethod
    def __call__(self, *args: Any, **kwargs: Any) -> Any:
        """Execute the tool with the given arguments."""
        pass

    @property
    def name(self) -> str:
        """Get the name of the tool."""
        return self.tool_config.function_config.name
