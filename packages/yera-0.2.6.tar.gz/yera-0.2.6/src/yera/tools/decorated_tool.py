from __future__ import annotations

import functools
from collections.abc import Callable
from typing import Any

from yera.config.tool_config import ToolConfig
from yera.tools.base import Tool


class DecoratedTool(Tool):
    def __init__(self, func: Callable, tool_config: ToolConfig):
        super().__init__(tool_config)
        self._func = func
        functools.update_wrapper(self, func)

    def __call__(self, *args: Any, **kwargs: Any) -> Any:
        return self._func(*args, **kwargs)
