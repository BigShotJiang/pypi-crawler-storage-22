YESIG

Yes another python interface for the signal-cli rest api.
Simple and Effictent just YESIG!

Set the envoirment var SIGNAL_ACCOUNT with the signal account in use!
This Interface is built on requests and websockets for a live jsonrpc asyncio mode.

Installation:

    python -m pip install yesig


Received Messages are stored as dataclasses such as ReceivedMessage ReceivedPreview ReceiptMessage where the first two are able to contain ReceivedAttachment's.


Receiving messages can be as simple as:
        
        receiver = RestReceiver(port=1312, attachment_folder=~/signal_attachments)
        msgs = receiver.receive()

Or live:
        
        await receive_from_socket(queue=q) # Run as a asyncio.thread for example



To send message simply call:

        Transmitter().send([+99999999, ThisIsAUsername.777, MyReallyCoolGroup], msg="Hello world", attachments=["funny_duck.jpg"])


Download an attachment with the receiver:
        
        fpath = Receiver().download(AttachmentId)


To send a preview use a preview object:        

        preview=Preview(url="https://wiki.archlinux.org",title="i use", description="Arch btw", filepath="/path/to/funnier_duck.jpg")
        Transmitter().send("+5512344567", msg="Hey dude\nDid you know:" preview=preview)



Planned features:

* Mentions
* Reply
* Edit Messages
* React
* Send/Stop writing
* Create/Delete Groups
* Fully asyncio|aiohttp support

Goal is to have a simple yet efficient and pythonic interface for the signal-rest api.