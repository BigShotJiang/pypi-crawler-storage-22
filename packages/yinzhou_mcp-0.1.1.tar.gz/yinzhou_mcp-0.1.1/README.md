# yinzhou-mcp

一个基于MCP的Python项目，提供Bark通知等工具。

## 项目结构

```
yinzhou-mcp/
├── src/
│   ├── bark/          # Bark通知模块
│   │   ├── __init__.py
│   │   └── bark.py
│   └── yinzhou-mcp/   # 主模块
│       └── __init__.py
├── pyproject.toml     # 项目配置文件
├── .gitignore         # Git忽略文件
└── README.md          # 项目说明文档
```

## 安装要求

- Python 3.11+
- [uv](https://github.com/astral-sh/uv) - 快速Python包管理器

## 安装教程

### 1. 安装uv

```bash
# Windows (PowerShell)
powershell -ExecutionPolicy ByPass -c "irm https://astral.sh/uv/install.ps1 | iex"

# macOS 和 Linux
curl -LsSf https://astral.sh/uv/install.sh | sh
```

### 2. 安装项目

```bash
# 从PyPI安装
uv add yinzhou-mcp

# 或从源码安装
uv sync
```

## 使用说明

### Bark通知模块

#### 配置Bark客户端

```python
from yinzhou-mcp.bark import configure

# 配置Bark客户端
configure("http://yin520.cn:777", "your-device-key")
```

#### 发送通知

```python
from yinzhou-mcp.bark import send, send_simple, send_with_sound

# 发送普通通知
send("测试标题", "测试内容")

# 发送简单通知
send_simple("简单通知内容")

# 发送带声音的通知
send_with_sound("测试标题", "测试内容", "minuet")
```

#### 其他通知类型

- `send_continuous_ring`: 发送持续响铃的通知
- `send_with_icon`: 发送带有自定义图标的通知
- `send_with_group`: 发送带有分组名称的通知
- `send_encrypted`: 发送加密通知
- `send_critical_alert`: 发送带有自定义音量的重要警告
- `send_with_url`: 发送带有要打开的URL的通知
- `send_with_image`: 发送带有图片的通知
- `send_with_copy`: 发送带有要复制到剪贴板的文本的通知

## 开发

### 添加依赖

```bash
# 添加运行时依赖
uv add package-name

# 添加开发依赖
uv add --dev package-name
```

### 运行测试

```bash
# 使用uv运行测试
uv run pytest

# 或使用覆盖率
uv run pytest --cov=yinzhou-mcp
```

### 代码格式化

```bash
# 使用black格式化代码
uv run black src/

# 使用ruff检查代码
uv run ruff check src/
```

## 构建和发布

### 构建项目

```bash
# 构建分发包
uv build
```

### 发布到PyPI

```bash
# 发布到PyPI
uv publish
```

## 参与贡献

1. Fork 本仓库
2. 新建 Feat_xxx 分支
3. 提交代码
4. 新建 Pull Request

## 许可证

MIT License
