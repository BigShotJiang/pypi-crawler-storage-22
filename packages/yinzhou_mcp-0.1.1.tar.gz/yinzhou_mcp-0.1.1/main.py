from mcp.server.fastmcp import FastMCP

# 初始化 FastMCP 实例，命名为 "yinzhou-mcp"
mcp = FastMCP("yinzhou-mcp")


# 定义一个加法工具函数
@mcp.tool("加法计算工具")
def add(a: int, b: int) -> int:
    """
    计算两个整数的和

    参数:
        a (int): 第一个整数
        b (int): 第二个整数

    返回:
        int: 两数之和
    """
    return a + b


# 程序入口：以 stdio 模式运行 MCP 服务
if __name__ == '__main__':
    mcp.run(transport='stdio')
