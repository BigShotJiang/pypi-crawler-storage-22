from mcp.server.fastmcp import FastMCP
from .bark import BarkClient

# 初始化 FastMCP 实例，命名为 "yinzhou-mcp-bark"
mcp = FastMCP("yinzhou-mcp-bark")

# 配置变量
SERVER_URL = None
DEVICE_KEY = None


@mcp.tool()
def configure(server_url: str, device_key: str):
    """
    配置Bark客户端参数。

    参数:
        server_url: Bark服务器的基础URL（例如："http://yin520.cn:777"）
        device_key: 您的苹果设备的设备密钥

    返回:
        dict: 配置成功信息
    """
    global SERVER_URL, DEVICE_KEY
    SERVER_URL = server_url
    DEVICE_KEY = device_key
    return {"status": "success", "message": "Bark客户端配置成功"}


def get_client():
    """
    获取BarkClient实例。

    返回:
        BarkClient: 配置好的BarkClient实例

    异常:
        ValueError: 如果未配置server_url或device_key
    """
    if not SERVER_URL or not DEVICE_KEY:
        raise ValueError("Bark客户端未配置，请先调用configure方法设置server_url和device_key")
    return BarkClient(SERVER_URL, DEVICE_KEY)


@mcp.tool()
def send(title: str, body: str = None, **kwargs):
    """
    向设备发送通知。

    参数:
        title: 通知的标题
        body: 通知的正文内容（可选）
        **kwargs: 通知的其他参数

    返回:
        Bark服务器的响应，以字典形式返回

    其他参数:
        sound: 要播放的声音（例如："minuet"）
        call: 设置为1以持续响铃
        icon: 自定义图标URL（需要iOS 15+）
        group: 通知分组名称
        ciphertext: 加密文本
        level: 警告级别（例如："critical"）
        volume: 音量级别（0-10）
        url: 点击通知时要打开的URL
        image: 要在通知中显示的图片URL
        copy: 要复制到剪贴板的文本
        autoCopy: 设置为1以自动将内容复制到剪贴板

    异常:
        ValueError: 如果未配置server_url或device_key
    """
    client = get_client()
    return client.send(title, body, **kwargs)


@mcp.tool()
def send_simple(content: str):
    """
    发送仅包含内容的简单通知。

    参数:
        content: 通知的内容

    返回:
        Bark服务器的响应，以字典形式返回

    异常:
        ValueError: 如果未配置server_url或device_key
    """
    client = get_client()
    return client.send_simple(content)


@mcp.tool()
def send_with_sound(title: str, body: str = None, sound: str = "minuet"):
    """
    发送带有自定义声音的通知。

    参数:
        title: 通知的标题
        body: 通知的正文内容（可选）
        sound: 要播放的声音

    返回:
        Bark服务器的响应，以字典形式返回

    异常:
        ValueError: 如果未配置server_url或device_key
    """
    client = get_client()
    return client.send_with_sound(title, body, sound)


@mcp.tool()
def send_continuous_ring(title: str, body: str = None):
    """
    发送持续响铃的通知。

    参数:
        title: 通知的标题
        body: 通知的正文内容（可选）

    返回:
        Bark服务器的响应，以字典形式返回

    异常:
        ValueError: 如果未配置server_url或device_key
    """
    client = get_client()
    return client.send_continuous_ring(title, body)


@mcp.tool()
def send_with_icon(title: str, body: str = None, icon: str = "https://day.app/assets/images/avatar.jpg"):
    """
    发送带有自定义图标的通知（需要iOS 15+）。

    参数:
        title: 通知的标题
        body: 通知的正文内容（可选）
        icon: 自定义图标的URL

    返回:
        Bark服务器的响应，以字典形式返回

    异常:
        ValueError: 如果未配置server_url或device_key
    """
    client = get_client()
    return client.send_with_icon(title, body, icon)


@mcp.tool()
def send_with_group(title: str, body: str = None, group: str = "default"):
    """
    发送带有分组名称的通知。

    参数:
        title: 通知的标题
        body: 通知的正文内容（可选）
        group: 通知的分组名称

    返回:
        Bark服务器的响应，以字典形式返回

    异常:
        ValueError: 如果未配置server_url或device_key
    """
    client = get_client()
    return client.send_with_group(title, body, group)


@mcp.tool()
def send_encrypted(title: str, ciphertext: str):
    """
    发送加密通知。

    参数:
        title: 通知的标题
        ciphertext: 加密文本

    返回:
        Bark服务器的响应，以字典形式返回

    异常:
        ValueError: 如果未配置server_url或device_key
    """
    client = get_client()
    return client.send_encrypted(title, ciphertext)


@mcp.tool()
def send_critical_alert(title: str, body: str = None, volume: int = 5):
    """
    发送带有自定义音量的重要警告。

    参数:
        title: 通知的标题
        body: 通知的正文内容（可选）
        volume: 音量级别（0-10）

    返回:
        Bark服务器的响应，以字典形式返回

    异常:
        ValueError: 如果未配置server_url或device_key
    """
    client = get_client()
    return client.send_critical_alert(title, body, volume)


@mcp.tool()
def send_with_url(title: str, url: str, body: str = None):
    """
    发送带有要打开的URL的通知。

    参数:
        title: 通知的标题
        url: 点击通知时要打开的URL
        body: 通知的正文内容（可选）

    返回:
        Bark服务器的响应，以字典形式返回

    异常:
        ValueError: 如果未配置server_url或device_key
    """
    client = get_client()
    return client.send_with_url(title, url, body)


@mcp.tool()
def send_with_image(title: str, image: str, body: str = None):
    """
    发送带有图片的通知。

    参数:
        title: 通知的标题
        image: 要显示的图片的URL
        body: 通知的正文内容（可选）

    返回:
        Bark服务器的响应，以字典形式返回

    异常:
        ValueError: 如果未配置server_url或device_key
    """
    client = get_client()
    return client.send_with_image(title, image, body)


@mcp.tool()
def send_with_copy(title: str, copy: str, body: str = None, auto_copy: bool = False):
    """
    发送带有要复制到剪贴板的文本的通知。

    参数:
        title: 通知的标题
        copy: 要复制到剪贴板的文本
        body: 通知的正文内容（可选）
        auto_copy: 是否自动将内容复制到剪贴板

    返回:
        Bark服务器的响应，以字典形式返回

    异常:
        ValueError: 如果未配置server_url或device_key
    """
    client = get_client()
    return client.send_with_copy(title, copy, body, auto_copy)


def main() -> None:
    mcp.run(transport='stdio')
