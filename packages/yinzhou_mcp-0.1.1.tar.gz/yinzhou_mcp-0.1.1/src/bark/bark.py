"""Bark服务器通知模块。"""

import requests
from typing import Optional, Dict, Any


class BarkClient:
    """用于向苹果设备发送通知的Bark服务器客户端。"""

    def __init__(self, server_url: str, device_key: str):
        """
        初始化一个新的BarkClient实例。

        参数:
            server_url: Bark服务器的基础URL（例如："http://yin520.cn:777"）
            device_key: 您的苹果设备的设备密钥
        """
        self.server_url = server_url.rstrip('/')
        self.device_key = device_key

    def send(self, title: str, body: Optional[str] = None, **kwargs) -> Dict[str, Any]:
        """
        向设备发送通知。

        参数:
            title: 通知的标题
            body: 通知的正文内容（可选）
            **kwargs: 通知的其他参数

        返回:
            Bark服务器的响应，以字典形式返回

        其他参数:
            sound: 要播放的声音（例如："minuet"）
            call: 设置为1以持续响铃
            icon: 自定义图标URL（需要iOS 15+）
            group: 通知分组名称
            ciphertext: 加密文本
            level: 警告级别（例如："critical"）
            volume: 音量级别（0-10）
            url: 点击通知时要打开的URL
            image: 要在通知中显示的图片URL
            copy: 要复制到剪贴板的文本
            autoCopy: 设置为1以自动将内容复制到剪贴板
        """
        # 构建URL路径
        path_parts = [self.device_key, title]
        if body:
            path_parts.append(body)
        path = '/'.join(path_parts)

        # 构建完整URL
        url = f"{self.server_url}/{path}"

        # 如果有查询参数，则添加
        if kwargs:
            # 过滤掉None值
            params = {k: v for k, v in kwargs.items() if v is not None}
            if params:
                response = requests.get(url, params=params)
            else:
                response = requests.get(url)
        else:
            response = requests.get(url)

        # 返回响应的JSON格式
        return response.json()

    def send_simple(self, content: str) -> Dict[str, Any]:
        """
        发送仅包含内容的简单通知。

        参数:
            content: 通知的内容

        返回:
            Bark服务器的响应，以字典形式返回
        """
        url = f"{self.server_url}/{self.device_key}/{content}"
        response = requests.get(url)
        return response.json()

    def send_with_sound(self, title: str, body: Optional[str] = None, sound: str = "minuet") -> Dict[str, Any]:
        """
        发送带有自定义声音的通知。

        参数:
            title: 通知的标题
            body: 通知的正文内容（可选）
            sound: 要播放的声音

        返回:
            Bark服务器的响应，以字典形式返回
        """
        return self.send(title, body, sound=sound)

    def send_continuous_ring(self, title: str, body: Optional[str] = None) -> Dict[str, Any]:
        """
        发送持续响铃的通知。

        参数:
            title: 通知的标题
            body: 通知的正文内容（可选）

        返回:
            Bark服务器的响应，以字典形式返回
        """
        return self.send(title, body, call=1)

    def send_with_icon(self, title: str, body: Optional[str] = None, icon: str = "https://day.app/assets/images/avatar.jpg") -> Dict[str, Any]:
        """
        发送带有自定义图标的通知（需要iOS 15+）。

        参数:
            title: 通知的标题
            body: 通知的正文内容（可选）
            icon: 自定义图标的URL

        返回:
            Bark服务器的响应，以字典形式返回
        """
        return self.send(title, body, icon=icon)

    def send_with_group(self, title: str, body: Optional[str] = None, group: str = "default") -> Dict[str, Any]:
        """
        发送带有分组名称的通知。

        参数:
            title: 通知的标题
            body: 通知的正文内容（可选）
            group: 通知的分组名称

        返回:
            Bark服务器的响应，以字典形式返回
        """
        return self.send(title, body, group=group)

    def send_encrypted(self, title: str, ciphertext: str) -> Dict[str, Any]:
        """
        发送加密通知。

        参数:
            title: 通知的标题
            ciphertext: 加密文本

        返回:
            Bark服务器的响应，以字典形式返回
        """
        return self.send(title, ciphertext=ciphertext)

    def send_critical_alert(self, title: str, body: Optional[str] = None, volume: int = 5) -> Dict[str, Any]:
        """
        发送带有自定义音量的重要警告。

        参数:
            title: 通知的标题
            body: 通知的正文内容（可选）
            volume: 音量级别（0-10）

        返回:
            Bark服务器的响应，以字典形式返回
        """
        return self.send(title, body, level="critical", volume=volume)

    def send_with_url(self, title: str, url: str, body: Optional[str] = None) -> Dict[str, Any]:
        """
        发送带有要打开的URL的通知。

        参数:
            title: 通知的标题
            url: 点击通知时要打开的URL
            body: 通知的正文内容（可选）

        返回:
            Bark服务器的响应，以字典形式返回
        """
        return self.send(title, body, url=url)

    def send_with_image(self, title: str, image: str, body: Optional[str] = None) -> Dict[str, Any]:
        """
        发送带有图片的通知。

        参数:
            title: 通知的标题
            image: 要显示的图片的URL
            body: 通知的正文内容（可选）

        返回:
            Bark服务器的响应，以字典形式返回
        """
        return self.send(title, body, image=image)

    def send_with_copy(self, title: str, copy: str, body: Optional[str] = None, auto_copy: bool = False) -> Dict[str, Any]:
        """
        发送带有要复制到剪贴板的文本的通知。

        参数:
            title: 通知的标题
            copy: 要复制到剪贴板的文本
            body: 通知的正文内容（可选）
            auto_copy: 是否自动将内容复制到剪贴板

        返回:
            Bark服务器的响应，以字典形式返回
        """
        kwargs = {"copy": copy}
        if auto_copy:
            kwargs["autoCopy"] = 1
        return self.send(title, body, **kwargs)


if __name__ == "__main__":
    # 测试BarkClient类
    print("测试BarkClient类定义...")
    print(f"BarkClient类: {BarkClient}")
    print("BarkClient类定义成功！")
    
    # 测试初始化
    try:
        client = BarkClient("http://test.com", "test-key")
        print("BarkClient初始化成功！")
        print(f"服务器URL: {client.server_url}")
        print(f"设备密钥: {client.device_key}")
    except Exception as e:
        print(f"BarkClient初始化失败: {e}")
