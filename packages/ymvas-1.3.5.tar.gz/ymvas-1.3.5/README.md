Ymvas - handle your life like a developer!

Installation:
```bash
pip3 install ymvas
```

Installation system base:
```bash
curl -sL https://docs.ymvas.com/vas/ymvas/install-unix.bash | bash
```

