# Module definition file
#
# This file is present to allow Examples to reference
# yoctolib source files using relative paths
#
# Nothing special to be done here :-)