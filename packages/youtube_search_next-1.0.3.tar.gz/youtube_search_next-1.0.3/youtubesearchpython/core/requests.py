import httpx
import os

from youtubesearchpython.core.constants import userAgent

class RequestCore:
    def __init__(self):
        self.url = None
        self.data = None
        self.timeout = 2
        # httpx 0.26+ uses 'proxy' instead of 'proxies' and expects a single URL string
        self.proxy = None
        https_proxy = os.environ.get("HTTPS_PROXY")
        http_proxy = os.environ.get("HTTP_PROXY")
        if https_proxy:
            self.proxy = https_proxy
        elif http_proxy:
            self.proxy = http_proxy

    def syncPostRequest(self) -> httpx.Response:
        return httpx.post(
            self.url,
            headers={"User-Agent": userAgent},
            json=self.data,
            timeout=self.timeout,
            proxy=self.proxy
        )

    async def asyncPostRequest(self) -> httpx.Response:
        async with httpx.AsyncClient(proxy=self.proxy) as client:
            r = await client.post(self.url, headers={"User-Agent": userAgent}, json=self.data, timeout=self.timeout)
            return r

    def syncGetRequest(self) -> httpx.Response:
        return httpx.get(self.url, headers={"User-Agent": userAgent}, timeout=self.timeout, cookies={'CONSENT': 'YES+1'}, proxy=self.proxy)

    async def asyncGetRequest(self) -> httpx.Response:
        async with httpx.AsyncClient(proxy=self.proxy) as client:
            r = await client.get(self.url, headers={"User-Agent": userAgent}, timeout=self.timeout, cookies={'CONSENT': 'YES+1'})
            return r
