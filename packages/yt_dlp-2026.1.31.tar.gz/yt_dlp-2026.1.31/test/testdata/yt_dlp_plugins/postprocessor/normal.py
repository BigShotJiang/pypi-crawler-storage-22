from yt_dlp.postprocessor.common import PostProcessor


class NormalPluginPP(PostProcessor):
    REPLACED = False
