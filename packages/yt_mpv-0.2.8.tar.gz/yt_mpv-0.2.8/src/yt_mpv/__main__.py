"""
Executable module entry point for yt-mpv
This file is executed when running 'python -m yt_mpv'
"""

from yt_mpv.cli.main import main

if __name__ == "__main__":
    main()
