"""
Archive-related functionality for yt-mpv
"""
