"""
Command-line interface for yt-mpv
"""
