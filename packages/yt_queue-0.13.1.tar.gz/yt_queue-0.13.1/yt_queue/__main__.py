import yt_queue

if __name__ == '__main__':
    yt_queue.cli()
