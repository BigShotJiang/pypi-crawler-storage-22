"""Prompt templates for study material generation."""
