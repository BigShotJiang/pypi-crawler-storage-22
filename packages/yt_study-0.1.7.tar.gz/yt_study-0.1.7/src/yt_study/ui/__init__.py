"""UI components for yt-study."""
