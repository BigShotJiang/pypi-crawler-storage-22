"""Configuration wizard for yt-study."""

import json
from pathlib import Path
from typing import Any

import structlog
from rich.panel import Panel
from rich.prompt import Confirm, Prompt
from rich.table import Table

from yt_study import __version__
from yt_study.ui.console import console


logger = structlog.get_logger(__name__)


# API key configuration for different providers
PROVIDER_CONFIG: dict[str, dict[str, Any]] = {
    "gemini": {
        "name": "Google Gemini",
        "env_var": "GEMINI_API_KEY",
        "api_url": "https://aistudio.google.com/app/apikey",
        "keywords": ["gemini", "vertex"],
    },
    "openai": {
        "name": "OpenAI (ChatGPT)",
        "env_var": "OPENAI_API_KEY",
        "api_url": "https://platform.openai.com/api-keys",
        "keywords": ["gpt", "openai", "o1"],
    },
    "anthropic": {
        "name": "Anthropic (Claude)",
        "env_var": "ANTHROPIC_API_KEY",
        "api_url": "https://console.anthropic.com/settings/keys",
        "keywords": ["claude", "anthropic"],
    },
    "groq": {
        "name": "Groq",
        "env_var": "GROQ_API_KEY",
        "api_url": "https://console.groq.com/keys",
        "keywords": ["groq"],
    },
    "xai": {
        "name": "xAI (Grok)",
        "env_var": "XAI_API_KEY",
        "api_url": "https://console.x.ai/",
        "keywords": ["grok", "xai"],
    },
    "mistral": {
        "name": "Mistral AI",
        "env_var": "MISTRAL_API_KEY",
        "api_url": "https://console.mistral.ai/api-keys/",
        "keywords": ["mistral"],
    },
    "cohere": {
        "name": "Cohere",
        "env_var": "COHERE_API_KEY",
        "api_url": "https://dashboard.cohere.com/api-keys",
        "keywords": ["cohere", "command"],
    },
    "deepseek": {
        "name": "DeepSeek",
        "env_var": "DEEPSEEK_API_KEY",
        "api_url": "https://platform.deepseek.com/api_keys",
        "keywords": ["deepseek"],
    },
}


def get_config_path() -> Path:
    """Get path to user config file."""
    config_dir = Path.home() / ".yt-study"
    config_dir.mkdir(exist_ok=True)
    return config_dir / "config.env"


def _get_cache_path() -> Path:
    """Get path to models cache file."""
    return Path.home() / ".yt-study" / "cache" / "models.json"


def _load_models_from_cache() -> dict[str, list[str]] | None:
    """Load models from cache if version matches."""
    try:
        cache_path = _get_cache_path()
        if not cache_path.exists():
            return None

        with cache_path.open("r", encoding="utf-8") as f:
            cache_data = json.load(f)

        # Check if version matches
        if cache_data.get("version") != __version__:
            logger.debug(
                "Cache version mismatch",
                cached_version=cache_data.get("version"),
                current_version=__version__,
            )
            return None

        models_data = cache_data.get("models")
        if isinstance(models_data, dict):
            return models_data
        return None
    except Exception as e:
        logger.debug("Failed to load models cache", error=str(e))
        return None


def _save_models_to_cache(models: dict[str, list[str]]) -> None:
    """Save models to cache with current version."""
    try:
        cache_path = _get_cache_path()
        cache_path.parent.mkdir(parents=True, exist_ok=True)
        cache_data = {"version": __version__, "models": models}
        with cache_path.open("w", encoding="utf-8") as f:
            json.dump(cache_data, f, indent=2)
    except Exception as e:
        logger.debug("Failed to save models cache", error=str(e))


def load_config() -> dict[str, str]:
    """Load existing configuration."""
    config_path = get_config_path()
    loaded_config = {}

    if config_path.exists():
        try:
            with config_path.open(encoding="utf-8") as f:
                for line in f:
                    line = line.strip()
                    if line and not line.startswith("#") and "=" in line:
                        key, value = line.split("=", 1)
                        loaded_config[key.strip()] = value.strip()
        except Exception:
            # If corrupted, return empty
            pass

    return loaded_config


def save_config(new_config: dict[str, str]) -> None:
    """
    Save configuration to file, preserving existing keys.

    Args:
        new_config: Dictionary of new configuration values to merge/update.
    """
    config_path = get_config_path()
    current_config = load_config()

    # Merge new config into current config
    current_config.update(new_config)

    with config_path.open("w", encoding="utf-8") as f:
        f.write("# yt-study Configuration\n\n")

        # Sort keys for consistent output, prioritize critical ones
        priority_keys = ["DEFAULT_MODEL", "OUTPUT_DIR", "MAX_CONCURRENT_VIDEOS"]
        for key in priority_keys:
            if key in current_config:
                f.write(f"{key}={current_config[key]}\n")

        # Write remaining keys
        for key, value in sorted(current_config.items()):
            if key not in priority_keys:
                f.write(f"{key}={value}\n")

    console.print(
        f"\n[green]✓[/green] Configuration saved to: [cyan]{config_path}[/cyan]"
    )


def get_available_models(force_refresh: bool = False) -> dict[str, list[str]]:
    """Fetch available models from LiteLLM."""
    # Try loading from cache first unless forced
    if not force_refresh:
        cached_models = _load_models_from_cache()
        if cached_models:
            return cached_models

    try:
        # Lazy import to avoid slow startup if not running setup
        from litellm import model_list

        # Group models by provider
        provider_models: dict[str, list[str]] = {}

        for model in model_list:
            # Determine provider from model name
            provider = None
            model_lower = model.lower()

            for prov_key, prov_config in PROVIDER_CONFIG.items():
                if any(keyword in model_lower for keyword in prov_config["keywords"]):
                    provider = prov_key
                    break

            if provider:
                if provider not in provider_models:
                    provider_models[provider] = []
                provider_models[provider].append(model)

        # Sort models within each provider
        for provider in provider_models:
            provider_models[provider] = sorted(set(provider_models[provider]))

        # Save to cache
        if provider_models:
            _save_models_to_cache(provider_models)

        return provider_models

    except Exception as e:
        console.print(f"[yellow]⚠ Could not fetch models from LiteLLM: {e}[/yellow]")
        console.print("[yellow]Using fallback model list...[/yellow]")

        # Fallback to curated list
        return {
            "gemini": [
                "gemini/gemini-2.0-flash",
                "gemini/gemini-2.0-flash-lite-preview-02-05",
                "gemini/gemini-1.5-pro",
                "gemini/gemini-1.5-flash",
                "gemini/gemini-1.5-flash-8b",
            ],
            "openai": [
                "gpt-4o",
                "gpt-4o-mini",
                "gpt-4-turbo",
                "o1",
                "o1-mini",
                "o1-preview",
            ],
            "anthropic": [
                "anthropic/claude-3-7-sonnet-20250219",
                "anthropic/claude-3-5-sonnet-20241022",
                "anthropic/claude-3-5-haiku-20241022",
                "anthropic/claude-3-opus-20240229",
            ],
            "deepseek": [
                "deepseek/deepseek-chat",
                "deepseek/deepseek-reasoner",
                "deepseek/deepseek-v3",
            ],
            "groq": [
                "groq/llama-3.3-70b-versatile",
                "groq/llama-3.1-70b-versatile",
                "groq/llama-3.1-8b-instant",
                "groq/mixtral-8x7b-32768",
                "groq/deepseek-r1-distill-llama-70b",
            ],
            "mistral": [
                "mistral/mistral-large-latest",
                "mistral/pixtral-large-latest",
                "mistral/mistral-small-latest",
                "mistral/open-mistral-nemo",
            ],
            "xai": [
                "xai/grok-2-latest",
                "xai/grok-2-1212",
                "xai/grok-beta",
            ],
            "cohere": [
                "cohere/command-r-plus",
                "cohere/command-r",
            ],
        }


def select_provider(available_models: dict[str, list[str]]) -> str:
    """Interactive provider selection."""
    console.print("\n[bold cyan]Select LLM Provider:[/bold cyan]\n")

    # Create table of providers
    table = Table(show_header=True, header_style="bold magenta")
    table.add_column("#", style="dim", width=4)
    table.add_column("Provider", style="cyan")
    table.add_column("Models Available", style="dim")

    providers_list = []
    for prov_key, _prov_config in PROVIDER_CONFIG.items():
        if prov_key in available_models:
            providers_list.append(prov_key)

    for i, provider_key in enumerate(providers_list, 1):
        config_data = PROVIDER_CONFIG[provider_key]
        model_count = len(available_models.get(provider_key, []))
        table.add_row(str(i), config_data["name"], f"{model_count} models")

    console.print(table)
    console.print(f"\n[dim]Total providers: {len(providers_list)}[/dim]")

    while True:
        choice = Prompt.ask(
            "\nSelect provider",
            choices=[str(i) for i in range(1, len(providers_list) + 1)],
        )
        return providers_list[int(choice) - 1]


def select_model(provider_key: str, available_models: dict[str, list[str]]) -> str:
    """Interactive model selection."""
    provider_config = PROVIDER_CONFIG[provider_key]
    models = available_models.get(provider_key, [])

    if not models:
        console.print(f"[yellow]No models found for {provider_config['name']}[/yellow]")
        return f"{provider_key}/default"

    console.print(f"\n[bold cyan]Select {provider_config['name']} Model:[/bold cyan]\n")
    console.print(f"[dim]Showing {len(models)} available models[/dim]\n")

    # Show models in pages of 20
    page_size = 20
    current_page = 0

    while True:
        start_idx = current_page * page_size
        end_idx = min(start_idx + page_size, len(models))
        page_models = models[start_idx:end_idx]

        # Create table of models
        table = Table(show_header=True, header_style="bold magenta")
        table.add_column("#", style="dim", width=4)
        table.add_column("Model", style="green")

        for i, model in enumerate(page_models, start_idx + 1):
            # Highlight recommended models
            model_display = model
            if "flash" in model.lower() or "mini" in model.lower():
                model_display = f"{model} [dim](fast)[/dim]"
            elif (
                "pro" in model.lower()
                or "turbo" in model.lower()
                or "sonnet" in model.lower()
            ):
                model_display = f"{model} [dim](powerful)[/dim]"

            table.add_row(str(i), model_display)

        console.print(table)

        # Navigation info
        total_pages = (len(models) + page_size - 1) // page_size
        console.print(
            f"\n[dim]Page {current_page + 1}/{total_pages} | "
            f"Showing {start_idx + 1}-{end_idx} of {len(models)} "
            f"models[/dim]"
        )

        if total_pages > 1:
            console.print(
                "[dim]Type 'n' for next page, 'p' for previous page, "
                "or model number to select[/dim]"
            )

        choice = Prompt.ask("\nSelect model (or n/p for navigation)")

        if choice.lower() == "n" and current_page < total_pages - 1:
            current_page += 1
            console.clear()
            console.print(
                f"\n[bold cyan]Select {provider_config['name']} Model:[/bold cyan]\n"
            )
            continue
        elif choice.lower() == "p" and current_page > 0:
            current_page -= 1
            console.clear()
            console.print(
                f"\n[bold cyan]Select {provider_config['name']} Model:[/bold cyan]\n"
            )
            continue
        elif choice.isdigit() and 1 <= int(choice) <= len(models):
            selected = models[int(choice) - 1]

            # Ensure Gemini models have correct prefix for Google AI Studio
            if (
                provider_key == "gemini"
                and not selected.startswith("gemini/")
                and not selected.startswith("vertex_ai/")
            ):
                return f"gemini/{selected}"

            return selected


def get_api_key(provider_key: str, existing_key: str | None = None) -> str:
    """Prompt for API key."""
    provider = PROVIDER_CONFIG[provider_key]

    console.print(f"\n[bold yellow]API Key Required:[/bold yellow] {provider['name']}")
    console.print(
        f"[dim]Get your API key from:[/dim] "
        f"[link={provider['api_url']}]{provider['api_url']}[/link]\n"
    )

    if existing_key:
        masked = (
            f"{existing_key[:8]}...{existing_key[-4:]}"
            if len(existing_key) > 12
            else "***"
        )
        use_existing = Confirm.ask(f"Use existing key ({masked})?", default=True)
        if use_existing:
            return existing_key

    while True:
        api_key = Prompt.ask("Enter your API key", password=True)
        if api_key and len(api_key) > 10:  # Basic validation
            return api_key
        console.print("[red]Invalid API key. Please try again.[/red]")


def run_setup_wizard(force: bool = False) -> dict[str, str]:
    """Run interactive setup wizard."""
    console.print(
        Panel(
            "[bold cyan]🎓 yt-study Setup Wizard[/bold cyan]\n\n"
            "Configure your LLM provider and API keys\n"
            "[dim]Powered by LiteLLM - 400+ models supported[/dim]",
            border_style="cyan",
            expand=False,
        )
    )

    # Load existing config
    current_config = load_config()

    if current_config and not force:
        console.print("\n[yellow]Existing configuration found.[/yellow]")
        reconfigure = Confirm.ask("Do you want to reconfigure?", default=False)
        if not reconfigure:
            console.print("[green]Using existing configuration.[/green]")
            return current_config

    # Fetch available models from LiteLLM
    console.print("\n[cyan]Fetching available models from LiteLLM...[/cyan]")
    available_models = get_available_models(force_refresh=force)
    console.print(
        f"[green]✓ Found {sum(len(m) for m in available_models.values())} "
        f"models across {len(available_models)} providers[/green]"
    )

    # Select provider
    provider_key = select_provider(available_models)

    # Select model
    model = select_model(provider_key, available_models)

    # Get API key
    provider_info = PROVIDER_CONFIG[provider_key]
    existing_key = current_config.get(provider_info["env_var"])
    api_key = get_api_key(provider_key, existing_key)

    # Optional: Configure output directory
    console.print("\n[bold cyan]Output Directory:[/bold cyan]")
    default_output = str(Path.cwd() / "output")
    # If output dir already in config, use it as default
    if "OUTPUT_DIR" in current_config:
        default_output = current_config["OUTPUT_DIR"]

    output_dir = Prompt.ask("Where should notes be saved?", default=default_output)

    # Optional: Configure concurrency
    console.print("\n[bold cyan]Concurrency:[/bold cyan]")
    default_concurrency = current_config.get("MAX_CONCURRENT_VIDEOS", "5")
    concurrency = Prompt.ask(
        "Max concurrent videos to process?", default=default_concurrency
    )

    # Optional: Configure telemetry
    console.print("\n[bold cyan]Telemetry:[/bold cyan]")
    msg = (
        "Help us improve yt-study by sending anonymous usage statistics "
        "and error reports."
    )
    console.print(f"[dim]{msg}[/dim]")
    telemetry_enabled = Confirm.ask("Enable anonymous telemetry?", default=True)

    # Build config updates
    new_config = {
        "DEFAULT_MODEL": model,
        provider_info["env_var"]: api_key,
        "OUTPUT_DIR": output_dir,
        "MAX_CONCURRENT_VIDEOS": concurrency,
        "TELEMETRY_ENABLED": "true" if telemetry_enabled else "false",
    }

    # Save configuration (merging with existing)
    save_config(new_config)

    console.print("\n[bold green]✓ Setup complete![/bold green]")
    console.print(
        Panel(
            f"[dim]Selected model:[/dim] [cyan]{model}[/cyan]\n"
            f"[dim]Configuration saved to:[/dim] [cyan]{get_config_path()}[/cyan]\n\n"
            "[bold]Next Steps:[/bold]\n"
            'Run: [green]yt-study process "URL"[/green]',
            title="🎉 Ready to go",
            border_style="green",
        )
    )

    # Return merged config
    current_config.update(new_config)
    return current_config
