"""
Media elements, that are the ones we will
use and place on the tracks, able to access
to the frames, using the different sources,
and to apply the effects we want.
"""
# from yta_editor.media.audio import AudioFileMedia
# from yta_editor.media.video import VideoFileMedia, VideoColorMedia, VideoImageMedia


# __all__ = [
#     'AudioFileMedia',
#     'VideoFileMedia',
#     'VideoColorMedia',
#     'VideoImageMedia',
# ]