"""
TODO: Just to reuse the code, adapt it and
refactor and remove this whole 'old_opengl'
module.

I just moved the code from 'yta_video_opengl'
here to refactor and adapt it.
"""