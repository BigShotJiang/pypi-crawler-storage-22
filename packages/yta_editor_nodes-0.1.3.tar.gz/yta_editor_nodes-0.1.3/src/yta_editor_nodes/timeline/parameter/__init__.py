"""
Module to handle the parameters we need to
provide to the nodes to be able to work.
"""