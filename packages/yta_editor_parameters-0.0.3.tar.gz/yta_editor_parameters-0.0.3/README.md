# Youtube Autonomous Editor Parameters Module

The module related to the parameters and how we define them to be used in the video editor 'yta-editor'.