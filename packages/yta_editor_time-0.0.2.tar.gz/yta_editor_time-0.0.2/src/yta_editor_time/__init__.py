"""
Module to include the functionality related to the
time and how we handle it to control the changes
perfectly.
"""