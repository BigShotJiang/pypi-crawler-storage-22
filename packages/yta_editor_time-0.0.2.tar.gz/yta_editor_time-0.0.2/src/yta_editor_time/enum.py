from yta_constants.enum import YTAEnum as Enum
from typing import Union


class TimeSpace(Enum):
    """
    The time space that is being used to handle the time
    moment in which something must be applied in the
    editor.
    """

    LOCAL_TIME_NORMALIZED = 'local_normalized'
    """
    The local time normalized, relative to the element.
    """
    LOCAL_TIME = 'local_time'
    """
    The local time (not normalized) relative to the
    element.
    """
    LOCAL_FRAME_INDEXES = 'local_frames'
    """
    The frame indexes, relative to the element.
    """
    # GLOBAL = 'global'
    # """
    # The global time moment, relative to the whole timeline.
    # """

    def to_effective_time_range(
        self,
        start: Union[float, int],
        end: Union[float, int]
    ) -> Union['LocalTimeNormalizedEffectiveTimeRange', 'LocalTimeEffectiveTimeRange', 'LocalFrameIndexesEffectiveTimeRange']:
        """
        Get an `EffectiveTimeRange` instance according to this
        `TimeSpace` enum option value, initialized with the
        `start` and `end` provided.
        """
        return TimeSpace.get_effective_time_range_class(
            start = start,
            end = end
        )

    @staticmethod
    def get_effective_time_range_class(
        time_space: 'TimeSpace'
    ) -> Union['LocalTimeNormalizedEffectiveTimeRange', 'LocalTimeEffectiveTimeRange', 'LocalFrameIndexesEffectiveTimeRange']:
        """
        Get the effective time range class associated to the
        given `time_space`.
        """
        from yta_editor_time.effective_time_range import LocalTimeNormalizedEffectiveTimeRange, LocalTimeEffectiveTimeRange, LocalFrameIndexesEffectiveTimeRange

        return (
            LocalTimeNormalizedEffectiveTimeRange
            if time_space == TimeSpace.LOCAL_TIME_NORMALIZED else
            LocalTimeEffectiveTimeRange
            if time_space == TimeSpace.LOCAL_TIME else
            LocalFrameIndexesEffectiveTimeRange
            if time_space == TimeSpace.LOCAL_FRAME_INDEXES else
            # None
            # if self.space == TimeSpace.GLOBAL else
            None
        )

class TimeAnchor(Enum):
    """
    The part of the element this time specification is
    anchored to and must be considered when calculating
    according to the context given.
    """

    START = 'start'
    """
    Anchored to the `start` of the element and depending
    on it.
    """
    END = 'end'
    """
    Anchored to the `end` of the element and depending on
    it.
    """

"""
Some examples below:
1. Normalized range
    t_start = 0.0
    t_end   = 1.0
    space = LOCAL_TIME_NORMALIZED
    anchor = START

2. Last N seconds
    duration = 0.5
    space = ITEM_SECONDS
    anchor = END

3. Frames
    frame_start = 120
    frame_end   = 180
    space = LOCAL_FRAME_INDEXES
    anchor = START
"""