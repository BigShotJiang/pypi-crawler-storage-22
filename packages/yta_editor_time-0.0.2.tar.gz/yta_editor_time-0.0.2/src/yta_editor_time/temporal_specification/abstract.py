from yta_editor_time.temporal_specification.temporal_resolution import TemporalResolution
from abc import ABC, abstractmethod


class TemporalSpecification(ABC):
    """
    Abstract base class that defines WHEN something is
    active in a given temporal context.
    """

    @abstractmethod
    def resolve(
        self,
        evaluation_context: 'VideoEditorEvaluationContext'
    ) -> TemporalResolution:
        """
        Resolve this temporal specification for the given
        `evaluation_context`.

        Must be:
        - Pure (no side effects)
        - Deterministic
        - Stateless (resolution is NOT stored)
        """
        pass
