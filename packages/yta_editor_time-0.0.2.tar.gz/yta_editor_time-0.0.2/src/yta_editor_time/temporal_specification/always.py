from yta_editor_time.temporal_specification.abstract import TemporalSpecification
from yta_editor_time.temporal_specification.temporal_resolution import TemporalResolution


class AlwaysTemporalSpecification(TemporalSpecification):
    """
    A `TemporalSpecification` class that indicates that it
    is always active and happening.
    """

    def resolve(
        self,
        evaluation_context: 'VideoEditorEvaluationContext'
    ) -> TemporalResolution:
        return TemporalResolution(
            is_active = True,
            t_local_normalized = evaluation_context.t_normalized,
            weight = 1.0
        )
