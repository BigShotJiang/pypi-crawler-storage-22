from yta_editor_time.temporal_specification.abstract import TemporalSpecification
from yta_editor_time.temporal_specification.temporal_resolution import TemporalResolution


class BlendTemporalSpecification(TemporalSpecification):
    """
    TODO: Explain better
    """

    def __init__(
        self,
        temporal_specifications: list[TemporalSpecification]
    ):
        self.temporal_specifications: list[TemporalSpecification] = list(temporal_specifications)
        """
        The list of `TemporalSpecification` instances that will
        be evaluated and blended.
        """

    def resolve(
        self,
        evaluation_context: 'VideoEditorEvaluationContext'
    ):
        weight = 0.0

        for temporal_specification in self.temporal_specifications:
            temporal_result = temporal_specification.resolve(evaluation_context)

            if temporal_result.active:
                weight += temporal_result.weight

        return TemporalResolution(
            is_active = weight > 0.0,
            t_local_normalized = evaluation_context.t_normalized,
            weight = min(1.0, weight)
        )