from yta_editor_time.temporal_specification.abstract import TemporalSpecification
from yta_editor_time.temporal_specification.temporal_resolution import TemporalResolution


class BooleanConditionTemporalSpecification(TemporalSpecification):
    """
    The element is active according to the specific
    and custom condition that has been provided.
    """

    def __init__(
        self,
        condition: any
    ):
        self.condition: any = condition
        """
        The condition that must be used to resolve if it
        must be active or not, based on the evaluation
        context.
        """

    def resolve(
        self,
        evaluation_context: 'VideoEditorEvaluationContext'
    ):
        return TemporalResolution(
            is_active = bool(self.condition(evaluation_context)),
            # TODO: Use 't_local_normalized' as in the context (?)
            t_local_normalized = None,
            weight = 1.0
        )
