from yta_editor_time.temporal_specification.abstract import TemporalSpecification
from yta_editor_time.temporal_specification.temporal_resolution import TemporalResolution


class EveryNthFrameTemporalSpecification(TemporalSpecification):
    """
    The element is active during every 'n' number
    of frames.
    """

    def __init__(
        self,
        n: int
    ):
        self.n: int = max(1, n)
        """
        The amount of frames in between one activation of
        this element and the next one.
        """

    def resolve(
        self,
        evaluation_context: 'VideoEditorEvaluationContext'
    ):
        is_active = (evaluation_context.frame_index % self.n) == 0

        return TemporalResolution(
            is_active = is_active,
            t_local_normalized = (
                evaluation_context.t_normalized
                if is_active else
                None
            ),
            weight = 1.0
        )