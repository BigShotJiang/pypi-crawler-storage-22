from yta_editor_time.temporal_specification.abstract import TemporalSpecification
from yta_editor_time.temporal_specification.temporal_resolution import TemporalResolution


class FirstFrameTemporalSpecification(TemporalSpecification):
    """
    The element is active only if the `frame_index`
    provided in the `evaluation_context` is the first
    frame.
    """

    def resolve(
        self,
        evaluation_context: 'VideoEditorEvaluationContext'
    ):
        return TemporalResolution(
            is_active = evaluation_context.frame_index == 0,
            # Use 't_local_normalized' as in the context
            t_local_normalized = None,
            weight = 1.0
        )