from yta_editor_time.temporal_specification.abstract import TemporalSpecification
from yta_editor_time.temporal_specification.temporal_resolution import TemporalResolution


class FrameTemporalSpecification(TemporalSpecification):
    """
    The element is active during a certain number of
    frames that are in between the `start` and `end`
    frame indexes provided.
    """

    def __init__(
        self,
        start: int,
        end: int
    ):
        # TODO: Validate 'start' and 'end' as normalized
        assert start <= end
        self.start: int = start
        self.end: int = end

    def resolve(
        self,
        evaluation_context: 'VideoEditorEvaluationContext'
    ):
        frame_index = evaluation_context.frame_index
        if (
            frame_index < self.start or
            frame_index > self.end
        ):
            return TemporalResolution(
                is_active = False,
                t_local_normalized = None,
                weight = 1.0
            )

        t_local = (frame_index - self.start) / max(1, self.end - self.start)

        return TemporalResolution(
            is_active = True,
            t_local_normalized = t_local,
            weight = 1.0
        )