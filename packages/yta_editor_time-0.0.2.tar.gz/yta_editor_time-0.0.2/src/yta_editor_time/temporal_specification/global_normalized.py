from yta_editor_time.temporal_specification.abstract import TemporalSpecification
from yta_editor_time.temporal_specification.temporal_resolution import TemporalResolution


class GlobalNormalizedTimeTemporalSpecification(TemporalSpecification):
    """
    The element is active during a period of time that
    is in between the `start` and `end` normalized global
    t time moment (or progress).

    TODO: Explain better
    """

    def __init__(
        self,
        start: float,
        end: float
    ):
        # TODO: Validate 'start' and 'end' as normalized
        assert start <= end
        self.start: float = start
        self.end: float = end

    def resolve(
        self,
        evaluation_context: 'VideoEditorEvaluationContext'
    ):
        # TODO: This could be handled dynamically
        domain_min = 0.0
        domain_max = 1.0

        start = max(self.start, domain_min)
        end = min(self.end, domain_max)

        t = evaluation_context.t_global_normalized

        if (
            t < start or
            t > end
        ):
            return TemporalResolution(
                is_active = False
            )
        
        t_local_normalized = (t - self.start) / (self.end - self.start)

        return TemporalResolution(
            is_active = True,
            t_local_normalized = t_local_normalized,
            weight = 1.0
        )
