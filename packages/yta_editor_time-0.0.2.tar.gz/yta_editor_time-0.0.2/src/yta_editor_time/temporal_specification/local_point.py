from yta_editor_time.temporal_specification.abstract import TemporalSpecification
from yta_editor_time.temporal_specification.temporal_resolution import TemporalResolution


# TODO: Maybe rename to 'instant' or 'frame' (?)
class LocalPointTemporalSpecification(TemporalSpecification):
    """
    The element is active during a single frame, based
    on the `point` provided (which is a not normalized
    time moment) and with the `epsilon` as the margin
    of error.
    """

    def __init__(
        self,
        point: float,
        epsilon: float = 1e-3
    ):
        self.point: float = point
        self.epsilon: float = epsilon

    def resolve(
        self,
        evaluation_context: 'VideoEditorEvaluationContext'
    ):
        return (
            TemporalResolution(
                is_active = True,
                t_local_normalized = 0.0,
                weight = 1.0
            )
            if abs(evaluation_context.t - self.point) <= self.epsilon else
            TemporalResolution(
                is_active = False,
                t_local_normalized = None,
                weight = 1.0
            )
        )