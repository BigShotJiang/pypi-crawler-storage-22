from yta_editor_time.temporal_specification.abstract import TemporalSpecification
from yta_editor_time.temporal_specification.temporal_resolution import TemporalResolution


class LocalTimeTemporalSpecification(TemporalSpecification):
    """
    The element is active during a period of time that
    is in between the `start` and `end` not normalized
    local t time moment.

    TODO: Explain better
    """

    def __init__(
        self,
        start: float,
        end: float
    ):
        # TODO: Validate 'start' and 'end' as normalized
        assert start <= end
        self.start: float = start
        self.end: float = end

    def resolve(
        self,
        evaluation_context: 'VideoEditorEvaluationContext'
    ):
        t = evaluation_context.t

        if (
            t < self.start or
            t > self.end
        ):
            return TemporalResolution(
                is_active = False,
                t_local_normalized = None,
                weight = 1.0
            )

        t_local_normalized = (t - self.start) / (self.end - self.start)

        return TemporalResolution(
            is_active = True,
            t_local_normalized = t_local_normalized,
            weight = 1.0
        )
