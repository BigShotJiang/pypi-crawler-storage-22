from yta_editor_time.temporal_specification.abstract import TemporalSpecification
from yta_editor_time.temporal_specification.temporal_resolution import TemporalResolution


class NeverTemporalSpecification(TemporalSpecification):
    """
    A `TemporalSpecification` class that indicates that it
    is never active and happening.
    """

    def resolve(
        self,
        evaluation_context: 'VideoEditorEvaluationContext'
    ):
        return TemporalResolution(
            is_active = False,
            t_local_normalized = None,
            weight = 1.0
        )
