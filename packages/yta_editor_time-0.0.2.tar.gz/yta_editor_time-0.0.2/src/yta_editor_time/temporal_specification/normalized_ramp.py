from yta_editor_time.temporal_specification.abstract import TemporalSpecification
from yta_editor_time.temporal_specification.temporal_resolution import TemporalResolution


class NormalizedRampTemporalSpecification(TemporalSpecification):
    """
    TODO: Explain this better.
    """

    def resolve(
        self,
        evaluation_context: 'VideoEditorEvaluationContext'
    ):
        t_local_normalized = evaluation_context.t_normalized
        weight = max(0.0, min(1.0, 1.0 - abs(2.0 * t_local_normalized - 1.0)))

        return TemporalResolution(
            is_active = True,
            t_local_normalized = t_local_normalized,
            weight = weight
        )