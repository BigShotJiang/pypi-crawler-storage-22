from yta_editor_time.temporal_specification.abstract import TemporalSpecification
from yta_editor_time.temporal_specification.temporal_resolution import TemporalResolution


class NotConditionTemporalSpecification(TemporalSpecification):
    """
    Special `TemporalSpecification`.

    The specification provided will be resolved according
    to the evaluation context and this result will be
    active only if the provided one is resolved as non
    active.
    """

    def __init__(
        self,
        temporal_specification: TemporalSpecification
    ):
        self.temporal_specification: TemporalSpecification = temporal_specification
        """
        A `TemporalSpecification` instance that will be 
        evaluated.
        """

    def resolve(
        self,
        evaluation_context: 'VideoEditorEvaluationContext'
    ):
        temporal_result = self.temporal_specification.resolve(evaluation_context)

        return TemporalResolution(
            is_active = not temporal_result.is_active,
            # Use 't_local_normalized' as in the context
            t_local_normalized = None,
            weight = 1.0
        )