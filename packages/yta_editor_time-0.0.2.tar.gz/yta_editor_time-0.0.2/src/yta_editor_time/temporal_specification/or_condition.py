from yta_editor_time.temporal_specification.abstract import TemporalSpecification
from yta_editor_time.temporal_specification.temporal_resolution import TemporalResolution


class OrConditionTemporalSpecification(TemporalSpecification):
    """
    Special `TemporalSpecification`.

    The set of specifications provided will be resolved
    according to the evaluation context. It will be
    active only if at least one of the specifications is
    is_active.

    The `t_local_normalized` value used will be the one
    obtained in the first `TemporalSpecification` resolved
    as active.
    """

    def __init__(
        self,
        temporal_specifications: list[TemporalSpecification]
    ):
        self.temporal_specifications: list[TemporalSpecification] = list(temporal_specifications)
        """
        The list of `TemporalSpecification` instances that will
        be evaluated. All of them must be active to turn the
        final result as active.
        """

    def resolve(
        self,
        evaluation_context: 'VideoEditorEvaluationContext'
    ):
        for temporal_specification in self.temporal_specifications:
            temporal_result = temporal_specification.resolve(evaluation_context)

            if temporal_result.is_active:
                return temporal_result
            
        return TemporalResolution(
            is_active = False,
            t_local_normalized = None,
            weight = 1.0
        )