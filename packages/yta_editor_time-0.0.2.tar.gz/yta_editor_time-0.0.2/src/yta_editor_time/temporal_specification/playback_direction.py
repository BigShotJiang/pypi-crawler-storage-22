from yta_editor_time.temporal_specification.abstract import TemporalSpecification
from yta_editor_time.temporal_specification.temporal_resolution import TemporalResolution


class PlaybackDirectionTemporalSpecification(TemporalSpecification):
    """
    TODO: Explain better
    """

    def __init__(
        self,
        do_forward: bool = True
    ):
        self.do_forward: bool = do_forward
        """
        Boolean flag to indicate if it is going forward
        or not (backwards).
        """

    def resolve(
        self,
        evaluation_context: 'VideoEditorEvaluationContext'
    ):
        # Requires ctx.playback_direction
        return TemporalResolution(True)