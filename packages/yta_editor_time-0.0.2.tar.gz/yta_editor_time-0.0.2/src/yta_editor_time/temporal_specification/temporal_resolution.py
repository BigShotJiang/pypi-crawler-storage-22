from dataclasses import dataclass
from typing import Union


@dataclass(frozen = True)
class TemporalResolution:
    """
    Result of resolving a `TemporalSpecification` for a
    given context.

    If the `t_local_normalized` parameter has a value
    means that this is the value that must be used, but
    if it is `None`, the original one provided in the
    context must be used. This is very important because
    we can analyze different specs and setting it wrongly
    could make the next ones think that we are in a new
    temporal subspace.
    """

    is_active: bool
    """
    Boolean flag to indicate if the element is active or
    not at that moment.
    """

    t_local_normalized: Union[float, None] = None
    """
    The local and normalized time moment in which it is
    being analyzed.

    The `None` value means that it must not be redefined
    and the original value must be used.
    """

    weight: float = 1.0
    """
    Weight of the resolution (e.g. for blending or stacking).
    """