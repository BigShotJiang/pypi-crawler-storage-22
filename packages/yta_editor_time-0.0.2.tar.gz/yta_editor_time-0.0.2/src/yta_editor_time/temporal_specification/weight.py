from yta_editor_time.temporal_specification.abstract import TemporalSpecification
from yta_editor_time.temporal_specification.temporal_resolution import TemporalResolution


class WeightTemporalSpecification(TemporalSpecification):
    """
    The element is active according to the specific
    and custom function that has been provided to
    this class, that is evaluated according to the
    evaluation context.

    This will always active and only calculate the
    weight based on the `function` provided.
    """

    def __init__(
        self,
        function: callable
    ):
        self.function: callable = function
        """
        The function that must be used to resolve the
        weight based on the evaluation context.
        """

    def resolve(
        self,
        evaluation_context: 'VideoEditorEvaluationContext'
    ):
        return TemporalResolution(
            is_active = True,
            t_local_normalized = evaluation_context.t_normalized,
            weight = max(0.0, min(1.0, self.function(evaluation_context)))
        )
