# Youtube Autónomo Math module

The module related with math, including graphics, rate functions, etc.