"""
Module to include the functionality related
to math, including graphics, rate functions,
etc.

TODO: This module has been migrated to 'yta_math_common'
to be able to import it without any other dependency
than 'numpy' (by now).
"""
from yta_math_common import Math