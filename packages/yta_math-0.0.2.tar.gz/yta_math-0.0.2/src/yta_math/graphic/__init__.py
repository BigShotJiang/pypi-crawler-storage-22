"""
TODO: This module has been refactored and rebuilt
completely in the new 'yta_math_graphic' library to
be implemented better. It is not exactly the same
and its being used somewhere, so I keep it by now
but it should be removed and replaced by the use of
'yta_math_graphic'.
"""