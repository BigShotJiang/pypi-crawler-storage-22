# Youtube Autónomo Math Common module

The module related with math, including the common mathematic operations.