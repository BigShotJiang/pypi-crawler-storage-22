"""
Module to include the functionality related
to defining custom curves to set parameters.
"""

