"""
Module to include the functionality related
to interpolation.
"""
from yta_math_interpolation.enums import InterpolationFunctionName
from abc import ABC, abstractmethod


class InterpolationFunction(ABC):
    """
    *Abstract class*

    Abstract class to be inherited by the specific
    interpolation implementations.

    An interpolation function that is able to
    calculate additional points associated to
    the points already provided.
    """
    _registry: dict[str, type['InterpolationFunction']] = {}
    """
    *For internal use only*
    
    A register to simplify the way we instantiate
    new classes from strings.
    """
    _name: str
    """
    *For internal use only*

    The string name of the specific interpolation
    implementation class.
    """
    # may_overshoot: bool
    # """
    # Boolean flag to indicate if the easing function can
    # generate values out of the bounds or not.
    # """

    def __init_subclass__(
        cls,
        **kwargs
    ):
        """
        Init the subclass and register it.
        """
        super().__init_subclass__(**kwargs)

        if hasattr(cls, '_name'):
            InterpolationFunction._registry[cls.get_name()] = cls

    @classmethod
    def get(
        cls,
        name: InterpolationFunctionName
    ) -> type['InterpolationFunction']:
        """
        Get the specific class associated to the given
        interpolation function `name`.
        """
        name = InterpolationFunctionName.to_enum(name)

        return cls._registry[name.value]

    @classmethod
    def get_name(
        cls
    ) -> str:
        """
        Get the string name of the specific interpolation
        implementation class.
        """
        return cls._name

    @abstractmethod
    def _interpolate(
        self,
        t: float,
        point_start: tuple[float, float],
        point_end: tuple[float, float],
        **kwargs
    ) -> tuple[tuple[float, float], tuple[float, float]]:
        """
        *For internal use only*

        The proper calculation of the interpolation, that
        must be implemented for each specific class.

        The interpolation calculation will provide the
        new point (or points) for the ones given as input,
        using the `t` provided (that must be a value in the
        `[0.0, 1.0]` range indicating the progress in
        between the `point_start` and `point_end`).

        Return the position obtained by evaluating the curve
        at `t`.
        """
        pass

    def interpolate(
        self,
        t: float,
        point_start: tuple[float, float],
        point_end: tuple[float, float],
        **kwargs
    ) -> tuple[tuple[float, float], tuple[float, float]]:
        """
        Apply the interpolation with the points provided as
        input.

        The interpolation calculation will provide the
        new point (or points) for the ones given as input,
        using the `t` provided (that must be a value in the
        `[0.0, 1.0]` range indicating the progress in
        between the `point_start` and `point_end`).

        Return the position obtained by evaluating the curve
        at `t`.
        """
        # TODO: Validate points

        # TODO: I think I only need 1 interpolate method
        return self._interpolate(
            t = t,
            point_start = point_start,
            point_end = point_end,
            **kwargs
        )

    def __call__(
        self,
        t: float,
        point_start: tuple[float, float],
        point_end: tuple[float, float],
        **kwargs
    ) -> tuple[tuple[float, float], tuple[float, float]]:
        """
        Special method to allow us doing
        `interpolation_function(point_start, point_end)`
        instead of
        `interpolation_function.interpolate(point_start, point_end)`.

        Apply the interpolation with the points provided as
        input.

        The interpolation calculation will provide the
        new point (or points) for the ones given as input,
        using the `t` provided (that must be a value in
        the `[0.0, 1.0]` range indicating the progress in
        between the `point_start` and `point_end`).

        Return the position obtained by evaluating the curve
        at `t`.
        """
        return self.interpolate(
            t = t,
            point_start = point_start,
            point_end = point_end,
            **kwargs
        )

    # @requires_dependency('matplotlib', 'yta_math', 'matplotlib')
    # def plot(
    #     self,
    #     number_of_samples: int = 100
    # ):
    #     """
    #     Plot a graphic representing `number_of_samples`
    #     values, from `0.0` to `1.0`, to see how the easing
    #     function works.
    #     """
    #     import matplotlib.pyplot as plt
        
    #     # Limit and draw axis
    #     plt.xlim(0, 1)
    #     plt.ylim(0, 1)
    #     plt.axhline(0, color = 'black', linewidth = 1)
    #     plt.axvline(0, color = 'black', linewidth = 1)

    #     plt.grid(True)

    #     # We will draw 'n'' values between 0.0 and 1.1
    #     x_vals = np.linspace(0.0, 1.0, number_of_samples).tolist()
    #     y_vals = [
    #         self.get_n_value(x)
    #         for x in x_vals
    #     ]
    #     plt.scatter(x_vals, y_vals, color = 'white', edgecolors = 'black', s = 100)

    #     # TODO: I think we don't need to draw anything
    #     # else. Remove this below if it is ok.
    #     # # Draw points between nodes
    #     # for pair_of_node in self.pairs_of_nodes:
    #     #     positions = pair_of_node.get_n_xy_values_to_plot(100)
    #     #     t_xs, t_ys = zip(*positions)
    #     #     xs += t_xs
    #     #     ys += t_ys
       
    #     # plt.scatter(xs, ys, color = 'black', s = 1)
        
    #     plt.title('')
    #     plt.xlabel('X axis')
    #     plt.ylabel('Y axis')
        
    #     plt.show()
