from yta_math_interpolation.abstract import InterpolationFunction
from yta_math_interpolation.enums import InterpolationFunctionName


class BezierCubicInterpolation(InterpolationFunction):
    """
    A cubic bezier interpolation function, that
    needs two control points.

    The formula:
    ```
    u = 1 - t

    return (
        u ** 3 * point_start[0] + 3 * u * u * t * point_control_1[0] + 3 * u * t * t * point_control_2[0] + t ** 3 * point_end[0],
        u ** 3 * point_start[1] + 3 * u * u * t * point_control_1[1] + 3 * u * t * t * point_control_2[1] + t ** 3 * point_end[1]
    )
    ```
    """
    _name: str = InterpolationFunctionName.BEZIER_CUBIC.value

    def interpolate(
        self,
        t: float,
        point_start: tuple[float, float],
        point_control_1: tuple[float, float],
        point_control_2: tuple[float, float],
        point_end: tuple[float, float]
    ):
        """
        Interpolate a point on a cubic Bézier curve for a
        given normalized parameter `t` (in the `[0.0, 1.0]`
        range), using all the points provided.

        Return the position obtained by evaluating the curve
        at `t`.
        """
        return super().interpolate(
            t = t,
            point_start = point_start,
            point_control_1 = point_control_1,
            point_control_2 = point_control_2,
            point_end = point_end
        )

    def _interpolate(
        self,
        t: float,
        point_start: tuple[float, float],
        point_control_1: tuple[float, float],
        point_control_2: tuple[float, float],
        point_end: tuple[float, float]
    ) -> tuple[tuple[float, float], tuple[float, float]]:
        u = 1 - t

        return (
            u ** 3 * point_start[0] + 3 * u * u * t * point_control_1[0] + 3 * u * t * t * point_control_2[0] + t ** 3 * point_end[0],
            u ** 3 * point_start[1] + 3 * u * u * t * point_control_1[1] + 3 * u * t * t * point_control_2[1] + t ** 3 * point_end[1]
        )
    
