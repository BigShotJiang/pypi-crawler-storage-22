from yta_math_interpolation.abstract import InterpolationFunction
from yta_math_interpolation.enums import InterpolationFunctionName


class BezierQuadraticInterpolation(InterpolationFunction):
    """
    A quadratic bezier interpolation function, that
    needs one control point.

    The formula:
    ```
    u = 1 - t
    return (
        u * u * point_start[0] + 2 * u * t * point_control[0] + t * t * point_end[0],
        u * u * point_start[1] + 2 * u * t * point_control[1] + t * t * point_end[1]
    )
    ```
    """
    _name: str = InterpolationFunctionName.BEZIER_QUADRATIC.value

    def interpolate(
        self,
        t: float,
        point_start: tuple[float, float],
        point_control: tuple[float, float],
        point_end: tuple[float, float]
    ):
        """
        Interpolate a point on a quadratic Bézier curve for
        a given normalized parameter `t` (in the `[0.0, 1.0]`
        range), using all the points provided.

        Return the position obtained by evaluating the curve
        at `t`.
        """
        return super().interpolate(
            t = t,
            point_start = point_start,
            point_control = point_control,
            point_end = point_end
        )

    def _interpolate(
        self,
        t: float,
        point_start: tuple[float, float],
        point_control: tuple[float, float],
        point_end: tuple[float, float]
    ) -> tuple[tuple[float, float], tuple[float, float]]:
        u = 1 - t

        return (
            u * u * point_start[0] + 2 * u * t * point_control[0] + t * t * point_end[0],
            u * u * point_start[1] + 2 * u * t * point_control[1] + t * t * point_end[1]
        )
    
