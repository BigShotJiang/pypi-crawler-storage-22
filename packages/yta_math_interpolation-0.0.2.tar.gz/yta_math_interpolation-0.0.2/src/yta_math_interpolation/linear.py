from yta_math_interpolation.abstract import InterpolationFunction
from yta_math_interpolation.enums import InterpolationFunctionName


class LinearInterpolation(InterpolationFunction):
    """
    A linear interpolation function, also called LERP.

    The formula:
    ```
    (
        point_start[0] + (point_end[0] - point_start[0]) * t,
        point_start[1] + (point_end[1] - point_start[1]) * t
    )
    ```
    """
    _name: str = InterpolationFunctionName.LINEAR.value

    def _interpolate(
        self,
        t: float,
        point_start: tuple[float, float],
        point_end: tuple[float, float]
    ) -> tuple[tuple[float, float], tuple[float, float]]:
        return (
            point_start[0] + (point_end[0] - point_start[0]) * t,
            point_start[1] + (point_end[1] - point_start[1]) * t
        )
    
