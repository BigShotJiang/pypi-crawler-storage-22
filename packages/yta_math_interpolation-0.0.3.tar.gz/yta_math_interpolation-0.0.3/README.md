# Youtube Autonomous Math Interpolation Module

The module related to interpolation.