# Youtube Autonomous Parameters Module

The module related to the parameters and how we define them to be used in the different apps.