from yta_video_frame_time.t_fraction import THandler
from yta_validation.parameter import ParameterValidator
from quicktions import Fraction
from dataclasses import dataclass, field
from typing import Union

import math


@dataclass(frozen = True)
class TMedia:
    """
    Class to represent a time moment of a media
    item, including the `fps` to be able to swap
    to frame index easily.

    The `t` time moment provided will be truncated
    to be a multiple of `1/fps` and be the exact
    time moment.

    You can use this class as `float(TMedia)` if
    you want to use it as a float, but we strongly
    recommend you to use the `.t` property that is
    a `Fraction`.
    """

    t: Union[Fraction, float]
    """
    The time moment in seconds as a `Fraction` that has
    been truncated according to the `fps` provided.
    """
    fps: float
    """
    The `fps` associated to the media.
    """
    frame_index: int = field(init = False)
    """
    The frame index, that comes from the `t` that has
    been truncated according to the `fps` provided.
    """

    def __post_init__(
        self
    ):
        t_handler = THandler(fps = self.fps)
        """
        *For internal use only*

        A `THandler` instance to be able to truncate and
        transform the values.
        """

        t_trunc = t_handler.t.truncated(
            t = self.t,
        )
        frame_index = t_handler.t.to_index(
            t = t_trunc,
            do_truncate = False
        )

        # We truncate 't' and calculate the 'frame_index'
        object.__setattr__(self, 't', t_trunc)
        object.__setattr__(self, 'frame_index', frame_index)

    def with_previous_frame(
        self,
        n: int = 1
    ) -> 'TMedia':
        """
        Get a new `TMedia` instance representing the
        frame that is `n` times before the current one.

        This method doesn't modify the original instance.
        """
        ParameterValidator.validate_mandatory_positive_int('n', n, do_include_zero = False)

        t = THandler(fps = self.fps).t.previous(
            t = self.t,
            n = n,
            do_truncate = True
        )

        if t < 0:
            raise Exception('The "n" value is not valid.')

        return TMedia(
            t = t,
            fps = self.fps
        )

    def with_next_frame(
        self,
        n: int = 1
    ) -> 'TMedia':
        """
        Get a new `TMedia` instance representing the
        frame that is `n` times after the current one.

        This method doesn't modify the original instance.
        """
        ParameterValidator.validate_mandatory_positive_int('n', n, do_include_zero = False)

        return TMedia(
            t = THandler(fps = self.fps).t.next(
                t = self.t,
                n = n,
                do_truncate = True
            ),
            fps = self.fps
        )

    # Methods to make it a number
    def __float__(
        self
    ):
        return float(self.t)
    
    def __add__(
        self,
        other
    ):
        return TMedia(self.t + float(other))

    def __radd__(
        self,
        other
    ):
        return self.__add__(other)
    
    @classmethod
    def from_frame_index(
        cls,
        frame_index: int,
        fps = float
    ) -> 'TMedia':
        """
        Get a `TMedia` instance representing the time
        moment corresponding to the `frame_index`
        provided (using the `fps` also given).

        The formula:
        - `frame_index * (1 / fps)`
        """
        ParameterValidator.validate_mandatory_positive_int('frame_index', frame_index, do_include_zero = True)

        return cls(
            t = THandler(fps = fps).t.from_index(
                index = frame_index
            ),
            fps = fps
        )
    
    @staticmethod
    def from_progress_normalized(
        progress_normalized: float,
        duration: float,
        fps: float
    ) -> 'TMedia':
        """
        Get a `TMedia` instance representing the time
        moment corresponding to the `progress_normalized`
        provided (according to the `duration` given).

        This method is using the frame indexes to obtain
        the values as `Fraction` instances, so the
        `duration` and the `t` time moment will be
        transformed into frame indexes to calculate.

        This is the formula:
        - `floor(p * (duration_in_frames - 1))`

        Here you have some examples considering `fps=60`
        and `duration=1.0`:
        - `p=0.0 => 0.0*59 => frame_index=0 => t=0.0`
        - `p=0.5 => 0.5*59 => frame_index=29 => t=0.4833333333333333`
        - `p=1.0 => 1.0*59 => frame_index=59 => t=0.9833333333333333`
        """
        ParameterValidator.validate_mandatory_number_between('progress_normalized', progress_normalized, 0.0, 1.0)
        ParameterValidator.validate_mandatory_positive_float('duration', duration, do_include_zero = False)
        ParameterValidator.validate_mandatory_positive_number('fps', fps, do_include_zero = False)

        thandler = THandler(fps = fps)

        duration_in_frames = thandler.t.to_index(
            t = duration,
            do_truncate =  True
        )

        frame_index = max(0, math.floor(progress_normalized * (duration_in_frames - 1)))

        return TMedia(
            t = thandler.t.from_index(frame_index),
            fps = fps
        )
    
    @staticmethod
    def to_progress_normalized(
        t: float,
        duration: float,
        fps: float
    ) -> float:
        """
        Get the progress normalized from the given `t`
        time moment and based on the total `duration` and
        the `fps`.

        This method is using the frame indexes to obtain
        the values as `Fraction` instances, so the
        `duration` and the `t` time moment will be
        transformed into frame indexes to calculate.

        This is the formula:
        - `frame_index / (duration_in_frames - 1)`

        Here you have some examples considering `fps=60`
        and `duration=1.0`:
        - `t=0.0 => frame_index=0 => 0/59 => progress_normalized=0.0`
        - `t=0.4833333333333333 => frame_index=29 => 29/59 =>  progress_normalized≈0.4915`
        - `t=0.5 => frame_index=30 => 30/59 =>  progress_normalized≈0.5085`
        - `t=0.9833333333333333 => frame_index=59 => 59/59 => progress_normalized=1.0`
        """
        ParameterValidator.validate_mandatory_positive_float('t', t, do_include_zero = True)
        ParameterValidator.validate_mandatory_positive_float('duration', duration, do_include_zero = False)
        ParameterValidator.validate_mandatory_positive_number('fps', fps, do_include_zero = False)

        thandler = THandler(fps = fps)

        frame_index = thandler.t.to_index(
            t = t,
            do_truncate = True
        )
        duration_in_frames = thandler.t.to_index(
            t = duration,
            do_truncate =  True
        )

        progress_normalized = Fraction(frame_index, duration_in_frames - 1)

        if (
            progress_normalized < 0.0 or
            progress_normalized > 1.0
        ):
            raise Exception('The progress normalized must be in the [0.0, 1.0] range.')

        return progress_normalized