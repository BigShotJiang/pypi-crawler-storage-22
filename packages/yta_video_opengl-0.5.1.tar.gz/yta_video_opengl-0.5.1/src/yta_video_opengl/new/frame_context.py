from yta_video_opengl.context import OpenGLContext
from typing import Union

import moderngl


class _OpenGLFrameContext:
    """
    *For internal use only*

    Manages output textures and framebuffer for a
    single rendering execution.
    """

    @property
    def output_texture(
        self
    ) -> moderngl.Texture:
        """
        The texture obtained as the output of the pipeline
        when processed the input.
        """
        return self._output_tex

    def __init__(
        self,
        opengl_context: Union[moderngl.Context, None],
        output_size: tuple[int, int]
    ):
        """
        TODO: Is this explanation below ok (?)

        The `output_size` is the size (width, height) of the
        texture that will be obtained as result. This size
        can be modified when processing a specific input, but
        please, consider the cost of resources of modifying
        the size because it will regenerate the output texture.
        """
        # TODO: Maybe we can obtain it from other place (?)
        self.context: moderngl.Context = (
            OpenGLContext().context
            if opengl_context is None else
            opengl_context
        )
        """
        The context of the OpenGL program.
        """
        self.output_size: tuple[int, int] = output_size
        """
        The size we want to use for the frame buffer
        in a (width, height) format.
        """

        self._output_tex: Union[moderngl.Texture, None] = None
        """
        *For internal use only*

        The texture obtained as the output of the pipeline
        when processed the input.
        """
        self.fbo: moderngl.Framebuffer | None = None
        """
        The Frame Buffer Object where the output will be
        rendered to be able to handle it.
        """

        self._prepare_output_texture(output_size)

    def _prepare_output_texture(
        self,
        size: tuple[int, int]
    ) -> '_OpenGLFrameContext':
        """
        *For internal use only*

        Set the output texture and the FBO if needed
        (the size changed or it was not set). This
        method has to be called before rendering any
        frame/texture to adapt it if needed.

        The output texture settings and the FBO will
        determine how the output result is obtained.
        """
        if (
            self._output_tex is None or
            self._output_tex.size != size
        ):
            self.output_size = size
            # self._output_tex = self.context.texture(self.output_size, 4)
            self._output_tex = self.context.texture(
                size = self.output_size,
                components = 4,
                dtype = 'f1'
            )
            self._output_tex.filter = (moderngl.LINEAR, moderngl.LINEAR)
            # Avoid repeating the texture and use black pixels instead
            # self._output_tex.repeat_x = False
            # self._output_tex.repeat_y = False

            """
            Something about these attachments:
            - Color attachments → Texture usuarlly
            - Depth attachment → DepthRenderBuffer or DepthTexture
            - Stencil attachment → less common
            """
            self.fbo = self.context.framebuffer(
                color_attachments = [self._output_tex]
            )

        return self

    def begin(
        self
    ) -> '_OpenGLFrameContext':
        """
        Binds the framebuffer object as the current render
        target and clears it to a fully transparent state,
        preparing the frame context for a new rendering pass.
        """
        self.fbo.use()
        # I think this is not needed but... here it is
        self.context.viewport = (0, 0, *self.output_size)
        self.context.clear(0.0, 0.0, 0.0, 0.0)

        return self