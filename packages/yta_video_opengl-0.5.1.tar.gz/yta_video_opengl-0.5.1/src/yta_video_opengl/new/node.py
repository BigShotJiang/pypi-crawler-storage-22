from yta_video_opengl.new.pipeline import _OpenGLPipeline
from yta_video_opengl.new.node_processor import _OpenGLNodeProcessor
from yta_video_opengl.new.frame_context import _OpenGLFrameContext
from yta_video_opengl.texture.utils import TextureUtils
from yta_validation.parameter import ParameterValidator
from abc import abstractmethod
from typing import Union, Mapping

import moderngl


# TODO: This class will be adapted to all our custom ones
class _OpenGLNode:
    """
    *For internal use only*

    Instanciable OpenGL node. Holds only parameters and
    timing.

    This node will instantiated as many times as
    different changes we want to apply with the same
    node, and will internally use the same singleton
    instance to actually apply the changes (due to a
    performance motivation).

    A static or initial uniform is an uniform that will
    not change during the different executions of the
    node. A dynamic uniform is an uniform that we set
    for that specific execution, which could be a 
    progress during a transition, for example.

    An nstantiable OpenGL node that encapsulates
    parameters, timing, and uniform state, delegating
    the actual GPU execution to a shared node processor.
    It merges static and per-execution dynamic uniforms,
    prepares the frame context and input textures, and
    produces an output texture at the requested
    resolution.
    """

    # TODO: Maybe we can refactor to a dict in which we
    # set it as mandatory or optional
    mandatory_inputs: list[str] = []
    """
    The name of the inputs that are mandatory to be able
    to use the node.
    """
    optional_inputs: list[str] = []
    """
    The name of the inputs that will be used in the node
    if provided but are not mandatory to make the node
    work properly.
    """

    def __init__(
        self,
        opengl_pipeline: _OpenGLPipeline,
        **initial_uniforms
    ):
        # TODO: Describe with the doc
        self._opengl_pipeline = opengl_pipeline
        """
        *For internal use only*

        The pipeline that contains the shaders to be
        executed.
        """
        self._opengl_node_processor = _OpenGLNodeProcessor.get(
            opengl_context = self._opengl_pipeline.context
        )
        """
        *For internal use only*

        The node processor that will handle the inputs
        to be processed by the pipeline shaders and
        obtain the expected result.
        """
        self._static_uniforms = initial_uniforms.copy()
        """
        *For internal useo nly*

        The uniforms that are passed when instantiating
        this class and will be used everytime we call
        the `process` method, unless they are
        overwritten by the dynamic one (passed when
        calling the `process` method).
        """

    @abstractmethod
    def _get_textures_map(
        self,
        inputs: Mapping[str, moderngl.Texture]
    ) -> dict:
        """
        *For internal use only*

        Map the textures we will pass to the shaders
        with the actual parameters we are receiving
        as `inputs` in the node.

        We will have pipelines that use a single base
        texture, pipelines that mix two different
        textures, etc.

        This is the base method for the node that is
        mapping a single texture. Rewrite it based on
        your own needs.
        """
        pass
        # return {
        #     'base_texture': inputs['base_texture']
        # }

    def _validate_inputs(
        self,
        inputs: dict[str, moderngl.Texture]
    ) -> None:
        """
        *For internal use only*

        Validate the `inputs` provided and check if all the
        mandatory ones are provided and if the optionals,
        if also provided, are valid.

        This method will raise an exception if some inputs
        are invalid or missing.
        """
        # 1. Mandatory exist and are valid
        for name in self.mandatory_inputs:
            if name not in inputs:
                raise Exception(f"The mandatory input '{name}' was not provided.")
            
            ParameterValidator.validate_mandatory_instance_of(name, inputs[name], moderngl.Texture)

        # 2. Optional, if existing, are valid
        for name in self.optional_inputs:
            if name not in inputs:
                continue

            ParameterValidator.validate_mandatory_instance_of(name, inputs[name], moderngl.Texture)

    def process(
        self,
        inputs: Mapping[str, moderngl.Texture],
        output_size: Union[tuple[int, int], None] = None,
        **dynamic_uniforms
    ) -> moderngl.Texture:
        """
        Process the `inputs` provided and get an output
        of the given `output_size` by using the
        `**dynamic_uniforms` if needed.

        This method must be overwritten in any specific
        node type implementation, modifying the name of
        the input textures and the way we pass them to
        the `_get_textures_map` method, that is also
        different for each specific node type.
        """
        ParameterValidator.validate_mandatory_dict_of('inputs', inputs, moderngl.Texture)

        # Validate mandatory and optional inputs
        self._validate_inputs(inputs)

        textures_map = self._get_textures_map(
            inputs = inputs
        )

        # Preserve original size or force the one passed
        # as parameter
        # TODO: Maybe this should change
        output_size = (
            TextureUtils.get_size_from_texture(next(iter(textures_map.values())))
            if output_size is None else
            output_size
        )

        frame_context = _OpenGLFrameContext(
            opengl_context = self._opengl_pipeline.context,
            output_size = output_size
        )

        # Combine uniforms but dynamic ones are a priority
        uniforms = {
            **self._static_uniforms,
            **dynamic_uniforms
        }

        return self._opengl_node_processor.execute(
            opengl_pipeline = self._opengl_pipeline,
            opengl_frame_context = frame_context,
            textures_map = textures_map,
            uniforms = uniforms
        )