from yta_video_opengl.new.pipeline import _OpenGLPipeline
from yta_video_opengl.new.frame_context import _OpenGLFrameContext
from yta_video_opengl.context import OpenGLContext
from yta_video_opengl.new.texture import PipelineTextures, _PipelineTexture
from typing import Union

import moderngl


class _OpenGLNodeProcessor:
    """
    *For internal use only*

    *Singleton (by context)*

    Executes a GPU node by binding the target framebuffer,
    setting input textures and shader uniforms, rendering
    a full-screen quad through the associated OpenGL
    pipeline, and returning the resulting output texture.
    """

    _instances: dict[int, '_OpenGLNodeProcessor'] = {}

    @classmethod
    def get(
        cls,
        opengl_context: moderngl.Context
    ) -> '_OpenGLNodeProcessor':
        """
        Get the singleton instance for the specific
        `opengl_context` provided as parameter.
        """
        key = id(opengl_context)
        if key not in cls._instances:
            cls._instances[key] = cls(opengl_context)

        return cls._instances[key]

    def __init__(
        self,
        opengl_context: Union[moderngl.Context, None] = None
    ):
        # TODO: Maybe we can obtain it from other place (?)
        self.context: moderngl.Context = (
            OpenGLContext().context
            if opengl_context is None else
            opengl_context
        )
        """
        The context of the OpenGL program.
        """  

    def execute(
        self,
        opengl_pipeline: _OpenGLPipeline,
        opengl_frame_context: _OpenGLFrameContext,
        textures_map: dict[str, moderngl.Texture],
        uniforms: dict[str, object]
    ) -> moderngl.Texture:
        """
        Execute the node.
        """
        if not textures_map:
            raise ValueError('At least one texture must be provided.')

        opengl_frame_context.begin()
        
        # TODO: Uniforms here must be a simple dict with
        # 'key': 'value'

        # Bind input textures
        """
        TODO: This needs to be refactored in the '_Textures'
        class to expect an '_OpenGLPipeline due to this big
        refactor that changed it.
        """
        textures = PipelineTextures(
            textures = [
                _PipelineTexture(
                    name = name,
                    opengl_texture = opengl_texture
                )
                for name, opengl_texture in textures_map.items()
            ]
        )

        opengl_pipeline.render(
            uniforms = uniforms,
            textures = textures
        )

        return opengl_frame_context.output_texture