"""
TODO: These nodes are here because they must
be moved to the 'yta_editor_nodes_gpu'.
"""
from yta_video_opengl.new.node import _OpenGLNode

import moderngl


# TODO: We need to create the specific _OpenGLNode
# implementations that assign the pipelines and
# contexts specifically and ask for the uniforms it
# can use directly as parameters. But we also need
# the specific _OpenGLPipeline that includes the
# shaders we want to apply for a specific purpose

# TODO: This is just an example below and shouldn't
# be in this proyect but in 'yta_editor_nodes_gpu'    

# TODO: Am I really using this (?)
class _SingleTextureOpenGLNode(_OpenGLNode):
    """
    *For internal use only*

    An OpenGL node that uses a single texture called
    `base_texture` in the shaders. This class must 
    be inherited by the specific nodes that use this
    single texture to make changes.
    """

    mandatory_inputs: list[str] = ['base_input']
    """
    The inputs that are mandatory to be able to use the
    node.
    """
    optional_inputs: list[str] = []
    """
    The inputs that will be used in the node if provided
    but are not mandatory to make the node work properly.
    """

    def _get_textures_map(
        self,
        inputs: dict[str, moderngl.Texture]
    ) -> dict:
        """
        *For internal use only*

        Map the textures to a dict that we will need
        depending on the shaders the pipeline is using.

        We will have pipelines that use a single base
        texture, pipelines that mix two different
        textures, etc. The input must be called
        `base_input`.

        This is the base method for the node that is
        mapping a single texture. Rewrite it based on
        your own needs.
        """
        return {
            'base_texture': inputs['base_input']
        }
    
# TODO: Create the other types but in the
# 'yta_editor_nodes_gpu' library
        
class _BaseAndOverlayTexturesOpenGLNode(_OpenGLNode):
    """
    *For internal use only*

    An OpenGL node that uses a base texture called
    `base_texture` and an overlay texture named as
    `overlay_texture` in the shaders. This class must 
    be inherited by the specific nodes that use this
    single texture to make changes.
    """

    mandatory_inputs: list[str] = ['base_input', 'overlay_input']
    """
    The inputs that are mandatory to be able to use the
    node.
    """
    optional_inputs: list[str] = []
    """
    The inputs that will be used in the node if provided
    but are not mandatory to make the node work properly.
    """

    def _get_textures_map(
        self,
        inputs: dict[moderngl.Texture]
    ) -> dict:
        """
        *For internal use only*

        Map the textures to a dict that we will need
        depending on the shaders the pipeline is using.

        We will have pipelines that use a single base
        texture, pipelines that mix two different
        textures, etc.

        This is the base method for the node that is
        mapping a single texture. Rewrite it based on
        your own needs.
        """
        return {
            'base_texture': inputs['base_input'],
            'overlay_texture': inputs['overlay_input']
        }
    
class _FirstAndSecondTexturesOpenGLNode(_OpenGLNode):
    """
    *For internal use only*

    An OpenGL node that uses a first texture called
    `first_texture` and a second texture named as
    `second_texture` in the shaders. This class must 
    be inherited by the specific nodes that use this
    single texture to make changes.

    This is more specific for transitions or changes
    in which we go from a first texture to a second
    one somehow.
    """

    mandatory_inputs: list[str] = ['first_input', 'second_input']
    """
    The inputs that are mandatory to be able to use the
    node.
    """
    optional_inputs: list[str] = []
    """
    The inputs that will be used in the node if provided
    but are not mandatory to make the node work properly.
    """

    def _get_textures_map(
        self,
        inputs: dict[str, moderngl.Texture]
    ) -> dict:
        """
        *For internal use only*

        Map the textures to a dict that we will need
        depending on the shaders the pipeline is using.

        We will have pipelines that use a single base
        texture, pipelines that mix two different
        textures, etc.

        This is the base method for the node that is
        mapping a single texture. Rewrite it based on
        your own needs.
        """
        return {
            'first_texture': inputs['first_input'],
            'second_texture': inputs['second_input']
        }
    
class _OriginalProcessedSelectionOpenGLNode(_OpenGLNode):
    """
    *For internal use only*

    An OpenGL node that uses one texture called
    `original_texture` and a second texture named as
    `processed_texture`, with also another one called
    `selection_mask_texture`, in the shaders. This
    class must be inherited by the specific nodes that
    use this single texture to make changes.

    This is specific for applying the selection mask
    to mix the `processed_texture` with the original
    one.
    """

    mandatory_inputs: list[str] = ['original_input', 'processed_input', 'selection_mask_input']
    """
    The inputs that are mandatory to be able to use the
    node.
    """
    optional_inputs: list[str] = []
    """
    The inputs that will be used in the node if provided
    but are not mandatory to make the node work properly.
    """

    def _get_textures_map(
        self,
        inputs: dict[str, moderngl.Texture]
    ) -> dict:
        """
        *For internal use only*

        Map the textures to a dict that we will need
        depending on the shaders the pipeline is using.

        We will have pipelines that use a single base
        texture, pipelines that mix two different
        textures, etc.

        This is the base method for the node that is
        mapping a single texture. Rewrite it based on
        your own needs.
        """
        return {
            'original_texture': inputs['original_input'],
            'processed_texture': inputs['processed_input'],
            'selection_mask_texture': inputs['selection_mask_input']
        }