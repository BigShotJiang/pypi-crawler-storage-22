"""
SBS Dataset Collection Pipeline - Settings
"""
from pathlib import Path

# Base paths
BASE_DIR = Path(__file__).parent.parent
DATA_DIR = BASE_DIR / "data"
URLS_DIR = DATA_DIR / "urls"
VIDEOS_DIR = DATA_DIR / "videos"
CLIPS_DIR = DATA_DIR / "clips"
OUTPUTS_DIR = BASE_DIR / "outputs"
REPORTS_DIR = OUTPUTS_DIR / "reports"

# Video settings
CLIP_DURATION_BEFORE = 90  # 1분 30초 (초 단위)
CLIP_DURATION_AFTER = 90   # 1분 30초 (초 단위)
MAX_CLIP_DURATION = 180    # 최대 3분

# Download settings
VIDEO_FORMAT = "best[ext=mp4]/best"
DOWNLOAD_RETRIES = 3

# YOLO-World settings
YOLO_MODEL = "yolov8s-worldv2.pt"
CONFIDENCE_THRESHOLD = 0.25
FRAME_SAMPLE_RATE = 30  # 매 30프레임마다 샘플링 (약 1초)

# Task-specific class prompts
TASK_CLASSES = {
    "face": ["human face", "person face", "close-up face"],
    "license_plate": ["car license plate", "vehicle license plate", "korean license plate"],
    "tattoo": ["tattoo", "body tattoo", "skin tattoo"],
    "text": ["text on screen", "subtitle", "korean text", "caption"]
}

# Create directories if not exist
for dir_path in [URLS_DIR, VIDEOS_DIR, CLIPS_DIR, REPORTS_DIR]:
    dir_path.mkdir(parents=True, exist_ok=True)
