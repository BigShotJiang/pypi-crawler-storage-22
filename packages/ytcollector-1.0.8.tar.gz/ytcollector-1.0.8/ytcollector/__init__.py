"""
SBS Dataset Collector - YouTube 영상 수집 및 YOLO-World 검증 파이프라인
"""
from pathlib import Path

__version__ = "1.0.8"
__author__ = "SBS Dataset Team"

# Package root directory
PACKAGE_DIR = Path(__file__).parent

# Default data directories (can be overridden)
DEFAULT_DATA_DIR = Path.cwd() / "data"
DEFAULT_OUTPUT_DIR = Path.cwd() / "outputs"
