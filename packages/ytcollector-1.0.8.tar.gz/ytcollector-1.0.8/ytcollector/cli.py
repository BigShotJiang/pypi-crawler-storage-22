#!/usr/bin/env python3
"""
SBS Dataset Collector CLI (Updated)
"""
import argparse
import logging
from pathlib import Path

# Package import modified to 'downloader'
from .config import TASK_CLASSES, VALID_TASKS, get_paths
from .utils import ensure_dir, get_url_file_path

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)


def init_project(args):
    """프로젝트 디렉토리 초기화"""
    base_dir = Path(args.dir) if args.dir else Path.cwd()
    
    # 1. 태스크별 폴더 및 youtube_url.txt 생성
    for task in VALID_TASKS:
        # get_url_file_path 내부에서 ensure_dir 호출로 폴더 생성됨
        txt_path = get_url_file_path(base_dir, task)
        
        if not txt_path.exists():
            txt_path.write_text(
                "task_type,url,timestamp_min,timestamp_sec,description\n"
                f"{task},https://www.youtube.com/watch?v=EXAMPLE,2,30,샘플\n",
                encoding='utf-8'
            )
            
    # 2. config.py의 get_paths 로직에 따른 폴더들 생성 확인
    paths = get_paths(base_dir)
    ensure_dir(paths['outputs']) 
    
    print(f"✓ Project initialized at: {base_dir}")
    print(f"  - Add URLs to: urls/<task>/youtube_url.txt")
    print(f"  - Videos will be saved to configured OUTPUT_DIR (or video/ folder)")


def run_download(args):
    """TXT 파일에서 영상 다운로드"""
    from .downloader import download_from_txt  # Changed function name
    
    base_dir = Path(args.dir) if args.dir else Path.cwd()
    
    # argparse에서 nargs='+'로 받아오면 args.task는 항상 리스트
    tasks = args.task if isinstance(args.task, list) else [args.task]
    
    total_success = 0
    total_processed = 0
    
    for task in tasks:
        logger.info(f"=== Processing Task: {task} ===")
        
        # 파일 경로: video/{task}/youtube_url.txt
        txt_file = get_url_file_path(base_dir, task)
        
        if not txt_file.exists():
            logger.error(f"URL file not found: {txt_file}")
            logger.info(f"Skipping {task}. Run 'ytcollector init' first.")
            continue
        
        logger.info(f"Starting{' fast' if args.fast else ''} download for task: {task}")
        
        if args.fast:
            from .downloader import download_from_txt_parallel
            results = download_from_txt_parallel(txt_file, task, base_dir, max_count=args.count, skip_verify=args.skip_verify)
        else:
            results = download_from_txt(txt_file, task, base_dir, max_count=args.count, skip_verify=args.skip_verify)
        
        success_count = sum(1 for r in results if r.get('success'))
        total_success += success_count
        total_processed += len(results)
        
        print(f"✓ Task '{task}' complete: {success_count}/{len(results)} successful")
        
    print(f"\n✓ All tasks complete: {total_success}/{total_processed} successful total")


def run_download_single(args):
    """단일 URL 다운로드"""
    from .downloader import VideoDownloader
    
    base_dir = Path(args.dir) if args.dir else Path.cwd()
    downloader = VideoDownloader(args.task, base_dir)
    
    try:
        output_path, metadata = downloader.download_clip_at_timestamp(
            url=args.url,
            timestamp_min=args.timestamp_min,
            timestamp_sec=args.timestamp_sec
        )
        status = "Cached" if metadata.get('cached') else "Downloaded"
        print(f"✓ {status}: {output_path}")
        if not metadata.get('cached'):
            print(f"  Clip duration: {metadata['clip_duration']}s")
            
    except Exception as e:
        logger.error(f"Download failed: {e}")


def run_verify(args):
    """클립 영상 검증"""
    from .verifier import verify_clip, batch_verify
    
    base_dir = Path(args.dir) if args.dir else Path.cwd()
    
    if args.video:
        video_path = Path(args.video)
        result = verify_clip(video_path, args.task, base_dir)
        print_verification_result(result)
    else:
        # 폴더 경로: video/{task}/
        clips_dir = base_dir / "video" / args.task
        if not clips_dir.exists():
            logger.error(f"Video directory not found: {clips_dir}")
            return
        
        results = batch_verify(clips_dir, args.task, base_dir)
        valid_count = sum(1 for r in results if r.get('is_valid'))
        print(f"✓ Verification complete: {valid_count}/{len(results)} valid")


def run_pipeline(args):
    """다운로드 + 검증 전체 파이프라인"""
    print(f"=== Starting pipeline for task: {args.task} ===")
    
    run_download(args)
    
    if args.verify:
        print("\n--- Running verification ---")
        run_verify(args)
    
    print("=== Pipeline complete ===")


def print_verification_result(result: dict):
    """검증 결과 출력"""
    summary = result.get('summary', {})
    
    print("\n" + "="*50)
    print(f"Video: {Path(result['video_path']).name}")
    print(f"Task: {result['task_type']}")
    print(f"Classes: {result['classes']}")
    print("-"*50)
    print(f"Duration: {summary.get('duration_sec', 0):.1f}s")
    print(f"Frames with detection: {summary.get('frames_with_detection', 0)}")
    print(f"Detection rate: {summary.get('detection_rate', 0):.1%}")
    print(f"Valid: {'✓ YES' if result.get('is_valid') else '✗ NO'}")
    print("="*50)


def list_tasks(args):
    """태스크 목록 출력"""
    print("\nAvailable Tasks and YOLO-World Classes:")
    print("-" * 50)
    for task, classes in TASK_CLASSES.items():
        print(f"\n{task}:")
        for cls in classes:
            print(f"  - {cls}")


def main():
    parser = argparse.ArgumentParser(
        description='Downloader - SBS Dataset Collector',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  downloader init                           # 프로젝트 초기화
  downloader download --task face           # 텍스트 파일에서 다운로드
  downloader verify --task face             # YOLO 검증
        """
    )
    
    parser.add_argument('--dir', '-d', help='Project directory (default: current)')
    
    subparsers = parser.add_subparsers(dest='command', help='Commands')
    
    # Init
    init_parser = subparsers.add_parser('init', help='Initialize project directory')
    
    # Download
    download_parser = subparsers.add_parser('download', help='Download from youtube_url.txt')
    download_parser.add_argument('--task', '-t', required=True, nargs='+', choices=VALID_TASKS, help='One or more tasks (e.g. face tattoo)')
    download_parser.add_argument('--count', '-n', type=int, help='Max videos to collect (default: 1000)')
    download_parser.add_argument('--fast', action='store_true', help='Enable fast parallel downloading')
    download_parser.add_argument('--skip-verify', '-S', action='store_true', help='Skip YOLO verification and save all clips')
    
    # Download single
    single_parser = subparsers.add_parser('download-single', help='Download single video')
    single_parser.add_argument('--task', '-t', required=True, choices=VALID_TASKS)
    single_parser.add_argument('--url', '-u', required=True, help='YouTube URL')
    single_parser.add_argument('--timestamp-min', '-m', type=int, required=True)
    single_parser.add_argument('--timestamp-sec', '-s', type=int, required=True)
    
    # Verify
    verify_parser = subparsers.add_parser('verify', help='Verify with YOLO-World')
    verify_parser.add_argument('--task', '-t', required=True, nargs='+', choices=VALID_TASKS)
    verify_parser.add_argument('--video', '-v', help='Specific video file')
    
    # Pipeline
    pipeline_parser = subparsers.add_parser('pipeline', help='Full pipeline')
    pipeline_parser.add_argument('--task', '-t', required=True, nargs='+', choices=VALID_TASKS)
    pipeline_parser.add_argument('--verify', action='store_true')
    pipeline_parser.add_argument('--skip-verify', '-S', action='store_true', help='Skip verification in download stage')
    
    # List tasks
    subparsers.add_parser('list-tasks', help='List available tasks')
    
    args = parser.parse_args()
    
    if args.command is None:
        parser.print_help()
        return
    
    commands = {
        'init': init_project,
        'download': run_download,
        'download-single': run_download_single,
        'verify': run_verify,
        'pipeline': run_pipeline,
        'list-tasks': list_tasks,
    }
    
    commands[args.command](args)


if __name__ == '__main__':
    main()
