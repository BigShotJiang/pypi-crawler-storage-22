"""
SBS Dataset Collector - Configuration
"""
from pathlib import Path
import platform

# Default paths (will use current working directory)
def get_paths(base_dir: Path = None):
    """Get all paths based on base directory"""
    if base_dir is None:
        base_dir = Path.cwd()
    
    return {
        'base': base_dir,
        'data': base_dir / "data",
        # 'urls' removed - now inside video/{task}/youtube_url.txt
        'videos': base_dir / "data" / "videos",  # 원본 전체 영상
        'clips': base_dir / "video",             # 클리핑된 영상 (요구사항: video/task_이름)
        'outputs': base_dir / "outputs",
        'reports': base_dir / "outputs" / "reports",
        'history': base_dir / "download_history.json",
    }

# 사용자 지정 출력 경로 (네트워크 드라이브 등)
# macOS에서는 "/Volumes/Data/..." 등으로 마운트된 경로를 사용해야 함
NAS_PATH_WINDOWS = r"\\NAS_SERVER_IP\Data\Private Dataset\SBS_De-Identification_YouTube"
NAS_PATH_MAC = "/Volumes/Data/Private Dataset/SBS_De-Identification_YouTube"

if platform.system() == 'Windows':
    CUSTOM_OUTPUT_DIR = NAS_PATH_WINDOWS
elif platform.system() == 'Darwin': # macOS
    CUSTOM_OUTPUT_DIR = NAS_PATH_MAC
else:
    CUSTOM_OUTPUT_DIR = None

# Video settings
CLIP_DURATION_BEFORE = 90  # 1분 30초 (초 단위)
CLIP_DURATION_AFTER = 90   # 1분 30초 (초 단위)
MAX_CLIP_DURATION = 180    # 최대 3분

# Download settings
VIDEO_FORMAT = "best[ext=mp4]/best"
DOWNLOAD_RETRIES = 3
MAX_VIDEOS_PER_TASK = 1000  # 태스크별 최대 영상 저장 수 (CLI -n 옵션으로 덮어쓰기 가능)

# Fast Mode Settings (Parallel)
MAX_WORKERS = 4              # 병렬 작업 프로세스 수
REQUEST_DELAY_MIN = 1.0      # 최소 대기 시간 (초)
REQUEST_DELAY_MAX = 3.0      # 최대 대기 시간 (초)
PROXY_URL = None             # 프록시 (예: "http://user:pass@host:port")

# YOLO-World settings
YOLO_MODEL = "yolov8s-worldv2.pt"
CONFIDENCE_THRESHOLD = 0.25
FRAME_SAMPLE_RATE = 30  # 매 30프레임마다 샘플링 (약 1초)

# Task-specific class prompts
TASK_CLASSES = {
    "face": ["face"],
    "license_plate": ["license plate"],
    "tattoo": ["tattoo"],
    "text": ["text"],
    "knife": ["knife"],
    "cigarette": ["cigarette"]
}

VALID_TASKS = list(TASK_CLASSES.keys())
