"""
YouTube Video Downloader Module
yt-dlp 기반 YouTube 영상 다운로드 및 특정 구간 추출
"""
from pathlib import Path
from typing import Optional, Tuple, List, Dict
import logging

import yt_dlp
from yt_dlp.utils import download_range_func

from .config import (
    VIDEO_FORMAT,
    DOWNLOAD_RETRIES,
    CLIP_DURATION_BEFORE,
    CLIP_DURATION_AFTER,
)
from .utils import extract_video_id, get_clip_path

logger = logging.getLogger(__name__)


class LimitReachedError(Exception):
    """다운로드 제한 도달 예외"""
    pass


class VideoDownloader:
    """YouTube 영상 다운로더 클래스"""
    
    def __init__(self, task_type: str, base_dir: Path = None):
        self.task_type = task_type
        self.base_dir = base_dir or Path.cwd()
    
    def get_video_info(self, url: str) -> dict:
        """영상 메타데이터 조회 (다운로드 없이)"""
        ydl_opts = {
            'quiet': True,
            'no_warnings': True,
            'extract_flat': False,
        }
        
        with yt_dlp.YoutubeDL(ydl_opts) as ydl:
            info = ydl.extract_info(url, download=False)
            return {
                'id': info.get('id'),
                'title': info.get('title'),
                'duration': info.get('duration'),
                'channel': info.get('channel'),
                'upload_date': info.get('upload_date'),
            }
            
    def search_youtube(self, query: str, max_results: int = 50) -> List[Dict]:
        """YouTube 검색을 통해 상위 결과의 URL 목록 반환"""
        ydl_opts = {
            'quiet': True,
            'no_warnings': True,
            'extract_flat': True,
            'force_generic_extractor': False,
        }
        
        search_query = f"ytsearch{max_results}:{query}"
        logger.info(f"Searching YouTube for: '{query}' (Max {max_results} results)")
        
        results = []
        with yt_dlp.YoutubeDL(ydl_opts) as ydl:
            try:
                info = ydl.extract_info(search_query, download=False)
                if 'entries' in info:
                    for entry in info['entries']:
                        if entry:
                            results.append({
                                'url': f"https://www.youtube.com/watch?v={entry['id']}",
                                'title': entry.get('title'),
                                'id': entry['id']
                            })
            except Exception as e:
                logger.error(f"Search failed: {e}")
                
        return results
    
    def calculate_clip_range(
        self, 
        timestamp_sec: int, 
        video_duration: int
    ) -> Tuple[int, int]:
        """타임스탬프 기준 ±1분 30초 클립 범위 계산"""
        start = max(0, timestamp_sec - CLIP_DURATION_BEFORE)
        end = min(video_duration, timestamp_sec + CLIP_DURATION_AFTER)
        return start, end
    
    def download_segment(
        self, 
        url: str, 
        start_sec: int, 
        end_sec: int,
        output_path: Optional[Path] = None
    ) -> Path:
        """특정 구간만 다운로드"""
        video_id = extract_video_id(url)
        
        if output_path is None:
            filename = f"{video_id}_{start_sec}-{end_sec}"
            output_path = get_clip_path(self.base_dir, self.task_type, filename)
        
        output_template = str(output_path).replace('.mp4', '')
        
        ydl_opts = {
            'format': VIDEO_FORMAT,
            'outtmpl': f"{output_template}.%(ext)s",
            'retries': DOWNLOAD_RETRIES,
            'quiet': False,
            'no_warnings': False,
            'download_ranges': download_range_func(None, [(start_sec, end_sec)]),
            'force_keyframes_at_cuts': True,
        }

        # Use ffmpeg from imageio-ffmpeg
        try:
            import imageio_ffmpeg
            ffmpeg_path = imageio_ffmpeg.get_ffmpeg_exe()
            ydl_opts['ffmpeg_location'] = ffmpeg_path
            logger.debug(f"Using ffmpeg from: {ffmpeg_path}")
        except ImportError:
            logger.warning("imageio-ffmpeg not found, relying on system ffmpeg")
        
        logger.info(f"Downloading segment [{start_sec}s - {end_sec}s] from: {url}")
        
        with yt_dlp.YoutubeDL(ydl_opts) as ydl:
            ydl.download([url])
        
        return output_path
    
    def get_saved_video_count(self) -> int:
        """현재 태스크 폴더에 저장된 영상 개수 확인"""
        from .utils import get_task_video_count
        return get_task_video_count(self.base_dir, self.task_type)

    def _get_history_key(self, url: str, timestamp_min: int, timestamp_sec: int) -> str:
        """히스토리 키 생성"""
        video_id = extract_video_id(url)
        return f"{self.task_type}_{video_id}_{timestamp_min}_{timestamp_sec}"

    def download_clip_at_timestamp(
        self, 
        url: str, 
        timestamp_min: int, 
        timestamp_sec: int,
        skip_verify: bool = False
    ) -> Tuple[Optional[Path], Optional[dict]]:
        """
        특정 타임스탬프 기준으로 ±1:30 클립 다운로드
        1. 임시 폴더에 다운로드
        2. YOLO 검증 (타겟 객체 유무 확인)
        3. 검증 통과 시 최종 경로로 이동 (task_xxxx.mp4)
        """
        from .config import MAX_VIDEOS_PER_TASK
        from .utils import load_history, save_history, get_clip_path, ensure_dir
        from .verifier import verify_clip
        import shutil
        
        target_sec = timestamp_min * 60 + timestamp_sec
        history_key = self._get_history_key(url, timestamp_min, timestamp_sec)
        
        # 1. 히스토리 기반 중복 확인
        history = load_history(self.base_dir)
        if history_key in history:
            saved_path = history[history_key].get('output_path', 'unknown')
            # 파일이 실제로 존재하는지도 확인하면 좋음
            if Path(saved_path).exists():
                logger.info(f"Skipping download (already in history): {saved_path}")
                return Path(saved_path), {'cached': True, 'output_path': saved_path}

        # 2. 개수 제한 확인
        current_count = self.get_saved_video_count()
        if current_count >= MAX_VIDEOS_PER_TASK:
            msg = f"Task limit reached ({current_count}/{MAX_VIDEOS_PER_TASK}). Stopping download."
            logger.warning(msg)
            raise LimitReachedError(msg)
        
        # 3. 영상 정보 조회
        try:
            info = self.get_video_info(url)
        except Exception as e:
            logger.error(f"Failed to get video info: {e}")
            raise

        video_duration = info.get('duration', 0)
        
        if video_duration == 0:
            raise ValueError(f"Cannot get video duration for: {url}")
        
        start_sec, end_sec = self.calculate_clip_range(target_sec, video_duration)
        clip_duration = end_sec - start_sec
        
        logger.info(
            f"Target: {timestamp_min}:{timestamp_sec:02d}, "
            f"Clip range: {start_sec}s - {end_sec}s (duration: {clip_duration}s)"
        )
        
        # 4. 임시 파일 다운로드
        # temp 폴더 생성
        temp_dir = ensure_dir(self.base_dir / "temp")
        video_id = extract_video_id(url)
        temp_filename = f"temp_{video_id}_{timestamp_min}_{timestamp_sec}.mp4"
        temp_path = temp_dir / temp_filename
        
        try:
            self.download_segment(url, start_sec, end_sec, temp_path)
            
            # 5. YOLO 검증 (skip_verify가 False일 때만 수행)
            if not skip_verify:
                logger.info(f"Verifying content for task: {self.task_type}...")
                # verifier 모듈 사용하여 검증
                verify_result = verify_clip(temp_path, self.task_type, self.base_dir)
                
                logger.info(f"Verification Info - Rate: {verify_result.get('summary', {}).get('detection_rate'):.2%}, Is Valid: {verify_result.get('is_valid')}")
                
                if not verify_result.get('is_valid', False):
                    logger.warning(f"Verification failed: No {self.task_type} detected (Rate: {verify_result.get('summary', {}).get('detection_rate'):.2%}). Deleting...")
                    if temp_path.exists():
                        temp_path.unlink()
                    return None, None
            else:
                logger.info(f"Skipping verification for task: {self.task_type} (--skip-verify enabled)")
                verify_result = {'is_valid': True, 'skipped': True}
            
            # 6. 검증 통과(혹은 건너뜀) -> 최종 저장 (순차적 파일명 생성)
            final_path = get_clip_path(self.base_dir, self.task_type, filename=None)
            
            # 이동 (네트워크 드라이브면 shutil.move 사용)
            shutil.move(str(temp_path), str(final_path))
            logger.info(f"Saved verified video to: {final_path}")
            
            metadata = {
                **info,
                'target_timestamp_sec': target_sec,
                'clip_start_sec': start_sec,
                'clip_end_sec': end_sec,
                'clip_duration': clip_duration,
                'output_path': str(final_path),
                'timestamp': timestamp_min * 60 + timestamp_sec,
                'verification': verify_result
            }
            
            # 7. 히스토리 업데이트
            history = load_history(self.base_dir)
            history[history_key] = metadata
            save_history(self.base_dir, history)
            
            return final_path, metadata
            
        except Exception as e:
            logger.error(f"Error during processing: {e}")
            # 에러 발생 시 임시 파일 정리
            if temp_path.exists():
                temp_path.unlink()
            raise


def parse_txt_line(line: str) -> Optional[Dict]:
    """
    텍스트 파일 한 줄 파싱
    형식: task_type,url,timestamp_min,timestamp_sec,description
    """
    parts = [p.strip() for p in line.split(',')]
    if len(parts) < 4:
        return None
    
    # 헤더 체크
    if parts[0] == 'task_type' and parts[2] == 'timestamp_min':
        return None
        
    try:
        return {
            'task_type': parts[0],
            'url': parts[1],
            'timestamp_min': int(parts[2]),
            'timestamp_sec': int(parts[3]),
            'description': parts[4] if len(parts) > 4 else ''
        }
    except ValueError:
        return None


def download_from_txt(txt_path: Path, task_type: str, base_dir: Path = None, max_count: int = None, skip_verify: bool = False) -> list:
    """TXT 파일에서 다운로드 실행 (순차)"""
    return _process_download_loop(txt_path, task_type, base_dir, parallel=False, max_count=max_count, skip_verify=skip_verify)


def download_from_txt_parallel(txt_path: Path, task_type: str, base_dir: Path = None, max_count: int = None, skip_verify: bool = False) -> list:
    """TXT 파일에서 병렬 다운로드 실행 (Fast Mode)"""
    return _process_download_loop(txt_path, task_type, base_dir, parallel=True, max_count=max_count, skip_verify=skip_verify)


def _process_download_loop(txt_path: Path, task_type: str, base_dir: Path = None, parallel: bool = False, max_count: int = None, skip_verify: bool = False) -> list:
    from .config import MAX_VIDEOS_PER_TASK, MAX_WORKERS, REQUEST_DELAY_MIN, REQUEST_DELAY_MAX
    import time
    import random
    from concurrent.futures import ThreadPoolExecutor, as_completed
    
    # max_count가 없으면 config의 기본값 사용
    limit = max_count if max_count is not None else MAX_VIDEOS_PER_TASK

    results = []
    downloader = VideoDownloader(task_type, base_dir)
    
    # 시작 전 개수 확인
    initial_count = downloader.get_saved_video_count()
    if initial_count >= limit:
        logger.warning(f"Task '{task_type}' already has {initial_count} videos (Limit: {limit}). Skipping.")
        return results
    
    if not txt_path.exists():
        logger.error(f"File not found: {txt_path}")
        return results

    lines = txt_path.read_text(encoding='utf-8').splitlines()
    items = []
    
    for line in lines:
        if not line.strip() or line.startswith('#'):
            continue
        data = parse_txt_line(line)
        if data and data['task_type'] == task_type:
            items.append(data)

    if not items:
        return results

    logger.info(f"Found {len(items)} URLs. Target: {limit} videos (Current: {initial_count}). Starting {'parallel' if parallel else 'sequential'} download...")

    def process_item(data):
        # 현재 개수 체크 (루프 도중 목표 달성 시 중단 위함)
        # 주의: 병렬 처리 시 정확한 count 동기화는 Lock이 필요하지만, 여기선 대략적인 체크로 충분
        current = downloader.get_saved_video_count()
        if current >= limit:
            raise LimitReachedError("Target count reached")

        # 방화벽 우회용 랜덤 딜레이 (병렬 모드에서도 적용하여 동시 요청 폭주 완화)
        if parallel:
            time.sleep(random.uniform(REQUEST_DELAY_MIN, REQUEST_DELAY_MAX))
            
        try:
            # VideoDownloader 내부의 limit 체크는 config 값을 쓰므로, 
            # 여기서는 외부에서 주입된 limit을 강제할 방법이 필요하거나, 
            # 단순히 루프 레벨에서 제어하면 됨.
            # download_clip_at_timestamp 메서드는 내부적으로 MAX_VIDEOS_PER_TASK를 체크하므로,
            # 이를 우회하거나 단순 루프 제어로 처리.
            
            output_path, metadata = downloader.download_clip_at_timestamp(
                url=data['url'],
                timestamp_min=data['timestamp_min'],
                timestamp_sec=data['timestamp_sec'],
                skip_verify=skip_verify
            )
            
            if output_path is None:
                return {
                    'success': False,
                    'url': data['url'],
                    'error': 'Verification failed',
                    'status': 'skipped'
                }

            if metadata and metadata.get('cached'):
                return {
                    'success': True,
                    'output_path': str(output_path),
                    'metadata': metadata,
                    'status': 'cached'
                }
                
            return {
                'success': True,
                'output_path': str(output_path),
                'metadata': metadata,
                'status': 'downloaded'
            }
            
        except LimitReachedError:
            # 내부에서 발생한 LimitReachedError도 처리
            return {'success': False, 'error': 'Limit reached', 'status': 'limit_reached'}
            
        except Exception as e:
            # "에러가 나면 pass" -> 로그만 남기고 실패 결과 반환
            logger.warning(f"Error processing {data['url']}: {e}")
            return {
                'success': False,
                'url': data['url'],
                'error': str(e),
                'status': 'error'
            }

    # --- 1단계: youtube_url.txt 파일 목록 처리 ---
    if items:
        if parallel:
            with ThreadPoolExecutor(max_workers=MAX_WORKERS) as executor:
                futures = [executor.submit(process_item, item) for item in items]
                
                # 진행 상황 표시
                from tqdm import tqdm
                for future in tqdm(as_completed(futures), total=len(items), desc="Fast Download"):
                    try:
                        res = future.result()
                        results.append(res)
                        if res.get('status') == 'limit_reached' or downloader.get_saved_video_count() >= limit:
                            logger.info(f"Download limit ({limit}) reached. Stopping.")
                            executor.shutdown(wait=False, cancel_futures=True)
                            break
                    except Exception:
                        continue
        else:
            # 순차 실행
            for item in items:
                if downloader.get_saved_video_count() >= limit:
                    break
                res = process_item(item)
                results.append(res)
                if res.get('status') == 'limit_reached':
                    break

    # --- 2단계: 목표 수량을 못 채웠을 경우 YouTube 검색Fallback (반복 시도) ---
    max_search_attempts = 5  # 최대 검색 시도 횟수
    search_attempt = 0
    processed_urls = set(data['url'] for data in items) # 이미 처리한 URL 중복 검색 방지
    
    while downloader.get_saved_video_count() < limit and search_attempt < max_search_attempts:
        current_count = downloader.get_saved_video_count()
        remaining = limit - current_count
        
        logger.info(f"\n[Search Attempt {search_attempt+1}] Target not reached ({current_count}/{limit}). Searching YouTube for '{task_type}'...")
        
        # 검색어: 태스크 이름
        # 검색 결과 개수를 점진적으로 늘리거나 조절 가능
        search_results = downloader.search_youtube(task_type, max_results=min(100, remaining * 5))
        
        if not search_results:
            logger.warning("No more search results found.")
            break
        
        # 새로운 URL만 필터링
        new_entries = [e for e in search_results if e['url'] not in processed_urls]
        if not new_entries:
            logger.info("No new unique videos found in this search attempt.")
            search_attempt += 1
            continue
            
        search_items = []
        for entry in new_entries:
            processed_urls.add(entry['url'])
            # 검색 결과는 타임스탬프 정보가 없으므로 여러 지점 시도 가능 (현재는 1분 지점 고정)
            search_items.append({
                'task_type': task_type,
                'url': entry['url'],
                'timestamp_min': 1, 
                'timestamp_sec': 0,
                'description': f"Auto-searched: {entry['title']}"
            })
            
        logger.info(f"Processing {len(search_items)} new search results...")
        
        if parallel:
            with ThreadPoolExecutor(max_workers=MAX_WORKERS) as executor:
                futures = [executor.submit(process_item, item) for item in search_items]
                from tqdm import tqdm
                for future in tqdm(as_completed(futures), total=len(search_items), desc=f"Search Fallback #{search_attempt+1}"):
                    try:
                        res = future.result()
                        results.append(res)
                        if res.get('status') == 'limit_reached' or downloader.get_saved_video_count() >= limit:
                            executor.shutdown(wait=False, cancel_futures=True)
                            break
                    except Exception:
                        continue
        else:
            for item in search_items:
                if downloader.get_saved_video_count() >= limit:
                    break
                res = process_item(item)
                results.append(res)
                if res.get('status') == 'limit_reached':
                    break
        
        search_attempt += 1
        
    final_count = downloader.get_saved_video_count()
    if final_count < limit:
        logger.warning(f"Finished search attempts. Final count: {final_count}/{limit}")
    else:
        logger.info(f"Successfully reached target count: {final_count}/{limit}")
    
    return results
