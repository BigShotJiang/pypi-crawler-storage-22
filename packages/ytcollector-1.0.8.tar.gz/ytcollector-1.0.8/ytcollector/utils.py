"""
Utility functions for the SBS Dataset Collection Pipeline
"""
from pathlib import Path
from datetime import datetime
import re
import json


def timestamp_to_seconds(minutes: int, seconds: int) -> int:
    """분:초를 총 초로 변환"""
    return minutes * 60 + seconds


def seconds_to_timestamp(total_seconds: int) -> str:
    """초를 MM:SS 형식으로 변환"""
    minutes = total_seconds // 60
    seconds = total_seconds % 60
    return f"{minutes:02d}:{seconds:02d}"


def extract_video_id(url: str) -> str:
    """YouTube URL에서 video ID 추출"""
    patterns = [
        r'(?:v=|/)([0-9A-Za-z_-]{11}).*',
        r'(?:embed/)([0-9A-Za-z_-]{11})',
        r'(?:youtu\.be/)([0-9A-Za-z_-]{11})',
    ]
    
    for pattern in patterns:
        match = re.search(pattern, url)
        if match:
            return match.group(1)
    
    return url[-11:] if len(url) >= 11 else url


def ensure_dir(path: Path) -> Path:
    """디렉토리 생성 (없으면)"""
    try:
        path.mkdir(parents=True, exist_ok=True)
    except PermissionError:
        # 네트워크 드라이브 권한 문제 등
        pass
    return path


def get_output_dir(base_dir: Path) -> Path:
    """영상이 저장될 실제 디렉토리 반환"""
    from .config import CUSTOM_OUTPUT_DIR
    
    if CUSTOM_OUTPUT_DIR:
        return ensure_dir(Path(CUSTOM_OUTPUT_DIR))
    
    # 기본값: 프로젝트 폴더 내 video/ (단일 폴더 모드)
    # 기존에는 video/{task_type}이었으나, 요구사항 변경으로 "한 폴더 안에" 저장
    return ensure_dir(base_dir / "video")


def get_next_filename(output_dir: Path, task_type: str) -> str:
    """
    순차적인 파일명 생성 (task_0001.mp4)
    폴더 내의 기존 파일을 스캔하여 가장 큰 번호 + 1 반환
    """
    # glob은 느릴 수 있으므로 파일이 많아지면 최적화 필요
    # 현재는 100개 제한이므로 괜찮음
    existing_files = list(output_dir.glob(f"{task_type}_*.mp4"))
    max_num = 0
    
    pattern = re.compile(rf"{task_type}_(\d{{4}})\.mp4")
    
    for file_path in existing_files:
        match = pattern.match(file_path.name)
        if match:
            num = int(match.group(1))
            if num > max_num:
                max_num = num
    
    next_num = max_num + 1
    return f"{task_type}_{next_num:04d}"


def get_clip_path(base_dir: Path, task_type: str, filename: str = None) -> Path:
    """클립 저장 경로 반환"""
    # filename이 None이면 순차적 이름 생성
    output_dir = get_output_dir(base_dir)
    
    if filename is None:
        filename_str = get_next_filename(output_dir, task_type)
        return output_dir / f"{filename_str}.mp4"
    
    # 확장자 보정
    if not filename.endswith('.mp4'):
        filename += '.mp4'
        
    return output_dir / filename


def get_task_video_count(base_dir: Path, task_type: str) -> int:
    """해당 태스크의 영상 개수 확인 (파일명 기준)"""
    output_dir = get_output_dir(base_dir)
    return len(list(output_dir.glob(f"{task_type}_*.mp4")))


def load_history(base_dir: Path) -> dict:
    """다운로드 히스토리 로드 (URL 중복 방지용)"""
    # 히스토리 파일은 항상 프로젝트 로컬 폴더에 저장 (네트워크 공유 X)
    history_path = base_dir / "download_history.json"
    if history_path.exists():
        try:
            return json.loads(history_path.read_text(encoding='utf-8'))
        except:
            return {}
    return {}


def save_history(base_dir: Path, history: dict):
    """다운로드 히스토리 저장"""
    history_path = base_dir / "download_history.json"
    history_path.write_text(json.dumps(history, indent=2, ensure_ascii=False), encoding='utf-8')


def get_url_file_path(base_dir: Path, task_type: str) -> Path:
    """URL 파일 경로 반환"""
    # URL 파일은 로컬 urls/task_type/youtube_url.txt
    task_dir = ensure_dir(base_dir / "urls" / task_type)
    return task_dir / "youtube_url.txt"


def get_report_path(base_dir: Path, task_type: str, filename: str) -> Path:
    """리포트 저장 경로 반환"""
    task_dir = ensure_dir(base_dir / "outputs" / "reports" / task_type)
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    return task_dir / f"{filename}_report_{timestamp}.json"


def validate_url(url: str) -> bool:
    """YouTube URL 유효성 검사"""
    youtube_patterns = [
        r'(https?://)?(www\.)?youtube\.com/watch\?v=',
        r'(https?://)?(www\.)?youtu\.be/',
        r'(https?://)?(www\.)?youtube\.com/embed/',
    ]
    return any(re.match(pattern, url) for pattern in youtube_patterns)
