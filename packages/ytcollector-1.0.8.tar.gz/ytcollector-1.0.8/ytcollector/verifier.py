"""
YOLO-World Verifier Module
YOLO-World 기반 객체 탐지 및 클래스 검증
"""
import json
from pathlib import Path
from typing import List, Dict, Optional
import logging
from datetime import datetime

import cv2
from tqdm import tqdm

# Updated imports for new package structure
from .config import (
    YOLO_MODEL,
    CONFIDENCE_THRESHOLD,
    FRAME_SAMPLE_RATE,
    TASK_CLASSES,
)
from .utils import get_report_path

logger = logging.getLogger(__name__)


class YOLOWorldVerifier:
    """YOLO-World 기반 영상 검증 클래스"""
    
    def __init__(self, task_type: str, base_dir: Path = None, model_name: str = YOLO_MODEL):
        self.task_type = task_type
        self.base_dir = base_dir or Path.cwd()
        self.model_name = model_name
        self.model = None
        self.classes = TASK_CLASSES.get(task_type, [])
        
        if not self.classes:
            raise ValueError(f"Unknown task type: {task_type}")
    
    def load_model(self):
        """YOLO-World 모델 로드"""
        if self.model is None:
            from ultralytics import YOLOWorld
            
            logger.info(f"Loading YOLO-World model: {self.model_name}")
            self.model = YOLOWorld(self.model_name)
            
            logger.info(f"Setting classes for {self.task_type}: {self.classes}")
            self.model.set_classes(self.classes)
        
        return self.model
    
    def verify_frame(self, frame) -> List[Dict]:
        """단일 프레임에서 객체 탐지"""
        model = self.load_model()
        results = model.predict(frame, conf=CONFIDENCE_THRESHOLD, verbose=False)
        
        detections = []
        for result in results:
            boxes = result.boxes
            for box in boxes:
                detection = {
                    'class_id': int(box.cls[0]),
                    'class_name': self.classes[int(box.cls[0])] if int(box.cls[0]) < len(self.classes) else 'unknown',
                    'confidence': float(box.conf[0]),
                    'bbox': box.xyxy[0].tolist(),
                }
                detections.append(detection)
        
        return detections
    
    def verify_video(
        self, 
        video_path: Path,
        sample_rate: int = FRAME_SAMPLE_RATE
    ) -> Dict:
        """영상 전체 검증"""
        logger.info(f"Verifying video: {video_path}")
        
        cap = cv2.VideoCapture(str(video_path))
        
        if not cap.isOpened():
            raise ValueError(f"Cannot open video: {video_path}")
        
        fps = cap.get(cv2.CAP_PROP_FPS)
        total_frames = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))
        duration = total_frames / fps if fps > 0 else 0
        
        frame_results = []
        detection_count = 0
        frames_with_detection = 0
        frame_idx = 0
        
        pbar = tqdm(total=total_frames // sample_rate, desc="Verifying")
        
        while True:
            ret, frame = cap.read()
            if not ret:
                break
            
            if frame_idx % sample_rate == 0:
                detections = self.verify_frame(frame)
                
                if detections:
                    frames_with_detection += 1
                    detection_count += len(detections)
                    
                    frame_results.append({
                        'frame_idx': frame_idx,
                        'timestamp_sec': frame_idx / fps if fps > 0 else 0,
                        'detections': detections,
                    })
                
                pbar.update(1)
            
            frame_idx += 1
        
        cap.release()
        pbar.close()
        
        sampled_frames = max(1, total_frames // sample_rate)
        detection_rate = frames_with_detection / sampled_frames
        
        result = {
            'video_path': str(video_path),
            'task_type': self.task_type,
            'classes': self.classes,
            'summary': {
                'total_frames': total_frames,
                'sampled_frames': sampled_frames,
                'fps': fps,
                'duration_sec': duration,
                'frames_with_detection': frames_with_detection,
                'total_detections': detection_count,
                'detection_rate': detection_rate,
            },
            'frame_results': frame_results,
            'verified_at': datetime.now().isoformat(),
            'model': self.model_name,
            'is_valid': detection_rate > 0.01,  # 1% 이상 탐지되면 유효한 것으로 간주 (기존 10%에서 하향)
        }
        
        logger.info(
            f"Verification complete: {frames_with_detection}/{sampled_frames} frames "
            f"({detection_rate:.1%}) with {self.task_type} detected"
        )
        
        return result
    
    def save_report(self, result: Dict, output_path: Optional[Path] = None) -> Path:
        """검증 결과 JSON 저장"""
        if output_path is None:
            video_name = Path(result['video_path']).stem
            output_path = get_report_path(self.base_dir, self.task_type, video_name)
        
        with open(output_path, 'w', encoding='utf-8') as f:
            json.dump(result, f, ensure_ascii=False, indent=2)
        
        logger.info(f"Report saved to: {output_path}")
        return output_path


def verify_clip(video_path: Path, task_type: str, base_dir: Path = None) -> Dict:
    """클립 검증 헬퍼 함수"""
    verifier = YOLOWorldVerifier(task_type, base_dir)
    result = verifier.verify_video(video_path)
    verifier.save_report(result)
    return result


def batch_verify(video_dir: Path, task_type: str, base_dir: Path = None) -> List[Dict]:
    """디렉토리 내 모든 영상 일괄 검증"""
    verifier = YOLOWorldVerifier(task_type, base_dir)
    results = []
    
    video_files = list(video_dir.glob("*.mp4"))
    logger.info(f"Found {len(video_files)} videos to verify")
    
    for video_path in video_files:
        try:
            result = verifier.verify_video(video_path)
            verifier.save_report(result)
            results.append(result)
        except Exception as e:
            logger.error(f"Failed to verify {video_path}: {e}")
            results.append({'video_path': str(video_path), 'error': str(e), 'is_valid': False})
    
    return results
