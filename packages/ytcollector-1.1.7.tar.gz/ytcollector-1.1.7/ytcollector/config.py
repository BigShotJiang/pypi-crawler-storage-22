# 설정 상수

USER_AGENTS = [
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
    'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:121.0) Gecko/20100101 Firefox/121.0',
    'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.2 Safari/605.1.15',
]

# 카테고리별 검색어 - SBS 콘텐츠 중심
CATEGORY_QUERIES = {
    'face': [
        "SBS 인터뷰 클립",
        "런닝맨 멤버 인터뷰",
        "SBS 뉴스 인터뷰",
        "미운우리새끼 인터뷰",
        "SBS 스페셜 인물",
        "집사부일체 인터뷰",
        "그것이알고싶다 인터뷰",
        "SBS 연예대상 소감",
    ],
    'license_plate': [
        "중고차 매물 소개",
        "자동차 세차 영상",
        "신차 출고 브이로그",
        "자동차 튜닝 작업",
        "엔카 허위매물",
        "주차장 만차",
    ],
    'tattoo': [
        "타투 시술 영상",
        "tattoo timelapse",
        "타투이스트 작업",
        "tattoo artist work",
        "문신 시술",
        "tattoo session",
    ],
    'text': [
        "SBS 런닝맨 레전드",
        "SBS 예능 쇼츠",
        "재미있는 자막 영상 쇼츠",
        "SBS 파워FM 보이는 라디오",
        "SBS 연예대상 소감",
    ],
}

CATEGORY_NAMES = {
    'face': '얼굴',
    'license_plate': '번호판',
    'tattoo': '타투',
    'text': '텍스트'
}

# 카테고리별 제외 키워드 (제목에 포함 시 스킵)
BLACKLIST_KEYWORDS = {
    'tattoo': [
        "두피 문신", "두피문신",
        "눈썹 문신", "눈썹문신",
        "입술 문신", "입술문신",
        "립타투", "립 타투",
        "헤어타투", "헤어 타투",
        "구레나룻문신", "구레나룻 문신",
        "틴트 입술",
        "반영구", "SMP"
    ],
    'face': [],
    'license_plate': [],
    'text': []
}

# YOLO 설정
YOLO_MODEL_NAME = 'yolov8s-world.pt' # YOLO-World 모델 (Open Vocabulary)
YOLO_CONFIDENCE = 0.3                # YOLO-World는 임계값을 약간 낮게 설정 가능
YOLO_PROMPTS = ["license plate"]

# 번호판 정규식 패턴 (한국 자동차 번호판 중심)
LICENSE_PLATE_PATTERNS = [
    # 1. 신형/구형 번호판 (12가 3456, 123가 4567)
    r'\d{2,3}[가-힣]{1}\d{4}',
    # 2. 지역 포함 번호판 (서울 12 가 3456)
    r'[가-힣]{2}\d{2}[가-힣]{1}\d{4}',
    # 3. 전기차/외교/임시 등 특수 패턴 대응
    r'[가-힣]{2,3}\d{4}', # (예: 외교 1234, 임시 1234)
    # 4. 결합된 텍스트에서 숫자-글자-숫자 구성 포착
    r'\d+[가-힣]+\d+',
]

# 스킵할 에러 메시지
SKIP_ERRORS = [
    "not available", "unavailable", "private", "removed",
    "deleted", "copyright", "blocked", "age", "sign in",
    "members-only", "premiere", "live event"
]
