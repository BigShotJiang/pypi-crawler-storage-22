# 설정 상수
from pathlib import Path

# 모델 경로 (패키지 내부)
MODEL_DIR = Path(__file__).parent / "models"
LICENSE_PLATE_MODEL_PATH = MODEL_DIR / "license_plate_detector.pt"

USER_AGENTS = [
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
    'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:121.0) Gecko/20100101 Firefox/121.0',
    'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.2 Safari/605.1.15',
]

# 카테고리별 검색어 - SBS 콘텐츠 중심
CATEGORY_QUERIES = {
    'face': [
        "SBS 인터뷰 클립",
        "MBC 뉴스 인터뷰",
        "tvN 유퀴즈 일반인 인터뷰",
        "JTBC 뉴스룸 초대석",
        "기자회견 현장",
        "연예대상 레드카펫 직캠",
        "길거리 인터뷰 브이로그",
        "무대인사 직캠 얼굴",
    ],
    'license_plate': [
        "SBS 드라마 자동차 추격 장면",
        "SBS 드라마 주차장 씬",
        "SBS 드라마 차량 씬",
        "SBS 드라마 운전 장면",
        "SBS 드라마 택시 장면",
        "SBS 드라마 교통사고 장면",
    ],
    'tattoo': [
        "타투 시술 영상",
        "tattoo timelapse",
        "타투이스트 작업",
        "tattoo artist work",
        "문신 시술",
        "tattoo session",
    ],
    'text': [
        "SBS 런닝맨 자막 레전드",
        "SBS 미우새 자막 모음",
        "tvN 놀라운토요일 자막",
        "JTBC 아는형님 자막 레전드",
        "MBC 나혼자산다 자막",
        "유튜버 예능 자막 편집",
        "브이로그 자막 효과",
        "먹방 자막 편집",
    ],
}

CATEGORY_NAMES = {
    'face': '얼굴',
    'license_plate': '번호판',
    'tattoo': '타투',
    'text': '텍스트'
}

# 카테고리별 제외 키워드 (제목에 포함 시 스킵)
BLACKLIST_KEYWORDS = {
    'tattoo': [
        # 반영구 화장 (Semi-permanent makeup)
        "눈썹", "입술", "두피", "헤어라인", "아이라인", "구렛나룻",
        "반영구", "영구화장", "립타투", "헤어타투", "SMP",
        "마이크로블레이딩", "microblading", "엠보", "콤보", "PMU",
        # 임시/가짜 타투
        "헤나", "henna", "스티커", "페이크", "fake", "임시", "붙이는",
        # 타투 제거
        "제거", "레이저", "지우기", "removal",
        # 도안/디자인만 (실제 시술 아님)
        "도안", "디자인", "스케치", "드로잉", "그리기",
        # 의료/미용 시술
        "유두", "유륜", "흉터", "점",
    ],
    'face': [],
    'license_plate': [],
    'text': []
}

# YOLO 설정
YOLO_CONFIDENCE = 0.5  # 오탐지 방지를 위해 신뢰도 상향

# 번호판 정규식 패턴 (한국 자동차 번호판 중심)
LICENSE_PLATE_PATTERNS = [
    # 1. 신형/구형 번호판 (12가 3456, 123가 4567)
    r'\d{2,3}[가-힣]{1}\d{4}',
    # 2. 지역 포함 번호판 (서울 12 가 3456)
    r'[가-힣]{2}\d{2}[가-힣]{1}\d{4}',
    # 3. 전기차/외교/임시 등 특수 패턴 대응
    r'[가-힣]{2,3}\d{4}', # (예: 외교 1234, 임시 1234)
    # 4. 결합된 텍스트에서 숫자-글자-숫자 구성 포착
    r'\d+[가-힣]+\d+',
]

# 스킵할 에러 메시지
SKIP_ERRORS = [
    "not available", "unavailable", "private", "removed",
    "deleted", "copyright", "blocked", "age", "sign in",
    "members-only", "premiere", "live event"
]
