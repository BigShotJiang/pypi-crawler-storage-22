"""YouTube 콘텐츠 수집기 라이브러리

외부에서 라이브러리로 사용하거나 CLI로 실행할 수 있습니다.

라이브러리 사용 예시:
    from ytcollector import YouTubeDownloader, run
    
    # 방법 1: YouTubeDownloader 직접 사용
    downloader = YouTubeDownloader(output_path="./videos")
    count = downloader.collect("face", max_videos=5)
    
    # 방법 2: run() 함수 사용 (간단한 방법)
    results = run(categories=["face", "text"], count=3)
    
CLI 사용 예시:
    ytcollector -c face -n 5
    ytc -c face text --fast
"""

from .config import CATEGORY_NAMES, CATEGORY_QUERIES, USER_AGENTS, LICENSE_PLATE_PATTERNS, LICENSE_PLATE_MODEL_PATH
from .analyzer import VideoAnalyzer, check_dependencies
from .downloader import YouTubeDownloader
from .cli import run, main as cli_main

__version__ = "1.2.5"
__all__ = [
    # 주요 클래스
    "VideoAnalyzer",
    "YouTubeDownloader",
    # 설정
    "CATEGORY_NAMES",
    "CATEGORY_QUERIES",
    "USER_AGENTS",
    "LICENSE_PLATE_PATTERNS",
    "LICENSE_PLATE_MODEL_PATH",
    # 유틸리티
    "check_dependencies",
    "run",
    "cli_main",
]
