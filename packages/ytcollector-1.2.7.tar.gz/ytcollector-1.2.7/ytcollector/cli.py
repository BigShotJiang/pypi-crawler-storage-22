#!/usr/bin/env python3
"""YouTube 콘텐츠 수집기 - CLI 모듈"""

import argparse
import os
import sys

from .config import CATEGORY_NAMES, DEFAULT_MAX_DURATION_MINS
from .downloader import YouTubeDownloader
from .analyzer import check_dependencies


def create_parser():
    """CLI 인자 파서 생성"""
    parser = argparse.ArgumentParser(
        prog='ytcollector',
        description='YouTube 콘텐츠 수집기 - 얼굴, 번호판, 타투, 텍스트 감지',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
예시:
  ytcollector -c face                    # 얼굴 카테고리 5개
  ytcollector -c face text -n 10         # 얼굴, 텍스트 각 10개
  ytcollector -c face --fast             # 고속 모드 (병렬 다운로드)
  ytcollector -c face --fast -w 5        # 5개 동시 다운로드
  ytcollector -c license_plate -d 90     # 번호판, 최대 90분
  
  # 짧은 명령어도 사용 가능
  ytc -c face -n 3
        """
    )

    parser.add_argument(
        '-c', '--categories',
        nargs='+',
        choices=['face', 'license_plate', 'tattoo', 'text'],
        default=['face'],
        help='수집할 카테고리 (기본: face)'
    )
    parser.add_argument(
        '-n', '--count',
        type=int,
        default=5,
        help='카테고리당 다운로드 수 (기본: 5)'
    )
    parser.add_argument(
        '-d', '--duration',
        type=int,
        default=DEFAULT_MAX_DURATION_MINS,
        help=f'최대 영상 길이(분) (기본: {DEFAULT_MAX_DURATION_MINS})'
    )
    parser.add_argument(
        '-o', '--output',
        type=str,
        default=".",
        help='저장 경로 (기본: 현재 폴더)'
    )
    parser.add_argument(
        '--fast',
        action='store_true',
        help='고속 모드 (병렬 다운로드, 딜레이 최소화)'
    )
    parser.add_argument(
        '-w', '--workers',
        type=int,
        default=3,
        help='병렬 다운로드 수 (기본: 3, --fast 필요)'
    )
    parser.add_argument(
        '--proxy',
        type=str,
        default=None,
        help='프록시 (예: http://proxy:8080)'
    )
    parser.add_argument(
        '-v', '--version',
        action='version',
        version='%(prog)s 1.2.5'
    )
    parser.add_argument(
        '--check-deps',
        action='store_true',
        help='의존성 확인 후 종료'
    )

    return parser


def run(
    categories=None,
    count=5,
    duration=3,
    output=None,
    fast=False,
    workers=3,
    proxy=None,
    quiet=False
):
    """
    프로그래밍 방식으로 수집기 실행
    
    Args:
        categories: 카테고리 리스트 (예: ['face', 'text'])
        count: 카테고리당 다운로드 수
        duration: 최대 영상 길이(분)
        output: 저장 경로
        fast: 고속 모드 여부
        workers: 병렬 다운로드 수
        proxy: 프록시 URL
        quiet: 조용한 모드 (출력 최소화)
        
    Returns:
        dict: 카테고리별 성공 다운로드 수
    """
    if categories is None:
        categories = ['face']
    
    if output is None:
        output = "."
    
    # 의존성 체크
    missing = check_dependencies()
    if missing and not quiet:
        print(f"⚠ 분석 기능을 위해 설치 필요: pip install {' '.join(missing)}")
    
    # 다운로더 생성
    downloader = YouTubeDownloader(
        output_path=output,
        max_duration=duration * 60,
        proxy=proxy,
        fast_mode=fast,
        workers=workers
    )
    
    results = {}
    for category in categories:
        count_success = downloader.collect(category, count)
        results[category] = count_success
    
    return results


def main(args=None):
    """CLI 메인 엔트리포인트"""
    parser = create_parser()
    parsed_args = parser.parse_args(args)

    # 의존성 확인 모드
    if parsed_args.check_deps:
        missing = check_dependencies()
        if missing:
            print("⚠ 누락된 의존성:")
            for dep in missing:
                print(f"  - {dep}")
            print(f"\n설치: pip install {' '.join(missing)}")
            sys.exit(1)
        else:
            print("✅ 모든 의존성이 설치되어 있습니다.")
            sys.exit(0)

    # 시작 메시지
    print("\n" + "=" * 60)
    print("YouTube 콘텐츠 수집기")
    print("=" * 60)
    print(f"카테고리: {', '.join([CATEGORY_NAMES[c] for c in parsed_args.categories])}")
    print(f"개수: 카테고리당 {parsed_args.count}개")
    print(f"최대길이: {parsed_args.duration}분")
    print(f"저장경로: {parsed_args.output}")
    if parsed_args.fast:
        print(f"모드: ⚡ 고속 (병렬 {parsed_args.workers}개)")
    if parsed_args.proxy:
        print(f"프록시: {parsed_args.proxy}")

    # 의존성 체크
    missing = check_dependencies()
    if missing:
        print(f"\n⚠ 분석 기능을 위해 설치 필요:")
        print(f"  pip install {' '.join(missing)}")

    # 수집 실행
    results = run(
        categories=parsed_args.categories,
        count=parsed_args.count,
        duration=parsed_args.duration,
        output=parsed_args.output,
        fast=parsed_args.fast,
        workers=parsed_args.workers,
        proxy=parsed_args.proxy
    )

    # 완료 메시지
    total = sum(results.values())
    print(f"\n{'='*60}")
    print(f"완료! 총 {total}개 저장")
    for cat, cnt in results.items():
        print(f"  - {CATEGORY_NAMES[cat]}: {cnt}개")
    print(f"{'='*60}\n")

    return 0


if __name__ == "__main__":
    sys.exit(main())
