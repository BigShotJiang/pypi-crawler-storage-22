# 설정 상수
from pathlib import Path

# 모델 경로 (패키지 내부)
MODEL_DIR = Path(__file__).parent / "models"
LICENSE_PLATE_MODEL_PATH = MODEL_DIR / "license_plate_detector.pt"

# 길이 관련 설정
CLIP_DURATION_SECS = 180       # 저장 시 트리밍 길이 (3분)
DEFAULT_MAX_DURATION_MINS = 90  # CLI 기본 최대 길이 (90분)
MAX_SEARCH_DURATION_SECS = 5400 # 검색 시 허용 최대 길이 (90분)

USER_AGENTS = [
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
    'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:121.0) Gecko/20100101 Firefox/121.0',
    'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.2 Safari/605.1.15',
]

# 카테고리별 검색어 - SBS 콘텐츠 중심
CATEGORY_QUERIES = {
    'face_broadcast_data': [
        "유퀴즈 인터뷰 클립",
        "유퀴즈 자기님 퀴즈 타임",
        "나혼산 스튜디오 풀샷",
        "연애 리얼리티 속마음 인터뷰",
        "핑계고 풀버전",
        "관찰 예능 차안 카메라",
        "아는형님 전학신청서",
        "미우새 패널 리액션",
        "보이는 라디오 풀버전",
        "라디오 초대석 4k",
        "제작발표회 포토타임 4k",
        "제작발표회 질의응답",
        "드라마 대본리딩 현장",
        "쇼케이스 기자회견",
        "예능 대기실 비하인드",
        "드라마 포스터 촬영 메이킹",
        "영화 무대인사 직캠 4k",
        "시상식 레드카펫 얼빡",
        "뉴스 앵커 클로즈업",
        "기상캐스터 예보",
        "수어 통역 영상",
],
    'license_plate': [
        "드라마 블랙박스 확인",
        "드라마 뺑소니 목격",
        "드라마 용의차량 수배",
        "드라마 미행 장면",
        "드라마 카체이싱 액션",
        "드라마 자동차 추격신",
        "드라마 교통사고 씬",
        "드라마 접촉사고 시비",
        "드라마 자동차 PPL",
        "드라마 주차장 씬",
        "드라마 차안 데이트 풀샷",
        "드라마 등교 하교 픽업",
        "드라마 카체이싱 메이킹",
        "드라마 촬영 현장 직캠"
        "Korea driving 4K",
        "Gangnam driving tour",
    ],
    'tattoo': [
        "Tattoo process -eyebrow -microblading -smp -scalp -lip -makeup",
    ],
    'text': [
        "무한도전 레전드",
        "런닝맨 게임 모음",
        "1박2일 복불복",
        "신서유기 인물퀴즈",
        "지구오락실 명장면",
        "나혼자산다 무지개 회원",
        "놀라운 토요일 받쓰",
        "라디오스타 레전드",
        "유퀴즈 온 더 블럭 토크",
        "아는형님 레전드",
        "전지적 참견 시점 먹방",
        "미운 우리 새끼 다시보기",
        "슈퍼맨이 돌아왔다 아이들",
        "복면가왕 정체 공개",
        "대탈출 하이라이트",
        "강철부대 참호격투",
        "스트릿 우먼 파이터 배틀",
        "최강야구 경기 하이라이트",
        "맛있는 녀석들 먹방",
        "도시어부 낚시 대결",
    ],
}

CATEGORY_NAMES = {
    'face': '얼굴',
    'license_plate': '번호판',
    'tattoo': '타투',
    'text': '텍스트'
}

# 카테고리별 제외 키워드 (제목에 포함 시 스킵)
BLACKLIST_KEYWORDS = {
    'tattoo': [
        # 반영구 화장 (Semi-permanent makeup)
        "눈썹", "입술", "두피", "헤어라인", "아이라인", "구렛나룻",
        "반영구", "영구화장", "립타투", "헤어타투", "SMP",
        "마이크로블레이딩", "microblading", "엠보", "콤보", "PMU",
        "eyebrow", "scalp", "lip", "makeup",
        # 임시/가짜 타투
        "헤나", "henna", "스티커", "페이크", "fake", "임시", "붙이는",
        # 타투 제거
        "제거", "레이저", "지우기", "removal",
        # 도안/디자인만 (실제 시술 아님)
        "도안", "디자인", "스케치", "드로잉", "그리기",
        # 의료/미용 시술
        "유두", "유륜", "흉터", "점",
    ],
    'face': [],
    'license_plate': [],
    'text': []
}

# YOLO 설정
YOLO_CONFIDENCE = 0.3  # 감지율 향상을 위해 낮춤
YOLO_HIGH_CONFIDENCE = 0.6  # 고신뢰도 (OCR 없이 바로 인정)

# 번호판 정규식 패턴 (한국 자동차 번호판 중심)
LICENSE_PLATE_PATTERNS = [
    # 1. 신형/구형 번호판 (12가 3456, 123가 4567)
    r'\d{2,3}[가-힣]{1}\d{4}',
    # 2. 지역 포함 번호판 (서울 12 가 3456)
    r'[가-힣]{2}\d{2}[가-힣]{1}\d{4}',
    # 3. 전기차/외교/임시 등 특수 패턴 대응
    r'[가-힣]{2,3}\d{4}', # (예: 외교 1234, 임시 1234)
    # 4. 결합된 텍스트에서 숫자-글자-숫자 구성 포착
    r'\d+[가-힣]+\d+',
]

# 스킵할 에러 메시지
SKIP_ERRORS = [
    "not available", "unavailable", "private", "removed",
    "deleted", "copyright", "blocked", "age", "sign in",
    "members-only", "premiere", "live event"
]
