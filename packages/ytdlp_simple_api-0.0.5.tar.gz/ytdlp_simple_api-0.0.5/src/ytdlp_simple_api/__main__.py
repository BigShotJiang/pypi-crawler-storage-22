from . import serve

serve()