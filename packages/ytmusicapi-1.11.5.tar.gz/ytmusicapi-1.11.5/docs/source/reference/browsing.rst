Browsing
--------

.. currentmodule:: ytmusicapi
.. automethod:: YTMusic.get_home
.. automethod:: YTMusic.get_artist
.. automethod:: YTMusic.get_artist_albums
.. automethod:: YTMusic.get_album
.. automethod:: YTMusic.get_album_browse_id
.. automethod:: YTMusic.get_user
.. automethod:: YTMusic.get_user_playlists
.. automethod:: YTMusic.get_user_videos
.. automethod:: YTMusic.get_song
.. automethod:: YTMusic.get_song_related
.. automethod:: YTMusic.get_lyrics
.. automethod:: YTMusic.get_tasteprofile
.. automethod:: YTMusic.set_tasteprofile
