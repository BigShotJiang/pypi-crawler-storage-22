Explore
--------

.. currentmodule:: ytmusicapi
.. automethod:: YTMusic.get_mood_categories
.. automethod:: YTMusic.get_mood_playlists
.. automethod:: YTMusic.get_charts
