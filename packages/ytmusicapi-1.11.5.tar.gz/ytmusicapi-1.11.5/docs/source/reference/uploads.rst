Uploads
-------

.. currentmodule:: ytmusicapi
.. automethod:: YTMusic.get_library_upload_songs
.. automethod:: YTMusic.get_library_upload_artists
.. automethod:: YTMusic.get_library_upload_albums
.. automethod:: YTMusic.get_library_upload_artist
.. automethod:: YTMusic.get_library_upload_album
.. automethod:: YTMusic.upload_song
.. automethod:: YTMusic.delete_upload_entity
