DOT_SEPARATOR_RUN = {"text": " • "}
