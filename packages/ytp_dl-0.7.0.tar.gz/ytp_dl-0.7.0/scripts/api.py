#!/usr/bin/env python3
from __future__ import annotations

import json
import os
import re
import shutil
import tempfile
import time
from threading import BoundedSemaphore, Lock

from flask import Flask, Response, jsonify, request, send_file, stream_with_context

from .downloader import (
    download_video,
    download_video_stream,
    validate_environment,
)

app = Flask(__name__)

BASE_DOWNLOAD_DIR = os.environ.get("YTPDL_JOB_BASE_DIR", "/root/ytpdl_jobs")
os.makedirs(BASE_DOWNLOAD_DIR, exist_ok=True)

MAX_CONCURRENT = int(os.environ.get("YTPDL_MAX_CONCURRENT", "1"))

# Thread-safe concurrency gate (caps actual download jobs).
_sem = BoundedSemaphore(MAX_CONCURRENT)

# Track in-flight jobs for /healthz reporting.
_in_use = 0
_in_use_lock = Lock()

# Failsafe: delete abandoned job dirs older than this many seconds.
STALE_JOB_TTL_S = int(os.environ.get("YTPDL_STALE_JOB_TTL_S", "3600"))

_ALLOWED_EXTENSIONS = {"mp3", "mp4", "best"}

_JOB_ID_RX = re.compile(r"^[A-Za-z0-9_-]{1,64}$")


def _cleanup_stale_jobs() -> None:
    now = time.time()
    try:
        for name in os.listdir(BASE_DOWNLOAD_DIR):
            p = os.path.join(BASE_DOWNLOAD_DIR, name)
            if not os.path.isdir(p):
                continue
            try:
                age = now - os.path.getmtime(p)
            except Exception:
                continue
            if age > STALE_JOB_TTL_S:
                shutil.rmtree(p, ignore_errors=True)
    except Exception:
        pass


def _safe_job_id(raw: str | None) -> str:
    s = (raw or "").strip()
    if _JOB_ID_RX.match(s):
        return s
    # fallback to timestamp-based id (stable & filesystem-safe)
    return str(int(time.time() * 1000))


def _try_acquire_job_slot() -> bool:
    global _in_use
    if not _sem.acquire(blocking=False):
        return False
    with _in_use_lock:
        _in_use += 1
    return True


def _release_job_slot() -> None:
    global _in_use
    with _in_use_lock:
        if _in_use > 0:
            _in_use -= 1
    _sem.release()


@app.route("/api/download", methods=["POST"])
def handle_download():
    """
    Backwards-compatible direct download endpoint:
      - runs yt-dlp
      - returns the file body directly
    """
    _cleanup_stale_jobs()

    if not _try_acquire_job_slot():
        return jsonify(error="Server busy, try again later"), 503

    job_dir: str | None = None
    released = False

    def _release_once() -> None:
        nonlocal released
        if not released:
            released = True
            _release_job_slot()

    try:
        data = request.get_json(force=True)
        url = (data.get("url") or "").strip()
        resolution = data.get("resolution")

        # extension is now a "mode": mp3 | mp4 | best
        extension = (data.get("extension") or "mp4").strip().lower()

        if not url:
            _release_once()
            return jsonify(error="Missing 'url'"), 400

        if extension not in _ALLOWED_EXTENSIONS:
            _release_once()
            return jsonify(
                error=f"Invalid 'extension'. Allowed: {sorted(_ALLOWED_EXTENSIONS)}"
            ), 400

        job_dir = tempfile.mkdtemp(prefix="ytpdl_", dir=BASE_DOWNLOAD_DIR)

        # yt-dlp work (guarded by semaphore)
        filename = download_video(
            url=url,
            resolution=resolution,
            extension=extension,
            out_dir=job_dir,
        )

        if not (filename and os.path.exists(filename)):
            raise RuntimeError("Download failed")

        # Release slot as soon as yt-dlp is done.
        _release_once()

        response = send_file(filename, as_attachment=True)

        # Cleanup directory after client finishes consuming the response.
        def _cleanup() -> None:
            try:
                if job_dir:
                    shutil.rmtree(job_dir, ignore_errors=True)
            except Exception:
                pass

        response.call_on_close(_cleanup)
        return response

    except RuntimeError as e:
        if job_dir:
            shutil.rmtree(job_dir, ignore_errors=True)
        _release_once()

        msg = str(e)
        if "Mullvad not logged in" in msg:
            return jsonify(error=msg), 503
        return jsonify(error=f"Download failed: {msg}"), 500

    except Exception as e:
        if job_dir:
            shutil.rmtree(job_dir, ignore_errors=True)
        _release_once()
        return jsonify(error=f"Download failed: {str(e)}"), 500


@app.route("/api/download_sse", methods=["POST"])
def handle_download_sse():
    """
    New SSE endpoint:
      - streams raw yt-dlp stdout lines in real-time (SSE)
      - stores result.json with the final file path in a stable job dir
      - releases concurrency slot immediately when yt-dlp completes
      - client fetches the final file via /api/fetch/<job_id>
    """
    _cleanup_stale_jobs()

    if not _try_acquire_job_slot():
        return jsonify(error="Server busy, try again later"), 503

    released = False

    def _release_once() -> None:
        nonlocal released
        if not released:
            released = True
            _release_job_slot()

    try:
        data = request.get_json(force=True)
        url = (data.get("url") or "").strip()
        resolution = data.get("resolution")
        extension = (data.get("extension") or "mp4").strip().lower()

        if not url:
            _release_once()
            return jsonify(error="Missing 'url'"), 400

        if extension not in _ALLOWED_EXTENSIONS:
            _release_once()
            return jsonify(
                error=f"Invalid 'extension'. Allowed: {sorted(_ALLOWED_EXTENSIONS)}"
            ), 400

        job_id = _safe_job_id(data.get("job_id"))
        job_dir = os.path.join(BASE_DOWNLOAD_DIR, job_id)
        shutil.rmtree(job_dir, ignore_errors=True)
        os.makedirs(job_dir, exist_ok=True)

        result_path = os.path.join(job_dir, "result.json")
        err_path = os.path.join(job_dir, "error.txt")

        def gen():
            file_path: str | None = None
            try:
                # optional "ready" marker
                yield f"data: [vps_ready] {job_id}\n\n"

                dl = download_video_stream(
                    url=url,
                    resolution=resolution,
                    extension=extension,
                    out_dir=job_dir,
                )

                # manually iterate so we can capture StopIteration.value (the final path)
                while True:
                    try:
                        line = next(dl)
                    except StopIteration as si:
                        file_path = si.value
                        break

                    if line:
                        yield f"data: {line}\n\n"

                if not (file_path and os.path.exists(file_path)):
                    raise RuntimeError("Download completed but output file not found")

                # Persist result for /api/fetch/<job_id>
                try:
                    with open(result_path, "w", encoding="utf-8") as f:
                        json.dump(
                            {
                                "job_id": job_id,
                                "file_path": os.path.abspath(file_path),
                                "basename": os.path.basename(file_path),
                                "created_ts": time.time(),
                            },
                            f,
                            ensure_ascii=False,
                        )
                except Exception:
                    pass

                # Release slot as soon as yt-dlp is done (do NOT hold slot for fetch transfer)
                _release_once()

                yield f"data: [vps_done] {os.path.basename(file_path)}\n\n"
                yield "data: [vps_end]\n\n"
                return

            except Exception as e:
                try:
                    with open(err_path, "w", encoding="utf-8") as f:
                        f.write(str(e))
                except Exception:
                    pass

                _release_once()
                msg = str(e)
                # keep it as a single SSE line
                yield f"data: [vps_error] {msg}\n\n"
                yield "data: [vps_end]\n\n"
                return

            finally:
                # ensure slot is released even if client disconnects mid-stream
                _release_once()

        resp = Response(stream_with_context(gen()), content_type="text/event-stream")
        resp.headers["Cache-Control"] = "no-cache"
        resp.headers["X-Accel-Buffering"] = "no"
        return resp

    except Exception as e:
        _release_once()
        return jsonify(error=f"Download failed: {str(e)}"), 500


@app.route("/api/fetch/<job_id>", methods=["GET"])
def fetch_job_file(job_id: str):
    """
    Fetch the finished file for a job_id created by /api/download_sse.
    Cleans up the job dir after response is fully consumed.
    """
    job_id = _safe_job_id(job_id)
    job_dir = os.path.join(BASE_DOWNLOAD_DIR, job_id)
    result_path = os.path.join(job_dir, "result.json")

    if not os.path.exists(result_path):
        return jsonify(error="Job not found or not complete"), 404

    try:
        with open(result_path, "r", encoding="utf-8") as f:
            meta = json.load(f)
        file_path = meta.get("file_path") or ""
    except Exception:
        return jsonify(error="Job metadata unreadable"), 500

    file_path = os.path.abspath(file_path)
    if not file_path.startswith(os.path.abspath(job_dir) + os.sep):
        return jsonify(error="Invalid job file path"), 500

    if not os.path.exists(file_path):
        return jsonify(error="Job file missing"), 404

    response = send_file(file_path, as_attachment=True)

    def _cleanup() -> None:
        try:
            shutil.rmtree(job_dir, ignore_errors=True)
        except Exception:
            pass

    response.call_on_close(_cleanup)
    return response


@app.route("/healthz", methods=["GET"])
def healthz():
    with _in_use_lock:
        in_use = _in_use
    return jsonify(ok=True, in_use=in_use, capacity=MAX_CONCURRENT), 200


def main():
    validate_environment()
    print("Starting ytp-dl API server...")
    app.run(host="0.0.0.0", port=5000)


if __name__ == "__main__":
    main()
