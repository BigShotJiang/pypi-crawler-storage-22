#!/usr/bin/env python3
from __future__ import annotations

import json
import os
import shutil
import tempfile
import time
from threading import BoundedSemaphore, Lock
from typing import Optional

from flask import Flask, request, send_file, jsonify, Response, stream_with_context

from .downloader import validate_environment, download_video, download_video_stream

app = Flask(__name__)

BASE_DOWNLOAD_DIR = os.environ.get("YTPDL_JOB_BASE_DIR", "/root/ytpdl_jobs")
os.makedirs(BASE_DOWNLOAD_DIR, exist_ok=True)

MAX_CONCURRENT = int(os.environ.get("YTPDL_MAX_CONCURRENT", "1"))

# Thread-safe concurrency gate (caps actual download jobs).
_sem = BoundedSemaphore(MAX_CONCURRENT)

# Track in-flight jobs for /healthz reporting.
_in_use = 0
_in_use_lock = Lock()

# Failsafe: delete abandoned job dirs older than this many seconds.
STALE_JOB_TTL_S = int(os.environ.get("YTPDL_STALE_JOB_TTL_S", "3600"))

_ALLOWED_EXTENSIONS = {"mp3", "mp4", "best"}


def _cleanup_stale_jobs() -> None:
    now = time.time()
    try:
        for name in os.listdir(BASE_DOWNLOAD_DIR):
            p = os.path.join(BASE_DOWNLOAD_DIR, name)
            if not os.path.isdir(p):
                continue
            try:
                age = now - os.path.getmtime(p)
            except Exception:
                continue
            if age > STALE_JOB_TTL_S:
                shutil.rmtree(p, ignore_errors=True)
    except Exception:
        pass


def _try_acquire_job_slot() -> bool:
    global _in_use
    if not _sem.acquire(blocking=False):
        return False
    with _in_use_lock:
        _in_use += 1
    return True


def _release_job_slot() -> None:
    global _in_use
    with _in_use_lock:
        if _in_use > 0:
            _in_use -= 1
    _sem.release()


def _safe_job_id(raw: str) -> str:
    s = (raw or "").strip()
    if not s:
        return str(int(time.time() * 1000))
    out = []
    for ch in s:
        if ch.isalnum() or ch in ("-", "_"):
            out.append(ch)
        else:
            out.append("_")
    return ("".join(out)[:120] or str(int(time.time() * 1000)))


def _write_result(job_dir: str, final_path: str) -> None:
    meta = {
        "path": final_path,
        "filename": os.path.basename(final_path),
        "ts": time.time(),
    }
    with open(os.path.join(job_dir, "result.json"), "w", encoding="utf-8") as f:
        json.dump(meta, f, ensure_ascii=False)


def _read_result(job_dir: str) -> Optional[dict]:
    p = os.path.join(job_dir, "result.json")
    if not os.path.exists(p):
        return None
    try:
        with open(p, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return None


@app.route("/api/download", methods=["POST"])
def handle_download():
    """
    Legacy endpoint (UNCHANGED):
    - Runs yt-dlp to completion
    - Returns the file as the HTTP response body
    """
    _cleanup_stale_jobs()

    if not _try_acquire_job_slot():
        return jsonify(error="Server busy, try again later"), 503

    job_dir: str | None = None
    released = False

    def _release_once() -> None:
        nonlocal released
        if not released:
            released = True
            _release_job_slot()

    try:
        data = request.get_json(force=True)
        url = (data.get("url") or "").strip()
        resolution = data.get("resolution")

        # extension is now a "mode": mp3 | mp4 | best
        extension = (data.get("extension") or "mp4").strip().lower()

        if not url:
            _release_once()
            return jsonify(error="Missing 'url'"), 400

        if extension not in _ALLOWED_EXTENSIONS:
            _release_once()
            return jsonify(
                error=f"Invalid 'extension'. Allowed: {sorted(_ALLOWED_EXTENSIONS)}"
            ), 400

        job_dir = tempfile.mkdtemp(prefix="ytpdl_", dir=BASE_DOWNLOAD_DIR)

        # yt-dlp work (guarded by semaphore)
        filename = download_video(
            url=url,
            resolution=resolution,
            extension=extension,
            out_dir=job_dir,
        )

        if not (filename and os.path.exists(filename)):
            raise RuntimeError("Download failed")

        # Release slot as soon as yt-dlp is done.
        _release_once()

        response = send_file(filename, as_attachment=True)

        # Cleanup directory after client finishes consuming the response.
        def _cleanup() -> None:
            try:
                if job_dir:
                    shutil.rmtree(job_dir, ignore_errors=True)
            except Exception:
                pass

        response.call_on_close(_cleanup)
        return response

    except RuntimeError as e:
        if job_dir:
            shutil.rmtree(job_dir, ignore_errors=True)
        _release_once()

        msg = str(e)
        if "Mullvad not logged in" in msg:
            return jsonify(error=msg), 503
        return jsonify(error=f"Download failed: {msg}"), 500

    except Exception as e:
        if job_dir:
            shutil.rmtree(job_dir, ignore_errors=True)
        _release_once()
        return jsonify(error=f"Download failed: {str(e)}"), 500


@app.route("/api/download_sse", methods=["POST"])
def handle_download_sse():
    """
    Stream yt-dlp logs as Server-Sent Events (SSE), then make the final file
    available via GET /api/fetch/<job_id>.

    Request JSON:
      - url (required)
      - resolution (optional, default 1080)
      - extension (optional: "mp4", "mp3", "best"; default "best")
      - job_id (required): client-chosen id used to fetch the file later
    """
    body = request.get_json(silent=True) or {}
    url = (body.get("url") or "").strip()
    ext = (body.get("extension") or "best").strip()
    res = int(body.get("resolution") or 1080)
    job_id = (body.get("job_id") or "").strip()

    if not url:
        return jsonify({"error": "Missing url"}), 400
    if ext not in ("mp4", "mp3", "best"):
        return jsonify({"error": "extension must be one of: mp4, mp3, best"}), 400
    if not job_id:
        return jsonify({"error": "Missing job_id"}), 400

    acquired = False
    try:
        _acquire_slot()
        acquired = True

        job_dir = _job_dir(job_id)
        os.makedirs(job_dir, exist_ok=True)

        result_path = os.path.join(job_dir, "result.json")

        def gen():
            # Immediately push bytes to defeat client/proxy buffering.
            yield ":" + (" " * 2048) + "\n\n"
            yield f"data: [accepted] job_id={job_id}\n\n"

            final_path: Optional[str] = None
            try:
                g = download_video_stream(
                    url=url,
                    resolution=res,
                    extension=ext,
                    out_dir=job_dir,
                )

                while True:
                    try:
                        line = next(g)
                    except StopIteration as si:
                        final_path = si.value
                        break

                    if line is None:
                        continue

                    s = str(line).replace("\r", "").rstrip("\n")
                    if not s:
                        continue
                    yield f"data: {s}\n\n"

                if not final_path:
                    raise RuntimeError("Download finished but no output path was returned")

                payload = {
                    "ok": True,
                    "job_id": job_id,
                    "path": final_path,
                    "filename": os.path.basename(final_path),
                }
                with open(result_path, "w", encoding="utf-8") as f:
                    json.dump(payload, f, ensure_ascii=False)

                yield f"data: [vps_ready] {payload['filename']}\n\n"

            except GeneratorExit:
                raise
            except Exception as e:
                payload = {
                    "ok": False,
                    "job_id": job_id,
                    "error": str(e),
                }
                try:
                    with open(result_path, "w", encoding="utf-8") as f:
                        json.dump(payload, f, ensure_ascii=False)
                except Exception:
                    pass
                yield f"data: [error] {payload['error']}\n\n"
            finally:
                _release_slot()

        resp = Response(stream_with_context(gen()), content_type="text/event-stream; charset=utf-8")
        resp.headers["Cache-Control"] = "no-cache, no-transform"
        resp.headers["Connection"] = "keep-alive"
        resp.headers["X-Accel-Buffering"] = "no"
        resp.headers["X-Content-Type-Options"] = "nosniff"
        resp.direct_passthrough = True
        return resp

    except Exception as e:
        if acquired:
            _release_slot()
        return jsonify({"error": str(e)}), 500
@app.route("/api/fetch/<job_id>", methods=["GET"])
def fetch_job(job_id: str):
    """
    NEW:
    - Returns the completed file for a prior /api/download_sse job.
    - Deletes the job dir after the client finishes consuming the response.
    """
    job_id = _safe_job_id(job_id)
    job_dir = os.path.join(BASE_DOWNLOAD_DIR, job_id)

    meta = _read_result(job_dir)
    if not meta:
        return jsonify(error="Job not found or not ready"), 404

    path = (meta.get("path") or "").strip()
    if not path:
        return jsonify(error="Job result missing path"), 500

    # Prevent path traversal: ensure file lives inside job_dir
    try:
        job_dir_abs = os.path.abspath(job_dir)
        path_abs = os.path.abspath(path)
        if os.path.commonpath([job_dir_abs, path_abs]) != job_dir_abs:
            return jsonify(error="Invalid job result path"), 500
    except Exception:
        return jsonify(error="Invalid job result path"), 500

    if not os.path.exists(path):
        return jsonify(error="File not found"), 404

    response = send_file(path, as_attachment=True)

    def _cleanup() -> None:
        try:
            shutil.rmtree(job_dir, ignore_errors=True)
        except Exception:
            pass

    response.call_on_close(_cleanup)
    return response


@app.route("/healthz", methods=["GET"])
def healthz():
    with _in_use_lock:
        in_use = _in_use
    return jsonify(ok=True, in_use=in_use, capacity=MAX_CONCURRENT), 200


def main():
    validate_environment()
    print("Starting ytp-dl API server...")
    app.run(host="0.0.0.0", port=5000)


if __name__ == "__main__":
    main()