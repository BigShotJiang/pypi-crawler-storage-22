# ytp-dl

A lightweight YouTube downloader with Mullvad VPN integration and an HTTP API.

[![PyPI version](https://img.shields.io/pypi/v/ytp-dl.svg)](https://pypi.org/project/ytp-dl/)
[![Python Support](https://img.shields.io/pypi/pyversions/ytp-dl.svg)](https://pypi.org/project/ytp-dl/)
[![License](https://img.shields.io/pypi/l/ytp-dl.svg)](https://pypi.org/project/ytp-dl/)
[![Downloads](https://img.shields.io/pypi/dm/ytp-dl.svg)](https://pypi.org/project/ytp-dl/)

**ytp-dl** is a privacy-focused YouTube downloader that routes downloads through Mullvad VPN via an HTTP API.

---

## Features

* Privacy-first: connect/disconnect Mullvad per download
* Smart quality selection: prefers 1080p H.264 + AAC (no transcoding)
* Audio downloads: extract audio as MP3
* HTTP API: simple Flask API with concurrency controls
* Stable public API under VPN cycling: exclude the API port from the tunnel (nftables marks) + policy routing
* VPS-ready: automated installer script for Ubuntu

---

## Installation

```bash
pip install ytp-dl==0.8.7 yt-dlp[default]
```

Requirements:

* Linux (tested on Ubuntu 24.04/25.04)
* Mullvad CLI installed and configured
* FFmpeg (audio/video handling)
* Deno (system-wide; required by yt-dlp for modern YouTube extraction)
* Python 3.8+

Notes:

* yt-dlp expects **Deno** to be available on `PATH` to run its JavaScript-based extraction logic.

---

## Using your VPS

Once your VPS is running, you can download videos using simple HTTP requests.

### Download a video (1080p MP4)

```bash
curl -X POST http://YOUR_VPS_IP:5000/api/download \
  -H "Content-Type: application/json" \
  -d '{"url": "https://www.youtube.com/watch?v=dQw4w9WgXcQ"}' \
  --output video.mp4
```

### Download audio only (MP3)

```bash
curl -X POST http://YOUR_VPS_IP:5000/api/download \
  -H "Content-Type: application/json" \
  -d '{"url": "https://www.youtube.com/watch?v=dQw4w9WgXcQ", "extension": "mp3"}' \
  --output audio.mp3
```

### Download at a specific resolution

```bash
curl -X POST http://YOUR_VPS_IP:5000/api/download \
  -H "Content-Type: application/json" \
  -d '{"url": "https://www.youtube.com/watch?v=dQw4w9WgXcQ", "resolution": 720}' \
  --output video.mp4
```

### Check server health

```bash
curl http://YOUR_VPS_IP:5000/healthz
```

Response example:

```json
{
  "ok": true,
  "in_use": 1,
  "capacity": 1
}
```


### Stream test output (SSE)

This is mainly for debugging the “API stays reachable during VPN cycling” fix. It streams text events while the download is running, including a small heartbeat line every couple seconds.

```bash
curl -N --http1.1 -H "Accept: text/event-stream" -H "Content-Type: application/json" \
  -X POST http://YOUR_VPS_IP:5000/api/download_sse \
  -d '{"url":"https://www.youtube.com/watch?v=dQw4w9WgXcQ","extension":"mp4","resolution":1080,"job_id":"test123"}'
```

When it finishes, fetch the file:

```bash
curl -L http://YOUR_VPS_IP:5000/api/fetch/test123 --output video.mp4
```

### Using from Python

```python
import requests

response = requests.post(
    "http://YOUR_VPS_IP:5000/api/download",
    json={
        "url": "https://www.youtube.com/watch?v=dQw4w9WgXcQ",
        "resolution": 1080,
        "extension": "mp4"
    },
    stream=True,
)

if response.status_code == 200:
    with open("video.mp4", "wb") as f:
        for chunk in response.iter_content(chunk_size=8192):
            f.write(chunk)
elif response.status_code == 503:
    print("Server busy, try again later")
else:
    print(f"Error: {response.json()}")
```

---

## Configuration

### Installation script variables

These environment variables configure the VPS installation (you can override them when running the script).

| Variable                 | Description                             | Default               |
| ------------------------ | --------------------------------------- | --------------------- |
| `PORT`                   | API server port                         | `5000`                |
| `APP_DIR`                | Installation directory                  | `/opt/yt-dlp-mullvad` |
| `MV_ACCOUNT`             | Mullvad account number                  | (empty)               |
| `YTPDL_MAX_CONCURRENT`   | Max simultaneous downloads (API cap)    | `1`                   |
| `YTPDL_MULLVAD_LOCATION` | Mullvad relay location code (e.g. `us`) | `us`                  |
| `GUNICORN_THREADS`       | Threads per Gunicorn worker             | `4`                   |

Notes:

* If `MV_ACCOUNT` is set, the installer attempts `mullvad account login <MV_ACCOUNT>` once.
* If `MV_ACCOUNT` is left empty, the script skips login and assumes Mullvad is already configured.

### Runtime environment variables

After installation, these are set in `/etc/default/ytp-dl-api` and can be edited manually.

| Variable                 | Description                   | Default                    |
| ------------------------ | ----------------------------- | -------------------------- |
| `YTPDL_MAX_CONCURRENT`   | Maximum concurrent downloads  | `1`                        |
| `YTPDL_MULLVAD_LOCATION` | Mullvad relay location code   | `us`                       |
| `YTPDL_VENV`             | Path to virtualenv for ytp-dl | `/opt/yt-dlp-mullvad/venv` |

To change configuration after installation:

```bash
sudo nano /etc/default/ytp-dl-api
sudo systemctl restart ytp-dl-api
```

---

## Managing your VPS service

```bash
sudo systemctl status ytp-dl-api
sudo journalctl -u ytp-dl-api -f
sudo systemctl restart ytp-dl-api
sudo systemctl stop ytp-dl-api
sudo systemctl start ytp-dl-api
```

---

## API reference

### POST `/api/download`

Request body:

```json
{
  "url": "string (required)",
  "resolution": "integer (optional, default: 1080)",
  "extension": "string (optional, 'mp4', 'mp3', or 'best')"
}
```

Response:

* `200 OK` - File download stream
* `400 Bad Request` - Missing or invalid URL
* `500 Internal Server Error` - Download failed
* `503 Service Unavailable` - Server busy (max concurrent downloads reached)

### GET `/healthz`

```json
{
  "ok": true,
  "in_use": 1,
  "capacity": 1
}
```

---

## VPS deployment

### Why policy routing is included

When Mullvad connects/disconnects, Linux routing can change in a way that breaks inbound TCP handshakes (clients see intermittent connection timeouts). The installer sets up a small policy-routing rule that forces replies sourced from your public VPS IP to use the public interface, keeping the API reachable even while Mullvad is cycling.

### What the installer does

* Installs Python, FFmpeg, Mullvad CLI, and Deno
* Creates a virtualenv at `/opt/yt-dlp-mullvad/venv`
* Installs `ytp-dl==0.8.7` + `yt-dlp[default]` + `gunicorn`
* Installs a policy-routing oneshot service to keep the public API reachable
* Sets up a systemd service on port 5000
* Runs Gunicorn with `gthread` (threaded) workers

Note: `gthread` is a built-in Gunicorn worker class (no extra Python dependency).

```bash
#!/usr/bin/env bash
# VPS_Installation.sh - Minimal Ubuntu 24.04/25.04 setup for ytp-dl API + Mullvad
#
# What this does:
#   - Installs Python, ffmpeg, Mullvad CLI
#   - Installs Deno system-wide (JS runtime required for modern YouTube extraction via yt-dlp)
#   - Configures policy routing so the public API stays reachable while Mullvad toggles
#   - Adds Mullvad excluded-port rules (nftables marks) so :PORT stays reachable under VPN
#   - Creates a virtualenv at /opt/yt-dlp-mullvad/venv
#   - Installs ytp-dl==0.8.7 + yt-dlp[default] + gunicorn in that venv
#   - Creates a systemd service ytp-dl-api.service on port 5000
#
# Mullvad connect/disconnect is handled per-job by downloader.py.

set -euo pipefail

### --- Tunables -------------------------------------------------------------
PORT="${PORT:-5000}"                           # API listen port
APP_DIR="${APP_DIR:-/opt/yt-dlp-mullvad}"      # app/venv root
VENV_DIR="${VENV_DIR:-${APP_DIR}/venv}"        # python venv

MV_ACCOUNT="${MV_ACCOUNT:-}"                   # Mullvad account (optional)
YTPDL_MAX_CONCURRENT="${YTPDL_MAX_CONCURRENT:-1}"        # API concurrency cap
YTPDL_MULLVAD_LOCATION="${YTPDL_MULLVAD_LOCATION:-us}"   # default Mullvad relay hint
GUNICORN_THREADS="${GUNICORN_THREADS:-4}"               # keep API responsive on small VPS
### -------------------------------------------------------------------------

[[ "${EUID}" -eq 0 ]] || { echo "Please run as root"; exit 1; }
export DEBIAN_FRONTEND=noninteractive

echo "==> 0) Capture public routing (pre-VPN)"
PUB_DEV="$(ip route show default | awk '/default/ {print $5; exit}')"
PUB_GW="$(ip route show default | awk '/default/ {print $3; exit}')"
PUB_IP="$(ip -4 addr show dev "${PUB_DEV}" | awk '/inet / {print $2}' | cut -d/ -f1 | head -n1)"

if [[ -z "${PUB_DEV}" || -z "${PUB_GW}" || -z "${PUB_IP}" ]]; then
  echo "Failed to detect public routing (PUB_DEV/PUB_GW/PUB_IP)."
  echo "PUB_DEV=${PUB_DEV} PUB_GW=${PUB_GW} PUB_IP=${PUB_IP}"
  exit 1
fi

echo "Public dev: ${PUB_DEV} | gw: ${PUB_GW} | ip: ${PUB_IP}"

echo "==> 1) Base packages & Mullvad CLI"
apt-get update
apt-get install -yq --no-install-recommends \
  python3-venv python3-pip curl ffmpeg ca-certificates unzip \
  iproute2 iptables nftables

if ! command -v mullvad >/dev/null 2>&1; then
  curl -fsSLo /tmp/mullvad.deb https://mullvad.net/download/app/deb/latest/
  apt-get install -y /tmp/mullvad.deb
fi

if [[ -n "${MV_ACCOUNT}" ]]; then
  echo "Logging into Mullvad account (if not already logged in)..."
  mullvad account login "${MV_ACCOUNT}" || true
fi

mullvad status || true

# Keep the public API reachable even if Mullvad disconnects between jobs.
# (Lockdown mode can block all traffic while disconnected.)
mullvad lockdown-mode set off || true
mullvad lan set allow || true

echo "==> 1.1) Policy routing: keep replies from ${PUB_IP} on ${PUB_DEV}"
# Loose reverse-path filtering avoids drops when the default route changes under VPN.
tee /etc/sysctl.d/99-ytpdl-policy-routing.conf >/dev/null <<EOF
net.ipv4.conf.all.rp_filter=2
net.ipv4.conf.default.rp_filter=2
net.ipv4.conf.${PUB_DEV}.rp_filter=2
EOF
sysctl --system >/dev/null

# Persist the detected public route info for re-apply at boot.
tee /etc/default/ytpdl-policy-routing >/dev/null <<EOF
PUB_DEV=${PUB_DEV}
PUB_GW=${PUB_GW}
PUB_IP=${PUB_IP}
EOF

# Add a routing table id if it doesn't already exist.
grep -qE '^100\s+ytpdl-public$' /etc/iproute2/rt_tables || echo '100 ytpdl-public' >> /etc/iproute2/rt_tables

# Idempotent apply script.
tee /usr/local/sbin/ytpdl-policy-routing.sh >/dev/null <<'EOF'
#!/usr/bin/env bash
set -euo pipefail

source /etc/default/ytpdl-policy-routing

TABLE_ID="100"
TABLE_NAME="ytpdl-public"
PRIO="11000"

# Ensure table has the public default route.
ip route replace default via "${PUB_GW}" dev "${PUB_DEV}" table "${TABLE_NAME}"

# Ensure rule exists (replace is not supported for rules).
if ip rule show | grep -qE "^${PRIO}:.*from ${PUB_IP}/32 lookup ${TABLE_NAME}\b"; then
  :
else
  # remove any stale rule at this priority
  while ip rule show | grep -qE "^${PRIO}:"; do
    ip rule del priority "${PRIO}" || true
  done
  ip rule add priority "${PRIO}" from "${PUB_IP}/32" table "${TABLE_NAME}"
fi

ip route flush cache || true
EOF
chmod +x /usr/local/sbin/ytpdl-policy-routing.sh

tee /etc/systemd/system/ytpdl-policy-routing.service >/dev/null <<EOF
[Unit]
Description=ytp-dl policy routing (keep public API reachable)
After=network-online.target
Wants=network-online.target

[Service]
Type=oneshot
ExecStart=/usr/local/sbin/ytpdl-policy-routing.sh
RemainAfterExit=yes

[Install]
WantedBy=multi-user.target
EOF

systemctl daemon-reload
systemctl enable --now ytpdl-policy-routing.service

echo "==> 1.2) Mullvad exclude rules: keep :${PORT} reachable during VPN"
# Uses Mullvad-documented nftables marks (advanced split tunneling).
EXCLUDE_NFT="/etc/ytpdl-mullvad-exclude-ports.nft"
tee "${EXCLUDE_NFT}" >/dev/null <<EOF
table inet ytpdl_mullvad_exclusions {
  chain allowIncoming {
    type filter hook input priority -100; policy accept;
    tcp dport ${PORT} ct mark set 0x00000f41 meta mark set 0x6d6f6c65
    udp dport ${PORT} ct mark set 0x00000f41 meta mark set 0x6d6f6c65
  }

  chain allowOutgoing {
    type route hook output priority -100; policy accept;
    tcp sport ${PORT} ct mark set 0x00000f41 meta mark set 0x6d6f6c65
    udp sport ${PORT} ct mark set 0x00000f41 meta mark set 0x6d6f6c65
  }
}
EOF

# Apply now (idempotent: it replaces/overwrites the table)
nft -f "${EXCLUDE_NFT}"

tee /etc/systemd/system/ytpdl-mullvad-exclude-ports.service >/dev/null <<EOF
[Unit]
Description=ytp-dl Mullvad excluded ports (nftables)
After=network-online.target
Wants=network-online.target

[Service]
Type=oneshot
ExecStart=/usr/sbin/nft -f ${EXCLUDE_NFT}
RemainAfterExit=yes

[Install]
WantedBy=multi-user.target
EOF

systemctl daemon-reload
systemctl enable --now ytpdl-mullvad-exclude-ports.service


echo "==> 1.5) Install Deno (system-wide, for yt-dlp YouTube extraction)"
# Install into /usr/local/bin/deno so systemd PATH can see it.
# Official installer supports system-wide install via DENO_INSTALL=/usr/local.
if ! command -v deno >/dev/null 2>&1; then
  curl -fsSL https://deno.land/install.sh | DENO_INSTALL=/usr/local sh
fi
deno --version

echo "==> 2) App dir & virtualenv"
mkdir -p "${APP_DIR}"
python3 -m venv "${VENV_DIR}"
source "${VENV_DIR}/bin/activate"
pip install --upgrade pip
pip install "ytp-dl==0.8.7" "yt-dlp[default]" gunicorn
deactivate

echo "==> 3) API environment file (/etc/default/ytp-dl-api)"
tee /etc/default/ytp-dl-api >/dev/null <<EOF
YTPDL_MAX_CONCURRENT=${YTPDL_MAX_CONCURRENT}
YTPDL_MULLVAD_LOCATION=${YTPDL_MULLVAD_LOCATION}
YTPDL_VENV=${VENV_DIR}
EOF

echo "==> 4) Gunicorn systemd service (ytp-dl-api.service on :${PORT})"
tee /etc/systemd/system/ytp-dl-api.service >/dev/null <<EOF
[Unit]
Description=Gunicorn for ytp-dl Mullvad API (minimal)
After=network-online.target ytpdl-policy-routing.service ytpdl-mullvad-exclude-ports.service
Wants=network-online.target
Requires=ytpdl-policy-routing.service ytpdl-mullvad-exclude-ports.service

[Service]
User=root
WorkingDirectory=${APP_DIR}
EnvironmentFile=/etc/default/ytp-dl-api
Environment=VIRTUAL_ENV=${VENV_DIR}
Environment=PATH=${VENV_DIR}/bin:/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin

ExecStart=${VENV_DIR}/bin/gunicorn -k gthread -w 1 --threads ${GUNICORN_THREADS} \
  --timeout 0 --graceful-timeout 15 --keep-alive 20 \
  --bind 0.0.0.0:${PORT} scripts.api:app

Restart=always
RestartSec=3
LimitNOFILE=65535
MemoryMax=800M

[Install]
WantedBy=multi-user.target
EOF

echo "==> 5) Start and enable API service"
systemctl daemon-reload
systemctl enable --now ytp-dl-api.service

echo "==> 6) Quick status + health check"
systemctl status ytp-dl-api --no-pager || true

echo
echo "Waiting for API to start..."
sleep 3
echo "Health (local):"
curl -sS "http://127.0.0.1:${PORT}/healthz" || true

echo
echo "========================================="
echo "Installation complete!"
echo "API running on port ${PORT}"
echo "Test from outside: curl http://YOUR_VPS_IP:${PORT}/healthz"
echo "If you use UFW: sudo ufw allow ${PORT}/tcp"
echo "========================================="
```
