from setuptools import setup, find_packages

setup(
    name="yu_agent",
    version="0.1.0",
    packages=find_packages(),
    install_requires=[
        "google_search_results==2.4.2",
        "openai==2.18.0",
        "pydantic==2.12.5",
        "serpapi==0.1.5",
        "tavily==1.1.0",
        "tavily_python==0.7.19"
    ],
    author="Zhuoyang Wu",
    description="学习阶段的agent框架实现,主体是helloagents中的大致框架,后续会逐步完善",
    license="MIT",
    url="https://github.com/xiaoyu-ops/agent",
    python_requires='>=3.10',
)