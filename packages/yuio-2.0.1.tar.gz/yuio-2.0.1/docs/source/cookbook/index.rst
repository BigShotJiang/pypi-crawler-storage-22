Cook Book
=========

Recipes for achieving common tasks with Yuio.

.. tip::

    This section is under construction;
    please, add your questions or requests to `GitHub issues`__!

    __ https://github.com/taminomara/yuio/issues

.. nice-toc::

    print_to_file
        Printing formatted text to file or terminal while respecting terminal width
        or other settings.

    generate_schema
        Generate Json schema for configs when rendering documentation.

    custom_tasks
        Implementing tasks with custom widget.
