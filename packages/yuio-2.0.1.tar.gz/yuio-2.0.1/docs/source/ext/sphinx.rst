Sphinx extension
================

.. automodule:: yuio.ext.sphinx
