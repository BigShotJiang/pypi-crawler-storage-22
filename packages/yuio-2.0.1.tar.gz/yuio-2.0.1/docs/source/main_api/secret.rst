Secret data
===========

.. automodule:: yuio.secret
