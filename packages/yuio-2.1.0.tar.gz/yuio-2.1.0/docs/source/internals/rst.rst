Rst
===

.. automodule:: yuio.rst
