String
======

.. automodule:: yuio.string
