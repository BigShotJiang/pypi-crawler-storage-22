"""Document API endpoints."""

from __future__ import annotations

from typing import Any

from ..models import PaginatedResponse
from .base import BaseAPI


class DocAPI(BaseAPI):
    """API endpoints for document operations."""

    def get(self, doc_id: int) -> dict[str, Any]:
        """Get a document by ID."""
        response = self._request("GET", f"/api/v2/repos/docs/{doc_id}")
        return response["data"]

    def get_by_repo(self, book_id: int, offset: int = 0, limit: int = 100) -> PaginatedResponse:
        """Get documents in a repository."""
        response = self._request(
            "GET",
            f"/api/v2/repos/{book_id}/docs",
            params={"offset": offset, "limit": limit},
        )
        return self._parse_paginated_response(response)

    def get_by_path(
        self, group_login: str, book_slug: str, offset: int = 0, limit: int = 100
    ) -> PaginatedResponse:
        """Get documents by group path and book slug."""
        response = self._request(
            "GET",
            f"/api/v2/repos/{group_login}/{book_slug}/docs",
            params={"offset": offset, "limit": limit},
        )
        return self._parse_paginated_response(response)

    def create(
        self,
        book_id: int,
        title: str = "无标题",
        slug: str | None = None,
        body: str | None = None,
        format: str = "markdown",
        public: int = 0,
    ) -> dict[str, Any]:
        """Create a new document."""
        response = self._request(
            "POST",
            f"/api/v2/repos/{book_id}/docs",
            json_data={
                "title": title,
                "slug": slug,
                "body": body,
                "format": format,
                "public": public,
            },
        )
        return response["data"]

    def create_by_path(
        self,
        group_login: str,
        book_slug: str,
        title: str = "无标题",
        slug: str | None = None,
        body: str | None = None,
        format: str = "markdown",
        public: int = 0,
    ) -> dict[str, Any]:
        """Create a new document by group path and book slug."""
        response = self._request(
            "POST",
            f"/api/v2/repos/{group_login}/{book_slug}/docs",
            json_data={
                "title": title,
                "slug": slug,
                "body": body,
                "format": format,
                "public": public,
            },
        )
        return response["data"]

    def update(
        self,
        doc_id: int,
        title: str | None = None,
        slug: str | None = None,
        body: str | None = None,
        format: str = "markdown",
        public: int = 0,
    ) -> dict[str, Any]:
        """Update an existing document."""
        response = self._request(
            "PUT",
            f"/api/v2/repos/docs/{doc_id}",
            json_data={
                "title": title,
                "slug": slug,
                "body": body,
                "format": format,
                "public": public,
            },
        )
        return response["data"]

    def update_by_repo(
        self,
        book_id: int,
        doc_id: int,
        title: str | None = None,
        slug: str | None = None,
        body: str | None = None,
        format: str = "markdown",
        public: int = 0,
    ) -> dict[str, Any]:
        """Update a document in a repository."""
        response = self._request(
            "PUT",
            f"/api/v2/repos/{book_id}/docs/{doc_id}",
            json_data={
                "title": title,
                "slug": slug,
                "body": body,
                "format": format,
                "public": public,
            },
        )
        return response["data"]

    def delete(self, doc_id: int) -> dict[str, Any]:
        """Delete a document."""
        response = self._request("DELETE", f"/api/v2/repos/docs/{doc_id}")
        return response.get("data", {})

    def get_version(self, version_id: int) -> dict[str, Any]:
        """Get a document version."""
        response = self._request("GET", f"/api/v2/doc_versions/{version_id}")
        return response["data"]
