"""Group API endpoints."""

from __future__ import annotations

from typing import Any

from ..models import PaginatedResponse
from .base import BaseAPI


class GroupAPI(BaseAPI):
    """API endpoints for group operations."""

    def get(self, login: str) -> dict[str, Any]:
        """Get a group by login name."""
        response = self._request("GET", f"/api/v2/groups/{login}")
        return response["data"]

    def get_repos(self, login: str, offset: int = 0, limit: int = 100) -> PaginatedResponse:
        """Get repositories in a group."""
        response = self._request(
            "GET", f"/api/v2/groups/{login}/repos", params={"offset": offset, "limit": limit}
        )
        return self._parse_paginated_response(response)

    def get_members(self, login: str, offset: int = 0, limit: int = 100) -> PaginatedResponse:
        """Get members of a group."""
        response = self._request(
            "GET", f"/api/v2/groups/{login}/users", params={"offset": offset, "limit": limit}
        )
        return self._parse_paginated_response(response)

    def add_member(self, login: str, user_id: int, role: int = 1) -> dict[str, Any]:
        """Add a member to a group."""
        response = self._request(
            "POST",
            f"/api/v2/groups/{login}/users",
            json_data={"user_id": user_id, "role": role},
        )
        return response.get("data", {})

    def update_member(self, login: str, user_id: int, role: int) -> dict[str, Any]:
        """Update a member's role in a group."""
        response = self._request(
            "PUT",
            f"/api/v2/groups/{login}/users/{user_id}",
            json_data={"role": role},
        )
        return response.get("data", {})

    def remove_member(self, login: str, user_id: int) -> dict[str, Any]:
        """Remove a member from a group."""
        response = self._request("DELETE", f"/api/v2/groups/{login}/users/{user_id}")
        return response.get("data", {})

    def get_statistics(self, login: str) -> dict[str, Any]:
        """Get group statistics."""
        response = self._request("GET", f"/api/v2/groups/{login}/statistics")
        return response["data"]
