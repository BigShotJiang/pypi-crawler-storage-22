"""Repository (Book) API endpoints."""

from __future__ import annotations

from typing import Any

from ..models import PaginatedResponse
from .base import BaseAPI


class RepoAPI(BaseAPI):
    """API endpoints for repository (knowledge base) operations."""

    def get(self, book_id: int) -> dict[str, Any]:
        """Get a repository by ID."""
        response = self._request("GET", f"/api/v2/repos/{book_id}")
        return response["data"]

    def get_by_path(self, group_login: str, book_slug: str) -> dict[str, Any]:
        """Get a repository by group path and book slug."""
        response = self._request("GET", f"/api/v2/repos/{group_login}/{book_slug}")
        return response["data"]

    def list(self, offset: int = 0, limit: int = 100) -> PaginatedResponse:
        """List repositories for the authenticated user."""
        response = self._request("GET", "/api/v2/repos", params={"offset": offset, "limit": limit})
        return self._parse_paginated_response(response)

    def get_user_repos(self, login: str, offset: int = 0, limit: int = 100) -> PaginatedResponse:
        """Get repositories for a specific user."""
        response = self._request(
            "GET", f"/api/v2/users/{login}/repos", params={"offset": offset, "limit": limit}
        )
        return self._parse_paginated_response(response)

    def get_group_repos(self, login: str, offset: int = 0, limit: int = 100) -> PaginatedResponse:
        """Get repositories in a group."""
        response = self._request(
            "GET", f"/api/v2/groups/{login}/repos", params={"offset": offset, "limit": limit}
        )
        return self._parse_paginated_response(response)

    def get_toc(self, book_id: int) -> list[dict[str, Any]]:
        """Get table of contents for a repository."""
        response = self._request("GET", f"/api/v2/repos/{book_id}/toc")
        return response.get("data", [])

    def get_toc_by_path(self, group_login: str, book_slug: str) -> list[dict[str, Any]]:
        """Get table of contents by group path and book slug."""
        response = self._request("GET", f"/api/v2/repos/{group_login}/{book_slug}/toc")
        return response.get("data", [])
