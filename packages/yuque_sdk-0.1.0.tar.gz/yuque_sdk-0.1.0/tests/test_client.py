"""Tests for Yuque API client."""

import pytest
from unittest.mock import MagicMock, patch

from yuque.client import YuqueClient
from yuque.exceptions import (
    AuthenticationError,
    InvalidArgumentError,
    NotFoundError,
    PermissionDeniedError,
    RateLimitError,
    ServerError,
    YuqueError,
)


class TestYuqueClient:
    """Tests for YuqueClient class."""

    def test_init(self):
        """Test client initialization."""
        client = YuqueClient(token="test-token")
        assert client._token == "test-token"
        assert client._timeout == 30.0
        assert client._max_retries == 3

    def test_init_custom_timeout(self):
        """Test client initialization with custom timeout."""
        client = YuqueClient(token="test-token", timeout=60.0)
        assert client._timeout == 60.0

    def test_init_custom_retries(self):
        """Test client initialization with custom retries."""
        client = YuqueClient(token="test-token", max_retries=5)
        assert client._max_retries == 5

    def test_get_headers(self):
        """Test header generation."""
        client = YuqueClient(token="test-token")
        headers = client._get_headers()
        assert headers["X-Auth-Token"] == "test-token"
        assert headers["Content-Type"] == "application/json"
        assert headers["Accept"] == "application/json"


class TestExceptionMapping:
    """Tests for exception mapping based on status codes."""

    def test_authentication_error(self):
        """Test 401 error mapping."""
        error = AuthenticationError()
        assert error.status_code == 401

    def test_permission_denied_error(self):
        """Test 403 error mapping."""
        error = PermissionDeniedError()
        assert error.status_code == 403

    def test_not_found_error(self):
        """Test 404 error mapping."""
        error = NotFoundError()
        assert error.status_code == 404

    def test_invalid_argument_error(self):
        """Test 400 error mapping."""
        error = InvalidArgumentError()
        assert error.status_code == 400

    def test_rate_limit_error(self):
        """Test 429 error mapping."""
        error = RateLimitError()
        assert error.status_code == 429

    def test_server_error(self):
        """Test 500+ error mapping."""
        error = ServerError(status_code=500)
        assert error.status_code == 500


class TestContextManager:
    """Tests for context manager usage."""

    def test_sync_context_manager(self):
        """Test synchronous context manager."""
        with YuqueClient(token="test-token") as client:
            assert client._sync_client is not None

    def test_async_context_manager(self):
        """Test asynchronous context manager."""
        import asyncio

        async def test_async():
            async with YuqueClient(token="test-token") as client:
                assert client._async_client is not None

        asyncio.run(test_async())


class TestAPIAccess:
    """Tests for API endpoint access."""

    def test_user_api_access(self):
        """Test user API property."""
        client = YuqueClient(token="test-token")
        assert hasattr(client, "user")
        assert client.user.__class__.__name__ == "UserAPI"

    def test_group_api_access(self):
        """Test group API property."""
        client = YuqueClient(token="test-token")
        assert hasattr(client, "group")
        assert client.group.__class__.__name__ == "GroupAPI"

    def test_repo_api_access(self):
        """Test repo API property."""
        client = YuqueClient(token="test-token")
        assert hasattr(client, "repo")
        assert client.repo.__class__.__name__ == "RepoAPI"

    def test_doc_api_access(self):
        """Test doc API property."""
        client = YuqueClient(token="test-token")
        assert hasattr(client, "doc")
        assert client.doc.__class__.__name__ == "DocAPI"

    def test_search_api_access(self):
        """Test search API property."""
        client = YuqueClient(token="test-token")
        assert hasattr(client, "search")
        assert client.search.__class__.__name__ == "SearchAPI"


class TestModels:
    """Tests for Pydantic models."""

    def test_user_model(self):
        """Test User model creation."""
        from yuque.models import User

        user_data = {
            "id": 123,
            "login": "testuser",
            "name": "Test User",
            "avatar_url": "https://example.com/avatar.png",
        }
        user = User(**user_data)
        assert user.id == 123
        assert user.login == "testuser"
        assert user.name == "Test User"

    def test_group_model(self):
        """Test Group model creation."""
        from yuque.models import Group

        group_data = {
            "id": 456,
            "login": "testgroup",
            "name": "Test Group",
            "description": "A test group",
            "owner_id": 123,  # Required field
        }
        group = Group(**group_data)
        assert group.id == 456
        assert group.login == "testgroup"

    def test_repository_model(self):
        """Test Repository model creation."""
        from yuque.models import Repository

        repo_data = {
            "id": 789,
            "type": "Book",
            "slug": "test-repo",
            "name": "Test Repository",
            "public": 0,
            "creator_id": 123,  # Required field
        }
        repo = Repository(**repo_data)
        assert repo.id == 789
        assert repo.slug == "test-repo"

    def test_document_model(self):
        """Test Document model creation."""
        from yuque.models import Document

        doc_data = {
            "id": 111,
            "slug": "test-doc",
            "title": "Test Document",
            "body": "# Hello World",
            "body_format": 1,
            "user_id": 123,
            "book_id": 789,
            "creator_id": 123,  # Required field
        }
        doc = Document(**doc_data)
        assert doc.id == 111
        assert doc.title == "Test Document"


class TestPaginationMeta:
    """Tests for pagination metadata."""

    def test_pagination_meta_creation(self):
        """Test PaginationMeta model."""
        from yuque.models import PaginationMeta

        meta = PaginationMeta(page=1, per_page=20, total=100, total_pages=5)
        assert meta.page == 1
        assert meta.per_page == 20
        assert meta.total == 100
        assert meta.total_pages == 5


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
