from yuque.client import YuqueClient
import json

client = YuqueClient(token="XLt4lWhVmd7qO9T5BXsQdjqSL7zVTlGkrXTLcA4z")

user = client.user.get_me()
print(f"用户名: {user.name}")
print(f"登录名: {user.login}")
print(f"邮箱: {user.email}")
docs = client.doc.get_by_path(group_login="otv8ou", book_slug="project_doc")
# print(json.dumps(docs.data))
# print()
# for doc in docs.data:
#     if doc["public"] != "0":
#         print(client.doc.get(doc_id=doc["id"])['body'])
#         break


tocs = client.repo.get_toc_by_path(group_login="otv8ou", book_slug="project_doc")
print(json.dumps(tocs))
