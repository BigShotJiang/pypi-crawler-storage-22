"""Test Document API endpoints."""

import pytest
from datetime import datetime

from yuque import YuqueClient
from conftest import get_config


config = get_config()
API_TOKEN = config.api_token
TEST_GROUP_LOGIN = config.test_group_login
TEST_BOOK_SLUG = config.test_book_slug
TEST_BOOK_ID = config.test_book_id


class TestDocAPI:
    """Test Document API endpoints."""

    @pytest.fixture(autouse=True)
    def setup(self):
        """Setup test client."""
        self.client = YuqueClient(token=API_TOKEN)
        self.test_group_login = TEST_GROUP_LOGIN
        self.test_book_slug = TEST_BOOK_SLUG
        self.test_book_id = TEST_BOOK_ID
        yield

    def test_get_documents_by_repo(self):
        """Test getting documents in a repository."""
        print("\n" + "=" * 60)
        print("Test: Get Documents By Repository")
        print("=" * 60)

        docs = self.client.doc.get_by_repo(book_id=self.test_book_id)

        assert docs is not None
        assert hasattr(docs, "data")
        assert isinstance(docs.data, list)

        print(f"文档数量: {len(docs.data)}")
        print(f"分页信息: offset=0, limit=100")

        for doc in docs.data[:5]:
            print(f"  - {doc.get('title')} (ID: {doc.get('id')})")

        if len(docs.data) > 5:
            print(f"  ... 还有 {len(docs.data) - 5} 个文档")

        print("✓ 测试通过: 获取仓库文档列表成功")

    def test_get_documents_by_path(self):
        """Test getting documents by group path and book slug."""
        print("\n" + "=" * 60)
        print("Test: Get Documents By Path")
        print("=" * 60)

        docs = self.client.doc.get_by_path(
            group_login=self.test_group_login, book_slug=self.test_book_slug
        )

        assert docs is not None
        assert hasattr(docs, "data")
        assert isinstance(docs.data, list)

        print(f"文档数量: {len(docs.data)}")
        print("✓ 测试通过: 按路径获取文档列表成功")

    def test_get_document_by_id(self):
        """Test getting a single document by ID."""
        print("\n" + "=" * 60)
        print("Test: Get Document By ID")
        print("=" * 60)

        docs = self.client.doc.get_by_repo(book_id=self.test_book_id)
        assert len(docs.data) > 0, "No documents found"

        first_doc = docs.data[0]
        doc_id = first_doc.get("id")

        doc = self.client.doc.get(doc_id=doc_id)

        assert doc is not None
        assert doc.get("id") == doc_id

        print(f"文档ID: {doc.get('id')}")
        print(f"文档标题: {doc.get('title')}")
        print(f"文档slug: {doc.get('slug')}")
        print(f"内容格式: {doc.get('body_format')}")
        print(f"字数: {doc.get('word_count', 0)}")
        print(f"阅读量: {doc.get('read_count', 0)}")
        print(f"创建时间: {doc.get('created_at')}")
        print(f"更新时间: {doc.get('updated_at')}")

        body = doc.get("body", "")
        if body:
            preview = body[:500] + "..." if len(body) > 500 else body
            print(f"\n内容预览:\n{preview}")

        print("✓ 测试通过: 获取单个文档成功")

    def test_get_document_version(self):
        """Test getting document version."""
        print("\n" + "=" * 60)
        print("Test: Get Document Version")
        print("=" * 60)

        docs = self.client.doc.get_by_repo(book_id=self.test_book_id)
        if len(docs.data) > 0:
            first_doc = docs.data[0]
            doc_id = first_doc.get("id")

            try:
                versions = self.client._client._request(
                    "GET", f"/api/v2/repos/{self.test_book_id}/docs/{doc_id}/versions"
                )
                import json

                print(f"文档版本信息: {json.dumps(versions, ensure_ascii=False, indent=2)}")
                print("✓ 测试通过: 获取文档版本成功")
            except Exception as e:
                print(f"文档无版本记录或API不支持: {e}")
        else:
            print("没有文档可测试版本功能")

    def test_create_document(self):
        """Test creating a new document."""
        print("\n" + "=" * 60)
        print("Test: Create Document")
        print("=" * 60)

        test_title = f"测试文档 - {datetime.now().strftime('%Y%m%d %H:%M:%S')}"
        test_body = f"""# {test_title}

这是一个测试文档。

## 测试内容

- 测试时间: {datetime.now().isoformat()}
- 测试目的: 验证创建文档功能

```python
print("Hello, Yuque API!")
```

祝好！
"""

        try:
            new_doc = self.client.doc.create(
                book_id=self.test_book_id,
                title=test_title,
                body=test_body,
                format="markdown",
                public=0,
            )

            assert new_doc is not None
            assert new_doc.get("id") is not None

            print(f"新文档ID: {new_doc.get('id')}")
            print(f"新文档标题: {new_doc.get('title')}")
            print(f"新文档slug: {new_doc.get('slug')}")
            print("✓ 测试通过: 创建文档成功")

            print("\n清理测试数据...")
            self.client.doc.delete(doc_id=new_doc.get("id"))
            print("✓ 测试文档已删除")

        except Exception as e:
            print(f"创建文档失败 (可能是权限问题): {e}")

    def test_update_document(self):
        """Test updating a document."""
        print("\n" + "=" * 60)
        print("Test: Update Document")
        print("=" * 60)

        docs = self.client.doc.get_by_repo(book_id=self.test_book_id)
        if len(docs.data) > 0:
            first_doc = docs.data[0]
            doc_id = first_doc.get("id")
            original_title = first_doc.get("title")

            print(f"待更新文档ID: {doc_id}")
            print(f"原始标题: {original_title}")

            updated_title = f"[已更新] {original_title}"

            try:
                updated_doc = self.client.doc.update(doc_id=doc_id, title=updated_title)

                assert updated_doc is not None
                assert updated_doc.get("title") == updated_title

                print(f"更新后标题: {updated_doc.get('title')}")
                print("✓ 测试通过: 更新文档成功")

                self.client.doc.update(doc_id=doc_id, title=original_title)
                print("✓ 已恢复原始标题")

            except Exception as e:
                print(f"更新文档失败: {e}")
        else:
            print("没有文档可测试更新功能")

    def test_delete_document(self):
        """Test deleting a document."""
        print("\n" + "=" * 60)
        print("Test: Delete Document")
        print("=" * 60)

        test_title = f"待删除测试文档 - {datetime.now().strftime('%Y%m%d %H:%M:%S')}"

        try:
            new_doc = self.client.doc.create(
                book_id=self.test_book_id,
                title=test_title,
                body="# 测试文档\n\n此文档将被删除。",
                format="markdown",
                public=0,
            )

            doc_id = new_doc.get("id")
            print(f"创建测试文档成功，ID: {doc_id}")

            result = self.client.doc.delete(doc_id=doc_id)
            print(f"删除结果: {result}")
            print("✓ 测试通过: 删除文档成功")

        except Exception as e:
            print(f"删除文档失败: {e}")
