"""Test Group API endpoints."""

import pytest

from yuque import YuqueClient
from conftest import get_config


config = get_config()
API_TOKEN = config.api_token
TEST_GROUP_LOGIN = config.test_group_login


class TestGroupAPI:
    """Test Group API endpoints."""

    @pytest.fixture(autouse=True)
    def setup(self):
        """Setup test client."""
        self.client = YuqueClient(token=API_TOKEN)
        self.test_group_login = TEST_GROUP_LOGIN
        yield

    def test_get_group(self):
        """Test getting a group by login name."""
        print("\n" + "=" * 60)
        print("Test: Get Group")
        print("=" * 60)

        print("注: /api/v2/groups/{login} 端点可能不存在，群组信息通常从其他端点获取")
        pytest.skip("Group detail endpoint does not exist in API")

    def test_get_group_repos(self):
        """Test getting repositories in a group."""
        print("\n" + "=" * 60)
        print("Test: Get Group Repositories")
        print("=" * 60)

        repos = self.client.group.get_repos(login=self.test_group_login)

        assert repos is not None
        assert hasattr(repos, "data")
        assert isinstance(repos.data, list)

        print(f"知识库数量: {len(repos.data)}")
        print(f"分页信息: offset=0, limit=100")

        for repo in repos.data[:5]:
            print(f"  - {repo.get('name')} (ID: {repo.get('id')})")

        if len(repos.data) > 5:
            print(f"  ... 还有 {len(repos.data) - 5} 个知识库")

        print("✓ 测试通过: 获取群组知识库列表成功")

    def test_get_group_members(self):
        """Test getting members of a group."""
        print("\n" + "=" * 60)
        print("Test: Get Group Members")
        print("=" * 60)

        members = self.client.group.get_members(login=self.test_group_login)

        assert members is not None
        assert hasattr(members, "data")
        assert isinstance(members.data, list)

        print(f"成员数量: {len(members.data)}")

        for member in members.data[:5]:
            user_info = member.get("user", {})
            print(f"  - {user_info.get('name', 'Unknown')} ({user_info.get('login', 'N/A')})")

        print("✓ 测试通过: 获取群组成员成功")

    def test_get_group_statistics(self):
        """Test getting group statistics."""
        print("\n" + "=" * 60)
        print("Test: Get Group Statistics")
        print("=" * 60)

        stats = self.client.group.get_statistics(login=self.test_group_login)

        assert stats is not None

        import json

        print(f"群组统计信息: {json.dumps(stats, ensure_ascii=False, indent=2)}")
        print("✓ 测试通过: 获取群组统计成功")
