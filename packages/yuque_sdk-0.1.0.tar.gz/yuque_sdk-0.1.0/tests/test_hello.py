"""Test Hello API endpoint."""

import pytest
import json

from yuque import YuqueClient
from conftest import get_config


config = get_config()
API_TOKEN = config.api_token


class TestHelloAPI:
    """Test Hello API endpoint."""

    def test_hello(self):
        """Test hello API connection."""
        print("\n" + "=" * 60)
        print("Test: Hello API Connection")
        print("=" * 60)

        client = YuqueClient(token=API_TOKEN)
        result = client.hello()

        assert result is not None

        print(f"Hello API响应: {json.dumps(result, ensure_ascii=False, indent=2)}")
        print("✓ 测试通过: Hello API连接成功")
