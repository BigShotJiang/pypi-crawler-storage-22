"""Test Repository (Book) API endpoints."""

import pytest

from yuque import YuqueClient
from conftest import get_config


config = get_config()
API_TOKEN = config.api_token
TEST_GROUP_LOGIN = config.test_group_login
TEST_BOOK_SLUG = config.test_book_slug
TEST_BOOK_ID = config.test_book_id


class TestRepoAPI:
    """Test Repository (Book) API endpoints."""

    @pytest.fixture(autouse=True)
    def setup(self):
        """Setup test client."""
        self.client = YuqueClient(token=API_TOKEN)
        self.test_group_login = TEST_GROUP_LOGIN
        self.test_book_slug = TEST_BOOK_SLUG
        self.test_book_id = TEST_BOOK_ID
        yield

    def test_get_repo_by_id(self):
        """Test getting repository by ID."""
        print("\n" + "=" * 60)
        print("Test: Get Repository By ID")
        print("=" * 60)

        repo = self.client.repo.get(book_id=self.test_book_id)

        assert repo is not None
        assert repo.get("id") == self.test_book_id

        print(f"知识库ID: {repo.get('id')}")
        print(f"知识库名称: {repo.get('name')}")
        print(f"知识库slug: {repo.get('slug')}")
        print(f"类型: {repo.get('type')}")
        print(f"公开级别: {repo.get('public')}")
        print(f"创建者ID: {repo.get('creator_id')}")
        print("✓ 测试通过: 按ID获取知识库成功")

    def test_get_repo_by_path(self):
        """Test getting repository by group path and book slug."""
        print("\n" + "=" * 60)
        print("Test: Get Repository By Path")
        print("=" * 60)

        repo = self.client.repo.get_by_path(
            group_login=self.test_group_login, book_slug=self.test_book_slug
        )

        assert repo is not None
        assert repo.get("id") == self.test_book_id

        print(f"知识库ID: {repo.get('id')}")
        print(f"知识库名称: {repo.get('name')}")
        print(f"完整路径: {self.test_group_login}/{self.test_book_slug}")
        print("✓ 测试通过: 按路径获取知识库成功")

    def test_list_repos(self):
        """Test listing all repositories for authenticated user."""
        print("\n" + "=" * 60)
        print("Test: List All Repositories")
        print("=" * 60)

        print("注: /api/v2/repos 端点可能不适用于群组账户")
        print("请使用 get_group_repos 或 get_user_repos 替代")
        pytest.skip("Personal repos endpoint may not exist for group accounts")

    def test_get_repo_toc(self):
        """Test getting table of contents for a repository."""
        print("\n" + "=" * 60)
        print("Test: Get Repository TOC")
        print("=" * 60)

        toc = self.client.repo.get_toc(book_id=self.test_book_id)

        assert toc is not None
        assert isinstance(toc, list)

        print(f"TOC节点数量: {len(toc)}")

        for node in toc[:10]:
            indent = "  " * (node.get("depth", 1) - 1)
            print(f"{indent}├─ {node.get('title')} (slug: {node.get('slug')})")

        if len(toc) > 10:
            print(f"  ... 还有 {len(toc) - 10} 个节点")

        print("✓ 测试通过: 获取知识库目录成功")

    def test_get_repo_toc_by_path(self):
        """Test getting TOC by group path and book slug."""
        print("\n" + "=" * 60)
        print("Test: Get Repository TOC By Path")
        print("=" * 60)

        toc = self.client.repo.get_toc_by_path(
            group_login=self.test_group_login, book_slug=self.test_book_slug
        )

        assert toc is not None
        assert isinstance(toc, list)

        print(f"TOC节点数量: {len(toc)}")
        print("✓ 测试通过: 按路径获取知识库目录成功")
