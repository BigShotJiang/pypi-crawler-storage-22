"""Test Search API endpoints."""

import pytest

from yuque import YuqueClient
from conftest import get_config


config = get_config()
API_TOKEN = config.api_token
SEARCH_KEYWORD = config.search_keyword
SEARCH_TYPE = config.search_type


class TestSearchAPI:
    """Test Search API endpoints."""

    @pytest.fixture(autouse=True)
    def setup(self):
        """Setup test client."""
        self.client = YuqueClient(token=API_TOKEN)
        yield

    def test_search_all(self):
        """Test searching across all content."""
        print("\n" + "=" * 60)
        print("Test: Search All")
        print("=" * 60)

        results = self.client.search.search(keyword=SEARCH_KEYWORD)

        assert results is not None
        assert hasattr(results, "data")
        assert isinstance(results.data, list)

        print(f"搜索关键词: {SEARCH_KEYWORD}")
        print(f"搜索结果数量: {len(results.data)}")

        for result in results.data[:5]:
            print(f"  - [{result.get('type')}] {result.get('title')}")

        if len(results.data) > 5:
            print(f"  ... 还有 {len(results.data) - 5} 个结果")

        print("✓ 测试通过: 全局搜索成功")

    def test_search_by_type(self):
        """Test searching with type filter."""
        print("\n" + "=" * 60)
        print("Test: Search By Type")
        print("=" * 60)

        results = self.client.search.search(keyword=SEARCH_KEYWORD, type=SEARCH_TYPE)

        assert results is not None
        assert hasattr(results, "data")

        print(f"类型筛选: {SEARCH_TYPE}")
        print(f"结果数量: {len(results.data)}")

        for result in results.data[:5]:
            print(f"  - {result.get('title')}")

        print("✓ 测试通过: 按类型搜索成功")

    def test_search_pagination(self):
        """Test search with pagination."""
        print("\n" + "=" * 60)
        print("Test: Search Pagination")
        print("=" * 60)

        page1 = self.client.search.search(keyword=SEARCH_KEYWORD, page=1)

        print(f"每页数量: 20 (API固定)")
        print(f"第一页结果数: {len(page1.data)}")

        if len(page1.data) >= 20:
            page2 = self.client.search.search(keyword=SEARCH_KEYWORD, page=2)
            print(f"第二页结果数: {len(page2.data)}")

        print("✓ 测试通过: 搜索分页成功")
