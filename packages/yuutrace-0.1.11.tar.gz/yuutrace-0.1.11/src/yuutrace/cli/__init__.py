"""yuutrace CLI package."""
