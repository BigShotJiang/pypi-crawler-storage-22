# yv-languages

## Requirements

This project recommends Python 3.11 or higher.

## Installation

```bash
pip install yv-languages
```

## Usage

You can make any language tag string canonical like:

```python
import yv_languages

bcp = yv_languages.canonical("eng")

print(str(bcp))  # "en"
```

or with validation:

```python
import yv_languages

bcp = yv_languages.canonical("eng", should_validate=True)

print(str(bcp))  # "en"
```

## Development

This project was written and tested with Python 3.11.

### Running tests

``` bash
pytest tests/
```

### Before committing any code

We have a pre-commit hook which should be setup.
You can symlink it to run before each commit by changing directory to the repo and running

``` bash
make githooks
```
