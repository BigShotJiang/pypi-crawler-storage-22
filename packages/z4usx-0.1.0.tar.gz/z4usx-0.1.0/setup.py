from setuptools import setup, find_packages

setup(
    name="Z4usX",
    version="0.1.0",
    packages=find_packages(),
    install_requires=[
        "requests",
        "fake-useragent",
    ],
    python_requires='>=3.7',
)
