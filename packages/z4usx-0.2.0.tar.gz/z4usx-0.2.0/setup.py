from setuptools import setup, find_packages

setup(
    name="z4usx",
    version="0.1.0",
    packages=find_packages(),
    description="A short description of your package",
    url="https://github.com/Z4usXcode/Zeus",
    author="z4usx",
    author_email="example@example.com",   # boş bırakma
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    python_requires='>=3.9',  # daha yaygın sürüm
)
