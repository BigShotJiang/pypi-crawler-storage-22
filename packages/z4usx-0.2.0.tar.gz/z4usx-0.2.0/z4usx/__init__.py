import requests
import random

def fetch_random_device():
    url = "https://raw.githubusercontent.com/Z4usXcode/-/main/devices.txt"
    response = requests.get(url)
    response.raise_for_status()
    
    lines = response.text.strip().splitlines()
    if not lines:
        raise ValueError("Dosya boş.")
    line = random.choice(lines)    
    parts = line.strip().split(":")
    if len(parts) != 7:
        raise ValueError("Satır beklenen formatta değil.")    
    return {
        "iid": parts[0],
        "did": parts[1],
        "type": parts[2],
        "brand": parts[3],
        "os_version": parts[4],
        "cdid": parts[5],
        "odid": parts[6],
    }
