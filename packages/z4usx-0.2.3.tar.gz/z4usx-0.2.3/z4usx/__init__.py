import requests,re,time,json,random,fake_useragent

def fetch_random_device():
    url = "https://raw.githubusercontent.com/Z4usXcode/-/main/devices.txt"
    response = requests.get(url)
    response.raise_for_status()
    
    lines = response.text.strip().splitlines()
    if not lines:
        raise ValueError("Dosya boş.")
    line = random.choice(lines)    
    parts = line.strip().split(":")
    if len(parts) != 7:
        raise ValueError("Satır beklenen formatta değil.")    
    return {
        "iid": parts[0],
        "did": parts[1],
        "type": parts[2],
        "brand": parts[3],
        "os_version": parts[4],
        "cdid": parts[5],
        "odid": parts[6],
    }
def info(username):
    headers = {
        "user-agent": "Mozilla/5.0 (Windows NT 10.0; Android 10; Pixel 3 Build/QKQ1.200308.002; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/125.0.6394.70 Mobile Safari/537.36 trill_350402 JsSdk/1.0 NetType/MOBILE Channel/googleplay AppName/trill app_version/35.3.1 ByteLocale/en ByteFullLocale/en Region/IN AppId/1180 Spark/1.5.9.1 AppVersion/35.3.1 BytedanceWebview/d8a21c6",
    }
    try:
        tikinfo = requests.get(f'https://www.tiktok.com/@{username}', headers=headers).text
        data = json.loads(re.search(r'<script id="__UNIVERSAL_DATA_FOR_REHYDRATION__" type="application/json">(.*?)</script>', tikinfo).group(1))
        user = data['__DEFAULT_SCOPE__']['webapp.user-detail']['userInfo']['user']
        stats = data['__DEFAULT_SCOPE__']['webapp.user-detail']['userInfo']['stats']
        
        return {
            'id': user['id'],
            'username': user['uniqueId'],
            'name': user['nickname'],
            'verified': user['verified'],
            'private': user['privateAccount'],
            'create_time': time.strftime('%Y-%m-%d', time.localtime(user['createTime'])),
            'videos': stats['videoCount'],
            'followers': stats['followerCount'],
            'following': stats['followingCount'],
            'likes': stats['heartCount']
        }
    except Exception as e:
        print(f"Error getting user info: {e}")
        return None

def check_tiktok_registered(email):
    response = requests.post(
        'https://web-sg.tiktok.com/passport/web/user/check_email_registered?multi_login=1&did=&locale=ar&app_language=en&aid=1459&account_sdk_source=web&sdk_version=2.1.11-tiktokbeta.3&language=en&verifyFp=&standalone_aid=&shark_extra=%7B%22aid%22:1459,%22app_name%22:%22Tik_Tok_Login%22,%22channel%22:%22tiktok_web%22,%22device_platform%22:%22web_mobile%22,%22device_id%22:%227597508492069586453%22,%22region%22:%22IQ%22,%22priority_region%22:%22%22,%22os%22:%22android%22,%22referer%22:%22https:%2F%2Fwww.tiktok.com%2Fprofile%22,%22root_referer%22:%22https:%2F%2Fwww.google.com%2F%22,%22cookie_enabled%22:true,%22screen_width%22:400,%22screen_height%22:889,%22browser_language%22:%22ar-IQ%22,%22browser_platform%22:%22Linux+armv81%22,%22browser_name%22:%22Mozilla%22,%22browser_version%22:%225.0+(Linux%3B+Android+10%3B+K)+AppleWebKit%2F537.36+(KHTML,+like+Gecko)+Chrome%2F132.0.0.0+Mobile+Safari%2F537.36%22,%22browser_online%22:true,%22verifyFp%22:%22verify_mkmwxx0p_ZkPLAvMH_3cNy_4QzT_BKNm_1cM1BmpAbadP%22,%22app_language%22:%22ar%22,%22webcast_language%22:%22ar%22,%22tz_name%22:%22Asia%2FBaghdad%22,%22is_page_visible%22:true,%22focus_state%22:true,%22is_fullscreen%22:false,%22history_len%22:39,%22user_is_login%22:false,%22data_collection_enabled%22:false%7D&msToken=',
        headers={
            'user-agent': fake_useragent.FakeUserAgent().random
        },
        data={'email': email}
    )
    return response.text
