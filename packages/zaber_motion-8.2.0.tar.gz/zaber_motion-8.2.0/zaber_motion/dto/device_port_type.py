# This file is generated. Do not modify by hand.
from enum import Enum


class DevicePortType(Enum):
    """
    Port type of device connect to network.
    """

    DEVICE = 0

    DEVICE_CHAIN = 1
