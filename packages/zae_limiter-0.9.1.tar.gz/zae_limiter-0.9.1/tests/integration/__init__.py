"""Integration tests using LocalStack."""
