#!/usr/bin/env bash
# E2E smoke: запуск e2e-тестов только при заданном ZAI_API_KEY.
# В CI по умолчанию не запускать (нет ключа).

set -e
cd "$(dirname "$0")/.."

if [ -z "${ZAI_API_KEY}" ]; then
  echo "ZAI_API_KEY не задан — e2e пропущены."
  exit 0
fi

.venv/bin/python -m pytest tests/ -v -m e2e 2>&1
