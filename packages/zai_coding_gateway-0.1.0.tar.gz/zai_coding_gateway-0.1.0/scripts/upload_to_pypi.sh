#!/usr/bin/env bash
# Сборка пакета и загрузка на PyPI.
# Нужен файл pypi_credentials.env с TWINE_USERNAME=__token__ и TWINE_PASSWORD=<API token с pypi.org>.
set -e
cd "$(dirname "$0")/.."
if [ ! -f pypi_credentials.env ]; then
  echo "Создайте pypi_credentials.env (см. pypi_credentials.env.example)."
  exit 1
fi
set -a
source pypi_credentials.env
set +a
if [ -z "$TWINE_PASSWORD" ]; then
  echo "В pypi_credentials.env задайте TWINE_PASSWORD (API token с https://pypi.org/manage/account/token/)."
  exit 1
fi
if [ "$TWINE_USERNAME" != "__token__" ]; then
  echo "Для API token TWINE_USERNAME должен быть __token__. Сейчас: $TWINE_USERNAME"
  exit 1
fi
echo "Сборка пакета..."
python -m build
echo "Загрузка на PyPI..."
twine upload dist/*
echo "Готово."
