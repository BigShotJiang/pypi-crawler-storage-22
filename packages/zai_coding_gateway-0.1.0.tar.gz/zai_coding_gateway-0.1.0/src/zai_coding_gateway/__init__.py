"""ZAI Coding Gateway — MCP-сервер для решения задач в рабочем пространстве через Z.AI Coding Plan."""

__version__ = "0.1.0"
