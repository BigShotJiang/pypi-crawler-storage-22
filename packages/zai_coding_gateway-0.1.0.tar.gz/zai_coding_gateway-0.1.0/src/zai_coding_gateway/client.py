"""Обёртка над OpenAI-клиентом для Z.AI Coding Plan endpoint."""

import os
from typing import Any

from openai import OpenAI

from zai_coding_gateway.errors import QuotaExceededError


def _is_quota_error(exc: Exception) -> bool:
    """Определяет по исключению, что это исчерпание квоты (429 / quota / rate limit)."""
    status = getattr(exc, "status_code", None)
    if status == 429:
        return True
    msg = str(exc).lower()
    if "429" in msg or "quota" in msg or "rate limit" in msg or "rate_limit" in msg:
        return True
    return False

DEFAULT_BASE_URL = "https://api.z.ai/api/coding/paas/v4"
DEFAULT_WORK_MODEL = "glm-4.7"
DEFAULT_FAST_MODEL = "glm-4.5-air"


def _get_env(key: str, default: str | None = None) -> str | None:
    return os.environ.get(key) or default


def get_effective_base_url() -> str:
    """Возвращает URL, который будет использоваться для запросов (из env или дефолт). Для проверки биллинга."""
    return (_get_env("ZAI_BASE_URL") or DEFAULT_BASE_URL).rstrip("/") + "/"


def get_work_model() -> str:
    """Модель для основного цикла сессии solve_in_workspace. По умолчанию glm-4.7."""
    v = (_get_env("ZAI_WORK_MODEL") or "").strip()
    return v or DEFAULT_WORK_MODEL


def get_fast_model() -> str:
    """Модель для консолидации и суммаризации в solve_in_workspace. По умолчанию glm-4.5-air."""
    v = (_get_env("ZAI_FAST_MODEL") or "").strip()
    return v or DEFAULT_FAST_MODEL


def create_client() -> OpenAI:
    """Создаёт OpenAI-клиент с base_url и api_key из ENV. Ключ только из окружения."""
    api_key = _get_env("ZAI_API_KEY")
    if not api_key:
        raise ValueError("ZAI_API_KEY не задан. Укажите ключ в env (например в mcp.json).")
    base_url = get_effective_base_url()
    return OpenAI(api_key=api_key, base_url=base_url)


def chat_completions(
    client: OpenAI,
    messages: list[dict[str, Any]],
    model: str,
    response_format: dict[str, Any] | None = None,
) -> dict[str, Any]:
    """
    Вызов chat/completions. При исчерпании квоты выбрасывает QuotaExceededError.
    model: передавать get_work_model() или get_fast_model() в зависимости от сценария.
    """
    kwargs: dict[str, Any] = {"model": model, "messages": messages, "stream": False}
    if response_format is not None:
        kwargs["response_format"] = response_format
    try:
        resp = client.chat.completions.create(**kwargs)
    except QuotaExceededError:
        raise
    except Exception as e:  # noqa: BLE001
        if _is_quota_error(e):
            raise QuotaExceededError("QuotaExceeded: wait for refresh cycle") from e
        raise
    return _completion_to_dict(resp)


def _completion_to_dict(resp: Any) -> dict[str, Any]:
    """Преобразует объект Completion в dict для единообразного разбора."""
    return {
        "choices": [
            {
                "message": {
                    "content": c.message.content,
                    "role": getattr(c.message, "role", "assistant"),
                }
            }
            for c in (resp.choices or [])
        ],
        "usage": getattr(resp, "usage", None),
    }
