"""Доменные исключения для ZAI Coding Gateway."""


class ZAIGatewayError(Exception):
    """Базовое исключение gateway."""

    pass


class QuotaExceededError(ZAIGatewayError):
    """Исчерпана квота Coding Plan. Ожидать обновления цикла (~5 ч)."""

    pass


class InstructionTooLongError(ZAIGatewayError):
    """Текстовый ввод (инструкция/задача/контекст) превышает допустимый лимит. Использовать file_paths для контекста."""

    pass


class FileOutsideProjectError(ZAIGatewayError):
    """Путь к файлу вне корня проекта (ZAI_PROJECT_ROOT)."""

    pass


class ProjectRootNotSetError(ZAIGatewayError):
    """
    Не удалось определить корень проекта: ZAI_PROJECT_ROOT не задан,
    MCP roots/list не поддерживается клиентом (например Cursor), cwd не подходит.
    Задайте ZAI_PROJECT_ROOT в конфиге MCP (env) — путь к папке проекта.
    """

    pass


class FilePathsRequiredError(ZAIGatewayError):
    """Для задачи требуются file_paths; список пуст или не передан."""

    pass


class SuggestedChangesOutsideSessionError(ZAIGatewayError):
    """Путь в suggested_changes не входит в множество файлов сессии."""

    pass


class DiffNotApplicableError(ZAIGatewayError):
    """Дифф не применим к текущему содержимому файла."""

    pass


class SessionNotFoundError(ZAIGatewayError):
    """Сессия workspace не найдена (уже очищена или неверный session_id)."""

    pass


# ~3000 токенов: ориентир ~4 символа на токен → 12000 символов
MAX_INSTRUCTION_CHARS = 12_000
