"""Структурированное логирование в stderr (JSON, одна строка на событие)."""

import json
import sys
from typing import Any, Literal

ToolInvocationStatus = Literal["success", "quota_exceeded", "error"]


def log_tool_invocation(
    tool: str,
    model: str,
    latency_ms: float,
    status: ToolInvocationStatus,
    extra: dict[str, Any] | None = None,
) -> None:
    """
    Пишет в stderr одну строку JSON: tool, model, latency, status.
    stdout не трогаем — занят MCP при stdio.
    """
    payload: dict[str, Any] = {
        "event": "tool_invocation",
        "tool": tool,
        "model": model,
        "latency_ms": round(latency_ms, 2),
        "status": status,
    }
    if extra:
        payload.update(extra)
    line = json.dumps(payload, ensure_ascii=False) + "\n"
    sys.stderr.write(line)
    sys.stderr.flush()
