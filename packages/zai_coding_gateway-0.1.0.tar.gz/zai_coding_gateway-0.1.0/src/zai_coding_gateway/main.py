"""Точка входа: парсинг аргументов, проверка ENV, запуск MCP по stdio."""

import argparse
import os
import sys

from zai_coding_gateway.server import get_mcp


def main() -> None:
    parser = argparse.ArgumentParser(description="ZAI Coding Gateway — MCP-сервер для Z.AI Coding Plan")
    parser.add_argument(
        "--stdio",
        action="store_true",
        default=True,
        help="Запуск с транспортом stdio (по умолчанию)",
    )
    args = parser.parse_args()

    if not os.environ.get("ZAI_API_KEY"):
        sys.stderr.write("Ошибка: ZAI_API_KEY не задан. Укажите ключ в env (например в mcp.json).\n")
        sys.stderr.flush()
        sys.exit(1)

    from zai_coding_gateway.client import get_effective_base_url
    effective = get_effective_base_url()
    plan = "Coding Plan" if "/coding/" in effective else "общий paas (не Coding Plan)"
    sys.stderr.write(f"zai-coding-gateway: endpoint = {effective.rstrip('/')} ({plan})\n")
    sys.stderr.flush()

    mcp = get_mcp()
    # Добавление StreamableHTTP: второй branch в main или отдельный entry point,
    # запуск сервера на указанном host/port.
    mcp.run(transport="stdio")


if __name__ == "__main__":
    main()
