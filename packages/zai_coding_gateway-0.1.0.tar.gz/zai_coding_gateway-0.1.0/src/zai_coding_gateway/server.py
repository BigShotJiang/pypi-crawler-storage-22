"""MCP Server: регистрация инструментов, без привязки к транспорту."""

import os

from mcp.server.fastmcp import Context, FastMCP

from zai_coding_gateway.tools.file_io import (
    _file_uri_to_path,
    get_cached_project_root,
    set_cached_project_root,
)


async def _ensure_project_root_from_mcp(context: Context | None) -> None:
    """
    Если ZAI_PROJECT_ROOT не задан и кэш пуст — запрашивает roots/list у клиента (Cursor)
    и кэширует первый корень как проект. При ошибке или отсутствии context — без изменений.
    """
    if context is None:
        return
    if os.environ.get("ZAI_PROJECT_ROOT") or get_cached_project_root() is not None:
        return
    try:
        result = await context.session.list_roots()
        if result.roots:
            path = _file_uri_to_path(str(result.roots[0].uri))
            if path and os.path.isdir(path):
                set_cached_project_root(path)
    except Exception:
        pass
from zai_coding_gateway.tools.solve_in_workspace import (
    answer_session_question as answer_session_question_impl,
    apply_changes as apply_changes_impl,
    confirm_session_done as confirm_session_done_impl,
    solve_in_workspace as solve_in_workspace_impl,
)

mcp = FastMCP(
    "ZAI Coding Gateway",
    json_response=True,
)


@mcp.tool(
    name="solve_in_workspace",
    description=(
        "Точка входа: запускает сессию рабочего пространства. "
        "Вход: instruction (строка — задача), todos (список строк), file_paths (список путей относительно корня проекта, обязательный начальный контекст), max_steps (число, по умолчанию 10). "
        "Внутри сессии модель получает полный контекст, может запрашивать файлы (need_more), использовать list_dir/grep/glob/read, затем вернуть отчёт и suggested_changes. "
        "Модель может предлагать и новые файлы в suggested_changes — создание в проекте только через apply_changes после вашего утверждения. "
        "Выход: session_id, report, suggested_changes, files_used либо при отсутствии корня проекта или вопросе модели — status «question», session_id, prompt (ответ передайте через answer_session_question)."
    ),
)
async def solve_in_workspace_tool(
    instruction: str,
    todos: list[str],
    file_paths: list[str],
    max_steps: int = 10,
    mcp_context: Context | None = None,
) -> dict:
    """Run workspace session: need_more/done loop with Z.AI (fixed model flow)."""
    await _ensure_project_root_from_mcp(mcp_context)
    return solve_in_workspace_impl(
        instruction=instruction,
        todos=todos,
        file_paths=file_paths,
        max_steps=max_steps,
    )


@mcp.tool(
    name="answer_session_question",
    description=(
        "Передаёт ответ на вопрос сессии и продолжает выполнение. Вызывайте, когда solve_in_workspace вернул status «question». "
        "Вход: session_id (из ответа solve_in_workspace), answer (строка — ответ на вопрос: путь к корню проекта или ответ модели, например «да» для дозагрузки файла). "
        "Выход: тот же формат, что и solve_in_workspace (session_id, report, suggested_changes, files_used либо снова status «question», session_id, prompt)."
    ),
)
async def answer_session_question_tool(session_id: str, answer: str) -> dict:
    """Submit architect answer to session question and continue."""
    return answer_session_question_impl(session_id, answer)


@mcp.tool(
    name="apply_changes",
    description=(
        "Применяет утверждённые изменения к проекту. Вызывайте после solve_in_workspace, когда приняли решение по suggested_changes. "
        "Вход: session_id (из ответа solve_in_workspace), changes (список объектов: каждый объект — {path: путь к файлу, content: новое содержимое целиком} или {path, diff: unified diff или полный текст}), confirm_after (bool, по умолчанию True — после применения очистить сессию). "
        "Пути проверяются только на нахождение внутри корня проекта; новые файлы разрешены. Каждое изменение обрабатывается отдельно. "
        "Выход: session_id, applied (список применённых путей), errors (список {path, error} для неудачных), cleaned (bool)."
    ),
)
async def apply_changes_tool(
    session_id: str,
    changes: list[dict],
    confirm_after: bool = True,
) -> dict:
    """Apply approved changes to project files."""
    return apply_changes_impl(
        session_id=session_id,
        changes=[dict(c) for c in changes],
        confirm_after=confirm_after,
    )


@mcp.tool(
    name="confirm_session_done",
    description=(
        "Очищает темп-каталог сессии после принятия решения (после apply_changes или при отказе от изменений). "
        "Вход: session_id (строка из ответа solve_in_workspace). Выход: session_id, cleaned (true)."
    ),
)
async def confirm_session_done_tool(session_id: str) -> dict:
    """Clean session temp dir."""
    return confirm_session_done_impl(session_id)


def get_mcp() -> FastMCP:
    """Возвращает экземпляр MCP-сервера (для main или тестов)."""
    return mcp
