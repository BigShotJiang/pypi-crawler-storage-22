"""Чтение и запись файлов проекта в пределах ZAI_PROJECT_ROOT."""

import os
import re
from pathlib import Path
from urllib.parse import urlparse

from zai_coding_gateway.errors import FileOutsideProjectError, ProjectRootNotSetError

# Каталоги, которые не обходим при grep/glob
_SKIP_DIRS = frozenset({".git", "node_modules", "__pycache__", ".venv", "venv"})
_MAX_GLOB_PATHS = 500
_MAX_GREP_FILES = 100
_MAX_GREP_OUTPUT_CHARS = 5000

# Кэш корня из MCP roots/list (клиент передаёт workspace). Cursor пока не поддерживает roots/list.
_cached_mcp_project_root: str | None = None

# Маркеры корня проекта при поиске вверх по дереву от cwd
_PROJECT_ROOT_MARKERS = ("package.json", "pyproject.toml", ".git")


def _infer_project_root_from_cwd() -> str | None:
    """
    Поднимается от os.getcwd() вверх и возвращает каталог, содержащий package.json, .git или pyproject.toml.
    Если cwd — уже корень или не найден маркер — возвращает None.
    """
    cwd = os.path.abspath(os.getcwd())
    if not os.path.isdir(cwd):
        return None
    current = cwd
    while current and current != os.path.dirname(current):
        for marker in _PROJECT_ROOT_MARKERS:
            if os.path.exists(os.path.join(current, marker)):
                return current
        current = os.path.dirname(current)
    return None


def get_project_root() -> str:
    """
    Корень проекта: ZAI_PROJECT_ROOT (env) > кэш из MCP roots/list > вывод по маркерам от cwd > cwd.
    Если итоговый корень — "/" или не подходит, выбрасывает ProjectRootNotSetError (Cursor не поддерживает roots/list).
    """
    root = os.environ.get("ZAI_PROJECT_ROOT")
    if root:
        return os.path.abspath(root)
    if _cached_mcp_project_root is not None:
        return _cached_mcp_project_root
    inferred = _infer_project_root_from_cwd()
    if inferred:
        return inferred
    cwd = os.path.abspath(os.getcwd())
    if not cwd or cwd == os.path.sep or cwd == "/":
        raise ProjectRootNotSetError(
            "Корень проекта не задан. Cursor пока не поддерживает MCP roots/list. "
            "Задайте ZAI_PROJECT_ROOT в настройках MCP (env) — абсолютный путь к папке проекта (например к папке с package.json)."
        )
    if not os.path.isdir(cwd):
        raise ProjectRootNotSetError(
            "Текущая рабочая директория не является каталогом. Задайте ZAI_PROJECT_ROOT в env MCP."
        )
    return cwd


def set_cached_project_root(path: str) -> None:
    """Установить кэшированный корень (из MCP roots/list). Для тестов — сброс через None не делаем, только через env."""
    global _cached_mcp_project_root
    _cached_mcp_project_root = os.path.abspath(path) if path else None


def get_cached_project_root() -> str | None:
    """Текущее значение кэша (для тестов)."""
    return _cached_mcp_project_root


def _file_uri_to_path(uri: str) -> str:
    """Преобразует file:// URI в абсолютный путь к файлу."""
    parsed = urlparse(uri)
    if parsed.scheme != "file":
        return ""
    path = parsed.path
    if not path:
        return ""
    if os.name == "nt" and path.startswith("/") and len(path) > 2 and path[2] == ":":
        path = path[1:]
    return os.path.normpath(path)


def resolve_path(path: str, project_root: str | None = None) -> str:
    """
    Преобразует путь (относительный или абсолютный) в абсолютный в пределах project_root.
    Выбрасывает FileOutsideProjectError, если итоговый путь вне корня.
    """
    root = project_root or get_project_root()
    path_abs = os.path.normpath(os.path.join(root, path)) if not os.path.isabs(path) else os.path.normpath(path)
    root_real = os.path.realpath(root)
    path_real = os.path.realpath(path_abs)
    if not path_real.startswith(root_real):
        raise FileOutsideProjectError(f"Путь вне корня проекта: {path!r}")
    return path_real


def read_file_content(path: str, project_root: str | None = None) -> str:
    """Читает содержимое файла по пути относительно корня проекта. UTF-8."""
    resolved = resolve_path(path, project_root)
    with open(resolved, encoding="utf-8") as f:
        return f.read()


def read_file(path: str, project_root: str | None = None) -> dict:
    """
    MCP-инструмент: прочитать файл по пути относительно корня проекта.
    Возвращает content и path (подтверждение).
    """
    root = project_root or get_project_root()
    content = read_file_content(path, root)
    return {"content": content, "path": path}


def write_file(path: str, content: str, project_root: str | None = None) -> dict:
    """
    MCP-инструмент: записать содержимое в файл по пути относительно корня проекта.
    Создаёт родительские директории при необходимости.
    """
    root = project_root or get_project_root()
    resolved = resolve_path(path, root)
    os.makedirs(os.path.dirname(resolved) or ".", exist_ok=True)
    with open(resolved, "w", encoding="utf-8") as f:
        f.write(content)
    return {"path": path, "written": True, "summary": f"written {len(content)} bytes"}


def list_dir_in_project(path: str = ".", project_root: str | None = None) -> list[str]:
    """
    Список имён прямых потомков каталога (один уровень). Путь относительно корня проекта.
    Для файла или несуществующего пути выбрасывает OSError/FileOutsideProjectError.
    """
    root = project_root or get_project_root()
    path = path.strip() or "."
    resolved = resolve_path(path, root)
    if not os.path.isdir(resolved):
        raise NotADirectoryError(f"Not a directory: {path!r}")
    return sorted(os.listdir(resolved))


def grep_in_project(
    pattern: str,
    path_or_none: str | None,
    project_root: str | None = None,
    max_files: int = _MAX_GREP_FILES,
    max_output_chars: int = _MAX_GREP_OUTPUT_CHARS,
) -> str:
    """
    Поиск подстроки (или regex) по содержимому текстовых файлов в пределах path или всего проекта.
    Возвращает сводку: path:line_no:line_content (обрезано по max_output_chars).
    """
    root = project_root or get_project_root()
    root_path = Path(root).resolve()
    start_path = root_path
    if path_or_none and path_or_none.strip():
        start_path = Path(resolve_path(path_or_none.strip(), root)).resolve()
        if not start_path.is_dir() and start_path.is_file():
            files_to_scan = [start_path]
        else:
            files_to_scan = []
            for p in start_path.rglob("*"):
                if p.is_file() and not any(part in _SKIP_DIRS for part in p.relative_to(root_path).parts):
                    files_to_scan.append(p)
                    if len(files_to_scan) >= max_files:
                        break
    else:
        files_to_scan = []
        for p in root_path.rglob("*"):
            if p.is_file() and not any(part in _SKIP_DIRS for part in p.relative_to(root_path).parts):
                files_to_scan.append(p)
                if len(files_to_scan) >= max_files:
                    break

    try:
        regex = re.compile(pattern)
    except re.error:
        regex = re.compile(re.escape(pattern))

    lines_out: list[str] = []
    total_chars = 0
    for fp in files_to_scan[:max_files]:
        try:
            with open(fp, encoding="utf-8", errors="replace") as f:
                rel = str(fp.relative_to(root_path)).replace("\\", "/")
                for line_no, line in enumerate(f, 1):
                    if regex.search(line):
                        frag = line.strip()[:200]
                        s = f"{rel}:{line_no}:{frag}\n"
                        lines_out.append(s)
                        total_chars += len(s)
                        if total_chars >= max_output_chars:
                            lines_out.append("(output truncated)\n")
                            return "".join(lines_out)
        except (OSError, UnicodeDecodeError):
            continue
    return "".join(lines_out) if lines_out else "(no matches)"


def glob_in_project(pattern: str, project_root: str | None = None) -> list[str]:
    """
    Список относительных путей файлов, совпадающих с маской (например *.py, **/test_*.py).
    Исключаются .git, node_modules, __pycache__. Не более _MAX_GLOB_PATHS путей.
    """
    root = project_root or get_project_root()
    root_path = Path(root).resolve()
    pattern = pattern.strip() or "*"
    if "**" not in pattern and "/" not in pattern and "\\" not in pattern:
        pattern = f"**/{pattern}"
    paths: list[str] = []
    try:
        for p in root_path.glob(pattern):
            if not p.is_file():
                continue
            if any(part in _SKIP_DIRS for part in p.relative_to(root_path).parts):
                continue
            rel = str(p.relative_to(root_path)).replace("\\", "/")
            paths.append(rel)
            if len(paths) >= _MAX_GLOB_PATHS:
                break
    except (ValueError, OSError):
        pass
    return sorted(paths)
