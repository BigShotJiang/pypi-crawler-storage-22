"""Сессия рабочего пространства: цикл need_more/done с Z.AI, темп-каталог, консолидация."""

import json
import os
import shutil
import uuid
from typing import Any

from zai_coding_gateway.client import (
    chat_completions,
    create_client,
    get_fast_model,
    get_work_model,
)
from zai_coding_gateway.errors import (
    FilePathsRequiredError,
    InstructionTooLongError,
    ProjectRootNotSetError,
)
from zai_coding_gateway.tools.file_io import (
    get_project_root,
    glob_in_project,
    grep_in_project,
    list_dir_in_project,
    read_file_content,
    resolve_path,
)

# Консолидация: порог по токенам (приблизительно)
CONSOLIDATION_TRIGGER_TOKENS = 4000
CONSOLIDATION_KEEP_MESSAGES = 5
TRIM_TOKENS_TO_SUMMARIZE = 4000
SUMMARY_PREFIX = "Previous context (summarized):"
WORKSPACE_SESSIONS_DIR = "workspace_sessions"
WORKSPACE_SESSIONS_LOGS_DIR = "workspace_sessions_logs"

MAX_TOOL_ROUNDS = 5

# Состояния сессий, ожидающих ответа архитектора (вопрос по корню проекта или вопрос от модели).
_session_states: dict[str, dict[str, Any]] = {}

SYSTEM_WORKSPACE_BASE = """You are a coding assistant in a workspace session. You receive an instruction and file contents. You must respond with valid JSON only, no markdown.

Reply with one of four structures:

1) If you need to explore the project (list directory, search text, find files by mask, read a file) use tools:
{"status": "use_tools", "tool_calls": [{"tool": "list_dir", "path": "src"}, {"tool": "grep", "pattern": "def ", "path": "src"}, {"tool": "glob", "pattern": "*.py"}, {"tool": "read", "path": "path/to/file.py"}]}
- list_dir: path (optional, default ".") — list direct children of a directory (one level).
- grep: pattern (required), path (optional) — search in file contents under path or whole project.
- glob: pattern (required) — e.g. "*.py", "**/test_*.py" — list matching file paths.
- read: path (required) — get file content (result shown in Tool results; use need_more to add to session files if needed).

2) If you need more files added to the session context:
{"status": "need_more", "requested_paths": ["path/to/file1.py", "path/to/file2.py"], "reason": "brief reason"}

3) When you have enough context and have produced your solution:
{"status": "done", "report": "text report: analysis, conclusions, recommendations", "suggested_changes": [{"path": "path/to/file.py", "diff": "unified diff or full new content"}, ...]}

4) If you need to ask the architect a question (e.g. to add a file to session, or clarify something):
{"status": "question", "prompt": "Your question text here"}
The architect will reply via answer_session_question; the reply is then added to the next user message as "Architect answer: ...".

Rules:
- requested_paths and all paths in tool_calls must be relative to project root.
- In suggested_changes, the "path" field must be exactly one of the paths from the "Current session file paths" block below. Copy the path character-for-character; do not truncate or modify (e.g. use "package.json" not "package.").
- Use "diff" for unified diff when possible, or full file content if simpler.
"""


def _build_system_content(
    instruction: str,
    todos: list[str],
    allowed_paths: list[str],
) -> str:
    """
    System: стабильная часть — роль, формат, инструкция, TODOs, пути сессии.
    Не суммаризируется; передаётся заново при каждом запросе. Всё переменное — в user.
    """
    parts = [SYSTEM_WORKSPACE_BASE]
    parts.append("Instruction (the task to accomplish):\n" + instruction)
    parts.append("TODOs (complete as requested):\n" + "\n".join("- " + t for t in todos))
    parts.append(
        "Current session file paths — use exactly one of these in suggested_changes.path (copy as-is):\n"
        + "\n".join(allowed_paths)
    )
    return "\n\n".join(parts)

SUMMARY_PROMPT_TEMPLATE = """Summarize the following conversation segment. Preserve: what was decided, what files were discussed, what is left to do. Output only the summary, no preamble. Conversation:
{messages}"""


def _approx_tokens(text: str) -> int:
    """Приблизительный подсчёт токенов (~4 символа на токен)."""
    return max(0, len(text) // 4)


def _get_workspace_sessions_root(project_root: str | None = None) -> str:
    """Корень каталога сессий: project_root/workspace_sessions. project_root по умолчанию — get_project_root()."""
    root = project_root if project_root is not None else get_project_root()
    return os.path.join(root, WORKSPACE_SESSIONS_DIR)


def _get_session_logs_root() -> str:
    """
    Каталог для логов сессий. По умолчанию — проект gateway (чтобы разработчики видели результаты).
    Если задана ZAI_SESSION_LOGS_DIR — туда (чтобы пользователь мог получать логи в свой проект по желанию).
    """
    env_dir = os.environ.get("ZAI_SESSION_LOGS_DIR", "").strip()
    if env_dir:
        return os.path.abspath(env_dir)
    # По умолчанию: рядом с пакетом (repo root при разработке, или site-packages при установке)
    import zai_coding_gateway

    pkg_dir = os.path.dirname(os.path.abspath(zai_coding_gateway.__file__))
    return os.path.abspath(os.path.join(pkg_dir, "..", "..", WORKSPACE_SESSIONS_LOGS_DIR))


def _get_session_log_path(session_id: str) -> str:
    """Путь к файлу лога сессии: <session_logs_root>/<session_id>.log."""
    logs_root = _get_session_logs_root()
    return os.path.join(logs_root, f"{session_id}.log")


def _open_session_log(session_id: str):  # noqa: ANN201
    """Создаёт каталог логов и открывает файл лога для дополнения. При ошибке возвращает None."""
    try:
        log_path = _get_session_log_path(session_id)
        os.makedirs(os.path.dirname(log_path), exist_ok=True)
        return open(log_path, "a", encoding="utf-8")
    except OSError:
        return None


def _session_log_write(log_file: Any, line: str) -> None:
    """Пишет строку в лог сессии. При ошибке молча пропускает (не ломает флоу)."""
    if log_file is None:
        return
    try:
        log_file.write(line)
        if not line.endswith("\n"):
            log_file.write("\n")
        log_file.flush()
    except OSError:
        pass


def _run_tool_calls(
    tool_calls: list[dict[str, Any]],
    root: str,
) -> tuple[str, list[str]]:
    """
    Выполняет предустановленные инструменты в пределах root. Возвращает (блок текста результатов, список ошибок).
    """
    results: list[str] = []
    errors: list[str] = []
    for i, call in enumerate(tool_calls):
        if not isinstance(call, dict):
            err = f"call_{i}: invalid (not a dict)"
            errors.append(err)
            results.append(f"{err}\n")
            continue
        tool = (call.get("tool") or "").strip().lower()
        path_arg = (call.get("path") or "").strip() or "."
        pattern_arg = (call.get("pattern") or "").strip()
        try:
            if tool == "list_dir":
                names = list_dir_in_project(path_arg, root)
                results.append(f"list_dir({path_arg!r}): {names!r}\n")
            elif tool == "grep":
                path_opt = path_arg if path_arg != "." else None
                out = grep_in_project(pattern_arg or "", path_opt, root)
                results.append(f"grep(pattern={pattern_arg!r}, path={path_opt!r}):\n{out}\n")
            elif tool == "glob":
                paths = glob_in_project(pattern_arg or "*", root)
                results.append(f"glob({pattern_arg!r}): {paths!r}\n")
            elif tool == "read":
                content = read_file_content(path_arg, root)
                preview = content[:2000] + "..." if len(content) > 2000 else content
                results.append(f"read({path_arg!r}):\n{preview}\n")
            else:
                err = f"call_{i}: unknown tool {tool!r}"
                errors.append(err)
                results.append(f"{err}\n")
        except Exception as e:
            err = f"call_{i}: {tool}({path_arg!r}, pattern={pattern_arg!r}): {e!s}"
            errors.append(err)
            results.append(f"{err}\n")
    return "".join(results), errors


def _session_dir(session_id: str, project_root: str | None = None) -> str:
    """Абсолютный путь к темп-каталогу сессии."""
    return os.path.join(_get_workspace_sessions_root(project_root), session_id)


def _ensure_session_dir(session_id: str, project_root: str | None = None) -> str:
    """Создаёт каталог сессии, возвращает путь."""
    path = _session_dir(session_id, project_root)
    os.makedirs(path, exist_ok=True)
    return path


def _add_file_to_session(session_dir: str, path: str, content: str) -> None:
    """Записывает файл в темп-каталог сессии (path — относительный)."""
    full = os.path.join(session_dir, path)
    os.makedirs(os.path.dirname(full) or ".", exist_ok=True)
    with open(full, "w", encoding="utf-8") as f:
        f.write(content)


def _list_session_paths(session_dir: str) -> set[str]:
    """Возвращает множество относительных путей файлов в каталоге сессии."""
    result: set[str] = set()
    root_real = os.path.realpath(session_dir)
    for dirpath, _dirnames, filenames in os.walk(session_dir):
        for name in filenames:
            full = os.path.join(dirpath, name)
            rel = os.path.relpath(full, session_dir)
            result.add(rel)
    return result


def _session_exists(session_id: str) -> bool:
    """Проверяет, что каталог сессии существует."""
    path = _session_dir(session_id)
    return os.path.isdir(path)


def _build_files_block(files: dict[str, str]) -> str:
    """Формирует блок «Files» для user-сообщения."""
    if not files:
        return ""
    parts = [f"File: {p}\n```\n{c}\n```" for p, c in sorted(files.items())]
    return "\n\n".join(parts)


def _build_user_content(
    files_block: str,
    summary_prefix: str | None = None,
    summary: str | None = None,
) -> str:
    """
    User: условная часть — содержимое файлов, суммаризованная история, ответы на вопросы.
    Результат консолидации/суммаризации подставляется только сюда, не в system.
    """
    parts: list[str] = []
    if summary_prefix and summary:
        parts.append(f"{summary_prefix}\n{summary}")
    parts.append("Files:\n" + (files_block or "(none)"))
    return "\n\n".join(parts)


def _run_summarization(client: Any, messages_to_summarize: str) -> str:
    """Вызов fast-модели для суммаризации фрагмента истории (по умолчанию glm-4.5-air)."""
    prompt = SUMMARY_PROMPT_TEMPLATE.format(messages=messages_to_summarize)
    resp = chat_completions(
        client,
        [{"role": "user", "content": prompt}],
        model=get_fast_model(),
        response_format=None,
    )
    content = (resp.get("choices") or [{}])[0].get("message", {}).get("content") or ""
    return content.strip()


def _maybe_consolidate(
    client: Any,
    instruction: str,
    files_block: str,
    assistant_messages: list[str],
) -> tuple[str, list[str]]:
    """
    Если история длинная — суммаризировать старые ответы, оставить последние K.
    Возвращает (new_user_content, kept_assistant_messages).
    """
    if len(assistant_messages) <= CONSOLIDATION_KEEP_MESSAGES:
        return _build_user_content(files_block), assistant_messages

    to_keep = assistant_messages[-CONSOLIDATION_KEEP_MESSAGES:]
    to_summarize = assistant_messages[: -CONSOLIDATION_KEEP_MESSAGES]
    blob = "\n\n".join(to_summarize)
    tokens = _approx_tokens(blob)
    if tokens > TRIM_TOKENS_TO_SUMMARIZE:
        max_chars = TRIM_TOKENS_TO_SUMMARIZE * 4
        blob = blob[-max_chars:]
    summary = _run_summarization(client, blob)
    new_user = _build_user_content(files_block, SUMMARY_PREFIX, summary)
    return new_user, to_keep


def _run_solve_in_workspace(
    instruction: str,
    todos: list[str],
    file_paths: list[str],
    max_steps: int,
    project_root: str,
    session_id: str | None = None,
    resume_state: dict[str, Any] | None = None,
    answer: str | None = None,
) -> dict[str, Any]:
    """
    Внутренний цикл сессии: инициализация или восстановление из resume_state, затем цикл до done/question/break.
    Ответ архитектора (answer) при восстановлении подставляется в user-сообщение.
    """
    from zai_coding_gateway.errors import MAX_INSTRUCTION_CHARS

    root = project_root
    if resume_state and answer is not None:
        session_id = resume_state["session_id"]
        instruction = resume_state["instruction"]
        todos = resume_state["todos"]
        session_files = resume_state["session_files"].copy()
        assistant_messages = list(resume_state["assistant_messages"])
        files_block = resume_state["files_block"]
        system_content = resume_state["system_content"]
        step = resume_state["step"]
        tool_rounds = resume_state["tool_rounds"]
        need_more_count = resume_state["need_more_count"]
        tool_errors = list(resume_state["tool_errors"])
        session_dir = resume_state["session_dir"]
        user_content = _build_user_content(files_block) + "\n\nArchitect answer: " + answer
        report = resume_state.get("report", "")
        suggested_changes = list(resume_state.get("suggested_changes", []))
        log_file = _open_session_log(session_id)
    else:
        session_files = {}
        for path in file_paths:
            resolve_path(path, root)
            content = read_file_content(path, root)
            session_files[path] = content
        session_id = session_id or uuid.uuid4().hex
        session_dir = _ensure_session_dir(session_id, root)
        for path, content in session_files.items():
            _add_file_to_session(session_dir, path, content)
        log_file = _open_session_log(session_id)
        _session_log_write(
            log_file,
            f"[start] session_id={session_id} instruction_len={len(instruction)} file_paths={list(session_files.keys())!r}",
        )
        files_block = _build_files_block(session_files)
        session_paths = list(session_files.keys())
        system_content = _build_system_content(instruction, todos, session_paths)
        user_content = _build_user_content(files_block)
        assistant_messages = []
        report = ""
        suggested_changes = []
        step = 0
        tool_rounds = 0
        need_more_count = 0
        tool_errors = []

    client = create_client()

    while step < max_steps:
        total_tokens = _approx_tokens(instruction) + _approx_tokens(files_block)
        for m in assistant_messages:
            total_tokens += _approx_tokens(m)
        if total_tokens >= CONSOLIDATION_TRIGGER_TOKENS and assistant_messages:
            user_content, assistant_messages = _maybe_consolidate(
                client, instruction, files_block, assistant_messages,
            )

        messages: list[dict[str, str]] = [
            {"role": "system", "content": system_content},
            {"role": "user", "content": user_content},
        ]
        for content in assistant_messages:
            messages.append({"role": "assistant", "content": content})

        _session_log_write(log_file, f"[step {step}] request: messages_count={len(messages)}")

        resp = chat_completions(
            client,
            messages,
            model=get_work_model(),
            response_format={"type": "json_object"},
        )
        raw = (resp.get("choices") or [{}])[0].get("message", {}).get("content") or "{}"
        try:
            data = json.loads(raw)
        except json.JSONDecodeError:
            data = {"status": "need_more", "requested_paths": [], "reason": "Invalid JSON from model"}
        status = data.get("status", "")

        if status == "done":
            report = data.get("report", "")
            suggested_changes = data.get("suggested_changes") or []
            _session_log_write(
                log_file,
                f"[step {step}] response: status=done report_len={len(report)} suggested_changes_count={len(suggested_changes)}",
            )
            break

        if status == "question":
            _session_states[session_id] = {
                "phase": "awaiting_answer",
                "project_root": root,
                "session_id": session_id,
                "instruction": instruction,
                "todos": todos,
                "file_paths": list(session_files.keys()),
                "session_files": session_files,
                "assistant_messages": assistant_messages + [raw],
                "files_block": files_block,
                "system_content": system_content,
                "step": step,
                "tool_rounds": tool_rounds,
                "need_more_count": need_more_count,
                "tool_errors": tool_errors,
                "session_dir": session_dir,
                "max_steps": max_steps,
                "report": report,
                "suggested_changes": suggested_changes,
            }
            _session_log_write(log_file, f"[step {step}] response: status=question prompt_len={len(data.get('prompt', ''))}")
            try:
                if log_file is not None:
                    log_file.close()
            except OSError:
                pass
            return {"status": "question", "session_id": session_id, "prompt": data.get("prompt", "")}

        if status == "use_tools":
            tool_calls_raw = data.get("tool_calls") or []
            if not isinstance(tool_calls_raw, list):
                tool_calls_raw = []
            tool_calls_list = [c for c in tool_calls_raw if isinstance(c, dict)]
            if tool_rounds >= MAX_TOOL_ROUNDS:
                tool_results_text = "Tool round limit (5) reached. Proceed with need_more or done."
                round_errors = ["tool_rounds limit reached"]
                tool_errors.extend(round_errors)
            else:
                tool_results_text, round_errors = _run_tool_calls(tool_calls_list, root)
                tool_errors.extend(round_errors)
                tool_rounds += 1
            _session_log_write(
                log_file,
                f"[step {step}] response: status=use_tools tool_calls={tool_calls_list!r} results_len={len(tool_results_text)} errors={round_errors!r}",
            )
            assistant_messages.append(raw)
            user_content = _build_user_content(files_block) + "\n\nTool results:\n" + tool_results_text
            continue

        if status not in ("need_more", ""):
            _session_log_write(log_file, f"[step {step}] response: status={status!r} (unknown, treating as need_more)")
        requested = data.get("requested_paths") or []
        added_paths = []
        need_more_errors = []
        for path in requested:
            if path in session_files:
                continue
            try:
                resolve_path(path, root)
                content = read_file_content(path, root)
                session_files[path] = content
                _add_file_to_session(session_dir, path, content)
                added_paths.append(path)
            except Exception as e:
                need_more_errors.append(f"{path}: {e!s}")
        added_any = len(added_paths) > 0
        need_more_count += 1
        _session_log_write(
            log_file,
            f"[step {step}] response: status=need_more requested_paths={requested!r} added={added_paths!r} errors={need_more_errors!r}",
        )
        files_block = _build_files_block(session_files)
        system_content = _build_system_content(instruction, todos, list(session_files.keys()))
        assistant_messages.append(raw)
        step += 1
        if not added_any and requested:
            break

    _session_log_write(
        log_file,
        f"[summary] steps={step} tool_rounds={tool_rounds} need_more_count={need_more_count} "
        f"final_status={'done' if report else 'break'} tool_errors={tool_errors!r}",
    )
    try:
        if log_file is not None:
            log_file.close()
    except OSError:
        pass

    return {
        "session_id": session_id,
        "report": report,
        "suggested_changes": suggested_changes,
        "files_used": list(session_files.keys()),
    }


def solve_in_workspace(
    instruction: str,
    todos: list[str],
    file_paths: list[str],
    max_steps: int = 10,
) -> dict[str, Any]:
    """
    Запускает сессию: загружает file_paths в темп-каталог, цикл need_more/done/question с Z.AI.
    Если корень проекта не задан — возвращает status «question» с prompt про указание пути; ответ передаёте через answer_session_question.
    Возвращает session_id, report, suggested_changes, files_used либо status «question», session_id, prompt.
    """
    from zai_coding_gateway.errors import MAX_INSTRUCTION_CHARS

    if not file_paths:
        raise FilePathsRequiredError("file_paths required for this task")
    if len(instruction) > MAX_INSTRUCTION_CHARS:
        raise InstructionTooLongError(
            f"Instruction exceeds max size ({MAX_INSTRUCTION_CHARS} chars). Use file_paths for context."
        )

    try:
        root = get_project_root()
    except ProjectRootNotSetError:
        session_id = uuid.uuid4().hex
        _session_states[session_id] = {
            "phase": "awaiting_root",
            "instruction": instruction,
            "todos": todos,
            "file_paths": file_paths,
            "max_steps": max_steps,
        }
        return {
            "status": "question",
            "session_id": session_id,
            "prompt": "Укажите абсолютный путь к корню проекта для этой сессии.",
        }

    return _run_solve_in_workspace(
        instruction, todos, file_paths, max_steps, project_root=root, session_id=None
    )


def answer_session_question(session_id: str, answer: str) -> dict[str, Any]:
    """
    Передаёт ответ архитектора на вопрос сессии и продолжает выполнение.
    Если сессия ожидала корень проекта — answer интерпретируется как абсолютный путь к корню.
    Если сессия ожидала ответ на вопрос модели — answer подставляется в контекст и цикл продолжается.
    """
    from zai_coding_gateway.errors import SessionNotFoundError

    state = _session_states.pop(session_id, None)
    if not state:
        raise SessionNotFoundError(f"Session not found or answer already submitted: {session_id!r}")
    phase = state.get("phase", "")
    answer_stripped = (answer or "").strip()
    if phase == "awaiting_root":
        if not answer_stripped:
            _session_states[session_id] = state
            raise ValueError("Ответ не должен быть пустым. Укажите абсолютный путь к корню проекта.")
        root_abs = os.path.abspath(answer_stripped)
        if not os.path.isdir(root_abs):
            _session_states[session_id] = state
            raise ValueError(f"Путь не является каталогом: {root_abs!r}")
        return _run_solve_in_workspace(
            state["instruction"],
            state["todos"],
            state["file_paths"],
            state.get("max_steps", 10),
            project_root=root_abs,
            session_id=session_id,
        )
    if phase == "awaiting_answer":
        return _run_solve_in_workspace(
            state["instruction"],
            state["todos"],
            state["file_paths"],
            state["max_steps"],
            project_root=state["project_root"],
            session_id=session_id,
            resume_state=state,
            answer=answer_stripped or answer,
        )
    _session_states[session_id] = state
    raise SessionNotFoundError(f"Unknown session phase: {phase!r}")


def confirm_session_done(session_id: str) -> dict[str, Any]:
    """
    Очищает темп-каталог сессии после принятия решения архитектором.
    Вызывать после apply_changes или при отказе от изменений.
    """
    from zai_coding_gateway.errors import SessionNotFoundError

    sessions_root = _get_workspace_sessions_root()
    session_path = _session_dir(session_id)
    root_real = os.path.realpath(sessions_root)
    path_real = os.path.realpath(session_path)
    if not path_real.startswith(root_real) or not os.path.isdir(session_path):
        raise SessionNotFoundError(f"Session not found or already cleaned: {session_id!r}")
    shutil.rmtree(session_path, ignore_errors=True)
    return {"session_id": session_id, "cleaned": True}


def apply_changes(
    session_id: str,
    changes: list[dict[str, str]],
    confirm_after: bool = True,
) -> dict[str, Any]:
    """
    Применяет утверждённые изменения к проекту: запись по path + content или path + diff.
    Пути проверяются только на нахождение внутри корня проекта (ZAI_PROJECT_ROOT); новые файлы разрешены.
    Каждое изменение обрабатывается отдельно: успешные — в applied, неудачи — в errors (path + причина).
    При confirm_after после вызова очищает сессию (confirm_session_done).
    """
    from zai_coding_gateway.errors import SessionNotFoundError
    from zai_coding_gateway.tools.file_io import read_file_content, write_file as write_file_impl

    root = get_project_root()
    session_path = _session_dir(session_id)
    if not os.path.isdir(session_path):
        raise SessionNotFoundError(f"Session not found: {session_id!r}")
    applied: list[str] = []
    errors: list[dict[str, str]] = []
    for ch in changes:
        path = (ch.get("path") or "").strip()
        if not path:
            continue
        norm_path = path.replace("\\", "/")
        try:
            resolve_path(norm_path, root)
        except Exception as e:
            errors.append({"path": norm_path, "error": str(e)})
            continue
        content = ch.get("content")
        diff = ch.get("diff")
        if content is not None:
            try:
                write_file_impl(path, content, root)
                applied.append(norm_path)
            except Exception as e:
                errors.append({"path": norm_path, "error": str(e)})
        elif diff:
            try:
                current = read_file_content(path, root)
            except FileNotFoundError:
                current = ""
            # Всегда пытаемся применить как unified diff (git diff начинается с "diff --git", не с "---").
            # Никогда не записываем сырой текст diff в файл — это ломает проект.
            new_content = _apply_unified_diff(current, diff)
            if new_content is not None:
                try:
                    write_file_impl(path, new_content, root)
                    applied.append(norm_path)
                except Exception as e:
                    errors.append({"path": norm_path, "error": str(e)})
            else:
                errors.append({"path": norm_path, "error": "Diff does not apply to current file state"})
        else:
            errors.append({"path": norm_path, "error": "Missing both content and diff"})
    if confirm_after:
        try:
            confirm_session_done(session_id)
        except Exception:
            pass
    return {"session_id": session_id, "applied": applied, "errors": errors, "cleaned": confirm_after}


def _apply_unified_diff(current: str, diff: str) -> str | None:
    """
    Применяет unified diff к current. Сначала пробует patch; для git-диффов (diff --git)
    при неудаче пробует git apply в темп-дереве. Никогда не записывает сырой diff в файл.
    Возвращает новое содержимое или None при ошибке.
    """
    import subprocess
    import tempfile

    content = _apply_unified_diff_patch(current, diff)
    if content is not None:
        return content
    return _apply_unified_diff_git_apply(current, diff)


def _apply_unified_diff_patch(current: str, diff: str) -> str | None:
    """Пробует применить через patch (unified diff)."""
    import subprocess
    import tempfile

    try:
        fd_orig, path_orig = tempfile.mkstemp(suffix=".txt", text=True)
        fd_patch, path_patch = tempfile.mkstemp(suffix=".patch", text=True)
        try:
            with os.fdopen(fd_orig, "w", encoding="utf-8") as f:
                f.write(current)
            with os.fdopen(fd_patch, "w", encoding="utf-8") as f:
                f.write(diff)
            result = subprocess.run(
                ["patch", "-s", path_orig, "-i", path_patch],
                capture_output=True,
                text=True,
                timeout=10,
            )
            if result.returncode != 0:
                return None
            with open(path_orig, encoding="utf-8") as f:
                return f.read()
        finally:
            try:
                os.unlink(path_orig)
            except OSError:
                pass
            try:
                os.unlink(path_patch)
            except OSError:
                pass
    except Exception:
        return None


def _apply_unified_diff_git_apply(current: str, diff: str) -> str | None:
    """
    Пробует применить через git apply в темп-директории (для диффов в формате git).
    Создаёт файл с current по пути из diff, инициализирует git, применяет патч, возвращает результат.
    """
    import subprocess
    import tempfile

    if not diff.strip().startswith("diff "):
        return None
    first_file = _first_file_from_git_diff(diff)
    if not first_file:
        return None
    try:
        with tempfile.TemporaryDirectory(prefix="zai_apply_") as tmpdir:
            target_path = os.path.join(tmpdir, first_file)
            os.makedirs(os.path.dirname(target_path) or ".", exist_ok=True)
            with open(target_path, "w", encoding="utf-8") as f:
                f.write(current)
            patch_file = os.path.join(tmpdir, "change.patch")
            with open(patch_file, "w", encoding="utf-8") as f:
                f.write(diff)
            subprocess.run(
                ["git", "init", "-q"],
                cwd=tmpdir,
                capture_output=True,
                timeout=5,
            )
            result = subprocess.run(
                ["git", "apply", "--allow-empty", "--whitespace=warn", patch_file],
                cwd=tmpdir,
                capture_output=True,
                text=True,
                timeout=10,
            )
            if result.returncode != 0:
                return None
            if not os.path.isfile(target_path):
                return None
            with open(target_path, encoding="utf-8") as f:
                return f.read()
    except Exception:
        return None


def _first_file_from_git_diff(diff: str) -> str | None:
    """Из заголовка git diff извлекает путь к первому файлу (b/path)."""
    for line in diff.splitlines():
        s = line.strip()
        if s.startswith("+++ b/"):
            return s[6:].strip()
    return None
