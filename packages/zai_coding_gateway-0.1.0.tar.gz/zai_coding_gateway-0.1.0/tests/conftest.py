"""Fixtures и моки для тестов."""

import os

import pytest
import respx


@pytest.fixture(autouse=True)
def env_zai_key(request: pytest.FixtureRequest, monkeypatch: pytest.MonkeyPatch) -> None:
    """Задаёт ZAI_API_KEY в тестах (без реального ключа). Для e2e не подменяем — там нужен реальный ключ из окружения."""
    if request.node.get_closest_marker("e2e"):
        return
    monkeypatch.setenv("ZAI_API_KEY", "test-key-for-tests")


@pytest.fixture
def coding_base_url() -> str:
    """Base URL Coding Plan endpoint для мока."""
    return "https://api.z.ai/api/coding/paas/v4"


@pytest.fixture
def mock_chat_completions(coding_base_url: str) -> respx.MockRouter:
    """Мок POST .../chat/completions. Использовать в тестах с respx.import respx."""
    with respx.mock(assert_all_called=False) as router:
        router.post(f"{coding_base_url}/chat/completions").mock(
            return_value=respx.MockResponse(
                200,
                json={
                    "id": "test",
                    "choices": [
                        {
                            "message": {
                                "role": "assistant",
                                "content": "def hello(): pass",
                            }
                        }
                    ],
                    "usage": {"prompt_tokens": 10, "completion_tokens": 5, "total_tokens": 15},
                },
            )
        )
        yield router
