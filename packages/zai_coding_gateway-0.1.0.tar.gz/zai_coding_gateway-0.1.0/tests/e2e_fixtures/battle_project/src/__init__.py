# Package for battle_project E2E fixtures.
