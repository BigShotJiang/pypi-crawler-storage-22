"""Простой калькулятор: add и mul."""


def add(a, b):
    return a + b


def mul(a, b):
    return a * b
