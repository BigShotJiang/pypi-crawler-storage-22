"""Точка входа: использует calc и выводит результат."""

from src.calc import add, mul

if __name__ == "__main__":
    print("2 + 3 =", add(2, 3))
    print("2 * 3 =", mul(2, 3))
