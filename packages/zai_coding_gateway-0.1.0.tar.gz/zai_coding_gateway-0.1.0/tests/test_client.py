"""Тесты client.py: успешный ответ, 401, quota exceeded, base_url."""

import os

import pytest
import respx
from openai import OpenAI

from zai_coding_gateway.client import (
    DEFAULT_BASE_URL,
    DEFAULT_FAST_MODEL,
    DEFAULT_WORK_MODEL,
    chat_completions,
    create_client,
    get_fast_model,
    get_work_model,
)
from zai_coding_gateway.errors import QuotaExceededError


def test_create_client_requires_key(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.delenv("ZAI_API_KEY", raising=False)
    with pytest.raises(ValueError, match="ZAI_API_KEY не задан"):
        create_client()


def test_create_client_uses_env_base_url(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("ZAI_API_KEY", "k")
    monkeypatch.setenv("ZAI_BASE_URL", "https://custom.example/v4")
    client = create_client()
    assert client.base_url is not None
    assert "custom.example" in str(client.base_url)
    assert "coding" not in str(client.base_url)


def test_create_client_default_base_url(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("ZAI_API_KEY", "k")
    monkeypatch.delenv("ZAI_BASE_URL", raising=False)
    client = create_client()
    assert client.base_url is not None
    assert "api.z.ai" in str(client.base_url)
    assert "coding" in str(client.base_url)


def test_get_work_model_default(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.delenv("ZAI_WORK_MODEL", raising=False)
    assert get_work_model() == DEFAULT_WORK_MODEL
    assert get_work_model() == "glm-4.7"


def test_get_work_model_from_env(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("ZAI_WORK_MODEL", "custom-work")
    assert get_work_model() == "custom-work"


def test_get_fast_model_default(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.delenv("ZAI_FAST_MODEL", raising=False)
    assert get_fast_model() == DEFAULT_FAST_MODEL
    assert get_fast_model() == "glm-4.5-air"


def test_get_fast_model_from_env(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("ZAI_FAST_MODEL", "custom-fast")
    assert get_fast_model() == "custom-fast"


@respx.mock
def test_chat_completions_success() -> None:
    respx.post(f"{DEFAULT_BASE_URL.rstrip('/')}/chat/completions").mock(
        return_value=respx.MockResponse(
            200,
            json={
                "choices": [{"message": {"role": "assistant", "content": "Hi"}}],
                "usage": {},
            },
        )
    )
    client = OpenAI(api_key="k", base_url=DEFAULT_BASE_URL.rstrip("/") + "/")
    out = chat_completions(client, [{"role": "user", "content": "Hi"}], model="glm-4.7")
    assert out["choices"][0]["message"]["content"] == "Hi"
    assert respx.calls.call_count == 1
    assert "api.z.ai" in str(respx.calls.last.request.url)
    assert "coding" in str(respx.calls.last.request.url)


@respx.mock
def test_chat_completions_429_raises_quota_exceeded() -> None:
    respx.post(f"{DEFAULT_BASE_URL.rstrip('/')}/chat/completions").mock(
        return_value=respx.MockResponse(429, json={"error": {"message": "quota exceeded"}})
    )
    client = OpenAI(api_key="k", base_url=DEFAULT_BASE_URL.rstrip("/") + "/")
    with pytest.raises(QuotaExceededError, match="QuotaExceeded: wait for refresh cycle"):
        chat_completions(client, [{"role": "user", "content": "Hi"}], model="glm-4.7")
