"""E2E-тесты: вызов инструментов с реальным Z.AI API. Запускать только при заданном ZAI_API_KEY."""

import os

import pytest

from zai_coding_gateway.tools.solve_in_workspace import solve_in_workspace


def _e2e_battle_root() -> str:
    return os.path.abspath(
        os.path.join(os.path.dirname(__file__), "e2e_fixtures", "battle_project")
    )


@pytest.mark.e2e
@pytest.mark.skipif(not os.environ.get("ZAI_API_KEY"), reason="ZAI_API_KEY not set")
def test_solve_in_workspace_e2e(monkeypatch: pytest.MonkeyPatch) -> None:
    """Один вызов solve_in_workspace к реальному API; проверка структуры ответа."""
    root = _e2e_battle_root()
    if not os.path.isdir(root) or not os.path.isfile(os.path.join(root, "src", "calc.py")):
        pytest.skip("e2e_fixtures/battle_project not found")
    monkeypatch.setenv("ZAI_PROJECT_ROOT", root)
    result = solve_in_workspace(
        instruction="Кратко опиши, что делает этот файл. Ответь status done с report в одно предложение, suggested_changes пустой.",
        todos=[],
        file_paths=["src/calc.py"],
        max_steps=3,
    )
    assert "session_id" in result
    assert "report" in result
    assert "suggested_changes" in result
    assert "files_used" in result
    assert isinstance(result["session_id"], str)
    assert isinstance(result["suggested_changes"], list)
    assert isinstance(result["files_used"], list)
