"""
Боевой E2E: отдельная папка (battle_project), solve_in_workspace и доступ к файлам.
Проверка структуры ответа. Требует ZAI_API_KEY.
"""

import os

import pytest

from zai_coding_gateway.tools.file_io import read_file
from zai_coding_gateway.tools.solve_in_workspace import solve_in_workspace


def _battle_project_root() -> str:
    """Абсолютный путь к папке тестового проекта."""
    return os.path.abspath(
        os.path.join(os.path.dirname(__file__), "e2e_fixtures", "battle_project")
    )


@pytest.mark.e2e
@pytest.mark.skipif(not os.environ.get("ZAI_API_KEY"), reason="ZAI_API_KEY not set")
def test_battle_read_file_and_structure(monkeypatch: pytest.MonkeyPatch) -> None:
    """Доступ к файлам проекта по пути из battle_project; проверка содержимого."""
    monkeypatch.setenv("ZAI_PROJECT_ROOT", _battle_project_root())
    result = read_file("src/calc.py")
    assert "content" in result
    assert result["path"] == "src/calc.py"
    assert "def add" in result["content"]
    assert "def mul" in result["content"]


@pytest.mark.e2e
@pytest.mark.skipif(not os.environ.get("ZAI_API_KEY"), reason="ZAI_API_KEY not set")
def test_battle_solve_in_workspace_structure(monkeypatch: pytest.MonkeyPatch) -> None:
    """solve_in_workspace с file_paths из battle_project; проверка полей ответа."""
    monkeypatch.setenv("ZAI_PROJECT_ROOT", _battle_project_root())
    result = solve_in_workspace(
        instruction="Опиши в одном предложении, что делают функции в файле. Ответь status done, report — одно предложение, suggested_changes — пустой список.",
        todos=[],
        file_paths=["src/calc.py"],
        max_steps=5,
    )
    assert "session_id" in result
    assert "report" in result
    assert "suggested_changes" in result
    assert "files_used" in result
    assert result["files_used"] == ["src/calc.py"] or "src/calc.py" in result["files_used"]
