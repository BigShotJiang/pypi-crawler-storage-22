"""Тесты file_io: read_file, write_file, resolve_path."""

import os

import pytest

from zai_coding_gateway.errors import FileOutsideProjectError, ProjectRootNotSetError
from zai_coding_gateway.tools.file_io import (
    get_project_root,
    glob_in_project,
    grep_in_project,
    list_dir_in_project,
    read_file_content,
    resolve_path,
    write_file,
)


def test_get_project_root_uses_cwd(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.delenv("ZAI_PROJECT_ROOT", raising=False)
    root = get_project_root()
    assert os.path.isabs(root)
    assert os.path.isdir(root)


def test_get_project_root_uses_env(monkeypatch: pytest.MonkeyPatch, tmp_path: os.PathLike) -> None:
    monkeypatch.setenv("ZAI_PROJECT_ROOT", str(tmp_path))
    assert get_project_root() == os.path.abspath(str(tmp_path))


def test_get_project_root_cwd_root_raises(monkeypatch: pytest.MonkeyPatch) -> None:
    """При cwd=/ и без ZAI_PROJECT_ROOT и roots — ProjectRootNotSetError с подсказкой про ZAI_PROJECT_ROOT."""
    monkeypatch.delenv("ZAI_PROJECT_ROOT", raising=False)
    monkeypatch.setattr("zai_coding_gateway.tools.file_io._cached_mcp_project_root", None)
    monkeypatch.setattr("os.getcwd", lambda: "/")
    monkeypatch.setattr(
        "zai_coding_gateway.tools.file_io._infer_project_root_from_cwd",
        lambda: None,
    )
    with pytest.raises(ProjectRootNotSetError) as exc_info:
        get_project_root()
    assert "ZAI_PROJECT_ROOT" in str(exc_info.value)


def test_resolve_path_relative(tmp_path: os.PathLike) -> None:
    root = str(tmp_path)
    (tmp_path / "src").mkdir()
    (tmp_path / "src" / "foo.py").write_text("x", encoding="utf-8")
    resolved = resolve_path("src/foo.py", root)
    assert resolved == os.path.realpath(os.path.join(root, "src", "foo.py"))


def test_resolve_path_outside_raises(tmp_path: os.PathLike) -> None:
    root = str(tmp_path)
    with pytest.raises(FileOutsideProjectError):
        resolve_path("../../../etc/passwd", root)


def test_read_file_content(tmp_path: os.PathLike) -> None:
    monkeypatch = pytest.MonkeyPatch()
    monkeypatch.setenv("ZAI_PROJECT_ROOT", str(tmp_path))
    (tmp_path / "f.txt").write_text("hello", encoding="utf-8")
    content = read_file_content("f.txt", str(tmp_path))
    assert content == "hello"
    monkeypatch.undo()


def test_write_file_creates_file(tmp_path: os.PathLike) -> None:
    root = str(tmp_path)
    result = write_file("out.txt", "content", root)
    assert result["written"] is True
    assert result["path"] == "out.txt"
    assert (tmp_path / "out.txt").read_text(encoding="utf-8") == "content"


def test_write_file_creates_dirs(tmp_path: os.PathLike) -> None:
    root = str(tmp_path)
    write_file("a/b/c.txt", "x", root)
    assert (tmp_path / "a" / "b" / "c.txt").read_text(encoding="utf-8") == "x"


def test_list_dir_in_project(tmp_path: os.PathLike) -> None:
    root = str(tmp_path)
    (tmp_path / "a").mkdir()
    (tmp_path / "a" / "b").mkdir()
    (tmp_path / "a" / "c.txt").write_text("x", encoding="utf-8")
    (tmp_path / "d.py").write_text("y", encoding="utf-8")
    names = list_dir_in_project(".", root)
    assert "a" in names
    assert "d.py" in names
    names_a = list_dir_in_project("a", root)
    assert "b" in names_a
    assert "c.txt" in names_a


def test_list_dir_in_project_not_dir_raises(tmp_path: os.PathLike) -> None:
    root = str(tmp_path)
    (tmp_path / "f.txt").write_text("x", encoding="utf-8")
    with pytest.raises(NotADirectoryError):
        list_dir_in_project("f.txt", root)


def test_grep_in_project(tmp_path: os.PathLike) -> None:
    root = str(tmp_path)
    (tmp_path / "a.py").write_text("def foo():\n  pass", encoding="utf-8")
    (tmp_path / "b.py").write_text("def bar():", encoding="utf-8")
    out = grep_in_project("def ", None, root)
    assert "a.py" in out
    assert "b.py" in out
    assert "def " in out
    out_path = grep_in_project("def ", "a.py", root)
    assert "a.py" in out_path
    assert "def " in out_path


def test_glob_in_project(tmp_path: os.PathLike) -> None:
    root = str(tmp_path)
    (tmp_path / "x.py").write_text("", encoding="utf-8")
    (tmp_path / "y.py").write_text("", encoding="utf-8")
    (tmp_path / "z.txt").write_text("", encoding="utf-8")
    (tmp_path / "src").mkdir()
    (tmp_path / "src" / "m.py").write_text("", encoding="utf-8")
    paths = glob_in_project("*.py", root)
    assert "x.py" in paths
    assert "y.py" in paths
    assert "z.txt" not in paths
    paths_all = glob_in_project("**/*.py", root)
    assert "src/m.py" in paths_all
