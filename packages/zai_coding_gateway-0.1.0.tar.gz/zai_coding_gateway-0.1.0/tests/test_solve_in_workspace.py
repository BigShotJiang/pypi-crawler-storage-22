"""Тесты solve_in_workspace: валидация, confirm_session_done, apply_changes, use_tools."""

import os

import pytest
import respx

from zai_coding_gateway.client import DEFAULT_BASE_URL
from zai_coding_gateway.errors import (
    FilePathsRequiredError,
    InstructionTooLongError,
    SessionNotFoundError,
)
from zai_coding_gateway.tools.solve_in_workspace import (
    _run_tool_calls,
    apply_changes,
    confirm_session_done,
    solve_in_workspace,
)


def test_solve_in_workspace_empty_file_paths_raises() -> None:
    with pytest.raises(FilePathsRequiredError):
        solve_in_workspace(
            instruction="Do something",
            todos=["task"],
            file_paths=[],
        )


def test_solve_in_workspace_instruction_too_long_raises(monkeypatch: pytest.MonkeyPatch) -> None:
    from zai_coding_gateway.errors import MAX_INSTRUCTION_CHARS

    monkeypatch.setenv("ZAI_API_KEY", "test-key")
    long_instruction = "x" * (MAX_INSTRUCTION_CHARS + 1)
    with pytest.raises(InstructionTooLongError):
        solve_in_workspace(
            instruction=long_instruction,
            todos=["task"],
            file_paths=["README.md"],
        )


def test_confirm_session_done_invalid_session_raises() -> None:
    with pytest.raises(SessionNotFoundError):
        confirm_session_done("nonexistent-session-id-12345")


def test_apply_changes_invalid_session_raises() -> None:
    with pytest.raises(SessionNotFoundError):
        apply_changes("nonexistent-session-id-12345", [{"path": "a.py", "content": "x"}])


@pytest.mark.asyncio
async def test_solve_in_workspace_tool_registered() -> None:
    """Проверяем, что инструмент зарегистрирован в MCP."""
    from zai_coding_gateway.server import get_mcp

    mcp = get_mcp()
    names = [t.name for t in mcp._tool_manager.list_tools()]
    assert "solve_in_workspace" in names
    assert "answer_session_question" in names
    assert "confirm_session_done" in names
    assert "apply_changes" in names


def test_run_tool_calls_list_dir(tmp_path: os.PathLike) -> None:
    """_run_tool_calls выполняет list_dir и возвращает результат."""
    (tmp_path / "a").mkdir()
    (tmp_path / "a" / "f.txt").write_text("x", encoding="utf-8")
    root = str(tmp_path)
    text, errors = _run_tool_calls([{"tool": "list_dir", "path": "."}], root)
    assert "list_dir" in text
    assert "a" in text
    assert not errors


def test_run_tool_calls_unknown_tool(tmp_path: os.PathLike) -> None:
    """Неизвестный инструмент попадает в errors и в текст результата."""
    root = str(tmp_path)
    text, errors = _run_tool_calls([{"tool": "unknown_tool", "path": "."}], root)
    assert "unknown tool" in text.lower() or "unknown_tool" in text
    assert len(errors) == 1


@respx.mock
def test_solve_in_workspace_use_tools_then_done(
    monkeypatch: pytest.MonkeyPatch,
    tmp_path: os.PathLike,
) -> None:
    """При ответе use_tools затем done: второй запрос содержит Tool results с выводом list_dir."""
    monkeypatch.setenv("ZAI_PROJECT_ROOT", str(tmp_path))
    (tmp_path / "src").mkdir()
    (tmp_path / "src" / "main.py").write_text("print(1)", encoding="utf-8")
    (tmp_path / "src" / "main.py").resolve()

    url = f"{DEFAULT_BASE_URL.rstrip('/')}/chat/completions"
    first_response = {
        "choices": [
            {
                "message": {
                    "content": '{"status": "use_tools", "tool_calls": [{"tool": "list_dir", "path": "src"}]}',
                }
            }
        ],
        "usage": {},
    }
    second_response = {
        "choices": [
            {
                "message": {
                    "content": '{"status": "done", "report": "Done.", "suggested_changes": [{"path": "src/main.py", "diff": ""}]}',
                }
            }
        ],
        "usage": {},
    }
    respx.post(url).mock(side_effect=[
        respx.MockResponse(200, json=first_response),
        respx.MockResponse(200, json=second_response),
    ])

    result = solve_in_workspace(
        instruction="List src and then report.",
        todos=[],
        file_paths=["src/main.py"],
        max_steps=10,
    )

    assert result["report"] == "Done."
    assert respx.calls.call_count == 2
    second_body = respx.calls[1].request.content.decode("utf-8")
    assert "Tool results" in second_body
    assert "main.py" in second_body or "list_dir" in second_body


@respx.mock
def test_solve_in_workspace_tool_round_limit(
    monkeypatch: pytest.MonkeyPatch,
    tmp_path: os.PathLike,
) -> None:
    """После 5 раундов use_tools следующий запрос получает сообщение о лимите."""
    monkeypatch.setenv("ZAI_PROJECT_ROOT", str(tmp_path))
    (tmp_path / "f.py").write_text("x", encoding="utf-8")

    url = f"{DEFAULT_BASE_URL.rstrip('/')}/chat/completions"
    use_tools_content = '{"status": "use_tools", "tool_calls": [{"tool": "list_dir", "path": "."}]}'
    done_content = '{"status": "done", "report": "Done.", "suggested_changes": []}'
    responses = [
        respx.MockResponse(200, json={"choices": [{"message": {"content": use_tools_content}}], "usage": {}})
        for _ in range(6)
    ]
    responses.append(
        respx.MockResponse(200, json={"choices": [{"message": {"content": done_content}}], "usage": {}})
    )
    respx.post(url).mock(side_effect=responses)

    result = solve_in_workspace(
        instruction="Use tools then report.",
        todos=[],
        file_paths=["f.py"],
        max_steps=20,
    )

    assert result["report"] == "Done."
    bodies = [c.request.content.decode("utf-8") for c in respx.calls]
    limit_bodies = [b for b in bodies if "Tool round limit" in b or "limit (5) reached" in b]
    assert len(limit_bodies) >= 1
