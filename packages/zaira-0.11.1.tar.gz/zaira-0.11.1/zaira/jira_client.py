"""Jira client wrapper using the jira library."""

import sys
import tomllib
from functools import lru_cache
from pathlib import Path

from jira import JIRA
from platformdirs import user_cache_dir, user_config_dir

from zaira.project import load_config
from zaira.types import Credentials

CONFIG_DIR = Path(user_config_dir("zaira"))
CACHE_DIR = Path(user_cache_dir("zaira"))
CREDENTIALS_FILE = CONFIG_DIR / "credentials.toml"


def get_profile() -> str:
    """Get current profile name from zproject.toml."""
    config = load_config()
    return config.get("project", {}).get("profile", "default")


def get_schema_path(profile: str | None = None) -> Path:
    """Get path to instance schema file for a profile.

    Schema is cached globally at ~/.cache/zaira/zschema_PROFILE.json.
    """
    if profile is None:
        profile = get_profile()
    return CACHE_DIR / f"zschema_{profile}.json"


def get_project_schema_path(project: str, profile: str | None = None) -> Path:
    """Get path to project schema file.

    Project schema is cached at ~/.cache/zaira/zproject_PROFILE_PROJECT.json.
    """
    if profile is None:
        profile = get_profile()
    return CACHE_DIR / f"zproject_{profile}_{project}.json"


def get_server_from_config() -> str | None:
    """Get Jira server URL from credentials or zproject.toml."""
    # First check credentials file
    creds = load_credentials()
    site = creds.get("site")

    # Fall back to zproject.toml
    if not site:
        config = load_config()
        site = config.get("project", {}).get("site")

    if site:
        if not site.startswith("https://"):
            site = f"https://{site}"
        return site
    return None


def load_credentials() -> Credentials:
    """Load credentials from $XDG_CONFIG_HOME/zaira/credentials.toml."""
    if not CREDENTIALS_FILE.exists():
        return {}

    with open(CREDENTIALS_FILE, "rb") as f:
        return tomllib.load(f)


def save_credentials(email: str, api_token: str) -> None:
    """Save credentials to $XDG_CONFIG_HOME/zaira/credentials.toml."""
    CONFIG_DIR.mkdir(parents=True, exist_ok=True)

    content = f'email = "{email}"\napi_token = "{api_token}"\n'
    CREDENTIALS_FILE.write_text(content)

    # Secure the file
    CREDENTIALS_FILE.chmod(0o600)


def get_credentials() -> tuple[str, str, str]:
    """Get Jira credentials from config files.

    Server comes from zproject.toml, credentials from $XDG_CONFIG_HOME/zaira/credentials.toml.

    Returns:
        Tuple of (server_url, email, api_token)
    """
    server = get_server_from_config()
    creds = load_credentials()
    email = creds.get("email")
    token = creds.get("api_token")

    if not server or not email or not token:
        print(
            f"Error: Credentials not configured in {CREDENTIALS_FILE}", file=sys.stderr
        )
        print("\nRun 'zaira init' to set up credentials.", file=sys.stderr)
        sys.exit(1)

    return server, email, token


# Injected client for testing
_jira_client: JIRA | None = None


def get_jira() -> JIRA:
    """Get the JIRA client instance (cached or injected).

    Returns:
        Authenticated JIRA client
    """
    global _jira_client
    if _jira_client is not None:
        return _jira_client
    return _get_default_jira()


@lru_cache(maxsize=1)
def _get_default_jira() -> JIRA:
    """Create the default JIRA client from credentials.

    Returns:
        Authenticated JIRA client
    """
    server, email, token = get_credentials()
    return JIRA(server=server, basic_auth=(email, token))


def set_jira(client: JIRA | None) -> None:
    """Inject a JIRA client for testing. Pass None to reset."""
    global _jira_client
    _jira_client = client


def reset_jira() -> None:
    """Reset to default client and clear cache."""
    global _jira_client
    _jira_client = None
    _get_default_jira.cache_clear()


def get_server_url() -> str:
    """Get the Jira server URL."""
    server, _, _ = get_credentials()
    return server


def get_jira_site() -> str:
    """Get Jira site name (without https://)."""
    # First check credentials file
    creds = load_credentials()
    site = creds.get("site", "")

    # Fall back to zproject.toml
    if not site:
        config = load_config()
        site = config.get("project", {}).get("site", "")

    return site.replace("https://", "").replace("http://", "")
