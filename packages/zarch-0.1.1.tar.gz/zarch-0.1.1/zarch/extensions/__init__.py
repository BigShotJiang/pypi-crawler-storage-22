"""
Z-Arch Extensions Package
-----------------------------------------------
Public package surface for the Z-Arch extension system.

Core modules:
  - `base`     : extension base class and lifecycle hook contract
  - `context`  : stable `project_context` interface exposed to extensions
  - `policy`   : core-owned lifecycle execution locality policy
  - `registry` : extension discovery, claiming, and event dispatch

Extensions are installed as Python packages and discovered through the
`zarch.extensions` entry-point group. Z-Arch core owns execution policy and
dispatch semantics; extensions implement lifecycle behavior through this API.

Copyright © 2026 RAM Cloud Code LLC
Licensed under the Apache License, Version 2.0.
"""
