# zbuild-tools

A build system for embedded Linux based on Conan package manager.

## Features

- Cross-compilation support for RISC-V and ARM architectures
- Board management and testing
- Disk image generation and flashing
- System simulation with QEMU
- CI/CD integration

## Installation

```bash
pip install zbuild-tools
```

## Usage

```bash
# Build packages
zbuild build [package]

# Flash to board
zflash

# Run image
zrun

# Board management
board
```

## Requirements

- Python >= 3.8, <= 3.14
- Conan >= 1.66.3, < 2.0.0
- Docker (for containerized builds)

## License

See LICENSE file for details.
