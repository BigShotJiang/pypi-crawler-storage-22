# Custom Skills 目录

## 命名规范

**所有自定义 skills 必须使用 `zco-` 前缀**（Zhicheng Custom Operations）

### 示例

✅ **正确命名**：
- `zco-docs-update/` - 更新文档元信息
- `zco-plan/` - 执行开发计划
- `zco-deploy/` - 部署脚本（如果创建）
- `zco-backup/` - 备份工具（如果创建）

❌ **错误命名**：
- `docs-update/` - 缺少前缀
- `my-skill/` - 不符合规范
- `common/` - 不是有效 skill
- `utils/` - 不符合规范

## Skill 结构

每个 skill 必须遵循以下结构：

```
.claude/skills/
└── zco-{skill-name}/
    └── SKILL.md          # 必需：Skill 定义文件
```

### SKILL.md 格式

```markdown
---
name: zco-{skill-name}
description: Skill 的简短描述
allowed-tools: Bash, Read, Glob, Write, Edit
---

# Skill 标题

## 🎯 Skill 用途
简要说明这个 skill 的用途

## 📋 何时使用此 Skill
列出使用场景

## 🚀 使用步骤
详细的执行步骤

## 📝 示例
使用示例
```

## 当前可用 Skills

| Skill | 描述 | 版本 |
|-------|------|------|
| [zco-docs-update](zco-docs-update/SKILL.md) | 更新 CLAUDE.md 的 Git 元信息 | 1.0.0 |
| [zco-plan](zco-plan/SKILL.md) | 读取并执行 docs/plans/ 下的开发计划 | 1.0.0 |

## 创建新 Skill

### 步骤 1：创建目录结构

```bash
# 使用 zco- 前缀
mkdir -p .claude/skills/zco-{your-skill-name}
```

### 步骤 2：创建 SKILL.md

```bash
# 复制模板（可选）
cp .claude/skills/zco-plan/SKILL.md .claude/skills/zco-{your-skill-name}/SKILL.md

# 编辑文件
vim .claude/skills/zco-{your-skill-name}/SKILL.md
```

### 步骤 3：定义 YAML Front Matter

必需字段：
- `name` - Skill 名称（必须以 `zco-` 开头）
- `description` - 简短描述
- `allowed-tools` - 允许使用的工具列表

可选字段：
- `version` - 版本号
- `author` - 作者
- `tags` - 标签

### 步骤 4：编写 Skill 内容

参考现有 skills 的格式：
- 使用清晰的标题层次
- 包含使用示例
- 说明错误处理
- 提供故障排查指南

### 步骤 5：测试 Skill

```bash
# 在 Claude CLI 中测试
zco-{your-skill-name}

# 或在对话中测试
"运行 zco-{your-skill-name}"
```

## 最佳实践

### 命名

1. **使用清晰的名称**：`zco-plan` 优于 `zco-p`
2. **使用连字符**：`zco-docs-update` 优于 `zco_docs_update`
3. **避免缩写**：除非是众所周知的缩写
4. **保持简洁**：2-3 个单词最佳

### 功能设计

1. **单一职责**：每个 skill 只做一件事
2. **幂等性**：多次运行产生相同结果
3. **错误处理**：提供清晰的错误信息
4. **文档完整**：包含使用示例和故障排查

### 工具权限

只请求必需的工具：
- **只读操作**：`Bash, Read, Glob`
- **文件编辑**：添加 `Edit, Write`
- **网络访问**：添加 `WebFetch`（谨慎使用）

### 示例

```yaml
---
name: zco-backup
description: 备份指定目录到时间戳命名的归档
allowed-tools: Bash, Read, Glob
---
```

## 共享和分发

### 项目内共享

Skills 通过软链接自动共享到所有链接的项目：

```bash
# 链接配置到其他项目
./link-to-project.py /path/to/other/project

# Skills 自动可用
cd /path/to/other/project
zco-plan 001  # 可以直接使用
```

### 团队协作

1. **提交到 Git**：
   ```bash
   git add .claude/skills/zco-{skill-name}/
   git commit -m "feat: add zco-{skill-name} skill"
   ```

2. **Code Review**：确保 skill 符合规范

3. **更新文档**：在 CLAUDE.md 中添加 skill 说明

## 维护

### 更新现有 Skill

1. 修改 `SKILL.md` 文件
2. 更新版本号（如果有）
3. 测试功能
4. 提交更改

### 废弃 Skill

如果 skill 不再需要：

```bash
# 1. 添加废弃标记
# 在 SKILL.md 开头添加：
# ⚠️ **DEPRECATED**: 此 skill 已废弃，请使用 zco-new-skill 替代

# 2. 几个版本后删除
rm -rf .claude/skills/zco-old-skill/
```

## 故障排查

### Skill 无法识别

**问题**：Claude 无法识别 skill

**检查项**：
1. ✅ 目录名称以 `zco-` 开头
2. ✅ 存在 `SKILL.md` 文件（大写）
3. ✅ YAML front matter 格式正确
4. ✅ `name` 字段与目录名匹配

### Skill 执行失败

**问题**：Skill 执行过程中报错

**检查项**：
1. ✅ `allowed-tools` 包含所需工具
2. ✅ 权限配置允许操作
3. ✅ 文件路径正确
4. ✅ 依赖项已安装

## 参考资源

- **项目文档**：[CLAUDE.md](../../CLAUDE.md)
- **示例 Skill**：[zco-plan](zco-plan/SKILL.md)
- **计划管理**：[docs/plans/README.md](../../docs/plans/README.md)

---

**文档版本**: 1.0.0
**最后更新**: 2026-01-08
**维护者**: 开发团队
