# Zeabur Python SDK

A Python SDK for the Zeabur platform, generated from the GraphQL schema.

## Installation

You can install the SDK using pip:

```bash
pip install zeabur
```

## Usage

First, you need to obtain an API key from the Zeabur dashboard.

### Initialization

```python
from zeabur import Zeabur

# Initialize the client
client = Zeabur(api_key="YOUR_API_KEY")
```

### Async Usage

All methods in the SDK are asynchronous. You need to use `await` to call them.

```python
import asyncio
from zeabur import Zeabur

async def main():
    client = Zeabur(api_key="YOUR_API_KEY")

    # List projects
    projects = await client.projects()
    for edge in projects.edges:
        print(f"Project ID: {edge.node.id}, Name: {edge.node.name}")

if __name__ == "__main__":
    asyncio.run(main())
```

### Creating a Service

```python
from zeabur import Zeabur, ServiceTemplate

async def create_service():
    client = Zeabur(api_key="YOUR_API_KEY")

    project_id = "YOUR_PROJECT_ID"

    service = await client.create_service(
        name="my-service",
        template=ServiceTemplate.GIT,
        project_id=project_id,
        # ... other parameters
    )
    print(f"Created service: {service.id}")
```

## Development

1. Install dependencies:
   ```bash
   pip install -e .[test]
   ```

2. Generate operations and client code:
   ```bash
   python generate_operations.py
   ariadne-codegen
   ```

3. Run tests:
   ```bash
   pytest
   ```
