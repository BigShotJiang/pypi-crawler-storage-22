from setuptools import setup, find_packages
from pathlib import Path


README = (Path(__file__).parent / "README.md").read_text(encoding="utf-8")

setup(
    name="zeabur",
    version="0.1.1",
    description="A Python SDK for the Zeabur platform, generated from the GraphQL schema.",
    long_description=README,
    long_description_content_type="text/markdown",
    url="https://github.com/brucx/zeabur-python-sdk",
    project_urls={
        "Source": "https://github.com/brucx/zeabur-python-sdk",
        "Issues": "https://github.com/brucx/zeabur-python-sdk/issues",
    },
    python_requires=">=3.8",
    packages=find_packages("src"),
    package_dir={"": "src"},
    install_requires=[
        "httpx>=0.23.0",
        "pydantic>=2.0.0",
    ],
    extras_require={
        "test": ["pytest", "pytest-asyncio"],
    },
    keywords=["zeabur", "graphql", "sdk"],
    classifiers=[
        "Development Status :: 3 - Alpha",
        "Intended Audience :: Developers",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3 :: Only",
        "Operating System :: OS Independent",
    ],
)
