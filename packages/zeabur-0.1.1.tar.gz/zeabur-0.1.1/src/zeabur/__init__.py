from .client import ZeaburGraphQLClient
from .async_base_client import AsyncBaseClient
import httpx

class Zeabur(ZeaburGraphQLClient):
    def __init__(self, api_key: str, endpoint: str = "https://api.zeabur.com/graphql"):
        self.api_key = api_key
        self.endpoint = endpoint

        # Initialize the base client with endpoint and headers
        super().__init__(
            url=endpoint,
            headers={
                "Authorization": f"Bearer {api_key}"
            }
        )

__all__ = ["Zeabur", "ZeaburGraphQLClient"]
