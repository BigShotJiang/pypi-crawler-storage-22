import pytest
from zeabur import Zeabur

def test_zeabur_client_initialization():
    client = Zeabur(api_key="test_key")
    assert client.url == "https://gateway.zeabur.com/graphql"
    assert client.headers["Authorization"] == "Bearer test_key"

@pytest.mark.asyncio
async def test_zeabur_client_has_methods():
    client = Zeabur(api_key="test_key")
    # Check if a few generated methods exist
    assert hasattr(client, "projects")
    assert hasattr(client, "create_service")
