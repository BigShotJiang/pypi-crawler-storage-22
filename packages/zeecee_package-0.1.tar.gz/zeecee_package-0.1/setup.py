from setuptools import setup, find_packages

setup (
    name="zeecee_package",
    version='0.1', #remember to increment versions upon modification
    packages=find_packages(),
    install_requires = [
        #add dependencies here.
        # e.g. 'numpy>=1.11.1'
    ],
    #add this for CLI access
    entry_points={
        "console_scripts": [
            "zeecee-hello = zeecee_package:hello",
        ],
    },
)