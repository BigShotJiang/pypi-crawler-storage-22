import Zelium
import time

driver = Zelium.start()

Zelium.open("http://127.0.0.1:5000", driver)
time.sleep(2)

Zelium.alarm.accept()
time.sleep(2)

Zelium.js.quitar_readonly("//input[@id='fecha']")
time.sleep(2)

Zelium.js.set_value("//input[@id='nombre']", "Iván")

Zelium.js.scroll(300)

time.sleep(5)

driver.quit()