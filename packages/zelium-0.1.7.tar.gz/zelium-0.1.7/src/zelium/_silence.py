# zelium/_silence.py
import sys
import os
from contextlib import contextmanager


@contextmanager
def silence_stdout(enabled=True):
    if not enabled:
        yield
        return

    old_stdout = sys.stdout
    try:
        sys.stdout = open(os.devnull, "w")
        yield
    finally:
        sys.stdout.close()
        sys.stdout = old_stdout