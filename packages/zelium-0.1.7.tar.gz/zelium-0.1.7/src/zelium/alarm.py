# zelium/alarm.py
from selenium.common.exceptions import NoAlertPresentException, WebDriverException
from selenium.webdriver.remote.webdriver import WebDriver


class Alarm:
    _driver: WebDriver = None

    @classmethod
    def set_driver(cls, driver: WebDriver):
        cls._driver = driver

    @classmethod
    def _get_alert(cls):
        if cls._driver is None:
            print("[Error] Alarm: driver no asignado")
            return None

        try:
            return cls._driver.switch_to.alert
        except NoAlertPresentException:
            return None
        except WebDriverException:
            print("[WebDriverError] No se pudo acceder al alert")
            return None
        except Exception as e:
            print(f"[Error inesperado] _get_alert: error={type(e).__name__}")
            return None

    @classmethod
    def accept(cls):
        alert = cls._get_alert()
        if not alert:
            return False

        try:
            alert.accept()
            return True
        except Exception as e:
            print(f"[Error] accept(): error={type(e).__name__}")
            return False

    @classmethod
    def deny(cls):
        alert = cls._get_alert()
        if not alert:
            return False

        try:
            alert.dismiss()
            return True
        except Exception as e:
            print(f"[Error] deny(): error={type(e).__name__}")
            return False

    @classmethod
    def delete(cls):
        alert = cls._get_alert()
        if not alert:
            return None

        try:
            text = alert.text
            alert.accept()
            return text
        except Exception as e:
            print(f"[Error] delete(): error={type(e).__name__}")
            return None

    @classmethod
    def text(cls):
        alert = cls._get_alert()
        if not alert:
            return None

        try:
            return alert.text
        except Exception as e:
            print(f"[Error] text(): error={type(e).__name__}")
            return None