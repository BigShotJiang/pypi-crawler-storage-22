# zelium/helpers.py
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import TimeoutException, WebDriverException


def wait(driver, condition, timeout=5):
    try:
        return WebDriverWait(driver, timeout).until(condition)
    except TimeoutException:
        print(f"[Timeout] Condición no cumplida tras {timeout}s")
        return None
    except WebDriverException:
        print("[WebDriverError] Error del driver durante wait()")
        return None
    except Exception as e:
        print(f"[Error inesperado] wait(): error={type(e).__name__}")
        return None


def find(xpath, driver, timeout=5, visible=False):
    condition = (
        EC.visibility_of_element_located
        if visible else EC.presence_of_element_located
    )
    try:
        return wait(driver, condition((By.XPATH, xpath)), timeout)
    except Exception as e:
        print(f"[Error] find(): No se pudo localizar el elemento ({xpath}) error={type(e).__name__}")
        return None


def scroll(elem, driver):
    try:
        driver.execute_script(
            "arguments[0].scrollIntoView({block:'center'});", elem
        )
    except WebDriverException:
        print("[WebDriverError] No se pudo hacer scroll al elemento")
    except Exception as e:
        print(f"[Error inesperado] scroll(): error={type(e).__name__}")


def js_click(elem, driver):
    try:
        driver.execute_script("arguments[0].click();", elem)
    except WebDriverException:
        print("[WebDriverError] No se pudo hacer click por JS")
    except Exception as e:
        print(f"[Error inesperado] js_click(): error={type(e).__name__}")