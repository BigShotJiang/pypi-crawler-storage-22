# zelium/js.py
import logging
from selenium.common.exceptions import (
    JavascriptException,
    NoSuchElementException,
    TimeoutException,
    InvalidSelectorException,
)
from selenium.webdriver.remote.webdriver import WebDriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC

logger = logging.getLogger(__name__)


class JS:
    _driver: WebDriver = None

    @classmethod
    def set_driver(cls, driver: WebDriver):
        cls._driver = driver
        logger.debug("JS | driver asignado")

    @classmethod
    def execute(cls, script: str, *args):
        if cls._driver is None:
            raise RuntimeError("Driver no asignado. Usa JS.set_driver(driver)")
        logger.debug("JS.execute | ejecutando script")
        try:
            return cls._driver.execute_script(script, *args)
        except JavascriptException:
            logger.error("JS.execute | error=JavascriptException")
            return None
        except Exception as e:
            logger.error(f"JS.execute | error={type(e).__name__}")
            return None

    @classmethod
    def quitar_readonly(cls, xpath: str):
        if cls._driver is None:
            raise RuntimeError("Driver no asignado. Usa JS.set_driver(driver)")
        logger.debug(f"JS.quitar_readonly | xpath={xpath}")
        try:
            elemento = cls._driver.find_element(By.XPATH, xpath)
            cls._driver.execute_script(
                "arguments[0].removeAttribute('readonly')", elemento
            )
            logger.info(f"JS.quitar_readonly | ok xpath={xpath}")
            return True
        except InvalidSelectorException:
            logger.error(
                f"JS.quitar_readonly | xpath inválido xpath={xpath} error=InvalidSelectorException"
            )
            return False
        except NoSuchElementException:
            logger.warning(
                f"JS.quitar_readonly | no encontrado xpath={xpath} error=NoSuchElementException"
            )
            return False
        except JavascriptException:
            logger.error(
                f"JS.quitar_readonly | error=JavascriptException xpath={xpath}"
            )
            return False

    @classmethod
    def set_value(cls, xpath: str, value):
        if cls._driver is None:
            raise RuntimeError("Driver no asignado. Usa JS.set_driver(driver)")
        logger.debug(f"JS.set_value | xpath={xpath} value={value}")
        try:
            elemento = cls._driver.find_element(By.XPATH, xpath)
            cls._driver.execute_script(
                "arguments[0].value = arguments[1];", elemento, value
            )
            logger.info(f"JS.set_value | ok xpath={xpath}")
            return True
        except InvalidSelectorException:
            logger.error(
                f"JS.set_value | xpath inválido xpath={xpath} error=InvalidSelectorException"
            )
            return False
        except NoSuchElementException:
            logger.warning(
                f"JS.set_value | no encontrado xpath={xpath} error=NoSuchElementException"
            )
            return False
        except JavascriptException:
            logger.error(
                f"JS.set_value | error=JavascriptException xpath={xpath}"
            )
            return False

    @classmethod
    def establecer_fecha(cls, xpath: str, valor: str):
        if cls._driver is None:
            raise RuntimeError("Driver no asignado. Usa JS.set_driver(driver)")
        logger.debug(f"JS.establecer_fecha | xpath={xpath} valor={valor}")
        try:
            elemento = cls._driver.find_element(By.XPATH, xpath)
            cls._driver.execute_script(
                "arguments[0].removeAttribute('readonly')", elemento
            )
            cls._driver.execute_script(
                "arguments[0].value = arguments[1];", elemento, valor
            )
            cls._driver.execute_script(
                "arguments[0].dispatchEvent(new Event('change', { bubbles: true }));",
                elemento,
            )
            logger.info(f"JS.establecer_fecha | ok xpath={xpath}")
            return True
        except InvalidSelectorException:
            logger.error(
                f"JS.establecer_fecha | xpath inválido xpath={xpath} error=InvalidSelectorException"
            )
            return False
        except NoSuchElementException:
            logger.warning(
                f"JS.establecer_fecha | no encontrado xpath={xpath} error=NoSuchElementException"
            )
            return False
        except JavascriptException:
            logger.error(
                f"JS.establecer_fecha | error=JavascriptException xpath={xpath}"
            )
            return False

    @classmethod
    def agregar_clase_valid(cls, xpath=None, xpaths=None, timeout=5):
        if cls._driver is None:
            raise RuntimeError("Driver no asignado. Usa JS.set_driver(driver)")

        if not xpaths and not xpath:
            logger.error(
                "JS.agregar_clase_valid | error=MissingXPath"
            )
            return 0

        if xpaths is None:
            xpaths = [xpath]

        if not isinstance(xpaths, (list, tuple)):
            logger.error(
                f"JS.agregar_clase_valid | error=InvalidType xpaths_type={type(xpaths).__name__}"
            )
            return 0

        modificados = 0
        js = (
            "if (arguments[0]) { arguments[0].classList.add('valid'); "
            "return true; } return false;"
        )

        for xp in xpaths:
            logger.debug(f"JS.agregar_clase_valid | xpath={xp}")
            try:
                elemento = WebDriverWait(cls._driver, timeout).until(
                    EC.presence_of_element_located((By.XPATH, xp))
                )
                result = cls._driver.execute_script(js, elemento)
                if result:
                    modificados += 1
            except InvalidSelectorException:
                logger.error(
                    f"JS.agregar_clase_valid | xpath inválido xpath={xp} error=InvalidSelectorException"
                )
            except TimeoutException:
                logger.warning(
                    f"JS.agregar_clase_valid | timeout={timeout}s xpath={xp} error=TimeoutException"
                )
            except JavascriptException:
                logger.error(
                    f"JS.agregar_clase_valid | error=JavascriptException xpath={xp}"
                )
            except Exception as e:
                logger.error(
                    f"JS.agregar_clase_valid | error={type(e).__name__} xpath={xp}"
                )

        logger.info(
            f"JS.agregar_clase_valid | modificados={modificados}"
        )
        return modificados

    @classmethod
    def scroll(cls, valor):
        if cls._driver is None:
            raise RuntimeError("Driver no asignado. Usa JS.set_driver(driver)")
        logger.debug(f"JS.scroll | valor={valor}")
        try:
            cls._driver.execute_script(f"window.scrollBy(0, {valor});")
            logger.info("JS.scroll | ok")
            return True
        except JavascriptException:
            logger.error("JS.scroll | error=JavascriptException")
            return False
        except Exception as e:
            logger.error(f"JS.scroll | error={type(e).__name__}")
            return False