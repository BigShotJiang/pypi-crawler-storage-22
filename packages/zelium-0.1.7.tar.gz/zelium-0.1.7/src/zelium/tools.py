# zelium/tools.py
from selenium.common.exceptions import WebDriverException
import logging

logger = logging.getLogger(__name__)


def open(url, driver):
    logger.debug(f"open | url={url}")
    try:
        driver.get(url)
        logger.info(f"open | ok url={url}")
        return True
    except WebDriverException as e:
        logger.error(
            f"open | webdriver error url={url} error={type(e).__name__}"
        )
        return False
    except Exception as e:
        logger.error(
            f"open | unexpected error url={url} error={type(e).__name__}"
        )
        return False
    

def quit(driver):
    if driver is None:
        logger.warning("quit | driver is None, nothing to quit")
        return False

    try:
        driver.quit()
        logger.info("quit | driver closed successfully")
        return True
    except WebDriverException as e:
        logger.error(f"quit | webdriver error closing driver error={type(e).__name__}")
        return False
    except Exception as e:
        logger.error(f"quit | unexpected error closing driver error={type(e).__name__}")
        return False