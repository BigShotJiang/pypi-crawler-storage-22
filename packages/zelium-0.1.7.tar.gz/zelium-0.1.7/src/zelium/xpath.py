from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import Select
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import (
    JavascriptException,
    TimeoutException,
    ElementNotInteractableException,
    InvalidSelectorException,
)
from .helpers import wait, find, scroll, js_click
import time
import logging

logger = logging.getLogger(__name__)


def exist(xpath, driver, timeout=5):
    logger.debug(f"exist | xpath={xpath} timeout={timeout}")
    try:
        find(xpath, driver, timeout)
        logger.debug(f"exist | encontrado xpath={xpath}")
        return True
    except TimeoutException:
        logger.debug(f"exist | no encontrado xpath={xpath}")
        return False
    except InvalidSelectorException:
        logger.error(f"exist | xpath inválido xpath={xpath} error=InvalidSelectorException")
        return False


def get_text(xpath, driver, timeout=5):
    logger.debug(f"get_text | xpath={xpath} timeout={timeout}")
    try:
        elem = find(xpath, driver, timeout)
        text = elem.text
        logger.debug(f"get_text | texto='{text}' xpath={xpath}")
        return text
    except TimeoutException:
        logger.warning(f"get_text | timeout xpath={xpath}")
        return None
    except InvalidSelectorException:
        logger.error(f"get_text | xpath inválido xpath={xpath} error=InvalidSelectorException")
        return None


def click(xpath, driver, timeout=5):
    try:
        elem = wait(driver, EC.element_to_be_clickable((By.XPATH, xpath)), timeout)
        if elem is None:
            logger.error(f"[click] Elemento no encontrado: {xpath}")
            return False

        scroll(elem, driver)
        elem.click()
        return True

    except (TimeoutException, ElementNotInteractableException) as e:
        logger.warning(
            f"[click] Click normal falló en '{xpath}' error={type(e).__name__}. Intentando js_click."
        )
        try:
            elem = find(xpath, driver, timeout)
            if elem is None:
                logger.error(f"[click] js_click: Elemento no encontrado: {xpath}")
                return False

            scroll(elem, driver)
            js_click(elem, driver)
            return True
        except Exception as e2:
            logger.error(f"[click] js_click también falló en '{xpath}' error={type(e2).__name__}")
            return False


def send_keys(xpath, value, driver, timeout=5):
    logger.debug(f"send_keys | xpath={xpath} value={value} timeout={timeout}")

    if value is None:
        logger.warning(f"send_keys | value None xpath={xpath}")
        return False

    try:
        elem = find(xpath, driver, timeout, visible=True)
        scroll(elem, driver)
        elem.clear()
        elem.send_keys(value)
        logger.info(f"send_keys | send_keys ok xpath={xpath}")
        return True

    except InvalidSelectorException:
        logger.error(
            f"send_keys | xpath inválido xpath={xpath} error=InvalidSelectorException"
        )
        return False

    except (TimeoutException, ElementNotInteractableException) as e:
        logger.warning(
            f"send_keys | send_keys normal falló xpath={xpath} error={type(e).__name__}"
        )
        try:
            elem = find(xpath, driver, timeout)
            driver.execute_script(
                """
                arguments[0].value = arguments[1];
                arguments[0].dispatchEvent(new Event('input', {bubbles:true}));
                arguments[0].dispatchEvent(new Event('change', {bubbles:true}));
                """,
                elem,
                value,
            )
            logger.info(f"send_keys | js fallback ok xpath={xpath}")
            return True
        except InvalidSelectorException:
            logger.error(
                f"send_keys | js fallback xpath inválido xpath={xpath} error=InvalidSelectorException"
            )
            return False
        except Exception as e2:
            logger.error(
                f"send_keys | js fallback falló xpath={xpath} error={type(e2).__name__}"
            )
            return False


def select(xpath, buscar, driver, attr="value", timeout=5):
    logger.debug(
        f"select | xpath={xpath} buscar={buscar} attr={attr} timeout={timeout}"
    )
    try:
        elem = find(xpath, driver, timeout)
        scroll(elem, driver)

        sel = Select(elem)
        buscar = str(buscar)

        if attr == "value":
            sel.select_by_value(buscar)
        elif attr == "text":
            sel.select_by_visible_text(buscar)
        else:
            for option in sel.options:
                if option.get_attribute(attr) == buscar:
                    option.click()
                    break
            else:
                logger.warning(
                    f"select | opción no encontrada xpath={xpath} buscar={buscar}"
                )
                return False

        logger.info(f"select | selección ok xpath={xpath}")
        return True

    except InvalidSelectorException:
        logger.error(
            f"select | xpath inválido xpath={xpath} error=InvalidSelectorException"
        )
        return False

    except Exception as e:
        logger.error(
            f"select | fallo xpath={xpath} error={type(e).__name__}"
        )
        return False


def force_select_combobox(input_xpath, option_text, driver, timeout=5):
    logger.debug(
        f"force_select_combobox | input_xpath={input_xpath} option_text={option_text}"
    )
    try:
        input_elem = find(input_xpath, driver, timeout)
        scroll(input_elem, driver)
        input_elem.click()

        option_xpath = (
            f"//li[@role='option' and normalize-space(text())='{option_text}']"
        )
        option_elem = find(option_xpath, driver, timeout)

        scroll(option_elem, driver)
        js_click(option_elem, driver)

        logger.info(
            f"force_select_combobox | selección ok option_text={option_text}"
        )
        return True

    except InvalidSelectorException:
        logger.error(
            f"force_select_combobox | xpath inválido option_text={option_text} error=InvalidSelectorException"
        )
        return False

    except Exception as e:
        logger.error(
            f"force_select_combobox | fallo option_text={option_text} error={type(e).__name__}"
        )
        return False


def clear(xpath, driver, timeout=5):
    logger.debug(f"clear | xpath={xpath} timeout={timeout}")
    try:
        elem = find(xpath, driver, timeout)
        elem.clear()
        logger.info(f"clear | ok xpath={xpath}")
        return True
    except InvalidSelectorException:
        logger.error(
            f"clear | xpath inválido xpath={xpath} error=InvalidSelectorException"
        )
        return False
    except Exception as e:
        logger.error(
            f"clear | fallo xpath={xpath} error={type(e).__name__}"
        )
        return False


def delDisable(xpath, driver, timeout=5):
    logger.debug(f"delDisable | xpath={xpath} timeout={timeout}")
    try:
        elem = find(xpath, driver, timeout)
        driver.execute_script(
            """
            arguments[0].removeAttribute('readonly');
            arguments[0].removeAttribute('disabled');
            try { arguments[0].readOnly = false; } catch(e) {}
            """,
            elem,
        )
        time.sleep(0.3)
        elem.click()
        logger.info(f"delDisable | ok xpath={xpath}")
        return True

    except InvalidSelectorException:
        logger.error(
            f"delDisable | xpath inválido xpath={xpath} error=InvalidSelectorException"
        )
        return False

    except (TimeoutException, JavascriptException) as e:
        logger.error(
            f"delDisable | fallo xpath={xpath} error={type(e).__name__}"
        )
        return False