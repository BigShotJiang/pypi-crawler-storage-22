from __future__ import annotations
from typing import List
from ..ir.types import Instruction

# Conventions
# - Qubits are rendered top (q0) → bottom (q{n-1}) for readability.
# - Columns advance in time, one column per instruction (simple MVP).
# - Supported ops: x, sx, rz(theta), cx, measure.
# - For measure, we annotate the destination classical bit as M[c].
# - Little-endian execution still applies (this is only visualization).

CELL_W = 7  # width per column


def _empty_canvas(n_qubits: int, n_cols: int) -> List[List[str]]:
    rows = []
    for _ in range(n_qubits):
        row = ["─" * CELL_W for _ in range(n_cols)]
        rows.append(row)
    return rows


def _place_label(cell: str, label: str) -> str:
    # Center label within CELL_W using monospaced assumptions
    pad = max(0, CELL_W - len(label))
    left = pad // 2
    right = pad - left
    return " " * left + label + " " * right


def _rz_label(theta: float) -> str:
    # Keep it compact; 3 significant digits
    return f"rz({theta:.3g})"


def draw_ascii(n_qubits: int, instructions: List[Instruction]) -> str:
    n_cols = max(1, len(instructions))
    canvas = _empty_canvas(n_qubits, n_cols)

    # Helper to map logical qubit index to row (q0 at top)
    def row_of(q: int) -> int:
        return q  # q0 at row 0, q1 at row 1, ...

    for col, inst in enumerate(instructions):
        name, qs, ps, cs = inst.name, inst.qubits, inst.params, inst.clbits

        if name in ("x", "sx", "rz", "measure"):
            q = qs[0]
            r = row_of(q)
            match name:
                case "x":
                    canvas[r][col] = _place_label(canvas[r][col], "X")
                case "sx":
                    canvas[r][col] = _place_label(canvas[r][col], "SX")
                case "rz":
                    canvas[r][col] = _place_label(canvas[r][col], _rz_label(float(ps[0])))
                case "measure":
                    lbl = "M" if cs is None or len(cs) == 0 else f"M[{cs[0]}]"
                    canvas[r][col] = _place_label(canvas[r][col], lbl)
            # leave other rows in this column as wires
            continue

        if name == "cx":
            c, t = qs
            rc = row_of(c)
            rt = row_of(t)
            top, bot = sorted((rc, rt))
            # Place control and target symbols
            canvas[rc][col] = _place_label(canvas[rc][col], "●")  # control
            canvas[rt][col] = _place_label(
                canvas[rt][col], "X"
            )  # target (CNOT symbolized as X)
            # Draw vertical wire between them in this column
            for r in range(top + 1, bot):
                canvas[r][col] = _place_label(canvas[r][col], "│")
            continue

        if name == "ccx":
            c1, c2, t = qs
            rc1, rc2, rt = row_of(c1), row_of(c2), row_of(t)
            top, bot = min(rc1, rc2, rt), max(rc1, rc2, rt)
            canvas[rc1][col] = _place_label(canvas[rc1][col], "●")
            canvas[rc2][col] = _place_label(canvas[rc2][col], "●")
            canvas[rt][col] = _place_label(canvas[rt][col], "X")
            for r in range(top + 1, bot):
                if r not in (rc1, rc2, rt):
                    canvas[r][col] = _place_label(canvas[r][col], "│")
            continue

        if name == "cswap":
            c, t1, t2 = qs
            rc, rt1, rt2 = row_of(c), row_of(t1), row_of(t2)
            top, bot = min(rc, rt1, rt2), max(rc, rt1, rt2)
            canvas[rc][col] = _place_label(canvas[rc][col], "●")
            canvas[rt1][col] = _place_label(canvas[rt1][col], "×") # multiplication sign as swap
            canvas[rt2][col] = _place_label(canvas[rt2][col], "×")
            for r in range(top + 1, bot):
                if r not in (rc, rt1, rt2):
                    canvas[r][col] = _place_label(canvas[r][col], "│")
            continue

        # Unknown op: show as name
        for q in qs:
            r = row_of(q)
            canvas[r][col] = _place_label(canvas[r][col], name.upper())

    # Build header with qubit labels
    lines: List[str] = []
    for q in range(n_qubits):
        label = f"q{q}: "
        line = label + "".join(canvas[q])
        lines.append(line)

    return "\n".join(lines)
