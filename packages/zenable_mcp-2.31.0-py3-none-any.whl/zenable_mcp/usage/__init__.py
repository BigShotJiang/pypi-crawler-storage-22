"""Usage data management for zenable_mcp commands."""
