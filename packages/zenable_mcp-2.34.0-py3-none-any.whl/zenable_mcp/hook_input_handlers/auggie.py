"""Auggie hook input handler.

See: https://docs.augmentcode.com/cli/hooks#hook-input

Auggie supports hook events configured in ~/.augment/settings.json:
- SessionStart: Runs when a session starts (for checkpointing)
- Stop: Runs when the session ends (for conformance check)

Auggie sends JSON to stdin with fields including:
- hook_event_name: "SessionStart" | "Stop" | etc.
- conversation_id: unique conversation identifier
- workspace_roots: list of workspace root directories

Environment variables also provided as convenience:
AUGMENT_PROJECT_DIR, AUGMENT_CONVERSATION_ID, AUGMENT_HOOK_EVENT, AUGMENT_TOOL_NAME.
"""

import json
import os
import sys
from pathlib import Path
from typing import Any

from zenable_mcp.checkpoint.storage import CheckpointStorage
from zenable_mcp.exceptions import HandlerEnvironmentError
from zenable_mcp.exit_codes import ExitCode
from zenable_mcp.hook_input_handlers.base import (
    HookInputContext,
    HookInputFormat,
    InputHandler,
)
from zenable_mcp.logging.logged_echo import echo
from zenable_mcp.logging.persona import Persona
from zenable_mcp.utils.git import (
    capture_checkpoint_state,
    get_branch_changed_files,
    get_files_modified_since_checkpoint,
)


class AuggieInputHandler(InputHandler):
    """Handler for Auggie hook inputs.

    See: https://docs.augmentcode.com/cli/hooks#hook-input

    Supports the following hook events:
    - SessionStart: Runs when a session starts (checkpoint state)
    - Stop: Runs when session ends (review all modified files)

    Auggie sends hook data as JSON to stdin:
    {
        "hook_event_name": "SessionStart" | "Stop",
        "conversation_id": "unique-id",
        "workspace_roots": ["/path/to/workspace"],
        ...
    }

    Detection uses stdin as the primary mechanism. For events shared with
    other handlers (e.g. "Stop" overlaps with Claude Code), Auggie-specific
    stdin fields (workspace_roots) and env vars (AUGMENT_HOOK_EVENT)
    are used to disambiguate.

    Response format:
    - stdout text is added as context to the conversation
    - Exit code 0 for success, non-zero to indicate issues
    """

    SUPPORTED_EVENTS = {"SessionStart", "Stop"}

    def __init__(self, checkpoint_storage: CheckpointStorage | None = None):
        self._stdin_data: dict[str, Any] | None = None
        self._stdin_read: bool = False
        self._shared_stdin_provided: bool = False
        self._checkpoint_storage = checkpoint_storage or CheckpointStorage()
        self._modified_files: list[Path] = []

    def set_shared_stdin_data(self, data: dict[str, Any] | None) -> None:
        """Set shared stdin data from the registry."""
        self._stdin_data = data
        self._stdin_read = True
        self._shared_stdin_provided = True

    @property
    def name(self) -> str:
        return "Auggie"

    @property
    def format(self) -> HookInputFormat:
        return HookInputFormat.AUGGIE_HOOK

    # Events unique to Auggie (no overlap with other handlers)
    _UNIQUE_EVENTS = {"SessionStart"}
    # Events shared with other handlers (e.g. Claude Code also uses "Stop")
    _AMBIGUOUS_EVENTS = {"Stop"}

    def can_handle(self) -> bool:
        """Check if we're running as an Auggie hook.

        Uses stdin JSON as the primary detection mechanism:
        1. Check hook_event_name in stdin against supported events
        2. For unique events (SessionStart), claim immediately
        3. For ambiguous events (Stop, shared with Claude Code), disambiguate
           using Auggie-specific stdin fields (workspace_roots) or
           AUGMENT_HOOK_EVENT env var
        """
        stdin_data = self._read_stdin()
        if not stdin_data:
            # No stdin — check env var as last resort
            hook_event = os.environ.get("AUGMENT_HOOK_EVENT", "")
            if hook_event in self.SUPPORTED_EVENTS:
                echo(
                    f"Detected Auggie {hook_event} hook via AUGMENT_HOOK_EVENT env var (no stdin)",
                    persona=Persona.DEVELOPER,
                )
                return True
            return False

        hook_event = stdin_data.get("hook_event_name", "")
        if hook_event not in self.SUPPORTED_EVENTS:
            return False

        # Unique events — no disambiguation needed
        if hook_event in self._UNIQUE_EVENTS:
            echo(
                f"Detected Auggie {hook_event} hook via stdin (unique event)",
                persona=Persona.DEVELOPER,
            )
            return True

        # Ambiguous events — need Auggie-specific markers
        # Check for workspace_roots (Auggie-specific; Claude Code uses cwd)
        if "workspace_roots" in stdin_data:
            echo(
                f"Detected Auggie {hook_event} hook via stdin (workspace_roots present)",
                persona=Persona.DEVELOPER,
            )
            return True

        # Fall back to env var
        if os.environ.get("AUGMENT_HOOK_EVENT", "") == hook_event:
            echo(
                f"Detected Auggie {hook_event} hook via AUGMENT_HOOK_EVENT env var",
                persona=Persona.DEVELOPER,
            )
            return True

        return False

    def parse_input(self) -> HookInputContext:
        """Parse Auggie hook input from stdin and env vars.

        Handles different hook types:
        - SessionStart: Capture checkpoint state
        - Stop: Load checkpoint and find modified files
        """
        stdin_data = self._read_stdin() or {}

        # Get hook event from stdin first, fall back to env var
        hook_event = stdin_data.get(
            "hook_event_name", os.environ.get("AUGMENT_HOOK_EVENT", "")
        )

        # Get workspace from stdin workspace_roots (array), fall back to env var
        workspace_roots = stdin_data.get("workspace_roots", [])
        if workspace_roots and isinstance(workspace_roots, list):
            workspace_root = workspace_roots[0]
        else:
            workspace_root = os.environ.get("AUGMENT_PROJECT_DIR", "") or str(
                Path.cwd()
            )

        # Get conversation ID from stdin first, fall back to env var
        conversation_id = stdin_data.get(
            "conversation_id", os.environ.get("AUGMENT_CONVERSATION_ID", "")
        )
        if conversation_id:
            session_id = f"auggie-{conversation_id}"
        else:
            session_id = f"auggie-{hash(workspace_root) & 0xFFFFFFFF:08x}"

        if hook_event == "SessionStart":
            return self._parse_session_start(stdin_data, session_id, workspace_root)
        elif hook_event == "Stop":
            return self._parse_stop(stdin_data, session_id, workspace_root)
        else:
            raise HandlerEnvironmentError(
                "Auggie", f"Unsupported hook event: {hook_event}"
            )

    def _parse_session_start(
        self, stdin_data: dict[str, Any], session_id: str, workspace_root: str
    ) -> HookInputContext:
        """Handle SessionStart hook - capture checkpoint state."""
        self._log_checkpoint_event_start("SessionStart", workspace_root)

        base_path = Path(workspace_root) if workspace_root else None
        checkpoint = capture_checkpoint_state(
            base_path=base_path, session_id=session_id
        )
        self._checkpoint_storage.save(checkpoint)
        self._log_checkpoint_captured("SessionStart", len(checkpoint.dirty_files))

        return HookInputContext(
            format=self.format,
            raw_data=stdin_data,
            files=[],
            environment={
                "AUGMENT_HOOK_EVENT": "SessionStart",
                "AUGMENT_PROJECT_DIR": workspace_root,
            },
            metadata={
                "hook_event_name": "SessionStart",
                "checkpoint_saved": True,
            },
        )

    def _parse_stop(
        self, stdin_data: dict[str, Any], session_id: str, workspace_root: str
    ) -> HookInputContext:
        """Handle Stop hook - find modified files since checkpoint."""
        workspace = workspace_root or str(Path.cwd())
        self._log_checkpoint_event_start("Stop", workspace)

        base_path = Path(workspace)
        checkpoint = self._checkpoint_storage.load(workspace, session_id)

        if checkpoint:
            self._log_checkpoint_loaded(
                "Stop", len(checkpoint.dirty_files), checkpoint.head_commit
            )
            self._modified_files = get_files_modified_since_checkpoint(
                checkpoint, base_path
            )
            self._log_files_modified_since_checkpoint("Stop", len(self._modified_files))
            self._checkpoint_storage.delete(workspace, session_id)
            had_checkpoint = True
        else:
            self._log_no_checkpoint_fallback("Stop")
            self._modified_files = get_branch_changed_files(base_path)
            self._log_branch_diff_result("Stop", len(self._modified_files))
            had_checkpoint = False

        return HookInputContext(
            format=self.format,
            raw_data=stdin_data,
            files=self._modified_files,
            environment={
                "AUGMENT_HOOK_EVENT": "Stop",
                "AUGMENT_PROJECT_DIR": workspace_root,
            },
            metadata={
                "hook_event_name": "Stop",
                "had_checkpoint": had_checkpoint,
            },
        )

    def get_files(self) -> list[Path]:
        """Extract file paths from Auggie input."""
        context = self.parse_input()
        return context.files

    def build_response_to_hook_call(
        self, has_findings: bool, findings_text: str = ""
    ) -> str | None:
        """Build response for Auggie hook.

        Auggie adds stdout text as context to the conversation.
        For SessionStart, we return empty (checkpoint saved silently).
        For Stop, we return findings as plain text for the agent to see.
        """
        stdin_data = self._read_stdin() or {}
        hook_event = stdin_data.get(
            "hook_event_name", os.environ.get("AUGMENT_HOOK_EVENT", "")
        )

        if hook_event == "SessionStart":
            return ""

        if has_findings and findings_text:
            return findings_text
        return ""

    def get_exit_code(self, has_findings: bool) -> int:
        """Get the appropriate exit code for Auggie handler."""
        return ExitCode.CONFORMANCE_ISSUES_FOUND if has_findings else ExitCode.SUCCESS

    def is_checkpoint_only_event(self, context: HookInputContext) -> bool:
        """Check if this hook event only saves checkpoint state.

        SessionStart hooks save checkpoint and exit early - no conformance check.
        """
        hook_event = context.metadata.get("hook_event_name", "")
        return hook_event == "SessionStart"

    def _read_stdin(self) -> dict[str, Any] | None:
        """Read and parse JSON from stdin if available."""
        if self._stdin_read:
            return self._stdin_data

        self._stdin_read = True

        # Log relevant Auggie env vars
        self._log_relevant_env_vars(["AUGMENT_"])

        if sys.stdin.isatty():
            echo(
                "Error: stdin is a tty, not reading input",
                persona=Persona.DEVELOPER,
                err=True,
            )
            return None

        try:
            self._stdin_data = json.load(sys.stdin)
            if isinstance(self._stdin_data, dict):
                self._log_stdin_data(self._stdin_data)
                return self._stdin_data
        except (json.JSONDecodeError, IOError, OSError) as e:
            echo(
                f"Error: Failed to parse stdin as JSON: {e}",
                persona=Persona.DEVELOPER,
                err=True,
            )
            self._stdin_data = None

        return None
