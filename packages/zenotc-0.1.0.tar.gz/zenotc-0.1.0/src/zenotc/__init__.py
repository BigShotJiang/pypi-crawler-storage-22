"""
ZenOTC Python SDK for Algorithmic Trading.

This SDK provides a clean, production-ready interface to the ZenOTC OTC Trading Platform.
"""

from zenotc.client import AsyncZenOTCClient, ZenOTCClient
from zenotc.config import Config, Environment
from zenotc.exceptions import (
    AuthenticationError,
    InsufficientFundsError,
    OrderNotFoundError,
    QuoteNotFoundError,
    RateLimitError,
    ValidationError,
    ZenOTCError,
)

__version__ = "0.1.0"

__all__ = [
    # Main clients
    "ZenOTCClient",
    "AsyncZenOTCClient",
    # Configuration
    "Config",
    "Environment",
    # Exceptions
    "ZenOTCError",
    "AuthenticationError",
    "RateLimitError",
    "ValidationError",
    "InsufficientFundsError",
    "OrderNotFoundError",
    "QuoteNotFoundError",
]
