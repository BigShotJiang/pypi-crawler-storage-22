"""Base client class for ZenOTC SDK."""

from __future__ import annotations

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from zenotc.utils.http import HTTPClient
    from zenotc.utils.rate_limiter import RateLimiter
    from zenotc.utils.websocket import WebSocketClient


class BaseClient:
    """Base class for all API clients."""

    def __init__(
        self,
        http: HTTPClient,
        rate_limiter: RateLimiter,
        websocket: WebSocketClient,
    ) -> None:
        self._http = http
        self._rate_limiter = rate_limiter
        self._websocket = websocket

    async def _rate_limited_request(self, *args, **kwargs):
        """Make a rate-limited HTTP request."""
        await self._rate_limiter.acquire()
        return await self._http.request(*args, **kwargs)
