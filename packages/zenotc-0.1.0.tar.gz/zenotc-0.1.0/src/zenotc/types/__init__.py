"""Type definitions for ZenOTC SDK."""

from typing import Callable, Coroutine, Any, Dict

# Callback types
PriceCallback = Callable[[Dict[str, Any]], Coroutine[Any, Any, None]]
OrderBookCallback = Callable[[Dict[str, Any]], Coroutine[Any, Any, None]]
TradeCallback = Callable[[Dict[str, Any]], Coroutine[Any, Any, None]]

__all__ = [
    "PriceCallback",
    "OrderBookCallback",
    "TradeCallback",
]
