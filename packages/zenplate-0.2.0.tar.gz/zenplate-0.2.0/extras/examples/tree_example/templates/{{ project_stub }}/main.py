print(
    "Welcome to {{ project_name }}!\n Copyright '{{ project_author }}' {{ project_copyright }}."
)
