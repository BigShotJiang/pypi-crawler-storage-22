__author__ = "Kapil Sachdeva"
__application__ = "zephyr-shell"
__version__ = "0.0.1"
