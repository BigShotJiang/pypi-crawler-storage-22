import unittest
import torch
import torch.nn as nn
from safetensors.torch import save_file
import shutil
from pathlib import Path
import os
import numpy as np
from zero_brain import NeuroConverter
from zero_brain import BioRuntime

class TestBrainSemantics(unittest.TestCase):
    def setUp(self):
        self.test_dir = Path("test_brain_language")
        self.model_dir = self.test_dir / "knowledge_base"
        self.brain_dir = self.test_dir / "cortex"
        
        if self.test_dir.exists():
            shutil.rmtree(self.test_dir)
        self.model_dir.mkdir(parents=True)
        self.brain_dir.mkdir(parents=True)

        # 1. Simulating "Tens of Thousands of Words"
        self.vocab_size = 10000 
        self.hidden_dim = 256 # internal thought dimension
        
        print("\n📚 Encoding Knowledge (10,000 Words)...")
        
        # Create a simple "Association Matrix" (Question -> Answer)
        # We use a 2-layer MLP to simulate "Processing"
        # Layer 1: Encode Question
        # Layer 2: Decode Answer
        
        # We define a specific fact: "Word 1234" -> "Word 5678"
        self.q_id = 1234
        self.a_id = 5678
        
        # Create meaningful weights manually (not random)
        # W1 column q_id gets value 1.0
        w1 = torch.zeros(self.hidden_dim, self.vocab_size)
        w1[:, self.q_id] = 1.0 # When q_id comes in, activate all hidden
        
        # W2 row a_id gets value 1.0 from all hidden
        w2 = torch.zeros(self.vocab_size, self.hidden_dim)
        w2[self.a_id, :] = 1.0 # When hidden is active, boost a_id
        
        # Save as model
        # Rename to enforce alphabetical order in simple brain runtime
        tensors = {
            "layer01_encoder.weight": w1,
            "layer02_decoder.weight": w2
        }
        save_file(tensors, self.model_dir / "model.safetensors")
        print("   Knowledge encoded: 'Word 1234' implies 'Word 5678'")

    def test_semantic_recall(self):
        # 2. Neuro-Transformation
        print("\n🧠 Dispersing Knowledge into the Web...")
        converter = NeuroConverter(self.model_dir, self.brain_dir)
        converter.convert_to_brain()
        
        # Verify fragmentation
        # 10k*256 float32 = 10MB approx.
        # Chunk limit is usually smaller, so it should split.
        files = list(self.brain_dir.glob("*.pt"))
        print(f"   Knowledge scattered into {len(files)} shards.")
        
        # 3. Brain Inference
        print("\n🔮 Asking the Brain...")
        # Reduce RAM to prove we don't need the whole dictionary in memory
        runtime = BioRuntime(self.brain_dir, max_ram_gb=0.01) # 10MB limit
        
        # Create Input Vector (One-hot for word 1234)
        input_vec = torch.zeros(self.vocab_size)
        input_vec[self.q_id] = 10.0 # Strong signal
        
        # Run!
        print("   Injecting thought: 'Concept 1234'")
        output = runtime.think(input_vec)
        
        # 4. Verify Output
        # We expect a huge activation at index 5678 (The Answer)
        # Detailed Math Check:
        # Layer 1 (Encoder): Input[1234]=10. W[:,1234]=1. Hidden = [10, 10, ... 10] (Size 256)
        # Layer 2 (Decoder): Hidden=[10..]. W[5678,:]=1. Output[5678] = Sum(10 * 1 * 256) = 2560.
        
        max_val, max_idx = torch.max(output, dim=0)
        
        print(f"   Brain Output Max Signal: {max_val.item():.2f} at Index {max_idx.item()}")
        
        self.assertEqual(max_idx.item(), self.a_id, f"Brain failed to recall! Expected {self.a_id}, got {max_idx.item()}")
        self.assertTrue(max_val.item() > 2000, "Signal too weak!")
        
        print(f"✅  Semantic Recall Verified! The brain successfully associated Concept {self.q_id} -> {self.a_id} across {len(files)} shards.")


    def tearDown(self):
        if self.test_dir.exists():
            shutil.rmtree(self.test_dir)

if __name__ == '__main__':
    unittest.main()
