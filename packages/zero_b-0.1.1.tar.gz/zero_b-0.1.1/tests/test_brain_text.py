import unittest
import torch
from safetensors.torch import save_file
import shutil
from pathlib import Path
from zero_brain import NeuroConverter
from zero_brain import BioRuntime

class TestBrainText(unittest.TestCase):
    def setUp(self):
        self.test_dir = Path("test_brain_char")
        if self.test_dir.exists():
            shutil.rmtree(self.test_dir)
        self.model_dir = self.test_dir / "models"
        self.brain_dir = self.test_dir / "brain"
        self.model_dir.mkdir(parents=True)
        self.brain_dir.mkdir(parents=True)

        # 1. Define Micro-Vocab
        self.vocab = list("Hello World") 
        # unique chars: H, e, l, o, W, r, d, space
        self.chars = sorted(list(set(self.vocab)))
        self.char_to_id = {c: i for i, c in enumerate(self.chars)}
        self.id_to_char = {i: c for i, c in enumerate(self.chars)}
        self.vocab_size = len(self.chars)
        
        print(f"\n🔡 Vocab: {self.chars}")
        
        # 2. Encode Logic: "H" -> "e" -> "l" -> "l" -> "o"
        # We model this as a single layer: Input Char OneHot -> Output Char Logits
        # No hidden layer needed for simple mapping, but let's use 2 layers to match architecture.
        # Layer 1: Embed (Identity)
        # Layer 2: Predict
        
        # Target Sequence: H -> e
        src_char = 'H'
        tgt_char = 'e'
        src_idx = self.char_to_id[src_char]
        tgt_idx = self.char_to_id[tgt_char]
        
        hidden_dim = 16
        
        # W1 (Encoder): [16, Vocab]
        w1 = torch.zeros(hidden_dim, self.vocab_size)
        w1[:, src_idx] = 1.0 # Embed 'H' as [1.0, 1.0...]
        
        # W2 (Decoder): [Vocab, 16]
        w2 = torch.zeros(self.vocab_size, hidden_dim)
        w2[tgt_idx, :] = 1.0 # map hidden to 'e'
        
        # Save
        tensors = {
            "layer01_proj.weight": w1,
            "layer02_lm_head.weight": w2
        }
        save_file(tensors, self.model_dir / "model.safetensors")

    def test_char_prediction(self):
        # 2. Neuro-Surgery
        print("🧠 Converting Text Logic to Brain...")
        converter = NeuroConverter(self.model_dir, self.brain_dir)
        converter.convert_to_brain()
        
        # 3. Execution
        runtime = BioRuntime(self.brain_dir, max_ram_gb=0.1)
        
        # Input: 'H'
        src_char = 'H'
        print(f"🎤 Input: '{src_char}'")
        
        input_vec = torch.zeros(self.vocab_size)
        input_vec[self.char_to_id[src_char]] = 10.0
        
        # Think
        output_logits = runtime.think(input_vec)
        
        # Decode
        pred_idx = torch.argmax(output_logits).item()
        pred_char = self.id_to_char[pred_idx]
        confidence = output_logits[pred_idx].item()
        
        print(f"🗣️  Brain Output: '{pred_char}' (Signal Strength: {confidence:.2f})")
        
        self.assertEqual(pred_char, 'e', f"Expected 'e', got '{pred_char}'")
        print("✅ Correct! 'H' triggered 'e'.")
        
    def tearDown(self):
        if self.test_dir.exists():
            shutil.rmtree(self.test_dir)

if __name__ == '__main__':
    unittest.main()
