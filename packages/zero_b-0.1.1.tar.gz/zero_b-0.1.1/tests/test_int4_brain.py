import unittest
import torch
import torch.nn as nn
from safetensors.torch import save_file
import shutil
from pathlib import Path
import os
from zero_brain import NeuroConverter
from zero_brain import BioRuntime

class TestInt4Brain(unittest.TestCase):
    def setUp(self):
        # Setup fake model
        self.test_dir = Path("test_int4_brain_data")
        if self.test_dir.exists():
            shutil.rmtree(self.test_dir)
        self.test_dir.mkdir()
        
        self.model_path = self.test_dir / "raw_model"
        self.model_path.mkdir()
        
        # Create a linear layer
        self.linear = nn.Linear(1024, 1024)
        # Random weights
        
        # Must save as safetensors as per Blueprint requirement
        save_file(self.linear.state_dict(), self.model_path / "model.safetensors")
        self.brain_path = self.test_dir / "int4_brain"
        
    def tearDown(self):
        if self.test_dir.exists():
            shutil.rmtree(self.test_dir)

    def test_compression_ratio(self):
        # 1. Convert with INT4
        converter = NeuroConverter(self.model_path, self.brain_path, quantization_type="int4")
        converter.convert_to_brain()
        
        # Check file sizes
        # Original FP32: 1024*1024 * 4 bytes = 4MB
        # INT4: 4MB / 8 = 0.5MB (theoretical) + Scales
        
        # Blueprint: Files are in neurons/ subdirectory
        neurons_dir = self.brain_path / "neurons"
        neuron_files = list(neurons_dir.glob("*.pt"))
        total_size = sum(f.stat().st_size for f in neuron_files)
        
        print(f"Total INT4 Size: {total_size / 1024:.2f} KB")
        # Approx should be around 512KB + Overhead
        
        self.assertTrue(total_size < 2 * 1024 * 1024, "Brain should be compressed (< 2MB)")
        
        # 2. Run Inference (Check Dequantization works)
        runtime = BioRuntime(self.brain_path)
        input_signal = torch.randn(1024)
        
        output = runtime.think(input_signal)
        
        self.assertEqual(output.shape[0], 1024)
        print("Inference Successful.")

if __name__ == "__main__":
    unittest.main()
