import unittest
import torch
import torch.nn as nn
from safetensors.torch import save_file
import shutil
from pathlib import Path
import os
from zero_brain import NeuroConverter
from zero_brain import BioRuntime

class TestNeuroEngineReal(unittest.TestCase):
    def setUp(self):
        self.test_dir = Path("test_neuro_data")
        self.model_dir = self.test_dir / "raw_model"
        self.brain_dir = self.test_dir / "digital_brain"
        
        # Clean start
        if self.test_dir.exists():
            shutil.rmtree(self.test_dir)
        self.model_dir.mkdir(parents=True)
        self.brain_dir.mkdir(parents=True)
        
        # 1. Create a "Real" Dummy Model (Large enough to chunk)
        # 10 Layers of 512x512 = 512*512*10 ~= 2.6M parameters
        # Float32 = ~10MB.
        # Let's make it bigger to force chunking. 
        # Layer 2048x2048 = 4M params = 16MB.
        print("🏗️  Constructing Dummy 200B (Simulation)...")
        self.tensors = {}
        for i in range(5):
            # Create identifiable weights
            w = torch.randn(2048, 2048, dtype=torch.float32)
            self.tensors[f"layer_{i}.weight"] = w
            
        save_file(self.tensors, self.model_dir / "model.safetensors")
        print(f"📦  Model saved at {self.model_dir}")

    def test_end_to_end_brain(self):
        # 2. Neuro-Transformation
        print("\n🧠 Phase 1: Neuro-Transformation (The Surgery)")
        converter = NeuroConverter(self.model_dir, self.brain_dir)
        converter.convert_to_brain()
        
        # Check if files exist
        neurons_dir = self.brain_dir / "neurons"
        pt_files = list(neurons_dir.glob("n_*.pt"))
        print(f"   Sensitivity Analysis: Found {len(pt_files)} active neuron clusters.")
        self.assertTrue(len(pt_files) > 5, "Should have split layers into multiple neurons!")
        self.assertTrue((self.brain_dir / "brain_map.json").exists())
        
        # 3. Bio-Runtime Execution
        print("\n⚡ Phase 2: Bio-Inference (The Thinking)")
        # Limit RAM to extremely low to force Swapping (e.g. 1MB)
        # Note: A single neuron 256*256*2bytes = 128KB.
        # 1MB fits ~8 neurons.
        runtime = BioRuntime(self.brain_dir, max_ram_gb=0.005) # 5MB limit
        
        input_signal = torch.randn(2048, dtype=torch.float32) # Signal matching dim
        
        # "Think"
        # Since we mocked the logic in brain_kernel to just loop and load (without matric mult in loop shown in prev code)
        # We need to verify that 'think' completes and loads files.
        # We will spy on the active_memory
        
        print("   Injecting thought signal...")
        output = runtime.think(input_signal)
        
        # Verify Homeostasis
        print(f"   Active Memory Cells: {len(runtime.active_memory)}")
        print(f"   RAM Usage: {runtime._get_memory_usage() / 1024:.2f} KB")
        
        # The logic in 'think' iterates all layers.
        # With 5 layers * chunks, we have many neurons.
        # With 5MB limit, it should have evicted some.
        
        # Verify output is returned (even if just passed through as per current mock logic)
        self.assertIsNotNone(output)
        print("✅  Thinking Process Complete. Brain is stable.")

    def tearDown(self):
        # Cleanup
        if self.test_dir.exists():
            shutil.rmtree(self.test_dir)

if __name__ == '__main__':
    unittest.main()
