import torch
import torch.nn as nn
from pathlib import Path
import json
import logging
from tqdm import tqdm
import shutil
import gc

logger = logging.getLogger("ZERO_BRAIN")

class NeuroConverter:
    """
    Transforms a Dense Transformer Model (Local or HF) into a 'Neuro Synaptic Format'.
    Follows ZERO Blueprint:
    - Pruning (Sparsity)
    - Granular Disintegration (Neurons)
    - Metadata Mapping
    """
    
    def __init__(self, model_input, save_path, quantization_type="fp16", token=None, cache_dir=None, override_files=None):
        """
        Args:
            model_input (str or Path): Path to local model OR HuggingFace Repo ID.
            save_path (str or Path): Where to save the brain.
            quantization_type (str): "fp16", "int4", "fp32".
            override_files (dict): Map of filename -> local_path to replace default model files.
                                   e.g. {"chat_template.jinja": "/path/to/custom.jinja"}
        """
        self.model_input = model_input
        self.save_path = Path(save_path)
        self.quantization_type = quantization_type
        self.token = token
        self.cache_dir = cache_dir
        self.override_files = override_files or {}
        
        self.save_path.mkdir(parents=True, exist_ok=True)
        self.neurons_dir = self.save_path / "neurons"
        self.neurons_dir.mkdir(exist_ok=True)
        
        # Initialize Quantizer if needed
        self.quantizer = None
        if self.quantization_type == "int4":
             from ..compression.int4_quantizer import INT4Quantizer
             self.quantizer = INT4Quantizer()

    def _bundle_tokenizer(self, source_path):
        """
        Copies tokenizer and configuration files to the ZERO_B package.
        Supports overrides for custom templates/configs.
        """
        logger.info("   📦 Bundling Tokenizer & Configs...")
        
        # Standard files to look for
        targets = [
            "tokenizer.json", "tokenizer.model", "vocab.json", "merges.txt", 
            "special_tokens_map.json", "tokenizer_config.json", 
            "config.json", # Base config often needed for dim info
            "added_tokens.json",
            "chat_template.json", "chat_template.jinja" # Custom templates
        ]
        
        count = 0
        
        # 1. Process Overrides first
        for filename, custom_path in self.override_files.items():
            src = Path(custom_path)
            dst = self.save_path / filename
            if src.exists():
                logger.info(f"      🔹 Injecting Custom File: {filename}")
                shutil.copy2(src, dst)
                count += 1
            else:
                logger.warning(f"      ⚠️ Custom file not found: {src}")

        # 2. Process Defaults (if not overridden)
        for filename in targets:
            if filename in self.override_files:
                continue # Already handled
                
            src = source_path / filename
            dst = self.save_path / filename
            
            if src.exists():
                shutil.copy2(src, dst)
                count += 1
                
        logger.info(f"      Bundled {count} configuration files.")
        
    def convert_to_brain(self):
        logger.info(f"🧠 Initializing Neuro-Transformation Protocol (Precision: {self.quantization_type})...")
        
        model_path = Path(self.model_input)
        if not model_path.exists():
             logger.info(f"   ☁️  Source detected as Cloud Repo: {self.model_input}")
             from huggingface_hub import snapshot_download
             model_path = Path(snapshot_download(
                 repo_id=self.model_input,
                 cache_dir=self.cache_dir,
                 token=self.token,
                 allow_patterns=["*.safetensors", "*.json", "*.txt"]
             ))
             logger.info(f"   📂 Model downloaded to: {model_path}")

        safetensor_files = sorted(list(model_path.glob("*.safetensors")))
        bin_files = sorted(list(model_path.glob("*.bin")))
        
        synaptic_map = {
             "meta": {
                 "quantization": self.quantization_type,
                 "model_source": str(self.model_input)
             }
        }
        
        cluster_id = 0
        neuron_size_elements = 256 * 256
        
        logger.info("   ⚡ Disintegrating Dense Layers into Sparse Neuron Clusters.")
        
        # Parallel Writer
        from concurrent.futures import ThreadPoolExecutor, as_completed
        io_pool = ThreadPoolExecutor(max_workers=8) # 8 Writers
        futures = []
        
        def save_task(payload, n_name):
             self._save_neuron(payload, n_name)
             return n_name
        
        def process_synapses(state_dict_iterator):
            nonlocal cluster_id
            for key, tensor in tqdm(state_dict_iterator, desc="   Synapses (CPU -> Stream)"):
                    
                    # --- Blueprint Core: Lossless (User Request) ---
                    # No Pruning Threshold (0.0). 
                    # Only remove absolute dead weights if requested, but for "Lossless" we keep ALL.
                    # Unless user explicitly wanted compression.
                    is_weight = "weight" in key and tensor.dim() > 1
                    
                    # 1. Pruning (Optional/Disabled for Lossless)
                    # if is_weight: ... (Disabled)
                    
                    # 2. Quantization
                    scales = None
                    if self.quantization_type == "int4" and is_weight:
                         tensor = tensor.cpu()
                         q, s = self.quantizer.quantize_tensor(tensor)
                         packed = self.quantizer.pack_int4(q)
                         tensor = packed
                         scales = s
                    elif self.quantization_type == "fp16":
                         if tensor.dtype == torch.float32:
                            tensor = tensor.half()
                    
                    # 3. Chunking (Granular Disintegration)
                    # We chunk to ensure effective streaming on mobile RAM
                    chunks = self._chunk_tensor(tensor, neuron_size_elements if self.quantization_type != "int4" else neuron_size_elements // 2)
                    
                    scales_chunks = []
                    if scales is not None:
                         scale_chunk_size = neuron_size_elements // 128
                         scales_chunks = self._chunk_tensor(scales, scale_chunk_size)
                    
                    for i, chunk in enumerate(chunks):
                        neuron_name = f"n_{cluster_id:08d}"
                        
                        payload = chunk
                        if self.quantization_type == "int4" and is_weight:
                            if i < len(scales_chunks):
                                payload = {"packed": chunk, "scale": scales_chunks[i]}
                            else:
                                payload = {"packed": chunk, "scale": scales[-1:]}
                        
                        # Async Save
                        futures.append(io_pool.submit(save_task, payload, neuron_name))
                        
                        # Metadata (Lightweight)
                        strength = 0.5
                        if self.quantization_type != "int4":
                            # Sampling strength (Optimization: Don't scan entire chunk)
                            strength = float(chunk.ravel()[::100].float().abs().mean()) if chunk.numel() > 100 else float(chunk.float().abs().mean())
                            
                        synaptic_map[neuron_name] = {
                            "origin": key,
                            "part": i,
                            "strength": strength,
                            # "shape": list(chunk.shape) # Removing shape to save huge JSON size? No, keep it.
                        }
                        cluster_id += 1
                        
                    # Non-Weight Global vars
                    if not is_weight:
                        name = f"global_{key.replace('.', '_')}"
                        if tensor.dtype == torch.float32:
                             tensor = tensor.half()
                        futures.append(io_pool.submit(save_task, tensor, name))
                        synaptic_map[name] = {
                            "origin": key,
                            "type": "global"
                        }

        # Execution
        if safetensor_files:
            from safetensors import safe_open
            for st_file in safetensor_files:
                logger.info(f"   Processing (SafeTensors): {st_file.name}")
                with safe_open(st_file, framework="pt", device="cpu") as f:
                    iterator = ((k, f.get_tensor(k)) for k in f.keys())
                    process_synapses(iterator)
                gc.collect()
        elif bin_files:
             logger.info("   Processing (Legacy PyTorch Binaries)...")
             for bin_file in bin_files:
                 logger.info(f"   Loading: {bin_file.name}")
                 state_dict = torch.load(bin_file, map_location="cpu")
                 process_synapses(state_dict.items())
                 del state_dict
                 gc.collect()
        else:
             raise ValueError(f"No model files found in {model_path}")
             
        # Wait for IO
        logger.info(f"   ⏳ Finalizing IO ({len(futures)} clusters)...")
        for _ in tqdm(as_completed(futures), total=len(futures), desc="   Writing to Disk"):
             pass
        io_pool.shutdown()

        # Save Brain Map
        with open(self.save_path / "brain_map.json", "w") as f:
            json.dump(synaptic_map, f, indent=2)
            
        # 4. Bundle Tokenizer
        self._bundle_tokenizer(model_path)
        self._standardize_chat_format(model_path) # Move call here
            
        logger.info(f"✅ Neuro-Transformation Complete! Created {cluster_id} Synaptic Clusters.")
        logger.info("   Digital Brain is ready in 'neurons' folder.")

    def _bundle_tokenizer(self, source_path):
        """
        Copies tokenizer and configuration files to the ZERO_B package.
        This makes the Brain self-contained.
        """
        logger.info("   📦 Bundling Tokenizer & Configs...")
        
        # Standard files to look for
        targets = [
            "tokenizer.json", "tokenizer.model", "vocab.json", "merges.txt", 
            "special_tokens_map.json", "tokenizer_config.json", 
            "config.json", # Base config
            "added_tokens.json",
            "chat_template.json", "chat_template.jinja",
            
            # Multimodal & Agentic Configs
            "preprocessor_config.json", # Image/Video Input
            "generation_config.json",   # Decoding & Tools
            "image_processing_config.json",
            "processor_config.json",     # Omni-modal inputs
            "agent_config.json"          # Explicit Agent Definition
        ]
        
        count = 0
        
        # 1. Process Overrides first
        for filename, custom_path in self.override_files.items():
            src = Path(custom_path)
            dst = self.save_path / filename
            if src.exists():
                logger.info(f"      🔹 Injecting Custom File: {filename}")
                shutil.copy2(src, dst)
                count += 1
            else:
                logger.warning(f"      ⚠️ Custom file not found: {src}")

        # 2. Process Defaults
        for filename in targets:
            if filename in self.override_files:
                continue 
            src = source_path / filename
            dst = self.save_path / filename
            if src.exists():
                shutil.copy2(src, dst)
                count += 1
                
        logger.info(f"      Bundled {count} configuration files.")
        
        # 3. Standardize to ZERO_B Format
        self._standardize_chat_format(source_path)

    def _standardize_chat_format(self, source_path):
        """
        Extracts Chat Template and Agentic Capabilities.
        Target: 'zero_chat.json'
        
        Now enhanced to detect:
        - Reasoning/Thinking (<think>)
        - Math/Science/Coding proficiency (via config/keywords)
        - Tool Usage
        """
        logger.info("   🎨 Standardizing Chat Template & Capabilities (Thinking, Tools, Coding)...")
        
        config_path = source_path / "tokenizer_config.json"
        base_config_path = source_path / "config.json"
        
        zero_chat = {
            "template": None,
            "roles": ["user", "assistant", "system"],
            "special_tokens": {
                "think_start": "<think>", # Default for reasoning models
                "think_end": "</think>"
            },
            "capabilities": {
                "tool_call": False,
                "reasoning": False,      # CoT / DeepSeek R1 style
                "vision": False,
                "audio": False,
                "code_interpreter": False,
                "agent": False,
                "math": False,
                "coding": False
            }
        }
        
        # 0. Check Base Config for Architecture hints
        if base_config_path.exists():
             try:
                 with open(base_config_path, 'r') as f:
                     b_cfg = json.load(f).get("architectures", [])
                     b_content = str(json.load(open(base_config_path))).lower()
                     
                     if "moe" in b_content or "mixtureofexperts" in b_content:
                          # MoEs are often strong at long-tail knowledge
                          pass
                     if "deepseek" in b_content or "reasoning" in b_content:
                          zero_chat["capabilities"]["reasoning"] = True
                          zero_chat["capabilities"]["math"] = True
                          zero_chat["capabilities"]["coding"] = True
             except: pass

        # 1. Extract from Tokenizer Config
        if config_path.exists():
            try:
                with open(config_path, 'r') as f:
                    cfg = json.load(f)
                    
                # Template
                if "chat_template" in cfg and cfg["chat_template"]:
                    raw_tmpl = cfg["chat_template"]
                    if isinstance(raw_tmpl, str):
                        zero_chat["template"] = raw_tmpl
                        
                    # Capability Detection (Heuristic)
                    tmpl_str = str(raw_tmpl).lower()
                    
                    if "tool" in tmpl_str or "<|tool_calls|>" in str(raw_tmpl):
                        zero_chat["capabilities"]["tool_call"] = True
                        zero_chat["capabilities"]["agent"] = True
                        
                    if "interpreter" in tmpl_str:
                        zero_chat["capabilities"]["code_interpreter"] = True
                        zero_chat["capabilities"]["agent"] = True
                        zero_chat["capabilities"]["coding"] = True
                        
                    if "thought" in tmpl_str or "planning" in tmpl_str or "<think>" in str(raw_tmpl):
                        zero_chat["capabilities"]["agent"] = True
                        zero_chat["capabilities"]["reasoning"] = True
                        
                # Special Tokens extraction
                for k, v in cfg.items():
                    if "token" in k and isinstance(v, (str, dict)):
                        content = v.get("content", "") if isinstance(v, dict) else v
                        if content == "<think>":
                             zero_chat["special_tokens"]["think_start"] = content
                        if content == "</think>":
                             zero_chat["special_tokens"]["think_end"] = content
                             
                # Map standard ones
                for k in ["bos_token", "eos_token", "pad_token", "unk_token", "tool_use_token"]:
                    if k in cfg:
                        val = cfg[k]
                        if isinstance(val, dict):
                            val = val.get("content", "")
                        zero_chat["special_tokens"][k.replace("_token", "")] = val

            except Exception as e:
                logger.warning(f"      ⚠️ Failed to parse tokenizer_config: {e}")

        # 2. Check for Vision/Multimodal Configs
        if (source_path / "preprocessor_config.json").exists():
            zero_chat["capabilities"]["vision"] = True
            
        # 3. Fallback Template (Jinja File)
        jinja_path = source_path / "chat_template.jinja"
        if jinja_path.exists():
            with open(jinja_path, 'r') as f:
                 tmpl = f.read()
                 zero_chat["template"] = tmpl
                 if "tool" in tmpl.lower():
                     zero_chat["capabilities"]["tool_call"] = True
                 if "<think>" in tmpl:
                     zero_chat["capabilities"]["reasoning"] = True

        # 4. Universal Default
        if not zero_chat["template"]:
            logger.warning("      ⚠️ No chat template found. Applying ZERO_B Universal Default (ChatML).")
            zero_chat["template"] = "{% for message in messages %}{{'<|im_start|>' + message['role'] + '\n' + message['content'] + '<|im_end|>' + '\n'}}{% endfor %}{% if add_generation_prompt %}{{ '<|im_start|>assistant\n' }}{% endif %}"
            zero_chat["special_tokens"]["eos"] = "<|im_end|>"
            
        # 5. Save
        with open(self.save_path / "zero_chat.json", "w") as f:
            json.dump(zero_chat, f, indent=2)
            
        logger.info(f"      ✅ Created 'zero_chat.json' (Reasoning: {zero_chat['capabilities']['reasoning']}, Agent: {zero_chat['capabilities']['agent']}).")

    def _chunk_tensor(self, tensor, chunk_size):
        flat = tensor.view(-1)
        if flat.numel() <= chunk_size:
            return [flat]
        return torch.split(flat, chunk_size)

    def _save_neuron(self, tensor, name):
        # Save as optimized PT
        if isinstance(tensor, dict):
             clean_payload = {k: v.clone() if torch.is_tensor(v) else v for k, v in tensor.items()}
             torch.save(clean_payload, self.neurons_dir / f"{name}.pt")
             return

        if torch.is_tensor(tensor):
             # Ensure no storage linkage for efficiency (View -> Clone)
             torch.save(tensor.clone(), self.neurons_dir / f"{name}.pt")
