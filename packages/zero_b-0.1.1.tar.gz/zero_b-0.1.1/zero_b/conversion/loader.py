import torch
import torch.nn as nn
from transformers import (
    AutoModelForCausalLM,
    AutoTokenizer,
    AutoConfig,
    BitsAndBytesConfig
)
import logging
from pathlib import Path
import psutil
import gc
import os

logger = logging.getLogger("ZERO_BRAIN")

class BrainLoader:
    """
    Robust Loader for gathering 'Raw Material' for the Brain.
    Inherits the power of ZERO's HF Loader:
    - Supports HuggingFace Repo IDs
    - Supports Sharded Checkpoints
    - Supports Kaggle/Low-RAM Environments
    """
    def __init__(self, model_name_or_path, cache_dir=None, use_auth_token=None):
        self.model_name = model_name_or_path
        self.cache_dir = cache_dir
        self.use_auth_token = use_auth_token
        
    def load_source_model(self):
        """
        Loads the monolithic model (Source) for conversion.
        Optimized for memory safety during the extraction process.
        """
        logger.info(f"📥 BrainLoader: Acquiring Source Material '{self.model_name}'...")
        
        # 1. Environment Check
        vm = psutil.virtual_memory()
        total_ram_gb = vm.total / (1024**3)
        available_ram_gb = vm.available / (1024**3)
        is_kaggle = total_ram_gb < 35 and total_ram_gb > 25
        
        if is_kaggle:
            logger.info(f"🛡️  Kaggle Environment Detected ({total_ram_gb:.1f}GB RAM). Engaging Safe Mode.")
            
        # 2. Config Loading
        try:
            config = AutoConfig.from_pretrained(
                self.model_name, 
                trust_remote_code=True,
                token=self.use_auth_token,
                cache_dir=self.cache_dir
            )
        except Exception as e:
            logger.error(f"Failed to load config: {e}")
            raise e

        # 3. Loading Strategy
        # If we are converting, we ideally want Full Precision or BF16 to capture all nuances.
        # But if RAM is tight, 4-bit load is better than OOM.
        
        device_map = "auto"
        max_memory = None
        quantization_config = None
        
        if is_kaggle:
            # Reserve 8GB for OS
            safe_cpu = max(available_ram_gb - 8.0, 8.0)
            max_memory = {"cpu": f"{safe_cpu:.1f}GiB"}
            if torch.cuda.is_available():
                for i in range(torch.cuda.device_count()):
                    vram = torch.cuda.get_device_properties(i).total_memory / (1024**3)
                    max_memory[i] = f"{max(vram-2, 0):.1f}GiB"
                    
            # Try 4-bit if model is huge (>10B)
            # Heuristic: hidden_size * layers * vocab? Or just trust user?
            # For robustness, we try standard load first, fallback to 4-bit.
            pass
            
        logger.info(f"   Strategy: Device Map={device_map}, Max Memory={max_memory}")
        
        try:
            model = AutoModelForCausalLM.from_pretrained(
                self.model_name,
                trust_remote_code=True,
                token=self.use_auth_token,
                cache_dir=self.cache_dir,
                device_map=device_map,
                max_memory=max_memory,
                low_cpu_mem_usage=True,
                torch_dtype="auto"
            )
        except Exception as e:
            logger.warning(f"Standard Load Failed: {e}")
            if is_kaggle and torch.cuda.is_available():
                logger.info("   ⚠️ Fallback: 4-bit Quantization Load")
                bnb_config = BitsAndBytesConfig(
                    load_in_4bit=True,
                    bnb_4bit_quant_type="nf4",
                    bnb_4bit_compute_dtype=torch.float16
                )
                gc.collect()
                torch.cuda.empty_cache()
                model = AutoModelForCausalLM.from_pretrained(
                    self.model_name,
                    quantization_config=bnb_config,
                    trust_remote_code=True,
                    token=self.use_auth_token,
                    cache_dir=self.cache_dir,
                    device_map="auto",
                    max_memory=max_memory
                )
            else:
                raise e
                
        logger.info("✅ Source Model Acquired.")
        return model

    def get_tokenizer(self):
        return AutoTokenizer.from_pretrained(
            self.model_name, 
            trust_remote_code=True,
            token=self.use_auth_token
        )
