"""
ZERO Library - Command Line Interface
User-friendly CLI for model optimization
"""

from .config_cli import ConfigCLI
from .config_cli import ConfigCLI

__all__ = ['ConfigCLI']
