import argparse
import sys
import logging
import torch
from pathlib import Path
from zero_lm import ZeroModel, ZeroConfig
from zero_lm.mobile.ultra_mobile_optimizer import UltraMobileOptimizer

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

def convert_model(args):
    """
    Handle the 'convert' command.
    Standardizes models to ZERO Native Format (.zero)
    """
    model_name_or_path = args.model
    output_path = args.output
    
    if not output_path:
        # Default name: {model_name}.zero
        name = Path(model_name_or_path).name
        output_path = f"{name}.zero"
        
    logger.info(f"🚀 ZERO Converter Initialized")
    logger.info(f"   Target: {model_name_or_path}")
    logger.info(f"   Quantization: {args.quantization.upper()}")
    logger.info(f"   Context Length: {args.context_length}")
    
    if args.ram_gb:
        logger.info(f"   Target RAM: {args.ram_gb}GB")
        
    try:
        # 1. Load Source Model (HuggingFace)
        logger.info("   Phase 1: Loading source model...")
        
        # Determine quantization for loading
        # If we are going to run UltraMobileOptimizer (implied by ram_gb or mixed),
        # we generally want to start with FP16 weights to allow custom quantization (e.g. INT2).
        # Loading as INT4 (bnb) would prevent re-quantization.
        load_quant = args.quantization
        if args.quantization == "mixed" or args.ram_gb is not None:
            logger.info("   ℹ️  Optimization requested: Loading source as FP16 to allow re-quantization")
            logger.info("       (Streaming loader will prevent OOM)")
            load_quant = "fp16"
            
        model = ZeroModel.from_pretrained(
            model_name_or_path,
            quantization=load_quant,
            streaming=True, # Always enable streaming capability
            max_cache_size=args.context_length # Configurable context
        )
        
        # 2. Optimization (Native)
        if args.ram_gb or args.quantization == "mixed":
             logger.info("   Phase 1.5: Applying Ultra Mobile Optimization...")
             
             optimizer = UltraMobileOptimizer(
                 target_ram_mb=(args.ram_gb * 1024) if args.ram_gb else 6144, # Default 6GB if mixed selected without ram
                 quality_mode=args.quality
             )
             model = optimizer.optimize(model)
        
        # 3. Save as ZERO Native Format
        logger.info("   Phase 2: Converting to .zero format...")
        model.save_pretrained(output_path, format="native")
        
        logger.info(f"✅ Conversion Complete: {output_path}")
        logger.info(f"   You can now load this model with: ZeroModel.from_pretrained('{output_path}')")
        
    except Exception as e:
        logger.error(f"❌ Conversion Failed: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)

def main():
    parser = argparse.ArgumentParser(description="ZERO CLI - AI Democracy Tools")
    subparsers = parser.add_subparsers(dest="command", help="Command to execute")
    
    # zero convert
    convert_parser = subparsers.add_parser("convert", help="Convert any model to ZERO Native Format")
    convert_parser.add_argument("--model", "-m", type=str, required=True, help="HuggingFace model ID or local path")
    convert_parser.add_argument("--output", "-o", type=str, help="Output path (default: model_name.zero)")
    convert_parser.add_argument("--quantization", "-q", type=str, default="int4", choices=["int4", "int8", "fp16", "mixed"], help="Target quantization")
    convert_parser.add_argument("--context-length", type=int, default=512, help="Max context length for streaming (default: 512)")
    convert_parser.add_argument("--ram-gb", type=int, help="Target RAM in GB for optimization (e.g. 6, 8, 16)")
    convert_parser.add_argument("--quality", type=str, default="balanced", choices=["balanced", "max_quality", "max_compression"], help="Optimization quality mode")
    convert_parser.set_defaults(func=convert_model)
    
    # Parse
    args = parser.parse_args()
    
    if hasattr(args, "func"):
        args.func(args)
    else:
        parser.print_help()

if __name__ == "__main__":
    main()
