import torch
import torch.nn.functional as F
from typing import Union, List, Optional, Dict, Any
import logging
from tqdm import tqdm

logger = logging.getLogger(__name__)

class InferenceEngine:
    def __init__(self, model, config, tokenizer):
        self.model = model
        self.config = config
        self.tokenizer = tokenizer
        self.device = torch.device(config.device)
        
    def generate(
        self,
        prompt: Union[str, List[str]],
        max_length: int = 100,
        temperature: float = 1.0,
        top_p: float = 0.9,
        top_k: int = 50,
        num_return_sequences: int = 1,
        do_sample: bool = True,
        memory_efficient: bool = True,
        stream: bool = False,
        **kwargs
    ) -> Union[str, List[str]]:
        is_batch = isinstance(prompt, list)
        prompts = prompt if is_batch else [prompt]
        
        if memory_efficient:
            return self._generate_memory_efficient(
                prompts=prompts,
                max_length=max_length,
                temperature=temperature,
                top_p=top_p,
                top_k=top_k,
                num_return_sequences=num_return_sequences,
                do_sample=do_sample,
                stream=stream,
                **kwargs
            )
        else:
            return self._generate_standard(
                prompts=prompts,
                max_length=max_length,
                temperature=temperature,
                top_p=top_p,
                top_k=top_k,
                num_return_sequences=num_return_sequences,
                do_sample=do_sample,
                **kwargs
            )
    
    def _generate_memory_efficient(
        self,
        prompts: List[str],
        max_length: int,
        temperature: float,
        top_p: float,
        top_k: int,
        num_return_sequences: int,
        do_sample: bool,
        stream: bool = False,
        **kwargs
    ) -> List[str]:
        # Democracy Runtime Feedback
        if self.config.streaming:
            logger.info(f"⚡ ZERO Native Runtime: Infinite Context Active (Window: {self.config.window_size}, Chunk: {self.config.max_cache_size})")
        
        self.model.eval()
        
        all_outputs = []
        
        # Optimization: dynamic GC threshold
        gc_threshold = getattr(self.config, "gc_step", 100) 

        
        for prompt in prompts:
            input_ids = self.tokenizer.encode(prompt, return_tensors="pt").to(self.device)
            
            generated_tokens = []
            past_key_values = None
            
            with torch.no_grad():
                for step in range(max_length):
                    if past_key_values is not None and self.config.streaming:
                        input_for_forward = input_ids[:, -1:]
                    else:
                        input_for_forward = input_ids
                    
                    try:
                        outputs = self.model(
                            input_for_forward,
                            past_key_values=past_key_values,
                            use_cache=True,
                            return_dict=True
                        )
                    except TypeError:
                        outputs = self.model(input_for_forward, return_dict=True)
                        past_key_values = None
                    
                    logits = outputs.logits[:, -1, :]
                    
                    if hasattr(outputs, 'past_key_values'):
                        past_key_values = outputs.past_key_values
                        
                        if self.config.streaming and past_key_values is not None:
                            past_key_values = self._trim_kv_cache(past_key_values)
                    
                    if do_sample:
                        next_token_id = self._sample_token(
                            logits, temperature, top_p, top_k
                        )
                    else:
                        next_token_id = torch.argmax(logits, dim=-1)
                    
                    generated_tokens.append(next_token_id.item())
                    
                    input_ids = torch.cat([
                        input_ids,
                        next_token_id
                    ], dim=1)
                    
                    if self.tokenizer.eos_token_id and next_token_id.item() == self.tokenizer.eos_token_id:
                        break
                    
                    if stream and step % 5 == 0:
                        partial_text = self.tokenizer.decode(generated_tokens, skip_special_tokens=True)
                        logger.info(f"Generated: {partial_text}")
                    
                    if step % gc_threshold == 0 and step > 0:
                        torch.cuda.empty_cache() if torch.cuda.is_available() else None
            
            output_text = self.tokenizer.decode(input_ids[0], skip_special_tokens=True)
            all_outputs.append(output_text)
        
        return all_outputs if len(all_outputs) > 1 else all_outputs[0]
    
    def _generate_standard(
        self,
        prompts: List[str],
        max_length: int,
        temperature: float,
        top_p: float,
        top_k: int,
        num_return_sequences: int,
        do_sample: bool,
        **kwargs
    ) -> List[str]:
        inputs = self.tokenizer(prompts, return_tensors="pt", padding=True).to(self.device)
        
        with torch.no_grad():
            outputs = self.model.generate(
                **inputs,
                max_length=max_length,
                temperature=temperature,
                top_p=top_p,
                top_k=top_k,
                num_return_sequences=num_return_sequences,
                do_sample=do_sample,
                pad_token_id=self.tokenizer.pad_token_id or self.tokenizer.eos_token_id,
                **kwargs
            )
        
        decoded = self.tokenizer.batch_decode(outputs, skip_special_tokens=True)
        return decoded if len(decoded) > 1 else decoded[0]
    
    def _sample_token(
        self,
        logits: torch.Tensor,
        temperature: float,
        top_p: float,
        top_k: int
    ) -> torch.Tensor:
        if temperature == 0:
            return torch.argmax(logits, dim=-1)
        
        logits = logits / temperature
        
        if top_k > 0:
            indices_to_remove = logits < torch.topk(logits, top_k)[0][..., -1, None]
            logits[indices_to_remove] = float('-inf')
        
        if top_p < 1.0:
            sorted_logits, sorted_indices = torch.sort(logits, descending=True)
            cumulative_probs = torch.cumsum(F.softmax(sorted_logits, dim=-1), dim=-1)
            
            sorted_indices_to_remove = cumulative_probs > top_p
            sorted_indices_to_remove[..., 1:] = sorted_indices_to_remove[..., :-1].clone()
            sorted_indices_to_remove[..., 0] = 0
            
            indices_to_remove = sorted_indices_to_remove.scatter(
                1, sorted_indices, sorted_indices_to_remove
            )
            logits[indices_to_remove] = float('-inf')
        
        probs = F.softmax(logits, dim=-1)
        next_token = torch.multinomial(probs, num_samples=1)
        
        return next_token
    
    def _trim_kv_cache(self, past_key_values):
        if past_key_values is None:
            return None
        
        max_cache = self.config.max_cache_size
        sink_size = self.config.attention_sink_size
        
        trimmed_past = []
        for layer_past in past_key_values:
            if layer_past is None:
                trimmed_past.append(None)
                continue
            
            key, value = layer_past
            seq_len = key.shape[2]
            
            if seq_len > max_cache:
                key_sink = key[:, :, :sink_size, :]
                value_sink = value[:, :, :sink_size, :]
                
                key_recent = key[:, :, -(max_cache - sink_size):, :]
                value_recent = value[:, :, -(max_cache - sink_size):, :]
                
                key = torch.cat([key_sink, key_recent], dim=2)
                value = torch.cat([value_sink, value_recent], dim=2)
            
            trimmed_past.append((key, value))
        
        return tuple(trimmed_past)
