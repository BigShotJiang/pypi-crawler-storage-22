import torch
import torch.nn as nn
from transformers import (
    AutoModelForCausalLM,
    AutoTokenizer,
    AutoConfig,
    BitsAndBytesConfig,
)
from typing import Tuple, Optional, Any
import logging
from pathlib import Path

logger = logging.getLogger(__name__)

class HuggingFaceLoader:
    def __init__(self, config):
        self.config = config
        self.model_name = config.model_name_or_path
        self._auto_detected_trust_remote_code = False
        
    def load(self) -> Tuple[nn.Module, Any]:
        logger.info(f"Loading model: {self.model_name}")
        
        # Auto-detect if model needs trust_remote_code
        self._auto_detect_custom_architecture()
        
        tokenizer = self._load_tokenizer()
        model = self._load_model()
        
        if self.config.quantization and self.config.quantization not in ["int4", "int8"]:
            model = self._apply_custom_quantization(model)
        
        return model, tokenizer
    
    def _auto_detect_custom_architecture(self):
        """Auto-detect if model uses custom architecture and needs trust_remote_code"""
        try:
            config = AutoConfig.from_pretrained(
                self.model_name,
                token=self.config.use_auth_token,
                cache_dir=self.config.cache_dir,
            )
            
            # Check if model uses custom architecture
            model_type = getattr(config, 'model_type', None)
            auto_map = getattr(config, 'auto_map', None)
            
            # Known custom architectures that need trust_remote_code
            custom_architectures = [
                'glm', 'chatglm', 'glm4', 'glm4moelite',  # GLM family
                'baichuan', 'internlm', 'internlm2',      # Chinese models
                'yi', 'deepseek', 'xverse',                # Other custom
            ]
            
            needs_trust = False
            
            # Check 1: auto_map indicates custom code
            if auto_map:
                logger.info(f"Detected auto_map: {auto_map}")
                needs_trust = True
            
            # Check 2: Known custom architecture
            if model_type and any(arch in model_type.lower() for arch in custom_architectures):
                logger.info(f"Detected custom architecture: {model_type}")
                needs_trust = True
            
            # Auto-enable trust_remote_code if needed
            if needs_trust and not self.config.trust_remote_code:
                logger.warning(f"Auto-enabling trust_remote_code for custom architecture: {model_type}")
                self.config.trust_remote_code = True
                self._auto_detected_trust_remote_code = True
                
        except Exception as e:
            logger.debug(f"Could not auto-detect architecture: {e}")
            # If detection fails, try with trust_remote_code=True as fallback
            pass
    
    def _load_tokenizer(self):
        logger.info("Loading tokenizer...")
        
        tokenizer = AutoTokenizer.from_pretrained(
            self.model_name,
            trust_remote_code=self.config.trust_remote_code,
            token=self.config.use_auth_token,
            cache_dir=self.config.cache_dir,
        )
        
        if tokenizer.pad_token is None:
            tokenizer.pad_token = tokenizer.eos_token
        
        return tokenizer
    
    def _load_model(self):
        logger.info("Loading model...")
        
        # -------------------------------------------------------------
        # KAGGLE-SAFE MEMORY CONFIGURATION
        # -------------------------------------------------------------
        import psutil
        import tempfile
        import uuid
        
        vm = psutil.virtual_memory()
        total_ram_gb = vm.total / (1024**3)
        available_ram_gb = vm.available / (1024**3)
        
        # Detect Kaggle environment (30GB RAM, no swap)
        is_kaggle = total_ram_gb < 35 and total_ram_gb > 25
        if is_kaggle:
            logger.info(f"🛡️  Kaggle Environment Detected: {total_ram_gb:.1f}GB RAM")
        
        # -------------------------------------------------------------
        # AUTO-CONFIGURE OFFLOADING (Kaggle/Colab Safety)
        # -------------------------------------------------------------
        # ALWAYS create offload folder for models > 10GB
        if not self.config.offload_folder:
            unique_id = str(uuid.uuid4())[:8]
            self.config.offload_folder = tempfile.mkdtemp(prefix=f"zero_offload_{unique_id}_")
            logger.info(f"🛡️  Auto-created offload folder: {self.config.offload_folder}")

        # -------------------------------------------------------------
        # AGGRESSIVE MAX MEMORY LIMITS FOR KAGGLE
        # -------------------------------------------------------------
        # On Kaggle: Reserve 8GB for OS/kernel/overhead
        # This is critical because Kaggle has NO SWAP!
        if self.config.low_memory and not self.config.max_memory:
            if is_kaggle:
                # Kaggle-aggressive: Only use 20GB of 30GB (leave 10GB headroom)
                safe_cpu_gb = min(available_ram_gb - 10.0, 20.0)
                safe_cpu_gb = max(safe_cpu_gb, 8.0)  # Min 8GB
                logger.info(f"🛡️  Kaggle Mode: Using max {safe_cpu_gb:.1f}GB CPU RAM")
            else:
                # Normal: leave 4GB headroom
                safe_cpu_gb = max(available_ram_gb - 4.0, 4.0)
            
            self.config.max_memory = {
                "cpu": f"{safe_cpu_gb:.1f}GiB"
            }
            
            # Get real GPU VRAM if available
            if torch.cuda.is_available():
                for i in range(torch.cuda.device_count()):
                    vram_gb = torch.cuda.get_device_properties(i).total_memory / (1024**3)
                    # Reserve 1.5GB VRAM for buffer on Kaggle T4
                    safe_gpu_gb = max(vram_gb - 1.5, 0)
                    self.config.max_memory[i] = f"{safe_gpu_gb:.1f}GiB"
            
            logger.info(f"🛡️  Auto-set Max Memory: {self.config.max_memory}")

        model_kwargs = {
            "trust_remote_code": self.config.trust_remote_code,
            "token": self.config.use_auth_token,
            "cache_dir": self.config.cache_dir,
            "low_cpu_mem_usage": self.config.low_memory,
        }
        
        # -------------------------------------------------------------
        # SPECIAL HANDLING FOR RELOADING ZERO-QUANTIZED MODELS
        # -------------------------------------------------------------
        # If we are reloading a model we saved (Zero-Quantized), we must:
        # 1. Load empty structure (skeleton)
        # 2. Reshape layers to match quantized weights (Float -> Int8 Packed)
        # 3. Load state_dict into this new structure
        # -------------------------------------------------------------
        
        # Check if this is a zero-quantized checkpoint
        is_zero_quantized = False
        zero_config_path = Path(self.model_name) / "zero_config.json"
        if zero_config_path.exists():
            try:
                import json
                with open(zero_config_path, 'r') as f:
                    zconf = json.load(f)
                    if zconf.get('quantization') == 'int4':
                        is_zero_quantized = True
                        logger.info("🛡️  Detected ZERO-Quantized Checkpoint (INT4)")
            except:
                pass

        if is_zero_quantized:
            try:
                logger.info("🔄 Reloading ZERO-Quantized Model...")
                from accelerate import init_empty_weights, load_checkpoint_and_dispatch
                from ..quantization.int4_quantizer import INT4Quantizer
                
                # 1. Create Skeleton (on Meta device)
                logger.info("   1. Creating skeleton model...")
                with init_empty_weights():
                    config = AutoConfig.from_pretrained(
                        self.model_name, 
                        trust_remote_code=self.config.trust_remote_code
                    )
                    model = AutoModelForCausalLM.from_config(
                        config, 
                        trust_remote_code=self.config.trust_remote_code
                    )
                
                # 2. Reshape for Quantization
                logger.info("   2. Preparing quantized structure...")
                quantizer = INT4Quantizer()
                quantizer.prepare_model_for_loading(model)
                
                # 3. Load Weights
                logger.info("   3. Loading sharded weights...")
                # offload_folder is redundant if offload_blobs is handled, but safe to pass
                model = load_checkpoint_and_dispatch(
                    model,
                    self.model_name,
                    device_map="auto",
                    offload_folder=self.config.offload_folder,
                    dtype=torch.float16, # Buffers are float16/float32
                    no_split_module_classes=model._no_split_modules
                )
                
                logger.info("✅ ZERO-Quantized Model Reloaded Successfully!")
                return model
                
            except Exception as e:
                logger.warning(f"⚠️  Failed to reload as Zero-Quantized: {e}")
                logger.warning("   -> Falling back to standard loading (may fail if shapes mismatch)")
        
        # Handle torch_dtype/dtype (transformers 5.0+ uses 'dtype')
        if hasattr(self.config, '_torch_dtype') and self.config._torch_dtype is not None:
            # Use 'dtype' for transformers 5.0+, fallback to 'torch_dtype' for older versions
            try:
                import transformers
                version = tuple(map(int, transformers.__version__.split('.')[:2]))
                if version >= (5, 0):
                    model_kwargs["dtype"] = self.config._torch_dtype
                    logger.info(f"Using dtype: {self.config._torch_dtype}")
                else:
                    model_kwargs["torch_dtype"] = self.config._torch_dtype
                    logger.info(f"Using torch_dtype: {self.config._torch_dtype}")
            except:
                # Fallback: try both
                model_kwargs["dtype"] = self.config._torch_dtype
                logger.info(f"Using dtype: {self.config._torch_dtype}")
        
        if self.config.device != "cpu":
            model_kwargs["device_map"] = "auto"
        
        if self.config.max_memory:
            model_kwargs["max_memory"] = self.config.max_memory
        
        if self.config.offload_folder:
            model_kwargs["offload_folder"] = self.config.offload_folder
        
        if self.config.load_in_4bit:
            logger.info("Loading with 4-bit quantization")
            quantization_config = BitsAndBytesConfig(
                load_in_4bit=True,
                bnb_4bit_compute_dtype=getattr(torch, self.config.bnb_4bit_compute_dtype),
                bnb_4bit_quant_type=self.config.bnb_4bit_quant_type,
                bnb_4bit_use_double_quant=self.config.bnb_4bit_use_double_quant,
            )
            model_kwargs["quantization_config"] = quantization_config
        elif self.config.load_in_8bit:
            logger.info("Loading with 8-bit quantization")
            model_kwargs["load_in_8bit"] = True
        
        # Try loading with multiple fallback strategies
        model = self._load_with_fallbacks(model_kwargs)
        
        model.eval()
        
        logger.info(f"Model loaded successfully on {self.config.device}")
        return model
    
    def _load_with_fallbacks(self, model_kwargs):
        """Try loading model with multiple fallback strategies"""
        import gc
        import psutil
        
        # Helper for cleanup
        def cleanup():
            gc.collect()
            if torch.cuda.is_available():
                torch.cuda.empty_cache()
        
        # Detect Kaggle environment
        vm = psutil.virtual_memory()
        total_ram_gb = vm.total / (1024**3)
        is_kaggle = total_ram_gb < 35 and total_ram_gb > 25
                
        # CORE MEMORY KEYWORDS that must NEVER be dropped
        # These prevent the model from exploding to float32
        base_minimal_kwargs = {
            "trust_remote_code": True,
            "token": self.config.use_auth_token,
            "cache_dir": self.config.cache_dir,
            "low_cpu_mem_usage": True,  # Critical for 30GB+ models
        }
        
        # Add dtype if available
        if "torch_dtype" in model_kwargs:
            base_minimal_kwargs["torch_dtype"] = model_kwargs["torch_dtype"]
        elif "dtype" in model_kwargs:
            base_minimal_kwargs["dtype"] = model_kwargs["dtype"]

        # =====================================================================
        # KAGGLE STRATEGY 0: 4-bit Quantization During Loading (bitsandbytes)
        # =====================================================================
        # For Kaggle (30GB RAM, no swap) and large models like GLM-4.7-Flash (30B),
        # we MUST use 4-bit quantization DURING loading to reduce memory by 4x.
        # Without this, 30B model at bfloat16 = 60GB RAM = OOM on Kaggle.
        # With 4-bit: 30B model = ~15GB RAM = fits in Kaggle!
        if is_kaggle:
            try:
                logger.info("🛡️  Kaggle Strategy 0: 4-bit Quantization Loading (bitsandbytes)")
                
                # Check if bitsandbytes is available
                try:
                    from transformers import BitsAndBytesConfig
                    import bitsandbytes as bnb
                    bnb_version = getattr(bnb, '__version__', '0.0.0')
                    bnb_available = True
                    logger.info(f"   ✓ bitsandbytes {bnb_version} available")
                except ImportError:
                    bnb_available = False
                    logger.warning("   ✗ bitsandbytes not available, falling back to standard loading")
                
                if bnb_available and torch.cuda.is_available():
                    # Configure 4-bit quantization for maximum memory savings
                    # Use minimal config to avoid version compatibility issues
                    bnb_config = BitsAndBytesConfig(
                        load_in_4bit=True,
                        bnb_4bit_quant_type="nf4",
                        bnb_4bit_compute_dtype=torch.float16,  # Use float16 for better compatibility
                        bnb_4bit_use_double_quant=True,
                    )
                    
                    logger.info("   4-bit config: NF4 + double quant + float16 compute")
                    
                    # Calculate memory limits - be very conservative
                    available_ram_gb = vm.available / (1024**3)
                    safe_cpu_gb = min(available_ram_gb - 8.0, 18.0)  # More conservative
                    safe_cpu_gb = max(safe_cpu_gb, 8.0)
                    
                    kaggle_max_memory = {"cpu": f"{safe_cpu_gb:.0f}GiB"}
                    
                    for i in range(torch.cuda.device_count()):
                        vram_gb = torch.cuda.get_device_properties(i).total_memory / (1024**3)
                        safe_gpu_gb = max(vram_gb - 2.0, 0)  # More conservative
                        kaggle_max_memory[i] = f"{safe_gpu_gb:.0f}GiB"
                    
                    logger.info(f"   Max memory: {kaggle_max_memory}")
                    
                    # CRITICAL: Clear memory before loading
                    gc.collect()
                    if torch.cuda.is_available():
                        torch.cuda.empty_cache()
                    
                    # Load with 4-bit quantization - minimal kwargs to avoid compatibility issues
                    model = AutoModelForCausalLM.from_pretrained(
                        self.model_name,
                        quantization_config=bnb_config,
                        device_map="auto",
                        max_memory=kaggle_max_memory,
                        trust_remote_code=True,
                        token=self.config.use_auth_token,
                        cache_dir=self.config.cache_dir,
                        low_cpu_mem_usage=True,
                    )
                    
                    # Mark as BNB quantized for optimizer to skip re-quantization
                    model._zero_bnb_quantized = True
                    model._zero_kaggle_loaded = True
                    
                    logger.info("✅ Kaggle 4-bit loading successful!")
                    return model
                    
                else:
                    # Fallback: No GPU or no bitsandbytes - use aggressive disk offload
                    logger.info("   No GPU/bitsandbytes - using aggressive disk offload")
                    
                    available_ram_gb = vm.available / (1024**3)
                    safe_cpu_gb = min(available_ram_gb - 10.0, 18.0)
                    safe_cpu_gb = max(safe_cpu_gb, 8.0)
                    
                    kaggle_max_memory = {"cpu": f"{safe_cpu_gb:.0f}GiB"}
                    
                    if torch.cuda.is_available():
                        for i in range(torch.cuda.device_count()):
                            vram_gb = torch.cuda.get_device_properties(i).total_memory / (1024**3)
                            kaggle_max_memory[i] = f"{max(vram_gb - 2.0, 0):.0f}GiB"
                    
                    kaggle_kwargs = {
                        "trust_remote_code": True,
                        "token": self.config.use_auth_token,
                        "cache_dir": self.config.cache_dir,
                        "low_cpu_mem_usage": True,
                        "device_map": "auto",
                        "max_memory": kaggle_max_memory,
                        "offload_folder": self.config.offload_folder,
                        "offload_state_dict": True,
                        "torch_dtype": torch.float16,  # Use fp16 to save memory
                    }
                    
                    model = AutoModelForCausalLM.from_pretrained(
                        self.model_name,
                        **kaggle_kwargs
                    )
                    
                    logger.info("✅ Kaggle disk offload loading successful!")
                    return model
                
            except Exception as e0:
                logger.warning(f"Kaggle Strategy 0 failed: {e0}")
                cleanup()
                # Fall through to standard strategies

        # Strategy 1: Try with user-specified settings (Quantized + Device Map)
        try:
            logger.info("Strategy 1: Loading with current settings (Quantization + Device Map)")
            return AutoModelForCausalLM.from_pretrained(
                self.model_name,
                **model_kwargs
            )
        except (TypeError, ValueError, ImportError) as e:
            # Special handling for "unexpected keyword argument 'load_in_8bit'"
            if "load_in_" in str(e) or "quantization" in str(e):
                 logger.warning(f"Strategy 1 failed (Quantization Config Error): {e}")
                 # This isn't a fatal error, just a config error. Fall through to S2.
            else:
                 logger.warning(f"Strategy 1 failed: {e}")
            
            cleanup()
            
            # Strategy 2: Remove Quantization but KEEP Device Map (Offloading)
            # This allows parsing 'load_in_8bit' errors while keeping memory safety
            try:
                logger.info("Strategy 2: Storage Offloading (device_map=auto, no quantization)")
                kwargs_offload = model_kwargs.copy()
                # Remove specific quantization args that might cause conflict
                kwargs_offload.pop("load_in_8bit", None)
                kwargs_offload.pop("load_in_4bit", None)
                kwargs_offload.pop("quantization_config", None)
                
                # Ensure device map is on
                if "device_map" not in kwargs_offload:
                    kwargs_offload["device_map"] = "auto"
                
                return AutoModelForCausalLM.from_pretrained(
                    self.model_name,
                    **kwargs_offload
                )
            except Exception as e2:
                logger.warning(f"Strategy 2 failed: {e2}")
                cleanup()

                # Strategy 3: Forced CPU/Disk Offloading
                # If CUDA OOM occurred in S2, we must force CPU offloading via device_map
                try:
                    logger.info("Strategy 3: Forced CPU/Disk Offloading")
                    
                    # ⚠️ SAFETY CHECK: parameter mismatch detection
                    # If this model has a mismatch (like MoE experts not mapping), 
                    # standard load will EXPLODE RAM. We must use a safe context.
                    from accelerate import init_empty_weights, load_checkpoint_and_dispatch
                    from accelerate.utils import infer_auto_device_map
                    
                    kwargs_cpu = model_kwargs.copy()
                    kwargs_cpu.pop("load_in_8bit", None)
                    kwargs_cpu.pop("load_in_4bit", None)
                    kwargs_cpu.pop("quantization_config", None)
                    
                    # Ensure minimal safe args are present
                    kwargs_cpu.update(base_minimal_kwargs)
                    
                    logger.info("   -> Creating skeleton first...")
                    with init_empty_weights():
                        config = AutoConfig.from_pretrained(
                            self.model_name, 
                            trust_remote_code=True
                        )
                        # Fix: Ensure model path is a local directory for load_checkpoint_and_dispatch
                        from huggingface_hub import snapshot_download, hf_hub_download
                        import json
                        import os
                        
                        # 🔍 PRE-FLIGHT CHECK: Mismatch Detection (Save RAM!)
                        # Before downloading 60GB, let's check if the keys actually match.
                        logger.info("   🔍 Running pre-flight structure check...")
                        try:
                            # Try to fetch index file
                            index_file = None
                            for index_name in ["model.safetensors.index.json", "pytorch_model.bin.index.json"]:
                               try:
                                   index_path = hf_hub_download(
                                       self.model_name,
                                       filename=index_name,
                                       cache_dir=self.config.cache_dir,
                                       token=self.config.use_auth_token
                                   )
                                   index_file = index_path
                                   break
                               except:
                                   pass
                            
                            if index_file:
                                with open(index_file, 'r') as f:
                                    index_data = json.load(f)
                                    checkpoint_keys = set(index_data.get("weight_map", {}).keys())
                                
                                model_keys = set(model.state_dict().keys())
                                
                                # Check for critical missing keys
                                missing_in_checkpoint = model_keys - checkpoint_keys
                                # Ignore small harmless missing keys (like tied weights or buffers)
                                critical_missing = [k for k in missing_in_checkpoint if "weight" in k and ("layers" in k or "experts" in k)]
                                
                                if len(critical_missing) > 20: # If many layers are missing
                                    logger.error(f"🛑 CRITICAL MISMATCH DETECTED: {len(critical_missing)} keys missing from checkpoint.")
                                    logger.error(f"   Example missing: {critical_missing[:3]}")
                                    raise RuntimeError(f"Model Structure Mismatch: {len(critical_missing)} keys missing. Aborting to save RAM.")
                                
                            logger.info("   ✅ Structure check passed. Downloading model...")
                        
                        except Exception as check_e:
                            if "Mismatch" in str(check_e):
                                raise check_e # Re-raise known mismatch
                            logger.warning(f"   ⚠️ Could not perform pre-flight check: {check_e}. Proceeding with caution...")

                        checkpoint_path = snapshot_download(
                            self.model_name,
                            allow_patterns=["*.safetensors", "*.bin", "*.json"],
                            cache_dir=self.config.cache_dir,
                            token=self.config.use_auth_token
                        )
                        
                        model = AutoModelForCausalLM.from_config(
                            config, 
                            trust_remote_code=True
                        )
                    
                    # Explicitly offload buffers to save GPU/CPU RAM
                    # This often fixes "buffer mismatch" OOMs
                    model.tie_weights()
                    
                    logger.info(f"   -> Dispatching with strict offload from {checkpoint_path}...")
                    
                    # Tweak max_memory to forbid GPU (force everything to CPU/Disk)
                    # We use a very strict limit to force disk offload if things defined wrong
                    strict_max_mem = {
                        "cpu": "12GiB", # Strict limit to force disk usage
                    }
                    if torch.cuda.is_available():
                         for i in range(torch.cuda.device_count()):
                             strict_max_mem[i] = "0GiB" # Block GPU to be safe in this fallback
                    
                    no_split = getattr(model, '_no_split_modules', None) or []
                    
                    model = load_checkpoint_and_dispatch(
                        model,
                        checkpoint_path, # Fix: Use local path
                        device_map="auto",
                        max_memory=strict_max_mem,
                        offload_folder=self.config.offload_folder,
                        offload_state_dict=True,
                        no_split_module_classes=no_split,
                        offload_buffers=True, # Critical for OOM prevention
                        dtype=kwargs_cpu.get("dtype", kwargs_cpu.get("torch_dtype", "auto"))
                    )
                    
                    # Manually move to device if needed/possible (usually it stays offloaded)
                    return model
                    
                except Exception as e3:
                    logger.error(f"Strategy 3 failed: {e3}")
                    logger.error("🛑 All safe loading strategies failed.")
                    # STOP HERE using 'raise'. Do NOT fall through to Strategy 4.
                    # Strategy 4 (Naive Loading) is guaranteed to crash 60GB models on 30GB RAM.
                    raise RuntimeError("Failed to load model safely. Check memory or checkpoint integrity.") from e3

    
    def _apply_custom_quantization(self, model: nn.Module) -> nn.Module:
        from ..quantization.quantizer import Quantizer
        
        logger.info(f"Applying custom {self.config.quantization} quantization")
        
        if self.config.quantization == "fp16":
            model = model.half()
        else:
            quantizer = Quantizer(bits=8, method="symmetric")
            model = quantizer.quantize_model(model)
        
        return model
    
    @staticmethod
    def get_model_info(model_name: str) -> dict:
        try:
            config = AutoConfig.from_pretrained(model_name)
            return {
                "model_type": config.model_type,
                "hidden_size": getattr(config, "hidden_size", None),
                "num_layers": getattr(config, "num_hidden_layers", None),
                "num_attention_heads": getattr(config, "num_attention_heads", None),
                "vocab_size": getattr(config, "vocab_size", None),
            }
        except Exception as e:
            logger.error(f"Failed to get model info: {e}")
            return {}
