import torch
import psutil
import gc
from typing import Dict, Optional
import logging

logger = logging.getLogger(__name__)

class MemoryMonitor:
    def __init__(self):
        self.process = psutil.Process()
        self.initial_memory = self.get_memory_usage()
    
    def get_memory_usage(self) -> Dict[str, float]:
        memory_info = {}
        
        memory_info["cpu_ram_mb"] = self.process.memory_info().rss / (1024 ** 2)
        memory_info["cpu_ram_percent"] = self.process.memory_percent()
        
        if torch.cuda.is_available():
            memory_info["gpu_allocated_mb"] = torch.cuda.memory_allocated() / (1024 ** 2)
            memory_info["gpu_reserved_mb"] = torch.cuda.memory_reserved() / (1024 ** 2)
            memory_info["gpu_max_allocated_mb"] = torch.cuda.max_memory_allocated() / (1024 ** 2)
        
        return memory_info
    
    def get_memory_delta(self) -> Dict[str, float]:
        current = self.get_memory_usage()
        delta = {}
        
        for key in current:
            if key in self.initial_memory:
                delta[f"delta_{key}"] = current[key] - self.initial_memory[key]
        
        return delta
    
    def log_memory(self, prefix: str = ""):
        usage = self.get_memory_usage()
        logger.info(f"{prefix} Memory Usage:")
        for key, value in usage.items():
            logger.info(f"  {key}: {value:.2f}")
    
    def reset(self):
        self.initial_memory = self.get_memory_usage()

def optimize_memory():
    gc.collect()
    
    if torch.cuda.is_available():
        torch.cuda.empty_cache()
        torch.cuda.synchronize()
    
    logger.info("Memory optimization completed")

def get_available_memory() -> Dict[str, float]:
    memory_info = {}
    
    virtual_memory = psutil.virtual_memory()
    memory_info["available_ram_gb"] = virtual_memory.available / (1024 ** 3)
    memory_info["total_ram_gb"] = virtual_memory.total / (1024 ** 3)
    memory_info["ram_percent_used"] = virtual_memory.percent
    
    if torch.cuda.is_available():
        for i in range(torch.cuda.device_count()):
            props = torch.cuda.get_device_properties(i)
            memory_info[f"gpu_{i}_total_gb"] = props.total_memory / (1024 ** 3)
            memory_info[f"gpu_{i}_available_gb"] = (
                props.total_memory - torch.cuda.memory_allocated(i)
            ) / (1024 ** 3)
    
    return memory_info

def estimate_model_memory(num_parameters: int, dtype: str = "float16") -> float:
    bytes_per_param = {
        "float32": 4,
        "float16": 2,
        "bfloat16": 2,
        "int8": 1,
        "int4": 0.5,
    }
    
    bytes_per = bytes_per_param.get(dtype, 2)
    memory_gb = (num_parameters * bytes_per) / (1024 ** 3)
    
    memory_gb *= 1.2
    
    return memory_gb
