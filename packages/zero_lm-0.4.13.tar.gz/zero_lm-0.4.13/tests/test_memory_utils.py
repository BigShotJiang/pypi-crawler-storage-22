import pytest
import torch
from zero_lm.utils import MemoryMonitor, optimize_memory

class TestMemoryMonitor:
    def test_initialization(self):
        monitor = MemoryMonitor()
        assert monitor.process is not None
        assert monitor.initial_memory is not None
    
    def test_get_memory_usage(self):
        monitor = MemoryMonitor()
        usage = monitor.get_memory_usage()
        
        assert "cpu_ram_mb" in usage
        assert "cpu_ram_percent" in usage
        assert usage["cpu_ram_mb"] > 0
    
    def test_memory_delta(self):
        monitor = MemoryMonitor()
        
        tensor = torch.randn(1000, 1000)
        
        delta = monitor.get_memory_delta()
        
        assert "delta_cpu_ram_mb" in delta
    
    def test_reset(self):
        monitor = MemoryMonitor()
        initial = monitor.initial_memory.copy()
        
        tensor = torch.randn(1000, 1000)
        
        monitor.reset()
        
        assert monitor.initial_memory != initial

class TestMemoryOptimization:
    def test_optimize_memory(self):
        tensor = torch.randn(1000, 1000)
        del tensor
        
        optimize_memory()

if __name__ == "__main__":
    pytest.main([__file__, "-v"])
