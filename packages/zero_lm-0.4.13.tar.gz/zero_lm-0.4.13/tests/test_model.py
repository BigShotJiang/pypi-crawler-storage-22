import pytest
import torch
from zero_lm import ZeroModel, ZeroConfig

class TestZeroModel:
    @pytest.fixture
    def config(self):
        return ZeroConfig(
            model_name_or_path="gpt2",
            quantization="int8",
            streaming=True,
            max_cache_size=256,
        )
    
    def test_model_initialization(self, config):
        model = ZeroModel(config=config)
        assert model.config == config
        assert model.device is not None
    
    def test_from_pretrained_gpt2(self):
        model = ZeroModel.from_pretrained(
            "gpt2",
            quantization="none",
            streaming=False,
        )
        assert model is not None
        assert model.model is not None
        assert model.tokenizer is not None
    
    def test_generation_basic(self):
        model = ZeroModel.from_pretrained(
            "gpt2",
            quantization="none",
            streaming=False,
        )
        
        output = model.generate(
            "Hello, my name is",
            max_length=20,
            temperature=0.7,
        )
        
        assert isinstance(output, str)
        assert len(output) > 0
    
    def test_generation_with_streaming(self):
        model = ZeroModel.from_pretrained(
            "gpt2",
            quantization="none",
            streaming=True,
        )
        
        output = model.generate(
            "The quick brown fox",
            max_length=30,
            memory_efficient=True,
        )
        
        assert isinstance(output, str)
        assert len(output) > 0
    
    def test_memory_usage(self):
        model = ZeroModel.from_pretrained(
            "gpt2",
            quantization="int8",
        )
        
        memory_info = model.get_memory_usage()
        
        assert "total_parameters" in memory_info
        assert "total_size_mb" in memory_info
        assert memory_info["total_parameters"] > 0
    
    def test_batch_generation(self):
        model = ZeroModel.from_pretrained(
            "gpt2",
            quantization="none",
        )
        
        prompts = [
            "Hello world",
            "How are you",
            "Good morning",
        ]
        
        outputs = model.generate(
            prompts,
            max_length=15,
        )
        
        assert isinstance(outputs, list)
        assert len(outputs) == len(prompts)
    
    def test_device_transfer(self):
        model = ZeroModel.from_pretrained(
            "gpt2",
            quantization="none",
        )
        
        model = model.to("cpu")
        assert model.device.type == "cpu"
    
    def test_eval_mode(self):
        model = ZeroModel.from_pretrained(
            "gpt2",
            quantization="none",
        )
        
        model = model.eval()
        assert not model.model.training

if __name__ == "__main__":
    pytest.main([__file__, "-v"])
