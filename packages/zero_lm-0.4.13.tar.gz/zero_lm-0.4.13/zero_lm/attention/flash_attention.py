import torch
import torch.nn as nn
import torch.nn.functional as F
from typing import Optional
import math

class FlashAttentionWrapper:
    def __init__(self, use_flash: bool = True):
        self.use_flash = use_flash
        self.flash_available = self._check_flash_attention()
    
    def _check_flash_attention(self) -> bool:
        try:
            from flash_attn import flash_attn_func
            return True
        except ImportError:
            return False
    
    def forward(
        self,
        query: torch.Tensor,
        key: torch.Tensor,
        value: torch.Tensor,
        attention_mask: Optional[torch.Tensor] = None,
        dropout_p: float = 0.0,
        causal: bool = True,
    ) -> torch.Tensor:
        if self.use_flash and self.flash_available:
            return self._flash_attention(query, key, value, dropout_p, causal)
        else:
            return self._standard_attention(query, key, value, attention_mask, dropout_p, causal)
    
    def _flash_attention(
        self,
        query: torch.Tensor,
        key: torch.Tensor,
        value: torch.Tensor,
        dropout_p: float,
        causal: bool,
    ) -> torch.Tensor:
        try:
            from flash_attn import flash_attn_func
            
            batch_size, num_heads, seq_len, head_dim = query.shape
            
            query = query.transpose(1, 2).contiguous()
            key = key.transpose(1, 2).contiguous()
            value = value.transpose(1, 2).contiguous()
            
            output = flash_attn_func(
                query, key, value,
                dropout_p=dropout_p,
                causal=causal,
            )
            
            output = output.transpose(1, 2).contiguous()
            
            return output
        except Exception as e:
            return self._standard_attention(query, key, value, None, dropout_p, causal)
    
    def _standard_attention(
        self,
        query: torch.Tensor,
        key: torch.Tensor,
        value: torch.Tensor,
        attention_mask: Optional[torch.Tensor],
        dropout_p: float,
        causal: bool,
    ) -> torch.Tensor:
        batch_size, num_heads, q_len, head_dim = query.shape
        k_len = key.shape[2]
        
        scale = 1.0 / math.sqrt(head_dim)
        attn_weights = torch.matmul(query, key.transpose(-2, -1)) * scale
        
        if causal:
            causal_mask = torch.triu(
                torch.ones(q_len, k_len, device=query.device, dtype=torch.bool),
                diagonal=1
            )
            attn_weights = attn_weights.masked_fill(causal_mask, float('-inf'))
        
        if attention_mask is not None:
            attn_weights = attn_weights + attention_mask
        
        attn_weights = F.softmax(attn_weights, dim=-1)
        
        if dropout_p > 0.0:
            attn_weights = F.dropout(attn_weights, p=dropout_p)
        
        attn_output = torch.matmul(attn_weights, value)
        
        return attn_output
