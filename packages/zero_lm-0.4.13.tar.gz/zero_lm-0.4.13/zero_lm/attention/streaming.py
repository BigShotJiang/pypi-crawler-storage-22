import torch
import torch.nn as nn
import torch.nn.functional as F
from typing import Optional, Tuple
import math

class StreamingAttention:
    def __init__(
        self,
        max_cache_size: int = 512,
        attention_sink_size: int = 4,
        window_size: int = 256,
    ):
        self.max_cache_size = max_cache_size
        self.attention_sink_size = attention_sink_size
        self.window_size = window_size
        self.cache = {}
    
    def forward(
        self,
        query: torch.Tensor,
        key: torch.Tensor,
        value: torch.Tensor,
        attention_mask: Optional[torch.Tensor] = None,
        layer_idx: Optional[int] = None,
    ) -> Tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
        batch_size, num_heads, seq_len, head_dim = query.shape
        
        if layer_idx is not None and layer_idx in self.cache:
            cached_key, cached_value = self.cache[layer_idx]
            key = torch.cat([cached_key, key], dim=2)
            value = torch.cat([cached_value, value], dim=2)
        
        key, value = self._manage_cache(key, value, layer_idx)
        
        attention_output = self._compute_attention(
            query, key, value, attention_mask
        )
        
        return attention_output, key, value
    
    def _manage_cache(
        self,
        key: torch.Tensor,
        value: torch.Tensor,
        layer_idx: Optional[int] = None,
    ) -> Tuple[torch.Tensor, torch.Tensor]:
        seq_len = key.shape[2]
        
        if seq_len > self.max_cache_size:
            key_sink = key[:, :, :self.attention_sink_size, :]
            value_sink = value[:, :, :self.attention_sink_size, :]
            
            key_recent = key[:, :, -(self.max_cache_size - self.attention_sink_size):, :]
            value_recent = value[:, :, -(self.max_cache_size - self.attention_sink_size):, :]
            
            key = torch.cat([key_sink, key_recent], dim=2)
            value = torch.cat([value_sink, value_recent], dim=2)
        
        if layer_idx is not None:
            self.cache[layer_idx] = (key.detach(), value.detach())
        
        return key, value
    
    def _compute_attention(
        self,
        query: torch.Tensor,
        key: torch.Tensor,
        value: torch.Tensor,
        attention_mask: Optional[torch.Tensor] = None,
    ) -> torch.Tensor:
        batch_size, num_heads, q_len, head_dim = query.shape
        k_len = key.shape[2]
        
        scale = 1.0 / math.sqrt(head_dim)
        
        if q_len > self.window_size and k_len > self.window_size:
            return self._windowed_attention(query, key, value, attention_mask, scale)
        else:
            return self._standard_attention(query, key, value, attention_mask, scale)
    
    def _standard_attention(
        self,
        query: torch.Tensor,
        key: torch.Tensor,
        value: torch.Tensor,
        attention_mask: Optional[torch.Tensor],
        scale: float,
    ) -> torch.Tensor:
        attn_weights = torch.matmul(query, key.transpose(-2, -1)) * scale
        
        if attention_mask is not None:
            attn_weights = attn_weights + attention_mask
        
        attn_weights = F.softmax(attn_weights, dim=-1)
        attn_output = torch.matmul(attn_weights, value)
        
        return attn_output
    
    def _windowed_attention(
        self,
        query: torch.Tensor,
        key: torch.Tensor,
        value: torch.Tensor,
        attention_mask: Optional[torch.Tensor],
        scale: float,
    ) -> torch.Tensor:
        batch_size, num_heads, q_len, head_dim = query.shape
        k_len = key.shape[2]
        
        outputs = []
        
        for i in range(0, q_len, self.window_size):
            end_i = min(i + self.window_size, q_len)
            query_chunk = query[:, :, i:end_i, :]
            
            start_k = max(0, i - self.window_size)
            end_k = min(k_len, end_i + self.window_size)
            
            key_chunk = key[:, :, start_k:end_k, :]
            value_chunk = value[:, :, start_k:end_k, :]
            
            attn_weights = torch.matmul(query_chunk, key_chunk.transpose(-2, -1)) * scale
            
            if attention_mask is not None:
                mask_chunk = attention_mask[:, :, i:end_i, start_k:end_k]
                attn_weights = attn_weights + mask_chunk
            
            attn_weights = F.softmax(attn_weights, dim=-1)
            chunk_output = torch.matmul(attn_weights, value_chunk)
            
            outputs.append(chunk_output)
        
        return torch.cat(outputs, dim=2)
    
    def trim_cache(self):
        """
        Trim KV cache to max_cache_size
        Preserves attention sinks and recent tokens
        """
        if self.kv_cache is None:
            return
        
        batch_size, num_heads, seq_len, head_dim = self.kv_cache.shape
        
        if seq_len > self.max_cache_size:
            # Keep attention sinks + recent tokens
            sinks = self.kv_cache[:, :, :self.attention_sink_size, :]
            recent = self.kv_cache[:, :, -(self.max_cache_size - self.attention_sink_size):, :]
            self.kv_cache = torch.cat([sinks, recent], dim=2)
    
    def clear_cache(self, layer_idx: Optional[int] = None):
        if layer_idx is not None:
            if layer_idx in self.cache:
                del self.cache[layer_idx]
        else:
            self.cache.clear()
    
    def get_cache_size(self) -> int:
        total_size = 0
        for key, value in self.cache.values():
            total_size += key.numel() * key.element_size()
            total_size += value.numel() * value.element_size()
        return total_size
