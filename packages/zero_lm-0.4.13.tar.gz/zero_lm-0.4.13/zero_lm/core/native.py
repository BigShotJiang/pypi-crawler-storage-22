import json
import logging
import torch
import torch.nn as nn
from pathlib import Path
from typing import Optional, Dict, Any, Union

logger = logging.getLogger(__name__)

class ZeroNativeFormat:
    """
    The Soul of AI Democracy.
    Preserves the model exactly as it is, accessible to everyone.
    Handles the ZERO Native Format (.zero) specification.
    """
    
    VERSION = "1.0"
    
    @staticmethod
    def save(model_wrapper: Any, save_path: Union[str, Path]):
        """
        Save model in ZERO Native Format.
        
        Args:
            model_wrapper: The ZeroModel wrapper instance containing model and config
            save_path: Directory path to save the .zero bundle
        """
        save_path = Path(save_path)
        save_path.mkdir(parents=True, exist_ok=True)
        
        logger.info(f"Saving model to ZERO Native Format at {save_path}")
        
        # 1. Capture the Soul (State & Config)
        # Extract quantization info
        quantization_method = "fp16" # Default
        if hasattr(model_wrapper.model, "quantization_method"):
             quantization_method = model_wrapper.model.quantization_method
        elif hasattr(model_wrapper.config, "quantization"):
             quantization_method = model_wrapper.config.quantization
             
        # Extract bits info if available
        native_precision = "fp16"
        if "4bit" in str(quantization_method):
            native_precision = "int4"
        elif "8bit" in str(quantization_method):
            native_precision = "int8"
            
        manifest = {
            "format_version": ZeroNativeFormat.VERSION,
            "validation_hash": "", # TODO: Implement hash calculation
            "model_type": getattr(model_wrapper.model.config, "model_type", "transformer"),
            "architecture": model_wrapper.model.config.architectures[0] if hasattr(model_wrapper.model.config, "architectures") else "Unknown",
            "native_precision": native_precision,
            "optimization_level": "standard", # default
            "features": {
                "infinite_context": model_wrapper.config.streaming, # Primary feature flag
                "streaming_attention": model_wrapper.config.streaming, 
                "layer_offloading": False, 
                "quantized": native_precision != "fp16"
            },
            "compatibility": {
                "min_ram_gb": 4, # Estimate based on model size?
                "recommended_backend": "zero_runtime"
            },
            "original_config": model_wrapper.config.to_dict()
        }
        
        # 1.1 Create Capabilities Structure
        capabilities_dir = save_path / "capabilities"
        capabilities_dir.mkdir(exist_ok=True)
        
        # Capability: Streaming
        streaming_config = {
            "enabled": model_wrapper.config.streaming,
            "max_cache_size": getattr(model_wrapper.config, "max_cache_size", 512),
            "attention_sink_size": getattr(model_wrapper.config, "attention_sink_size", 4),
            "window_size": getattr(model_wrapper.config, "window_size", 256),
            "rope_scaling": getattr(model_wrapper.config, "rope_scaling", None)
        }
        with open(capabilities_dir / "streaming_config.json", "w") as f:
            json.dump(streaming_config, f, indent=2)

        # Capability: Offloading
        offload_strategy = {
             "strategy": "auto",
             "device_map": None
        }
        if hasattr(model_wrapper.model, "hf_device_map"):
             manifest["features"]["layer_offloading"] = True
             offload_strategy["device_map"] = model_wrapper.model.hf_device_map
             offload_strategy["strategy"] = "hooks"
        
        with open(capabilities_dir / "offload_strategy.json", "w") as f:
            json.dump(offload_strategy, f, indent=2)
        
        # 2. Preserve the Body (Weights)
        # Use Streaming Save for robustness on low-memory environments (like Kaggle)
        logger.info("Extracting weights (using Streaming Save)...")
        try:
             ZeroNativeFormat._save_weights_streaming(model_wrapper.model, save_path)
        except Exception as e:
             logger.error(f"Failed to save weights: {e}")
             raise e

        # 4. Save Configs
        # Save standard config.json for AutoConfig compatibility
        config_path = save_path / "config.json"
        if hasattr(model_wrapper.model, "config") and hasattr(model_wrapper.model.config, "to_json_string"):
            with open(config_path, "w") as f:
                f.write(model_wrapper.model.config.to_json_string())
        else:
            logger.warning("Could not find standard HF config to save as config.json")
            
        # tokenizer.json (if available)
        if model_wrapper.tokenizer is not None:
            logger.info("Saving tokenizer...")
            model_wrapper.tokenizer.save_pretrained(save_path)

        # 5. Seal with Manifesto
        logger.info("Sealing with zero_manifest.json...")
        with open(save_path / "zero_manifest.json", "w") as f:
            json.dump(manifest, f, indent=2)
            
        logger.info(f"✅ Democratized Model Saved at: {save_path}")

    @staticmethod
    def _save_weights_streaming(model: nn.Module, save_path: Path, max_shard_size_gb: int = 2):
        """
        Save weights using a streaming approach to minimize memory usage.
        Handles both in-memory (CPU/GPU) and offloaded (Meta) tensors.
        Explicitly triggers accelerate hooks to materialize offloaded weights.
        """
        from safetensors.torch import save_file
        import gc
        from accelerate.hooks import ModelHook
        
        logger.info(f"   💾 Streaming weights to disk (Max shard: {max_shard_size_gb}GB)...")
        
        current_shard = {}
        current_shard_size = 0
        max_shard_bytes = max_shard_size_gb * 1024**3
        shard_count = 0
        tensor_to_shard_index = {}
        
        # Get named modules to find parents of parameters
        named_modules = dict(model.named_modules())
        
        all_names = [n for n, _ in model.named_parameters()] + [n for n, _ in model.named_buffers()]
        total_tensors = len(all_names)
        total_model_size = 0
        
        logger.info(f"   Processing {total_tensors} tensors...")

        for i, name in enumerate(all_names):
            try:
                # 1. Resolve Parent Module
                if "." in name:
                    parent_name, attr_name = name.rsplit(".", 1)
                    parent_module = named_modules[parent_name]
                else:
                    parent_name = ""
                    attr_name = name
                    parent_module = model
                
                # 2. Trigger Accelerate Hook (pre_forward) to Load Weights
                # This is crucial for "Disk Offload" where weights are on disk/meta device
                hook_triggered = False
                if hasattr(parent_module, "_hf_hook"):
                    try:
                        # Force load weights
                        parent_module._hf_hook.pre_forward(parent_module)
                        hook_triggered = True
                    except Exception as e:
                        logger.warning(f"     Could not trigger pre_forward hook for {name}: {e}")

                # 3. Access the tensor
                tensor = getattr(parent_module, attr_name)
                
                # 4. Handle Meta Tensors (If hook failed or didn't exist)
                if tensor.device.type == 'meta':
                    # Last ditch effort: Try to use the offload_index if available in accelerate
                    # But if pre_forward failed, we are likely out of luck.
                    logger.warning(f"   ⚠️ Skipping meta tensor {name} (still meta after hook)")
                    
                    # Cleanup hook if we triggered it but it didn't help (unlikely)
                    if hook_triggered and hasattr(parent_module, "_hf_hook"):
                        parent_module._hf_hook.post_forward(parent_module, None)
                    continue

                # 5. Detach and Move to CPU
                tensor_cpu = tensor.detach().cpu()
                
                # 6. Offload Back Immediately (post_forward)
                # Save RAM by offloading this module's weights back to disk/CPU immediately
                if hook_triggered and hasattr(parent_module, "_hf_hook"):
                    # accelerate's post_forward usually offloads if configured to do so
                    parent_module._hf_hook.post_forward(parent_module, None)

                tensor_size = tensor_cpu.numel() * tensor_cpu.element_size()
                total_model_size += tensor_size
                
                # 7. Check shard limit
                if current_shard_size + tensor_size > max_shard_bytes and current_shard:
                    shard_count += 1
                    temp_filename = f"model-{shard_count:05d}-of-XXXXX.safetensors"
                    save_file(current_shard, save_path / temp_filename)
                    
                    # Clear memory aggressively
                    del current_shard
                    current_shard = {}
                    current_shard_size = 0
                    gc.collect()
                    if torch.cuda.is_available():
                        torch.cuda.empty_cache()
                
                current_shard[name] = tensor_cpu
                current_shard_size += tensor_size
                tensor_to_shard_index[name] = shard_count + 1
                
                # Explicit cleanup
                del tensor_cpu
                del tensor
                
                # Periodic GC
                if i % 100 == 0:
                    gc.collect()
            
            except Exception as e:
                logger.error(f"   ❌ Failed to process tensor {name}: {e}")
                raise e
        
        # Save final shard
        if current_shard:
            shard_count += 1
            temp_filename = f"model-{shard_count:05d}-of-XXXXX.safetensors"
            save_file(current_shard, save_path / temp_filename)
            for name in current_shard:
                tensor_to_shard_index[name] = shard_count
            del current_shard
            gc.collect()
            
        # Rename shards
        logger.info(f"   🔄 Renaming {shard_count} shards...")
        final_weight_map = {}
        for i in range(1, shard_count + 1):
            old_name = f"model-{i:05d}-of-XXXXX.safetensors"
            new_name = f"model-{i:05d}-of-{shard_count:05d}.safetensors"
            
            old_path = save_path / old_name
            if old_path.exists():
                old_path.rename(save_path / new_name)
                
        # Build final map
        for name, shard_idx in tensor_to_shard_index.items():
            final_weight_map[name] = f"model-{shard_idx:05d}-of-{shard_count:05d}.safetensors"
            
        # Save index
        index_data = {
            "metadata": {"total_size": total_model_size},
            "weight_map": final_weight_map
        }
        with open(save_path / "model.safetensors.index.json", "w") as f:
            json.dump(index_data, f, indent=2)
            
        logger.info("   ✓ Weights saved successfully")

    @staticmethod
    def load(path: Union[str, Path], device_budget: str = "auto"):
        """
        Load model from ZERO Native Format.
        """
        path = Path(path)
        manifest_path = path / "zero_manifest.json"
        
        if not manifest_path.exists():
            raise FileNotFoundError(f"Not a valid ZERO bundle: {manifest_path} missng")
            
        # 1. Read Manifesto
        with open(manifest_path) as f:
            manifest = json.load(f)
            
        logger.info(f"Loading ZERO Model: {manifest.get('model_type', 'Unknown')}")
            
        # 2. Allocate Resources based on Democracy (Available Hardware)
        if device_budget == "low_ram":
             logger.warning("⚠️ Low RAM detected: Activating Zero-Streaming Loader")
             # Load logic specific for low-end devices
             return ZeroNativeFormat._streaming_load(path, manifest)
        else:
             # Standard Load
             return ZeroNativeFormat._standard_load(path, manifest)

    @staticmethod
    def _standard_load(path: Path, manifest: Dict):
        # Placeholder for standard loading logic using safetensors and config reconstruction
        # This will need to interface with ZeroModel/Transformers to rebuild the model object
        # For now, return the paths/config so ZeroModel can use them
        return {
            "weights": path / "weights.safetensors",
            "config": path / "zero_config.json",
            "manifest": manifest
        }

    @staticmethod
    def _streaming_load(path: Path, manifest: Dict):
        # Placeholder for streaming load
        return ZeroNativeFormat._standard_load(path, manifest)
