"""
Model Registry for ZERO Library
Automatic detection and optimization for latest models
"""

import torch
import torch.nn as nn
from typing import Dict, Any, Optional, Callable
import logging

logger = logging.getLogger(__name__)

class ModelRegistry:
    """
    Registry for model-specific optimizations
    Automatically detects and applies best optimizations
    """
    
    _registry: Dict[str, Dict[str, Any]] = {}
    
    @classmethod
    def register(
        cls,
        model_name: str,
        optimizer_class: Callable,
        config: Dict[str, Any],
    ):
        """Register a model with its optimizer"""
        cls._registry[model_name] = {
            'optimizer': optimizer_class,
            'config': config,
        }
        logger.info(f"Registered model: {model_name}")
    
    @classmethod
    def get_optimizer(cls, model_name: str) -> Optional[Callable]:
        """Get optimizer for a model"""
        for key in cls._registry:
            if key.lower() in model_name.lower():
                return cls._registry[key]['optimizer']
        return None
    
    @classmethod
    def get_config(cls, model_name: str) -> Optional[Dict[str, Any]]:
        """Get config for a model"""
        for key in cls._registry:
            if key.lower() in model_name.lower():
                return cls._registry[key]['config']
        return None
    
    @classmethod
    def detect_model_type(cls, model: nn.Module) -> str:
        """
        Auto-detect model type from architecture
        Supports: Qwen3, Gemma3, LLaMA, Mistral, etc.
        """
        model_class = model.__class__.__name__.lower()
        
        # Check for Qwen3
        if 'qwen' in model_class or hasattr(model, 'qwen'):
            return 'qwen3'
        
        # Check for Gemma3
        if 'gemma' in model_class or hasattr(model, 'gemma'):
            return 'gemma3'
        
        # Check for LLaMA
        if 'llama' in model_class:
            return 'llama'
        
        # Check for Mistral
        if 'mistral' in model_class:
            return 'mistral'
        
        # Check for GPT
        if 'gpt' in model_class:
            return 'gpt'
        
        # Default to universal
        return 'universal'
    
    @classmethod
    def list_supported_models(cls) -> list:
        """List all registered models"""
        return list(cls._registry.keys())


def register_model(name: str, config: Dict[str, Any] = None):
    """Decorator for registering model optimizers"""
    def decorator(optimizer_class):
        ModelRegistry.register(name, optimizer_class, config or {})
        return optimizer_class
    return decorator


# Register known model patterns
ModelRegistry.register('qwen3', None, {
    'supports_moe': True,
    'supports_thinking_mode': True,
    'max_context': 131072,  # 128K
    'recommended_quantization': 'int4',
    'group_size': 128,
})

ModelRegistry.register('gemma3', None, {
    'supports_multimodal': True,
    'supports_function_calling': True,
    'max_context': 131072,  # 128K
    'recommended_quantization': 'int4',
    'group_size': 128,
})

ModelRegistry.register('llama', None, {
    'max_context': 32768,
    'recommended_quantization': 'int4',
    'group_size': 128,
})

ModelRegistry.register('mistral', None, {
    'supports_moe': True,
    'max_context': 32768,
    'recommended_quantization': 'int4',
    'group_size': 128,
})
