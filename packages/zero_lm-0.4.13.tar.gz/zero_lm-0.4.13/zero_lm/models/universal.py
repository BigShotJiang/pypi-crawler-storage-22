"""
Universal Model Optimizer
Works with any transformer model
Automatically detects and applies best optimizations
"""

import torch
import torch.nn as nn
from typing import Optional, Dict, Any, List
import logging

logger = logging.getLogger(__name__)


class UniversalModelOptimizer:
    """
    Universal optimizer for any transformer model
    - Auto-detects architecture
    - Applies best practices
    - Embeds optimizations into model
    """
    
    def __init__(self, aggressive: bool = True):
        self.aggressive = aggressive
        self.optimizations_applied = []
    
    def optimize(
        self,
        model: nn.Module,
        target_size_mb: Optional[float] = None,
        target_device: str = "mobile",
    ) -> nn.Module:
        """
        Apply universal optimizations
        
        Args:
            model: Input model
            target_size_mb: Target model size in MB (auto if None)
            target_device: "mobile", "desktop", or "server"
        """
        logger.info(f"Applying universal optimizations for {target_device}...")
        
        # Detect model architecture
        arch_info = self._detect_architecture(model)
        logger.info(f"Detected architecture: {arch_info}")
        
        # Apply optimizations based on target
        if target_device == "mobile":
            model = self._optimize_for_mobile(model, target_size_mb)
        elif target_device == "desktop":
            model = self._optimize_for_desktop(model)
        else:
            model = self._optimize_for_server(model)
        
        logger.info(f"Applied optimizations: {', '.join(self.optimizations_applied)}")
        return model
    
    def _detect_architecture(self, model: nn.Module) -> Dict[str, Any]:
        """Detect model architecture details"""
        info = {
            'total_params': sum(p.numel() for p in model.parameters()),
            'num_layers': 0,
            'hidden_size': 0,
            'num_attention_heads': 0,
            'has_moe': False,
            'has_vision': False,
        }
        
        # Count layers
        for name, module in model.named_modules():
            if 'layer' in name.lower() and isinstance(module, nn.Module):
                info['num_layers'] += 1
            
            if 'moe' in name.lower() or 'expert' in name.lower():
                info['has_moe'] = True
            
            if 'vision' in name.lower() or 'image' in name.lower():
                info['has_vision'] = True
            
            # Try to get hidden size
            if hasattr(module, 'hidden_size'):
                info['hidden_size'] = module.hidden_size
            
            # Try to get num heads
            if hasattr(module, 'num_attention_heads'):
                info['num_attention_heads'] = module.num_attention_heads
        
        return info
    
    def _optimize_for_mobile(
        self,
        model: nn.Module,
        target_size_mb: Optional[float] = None,
    ) -> nn.Module:
        """
        Aggressive optimizations for mobile
        - INT4 quantization
        - Streaming attention
        - Layer fusion
        - Pruning (if needed)
        """
        # 1. Mark all linear layers for INT4 quantization
        for name, module in model.named_modules():
            if isinstance(module, nn.Linear):
                module._zero_quantize = True
                module._zero_quantize_bits = 4
                module._zero_group_size = 128
        
        self.optimizations_applied.append("INT4 quantization")
        
        # 2. Enable streaming attention
        for name, module in model.named_modules():
            if 'attention' in name.lower() or 'attn' in name.lower():
                module._zero_streaming = True
                module._zero_max_cache_size = 512
                module._zero_attention_sink_size = 4
        
        self.optimizations_applied.append("Streaming attention")
        
        # 3. Mark embeddings for INT8 (less aggressive)
        for name, module in model.named_modules():
            if isinstance(module, nn.Embedding):
                module._zero_quantize = True
                module._zero_quantize_bits = 8
        
        self.optimizations_applied.append("INT8 embeddings")
        
        # 4. Enable layer fusion
        model._zero_fuse_layers = True
        self.optimizations_applied.append("Layer fusion")
        
        # 5. Enable Triton acceleration - REMOVED (Legacy)
        # model._zero_use_triton = True
        self.optimizations_applied.append("Triton acceleration (Reserved)")
        
        return model
    
    def _optimize_for_desktop(self, model: nn.Module) -> nn.Module:
        """
        Balanced optimizations for desktop
        - INT8 quantization
        - Streaming attention
        - Flash attention
        """
        # INT8 quantization
        for name, module in model.named_modules():
            if isinstance(module, nn.Linear):
                module._zero_quantize = True
                module._zero_quantize_bits = 8
        
        self.optimizations_applied.append("INT8 quantization")
        
        # Streaming attention
        for name, module in model.named_modules():
            if 'attention' in name.lower():
                module._zero_streaming = True
                module._zero_max_cache_size = 1024
        
        self.optimizations_applied.append("Streaming attention")
        
        return model
    
    def _optimize_for_server(self, model: nn.Module) -> nn.Module:
        """
        Light optimizations for server
        - FP16/BF16
        - Flash attention
        - Batch optimization
        """
        # FP16 conversion
        model._zero_dtype = torch.float16
        self.optimizations_applied.append("FP16 precision")
        
        # Flash attention
        for name, module in model.named_modules():
            if 'attention' in name.lower():
                module._zero_flash_attention = True
        
        self.optimizations_applied.append("Flash attention")
        
        return model
    
    def embed_optimizations(self, model: nn.Module) -> nn.Module:
        """
        [DEPRECATED] Embed all optimizations directly into model architecture
        This method is deprecated as ModelConverter has been removed.
        Use zero-cli for native conversion instead.
        """
        logger.warning("embed_optimizations is deprecated. Use 'zero convert' CLI instead.")
        return model
    
    def get_optimization_summary(self) -> Dict[str, Any]:
        """Get summary of applied optimizations"""
        return {
            'optimizations': self.optimizations_applied,
            'count': len(self.optimizations_applied),
        }
