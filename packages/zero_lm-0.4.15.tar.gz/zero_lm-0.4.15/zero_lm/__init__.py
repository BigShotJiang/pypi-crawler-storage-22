import os
import sys
import warnings
from packaging.version import Version

try:
    from importlib.metadata import version, PackageNotFoundError
except ImportError:
    from importlib_metadata import version, PackageNotFoundError

try:
    __version__ = version("zero-lm")
except PackageNotFoundError:
    __version__ = "0.3.6"

# 2. Smart Dependency Checks (Unsloth-style)
def _check_deps():
    # Check PyTorch
    try:
        import torch
    except ImportError:
        raise ImportError(
            "ZERO-LM: PyTorch is not installed. Please install it from https://pytorch.org/"
        )
    
    # Check Torchvision (Common issue)
    try:
        import torchvision
    except ImportError:
        warnings.warn(
            "ZERO-LM: torchvision is not installed! Some custom models (like GLM-4) may fail to load.\n"
            "Please install it: pip install torchvision"
        )

_check_deps()

from .core.model import ZeroModel
from .core.config import ZeroConfig
from .attention.streaming import StreamingAttention
from .quantization.quantizer import Quantizer
from .loaders.hf_loader import HuggingFaceLoader

__all__ = [
    "ZeroModel",
    "ZeroConfig",
    "StreamingAttention",
    "Quantizer",
    "HuggingFaceLoader",
]
