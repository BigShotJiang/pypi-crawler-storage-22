"""
Configuration CLI
Interactive configuration tool
"""

import sys
from pathlib import Path
from typing import Optional
import json

try:
    from ..config import ZeroConfig, ConfigPresets, list_presets
except ImportError:
    # Fallback for direct execution
    sys.path.insert(0, str(Path(__file__).parent.parent.parent))
    from zero_lm.config import ZeroConfig, ConfigPresets, list_presets


class ConfigCLI:
    """Interactive configuration CLI"""
    
    @staticmethod
    def create_interactive() -> ZeroConfig:
        """Create configuration interactively"""
        
        print("\n" + "="*70)
        print("  ZERO Configuration Wizard")
        print("="*70 + "\n")
        
        # Ask for preset or custom
        print("Choose configuration mode:")
        print("  1. Use preset (recommended)")
        print("  2. Custom configuration")
        
        choice = input("\nYour choice (1-2): ").strip()
        
        if choice == "1":
            return ConfigCLI._create_from_preset()
        else:
            return ConfigCLI._create_custom()
    
    @staticmethod
    def _create_from_preset() -> ZeroConfig:
        """Create from preset"""
        
        print("\n" + "-"*70)
        print("Available Presets:")
        print("-"*70)
        
        presets = list_presets()
        for i, preset in enumerate(presets, 1):
            print(f"\n{i}. {preset['name']}")
            print(f"   {preset['description']}")
            print(f"   Use case: {preset['use_case']}")
        
        print("\n" + "-"*70)
        choice = input(f"\nChoose preset (1-{len(presets)}): ").strip()
        
        try:
            idx = int(choice) - 1
            preset_name = presets[idx]['name']
            
            if preset_name == 'quality_first':
                config = ConfigPresets.quality_first()
            elif preset_name == 'balanced':
                config = ConfigPresets.balanced()
            elif preset_name == 'speed_first':
                config = ConfigPresets.speed_first()
            elif preset_name == 'mobile_phone':
                config = ConfigPresets.mobile_phone()
            elif preset_name == 'mobile_tablet':
                config = ConfigPresets.mobile_tablet()
            elif preset_name == 'desktop':
                config = ConfigPresets.desktop()
            elif preset_name == 'server':
                config = ConfigPresets.server()
            elif preset_name == 'unlimited_context':
                config = ConfigPresets.unlimited_context()
            elif preset_name == 'research':
                config = ConfigPresets.research()
            else:
                config = ConfigPresets.balanced()
            
            print(f"\n✓ Using preset: {preset_name}")
            return config
        
        except (ValueError, IndexError):
            print("\n⚠ Invalid choice, using 'balanced' preset")
            return ConfigPresets.balanced()
    
    @staticmethod
    def _create_custom() -> ZeroConfig:
        """Create custom configuration"""
        
        print("\n" + "-"*70)
        print("Custom Configuration")
        print("-"*70 + "\n")
        
        # Quantization
        print("Quantization Settings:")
        quant_bits = ConfigCLI._ask_choice(
            "Quantization bits",
            ["4 (smallest, fastest)", "8 (balanced)", "16 (best quality)"],
            default=0
        )
        bits_map = {0: 4, 1: 8, 2: 16}
        bits = bits_map[quant_bits]
        
        # Streaming
        print("\nStreaming Attention Settings:")
        cache_size = ConfigCLI._ask_number(
            "Max cache size (tokens)",
            default=512,
            min_val=128,
            max_val=4096
        )
        
        # Device target
        print("\nTarget Device:")
        device_choice = ConfigCLI._ask_choice(
            "Target device",
            ["Mobile (4GB)", "Tablet (8GB)", "Desktop (16GB+)", "Server"],
            default=2
        )
        
        # Create config
        from ..config import QuantizationConfig, StreamingConfig, MobileConfig
        
        config = ZeroConfig(
            quantization=QuantizationConfig(
                enabled=True,
                bits=bits,
                method=f"int{bits}",
            ),
            streaming=StreamingConfig(
                enabled=True,
                max_cache_size=cache_size,
            ),
            mobile=MobileConfig(
                enabled=device_choice < 2,
                target_ram_mb=[4096, 8192, 16384, 32768][device_choice],
            ),
        )
        
        print("\n✓ Custom configuration created")
        return config
    
    @staticmethod
    def _ask_choice(prompt: str, choices: list, default: int = 0) -> int:
        """Ask user to choose from list"""
        
        print(f"\n{prompt}:")
        for i, choice in enumerate(choices):
            marker = " (default)" if i == default else ""
            print(f"  {i+1}. {choice}{marker}")
        
        user_input = input(f"\nYour choice (1-{len(choices)}) [{default+1}]: ").strip()
        
        if not user_input:
            return default
        
        try:
            choice = int(user_input) - 1
            if 0 <= choice < len(choices):
                return choice
            else:
                return default
        except ValueError:
            return default
    
    @staticmethod
    def _ask_number(
        prompt: str,
        default: int,
        min_val: Optional[int] = None,
        max_val: Optional[int] = None
    ) -> int:
        """Ask user for number"""
        
        range_str = ""
        if min_val is not None and max_val is not None:
            range_str = f" ({min_val}-{max_val})"
        
        user_input = input(f"{prompt}{range_str} [{default}]: ").strip()
        
        if not user_input:
            return default
        
        try:
            value = int(user_input)
            
            if min_val is not None and value < min_val:
                print(f"⚠ Value too small, using {min_val}")
                return min_val
            
            if max_val is not None and value > max_val:
                print(f"⚠ Value too large, using {max_val}")
                return max_val
            
            return value
        
        except ValueError:
            print(f"⚠ Invalid input, using default: {default}")
            return default
    
    @staticmethod
    def save_config(config: ZeroConfig, path: str):
        """Save configuration to file"""
        
        config.save(path)
        print(f"\n✓ Configuration saved to: {path}")
    
    @staticmethod
    def load_config(path: str) -> ZeroConfig:
        """Load configuration from file"""
        
        config = ZeroConfig.load(path)
        print(f"\n✓ Configuration loaded from: {path}")
        return config
    
    @staticmethod
    def print_config(config: ZeroConfig):
        """Print configuration"""
        
        print("\n" + "="*70)
        print("Configuration Summary")
        print("="*70)
        
        # Quantization
        print("\nQuantization:")
        print(f"  Enabled: {config.quantization.enabled}")
        print(f"  Bits: {config.quantization.bits}")
        print(f"  Method: {config.quantization.method}")
        print(f"  Group size: {config.quantization.group_size}")
        
        # Streaming
        print("\nStreaming Attention:")
        print(f"  Enabled: {config.streaming.enabled}")
        print(f"  Max cache: {config.streaming.max_cache_size}")
        print(f"  Attention sinks: {config.streaming.attention_sink_size}")
        print(f"  Window size: {config.streaming.window_size}")
        
        # Triton
        print("\nTriton Acceleration:")
        print(f"  Enabled: {config.triton.enabled}")
        print(f"  Auto-detect: {config.triton.auto_detect}")
        
        # Mobile
        if config.mobile.enabled:
            print("\nMobile Optimization:")
            print(f"  Target RAM: {config.mobile.target_ram_mb}MB")
            print(f"  Device: {config.mobile.target_device}")
            print(f"  Aggressive: {config.mobile.aggressive}")
        
        # Optimization
        print("\nOptimization:")
        print(f"  Level: {config.optimization.level}")
        print(f"  Progressive: {config.optimization.progressive}")
        print(f"  Adaptive: {config.optimization.adaptive}")
        print(f"  Safety checks: {config.optimization.safety_checks}")
        
        print("="*70 + "\n")


def main():
    """Main CLI entry point"""
    
    import argparse
    
    parser = argparse.ArgumentParser(description="ZERO Configuration Tool")
    parser.add_argument('--create', action='store_true', help='Create new configuration')
    parser.add_argument('--load', type=str, help='Load configuration from file')
    parser.add_argument('--save', type=str, help='Save configuration to file')
    parser.add_argument('--preset', type=str, help='Use preset configuration')
    
    args = parser.parse_args()
    
    cli = ConfigCLI()
    
    if args.load:
        config = cli.load_config(args.load)
        cli.print_config(config)
    
    elif args.preset:
        from ..config import get_preset
        config = get_preset(args.preset)
        print(f"\n✓ Using preset: {args.preset}")
        cli.print_config(config)
        
        if args.save:
            cli.save_config(config, args.save)
    
    elif args.create:
        config = cli.create_interactive()
        cli.print_config(config)
        
        if args.save:
            cli.save_config(config, args.save)
    
    else:
        parser.print_help()


if __name__ == '__main__':
    main()
