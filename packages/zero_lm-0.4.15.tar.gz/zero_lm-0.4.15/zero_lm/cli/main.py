import argparse
import sys
import logging
import torch
from pathlib import Path
from zero_lm import ZeroModel, ZeroConfig
from zero_lm.mobile.ultra_mobile_optimizer import UltraMobileOptimizer

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

def convert_model(args):
    """
    Handle the 'convert' command.
    Standardizes models to ZERO Native Format (.zero)
    """
    model_name_or_path = args.model
    output_path = args.output
    
    if not output_path:
        # Default name: {model_name}.zero
        name = Path(model_name_or_path).name
        output_path = f"{name}.zero"
        
    logger.info(f"🚀 ZERO Converter Initialized")
    logger.info(f"   Target: {model_name_or_path}")
    logger.info(f"   Quantization: {args.quantization.upper()}")
    logger.info(f"   Context Length: {args.context_length}")
    
    if args.ram_gb:
        logger.info(f"   Target RAM: {args.ram_gb}GB")
        
    try:
        # 1. Direct Streaming Conversion (Zero-Copy)
        from zero_lm.core.native import ZeroNativeFormat
        
        # Check if we should use legacy loading (only if explicit optimizer requested?)
        # For now, default to the robust Zero-Copy method for all HF models
        logger.info("   Phase 1: Starting Direct Streaming Conversion (Zero-Copy)...")
        
        ZeroNativeFormat.convert_from_hf(
            model_id=model_name_or_path,
            save_path=output_path,
            quantization_type=args.quantization,
            context_length=args.context_length
        )
        
        logger.info(f"✅ Conversion Complete: {output_path}")
        logger.info(f"   You can now load this model with: ZeroModel.from_pretrained('{output_path}')")
        
    except Exception as e:
        logger.error(f"❌ Conversion Failed: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)

def main():
    parser = argparse.ArgumentParser(description="ZERO CLI - AI Democracy Tools")
    subparsers = parser.add_subparsers(dest="command", help="Command to execute")
    
    # zero convert
    convert_parser = subparsers.add_parser("convert", help="Convert any model to ZERO Native Format")
    convert_parser.add_argument("--model", "-m", type=str, required=True, help="HuggingFace model ID or local path")
    convert_parser.add_argument("--output", "-o", type=str, help="Output path (default: model_name.zero)")
    convert_parser.add_argument("--quantization", "-q", type=str, default="int4", choices=["int4", "int8", "fp16", "mixed"], help="Target quantization")
    convert_parser.add_argument("--context-length", type=int, default=512, help="Max context length for streaming (default: 512)")
    convert_parser.add_argument("--ram-gb", type=int, help="Target RAM in GB for optimization (e.g. 6, 8, 16)")
    convert_parser.add_argument("--quality", type=str, default="balanced", choices=["balanced", "max_quality", "max_compression"], help="Optimization quality mode")
    convert_parser.set_defaults(func=convert_model)
    
    # Parse
    args = parser.parse_args()
    
    if hasattr(args, "func"):
        args.func(args)
    else:
        parser.print_help()

if __name__ == "__main__":
    main()
