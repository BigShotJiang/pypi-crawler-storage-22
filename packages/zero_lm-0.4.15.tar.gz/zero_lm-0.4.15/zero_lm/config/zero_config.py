"""
ZERO Configuration System
Comprehensive, validated, and user-friendly configuration
"""

import json
import yaml
from pathlib import Path
from typing import Optional, Dict, Any, List, Union
from dataclasses import dataclass, field, asdict
import logging

logger = logging.getLogger(__name__)


@dataclass
class QuantizationConfig:
    """
    Quantization configuration
    
    Args:
        enabled: Enable quantization
        bits: Quantization bits (4, 8, 16)
        method: Quantization method ('int4', 'int8', 'gptq', 'awq')
        group_size: Group size for quantization
        symmetric: Use symmetric quantization
        dynamic: Use dynamic quantization
        calibration_samples: Number of calibration samples
    """
    enabled: bool = True
    bits: int = 4
    method: str = "int4"
    group_size: int = 128
    symmetric: bool = True
    dynamic: bool = False
    calibration_samples: int = 512
    
    def validate(self) -> List[str]:
        """Validate configuration"""
        errors = []
        
        if self.bits not in [4, 8, 16]:
            errors.append(f"Invalid bits: {self.bits}. Must be 4, 8, or 16")
        
        if self.method not in ['int4', 'int8', 'int16', 'gptq', 'awq']:
            errors.append(f"Invalid method: {self.method}")
        
        if self.group_size <= 0 or self.group_size > 1024:
            errors.append(f"Invalid group_size: {self.group_size}. Must be 1-1024")
        
        if self.calibration_samples < 0:
            errors.append(f"Invalid calibration_samples: {self.calibration_samples}")
        
        return errors


@dataclass
class StreamingConfig:
    """
    Streaming attention configuration
    
    Args:
        enabled: Enable streaming attention
        max_cache_size: Maximum KV cache size
        attention_sink_size: Number of attention sink tokens
        window_size: Sliding window size
        eviction_policy: Cache eviction policy ('fifo', 'lru', 'adaptive')
    """
    enabled: bool = True
    max_cache_size: int = 512
    attention_sink_size: int = 4
    window_size: int = 256
    eviction_policy: str = "adaptive"
    
    def validate(self) -> List[str]:
        """Validate configuration"""
        errors = []
        
        if self.max_cache_size <= 0:
            errors.append(f"Invalid max_cache_size: {self.max_cache_size}")
        
        if self.attention_sink_size < 0 or self.attention_sink_size > self.max_cache_size:
            errors.append(f"Invalid attention_sink_size: {self.attention_sink_size}")
        
        if self.window_size <= 0:
            errors.append(f"Invalid window_size: {self.window_size}")
        
        if self.eviction_policy not in ['fifo', 'lru', 'adaptive']:
            errors.append(f"Invalid eviction_policy: {self.eviction_policy}")
        
        return errors


@dataclass
class TritonConfig:
    """
    Triton acceleration configuration
    
    Args:
        enabled: Enable Triton acceleration
        auto_detect: Auto-detect Triton availability
        block_size: Block size for Triton kernels
        num_warps: Number of warps per block
        num_stages: Number of pipeline stages
    """
    enabled: bool = True
    auto_detect: bool = True
    block_size: int = 1024
    num_warps: int = 4
    num_stages: int = 2
    
    def validate(self) -> List[str]:
        """Validate configuration"""
        errors = []
        
        if self.block_size not in [128, 256, 512, 1024, 2048]:
            errors.append(f"Invalid block_size: {self.block_size}")
        
        if self.num_warps not in [1, 2, 4, 8]:
            errors.append(f"Invalid num_warps: {self.num_warps}")
        
        if self.num_stages < 1 or self.num_stages > 4:
            errors.append(f"Invalid num_stages: {self.num_stages}")
        
        return errors


@dataclass
class MobileConfig:
    """
    Mobile optimization configuration
    
    Args:
        enabled: Enable mobile optimizations
        target_ram_mb: Target RAM budget in MB
        target_device: Target device type
        aggressive: Use aggressive optimizations
        mixed_precision: Enable mixed precision
        operator_fusion: Enable operator fusion
    """
    enabled: bool = False
    target_ram_mb: int = 4096
    target_device: str = "mobile"
    aggressive: bool = True
    mixed_precision: bool = True
    operator_fusion: bool = True
    
    def validate(self) -> List[str]:
        """Validate configuration"""
        errors = []
        
        if self.target_ram_mb < 512 or self.target_ram_mb > 32768:
            errors.append(f"Invalid target_ram_mb: {self.target_ram_mb}")
        
        if self.target_device not in ['mobile', 'tablet', 'desktop', 'server']:
            errors.append(f"Invalid target_device: {self.target_device}")
        
        return errors


@dataclass
class OptimizationConfig:
    """
    General optimization configuration
    
    Args:
        level: Optimization level (0-3)
        progressive: Use progressive optimization
        adaptive: Use adaptive optimization
        safety_checks: Enable safety checks
        validation: Enable validation
        backup_original: Backup original model
    """
    level: int = 2
    progressive: bool = True
    adaptive: bool = True
    safety_checks: bool = True
    validation: bool = True
    backup_original: bool = True
    
    def validate(self) -> List[str]:
        """Validate configuration"""
        errors = []
        
        if self.level < 0 or self.level > 3:
            errors.append(f"Invalid level: {self.level}. Must be 0-3")
        
        return errors


@dataclass
class ZeroConfig:
    """
    Main ZERO configuration
    
    This is the central configuration object that combines all settings.
    All values are configurable and validated.
    """
    
    # Model settings
    model_name: Optional[str] = None
    model_type: Optional[str] = None
    
    # Sub-configurations
    quantization: QuantizationConfig = field(default_factory=QuantizationConfig)
    streaming: StreamingConfig = field(default_factory=StreamingConfig)
    triton: TritonConfig = field(default_factory=TritonConfig)
    mobile: MobileConfig = field(default_factory=MobileConfig)
    optimization: OptimizationConfig = field(default_factory=OptimizationConfig)
    
    # Advanced settings
    dtype: str = "float16"
    device: str = "auto"
    seed: int = 42
    
    # Logging
    verbose: bool = True
    log_level: str = "INFO"
    
    def validate(self) -> bool:
        """
        Validate entire configuration
        
        Returns:
            True if valid, raises ValueError if invalid
        """
        all_errors = []
        
        # Validate sub-configs
        all_errors.extend(self.quantization.validate())
        all_errors.extend(self.streaming.validate())
        all_errors.extend(self.triton.validate())
        all_errors.extend(self.mobile.validate())
        all_errors.extend(self.optimization.validate())
        
        # Validate main config
        if self.dtype not in ['float16', 'float32', 'bfloat16']:
            all_errors.append(f"Invalid dtype: {self.dtype}")
        
        if self.device not in ['auto', 'cpu', 'cuda', 'mps']:
            all_errors.append(f"Invalid device: {self.device}")
        
        if self.log_level not in ['DEBUG', 'INFO', 'WARNING', 'ERROR']:
            all_errors.append(f"Invalid log_level: {self.log_level}")
        
        if all_errors:
            error_msg = "Configuration validation failed:\n" + "\n".join(f"  - {e}" for e in all_errors)
            raise ValueError(error_msg)
        
        return True
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary"""
        return asdict(self)
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'ZeroConfig':
        """Create from dictionary"""
        # Handle nested configs
        if 'quantization' in data and isinstance(data['quantization'], dict):
            data['quantization'] = QuantizationConfig(**data['quantization'])
        
        if 'streaming' in data and isinstance(data['streaming'], dict):
            data['streaming'] = StreamingConfig(**data['streaming'])
        
        if 'triton' in data and isinstance(data['triton'], dict):
            data['triton'] = TritonConfig(**data['triton'])
        
        if 'mobile' in data and isinstance(data['mobile'], dict):
            data['mobile'] = MobileConfig(**data['mobile'])
        
        if 'optimization' in data and isinstance(data['optimization'], dict):
            data['optimization'] = OptimizationConfig(**data['optimization'])
        
        return cls(**data)
    
    def save(self, path: Union[str, Path], format: str = "json"):
        """
        Save configuration to file
        
        Args:
            path: Path to save
            format: File format ('json' or 'yaml')
        """
        path = Path(path)
        data = self.to_dict()
        
        if format == "json":
            with open(path, 'w') as f:
                json.dump(data, f, indent=2)
        elif format == "yaml":
            with open(path, 'w') as f:
                yaml.dump(data, f, default_flow_style=False)
        else:
            raise ValueError(f"Unsupported format: {format}")
        
        logger.info(f"Configuration saved to {path}")
    
    @classmethod
    def load(cls, path: Union[str, Path]) -> 'ZeroConfig':
        """
        Load configuration from file
        
        Args:
            path: Path to load from
        
        Returns:
            ZeroConfig instance
        """
        path = Path(path)
        
        if not path.exists():
            raise FileNotFoundError(f"Configuration file not found: {path}")
        
        if path.suffix == '.json':
            with open(path, 'r') as f:
                data = json.load(f)
        elif path.suffix in ['.yaml', '.yml']:
            with open(path, 'r') as f:
                data = yaml.safe_load(f)
        else:
            raise ValueError(f"Unsupported file format: {path.suffix}")
        
        config = cls.from_dict(data)
        config.validate()
        
        logger.info(f"Configuration loaded from {path}")
        return config


class ConfigValidator:
    """Utility class for configuration validation"""
    
    @staticmethod
    def validate_config(config: ZeroConfig) -> bool:
        """Validate configuration"""
        return config.validate()
    
    @staticmethod
    def check_compatibility(config: ZeroConfig) -> Dict[str, Any]:
        """
        Check configuration compatibility
        
        Returns:
            Dictionary with compatibility warnings
        """
        warnings = []
        
        # Check Triton + CPU
        if config.triton.enabled and config.device == 'cpu':
            warnings.append("Triton acceleration requires GPU. Will be disabled on CPU.")
        
        # Check mobile + high precision
        if config.mobile.enabled and config.dtype == 'float32':
            warnings.append("Mobile optimization works best with float16. Consider changing dtype.")
        
        # Check streaming + small cache
        if config.streaming.enabled and config.streaming.max_cache_size < 256:
            warnings.append("Small cache size may impact quality. Consider increasing max_cache_size.")
        
        # Check quantization + bits mismatch
        if config.quantization.enabled:
            if config.quantization.method == 'int4' and config.quantization.bits != 4:
                warnings.append(f"Method 'int4' but bits={config.quantization.bits}. Should be 4.")
        
        return {
            'compatible': len(warnings) == 0,
            'warnings': warnings,
        }


def load_config(path: Union[str, Path]) -> ZeroConfig:
    """Load configuration from file"""
    return ZeroConfig.load(path)


def save_config(config: ZeroConfig, path: Union[str, Path], format: str = "json"):
    """Save configuration to file"""
    config.save(path, format)
