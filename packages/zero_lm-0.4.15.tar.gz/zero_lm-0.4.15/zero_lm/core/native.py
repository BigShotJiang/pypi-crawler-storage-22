import json
import logging
import torch
import torch.nn as nn
from pathlib import Path
from typing import Optional, Dict, Any, Union

logger = logging.getLogger(__name__)

class ZeroNativeFormat:
    """
    The Soul of AI Democracy.
    Preserves the model exactly as it is, accessible to everyone.
    Handles the ZERO Native Format (.zero) specification.
    """
    
    VERSION = "1.0"
    
    @staticmethod
    def save(model_wrapper: Any, save_path: Union[str, Path]):
        """
        Save model in ZERO Native Format.
        
        Args:
            model_wrapper: The ZeroModel wrapper instance containing model and config
            save_path: Directory path to save the .zero bundle
        """
        save_path = Path(save_path)
        save_path.mkdir(parents=True, exist_ok=True)
        
        logger.info(f"Saving model to ZERO Native Format at {save_path}")
        
        # 1. Capture the Soul (State & Config)
        # Extract quantization info
        quantization_method = "fp16" # Default
        if hasattr(model_wrapper.model, "quantization_method"):
             quantization_method = model_wrapper.model.quantization_method
        elif hasattr(model_wrapper.config, "quantization"):
             quantization_method = model_wrapper.config.quantization
             
        # Extract bits info if available
        native_precision = "fp16"
        if "4bit" in str(quantization_method):
            native_precision = "int4"
        elif "8bit" in str(quantization_method):
            native_precision = "int8"
            
        manifest = {
            "format_version": ZeroNativeFormat.VERSION,
            "validation_hash": "", # TODO: Implement hash calculation
            "model_type": getattr(model_wrapper.model.config, "model_type", "transformer"),
            "architecture": model_wrapper.model.config.architectures[0] if hasattr(model_wrapper.model.config, "architectures") else "Unknown",
            "native_precision": native_precision,
            "optimization_level": "standard", # default
            "features": {
                "infinite_context": model_wrapper.config.streaming, # Primary feature flag
                "streaming_attention": model_wrapper.config.streaming, 
                "layer_offloading": False, 
                "quantized": native_precision != "fp16"
            },
            "compatibility": {
                "min_ram_gb": 4, # Estimate based on model size?
                "recommended_backend": "zero_runtime"
            },
            "original_config": model_wrapper.config.to_dict()
        }
        
        # 1.1 Create Capabilities Structure
        capabilities_dir = save_path / "capabilities"
        capabilities_dir.mkdir(exist_ok=True)
        
        # Capability: Streaming
        streaming_config = {
            "enabled": model_wrapper.config.streaming,
            "max_cache_size": getattr(model_wrapper.config, "max_cache_size", 512),
            "attention_sink_size": getattr(model_wrapper.config, "attention_sink_size", 4),
            "window_size": getattr(model_wrapper.config, "window_size", 256),
            "rope_scaling": getattr(model_wrapper.config, "rope_scaling", None)
        }
        with open(capabilities_dir / "streaming_config.json", "w") as f:
            json.dump(streaming_config, f, indent=2)

        # Capability: Offloading
        offload_strategy = {
             "strategy": "auto",
             "device_map": None
        }
        if hasattr(model_wrapper.model, "hf_device_map"):
             manifest["features"]["layer_offloading"] = True
             offload_strategy["device_map"] = model_wrapper.model.hf_device_map
             offload_strategy["strategy"] = "hooks"
        
        with open(capabilities_dir / "offload_strategy.json", "w") as f:
            json.dump(offload_strategy, f, indent=2)
        
        # 2. Preserve the Body (Weights)
        # Use Streaming Save for robustness on low-memory environments (like Kaggle)
        logger.info("Extracting weights (using Streaming Save)...")
        try:
             ZeroNativeFormat._save_weights_streaming(model_wrapper.model, save_path)
        except Exception as e:
             logger.error(f"Failed to save weights: {e}")
             raise e

        # 4. Save Configs
        # Save standard config.json for AutoConfig compatibility
        config_path = save_path / "config.json"
        if hasattr(model_wrapper.model, "config") and hasattr(model_wrapper.model.config, "to_json_string"):
            with open(config_path, "w") as f:
                f.write(model_wrapper.model.config.to_json_string())
        else:
            logger.warning("Could not find standard HF config to save as config.json")
            
        # tokenizer.json (if available)
        if model_wrapper.tokenizer is not None:
            logger.info("Saving tokenizer...")
            model_wrapper.tokenizer.save_pretrained(save_path)

        # 5. Seal with Manifesto
        logger.info("Sealing with zero_manifest.json...")
        with open(save_path / "zero_manifest.json", "w") as f:
            json.dump(manifest, f, indent=2)
            
        logger.info(f"✅ Democratized Model Saved at: {save_path}")

    @staticmethod
    def convert_from_hf(
        model_id: str, 
        save_path: Union[str, Path], 
        quantization_type: str = "int4", 
        context_length: int = 4096,
        token: Optional[str] = None
    ):
        """
        Direct Streaming Conversion (Zero-Copy).
        Converts a HuggingFace model directly to ZERO Native Format without loading the full model into RAM.
        Optimized for memory-constrained environments (e.g. Kaggle T4).
        
        Args:
            model_id: HuggingFace model ID
            save_path: Output directory
            quantization_type: Target quantization ('int4', 'int8', 'fp16')
            context_length: Max context length for capability config
            token: HF Token
        """
        from huggingface_hub import snapshot_download, hf_hub_download
        from safetensors.torch import load_file, save_file
        from ..quantization.int4_quantizer import INT4Quantizer
        import gc
        import shutil
        import os
        
        save_path = Path(save_path)
        save_path.mkdir(parents=True, exist_ok=True)
        capabilities_dir = save_path / "capabilities"
        capabilities_dir.mkdir(exist_ok=True)
        
        logger.info(f"🚀 Starting Direct Streaming Conversion for {model_id}...")
        logger.info(f"   Target: {save_path}")
        logger.info(f"   Mode: Zero-Copy ({quantization_type})")
        
        # 1. Download/Cache Source Model
        # We need the index and shards.
        logger.info("   📥 Fetching model structure...")
        try:
            # First fetch config to check size/params
            config_path = hf_hub_download(model_id, "config.json", token=token)
            with open(config_path, 'r') as f:
                config_data = json.load(f)
                
            # Fetch index to map tensors
            index_path = None
            try:
                index_path = hf_hub_download(model_id, "model.safetensors.index.json", token=token)
            except:
                # Fallback for single-file models
                pass
                
            # Download all safetensors (lazy download via snapshot usually works best)
            logger.info("   📥 Downloading/Verifying weights (Snapshot)...")
            source_path = snapshot_download(
                model_id, 
                allow_patterns=["*.safetensors", "config.json", "tokenizer.json", "tokenizer_config.json", "*.model"],
                token=token
            )
            source_path = Path(source_path)
            
        except Exception as e:
            logger.error(f"❌ Failed to download model: {e}")
            raise e
            
        # 2. Setup Quantizer
        quantizer = None
        if quantization_type == "int4":
            quantizer = INT4Quantizer()
            logger.info("   ⚡ INT4 Quantizer Initialized")
            
        # 3. Stream Processing
        logger.info("   🔄 Processing tensors (Streamed)...")
        
        # Identify input files
        if index_path:
            with open(index_path, 'r') as f:
                index_data = json.load(f)
            weight_map = index_data['weight_map']
            shard_files = sorted(list(set(weight_map.values())))
        else:
            # Single file
            shard_files = ["model.safetensors"]
            if not (source_path / "model.safetensors").exists():
                 # Handle cases like pytorch_model.bin? No, we require safetensors for direct copy for now.
                 # TODO: Add bin support if needed, but modern models use safetensors.
                 found = list(source_path.glob("*.safetensors"))
                 if found:
                     shard_files = [f.name for f in found]
                 else:
                     raise ValueError("No .safetensors found in source model. Zero-Copy requires safetensors.")
        
        # Output State
        current_shard = {}
        current_shard_size = 0
        max_shard_bytes = 2 * 1024**3 # 2GB Shards
        output_shard_count = 0
        final_weight_map = {}
        total_model_size = 0
        
        # Helper to flush shard
        def flush_shard():
            nonlocal current_shard, current_shard_size, output_shard_count
            if not current_shard:
                return
            
            output_shard_count += 1
            filename = f"model-{output_shard_count:05d}-of-XXXXX.safetensors"
            save_file(current_shard, save_path / filename)
            
            # Map tensors
            for k in current_shard.keys():
                final_weight_map[k] = filename  # Placeholder name, will fix later
                
            current_shard = {}
            current_shard_size = 0
            gc.collect()
            if torch.cuda.is_available():
                torch.cuda.empty_cache()
        
        from safetensors import safe_open
        
        # Iterate source shards
        for shard_file in shard_files:
            shard_full_path = source_path / shard_file
            logger.info(f"   📄 Processing source shard: {shard_file}...")
            
            try:
                # Load context managed with safe_open for True Streaming (Tensor-by-Tensor)
                # This minimizes RAM usage to just the largest single tensor, not the whole shard.
                with safe_open(shard_full_path, framework="pt", device="cpu") as f:
                    # Iterate keys without loading data yet
                    for name in f.keys():
                        tensor = f.get_tensor(name)
                        
                        # Determine handling
                        is_weight = "weight" in name and "norm" not in name and "embed" not in name and "lm_head" not in name
                        # Exceptions: Norms, Embeddings, Biases usually stay FP16
                        # Specifically for Qwen/LLaMA:
                        # layers.N.self_attn.q_proj.weight -> Quantize
                        # layers.N.input_layernorm.weight -> Keep
                        
                        # Fix for non-linear weights (like norms)
                        if "norm" in name or "bias" in name or "embed" in name or "wte" in name:
                             is_weight = False
                        
                        # 3.1 Quantization Logic
                        if is_weight and quantizer:
                            # Cast FP8/BF16 -> FP16 first
                            if tensor.dtype == torch.float8_e4m3fn or tensor.dtype == torch.bfloat16:
                                tensor = tensor.to(torch.float16)
                            
                            # Quantize
                            q_weight, scale = quantizer.quantize_tensor(tensor)
                            packed = quantizer.pack_int4(q_weight)
                            
                            # Add to shard (Pack triplet)
                            current_shard[name] = packed
                            current_shard[f"{name}_scale"] = scale
                            # Optional: Store shape? Standard Zero format usually implies it or stores in config/manifest
                            # But ZeroModel expects 'original_shape' param or buffer?
                            # Our native loader reconstructs. 
                            # Wait, INT4Quantizer setup expects 'weight_scale' and 'original_shape' params.
                            # We should save them.
                            current_shard[f"{name}_shape"] = torch.tensor(tensor.shape, dtype=torch.int32)
                            
                            # Size accounting 
                            sz = packed.numel() + scale.numel() * 2 + 16 # Approx
                        else:
                            # Passthrough (Metadata or small tensors)
                            if tensor.dtype == torch.float8_e4m3fn:
                                tensor = tensor.to(torch.float16) # Always standardize to FP16/FP32
                            elif tensor.dtype == torch.bfloat16:
                                tensor = tensor.to(torch.float16)

                            current_shard[name] = tensor
                            sz = tensor.numel() * tensor.element_size()
                            
                        current_shard_size += sz
                        total_model_size += sz
                        
                        # Check flush
                        if current_shard_size > max_shard_bytes:
                            flush_shard()
                        
                        # Explicit cleanup per tensor
                        del tensor
                
                # Shard cleanup
                gc.collect()
                    
            except Exception as e:
                logger.error(f"   ❌ Error processing shard {shard_file}: {e}")
                # Try fallback: Maybe safe_open?
                # For now raise
                raise e
                
        # Final flush
        flush_shard()
        
        # 4. Finalize Files (Rename shards)
        logger.info(f"   🔄 Finalizing {output_shard_count} shards...")
        
        # Rename loop
        final_map_fixed = {}
        for i in range(1, output_shard_count + 1):
            temp_name = f"model-{i:05d}-of-XXXXX.safetensors"
            final_name = f"model-{i:05d}-of-{output_shard_count:05d}.safetensors"
            
            src = save_path / temp_name
            dst = save_path / final_name
            if src.exists():
                src.rename(dst)
                
            # Updates map keys that pointed to temp_name
            for k, v in final_weight_map.items():
                if v == temp_name:
                    final_map_fixed[k] = final_name
                    
        # 5. Write Index & Manifest
        # Index
        index_data = {
            "metadata": {"total_size": total_model_size},
            "weight_map": final_map_fixed
        }
        with open(save_path / "model.safetensors.index.json", "w") as f:
            json.dump(index_data, f, indent=2)
            
        # Manifest
        manifest = {
            "format_version": "1.0",
            "model_type": config_data.get("model_type", "transformer"),
            "architecture": config_data.get("architectures", ["Unknown"])[0],
            "native_precision": quantization_type,
            "features": {
                "infinite_context": True,
                "streaming_attention": True,
                "quantized": quantization_type != "fp16"
            },
            "original_config": config_data
        }
        with open(save_path / "zero_manifest.json", "w") as f:
            json.dump(manifest, f, indent=2)
            
        # Configs
        with open(save_path / "config.json", "w") as f:
            json.dump(config_data, f, indent=2)
            
        # Capability: Streaming
        streaming_config = {
            "enabled": True,
            "max_cache_size": context_length,
            "attention_sink_size": 4,
            "window_size": 256
        }
        with open(capabilities_dir / "streaming_config.json", "w") as f:
            json.dump(streaming_config, f, indent=2)

        # Tokenizer (Copy from source)
        for t_file in ["tokenizer.json", "tokenizer_config.json", "tokenizer.model", "vocab.json", "merges.txt"]:
             src_t = source_path / t_file
             if src_t.exists():
                 shutil.copy(src_t, save_path / t_file)
                 
        logger.info(f"✅ Conversion Complete! Output: {save_path}")


    @staticmethod
    def _save_weights_streaming(model: nn.Module, save_path: Path, max_shard_size_gb: int = 2):
        """
        Save weights using a streaming approach to minimize memory usage.
        Handles both in-memory (CPU/GPU) and offloaded (Meta) tensors.
        Explicitly triggers accelerate hooks to materialize offloaded weights.
        """
        from safetensors.torch import save_file
        import gc
        from accelerate.hooks import ModelHook
        
        logger.info(f"   💾 Streaming weights to disk (Max shard: {max_shard_size_gb}GB)...")
        
        current_shard = {}
        current_shard_size = 0
        max_shard_bytes = max_shard_size_gb * 1024**3
        shard_count = 0
        tensor_to_shard_index = {}
        
        # Get named modules to find parents of parameters
        named_modules = dict(model.named_modules())
        
        all_names = [n for n, _ in model.named_parameters()] + [n for n, _ in model.named_buffers()]
        total_tensors = len(all_names)
        total_model_size = 0
        
        logger.info(f"   Processing {total_tensors} tensors...")

        for i, name in enumerate(all_names):
            try:
                # 1. Resolve Parent Module
                if "." in name:
                    parent_name, attr_name = name.rsplit(".", 1)
                    parent_module = named_modules[parent_name]
                else:
                    parent_name = ""
                    attr_name = name
                    parent_module = model
                
                # 2. Trigger Accelerate Hook (pre_forward) to Load Weights
                # This is crucial for "Disk Offload" where weights are on disk/meta device
                hook_triggered = False
                if hasattr(parent_module, "_hf_hook"):
                    try:
                        # Force load weights
                        parent_module._hf_hook.pre_forward(parent_module)
                        hook_triggered = True
                    except Exception as e:
                        logger.warning(f"     Could not trigger pre_forward hook for {name}: {e}")

                # 3. Access the tensor
                tensor = getattr(parent_module, attr_name)
                
                # 4. Handle Meta Tensors (If hook failed or didn't exist)
                if tensor.device.type == 'meta':
                    # Last ditch effort: Try to use the offload_index if available in accelerate
                    # But if pre_forward failed, we are likely out of luck.
                    logger.warning(f"   ⚠️ Skipping meta tensor {name} (still meta after hook)")
                    
                    # Cleanup hook if we triggered it but it didn't help (unlikely)
                    if hook_triggered and hasattr(parent_module, "_hf_hook"):
                        parent_module._hf_hook.post_forward(parent_module, None)
                    continue

                # 5. Detach and Move to CPU
                tensor_cpu = tensor.detach().cpu()
                
                # 6. Offload Back Immediately (post_forward)
                # Save RAM by offloading this module's weights back to disk/CPU immediately
                if hook_triggered and hasattr(parent_module, "_hf_hook"):
                    # accelerate's post_forward usually offloads if configured to do so
                    parent_module._hf_hook.post_forward(parent_module, None)

                tensor_size = tensor_cpu.numel() * tensor_cpu.element_size()
                total_model_size += tensor_size
                
                # 7. Check shard limit
                if current_shard_size + tensor_size > max_shard_bytes and current_shard:
                    shard_count += 1
                    temp_filename = f"model-{shard_count:05d}-of-XXXXX.safetensors"
                    save_file(current_shard, save_path / temp_filename)
                    
                    # Clear memory aggressively
                    del current_shard
                    current_shard = {}
                    current_shard_size = 0
                    gc.collect()
                    if torch.cuda.is_available():
                        torch.cuda.empty_cache()
                
                current_shard[name] = tensor_cpu
                current_shard_size += tensor_size
                tensor_to_shard_index[name] = shard_count + 1
                
                # Explicit cleanup
                del tensor_cpu
                del tensor
                
                # Periodic GC
                if i % 100 == 0:
                    gc.collect()
            
            except Exception as e:
                logger.error(f"   ❌ Failed to process tensor {name}: {e}")
                raise e
        
        # Save final shard
        if current_shard:
            shard_count += 1
            temp_filename = f"model-{shard_count:05d}-of-XXXXX.safetensors"
            save_file(current_shard, save_path / temp_filename)
            for name in current_shard:
                tensor_to_shard_index[name] = shard_count
            del current_shard
            gc.collect()
            
        # Rename shards
        logger.info(f"   🔄 Renaming {shard_count} shards...")
        final_weight_map = {}
        for i in range(1, shard_count + 1):
            old_name = f"model-{i:05d}-of-XXXXX.safetensors"
            new_name = f"model-{i:05d}-of-{shard_count:05d}.safetensors"
            
            old_path = save_path / old_name
            if old_path.exists():
                old_path.rename(save_path / new_name)
                
        # Build final map
        for name, shard_idx in tensor_to_shard_index.items():
            final_weight_map[name] = f"model-{shard_idx:05d}-of-{shard_count:05d}.safetensors"
            
        # Save index
        index_data = {
            "metadata": {"total_size": total_model_size},
            "weight_map": final_weight_map
        }
        with open(save_path / "model.safetensors.index.json", "w") as f:
            json.dump(index_data, f, indent=2)
            
        logger.info("   ✓ Weights saved successfully")

    @staticmethod
    def load(path: Union[str, Path], device_budget: str = "auto"):
        """
        Load model from ZERO Native Format.
        """
        path = Path(path)
        manifest_path = path / "zero_manifest.json"
        
        if not manifest_path.exists():
            raise FileNotFoundError(f"Not a valid ZERO bundle: {manifest_path} missng")
            
        # 1. Read Manifesto
        with open(manifest_path) as f:
            manifest = json.load(f)
            
        logger.info(f"Loading ZERO Model: {manifest.get('model_type', 'Unknown')}")
            
        # 2. Allocate Resources based on Democracy (Available Hardware)
        if device_budget == "low_ram":
             logger.warning("⚠️ Low RAM detected: Activating Zero-Streaming Loader")
             # Load logic specific for low-end devices
             return ZeroNativeFormat._streaming_load(path, manifest)
        else:
             # Standard Load
             return ZeroNativeFormat._standard_load(path, manifest)

    @staticmethod
    def _standard_load(path: Path, manifest: Dict):
        # Placeholder for standard loading logic using safetensors and config reconstruction
        # This will need to interface with ZeroModel/Transformers to rebuild the model object
        # For now, return the paths/config so ZeroModel can use them
        return {
            "weights": path / "weights.safetensors",
            "config": path / "zero_config.json",
            "manifest": manifest
        }

    @staticmethod
    def _streaming_load(path: Path, manifest: Dict):
        # Placeholder for streaming load
        return ZeroNativeFormat._standard_load(path, manifest)
