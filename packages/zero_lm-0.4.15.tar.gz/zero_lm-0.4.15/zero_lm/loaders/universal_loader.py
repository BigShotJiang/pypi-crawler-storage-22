import logging
import json
from pathlib import Path
from typing import Optional, Dict, Any, Tuple
import torch
import torch.nn as nn
from transformers import AutoTokenizer, AutoConfig, AutoModelForCausalLM

from ..core.config import ZeroConfig
from ..core.native import ZeroNativeFormat
from .hf_loader import HuggingFaceLoader

logger = logging.getLogger(__name__)

class ZeroUniversalLoader:
    """
    The One Loader to Rule Them All.
    Intelligently handles both ZERO Native Format (.zero) and legacy HuggingFace models.
    Prioritizes memory efficiency and preservation of 'Infinite Context'.
    """
    
    def __init__(self, config: ZeroConfig):
        self.config = config
        
    def load(self) -> Tuple[nn.Module, Any]:
        """
        Load model and tokenizer.
        """
        model_path = Path(self.config.model_name_or_path)
        manifest_path = model_path / "zero_manifest.json"
        
        # 1. Check for ZERO Native Format
        if manifest_path.exists():
            logger.info(f"✨ Detected ZERO Native Format at {model_path}")
            return self._load_native(model_path)
        else:
            # 2. Fallback to Legacy (HuggingFace)
            logger.info("📦 Using Legacy HuggingFace Loader")
            return self._load_legacy()

    def _load_native(self, model_path: Path) -> Tuple[nn.Module, Any]:
        """Load from .zero format with Smart Allocation"""
        # Load Manifest
        try:
            with open(model_path / "zero_manifest.json") as f:
                manifest = json.load(f)
        except Exception as e:
            logger.error(f"Failed to load manifest: {e}")
            raise
            
        logger.info(f"   Model Type: {manifest.get('model_type', 'Unknown')}")
        logger.info(f"   Optimization: {manifest.get('optimization_level', 'Standard')}")
        
        if manifest.get("features", {}).get("infinite_context"):
             logger.info("   ∞ Infinite Context: Enabled via Manifest")
             self.config.streaming = True 
             
             # Load detailed streaming config from capabilities if exists
             streaming_config_path = model_path / "capabilities" / "streaming_config.json"
             if streaming_config_path.exists():
                 try:
                     with open(streaming_config_path) as f:
                         stream_conf = json.load(f)
                         self.config.max_cache_size = stream_conf.get("max_cache_size", 512)
                         self.config.attention_sink_size = stream_conf.get("attention_sink_size", 4)
                         self.config.window_size = stream_conf.get("window_size", 256)
                         logger.info(f"     - Cache Size: {self.config.max_cache_size}")
                 except Exception as e:
                     logger.warning(f"     - Failed to load streaming config: {e}")
             
        # Smart Resource Allocation
        device_budget = self._assess_resources()
        if device_budget == "low_ram":
            logger.info("   ⚠️ Low RAM detected: Optimizing for minimal footprint")
            # In a real scenario, this might trigger mmap loading or aggressive offloading
            
        # Reconstruct Model (Phase 2 Simplified: Load weights into HF Architecture)
        # TODO: In Phase 4, we will load directly into a Native ZERO Runtime without HF dependency if possible.
        # For now, we instantiate the HF model structure and load the safetensors.
        
        try:
             # Load config first
             if (model_path / "config.json").exists(): # HF config might be needed for architecture initialization
                 hf_config = AutoConfig.from_pretrained(model_path)
             else:
                 # Fallback to manifest info if distinct standard config missing (Native pure format)
                 # This part requires mapping manifest architecture to HF config, assuming standard config exists for now within native bundle if it was converted
                 # For the prototype, let's assume standard HF config.json is preserved or zero_config has enough.
                 # Let's try loading AutoConfig from the path assuming it's a valid HF directory too + .zero extras
                 hf_config = AutoConfig.from_pretrained(model_path)

             # Initialize empty model
             with torch.device("meta"):
                 model = AutoModelForCausalLM.from_config(hf_config)
                 
             # Load State Dict
             from safetensors.torch import load_file
             state_dict = load_file(model_path / "weights.safetensors")
             
             # Materialize & Load
             model.to_empty(device=self.config.device) # Move to target device (e.g. cpu/cuda)
             model.load_state_dict(state_dict, strict=False) # strict=False to allow for quantization layers if present
             
             # Tokenizer
             tokenizer = AutoTokenizer.from_pretrained(model_path)
             
             return model, tokenizer
             
        except Exception as e:
            logger.error(f"Native Load Logic Failed: {e}")
            logger.info("Fallback to standard from_pretrained on the path...")
            # Emergency fallback
            return self._load_legacy()

    def _load_legacy(self) -> Tuple[nn.Module, Any]:
        """Delegate to existing HuggingFaceLoader"""
        loader = HuggingFaceLoader(self.config)
        return loader.load()

    def _assess_resources(self) -> str:
        """Simple resource check"""
        try:
            import psutil
            vm = psutil.virtual_memory()
            free_gb = vm.available / (1024**3)
            if free_gb < 8:
                return "low_ram"
            return "standard"
        except ImportError:
            return "standard"
