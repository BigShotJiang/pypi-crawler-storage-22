"""
KV Cache Compression
Compress KV cache to reduce memory usage during inference
Critical for long context on mobile devices
"""

import torch
import torch.nn as nn
from typing import Optional, Tuple
import logging

logger = logging.getLogger(__name__)


class KVCacheQuantizer:
    """
    Quantize KV cache to INT8/INT4
    
    KV cache typically consumes significant memory during inference.
    Quantizing it can save 50-75% memory with minimal quality loss.
    """
    
    def __init__(self, bits: int = 8, dynamic: bool = True):
        """
        Args:
            bits: Quantization bits (4 or 8)
            dynamic: Use dynamic quantization per token
        """
        self.bits = bits
        self.dynamic = dynamic
        
        if bits == 8:
            self.qmin = -128
            self.qmax = 127
        elif bits == 4:
            self.qmin = -8
            self.qmax = 7
        elif bits == 16:
            # 16-bit means NO quantization (BF16/FP16)
            self.qmin = None
            self.qmax = None
        else:
            raise ValueError(f"Unsupported bits: {bits}")
    
    def quantize_cache(
        self,
        cache: torch.Tensor,
    ) -> Tuple[torch.Tensor, torch.Tensor]:
        """
        Quantize KV cache
        
        Args:
            cache: KV cache tensor [batch, heads, seq_len, head_dim]
        
        Returns:
            quantized_cache: Quantized cache
            scale: Scale factors
        """
        # If 16-bit, return as is (Pass-through)
        if self.bits == 16:
            return cache, torch.ones(1, device=cache.device, dtype=cache.dtype)

        if self.dynamic:
            # Dynamic quantization per token
            # Calculate scale per token
            max_val = cache.abs().amax(dim=-1, keepdim=True)
            scale = max_val / self.qmax
            scale = torch.clamp(scale, min=1e-8)
            
            # Quantize
            quantized = torch.round(cache / scale).clamp(self.qmin, self.qmax)
        else:
            # Static quantization
            max_val = cache.abs().max()
            scale = max_val / self.qmax
            scale = torch.clamp(scale, min=1e-8)
            
            quantized = torch.round(cache / scale).clamp(self.qmin, self.qmax)
        
        # Convert to int8
        if self.bits == 8:
            quantized = quantized.to(torch.int8)
        else:
            # Store INT4 in int8
            quantized = quantized.to(torch.int8)
        
        return quantized, scale
    
    def dequantize_cache(
        self,
        quantized: torch.Tensor,
        scale: torch.Tensor,
    ) -> torch.Tensor:
        """
        Dequantize KV cache
        
        Args:
            quantized: Quantized cache
            scale: Scale factors
        
        Returns:
            Dequantized cache
        """
        # If 16-bit, it's already float/bfloat (Pass-through)
        if self.bits == 16:
            return quantized

        return quantized.float() * scale
    
    def estimate_memory_savings(self, cache_size_mb: float) -> dict:
        """
        Estimate memory savings
        
        Args:
            cache_size_mb: Original cache size in MB (FP16)
        
        Returns:
            Memory statistics
        """
        if self.bits == 8:
            # INT8: 50% savings from FP16
            quantized_size = cache_size_mb * 0.5
            savings_percent = 50.0
        elif self.bits == 4:
            # INT4: 75% savings from FP16
            quantized_size = cache_size_mb * 0.25
            savings_percent = 75.0
        else:
             # 16-bit: 0% savings
            quantized_size = cache_size_mb
            savings_percent = 0.0
        
        return {
            'original_mb': cache_size_mb,
            'quantized_mb': quantized_size,
            'savings_mb': cache_size_mb - quantized_size,
            'savings_percent': savings_percent,
        }


class KVCacheCompressor:
    """
    Compress KV cache using various techniques
    
    Combines:
    - Quantization (INT8/INT4)
    - Pruning (remove less important tokens)
    - Compression (group similar tokens)
    """
    
    def __init__(
        self,
        quantize_bits: int = 8,
        prune_ratio: float = 0.0,
        compress_ratio: float = 1.0,
    ):
        """
        Args:
            quantize_bits: Quantization bits (4 or 8)
            prune_ratio: Ratio of tokens to prune (0.0 = no pruning)
            compress_ratio: Compression ratio (1.0 = no compression)
        """
        self.quantizer = KVCacheQuantizer(bits=quantize_bits)
        self.prune_ratio = prune_ratio
        self.compress_ratio = compress_ratio
    
    def compress(
        self,
        key_cache: torch.Tensor,
        value_cache: torch.Tensor,
        attention_scores: Optional[torch.Tensor] = None,
    ) -> Tuple[torch.Tensor, torch.Tensor, dict]:
        """
        Compress KV cache
        
        Args:
            key_cache: Key cache
            value_cache: Value cache
            attention_scores: Attention scores for importance-based pruning
        
        Returns:
            compressed_key: Compressed key cache
            compressed_value: Compressed value cache
            metadata: Compression metadata
        """
        metadata = {}
        
        # Step 1: Pruning (if enabled)
        if self.prune_ratio > 0 and attention_scores is not None:
            key_cache, value_cache, prune_info = self._prune_cache(
                key_cache, value_cache, attention_scores
            )
            metadata['pruned_tokens'] = prune_info
        
        # Step 2: Quantization
        key_q, key_scale = self.quantizer.quantize_cache(key_cache)
        value_q, value_scale = self.quantizer.quantize_cache(value_cache)
        
        metadata['quantization'] = {
            'bits': self.quantizer.bits,
            'key_scale': key_scale,
            'value_scale': value_scale,
        }
        
        return key_q, value_q, metadata
    
    def decompress(
        self,
        key_cache: torch.Tensor,
        value_cache: torch.Tensor,
        metadata: dict,
    ) -> Tuple[torch.Tensor, torch.Tensor]:
        """
        Decompress KV cache
        
        Args:
            key_cache: Compressed key cache
            value_cache: Compressed value cache
            metadata: Compression metadata
        
        Returns:
            key: Decompressed key cache
            value: Decompressed value cache
        """
        # Dequantize
        quant_meta = metadata['quantization']
        key = self.quantizer.dequantize_cache(key_cache, quant_meta['key_scale'])
        value = self.quantizer.dequantize_cache(value_cache, quant_meta['value_scale'])
        
        return key, value
    
    def _prune_cache(
        self,
        key_cache: torch.Tensor,
        value_cache: torch.Tensor,
        attention_scores: torch.Tensor,
    ) -> Tuple[torch.Tensor, torch.Tensor, dict]:
        """
        Prune less important tokens from cache
        
        Args:
            key_cache: Key cache
            value_cache: Value cache
            attention_scores: Attention scores
        
        Returns:
            pruned_key: Pruned key cache
            pruned_value: Pruned value cache
            prune_info: Pruning information
        """
        batch, heads, seq_len, head_dim = key_cache.shape
        
        # Calculate importance scores (average attention)
        importance = attention_scores.mean(dim=1)  # [batch, seq_len]
        
        # Keep top-k tokens
        keep_tokens = int(seq_len * (1 - self.prune_ratio))
        _, keep_indices = torch.topk(importance, keep_tokens, dim=-1)
        keep_indices = keep_indices.sort(dim=-1)[0]  # Sort to maintain order
        
        # Prune
        pruned_key = torch.gather(
            key_cache,
            dim=2,
            index=keep_indices.unsqueeze(1).unsqueeze(-1).expand(-1, heads, -1, head_dim)
        )
        pruned_value = torch.gather(
            value_cache,
            dim=2,
            index=keep_indices.unsqueeze(1).unsqueeze(-1).expand(-1, heads, -1, head_dim)
        )
        
        prune_info = {
            'original_length': seq_len,
            'pruned_length': keep_tokens,
            'pruned_count': seq_len - keep_tokens,
        }
        
        return pruned_key, pruned_value, prune_info


class AdaptiveKVCacheManager:
    """
    Adaptive KV Cache Manager
    
    Dynamically adjusts cache compression based on:
    - Available memory
    - Sequence length
    - Quality requirements
    """
    
    def __init__(
        self,
        target_memory_mb: float = 512,
        min_quality: float = 0.95,
    ):
        """
        Args:
            target_memory_mb: Target memory budget for KV cache
            min_quality: Minimum acceptable quality (0-1)
        """
        self.target_memory_mb = target_memory_mb
        self.min_quality = min_quality
        
        # Available compression strategies
        self.strategies = {
            'none': KVCacheCompressor(quantize_bits=16, prune_ratio=0.0),
            'int8': KVCacheCompressor(quantize_bits=8, prune_ratio=0.0),
            'int4': KVCacheCompressor(quantize_bits=4, prune_ratio=0.0),
            'int8_prune10': KVCacheCompressor(quantize_bits=8, prune_ratio=0.1),
            'int4_prune10': KVCacheCompressor(quantize_bits=4, prune_ratio=0.1),
            'int4_prune20': KVCacheCompressor(quantize_bits=4, prune_ratio=0.2),
        }
    
    def select_strategy(
        self,
        current_memory_mb: float,
        seq_length: int,
    ) -> str:
        """
        Select best compression strategy
        
        Args:
            current_memory_mb: Current memory usage
            seq_length: Current sequence length
        
        Returns:
            Strategy name
        """
        memory_pressure = current_memory_mb / self.target_memory_mb
        
        if memory_pressure < 0.5:
            # Low pressure: no compression
            return 'none'
        elif memory_pressure < 0.7:
            # Medium pressure: INT8
            return 'int8'
        elif memory_pressure < 0.85:
            # High pressure: INT4
            return 'int4'
        elif memory_pressure < 0.95:
            # Very high pressure: INT8 + pruning
            return 'int8_prune10'
        else:
            # Critical pressure: INT4 + aggressive pruning
            if seq_length > 2048:
                return 'int4_prune20'
            else:
                return 'int4_prune10'
    
    def compress_adaptive(
        self,
        key_cache: torch.Tensor,
        value_cache: torch.Tensor,
        current_memory_mb: float,
        attention_scores: Optional[torch.Tensor] = None,
    ) -> Tuple[torch.Tensor, torch.Tensor, dict]:
        """
        Compress cache adaptively
        
        Args:
            key_cache: Key cache
            value_cache: Value cache
            current_memory_mb: Current memory usage
            attention_scores: Attention scores
        
        Returns:
            compressed_key: Compressed key
            compressed_value: Compressed value
            metadata: Compression metadata
        """
        seq_length = key_cache.shape[2]
        
        # Select strategy
        strategy_name = self.select_strategy(current_memory_mb, seq_length)
        compressor = self.strategies[strategy_name]
        
        # Compress
        key_q, value_q, metadata = compressor.compress(
            key_cache, value_cache, attention_scores
        )
        
        metadata['strategy'] = strategy_name
        
        logger.debug(f"KV cache compressed using strategy: {strategy_name}")
        
        return key_q, value_q, metadata
