"""
Qwen3 Model Support
Optimized for Qwen3 family: 4B, 30B, 235B (MoE)
Supports thinking/non-thinking modes
"""

import torch
import torch.nn as nn
from typing import Optional, Dict, Any
import logging
from .model_registry import register_model

logger = logging.getLogger(__name__)


class Qwen3Config:
    """Configuration for Qwen3 models"""
    
    def __init__(
        self,
        model_size: str = "30B",
        use_moe: bool = False,
        thinking_mode: bool = False,
        reasoning_budget: int = 5,
        **kwargs
    ):
        self.model_size = model_size
        self.use_moe = use_moe
        self.thinking_mode = thinking_mode
        self.reasoning_budget = reasoning_budget
        self.extra_config = kwargs
    
    @staticmethod
    def detect_from_model(model: nn.Module) -> 'Qwen3Config':
        """Auto-detect Qwen3 configuration"""
        config = Qwen3Config()
        
        # Detect MoE
        for module in model.modules():
            if 'moe' in module.__class__.__name__.lower():
                config.use_moe = True
                break
        
        # Detect model size from parameters
        total_params = sum(p.numel() for p in model.parameters())
        if total_params < 10e9:
            config.model_size = "4B"
        elif total_params < 50e9:
            config.model_size = "30B"
        else:
            config.model_size = "235B"
        
        logger.info(f"Detected Qwen3-{config.model_size} (MoE: {config.use_moe})")
        return config


@register_model('qwen3', {
    'supports_moe': True,
    'supports_thinking_mode': True,
    'max_context': 131072,
})
class Qwen3Optimizer:
    """
    Qwen3-specific optimizations
    - MoE-aware quantization (only active experts)
    - Thinking mode optimization
    - Ultra-long context support (128K+)
    """
    
    def __init__(self, config: Optional[Qwen3Config] = None):
        self.config = config or Qwen3Config()
    
    def optimize_for_mobile(self, model: nn.Module) -> nn.Module:
        """
        Optimize Qwen3 for mobile deployment
        - Quantize only active experts in MoE
        - Reduce reasoning budget for speed
        - Enable streaming attention
        """
        logger.info("Optimizing Qwen3 for mobile...")
        
        if self.config.use_moe:
            model = self._optimize_moe(model)
        
        if self.config.thinking_mode:
            model = self._optimize_thinking_mode(model)
        
        return model
    
    def _optimize_moe(self, model: nn.Module) -> nn.Module:
        """
        MoE-specific optimizations
        - Quantize inactive experts more aggressively
        - Keep active experts in higher precision
        """
        logger.info("Applying MoE optimizations...")
        
        for name, module in model.named_modules():
            if 'expert' in name.lower():
                # Mark for selective quantization
                module._zero_expert = True
                module._zero_quantize_bits = 4  # INT4 for experts
        
        return model
    
    def _optimize_thinking_mode(self, model: nn.Module) -> nn.Module:
        """
        Optimize thinking mode for mobile
        - Reduce reasoning budget
        - Enable fast path for non-thinking queries
        """
        logger.info("Optimizing thinking mode...")
        
        # Reduce reasoning budget for mobile
        if hasattr(model, 'reasoning_budget'):
            model.reasoning_budget = min(self.config.reasoning_budget, 3)
        
        return model
    
    def get_recommended_settings(self) -> Dict[str, Any]:
        """Get recommended settings for Qwen3"""
        return {
            'quantization': 'int4',
            'group_size': 128,
            'streaming': True,
            'max_cache_size': 512,
            'attention_sink_size': 4,
            'use_triton': True,
            'mobile_optimize': True,
        }
