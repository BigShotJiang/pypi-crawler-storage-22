import torch
import torch.nn as nn
from typing import Optional, Literal
import logging

logger = logging.getLogger(__name__)

class Quantizer:
    def __init__(
        self,
        bits: int = 8,
        method: Literal["symmetric", "asymmetric", "dynamic"] = "symmetric",
        per_channel: bool = True,
    ):
        self.bits = bits
        self.method = method
        self.per_channel = per_channel
        self.qmin = -(2 ** (bits - 1))
        self.qmax = 2 ** (bits - 1) - 1
    
    def quantize_tensor(
        self,
        tensor: torch.Tensor,
        return_scale_zero: bool = False
    ):
        if self.method == "dynamic":
            return self._dynamic_quantize(tensor, return_scale_zero)
        elif self.method == "symmetric":
            return self._symmetric_quantize(tensor, return_scale_zero)
        else:
            return self._asymmetric_quantize(tensor, return_scale_zero)
    
    def _symmetric_quantize(
        self,
        tensor: torch.Tensor,
        return_scale_zero: bool = False
    ):
        if self.per_channel and tensor.dim() >= 2:
            max_val = tensor.abs().amax(dim=list(range(1, tensor.dim())), keepdim=True)
        else:
            max_val = tensor.abs().max()
        
        max_val = torch.clamp(max_val, min=1e-8)
        
        scale = max_val / self.qmax
        
        quantized = torch.clamp(
            torch.round(tensor / scale),
            self.qmin,
            self.qmax
        ).to(torch.int8 if self.bits == 8 else torch.int32)
        
        if return_scale_zero:
            return quantized, scale, torch.zeros_like(scale)
        return quantized, scale
    
    def _asymmetric_quantize(
        self,
        tensor: torch.Tensor,
        return_scale_zero: bool = False
    ):
        if self.per_channel and tensor.dim() >= 2:
            min_val = tensor.amin(dim=list(range(1, tensor.dim())), keepdim=True)
            max_val = tensor.amax(dim=list(range(1, tensor.dim())), keepdim=True)
        else:
            min_val = tensor.min()
            max_val = tensor.max()
        
        scale = (max_val - min_val) / (self.qmax - self.qmin)
        scale = torch.clamp(scale, min=1e-8)
        
        zero_point = self.qmin - torch.round(min_val / scale)
        zero_point = torch.clamp(zero_point, self.qmin, self.qmax)
        
        quantized = torch.clamp(
            torch.round(tensor / scale + zero_point),
            self.qmin,
            self.qmax
        ).to(torch.int8 if self.bits == 8 else torch.int32)
        
        if return_scale_zero:
            return quantized, scale, zero_point
        return quantized, scale, zero_point
    
    def _dynamic_quantize(
        self,
        tensor: torch.Tensor,
        return_scale_zero: bool = False
    ):
        return self._symmetric_quantize(tensor, return_scale_zero)
    
    def dequantize_tensor(
        self,
        quantized: torch.Tensor,
        scale: torch.Tensor,
        zero_point: Optional[torch.Tensor] = None
    ) -> torch.Tensor:
        if zero_point is None:
            return quantized.to(scale.dtype) * scale
        else:
            return (quantized.to(scale.dtype) - zero_point) * scale
    
    def quantize_model(self, model: nn.Module) -> nn.Module:
        logger.info(f"Quantizing model to {self.bits}-bit")
        
        for name, module in model.named_modules():
            if isinstance(module, nn.Linear):
                self._quantize_linear(module)
            elif isinstance(module, nn.Conv2d):
                self._quantize_conv2d(module)
        
        logger.info("Model quantization completed")
        return model
    
    def _quantize_linear(self, module: nn.Linear):
        weight = module.weight.data
        quantized_weight, scale, zero_point = self.quantize_tensor(
            weight, return_scale_zero=True
        )
        
        module.weight.data = quantized_weight.to(weight.dtype)
        module.register_buffer('weight_scale', scale)
        if zero_point is not None:
            module.register_buffer('weight_zero_point', zero_point)
    
    def _quantize_conv2d(self, module: nn.Conv2d):
        weight = module.weight.data
        quantized_weight, scale, zero_point = self.quantize_tensor(
            weight, return_scale_zero=True
        )
        
        module.weight.data = quantized_weight.to(weight.dtype)
        module.register_buffer('weight_scale', scale)
        if zero_point is not None:
            module.register_buffer('weight_zero_point', zero_point)
