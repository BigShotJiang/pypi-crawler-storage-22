"""zunzunbee devices."""

ZUNZUNBEE = "zunzunbee"
