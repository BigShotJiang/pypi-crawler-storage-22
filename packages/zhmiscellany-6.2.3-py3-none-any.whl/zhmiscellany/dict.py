import json


def print_dict(ldict):
    print(json.dumps(ldict, indent=4))
