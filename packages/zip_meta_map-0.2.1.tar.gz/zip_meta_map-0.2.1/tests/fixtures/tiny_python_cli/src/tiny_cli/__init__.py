"""Tiny CLI."""
