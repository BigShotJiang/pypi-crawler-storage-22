from ziqara.resources.chat import ChatCompletions

__all__ = ["ChatCompletions"]
