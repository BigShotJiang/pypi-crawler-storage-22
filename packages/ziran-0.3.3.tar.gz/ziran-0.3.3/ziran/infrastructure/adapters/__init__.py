"""Agent framework adapters."""
