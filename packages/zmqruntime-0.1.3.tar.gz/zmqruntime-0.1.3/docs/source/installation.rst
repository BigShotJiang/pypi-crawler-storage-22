Installation
============

Install the core package from PyPI:

.. code-block:: bash

    pip install zmqruntime

If you're developing locally:

.. code-block:: bash

    git clone https://github.com/OpenHCSDev/zmqruntime.git
    cd zmqruntime
    pip install -e .
