### DOCUMENTATION: https://zonerama.com/services/zpsforandroid/apiservice.asmx
###                https://zonerama.com/services/zpsforandroid/dataservice.asmx


APISERVICE_WSDL_URL = "https://zonerama.com/services/zpsforandroid/apiservice.asmx?WSDL"
DATASERVICE_WSDL_URL = "https://zonerama.com/services/zpsforandroid/dataservice.asmx?WSDL"

ZIP_REQUEST_URL = "https://zonerama.com/Zip/Album"
ZIP_READY_URL = "https://zonerama.com/Zip/IsReady"
ZIP_DOWNLOAD_URL = "https://zonerama.com/Zip/Download"
