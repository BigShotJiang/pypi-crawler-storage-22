from dataclasses import dataclass
from datetime import datetime, tzinfo

from zoneramaapi.models.aliases import AccountID, AlbumID, PhotoID, TabID
from zoneramaapi.models.enums import AlbumType
from zoneramaapi.models.licence import Licence
from zoneramaapi.models.utils import map_key, map_value

FIELD_MAP = {
    "ID": "id",
    "ParentID": "parent_id",
    "AccountID": "account_id",
    "PhotoID": "cover_photo_id",
    "Inserted": "created_at",
    "Changed": "changed_at",
    "Updated": "updated_at",
    "Text": "description",
    "Pwd": "password",
    "PwdHelp": "password_hint",
    "PublicList": "is_public_list",
    "PageUrl": "page_url",
    "ImageUrl": "cover_image_url",
    "ImagePatternUrl": "cover_image_pattern_url",
    "IsPasswordProtected": "is_password_protected",
    "IsPrivate": "is_private",
    "IsProtected": "is_protected",
    "IsPublic": "is_public",
    "IsSecret": "is_secret",
}


@dataclass(slots=True)
class Album:
    """
    Represents an album in user's gallery.

    Attributes:
        id: Unique identifier for the album.
        parent_id: ???
        account_id: Identifier of the tab's owner.
        cover_photo_id: Identifier of the cover photo.
        name: The display name of the album.
        created_at: Timestamp of the album creation.
        changed_at: Timestamp of the last modification.
            Updated on:
                - Rename
                - Password protection change
                - Photo sorting order change
                - Move photo in or out
                - Create photo
                - Delete photo
                - Set (main) cover photo
                - Album description change
            Not updated on:
                - Album tab change
                - Album sorting order change
                - Album URL change
                - Album secondary cover photo change
        updated_at: Timestamp of the last update.
            None if just created.
            Updated on:
                - ???
        description: Optional text description of the album.
        password: Optional password string used to access the album if locked
        password_hint: Optional hint for the album's password.
        secret: ???
        is_public_list: ???
        path_of_id: ???
        path_of_name: ???
        path_level: ???
        protected: ???
        longitude: ???
        latitude: ???
        tab_id: Identifier of the parent tab.
        facebook_synced: ???
        page_url: URL for web access.
        cover_image_url: URL of the cover image. Requested width = 20000, height = 20000.
        cover_image_pattern_url: URL of the cover image. Requested width = {width}, height = {height}.
        is_password_protected: Flag indicating if a password is required to view the album.
        is_private: ???
        is_protected: ???
        is_public: ???
        is_secret: ???
        type: 'Normal' for a typical album.
        albums: ???
        photos: Number of photos in the album.
        size: ???
        comments: ???
        browse: ???
        like: ???
        licence: A licence object associated with the album.
        sorting: Current photo sorting order in the album.
        watermark_text: Optional text used for watermarking photos.
        watermark_type: ???
    """

    id: AlbumID
    parent_id: int | None
    account_id: AccountID
    cover_photo_id: PhotoID
    name: str
    created_at: datetime
    changed_at: datetime
    updated_at: datetime | None
    description: str | None
    password: str | None
    password_hint: str | None
    secret: str
    is_public_list: bool
    path_of_id: str
    path_of_name: str
    path_level: int
    protected: bool | None
    longitude: float | None
    latitude: float | None
    tab_id: TabID
    facebook_synced: int
    page_url: str
    cover_image_url: str
    cover_image_pattern_url: str
    is_password_protected: bool
    is_private: bool
    is_protected: bool
    is_public: bool
    is_secret: bool
    type: AlbumType
    albums: int
    photos: int
    size: int
    comments: int
    browse: int
    like: int
    licence: Licence
    sorting: str
    watermark_text: str | None
    watermark_type: int

    @classmethod
    def from_api(cls, data: dict, *, timezone: tzinfo | None = None) -> Album:
        mapped_data = {
            map_key(FIELD_MAP, k): map_value(v, timezone=timezone)
            for k, v in data.items()
        }

        if "type" in mapped_data:
            mapped_data["type"] = AlbumType(mapped_data["type"])

        if "licence" in mapped_data:
            mapped_data["licence"] = Licence.from_api(mapped_data["licence"].__values__)

        return cls(**mapped_data)

    def __repr__(self) -> str:
        return f"<Album id={self.id} name={self.name!r}>"
