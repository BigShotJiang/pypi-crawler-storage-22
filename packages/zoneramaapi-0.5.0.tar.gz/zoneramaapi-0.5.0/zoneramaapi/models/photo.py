from dataclasses import dataclass
from datetime import datetime, tzinfo

from zoneramaapi.models.aliases import AccountID, AlbumID, TabID
from zoneramaapi.models.licence import Licence
from zoneramaapi.models.metadata import Metadata
from zoneramaapi.models.alt_stream import AltStream
from zoneramaapi.models.enums import MediaType
from zoneramaapi.models.utils import map_key, map_value

FIELD_MAP = {
    "ID": "id",
    "AlbumID": "album_id",
    "AccountID": "account_id",
    "Inserted": "created_at",
    "Changed": "changed_at",
    "Pwd": "password",
    "Changed": "changed_at",
    "PathOfID": "path_of_id",
    "MD5Hash": "MD5",
}


@dataclass(slots=True)
class Photo:
    id: TabID
    album_id: AlbumID
    account_id: AccountID
    name: str
    created_at: datetime
    changed_at: datetime
    text: str | None
    password: str | None
    secret: str | None
    public_list: bool
    path_of_id: str
    path_of_name: str
    path_level: int
    protected: bool | None
    longitude: float | None
    latitude: float | None
    media_type: MediaType
    page_url: str
    image_url: str
    image_pattern_url: str
    original_image_url: str
    is_password_protected: bool
    is_private: bool
    is_protected: bool
    is_public: bool
    is_secret: bool
    width: int
    height: int
    size: int
    timestamp: datetime
    rotate_flip: int
    browse: int
    comments: int
    like: int
    score_sum: int
    score_count: int
    score: float
    metadata: Metadata
    licence: Licence
    MD5: str
    alt_streams: list[AltStream]
    placeholder: bool

    @classmethod
    def from_api(cls, data: dict, *, timezone: tzinfo | None = None) -> Photo:
        mapped_data = {
            map_key(FIELD_MAP, k): map_value(v, timezone=timezone)
            for k, v in data.items()
        }

        if "licence" in mapped_data:
            mapped_data["licence"] = Licence.from_api(mapped_data["licence"].__values__)

        if "metadata" in mapped_data:
            mapped_data["metadata"] = Metadata.from_api(
                mapped_data["metadata"].__values__
            )

        if "alt_streams" in mapped_data:
            mapped_data["alt_streams"] = [
                AltStream.from_api(stream.__values__)
                for stream in mapped_data["alt_streams"]["AltStream"]
            ]

        if "media_type" in mapped_data:
            mapped_data["media_type"] = MediaType(mapped_data["media_type"])

        return cls(**mapped_data)

    def __repr__(self) -> str:
        return f"<Photo id={self.id} name={self.name!r}>"
