from dataclasses import dataclass

from zoneramaapi.models.utils import map_key, map_value

FIELD_MAP = {}


@dataclass(slots=True)
class AltStream:
    name: str
    size: int
    url: str

    @classmethod
    def from_api(cls, data: dict) -> AltStream:
        return cls(**{map_key(FIELD_MAP, k): map_value(v) for k, v in data.items()})
