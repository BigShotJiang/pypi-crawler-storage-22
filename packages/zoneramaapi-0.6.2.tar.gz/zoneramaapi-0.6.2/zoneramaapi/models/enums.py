from enum import Enum


class TabType(str, Enum):
    NORMAL = "Normal"
    CLOUD = "Cloud"


class AlbumType(str, Enum):
    NORMAL = "Normal"
    MOBILE_DEVICES = "MobileDevices"
    UNCOMPLETE_ALBUMS = "UncompleteAlbum"
    SLIDE_ON_PROFILE = "SlideOnProfile"
    ISOLATED = "Isolated"
    UNCOMPLETE_ALBUM_GUEST = "UncompleteAlbumGuest"


class MediaType(int, Enum):
    IMAGE = 1
    VIDEO = 2


class VideoState(str, Enum):
    IN_QUEUE = "InQueue"
    PROCESSING = "Processing"
    FAILED = "Failed"
