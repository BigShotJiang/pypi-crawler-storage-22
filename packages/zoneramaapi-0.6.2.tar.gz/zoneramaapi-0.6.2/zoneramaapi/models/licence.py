from dataclasses import dataclass

from zoneramaapi.models.utils import map_key, map_value

FIELD_MAP = {
    "CC": "creative_commons",
    "EnableCommercial": "commercial",
    "EnableDownload": "download",
    "EnableModification": "modification",
}


@dataclass(slots=True)
class Licence:
    creative_commons: bool
    commercial: bool
    download: bool
    modification: bool

    @classmethod
    def from_api(cls, data: dict) -> Licence:
        return cls(**{map_key(FIELD_MAP, k): map_value(v) for k, v in data.items()})
