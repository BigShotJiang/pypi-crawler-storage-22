from dataclasses import dataclass
from datetime import datetime

from zoneramaapi.models.utils import map_key, map_value

FIELD_MAP = {
    "CamHWMaker": "camera_maker",
    "CamHWModel": "camera_model",
    "Created": "created_at",
    "ExposureTime": "exposure",
    "FocalLength35": "focal_length_35mm",
}


@dataclass(slots=True)
class Metadata:
    aperture: str | None
    author: str | None
    camera_maker: str | None
    camera_model: str | None
    created_at: datetime | None
    description: str | None
    exposure: str | None
    flash_type: str | None
    focal_length: str | None
    focal_length_35mm: str | None
    focal_length_range: str | None
    iso: str | None
    keywords: str | None
    name: str | None

    @classmethod
    def from_api(cls, data: dict) -> Metadata:
        return cls(**{map_key(FIELD_MAP, k): map_value(v) for k, v in data.items()})
