from dataclasses import dataclass
from datetime import datetime, tzinfo

from zoneramaapi.models.aliases import AccountID, TabID
from zoneramaapi.models.enums import TabType
from zoneramaapi.models.utils import map_key, map_value

FIELD_MAP = {
    "ID": "id",
    "AccountID": "account_id",
    "Pwd": "password",
    "PwdHelp": "password_hint",
    "Public": "is_public",
    "Changed": "changed_at",
}


@dataclass(slots=True)
class Tab:
    """
    Represents a tab (folder) in user's gallery.

    Attributes:
        id: Unique identifier for the tab.
        account_id: Identifier of the tab's owner.
        name: The display name of the tab.
        rank: Sorting order.
        secret: A unique token used for access when the tab is hidden.
        password: Optional password string used to access the tab if locked.
        password_hint: Optional hint for the tab's password.
        is_password_protected: Flag indicating if a password is required to view the tab.
        is_public: Flag indicating if the tab can be accessed without the secret token.
        changed_at: Timestamp of the last modification.
            None if just created.
            Updated on:
                - Rename
                - Password protection change
                - Visibility change
                - Child album rename
                - Child album password protection change
                - Children sorting order change
                - Move photo in or out of child album
                - Create photo in child album
                - Delete photo in child album
                - Set (main) cover photo for child album
                - Child album description change
            Not updated on:
                - Change to tab sorting order
                - Move album in or out
                - (Empty) child album creation
                - Child album URL change
                - Child album secondary cover photo change
        type: 'Normal' for a typical tab.
        page_url: URL for web access.
        sorting: Current sorting order of child albums within the tab.
    """

    id: TabID
    account_id: AccountID
    name: str
    rank: int
    secret: str
    password: str | None
    password_hint: str | None
    is_password_protected: bool
    is_public: bool
    changed_at: datetime | None
    type: TabType
    page_url: str
    sorting: str

    @classmethod
    def from_api(cls, data: dict, *, timezone: tzinfo | None = None) -> Tab:
        mapped_data = {
            map_key(FIELD_MAP, k): map_value(v, timezone=timezone)
            for k, v in data.items()
        }

        if "type" in mapped_data:
            mapped_data["type"] = TabType(mapped_data["type"])

        return cls(**mapped_data)

    def __repr__(self) -> str:
        return f"<Tab id={self.id} name={self.name!r}>"
