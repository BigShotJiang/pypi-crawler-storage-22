from dataclasses import dataclass
from datetime import datetime, tzinfo

from zoneramaapi.models.aliases import AccountID
from zoneramaapi.models.utils import map_key, map_value

FIELD_MAP = {
    "ID": "id",
    "ZAID": "zoner_account_id",
    "EMail": "email",
    "Inserted": "created_at",
    "LastAccess": "last_accessed_at",
    "Changed": "changed_at",
    "ChangeAvatar": "changed_avatar_at",
}


@dataclass(slots=True)
class Account:
    """
    Represents a Zonerama user account and the user's gallery.

    Attributes:
        id (AccountID): Unique identifier for the account.
        zoner_account_id (int): Unique identifier for the associated Zoner account.
        email (str): Email address, serving as username.
        name (str | None): ???
        domain (str): The gallery's domain (domain.zonerama.com).
        full_name (str): The user's complete name.
        language (str): BCP 47 language tag (e.g. en-US).
        country (str): ISO country code of the user.
        text (str | None): ???
        created_at (datetime): Timestamp of account creation.
        last_accessed_at (datetime): Timestamp of the most recent user login or activity.
        changed_at (datetime): Timestamp of the last gallery update.
            Updated on:
                - Tab rename
                - Tab password protection change
                - Tab visibility change
                - Tab sorting order change
                - Album rename
                - Album password protection change
                - Album sorting order change
                - Move photo in or out of album
                - Create photo in album
                - Delete photo in album
                - Set (main) cover photo for album
                - Album description change
            Not updated on:
                - Move album to different tab
                - (Empty) album creation
                - Album URL change
                - Album secondary cover photo change
        changed_avatar_at (datetime): Timestamp of the last profile picture update.
        page_url (str): Absolute URL to the user's gallery page.
        avatar_url (str): URL to the user's thumbnail avatar image.
        profile_photo_url (str): URL to the high-resolution profile photograph. Likely same as the above.
        max_albums (int): Maximum number of albums allowed (0 expected).
        max_photos (int): Maximum total photos allowed across all albums (0 expected).
        max_size (int): Total storage capacity allowed (typically in bytes) (0 expected).
        albums (int): Current count of albums created by the user.
        photos (int): Current count of photos uploaded by the user.
        size (int): Current total storage used (typically in bytes).
        likes (int): Total number of 'likes' this gallery received.
    """

    id: AccountID
    zoner_account_id: int
    email: str
    name: str | None
    domain: str
    full_name: str
    language: str
    country: str
    text: str | None
    created_at: datetime
    last_accessed_at: datetime
    changed_at: datetime
    changed_avatar_at: datetime
    page_url: str
    avatar_url: str
    profile_photo_url: str
    max_albums: int
    max_photos: int
    max_size: int
    albums: int
    photos: int
    size: int
    likes: int

    @classmethod
    def from_api(cls, data: dict, *, timezone: tzinfo | None = None) -> Account:
        return cls(
            **{
                map_key(FIELD_MAP, k): map_value(v, timezone=timezone)
                for k, v in data.items()
            }
        )

    def __repr__(self) -> str:
        return f"<Account id={self.id} email={self.email!r}>"
