from dataclasses import dataclass
from datetime import datetime, tzinfo

from zoneramaapi.models.aliases import AccountID, AlbumID, TabID
from zoneramaapi.models.licence import Licence
from zoneramaapi.models.metadata import Metadata
from zoneramaapi.models.alt_stream import AltStream
from zoneramaapi.models.enums import MediaType
from zoneramaapi.models.utils import map_key, map_value
from zoneramaapi.errors import ZoneramaError

FIELD_MAP = {
    "ID": "id",
    "AlbumID": "album_id",
    "AccountID": "account_id",
    "Inserted": "created_at",
    "Changed": "changed_at",
    "Pwd": "password",
    "Changed": "changed_at",
    "PathOfID": "path_of_id",
    "MD5Hash": "MD5",
}


@dataclass(slots=True)
class Photo:
    """
    Represents a photo (image or video) on Zonerama.

    Attributes:
        id: Unique identifier for the photo.
        album_id: Identifier of the album containing the photo.
        account_id: Identifier of the photo's owner.
        name: The display name of the photo.
        created_at: Timestamp of when the photo was created in Zonerama.
        changed_at: Timestamp of the last modification.
        text: Optional description text for the photo.
        password: Optional password string used to access the photo if protected.
        secret: A unique token used for access when the tab is hidden.
        public_list: ???
        path_of_id: ???
        path_of_name: ???
        path_level: ???
        protected: ???
        longitude: Longitude coordinate where the photo was taken.
        latitude: Latitude coordinate where the photo was taken.
        media_type: The type of media (image or video).
        page_url: URL for web access.
        image_url: ???
        image_pattern_url: ???
        original_image_url: URL of the "original" jpeg image.
        is_password_protected: Flag indicating if a password is required to view the photo.
        is_private: ???
        is_protected: ???
        is_public: ???
        is_secret: ???
        width: Width of the photo in pixels.
        height: Height of the photo in pixels.
        size: ???
        timestamp: Timestamp of when the photo was taken.
        rotate_flip: ???
        browse: ???
        comments: ???
        like: ???
        score_sum: ???
        score_count: ???
        score: ???
        metadata: Metadata object containing some photographic metadata.
        licence: Licence object containing licensing information.
        MD5: MD5 hash of the photo. Does not work properly for raw files.
        alt_streams: A list of alternative streams (different formats).
        placeholder: Whether this is a placeholder photo (used during upload and processing).
    """

    id: TabID
    album_id: AlbumID
    account_id: AccountID
    name: str
    created_at: datetime
    changed_at: datetime
    text: str | None
    password: str | None
    secret: str | None
    public_list: bool
    path_of_id: str
    path_of_name: str
    path_level: int
    protected: bool | None
    longitude: float | None
    latitude: float | None
    media_type: MediaType
    page_url: str
    image_url: str
    image_pattern_url: str
    original_image_url: str
    is_password_protected: bool
    is_private: bool
    is_protected: bool
    is_public: bool
    is_secret: bool
    width: int
    height: int
    size: int
    timestamp: datetime
    rotate_flip: int
    browse: int
    comments: int
    like: int
    score_sum: int
    score_count: int
    score: float
    metadata: Metadata
    licence: Licence
    MD5: str
    alt_streams: list[AltStream]
    placeholder: bool

    @property
    def available_formats(self) -> dict[str, AltStream]:
        if self.media_type == MediaType.VIDEO:
            raise ZoneramaError(
                "available_formats is meant to be used for images only. For videos, use the Video class."
            )
        return {stream.name: stream for stream in self.alt_streams} | {
            "jpg": AltStream(name="jpg", size=self.size, url=self.original_image_url)
        }

    @classmethod
    def from_api(cls, data: dict, *, timezone: tzinfo | None = None) -> Photo:
        mapped_data = {
            map_key(FIELD_MAP, k): map_value(v, timezone=timezone)
            for k, v in data.items()
        }

        if "licence" in mapped_data:
            mapped_data["licence"] = Licence.from_api(mapped_data["licence"].__values__)

        if "metadata" in mapped_data:
            mapped_data["metadata"] = Metadata.from_api(
                mapped_data["metadata"].__values__
            )

        if "alt_streams" in mapped_data:
            mapped_data["alt_streams"] = [
                AltStream.from_api(stream.__values__)
                for stream in mapped_data["alt_streams"]["AltStream"]
            ]

        if "media_type" in mapped_data:
            mapped_data["media_type"] = MediaType(mapped_data["media_type"])

        return cls(**mapped_data)

    def __repr__(self) -> str:
        return f"<Photo id={self.id} name={self.name!r}>"
