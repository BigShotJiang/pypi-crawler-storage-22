from dataclasses import dataclass

from zoneramaapi.models.enums import VideoState
from zoneramaapi.models.video_stream import VideoStream
from zoneramaapi.models.utils import map_key, map_value

FIELD_MAP = {}


@dataclass(slots=True)
class Video:
    length: int
    status: VideoState
    streams: list[VideoStream]

    @classmethod
    def from_api(cls, data: dict) -> Video:
        mapped_data = {map_key(FIELD_MAP, k): map_value(v) for k, v in data.items()}

        if "streams" in mapped_data:
            mapped_data["streams"] = [
                VideoStream.from_api(stream.__values__)
                for stream in mapped_data["streams"]["VideoStream"]
            ]

        return cls(**mapped_data)
