#!/usr/bin/env python
from setuptools import setup

setup(python_requires=">=3.10, <3.14")
