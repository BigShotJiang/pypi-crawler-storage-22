my_module_menu.append_page(
    Page(
        name="my-module.my-entity",
        caption="My Entity",
        url="/my-module/my-entities",
        permission="my-entity:read",
    )
)
