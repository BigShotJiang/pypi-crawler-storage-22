from my_app_name.config import APP_MY_MODULE_BASE_URL
from my_app_name.module.my_module.client.my_module_client import MyModuleClient


class MyModuleAPIClient(MyModuleClient):
    pass
