import asyncio
from typing import Any, Callable, Coroutine


def create_speak_tool(
    voice_name: str | None = None,  # Renamed from voice_id to match Google
    rate: int | None = None,
    volume: float | None = None,
    tool_name: str | None = None,
    tool_description: str | None = None,
) -> Callable[[str, str | None], Coroutine[Any, Any, bool]]:
    """
    Factory to create a speak tool using pyttsx3 (offline TTS).
    """

    async def speak(
        text: str, voice_name: str | None = voice_name
    ) -> bool:
        """Converts text to speech using pyttsx3."""
        import sys
        if sys.platform == "darwin":
            print(f"Speaking (say): {text}")
            cmd = ["say", text]
            if voice_name:
                cmd.extend(["-v", voice_name])
            if rate:
                # pyttsx3 rate 200 is roughly normal.
                # say rate 175 is roughly normal.
                # mapping: say_rate = (rate / 200) * 175
                say_rate = int((rate / 200) * 175)
                cmd.extend(["-r", str(say_rate)])
            
            process = await asyncio.create_subprocess_exec(
                *cmd,
                stdout=asyncio.subprocess.DEVNULL,
                stderr=asyncio.subprocess.DEVNULL
            )
            await process.wait()
            return True

        # Capture closure variables to avoid confusion with local args
        factory_rate = rate
        factory_volume = volume

        def _speak_sync():
            try:
                import pyttsx3
            except ImportError:
                raise ImportError(
                    "pyttsx3 is not installed. Please install zrb-extras[tts] or zrb-extras[all]."
                )

            try:
                engine = pyttsx3.init()
                final_voice = voice_name
                if final_voice:
                    engine.setProperty("voice", final_voice)
                if factory_rate:
                    engine.setProperty("rate", factory_rate)
                if factory_volume is not None:
                    engine.setProperty("volume", factory_volume)
                print(f"Speaking (pyttsx3): {text}")
                engine.say(text)
                engine.runAndWait()
                return True
            except Exception as e:
                print(f"Error in pyttsx3: {e}")
                return False

        return await asyncio.to_thread(_speak_sync)

    if tool_name is not None:
        speak.__name__ = tool_name
    if tool_description is not None:
        speak.__doc__ = tool_description
    return speak
