from zscams.deps import ensure_native_deps

ensure_native_deps()
