"""
Zuna: a 380M-parameter masked diffusion autoencoder EEG Foundation Model trained to reconstruct, denoise, and upsample scalp-EEG signals.  

Main functions:
    zuna.run_pipeline()           - Complete pipeline: .fif → .pt → .pt → .fif
    zuna.preprocessing()          - .fif → .pt (resample, filter, epoch, normalize)
    zuna.inference()              - .pt → .pt (model reconstruction)
    zuna.pt_to_fif()              - .pt → .fif (denormalize, concatenate)
    zuna.compare_plot_pipeline()  - Generate comparison plots

See tutorials/run_zuna_pipeline.py for a complete working example.
Use help(zuna.preprocessing) etc. for detailed documentation.
"""

__version__ = "0.0.3"

from .preprocessing.batch import preprocessing
from .pipeline import inference, pt_to_fif
from .visualization.compare import compare_plot_pipeline
# from .tutorials.run_zuna_pipeline import run_pipeline

__all__ = [
    'preprocessing',
    'inference',
    'pt_to_fif',
    'compare_plot_pipeline',
    # 'run_pipeline',
]
