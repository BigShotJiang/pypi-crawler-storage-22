# demo.py
from zylos import mean, hypotenuse

grades = [85, 92, 78, 90]
print(f"Zylos Mean: {mean(grades)}")

c = hypotenuse(3, 4)
print(f"The diagonal length is: {c}")