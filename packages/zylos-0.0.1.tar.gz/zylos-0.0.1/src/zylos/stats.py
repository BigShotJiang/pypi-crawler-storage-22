# zylos/stats.py

import math

def mean(data):
    """Returns the average of a list of numbers."""
    return sum(data) / len(data)

def hypotenuse(a, b):
    """Calculates the long side of a right triangle."""
    return math.sqrt(a**2 + b**2)

def percentage_change(old, new):
    """Calculates % increase or decrease."""
    return ((new - old) / old) * 100