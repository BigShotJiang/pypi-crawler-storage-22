import argparse
from zyworkflow.policy.bnn import train_single_view_parallel_chunk

parser = argparse.ArgumentParser(description="训练脚本")
parser.add_argument("--task_name", type=str, required=False, default=None)
parser.add_argument("--algo_type", type=str, required=True, default=None)
parser.add_argument("--action_type", type=str, required=True, default=None)
parser.add_argument("--report_url", type=str, required=False, default=None)
parser.add_argument("--root_dir", type=str, required=True)
parser.add_argument("--batch_size", type=int, default=48)
parser.add_argument("--seq_len", type=int, default=4)
parser.add_argument("--action_chunk", type=int, default=8)
parser.add_argument("--lr", type=float, default=1e-4)
parser.add_argument("--num_epochs", type=int, default=500)
parser.add_argument("--start_epoch", type=int, default=0)
parser.add_argument("--lambda_joints", type=float, default=10.0)
parser.add_argument("--lambda_grip", type=float, default=5.0)
parser.add_argument("--lambda_success", type=float, default=2.0)
parser.add_argument("--log_path", type=str, default=None)
parser.add_argument("--ckpt_dir", type=str, required=True)
parser.add_argument("--success_mode", type=str, default="within_horizon")

args = parser.parse_args()

if args.algo_type == 'bnn' and args.action_type in ['pick', 'place']:
    train_single_view_parallel_chunk(
        task_name=args.task_name,
        root_dir=args.root_dir,
        batch_size=args.batch_size,
        seq_len=args.seq_len,
        action_chunk=args.action_chunk,
        lr=args.lr,
        num_epochs=args.num_epochs,
        start_epoch=args.start_epoch,
        log_path=args.log_path,
        ckpt_dir=args.ckpt_dir,
        lambda_joints=args.lambda_joints,
        lambda_grip=args.lambda_grip,
        lambda_success=args.lambda_success,
        success_mode=args.success_mode,
        report_url=args.report_url,
    )
